using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AntiCheatMgr_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BC0234 (12321332), len: 8  VirtAddr: 0x00BC0234 RVA: 0x00BC0234 token: 100663808 methodIndex: 29853 delegateWrapperIndex: 0 methodInvoker: 0
        public AntiCheatMgr_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BC0234: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0238: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC023C (12321340), len: 4868  VirtAddr: 0x00BC023C RVA: 0x00BC023C token: 100663809 methodIndex: 29854 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_48;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_49;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_50;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_51;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_52;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_53;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_54;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_55;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_56;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_57;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_58;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_59;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_60;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_61;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_62;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_63;
            // 0x00BC023C: STP x28, x27, [sp, #-0x60]! | stack[1152921510051211488] = ???;  stack[1152921510051211496] = ???;  //  dest_result_addr=1152921510051211488 |  dest_result_addr=1152921510051211496
            // 0x00BC0240: STP x26, x25, [sp, #0x10]  | stack[1152921510051211504] = ???;  stack[1152921510051211512] = ???;  //  dest_result_addr=1152921510051211504 |  dest_result_addr=1152921510051211512
            // 0x00BC0244: STP x24, x23, [sp, #0x20]  | stack[1152921510051211520] = ???;  stack[1152921510051211528] = ???;  //  dest_result_addr=1152921510051211520 |  dest_result_addr=1152921510051211528
            // 0x00BC0248: STP x22, x21, [sp, #0x30]  | stack[1152921510051211536] = ???;  stack[1152921510051211544] = ???;  //  dest_result_addr=1152921510051211536 |  dest_result_addr=1152921510051211544
            // 0x00BC024C: STP x20, x19, [sp, #0x40]  | stack[1152921510051211552] = ???;  stack[1152921510051211560] = ???;  //  dest_result_addr=1152921510051211552 |  dest_result_addr=1152921510051211560
            // 0x00BC0250: STP x29, x30, [sp, #0x50]  | stack[1152921510051211568] = ???;  stack[1152921510051211576] = ???;  //  dest_result_addr=1152921510051211568 |  dest_result_addr=1152921510051211576
            // 0x00BC0254: ADD x29, sp, #0x50         | X29 = (1152921510051211488 + 80) = 1152921510051211568 (0x1000000144826930);
            // 0x00BC0258: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC025C: LDRB w8, [x20, #0xb8b]     | W8 = (bool)static_value_03733B8B;       
            // 0x00BC0260: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC0264: TBNZ w8, #0, #0xbc0280     | if (static_value_03733B8B == true) goto label_0;
            // 0x00BC0268: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00BC026C: LDR x8, [x8, #0xc18]       | X8 = 0x2B8AF74;                         
            // 0x00BC0270: LDR w0, [x8]               | W0 = 0x29B;                             
            // 0x00BC0274: BL #0x2782188              | X0 = sub_2782188( ?? 0x29B, ????);      
            // 0x00BC0278: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC027C: STRB w8, [x20, #0xb8b]     | static_value_03733B8B = true;            //  dest_result_addr=57883531
            label_0:
            // 0x00BC0280: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC0284: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC0288: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BC028C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC0290: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC0294: LDR x20, [x8]              | X20 = typeof(AntiCheatMgr);             
            // 0x00BC0298: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC029C: TBZ w8, #0, #0xbc02ac      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BC02A0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC02A4: CBNZ w8, #0xbc02ac         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BC02A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BC02AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC02B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC02B4: MOV x1, x20                | X1 = 1152921504902479872 (0x10000000119F0000);//ML01
            // 0x00BC02B8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC02BC: ADRP x27, #0x35ef000       | X27 = 56553472 (0x35EF000);             
            // 0x00BC02C0: LDR x27, [x27, #0xff0]     | X27 = 1152921504987155056;              
            // 0x00BC02C4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BC02C8: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC02CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC02D0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC02D4: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00BC02D8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC02DC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC02E0: ADRP x26, #0x3607000       | X26 = 56651776 (0x3607000);             
            // 0x00BC02E4: LDR x26, [x26, #0xbb8]     | X26 = 1152921504608284672;              
            // 0x00BC02E8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC02EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC02F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC02F4: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC02F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_2 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC02FC: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00BC0300: CBNZ x21, #0xbc0308        | if ( != null) goto label_3;             
            if(null != null)
            {
                goto label_3;
            }
            // 0x00BC0304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00BC0308: CBZ x22, #0xbc032c         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x00BC030C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0310: MOV x0, x22                | X0 = val_2;//m1                         
            // 0x00BC0314: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0318: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00BC031C: CBNZ x0, #0xbc032c         | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x00BC0320: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00BC0324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0328: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_5:
            // 0x00BC032C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0330: CBNZ w8, #0xbc0340         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_6;
            // 0x00BC0334: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00BC0338: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC033C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_6:
            // 0x00BC0340: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_2;
            // 0x00BC0344: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC0348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC034C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0350: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0354: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00BC0358: CBZ x22, #0xbc037c         | if (val_3 == null) goto label_8;        
            if(val_3 == null)
            {
                goto label_8;
            }
            // 0x00BC035C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0360: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x00BC0364: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0368: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x00BC036C: CBNZ x0, #0xbc037c         | if (val_3 != null) goto label_8;        
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x00BC0370: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
            // 0x00BC0374: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0378: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_8:
            // 0x00BC037C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0380: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC0384: B.HI #0xbc0394             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_9;
            // 0x00BC0388: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00BC038C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0390: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_9:
            // 0x00BC0394: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_3;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_3;
            // 0x00BC0398: ADRP x25, #0x3600000       | X25 = 56623104 (0x3600000);             
            // 0x00BC039C: LDR x25, [x25, #0xff0]     | X25 = 1152921504607645696;              
            // 0x00BC03A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC03A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC03A8: LDR x1, [x25]              | X1 = typeof(System.UInt32);             
            // 0x00BC03AC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC03B0: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BC03B4: CBZ x22, #0xbc03d8         | if (val_4 == null) goto label_11;       
            if(val_4 == null)
            {
                goto label_11;
            }
            // 0x00BC03B8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC03BC: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00BC03C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC03C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00BC03C8: CBNZ x0, #0xbc03d8         | if (val_4 != null) goto label_11;       
            if(val_4 != null)
            {
                goto label_11;
            }
            // 0x00BC03CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00BC03D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC03D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_11:
            // 0x00BC03D8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC03DC: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BC03E0: B.HI #0xbc03f0             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_12;
            // 0x00BC03E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00BC03E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC03EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_12:
            // 0x00BC03F0: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_4;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_4;
            // 0x00BC03F4: LDR x1, [x25]              | X1 = typeof(System.UInt32);             
            // 0x00BC03F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC03FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0400: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0404: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BC0408: CBZ x22, #0xbc042c         | if (val_5 == null) goto label_14;       
            if(val_5 == null)
            {
                goto label_14;
            }
            // 0x00BC040C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0410: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x00BC0414: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0418: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x00BC041C: CBNZ x0, #0xbc042c         | if (val_5 != null) goto label_14;       
            if(val_5 != null)
            {
                goto label_14;
            }
            // 0x00BC0420: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x00BC0424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0428: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_14:
            // 0x00BC042C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0430: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00BC0434: B.HI #0xbc0444             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_15;
            // 0x00BC0438: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00BC043C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0440: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_15:
            // 0x00BC0444: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_5;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_5;
            // 0x00BC0448: CBNZ x20, #0xbc0450        | if (val_1 != null) goto label_16;       
            if(val_1 != null)
            {
                goto label_16;
            }
            // 0x00BC044C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_16:
            // 0x00BC0450: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00BC0454: LDR x8, [x8, #0x5f0]       | X8 = (string**)(1152921510051072512)("SetHeroAntiCheatCS");
            // 0x00BC0458: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC045C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0460: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0464: LDR x1, [x8]               | X1 = "SetHeroAntiCheatCS";              
            // 0x00BC0468: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC046C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0470: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0474: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_6 = val_1.GetMethod(name:  "SetHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0478: ADRP x24, #0x3656000       | X24 = 56975360 (0x3656000);             
            // 0x00BC047C: LDR x24, [x24, #0xa58]     | X24 = 1152921504782938112;              
            // 0x00BC0480: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00BC0484: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0488: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC048C: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache0;
            val_48 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache0;
            // 0x00BC0490: CBNZ x22, #0xbc04dc        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache0 != null) goto label_17;
            if(val_48 != null)
            {
                goto label_17;
            }
            // 0x00BC0494: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00BC0498: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC049C: LDR x8, [x8, #0x2d8]       | X8 = 1152921510051076720;               
            // 0x00BC04A0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC04A4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheatCS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC04A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BC04AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC04B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC04B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC04B8: MOV x2, x22                | X2 = 1152921510051076720 (0x1000000144805A70);//ML01
            // 0x00BC04BC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_7;
            // 0x00BC04C0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheatCS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheatCS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC04C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC04C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC04CC: STR x23, [x8]              | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942208
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache0 = val_49;
            // 0x00BC04D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC04D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC04D8: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_48 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache0;
            label_17:
            // 0x00BC04DC: CBNZ x19, #0xbc04e4        | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x00BC04E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheatCS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_18:
            // 0x00BC04E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC04E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC04EC: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x00BC04F0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC04F4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_48);
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_48);
            // 0x00BC04F8: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC04FC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0500: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC0504: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC0508: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC050C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0510: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC0514: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC0518: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC051C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0520: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC0524: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC0528: TBZ w9, #0, #0xbc053c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00BC052C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC0530: CBNZ w9, #0xbc053c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00BC0534: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC0538: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_20:
            // 0x00BC053C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0540: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0544: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC0548: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC054C: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BC0550: CBNZ x21, #0xbc0558        | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x00BC0554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_21:
            // 0x00BC0558: CBZ x22, #0xbc057c         | if (val_8 == null) goto label_23;       
            if(val_8 == null)
            {
                goto label_23;
            }
            // 0x00BC055C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0560: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x00BC0564: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0568: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x00BC056C: CBNZ x0, #0xbc057c         | if (val_8 != null) goto label_23;       
            if(val_8 != null)
            {
                goto label_23;
            }
            // 0x00BC0570: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x00BC0574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0578: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_23:
            // 0x00BC057C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0580: CBNZ w8, #0xbc0590         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_24;
            // 0x00BC0584: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x00BC0588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC058C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_24:
            // 0x00BC0590: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_8;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_8;
            // 0x00BC0594: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC0598: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC059C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC05A0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC05A4: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BC05A8: CBZ x22, #0xbc05cc         | if (val_9 == null) goto label_26;       
            if(val_9 == null)
            {
                goto label_26;
            }
            // 0x00BC05AC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC05B0: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00BC05B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC05B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x00BC05BC: CBNZ x0, #0xbc05cc         | if (val_9 != null) goto label_26;       
            if(val_9 != null)
            {
                goto label_26;
            }
            // 0x00BC05C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x00BC05C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC05C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_26:
            // 0x00BC05CC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC05D0: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC05D4: B.HI #0xbc05e4             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_27;
            // 0x00BC05D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x00BC05DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC05E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_27:
            // 0x00BC05E4: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_9;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_9;
            // 0x00BC05E8: CBNZ x20, #0xbc05f0        | if (val_1 != null) goto label_28;       
            if(val_1 != null)
            {
                goto label_28;
            }
            // 0x00BC05EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_28:
            // 0x00BC05F0: ADRP x28, #0x365f000       | X28 = 57012224 (0x365F000);             
            // 0x00BC05F4: LDR x28, [x28, #0xad8]     | X28 = (string**)(1152921510051085936)("GetHeroAntiCheatCS");
            // 0x00BC05F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC05FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0600: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0604: LDR x1, [x28]              | X1 = "GetHeroAntiCheatCS";              
            // 0x00BC0608: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC060C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0610: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0614: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "GetHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0618: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC061C: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x00BC0620: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0624: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache1;
            val_50 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache1;
            // 0x00BC0628: CBNZ x22, #0xbc0674        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache1 != null) goto label_29;
            if(val_50 != null)
            {
                goto label_29;
            }
            // 0x00BC062C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BC0630: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0634: LDR x8, [x8, #0xb10]       | X8 = 1152921510051090144;               
            // 0x00BC0638: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC063C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0640: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_11 = null;
            // 0x00BC0644: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC064C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0650: MOV x2, x22                | X2 = 1152921510051090144 (0x1000000144808EE0);//ML01
            // 0x00BC0654: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_11;
            // 0x00BC0658: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC065C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0660: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0664: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942216
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache1 = val_49;
            // 0x00BC0668: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC066C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0670: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_50 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache1;
            label_29:
            // 0x00BC0674: CBNZ x19, #0xbc067c        | if (X1 != 0) goto label_30;             
            if(X1 != 0)
            {
                goto label_30;
            }
            // 0x00BC0678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_30:
            // 0x00BC067C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0680: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0684: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x00BC0688: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC068C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_50);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_50);
            // 0x00BC0690: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0694: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0698: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC069C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC06A0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC06A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC06A8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC06AC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC06B0: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC06B4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC06B8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC06BC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC06C0: TBZ w9, #0, #0xbc06d4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x00BC06C4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC06C8: CBNZ w9, #0xbc06d4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x00BC06CC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC06D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_32:
            // 0x00BC06D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC06D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC06DC: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC06E0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC06E4: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x00BC06E8: CBNZ x21, #0xbc06f0        | if ( != null) goto label_33;            
            if(null != null)
            {
                goto label_33;
            }
            // 0x00BC06EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_33:
            // 0x00BC06F0: CBZ x22, #0xbc0714         | if (val_12 == null) goto label_35;      
            if(val_12 == null)
            {
                goto label_35;
            }
            // 0x00BC06F4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC06F8: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x00BC06FC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0700: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x00BC0704: CBNZ x0, #0xbc0714         | if (val_12 != null) goto label_35;      
            if(val_12 != null)
            {
                goto label_35;
            }
            // 0x00BC0708: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x00BC070C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0710: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_35:
            // 0x00BC0714: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0718: CBNZ w8, #0xbc0728         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_36;
            // 0x00BC071C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x00BC0720: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0724: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_36:
            // 0x00BC0728: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_12;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_12;
            // 0x00BC072C: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC0730: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0734: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0738: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC073C: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00BC0740: CBZ x22, #0xbc0764         | if (val_13 == null) goto label_38;      
            if(val_13 == null)
            {
                goto label_38;
            }
            // 0x00BC0744: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0748: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x00BC074C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0750: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x00BC0754: CBNZ x0, #0xbc0764         | if (val_13 != null) goto label_38;      
            if(val_13 != null)
            {
                goto label_38;
            }
            // 0x00BC0758: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x00BC075C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0760: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_38:
            // 0x00BC0764: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0768: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC076C: B.HI #0xbc077c             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_39;
            // 0x00BC0770: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x00BC0774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0778: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_39:
            // 0x00BC077C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_13;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_13;
            // 0x00BC0780: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BC0784: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x00BC0788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC078C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0790: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x00BC0794: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0798: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x00BC079C: CBZ x22, #0xbc07c0         | if (val_14 == null) goto label_41;      
            if(val_14 == null)
            {
                goto label_41;
            }
            // 0x00BC07A0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC07A4: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x00BC07A8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC07AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x00BC07B0: CBNZ x0, #0xbc07c0         | if (val_14 != null) goto label_41;      
            if(val_14 != null)
            {
                goto label_41;
            }
            // 0x00BC07B4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x00BC07B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC07BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_41:
            // 0x00BC07C0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC07C4: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BC07C8: B.HI #0xbc07d8             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_42;
            // 0x00BC07CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x00BC07D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC07D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_42:
            // 0x00BC07D8: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_14;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_14;
            // 0x00BC07DC: CBNZ x20, #0xbc07e4        | if (val_1 != null) goto label_43;       
            if(val_1 != null)
            {
                goto label_43;
            }
            // 0x00BC07E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_43:
            // 0x00BC07E4: LDR x1, [x28]              | X1 = "GetHeroAntiCheatCS";              
            // 0x00BC07E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC07EC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC07F0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC07F4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC07F8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC07FC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0800: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_15 = val_1.GetMethod(name:  "GetHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0804: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0808: MOV x21, x0                | X21 = val_15;//m1                       
            // 0x00BC080C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0810: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache2;
            val_51 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache2;
            // 0x00BC0814: CBNZ x22, #0xbc0860        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache2 != null) goto label_44;
            if(val_51 != null)
            {
                goto label_44;
            }
            // 0x00BC0818: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x00BC081C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0820: LDR x8, [x8, #0x840]       | X8 = 1152921510051107552;               
            // 0x00BC0824: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0828: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC082C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_16 = null;
            // 0x00BC0830: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0838: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC083C: MOV x2, x22                | X2 = 1152921510051107552 (0x100000014480D2E0);//ML01
            // 0x00BC0840: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_16;
            // 0x00BC0844: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0848: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC084C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0850: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942224
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache2 = val_49;
            // 0x00BC0854: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0858: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC085C: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_51 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache2;
            label_44:
            // 0x00BC0860: MOV x28, x25               | X28 = 57965560 (0x3747BF8);//ML01       
            // 0x00BC0864: CBNZ x19, #0xbc086c        | if (X1 != 0) goto label_45;             
            if(X1 != 0)
            {
                goto label_45;
            }
            // 0x00BC0868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheatCS_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_45:
            // 0x00BC086C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0870: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0874: MOV x1, x21                | X1 = val_15;//m1                        
            // 0x00BC0878: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC087C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_15, func:  val_51);
            X1.RegisterCLRMethodRedirection(mi:  val_15, func:  val_51);
            // 0x00BC0880: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0884: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0888: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC088C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC0890: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0894: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0898: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x00BC089C: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x00BC08A0: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC08A4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC08A8: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x00BC08AC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC08B0: TBZ w9, #0, #0xbc08c4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x00BC08B4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC08B8: CBNZ w9, #0xbc08c4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x00BC08BC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC08C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_47:
            // 0x00BC08C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC08C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC08CC: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC08D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC08D4: MOV x22, x0                | X22 = val_17;//m1                       
            // 0x00BC08D8: CBNZ x21, #0xbc08e0        | if ( != null) goto label_48;            
            if(null != null)
            {
                goto label_48;
            }
            // 0x00BC08DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_48:
            // 0x00BC08E0: CBZ x22, #0xbc0904         | if (val_17 == null) goto label_50;      
            if(val_17 == null)
            {
                goto label_50;
            }
            // 0x00BC08E4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC08E8: MOV x0, x22                | X0 = val_17;//m1                        
            // 0x00BC08EC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC08F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x00BC08F4: CBNZ x0, #0xbc0904         | if (val_17 != null) goto label_50;      
            if(val_17 != null)
            {
                goto label_50;
            }
            // 0x00BC08F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x00BC08FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0900: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_50:
            // 0x00BC0904: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0908: CBNZ w8, #0xbc0918         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_51;
            // 0x00BC090C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x00BC0910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0914: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_51:
            // 0x00BC0918: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;
            // 0x00BC091C: CBNZ x20, #0xbc0924        | if (val_1 != null) goto label_52;       
            if(val_1 != null)
            {
                goto label_52;
            }
            // 0x00BC0920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_52:
            // 0x00BC0924: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00BC0928: LDR x8, [x8, #0xe70]       | X8 = (string**)(1152921510051112672)("RemoveHeroAntiCheatCS");
            // 0x00BC092C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0930: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0934: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0938: LDR x1, [x8]               | X1 = "RemoveHeroAntiCheatCS";           
            // 0x00BC093C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC0940: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0944: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0948: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "RemoveHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_18 = val_1.GetMethod(name:  "RemoveHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC094C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0950: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x00BC0954: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0958: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache3;
            val_52 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache3;
            // 0x00BC095C: CBNZ x22, #0xbc09a8        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache3 != null) goto label_53;
            if(val_52 != null)
            {
                goto label_53;
            }
            // 0x00BC0960: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00BC0964: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0968: LDR x8, [x8, #0xc88]       | X8 = 1152921510051116880;               
            // 0x00BC096C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0970: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheatCS_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0974: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_19 = null;
            // 0x00BC0978: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC097C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0980: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0984: MOV x2, x22                | X2 = 1152921510051116880 (0x100000014480F750);//ML01
            // 0x00BC0988: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_19;
            // 0x00BC098C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheatCS_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheatCS_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0990: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0994: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0998: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942232
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache3 = val_49;
            // 0x00BC099C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC09A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC09A4: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_52 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache3;
            label_53:
            // 0x00BC09A8: CBNZ x19, #0xbc09b0        | if (X1 != 0) goto label_54;             
            if(X1 != 0)
            {
                goto label_54;
            }
            // 0x00BC09AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheatCS_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_54:
            // 0x00BC09B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC09B4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC09B8: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x00BC09BC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC09C0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_52);
            X1.RegisterCLRMethodRedirection(mi:  val_18, func:  val_52);
            // 0x00BC09C4: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC09C8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC09CC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC09D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC09D4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC09D8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC09DC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC09E0: CBNZ x20, #0xbc09e8        | if (val_1 != null) goto label_55;       
            if(val_1 != null)
            {
                goto label_55;
            }
            // 0x00BC09E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_55:
            // 0x00BC09E8: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00BC09EC: LDR x8, [x8, #0x850]       | X8 = (string**)(1152921510051117904)("ClearHeroAntiCheat");
            // 0x00BC09F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC09F4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC09F8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC09FC: LDR x1, [x8]               | X1 = "ClearHeroAntiCheat";              
            // 0x00BC0A00: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC0A04: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0A08: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0A0C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ClearHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_20 = val_1.GetMethod(name:  "ClearHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0A10: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0A14: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x00BC0A18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0A1C: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache4;
            val_53 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache4;
            // 0x00BC0A20: CBNZ x22, #0xbc0a6c        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache4 != null) goto label_56;
            if(val_53 != null)
            {
                goto label_56;
            }
            // 0x00BC0A24: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x00BC0A28: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0A2C: LDR x8, [x8, #0x1c0]       | X8 = 1152921510051122112;               
            // 0x00BC0A30: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0A34: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheat_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0A38: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_21 = null;
            // 0x00BC0A3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0A40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0A44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0A48: MOV x2, x22                | X2 = 1152921510051122112 (0x1000000144810BC0);//ML01
            // 0x00BC0A4C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_21;
            // 0x00BC0A50: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheat_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheat_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0A54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0A58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0A5C: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942240
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache4 = val_49;
            // 0x00BC0A60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0A64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0A68: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_53 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache4;
            label_56:
            // 0x00BC0A6C: CBNZ x19, #0xbc0a74        | if (X1 != 0) goto label_57;             
            if(X1 != 0)
            {
                goto label_57;
            }
            // 0x00BC0A70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheat_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_57:
            // 0x00BC0A74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0A78: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0A7C: MOV x1, x21                | X1 = val_20;//m1                        
            // 0x00BC0A80: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC0A84: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_53);
            X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_53);
            // 0x00BC0A88: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0A8C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0A90: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC0A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0A98: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0A9C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0AA0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0AA4: CBNZ x20, #0xbc0aac        | if (val_1 != null) goto label_58;       
            if(val_1 != null)
            {
                goto label_58;
            }
            // 0x00BC0AA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_58:
            // 0x00BC0AAC: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00BC0AB0: LDR x8, [x8, #0xfb0]       | X8 = (string**)(1152921510051123136)("ClearHeroAntiCheatCS");
            // 0x00BC0AB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0AB8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0ABC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0AC0: LDR x1, [x8]               | X1 = "ClearHeroAntiCheatCS";            
            // 0x00BC0AC4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC0AC8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0ACC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0AD0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "ClearHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_22 = val_1.GetMethod(name:  "ClearHeroAntiCheatCS", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0AD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0AD8: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x00BC0ADC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0AE0: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache5;
            val_54 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache5;
            // 0x00BC0AE4: CBNZ x22, #0xbc0b30        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache5 != null) goto label_59;
            if(val_54 != null)
            {
                goto label_59;
            }
            // 0x00BC0AE8: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
            // 0x00BC0AEC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0AF0: LDR x8, [x8, #0x740]       | X8 = 1152921510051127344;               
            // 0x00BC0AF4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0AF8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheatCS_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0AFC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23 = null;
            // 0x00BC0B00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0B08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0B0C: MOV x2, x22                | X2 = 1152921510051127344 (0x1000000144812030);//ML01
            // 0x00BC0B10: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_23;
            // 0x00BC0B14: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheatCS_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheatCS_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0B18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0B1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0B20: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942248
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache5 = val_49;
            // 0x00BC0B24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0B28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0B2C: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_54 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache5;
            label_59:
            // 0x00BC0B30: CBNZ x19, #0xbc0b38        | if (X1 != 0) goto label_60;             
            if(X1 != 0)
            {
                goto label_60;
            }
            // 0x00BC0B34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::ClearHeroAntiCheatCS_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_60:
            // 0x00BC0B38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0B3C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0B40: MOV x1, x21                | X1 = val_22;//m1                        
            // 0x00BC0B44: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC0B48: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_54);
            X1.RegisterCLRMethodRedirection(mi:  val_22, func:  val_54);
            // 0x00BC0B4C: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0B50: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0B54: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC0B58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0B5C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0B60: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0B64: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0B68: CBNZ x20, #0xbc0b70        | if (val_1 != null) goto label_61;       
            if(val_1 != null)
            {
                goto label_61;
            }
            // 0x00BC0B6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_61:
            // 0x00BC0B70: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BC0B74: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921510043458688)("Clear");
            // 0x00BC0B78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0B7C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0B80: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0B84: LDR x1, [x8]               | X1 = "Clear";                           
            // 0x00BC0B88: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC0B8C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0B90: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0B94: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_24 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0B98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0B9C: MOV x21, x0                | X21 = val_24;//m1                       
            // 0x00BC0BA0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0BA4: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache6;
            val_55 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache6;
            // 0x00BC0BA8: CBNZ x22, #0xbc0bf4        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache6 != null) goto label_62;
            if(val_55 != null)
            {
                goto label_62;
            }
            // 0x00BC0BAC: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x00BC0BB0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0BB4: LDR x8, [x8, #0x7c8]       | X8 = 1152921510051132464;               
            // 0x00BC0BB8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0BBC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0BC0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25 = null;
            // 0x00BC0BC4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0BC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0BCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0BD0: MOV x2, x22                | X2 = 1152921510051132464 (0x1000000144813430);//ML01
            // 0x00BC0BD4: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_25;
            // 0x00BC0BD8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0BDC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0BE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0BE4: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942256
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache6 = val_49;
            // 0x00BC0BE8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0BEC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0BF0: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_55 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache6;
            label_62:
            // 0x00BC0BF4: CBNZ x19, #0xbc0bfc        | if (X1 != 0) goto label_63;             
            if(X1 != 0)
            {
                goto label_63;
            }
            // 0x00BC0BF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_63:
            // 0x00BC0BFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0C00: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0C04: MOV x1, x21                | X1 = val_24;//m1                        
            // 0x00BC0C08: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC0C0C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_55);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_55);
            // 0x00BC0C10: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0C14: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0C18: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC0C1C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00BC0C20: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0C24: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0C28: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x00BC0C2C: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC0C30: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0C34: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC0C38: TBZ w9, #0, #0xbc0c4c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_65;
            // 0x00BC0C3C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC0C40: CBNZ w9, #0xbc0c4c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
            // 0x00BC0C44: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC0C48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_65:
            // 0x00BC0C4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0C50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0C54: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC0C58: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_26 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0C5C: MOV x22, x0                | X22 = val_26;//m1                       
            // 0x00BC0C60: CBNZ x21, #0xbc0c68        | if ( != null) goto label_66;            
            if(null != null)
            {
                goto label_66;
            }
            // 0x00BC0C64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_66:
            // 0x00BC0C68: CBZ x22, #0xbc0c8c         | if (val_26 == null) goto label_68;      
            if(val_26 == null)
            {
                goto label_68;
            }
            // 0x00BC0C6C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0C70: MOV x0, x22                | X0 = val_26;//m1                        
            // 0x00BC0C74: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0C78: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_26, ????);     
            // 0x00BC0C7C: CBNZ x0, #0xbc0c8c         | if (val_26 != null) goto label_68;      
            if(val_26 != null)
            {
                goto label_68;
            }
            // 0x00BC0C80: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_26, ????);     
            // 0x00BC0C84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0C88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_68:
            // 0x00BC0C8C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0C90: CBNZ w8, #0xbc0ca0         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_69;
            // 0x00BC0C94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_26, ????);     
            // 0x00BC0C98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0C9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_69:
            // 0x00BC0CA0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_26;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_26;
            // 0x00BC0CA4: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC0CA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0CB0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_27 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0CB4: MOV x22, x0                | X22 = val_27;//m1                       
            // 0x00BC0CB8: CBZ x22, #0xbc0cdc         | if (val_27 == null) goto label_71;      
            if(val_27 == null)
            {
                goto label_71;
            }
            // 0x00BC0CBC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0CC0: MOV x0, x22                | X0 = val_27;//m1                        
            // 0x00BC0CC4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0CC8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_27, ????);     
            // 0x00BC0CCC: CBNZ x0, #0xbc0cdc         | if (val_27 != null) goto label_71;      
            if(val_27 != null)
            {
                goto label_71;
            }
            // 0x00BC0CD0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_27, ????);     
            // 0x00BC0CD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0CD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_71:
            // 0x00BC0CDC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0CE0: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC0CE4: B.HI #0xbc0cf4             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_72;
            // 0x00BC0CE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_27, ????);     
            // 0x00BC0CEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0CF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_72:
            // 0x00BC0CF4: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_27;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_27;
            // 0x00BC0CF8: LDR x1, [x28]              | X1 = typeof(System.UInt32);             
            // 0x00BC0CFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0D00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0D04: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0D08: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x00BC0D0C: CBZ x22, #0xbc0d30         | if (val_28 == null) goto label_74;      
            if(val_28 == null)
            {
                goto label_74;
            }
            // 0x00BC0D10: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0D14: MOV x0, x22                | X0 = val_28;//m1                        
            // 0x00BC0D18: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0D1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x00BC0D20: CBNZ x0, #0xbc0d30         | if (val_28 != null) goto label_74;      
            if(val_28 != null)
            {
                goto label_74;
            }
            // 0x00BC0D24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x00BC0D28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0D2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_74:
            // 0x00BC0D30: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0D34: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BC0D38: B.HI #0xbc0d48             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_75;
            // 0x00BC0D3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x00BC0D40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0D44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_75:
            // 0x00BC0D48: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_28;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_28;
            // 0x00BC0D4C: LDR x1, [x28]              | X1 = typeof(System.UInt32);             
            // 0x00BC0D50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0D54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0D58: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_29 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0D5C: MOV x22, x0                | X22 = val_29;//m1                       
            // 0x00BC0D60: CBZ x22, #0xbc0d84         | if (val_29 == null) goto label_77;      
            if(val_29 == null)
            {
                goto label_77;
            }
            // 0x00BC0D64: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0D68: MOV x0, x22                | X0 = val_29;//m1                        
            // 0x00BC0D6C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0D70: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_29, ????);     
            // 0x00BC0D74: CBNZ x0, #0xbc0d84         | if (val_29 != null) goto label_77;      
            if(val_29 != null)
            {
                goto label_77;
            }
            // 0x00BC0D78: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_29, ????);     
            // 0x00BC0D7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0D80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            label_77:
            // 0x00BC0D84: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0D88: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00BC0D8C: B.HI #0xbc0d9c             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_78;
            // 0x00BC0D90: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_29, ????);     
            // 0x00BC0D94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0D98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            label_78:
            // 0x00BC0D9C: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_29;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_29;
            // 0x00BC0DA0: CBNZ x20, #0xbc0da8        | if (val_1 != null) goto label_79;       
            if(val_1 != null)
            {
                goto label_79;
            }
            // 0x00BC0DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_79:
            // 0x00BC0DA8: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x00BC0DAC: LDR x8, [x8, #0x1f8]       | X8 = (string**)(1152921510051149872)("SetHeroAntiCheat");
            // 0x00BC0DB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0DB4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0DB8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0DBC: LDR x1, [x8]               | X1 = "SetHeroAntiCheat";                
            // 0x00BC0DC0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC0DC4: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0DC8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0DCC: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "SetHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_30 = val_1.GetMethod(name:  "SetHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0DD0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0DD4: MOV x21, x0                | X21 = val_30;//m1                       
            // 0x00BC0DD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0DDC: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache7;
            val_56 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache7;
            // 0x00BC0DE0: CBNZ x22, #0xbc0e2c        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache7 != null) goto label_80;
            if(val_56 != null)
            {
                goto label_80;
            }
            // 0x00BC0DE4: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BC0DE8: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0DEC: LDR x8, [x8, #0x7b0]       | X8 = 1152921510051154080;               
            // 0x00BC0DF0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0DF4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheat_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0DF8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31 = null;
            // 0x00BC0DFC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0E00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0E04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0E08: MOV x2, x22                | X2 = 1152921510051154080 (0x10000001448188A0);//ML01
            // 0x00BC0E0C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_31;
            // 0x00BC0E10: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheat_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheat_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0E14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0E18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0E1C: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942264
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache7 = val_49;
            // 0x00BC0E20: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0E24: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0E28: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_56 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache7;
            label_80:
            // 0x00BC0E2C: CBNZ x19, #0xbc0e34        | if (X1 != 0) goto label_81;             
            if(X1 != 0)
            {
                goto label_81;
            }
            // 0x00BC0E30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::SetHeroAntiCheat_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_81:
            // 0x00BC0E34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0E38: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0E3C: MOV x1, x21                | X1 = val_30;//m1                        
            // 0x00BC0E40: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC0E44: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_56);
            X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_56);
            // 0x00BC0E48: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0E4C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0E50: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC0E54: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC0E58: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0E5C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0E60: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x00BC0E64: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC0E68: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0E6C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC0E70: TBZ w9, #0, #0xbc0e84      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_83;
            // 0x00BC0E74: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC0E78: CBNZ w9, #0xbc0e84         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
            // 0x00BC0E7C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC0E80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_83:
            // 0x00BC0E84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0E88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0E8C: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC0E90: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_32 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0E94: MOV x22, x0                | X22 = val_32;//m1                       
            // 0x00BC0E98: CBNZ x21, #0xbc0ea0        | if ( != null) goto label_84;            
            if(null != null)
            {
                goto label_84;
            }
            // 0x00BC0E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_84:
            // 0x00BC0EA0: CBZ x22, #0xbc0ec4         | if (val_32 == null) goto label_86;      
            if(val_32 == null)
            {
                goto label_86;
            }
            // 0x00BC0EA4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0EA8: MOV x0, x22                | X0 = val_32;//m1                        
            // 0x00BC0EAC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0EB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_32, ????);     
            // 0x00BC0EB4: CBNZ x0, #0xbc0ec4         | if (val_32 != null) goto label_86;      
            if(val_32 != null)
            {
                goto label_86;
            }
            // 0x00BC0EB8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_32, ????);     
            // 0x00BC0EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0EC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_86:
            // 0x00BC0EC4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0EC8: CBNZ w8, #0xbc0ed8         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_87;
            // 0x00BC0ECC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_32, ????);     
            // 0x00BC0ED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0ED4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_87:
            // 0x00BC0ED8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_32;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_32;
            // 0x00BC0EDC: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC0EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC0EE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC0EE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_33 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC0EEC: MOV x22, x0                | X22 = val_33;//m1                       
            // 0x00BC0EF0: CBZ x22, #0xbc0f14         | if (val_33 == null) goto label_89;      
            if(val_33 == null)
            {
                goto label_89;
            }
            // 0x00BC0EF4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC0EF8: MOV x0, x22                | X0 = val_33;//m1                        
            // 0x00BC0EFC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC0F00: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_33, ????);     
            // 0x00BC0F04: CBNZ x0, #0xbc0f14         | if (val_33 != null) goto label_89;      
            if(val_33 != null)
            {
                goto label_89;
            }
            // 0x00BC0F08: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_33, ????);     
            // 0x00BC0F0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0F10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            label_89:
            // 0x00BC0F14: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC0F18: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC0F1C: B.HI #0xbc0f2c             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_90;
            // 0x00BC0F20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_33, ????);     
            // 0x00BC0F24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0F28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
            label_90:
            // 0x00BC0F2C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_33;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_33;
            // 0x00BC0F30: CBNZ x20, #0xbc0f38        | if (val_1 != null) goto label_91;       
            if(val_1 != null)
            {
                goto label_91;
            }
            // 0x00BC0F34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_91:
            // 0x00BC0F38: ADRP x28, #0x364c000       | X28 = 56934400 (0x364C000);             
            // 0x00BC0F3C: LDR x28, [x28, #0x228]     | X28 = (string**)(1152921510051163296)("GetHeroAntiCheat");
            // 0x00BC0F40: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0F44: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC0F48: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC0F4C: LDR x1, [x28]              | X1 = "GetHeroAntiCheat";                
            // 0x00BC0F50: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC0F54: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0F58: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC0F5C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_34 = val_1.GetMethod(name:  "GetHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC0F60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0F64: MOV x21, x0                | X21 = val_34;//m1                       
            // 0x00BC0F68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0F6C: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache8;
            val_57 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache8;
            // 0x00BC0F70: CBNZ x22, #0xbc0fbc        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache8 != null) goto label_92;
            if(val_57 != null)
            {
                goto label_92;
            }
            // 0x00BC0F74: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BC0F78: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC0F7C: LDR x8, [x8, #0x998]       | X8 = 1152921510051167504;               
            // 0x00BC0F80: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC0F84: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC0F88: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_35 = null;
            // 0x00BC0F8C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC0F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC0F94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0F98: MOV x2, x22                | X2 = 1152921510051167504 (0x100000014481BD10);//ML01
            // 0x00BC0F9C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_35;
            // 0x00BC0FA0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_35 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC0FA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0FA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0FAC: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942272
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache8 = val_49;
            // 0x00BC0FB0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC0FB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC0FB8: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_57 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache8;
            label_92:
            // 0x00BC0FBC: CBNZ x19, #0xbc0fc4        | if (X1 != 0) goto label_93;             
            if(X1 != 0)
            {
                goto label_93;
            }
            // 0x00BC0FC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_93:
            // 0x00BC0FC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC0FC8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC0FCC: MOV x1, x21                | X1 = val_34;//m1                        
            // 0x00BC0FD0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC0FD4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_34, func:  val_57);
            X1.RegisterCLRMethodRedirection(mi:  val_34, func:  val_57);
            // 0x00BC0FD8: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC0FDC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0FE0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC0FE4: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00BC0FE8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0FEC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC0FF0: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x00BC0FF4: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC0FF8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC0FFC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC1000: TBZ w9, #0, #0xbc1014      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_95;
            // 0x00BC1004: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1008: CBNZ w9, #0xbc1014         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_95;
            // 0x00BC100C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC1010: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_95:
            // 0x00BC1014: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1018: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC101C: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC1020: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_36 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1024: MOV x22, x0                | X22 = val_36;//m1                       
            // 0x00BC1028: CBNZ x21, #0xbc1030        | if ( != null) goto label_96;            
            if(null != null)
            {
                goto label_96;
            }
            // 0x00BC102C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_96:
            // 0x00BC1030: CBZ x22, #0xbc1054         | if (val_36 == null) goto label_98;      
            if(val_36 == null)
            {
                goto label_98;
            }
            // 0x00BC1034: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC1038: MOV x0, x22                | X0 = val_36;//m1                        
            // 0x00BC103C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC1040: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_36, ????);     
            // 0x00BC1044: CBNZ x0, #0xbc1054         | if (val_36 != null) goto label_98;      
            if(val_36 != null)
            {
                goto label_98;
            }
            // 0x00BC1048: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_36, ????);     
            // 0x00BC104C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1050: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_36, ????);     
            label_98:
            // 0x00BC1054: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC1058: CBNZ w8, #0xbc1068         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_99;
            // 0x00BC105C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_36, ????);     
            // 0x00BC1060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1064: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_36, ????);     
            label_99:
            // 0x00BC1068: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_36;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_36;
            // 0x00BC106C: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00BC1070: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1074: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1078: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_37 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC107C: MOV x22, x0                | X22 = val_37;//m1                       
            // 0x00BC1080: CBZ x22, #0xbc10a4         | if (val_37 == null) goto label_101;     
            if(val_37 == null)
            {
                goto label_101;
            }
            // 0x00BC1084: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC1088: MOV x0, x22                | X0 = val_37;//m1                        
            // 0x00BC108C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC1090: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_37, ????);     
            // 0x00BC1094: CBNZ x0, #0xbc10a4         | if (val_37 != null) goto label_101;     
            if(val_37 != null)
            {
                goto label_101;
            }
            // 0x00BC1098: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_37, ????);     
            // 0x00BC109C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC10A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
            label_101:
            // 0x00BC10A4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC10A8: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC10AC: B.HI #0xbc10bc             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_102;
            // 0x00BC10B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_37, ????);     
            // 0x00BC10B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC10B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_37, ????);     
            label_102:
            // 0x00BC10BC: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_37;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_37;
            // 0x00BC10C0: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00BC10C4: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x00BC10C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC10CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC10D0: LDR x1, [x8]               | X1 = typeof(System.Int32);              
            // 0x00BC10D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_38 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC10D8: MOV x22, x0                | X22 = val_38;//m1                       
            // 0x00BC10DC: CBZ x22, #0xbc1100         | if (val_38 == null) goto label_104;     
            if(val_38 == null)
            {
                goto label_104;
            }
            // 0x00BC10E0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC10E4: MOV x0, x22                | X0 = val_38;//m1                        
            // 0x00BC10E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC10EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_38, ????);     
            // 0x00BC10F0: CBNZ x0, #0xbc1100         | if (val_38 != null) goto label_104;     
            if(val_38 != null)
            {
                goto label_104;
            }
            // 0x00BC10F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_38, ????);     
            // 0x00BC10F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC10FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            label_104:
            // 0x00BC1100: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC1104: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00BC1108: B.HI #0xbc1118             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_105;
            // 0x00BC110C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_38, ????);     
            // 0x00BC1110: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1114: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            label_105:
            // 0x00BC1118: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_38;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_38;
            // 0x00BC111C: CBNZ x20, #0xbc1124        | if (val_1 != null) goto label_106;      
            if(val_1 != null)
            {
                goto label_106;
            }
            // 0x00BC1120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_106:
            // 0x00BC1124: LDR x1, [x28]              | X1 = "GetHeroAntiCheat";                
            // 0x00BC1128: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC112C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC1130: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC1134: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC1138: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC113C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC1140: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "GetHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_39 = val_1.GetMethod(name:  "GetHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC1144: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1148: MOV x21, x0                | X21 = val_39;//m1                       
            // 0x00BC114C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1150: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache9;
            val_58 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache9;
            // 0x00BC1154: CBNZ x22, #0xbc11a0        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache9 != null) goto label_107;
            if(val_58 != null)
            {
                goto label_107;
            }
            // 0x00BC1158: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00BC115C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC1160: LDR x8, [x8, #0xb28]       | X8 = 1152921510051184912;               
            // 0x00BC1164: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC1168: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC116C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_40 = null;
            // 0x00BC1170: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC1174: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1178: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC117C: MOV x2, x22                | X2 = 1152921510051184912 (0x1000000144820110);//ML01
            // 0x00BC1180: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_40;
            // 0x00BC1184: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_40 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC1188: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC118C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1190: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942280
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache9 = val_49;
            // 0x00BC1194: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1198: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC119C: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_58 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cache9;
            label_107:
            // 0x00BC11A0: CBNZ x19, #0xbc11a8        | if (X1 != 0) goto label_108;            
            if(X1 != 0)
            {
                goto label_108;
            }
            // 0x00BC11A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::GetHeroAntiCheat_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_108:
            // 0x00BC11A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC11AC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC11B0: MOV x1, x21                | X1 = val_39;//m1                        
            // 0x00BC11B4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC11B8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_39, func:  val_58);
            X1.RegisterCLRMethodRedirection(mi:  val_39, func:  val_58);
            // 0x00BC11BC: LDR x21, [x27]             | X21 = typeof(System.Type[]);            
            // 0x00BC11C0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC11C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC11C8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC11CC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC11D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC11D4: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x00BC11D8: LDR x22, [x26]             | X22 = typeof(System.String);            
            // 0x00BC11DC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC11E0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC11E4: TBZ w9, #0, #0xbc11f8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_110;
            // 0x00BC11E8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC11EC: CBNZ w9, #0xbc11f8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_110;
            // 0x00BC11F0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC11F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_110:
            // 0x00BC11F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC11FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1200: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC1204: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_41 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1208: MOV x22, x0                | X22 = val_41;//m1                       
            // 0x00BC120C: CBNZ x21, #0xbc1214        | if ( != null) goto label_111;           
            if(null != null)
            {
                goto label_111;
            }
            // 0x00BC1210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
            label_111:
            // 0x00BC1214: CBZ x22, #0xbc1238         | if (val_41 == null) goto label_113;     
            if(val_41 == null)
            {
                goto label_113;
            }
            // 0x00BC1218: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC121C: MOV x0, x22                | X0 = val_41;//m1                        
            // 0x00BC1220: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC1224: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_41, ????);     
            // 0x00BC1228: CBNZ x0, #0xbc1238         | if (val_41 != null) goto label_113;     
            if(val_41 != null)
            {
                goto label_113;
            }
            // 0x00BC122C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_41, ????);     
            // 0x00BC1230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1234: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_41, ????);     
            label_113:
            // 0x00BC1238: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC123C: CBNZ w8, #0xbc124c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_114;
            // 0x00BC1240: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_41, ????);     
            // 0x00BC1244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1248: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_41, ????);     
            label_114:
            // 0x00BC124C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_41;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_41;
            // 0x00BC1250: CBNZ x20, #0xbc1258        | if (val_1 != null) goto label_115;      
            if(val_1 != null)
            {
                goto label_115;
            }
            // 0x00BC1254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
            label_115:
            // 0x00BC1258: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x00BC125C: LDR x8, [x8, #0x870]       | X8 = (string**)(1152921510051190032)("RemoveHeroAntiCheat");
            // 0x00BC1260: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1264: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC1268: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC126C: LDR x1, [x8]               | X1 = "RemoveHeroAntiCheat";             
            // 0x00BC1270: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC1274: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC1278: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC127C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "RemoveHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_42 = val_1.GetMethod(name:  "RemoveHeroAntiCheat", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC1280: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1284: MOV x21, x0                | X21 = val_42;//m1                       
            // 0x00BC1288: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC128C: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheA;
            val_59 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheA;
            // 0x00BC1290: CBNZ x22, #0xbc12dc        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheA != null) goto label_116;
            if(val_59 != null)
            {
                goto label_116;
            }
            // 0x00BC1294: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00BC1298: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC129C: LDR x8, [x8, #0xaa0]       | X8 = 1152921510051194240;               
            // 0x00BC12A0: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC12A4: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheat_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC12A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_43 = null;
            // 0x00BC12AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC12B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC12B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC12B8: MOV x2, x22                | X2 = 1152921510051194240 (0x1000000144822580);//ML01
            // 0x00BC12BC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_49 = val_43;
            // 0x00BC12C0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheat_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_43 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheat_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC12C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC12C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC12CC: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782942288
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheA = val_49;
            // 0x00BC12D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC12D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC12D8: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_59 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheA;
            label_116:
            // 0x00BC12DC: CBNZ x19, #0xbc12e4        | if (X1 != 0) goto label_117;            
            if(X1 != 0)
            {
                goto label_117;
            }
            // 0x00BC12E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::RemoveHeroAntiCheat_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_117:
            // 0x00BC12E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC12E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC12EC: MOV x1, x21                | X1 = val_42;//m1                        
            // 0x00BC12F0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC12F4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_42, func:  val_59);
            X1.RegisterCLRMethodRedirection(mi:  val_42, func:  val_59);
            // 0x00BC12F8: CBNZ x20, #0xbc1300        | if (val_1 != null) goto label_118;      
            if(val_1 != null)
            {
                goto label_118;
            }
            // 0x00BC12FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_118:
            // 0x00BC1300: ADRP x9, #0x35ed000        | X9 = 56545280 (0x35ED000);              
            // 0x00BC1304: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BC1308: LDR x9, [x9, #0xac0]       | X9 = (string**)(1152921510051195264)("heroAntiCheatCSData");
            // 0x00BC130C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC1310: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC1314: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BC1318: LDR x1, [x9]               | X1 = "heroAntiCheatCSData";             
            // 0x00BC131C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BC1320: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BC1324: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1328: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BC132C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1330: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheB;
            val_60 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheB;
            // 0x00BC1334: CBNZ x22, #0xbc1380        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheB != null) goto label_119;
            if(val_60 != null)
            {
                goto label_119;
            }
            // 0x00BC1338: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x00BC133C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BC1340: LDR x8, [x8, #0xcd0]       | X8 = 1152921510051195376;               
            // 0x00BC1344: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BC1348: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatCSData_0(ref object o);
            // 0x00BC134C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_44 = null;
            // 0x00BC1350: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BC1354: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1358: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC135C: MOV x2, x22                | X2 = 1152921510051195376 (0x10000001448229F0);//ML01
            // 0x00BC1360: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_49 = val_44;
            // 0x00BC1364: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatCSData_0(ref object o));
            val_44 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatCSData_0(ref object o));
            // 0x00BC1368: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC136C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1370: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782942296
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheB = val_49;
            // 0x00BC1374: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1378: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC137C: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_60 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheB;
            label_119:
            // 0x00BC1380: CBNZ x19, #0xbc1388        | if (X1 != 0) goto label_120;            
            if(X1 != 0)
            {
                goto label_120;
            }
            // 0x00BC1384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatCSData_0(ref object o)), ????);
            label_120:
            // 0x00BC1388: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC138C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC1390: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BC1394: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BC1398: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_60);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_60);
            // 0x00BC139C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC13A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC13A4: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheC;
            val_61 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheC;
            // 0x00BC13A8: CBNZ x22, #0xbc13f4        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheC != null) goto label_121;
            if(val_61 != null)
            {
                goto label_121;
            }
            // 0x00BC13AC: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x00BC13B0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BC13B4: LDR x8, [x8, #0x4e0]       | X8 = 1152921510051196400;               
            // 0x00BC13B8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BC13BC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatCSData_0(ref object o, object v);
            // 0x00BC13C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_45 = null;
            // 0x00BC13C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BC13C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC13CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC13D0: MOV x2, x22                | X2 = 1152921510051196400 (0x1000000144822DF0);//ML01
            // 0x00BC13D4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_49 = val_45;
            // 0x00BC13D8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatCSData_0(ref object o, object v));
            val_45 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatCSData_0(ref object o, object v));
            // 0x00BC13DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC13E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC13E4: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782942304
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheC = val_49;
            // 0x00BC13E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC13EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC13F0: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_61 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheC;
            label_121:
            // 0x00BC13F4: CBNZ x19, #0xbc13fc        | if (X1 != 0) goto label_122;            
            if(X1 != 0)
            {
                goto label_122;
            }
            // 0x00BC13F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatCSData_0(ref object o, object v)), ????);
            label_122:
            // 0x00BC13FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1400: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC1404: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BC1408: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BC140C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_61);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_61);
            // 0x00BC1410: CBNZ x20, #0xbc1418        | if (val_1 != null) goto label_123;      
            if(val_1 != null)
            {
                goto label_123;
            }
            // 0x00BC1414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_123:
            // 0x00BC1418: ADRP x9, #0x3624000        | X9 = 56770560 (0x3624000);              
            // 0x00BC141C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BC1420: LDR x9, [x9, #0x730]       | X9 = (string**)(1152921510051197424)("heroAntiCheatData");
            // 0x00BC1424: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC1428: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC142C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BC1430: LDR x1, [x9]               | X1 = "heroAntiCheatData";               
            // 0x00BC1434: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BC1438: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BC143C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1440: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BC1444: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1448: LDR x21, [x8, #0x68]       | X21 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheD;
            val_62 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheD;
            // 0x00BC144C: CBNZ x21, #0xbc1498        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheD != null) goto label_124;
            if(val_62 != null)
            {
                goto label_124;
            }
            // 0x00BC1450: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00BC1454: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BC1458: LDR x8, [x8, #0xfa0]       | X8 = 1152921510051197536;               
            // 0x00BC145C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BC1460: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatData_1(ref object o);
            // 0x00BC1464: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_46 = null;
            // 0x00BC1468: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BC146C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1470: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1474: MOV x2, x21                | X2 = 1152921510051197536 (0x1000000144823260);//ML01
            // 0x00BC1478: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BC147C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatData_1(ref object o));
            val_46 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatData_1(ref object o));
            // 0x00BC1480: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1484: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1488: STR x22, [x8, #0x68]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782942312
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheD = val_46;
            // 0x00BC148C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1490: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1494: LDR x21, [x8, #0x68]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_62 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheD;
            label_124:
            // 0x00BC1498: CBNZ x19, #0xbc14a0        | if (X1 != 0) goto label_125;            
            if(X1 != 0)
            {
                goto label_125;
            }
            // 0x00BC149C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::get_heroAntiCheatData_1(ref object o)), ????);
            label_125:
            // 0x00BC14A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC14A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC14A8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BC14AC: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BC14B0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_62);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_62);
            // 0x00BC14B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC14B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC14BC: LDR x21, [x8, #0x70]       | X21 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheE;
            val_63 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheE;
            // 0x00BC14C0: CBNZ x21, #0xbc150c        | if (ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheE != null) goto label_126;
            if(val_63 != null)
            {
                goto label_126;
            }
            // 0x00BC14C4: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00BC14C8: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BC14CC: LDR x8, [x8, #0xc40]       | X8 = 1152921510051198560;               
            // 0x00BC14D0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BC14D4: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatData_1(ref object o, object v);
            // 0x00BC14D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_47 = null;
            // 0x00BC14DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BC14E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC14E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC14E8: MOV x2, x21                | X2 = 1152921510051198560 (0x1000000144823660);//ML01
            // 0x00BC14EC: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BC14F0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatData_1(ref object o, object v));
            val_47 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatData_1(ref object o, object v));
            // 0x00BC14F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC14F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC14FC: STR x22, [x8, #0x70]       | ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782942320
            ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheE = val_47;
            // 0x00BC1500: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AntiCheatMgr_Binding);
            // 0x00BC1504: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC1508: LDR x21, [x8, #0x70]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_63 = ILRuntime.Runtime.Generated.AntiCheatMgr_Binding.<>f__mg$cacheE;
            label_126:
            // 0x00BC150C: CBNZ x19, #0xbc1514        | if (X1 != 0) goto label_127;            
            if(X1 != 0)
            {
                goto label_127;
            }
            // 0x00BC1510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AntiCheatMgr_Binding::set_heroAntiCheatData_1(ref object o, object v)), ????);
            label_127:
            // 0x00BC1514: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC1518: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BC151C: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BC1520: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC1524: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC1528: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC152C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC1530: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC1534: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1538: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC153C: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_63); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_63);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC1540 (12326208), len: 1036  VirtAddr: 0x00BC1540 RVA: 0x00BC1540 token: 100663810 methodIndex: 29855 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetHeroAntiCheatCS_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_14;
            //  | 
            var val_20;
            //  | 
            string val_21;
            //  | 
            string val_22;
            //  | 
            var val_23;
            // 0x00BC1540: STP x28, x27, [sp, #-0x60]! | stack[1152921510051511904] = ???;  stack[1152921510051511912] = ???;  //  dest_result_addr=1152921510051511904 |  dest_result_addr=1152921510051511912
            // 0x00BC1544: STP x26, x25, [sp, #0x10]  | stack[1152921510051511920] = ???;  stack[1152921510051511928] = ???;  //  dest_result_addr=1152921510051511920 |  dest_result_addr=1152921510051511928
            // 0x00BC1548: STP x24, x23, [sp, #0x20]  | stack[1152921510051511936] = ???;  stack[1152921510051511944] = ???;  //  dest_result_addr=1152921510051511936 |  dest_result_addr=1152921510051511944
            // 0x00BC154C: STP x22, x21, [sp, #0x30]  | stack[1152921510051511952] = ???;  stack[1152921510051511960] = ???;  //  dest_result_addr=1152921510051511952 |  dest_result_addr=1152921510051511960
            // 0x00BC1550: STP x20, x19, [sp, #0x40]  | stack[1152921510051511968] = ???;  stack[1152921510051511976] = ???;  //  dest_result_addr=1152921510051511968 |  dest_result_addr=1152921510051511976
            // 0x00BC1554: STP x29, x30, [sp, #0x50]  | stack[1152921510051511984] = ???;  stack[1152921510051511992] = ???;  //  dest_result_addr=1152921510051511984 |  dest_result_addr=1152921510051511992
            // 0x00BC1558: ADD x29, sp, #0x50         | X29 = (1152921510051511904 + 80) = 1152921510051511984 (0x100000014486FEB0);
            // 0x00BC155C: SUB sp, sp, #0x30          | SP = (1152921510051511904 - 48) = 1152921510051511856 (0x100000014486FE30);
            // 0x00BC1560: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC1564: LDRB w8, [x20, #0xb8c]     | W8 = (bool)static_value_03733B8C;       
            // 0x00BC1568: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BC156C: MOV x24, x2                | X24 = X2;//m1                           
            // 0x00BC1570: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC1574: TBNZ w8, #0, #0xbc1590     | if (static_value_03733B8C == true) goto label_0;
            // 0x00BC1578: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00BC157C: LDR x8, [x8, #0x1f8]       | X8 = 0x2B8AF8C;                         
            // 0x00BC1580: LDR w0, [x8]               | W0 = 0x2A1;                             
            // 0x00BC1584: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A1, ????);      
            // 0x00BC1588: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC158C: STRB w8, [x20, #0xb8c]     | static_value_03733B8C = true;            //  dest_result_addr=57883532
            label_0:
            // 0x00BC1590: CBNZ x19, #0xbc1598        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC1594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A1, ????);      
            label_1:
            // 0x00BC1598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC159C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC15A0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC15A4: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x00BC15A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC15AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC15B0: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BC15B4: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC15B8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC15BC: STR x0, [sp, #0x10]        | stack[1152921510051511872] = val_2;      //  dest_result_addr=1152921510051511872
            // 0x00BC15C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC15C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC15C8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC15CC: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC15D0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC15D4: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC15D8: CBNZ x21, #0xbc15e0        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC15DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC15E0: LDR w8, [x21, #4]          | W8 = val_3 + 4;                         
            // 0x00BC15E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC15E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC15EC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC15F0: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC15F4: STR w8, [sp, #0xc]         | stack[1152921510051511868] = val_3 + 4;  //  dest_result_addr=1152921510051511868
            // 0x00BC15F8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC15FC: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BC1600: CBNZ x22, #0xbc1608        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BC1604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BC1608: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x00BC160C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1610: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1614: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC1618: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC161C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1620: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC1624: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC1628: ADRP x20, #0x3607000       | X20 = 56651776 (0x3607000);             
            // 0x00BC162C: MOV x27, x0                | X27 = val_5;//m1                        
            // 0x00BC1630: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC1634: LDR x20, [x20, #0xbb8]     | X20 = 1152921504608284672;              
            // 0x00BC1638: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC163C: LDR x26, [x20]             | X26 = typeof(System.String);            
            // 0x00BC1640: TBZ w9, #0, #0xbc1654      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC1644: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1648: CBNZ w9, #0xbc1654         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC164C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC1650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00BC1654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC165C: MOV x1, x26                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC1660: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1664: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC1668: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC166C: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BC1670: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC1674: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC1678: TBZ w9, #0, #0xbc168c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC167C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1680: CBNZ w9, #0xbc168c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC1684: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC1688: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x00BC168C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1690: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1694: MOV x1, x27                | X1 = val_5;//m1                         
            // 0x00BC1698: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC169C: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC16A0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            // 0x00BC16A4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC16A8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC16AC: MOV x28, x0                | X28 = val_7;//m1                        
            // 0x00BC16B0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC16B4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC16B8: TBZ w9, #0, #0xbc16cc      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BC16BC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC16C0: CBNZ w9, #0xbc16cc         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BC16C4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC16C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x00BC16CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC16D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC16D4: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x00BC16D8: MOV x2, x28                | X2 = val_7;//m1                         
            // 0x00BC16DC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x00BC16E0: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
            // 0x00BC16E4: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
            // 0x00BC16E8: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00BC16EC: CBZ x0, #0xbc172c          | if (val_8 == null) goto label_11;       
            if(val_8 == null)
            {
                goto label_11;
            }
            // 0x00BC16F0: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC16F4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC16F8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC16FC: MOV x26, x0                | X26 = val_8;//m1                        
            val_21 = val_8;
            // 0x00BC1700: B.EQ #0xbc172c             | if (typeof(System.Object) == null) goto label_11;
            if(null == null)
            {
                goto label_11;
            }
            // 0x00BC1704: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC1708: ADD x8, sp, #0x18          | X8 = (1152921510051511856 + 24) = 1152921510051511880 (0x100000014486FE48);
            // 0x00BC170C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC1710: LDR x0, [sp, #0x18]        | X0 = val_9;                              //  find_add[1152921510051500000]
            // 0x00BC1714: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BC1718: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC171C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BC1720: ADD x0, sp, #0x18          | X0 = (1152921510051511856 + 24) = 1152921510051511880 (0x100000014486FE48);
            // 0x00BC1724: BL #0x299a140              | 
            // 0x00BC1728: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_11:
            // 0x00BC172C: CBNZ x19, #0xbc1734        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BC1730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014486FE48, ????);
            label_12:
            // 0x00BC1734: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1738: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC173C: MOV x1, x27                | X1 = val_5;//m1                         
            // 0x00BC1740: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC1744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC174C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC1750: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC1754: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1758: LDR x1, [x20]              | X1 = typeof(System.String);             
            // 0x00BC175C: MOV x28, x0                | X28 = val_10;//m1                       
            // 0x00BC1760: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1764: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1768: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC176C: MOV x27, x0                | X27 = val_11;//m1                       
            // 0x00BC1770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1774: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1778: MOV x1, x28                | X1 = val_10;//m1                        
            // 0x00BC177C: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC1780: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC1784: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            // 0x00BC1788: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x00BC178C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1790: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1794: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x00BC1798: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x00BC179C: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BC17A0: CBZ x0, #0xbc17e0          | if (val_13 == null) goto label_14;      
            if(val_13 == null)
            {
                goto label_14;
            }
            // 0x00BC17A4: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC17A8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC17AC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC17B0: MOV x27, x0                | X27 = val_13;//m1                       
            val_22 = val_13;
            // 0x00BC17B4: B.EQ #0xbc17e0             | if (typeof(System.Object) == null) goto label_14;
            if(null == null)
            {
                goto label_14;
            }
            // 0x00BC17B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC17BC: ADD x8, sp, #0x20          | X8 = (1152921510051511856 + 32) = 1152921510051511888 (0x100000014486FE50);
            // 0x00BC17C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC17C4: LDR x0, [sp, #0x20]        | X0 = val_14;                             //  find_add[1152921510051500000]
            // 0x00BC17C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BC17CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC17D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BC17D4: ADD x0, sp, #0x20          | X0 = (1152921510051511856 + 32) = 1152921510051511888 (0x100000014486FE50);
            // 0x00BC17D8: BL #0x299a140              | 
            // 0x00BC17DC: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_14:
            // 0x00BC17E0: CBNZ x19, #0xbc17e8        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BC17E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014486FE50, ????);
            label_15:
            // 0x00BC17E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC17EC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC17F0: MOV x1, x28                | X1 = val_10;//m1                        
            // 0x00BC17F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC17F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC17FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1800: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BC1804: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC1808: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC180C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC1810: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC1814: MOV x24, x0                | X24 = val_15;//m1                       
            // 0x00BC1818: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC181C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1820: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC1824: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1828: MOV x28, x0                | X28 = val_16;//m1                       
            // 0x00BC182C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1830: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1834: MOV x1, x24                | X1 = val_15;//m1                        
            // 0x00BC1838: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC183C: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC1840: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            object val_17 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            // 0x00BC1844: MOV x2, x0                 | X2 = val_17;//m1                        
            // 0x00BC1848: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC184C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1850: MOV x1, x28                | X1 = val_16;//m1                        
            // 0x00BC1854: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            object val_18 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            // 0x00BC1858: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BC185C: CBZ x0, #0xbc18c0          | if (val_18 == null) goto label_18;      
            if(val_18 == null)
            {
                goto label_18;
            }
            // 0x00BC1860: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC1864: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC1868: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC186C: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC1870: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC1874: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC1878: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC187C: B.LO #0xbc1898             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x00BC1880: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC1884: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC1888: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC188C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC1890: MOV x23, x0                | X23 = val_18;//m1                       
            val_23 = val_18;
            // 0x00BC1894: B.EQ #0xbc18c0             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_18;
            label_17:
            // 0x00BC1898: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC189C: ADD x8, sp, #0x28          | X8 = (1152921510051511856 + 40) = 1152921510051511896 (0x100000014486FE58);
            // 0x00BC18A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC18A4: LDR x0, [sp, #0x28]        | X0 = val_20;                             //  find_add[1152921510051500000]
            // 0x00BC18A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_20, ????);     
            // 0x00BC18AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC18B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            // 0x00BC18B4: ADD x0, sp, #0x28          | X0 = (1152921510051511856 + 40) = 1152921510051511896 (0x100000014486FE58);
            // 0x00BC18B8: BL #0x299a140              | 
            // 0x00BC18BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_18:
            // 0x00BC18C0: CBNZ x19, #0xbc18c8        | if (X1 != 0) goto label_19;             
            if(X1 != 0)
            {
                goto label_19;
            }
            // 0x00BC18C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014486FE58, ????);
            label_19:
            // 0x00BC18C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC18CC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC18D0: MOV x1, x24                | X1 = val_15;//m1                        
            // 0x00BC18D4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC18D8: CBNZ x23, #0xbc18e0        | if (0x0 != 0) goto label_20;            
            if(val_23 != 0)
            {
                goto label_20;
            }
            // 0x00BC18DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_20:
            // 0x00BC18E0: LDR w4, [sp, #0xc]         | W4 = val_3 + 4;                         
            // 0x00BC18E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC18E8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BC18EC: MOV x1, x27                | X1 = 0 (0x0);//ML01                     
            // 0x00BC18F0: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x00BC18F4: MOV w3, w22                | W3 = val_4 + 4;//m1                     
            // 0x00BC18F8: BL #0xb29c34               | val_23.SetHeroAntiCheatCS(uuid:  val_22, attrName:  val_21, value:  val_4 + 4, acValue:  val_3 + 4);
            val_23.SetHeroAntiCheatCS(uuid:  val_22, attrName:  val_21, value:  val_4 + 4, acValue:  val_3 + 4);
            // 0x00BC18FC: LDR x0, [sp, #0x10]        | X0 = val_2;                             
            // 0x00BC1900: SUB sp, x29, #0x50         | SP = (1152921510051511984 - 80) = 1152921510051511904 (0x100000014486FE60);
            // 0x00BC1904: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC1908: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC190C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC1910: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC1914: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC1918: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC191C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC1920: MOV x19, x0                | 
            // 0x00BC1924: ADD x0, sp, #0x28          | 
            // 0x00BC1928: B #0xbc1940                | 
            // 0x00BC192C: MOV x19, x0                | 
            // 0x00BC1930: ADD x0, sp, #0x18          | 
            // 0x00BC1934: B #0xbc1940                | 
            // 0x00BC1938: MOV x19, x0                | 
            // 0x00BC193C: ADD x0, sp, #0x20          | 
            label_22:
            // 0x00BC1940: BL #0x299a140              | 
            // 0x00BC1944: MOV x0, x19                | 
            // 0x00BC1948: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC194C (12327244), len: 1008  VirtAddr: 0x00BC194C RVA: 0x00BC194C token: 100663811 methodIndex: 29856 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetHeroAntiCheatCS_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_18;
            //  | 
            string val_21;
            //  | 
            string val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x00BC194C: STP x28, x27, [sp, #-0x60]! | stack[1152921510051730400] = ???;  stack[1152921510051730408] = ???;  //  dest_result_addr=1152921510051730400 |  dest_result_addr=1152921510051730408
            // 0x00BC1950: STP x26, x25, [sp, #0x10]  | stack[1152921510051730416] = ???;  stack[1152921510051730424] = ???;  //  dest_result_addr=1152921510051730416 |  dest_result_addr=1152921510051730424
            // 0x00BC1954: STP x24, x23, [sp, #0x20]  | stack[1152921510051730432] = ???;  stack[1152921510051730440] = ???;  //  dest_result_addr=1152921510051730432 |  dest_result_addr=1152921510051730440
            // 0x00BC1958: STP x22, x21, [sp, #0x30]  | stack[1152921510051730448] = ???;  stack[1152921510051730456] = ???;  //  dest_result_addr=1152921510051730448 |  dest_result_addr=1152921510051730456
            // 0x00BC195C: STP x20, x19, [sp, #0x40]  | stack[1152921510051730464] = ???;  stack[1152921510051730472] = ???;  //  dest_result_addr=1152921510051730464 |  dest_result_addr=1152921510051730472
            // 0x00BC1960: STP x29, x30, [sp, #0x50]  | stack[1152921510051730480] = ???;  stack[1152921510051730488] = ???;  //  dest_result_addr=1152921510051730480 |  dest_result_addr=1152921510051730488
            // 0x00BC1964: ADD x29, sp, #0x50         | X29 = (1152921510051730400 + 80) = 1152921510051730480 (0x10000001448A5430);
            // 0x00BC1968: SUB sp, sp, #0x20          | SP = (1152921510051730400 - 32) = 1152921510051730368 (0x10000001448A53C0);
            // 0x00BC196C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC1970: LDRB w8, [x19, #0xb8d]     | W8 = (bool)static_value_03733B8D;       
            // 0x00BC1974: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BC1978: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BC197C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC1980: TBNZ w8, #0, #0xbc199c     | if (static_value_03733B8D == true) goto label_0;
            // 0x00BC1984: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x00BC1988: LDR x8, [x8, #0x28]        | X8 = 0x2B8AF6C;                         
            // 0x00BC198C: LDR w0, [x8]               | W0 = 0x299;                             
            // 0x00BC1990: BL #0x2782188              | X0 = sub_2782188( ?? 0x299, ????);      
            // 0x00BC1994: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC1998: STRB w8, [x19, #0xb8d]     | static_value_03733B8D = true;            //  dest_result_addr=57883533
            label_0:
            // 0x00BC199C: CBNZ x20, #0xbc19a4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC19A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x299, ????);      
            label_1:
            // 0x00BC19A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC19A8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC19AC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC19B0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC19B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC19B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC19BC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC19C0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC19C4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC19C8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC19CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC19D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC19D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC19D8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC19DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC19E0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC19E4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC19E8: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00BC19EC: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC19F0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC19F4: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            // 0x00BC19F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC19FC: LDR x24, [x28]             | X24 = typeof(System.String);            
            // 0x00BC1A00: TBZ w9, #0, #0xbc1a14      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC1A04: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1A08: CBNZ w9, #0xbc1a14         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC1A0C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC1A10: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC1A14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1A18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1A1C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC1A20: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1A24: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC1A28: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC1A2C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC1A30: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC1A34: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC1A38: TBZ w9, #0, #0xbc1a4c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC1A3C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1A40: CBNZ w9, #0xbc1a4c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC1A44: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC1A48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC1A4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1A50: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1A54: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC1A58: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC1A5C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC1A60: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC1A64: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC1A68: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC1A6C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC1A70: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC1A74: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC1A78: TBZ w9, #0, #0xbc1a8c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC1A7C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1A80: CBNZ w9, #0xbc1a8c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC1A84: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC1A88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC1A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1A90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1A94: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC1A98: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC1A9C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC1AA0: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
            // 0x00BC1AA4: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
            // 0x00BC1AA8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00BC1AAC: CBZ x0, #0xbc1aec          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC1AB0: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00BC1AB4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC1AB8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC1ABC: MOV x24, x0                | X24 = val_6;//m1                        
            val_21 = val_6;
            // 0x00BC1AC0: B.EQ #0xbc1aec             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC1AC4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC1AC8: ADD x8, sp, #8             | X8 = (1152921510051730368 + 8) = 1152921510051730376 (0x10000001448A53C8);
            // 0x00BC1ACC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC1AD0: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510051718496]
            // 0x00BC1AD4: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC1AD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1ADC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC1AE0: ADD x0, sp, #8             | X0 = (1152921510051730368 + 8) = 1152921510051730376 (0x10000001448A53C8);
            // 0x00BC1AE4: BL #0x299a140              | 
            // 0x00BC1AE8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_9:
            // 0x00BC1AEC: CBNZ x20, #0xbc1af4        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC1AF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001448A53C8, ????);
            label_10:
            // 0x00BC1AF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1AF8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC1AFC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC1B00: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC1B04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1B08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1B0C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC1B10: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC1B14: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1B18: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00BC1B1C: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00BC1B20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1B24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1B28: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1B2C: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BC1B30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1B34: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1B38: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00BC1B3C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC1B40: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC1B44: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC1B48: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BC1B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1B50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1B54: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BC1B58: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BC1B5C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BC1B60: CBZ x0, #0xbc1ba0          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00BC1B64: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00BC1B68: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC1B6C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC1B70: MOV x25, x0                | X25 = val_11;//m1                       
            val_22 = val_11;
            // 0x00BC1B74: B.EQ #0xbc1ba0             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00BC1B78: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC1B7C: ADD x8, sp, #0x10          | X8 = (1152921510051730368 + 16) = 1152921510051730384 (0x10000001448A53D0);
            // 0x00BC1B80: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC1B84: LDR x0, [sp, #0x10]        | X0 = val_12;                             //  find_add[1152921510051718496]
            // 0x00BC1B88: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BC1B8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1B90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BC1B94: ADD x0, sp, #0x10          | X0 = (1152921510051730368 + 16) = 1152921510051730384 (0x10000001448A53D0);
            // 0x00BC1B98: BL #0x299a140              | 
            // 0x00BC1B9C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_12:
            // 0x00BC1BA0: CBNZ x20, #0xbc1ba8        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BC1BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001448A53D0, ????);
            label_13:
            // 0x00BC1BA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1BAC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC1BB0: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00BC1BB4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC1BB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1BBC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1BC0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC1BC4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC1BC8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1BCC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC1BD0: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC1BD4: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00BC1BD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1BDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1BE0: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC1BE4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1BE8: MOV x26, x0                | X26 = val_14;//m1                       
            // 0x00BC1BEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1BF0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1BF4: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00BC1BF8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC1BFC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC1C00: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_15 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC1C04: MOV x2, x0                 | X2 = val_15;//m1                        
            // 0x00BC1C08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1C0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1C10: MOV x1, x26                | X1 = val_14;//m1                        
            // 0x00BC1C14: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            object val_16 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            // 0x00BC1C18: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BC1C1C: CBZ x0, #0xbc1c80          | if (val_16 == null) goto label_16;      
            if(val_16 == null)
            {
                goto label_16;
            }
            // 0x00BC1C20: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC1C24: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC1C28: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC1C2C: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC1C30: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC1C34: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC1C38: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC1C3C: B.LO #0xbc1c58             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x00BC1C40: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC1C44: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC1C48: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC1C4C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC1C50: MOV x21, x0                | X21 = val_16;//m1                       
            val_23 = val_16;
            // 0x00BC1C54: B.EQ #0xbc1c80             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x00BC1C58: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC1C5C: ADD x8, sp, #0x18          | X8 = (1152921510051730368 + 24) = 1152921510051730392 (0x10000001448A53D8);
            // 0x00BC1C60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC1C64: LDR x0, [sp, #0x18]        | X0 = val_18;                             //  find_add[1152921510051718496]
            // 0x00BC1C68: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x00BC1C6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1C70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x00BC1C74: ADD x0, sp, #0x18          | X0 = (1152921510051730368 + 24) = 1152921510051730392 (0x10000001448A53D8);
            // 0x00BC1C78: BL #0x299a140              | 
            // 0x00BC1C7C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_16:
            // 0x00BC1C80: CBNZ x20, #0xbc1c88        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BC1C84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001448A53D8, ????);
            label_17:
            // 0x00BC1C88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1C8C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC1C90: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00BC1C94: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC1C98: CBNZ x21, #0xbc1ca0        | if (0x0 != 0) goto label_18;            
            if(val_23 != 0)
            {
                goto label_18;
            }
            // 0x00BC1C9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x00BC1CA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1CA4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1CA8: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1CAC: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1CB0: BL #0xb29e70               | X0 = val_23.GetHeroAntiCheatCS(uuid:  val_22, attrName:  val_21);
            uint val_19 = val_23.GetHeroAntiCheatCS(uuid:  val_22, attrName:  val_21);
            // 0x00BC1CB4: CBZ x19, #0xbc1d14         | if (val_2 == 0) goto label_19;          
            if(val_2 == 0)
            {
                goto label_19;
            }
            // 0x00BC1CB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC1CBC: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_19;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_19;
            // 0x00BC1CC0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC1CC4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC1CC8: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC1CCC: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_24 = 8;
            // 0x00BC1CD0: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC1CD4: TBZ w9, #0, #0xbc1ce4      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_20;
            // 0x00BC1CD8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC1CDC: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC1CE0: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_24 = 219381744;
            label_20:
            // 0x00BC1CE4: ADD x0, x8, x19            | X0 = (val_24 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_20 = val_24 + val_2;
            // 0x00BC1CE8: SUB sp, x29, #0x50         | SP = (1152921510051730480 - 80) = 1152921510051730400 (0x10000001448A53E0);
            // 0x00BC1CEC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC1CF0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC1CF4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC1CF8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC1CFC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC1D00: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC1D04: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_24 + val_2);
            return val_20;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC1D08: MOV x19, x0                | X19 = (val_24 + val_2);//m1             
            val_25 = val_20;
            // 0x00BC1D0C: ADD x0, sp, #0x18          | X0 = (1152921510051730496 + 24) = 1152921510051730520 (0x10000001448A5458);
            // 0x00BC1D10: B #0xbc1d30                |  goto label_22;                         
            goto label_22;
            label_19:
            // 0x00BC1D14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            // 0x00BC1D18: BRK #0x1                   | 
            // 0x00BC1D1C: MOV x19, x0                | X19 = val_19;//m1                       
            val_25 = val_19;
            // 0x00BC1D20: ADD x0, sp, #8             | X0 = (1152921510051730368 + 8) = 1152921510051730376 (0x10000001448A53C8);
            // 0x00BC1D24: B #0xbc1d30                |  goto label_22;                         
            goto label_22;
            // 0x00BC1D28: MOV x19, x0                | X19 = 1152921510051730376 (0x10000001448A53C8);//ML01
            val_25;
            // 0x00BC1D2C: ADD x0, sp, #0x10          | X0 = (1152921510051730368 + 16) = 1152921510051730384 (0x10000001448A53D0);
            label_22:
            // 0x00BC1D30: BL #0x299a140              | 
            // 0x00BC1D34: MOV x0, x19                | X0 = 1152921510051730376 (0x10000001448A53C8);//ML01
            // 0x00BC1D38: BL #0x980800               | X0 = sub_980800( ?? 0x10000001448A53C8, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC1D3C (12328252), len: 1052  VirtAddr: 0x00BC1D3C RVA: 0x00BC1D3C token: 100663812 methodIndex: 29857 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetHeroAntiCheatCS_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_19;
            //  | 
            string val_22;
            //  | 
            string val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            // 0x00BC1D3C: STP x28, x27, [sp, #-0x60]! | stack[1152921510051948896] = ???;  stack[1152921510051948904] = ???;  //  dest_result_addr=1152921510051948896 |  dest_result_addr=1152921510051948904
            // 0x00BC1D40: STP x26, x25, [sp, #0x10]  | stack[1152921510051948912] = ???;  stack[1152921510051948920] = ???;  //  dest_result_addr=1152921510051948912 |  dest_result_addr=1152921510051948920
            // 0x00BC1D44: STP x24, x23, [sp, #0x20]  | stack[1152921510051948928] = ???;  stack[1152921510051948936] = ???;  //  dest_result_addr=1152921510051948928 |  dest_result_addr=1152921510051948936
            // 0x00BC1D48: STP x22, x21, [sp, #0x30]  | stack[1152921510051948944] = ???;  stack[1152921510051948952] = ???;  //  dest_result_addr=1152921510051948944 |  dest_result_addr=1152921510051948952
            // 0x00BC1D4C: STP x20, x19, [sp, #0x40]  | stack[1152921510051948960] = ???;  stack[1152921510051948968] = ???;  //  dest_result_addr=1152921510051948960 |  dest_result_addr=1152921510051948968
            // 0x00BC1D50: STP x29, x30, [sp, #0x50]  | stack[1152921510051948976] = ???;  stack[1152921510051948984] = ???;  //  dest_result_addr=1152921510051948976 |  dest_result_addr=1152921510051948984
            // 0x00BC1D54: ADD x29, sp, #0x50         | X29 = (1152921510051948896 + 80) = 1152921510051948976 (0x10000001448DA9B0);
            // 0x00BC1D58: SUB sp, sp, #0x20          | SP = (1152921510051948896 - 32) = 1152921510051948864 (0x10000001448DA940);
            // 0x00BC1D5C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC1D60: LDRB w8, [x19, #0xb8e]     | W8 = (bool)static_value_03733B8E;       
            // 0x00BC1D64: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC1D68: MOV x23, x2                | X23 = X2;//m1                           
            // 0x00BC1D6C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC1D70: TBNZ w8, #0, #0xbc1d8c     | if (static_value_03733B8E == true) goto label_0;
            // 0x00BC1D74: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x00BC1D78: LDR x8, [x8, #0xdc8]       | X8 = 0x2B8AF70;                         
            // 0x00BC1D7C: LDR w0, [x8]               | W0 = 0x29A;                             
            // 0x00BC1D80: BL #0x2782188              | X0 = sub_2782188( ?? 0x29A, ????);      
            // 0x00BC1D84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC1D88: STRB w8, [x19, #0xb8e]     | static_value_03733B8E = true;            //  dest_result_addr=57883534
            label_0:
            // 0x00BC1D8C: CBNZ x20, #0xbc1d94        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC1D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x29A, ????);      
            label_1:
            // 0x00BC1D94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1D98: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC1D9C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC1DA0: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC1DA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1DA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1DAC: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC1DB0: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC1DB4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1DB8: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC1DBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1DC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1DC4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC1DC8: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC1DCC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1DD0: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC1DD4: CBNZ x21, #0xbc1ddc        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC1DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC1DDC: LDR w8, [x21, #4]          | W8 = val_3 + 4;                         
            // 0x00BC1DE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1DE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1DE8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC1DEC: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC1DF0: STR w8, [sp, #4]           | stack[1152921510051948868] = val_3 + 4;  //  dest_result_addr=1152921510051948868
            // 0x00BC1DF4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1DF8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC1DFC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC1E00: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00BC1E04: MOV x26, x0                | X26 = val_4;//m1                        
            // 0x00BC1E08: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC1E0C: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            // 0x00BC1E10: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC1E14: LDR x25, [x28]             | X25 = typeof(System.String);            
            // 0x00BC1E18: TBZ w9, #0, #0xbc1e2c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC1E1C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1E20: CBNZ w9, #0xbc1e2c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC1E24: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC1E28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BC1E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1E30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1E34: MOV x1, x25                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC1E38: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1E3C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC1E40: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC1E44: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BC1E48: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC1E4C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC1E50: TBZ w9, #0, #0xbc1e64      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BC1E54: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1E58: CBNZ w9, #0xbc1e64         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BC1E5C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC1E60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BC1E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1E68: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1E6C: MOV x1, x26                | X1 = val_4;//m1                         
            // 0x00BC1E70: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC1E74: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC1E78: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC1E7C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC1E80: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC1E84: MOV x27, x0                | X27 = val_6;//m1                        
            // 0x00BC1E88: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC1E8C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC1E90: TBZ w9, #0, #0xbc1ea4      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BC1E94: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC1E98: CBNZ w9, #0xbc1ea4         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BC1E9C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC1EA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BC1EA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1EA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1EAC: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BC1EB0: MOV x2, x27                | X2 = val_6;//m1                         
            // 0x00BC1EB4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BC1EB8: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
            // 0x00BC1EBC: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
            // 0x00BC1EC0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BC1EC4: CBZ x0, #0xbc1f04          | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BC1EC8: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC1ECC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC1ED0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC1ED4: MOV x25, x0                | X25 = val_7;//m1                        
            val_22 = val_7;
            // 0x00BC1ED8: B.EQ #0xbc1f04             | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x00BC1EDC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC1EE0: ADD x8, sp, #8             | X8 = (1152921510051948864 + 8) = 1152921510051948872 (0x10000001448DA948);
            // 0x00BC1EE4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC1EE8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510051936992]
            // 0x00BC1EEC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC1EF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1EF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC1EF8: ADD x0, sp, #8             | X0 = (1152921510051948864 + 8) = 1152921510051948872 (0x10000001448DA948);
            // 0x00BC1EFC: BL #0x299a140              | 
            // 0x00BC1F00: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_10:
            // 0x00BC1F04: CBNZ x20, #0xbc1f0c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC1F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001448DA948, ????);
            label_11:
            // 0x00BC1F0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1F10: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC1F14: MOV x1, x26                | X1 = val_4;//m1                         
            // 0x00BC1F18: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC1F1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1F20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1F24: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC1F28: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC1F2C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1F30: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00BC1F34: MOV x27, x0                | X27 = val_9;//m1                        
            // 0x00BC1F38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1F3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1F40: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC1F44: MOV x26, x0                | X26 = val_10;//m1                       
            // 0x00BC1F48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1F4C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC1F50: MOV x1, x27                | X1 = val_9;//m1                         
            // 0x00BC1F54: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC1F58: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC1F5C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC1F60: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BC1F64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1F68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1F6C: MOV x1, x26                | X1 = val_10;//m1                        
            // 0x00BC1F70: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BC1F74: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BC1F78: CBZ x0, #0xbc1fb8          | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x00BC1F7C: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC1F80: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC1F84: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC1F88: MOV x26, x0                | X26 = val_12;//m1                       
            val_23 = val_12;
            // 0x00BC1F8C: B.EQ #0xbc1fb8             | if (typeof(System.Object) == null) goto label_13;
            if(null == null)
            {
                goto label_13;
            }
            // 0x00BC1F90: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC1F94: ADD x8, sp, #0x10          | X8 = (1152921510051948864 + 16) = 1152921510051948880 (0x10000001448DA950);
            // 0x00BC1F98: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC1F9C: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510051936992]
            // 0x00BC1FA0: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BC1FA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC1FA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BC1FAC: ADD x0, sp, #0x10          | X0 = (1152921510051948864 + 16) = 1152921510051948880 (0x10000001448DA950);
            // 0x00BC1FB0: BL #0x299a140              | 
            // 0x00BC1FB4: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_13:
            // 0x00BC1FB8: CBNZ x20, #0xbc1fc0        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BC1FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001448DA950, ????);
            label_14:
            // 0x00BC1FC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1FC4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC1FC8: MOV x1, x27                | X1 = val_9;//m1                         
            // 0x00BC1FCC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC1FD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1FD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC1FD8: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC1FDC: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC1FE0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC1FE4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC1FE8: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC1FEC: MOV x23, x0                | X23 = val_14;//m1                       
            // 0x00BC1FF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC1FF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC1FF8: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC1FFC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2000: MOV x27, x0                | X27 = val_15;//m1                       
            // 0x00BC2004: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2008: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC200C: MOV x1, x23                | X1 = val_14;//m1                        
            // 0x00BC2010: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC2014: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC2018: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC201C: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x00BC2020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2024: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2028: MOV x1, x27                | X1 = val_15;//m1                        
            // 0x00BC202C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x00BC2030: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x00BC2034: CBZ x0, #0xbc2098          | if (val_17 == null) goto label_17;      
            if(val_17 == null)
            {
                goto label_17;
            }
            // 0x00BC2038: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC203C: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC2040: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC2044: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC2048: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC204C: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC2050: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC2054: B.LO #0xbc2070             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x00BC2058: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC205C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC2060: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC2064: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC2068: MOV x22, x0                | X22 = val_17;//m1                       
            val_24 = val_17;
            // 0x00BC206C: B.EQ #0xbc2098             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x00BC2070: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC2074: ADD x8, sp, #0x18          | X8 = (1152921510051948864 + 24) = 1152921510051948888 (0x10000001448DA958);
            // 0x00BC2078: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC207C: LDR x0, [sp, #0x18]        | X0 = val_19;                             //  find_add[1152921510051936992]
            // 0x00BC2080: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x00BC2084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2088: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x00BC208C: ADD x0, sp, #0x18          | X0 = (1152921510051948864 + 24) = 1152921510051948888 (0x10000001448DA958);
            // 0x00BC2090: BL #0x299a140              | 
            // 0x00BC2094: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_24 = 0;
            label_17:
            // 0x00BC2098: CBNZ x20, #0xbc20a0        | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x00BC209C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001448DA958, ????);
            label_18:
            // 0x00BC20A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC20A4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC20A8: MOV x1, x23                | X1 = val_14;//m1                        
            // 0x00BC20AC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC20B0: CBNZ x22, #0xbc20b8        | if (0x0 != 0) goto label_19;            
            if(val_24 != 0)
            {
                goto label_19;
            }
            // 0x00BC20B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_19:
            // 0x00BC20B8: LDR w3, [sp, #4]           | W3 = val_3 + 4;                         
            // 0x00BC20BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC20C0: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BC20C4: MOV x1, x26                | X1 = 0 (0x0);//ML01                     
            // 0x00BC20C8: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x00BC20CC: BL #0xb29fa0               | X0 = val_24.GetHeroAntiCheatCS(uuid:  val_23, attrName:  val_22, defaultValue:  val_3 + 4);
            int val_20 = val_24.GetHeroAntiCheatCS(uuid:  val_23, attrName:  val_22, defaultValue:  val_3 + 4);
            // 0x00BC20D0: CBZ x19, #0xbc2130         | if (val_2 == 0) goto label_20;          
            if(val_2 == 0)
            {
                goto label_20;
            }
            // 0x00BC20D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC20D8: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_20;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_20;
            // 0x00BC20DC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC20E0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC20E4: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC20E8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_25 = 8;
            // 0x00BC20EC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC20F0: TBZ w9, #0, #0xbc2100      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_21;
            // 0x00BC20F4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC20F8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC20FC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_25 = 219381744;
            label_21:
            // 0x00BC2100: ADD x0, x8, x19            | X0 = (val_25 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_21 = val_25 + val_2;
            // 0x00BC2104: SUB sp, x29, #0x50         | SP = (1152921510051948976 - 80) = 1152921510051948896 (0x10000001448DA960);
            // 0x00BC2108: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC210C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC2110: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC2114: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC2118: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC211C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC2120: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_25 + val_2);
            return val_21;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC2124: MOV x19, x0                | X19 = (val_25 + val_2);//m1             
            val_26 = val_21;
            // 0x00BC2128: ADD x0, sp, #0x18          | X0 = (1152921510051948992 + 24) = 1152921510051949016 (0x10000001448DA9D8);
            // 0x00BC212C: B #0xbc214c                |  goto label_23;                         
            goto label_23;
            label_20:
            // 0x00BC2130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            // 0x00BC2134: BRK #0x1                   | 
            // 0x00BC2138: MOV x19, x0                | X19 = val_20;//m1                       
            val_26 = val_20;
            // 0x00BC213C: ADD x0, sp, #8             | X0 = (1152921510051948864 + 8) = 1152921510051948872 (0x10000001448DA948);
            // 0x00BC2140: B #0xbc214c                |  goto label_23;                         
            goto label_23;
            // 0x00BC2144: MOV x19, x0                | X19 = 1152921510051948872 (0x10000001448DA948);//ML01
            val_26;
            // 0x00BC2148: ADD x0, sp, #0x10          | X0 = (1152921510051948864 + 16) = 1152921510051948880 (0x10000001448DA950);
            label_23:
            // 0x00BC214C: BL #0x299a140              | 
            // 0x00BC2150: MOV x0, x19                | X0 = 1152921510051948872 (0x10000001448DA948);//ML01
            // 0x00BC2154: BL #0x980800               | X0 = sub_980800( ?? 0x10000001448DA948, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC2158 (12329304), len: 748  VirtAddr: 0x00BC2158 RVA: 0x00BC2158 token: 100663813 methodIndex: 29858 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* RemoveHeroAntiCheatCS_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_14;
            //  | 
            var val_15;
            // 0x00BC2158: STP x26, x25, [sp, #-0x50]! | stack[1152921510052155120] = ???;  stack[1152921510052155128] = ???;  //  dest_result_addr=1152921510052155120 |  dest_result_addr=1152921510052155128
            // 0x00BC215C: STP x24, x23, [sp, #0x10]  | stack[1152921510052155136] = ???;  stack[1152921510052155144] = ???;  //  dest_result_addr=1152921510052155136 |  dest_result_addr=1152921510052155144
            // 0x00BC2160: STP x22, x21, [sp, #0x20]  | stack[1152921510052155152] = ???;  stack[1152921510052155160] = ???;  //  dest_result_addr=1152921510052155152 |  dest_result_addr=1152921510052155160
            // 0x00BC2164: STP x20, x19, [sp, #0x30]  | stack[1152921510052155168] = ???;  stack[1152921510052155176] = ???;  //  dest_result_addr=1152921510052155168 |  dest_result_addr=1152921510052155176
            // 0x00BC2168: STP x29, x30, [sp, #0x40]  | stack[1152921510052155184] = ???;  stack[1152921510052155192] = ???;  //  dest_result_addr=1152921510052155184 |  dest_result_addr=1152921510052155192
            // 0x00BC216C: ADD x29, sp, #0x40         | X29 = (1152921510052155120 + 64) = 1152921510052155184 (0x100000014490CF30);
            // 0x00BC2170: SUB sp, sp, #0x10          | SP = (1152921510052155120 - 16) = 1152921510052155104 (0x100000014490CEE0);
            // 0x00BC2174: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC2178: LDRB w8, [x20, #0xb8f]     | W8 = (bool)static_value_03733B8F;       
            // 0x00BC217C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BC2180: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BC2184: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC2188: TBNZ w8, #0, #0xbc21a4     | if (static_value_03733B8F == true) goto label_0;
            // 0x00BC218C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00BC2190: LDR x8, [x8, #0x9f8]       | X8 = 0x2B8AF7C;                         
            // 0x00BC2194: LDR w0, [x8]               | W0 = 0x29D;                             
            // 0x00BC2198: BL #0x2782188              | X0 = sub_2782188( ?? 0x29D, ????);      
            // 0x00BC219C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC21A0: STRB w8, [x20, #0xb8f]     | static_value_03733B8F = true;            //  dest_result_addr=57883535
            label_0:
            // 0x00BC21A4: CBNZ x19, #0xbc21ac        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC21A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x29D, ????);      
            label_1:
            // 0x00BC21AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC21B0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC21B4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC21B8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC21BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC21C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC21C4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC21C8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC21CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC21D0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC21D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC21D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC21DC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC21E0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC21E4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC21E8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC21EC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC21F0: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BC21F4: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC21F8: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC21FC: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BC2200: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BC2204: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC2208: TBZ w9, #0, #0xbc221c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC220C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2210: CBNZ w9, #0xbc221c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC2214: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC2218: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC221C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2220: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2224: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC2228: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC222C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC2230: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC2234: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC2238: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC223C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC2240: TBZ w9, #0, #0xbc2254      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC2244: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2248: CBNZ w9, #0xbc2254         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC224C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC2250: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC2254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2258: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC225C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC2260: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC2264: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC2268: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC226C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC2270: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC2274: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC2278: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC227C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC2280: TBZ w9, #0, #0xbc2294      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC2284: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2288: CBNZ w9, #0xbc2294         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC228C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC2290: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC2294: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2298: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC229C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC22A0: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC22A4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC22A8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x00BC22AC: CBZ x0, #0xbc22f4          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC22B0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BC22B4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BC22B8: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BC22BC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC22C0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC22C4: MOV x24, x0                | X24 = val_6;//m1                        
            val_14 = val_6;
            // 0x00BC22C8: B.EQ #0xbc22f4             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC22CC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC22D0: MOV x8, sp                 | X8 = 1152921510052155104 (0x100000014490CEE0);//ML01
            // 0x00BC22D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC22D8: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510052143200]
            // 0x00BC22DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC22E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC22E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC22E8: MOV x0, sp                 | X0 = 1152921510052155104 (0x100000014490CEE0);//ML01
            // 0x00BC22EC: BL #0x299a140              | 
            // 0x00BC22F0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_9:
            // 0x00BC22F4: CBNZ x19, #0xbc22fc        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC22F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014490CEE0, ????);
            label_10:
            // 0x00BC22FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2300: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2304: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC2308: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC230C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2310: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2314: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC2318: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC231C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2320: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC2324: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC2328: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BC232C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2330: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2334: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC2338: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC233C: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BC2340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2344: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2348: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BC234C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC2350: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC2354: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC2358: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BC235C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2360: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2364: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BC2368: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BC236C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BC2370: CBZ x0, #0xbc23d4          | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x00BC2374: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC2378: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC237C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC2380: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC2384: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC2388: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC238C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC2390: B.LO #0xbc23ac             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BC2394: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC2398: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC239C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC23A0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC23A4: MOV x21, x0                | X21 = val_11;//m1                       
            val_15 = val_11;
            // 0x00BC23A8: B.EQ #0xbc23d4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BC23AC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC23B0: ADD x8, sp, #8             | X8 = (1152921510052155104 + 8) = 1152921510052155112 (0x100000014490CEE8);
            // 0x00BC23B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC23B8: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510052143200]
            // 0x00BC23BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BC23C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC23C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BC23C8: ADD x0, sp, #8             | X0 = (1152921510052155104 + 8) = 1152921510052155112 (0x100000014490CEE8);
            // 0x00BC23CC: BL #0x299a140              | 
            // 0x00BC23D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_13:
            // 0x00BC23D4: CBNZ x19, #0xbc23dc        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BC23D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014490CEE8, ????);
            label_14:
            // 0x00BC23DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC23E0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC23E4: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BC23E8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC23EC: CBNZ x21, #0xbc23f4        | if (0x0 != 0) goto label_15;            
            if(val_15 != 0)
            {
                goto label_15;
            }
            // 0x00BC23F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BC23F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC23F8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BC23FC: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2400: BL #0xb2a0d0               | val_15.RemoveHeroAntiCheatCS(uuid:  val_14);
            val_15.RemoveHeroAntiCheatCS(uuid:  val_14);
            // 0x00BC2404: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BC2408: SUB sp, x29, #0x40         | SP = (1152921510052155184 - 64) = 1152921510052155120 (0x100000014490CEF0);
            // 0x00BC240C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC2410: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC2414: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC2418: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC241C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BC2420: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC2424: MOV x19, x0                | 
            // 0x00BC2428: ADD x0, sp, #8             | 
            // 0x00BC242C: B #0xbc2438                | 
            // 0x00BC2430: MOV x19, x0                | 
            // 0x00BC2434: MOV x0, sp                 | 
            label_16:
            // 0x00BC2438: BL #0x299a140              | 
            // 0x00BC243C: MOV x0, x19                | 
            // 0x00BC2440: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC2444 (12330052), len: 528  VirtAddr: 0x00BC2444 RVA: 0x00BC2444 token: 100663814 methodIndex: 29859 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ClearHeroAntiCheat_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BC2444: STP x24, x23, [sp, #-0x40]! | stack[1152921510052336768] = ???;  stack[1152921510052336776] = ???;  //  dest_result_addr=1152921510052336768 |  dest_result_addr=1152921510052336776
            // 0x00BC2448: STP x22, x21, [sp, #0x10]  | stack[1152921510052336784] = ???;  stack[1152921510052336792] = ???;  //  dest_result_addr=1152921510052336784 |  dest_result_addr=1152921510052336792
            // 0x00BC244C: STP x20, x19, [sp, #0x20]  | stack[1152921510052336800] = ???;  stack[1152921510052336808] = ???;  //  dest_result_addr=1152921510052336800 |  dest_result_addr=1152921510052336808
            // 0x00BC2450: STP x29, x30, [sp, #0x30]  | stack[1152921510052336816] = ???;  stack[1152921510052336824] = ???;  //  dest_result_addr=1152921510052336816 |  dest_result_addr=1152921510052336824
            // 0x00BC2454: ADD x29, sp, #0x30         | X29 = (1152921510052336768 + 48) = 1152921510052336816 (0x10000001449394B0);
            // 0x00BC2458: SUB sp, sp, #0x10          | SP = (1152921510052336768 - 16) = 1152921510052336752 (0x1000000144939470);
            // 0x00BC245C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC2460: LDRB w8, [x20, #0xb90]     | W8 = (bool)static_value_03733B90;       
            // 0x00BC2464: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC2468: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BC246C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC2470: TBNZ w8, #0, #0xbc248c     | if (static_value_03733B90 == true) goto label_0;
            // 0x00BC2474: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00BC2478: LDR x8, [x8, #0x828]       | X8 = 0x2B8AF54;                         
            // 0x00BC247C: LDR w0, [x8]               | W0 = 0x293;                             
            // 0x00BC2480: BL #0x2782188              | X0 = sub_2782188( ?? 0x293, ????);      
            // 0x00BC2484: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC2488: STRB w8, [x20, #0xb90]     | static_value_03733B90 = true;            //  dest_result_addr=57883536
            label_0:
            // 0x00BC248C: CBNZ x19, #0xbc2494        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC2490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x293, ????);      
            label_1:
            // 0x00BC2494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2498: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC249C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC24A0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC24A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC24A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC24AC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC24B0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC24B4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC24B8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC24BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC24C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC24C4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC24C8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC24CC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC24D0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC24D4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC24D8: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x00BC24DC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC24E0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC24E4: LDR x9, [x9, #0x728]       | X9 = 1152921504902479872;               
            // 0x00BC24E8: LDR x24, [x9]              | X24 = typeof(AntiCheatMgr);             
            // 0x00BC24EC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC24F0: TBZ w9, #0, #0xbc2504      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC24F4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC24F8: CBNZ w9, #0xbc2504         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC24FC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC2500: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC2504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2508: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC250C: MOV x1, x24                | X1 = 1152921504902479872 (0x10000000119F0000);//ML01
            // 0x00BC2510: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2514: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC2518: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC251C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC2520: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC2524: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC2528: TBZ w9, #0, #0xbc253c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC252C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2530: CBNZ w9, #0xbc253c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC2534: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC2538: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC253C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2540: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2544: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC2548: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC254C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC2550: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC2554: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC2558: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC255C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BC2560: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC2564: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC2568: TBZ w9, #0, #0xbc257c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC256C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2570: CBNZ w9, #0xbc257c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC2574: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC2578: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC257C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2580: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2584: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC2588: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BC258C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC2590: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BC2594: CBZ x0, #0xbc25f8          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BC2598: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC259C: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC25A0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC25A4: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC25A8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC25AC: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC25B0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC25B4: B.LO #0xbc25d0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BC25B8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC25BC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC25C0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC25C4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC25C8: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BC25CC: B.EQ #0xbc25f8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BC25D0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC25D4: ADD x8, sp, #8             | X8 = (1152921510052336752 + 8) = 1152921510052336760 (0x1000000144939478);
            // 0x00BC25D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC25DC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510052324832]
            // 0x00BC25E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC25E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC25E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC25EC: ADD x0, sp, #8             | X0 = (1152921510052336752 + 8) = 1152921510052336760 (0x1000000144939478);
            // 0x00BC25F0: BL #0x299a140              | 
            // 0x00BC25F4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BC25F8: CBNZ x19, #0xbc2600        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC25FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144939478, ????);
            label_11:
            // 0x00BC2600: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2604: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2608: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC260C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC2610: CBNZ x22, #0xbc2618        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BC2614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BC2618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC261C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2620: BL #0xb2a174               | val_9.ClearHeroAntiCheat();             
            val_9.ClearHeroAntiCheat();
            // 0x00BC2624: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BC2628: SUB sp, x29, #0x30         | SP = (1152921510052336816 - 48) = 1152921510052336768 (0x1000000144939480);
            // 0x00BC262C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC2630: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC2634: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC2638: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC263C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC2640: MOV x19, x0                | 
            // 0x00BC2644: ADD x0, sp, #8             | 
            // 0x00BC2648: BL #0x299a140              | 
            // 0x00BC264C: MOV x0, x19                | 
            // 0x00BC2650: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC2654 (12330580), len: 528  VirtAddr: 0x00BC2654 RVA: 0x00BC2654 token: 100663815 methodIndex: 29860 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* ClearHeroAntiCheatCS_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BC2654: STP x24, x23, [sp, #-0x40]! | stack[1152921510052506112] = ???;  stack[1152921510052506120] = ???;  //  dest_result_addr=1152921510052506112 |  dest_result_addr=1152921510052506120
            // 0x00BC2658: STP x22, x21, [sp, #0x10]  | stack[1152921510052506128] = ???;  stack[1152921510052506136] = ???;  //  dest_result_addr=1152921510052506128 |  dest_result_addr=1152921510052506136
            // 0x00BC265C: STP x20, x19, [sp, #0x20]  | stack[1152921510052506144] = ???;  stack[1152921510052506152] = ???;  //  dest_result_addr=1152921510052506144 |  dest_result_addr=1152921510052506152
            // 0x00BC2660: STP x29, x30, [sp, #0x30]  | stack[1152921510052506160] = ???;  stack[1152921510052506168] = ???;  //  dest_result_addr=1152921510052506160 |  dest_result_addr=1152921510052506168
            // 0x00BC2664: ADD x29, sp, #0x30         | X29 = (1152921510052506112 + 48) = 1152921510052506160 (0x1000000144962A30);
            // 0x00BC2668: SUB sp, sp, #0x10          | SP = (1152921510052506112 - 16) = 1152921510052506096 (0x10000001449629F0);
            // 0x00BC266C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC2670: LDRB w8, [x20, #0xb91]     | W8 = (bool)static_value_03733B91;       
            // 0x00BC2674: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC2678: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BC267C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC2680: TBNZ w8, #0, #0xbc269c     | if (static_value_03733B91 == true) goto label_0;
            // 0x00BC2684: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00BC2688: LDR x8, [x8, #0x938]       | X8 = 0x2B8AF58;                         
            // 0x00BC268C: LDR w0, [x8]               | W0 = 0x294;                             
            // 0x00BC2690: BL #0x2782188              | X0 = sub_2782188( ?? 0x294, ????);      
            // 0x00BC2694: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC2698: STRB w8, [x20, #0xb91]     | static_value_03733B91 = true;            //  dest_result_addr=57883537
            label_0:
            // 0x00BC269C: CBNZ x19, #0xbc26a4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC26A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x294, ????);      
            label_1:
            // 0x00BC26A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC26A8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC26AC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC26B0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC26B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC26B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC26BC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC26C0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC26C4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC26C8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC26CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC26D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC26D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC26D8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC26DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC26E0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC26E4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC26E8: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x00BC26EC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC26F0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC26F4: LDR x9, [x9, #0x728]       | X9 = 1152921504902479872;               
            // 0x00BC26F8: LDR x24, [x9]              | X24 = typeof(AntiCheatMgr);             
            // 0x00BC26FC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC2700: TBZ w9, #0, #0xbc2714      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC2704: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2708: CBNZ w9, #0xbc2714         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC270C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC2710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC2714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2718: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC271C: MOV x1, x24                | X1 = 1152921504902479872 (0x10000000119F0000);//ML01
            // 0x00BC2720: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2724: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC2728: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC272C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC2730: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC2734: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC2738: TBZ w9, #0, #0xbc274c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC273C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2740: CBNZ w9, #0xbc274c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC2744: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC2748: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC274C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2750: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2754: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC2758: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC275C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC2760: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC2764: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC2768: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC276C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BC2770: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC2774: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC2778: TBZ w9, #0, #0xbc278c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC277C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2780: CBNZ w9, #0xbc278c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC2784: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC2788: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC278C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2790: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2794: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC2798: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BC279C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC27A0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BC27A4: CBZ x0, #0xbc2808          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BC27A8: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC27AC: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC27B0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC27B4: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC27B8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC27BC: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC27C0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC27C4: B.LO #0xbc27e0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BC27C8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC27CC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC27D0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC27D4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC27D8: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BC27DC: B.EQ #0xbc2808             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BC27E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC27E4: ADD x8, sp, #8             | X8 = (1152921510052506096 + 8) = 1152921510052506104 (0x10000001449629F8);
            // 0x00BC27E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC27EC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510052494176]
            // 0x00BC27F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC27F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC27F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC27FC: ADD x0, sp, #8             | X0 = (1152921510052506096 + 8) = 1152921510052506104 (0x10000001449629F8);
            // 0x00BC2800: BL #0x299a140              | 
            // 0x00BC2804: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BC2808: CBNZ x19, #0xbc2810        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC280C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449629F8, ????);
            label_11:
            // 0x00BC2810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2814: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2818: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC281C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC2820: CBNZ x22, #0xbc2828        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BC2824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BC2828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC282C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2830: BL #0xb2a1d0               | val_9.ClearHeroAntiCheatCS();           
            val_9.ClearHeroAntiCheatCS();
            // 0x00BC2834: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BC2838: SUB sp, x29, #0x30         | SP = (1152921510052506160 - 48) = 1152921510052506112 (0x1000000144962A00);
            // 0x00BC283C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC2840: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC2844: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC2848: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC284C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC2850: MOV x19, x0                | 
            // 0x00BC2854: ADD x0, sp, #8             | 
            // 0x00BC2858: BL #0x299a140              | 
            // 0x00BC285C: MOV x0, x19                | 
            // 0x00BC2860: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC2864 (12331108), len: 528  VirtAddr: 0x00BC2864 RVA: 0x00BC2864 token: 100663816 methodIndex: 29861 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BC2864: STP x24, x23, [sp, #-0x40]! | stack[1152921510052675456] = ???;  stack[1152921510052675464] = ???;  //  dest_result_addr=1152921510052675456 |  dest_result_addr=1152921510052675464
            // 0x00BC2868: STP x22, x21, [sp, #0x10]  | stack[1152921510052675472] = ???;  stack[1152921510052675480] = ???;  //  dest_result_addr=1152921510052675472 |  dest_result_addr=1152921510052675480
            // 0x00BC286C: STP x20, x19, [sp, #0x20]  | stack[1152921510052675488] = ???;  stack[1152921510052675496] = ???;  //  dest_result_addr=1152921510052675488 |  dest_result_addr=1152921510052675496
            // 0x00BC2870: STP x29, x30, [sp, #0x30]  | stack[1152921510052675504] = ???;  stack[1152921510052675512] = ???;  //  dest_result_addr=1152921510052675504 |  dest_result_addr=1152921510052675512
            // 0x00BC2874: ADD x29, sp, #0x30         | X29 = (1152921510052675456 + 48) = 1152921510052675504 (0x100000014498BFB0);
            // 0x00BC2878: SUB sp, sp, #0x10          | SP = (1152921510052675456 - 16) = 1152921510052675440 (0x100000014498BF70);
            // 0x00BC287C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC2880: LDRB w8, [x20, #0xb92]     | W8 = (bool)static_value_03733B92;       
            // 0x00BC2884: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC2888: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BC288C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC2890: TBNZ w8, #0, #0xbc28ac     | if (static_value_03733B92 == true) goto label_0;
            // 0x00BC2894: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00BC2898: LDR x8, [x8, #0xb58]       | X8 = 0x2B8AF50;                         
            // 0x00BC289C: LDR w0, [x8]               | W0 = 0x292;                             
            // 0x00BC28A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x292, ????);      
            // 0x00BC28A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC28A8: STRB w8, [x20, #0xb92]     | static_value_03733B92 = true;            //  dest_result_addr=57883538
            label_0:
            // 0x00BC28AC: CBNZ x19, #0xbc28b4        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC28B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x292, ????);      
            label_1:
            // 0x00BC28B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC28B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC28BC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC28C0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC28C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC28C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC28CC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC28D0: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC28D4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC28D8: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC28DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC28E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC28E4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC28E8: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BC28EC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC28F0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC28F4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC28F8: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x00BC28FC: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC2900: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC2904: LDR x9, [x9, #0x728]       | X9 = 1152921504902479872;               
            // 0x00BC2908: LDR x24, [x9]              | X24 = typeof(AntiCheatMgr);             
            // 0x00BC290C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC2910: TBZ w9, #0, #0xbc2924      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC2914: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2918: CBNZ w9, #0xbc2924         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC291C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC2920: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC2924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2928: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC292C: MOV x1, x24                | X1 = 1152921504902479872 (0x10000000119F0000);//ML01
            // 0x00BC2930: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2934: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC2938: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC293C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC2940: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC2944: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC2948: TBZ w9, #0, #0xbc295c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC294C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2950: CBNZ w9, #0xbc295c         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC2954: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC2958: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC295C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2960: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2964: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC2968: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC296C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC2970: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC2974: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC2978: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC297C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BC2980: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC2984: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC2988: TBZ w9, #0, #0xbc299c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC298C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2990: CBNZ w9, #0xbc299c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC2994: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC2998: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC299C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC29A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC29A4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC29A8: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BC29AC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC29B0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BC29B4: CBZ x0, #0xbc2a18          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BC29B8: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC29BC: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC29C0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC29C4: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC29C8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC29CC: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC29D0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC29D4: B.LO #0xbc29f0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BC29D8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC29DC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC29E0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC29E4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC29E8: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BC29EC: B.EQ #0xbc2a18             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BC29F0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC29F4: ADD x8, sp, #8             | X8 = (1152921510052675440 + 8) = 1152921510052675448 (0x100000014498BF78);
            // 0x00BC29F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC29FC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510052663520]
            // 0x00BC2A00: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC2A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2A08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC2A0C: ADD x0, sp, #8             | X0 = (1152921510052675440 + 8) = 1152921510052675448 (0x100000014498BF78);
            // 0x00BC2A10: BL #0x299a140              | 
            // 0x00BC2A14: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BC2A18: CBNZ x19, #0xbc2a20        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC2A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014498BF78, ????);
            label_11:
            // 0x00BC2A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2A24: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2A28: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BC2A2C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC2A30: CBNZ x22, #0xbc2a38        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BC2A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BC2A38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2A3C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2A40: BL #0xb2a22c               | val_9.Clear();                          
            val_9.Clear();
            // 0x00BC2A44: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BC2A48: SUB sp, x29, #0x30         | SP = (1152921510052675504 - 48) = 1152921510052675456 (0x100000014498BF80);
            // 0x00BC2A4C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC2A50: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC2A54: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC2A58: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC2A5C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC2A60: MOV x19, x0                | 
            // 0x00BC2A64: ADD x0, sp, #8             | 
            // 0x00BC2A68: BL #0x299a140              | 
            // 0x00BC2A6C: MOV x0, x19                | 
            // 0x00BC2A70: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC2A74 (12331636), len: 1036  VirtAddr: 0x00BC2A74 RVA: 0x00BC2A74 token: 100663817 methodIndex: 29862 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* SetHeroAntiCheat_7(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_14;
            //  | 
            var val_20;
            //  | 
            string val_21;
            //  | 
            string val_22;
            //  | 
            var val_23;
            // 0x00BC2A74: STP x28, x27, [sp, #-0x60]! | stack[1152921510052869344] = ???;  stack[1152921510052869352] = ???;  //  dest_result_addr=1152921510052869344 |  dest_result_addr=1152921510052869352
            // 0x00BC2A78: STP x26, x25, [sp, #0x10]  | stack[1152921510052869360] = ???;  stack[1152921510052869368] = ???;  //  dest_result_addr=1152921510052869360 |  dest_result_addr=1152921510052869368
            // 0x00BC2A7C: STP x24, x23, [sp, #0x20]  | stack[1152921510052869376] = ???;  stack[1152921510052869384] = ???;  //  dest_result_addr=1152921510052869376 |  dest_result_addr=1152921510052869384
            // 0x00BC2A80: STP x22, x21, [sp, #0x30]  | stack[1152921510052869392] = ???;  stack[1152921510052869400] = ???;  //  dest_result_addr=1152921510052869392 |  dest_result_addr=1152921510052869400
            // 0x00BC2A84: STP x20, x19, [sp, #0x40]  | stack[1152921510052869408] = ???;  stack[1152921510052869416] = ???;  //  dest_result_addr=1152921510052869408 |  dest_result_addr=1152921510052869416
            // 0x00BC2A88: STP x29, x30, [sp, #0x50]  | stack[1152921510052869424] = ???;  stack[1152921510052869432] = ???;  //  dest_result_addr=1152921510052869424 |  dest_result_addr=1152921510052869432
            // 0x00BC2A8C: ADD x29, sp, #0x50         | X29 = (1152921510052869344 + 80) = 1152921510052869424 (0x10000001449BB530);
            // 0x00BC2A90: SUB sp, sp, #0x30          | SP = (1152921510052869344 - 48) = 1152921510052869296 (0x10000001449BB4B0);
            // 0x00BC2A94: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC2A98: LDRB w8, [x20, #0xb93]     | W8 = (bool)static_value_03733B93;       
            // 0x00BC2A9C: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BC2AA0: MOV x24, x2                | X24 = X2;//m1                           
            // 0x00BC2AA4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC2AA8: TBNZ w8, #0, #0xbc2ac4     | if (static_value_03733B93 == true) goto label_0;
            // 0x00BC2AAC: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00BC2AB0: LDR x8, [x8, #0xf68]       | X8 = 0x2B8AF88;                         
            // 0x00BC2AB4: LDR w0, [x8]               | W0 = 0x2A0;                             
            // 0x00BC2AB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2A0, ????);      
            // 0x00BC2ABC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC2AC0: STRB w8, [x20, #0xb93]     | static_value_03733B93 = true;            //  dest_result_addr=57883539
            label_0:
            // 0x00BC2AC4: CBNZ x19, #0xbc2acc        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC2AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2A0, ????);      
            label_1:
            // 0x00BC2ACC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2AD0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2AD4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC2AD8: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x00BC2ADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2AE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2AE4: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BC2AE8: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC2AEC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2AF0: STR x0, [sp, #0x10]        | stack[1152921510052869312] = val_2;      //  dest_result_addr=1152921510052869312
            // 0x00BC2AF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2AF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2AFC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC2B00: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC2B04: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2B08: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC2B0C: CBNZ x21, #0xbc2b14        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC2B10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC2B14: LDR w8, [x21, #4]          | W8 = val_3 + 4;                         
            // 0x00BC2B18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2B1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2B20: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC2B24: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC2B28: STR w8, [sp, #0xc]         | stack[1152921510052869308] = val_3 + 4;  //  dest_result_addr=1152921510052869308
            // 0x00BC2B2C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2B30: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BC2B34: CBNZ x22, #0xbc2b3c        | if (val_4 != 0) goto label_3;           
            if(val_4 != 0)
            {
                goto label_3;
            }
            // 0x00BC2B38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_3:
            // 0x00BC2B3C: LDR w22, [x22, #4]         | W22 = val_4 + 4;                        
            // 0x00BC2B40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2B44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2B48: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC2B4C: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC2B50: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2B54: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC2B58: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC2B5C: ADRP x20, #0x3607000       | X20 = 56651776 (0x3607000);             
            // 0x00BC2B60: MOV x27, x0                | X27 = val_5;//m1                        
            // 0x00BC2B64: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC2B68: LDR x20, [x20, #0xbb8]     | X20 = 1152921504608284672;              
            // 0x00BC2B6C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC2B70: LDR x26, [x20]             | X26 = typeof(System.String);            
            // 0x00BC2B74: TBZ w9, #0, #0xbc2b88      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC2B78: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2B7C: CBNZ w9, #0xbc2b88         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC2B80: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC2B84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_5:
            // 0x00BC2B88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2B8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2B90: MOV x1, x26                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC2B94: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2B98: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC2B9C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC2BA0: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x00BC2BA4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC2BA8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC2BAC: TBZ w9, #0, #0xbc2bc0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC2BB0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2BB4: CBNZ w9, #0xbc2bc0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC2BB8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC2BBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x00BC2BC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2BC4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2BC8: MOV x1, x27                | X1 = val_5;//m1                         
            // 0x00BC2BCC: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC2BD0: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC2BD4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            // 0x00BC2BD8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC2BDC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC2BE0: MOV x28, x0                | X28 = val_7;//m1                        
            // 0x00BC2BE4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC2BE8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC2BEC: TBZ w9, #0, #0xbc2c00      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00BC2BF0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2BF4: CBNZ w9, #0xbc2c00         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00BC2BF8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC2BFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_9:
            // 0x00BC2C00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2C04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2C08: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x00BC2C0C: MOV x2, x28                | X2 = val_7;//m1                         
            // 0x00BC2C10: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            object val_8 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_6);
            // 0x00BC2C14: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
            // 0x00BC2C18: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
            // 0x00BC2C1C: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00BC2C20: CBZ x0, #0xbc2c60          | if (val_8 == null) goto label_11;       
            if(val_8 == null)
            {
                goto label_11;
            }
            // 0x00BC2C24: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC2C28: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC2C2C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC2C30: MOV x26, x0                | X26 = val_8;//m1                        
            val_21 = val_8;
            // 0x00BC2C34: B.EQ #0xbc2c60             | if (typeof(System.Object) == null) goto label_11;
            if(null == null)
            {
                goto label_11;
            }
            // 0x00BC2C38: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC2C3C: ADD x8, sp, #0x18          | X8 = (1152921510052869296 + 24) = 1152921510052869320 (0x10000001449BB4C8);
            // 0x00BC2C40: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC2C44: LDR x0, [sp, #0x18]        | X0 = val_9;                              //  find_add[1152921510052857440]
            // 0x00BC2C48: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BC2C4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2C50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BC2C54: ADD x0, sp, #0x18          | X0 = (1152921510052869296 + 24) = 1152921510052869320 (0x10000001449BB4C8);
            // 0x00BC2C58: BL #0x299a140              | 
            // 0x00BC2C5C: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_11:
            // 0x00BC2C60: CBNZ x19, #0xbc2c68        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BC2C64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449BB4C8, ????);
            label_12:
            // 0x00BC2C68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2C6C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2C70: MOV x1, x27                | X1 = val_5;//m1                         
            // 0x00BC2C74: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC2C78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2C7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2C80: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC2C84: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC2C88: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2C8C: LDR x1, [x20]              | X1 = typeof(System.String);             
            // 0x00BC2C90: MOV x28, x0                | X28 = val_10;//m1                       
            // 0x00BC2C94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2C98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2C9C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2CA0: MOV x27, x0                | X27 = val_11;//m1                       
            // 0x00BC2CA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2CA8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2CAC: MOV x1, x28                | X1 = val_10;//m1                        
            // 0x00BC2CB0: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC2CB4: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC2CB8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            object val_12 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            // 0x00BC2CBC: MOV x2, x0                 | X2 = val_12;//m1                        
            // 0x00BC2CC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2CC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2CC8: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x00BC2CCC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            object val_13 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_11);
            // 0x00BC2CD0: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BC2CD4: CBZ x0, #0xbc2d14          | if (val_13 == null) goto label_14;      
            if(val_13 == null)
            {
                goto label_14;
            }
            // 0x00BC2CD8: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC2CDC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC2CE0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC2CE4: MOV x27, x0                | X27 = val_13;//m1                       
            val_22 = val_13;
            // 0x00BC2CE8: B.EQ #0xbc2d14             | if (typeof(System.Object) == null) goto label_14;
            if(null == null)
            {
                goto label_14;
            }
            // 0x00BC2CEC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC2CF0: ADD x8, sp, #0x20          | X8 = (1152921510052869296 + 32) = 1152921510052869328 (0x10000001449BB4D0);
            // 0x00BC2CF4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC2CF8: LDR x0, [sp, #0x20]        | X0 = val_14;                             //  find_add[1152921510052857440]
            // 0x00BC2CFC: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BC2D00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2D04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BC2D08: ADD x0, sp, #0x20          | X0 = (1152921510052869296 + 32) = 1152921510052869328 (0x10000001449BB4D0);
            // 0x00BC2D0C: BL #0x299a140              | 
            // 0x00BC2D10: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_14:
            // 0x00BC2D14: CBNZ x19, #0xbc2d1c        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BC2D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449BB4D0, ????);
            label_15:
            // 0x00BC2D1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2D20: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2D24: MOV x1, x28                | X1 = val_10;//m1                        
            // 0x00BC2D28: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC2D2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2D30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2D34: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x00BC2D38: MOV x1, x24                | X1 = X2;//m1                            
            // 0x00BC2D3C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2D40: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC2D44: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC2D48: MOV x24, x0                | X24 = val_15;//m1                       
            // 0x00BC2D4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2D50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2D54: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC2D58: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2D5C: MOV x28, x0                | X28 = val_16;//m1                       
            // 0x00BC2D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2D64: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2D68: MOV x1, x24                | X1 = val_15;//m1                        
            // 0x00BC2D6C: MOV x2, x25                | X2 = val_1;//m1                         
            // 0x00BC2D70: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BC2D74: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            object val_17 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  val_2);
            // 0x00BC2D78: MOV x2, x0                 | X2 = val_17;//m1                        
            // 0x00BC2D7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2D80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2D84: MOV x1, x28                | X1 = val_16;//m1                        
            // 0x00BC2D88: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            object val_18 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            // 0x00BC2D8C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BC2D90: CBZ x0, #0xbc2df4          | if (val_18 == null) goto label_18;      
            if(val_18 == null)
            {
                goto label_18;
            }
            // 0x00BC2D94: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC2D98: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC2D9C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC2DA0: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC2DA4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC2DA8: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC2DAC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC2DB0: B.LO #0xbc2dcc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x00BC2DB4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC2DB8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC2DBC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC2DC0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC2DC4: MOV x23, x0                | X23 = val_18;//m1                       
            val_23 = val_18;
            // 0x00BC2DC8: B.EQ #0xbc2df4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_18;
            label_17:
            // 0x00BC2DCC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC2DD0: ADD x8, sp, #0x28          | X8 = (1152921510052869296 + 40) = 1152921510052869336 (0x10000001449BB4D8);
            // 0x00BC2DD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC2DD8: LDR x0, [sp, #0x28]        | X0 = val_20;                             //  find_add[1152921510052857440]
            // 0x00BC2DDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_20, ????);     
            // 0x00BC2DE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2DE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            // 0x00BC2DE8: ADD x0, sp, #0x28          | X0 = (1152921510052869296 + 40) = 1152921510052869336 (0x10000001449BB4D8);
            // 0x00BC2DEC: BL #0x299a140              | 
            // 0x00BC2DF0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_18:
            // 0x00BC2DF4: CBNZ x19, #0xbc2dfc        | if (X1 != 0) goto label_19;             
            if(X1 != 0)
            {
                goto label_19;
            }
            // 0x00BC2DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449BB4D8, ????);
            label_19:
            // 0x00BC2DFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2E00: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC2E04: MOV x1, x24                | X1 = val_15;//m1                        
            // 0x00BC2E08: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC2E0C: CBNZ x23, #0xbc2e14        | if (0x0 != 0) goto label_20;            
            if(val_23 != 0)
            {
                goto label_20;
            }
            // 0x00BC2E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_20:
            // 0x00BC2E14: LDR w4, [sp, #0xc]         | W4 = val_3 + 4;                         
            // 0x00BC2E18: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC2E1C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2E20: MOV x1, x27                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2E24: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2E28: MOV w3, w22                | W3 = val_4 + 4;//m1                     
            // 0x00BC2E2C: BL #0xb2a250               | val_23.SetHeroAntiCheat(uuid:  val_22, attrName:  val_21, value:  val_4 + 4, acValue:  val_3 + 4);
            val_23.SetHeroAntiCheat(uuid:  val_22, attrName:  val_21, value:  val_4 + 4, acValue:  val_3 + 4);
            // 0x00BC2E30: LDR x0, [sp, #0x10]        | X0 = val_2;                             
            // 0x00BC2E34: SUB sp, x29, #0x50         | SP = (1152921510052869424 - 80) = 1152921510052869344 (0x10000001449BB4E0);
            // 0x00BC2E38: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC2E3C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC2E40: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC2E44: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC2E48: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC2E4C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC2E50: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC2E54: MOV x19, x0                | 
            // 0x00BC2E58: ADD x0, sp, #0x28          | 
            // 0x00BC2E5C: B #0xbc2e74                | 
            // 0x00BC2E60: MOV x19, x0                | 
            // 0x00BC2E64: ADD x0, sp, #0x18          | 
            // 0x00BC2E68: B #0xbc2e74                | 
            // 0x00BC2E6C: MOV x19, x0                | 
            // 0x00BC2E70: ADD x0, sp, #0x20          | 
            label_22:
            // 0x00BC2E74: BL #0x299a140              | 
            // 0x00BC2E78: MOV x0, x19                | 
            // 0x00BC2E7C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC2E80 (12332672), len: 1008  VirtAddr: 0x00BC2E80 RVA: 0x00BC2E80 token: 100663818 methodIndex: 29863 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetHeroAntiCheat_8(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_18;
            //  | 
            string val_21;
            //  | 
            string val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x00BC2E80: STP x28, x27, [sp, #-0x60]! | stack[1152921510053087840] = ???;  stack[1152921510053087848] = ???;  //  dest_result_addr=1152921510053087840 |  dest_result_addr=1152921510053087848
            // 0x00BC2E84: STP x26, x25, [sp, #0x10]  | stack[1152921510053087856] = ???;  stack[1152921510053087864] = ???;  //  dest_result_addr=1152921510053087856 |  dest_result_addr=1152921510053087864
            // 0x00BC2E88: STP x24, x23, [sp, #0x20]  | stack[1152921510053087872] = ???;  stack[1152921510053087880] = ???;  //  dest_result_addr=1152921510053087872 |  dest_result_addr=1152921510053087880
            // 0x00BC2E8C: STP x22, x21, [sp, #0x30]  | stack[1152921510053087888] = ???;  stack[1152921510053087896] = ???;  //  dest_result_addr=1152921510053087888 |  dest_result_addr=1152921510053087896
            // 0x00BC2E90: STP x20, x19, [sp, #0x40]  | stack[1152921510053087904] = ???;  stack[1152921510053087912] = ???;  //  dest_result_addr=1152921510053087904 |  dest_result_addr=1152921510053087912
            // 0x00BC2E94: STP x29, x30, [sp, #0x50]  | stack[1152921510053087920] = ???;  stack[1152921510053087928] = ???;  //  dest_result_addr=1152921510053087920 |  dest_result_addr=1152921510053087928
            // 0x00BC2E98: ADD x29, sp, #0x50         | X29 = (1152921510053087840 + 80) = 1152921510053087920 (0x10000001449F0AB0);
            // 0x00BC2E9C: SUB sp, sp, #0x20          | SP = (1152921510053087840 - 32) = 1152921510053087808 (0x10000001449F0A40);
            // 0x00BC2EA0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC2EA4: LDRB w8, [x19, #0xb94]     | W8 = (bool)static_value_03733B94;       
            // 0x00BC2EA8: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BC2EAC: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BC2EB0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC2EB4: TBNZ w8, #0, #0xbc2ed0     | if (static_value_03733B94 == true) goto label_0;
            // 0x00BC2EB8: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x00BC2EBC: LDR x8, [x8, #0xdb8]       | X8 = 0x2B8AF64;                         
            // 0x00BC2EC0: LDR w0, [x8]               | W0 = 0x297;                             
            // 0x00BC2EC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x297, ????);      
            // 0x00BC2EC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC2ECC: STRB w8, [x19, #0xb94]     | static_value_03733B94 = true;            //  dest_result_addr=57883540
            label_0:
            // 0x00BC2ED0: CBNZ x20, #0xbc2ed8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC2ED4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x297, ????);      
            label_1:
            // 0x00BC2ED8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC2EDC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC2EE0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC2EE4: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC2EE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2EEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2EF0: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC2EF4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC2EF8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2EFC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC2F00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2F04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2F08: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC2F0C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC2F10: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC2F14: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC2F18: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC2F1C: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00BC2F20: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC2F24: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC2F28: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            // 0x00BC2F2C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC2F30: LDR x24, [x28]             | X24 = typeof(System.String);            
            // 0x00BC2F34: TBZ w9, #0, #0xbc2f48      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC2F38: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2F3C: CBNZ w9, #0xbc2f48         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC2F40: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC2F44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC2F48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2F4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC2F50: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC2F54: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC2F58: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC2F5C: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC2F60: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC2F64: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC2F68: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC2F6C: TBZ w9, #0, #0xbc2f80      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC2F70: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2F74: CBNZ w9, #0xbc2f80         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC2F78: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC2F7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC2F80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2F84: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC2F88: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC2F8C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC2F90: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC2F94: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC2F98: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC2F9C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC2FA0: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC2FA4: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC2FA8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC2FAC: TBZ w9, #0, #0xbc2fc0      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC2FB0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC2FB4: CBNZ w9, #0xbc2fc0         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC2FB8: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC2FBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC2FC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC2FC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC2FC8: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC2FCC: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC2FD0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC2FD4: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
            // 0x00BC2FD8: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
            // 0x00BC2FDC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00BC2FE0: CBZ x0, #0xbc3020          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC2FE4: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00BC2FE8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC2FEC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC2FF0: MOV x24, x0                | X24 = val_6;//m1                        
            val_21 = val_6;
            // 0x00BC2FF4: B.EQ #0xbc3020             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC2FF8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC2FFC: ADD x8, sp, #8             | X8 = (1152921510053087808 + 8) = 1152921510053087816 (0x10000001449F0A48);
            // 0x00BC3000: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC3004: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510053075936]
            // 0x00BC3008: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC300C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3010: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC3014: ADD x0, sp, #8             | X0 = (1152921510053087808 + 8) = 1152921510053087816 (0x10000001449F0A48);
            // 0x00BC3018: BL #0x299a140              | 
            // 0x00BC301C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_9:
            // 0x00BC3020: CBNZ x20, #0xbc3028        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC3024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449F0A48, ????);
            label_10:
            // 0x00BC3028: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC302C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC3030: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC3034: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC3038: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC303C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3040: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC3044: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC3048: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC304C: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00BC3050: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x00BC3054: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3058: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC305C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3060: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BC3064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3068: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC306C: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00BC3070: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC3074: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC3078: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC307C: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BC3080: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3084: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3088: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BC308C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BC3090: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BC3094: CBZ x0, #0xbc30d4          | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x00BC3098: LDR x1, [x27]              | X1 = typeof(System.String);             
            // 0x00BC309C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC30A0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC30A4: MOV x25, x0                | X25 = val_11;//m1                       
            val_22 = val_11;
            // 0x00BC30A8: B.EQ #0xbc30d4             | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x00BC30AC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC30B0: ADD x8, sp, #0x10          | X8 = (1152921510053087808 + 16) = 1152921510053087824 (0x10000001449F0A50);
            // 0x00BC30B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC30B8: LDR x0, [sp, #0x10]        | X0 = val_12;                             //  find_add[1152921510053075936]
            // 0x00BC30BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BC30C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC30C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BC30C8: ADD x0, sp, #0x10          | X0 = (1152921510053087808 + 16) = 1152921510053087824 (0x10000001449F0A50);
            // 0x00BC30CC: BL #0x299a140              | 
            // 0x00BC30D0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_12:
            // 0x00BC30D4: CBNZ x20, #0xbc30dc        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00BC30D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449F0A50, ????);
            label_13:
            // 0x00BC30DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC30E0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC30E4: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x00BC30E8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC30EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC30F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC30F4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC30F8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC30FC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC3100: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC3104: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC3108: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00BC310C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3110: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3114: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3118: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC311C: MOV x26, x0                | X26 = val_14;//m1                       
            // 0x00BC3120: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3124: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC3128: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00BC312C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC3130: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC3134: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_15 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC3138: MOV x2, x0                 | X2 = val_15;//m1                        
            // 0x00BC313C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3140: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3144: MOV x1, x26                | X1 = val_14;//m1                        
            // 0x00BC3148: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            object val_16 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_14);
            // 0x00BC314C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BC3150: CBZ x0, #0xbc31b4          | if (val_16 == null) goto label_16;      
            if(val_16 == null)
            {
                goto label_16;
            }
            // 0x00BC3154: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC3158: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC315C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC3160: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3164: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3168: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC316C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3170: B.LO #0xbc318c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x00BC3174: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC3178: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC317C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3180: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3184: MOV x21, x0                | X21 = val_16;//m1                       
            val_23 = val_16;
            // 0x00BC3188: B.EQ #0xbc31b4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x00BC318C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC3190: ADD x8, sp, #0x18          | X8 = (1152921510053087808 + 24) = 1152921510053087832 (0x10000001449F0A58);
            // 0x00BC3194: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC3198: LDR x0, [sp, #0x18]        | X0 = val_18;                             //  find_add[1152921510053075936]
            // 0x00BC319C: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x00BC31A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC31A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x00BC31A8: ADD x0, sp, #0x18          | X0 = (1152921510053087808 + 24) = 1152921510053087832 (0x10000001449F0A58);
            // 0x00BC31AC: BL #0x299a140              | 
            // 0x00BC31B0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_16:
            // 0x00BC31B4: CBNZ x20, #0xbc31bc        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BC31B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001449F0A58, ????);
            label_17:
            // 0x00BC31BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC31C0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC31C4: MOV x1, x22                | X1 = val_13;//m1                        
            // 0x00BC31C8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC31CC: CBNZ x21, #0xbc31d4        | if (0x0 != 0) goto label_18;            
            if(val_23 != 0)
            {
                goto label_18;
            }
            // 0x00BC31D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x00BC31D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC31D8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BC31DC: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BC31E0: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BC31E4: BL #0xb2a48c               | X0 = val_23.GetHeroAntiCheat(uuid:  val_22, attrName:  val_21);
            uint val_19 = val_23.GetHeroAntiCheat(uuid:  val_22, attrName:  val_21);
            // 0x00BC31E8: CBZ x19, #0xbc3248         | if (val_2 == 0) goto label_19;          
            if(val_2 == 0)
            {
                goto label_19;
            }
            // 0x00BC31EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC31F0: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_19;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_19;
            // 0x00BC31F4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC31F8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC31FC: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC3200: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_24 = 8;
            // 0x00BC3204: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC3208: TBZ w9, #0, #0xbc3218      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_20;
            // 0x00BC320C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC3210: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC3214: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_24 = 219381744;
            label_20:
            // 0x00BC3218: ADD x0, x8, x19            | X0 = (val_24 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_20 = val_24 + val_2;
            // 0x00BC321C: SUB sp, x29, #0x50         | SP = (1152921510053087920 - 80) = 1152921510053087840 (0x10000001449F0A60);
            // 0x00BC3220: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3224: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3228: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC322C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC3230: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC3234: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC3238: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_24 + val_2);
            return val_20;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC323C: MOV x19, x0                | X19 = (val_24 + val_2);//m1             
            val_25 = val_20;
            // 0x00BC3240: ADD x0, sp, #0x18          | X0 = (1152921510053087936 + 24) = 1152921510053087960 (0x10000001449F0AD8);
            // 0x00BC3244: B #0xbc3264                |  goto label_22;                         
            goto label_22;
            label_19:
            // 0x00BC3248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            // 0x00BC324C: BRK #0x1                   | 
            // 0x00BC3250: MOV x19, x0                | X19 = val_19;//m1                       
            val_25 = val_19;
            // 0x00BC3254: ADD x0, sp, #8             | X0 = (1152921510053087808 + 8) = 1152921510053087816 (0x10000001449F0A48);
            // 0x00BC3258: B #0xbc3264                |  goto label_22;                         
            goto label_22;
            // 0x00BC325C: MOV x19, x0                | X19 = 1152921510053087816 (0x10000001449F0A48);//ML01
            val_25;
            // 0x00BC3260: ADD x0, sp, #0x10          | X0 = (1152921510053087808 + 16) = 1152921510053087824 (0x10000001449F0A50);
            label_22:
            // 0x00BC3264: BL #0x299a140              | 
            // 0x00BC3268: MOV x0, x19                | X0 = 1152921510053087816 (0x10000001449F0A48);//ML01
            // 0x00BC326C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001449F0A48, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC3270 (12333680), len: 1052  VirtAddr: 0x00BC3270 RVA: 0x00BC3270 token: 100663819 methodIndex: 29864 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* GetHeroAntiCheat_9(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            var val_19;
            //  | 
            string val_22;
            //  | 
            string val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            // 0x00BC3270: STP x28, x27, [sp, #-0x60]! | stack[1152921510053306336] = ???;  stack[1152921510053306344] = ???;  //  dest_result_addr=1152921510053306336 |  dest_result_addr=1152921510053306344
            // 0x00BC3274: STP x26, x25, [sp, #0x10]  | stack[1152921510053306352] = ???;  stack[1152921510053306360] = ???;  //  dest_result_addr=1152921510053306352 |  dest_result_addr=1152921510053306360
            // 0x00BC3278: STP x24, x23, [sp, #0x20]  | stack[1152921510053306368] = ???;  stack[1152921510053306376] = ???;  //  dest_result_addr=1152921510053306368 |  dest_result_addr=1152921510053306376
            // 0x00BC327C: STP x22, x21, [sp, #0x30]  | stack[1152921510053306384] = ???;  stack[1152921510053306392] = ???;  //  dest_result_addr=1152921510053306384 |  dest_result_addr=1152921510053306392
            // 0x00BC3280: STP x20, x19, [sp, #0x40]  | stack[1152921510053306400] = ???;  stack[1152921510053306408] = ???;  //  dest_result_addr=1152921510053306400 |  dest_result_addr=1152921510053306408
            // 0x00BC3284: STP x29, x30, [sp, #0x50]  | stack[1152921510053306416] = ???;  stack[1152921510053306424] = ???;  //  dest_result_addr=1152921510053306416 |  dest_result_addr=1152921510053306424
            // 0x00BC3288: ADD x29, sp, #0x50         | X29 = (1152921510053306336 + 80) = 1152921510053306416 (0x1000000144A26030);
            // 0x00BC328C: SUB sp, sp, #0x20          | SP = (1152921510053306336 - 32) = 1152921510053306304 (0x1000000144A25FC0);
            // 0x00BC3290: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC3294: LDRB w8, [x19, #0xb95]     | W8 = (bool)static_value_03733B95;       
            // 0x00BC3298: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BC329C: MOV x23, x2                | X23 = X2;//m1                           
            // 0x00BC32A0: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BC32A4: TBNZ w8, #0, #0xbc32c0     | if (static_value_03733B95 == true) goto label_0;
            // 0x00BC32A8: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x00BC32AC: LDR x8, [x8, #0xd50]       | X8 = 0x2B8AF68;                         
            // 0x00BC32B0: LDR w0, [x8]               | W0 = 0x298;                             
            // 0x00BC32B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x298, ????);      
            // 0x00BC32B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC32BC: STRB w8, [x19, #0xb95]     | static_value_03733B95 = true;            //  dest_result_addr=57883541
            label_0:
            // 0x00BC32C0: CBNZ x20, #0xbc32c8        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC32C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x298, ????);      
            label_1:
            // 0x00BC32C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC32CC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC32D0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC32D4: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BC32D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC32DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC32E0: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC32E4: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC32E8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC32EC: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BC32F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC32F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC32F8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC32FC: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC3300: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC3304: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BC3308: CBNZ x21, #0xbc3310        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BC330C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BC3310: LDR w8, [x21, #4]          | W8 = val_3 + 4;                         
            // 0x00BC3314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3318: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC331C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC3320: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC3324: STR w8, [sp, #4]           | stack[1152921510053306308] = val_3 + 4;  //  dest_result_addr=1152921510053306308
            // 0x00BC3328: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC332C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC3330: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC3334: ADRP x28, #0x3607000       | X28 = 56651776 (0x3607000);             
            // 0x00BC3338: MOV x26, x0                | X26 = val_4;//m1                        
            // 0x00BC333C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC3340: LDR x28, [x28, #0xbb8]     | X28 = 1152921504608284672;              
            // 0x00BC3344: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC3348: LDR x25, [x28]             | X25 = typeof(System.String);            
            // 0x00BC334C: TBZ w9, #0, #0xbc3360      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BC3350: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC3354: CBNZ w9, #0xbc3360         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BC3358: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC335C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BC3360: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3364: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3368: MOV x1, x25                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC336C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3370: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC3374: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC3378: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BC337C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC3380: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC3384: TBZ w9, #0, #0xbc3398      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BC3388: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC338C: CBNZ w9, #0xbc3398         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BC3390: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC3394: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BC3398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC339C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC33A0: MOV x1, x26                | X1 = val_4;//m1                         
            // 0x00BC33A4: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC33A8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC33AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC33B0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC33B4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC33B8: MOV x27, x0                | X27 = val_6;//m1                        
            // 0x00BC33BC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC33C0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC33C4: TBZ w9, #0, #0xbc33d8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BC33C8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC33CC: CBNZ w9, #0xbc33d8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BC33D0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC33D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BC33D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC33DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC33E0: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BC33E4: MOV x2, x27                | X2 = val_6;//m1                         
            // 0x00BC33E8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BC33EC: ADRP x21, #0x35d6000       | X21 = 56451072 (0x35D6000);             
            // 0x00BC33F0: LDR x21, [x21, #0xe38]     | X21 = 1152921504608284672;              
            // 0x00BC33F4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BC33F8: CBZ x0, #0xbc3438          | if (val_7 == null) goto label_10;       
            if(val_7 == null)
            {
                goto label_10;
            }
            // 0x00BC33FC: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC3400: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC3404: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC3408: MOV x25, x0                | X25 = val_7;//m1                        
            val_22 = val_7;
            // 0x00BC340C: B.EQ #0xbc3438             | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x00BC3410: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC3414: ADD x8, sp, #8             | X8 = (1152921510053306304 + 8) = 1152921510053306312 (0x1000000144A25FC8);
            // 0x00BC3418: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC341C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510053294432]
            // 0x00BC3420: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BC3424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3428: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BC342C: ADD x0, sp, #8             | X0 = (1152921510053306304 + 8) = 1152921510053306312 (0x1000000144A25FC8);
            // 0x00BC3430: BL #0x299a140              | 
            // 0x00BC3434: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_10:
            // 0x00BC3438: CBNZ x20, #0xbc3440        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BC343C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A25FC8, ????);
            label_11:
            // 0x00BC3440: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3444: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC3448: MOV x1, x26                | X1 = val_4;//m1                         
            // 0x00BC344C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC3450: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3454: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3458: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BC345C: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC3460: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC3464: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x00BC3468: MOV x27, x0                | X27 = val_9;//m1                        
            // 0x00BC346C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3470: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3474: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3478: MOV x26, x0                | X26 = val_10;//m1                       
            // 0x00BC347C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3480: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC3484: MOV x1, x27                | X1 = val_9;//m1                         
            // 0x00BC3488: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC348C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC3490: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC3494: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BC3498: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC349C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC34A0: MOV x1, x26                | X1 = val_10;//m1                        
            // 0x00BC34A4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BC34A8: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BC34AC: CBZ x0, #0xbc34ec          | if (val_12 == null) goto label_13;      
            if(val_12 == null)
            {
                goto label_13;
            }
            // 0x00BC34B0: LDR x1, [x21]              | X1 = typeof(System.String);             
            // 0x00BC34B4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC34B8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC34BC: MOV x26, x0                | X26 = val_12;//m1                       
            val_23 = val_12;
            // 0x00BC34C0: B.EQ #0xbc34ec             | if (typeof(System.Object) == null) goto label_13;
            if(null == null)
            {
                goto label_13;
            }
            // 0x00BC34C4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC34C8: ADD x8, sp, #0x10          | X8 = (1152921510053306304 + 16) = 1152921510053306320 (0x1000000144A25FD0);
            // 0x00BC34CC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC34D0: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510053294432]
            // 0x00BC34D4: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BC34D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC34DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BC34E0: ADD x0, sp, #0x10          | X0 = (1152921510053306304 + 16) = 1152921510053306320 (0x1000000144A25FD0);
            // 0x00BC34E4: BL #0x299a140              | 
            // 0x00BC34E8: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_13:
            // 0x00BC34EC: CBNZ x20, #0xbc34f4        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BC34F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A25FD0, ????);
            label_14:
            // 0x00BC34F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC34F8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC34FC: MOV x1, x27                | X1 = val_9;//m1                         
            // 0x00BC3500: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC3504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3508: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC350C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BC3510: MOV x1, x23                | X1 = X2;//m1                            
            // 0x00BC3514: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC3518: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC351C: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC3520: MOV x23, x0                | X23 = val_14;//m1                       
            // 0x00BC3524: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3528: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC352C: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3530: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3534: MOV x27, x0                | X27 = val_15;//m1                       
            // 0x00BC3538: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC353C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC3540: MOV x1, x23                | X1 = val_14;//m1                        
            // 0x00BC3544: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BC3548: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BC354C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_16 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BC3550: MOV x2, x0                 | X2 = val_16;//m1                        
            // 0x00BC3554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3558: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC355C: MOV x1, x27                | X1 = val_15;//m1                        
            // 0x00BC3560: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            object val_17 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_15);
            // 0x00BC3564: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x00BC3568: CBZ x0, #0xbc35cc          | if (val_17 == null) goto label_17;      
            if(val_17 == null)
            {
                goto label_17;
            }
            // 0x00BC356C: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC3570: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC3574: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC3578: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC357C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3580: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3584: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3588: B.LO #0xbc35a4             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x00BC358C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC3590: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC3594: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3598: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC359C: MOV x22, x0                | X22 = val_17;//m1                       
            val_24 = val_17;
            // 0x00BC35A0: B.EQ #0xbc35cc             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x00BC35A4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC35A8: ADD x8, sp, #0x18          | X8 = (1152921510053306304 + 24) = 1152921510053306328 (0x1000000144A25FD8);
            // 0x00BC35AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC35B0: LDR x0, [sp, #0x18]        | X0 = val_19;                             //  find_add[1152921510053294432]
            // 0x00BC35B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x00BC35B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC35BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x00BC35C0: ADD x0, sp, #0x18          | X0 = (1152921510053306304 + 24) = 1152921510053306328 (0x1000000144A25FD8);
            // 0x00BC35C4: BL #0x299a140              | 
            // 0x00BC35C8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_24 = 0;
            label_17:
            // 0x00BC35CC: CBNZ x20, #0xbc35d4        | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x00BC35D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A25FD8, ????);
            label_18:
            // 0x00BC35D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC35D8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC35DC: MOV x1, x23                | X1 = val_14;//m1                        
            // 0x00BC35E0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC35E4: CBNZ x22, #0xbc35ec        | if (0x0 != 0) goto label_19;            
            if(val_24 != 0)
            {
                goto label_19;
            }
            // 0x00BC35E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_19:
            // 0x00BC35EC: LDR w3, [sp, #4]           | W3 = val_3 + 4;                         
            // 0x00BC35F0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC35F4: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BC35F8: MOV x1, x26                | X1 = 0 (0x0);//ML01                     
            // 0x00BC35FC: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3600: BL #0xb2a5bc               | X0 = val_24.GetHeroAntiCheat(uuid:  val_23, attrName:  val_22, defaultValue:  val_3 + 4);
            int val_20 = val_24.GetHeroAntiCheat(uuid:  val_23, attrName:  val_22, defaultValue:  val_3 + 4);
            // 0x00BC3604: CBZ x19, #0xbc3664         | if (val_2 == 0) goto label_20;          
            if(val_2 == 0)
            {
                goto label_20;
            }
            // 0x00BC3608: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC360C: STP w8, w0, [x19]          | mem2[0] = 0x1;  mem2[0] = val_20;        //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 1;
            mem2[0] = val_20;
            // 0x00BC3610: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC3614: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC3618: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC361C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_25 = 8;
            // 0x00BC3620: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BC3624: TBZ w9, #0, #0xbc3634      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_21;
            // 0x00BC3628: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BC362C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BC3630: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_25 = 219381744;
            label_21:
            // 0x00BC3634: ADD x0, x8, x19            | X0 = (val_25 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_21 = val_25 + val_2;
            // 0x00BC3638: SUB sp, x29, #0x50         | SP = (1152921510053306416 - 80) = 1152921510053306336 (0x1000000144A25FE0);
            // 0x00BC363C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3640: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3644: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC3648: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC364C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BC3650: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BC3654: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_25 + val_2);
            return val_21;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC3658: MOV x19, x0                | X19 = (val_25 + val_2);//m1             
            val_26 = val_21;
            // 0x00BC365C: ADD x0, sp, #0x18          | X0 = (1152921510053306432 + 24) = 1152921510053306456 (0x1000000144A26058);
            // 0x00BC3660: B #0xbc3680                |  goto label_23;                         
            goto label_23;
            label_20:
            // 0x00BC3664: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            // 0x00BC3668: BRK #0x1                   | 
            // 0x00BC366C: MOV x19, x0                | X19 = val_20;//m1                       
            val_26 = val_20;
            // 0x00BC3670: ADD x0, sp, #8             | X0 = (1152921510053306304 + 8) = 1152921510053306312 (0x1000000144A25FC8);
            // 0x00BC3674: B #0xbc3680                |  goto label_23;                         
            goto label_23;
            // 0x00BC3678: MOV x19, x0                | X19 = 1152921510053306312 (0x1000000144A25FC8);//ML01
            val_26;
            // 0x00BC367C: ADD x0, sp, #0x10          | X0 = (1152921510053306304 + 16) = 1152921510053306320 (0x1000000144A25FD0);
            label_23:
            // 0x00BC3680: BL #0x299a140              | 
            // 0x00BC3684: MOV x0, x19                | X0 = 1152921510053306312 (0x1000000144A25FC8);//ML01
            // 0x00BC3688: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144A25FC8, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC368C (12334732), len: 748  VirtAddr: 0x00BC368C RVA: 0x00BC368C token: 100663820 methodIndex: 29865 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* RemoveHeroAntiCheat_10(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_13;
            //  | 
            string val_14;
            //  | 
            var val_15;
            // 0x00BC368C: STP x26, x25, [sp, #-0x50]! | stack[1152921510053512560] = ???;  stack[1152921510053512568] = ???;  //  dest_result_addr=1152921510053512560 |  dest_result_addr=1152921510053512568
            // 0x00BC3690: STP x24, x23, [sp, #0x10]  | stack[1152921510053512576] = ???;  stack[1152921510053512584] = ???;  //  dest_result_addr=1152921510053512576 |  dest_result_addr=1152921510053512584
            // 0x00BC3694: STP x22, x21, [sp, #0x20]  | stack[1152921510053512592] = ???;  stack[1152921510053512600] = ???;  //  dest_result_addr=1152921510053512592 |  dest_result_addr=1152921510053512600
            // 0x00BC3698: STP x20, x19, [sp, #0x30]  | stack[1152921510053512608] = ???;  stack[1152921510053512616] = ???;  //  dest_result_addr=1152921510053512608 |  dest_result_addr=1152921510053512616
            // 0x00BC369C: STP x29, x30, [sp, #0x40]  | stack[1152921510053512624] = ???;  stack[1152921510053512632] = ???;  //  dest_result_addr=1152921510053512624 |  dest_result_addr=1152921510053512632
            // 0x00BC36A0: ADD x29, sp, #0x40         | X29 = (1152921510053512560 + 64) = 1152921510053512624 (0x1000000144A585B0);
            // 0x00BC36A4: SUB sp, sp, #0x10          | SP = (1152921510053512560 - 16) = 1152921510053512544 (0x1000000144A58560);
            // 0x00BC36A8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC36AC: LDRB w8, [x20, #0xb96]     | W8 = (bool)static_value_03733B96;       
            // 0x00BC36B0: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BC36B4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BC36B8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC36BC: TBNZ w8, #0, #0xbc36d8     | if (static_value_03733B96 == true) goto label_0;
            // 0x00BC36C0: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BC36C4: LDR x8, [x8, #0xf8]        | X8 = 0x2B8AF78;                         
            // 0x00BC36C8: LDR w0, [x8]               | W0 = 0x29C;                             
            // 0x00BC36CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x29C, ????);      
            // 0x00BC36D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC36D4: STRB w8, [x20, #0xb96]     | static_value_03733B96 = true;            //  dest_result_addr=57883542
            label_0:
            // 0x00BC36D8: CBNZ x19, #0xbc36e0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC36DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x29C, ????);      
            label_1:
            // 0x00BC36E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC36E4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC36E8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BC36EC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BC36F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC36F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC36F8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC36FC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC3700: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC3704: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BC3708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC370C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3710: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BC3714: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC3718: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC371C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC3720: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC3724: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BC3728: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BC372C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BC3730: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x00BC3734: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x00BC3738: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC373C: TBZ w9, #0, #0xbc3750      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BC3740: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC3744: CBNZ w9, #0xbc3750         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BC3748: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC374C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BC3750: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3754: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3758: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00BC375C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3760: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BC3764: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BC3768: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BC376C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BC3770: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BC3774: TBZ w9, #0, #0xbc3788      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BC3778: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BC377C: CBNZ w9, #0xbc3788         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BC3780: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BC3784: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BC3788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC378C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC3790: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC3794: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC3798: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC379C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC37A0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BC37A4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BC37A8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BC37AC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BC37B0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BC37B4: TBZ w9, #0, #0xbc37c8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC37B8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BC37BC: CBNZ w9, #0xbc37c8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC37C0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BC37C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BC37C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC37CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC37D0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BC37D4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BC37D8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BC37DC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x00BC37E0: CBZ x0, #0xbc3828          | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x00BC37E4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00BC37E8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00BC37EC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00BC37F0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC37F4: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00BC37F8: MOV x24, x0                | X24 = val_6;//m1                        
            val_14 = val_6;
            // 0x00BC37FC: B.EQ #0xbc3828             | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x00BC3800: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC3804: MOV x8, sp                 | X8 = 1152921510053512544 (0x1000000144A58560);//ML01
            // 0x00BC3808: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC380C: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510053500640]
            // 0x00BC3810: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x00BC3814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3818: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x00BC381C: MOV x0, sp                 | X0 = 1152921510053512544 (0x1000000144A58560);//ML01
            // 0x00BC3820: BL #0x299a140              | 
            // 0x00BC3824: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_9:
            // 0x00BC3828: CBNZ x19, #0xbc3830        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BC382C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A58560, ????);
            label_10:
            // 0x00BC3830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3834: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC3838: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BC383C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC3840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3844: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3848: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BC384C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BC3850: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BC3854: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00BC3858: LDR x8, [x8, #0x728]       | X8 = 1152921504902479872;               
            // 0x00BC385C: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BC3860: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3864: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3868: LDR x1, [x8]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC386C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3870: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x00BC3874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3878: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BC387C: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BC3880: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BC3884: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BC3888: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BC388C: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00BC3890: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3894: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3898: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x00BC389C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x00BC38A0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BC38A4: CBZ x0, #0xbc3908          | if (val_11 == null) goto label_13;      
            if(val_11 == null)
            {
                goto label_13;
            }
            // 0x00BC38A8: ADRP x9, #0x3678000        | X9 = 57114624 (0x3678000);              
            // 0x00BC38AC: LDR x9, [x9, #0x328]       | X9 = 1152921504902479872;               
            // 0x00BC38B0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BC38B4: LDR x1, [x9]               | X1 = typeof(AntiCheatMgr);              
            // 0x00BC38B8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC38BC: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC38C0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC38C4: B.LO #0xbc38e0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BC38C8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BC38CC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHier
            // 0x00BC38D0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC38D4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC38D8: MOV x21, x0                | X21 = val_11;//m1                       
            val_15 = val_11;
            // 0x00BC38DC: B.EQ #0xbc3908             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BC38E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BC38E4: ADD x8, sp, #8             | X8 = (1152921510053512544 + 8) = 1152921510053512552 (0x1000000144A58568);
            // 0x00BC38E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BC38EC: LDR x0, [sp, #8]           | X0 = val_13;                             //  find_add[1152921510053500640]
            // 0x00BC38F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x00BC38F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC38F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x00BC38FC: ADD x0, sp, #8             | X0 = (1152921510053512544 + 8) = 1152921510053512552 (0x1000000144A58568);
            // 0x00BC3900: BL #0x299a140              | 
            // 0x00BC3904: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_13:
            // 0x00BC3908: CBNZ x19, #0xbc3910        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BC390C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A58568, ????);
            label_14:
            // 0x00BC3910: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3914: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC3918: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x00BC391C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BC3920: CBNZ x21, #0xbc3928        | if (0x0 != 0) goto label_15;            
            if(val_15 != 0)
            {
                goto label_15;
            }
            // 0x00BC3924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BC3928: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC392C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3930: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3934: BL #0xb2a6ec               | val_15.RemoveHeroAntiCheat(uuid:  val_14);
            val_15.RemoveHeroAntiCheat(uuid:  val_14);
            // 0x00BC3938: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BC393C: SUB sp, x29, #0x40         | SP = (1152921510053512624 - 64) = 1152921510053512560 (0x1000000144A58570);
            // 0x00BC3940: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3944: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3948: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC394C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BC3950: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BC3954: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BC3958: MOV x19, x0                | 
            // 0x00BC395C: ADD x0, sp, #8             | 
            // 0x00BC3960: B #0xbc396c                | 
            // 0x00BC3964: MOV x19, x0                | 
            // 0x00BC3968: MOV x0, sp                 | 
            label_16:
            // 0x00BC396C: BL #0x299a140              | 
            // 0x00BC3970: MOV x0, x19                | 
            // 0x00BC3974: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC3978 (12335480), len: 288  VirtAddr: 0x00BC3978 RVA: 0x00BC3978 token: 100663821 methodIndex: 29866 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_heroAntiCheatCSData_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BC3978: STP x20, x19, [sp, #-0x20]! | stack[1152921510053669584] = ???;  stack[1152921510053669592] = ???;  //  dest_result_addr=1152921510053669584 |  dest_result_addr=1152921510053669592
            // 0x00BC397C: STP x29, x30, [sp, #0x10]  | stack[1152921510053669600] = ???;  stack[1152921510053669608] = ???;  //  dest_result_addr=1152921510053669600 |  dest_result_addr=1152921510053669608
            // 0x00BC3980: ADD x29, sp, #0x10         | X29 = (1152921510053669584 + 16) = 1152921510053669600 (0x1000000144A7EAE0);
            // 0x00BC3984: SUB sp, sp, #0x10          | SP = (1152921510053669584 - 16) = 1152921510053669568 (0x1000000144A7EAC0);
            // 0x00BC3988: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC398C: LDRB w8, [x20, #0xb97]     | W8 = (bool)static_value_03733B97;       
            // 0x00BC3990: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC3994: TBNZ w8, #0, #0xbc39b0     | if (static_value_03733B97 == true) goto label_0;
            // 0x00BC3998: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00BC399C: LDR x8, [x8, #0x9b8]       | X8 = 0x2B8AF5C;                         
            // 0x00BC39A0: LDR w0, [x8]               | W0 = 0x295;                             
            // 0x00BC39A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x295, ????);      
            // 0x00BC39A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC39AC: STRB w8, [x20, #0xb97]     | static_value_03733B97 = true;            //  dest_result_addr=57883543
            label_0:
            // 0x00BC39B0: ADRP x20, #0x3678000       | X20 = 57114624 (0x3678000);             
            // 0x00BC39B4: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BC39B8: LDR x20, [x20, #0x328]     | X20 = 1152921504902479872;              
            // 0x00BC39BC: CBZ x19, #0xbc3a10         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BC39C0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BC39C4: LDR x1, [x20]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC39C8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BC39CC: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC39D0: CMP w10, w9                | STATE = COMPARE(X1 + 260, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC39D4: B.LO #0xbc39ec             | if (X1 + 260 < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BC39D8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BC39DC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC39E0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC39E4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC39E8: B.EQ #0xbc3a14             | if ((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BC39EC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC39F0: MOV x8, sp                 | X8 = 1152921510053669568 (0x1000000144A7EAC0);//ML01
            // 0x00BC39F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC39F8: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510053657616]
            // 0x00BC39FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BC3A00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3A04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BC3A08: MOV x0, sp                 | X0 = 1152921510053669568 (0x1000000144A7EAC0);//ML01
            // 0x00BC3A0C: BL #0x299a140              | 
            label_1:
            // 0x00BC3A10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A7EAC0, ????);
            label_3:
            // 0x00BC3A14: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BC3A18: LDR x1, [x20]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3A1C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BC3A20: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3A24: CMP w10, w9                | STATE = COMPARE(X1 + 260, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3A28: B.LO #0xbc3a54             | if (X1 + 260 < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BC3A2C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BC3A30: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3A34: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3A38: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3A3C: B.NE #0xbc3a54             | if ((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BC3A40: LDR x0, [x19, #0x10]       | X0 = X1 + 16;                           
            // 0x00BC3A44: SUB sp, x29, #0x10         | SP = (1152921510053669600 - 16) = 1152921510053669584 (0x1000000144A7EAD0);
            // 0x00BC3A48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3A4C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3A50: RET                        |  return (System.Object)X1 + 16;         
            return (object)X1 + 16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BC3A54: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC3A58: ADD x8, sp, #8             | X8 = (1152921510053669568 + 8) = 1152921510053669576 (0x1000000144A7EAC8);
            // 0x00BC3A5C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC3A60: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510053657616]
            // 0x00BC3A64: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC3A68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3A6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC3A70: ADD x0, sp, #8             | X0 = (1152921510053669568 + 8) = 1152921510053669576 (0x1000000144A7EAC8);
            // 0x00BC3A74: BL #0x299a140              | 
            // 0x00BC3A78: MOV x19, x0                | X19 = 1152921510053669576 (0x1000000144A7EAC8);//ML01
            // 0x00BC3A7C: MOV x0, sp                 | X0 = 1152921510053669568 (0x1000000144A7EAC0);//ML01
            label_6:
            // 0x00BC3A80: BL #0x299a140              | 
            // 0x00BC3A84: MOV x0, x19                | X0 = 1152921510053669576 (0x1000000144A7EAC8);//ML01
            // 0x00BC3A88: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144A7EAC8, ????);
            // 0x00BC3A8C: MOV x19, x0                | X19 = 1152921510053669576 (0x1000000144A7EAC8);//ML01
            // 0x00BC3A90: ADD x0, sp, #8             | X0 = (1152921510053669568 + 8) = 1152921510053669576 (0x1000000144A7EAC8);
            // 0x00BC3A94: B #0xbc3a80                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC3A98 (12335768), len: 420  VirtAddr: 0x00BC3A98 RVA: 0x00BC3A98 token: 100663822 methodIndex: 29867 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_heroAntiCheatCSData_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BC3A98: STP x22, x21, [sp, #-0x30]! | stack[1152921510053793696] = ???;  stack[1152921510053793704] = ???;  //  dest_result_addr=1152921510053793696 |  dest_result_addr=1152921510053793704
            // 0x00BC3A9C: STP x20, x19, [sp, #0x10]  | stack[1152921510053793712] = ???;  stack[1152921510053793720] = ???;  //  dest_result_addr=1152921510053793712 |  dest_result_addr=1152921510053793720
            // 0x00BC3AA0: STP x29, x30, [sp, #0x20]  | stack[1152921510053793728] = ???;  stack[1152921510053793736] = ???;  //  dest_result_addr=1152921510053793728 |  dest_result_addr=1152921510053793736
            // 0x00BC3AA4: ADD x29, sp, #0x20         | X29 = (1152921510053793696 + 32) = 1152921510053793728 (0x1000000144A9CFC0);
            // 0x00BC3AA8: SUB sp, sp, #0x20          | SP = (1152921510053793696 - 32) = 1152921510053793664 (0x1000000144A9CF80);
            // 0x00BC3AAC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC3AB0: LDRB w8, [x21, #0xb98]     | W8 = (bool)static_value_03733B98;       
            // 0x00BC3AB4: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00BC3AB8: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BC3ABC: TBNZ w8, #0, #0xbc3ad8     | if (static_value_03733B98 == true) goto label_0;
            // 0x00BC3AC0: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x00BC3AC4: LDR x8, [x8, #0xc48]       | X8 = 0x2B8AF80;                         
            // 0x00BC3AC8: LDR w0, [x8]               | W0 = 0x29E;                             
            // 0x00BC3ACC: BL #0x2782188              | X0 = sub_2782188( ?? 0x29E, ????);      
            // 0x00BC3AD0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC3AD4: STRB w8, [x21, #0xb98]     | static_value_03733B98 = true;            //  dest_result_addr=57883544
            label_0:
            // 0x00BC3AD8: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BC3ADC: CBZ x20, #0xbc3b90         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BC3AE0: ADRP x21, #0x3678000       | X21 = 57114624 (0x3678000);             
            // 0x00BC3AE4: LDR x21, [x21, #0x328]     | X21 = 1152921504902479872;              
            val_7 = 1152921504902479872;
            // 0x00BC3AE8: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC3AEC: LDR x1, [x21]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3AF0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BC3AF4: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3AF8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3AFC: B.LO #0xbc3b14             | if (mem[null + 260] < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BC3B00: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BC3B04: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3B08: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3B0C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3B10: B.EQ #0xbc3b3c             | if ((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BC3B14: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC3B18: ADD x8, sp, #8             | X8 = (1152921510053793664 + 8) = 1152921510053793672 (0x1000000144A9CF88);
            // 0x00BC3B1C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BC3B20: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510053781744]
            // 0x00BC3B24: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BC3B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3B2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BC3B30: ADD x0, sp, #8             | X0 = (1152921510053793664 + 8) = 1152921510053793672 (0x1000000144A9CF88);
            // 0x00BC3B34: BL #0x299a140              | 
            // 0x00BC3B38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144A9CF88, ????);
            label_3:
            // 0x00BC3B3C: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC3B40: LDR x1, [x21]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3B44: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BC3B48: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3B4C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3B50: B.LO #0xbc3b68             | if (mem[null + 260] < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BC3B54: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BC3B58: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3B5C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3B60: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3B64: B.EQ #0xbc3b98             | if ((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BC3B68: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC3B6C: ADD x8, sp, #0x10          | X8 = (1152921510053793664 + 16) = 1152921510053793680 (0x1000000144A9CF90);
            // 0x00BC3B70: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BC3B74: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510053781744]
            // 0x00BC3B78: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC3B7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3B80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC3B84: ADD x0, sp, #0x10          | X0 = (1152921510053793664 + 16) = 1152921510053793680 (0x1000000144A9CF90);
            // 0x00BC3B88: BL #0x299a140              | 
            // 0x00BC3B8C: B #0xbc3b94                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BC3B90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x29E, ????);      
            label_6:
            // 0x00BC3B94: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x00BC3B98: CBZ x19, #0xbc3bf4         | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00BC3B9C: ADRP x9, #0x35dc000        | X9 = 56475648 (0x35DC000);              
            // 0x00BC3BA0: LDR x9, [x9, #0xd90]       | X9 = 1152921504615792640;               
            // 0x00BC3BA4: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BC3BA8: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            // 0x00BC3BAC: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x00BC3BB0: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3BB4: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3BB8: B.LO #0xbc3bd0             | if (X2 + 260 < System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00BC3BBC: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x00BC3BC0: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHiera
            // 0x00BC3BC4: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3BC8: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.Dictionary<TKey, TValue>))
            // 0x00BC3BCC: B.EQ #0xbc3bf8             | if ((X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00BC3BD0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BC3BD4: ADD x8, sp, #0x18          | X8 = (1152921510053793664 + 24) = 1152921510053793688 (0x1000000144A9CF98);
            // 0x00BC3BD8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BC3BDC: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510053781744]
            // 0x00BC3BE0: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BC3BE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3BE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BC3BEC: ADD x0, sp, #0x18          | X0 = (1152921510053793664 + 24) = 1152921510053793688 (0x1000000144A9CF98);
            // 0x00BC3BF0: BL #0x299a140              | 
            label_7:
            // 0x00BC3BF4: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BC3BF8: STR x19, [x20, #0x10]      | mem[16] = 0x0;                           //  dest_result_addr=16
            mem[16] = val_8;
            // 0x00BC3BFC: SUB sp, x29, #0x20         | SP = (1152921510053793728 - 32) = 1152921510053793696 (0x1000000144A9CFA0);
            // 0x00BC3C00: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3C04: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3C08: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC3C0C: RET                        |  return;                                
            return;
            // 0x00BC3C10: MOV x19, x0                | 
            // 0x00BC3C14: ADD x0, sp, #8             | 
            // 0x00BC3C18: B #0xbc3c30                | 
            // 0x00BC3C1C: MOV x19, x0                | 
            // 0x00BC3C20: ADD x0, sp, #0x10          | 
            // 0x00BC3C24: B #0xbc3c30                | 
            // 0x00BC3C28: MOV x19, x0                | 
            // 0x00BC3C2C: ADD x0, sp, #0x18          | 
            label_11:
            // 0x00BC3C30: BL #0x299a140              | 
            // 0x00BC3C34: MOV x0, x19                | 
            // 0x00BC3C38: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC3C3C (12336188), len: 288  VirtAddr: 0x00BC3C3C RVA: 0x00BC3C3C token: 100663823 methodIndex: 29868 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_heroAntiCheatData_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BC3C3C: STP x20, x19, [sp, #-0x20]! | stack[1152921510053917840] = ???;  stack[1152921510053917848] = ???;  //  dest_result_addr=1152921510053917840 |  dest_result_addr=1152921510053917848
            // 0x00BC3C40: STP x29, x30, [sp, #0x10]  | stack[1152921510053917856] = ???;  stack[1152921510053917864] = ???;  //  dest_result_addr=1152921510053917856 |  dest_result_addr=1152921510053917864
            // 0x00BC3C44: ADD x29, sp, #0x10         | X29 = (1152921510053917840 + 16) = 1152921510053917856 (0x1000000144ABB4A0);
            // 0x00BC3C48: SUB sp, sp, #0x10          | SP = (1152921510053917840 - 16) = 1152921510053917824 (0x1000000144ABB480);
            // 0x00BC3C4C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC3C50: LDRB w8, [x20, #0xb99]     | W8 = (bool)static_value_03733B99;       
            // 0x00BC3C54: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC3C58: TBNZ w8, #0, #0xbc3c74     | if (static_value_03733B99 == true) goto label_0;
            // 0x00BC3C5C: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00BC3C60: LDR x8, [x8, #0x228]       | X8 = 0x2B8AF60;                         
            // 0x00BC3C64: LDR w0, [x8]               | W0 = 0x296;                             
            // 0x00BC3C68: BL #0x2782188              | X0 = sub_2782188( ?? 0x296, ????);      
            // 0x00BC3C6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC3C70: STRB w8, [x20, #0xb99]     | static_value_03733B99 = true;            //  dest_result_addr=57883545
            label_0:
            // 0x00BC3C74: ADRP x20, #0x3678000       | X20 = 57114624 (0x3678000);             
            // 0x00BC3C78: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BC3C7C: LDR x20, [x20, #0x328]     | X20 = 1152921504902479872;              
            // 0x00BC3C80: CBZ x19, #0xbc3cd4         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BC3C84: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BC3C88: LDR x1, [x20]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3C8C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BC3C90: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3C94: CMP w10, w9                | STATE = COMPARE(X1 + 260, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3C98: B.LO #0xbc3cb0             | if (X1 + 260 < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BC3C9C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BC3CA0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3CA4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3CA8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3CAC: B.EQ #0xbc3cd8             | if ((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BC3CB0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC3CB4: MOV x8, sp                 | X8 = 1152921510053917824 (0x1000000144ABB480);//ML01
            // 0x00BC3CB8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC3CBC: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510053905872]
            // 0x00BC3CC0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BC3CC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3CC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BC3CCC: MOV x0, sp                 | X0 = 1152921510053917824 (0x1000000144ABB480);//ML01
            // 0x00BC3CD0: BL #0x299a140              | 
            label_1:
            // 0x00BC3CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144ABB480, ????);
            label_3:
            // 0x00BC3CD8: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BC3CDC: LDR x1, [x20]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3CE0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BC3CE4: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3CE8: CMP w10, w9                | STATE = COMPARE(X1 + 260, AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3CEC: B.LO #0xbc3d18             | if (X1 + 260 < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BC3CF0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BC3CF4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3CF8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3CFC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3D00: B.NE #0xbc3d18             | if ((X1 + 176 + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BC3D04: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x00BC3D08: SUB sp, x29, #0x10         | SP = (1152921510053917856 - 16) = 1152921510053917840 (0x1000000144ABB490);
            // 0x00BC3D0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3D10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3D14: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BC3D18: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC3D1C: ADD x8, sp, #8             | X8 = (1152921510053917824 + 8) = 1152921510053917832 (0x1000000144ABB488);
            // 0x00BC3D20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC3D24: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510053905872]
            // 0x00BC3D28: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC3D2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3D30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC3D34: ADD x0, sp, #8             | X0 = (1152921510053917824 + 8) = 1152921510053917832 (0x1000000144ABB488);
            // 0x00BC3D38: BL #0x299a140              | 
            // 0x00BC3D3C: MOV x19, x0                | X19 = 1152921510053917832 (0x1000000144ABB488);//ML01
            // 0x00BC3D40: MOV x0, sp                 | X0 = 1152921510053917824 (0x1000000144ABB480);//ML01
            label_6:
            // 0x00BC3D44: BL #0x299a140              | 
            // 0x00BC3D48: MOV x0, x19                | X0 = 1152921510053917832 (0x1000000144ABB488);//ML01
            // 0x00BC3D4C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144ABB488, ????);
            // 0x00BC3D50: MOV x19, x0                | X19 = 1152921510053917832 (0x1000000144ABB488);//ML01
            // 0x00BC3D54: ADD x0, sp, #8             | X0 = (1152921510053917824 + 8) = 1152921510053917832 (0x1000000144ABB488);
            // 0x00BC3D58: B #0xbc3d44                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC3D5C (12336476), len: 420  VirtAddr: 0x00BC3D5C RVA: 0x00BC3D5C token: 100663824 methodIndex: 29869 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_heroAntiCheatData_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BC3D5C: STP x22, x21, [sp, #-0x30]! | stack[1152921510054041952] = ???;  stack[1152921510054041960] = ???;  //  dest_result_addr=1152921510054041952 |  dest_result_addr=1152921510054041960
            // 0x00BC3D60: STP x20, x19, [sp, #0x10]  | stack[1152921510054041968] = ???;  stack[1152921510054041976] = ???;  //  dest_result_addr=1152921510054041968 |  dest_result_addr=1152921510054041976
            // 0x00BC3D64: STP x29, x30, [sp, #0x20]  | stack[1152921510054041984] = ???;  stack[1152921510054041992] = ???;  //  dest_result_addr=1152921510054041984 |  dest_result_addr=1152921510054041992
            // 0x00BC3D68: ADD x29, sp, #0x20         | X29 = (1152921510054041952 + 32) = 1152921510054041984 (0x1000000144AD9980);
            // 0x00BC3D6C: SUB sp, sp, #0x20          | SP = (1152921510054041952 - 32) = 1152921510054041920 (0x1000000144AD9940);
            // 0x00BC3D70: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC3D74: LDRB w8, [x21, #0xb9a]     | W8 = (bool)static_value_03733B9A;       
            // 0x00BC3D78: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x00BC3D7C: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BC3D80: TBNZ w8, #0, #0xbc3d9c     | if (static_value_03733B9A == true) goto label_0;
            // 0x00BC3D84: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00BC3D88: LDR x8, [x8, #0x418]       | X8 = 0x2B8AF84;                         
            // 0x00BC3D8C: LDR w0, [x8]               | W0 = 0x29F;                             
            // 0x00BC3D90: BL #0x2782188              | X0 = sub_2782188( ?? 0x29F, ????);      
            // 0x00BC3D94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC3D98: STRB w8, [x21, #0xb9a]     | static_value_03733B9A = true;            //  dest_result_addr=57883546
            label_0:
            // 0x00BC3D9C: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x00BC3DA0: CBZ x20, #0xbc3e54         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BC3DA4: ADRP x21, #0x3678000       | X21 = 57114624 (0x3678000);             
            // 0x00BC3DA8: LDR x21, [x21, #0x328]     | X21 = 1152921504902479872;              
            val_7 = 1152921504902479872;
            // 0x00BC3DAC: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC3DB0: LDR x1, [x21]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3DB4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BC3DB8: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3DBC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3DC0: B.LO #0xbc3dd8             | if (mem[null + 260] < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BC3DC4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BC3DC8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3DCC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3DD0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3DD4: B.EQ #0xbc3e00             | if ((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BC3DD8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC3DDC: ADD x8, sp, #8             | X8 = (1152921510054041920 + 8) = 1152921510054041928 (0x1000000144AD9948);
            // 0x00BC3DE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BC3DE4: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510054030000]
            // 0x00BC3DE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BC3DEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3DF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BC3DF4: ADD x0, sp, #8             | X0 = (1152921510054041920 + 8) = 1152921510054041928 (0x1000000144AD9948);
            // 0x00BC3DF8: BL #0x299a140              | 
            // 0x00BC3DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144AD9948, ????);
            label_3:
            // 0x00BC3E00: LDR x8, [x20]              | X8 = ;                                  
            // 0x00BC3E04: LDR x1, [x21]              | X1 = typeof(AntiCheatMgr);              
            // 0x00BC3E08: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BC3E0C: LDRB w9, [x1, #0x104]      | W9 = AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3E10: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3E14: B.LO #0xbc3e2c             | if (mem[null + 260] < AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BC3E18: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BC3E1C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC3E20: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3E24: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AntiCheatMgr))
            // 0x00BC3E28: B.EQ #0xbc3e5c             | if ((mem[null + 176] + (AntiCheatMgr.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BC3E2C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC3E30: ADD x8, sp, #0x10          | X8 = (1152921510054041920 + 16) = 1152921510054041936 (0x1000000144AD9950);
            // 0x00BC3E34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BC3E38: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510054030000]
            // 0x00BC3E3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC3E40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3E44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC3E48: ADD x0, sp, #0x10          | X0 = (1152921510054041920 + 16) = 1152921510054041936 (0x1000000144AD9950);
            // 0x00BC3E4C: BL #0x299a140              | 
            // 0x00BC3E50: B #0xbc3e58                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BC3E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x29F, ????);      
            label_6:
            // 0x00BC3E58: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x00BC3E5C: CBZ x19, #0xbc3eb8         | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x00BC3E60: ADRP x9, #0x35dc000        | X9 = 56475648 (0x35DC000);              
            // 0x00BC3E64: LDR x9, [x9, #0xd90]       | X9 = 1152921504615792640;               
            // 0x00BC3E68: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BC3E6C: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            // 0x00BC3E70: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x00BC3E74: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC3E78: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC3E7C: B.LO #0xbc3e94             | if (X2 + 260 < System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00BC3E80: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x00BC3E84: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHiera
            // 0x00BC3E88: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC3E8C: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.Dictionary<TKey, TValue>))
            // 0x00BC3E90: B.EQ #0xbc3ebc             | if ((X2 + 176 + (System.Collections.Generic.Dictionary<TKey, TValue>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00BC3E94: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BC3E98: ADD x8, sp, #0x18          | X8 = (1152921510054041920 + 24) = 1152921510054041944 (0x1000000144AD9958);
            // 0x00BC3E9C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BC3EA0: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510054030000]
            // 0x00BC3EA4: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BC3EA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3EAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BC3EB0: ADD x0, sp, #0x18          | X0 = (1152921510054041920 + 24) = 1152921510054041944 (0x1000000144AD9958);
            // 0x00BC3EB4: BL #0x299a140              | 
            label_7:
            // 0x00BC3EB8: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x00BC3EBC: STR x19, [x20, #0x18]      | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_8;
            // 0x00BC3EC0: SUB sp, x29, #0x20         | SP = (1152921510054041984 - 32) = 1152921510054041952 (0x1000000144AD9960);
            // 0x00BC3EC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC3EC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC3ECC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC3ED0: RET                        |  return;                                
            return;
            // 0x00BC3ED4: MOV x19, x0                | 
            // 0x00BC3ED8: ADD x0, sp, #8             | 
            // 0x00BC3EDC: B #0xbc3ef4                | 
            // 0x00BC3EE0: MOV x19, x0                | 
            // 0x00BC3EE4: ADD x0, sp, #0x10          | 
            // 0x00BC3EE8: B #0xbc3ef4                | 
            // 0x00BC3EEC: MOV x19, x0                | 
            // 0x00BC3EF0: ADD x0, sp, #0x18          | 
            label_11:
            // 0x00BC3EF4: BL #0x299a140              | 
            // 0x00BC3EF8: MOV x0, x19                | 
            // 0x00BC3EFC: BL #0x980800               | 
        
        }
    
    }

}
