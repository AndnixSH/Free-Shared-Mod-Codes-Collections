using UnityEngine;
public enum UIGrid.Arrangement
{
    // Fields
    Horizontal = 0
    ,Vertical = 1
    ,CellSnap = 2
    

}
