using UnityEngine;
public class AssetDownMgr : IZUpdate
{
    // Fields
    private static AssetDownMgr _instance; // static_offset: 0x00000000
    private Filelist<FileInfoCrc> fileCrcList; //  0x00000010
    private System.Collections.Generic.Dictionary<string, string> updateCrcDic; //  0x00000018
    private System.Collections.Generic.Dictionary<string, FileInfoRes> updateDic; //  0x00000020
    private System.Collections.Generic.List<Mihua.Net.UrlLoader> wwwGroups; //  0x00000028
    private System.Collections.Generic.List<string> waitUrlGroups; //  0x00000030
    private System.Collections.Generic.List<string> writeFileData; //  0x00000038
    private int MAXDOWNFILE; //  0x00000040
    private int MAXUNZIPFILE; //  0x00000044
    private int MAXDOWNERROR; //  0x00000048
    private bool isStart; //  0x0000004C
    private uint totalBytes; //  0x00000050
    private uint curBytes; //  0x00000054
    private int totalFileCount; //  0x00000058
    private int curFileCount; //  0x0000005C
    private bool IsWriteFinish; //  0x00000060
    private System.Collections.Generic.Dictionary<int, AssetDownMgr.SetBytes> downFinishCallDic; //  0x00000068
    private System.Action writeDownFinishCall; //  0x00000070
    private System.Collections.Generic.Dictionary<int, System.Collections.Generic.List<FileInfoRes>> addDataDic; //  0x00000078
    private int addTotal; //  0x00000080
    private int adddownIndex; //  0x00000084
    public bool IsDownSuccess; //  0x00000088
    private uint loadingBytes; //  0x0000008C
    private uint loadedBytes; //  0x00000090
    private System.Collections.Generic.Dictionary<string, int> errorDownFiles; //  0x00000098
    private string errorUrl; //  0x000000A0
    private bool CanDownFile; //  0x000000A8
    
    // Properties
    public static AssetDownMgr Instance { get; }
    public static long GetMinutes { get; }
    public float Progress { get; }
    public string ProgressMsg { get; }
    public float WriteProgress { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B30030 (11730992), len: 408  VirtAddr: 0x00B30030 RVA: 0x00B30030 token: 100694310 methodIndex: 24921 delegateWrapperIndex: 0 methodInvoker: 0
    public AssetDownMgr()
    {
        //
        // Disasemble & Code
        // 0x00B30030: STP x22, x21, [sp, #-0x30]! | stack[1152921515151500800] = ???;  stack[1152921515151500808] = ???;  //  dest_result_addr=1152921515151500800 |  dest_result_addr=1152921515151500808
        // 0x00B30034: STP x20, x19, [sp, #0x10]  | stack[1152921515151500816] = ???;  stack[1152921515151500824] = ???;  //  dest_result_addr=1152921515151500816 |  dest_result_addr=1152921515151500824
        // 0x00B30038: STP x29, x30, [sp, #0x20]  | stack[1152921515151500832] = ???;  stack[1152921515151500840] = ???;  //  dest_result_addr=1152921515151500832 |  dest_result_addr=1152921515151500840
        // 0x00B3003C: ADD x29, sp, #0x20         | X29 = (1152921515151500800 + 32) = 1152921515151500832 (0x100000027482A620);
        // 0x00B30040: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B30044: LDRB w8, [x20, #0x78c]     | W8 = (bool)static_value_0373378C;       
        // 0x00B30048: MOV x19, x0                | X19 = 1152921515151512848 (0x100000027482D510);//ML01
        // 0x00B3004C: TBNZ w8, #0, #0xb30068     | if (static_value_0373378C == true) goto label_0;
        // 0x00B30050: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
        // 0x00B30054: LDR x8, [x8, #0xcb0]       | X8 = 0x2B8EAC0;                         
        // 0x00B30058: LDR w0, [x8]               | W0 = 0x1170;                            
        // 0x00B3005C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1170, ????);     
        // 0x00B30060: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B30064: STRB w8, [x20, #0x78c]     | static_value_0373378C = true;            //  dest_result_addr=57882508
        label_0:
        // 0x00B30068: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00B3006C: LDR x8, [x8, #0xf18]       | X8 = 1152921504615792640;               
        // 0x00B30070: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.String> val_1 = null;
        // 0x00B30074: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B30078: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B3007C: LDR x8, [x8, #0x9f8]       | X8 = 1152921509931587600;               
        // 0x00B30080: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B30084: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::.ctor();
        // 0x00B30088: BL #0x23fb0c4              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.String, System.String>();
        // 0x00B3008C: STR x20, [x19, #0x18]      | this.updateCrcDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515151512872
        this.updateCrcDic = val_1;
        // 0x00B30090: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B30094: LDR x8, [x8, #0x180]       | X8 = 1152921504615792640;               
        // 0x00B30098: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, FileInfoRes> val_2 = null;
        // 0x00B3009C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B300A0: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B300A4: LDR x8, [x8, #0xa0]        | X8 = 1152921514958642352;               
        // 0x00B300A8: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B300AC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::.ctor();
        // 0x00B300B0: BL #0x23fb0c4              | .ctor();                                
        val_2 = new System.Collections.Generic.Dictionary<System.String, FileInfoRes>();
        // 0x00B300B4: STR x20, [x19, #0x20]      | this.updateDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515151512880
        this.updateDic = val_2;
        // 0x00B300B8: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B300BC: LDR x8, [x8, #0x1a8]       | X8 = 1152921504616644608;               
        // 0x00B300C0: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<Mihua.Net.UrlLoader> val_3 = null;
        // 0x00B300C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B300C8: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B300CC: LDR x8, [x8, #0x7a8]       | X8 = 1152921514961034640;               
        // 0x00B300D0: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B300D4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Net.UrlLoader>::.ctor();
        // 0x00B300D8: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<Mihua.Net.UrlLoader>();
        // 0x00B300DC: STR x20, [x19, #0x28]      | this.wwwGroups = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515151512888
        this.wwwGroups = val_3;
        // 0x00B300E0: ADRP x21, #0x367b000       | X21 = 57126912 (0x367B000);             
        // 0x00B300E4: LDR x21, [x21, #0xe00]     | X21 = 1152921504616644608;              
        // 0x00B300E8: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.String> val_4 = null;
        // 0x00B300EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B300F0: ADRP x22, #0x35e9000       | X22 = 56528896 (0x35E9000);             
        // 0x00B300F4: LDR x22, [x22, #0xe88]     | X22 = 1152921510893072720;              
        // 0x00B300F8: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B300FC: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
        // 0x00B30100: BL #0x25e9474              | .ctor();                                
        val_4 = new System.Collections.Generic.List<System.String>();
        // 0x00B30104: STR x20, [x19, #0x30]      | this.waitUrlGroups = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515151512896
        this.waitUrlGroups = val_4;
        // 0x00B30108: LDR x0, [x21]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.String> val_5 = null;
        // 0x00B3010C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B30110: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
        // 0x00B30114: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B30118: BL #0x25e9474              | .ctor();                                
        val_5 = new System.Collections.Generic.List<System.String>();
        // 0x00B3011C: ORR x8, xzr, #0x400000004  | X8 = 17179869188(0x400000004);          
        // 0x00B30120: MOVK x8, #0x5, lsl #32     | X8 = 21474836484 (0x500000004);         
        // 0x00B30124: ORR w9, wzr, #4            | W9 = 4(0x4);                            
        // 0x00B30128: STP x20, x8, [x19, #0x38]  | this.writeFileData = typeof(System.Collections.Generic.List<T>);  this.MAXDOWNFILE = 4; this.MAXUNZIPFILE = 5;  //  dest_result_addr=1152921515151512904 |  dest_result_addr=1152921515151512912 dest_result_addr=1152921515151512916
        this.writeFileData = val_5;
        this.MAXDOWNFILE = 4;
        this.MAXUNZIPFILE = 5;
        // 0x00B3012C: STR w9, [x19, #0x48]       | this.MAXDOWNERROR = 4;                   //  dest_result_addr=1152921515151512920
        this.MAXDOWNERROR = 4;
        // 0x00B30130: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B30134: LDR x8, [x8, #0xd68]       | X8 = 1152921504615792640;               
        // 0x00B30138: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.Int32, SetBytes> val_6 = null;
        // 0x00B3013C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B30140: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B30144: LDR x8, [x8, #0x938]       | X8 = 1152921515151486800;               
        // 0x00B30148: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B3014C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, SetBytes>::.ctor();
        // 0x00B30150: BL #0x2413320              | .ctor();                                
        val_6 = new System.Collections.Generic.Dictionary<System.Int32, SetBytes>();
        // 0x00B30154: STR x20, [x19, #0x68]      | this.downFinishCallDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515151512952
        this.downFinishCallDic = val_6;
        // 0x00B30158: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x00B3015C: LDR x8, [x8, #0xe78]       | X8 = 1152921504615792640;               
        // 0x00B30160: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>> val_7 = null;
        // 0x00B30164: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B30168: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00B3016C: LDR x8, [x8, #0x440]       | X8 = 1152921515151487824;               
        // 0x00B30170: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B30174: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::.ctor();
        // 0x00B30178: BL #0x2413320              | .ctor();                                
        val_7 = new System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>();
        // 0x00B3017C: STR x20, [x19, #0x78]      | this.addDataDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515151512968
        this.addDataDic = val_7;
        // 0x00B30180: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00B30184: LDR x8, [x8, #0x610]       | X8 = 1152921504615792640;               
        // 0x00B30188: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.String, System.Int32> val_8 = null;
        // 0x00B3018C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B30190: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00B30194: LDR x8, [x8, #0x6d8]       | X8 = 1152921510000487872;               
        // 0x00B30198: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B3019C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::.ctor();
        // 0x00B301A0: BL #0x23f2edc              | .ctor();                                
        val_8 = new System.Collections.Generic.Dictionary<System.String, System.Int32>();
        // 0x00B301A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B301A8: STRB w8, [x19, #0xa8]      | this.CanDownFile = true;                 //  dest_result_addr=1152921515151513016
        this.CanDownFile = true;
        // 0x00B301AC: STR x20, [x19, #0x98]      | this.errorDownFiles = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515151513000
        this.errorDownFiles = val_8;
        // 0x00B301B0: MOV x0, x19                | X0 = 1152921515151512848 (0x100000027482D510);//ML01
        // 0x00B301B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B301B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B301BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B301C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B301C4: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14F80 (11620224), len: 124  VirtAddr: 0x00B14F80 RVA: 0x00B14F80 token: 100694311 methodIndex: 24922 delegateWrapperIndex: 0 methodInvoker: 0
    public static AssetDownMgr get_Instance()
    {
        //
        // Disasemble & Code
        //  | 
        AssetDownMgr val_2;
        //  | 
        AssetDownMgr val_3;
        // 0x00B14F80: STP x20, x19, [sp, #-0x20]! | stack[1152921515151612816] = ???;  stack[1152921515151612824] = ???;  //  dest_result_addr=1152921515151612816 |  dest_result_addr=1152921515151612824
        // 0x00B14F84: STP x29, x30, [sp, #0x10]  | stack[1152921515151612832] = ???;  stack[1152921515151612840] = ???;  //  dest_result_addr=1152921515151612832 |  dest_result_addr=1152921515151612840
        // 0x00B14F88: ADD x29, sp, #0x10         | X29 = (1152921515151612816 + 16) = 1152921515151612832 (0x1000000274845BA0);
        // 0x00B14F8C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B14F90: LDRB w8, [x19, #0x78d]     | W8 = (bool)static_value_0373378D;       
        // 0x00B14F94: TBNZ w8, #0, #0xb14fb0     | if (static_value_0373378D == true) goto label_0;
        // 0x00B14F98: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B14F9C: LDR x8, [x8, #0xe78]       | X8 = 0x2B8EAD8;                         
        // 0x00B14FA0: LDR w0, [x8]               | W0 = 0x1176;                            
        // 0x00B14FA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1176, ????);     
        // 0x00B14FA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B14FAC: STRB w8, [x19, #0x78d]     | static_value_0373378D = true;            //  dest_result_addr=57882509
        label_0:
        // 0x00B14FB0: ADRP x20, #0x35e2000       | X20 = 56500224 (0x35E2000);             
        // 0x00B14FB4: LDR x20, [x20, #0xe98]     | X20 = 1152921504910733312;              
        // 0x00B14FB8: LDR x0, [x20]              | X0 = typeof(AssetDownMgr);              
        AssetDownMgr val_1 = null;
        // 0x00B14FBC: LDR x8, [x0, #0xa0]        | X8 = AssetDownMgr.__il2cppRuntimeField_static_fields;
        // 0x00B14FC0: LDR x8, [x8]               | X8 = AssetDownMgr._instance;            
        val_3 = AssetDownMgr._instance;
        // 0x00B14FC4: CBNZ x8, #0xb14fec         | if (AssetDownMgr._instance != null) goto label_1;
        if(val_3 != null)
        {
            goto label_1;
        }
        // 0x00B14FC8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AssetDownMgr), ????);
        // 0x00B14FCC: MOV x19, x0                | X19 = 1152921504910733312 (0x10000000121CF000);//ML01
        val_2 = val_1;
        // 0x00B14FD0: BL #0xb30030               | .ctor();                                
        val_1 = new AssetDownMgr();
        // 0x00B14FD4: LDR x8, [x20]              | X8 = typeof(AssetDownMgr);              
        // 0x00B14FD8: LDR x8, [x8, #0xa0]        | X8 = AssetDownMgr.__il2cppRuntimeField_static_fields;
        // 0x00B14FDC: STR x19, [x8]              | AssetDownMgr._instance = typeof(AssetDownMgr);  //  dest_result_addr=1152921504910737408
        AssetDownMgr._instance = val_2;
        // 0x00B14FE0: LDR x8, [x20]              | X8 = typeof(AssetDownMgr);              
        // 0x00B14FE4: LDR x8, [x8, #0xa0]        | X8 = AssetDownMgr.__il2cppRuntimeField_static_fields;
        // 0x00B14FE8: LDR x8, [x8]               | X8 = typeof(AssetDownMgr);              
        val_3 = AssetDownMgr._instance;
        label_1:
        // 0x00B14FEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B14FF0: MOV x0, x8                 | X0 = 1152921504910733312 (0x10000000121CF000);//ML01
        // 0x00B14FF4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B14FF8: RET                        |  return (AssetDownMgr)typeof(AssetDownMgr);
        return (AssetDownMgr)val_3;
        //  |  // // {name=val_0, type=AssetDownMgr, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B301C8 (11731400), len: 160  VirtAddr: 0x00B301C8 RVA: 0x00B301C8 token: 100694312 methodIndex: 24923 delegateWrapperIndex: 0 methodInvoker: 0
    public static long get_GetMinutes()
    {
        //
        // Disasemble & Code
        // 0x00B301C8: STP x20, x19, [sp, #-0x20]! | stack[1152921515151724816] = ???;  stack[1152921515151724824] = ???;  //  dest_result_addr=1152921515151724816 |  dest_result_addr=1152921515151724824
        // 0x00B301CC: STP x29, x30, [sp, #0x10]  | stack[1152921515151724832] = ???;  stack[1152921515151724840] = ???;  //  dest_result_addr=1152921515151724832 |  dest_result_addr=1152921515151724840
        // 0x00B301D0: ADD x29, sp, #0x10         | X29 = (1152921515151724816 + 16) = 1152921515151724832 (0x1000000274861120);
        // 0x00B301D4: SUB sp, sp, #0x10          | SP = (1152921515151724816 - 16) = 1152921515151724800 (0x1000000274861100);
        // 0x00B301D8: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B301DC: LDRB w8, [x19, #0x78e]     | W8 = (bool)static_value_0373378E;       
        // 0x00B301E0: TBNZ w8, #0, #0xb301fc     | if (static_value_0373378E == true) goto label_0;
        // 0x00B301E4: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00B301E8: LDR x8, [x8, #0xa80]       | X8 = 0x2B8EAD4;                         
        // 0x00B301EC: LDR w0, [x8]               | W0 = 0x1175;                            
        // 0x00B301F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1175, ????);     
        // 0x00B301F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B301F8: STRB w8, [x19, #0x78e]     | static_value_0373378E = true;            //  dest_result_addr=57882510
        label_0:
        // 0x00B301FC: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B30200: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00B30204: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
        // 0x00B30208: STP xzr, xzr, [sp]         | stack[1152921515151724800] = 0x0;  stack[1152921515151724808] = 0x0;  //  dest_result_addr=1152921515151724800 |  dest_result_addr=1152921515151724808
        // 0x00B3020C: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
        // 0x00B30210: TBZ w8, #0, #0xb30220      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B30214: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
        // 0x00B30218: CBNZ w8, #0xb30220         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B3021C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
        label_2:
        // 0x00B30220: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30228: BL #0x1bacd34              | X0 = System.DateTime.get_Now();         
        System.DateTime val_1 = System.DateTime.Now;
        // 0x00B3022C: STP x0, x1, [sp]           | stack[1152921515151724800] = val_1.ticks._ticks;  stack[1152921515151724808] = val_1.kind;  //  dest_result_addr=1152921515151724800 |  dest_result_addr=1152921515151724808
        // 0x00B30230: MOV x0, sp                 | X0 = 1152921515151724800 (0x1000000274861100);//ML01
        // 0x00B30234: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30238: BL #0x1bacf30              | X0 = val_1.ticks._ticks.get_Ticks();    
        long val_2 = val_1.ticks._ticks.Ticks;
        // 0x00B3023C: MOVZ x8, #0x1ca2, lsl #48  | X8 = 2063211579289108480 (0x1CA2000000000000);//ML01
        // 0x00B30240: MOVK x8, #0x13d8, lsl #32  | X8 = 2063233397722972160 (0x1CA213D800000000);
        // 0x00B30244: MOVK x8, #0x40ba, lsl #16  | X8 = 2063233398808903680 (0x1CA213D840BA0000);
        // 0x00B30248: MOVK x8, #0xf7d5           | X8 = 2063233398808967125 (0x1CA213D840BAF7D5);
        // 0x00B3024C: SMULH x8, x0, x8           | 
        // 0x00B30250: ASR x9, x8, #0x1a          | X9 = (2063233398808967125 >> 26) = 0 (0x00000000);
        // 0x00B30254: ADD x0, x9, x8, lsr #63    | X0 = (0 + 0) = 30744573456 (0x72884F610);
        // 0x00B30258: SUB sp, x29, #0x10         | SP = (1152921515151724832 - 16) = 1152921515151724816 (0x1000000274861110);
        // 0x00B3025C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B30260: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B30264: RET                        |  return (System.Int64)679802384;        
        return (long)30744573456;
        //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19BF4 (11639796), len: 44  VirtAddr: 0x00B19BF4 RVA: 0x00B19BF4 token: 100694313 methodIndex: 24924 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_Progress()
    {
        //
        // Disasemble & Code
        // 0x00B19BF4: LDR x8, [x0, #0x50]        | X8 = this.totalBytes; //P2              
        // 0x00B19BF8: CBZ w8, #0xb19c18          | if (this.totalBytes == 0) goto label_0; 
        if(this.totalBytes == 0)
        {
            goto label_0;
        }
        // 0x00B19BFC: LSR x9, x8, #0x20          | X9 = (this.totalBytes >> 32);           
        uint val_1 = this.totalBytes >> 32;
        // 0x00B19C00: UCVTF d0, w8               | D0 = (double)(this.totalBytes);         
        // 0x00B19C04: UCVTF d1, w9               | D1 = (double)((this.totalBytes >> 32)); 
        // 0x00B19C08: FCVT s1, d1                | S1 = (float)(this.totalBytes >> 32));   
        // 0x00B19C0C: FCVT s0, d0                | S0 = (float)this.totalBytes);           
        float val_2 = (float)(double)this.totalBytes;
        // 0x00B19C10: FDIV s0, s1, s0            | S0 = ((this.totalBytes >> 32) / this.totalBytes);
        val_2 = (float)(double)val_1 / val_2;
        // 0x00B19C14: RET                        |  return (System.Single)((this.totalBytes >> 32) / this.totalBytes);
        return (float)val_2;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        label_0:
        // 0x00B19C18: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B19C1C: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19C4C (11639884), len: 216  VirtAddr: 0x00B19C4C RVA: 0x00B19C4C token: 100694314 methodIndex: 24925 delegateWrapperIndex: 0 methodInvoker: 0
    public string get_ProgressMsg()
    {
        //
        // Disasemble & Code
        // 0x00B19C4C: STP x20, x19, [sp, #-0x20]! | stack[1152921515151957008] = ???;  stack[1152921515151957016] = ???;  //  dest_result_addr=1152921515151957008 |  dest_result_addr=1152921515151957016
        // 0x00B19C50: STP x29, x30, [sp, #0x10]  | stack[1152921515151957024] = ???;  stack[1152921515151957032] = ???;  //  dest_result_addr=1152921515151957024 |  dest_result_addr=1152921515151957032
        // 0x00B19C54: ADD x29, sp, #0x10         | X29 = (1152921515151957008 + 16) = 1152921515151957024 (0x1000000274899C20);
        // 0x00B19C58: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B19C5C: LDRB w8, [x20, #0x78f]     | W8 = (bool)static_value_0373378F;       
        // 0x00B19C60: MOV x19, x0                | X19 = 1152921515151969040 (0x100000027489CB10);//ML01
        // 0x00B19C64: TBNZ w8, #0, #0xb19c80     | if (static_value_0373378F == true) goto label_0;
        // 0x00B19C68: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x00B19C6C: LDR x8, [x8, #0xee0]       | X8 = 0x2B8EADC;                         
        // 0x00B19C70: LDR w0, [x8]               | W0 = 0x1177;                            
        // 0x00B19C74: BL #0x2782188              | X0 = sub_2782188( ?? 0x1177, ????);     
        // 0x00B19C78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B19C7C: STRB w8, [x20, #0x78f]     | static_value_0373378F = true;            //  dest_result_addr=57882511
        label_0:
        // 0x00B19C80: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B19C84: LDR x8, [x8, #0xa90]       | X8 = 1152921504911745024;               
        // 0x00B19C88: LDR w20, [x19, #0x54]      | W20 = this.curBytes; //P2               
        // 0x00B19C8C: LDR x0, [x8]               | X0 = typeof(Util);                      
        // 0x00B19C90: LDRB w8, [x0, #0x10a]      | W8 = Util.__il2cppRuntimeField_10A;     
        // 0x00B19C94: TBZ w8, #0, #0xb19ca4      | if (Util.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B19C98: LDR w8, [x0, #0xbc]        | W8 = Util.__il2cppRuntimeField_cctor_finished;
        // 0x00B19C9C: CBNZ w8, #0xb19ca4         | if (Util.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B19CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Util), ????);
        label_2:
        // 0x00B19CA4: UCVTF d0, w20              | D0 = (double)(this.curBytes);           
        // 0x00B19CA8: FCVT s0, d0                | S0 = (float)this.curBytes);             
        // 0x00B19CAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19CB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19CB4: BL #0xe17448               | X0 = Util.FormatIntToString_KB(num:  (float)(double)this.curBytes);
        string val_1 = Util.FormatIntToString_KB(num:  (float)(double)this.curBytes);
        // 0x00B19CB8: LDR w8, [x19, #0x50]       | W8 = this.totalBytes; //P2              
        // 0x00B19CBC: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B19CC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19CC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B19CC8: UCVTF d0, w8               | D0 = (double)(this.totalBytes);         
        // 0x00B19CCC: FCVT s0, d0                | S0 = (float)this.totalBytes);           
        // 0x00B19CD0: BL #0xe17448               | X0 = Util.FormatIntToString_KB(num:  (float)(double)this.totalBytes);
        string val_2 = Util.FormatIntToString_KB(num:  (float)(double)this.totalBytes);
        // 0x00B19CD4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B19CD8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B19CDC: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B19CE0: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B19CE4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B19CE8: TBZ w9, #0, #0xb19cfc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B19CEC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B19CF0: CBNZ w9, #0xb19cfc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B19CF4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B19CF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x00B19CFC: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B19D00: LDR x8, [x8, #0x458]       | X8 = (string**)(1152921509471652944)("/");
        // 0x00B19D04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19D08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B19D0C: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B19D10: LDR x2, [x8]               | X2 = "/";                               
        // 0x00B19D14: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19D18: MOV x3, x20                | X3 = val_2;//m1                         
        // 0x00B19D1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B19D20: B #0x18a311c               | return System.String.Concat(str0:  0, str1:  val_1, str2:  "/");
        return System.String.Concat(str0:  0, str1:  val_1, str2:  "/");
    
    }
    //
    // Offset in libil2cpp.so: 0x00B19B48 (11639624), len: 36  VirtAddr: 0x00B19B48 RVA: 0x00B19B48 token: 100694315 methodIndex: 24926 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_WriteProgress()
    {
        //
        // Disasemble & Code
        // 0x00B19B48: LDR x8, [x0, #0x58]        | X8 = this.totalFileCount; //P2          
        // 0x00B19B4C: CBZ w8, #0xb19b64          | if (this.totalFileCount == 0) goto label_0;
        if(this.totalFileCount == 0)
        {
            goto label_0;
        }
        // 0x00B19B50: LSR x9, x8, #0x20          | X9 = (this.totalFileCount >> 32);       
        int val_1 = this.totalFileCount >> 32;
        // 0x00B19B54: SCVTF s0, w9               | S0 = (float)((this.totalFileCount >> 32));
        float val_2 = (float)val_1;
        // 0x00B19B58: SCVTF s1, w8               | S1 = (float)(this.totalFileCount);      
        // 0x00B19B5C: FDIV s0, s0, s1            | S0 = ((this.totalFileCount >> 32) / this.totalFileCount);
        val_2 = val_2 / (float)this.totalFileCount;
        // 0x00B19B60: RET                        |  return (System.Single)((this.totalFileCount >> 32) / this.totalFileCount);
        return (float)val_2;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        label_0:
        // 0x00B19B64: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B19B68: RET                        |  return (System.Single)0;               
        return (float)0f;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B14FFC (11620348), len: 24  VirtAddr: 0x00B14FFC RVA: 0x00B14FFC token: 100694316 methodIndex: 24927 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        // 0x00B14FFC: STR wzr, [x0, #0x50]       | this.totalBytes = null;                  //  dest_result_addr=1152921515152201312
        this.totalBytes = 0;
        // 0x00B15000: STRB wzr, [x0, #0x4c]      | this.isStart = false;                    //  dest_result_addr=1152921515152201308
        this.isStart = false;
        // 0x00B15004: STP wzr, wzr, [x0, #0x58]  | this.totalFileCount = 0;  this.curFileCount = 0;  //  dest_result_addr=1152921515152201320 |  dest_result_addr=1152921515152201324
        this.totalFileCount = 0;
        this.curFileCount = 0;
        // 0x00B15008: STRB wzr, [x0, #0x88]      | this.IsDownSuccess = false;              //  dest_result_addr=1152921515152201368
        this.IsDownSuccess = false;
        // 0x00B1500C: STRB wzr, [x0, #0x60]      | this.IsWriteFinish = false;              //  dest_result_addr=1152921515152201328
        this.IsWriteFinish = false;
        // 0x00B15010: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B18C70 (11635824), len: 1228  VirtAddr: 0x00B18C70 RVA: 0x00B18C70 token: 100694317 methodIndex: 24928 delegateWrapperIndex: 0 methodInvoker: 0
    public void AddUpdateData(System.Collections.Generic.List<FileInfoRes> updateList, AssetDownMgr.SetBytes downFinishCall, System.Action writeDownFinishCall)
    {
        //
        // Disasemble & Code
        //  | 
        System.Action val_23;
        //  | 
        SetBytes val_24;
        //  | 
        var val_25;
        //  | 
        var val_26;
        //  | 
        string val_27;
        //  | 
        var val_28;
        // 0x00B18C70: STP x28, x27, [sp, #-0x60]! | stack[1152921515152438352] = ???;  stack[1152921515152438360] = ???;  //  dest_result_addr=1152921515152438352 |  dest_result_addr=1152921515152438360
        // 0x00B18C74: STP x26, x25, [sp, #0x10]  | stack[1152921515152438368] = ???;  stack[1152921515152438376] = ???;  //  dest_result_addr=1152921515152438368 |  dest_result_addr=1152921515152438376
        // 0x00B18C78: STP x24, x23, [sp, #0x20]  | stack[1152921515152438384] = ???;  stack[1152921515152438392] = ???;  //  dest_result_addr=1152921515152438384 |  dest_result_addr=1152921515152438392
        // 0x00B18C7C: STP x22, x21, [sp, #0x30]  | stack[1152921515152438400] = ???;  stack[1152921515152438408] = ???;  //  dest_result_addr=1152921515152438400 |  dest_result_addr=1152921515152438408
        // 0x00B18C80: STP x20, x19, [sp, #0x40]  | stack[1152921515152438416] = ???;  stack[1152921515152438424] = ???;  //  dest_result_addr=1152921515152438416 |  dest_result_addr=1152921515152438424
        // 0x00B18C84: STP x29, x30, [sp, #0x50]  | stack[1152921515152438432] = ???;  stack[1152921515152438440] = ???;  //  dest_result_addr=1152921515152438432 |  dest_result_addr=1152921515152438440
        // 0x00B18C88: ADD x29, sp, #0x50         | X29 = (1152921515152438352 + 80) = 1152921515152438432 (0x100000027490F4A0);
        // 0x00B18C8C: SUB sp, sp, #0x10          | SP = (1152921515152438352 - 16) = 1152921515152438336 (0x100000027490F440);
        // 0x00B18C90: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B18C94: LDRB w8, [x20, #0x790]     | W8 = (bool)static_value_03733790;       
        // 0x00B18C98: MOV x21, x3                | X21 = writeDownFinishCall;//m1          
        val_23 = writeDownFinishCall;
        // 0x00B18C9C: MOV x23, x2                | X23 = downFinishCall;//m1               
        val_24 = downFinishCall;
        // 0x00B18CA0: MOV x22, x1                | X22 = updateList;//m1                   
        // 0x00B18CA4: MOV x19, x0                | X19 = 1152921515152450448 (0x1000000274912390);//ML01
        // 0x00B18CA8: TBNZ w8, #0, #0xb18cc4     | if (static_value_03733790 == true) goto label_0;
        // 0x00B18CAC: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00B18CB0: LDR x8, [x8, #0x590]       | X8 = 0x2B8EAC4;                         
        // 0x00B18CB4: LDR w0, [x8]               | W0 = 0x1171;                            
        // 0x00B18CB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1171, ????);     
        // 0x00B18CBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B18CC0: STRB w8, [x20, #0x790]     | static_value_03733790 = true;            //  dest_result_addr=57882512
        label_0:
        // 0x00B18CC4: CBZ x22, #0xb190f8         | if (updateList == null) goto label_1;   
        if(updateList == null)
        {
            goto label_1;
        }
        // 0x00B18CC8: STP x23, x21, [sp]         | stack[1152921515152438336] = downFinishCall;  stack[1152921515152438344] = writeDownFinishCall;  //  dest_result_addr=1152921515152438336 |  dest_result_addr=1152921515152438344
        // 0x00B18CCC: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
        // 0x00B18CD0: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
        val_25 = 1152921504608284672;
        // 0x00B18CD4: LDR x0, [x27]              | X0 = typeof(System.String);             
        // 0x00B18CD8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18CDC: TBZ w8, #0, #0xb18cec      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B18CE0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18CE4: CBNZ w8, #0xb18cec         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B18CE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_3:
        // 0x00B18CEC: ADRP x20, #0x35c6000       | X20 = 56385536 (0x35C6000);             
        // 0x00B18CF0: LDR w21, [x19, #0x58]      | W21 = this.totalFileCount; //P2         
        // 0x00B18CF4: LDR x20, [x20, #0x5d8]     | X20 = 1152921514959024432;              
        val_26 = 1152921514959024432;
        // 0x00B18CF8: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18CFC: LDR x1, [x20]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B18D00: BL #0x25ed72c              | X0 = updateList.get_Count();            
        int val_1 = updateList.Count;
        // 0x00B18D04: ADD w8, w0, w21            | W8 = (val_1 + this.totalFileCount);     
        int val_2 = val_1 + this.totalFileCount;
        // 0x00B18D08: STR w8, [x19, #0x58]       | this.totalFileCount = (val_1 + this.totalFileCount);  //  dest_result_addr=1152921515152450536
        this.totalFileCount = val_2;
        // 0x00B18D0C: LDR x1, [x20]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B18D10: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18D14: BL #0x25ed72c              | X0 = updateList.get_Count();            
        int val_3 = updateList.Count;
        // 0x00B18D18: CMP w0, #1                 | STATE = COMPARE(val_3, 0x1)             
        // 0x00B18D1C: B.LT #0xb18f80             | if (val_3 < 1) goto label_4;            
        if(val_3 < 1)
        {
            goto label_4;
        }
        // 0x00B18D20: ADRP x21, #0x35cc000       | X21 = 56410112 (0x35CC000);             
        // 0x00B18D24: ADRP x28, #0x3621000       | X28 = 56758272 (0x3621000);             
        // 0x00B18D28: LDR x21, [x21, #0x7d8]     | X21 = 1152921514959025456;              
        // 0x00B18D2C: LDR x28, [x28, #0x348]     | X28 = (string**)(1152921514964332640)("http:");
        // 0x00B18D30: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        var val_24 = 0;
        label_23:
        // 0x00B18D34: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18D38: LDR w25, [x19, #0x50]      | W25 = this.totalBytes; //P2             
        // 0x00B18D3C: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18D40: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18D44: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_4 = updateList.Item[0];
        // 0x00B18D48: MOV x24, x0                | X24 = val_4;//m1                        
        // 0x00B18D4C: CBNZ x24, #0xb18d54        | if (val_4 != null) goto label_5;        
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x00B18D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x00B18D54: LDR w8, [x24, #0x28]       | W8 = val_4.mSize; //P2                  
        uint val_23 = val_4.mSize;
        // 0x00B18D58: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18D5C: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18D60: ADD w8, w8, w25            | W8 = (val_4.mSize + this.totalBytes);   
        val_23 = val_23 + this.totalBytes;
        // 0x00B18D64: STR w8, [x19, #0x50]       | this.totalBytes = (val_4.mSize + this.totalBytes);  //  dest_result_addr=1152921515152450528
        this.totalBytes = val_23;
        // 0x00B18D68: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18D6C: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_5 = updateList.Item[0];
        // 0x00B18D70: MOV x24, x0                | X24 = val_5;//m1                        
        // 0x00B18D74: CBNZ x24, #0xb18d7c        | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x00B18D78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00B18D7C: LDR x24, [x24, #0x20]      | X24 = val_5.mPath; //P2                 
        val_27 = val_5.mPath;
        // 0x00B18D80: CBNZ x24, #0xb18d88        | if (val_5.mPath != null) goto label_7;  
        if(val_27 != null)
        {
            goto label_7;
        }
        // 0x00B18D84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00B18D88: LDR x1, [x28]              | X1 = "http:";                           
        // 0x00B18D8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18D90: MOV x0, x24                | X0 = val_5.mPath;//m1                   
        // 0x00B18D94: BL #0x18add38              | X0 = val_5.mPath.StartsWith(value:  "http:");
        bool val_6 = val_27.StartsWith(value:  "http:");
        // 0x00B18D98: AND w8, w0, #1             | W8 = (val_6 & 1);                       
        bool val_7 = val_6;
        // 0x00B18D9C: TBNZ w8, #0, #0xb18dc4     | if ((val_6 & 1) == true) goto label_8;  
        if(val_7 == true)
        {
            goto label_8;
        }
        // 0x00B18DA0: CBNZ x24, #0xb18da8        | if (val_5.mPath != null) goto label_9;  
        if(val_27 != null)
        {
            goto label_9;
        }
        // 0x00B18DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_9:
        // 0x00B18DA8: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x00B18DAC: LDR x8, [x8, #0xc78]       | X8 = (string**)(1152921514964332720)("https:");
        // 0x00B18DB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B18DB4: MOV x0, x24                | X0 = val_5.mPath;//m1                   
        // 0x00B18DB8: LDR x1, [x8]               | X1 = "https:";                          
        // 0x00B18DBC: BL #0x18add38              | X0 = val_5.mPath.StartsWith(value:  "https:");
        bool val_8 = val_27.StartsWith(value:  "https:");
        // 0x00B18DC0: TBZ w0, #0, #0xb18e20      | if (val_8 == false) goto label_10;      
        if(val_8 == false)
        {
            goto label_10;
        }
        label_8:
        // 0x00B18DC4: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18DC8: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18DCC: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18DD0: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_9 = updateList.Item[0];
        // 0x00B18DD4: MOV x25, x0                | X25 = val_9;//m1                        
        // 0x00B18DD8: CBNZ x25, #0xb18de0        | if (val_9 != null) goto label_11;       
        if(val_9 != null)
        {
            goto label_11;
        }
        // 0x00B18DDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_11:
        // 0x00B18DE0: LDR x0, [x27]              | X0 = typeof(System.String);             
        // 0x00B18DE4: LDR x25, [x25, #0x18]      | X25 = val_9.mDataMD5; //P2              
        // 0x00B18DE8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18DEC: TBZ w8, #0, #0xb18dfc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B18DF0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18DF4: CBNZ w8, #0xb18dfc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B18DF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_13:
        // 0x00B18DFC: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x00B18E00: LDR x8, [x8, #0x8a8]       | X8 = (string**)(1152921513099568080)("?");
        // 0x00B18E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18E08: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B18E0C: MOV x1, x24                | X1 = val_5.mPath;//m1                   
        // 0x00B18E10: LDR x2, [x8]               | X2 = "?";                               
        // 0x00B18E14: MOV x3, x25                | X3 = val_9.mDataMD5;//m1                
        // 0x00B18E18: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  val_27, str2:  "?");
        string val_10 = System.String.Concat(str0:  0, str1:  val_27, str2:  "?");
        // 0x00B18E1C: MOV x24, x0                | X24 = val_10;//m1                       
        val_27 = val_10;
        label_10:
        // 0x00B18E20: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18E24: LDR x25, [x19, #0x20]      | X25 = this.updateDic; //P2              
        // 0x00B18E28: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18E2C: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18E30: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_11 = updateList.Item[0];
        // 0x00B18E34: MOV x26, x0                | X26 = val_11;//m1                       
        // 0x00B18E38: CBNZ x25, #0xb18e40        | if (this.updateDic != null) goto label_14;
        if(this.updateDic != null)
        {
            goto label_14;
        }
        // 0x00B18E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_14:
        // 0x00B18E40: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00B18E44: LDR x8, [x8, #0xd20]       | X8 = 1152921514959026480;               
        // 0x00B18E48: MOV x0, x25                | X0 = this.updateDic;//m1                
        // 0x00B18E4C: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x00B18E50: MOV x2, x26                | X2 = val_11;//m1                        
        // 0x00B18E54: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Add(System.String key, FileInfoRes value);
        // 0x00B18E58: BL #0x23fd44c              | this.updateDic.Add(key:  val_27, value:  val_11);
        this.updateDic.Add(key:  val_27, value:  val_11);
        // 0x00B18E5C: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18E60: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18E64: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18E68: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_12 = updateList.Item[0];
        // 0x00B18E6C: MOV x25, x0                | X25 = val_12;//m1                       
        // 0x00B18E70: CBNZ x25, #0xb18e78        | if (val_12 != null) goto label_15;      
        if(val_12 != null)
        {
            goto label_15;
        }
        // 0x00B18E74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_15:
        // 0x00B18E78: LDRB w8, [x25, #0x34]      | W8 = val_12.isWrite; //P2               
        // 0x00B18E7C: CBNZ w8, #0xb18f44         | if (val_12.isWrite == true) goto label_16;
        if(val_12.isWrite == true)
        {
            goto label_16;
        }
        // 0x00B18E80: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18E84: LDR x25, [x19, #0x18]      | X25 = this.updateCrcDic; //P2           
        // 0x00B18E88: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18E8C: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18E90: MOV x28, x20               | X28 = 58057672 (0x375E3C8);//ML01       
        // 0x00B18E94: MOV x20, x27               | X20 = 57977240 (0x374A998);//ML01       
        // 0x00B18E98: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_13 = updateList.Item[0];
        // 0x00B18E9C: MOV x26, x0                | X26 = val_13;//m1                       
        // 0x00B18EA0: CBNZ x26, #0xb18ea8        | if (val_13 != null) goto label_17;      
        if(val_13 != null)
        {
            goto label_17;
        }
        // 0x00B18EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_17:
        // 0x00B18EA8: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18EAC: LDR x26, [x26, #0x10]      | 
        // 0x00B18EB0: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18EB4: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18EB8: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_14 = updateList.Item[0];
        // 0x00B18EBC: MOV x27, x0                | X27 = val_14;//m1                       
        // 0x00B18EC0: CBNZ x27, #0xb18ec8        | if (val_14 != null) goto label_18;      
        if(val_14 != null)
        {
            goto label_18;
        }
        // 0x00B18EC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_18:
        // 0x00B18EC8: LDR x27, [x27, #0x18]      | X27 = val_14.mDataMD5; //P2             
        // 0x00B18ECC: CBNZ x25, #0xb18ed4        | if (this.updateCrcDic != null) goto label_19;
        if(this.updateCrcDic != null)
        {
            goto label_19;
        }
        // 0x00B18ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_19:
        // 0x00B18ED4: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x00B18ED8: LDR x8, [x8, #0x310]       | X8 = 1152921509931601104;               
        // 0x00B18EDC: MOV x0, x25                | X0 = this.updateCrcDic;//m1             
        // 0x00B18EE0: MOV x1, x26                | X1 = val_13;//m1                        
        // 0x00B18EE4: MOV x2, x27                | X2 = val_14.mDataMD5;//m1               
        // 0x00B18EE8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Add(System.String key, System.String value);
        // 0x00B18EEC: BL #0x23fd44c              | this.updateCrcDic.Add(key:  val_13, value:  val_14.mDataMD5);
        this.updateCrcDic.Add(key:  val_13, value:  val_14.mDataMD5);
        // 0x00B18EF0: LDR x2, [x21]              | X2 = public FileInfoRes System.Collections.Generic.List<FileInfoRes>::get_Item(int index);
        // 0x00B18EF4: LDR x25, [x19, #0x38]      | X25 = this.writeFileData; //P2          
        // 0x00B18EF8: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18EFC: MOV w1, w23                | W1 = 0 (0x0);//ML01                     
        // 0x00B18F00: BL #0x25ed734              | X0 = updateList.get_Item(index:  0);    
        FileInfoRes val_15 = updateList.Item[0];
        // 0x00B18F04: MOV x26, x0                | X26 = val_15;//m1                       
        // 0x00B18F08: CBNZ x26, #0xb18f10        | if (val_15 != null) goto label_20;      
        if(val_15 != null)
        {
            goto label_20;
        }
        // 0x00B18F0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_20:
        // 0x00B18F10: LDR x26, [x26, #0x10]      | 
        // 0x00B18F14: MOV x27, x20               | X27 = 57977240 (0x374A998);//ML01       
        val_25 = val_25;
        // 0x00B18F18: CBNZ x25, #0xb18f20        | if (this.writeFileData != null) goto label_21;
        if(this.writeFileData != null)
        {
            goto label_21;
        }
        // 0x00B18F1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_21:
        // 0x00B18F20: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B18F24: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
        // 0x00B18F28: MOV x0, x25                | X0 = this.writeFileData;//m1            
        // 0x00B18F2C: MOV x1, x26                | X1 = val_15;//m1                        
        // 0x00B18F30: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B18F34: BL #0x25ea480              | this.writeFileData.Add(item:  val_15);  
        this.writeFileData.Add(item:  val_15);
        // 0x00B18F38: MOV x20, x28               | X20 = 58057672 (0x375E3C8);//ML01       
        val_26 = val_26;
        // 0x00B18F3C: ADRP x28, #0x3621000       | X28 = 56758272 (0x3621000);             
        // 0x00B18F40: LDR x28, [x28, #0x348]     | X28 = (string**)(1152921514964332640)("http:");
        label_16:
        // 0x00B18F44: LDR x25, [x19, #0x30]      | X25 = this.waitUrlGroups; //P2          
        // 0x00B18F48: CBNZ x25, #0xb18f50        | if (this.waitUrlGroups != null) goto label_22;
        if(this.waitUrlGroups != null)
        {
            goto label_22;
        }
        // 0x00B18F4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.writeFileData, ????);
        label_22:
        // 0x00B18F50: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B18F54: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
        // 0x00B18F58: MOV x0, x25                | X0 = this.waitUrlGroups;//m1            
        // 0x00B18F5C: MOV x1, x24                | X1 = val_10;//m1                        
        // 0x00B18F60: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B18F64: BL #0x25ea480              | this.waitUrlGroups.Add(item:  val_27);  
        this.waitUrlGroups.Add(item:  val_27);
        // 0x00B18F68: LDR x1, [x20]              | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B18F6C: MOV x0, x22                | X0 = updateList;//m1                    
        // 0x00B18F70: ADD w23, w23, #1           | W23 = (0 + 1);                          
        val_24 = val_24 + 1;
        // 0x00B18F74: BL #0x25ed72c              | X0 = updateList.get_Count();            
        int val_16 = updateList.Count;
        // 0x00B18F78: CMP w23, w0                | STATE = COMPARE((0 + 1), val_16)        
        // 0x00B18F7C: B.LT #0xb18d34             | if (0 < val_16) goto label_23;          
        if(val_24 < val_16)
        {
            goto label_23;
        }
        label_4:
        // 0x00B18F80: LDR x23, [x19, #0x38]      | X23 = this.writeFileData; //P2          
        // 0x00B18F84: LDR x21, [sp, #8]          | X21 = writeDownFinishCall;              
        val_23 = val_23;
        // 0x00B18F88: CBNZ x23, #0xb18f90        | if (this.writeFileData != null) goto label_24;
        if(this.writeFileData != null)
        {
            goto label_24;
        }
        // 0x00B18F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_24:
        // 0x00B18F90: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B18F94: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
        // 0x00B18F98: MOV x0, x23                | X0 = this.writeFileData;//m1            
        // 0x00B18F9C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B18FA0: BL #0x25ed72c              | X0 = this.writeFileData.get_Count();    
        int val_17 = this.writeFileData.Count;
        // 0x00B18FA4: CMP w0, #1                 | STATE = COMPARE(val_17, 0x1)            
        // 0x00B18FA8: B.LT #0xb1907c             | if (val_17 < 1) goto label_31;          
        if(val_17 < 1)
        {
            goto label_31;
        }
        // 0x00B18FAC: ADRP x20, #0x35ef000       | X20 = 56553472 (0x35EF000);             
        // 0x00B18FB0: LDR x20, [x20, #0xde8]     | X20 = 1152921504911265792;              
        // 0x00B18FB4: LDR x0, [x20]              | X0 = typeof(Loader.PathUtil);           
        val_28 = null;
        // 0x00B18FB8: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B18FBC: TBZ w8, #0, #0xb18fd0      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00B18FC0: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B18FC4: CBNZ w8, #0xb18fd0         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00B18FC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B18FCC: LDR x0, [x20]              | X0 = typeof(Loader.PathUtil);           
        val_28 = null;
        label_27:
        // 0x00B18FD0: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B18FD4: LDR x0, [x27]              | X0 = typeof(System.String);             
        // 0x00B18FD8: LDR x23, [x8, #0x28]       | X23 = Loader.PathUtil.persistentDataPath;
        // 0x00B18FDC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B18FE0: TBZ w8, #0, #0xb18ff0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_29;
        // 0x00B18FE4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B18FE8: CBNZ w8, #0xb18ff0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
        // 0x00B18FEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_29:
        // 0x00B18FF0: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B18FF4: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510474838464)("eff_crc.uab");
        // 0x00B18FF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B18FFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B19000: MOV x1, x23                | X1 = Loader.PathUtil.persistentDataPath;//m1
        // 0x00B19004: LDR x2, [x8]               | X2 = "eff_crc.uab";                     
        // 0x00B19008: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        string val_18 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        // 0x00B1900C: MOV x23, x0                | X23 = val_18;//m1                       
        // 0x00B19010: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19014: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B19018: MOV x1, x23                | X1 = val_18;//m1                        
        // 0x00B1901C: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
        bool val_19 = System.IO.File.Exists(path:  0);
        // 0x00B19020: TBZ w0, #0, #0xb19054      | if (val_19 == false) goto label_30;     
        if(val_19 == false)
        {
            goto label_30;
        }
        // 0x00B19024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19028: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1902C: MOV x1, x23                | X1 = val_18;//m1                        
        // 0x00B19030: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_20 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00B19034: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00B19038: LDR x8, [x8, #0xd0]        | X8 = 1152921514962412304;               
        // 0x00B1903C: MOV x1, x0                 | X1 = val_20;//m1                        
        // 0x00B19040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B19044: LDR x2, [x8]               | X2 = public static Filelist<T> Filelist<FileInfoCrc>::CreatFromBytes(byte[] bytes);
        // 0x00B19048: BL #0x19ccffc              | X0 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        Filelist<T> val_21 = Filelist<FileInfoRes>.CreatFromBytes(bytes:  0);
        // 0x00B1904C: STR x0, [x19, #0x10]       | this.fileCrcList = val_21;               //  dest_result_addr=1152921515152450464
        this.fileCrcList = val_21;
        // 0x00B19050: B #0xb1907c                |  goto label_31;                         
        goto label_31;
        label_30:
        // 0x00B19054: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B19058: LDR x8, [x8, #0x940]       | X8 = 1152921504911052800;               
        // 0x00B1905C: LDR x0, [x8]               | X0 = typeof(Filelist<T>);               
        Filelist<FileInfoCrc> val_22 = null;
        // 0x00B19060: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Filelist<T>), ????);
        // 0x00B19064: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B19068: LDR x8, [x8, #0xe08]       | X8 = 1152921514962417424;               
        // 0x00B1906C: MOV x23, x0                | X23 = 1152921504911052800 (0x100000001221D000);//ML01
        // 0x00B19070: LDR x1, [x8]               | X1 = public System.Void Filelist<FileInfoCrc>::.ctor();
        // 0x00B19074: BL #0x19ccf20              | .ctor();                                
        val_22 = new Filelist<FileInfoCrc>();
        // 0x00B19078: STR x23, [x19, #0x10]      | this.fileCrcList = typeof(Filelist<T>);  //  dest_result_addr=1152921515152450464
        this.fileCrcList = val_22;
        label_31:
        // 0x00B1907C: LDR x23, [x19, #0x78]      | X23 = this.addDataDic; //P2             
        val_24 = this.addDataDic;
        // 0x00B19080: LDR w24, [x19, #0x80]      | W24 = this.addTotal; //P2               
        // 0x00B19084: CBNZ x23, #0xb1908c        | if (this.addDataDic != null) goto label_32;
        if(val_24 != null)
        {
            goto label_32;
        }
        // 0x00B19088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_32:
        // 0x00B1908C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00B19090: LDR x8, [x8, #0xf20]       | X8 = 1152921515152420304;               
        // 0x00B19094: MOV x0, x23                | X0 = this.addDataDic;//m1               
        // 0x00B19098: MOV w1, w24                | W1 = this.addTotal;//m1                 
        // 0x00B1909C: MOV x2, x22                | X2 = updateList;//m1                    
        // 0x00B190A0: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::Add(System.Int32 key, System.Collections.Generic.List<FileInfoRes> value);
        // 0x00B190A4: BL #0x2415668              | this.addDataDic.Add(key:  this.addTotal, value:  updateList);
        val_24.Add(key:  this.addTotal, value:  updateList);
        // 0x00B190A8: LDR x20, [sp]              | X20 = downFinishCall;                   
        // 0x00B190AC: CBZ x20, #0xb190dc         | if (downFinishCall == 0) goto label_33; 
        if(val_24 == 0)
        {
            goto label_33;
        }
        // 0x00B190B0: LDR x22, [x19, #0x68]      | X22 = this.downFinishCallDic; //P2      
        // 0x00B190B4: LDR w23, [x19, #0x80]      | W23 = this.addTotal; //P2               
        val_24 = this.addTotal;
        // 0x00B190B8: CBNZ x22, #0xb190c0        | if (this.downFinishCallDic != null) goto label_34;
        if(this.downFinishCallDic != null)
        {
            goto label_34;
        }
        // 0x00B190BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.addDataDic, ????);
        label_34:
        // 0x00B190C0: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B190C4: LDR x8, [x8, #0x220]       | X8 = 1152921515152425424;               
        // 0x00B190C8: MOV x0, x22                | X0 = this.downFinishCallDic;//m1        
        // 0x00B190CC: MOV w1, w23                | W1 = this.addTotal;//m1                 
        // 0x00B190D0: MOV x2, x20                | X2 = downFinishCall;//m1                
        // 0x00B190D4: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, SetBytes>::Add(System.Int32 key, SetBytes value);
        // 0x00B190D8: BL #0x2415668              | this.downFinishCallDic.Add(key:  val_24, value:  val_24);
        this.downFinishCallDic.Add(key:  val_24, value:  val_24);
        label_33:
        // 0x00B190DC: CBZ x21, #0xb190e4         | if (writeDownFinishCall == 0) goto label_35;
        if(val_23 == 0)
        {
            goto label_35;
        }
        // 0x00B190E0: STR x21, [x19, #0x70]      | this.writeDownFinishCall = writeDownFinishCall;  //  dest_result_addr=1152921515152450560
        this.writeDownFinishCall = val_23;
        label_35:
        // 0x00B190E4: LDR w8, [x19, #0x80]       | W8 = this.addTotal; //P2                
        int val_25 = this.addTotal;
        // 0x00B190E8: LDRB w9, [x19, #0x4c]      | W9 = this.isStart; //P2                 
        // 0x00B190EC: ADD w8, w8, #1             | W8 = (this.addTotal + 1);               
        val_25 = val_25 + 1;
        // 0x00B190F0: STR w8, [x19, #0x80]       | this.addTotal = (this.addTotal + 1);     //  dest_result_addr=1152921515152450576
        this.addTotal = val_25;
        // 0x00B190F4: CBZ w9, #0xb19118          | if (this.isStart == false) goto label_36;
        if(this.isStart == false)
        {
            goto label_36;
        }
        label_1:
        // 0x00B190F8: SUB sp, x29, #0x50         | SP = (1152921515152438432 - 80) = 1152921515152438352 (0x100000027490F450);
        // 0x00B190FC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19100: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19104: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B19108: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1910C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B19110: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B19114: RET                        |  return;                                
        return;
        label_36:
        // 0x00B19118: MOV x0, x19                | X0 = 1152921515152450448 (0x1000000274912390);//ML01
        // 0x00B1911C: SUB sp, x29, #0x50         | SP = (1152921515152438432 - 80) = 1152921515152438352 (0x100000027490F450);
        // 0x00B19120: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B19124: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B19128: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1912C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B19130: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B19134: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B19138: B #0xb15014                | this.StartDown(); return;               
        this.StartDown();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15AB0 (11623088), len: 660  VirtAddr: 0x00B15AB0 RVA: 0x00B15AB0 token: 100694318 methodIndex: 24929 delegateWrapperIndex: 0 methodInvoker: 0
    public void AddUpdateData(string path, AssetDownMgr.SetBytes downFinishCall, bool isInsert = False)
    {
        //
        // Disasemble & Code
        //  | 
        string val_8;
        //  | 
        int val_9;
        // 0x00B15AB0: STP x24, x23, [sp, #-0x40]! | stack[1152921515152715248] = ???;  stack[1152921515152715256] = ???;  //  dest_result_addr=1152921515152715248 |  dest_result_addr=1152921515152715256
        // 0x00B15AB4: STP x22, x21, [sp, #0x10]  | stack[1152921515152715264] = ???;  stack[1152921515152715272] = ???;  //  dest_result_addr=1152921515152715264 |  dest_result_addr=1152921515152715272
        // 0x00B15AB8: STP x20, x19, [sp, #0x20]  | stack[1152921515152715280] = ???;  stack[1152921515152715288] = ???;  //  dest_result_addr=1152921515152715280 |  dest_result_addr=1152921515152715288
        // 0x00B15ABC: STP x29, x30, [sp, #0x30]  | stack[1152921515152715296] = ???;  stack[1152921515152715304] = ???;  //  dest_result_addr=1152921515152715296 |  dest_result_addr=1152921515152715304
        // 0x00B15AC0: ADD x29, sp, #0x30         | X29 = (1152921515152715248 + 48) = 1152921515152715296 (0x1000000274952E20);
        // 0x00B15AC4: SUB sp, sp, #0x10          | SP = (1152921515152715248 - 16) = 1152921515152715232 (0x1000000274952DE0);
        // 0x00B15AC8: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
        // 0x00B15ACC: LDRB w8, [x23, #0x791]     | W8 = (bool)static_value_03733791;       
        // 0x00B15AD0: MOV w22, w3                | W22 = isInsert;//m1                     
        // 0x00B15AD4: MOV x20, x2                | X20 = downFinishCall;//m1               
        // 0x00B15AD8: MOV x21, x1                | X21 = path;//m1                         
        val_8 = path;
        // 0x00B15ADC: MOV x19, x0                | X19 = 1152921515152727312 (0x1000000274955D10);//ML01
        // 0x00B15AE0: TBNZ w8, #0, #0xb15afc     | if (static_value_03733791 == true) goto label_0;
        // 0x00B15AE4: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00B15AE8: LDR x8, [x8, #0x220]       | X8 = 0x2B8EAC8;                         
        // 0x00B15AEC: LDR w0, [x8]               | W0 = 0x1172;                            
        // 0x00B15AF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1172, ????);     
        // 0x00B15AF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15AF8: STRB w8, [x23, #0x791]     | static_value_03733791 = true;            //  dest_result_addr=57882513
        label_0:
        // 0x00B15AFC: STR xzr, [sp, #8]          | stack[1152921515152715240] = 0x0;        //  dest_result_addr=1152921515152715240
        // 0x00B15B00: CBNZ x21, #0xb15b08        | if (path != null) goto label_1;         
        if(val_8 != null)
        {
            goto label_1;
        }
        // 0x00B15B04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1172, ????);     
        label_1:
        // 0x00B15B08: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
        // 0x00B15B0C: LDR x8, [x8, #0x348]       | X8 = (string**)(1152921514964332640)("http:");
        // 0x00B15B10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15B14: MOV x0, x21                | X0 = path;//m1                          
        // 0x00B15B18: LDR x1, [x8]               | X1 = "http:";                           
        // 0x00B15B1C: BL #0x18add38              | X0 = path.StartsWith(value:  "http:");  
        bool val_1 = val_8.StartsWith(value:  "http:");
        // 0x00B15B20: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B15B24: TBNZ w8, #0, #0xb15b4c     | if ((val_1 & 1) == true) goto label_2;  
        if(val_2 == true)
        {
            goto label_2;
        }
        // 0x00B15B28: CBNZ x21, #0xb15b30        | if (path != null) goto label_3;         
        if(val_8 != null)
        {
            goto label_3;
        }
        // 0x00B15B2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B15B30: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x00B15B34: LDR x8, [x8, #0xc78]       | X8 = (string**)(1152921514964332720)("https:");
        // 0x00B15B38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B15B3C: MOV x0, x21                | X0 = path;//m1                          
        // 0x00B15B40: LDR x1, [x8]               | X1 = "https:";                          
        // 0x00B15B44: BL #0x18add38              | X0 = path.StartsWith(value:  "https:"); 
        bool val_3 = val_8.StartsWith(value:  "https:");
        // 0x00B15B48: TBZ w0, #0, #0xb15bac      | if (val_3 == false) goto label_4;       
        if(val_3 == false)
        {
            goto label_4;
        }
        label_2:
        // 0x00B15B4C: BL #0xb301c8               | X0 = AssetDownMgr.get_GetMinutes();     
        long val_4 = AssetDownMgr.GetMinutes;
        // 0x00B15B50: STR x0, [sp, #8]           | stack[1152921515152715240] = val_4;      //  dest_result_addr=1152921515152715240
        // 0x00B15B54: ADD x0, sp, #8             | X0 = (1152921515152715232 + 8) = 1152921515152715240 (0x1000000274952DE8);
        // 0x00B15B58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15B5C: BL #0x1e65e0c              | X0 = label_System_Int64_TryParse_GL01E65E0C();
        // 0x00B15B60: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B15B64: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B15B68: MOV x23, x0                | X23 = 1152921515152715240 (0x1000000274952DE8);//ML01
        // 0x00B15B6C: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00B15B70: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B15B74: TBZ w9, #0, #0xb15b88      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B15B78: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B15B7C: CBNZ w9, #0xb15b88         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B15B80: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B15B84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_6:
        // 0x00B15B88: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x00B15B8C: LDR x8, [x8, #0x8a8]       | X8 = (string**)(1152921513099568080)("?");
        // 0x00B15B90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B15B94: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B15B98: MOV x1, x21                | X1 = path;//m1                          
        // 0x00B15B9C: LDR x2, [x8]               | X2 = "?";                               
        // 0x00B15BA0: MOV x3, x23                | X3 = 1152921515152715240 (0x1000000274952DE8);//ML01
        // 0x00B15BA4: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  val_8, str2:  "?");
        string val_5 = System.String.Concat(str0:  0, str1:  val_8, str2:  "?");
        // 0x00B15BA8: MOV x21, x0                | X21 = val_5;//m1                        
        val_8 = val_5;
        label_4:
        // 0x00B15BAC: LDR x23, [x19, #0x30]      | X23 = this.waitUrlGroups; //P2          
        // 0x00B15BB0: CBNZ x23, #0xb15bb8        | if (this.waitUrlGroups != null) goto label_7;
        if(this.waitUrlGroups != null)
        {
            goto label_7;
        }
        // 0x00B15BB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_7:
        // 0x00B15BB8: TBZ w22, #0, #0xb15bdc     | if (isInsert == false) goto label_8;    
        if(isInsert == false)
        {
            goto label_8;
        }
        // 0x00B15BBC: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00B15BC0: LDR x8, [x8, #0xc38]       | X8 = 1152921515152690000;               
        // 0x00B15BC4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B15BC8: MOV x0, x23                | X0 = this.waitUrlGroups;//m1            
        // 0x00B15BCC: MOV x2, x21                | X2 = val_5;//m1                         
        // 0x00B15BD0: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.List<System.String>::Insert(int index, System.String item);
        // 0x00B15BD4: BL #0x25ec310              | this.waitUrlGroups.Insert(index:  0, item:  val_8);
        this.waitUrlGroups.Insert(index:  0, item:  val_8);
        // 0x00B15BD8: B #0xb15bf4                |  goto label_9;                          
        goto label_9;
        label_8:
        // 0x00B15BDC: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B15BE0: LDR x8, [x8, #0x500]       | X8 = 1152921510890816336;               
        // 0x00B15BE4: MOV x0, x23                | X0 = this.waitUrlGroups;//m1            
        // 0x00B15BE8: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B15BEC: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
        // 0x00B15BF0: BL #0x25ea480              | this.waitUrlGroups.Add(item:  val_8);   
        this.waitUrlGroups.Add(item:  val_8);
        label_9:
        // 0x00B15BF4: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00B15BF8: LDR x8, [x8, #0x88]        | X8 = 1152921504910999552;               
        // 0x00B15BFC: LDR x0, [x8]               | X0 = typeof(FileInfoRes);               
        FileInfoRes val_6 = null;
        // 0x00B15C00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(FileInfoRes), ????);
        // 0x00B15C04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B15C08: MOV x22, x0                | X22 = 1152921504910999552 (0x1000000012210000);//ML01
        // 0x00B15C0C: BL #0xed4bb4               | .ctor();                                
        val_6 = new FileInfoRes();
        // 0x00B15C10: CBZ x22, #0xb15c24         | if ( == 0) goto label_10;               
        if(null == 0)
        {
            goto label_10;
        }
        // 0x00B15C14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15C18: STR x21, [x22, #0x20]      | typeof(FileInfoRes).__il2cppRuntimeField_20 = val_5;  //  dest_result_addr=1152921504910999584
        typeof(FileInfoRes).__il2cppRuntimeField_20 = val_8;
        // 0x00B15C1C: STRB w8, [x22, #0x2c]      | typeof(FileInfoRes).__il2cppRuntimeField_2C = 0x1;  //  dest_result_addr=1152921504910999596
        typeof(FileInfoRes).__il2cppRuntimeField_2C = 1;
        // 0x00B15C20: B #0xb15c40                |  goto label_11;                         
        goto label_11;
        label_10:
        // 0x00B15C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00B15C28: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
        // 0x00B15C2C: STR x21, [x8]              | mem[32] = val_5;                         //  dest_result_addr=32
        mem[32] = val_8;
        // 0x00B15C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00B15C34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15C38: STRB w8, [x22, #0x2c]      | typeof(FileInfoRes).__il2cppRuntimeField_2C = 0x1;  //  dest_result_addr=1152921504910999596
        typeof(FileInfoRes).__il2cppRuntimeField_2C = 1;
        // 0x00B15C3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_11:
        // 0x00B15C40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15C44: STRB w8, [x22, #0x34]      | typeof(FileInfoRes).__il2cppRuntimeField_34 = 0x1;  //  dest_result_addr=1152921504910999604
        typeof(FileInfoRes).__il2cppRuntimeField_34 = 1;
        // 0x00B15C48: LDR x23, [x19, #0x20]      | X23 = this.updateDic; //P2              
        // 0x00B15C4C: CBNZ x23, #0xb15c54        | if (this.updateDic != null) goto label_12;
        if(this.updateDic != null)
        {
            goto label_12;
        }
        // 0x00B15C50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_12:
        // 0x00B15C54: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00B15C58: LDR x8, [x8, #0xd20]       | X8 = 1152921514959026480;               
        // 0x00B15C5C: MOV x0, x23                | X0 = this.updateDic;//m1                
        // 0x00B15C60: MOV x1, x21                | X1 = val_5;//m1                         
        // 0x00B15C64: MOV x2, x22                | X2 = 1152921504910999552 (0x1000000012210000);//ML01
        // 0x00B15C68: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Add(System.String key, FileInfoRes value);
        // 0x00B15C6C: BL #0x23fd44c              | this.updateDic.Add(key:  val_8, value:  val_6);
        this.updateDic.Add(key:  val_8, value:  val_6);
        // 0x00B15C70: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
        // 0x00B15C74: LDR x23, [x19, #0x78]      | X23 = this.addDataDic; //P2             
        // 0x00B15C78: LDR w21, [x19, #0x80]      | W21 = this.addTotal; //P2               
        val_9 = this.addTotal;
        // 0x00B15C7C: LDR x8, [x8, #0x540]       | X8 = 1152921504616644608;               
        // 0x00B15C80: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<FileInfoRes> val_7 = null;
        // 0x00B15C84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B15C88: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00B15C8C: LDR x8, [x8, #0x1b0]       | X8 = 1152921514959159984;               
        // 0x00B15C90: MOV x24, x0                | X24 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B15C94: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<FileInfoRes>::.ctor();
        // 0x00B15C98: BL #0x25e9474              | .ctor();                                
        val_7 = new System.Collections.Generic.List<FileInfoRes>();
        // 0x00B15C9C: CBNZ x24, #0xb15ca4        | if ( != 0) goto label_13;               
        if(null != 0)
        {
            goto label_13;
        }
        // 0x00B15CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_13:
        // 0x00B15CA4: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00B15CA8: LDR x8, [x8, #0xcc0]       | X8 = 1152921514959166128;               
        // 0x00B15CAC: MOV x0, x24                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B15CB0: MOV x1, x22                | X1 = 1152921504910999552 (0x1000000012210000);//ML01
        // 0x00B15CB4: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<FileInfoRes>::Add(FileInfoRes item);
        // 0x00B15CB8: BL #0x25ea480              | Add(item:  val_6);                      
        Add(item:  val_6);
        // 0x00B15CBC: CBNZ x23, #0xb15cc4        | if (this.addDataDic != null) goto label_14;
        if(this.addDataDic != null)
        {
            goto label_14;
        }
        // 0x00B15CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
        label_14:
        // 0x00B15CC4: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00B15CC8: LDR x8, [x8, #0xf20]       | X8 = 1152921515152420304;               
        // 0x00B15CCC: MOV x0, x23                | X0 = this.addDataDic;//m1               
        // 0x00B15CD0: MOV w1, w21                | W1 = this.addTotal;//m1                 
        // 0x00B15CD4: MOV x2, x24                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B15CD8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::Add(System.Int32 key, System.Collections.Generic.List<FileInfoRes> value);
        // 0x00B15CDC: BL #0x2415668              | this.addDataDic.Add(key:  val_9, value:  val_7);
        this.addDataDic.Add(key:  val_9, value:  val_7);
        // 0x00B15CE0: CBZ x20, #0xb15d10         | if (downFinishCall == null) goto label_15;
        if(downFinishCall == null)
        {
            goto label_15;
        }
        // 0x00B15CE4: LDR x21, [x19, #0x68]      | X21 = this.downFinishCallDic; //P2      
        val_9 = this.downFinishCallDic;
        // 0x00B15CE8: LDR w22, [x19, #0x80]      | W22 = this.addTotal; //P2               
        // 0x00B15CEC: CBNZ x21, #0xb15cf4        | if (this.downFinishCallDic != null) goto label_16;
        if(val_9 != null)
        {
            goto label_16;
        }
        // 0x00B15CF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.addDataDic, ????);
        label_16:
        // 0x00B15CF4: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B15CF8: LDR x8, [x8, #0x220]       | X8 = 1152921515152425424;               
        // 0x00B15CFC: MOV x0, x21                | X0 = this.downFinishCallDic;//m1        
        // 0x00B15D00: MOV w1, w22                | W1 = this.addTotal;//m1                 
        // 0x00B15D04: MOV x2, x20                | X2 = downFinishCall;//m1                
        // 0x00B15D08: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, SetBytes>::Add(System.Int32 key, SetBytes value);
        // 0x00B15D0C: BL #0x2415668              | this.downFinishCallDic.Add(key:  this.addTotal, value:  downFinishCall);
        val_9.Add(key:  this.addTotal, value:  downFinishCall);
        label_15:
        // 0x00B15D10: LDR w8, [x19, #0x80]       | W8 = this.addTotal; //P2                
        int val_8 = this.addTotal;
        // 0x00B15D14: LDRB w9, [x19, #0x4c]      | W9 = this.isStart; //P2                 
        // 0x00B15D18: ADD w8, w8, #1             | W8 = (this.addTotal + 1);               
        val_8 = val_8 + 1;
        // 0x00B15D1C: STR w8, [x19, #0x80]       | this.addTotal = (this.addTotal + 1);     //  dest_result_addr=1152921515152727440
        this.addTotal = val_8;
        // 0x00B15D20: CBNZ w9, #0xb15d2c         | if (this.isStart == true) goto label_17;
        if(this.isStart == true)
        {
            goto label_17;
        }
        // 0x00B15D24: MOV x0, x19                | X0 = 1152921515152727312 (0x1000000274955D10);//ML01
        // 0x00B15D28: BL #0xb15014               | this.StartDown();                       
        this.StartDown();
        label_17:
        // 0x00B15D2C: SUB sp, x29, #0x30         | SP = (1152921515152715296 - 48) = 1152921515152715248 (0x1000000274952DF0);
        // 0x00B15D30: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15D34: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B15D38: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B15D3C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B15D40: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B15014 (11620372), len: 112  VirtAddr: 0x00B15014 RVA: 0x00B15014 token: 100694319 methodIndex: 24930 delegateWrapperIndex: 0 methodInvoker: 0
    public void StartDown()
    {
        //
        // Disasemble & Code
        // 0x00B15014: STP x20, x19, [sp, #-0x20]! | stack[1152921515152855952] = ???;  stack[1152921515152855960] = ???;  //  dest_result_addr=1152921515152855952 |  dest_result_addr=1152921515152855960
        // 0x00B15018: STP x29, x30, [sp, #0x10]  | stack[1152921515152855968] = ???;  stack[1152921515152855976] = ???;  //  dest_result_addr=1152921515152855968 |  dest_result_addr=1152921515152855976
        // 0x00B1501C: ADD x29, sp, #0x10         | X29 = (1152921515152855952 + 16) = 1152921515152855968 (0x10000002749753A0);
        // 0x00B15020: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B15024: LDRB w8, [x20, #0x792]     | W8 = (bool)static_value_03733792;       
        // 0x00B15028: MOV x19, x0                | X19 = 1152921515152867984 (0x1000000274978290);//ML01
        // 0x00B1502C: TBNZ w8, #0, #0xb15048     | if (static_value_03733792 == true) goto label_0;
        // 0x00B15030: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00B15034: LDR x8, [x8, #0x3a8]       | X8 = 0x2B8EAEC;                         
        // 0x00B15038: LDR w0, [x8]               | W0 = 0x117B;                            
        // 0x00B1503C: BL #0x2782188              | X0 = sub_2782188( ?? 0x117B, ????);     
        // 0x00B15040: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15044: STRB w8, [x20, #0x792]     | static_value_03733792 = true;            //  dest_result_addr=57882514
        label_0:
        // 0x00B15048: STRB wzr, [x19, #0x60]     | this.IsWriteFinish = false;              //  dest_result_addr=1152921515152868080
        this.IsWriteFinish = false;
        // 0x00B1504C: ADRP x9, #0x360d000        | X9 = 56676352 (0x360D000);              
        // 0x00B15050: LDR x9, [x9, #0xf38]       | X9 = 1152921504922128384;               
        // 0x00B15054: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B15058: STRB w8, [x19, #0x4c]      | this.isStart = true;                     //  dest_result_addr=1152921515152868060
        this.isStart = true;
        // 0x00B1505C: LDR x0, [x9]               | X0 = typeof(AllUpdate);                 
        // 0x00B15060: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B15064: TBZ w8, #0, #0xb15074      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B15068: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B1506C: CBNZ w8, #0xb15074         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B15070: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        label_2:
        // 0x00B15074: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B15078: MOV x1, x19                | X1 = 1152921515152867984 (0x1000000274978290);//ML01
        // 0x00B1507C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B15080: B #0xb14d7c                | AllUpdate.AddUpdate(update:  null); return;
        AllUpdate.AddUpdate(update:  null);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B30268 (11731560), len: 276  VirtAddr: 0x00B30268 RVA: 0x00B30268 token: 100694320 methodIndex: 24931 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B30268: STP x20, x19, [sp, #-0x20]! | stack[1152921515152990480] = ???;  stack[1152921515152990488] = ???;  //  dest_result_addr=1152921515152990480 |  dest_result_addr=1152921515152990488
        // 0x00B3026C: STP x29, x30, [sp, #0x10]  | stack[1152921515152990496] = ???;  stack[1152921515152990504] = ???;  //  dest_result_addr=1152921515152990496 |  dest_result_addr=1152921515152990504
        // 0x00B30270: ADD x29, sp, #0x10         | X29 = (1152921515152990480 + 16) = 1152921515152990496 (0x1000000274996120);
        // 0x00B30274: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B30278: LDRB w8, [x20, #0x793]     | W8 = (bool)static_value_03733793;       
        // 0x00B3027C: MOV x19, x0                | X19 = 1152921515153002512 (0x1000000274999010);//ML01
        // 0x00B30280: TBNZ w8, #0, #0xb3029c     | if (static_value_03733793 == true) goto label_0;
        // 0x00B30284: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x00B30288: LDR x8, [x8, #0x10]        | X8 = 0x2B8EACC;                         
        // 0x00B3028C: LDR w0, [x8]               | W0 = 0x1173;                            
        // 0x00B30290: BL #0x2782188              | X0 = sub_2782188( ?? 0x1173, ????);     
        // 0x00B30294: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B30298: STRB w8, [x20, #0x793]     | static_value_03733793 = true;            //  dest_result_addr=57882515
        label_0:
        // 0x00B3029C: LDR x20, [x19, #0x20]      | X20 = this.updateDic; //P2              
        // 0x00B302A0: CBNZ x20, #0xb302a8        | if (this.updateDic != null) goto label_1;
        if(this.updateDic != null)
        {
            goto label_1;
        }
        // 0x00B302A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1173, ????);     
        label_1:
        // 0x00B302A8: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00B302AC: LDR x8, [x8, #0x138]       | X8 = 1152921514963718752;               
        // 0x00B302B0: MOV x0, x20                | X0 = this.updateDic;//m1                
        // 0x00B302B4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Clear();
        // 0x00B302B8: BL #0x23fd92c              | this.updateDic.Clear();                 
        this.updateDic.Clear();
        // 0x00B302BC: LDR x20, [x19, #0x68]      | X20 = this.downFinishCallDic; //P2      
        // 0x00B302C0: CBNZ x20, #0xb302c8        | if (this.downFinishCallDic != null) goto label_2;
        if(this.downFinishCallDic != null)
        {
            goto label_2;
        }
        // 0x00B302C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.updateDic, ????);
        label_2:
        // 0x00B302C8: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00B302CC: LDR x8, [x8, #0x530]       | X8 = 1152921515152964176;               
        // 0x00B302D0: MOV x0, x20                | X0 = this.downFinishCallDic;//m1        
        // 0x00B302D4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, SetBytes>::Clear();
        // 0x00B302D8: BL #0x2415b18              | this.downFinishCallDic.Clear();         
        this.downFinishCallDic.Clear();
        // 0x00B302DC: LDR x20, [x19, #0x78]      | X20 = this.addDataDic; //P2             
        // 0x00B302E0: CBNZ x20, #0xb302e8        | if (this.addDataDic != null) goto label_3;
        if(this.addDataDic != null)
        {
            goto label_3;
        }
        // 0x00B302E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.downFinishCallDic, ????);
        label_3:
        // 0x00B302E8: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x00B302EC: LDR x8, [x8, #0x188]       | X8 = 1152921515152969296;               
        // 0x00B302F0: MOV x0, x20                | X0 = this.addDataDic;//m1               
        // 0x00B302F4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::Clear();
        // 0x00B302F8: BL #0x2415b18              | this.addDataDic.Clear();                
        this.addDataDic.Clear();
        // 0x00B302FC: LDR x20, [x19, #0x98]      | X20 = this.errorDownFiles; //P2         
        // 0x00B30300: CBNZ x20, #0xb30308        | if (this.errorDownFiles != null) goto label_4;
        if(this.errorDownFiles != null)
        {
            goto label_4;
        }
        // 0x00B30304: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.addDataDic, ????);
        label_4:
        // 0x00B30308: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00B3030C: LDR x8, [x8, #0xf98]       | X8 = 1152921510807332752;               
        // 0x00B30310: MOV x0, x20                | X0 = this.errorDownFiles;//m1           
        // 0x00B30314: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Clear();
        // 0x00B30318: BL #0x23f5768              | this.errorDownFiles.Clear();            
        this.errorDownFiles.Clear();
        // 0x00B3031C: STP wzr, wzr, [x19, #0x80] | this.addTotal = 0;  this.adddownIndex = 0;  //  dest_result_addr=1152921515153002640 |  dest_result_addr=1152921515153002644
        this.addTotal = 0;
        this.adddownIndex = 0;
        // 0x00B30320: LDR x20, [x19, #0x28]      | X20 = this.wwwGroups; //P2              
        // 0x00B30324: STRB wzr, [x19, #0x4c]     | this.isStart = false;                    //  dest_result_addr=1152921515153002588
        this.isStart = false;
        // 0x00B30328: STRB wzr, [x19, #0x88]     | this.IsDownSuccess = false;              //  dest_result_addr=1152921515153002648
        this.IsDownSuccess = false;
        // 0x00B3032C: STP xzr, xzr, [x19, #0x50] | this.totalBytes = null; this.curBytes = null;  this.totalFileCount = 0; this.curFileCount = 0;  //  dest_result_addr=1152921515153002592 dest_result_addr=1152921515153002596 |  dest_result_addr=1152921515153002600 dest_result_addr=1152921515153002604
        this.totalBytes = 0;
        this.curBytes = 0;
        this.totalFileCount = 0;
        this.curFileCount = 0;
        // 0x00B30330: CBNZ x20, #0xb30338        | if (this.wwwGroups != null) goto label_5;
        if(this.wwwGroups != null)
        {
            goto label_5;
        }
        // 0x00B30334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.errorDownFiles, ????);
        label_5:
        // 0x00B30338: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00B3033C: LDR x8, [x8, #0xaf8]       | X8 = 1152921514963733088;               
        // 0x00B30340: MOV x0, x20                | X0 = this.wwwGroups;//m1                
        // 0x00B30344: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Mihua.Net.UrlLoader>::Clear();
        // 0x00B30348: BL #0x25ead28              | this.wwwGroups.Clear();                 
        this.wwwGroups.Clear();
        // 0x00B3034C: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x00B30350: LDR x8, [x8, #0xf38]       | X8 = 1152921504922128384;               
        // 0x00B30354: LDR x0, [x8]               | X0 = typeof(AllUpdate);                 
        // 0x00B30358: LDRB w8, [x0, #0x10a]      | W8 = AllUpdate.__il2cppRuntimeField_10A;
        // 0x00B3035C: TBZ w8, #0, #0xb3036c      | if (AllUpdate.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B30360: LDR w8, [x0, #0xbc]        | W8 = AllUpdate.__il2cppRuntimeField_cctor_finished;
        // 0x00B30364: CBNZ w8, #0xb3036c         | if (AllUpdate.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B30368: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AllUpdate), ????);
        label_7:
        // 0x00B3036C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B30370: MOV x1, x19                | X1 = 1152921515153002512 (0x1000000274999010);//ML01
        // 0x00B30374: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B30378: B #0xb25c84                | AllUpdate.RemoveUpdate(update:  null); return;
        AllUpdate.RemoveUpdate(update:  null);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B3037C (11731836), len: 5788  VirtAddr: 0x00B3037C RVA: 0x00B3037C token: 100694321 methodIndex: 24932 delegateWrapperIndex: 0 methodInvoker: 0
    private void IZUpdate.ZUpdate()
    {
        //
        // Disasemble & Code
        //  | 
        string val_142;
        //  | 
        int val_143;
        //  | 
        string val_144;
        //  | 
        string val_145;
        //  | 
        int val_146;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Int32> val_147;
        //  | 
        var val_148;
        //  | 
        var val_149;
        //  | 
        System.Collections.Generic.List<Mihua.Net.UrlLoader> val_150;
        //  | 
        FileInfoRes val_151;
        //  | 
        System.Collections.Generic.Dictionary<System.String, System.Int32> val_152;
        //  | 
        string val_153;
        //  | 
        string val_154;
        //  | 
        var val_155;
        //  | 
        string val_156;
        //  | 
        var val_157;
        // 0x00B3037C: STP d9, d8, [sp, #-0x70]!  | stack[1152921515154046768] = ???;  stack[1152921515154046776] = ???;  //  dest_result_addr=1152921515154046768 |  dest_result_addr=1152921515154046776
        // 0x00B30380: STP x28, x27, [sp, #0x10]  | stack[1152921515154046784] = ???;  stack[1152921515154046792] = ???;  //  dest_result_addr=1152921515154046784 |  dest_result_addr=1152921515154046792
        // 0x00B30384: STP x26, x25, [sp, #0x20]  | stack[1152921515154046800] = ???;  stack[1152921515154046808] = ???;  //  dest_result_addr=1152921515154046800 |  dest_result_addr=1152921515154046808
        // 0x00B30388: STP x24, x23, [sp, #0x30]  | stack[1152921515154046816] = ???;  stack[1152921515154046824] = ???;  //  dest_result_addr=1152921515154046816 |  dest_result_addr=1152921515154046824
        // 0x00B3038C: STP x22, x21, [sp, #0x40]  | stack[1152921515154046832] = ???;  stack[1152921515154046840] = ???;  //  dest_result_addr=1152921515154046832 |  dest_result_addr=1152921515154046840
        // 0x00B30390: STP x20, x19, [sp, #0x50]  | stack[1152921515154046848] = ???;  stack[1152921515154046856] = ???;  //  dest_result_addr=1152921515154046848 |  dest_result_addr=1152921515154046856
        // 0x00B30394: STP x29, x30, [sp, #0x60]  | stack[1152921515154046864] = ???;  stack[1152921515154046872] = ???;  //  dest_result_addr=1152921515154046864 |  dest_result_addr=1152921515154046872
        // 0x00B30398: ADD x29, sp, #0x60         | X29 = (1152921515154046768 + 96) = 1152921515154046864 (0x1000000274A97F90);
        // 0x00B3039C: SUB sp, sp, #0x10          | SP = (1152921515154046768 - 16) = 1152921515154046752 (0x1000000274A97F20);
        // 0x00B303A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B303A4: LDRB w8, [x20, #0x794]     | W8 = (bool)static_value_03733794;       
        // 0x00B303A8: MOV x19, x0                | X19 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B303AC: TBNZ w8, #0, #0xb303c8     | if (static_value_03733794 == true) goto label_0;
        // 0x00B303B0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B303B4: LDR x8, [x8, #0x410]       | X8 = 0x2B8EAE0;                         
        // 0x00B303B8: LDR w0, [x8]               | W0 = 0x1178;                            
        // 0x00B303BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1178, ????);     
        // 0x00B303C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B303C4: STRB w8, [x20, #0x794]     | static_value_03733794 = true;            //  dest_result_addr=57882516
        label_0:
        // 0x00B303C8: LDRB w8, [x19, #0xa8]      | W8 = this.CanDownFile; //P2             
        // 0x00B303CC: CBZ w8, #0xb3184c          | if (this.CanDownFile == false) goto label_219;
        if(this.CanDownFile == false)
        {
            goto label_219;
        }
        // 0x00B303D0: STR wzr, [x19, #0x8c]      | this.loadingBytes = null;                //  dest_result_addr=1152921515154059020
        this.loadingBytes = 0;
        // 0x00B303D4: ADRP x27, #0x3602000       | X27 = 56631296 (0x3602000);             
        // 0x00B303D8: ADRP x26, #0x362d000       | X26 = 56807424 (0x362D000);             
        // 0x00B303DC: ADRP x25, #0x3633000       | X25 = 56832000 (0x3633000);             
        // 0x00B303E0: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
        // 0x00B303E4: LDR x27, [x27, #0x640]     | X27 = 1152921514964529792;              
        // 0x00B303E8: LDR x26, [x26, #0x230]     | X26 = 1152921514959293488;              
        // 0x00B303EC: LDR x25, [x25, #0x8a8]     | X25 = (string**)(1152921513099568080)("?");
        // 0x00B303F0: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
        // 0x00B303F4: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        // 0x00B303F8: FMOV s8, #15.00000000      | S8 = 15;                                
        // 0x00B303FC: B #0xb30e38                |  goto label_197;                        
        goto label_197;
        label_177:
        // 0x00B30400: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00B30404: LDR x8, [x8, #0x6f0]       | X8 = 1152921514964672640;               
        uint val_145 = 1152921514964672640;
        // 0x00B30408: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B3040C: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30410: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Net.UrlLoader>::RemoveAt(int index);
        // 0x00B30414: BL #0x25ed00c              | X21.RemoveAt(index:  0);                
        X21.RemoveAt(index:  0);
        // 0x00B30418: B #0xb30e38                |  goto label_197;                        
        goto label_197;
        label_95:
        // 0x00B3041C: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B30420: CBNZ x21, #0xb30428        | if (this.wwwGroups != null) goto label_4;
        if(this.wwwGroups != null)
        {
            goto label_4;
        }
        // 0x00B30424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X21, ????);        
        label_4:
        // 0x00B30428: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B3042C: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B30430: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30434: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_1 = this.wwwGroups.Item[0];
        // 0x00B30438: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B3043C: CBNZ x21, #0xb30444        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00B30440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00B30444: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30448: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B3044C: BL #0xabe8e8               | X0 = val_1.get_error();                 
        string val_2 = val_1.error;
        // 0x00B30450: CBZ x0, #0xb30648          | if (val_2 == null) goto label_6;        
        if(val_2 == null)
        {
            goto label_6;
        }
        // 0x00B30454: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B30458: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B3045C: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x00B30460: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B30464: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B30468: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B3046C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B30470: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B30474: LDR x22, [x19, #0x28]      | X22 = this.wwwGroups; //P2              
        // 0x00B30478: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B3047C: CBNZ x22, #0xb30484        | if (this.wwwGroups != null) goto label_7;
        if(this.wwwGroups != null)
        {
            goto label_7;
        }
        // 0x00B30480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_7:
        // 0x00B30484: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30488: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B3048C: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30490: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_3 = this.wwwGroups.Item[0];
        // 0x00B30494: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00B30498: CBNZ x22, #0xb304a0        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00B3049C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B304A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B304A4: MOV x0, x22                | X0 = val_3;//m1                         
        // 0x00B304A8: BL #0xabe980               | X0 = val_3.get_url();                   
        string val_4 = val_3.url;
        // 0x00B304AC: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x00B304B0: CBNZ x21, #0xb304b8        | if ( != null) goto label_9;             
        if(null != null)
        {
            goto label_9;
        }
        // 0x00B304B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_9:
        // 0x00B304B8: CBZ x22, #0xb304dc         | if (val_4 == null) goto label_11;       
        if(val_4 == null)
        {
            goto label_11;
        }
        // 0x00B304BC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B304C0: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x00B304C4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B304C8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x00B304CC: CBNZ x0, #0xb304dc         | if (val_4 != null) goto label_11;       
        if(val_4 != null)
        {
            goto label_11;
        }
        // 0x00B304D0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
        // 0x00B304D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B304D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_11:
        // 0x00B304DC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B304E0: CBNZ w8, #0xb304f0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_12;
        // 0x00B304E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
        // 0x00B304E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B304EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        label_12:
        // 0x00B304F0: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_4;
        // 0x00B304F4: LDR x22, [x19, #0x28]      | X22 = this.wwwGroups; //P2              
        // 0x00B304F8: CBNZ x22, #0xb30500        | if (this.wwwGroups != null) goto label_13;
        if(this.wwwGroups != null)
        {
            goto label_13;
        }
        // 0x00B304FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_13:
        // 0x00B30500: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30504: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30508: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3050C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_5 = this.wwwGroups.Item[0];
        // 0x00B30510: MOV x22, x0                | X22 = val_5;//m1                        
        // 0x00B30514: CBNZ x22, #0xb3051c        | if (val_5 != null) goto label_14;       
        if(val_5 != null)
        {
            goto label_14;
        }
        // 0x00B30518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_14:
        // 0x00B3051C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30520: MOV x0, x22                | X0 = val_5;//m1                         
        // 0x00B30524: BL #0xabe8e8               | X0 = val_5.get_error();                 
        string val_6 = val_5.error;
        // 0x00B30528: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B3052C: CBNZ x21, #0xb30534        | if ( != null) goto label_15;            
        if(null != null)
        {
            goto label_15;
        }
        // 0x00B30530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_15:
        // 0x00B30534: CBZ x22, #0xb30558         | if (val_6 == null) goto label_17;       
        if(val_6 == null)
        {
            goto label_17;
        }
        // 0x00B30538: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B3053C: MOV x0, x22                | X0 = val_6;//m1                         
        // 0x00B30540: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B30544: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
        // 0x00B30548: CBNZ x0, #0xb30558         | if (val_6 != null) goto label_17;       
        if(val_6 != null)
        {
            goto label_17;
        }
        // 0x00B3054C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
        // 0x00B30550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30554: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_17:
        // 0x00B30558: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B3055C: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B30560: B.HI #0xb30570             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_18;
        // 0x00B30564: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B30568: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3056C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_18:
        // 0x00B30570: STR x22, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_6;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_6;
        // 0x00B30574: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B30578: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921514964571776)("{0} 资源加载出错：{1}");
        // 0x00B3057C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30580: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30584: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B30588: LDR x1, [x8]               | X1 = "{0} 资源加载出错：{1}";                  
        // 0x00B3058C: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0} 资源加载出错：{1}");
        string val_7 = EString.EFormat(format:  0, args:  "{0} 资源加载出错：{1}");
        // 0x00B30590: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B30594: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B30598: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00B3059C: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B305A0: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B305A4: TBZ w9, #0, #0xb305b8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B305A8: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B305AC: CBNZ w9, #0xb305b8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B305B0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B305B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_20:
        // 0x00B305B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B305BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B305C0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B305C4: MOV x1, x21                | X1 = val_7;//m1                         
        // 0x00B305C8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_7);
        EDebug.Log(message:  0, isShowStack:  val_7);
        // 0x00B305CC: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B305D0: CBNZ x21, #0xb305d8        | if (this.wwwGroups != null) goto label_21;
        if(this.wwwGroups != null)
        {
            goto label_21;
        }
        // 0x00B305D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_21:
        // 0x00B305D8: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B305DC: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B305E0: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B305E4: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_8 = this.wwwGroups.Item[0];
        // 0x00B305E8: MOV x21, x0                | X21 = val_8;//m1                        
        // 0x00B305EC: CBNZ x21, #0xb305f4        | if (val_8 != null) goto label_22;       
        if(val_8 != null)
        {
            goto label_22;
        }
        // 0x00B305F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_22:
        // 0x00B305F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B305F8: MOV x0, x21                | X0 = val_8;//m1                         
        // 0x00B305FC: BL #0xabe980               | X0 = val_8.get_url();                   
        string val_9 = val_8.url;
        // 0x00B30600: MOV x21, x0                | X21 = val_9;//m1                        
        // 0x00B30604: STR x21, [x19, #0xa0]      | this.errorUrl = val_9;                   //  dest_result_addr=1152921515154059040
        this.errorUrl = val_9;
        // 0x00B30608: CBNZ x21, #0xb30610        | if (val_9 != null) goto label_23;       
        if(val_9 != null)
        {
            goto label_23;
        }
        // 0x00B3060C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_23:
        // 0x00B30610: LDR x1, [x25]              | X1 = "?";                               
        // 0x00B30614: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30618: MOV x0, x21                | X0 = val_9;//m1                         
        // 0x00B3061C: BL #0x18ad1e4              | X0 = val_9.LastIndexOf(value:  "?");    
        int val_10 = val_9.LastIndexOf(value:  "?");
        // 0x00B30620: LDR x22, [x19, #0xa0]      | X22 = this.errorUrl; //P2               
        val_142 = this.errorUrl;
        // 0x00B30624: CMP w0, #1                 | STATE = COMPARE(val_10, 0x1)            
        // 0x00B30628: B.LT #0xb30ac8             | if (val_10 < 1) goto label_24;          
        if(val_10 < 1)
        {
            goto label_24;
        }
        // 0x00B3062C: CBZ x22, #0xb30a90         | if (this.errorUrl == null) goto label_25;
        if(val_142 == null)
        {
            goto label_25;
        }
        // 0x00B30630: LDR x1, [x25]              | X1 = "?";                               
        // 0x00B30634: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30638: MOV x0, x22                | X0 = this.errorUrl;//m1                 
        // 0x00B3063C: BL #0x18ad1e4              | X0 = this.errorUrl.LastIndexOf(value:  "?");
        int val_11 = val_142.LastIndexOf(value:  "?");
        // 0x00B30640: MOV w23, w0                | W23 = val_11;//m1                       
        val_143 = val_11;
        // 0x00B30644: B #0xb30aac                |  goto label_26;                         
        goto label_26;
        label_6:
        // 0x00B30648: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B3064C: CBNZ x21, #0xb30654        | if (this.wwwGroups != null) goto label_27;
        if(this.wwwGroups != null)
        {
            goto label_27;
        }
        // 0x00B30650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_27:
        // 0x00B30654: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30658: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B3065C: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30660: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_12 = this.wwwGroups.Item[0];
        // 0x00B30664: MOV x21, x0                | X21 = val_12;//m1                       
        // 0x00B30668: CBNZ x21, #0xb30670        | if (val_12 != null) goto label_28;      
        if(val_12 != null)
        {
            goto label_28;
        }
        // 0x00B3066C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_28:
        // 0x00B30670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30674: MOV x0, x21                | X0 = val_12;//m1                        
        // 0x00B30678: BL #0xabebcc               | X0 = val_12.get_isDone();               
        bool val_13 = val_12.isDone;
        // 0x00B3067C: TBZ w0, #0, #0xb3172c      | if (val_13 == false) goto label_29;     
        if(val_13 == false)
        {
            goto label_29;
        }
        // 0x00B30680: LDR w23, [x19, #0x90]      | W23 = this.loadedBytes; //P2            
        // 0x00B30684: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B30688: CBNZ x22, #0xb30690        | if (this.wwwGroups != null) goto label_30;
        if(this.wwwGroups != null)
        {
            goto label_30;
        }
        // 0x00B3068C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_30:
        // 0x00B30690: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30694: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30698: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3069C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_14 = this.wwwGroups.Item[0];
        // 0x00B306A0: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00B306A4: CBNZ x22, #0xb306ac        | if (val_14 != null) goto label_31;      
        if(val_14 != null)
        {
            goto label_31;
        }
        // 0x00B306A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_31:
        // 0x00B306AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B306B0: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00B306B4: BL #0xabe980               | X0 = val_14.get_url();                  
        string val_15 = val_14.url;
        // 0x00B306B8: MOV x22, x0                | X22 = val_15;//m1                       
        // 0x00B306BC: CBNZ x21, #0xb306c4        | if (this.updateDic != null) goto label_32;
        if(this.updateDic != null)
        {
            goto label_32;
        }
        // 0x00B306C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_32:
        // 0x00B306C4: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B306C8: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B306CC: MOV x1, x22                | X1 = val_15;//m1                        
        // 0x00B306D0: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_15);
        FileInfoRes val_16 = this.updateDic.Item[val_15];
        // 0x00B306D4: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00B306D8: CBNZ x21, #0xb306e0        | if (val_16 != null) goto label_33;      
        if(val_16 != null)
        {
            goto label_33;
        }
        // 0x00B306DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_33:
        // 0x00B306E0: LDR w8, [x21, #0x28]       | W8 = val_16.mSize; //P2                 
        uint val_142 = val_16.mSize;
        // 0x00B306E4: LDR x21, [x19, #0x78]      | X21 = this.addDataDic; //P2             
        // 0x00B306E8: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B306EC: ADD w8, w8, w23            | W8 = (val_16.mSize + this.loadedBytes); 
        val_142 = val_142 + this.loadedBytes;
        // 0x00B306F0: STR w8, [x19, #0x90]       | this.loadedBytes = (val_16.mSize + this.loadedBytes);  //  dest_result_addr=1152921515154059024
        this.loadedBytes = val_142;
        // 0x00B306F4: CBNZ x21, #0xb306fc        | if (this.addDataDic != null) goto label_34;
        if(this.addDataDic != null)
        {
            goto label_34;
        }
        // 0x00B306F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_34:
        // 0x00B306FC: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00B30700: LDR x8, [x8, #0x990]       | X8 = 1152921515153201104;               
        // 0x00B30704: MOV x0, x21                | X0 = this.addDataDic;//m1               
        // 0x00B30708: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B3070C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::ContainsKey(System.Int32 key);
        // 0x00B30710: BL #0x2415bdc              | X0 = this.addDataDic.ContainsKey(key:  this.adddownIndex);
        bool val_17 = this.addDataDic.ContainsKey(key:  this.adddownIndex);
        // 0x00B30714: TBZ w0, #0, #0xb30a14      | if (val_17 == false) goto label_51;     
        if(val_17 == false)
        {
            goto label_51;
        }
        // 0x00B30718: LDR x21, [x19, #0x78]      | X21 = this.addDataDic; //P2             
        // 0x00B3071C: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B30720: CBNZ x21, #0xb30728        | if (this.addDataDic != null) goto label_36;
        if(this.addDataDic != null)
        {
            goto label_36;
        }
        // 0x00B30724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_36:
        // 0x00B30728: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B3072C: LDR x8, [x8, #0x7c0]       | X8 = 1152921515153206224;               
        // 0x00B30730: MOV x0, x21                | X0 = this.addDataDic;//m1               
        // 0x00B30734: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B30738: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<FileInfoRes> System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::get_Item(System.Int32 key);
        // 0x00B3073C: BL #0x24144f0              | X0 = this.addDataDic.get_Item(key:  this.adddownIndex);
        System.Collections.Generic.List<FileInfoRes> val_18 = this.addDataDic.Item[this.adddownIndex];
        // 0x00B30740: LDP x22, x23, [x19, #0x20] | X22 = this.updateDic; //P2  X23 = this.wwwGroups; //P2  //  | 
        // 0x00B30744: MOV x21, x0                | X21 = val_18;//m1                       
        // 0x00B30748: CBNZ x23, #0xb30750        | if (this.wwwGroups != null) goto label_37;
        if(this.wwwGroups != null)
        {
            goto label_37;
        }
        // 0x00B3074C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_37:
        // 0x00B30750: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30754: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B30758: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3075C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_19 = this.wwwGroups.Item[0];
        // 0x00B30760: MOV x23, x0                | X23 = val_19;//m1                       
        // 0x00B30764: CBNZ x23, #0xb3076c        | if (val_19 != null) goto label_38;      
        if(val_19 != null)
        {
            goto label_38;
        }
        // 0x00B30768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_38:
        // 0x00B3076C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30770: MOV x0, x23                | X0 = val_19;//m1                        
        // 0x00B30774: BL #0xabe980               | X0 = val_19.get_url();                  
        string val_20 = val_19.url;
        // 0x00B30778: MOV x23, x0                | X23 = val_20;//m1                       
        val_144 = val_20;
        // 0x00B3077C: CBNZ x22, #0xb30784        | if (this.updateDic != null) goto label_39;
        if(this.updateDic != null)
        {
            goto label_39;
        }
        // 0x00B30780: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_39:
        // 0x00B30784: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B30788: MOV x0, x22                | X0 = this.updateDic;//m1                
        // 0x00B3078C: MOV x1, x23                | X1 = val_20;//m1                        
        // 0x00B30790: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_144);
        FileInfoRes val_21 = this.updateDic.Item[val_144];
        // 0x00B30794: MOV x22, x0                | X22 = val_21;//m1                       
        // 0x00B30798: CBNZ x21, #0xb307a0        | if (val_18 != null) goto label_40;      
        if(val_18 != null)
        {
            goto label_40;
        }
        // 0x00B3079C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_40:
        // 0x00B307A0: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00B307A4: LDR x8, [x8, #0xe60]       | X8 = 1152921515153231824;               
        // 0x00B307A8: MOV x0, x21                | X0 = val_18;//m1                        
        // 0x00B307AC: MOV x1, x22                | X1 = val_21;//m1                        
        // 0x00B307B0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<FileInfoRes>::Contains(FileInfoRes item);
        // 0x00B307B4: BL #0x25ead74              | X0 = val_18.Contains(item:  val_21);    
        bool val_22 = val_18.Contains(item:  val_21);
        // 0x00B307B8: TBZ w0, #0, #0xb3085c      | if (val_22 == false) goto label_41;     
        if(val_22 == false)
        {
            goto label_41;
        }
        // 0x00B307BC: LDR x21, [x19, #0x78]      | X21 = this.addDataDic; //P2             
        // 0x00B307C0: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B307C4: CBNZ x21, #0xb307cc        | if (this.addDataDic != null) goto label_42;
        if(this.addDataDic != null)
        {
            goto label_42;
        }
        // 0x00B307C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_42:
        // 0x00B307CC: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B307D0: LDR x8, [x8, #0x7c0]       | X8 = 1152921515153206224;               
        // 0x00B307D4: MOV x0, x21                | X0 = this.addDataDic;//m1               
        // 0x00B307D8: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B307DC: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<FileInfoRes> System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::get_Item(System.Int32 key);
        // 0x00B307E0: BL #0x24144f0              | X0 = this.addDataDic.get_Item(key:  this.adddownIndex);
        System.Collections.Generic.List<FileInfoRes> val_23 = this.addDataDic.Item[this.adddownIndex];
        // 0x00B307E4: LDP x22, x23, [x19, #0x20] | X22 = this.updateDic; //P2  X23 = this.wwwGroups; //P2  //  | 
        // 0x00B307E8: MOV x21, x0                | X21 = val_23;//m1                       
        // 0x00B307EC: CBNZ x23, #0xb307f4        | if (this.wwwGroups != null) goto label_43;
        if(this.wwwGroups != null)
        {
            goto label_43;
        }
        // 0x00B307F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_43:
        // 0x00B307F4: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B307F8: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B307FC: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30800: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_24 = this.wwwGroups.Item[0];
        // 0x00B30804: MOV x23, x0                | X23 = val_24;//m1                       
        // 0x00B30808: CBNZ x23, #0xb30810        | if (val_24 != null) goto label_44;      
        if(val_24 != null)
        {
            goto label_44;
        }
        // 0x00B3080C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_44:
        // 0x00B30810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30814: MOV x0, x23                | X0 = val_24;//m1                        
        // 0x00B30818: BL #0xabe980               | X0 = val_24.get_url();                  
        string val_25 = val_24.url;
        // 0x00B3081C: MOV x23, x0                | X23 = val_25;//m1                       
        val_144 = val_25;
        // 0x00B30820: CBNZ x22, #0xb30828        | if (this.updateDic != null) goto label_45;
        if(this.updateDic != null)
        {
            goto label_45;
        }
        // 0x00B30824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_45:
        // 0x00B30828: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B3082C: MOV x0, x22                | X0 = this.updateDic;//m1                
        // 0x00B30830: MOV x1, x23                | X1 = val_25;//m1                        
        // 0x00B30834: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_144);
        FileInfoRes val_26 = this.updateDic.Item[val_144];
        // 0x00B30838: MOV x22, x0                | X22 = val_26;//m1                       
        // 0x00B3083C: CBNZ x21, #0xb30844        | if (val_23 != null) goto label_46;      
        if(val_23 != null)
        {
            goto label_46;
        }
        // 0x00B30840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_46:
        // 0x00B30844: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00B30848: LDR x8, [x8, #0x128]       | X8 = 1152921515153261520;               
        // 0x00B3084C: MOV x0, x21                | X0 = val_23;//m1                        
        // 0x00B30850: MOV x1, x22                | X1 = val_26;//m1                        
        // 0x00B30854: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<FileInfoRes>::Remove(FileInfoRes item);
        // 0x00B30858: BL #0x25ecd20              | X0 = val_23.Remove(item:  val_26);      
        bool val_27 = val_23.Remove(item:  val_26);
        label_41:
        // 0x00B3085C: LDR x21, [x19, #0x78]      | X21 = this.addDataDic; //P2             
        // 0x00B30860: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B30864: CBNZ x21, #0xb3086c        | if (this.addDataDic != null) goto label_47;
        if(this.addDataDic != null)
        {
            goto label_47;
        }
        // 0x00B30868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
        label_47:
        // 0x00B3086C: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B30870: LDR x8, [x8, #0x7c0]       | X8 = 1152921515153206224;               
        // 0x00B30874: MOV x0, x21                | X0 = this.addDataDic;//m1               
        // 0x00B30878: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B3087C: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<FileInfoRes> System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::get_Item(System.Int32 key);
        // 0x00B30880: BL #0x24144f0              | X0 = this.addDataDic.get_Item(key:  this.adddownIndex);
        System.Collections.Generic.List<FileInfoRes> val_28 = this.addDataDic.Item[this.adddownIndex];
        // 0x00B30884: CBZ x0, #0xb308d4          | if (val_28 == null) goto label_48;      
        if(val_28 == null)
        {
            goto label_48;
        }
        // 0x00B30888: LDR x21, [x19, #0x78]      | X21 = this.addDataDic; //P2             
        // 0x00B3088C: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B30890: CBNZ x21, #0xb30898        | if (this.addDataDic != null) goto label_49;
        if(this.addDataDic != null)
        {
            goto label_49;
        }
        // 0x00B30894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_49:
        // 0x00B30898: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00B3089C: LDR x8, [x8, #0x7c0]       | X8 = 1152921515153206224;               
        // 0x00B308A0: MOV x0, x21                | X0 = this.addDataDic;//m1               
        // 0x00B308A4: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B308A8: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<FileInfoRes> System.Collections.Generic.Dictionary<System.Int32, System.Collections.Generic.List<FileInfoRes>>::get_Item(System.Int32 key);
        // 0x00B308AC: BL #0x24144f0              | X0 = this.addDataDic.get_Item(key:  this.adddownIndex);
        System.Collections.Generic.List<FileInfoRes> val_29 = this.addDataDic.Item[this.adddownIndex];
        // 0x00B308B0: MOV x21, x0                | X21 = val_29;//m1                       
        // 0x00B308B4: CBNZ x21, #0xb308bc        | if (val_29 != null) goto label_50;      
        if(val_29 != null)
        {
            goto label_50;
        }
        // 0x00B308B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
        label_50:
        // 0x00B308BC: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B308C0: LDR x8, [x8, #0x5d8]       | X8 = 1152921514959024432;               
        // 0x00B308C4: MOV x0, x21                | X0 = val_29;//m1                        
        // 0x00B308C8: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<FileInfoRes>::get_Count();
        // 0x00B308CC: BL #0x25ed72c              | X0 = val_29.get_Count();                
        int val_30 = val_29.Count;
        // 0x00B308D0: CBNZ w0, #0xb30a14         | if (val_30 != 0) goto label_51;         
        if(val_30 != 0)
        {
            goto label_51;
        }
        label_48:
        // 0x00B308D4: LDR x21, [x19, #0x68]      | X21 = this.downFinishCallDic; //P2      
        // 0x00B308D8: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B308DC: CBNZ x21, #0xb308e4        | if (this.downFinishCallDic != null) goto label_52;
        if(this.downFinishCallDic != null)
        {
            goto label_52;
        }
        // 0x00B308E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_52:
        // 0x00B308E4: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00B308E8: LDR x8, [x8, #0x848]       | X8 = 1152921515153283024;               
        // 0x00B308EC: MOV x0, x21                | X0 = this.downFinishCallDic;//m1        
        // 0x00B308F0: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B308F4: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, SetBytes>::ContainsKey(System.Int32 key);
        // 0x00B308F8: BL #0x2415bdc              | X0 = this.downFinishCallDic.ContainsKey(key:  this.adddownIndex);
        bool val_31 = this.downFinishCallDic.ContainsKey(key:  this.adddownIndex);
        // 0x00B308FC: TBZ w0, #0, #0xb30a08      | if (val_31 == false) goto label_53;     
        if(val_31 == false)
        {
            goto label_53;
        }
        // 0x00B30900: LDR x21, [x19, #0x68]      | X21 = this.downFinishCallDic; //P2      
        // 0x00B30904: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B30908: CBNZ x21, #0xb30910        | if (this.downFinishCallDic != null) goto label_54;
        if(this.downFinishCallDic != null)
        {
            goto label_54;
        }
        // 0x00B3090C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_54:
        // 0x00B30910: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x00B30914: LDR x8, [x8, #0xd30]       | X8 = 1152921515153288144;               
        // 0x00B30918: MOV x0, x21                | X0 = this.downFinishCallDic;//m1        
        // 0x00B3091C: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B30920: LDR x2, [x8]               | X2 = public SetBytes System.Collections.Generic.Dictionary<System.Int32, SetBytes>::get_Item(System.Int32 key);
        // 0x00B30924: BL #0x24144f0              | X0 = this.downFinishCallDic.get_Item(key:  this.adddownIndex);
        SetBytes val_32 = this.downFinishCallDic.Item[this.adddownIndex];
        // 0x00B30928: LDP x22, x23, [x19, #0x20] | X22 = this.updateDic; //P2  X23 = this.wwwGroups; //P2  //  | 
        // 0x00B3092C: MOV x21, x0                | X21 = val_32;//m1                       
        // 0x00B30930: CBNZ x23, #0xb30938        | if (this.wwwGroups != null) goto label_55;
        if(this.wwwGroups != null)
        {
            goto label_55;
        }
        // 0x00B30934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_55:
        // 0x00B30938: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B3093C: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B30940: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30944: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_33 = this.wwwGroups.Item[0];
        // 0x00B30948: MOV x23, x0                | X23 = val_33;//m1                       
        // 0x00B3094C: CBNZ x23, #0xb30954        | if (val_33 != null) goto label_56;      
        if(val_33 != null)
        {
            goto label_56;
        }
        // 0x00B30950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
        label_56:
        // 0x00B30954: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30958: MOV x0, x23                | X0 = val_33;//m1                        
        // 0x00B3095C: BL #0xabe980               | X0 = val_33.get_url();                  
        string val_34 = val_33.url;
        // 0x00B30960: MOV x23, x0                | X23 = val_34;//m1                       
        // 0x00B30964: CBNZ x22, #0xb3096c        | if (this.updateDic != null) goto label_57;
        if(this.updateDic != null)
        {
            goto label_57;
        }
        // 0x00B30968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_57:
        // 0x00B3096C: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B30970: MOV x0, x22                | X0 = this.updateDic;//m1                
        // 0x00B30974: MOV x1, x23                | X1 = val_34;//m1                        
        // 0x00B30978: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_34);
        FileInfoRes val_35 = this.updateDic.Item[val_34];
        // 0x00B3097C: MOV x22, x0                | X22 = val_35;//m1                       
        // 0x00B30980: CBNZ x22, #0xb30988        | if (val_35 != null) goto label_58;      
        if(val_35 != null)
        {
            goto label_58;
        }
        // 0x00B30984: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_58:
        // 0x00B30988: LDR x22, [x22, #0x10]      | 
        // 0x00B3098C: LDR x23, [x19, #0x28]      | X23 = this.wwwGroups; //P2              
        // 0x00B30990: CBNZ x23, #0xb30998        | if (this.wwwGroups != null) goto label_59;
        if(this.wwwGroups != null)
        {
            goto label_59;
        }
        // 0x00B30994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_59:
        // 0x00B30998: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B3099C: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B309A0: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B309A4: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_36 = this.wwwGroups.Item[0];
        // 0x00B309A8: MOV x23, x0                | X23 = val_36;//m1                       
        // 0x00B309AC: CBNZ x23, #0xb309b4        | if (val_36 != null) goto label_60;      
        if(val_36 != null)
        {
            goto label_60;
        }
        // 0x00B309B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_60:
        // 0x00B309B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B309B8: MOV x0, x23                | X0 = val_36;//m1                        
        // 0x00B309BC: BL #0xabed30               | X0 = val_36.get_bytes();                
        System.Byte[] val_37 = val_36.bytes;
        // 0x00B309C0: MOV x23, x0                | X23 = val_37;//m1                       
        // 0x00B309C4: CBNZ x21, #0xb309cc        | if (val_32 != null) goto label_61;      
        if(val_32 != null)
        {
            goto label_61;
        }
        // 0x00B309C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_61:
        // 0x00B309CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B309D0: MOV x0, x21                | X0 = val_32;//m1                        
        // 0x00B309D4: MOV x1, x22                | X1 = val_35;//m1                        
        // 0x00B309D8: MOV x2, x23                | X2 = val_37;//m1                        
        // 0x00B309DC: BL #0xb31a18               | val_32.Invoke(key:  val_35, ab:  val_37);
        val_32.Invoke(key:  val_35, ab:  val_37);
        // 0x00B309E0: LDR x21, [x19, #0x68]      | X21 = this.downFinishCallDic; //P2      
        // 0x00B309E4: LDR w22, [x19, #0x84]      | W22 = this.adddownIndex; //P2           
        // 0x00B309E8: CBNZ x21, #0xb309f0        | if (this.downFinishCallDic != null) goto label_62;
        if(this.downFinishCallDic != null)
        {
            goto label_62;
        }
        // 0x00B309EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_62:
        // 0x00B309F0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B309F4: LDR x8, [x8, #0xb08]       | X8 = 1152921515153362896;               
        // 0x00B309F8: MOV x0, x21                | X0 = this.downFinishCallDic;//m1        
        // 0x00B309FC: MOV w1, w22                | W1 = this.adddownIndex;//m1             
        // 0x00B30A00: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, SetBytes>::Remove(System.Int32 key);
        // 0x00B30A04: BL #0x24164fc              | X0 = this.downFinishCallDic.Remove(key:  this.adddownIndex);
        bool val_38 = this.downFinishCallDic.Remove(key:  this.adddownIndex);
        label_53:
        // 0x00B30A08: LDR w8, [x19, #0x84]       | W8 = this.adddownIndex; //P2            
        int val_143 = this.adddownIndex;
        // 0x00B30A0C: ADD w8, w8, #1             | W8 = (this.adddownIndex + 1);           
        val_143 = val_143 + 1;
        // 0x00B30A10: STR w8, [x19, #0x84]       | this.adddownIndex = (this.adddownIndex + 1);  //  dest_result_addr=1152921515154059012
        this.adddownIndex = val_143;
        label_51:
        // 0x00B30A14: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B30A18: CBNZ x21, #0xb30a20        | if (this.wwwGroups != null) goto label_63;
        if(this.wwwGroups != null)
        {
            goto label_63;
        }
        // 0x00B30A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
        label_63:
        // 0x00B30A20: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30A24: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B30A28: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30A2C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_39 = this.wwwGroups.Item[0];
        // 0x00B30A30: MOV x21, x0                | X21 = val_39;//m1                       
        // 0x00B30A34: CBNZ x21, #0xb30a3c        | if (val_39 != null) goto label_64;      
        if(val_39 != null)
        {
            goto label_64;
        }
        // 0x00B30A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_64:
        // 0x00B30A3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30A40: MOV x0, x21                | X0 = val_39;//m1                        
        // 0x00B30A44: BL #0xabe980               | X0 = val_39.get_url();                  
        string val_40 = val_39.url;
        // 0x00B30A48: MOV x21, x0                | X21 = val_40;//m1                       
        // 0x00B30A4C: STR x21, [x19, #0xa0]      | this.errorUrl = val_40;                  //  dest_result_addr=1152921515154059040
        this.errorUrl = val_40;
        // 0x00B30A50: CBNZ x21, #0xb30a58        | if (val_40 != null) goto label_65;      
        if(val_40 != null)
        {
            goto label_65;
        }
        // 0x00B30A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_65:
        // 0x00B30A58: LDR x1, [x25]              | X1 = "?";                               
        // 0x00B30A5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30A60: MOV x0, x21                | X0 = val_40;//m1                        
        // 0x00B30A64: BL #0x18ad1e4              | X0 = val_40.LastIndexOf(value:  "?");   
        int val_41 = val_40.LastIndexOf(value:  "?");
        // 0x00B30A68: LDR x21, [x19, #0xa0]      | X21 = this.errorUrl; //P2               
        val_145 = this.errorUrl;
        // 0x00B30A6C: CMP w0, #1                 | STATE = COMPARE(val_41, 0x1)            
        // 0x00B30A70: B.LT #0xb30e9c             | if (val_41 < 1) goto label_66;          
        if(val_41 < 1)
        {
            goto label_66;
        }
        // 0x00B30A74: CBZ x21, #0xb30e64         | if (this.errorUrl == null) goto label_67;
        if(val_145 == null)
        {
            goto label_67;
        }
        // 0x00B30A78: LDR x1, [x25]              | X1 = "?";                               
        // 0x00B30A7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30A80: MOV x0, x21                | X0 = this.errorUrl;//m1                 
        // 0x00B30A84: BL #0x18ad1e4              | X0 = this.errorUrl.LastIndexOf(value:  "?");
        int val_42 = val_145.LastIndexOf(value:  "?");
        // 0x00B30A88: MOV w22, w0                | W22 = val_42;//m1                       
        val_146 = val_42;
        // 0x00B30A8C: B #0xb30e80                |  goto label_68;                         
        goto label_68;
        label_25:
        // 0x00B30A90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B30A94: LDR x1, [x25]              | X1 = "?";                               
        // 0x00B30A98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30A9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30AA0: BL #0x18ad1e4              | X0 = 0.LastIndexOf(value:  "?");        
        int val_43 = 0.LastIndexOf(value:  "?");
        // 0x00B30AA4: MOV w23, w0                | W23 = val_43;//m1                       
        val_143 = val_43;
        // 0x00B30AA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_26:
        // 0x00B30AAC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B30AB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30AB4: MOV x0, x22                | X0 = this.errorUrl;//m1                 
        // 0x00B30AB8: MOV w2, w23                | W2 = val_43;//m1                        
        // 0x00B30ABC: BL #0x18a920c              | X0 = this.errorUrl.Substring(startIndex:  0, length:  val_143);
        string val_44 = val_142.Substring(startIndex:  0, length:  val_143);
        // 0x00B30AC0: MOV x22, x0                | X22 = val_44;//m1                       
        val_142 = val_44;
        // 0x00B30AC4: STR x22, [x19, #0xa0]      | this.errorUrl = val_44;                  //  dest_result_addr=1152921515154059040
        this.errorUrl = val_142;
        label_24:
        // 0x00B30AC8: LDR x23, [x19, #0x98]      | X23 = this.errorDownFiles; //P2         
        // 0x00B30ACC: CBNZ x23, #0xb30ad4        | if (this.errorDownFiles != null) goto label_69;
        if(this.errorDownFiles != null)
        {
            goto label_69;
        }
        // 0x00B30AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_69:
        // 0x00B30AD4: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00B30AD8: LDR x8, [x8, #0x10]        | X8 = 1152921510807693968;               
        // 0x00B30ADC: MOV x0, x23                | X0 = this.errorDownFiles;//m1           
        // 0x00B30AE0: MOV x1, x22                | X1 = val_44;//m1                        
        // 0x00B30AE4: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::ContainsKey(System.String key);
        // 0x00B30AE8: BL #0x23f582c              | X0 = this.errorDownFiles.ContainsKey(key:  val_142);
        bool val_45 = this.errorDownFiles.ContainsKey(key:  val_142);
        // 0x00B30AEC: LDP x23, x22, [x19, #0x98] | X23 = this.errorDownFiles; //P2  X22 = this.errorUrl; //P2  //  | 
        val_147 = this.errorDownFiles;
        // 0x00B30AF0: TBZ w0, #0, #0xb30b18      | if (val_45 == false) goto label_70;     
        if(val_45 == false)
        {
            goto label_70;
        }
        // 0x00B30AF4: CBZ x23, #0xb30b40         | if (this.errorDownFiles == null) goto label_71;
        if(val_147 == null)
        {
            goto label_71;
        }
        // 0x00B30AF8: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B30AFC: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
        // 0x00B30B00: MOV x0, x23                | X0 = this.errorDownFiles;//m1           
        // 0x00B30B04: MOV x1, x22                | X1 = this.errorUrl;//m1                 
        // 0x00B30B08: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
        // 0x00B30B0C: BL #0x23f40a8              | X0 = this.errorDownFiles.get_Item(key:  this.errorUrl);
        int val_46 = val_147.Item[this.errorUrl];
        // 0x00B30B10: MOV w24, w0                | W24 = val_46;//m1                       
        val_148 = val_46;
        // 0x00B30B14: B #0xb30b68                |  goto label_72;                         
        goto label_72;
        label_70:
        // 0x00B30B18: CBNZ x23, #0xb30b20        | if (this.errorDownFiles != null) goto label_73;
        if(val_147 != null)
        {
            goto label_73;
        }
        // 0x00B30B1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_73:
        // 0x00B30B20: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x00B30B24: LDR x8, [x8, #0xfb0]       | X8 = 1152921509743365200;               
        // 0x00B30B28: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B30B2C: MOV x0, x23                | X0 = this.errorDownFiles;//m1           
        // 0x00B30B30: MOV x1, x22                | X1 = this.errorUrl;//m1                 
        // 0x00B30B34: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::Add(System.String key, System.Int32 value);
        // 0x00B30B38: BL #0x23f5288              | this.errorDownFiles.Add(key:  this.errorUrl, value:  1);
        val_147.Add(key:  this.errorUrl, value:  1);
        // 0x00B30B3C: B #0xb30b84                |  goto label_74;                         
        goto label_74;
        label_71:
        // 0x00B30B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        // 0x00B30B44: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B30B48: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
        // 0x00B30B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30B50: MOV x1, x22                | X1 = this.errorUrl;//m1                 
        // 0x00B30B54: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
        // 0x00B30B58: BL #0x23f40a8              | X0 = 0.get_Item(key:  this.errorUrl);   
        int val_47 = 0.Item[this.errorUrl];
        // 0x00B30B5C: MOV w24, w0                | W24 = val_47;//m1                       
        val_148 = val_47;
        // 0x00B30B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        // 0x00B30B64: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_147 = 0;
        label_72:
        // 0x00B30B68: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B30B6C: LDR x8, [x8, #0x6b0]       | X8 = 1152921510000499136;               
        // 0x00B30B70: ADD w2, w24, #1            | W2 = (val_47 + 1);                      
        int val_48 = val_148 + 1;
        // 0x00B30B74: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B30B78: MOV x1, x22                | X1 = this.errorUrl;//m1                 
        // 0x00B30B7C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::set_Item(System.String key, System.Int32 value);
        // 0x00B30B80: BL #0x23f4398              | val_147.set_Item(key:  this.errorUrl, value:  int val_48 = val_148 + 1);
        val_147.set_Item(key:  this.errorUrl, value:  val_48);
        label_74:
        // 0x00B30B84: LDR x22, [x19, #0x28]      | X22 = this.wwwGroups; //P2              
        // 0x00B30B88: CBNZ x22, #0xb30b90        | if (this.wwwGroups != null) goto label_75;
        if(this.wwwGroups != null)
        {
            goto label_75;
        }
        // 0x00B30B8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_75:
        // 0x00B30B90: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30B94: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30B98: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30B9C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_49 = this.wwwGroups.Item[0];
        // 0x00B30BA0: MOV x22, x0                | X22 = val_49;//m1                       
        // 0x00B30BA4: CBNZ x22, #0xb30bac        | if (val_49 != null) goto label_76;      
        if(val_49 != null)
        {
            goto label_76;
        }
        // 0x00B30BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_76:
        // 0x00B30BAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30BB0: MOV x0, x22                | X0 = val_49;//m1                        
        // 0x00B30BB4: BL #0xabe8e8               | X0 = val_49.get_error();                
        string val_50 = val_49.error;
        // 0x00B30BB8: LDR x8, [x28]              | X8 = typeof(System.String);             
        // 0x00B30BBC: MOV x22, x0                | X22 = val_50;//m1                       
        // 0x00B30BC0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B30BC4: TBZ w9, #0, #0xb30bd8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_78;
        // 0x00B30BC8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B30BCC: CBNZ w9, #0xb30bd8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_78;
        // 0x00B30BD0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B30BD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_78:
        // 0x00B30BD8: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00B30BDC: LDR x8, [x8, #0x7b0]       | X8 = (string**)(1152921514969354720)("timeout...");
        // 0x00B30BE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30BE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30BE8: MOV x1, x22                | X1 = val_50;//m1                        
        // 0x00B30BEC: LDR x2, [x8]               | X2 = "timeout...";                      
        // 0x00B30BF0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_50);
        bool val_51 = System.String.op_Equality(a:  0, b:  val_50);
        // 0x00B30BF4: AND w8, w0, #1             | W8 = (val_51 & 1);                      
        bool val_52 = val_51;
        // 0x00B30BF8: TBNZ w8, #0, #0xb30c40     | if ((val_51 & 1) == true) goto label_79;
        if(val_52 == true)
        {
            goto label_79;
        }
        // 0x00B30BFC: LDP x22, x23, [x19, #0x98] | X22 = this.errorDownFiles; //P2  X23 = this.errorUrl; //P2  //  | 
        // 0x00B30C00: CBNZ x22, #0xb30c08        | if (this.errorDownFiles != null) goto label_80;
        if(this.errorDownFiles != null)
        {
            goto label_80;
        }
        // 0x00B30C04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
        label_80:
        // 0x00B30C08: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B30C0C: LDR x8, [x8, #0xeb0]       | X8 = 1152921510808082832;               
        // 0x00B30C10: MOV x0, x22                | X0 = this.errorDownFiles;//m1           
        // 0x00B30C14: MOV x1, x23                | X1 = this.errorUrl;//m1                 
        // 0x00B30C18: LDR x2, [x8]               | X2 = public System.Int32 System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Item(System.String key);
        // 0x00B30C1C: BL #0x23f40a8              | X0 = this.errorDownFiles.get_Item(key:  this.errorUrl);
        int val_53 = this.errorDownFiles.Item[this.errorUrl];
        // 0x00B30C20: LDR w8, [x19, #0x48]       | W8 = this.MAXDOWNERROR; //P2            
        // 0x00B30C24: CMP w0, w8                 | STATE = COMPARE(val_53, this.MAXDOWNERROR)
        // 0x00B30C28: B.LT #0xb30ca0             | if (val_53 < this.MAXDOWNERROR) goto label_82;
        if(val_53 < this.MAXDOWNERROR)
        {
            goto label_82;
        }
        // 0x00B30C2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30C30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30C34: BL #0x2691214              | X0 = UnityEngine.Time.get_realtimeSinceStartup();
        float val_54 = UnityEngine.Time.realtimeSinceStartup;
        // 0x00B30C38: FCMP s0, s8                | STATE = COMPARE(val_54, 15)             
        // 0x00B30C3C: B.LE #0xb30ca0             | if (val_54 <= 15f) goto label_82;       
        if(val_54 <= 15f)
        {
            goto label_82;
        }
        label_79:
        // 0x00B30C40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30C44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30C48: STRB wzr, [x19, #0xa8]     | this.CanDownFile = false;                //  dest_result_addr=1152921515154059048
        this.CanDownFile = false;
        // 0x00B30C4C: BL #0xdbd3cc               | X0 = LoadingBoardMgr.get_Instance();    
        LoadingBoardMgr val_55 = LoadingBoardMgr.Instance;
        // 0x00B30C50: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x00B30C54: LDR x8, [x8, #0x70]        | X8 = 1152921515153421264;               
        // 0x00B30C58: MOV x22, x0                | X22 = val_55;//m1                       
        // 0x00B30C5C: LDR x24, [x8]              | X24 = System.Void AssetDownMgr::<ZUpdate>m__0();
        // 0x00B30C60: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00B30C64: LDR x8, [x8, #0xbe0]       | X8 = 1152921504687837184;               
        // 0x00B30C68: LDR x8, [x8]               | X8 = typeof(System.Action);             
        // 0x00B30C6C: MOV x0, x8                 | X0 = 1152921504687837184 (0x1000000004D3D000);//ML01
        System.Action val_56 = null;
        // 0x00B30C70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B30C74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30C78: MOV x1, x19                | X1 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B30C7C: MOV x2, x24                | X2 = 1152921515153421264 (0x10000002749FF3D0);//ML01
        // 0x00B30C80: MOV x23, x0                | X23 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B30C84: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void AssetDownMgr::<ZUpdate>m__0());
        val_56 = new System.Action(object:  this, method:  System.Void AssetDownMgr::<ZUpdate>m__0());
        // 0x00B30C88: CBNZ x22, #0xb30c90        | if (val_55 != null) goto label_83;      
        if(val_55 != null)
        {
            goto label_83;
        }
        // 0x00B30C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void AssetDownMgr::<ZUpdate>m__0()), ????);
        label_83:
        // 0x00B30C90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30C94: MOV x0, x22                | X0 = val_55;//m1                        
        // 0x00B30C98: MOV x1, x23                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B30C9C: BL #0xdbda0c               | val_55.OpenDialog(call:  val_56);       
        val_55.OpenDialog(call:  val_56);
        label_82:
        // 0x00B30CA0: LDR x22, [x19, #0x28]      | X22 = this.wwwGroups; //P2              
        // 0x00B30CA4: CBNZ x22, #0xb30cac        | if (this.wwwGroups != null) goto label_84;
        if(this.wwwGroups != null)
        {
            goto label_84;
        }
        // 0x00B30CA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_84:
        // 0x00B30CAC: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30CB0: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30CB4: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30CB8: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_57 = this.wwwGroups.Item[0];
        // 0x00B30CBC: MOV x22, x0                | X22 = val_57;//m1                       
        // 0x00B30CC0: CBNZ x22, #0xb30cc8        | if (val_57 != null) goto label_85;      
        if(val_57 != null)
        {
            goto label_85;
        }
        // 0x00B30CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
        label_85:
        // 0x00B30CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30CCC: MOV x0, x22                | X0 = val_57;//m1                        
        // 0x00B30CD0: BL #0xabeb78               | val_57.Dispose();                       
        val_57.Dispose();
        // 0x00B30CD4: LDR x22, [x19, #0x28]      | X22 = this.wwwGroups; //P2              
        // 0x00B30CD8: CBNZ x22, #0xb30ce0        | if (this.wwwGroups != null) goto label_86;
        if(this.wwwGroups != null)
        {
            goto label_86;
        }
        // 0x00B30CDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
        label_86:
        // 0x00B30CE0: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
        // 0x00B30CE4: LDR x8, [x8, #0x6f0]       | X8 = 1152921514964672640;               
        // 0x00B30CE8: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30CEC: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30CF0: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Net.UrlLoader>::RemoveAt(int index);
        // 0x00B30CF4: BL #0x25ed00c              | this.wwwGroups.RemoveAt(index:  0);     
        this.wwwGroups.RemoveAt(index:  0);
        // 0x00B30CF8: LDR x22, [x19, #0xa0]      | X22 = this.errorUrl; //P2               
        // 0x00B30CFC: BL #0xb301c8               | X0 = AssetDownMgr.get_GetMinutes();     
        long val_58 = AssetDownMgr.GetMinutes;
        // 0x00B30D00: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B30D04: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
        // 0x00B30D08: STR x0, [sp, #8]           | stack[1152921515154046760] = val_58;     //  dest_result_addr=1152921515154046760
        // 0x00B30D0C: ADD x1, sp, #8             | X1 = (1152921515154046752 + 8) = 1152921515154046760 (0x1000000274A97F28);
        // 0x00B30D10: LDR x8, [x8]               | X8 = typeof(System.Int64);              
        // 0x00B30D14: MOV x0, x8                 | X0 = 1152921504607592448 (0x10000000000B6000);//ML01
        // 0x00B30D18: BL #0x27bc028              | X0 = 1152921515154410368 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), val_58);
        // 0x00B30D1C: LDR x8, [x28]              | X8 = typeof(System.String);             
        // 0x00B30D20: MOV x23, x0                | X23 = 1152921515154410368 (0x1000000274AF0B80);//ML01
        // 0x00B30D24: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B30D28: TBZ w9, #0, #0xb30d3c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_88;
        // 0x00B30D2C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B30D30: CBNZ w9, #0xb30d3c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_88;
        // 0x00B30D34: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B30D38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_88:
        // 0x00B30D3C: LDR x2, [x25]              | X2 = "?";                               
        // 0x00B30D40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30D44: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B30D48: MOV x1, x22                | X1 = this.errorUrl;//m1                 
        // 0x00B30D4C: MOV x3, x23                | X3 = 1152921515154410368 (0x1000000274AF0B80);//ML01
        // 0x00B30D50: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  this.errorUrl, arg2:  "?");
        string val_59 = System.String.Concat(arg0:  0, arg1:  this.errorUrl, arg2:  "?");
        // 0x00B30D54: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00B30D58: LDR x23, [x19, #0x28]      | X23 = this.wwwGroups; //P2              
        val_150 = this.wwwGroups;
        // 0x00B30D5C: LDR x8, [x8, #0xc98]       | X8 = 1152921504903864320;               
        // 0x00B30D60: MOV x22, x0                | X22 = val_59;//m1                       
        // 0x00B30D64: LDR x8, [x8]               | X8 = typeof(Mihua.Net.UrlLoader);       
        // 0x00B30D68: MOV x0, x8                 | X0 = 1152921504903864320 (0x1000000011B42000);//ML01
        Mihua.Net.UrlLoader val_60 = null;
        // 0x00B30D6C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Net.UrlLoader), ????);
        // 0x00B30D70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30D74: MOV x1, x22                | X1 = val_59;//m1                        
        // 0x00B30D78: MOV x24, x0                | X24 = 1152921504903864320 (0x1000000011B42000);//ML01
        // 0x00B30D7C: BL #0xabda64               | .ctor(url:  val_59);                    
        val_60 = new Mihua.Net.UrlLoader(url:  val_59);
        // 0x00B30D80: CBNZ x23, #0xb30d88        | if (this.wwwGroups != null) goto label_89;
        if(val_150 != null)
        {
            goto label_89;
        }
        // 0x00B30D84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(url:  val_59), ????);
        label_89:
        // 0x00B30D88: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B30D8C: LDR x8, [x8, #0x280]       | X8 = 1152921514964362496;               
        // 0x00B30D90: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B30D94: MOV x1, x24                | X1 = 1152921504903864320 (0x1000000011B42000);//ML01
        // 0x00B30D98: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Net.UrlLoader>::Add(Mihua.Net.UrlLoader item);
        // 0x00B30D9C: BL #0x25ea480              | this.wwwGroups.Add(item:  val_60);      
        val_150.Add(item:  val_60);
        // 0x00B30DA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30DA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30DA8: MOV x1, x22                | X1 = val_59;//m1                        
        // 0x00B30DAC: MOV x2, x21                | X2 = val_9;//m1                         
        // 0x00B30DB0: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_59);
        bool val_61 = System.String.op_Inequality(a:  0, b:  val_59);
        // 0x00B30DB4: TBZ w0, #0, #0xb30e38      | if (val_61 == false) goto label_197;    
        if(val_61 == false)
        {
            goto label_197;
        }
        // 0x00B30DB8: LDR x23, [x19, #0x20]      | X23 = this.updateDic; //P2              
        val_150 = this.updateDic;
        // 0x00B30DBC: CBZ x23, #0xb30dd8         | if (this.updateDic == null) goto label_91;
        if(val_150 == null)
        {
            goto label_91;
        }
        // 0x00B30DC0: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B30DC4: MOV x0, x23                | X0 = this.updateDic;//m1                
        // 0x00B30DC8: MOV x1, x21                | X1 = val_9;//m1                         
        // 0x00B30DCC: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_9);
        FileInfoRes val_62 = val_150.Item[val_9];
        // 0x00B30DD0: MOV x24, x0                | X24 = val_62;//m1                       
        val_151 = val_62;
        // 0x00B30DD4: B #0xb30df8                |  goto label_92;                         
        goto label_92;
        label_91:
        // 0x00B30DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        // 0x00B30DDC: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B30DE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30DE4: MOV x1, x21                | X1 = val_9;//m1                         
        // 0x00B30DE8: BL #0x23fc26c              | X0 = 0.get_Item(key:  val_9);           
        FileInfoRes val_63 = 0.Item[val_9];
        // 0x00B30DEC: MOV x24, x0                | X24 = val_63;//m1                       
        val_151 = val_63;
        // 0x00B30DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
        // 0x00B30DF4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_150 = 0;
        label_92:
        // 0x00B30DF8: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00B30DFC: LDR x8, [x8, #0xd20]       | X8 = 1152921514959026480;               
        // 0x00B30E00: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B30E04: MOV x1, x22                | X1 = val_59;//m1                        
        // 0x00B30E08: MOV x2, x24                | X2 = val_63;//m1                        
        // 0x00B30E0C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Add(System.String key, FileInfoRes value);
        // 0x00B30E10: BL #0x23fd44c              | val_150.Add(key:  val_59, value:  val_151);
        val_150.Add(key:  val_59, value:  val_151);
        // 0x00B30E14: LDR x22, [x19, #0x20]      | X22 = this.updateDic; //P2              
        // 0x00B30E18: CBNZ x22, #0xb30e20        | if (this.updateDic != null) goto label_93;
        if(this.updateDic != null)
        {
            goto label_93;
        }
        // 0x00B30E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_93:
        // 0x00B30E20: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00B30E24: LDR x8, [x8, #0xd08]       | X8 = 1152921515153467344;               
        // 0x00B30E28: MOV x0, x22                | X0 = this.updateDic;//m1                
        // 0x00B30E2C: MOV x1, x21                | X1 = val_9;//m1                         
        // 0x00B30E30: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Remove(System.String key);
        // 0x00B30E34: BL #0x23fe354              | X0 = this.updateDic.Remove(key:  val_9);
        bool val_64 = this.updateDic.Remove(key:  val_9);
        label_197:
        // 0x00B30E38: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B30E3C: CBNZ x21, #0xb30e44        | if (this.wwwGroups != null) goto label_94;
        if(this.wwwGroups != null)
        {
            goto label_94;
        }
        // 0x00B30E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_94:
        // 0x00B30E44: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B30E48: LDR x8, [x8, #0xe90]       | X8 = 1152921514964866176;               
        // 0x00B30E4C: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B30E50: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Count();
        // 0x00B30E54: BL #0x25ed72c              | X0 = this.wwwGroups.get_Count();        
        int val_65 = this.wwwGroups.Count;
        // 0x00B30E58: CMP w20, w0                | STATE = COMPARE(0x0, val_65)            
        // 0x00B30E5C: B.LT #0xb3041c             | if (0 < val_65) goto label_95;          
        if(0 < val_65)
        {
            goto label_95;
        }
        // 0x00B30E60: B #0xb317e4                |  goto label_96;                         
        goto label_96;
        label_67:
        // 0x00B30E64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        // 0x00B30E68: LDR x1, [x25]              | X1 = "?";                               
        // 0x00B30E6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30E70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B30E74: BL #0x18ad1e4              | X0 = 0.LastIndexOf(value:  "?");        
        int val_66 = 0.LastIndexOf(value:  "?");
        // 0x00B30E78: MOV w22, w0                | W22 = val_66;//m1                       
        val_146 = val_66;
        // 0x00B30E7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
        label_68:
        // 0x00B30E80: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B30E84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30E88: MOV x0, x21                | X0 = this.errorUrl;//m1                 
        // 0x00B30E8C: MOV w2, w22                | W2 = val_66;//m1                        
        // 0x00B30E90: BL #0x18a920c              | X0 = this.errorUrl.Substring(startIndex:  0, length:  val_146);
        string val_67 = val_145.Substring(startIndex:  0, length:  val_146);
        // 0x00B30E94: MOV x21, x0                | X21 = val_67;//m1                       
        val_145 = val_67;
        // 0x00B30E98: STR x21, [x19, #0xa0]      | this.errorUrl = val_67;                  //  dest_result_addr=1152921515154059040
        this.errorUrl = val_145;
        label_66:
        // 0x00B30E9C: LDR x22, [x19, #0x98]      | X22 = this.errorDownFiles; //P2         
        val_152 = this.errorDownFiles;
        // 0x00B30EA0: CBNZ x22, #0xb30ea8        | if (this.errorDownFiles != null) goto label_97;
        if(val_152 != null)
        {
            goto label_97;
        }
        // 0x00B30EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_67, ????);     
        label_97:
        // 0x00B30EA8: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00B30EAC: LDR x8, [x8, #0x10]        | X8 = 1152921510807693968;               
        // 0x00B30EB0: MOV x0, x22                | X0 = this.errorDownFiles;//m1           
        // 0x00B30EB4: MOV x1, x21                | X1 = val_67;//m1                        
        // 0x00B30EB8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::ContainsKey(System.String key);
        // 0x00B30EBC: BL #0x23f582c              | X0 = this.errorDownFiles.ContainsKey(key:  val_145);
        bool val_68 = val_152.ContainsKey(key:  val_145);
        // 0x00B30EC0: TBZ w0, #0, #0xb30ee8      | if (val_68 == false) goto label_98;     
        if(val_68 == false)
        {
            goto label_98;
        }
        // 0x00B30EC4: LDP x21, x22, [x19, #0x98] | X21 = this.errorDownFiles; //P2  X22 = this.errorUrl; //P2  //  | 
        val_152 = this.errorUrl;
        // 0x00B30EC8: CBNZ x21, #0xb30ed0        | if (this.errorDownFiles != null) goto label_99;
        if(this.errorDownFiles != null)
        {
            goto label_99;
        }
        // 0x00B30ECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
        label_99:
        // 0x00B30ED0: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
        // 0x00B30ED4: LDR x8, [x8, #0x848]       | X8 = 1152921510808642064;               
        // 0x00B30ED8: MOV x0, x21                | X0 = this.errorDownFiles;//m1           
        // 0x00B30EDC: MOV x1, x22                | X1 = this.errorUrl;//m1                 
        // 0x00B30EE0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Int32>::Remove(System.String key);
        // 0x00B30EE4: BL #0x23f6190              | X0 = this.errorDownFiles.Remove(key:  val_152);
        bool val_69 = this.errorDownFiles.Remove(key:  val_152);
        label_98:
        // 0x00B30EE8: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B30EEC: CBNZ x22, #0xb30ef4        | if (this.wwwGroups != null) goto label_100;
        if(this.wwwGroups != null)
        {
            goto label_100;
        }
        // 0x00B30EF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
        label_100:
        // 0x00B30EF4: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30EF8: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30EFC: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30F00: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_70 = this.wwwGroups.Item[0];
        // 0x00B30F04: MOV x22, x0                | X22 = val_70;//m1                       
        // 0x00B30F08: CBNZ x22, #0xb30f10        | if (val_70 != null) goto label_101;     
        if(val_70 != null)
        {
            goto label_101;
        }
        // 0x00B30F0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
        label_101:
        // 0x00B30F10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30F14: MOV x0, x22                | X0 = val_70;//m1                        
        // 0x00B30F18: BL #0xabe980               | X0 = val_70.get_url();                  
        string val_71 = val_70.url;
        // 0x00B30F1C: MOV x22, x0                | X22 = val_71;//m1                       
        val_153 = val_71;
        // 0x00B30F20: CBNZ x21, #0xb30f28        | if (this.updateDic != null) goto label_102;
        if(this.updateDic != null)
        {
            goto label_102;
        }
        // 0x00B30F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_71, ????);     
        label_102:
        // 0x00B30F28: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B30F2C: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B30F30: MOV x1, x22                | X1 = val_71;//m1                        
        // 0x00B30F34: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_153);
        FileInfoRes val_72 = this.updateDic.Item[val_153];
        // 0x00B30F38: MOV x21, x0                | X21 = val_72;//m1                       
        // 0x00B30F3C: CBNZ x21, #0xb30f44        | if (val_72 != null) goto label_103;     
        if(val_72 != null)
        {
            goto label_103;
        }
        // 0x00B30F40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_72, ????);     
        label_103:
        // 0x00B30F44: LDRB w8, [x21, #0x34]      | W8 = val_72.isWrite; //P2               
        // 0x00B30F48: CBNZ w8, #0xb314f4         | if (val_72.isWrite == true) goto label_136;
        if(val_72.isWrite == true)
        {
            goto label_136;
        }
        // 0x00B30F4C: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B30F50: CBNZ x22, #0xb30f58        | if (this.wwwGroups != null) goto label_105;
        if(this.wwwGroups != null)
        {
            goto label_105;
        }
        // 0x00B30F54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_72, ????);     
        label_105:
        // 0x00B30F58: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30F5C: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B30F60: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30F64: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_73 = this.wwwGroups.Item[0];
        // 0x00B30F68: MOV x22, x0                | X22 = val_73;//m1                       
        // 0x00B30F6C: CBNZ x22, #0xb30f74        | if (val_73 != null) goto label_106;     
        if(val_73 != null)
        {
            goto label_106;
        }
        // 0x00B30F70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
        label_106:
        // 0x00B30F74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B30F78: MOV x0, x22                | X0 = val_73;//m1                        
        // 0x00B30F7C: BL #0xabe980               | X0 = val_73.get_url();                  
        string val_74 = val_73.url;
        // 0x00B30F80: MOV x22, x0                | X22 = val_74;//m1                       
        // 0x00B30F84: CBNZ x21, #0xb30f8c        | if (this.updateDic != null) goto label_107;
        if(this.updateDic != null)
        {
            goto label_107;
        }
        // 0x00B30F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
        label_107:
        // 0x00B30F8C: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B30F90: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B30F94: MOV x1, x22                | X1 = val_74;//m1                        
        // 0x00B30F98: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_74);
        FileInfoRes val_75 = this.updateDic.Item[val_74];
        // 0x00B30F9C: MOV x21, x0                | X21 = val_75;//m1                       
        // 0x00B30FA0: CBNZ x21, #0xb30fa8        | if (val_75 != null) goto label_108;     
        if(val_75 != null)
        {
            goto label_108;
        }
        // 0x00B30FA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_75, ????);     
        label_108:
        // 0x00B30FA8: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x00B30FAC: LDR x21, [x21, #0x10]      | 
        // 0x00B30FB0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B30FB4: TBZ w8, #0, #0xb30fc4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_110;
        // 0x00B30FB8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B30FBC: CBNZ w8, #0xb30fc4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_110;
        // 0x00B30FC0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_110:
        // 0x00B30FC4: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00B30FC8: LDR x8, [x8, #0xa88]       | X8 = (string**)(1152921515142011008)("csscript.uab");
        // 0x00B30FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B30FD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B30FD4: MOV x1, x21                | X1 = val_75;//m1                        
        // 0x00B30FD8: LDR x2, [x8]               | X2 = "csscript.uab";                    
        // 0x00B30FDC: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_75);
        bool val_76 = System.String.op_Equality(a:  0, b:  val_75);
        // 0x00B30FE0: TBZ w0, #0, #0xb310f0      | if (val_76 == false) goto label_111;    
        if(val_76 == false)
        {
            goto label_111;
        }
        // 0x00B30FE4: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B30FE8: CBNZ x21, #0xb30ff0        | if (this.wwwGroups != null) goto label_112;
        if(this.wwwGroups != null)
        {
            goto label_112;
        }
        // 0x00B30FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_112:
        // 0x00B30FF0: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B30FF4: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B30FF8: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B30FFC: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_77 = this.wwwGroups.Item[0];
        // 0x00B31000: MOV x21, x0                | X21 = val_77;//m1                       
        // 0x00B31004: CBNZ x21, #0xb3100c        | if (val_77 != null) goto label_113;     
        if(val_77 != null)
        {
            goto label_113;
        }
        // 0x00B31008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
        label_113:
        // 0x00B3100C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31010: MOV x0, x21                | X0 = val_77;//m1                        
        // 0x00B31014: BL #0xac0bfc               | X0 = val_77.get_assetBundle();          
        UnityEngine.AssetBundle val_78 = val_77.assetBundle;
        // 0x00B31018: MOV x21, x0                | X21 = val_78;//m1                       
        // 0x00B3101C: CBNZ x21, #0xb31024        | if (val_78 != null) goto label_114;     
        if(val_78 != null)
        {
            goto label_114;
        }
        // 0x00B31020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
        label_114:
        // 0x00B31024: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00B31028: LDR x8, [x8, #0x278]       | X8 = 1152921515153542096;               
        // 0x00B3102C: MOV x0, x21                | X0 = val_78;//m1                        
        // 0x00B31030: LDR x1, [x8]               | X1 = public T[] UnityEngine.AssetBundle::LoadAllAssets<UnityEngine.TextAsset>();
        // 0x00B31034: BL #0x23d89f8              | X0 = val_78.LoadAllAssets<UnityEngine.TextAsset>();
        T[] val_79 = val_78.LoadAllAssets<UnityEngine.TextAsset>();
        // 0x00B31038: MOV x22, x0                | X22 = val_79;//m1                       
        // 0x00B3103C: CBNZ x22, #0xb31044        | if (val_79 != null) goto label_115;     
        if(val_79 != null)
        {
            goto label_115;
        }
        // 0x00B31040: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_79, ????);     
        label_115:
        // 0x00B31044: LDR w8, [x22, #0x18]       | W8 = val_79.Length; //P2                
        // 0x00B31048: CBNZ w8, #0xb31058         | if (val_79.Length != 0) goto label_116; 
        if(val_79.Length != 0)
        {
            goto label_116;
        }
        // 0x00B3104C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_79, ????);     
        // 0x00B31050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31054: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_79, ????);     
        label_116:
        // 0x00B31058: LDR x22, [x22, #0x20]      | X22 = val_79[0]                         
        T val_144 = val_79[0];
        // 0x00B3105C: CBNZ x22, #0xb31064        | if (val_79[0] != 0) goto label_117;     
        if(val_144 != 0)
        {
            goto label_117;
        }
        // 0x00B31060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_79, ????);     
        label_117:
        // 0x00B31064: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31068: MOV x0, x22                | X0 = val_79[0];//m1                     
        // 0x00B3106C: BL #0x268e974              | X0 = val_79[0].get_bytes();             
        System.Byte[] val_80 = val_144.bytes;
        // 0x00B31070: LDP x23, x24, [x19, #0x20] | X23 = this.updateDic; //P2  X24 = this.wwwGroups; //P2  //  | 
        // 0x00B31074: MOV x22, x0                | X22 = val_80;//m1                       
        val_153 = val_80;
        // 0x00B31078: CBNZ x24, #0xb31080        | if (this.wwwGroups != null) goto label_118;
        if(this.wwwGroups != null)
        {
            goto label_118;
        }
        // 0x00B3107C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
        label_118:
        // 0x00B31080: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31084: MOV x0, x24                | X0 = this.wwwGroups;//m1                
        // 0x00B31088: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3108C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_81 = this.wwwGroups.Item[0];
        // 0x00B31090: MOV x24, x0                | X24 = val_81;//m1                       
        // 0x00B31094: CBNZ x24, #0xb3109c        | if (val_81 != null) goto label_119;     
        if(val_81 != null)
        {
            goto label_119;
        }
        // 0x00B31098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_81, ????);     
        label_119:
        // 0x00B3109C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B310A0: MOV x0, x24                | X0 = val_81;//m1                        
        // 0x00B310A4: BL #0xabe980               | X0 = val_81.get_url();                  
        string val_82 = val_81.url;
        // 0x00B310A8: MOV x24, x0                | X24 = val_82;//m1                       
        // 0x00B310AC: CBNZ x23, #0xb310b4        | if (this.updateDic != null) goto label_120;
        if(this.updateDic != null)
        {
            goto label_120;
        }
        // 0x00B310B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_82, ????);     
        label_120:
        // 0x00B310B4: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B310B8: MOV x0, x23                | X0 = this.updateDic;//m1                
        // 0x00B310BC: MOV x1, x24                | X1 = val_82;//m1                        
        // 0x00B310C0: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_82);
        FileInfoRes val_83 = this.updateDic.Item[val_82];
        // 0x00B310C4: MOV x2, x0                 | X2 = val_83;//m1                        
        // 0x00B310C8: MOV x0, x19                | X0 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B310CC: MOV x1, x22                | X1 = val_80;//m1                        
        // 0x00B310D0: BL #0xb31de0               | this.SaveBytes(bytes:  val_153, assetData:  val_83);
        this.SaveBytes(bytes:  val_153, assetData:  val_83);
        // 0x00B310D4: CBNZ x21, #0xb310dc        | if (val_78 != null) goto label_121;     
        if(val_78 != null)
        {
            goto label_121;
        }
        // 0x00B310D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_121:
        // 0x00B310DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B310E0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B310E4: MOV x0, x21                | X0 = val_78;//m1                        
        // 0x00B310E8: BL #0x20ca1d4              | val_78.Unload(unloadAllLoadedObjects:  true);
        val_78.Unload(unloadAllLoadedObjects:  true);
        // 0x00B310EC: B #0xb314f4                |  goto label_136;                        
        goto label_136;
        label_111:
        // 0x00B310F0: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B310F4: CBNZ x22, #0xb310fc        | if (this.wwwGroups != null) goto label_123;
        if(this.wwwGroups != null)
        {
            goto label_123;
        }
        // 0x00B310F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
        label_123:
        // 0x00B310FC: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31100: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31104: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B31108: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_84 = this.wwwGroups.Item[0];
        // 0x00B3110C: MOV x22, x0                | X22 = val_84;//m1                       
        // 0x00B31110: CBNZ x22, #0xb31118        | if (val_84 != null) goto label_124;     
        if(val_84 != null)
        {
            goto label_124;
        }
        // 0x00B31114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_84, ????);     
        label_124:
        // 0x00B31118: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3111C: MOV x0, x22                | X0 = val_84;//m1                        
        // 0x00B31120: BL #0xabe980               | X0 = val_84.get_url();                  
        string val_85 = val_84.url;
        // 0x00B31124: MOV x22, x0                | X22 = val_85;//m1                       
        val_154 = val_85;
        // 0x00B31128: CBNZ x21, #0xb31130        | if (this.updateDic != null) goto label_125;
        if(this.updateDic != null)
        {
            goto label_125;
        }
        // 0x00B3112C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
        label_125:
        // 0x00B31130: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B31134: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B31138: MOV x1, x22                | X1 = val_85;//m1                        
        // 0x00B3113C: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_154);
        FileInfoRes val_86 = this.updateDic.Item[val_154];
        // 0x00B31140: MOV x21, x0                | X21 = val_86;//m1                       
        // 0x00B31144: CBNZ x21, #0xb3114c        | if (val_86 != null) goto label_126;     
        if(val_86 != null)
        {
            goto label_126;
        }
        // 0x00B31148: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_86, ????);     
        label_126:
        // 0x00B3114C: LDR x21, [x21, #0x10]      | 
        // 0x00B31150: CBNZ x21, #0xb31158        | if (val_86 != null) goto label_127;     
        if(val_86 != null)
        {
            goto label_127;
        }
        // 0x00B31154: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_86, ????);     
        label_127:
        // 0x00B31158: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B3115C: LDR x8, [x8, #0xfc8]       | X8 = (string**)(1152921514967116720)("_csscript.uab");
        // 0x00B31160: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B31164: MOV x0, x21                | X0 = val_86;//m1                        
        // 0x00B31168: LDR x1, [x8]               | X1 = "_csscript.uab";                   
        // 0x00B3116C: BL #0x18ab0a0              | X0 = val_86.EndsWith(value:  "_csscript.uab");
        bool val_87 = val_86.EndsWith(value:  "_csscript.uab");
        // 0x00B31170: TBZ w0, #0, #0xb31224      | if (val_87 == false) goto label_128;    
        if(val_87 == false)
        {
            goto label_128;
        }
        // 0x00B31174: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B31178: CBNZ x22, #0xb31180        | if (this.wwwGroups != null) goto label_129;
        if(this.wwwGroups != null)
        {
            goto label_129;
        }
        // 0x00B3117C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_87, ????);     
        label_129:
        // 0x00B31180: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31184: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31188: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3118C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_88 = this.wwwGroups.Item[0];
        // 0x00B31190: MOV x22, x0                | X22 = val_88;//m1                       
        // 0x00B31194: CBNZ x22, #0xb3119c        | if (val_88 != null) goto label_130;     
        if(val_88 != null)
        {
            goto label_130;
        }
        // 0x00B31198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_88, ????);     
        label_130:
        // 0x00B3119C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B311A0: MOV x0, x22                | X0 = val_88;//m1                        
        // 0x00B311A4: BL #0xabe980               | X0 = val_88.get_url();                  
        string val_89 = val_88.url;
        // 0x00B311A8: MOV x22, x0                | X22 = val_89;//m1                       
        // 0x00B311AC: CBNZ x21, #0xb311b4        | if (this.updateDic != null) goto label_131;
        if(this.updateDic != null)
        {
            goto label_131;
        }
        // 0x00B311B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_89, ????);     
        label_131:
        // 0x00B311B4: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B311B8: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B311BC: MOV x1, x22                | X1 = val_89;//m1                        
        // 0x00B311C0: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_89);
        FileInfoRes val_90 = this.updateDic.Item[val_89];
        // 0x00B311C4: MOV x21, x0                | X21 = val_90;//m1                       
        // 0x00B311C8: CBNZ x21, #0xb311d0        | if (val_90 != null) goto label_132;     
        if(val_90 != null)
        {
            goto label_132;
        }
        // 0x00B311CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_90, ????);     
        label_132:
        // 0x00B311D0: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B311D4: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B311D8: LDR x21, [x21, #0x10]      | 
        // 0x00B311DC: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_155 = null;
        // 0x00B311E0: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B311E4: TBZ w8, #0, #0xb31200      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_134;
        // 0x00B311E8: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B311EC: CBNZ w8, #0xb31200         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_134;
        // 0x00B311F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B311F4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B311F8: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B311FC: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_155 = null;
        label_134:
        // 0x00B31200: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B31204: LDR x22, [x8, #0x10]       | X22 = Loader.PathUtil.ARCH_ABI_TYPE;    
        val_156 = Loader.PathUtil.ARCH_ABI_TYPE;
        // 0x00B31208: CBNZ x21, #0xb31210        | if (val_90 != null) goto label_135;     
        if(val_90 != null)
        {
            goto label_135;
        }
        // 0x00B3120C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Loader.PathUtil), ????);
        label_135:
        // 0x00B31210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B31214: MOV x0, x21                | X0 = val_90;//m1                        
        // 0x00B31218: MOV x1, x22                | X1 = Loader.PathUtil.ARCH_ABI_TYPE;//m1 
        // 0x00B3121C: BL #0x18ad42c              | X0 = val_90.Contains(value:  val_156);  
        bool val_91 = val_90.Contains(value:  val_156);
        // 0x00B31220: TBZ w0, #0, #0xb314f4      | if (val_91 == false) goto label_136;    
        if(val_91 == false)
        {
            goto label_136;
        }
        label_128:
        // 0x00B31224: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B31228: CBNZ x22, #0xb31230        | if (this.wwwGroups != null) goto label_137;
        if(this.wwwGroups != null)
        {
            goto label_137;
        }
        // 0x00B3122C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_91, ????);     
        label_137:
        // 0x00B31230: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31234: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31238: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3123C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_92 = this.wwwGroups.Item[0];
        // 0x00B31240: MOV x22, x0                | X22 = val_92;//m1                       
        // 0x00B31244: CBNZ x22, #0xb3124c        | if (val_92 != null) goto label_138;     
        if(val_92 != null)
        {
            goto label_138;
        }
        // 0x00B31248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_92, ????);     
        label_138:
        // 0x00B3124C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31250: MOV x0, x22                | X0 = val_92;//m1                        
        // 0x00B31254: BL #0xabe980               | X0 = val_92.get_url();                  
        string val_93 = val_92.url;
        // 0x00B31258: MOV x22, x0                | X22 = val_93;//m1                       
        // 0x00B3125C: CBNZ x21, #0xb31264        | if (this.updateDic != null) goto label_139;
        if(this.updateDic != null)
        {
            goto label_139;
        }
        // 0x00B31260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
        label_139:
        // 0x00B31264: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B31268: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B3126C: MOV x1, x22                | X1 = val_93;//m1                        
        // 0x00B31270: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_93);
        FileInfoRes val_94 = this.updateDic.Item[val_93];
        // 0x00B31274: MOV x21, x0                | X21 = val_94;//m1                       
        // 0x00B31278: CBNZ x21, #0xb31280        | if (val_94 != null) goto label_140;     
        if(val_94 != null)
        {
            goto label_140;
        }
        // 0x00B3127C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_94, ????);     
        label_140:
        // 0x00B31280: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x00B31284: LDR x21, [x21, #0x10]      | 
        // 0x00B31288: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B3128C: TBZ w8, #0, #0xb3129c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_142;
        // 0x00B31290: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B31294: CBNZ w8, #0xb3129c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_142;
        // 0x00B31298: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_142:
        // 0x00B3129C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B312A0: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921510473861536)("config.uab");
        // 0x00B312A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B312A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B312AC: MOV x1, x21                | X1 = val_94;//m1                        
        // 0x00B312B0: LDR x2, [x8]               | X2 = "config.uab";                      
        // 0x00B312B4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_94);
        bool val_95 = System.String.op_Equality(a:  0, b:  val_94);
        // 0x00B312B8: AND w8, w0, #1             | W8 = (val_95 & 1);                      
        bool val_96 = val_95;
        // 0x00B312BC: TBNZ w8, #0, #0xb31358     | if ((val_95 & 1) == true) goto label_143;
        if(val_96 == true)
        {
            goto label_143;
        }
        // 0x00B312C0: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B312C4: CBNZ x22, #0xb312cc        | if (this.wwwGroups != null) goto label_144;
        if(this.wwwGroups != null)
        {
            goto label_144;
        }
        // 0x00B312C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_95, ????);     
        label_144:
        // 0x00B312CC: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B312D0: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B312D4: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B312D8: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_97 = this.wwwGroups.Item[0];
        // 0x00B312DC: MOV x22, x0                | X22 = val_97;//m1                       
        // 0x00B312E0: CBNZ x22, #0xb312e8        | if (val_97 != null) goto label_145;     
        if(val_97 != null)
        {
            goto label_145;
        }
        // 0x00B312E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_97, ????);     
        label_145:
        // 0x00B312E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B312EC: MOV x0, x22                | X0 = val_97;//m1                        
        // 0x00B312F0: BL #0xabe980               | X0 = val_97.get_url();                  
        string val_98 = val_97.url;
        // 0x00B312F4: MOV x22, x0                | X22 = val_98;//m1                       
        // 0x00B312F8: CBNZ x21, #0xb31300        | if (this.updateDic != null) goto label_146;
        if(this.updateDic != null)
        {
            goto label_146;
        }
        // 0x00B312FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_98, ????);     
        label_146:
        // 0x00B31300: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B31304: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B31308: MOV x1, x22                | X1 = val_98;//m1                        
        // 0x00B3130C: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_98);
        FileInfoRes val_99 = this.updateDic.Item[val_98];
        // 0x00B31310: MOV x21, x0                | X21 = val_99;//m1                       
        // 0x00B31314: CBNZ x21, #0xb3131c        | if (val_99 != null) goto label_147;     
        if(val_99 != null)
        {
            goto label_147;
        }
        // 0x00B31318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_99, ????);     
        label_147:
        // 0x00B3131C: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x00B31320: LDR x21, [x21, #0x10]      | 
        // 0x00B31324: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B31328: TBZ w8, #0, #0xb31338      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_149;
        // 0x00B3132C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B31330: CBNZ w8, #0xb31338         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_149;
        // 0x00B31334: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_149:
        // 0x00B31338: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B3133C: LDR x8, [x8, #0xde8]       | X8 = (string**)(1152921509978841008)("javascript.uab");
        // 0x00B31340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B31344: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B31348: MOV x1, x21                | X1 = val_99;//m1                        
        // 0x00B3134C: LDR x2, [x8]               | X2 = "javascript.uab";                  
        // 0x00B31350: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_99);
        bool val_100 = System.String.op_Equality(a:  0, b:  val_99);
        // 0x00B31354: TBZ w0, #0, #0xb315ec      | if (val_100 == false) goto label_150;   
        if(val_100 == false)
        {
            goto label_150;
        }
        label_143:
        // 0x00B31358: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B3135C: CBNZ x21, #0xb31364        | if (this.wwwGroups != null) goto label_151;
        if(this.wwwGroups != null)
        {
            goto label_151;
        }
        // 0x00B31360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_100, ????);    
        label_151:
        // 0x00B31364: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31368: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B3136C: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B31370: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_101 = this.wwwGroups.Item[0];
        // 0x00B31374: MOV x21, x0                | X21 = val_101;//m1                      
        // 0x00B31378: CBNZ x21, #0xb31380        | if (val_101 != null) goto label_152;    
        if(val_101 != null)
        {
            goto label_152;
        }
        // 0x00B3137C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_101, ????);    
        label_152:
        // 0x00B31380: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31384: MOV x0, x21                | X0 = val_101;//m1                       
        // 0x00B31388: BL #0xabed30               | X0 = val_101.get_bytes();               
        System.Byte[] val_102 = val_101.bytes;
        // 0x00B3138C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B31390: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B31394: MOV x21, x0                | X21 = val_102;//m1                      
        // 0x00B31398: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B3139C: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B313A0: TBZ w9, #0, #0xb313b4      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_154;
        // 0x00B313A4: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B313A8: CBNZ w9, #0xb313b4         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_154;
        // 0x00B313AC: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B313B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_154:
        // 0x00B313B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B313B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B313BC: MOV x1, x21                | X1 = val_102;//m1                       
        // 0x00B313C0: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_103 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        label_190:
        // 0x00B313C4: LDR x22, [x19, #0x20]      | X22 = this.updateDic; //P2              
        // 0x00B313C8: LDR x23, [x19, #0x28]      | X23 = this.wwwGroups; //P2              
        // 0x00B313CC: MOV x21, x0                | X21 = val_103;//m1                      
        // 0x00B313D0: CBNZ x23, #0xb313d8        | if (this.wwwGroups != null) goto label_155;
        if(this.wwwGroups != null)
        {
            goto label_155;
        }
        // 0x00B313D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_103, ????);    
        label_155:
        // 0x00B313D8: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B313DC: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B313E0: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B313E4: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_104 = this.wwwGroups.Item[0];
        // 0x00B313E8: MOV x23, x0                | X23 = val_104;//m1                      
        // 0x00B313EC: CBNZ x23, #0xb313f4        | if (val_104 != null) goto label_156;    
        if(val_104 != null)
        {
            goto label_156;
        }
        // 0x00B313F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_104, ????);    
        label_156:
        // 0x00B313F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B313F8: MOV x0, x23                | X0 = val_104;//m1                       
        // 0x00B313FC: BL #0xabe980               | X0 = val_104.get_url();                 
        string val_105 = val_104.url;
        // 0x00B31400: MOV x23, x0                | X23 = val_105;//m1                      
        // 0x00B31404: CBNZ x22, #0xb3140c        | if (this.updateDic != null) goto label_157;
        if(this.updateDic != null)
        {
            goto label_157;
        }
        // 0x00B31408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_105, ????);    
        label_157:
        // 0x00B3140C: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B31410: MOV x0, x22                | X0 = this.updateDic;//m1                
        // 0x00B31414: MOV x1, x23                | X1 = val_105;//m1                       
        // 0x00B31418: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_105);
        FileInfoRes val_106 = this.updateDic.Item[val_105];
        // 0x00B3141C: MOV x22, x0                | X22 = val_106;//m1                      
        // 0x00B31420: CBNZ x22, #0xb31428        | if (val_106 != null) goto label_158;    
        if(val_106 != null)
        {
            goto label_158;
        }
        // 0x00B31424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_106, ????);    
        label_158:
        // 0x00B31428: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x00B3142C: LDR x22, [x22, #0x18]      | X22 = val_106.mDataMD5; //P2            
        // 0x00B31430: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B31434: TBZ w8, #0, #0xb31444      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_160;
        // 0x00B31438: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B3143C: CBNZ w8, #0xb31444         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_160;
        // 0x00B31440: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_160:
        // 0x00B31444: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B31448: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B3144C: MOV x1, x21                | X1 = val_103;//m1                       
        // 0x00B31450: MOV x2, x22                | X2 = val_106.mDataMD5;//m1              
        // 0x00B31454: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_103);
        bool val_107 = System.String.op_Inequality(a:  0, b:  val_103);
        // 0x00B31458: TBNZ w0, #0, #0xb31870     | if (val_107 == true) goto label_161;    
        if(val_107 == true)
        {
            goto label_161;
        }
        label_185:
        // 0x00B3145C: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B31460: CBNZ x21, #0xb31468        | if (this.wwwGroups != null) goto label_162;
        if(this.wwwGroups != null)
        {
            goto label_162;
        }
        // 0x00B31464: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_107, ????);    
        label_162:
        // 0x00B31468: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B3146C: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B31470: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B31474: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_108 = this.wwwGroups.Item[0];
        // 0x00B31478: MOV x21, x0                | X21 = val_108;//m1                      
        // 0x00B3147C: CBNZ x21, #0xb31484        | if (val_108 != null) goto label_163;    
        if(val_108 != null)
        {
            goto label_163;
        }
        // 0x00B31480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_108, ????);    
        label_163:
        // 0x00B31484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31488: MOV x0, x21                | X0 = val_108;//m1                       
        // 0x00B3148C: BL #0xabed30               | X0 = val_108.get_bytes();               
        System.Byte[] val_109 = val_108.bytes;
        // 0x00B31490: LDP x22, x23, [x19, #0x20] | X22 = this.updateDic; //P2  X23 = this.wwwGroups; //P2  //  | 
        val_153 = this.updateDic;
        // 0x00B31494: MOV x21, x0                | X21 = val_109;//m1                      
        // 0x00B31498: CBNZ x23, #0xb314a0        | if (this.wwwGroups != null) goto label_164;
        if(this.wwwGroups != null)
        {
            goto label_164;
        }
        // 0x00B3149C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_109, ????);    
        label_164:
        // 0x00B314A0: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B314A4: MOV x0, x23                | X0 = this.wwwGroups;//m1                
        // 0x00B314A8: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B314AC: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_110 = this.wwwGroups.Item[0];
        // 0x00B314B0: MOV x23, x0                | X23 = val_110;//m1                      
        // 0x00B314B4: CBNZ x23, #0xb314bc        | if (val_110 != null) goto label_165;    
        if(val_110 != null)
        {
            goto label_165;
        }
        // 0x00B314B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_110, ????);    
        label_165:
        // 0x00B314BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B314C0: MOV x0, x23                | X0 = val_110;//m1                       
        // 0x00B314C4: BL #0xabe980               | X0 = val_110.get_url();                 
        string val_111 = val_110.url;
        // 0x00B314C8: MOV x23, x0                | X23 = val_111;//m1                      
        // 0x00B314CC: CBNZ x22, #0xb314d4        | if (this.updateDic != null) goto label_166;
        if(val_153 != null)
        {
            goto label_166;
        }
        // 0x00B314D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_111, ????);    
        label_166:
        // 0x00B314D4: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B314D8: MOV x0, x22                | X0 = this.updateDic;//m1                
        // 0x00B314DC: MOV x1, x23                | X1 = val_111;//m1                       
        // 0x00B314E0: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_111);
        FileInfoRes val_112 = val_153.Item[val_111];
        // 0x00B314E4: MOV x2, x0                 | X2 = val_112;//m1                       
        // 0x00B314E8: MOV x0, x19                | X0 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B314EC: MOV x1, x21                | X1 = val_109;//m1                       
        // 0x00B314F0: BL #0xb31de0               | this.SaveBytes(bytes:  val_109, assetData:  val_112);
        this.SaveBytes(bytes:  val_109, assetData:  val_112);
        label_136:
        // 0x00B314F4: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B314F8: CBNZ x22, #0xb31500        | if (this.wwwGroups != null) goto label_167;
        if(this.wwwGroups != null)
        {
            goto label_167;
        }
        // 0x00B314FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_167:
        // 0x00B31500: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31504: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31508: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B3150C: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_113 = this.wwwGroups.Item[0];
        // 0x00B31510: MOV x22, x0                | X22 = val_113;//m1                      
        // 0x00B31514: CBNZ x22, #0xb3151c        | if (val_113 != null) goto label_168;    
        if(val_113 != null)
        {
            goto label_168;
        }
        // 0x00B31518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_113, ????);    
        label_168:
        // 0x00B3151C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31520: MOV x0, x22                | X0 = val_113;//m1                       
        // 0x00B31524: BL #0xabe980               | X0 = val_113.get_url();                 
        string val_114 = val_113.url;
        // 0x00B31528: MOV x22, x0                | X22 = val_114;//m1                      
        // 0x00B3152C: CBNZ x21, #0xb31534        | if (this.updateDic != null) goto label_169;
        if(this.updateDic != null)
        {
            goto label_169;
        }
        // 0x00B31530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_114, ????);    
        label_169:
        // 0x00B31534: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00B31538: LDR x8, [x8, #0x530]       | X8 = 1152921514959292464;               
        // 0x00B3153C: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B31540: MOV x1, x22                | X1 = val_114;//m1                       
        // 0x00B31544: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, FileInfoRes>::ContainsKey(System.String key);
        // 0x00B31548: BL #0x23fd9f0              | X0 = this.updateDic.ContainsKey(key:  val_114);
        bool val_115 = this.updateDic.ContainsKey(key:  val_114);
        // 0x00B3154C: TBZ w0, #0, #0xb315a8      | if (val_115 == false) goto label_170;   
        if(val_115 == false)
        {
            goto label_170;
        }
        // 0x00B31550: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B31554: CBNZ x22, #0xb3155c        | if (this.wwwGroups != null) goto label_171;
        if(this.wwwGroups != null)
        {
            goto label_171;
        }
        // 0x00B31558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_115, ????);    
        label_171:
        // 0x00B3155C: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31560: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31564: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B31568: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_116 = this.wwwGroups.Item[0];
        // 0x00B3156C: MOV x22, x0                | X22 = val_116;//m1                      
        // 0x00B31570: CBNZ x22, #0xb31578        | if (val_116 != null) goto label_172;    
        if(val_116 != null)
        {
            goto label_172;
        }
        // 0x00B31574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_116, ????);    
        label_172:
        // 0x00B31578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3157C: MOV x0, x22                | X0 = val_116;//m1                       
        // 0x00B31580: BL #0xabe980               | X0 = val_116.get_url();                 
        string val_117 = val_116.url;
        // 0x00B31584: MOV x22, x0                | X22 = val_117;//m1                      
        // 0x00B31588: CBNZ x21, #0xb31590        | if (this.updateDic != null) goto label_173;
        if(this.updateDic != null)
        {
            goto label_173;
        }
        // 0x00B3158C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_117, ????);    
        label_173:
        // 0x00B31590: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00B31594: LDR x8, [x8, #0xd08]       | X8 = 1152921515153467344;               
        // 0x00B31598: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B3159C: MOV x1, x22                | X1 = val_117;//m1                       
        // 0x00B315A0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, FileInfoRes>::Remove(System.String key);
        // 0x00B315A4: BL #0x23fe354              | X0 = this.updateDic.Remove(key:  val_117);
        bool val_118 = this.updateDic.Remove(key:  val_117);
        label_170:
        // 0x00B315A8: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B315AC: CBNZ x21, #0xb315b4        | if (this.wwwGroups != null) goto label_174;
        if(this.wwwGroups != null)
        {
            goto label_174;
        }
        // 0x00B315B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_118, ????);    
        label_174:
        // 0x00B315B4: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B315B8: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B315BC: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B315C0: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_119 = this.wwwGroups.Item[0];
        // 0x00B315C4: MOV x21, x0                | X21 = val_119;//m1                      
        // 0x00B315C8: CBNZ x21, #0xb315d0        | if (val_119 != null) goto label_175;    
        if(val_119 != null)
        {
            goto label_175;
        }
        // 0x00B315CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_119, ????);    
        label_175:
        // 0x00B315D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B315D4: MOV x0, x21                | X0 = val_119;//m1                       
        // 0x00B315D8: BL #0xabeb78               | val_119.Dispose();                      
        val_119.Dispose();
        // 0x00B315DC: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B315E0: CBNZ x21, #0xb30400        | if (this.wwwGroups != null) goto label_177;
        if(this.wwwGroups != null)
        {
            goto label_177;
        }
        // 0x00B315E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_119, ????);    
        // 0x00B315E8: B #0xb30400                |  goto label_177;                        
        goto label_177;
        label_150:
        // 0x00B315EC: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B315F0: CBNZ x22, #0xb315f8        | if (this.wwwGroups != null) goto label_178;
        if(this.wwwGroups != null)
        {
            goto label_178;
        }
        // 0x00B315F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_100, ????);    
        label_178:
        // 0x00B315F8: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B315FC: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31600: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B31604: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_120 = this.wwwGroups.Item[0];
        // 0x00B31608: MOV x22, x0                | X22 = val_120;//m1                      
        // 0x00B3160C: CBNZ x22, #0xb31614        | if (val_120 != null) goto label_179;    
        if(val_120 != null)
        {
            goto label_179;
        }
        // 0x00B31610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_120, ????);    
        label_179:
        // 0x00B31614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31618: MOV x0, x22                | X0 = val_120;//m1                       
        // 0x00B3161C: BL #0xabe980               | X0 = val_120.get_url();                 
        string val_121 = val_120.url;
        // 0x00B31620: MOV x22, x0                | X22 = val_121;//m1                      
        // 0x00B31624: CBNZ x21, #0xb3162c        | if (this.updateDic != null) goto label_180;
        if(this.updateDic != null)
        {
            goto label_180;
        }
        // 0x00B31628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_121, ????);    
        label_180:
        // 0x00B3162C: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B31630: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B31634: MOV x1, x22                | X1 = val_121;//m1                       
        // 0x00B31638: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_121);
        FileInfoRes val_122 = this.updateDic.Item[val_121];
        // 0x00B3163C: MOV x21, x0                | X21 = val_122;//m1                      
        // 0x00B31640: CBNZ x21, #0xb31648        | if (val_122 != null) goto label_181;    
        if(val_122 != null)
        {
            goto label_181;
        }
        // 0x00B31644: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_122, ????);    
        label_181:
        // 0x00B31648: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B3164C: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B31650: LDR x21, [x21, #0x10]      | 
        // 0x00B31654: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_157 = null;
        // 0x00B31658: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B3165C: TBZ w8, #0, #0xb31678      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_183;
        // 0x00B31660: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B31664: CBNZ w8, #0xb31678         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_183;
        // 0x00B31668: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B3166C: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00B31670: LDR x8, [x8, #0xde8]       | X8 = 1152921504911265792;               
        // 0x00B31674: LDR x0, [x8]               | X0 = typeof(Loader.PathUtil);           
        val_157 = null;
        label_183:
        // 0x00B31678: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B3167C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B31680: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B31684: LDR x2, [x8, #0x10]        | X2 = Loader.PathUtil.ARCH_ABI_TYPE;     
        // 0x00B31688: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
        // 0x00B3168C: LDR x8, [x8, #0xbd8]       | X8 = (string**)(1152921515153924048)("{0}_csscript.uab");
        // 0x00B31690: LDR x1, [x8]               | X1 = "{0}_csscript.uab";                
        // 0x00B31694: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "{0}_csscript.uab");
        string val_123 = EString.EFormat(format:  0, arg0:  "{0}_csscript.uab");
        // 0x00B31698: MOV x22, x0                | X22 = val_123;//m1                      
        // 0x00B3169C: CBNZ x21, #0xb316a4        | if (val_122 != null) goto label_184;    
        if(val_122 != null)
        {
            goto label_184;
        }
        // 0x00B316A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_123, ????);    
        label_184:
        // 0x00B316A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B316A8: MOV x0, x21                | X0 = val_122;//m1                       
        // 0x00B316AC: MOV x1, x22                | X1 = val_123;//m1                       
        // 0x00B316B0: BL #0x18ab0a0              | X0 = val_122.EndsWith(value:  val_123); 
        bool val_124 = val_122.EndsWith(value:  val_123);
        // 0x00B316B4: AND w8, w0, #1             | W8 = (val_124 & 1);                     
        bool val_125 = val_124;
        // 0x00B316B8: TBNZ w8, #0, #0xb3145c     | if ((val_124 & 1) == true) goto label_185;
        if(val_125 == true)
        {
            goto label_185;
        }
        // 0x00B316BC: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B316C0: CBNZ x21, #0xb316c8        | if (this.wwwGroups != null) goto label_186;
        if(this.wwwGroups != null)
        {
            goto label_186;
        }
        // 0x00B316C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_124, ????);    
        label_186:
        // 0x00B316C8: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B316CC: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B316D0: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B316D4: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_126 = this.wwwGroups.Item[0];
        // 0x00B316D8: MOV x21, x0                | X21 = val_126;//m1                      
        // 0x00B316DC: CBNZ x21, #0xb316e4        | if (val_126 != null) goto label_187;    
        if(val_126 != null)
        {
            goto label_187;
        }
        // 0x00B316E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_126, ????);    
        label_187:
        // 0x00B316E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B316E8: MOV x0, x21                | X0 = val_126;//m1                       
        // 0x00B316EC: BL #0xabed30               | X0 = val_126.get_bytes();               
        System.Byte[] val_127 = val_126.bytes;
        // 0x00B316F0: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B316F4: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B316F8: MOV x21, x0                | X21 = val_127;//m1                      
        // 0x00B316FC: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B31700: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B31704: TBZ w9, #0, #0xb31718      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_189;
        // 0x00B31708: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B3170C: CBNZ w9, #0xb31718         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_189;
        // 0x00B31710: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B31714: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_189:
        // 0x00B31718: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3171C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B31720: MOV x1, x21                | X1 = val_127;//m1                       
        // 0x00B31724: BL #0xabed5c               | X0 = Mihua.Update.VSTools.GetCRC32(bytes:  0);
        string val_128 = Mihua.Update.VSTools.GetCRC32(bytes:  0);
        // 0x00B31728: B #0xb313c4                |  goto label_190;                        
        goto label_190;
        label_29:
        // 0x00B3172C: LDR w23, [x19, #0x8c]      | W23 = this.loadingBytes; //P2           
        // 0x00B31730: LDP x21, x22, [x19, #0x20] | X21 = this.updateDic; //P2  X22 = this.wwwGroups; //P2  //  | 
        // 0x00B31734: CBNZ x22, #0xb3173c        | if (this.wwwGroups != null) goto label_191;
        if(this.wwwGroups != null)
        {
            goto label_191;
        }
        // 0x00B31738: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_191:
        // 0x00B3173C: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B31740: MOV x0, x22                | X0 = this.wwwGroups;//m1                
        // 0x00B31744: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B31748: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_129 = this.wwwGroups.Item[0];
        // 0x00B3174C: MOV x22, x0                | X22 = val_129;//m1                      
        // 0x00B31750: CBNZ x22, #0xb31758        | if (val_129 != null) goto label_192;    
        if(val_129 != null)
        {
            goto label_192;
        }
        // 0x00B31754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_129, ????);    
        label_192:
        // 0x00B31758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3175C: MOV x0, x22                | X0 = val_129;//m1                       
        // 0x00B31760: BL #0xabe980               | X0 = val_129.get_url();                 
        string val_130 = val_129.url;
        // 0x00B31764: MOV x22, x0                | X22 = val_130;//m1                      
        // 0x00B31768: CBNZ x21, #0xb31770        | if (this.updateDic != null) goto label_193;
        if(this.updateDic != null)
        {
            goto label_193;
        }
        // 0x00B3176C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_130, ????);    
        label_193:
        // 0x00B31770: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B31774: MOV x0, x21                | X0 = this.updateDic;//m1                
        // 0x00B31778: MOV x1, x22                | X1 = val_130;//m1                       
        // 0x00B3177C: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_130);
        FileInfoRes val_131 = this.updateDic.Item[val_130];
        // 0x00B31780: MOV x21, x0                | X21 = val_131;//m1                      
        // 0x00B31784: CBNZ x21, #0xb3178c        | if (val_131 != null) goto label_194;    
        if(val_131 != null)
        {
            goto label_194;
        }
        // 0x00B31788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_131, ????);    
        label_194:
        // 0x00B3178C: LDR w22, [x21, #0x28]      | W22 = val_131.mSize; //P2               
        // 0x00B31790: LDR x21, [x19, #0x28]      | X21 = this.wwwGroups; //P2              
        // 0x00B31794: CBNZ x21, #0xb3179c        | if (this.wwwGroups != null) goto label_195;
        if(this.wwwGroups != null)
        {
            goto label_195;
        }
        // 0x00B31798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_131, ????);    
        label_195:
        // 0x00B3179C: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B317A0: MOV x0, x21                | X0 = this.wwwGroups;//m1                
        // 0x00B317A4: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B317A8: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_132 = this.wwwGroups.Item[0];
        // 0x00B317AC: MOV x21, x0                | X21 = val_132;//m1                      
        // 0x00B317B0: CBNZ x21, #0xb317b8        | if (val_132 != null) goto label_196;    
        if(val_132 != null)
        {
            goto label_196;
        }
        // 0x00B317B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_132, ????);    
        label_196:
        // 0x00B317B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B317BC: MOV x0, x21                | X0 = val_132;//m1                       
        // 0x00B317C0: BL #0xabefa8               | X0 = val_132.get_progress();            
        float val_133 = val_132.progress;
        // 0x00B317C4: UCVTF d1, w22              | D1 = (double)(val_131.mSize);           
        // 0x00B317C8: FCVT s1, d1                | S1 = (float)val_131.mSize);             
        // 0x00B317CC: FMUL s0, s1, s0            | S0 = (val_131.mSize * val_133);         
        val_133 = (float)(double)val_131.mSize * val_133;
        // 0x00B317D0: FCVTZU w8, s0              | 
        // 0x00B317D4: ADD w8, w8, w23            | W8 = (1152921514964672640 + this.loadingBytes);
        val_145 = val_145 + this.loadingBytes;
        // 0x00B317D8: ADD w20, w20, #1           | W20 = (0 + 1) = 1 (0x00000001);         
        // 0x00B317DC: STR w8, [x19, #0x8c]       | this.loadingBytes = (1152921514964672640 + this.loadingBytes);  //  dest_result_addr=1152921515154059020
        this.loadingBytes = val_145;
        // 0x00B317E0: B #0xb30e38                |  goto label_197;                        
        goto label_197;
        label_96:
        // 0x00B317E4: LDP w8, w9, [x19, #0x8c]   | W8 = this.loadingBytes; //P2  W9 = this.loadedBytes; //P2  //  | 
        uint val_146 = this.loadingBytes;
        // 0x00B317E8: LDR w10, [x19, #0x50]      | W10 = this.totalBytes; //P2             
        // 0x00B317EC: LDRB w11, [x19, #0x4c]     | W11 = this.isStart; //P2                
        // 0x00B317F0: ADD w8, w8, w9             | W8 = (this.loadingBytes + this.loadedBytes);
        val_146 = val_146 + this.loadedBytes;
        // 0x00B317F4: CMP w8, w10                | STATE = COMPARE((this.loadingBytes + this.loadedBytes), this.totalBytes)
        // 0x00B317F8: CSET w9, eq                | W9 = this.loadingBytes == this.totalBytes ? 1 : 0;
        bool val_134 = (val_146 == this.totalBytes) ? 1 : 0;
        // 0x00B317FC: STR w8, [x19, #0x54]       | this.curBytes = (this.loadingBytes + this.loadedBytes);  //  dest_result_addr=1152921515154058964
        this.curBytes = val_146;
        // 0x00B31800: STRB w9, [x19, #0x88]      | this.IsDownSuccess = this.loadingBytes == this.totalBytes ? 1 : 0;  //  dest_result_addr=1152921515154059016
        this.IsDownSuccess = val_134;
        // 0x00B31804: CBZ w11, #0xb31828         | if (this.isStart == false) goto label_199;
        if(this.isStart == false)
        {
            goto label_199;
        }
        label_200:
        // 0x00B31808: MOV x0, x19                | X0 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B3180C: BL #0xb31ecc               | X0 = this.DownNext();                   
        bool val_135 = this.DownNext();
        // 0x00B31810: AND w8, w0, #1             | W8 = (val_135 & 1);                     
        bool val_136 = val_135;
        // 0x00B31814: TBZ w8, #0, #0xb31828      | if ((val_135 & 1) == false) goto label_199;
        if(val_136 == false)
        {
            goto label_199;
        }
        // 0x00B31818: MOV x0, x19                | X0 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B3181C: BL #0xb31ecc               | X0 = this.DownNext();                   
        bool val_137 = this.DownNext();
        // 0x00B31820: LDRB w8, [x19, #0x4c]      | W8 = this.isStart; //P2                 
        // 0x00B31824: CBNZ w8, #0xb31808         | if (this.isStart == true) goto label_200;
        if(this.isStart == true)
        {
            goto label_200;
        }
        label_199:
        // 0x00B31828: LDRB w8, [x19, #0x60]      | W8 = this.IsWriteFinish; //P2           
        // 0x00B3182C: CBZ w8, #0xb3184c          | if (this.IsWriteFinish == false) goto label_219;
        if(this.IsWriteFinish == false)
        {
            goto label_219;
        }
        // 0x00B31830: MOV x0, x19                | X0 = 1152921515154058880 (0x1000000274A9AE80);//ML01
        // 0x00B31834: STRB wzr, [x19, #0x60]     | this.IsWriteFinish = false;              //  dest_result_addr=1152921515154058976
        this.IsWriteFinish = false;
        // 0x00B31838: BL #0xb30268               | this.Clear();                           
        this.Clear();
        // 0x00B3183C: LDR x0, [x19, #0x70]       | X0 = this.writeDownFinishCall; //P2     
        // 0x00B31840: CBZ x0, #0xb3184c          | if (this.writeDownFinishCall == null) goto label_219;
        if(this.writeDownFinishCall == null)
        {
            goto label_219;
        }
        // 0x00B31844: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31848: BL #0x26e3100              | this.writeDownFinishCall.Invoke();      
        this.writeDownFinishCall.Invoke();
        label_219:
        // 0x00B3184C: SUB sp, x29, #0x60         | SP = (1152921515154046864 - 96) = 1152921515154046768 (0x1000000274A97F30);
        // 0x00B31850: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B31854: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B31858: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B3185C: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00B31860: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00B31864: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00B31868: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00B3186C: RET                        |  return;                                
        return;
        label_161:
        // 0x00B31870: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00B31874: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00B31878: LDR x23, [x8]              | X23 = typeof(System.Object[]);          
        // 0x00B3187C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B31880: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B31884: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B31888: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B3188C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B31890: LDR x23, [x19, #0x20]      | X23 = this.updateDic; //P2              
        // 0x00B31894: LDR x24, [x19, #0x28]      | X24 = this.wwwGroups; //P2              
        // 0x00B31898: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B3189C: CBNZ x24, #0xb318a4        | if (this.wwwGroups != null) goto label_203;
        if(this.wwwGroups != null)
        {
            goto label_203;
        }
        // 0x00B318A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_203:
        // 0x00B318A4: LDR x2, [x27]              | X2 = public Mihua.Net.UrlLoader System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Item(int index);
        // 0x00B318A8: MOV x0, x24                | X0 = this.wwwGroups;//m1                
        // 0x00B318AC: MOV w1, w20                | W1 = 0 (0x0);//ML01                     
        // 0x00B318B0: BL #0x25ed734              | X0 = this.wwwGroups.get_Item(index:  0);
        Mihua.Net.UrlLoader val_138 = this.wwwGroups.Item[0];
        // 0x00B318B4: MOV x20, x0                | X20 = val_138;//m1                      
        // 0x00B318B8: CBNZ x20, #0xb318c0        | if (val_138 != null) goto label_204;    
        if(val_138 != null)
        {
            goto label_204;
        }
        // 0x00B318BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_138, ????);    
        label_204:
        // 0x00B318C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B318C4: MOV x0, x20                | X0 = val_138;//m1                       
        // 0x00B318C8: BL #0xabe980               | X0 = val_138.get_url();                 
        string val_139 = val_138.url;
        // 0x00B318CC: MOV x20, x0                | X20 = val_139;//m1                      
        // 0x00B318D0: CBNZ x23, #0xb318d8        | if (this.updateDic != null) goto label_205;
        if(this.updateDic != null)
        {
            goto label_205;
        }
        // 0x00B318D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_139, ????);    
        label_205:
        // 0x00B318D8: LDR x2, [x26]              | X2 = public FileInfoRes System.Collections.Generic.Dictionary<System.String, FileInfoRes>::get_Item(System.String key);
        // 0x00B318DC: MOV x0, x23                | X0 = this.updateDic;//m1                
        // 0x00B318E0: MOV x1, x20                | X1 = val_139;//m1                       
        // 0x00B318E4: BL #0x23fc26c              | X0 = this.updateDic.get_Item(key:  val_139);
        FileInfoRes val_140 = this.updateDic.Item[val_139];
        // 0x00B318E8: MOV x20, x0                | X20 = val_140;//m1                      
        // 0x00B318EC: CBNZ x20, #0xb318f4        | if (val_140 != null) goto label_206;    
        if(val_140 != null)
        {
            goto label_206;
        }
        // 0x00B318F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_140, ????);    
        label_206:
        // 0x00B318F4: LDR x20, [x20, #0x10]      | 
        // 0x00B318F8: CBNZ x19, #0xb31900        | if ( != null) goto label_207;           
        if(null != null)
        {
            goto label_207;
        }
        // 0x00B318FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_140, ????);    
        label_207:
        // 0x00B31900: CBZ x20, #0xb31924         | if (val_140 == null) goto label_209;    
        if(val_140 == null)
        {
            goto label_209;
        }
        // 0x00B31904: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B31908: MOV x0, x20                | X0 = val_140;//m1                       
        // 0x00B3190C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B31910: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_140, ????);    
        // 0x00B31914: CBNZ x0, #0xb31924         | if (val_140 != null) goto label_209;    
        if(val_140 != null)
        {
            goto label_209;
        }
        // 0x00B31918: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_140, ????);    
        // 0x00B3191C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31920: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_140, ????);    
        label_209:
        // 0x00B31924: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B31928: CBNZ w8, #0xb31938         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_210;
        // 0x00B3192C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_140, ????);    
        // 0x00B31930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31934: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_140, ????);    
        label_210:
        // 0x00B31938: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_140;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_140;
        // 0x00B3193C: CBZ x21, #0xb31960         | if (val_103 == null) goto label_212;    
        if(val_103 == null)
        {
            goto label_212;
        }
        // 0x00B31940: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B31944: MOV x0, x21                | X0 = val_103;//m1                       
        // 0x00B31948: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B3194C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_103, ????);    
        // 0x00B31950: CBNZ x0, #0xb31960         | if (val_103 != null) goto label_212;    
        if(val_103 != null)
        {
            goto label_212;
        }
        // 0x00B31954: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_103, ????);    
        // 0x00B31958: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3195C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_103, ????);    
        label_212:
        // 0x00B31960: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B31964: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B31968: B.HI #0xb31978             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_213;
        // 0x00B3196C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_103, ????);    
        // 0x00B31970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31974: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_103, ????);    
        label_213:
        // 0x00B31978: STR x21, [x19, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_103;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_103;
        // 0x00B3197C: CBZ x22, #0xb319a0         | if (val_106.mDataMD5 == null) goto label_215;
        if(val_106.mDataMD5 == null)
        {
            goto label_215;
        }
        // 0x00B31980: LDR x8, [x19]              | X8 = ;                                  
        // 0x00B31984: MOV x0, x22                | X0 = val_106.mDataMD5;//m1              
        // 0x00B31988: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B3198C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_106.mDataMD5, ????);
        // 0x00B31990: CBNZ x0, #0xb319a0         | if (val_106.mDataMD5 != null) goto label_215;
        if(val_106.mDataMD5 != null)
        {
            goto label_215;
        }
        // 0x00B31994: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_106.mDataMD5, ????);
        // 0x00B31998: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3199C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_106.mDataMD5, ????);
        label_215:
        // 0x00B319A0: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B319A4: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B319A8: B.HI #0xb319b8             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_216;
        // 0x00B319AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_106.mDataMD5, ????);
        // 0x00B319B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B319B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_106.mDataMD5, ????);
        label_216:
        // 0x00B319B8: STR x22, [x19, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = val_106.mDataMD5;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_106.mDataMD5;
        // 0x00B319BC: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00B319C0: LDR x8, [x8, #0x8e8]       | X8 = (string**)(1152921515154030656)("{0}资源下载{1}:{2}________error");
        // 0x00B319C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B319C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B319CC: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B319D0: LDR x1, [x8]               | X1 = "{0}资源下载{1}:{2}________error";     
        // 0x00B319D4: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}资源下载{1}:{2}________error");
        string val_141 = EString.EFormat(format:  0, args:  "{0}资源下载{1}:{2}________error");
        // 0x00B319D8: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B319DC: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B319E0: MOV x19, x0                | X19 = val_141;//m1                      
        // 0x00B319E4: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B319E8: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B319EC: TBZ w9, #0, #0xb31a00      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_218;
        // 0x00B319F0: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B319F4: CBNZ w9, #0xb31a00         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_218;
        // 0x00B319F8: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B319FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_218:
        // 0x00B31A00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B31A04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B31A08: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B31A0C: MOV x1, x19                | X1 = val_141;//m1                       
        // 0x00B31A10: BL #0xb5b538               | EDebug.LogError(message:  0, isShowStack:  val_141);
        EDebug.LogError(message:  0, isShowStack:  val_141);
        // 0x00B31A14: B #0xb3184c                |  goto label_219;                        
        goto label_219;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B31ECC (11738828), len: 368  VirtAddr: 0x00B31ECC RVA: 0x00B31ECC token: 100694322 methodIndex: 24933 delegateWrapperIndex: 0 methodInvoker: 0
    private bool DownNext()
    {
        //
        // Disasemble & Code
        // 0x00B31ECC: STP x22, x21, [sp, #-0x30]! | stack[1152921515155100912] = ???;  stack[1152921515155100920] = ???;  //  dest_result_addr=1152921515155100912 |  dest_result_addr=1152921515155100920
        // 0x00B31ED0: STP x20, x19, [sp, #0x10]  | stack[1152921515155100928] = ???;  stack[1152921515155100936] = ???;  //  dest_result_addr=1152921515155100928 |  dest_result_addr=1152921515155100936
        // 0x00B31ED4: STP x29, x30, [sp, #0x20]  | stack[1152921515155100944] = ???;  stack[1152921515155100952] = ???;  //  dest_result_addr=1152921515155100944 |  dest_result_addr=1152921515155100952
        // 0x00B31ED8: ADD x29, sp, #0x20         | X29 = (1152921515155100912 + 32) = 1152921515155100944 (0x1000000274B99510);
        // 0x00B31EDC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B31EE0: LDRB w8, [x20, #0x795]     | W8 = (bool)static_value_03733795;       
        // 0x00B31EE4: MOV x19, x0                | X19 = 1152921515155112960 (0x1000000274B9C400);//ML01
        // 0x00B31EE8: TBNZ w8, #0, #0xb31f04     | if (static_value_03733795 == true) goto label_0;
        // 0x00B31EEC: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00B31EF0: LDR x8, [x8, #0xa8]        | X8 = 0x2B8EAD0;                         
        // 0x00B31EF4: LDR w0, [x8]               | W0 = 0x1174;                            
        // 0x00B31EF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1174, ????);     
        // 0x00B31EFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B31F00: STRB w8, [x20, #0x795]     | static_value_03733795 = true;            //  dest_result_addr=57882517
        label_0:
        // 0x00B31F04: LDR x20, [x19, #0x28]      | X20 = this.wwwGroups; //P2              
        // 0x00B31F08: CBNZ x20, #0xb31f10        | if (this.wwwGroups != null) goto label_1;
        if(this.wwwGroups != null)
        {
            goto label_1;
        }
        // 0x00B31F0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1174, ????);     
        label_1:
        // 0x00B31F10: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B31F14: LDR x8, [x8, #0xe90]       | X8 = 1152921514964866176;               
        // 0x00B31F18: MOV x0, x20                | X0 = this.wwwGroups;//m1                
        // 0x00B31F1C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<Mihua.Net.UrlLoader>::get_Count();
        // 0x00B31F20: BL #0x25ed72c              | X0 = this.wwwGroups.get_Count();        
        int val_1 = this.wwwGroups.Count;
        // 0x00B31F24: LDR w8, [x19, #0x40]       | W8 = this.MAXDOWNFILE; //P2             
        // 0x00B31F28: CMP w0, w8                 | STATE = COMPARE(val_1, this.MAXDOWNFILE)
        // 0x00B31F2C: B.GE #0xb31f90             | if (val_1 >= this.MAXDOWNFILE) goto label_4;
        if(val_1 >= this.MAXDOWNFILE)
        {
            goto label_4;
        }
        // 0x00B31F30: LDR x20, [x19, #0x30]      | X20 = this.waitUrlGroups; //P2          
        // 0x00B31F34: CBNZ x20, #0xb31f3c        | if (this.waitUrlGroups != null) goto label_3;
        if(this.waitUrlGroups != null)
        {
            goto label_3;
        }
        // 0x00B31F38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B31F3C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B31F40: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
        // 0x00B31F44: MOV x0, x20                | X0 = this.waitUrlGroups;//m1            
        // 0x00B31F48: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B31F4C: BL #0x25ed72c              | X0 = this.waitUrlGroups.get_Count();    
        int val_2 = this.waitUrlGroups.Count;
        // 0x00B31F50: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
        // 0x00B31F54: B.LT #0xb31f90             | if (val_2 < 1) goto label_4;            
        if(val_2 < 1)
        {
            goto label_4;
        }
        // 0x00B31F58: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00B31F5C: LDR x8, [x8, #0x510]       | X8 = 1152921514965976448;               
        // 0x00B31F60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B31F64: LDR x1, [x8]               | X1 = public static Mihua.Assets.UnzipAssetMgr Singleton<Mihua.Assets.UnzipAssetMgr>::get_Instance();
        // 0x00B31F68: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
        ILAssetMgr val_3 = Singleton<ILAssetMgr>.Instance;
        // 0x00B31F6C: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B31F70: CBNZ x20, #0xb31f78        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00B31F74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B31F78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B31F7C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B31F80: BL #0xabfaa8               | X0 = val_3.get_UnZipFileCount();        
        int val_4 = val_3.UnZipFileCount;
        // 0x00B31F84: LDR w8, [x19, #0x44]       | W8 = this.MAXUNZIPFILE; //P2            
        // 0x00B31F88: CMP w0, w8                 | STATE = COMPARE(val_4, this.MAXUNZIPFILE)
        // 0x00B31F8C: B.LE #0xb31fa4             | if (val_4 <= this.MAXUNZIPFILE) goto label_6;
        if(val_4 <= this.MAXUNZIPFILE)
        {
            goto label_6;
        }
        label_4:
        // 0x00B31F90: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        label_10:
        // 0x00B31F94: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B31F98: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B31F9C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B31FA0: RET                        |  return (System.Boolean)false;          
        return (bool)0;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_6:
        // 0x00B31FA4: LDR x20, [x19, #0x30]      | X20 = this.waitUrlGroups; //P2          
        // 0x00B31FA8: CBNZ x20, #0xb31fb0        | if (this.waitUrlGroups != null) goto label_7;
        if(this.waitUrlGroups != null)
        {
            goto label_7;
        }
        // 0x00B31FAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B31FB0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
        // 0x00B31FB4: LDR x8, [x8, #0xb50]       | X8 = 1152921510890998992;               
        // 0x00B31FB8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B31FBC: MOV x0, x20                | X0 = this.waitUrlGroups;//m1            
        // 0x00B31FC0: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
        // 0x00B31FC4: BL #0x25ed734              | X0 = this.waitUrlGroups.get_Item(index:  0);
        string val_5 = this.waitUrlGroups.Item[0];
        // 0x00B31FC8: LDR x21, [x19, #0x30]      | X21 = this.waitUrlGroups; //P2          
        // 0x00B31FCC: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B31FD0: CBNZ x21, #0xb31fd8        | if (this.waitUrlGroups != null) goto label_8;
        if(this.waitUrlGroups != null)
        {
            goto label_8;
        }
        // 0x00B31FD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B31FD8: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B31FDC: LDR x8, [x8, #0xa30]       | X8 = 1152921510892175824;               
        // 0x00B31FE0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B31FE4: MOV x0, x21                | X0 = this.waitUrlGroups;//m1            
        // 0x00B31FE8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::RemoveAt(int index);
        // 0x00B31FEC: BL #0x25ed00c              | this.waitUrlGroups.RemoveAt(index:  0); 
        this.waitUrlGroups.RemoveAt(index:  0);
        // 0x00B31FF0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00B31FF4: LDR x8, [x8, #0xc98]       | X8 = 1152921504903864320;               
        // 0x00B31FF8: LDR x0, [x8]               | X0 = typeof(Mihua.Net.UrlLoader);       
        Mihua.Net.UrlLoader val_6 = null;
        // 0x00B31FFC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Mihua.Net.UrlLoader), ????);
        // 0x00B32000: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B32004: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x00B32008: MOV x21, x0                | X21 = 1152921504903864320 (0x1000000011B42000);//ML01
        // 0x00B3200C: BL #0xabda64               | .ctor(url:  val_5);                     
        val_6 = new Mihua.Net.UrlLoader(url:  val_5);
        // 0x00B32010: LDR x19, [x19, #0x28]      | X19 = this.wwwGroups; //P2              
        // 0x00B32014: CBNZ x19, #0xb3201c        | if (this.wwwGroups != null) goto label_9;
        if(this.wwwGroups != null)
        {
            goto label_9;
        }
        // 0x00B32018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(url:  val_5), ????);
        label_9:
        // 0x00B3201C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B32020: LDR x8, [x8, #0x280]       | X8 = 1152921514964362496;               
        // 0x00B32024: MOV x0, x19                | X0 = this.wwwGroups;//m1                
        // 0x00B32028: MOV x1, x21                | X1 = 1152921504903864320 (0x1000000011B42000);//ML01
        // 0x00B3202C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Mihua.Net.UrlLoader>::Add(Mihua.Net.UrlLoader item);
        // 0x00B32030: BL #0x25ea480              | this.wwwGroups.Add(item:  val_6);       
        this.wwwGroups.Add(item:  val_6);
        // 0x00B32034: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        // 0x00B32038: B #0xb31f94                |  goto label_10;                         
        goto label_10;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B31DE0 (11738592), len: 236  VirtAddr: 0x00B31DE0 RVA: 0x00B31DE0 token: 100694323 methodIndex: 24934 delegateWrapperIndex: 0 methodInvoker: 0
    private void SaveBytes(byte[] bytes, FileInfoRes assetData)
    {
        //
        // Disasemble & Code
        // 0x00B31DE0: STP x26, x25, [sp, #-0x50]! | stack[1152921515155287632] = ???;  stack[1152921515155287640] = ???;  //  dest_result_addr=1152921515155287632 |  dest_result_addr=1152921515155287640
        // 0x00B31DE4: STP x24, x23, [sp, #0x10]  | stack[1152921515155287648] = ???;  stack[1152921515155287656] = ???;  //  dest_result_addr=1152921515155287648 |  dest_result_addr=1152921515155287656
        // 0x00B31DE8: STP x22, x21, [sp, #0x20]  | stack[1152921515155287664] = ???;  stack[1152921515155287672] = ???;  //  dest_result_addr=1152921515155287664 |  dest_result_addr=1152921515155287672
        // 0x00B31DEC: STP x20, x19, [sp, #0x30]  | stack[1152921515155287680] = ???;  stack[1152921515155287688] = ???;  //  dest_result_addr=1152921515155287680 |  dest_result_addr=1152921515155287688
        // 0x00B31DF0: STP x29, x30, [sp, #0x40]  | stack[1152921515155287696] = ???;  stack[1152921515155287704] = ???;  //  dest_result_addr=1152921515155287696 |  dest_result_addr=1152921515155287704
        // 0x00B31DF4: ADD x29, sp, #0x40         | X29 = (1152921515155287632 + 64) = 1152921515155287696 (0x1000000274BC6E90);
        // 0x00B31DF8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B31DFC: LDRB w8, [x21, #0x796]     | W8 = (bool)static_value_03733796;       
        // 0x00B31E00: MOV x20, x2                | X20 = assetData;//m1                    
        // 0x00B31E04: MOV x19, x1                | X19 = bytes;//m1                        
        // 0x00B31E08: MOV x22, x0                | X22 = 1152921515155299712 (0x1000000274BC9D80);//ML01
        // 0x00B31E0C: TBNZ w8, #0, #0xb31e28     | if (static_value_03733796 == true) goto label_0;
        // 0x00B31E10: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B31E14: LDR x8, [x8, #0xd28]       | X8 = 0x2B8EAE4;                         
        // 0x00B31E18: LDR w0, [x8]               | W0 = 0x1179;                            
        // 0x00B31E1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1179, ????);     
        // 0x00B31E20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B31E24: STRB w8, [x21, #0x796]     | static_value_03733796 = true;            //  dest_result_addr=57882518
        label_0:
        // 0x00B31E28: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00B31E2C: LDR x8, [x8, #0x510]       | X8 = 1152921514965976448;               
        // 0x00B31E30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B31E34: LDR x1, [x8]               | X1 = public static Mihua.Assets.UnzipAssetMgr Singleton<Mihua.Assets.UnzipAssetMgr>::get_Instance();
        // 0x00B31E38: BL #0x1a04438              | X0 = Singleton<ILAssetMgr>.get_Instance();
        ILAssetMgr val_1 = Singleton<ILAssetMgr>.Instance;
        // 0x00B31E3C: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B31E40: CBNZ x20, #0xb31e48        | if (assetData != null) goto label_1;    
        if(assetData != null)
        {
            goto label_1;
        }
        // 0x00B31E44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B31E48: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
        // 0x00B31E4C: ADRP x9, #0x363c000        | X9 = 56868864 (0x363C000);              
        // 0x00B31E50: LDR x23, [x20, #0x10]      | 
        // 0x00B31E54: LDR x8, [x8, #0x28]        | X8 = 1152921515155274688;               
        // 0x00B31E58: LDR x9, [x9, #0x9b8]       | X9 = 1152921504687890432;               
        // 0x00B31E5C: LDR x25, [x8]              | X25 = System.Void AssetDownMgr::OnUnzip(byte[] bytes, string assetName);
        // 0x00B31E60: LDR x0, [x9]               | X0 = typeof(System.Action<T1, T2>);     
        System.Action<System.Byte[], System.String> val_2 = null;
        // 0x00B31E64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action<T1, T2>), ????);
        // 0x00B31E68: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00B31E6C: LDR x8, [x8, #0xda0]       | X8 = 1152921514965982592;               
        // 0x00B31E70: MOV x1, x22                | X1 = 1152921515155299712 (0x1000000274BC9D80);//ML01
        // 0x00B31E74: MOV x2, x25                | X2 = 1152921515155274688 (0x1000000274BC3BC0);//ML01
        // 0x00B31E78: MOV x24, x0                | X24 = 1152921504687890432 (0x1000000004D4A000);//ML01
        // 0x00B31E7C: LDR x3, [x8]               | X3 = public System.Void System.Action<System.Byte[], System.String>::.ctor(object object, IntPtr method);
        // 0x00B31E80: BL #0x12a30ec              | .ctor(object:  this, method:  System.Void AssetDownMgr::OnUnzip(byte[] bytes, string assetName));
        val_2 = new System.Action<System.Byte[], System.String>(object:  this, method:  System.Void AssetDownMgr::OnUnzip(byte[] bytes, string assetName));
        // 0x00B31E84: CBNZ x20, #0xb31e8c        | if (assetData != null) goto label_2;    
        if(assetData != null)
        {
            goto label_2;
        }
        // 0x00B31E88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void AssetDownMgr::OnUnzip(byte[] bytes, string assetName)), ????);
        label_2:
        // 0x00B31E8C: LDRB w20, [x20, #0x2c]     | W20 = assetData.isCompress; //P2        
        // 0x00B31E90: CBNZ x21, #0xb31e98        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B31E94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  System.Void AssetDownMgr::OnUnzip(byte[] bytes, string assetName)), ????);
        label_3:
        // 0x00B31E98: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B31E9C: CMP w20, #0                | STATE = COMPARE(assetData.isCompress, 0x0)
        // 0x00B31EA0: MOV x0, x21                | X0 = val_1;//m1                         
        // 0x00B31EA4: MOV x1, x19                | X1 = bytes;//m1                         
        // 0x00B31EA8: MOV x2, x23                | X2 = X23;//m1                           
        // 0x00B31EAC: MOV x3, x24                | X3 = 1152921504687890432 (0x1000000004D4A000);//ML01
        // 0x00B31EB0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B31EB4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B31EB8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B31EBC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B31EC0: CSET w4, ne                | W4 = assetData.isCompress == true ? 1 : 0;
        bool val_3 = (assetData.isCompress == true) ? 1 : 0;
        // 0x00B31EC4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B31EC8: B #0xabefd4                | val_1.AddUnzip(bytes:  bytes, key:  X23, callBack:  val_2, isCompress:  bool val_3 = (assetData.isCompress == true) ? 1 : 0); return;
        val_1.AddUnzip(bytes:  bytes, key:  X23, callBack:  val_2, isCompress:  val_3);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B3203C (11739196), len: 4  VirtAddr: 0x00B3203C RVA: 0x00B3203C token: 100694324 methodIndex: 24935 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnUnzip(byte[] bytes, string assetName)
    {
        //
        // Disasemble & Code
        // 0x00B3203C: B #0xb32040                | this.SaveBytesToFile(bytes:  bytes, assetName:  assetName); return;
        this.SaveBytesToFile(bytes:  bytes, assetName:  assetName);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B32040 (11739200), len: 2336  VirtAddr: 0x00B32040 RVA: 0x00B32040 token: 100694325 methodIndex: 24936 delegateWrapperIndex: 0 methodInvoker: 0
    private void SaveBytesToFile(byte[] bytes, string assetName)
    {
        //
        // Disasemble & Code
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_32;
        //  | 
        float val_33;
        // 0x00B32040: STP x28, x27, [sp, #-0x60]! | stack[1152921515155820224] = ???;  stack[1152921515155820232] = ???;  //  dest_result_addr=1152921515155820224 |  dest_result_addr=1152921515155820232
        // 0x00B32044: STP x26, x25, [sp, #0x10]  | stack[1152921515155820240] = ???;  stack[1152921515155820248] = ???;  //  dest_result_addr=1152921515155820240 |  dest_result_addr=1152921515155820248
        // 0x00B32048: STP x24, x23, [sp, #0x20]  | stack[1152921515155820256] = ???;  stack[1152921515155820264] = ???;  //  dest_result_addr=1152921515155820256 |  dest_result_addr=1152921515155820264
        // 0x00B3204C: STP x22, x21, [sp, #0x30]  | stack[1152921515155820272] = ???;  stack[1152921515155820280] = ???;  //  dest_result_addr=1152921515155820272 |  dest_result_addr=1152921515155820280
        // 0x00B32050: STP x20, x19, [sp, #0x40]  | stack[1152921515155820288] = ???;  stack[1152921515155820296] = ???;  //  dest_result_addr=1152921515155820288 |  dest_result_addr=1152921515155820296
        // 0x00B32054: STP x29, x30, [sp, #0x50]  | stack[1152921515155820304] = ???;  stack[1152921515155820312] = ???;  //  dest_result_addr=1152921515155820304 |  dest_result_addr=1152921515155820312
        // 0x00B32058: ADD x29, sp, #0x50         | X29 = (1152921515155820224 + 80) = 1152921515155820304 (0x1000000274C48F10);
        // 0x00B3205C: SUB sp, sp, #0x20          | SP = (1152921515155820224 - 32) = 1152921515155820192 (0x1000000274C48EA0);
        // 0x00B32060: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B32064: LDRB w8, [x22, #0x797]     | W8 = (bool)static_value_03733797;       
        // 0x00B32068: MOV x19, x2                | X19 = assetName;//m1                    
        // 0x00B3206C: MOV x21, x1                | X21 = bytes;//m1                        
        // 0x00B32070: MOV x20, x0                | X20 = 1152921515155832320 (0x1000000274C4BE00);//ML01
        // 0x00B32074: TBNZ w8, #0, #0xb32090     | if (static_value_03733797 == true) goto label_0;
        // 0x00B32078: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B3207C: LDR x8, [x8, #0x620]       | X8 = 0x2B8EAE8;                         
        // 0x00B32080: LDR w0, [x8]               | W0 = 0x117A;                            
        // 0x00B32084: BL #0x2782188              | X0 = sub_2782188( ?? 0x117A, ????);     
        // 0x00B32088: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B3208C: STRB w8, [x22, #0x797]     | static_value_03733797 = true;            //  dest_result_addr=57882519
        label_0:
        // 0x00B32090: CBNZ x19, #0xb32098        | if (assetName != null) goto label_1;    
        if(assetName != null)
        {
            goto label_1;
        }
        // 0x00B32094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x117A, ????);     
        label_1:
        // 0x00B32098: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B3209C: LDR x8, [x8, #0xfc8]       | X8 = (string**)(1152921514967116720)("_csscript.uab");
        // 0x00B320A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B320A4: MOV x0, x19                | X0 = assetName;//m1                     
        // 0x00B320A8: LDR x1, [x8]               | X1 = "_csscript.uab";                   
        // 0x00B320AC: BL #0x18ab0a0              | X0 = assetName.EndsWith(value:  "_csscript.uab");
        bool val_1 = assetName.EndsWith(value:  "_csscript.uab");
        // 0x00B320B0: TBZ w0, #0, #0xb3226c      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00B320B4: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B320B8: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B320BC: LDR x0, [x8]               | X0 = typeof(Mihua.Update.VSTools);      
        // 0x00B320C0: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B320C4: TBZ w8, #0, #0xb320d4      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B320C8: LDR w8, [x0, #0xbc]        | W8 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B320CC: CBNZ w8, #0xb320d4         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B320D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_4:
        // 0x00B320D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B320D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B320DC: MOV x1, x21                | X1 = bytes;//m1                         
        // 0x00B320E0: BL #0xac28b4               | X0 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        string val_2 = Mihua.Update.VSTools.GetMD5(bytes:  0);
        // 0x00B320E4: LDR x23, [x20, #0x18]      | X23 = this.updateCrcDic; //P2           
        // 0x00B320E8: MOV x22, x0                | X22 = val_2;//m1                        
        // 0x00B320EC: CBNZ x23, #0xb320f4        | if (this.updateCrcDic != null) goto label_5;
        if(this.updateCrcDic != null)
        {
            goto label_5;
        }
        // 0x00B320F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B320F4: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00B320F8: LDR x8, [x8, #0x90]        | X8 = 1152921510817398768;               
        // 0x00B320FC: MOV x0, x23                | X0 = this.updateCrcDic;//m1             
        // 0x00B32100: MOV x1, x19                | X1 = assetName;//m1                     
        // 0x00B32104: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B32108: BL #0x23fc26c              | X0 = this.updateCrcDic.get_Item(key:  assetName);
        string val_3 = this.updateCrcDic.Item[assetName];
        // 0x00B3210C: ADRP x24, #0x35d6000       | X24 = 56451072 (0x35D6000);             
        // 0x00B32110: LDR x24, [x24, #0xe38]     | X24 = 1152921504608284672;              
        // 0x00B32114: MOV x23, x0                | X23 = val_3;//m1                        
        // 0x00B32118: LDR x8, [x24]              | X8 = typeof(System.String);             
        // 0x00B3211C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B32120: TBZ w9, #0, #0xb32134      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B32124: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B32128: CBNZ w9, #0xb32134         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B3212C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B32130: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_7:
        // 0x00B32134: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32138: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B3213C: MOV x1, x22                | X1 = val_2;//m1                         
        // 0x00B32140: MOV x2, x23                | X2 = val_3;//m1                         
        // 0x00B32144: BL #0x18a1020              | X0 = System.String.op_Inequality(a:  0, b:  val_2);
        bool val_4 = System.String.op_Inequality(a:  0, b:  val_2);
        // 0x00B32148: TBZ w0, #0, #0xb321bc      | if (val_4 == false) goto label_8;       
        if(val_4 == false)
        {
            goto label_8;
        }
        // 0x00B3214C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B32150: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B32154: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B32158: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B3215C: TBZ w8, #0, #0xb3216c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B32160: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B32164: CBNZ w8, #0xb3216c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B32168: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_10:
        // 0x00B3216C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00B32170: LDR x8, [x8, #0x318]       | X8 = (string**)(1152921515155679936)("csscript save bytes error!!! ");
        // 0x00B32174: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32178: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B3217C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B32180: LDR x1, [x8]               | X1 = "csscript save bytes error!!! ";   
        // 0x00B32184: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00B32188: BL #0xb145d8               | X0 = ABCheckUpdate.get_Instance();      
        ABCheckUpdate val_5 = ABCheckUpdate.Instance;
        // 0x00B3218C: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B32190: CBNZ x19, #0xb32198        | if (val_5 != null) goto label_11;       
        if(val_5 != null)
        {
            goto label_11;
        }
        // 0x00B32194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00B32198: MOV x0, x19                | X0 = val_5;//m1                         
        // 0x00B3219C: SUB sp, x29, #0x50         | SP = (1152921515155820304 - 80) = 1152921515155820224 (0x1000000274C48EC0);
        // 0x00B321A0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B321A4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B321A8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B321AC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B321B0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B321B4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B321B8: B #0xb19498                | val_5.StartCsDown(); return;            
        val_5.StartCsDown();
        return;
        label_8:
        // 0x00B321BC: ADRP x22, #0x35ef000       | X22 = 56553472 (0x35EF000);             
        // 0x00B321C0: LDR x22, [x22, #0xde8]     | X22 = 1152921504911265792;              
        // 0x00B321C4: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        val_29 = null;
        // 0x00B321C8: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B321CC: TBZ w8, #0, #0xb321e0      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B321D0: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B321D4: CBNZ w8, #0xb321e0         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B321D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B321DC: LDR x0, [x22]              | X0 = typeof(Loader.PathUtil);           
        val_29 = null;
        label_13:
        // 0x00B321E0: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B321E4: LDR x0, [x24]              | X0 = typeof(System.String);             
        // 0x00B321E8: LDR x22, [x8, #0x28]       | X22 = Loader.PathUtil.persistentDataPath;
        // 0x00B321EC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B321F0: TBZ w8, #0, #0xb32200      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B321F4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B321F8: CBNZ w8, #0xb32200         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B321FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_15:
        // 0x00B32200: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B32204: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921515143247648)("libil2cpp.so");
        // 0x00B32208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3220C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B32210: MOV x1, x22                | X1 = Loader.PathUtil.persistentDataPath;//m1
        // 0x00B32214: LDR x2, [x8]               | X2 = "libil2cpp.so";                    
        // 0x00B32218: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        string val_6 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        // 0x00B3221C: MOV x1, x0                 | X1 = val_6;//m1                         
        // 0x00B32220: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32224: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B32228: MOV x2, x21                | X2 = bytes;//m1                         
        // 0x00B3222C: BL #0x1e71f34              | System.IO.File.WriteAllBytes(path:  0, bytes:  val_6);
        System.IO.File.WriteAllBytes(path:  0, bytes:  val_6);
        // 0x00B32230: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B32234: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B32238: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00B3223C: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B32240: TBZ w8, #0, #0xb32250      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B32244: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B32248: CBNZ w8, #0xb32250         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B3224C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_17:
        // 0x00B32250: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00B32254: LDR x8, [x8, #0x228]       | X8 = (string**)(1152921515155688256)("csscript copy success!!! ");
        // 0x00B32258: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3225C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B32260: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B32264: LDR x1, [x8]               | X1 = "csscript copy success!!! ";       
        // 0x00B32268: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        label_2:
        // 0x00B3226C: ADRP x26, #0x35ef000       | X26 = 56553472 (0x35EF000);             
        // 0x00B32270: LDR x26, [x26, #0xde8]     | X26 = 1152921504911265792;              
        // 0x00B32274: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        val_30 = null;
        // 0x00B32278: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B3227C: TBZ w8, #0, #0xb32290      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B32280: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B32284: CBNZ w8, #0xb32290         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B32288: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B3228C: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        val_30 = null;
        label_19:
        // 0x00B32290: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
        // 0x00B32294: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B32298: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
        // 0x00B3229C: LDR x22, [x8, #0x28]       | X22 = Loader.PathUtil.persistentDataPath;
        // 0x00B322A0: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x00B322A4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B322A8: TBZ w8, #0, #0xb322b8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00B322AC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B322B0: CBNZ w8, #0xb322b8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00B322B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_21:
        // 0x00B322B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B322BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B322C0: MOV x1, x22                | X1 = Loader.PathUtil.persistentDataPath;//m1
        // 0x00B322C4: MOV x2, x19                | X2 = assetName;//m1                     
        // 0x00B322C8: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        string val_7 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        // 0x00B322CC: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B322D0: LDR x8, [x8, #0x48]        | X8 = 1152921504621170688;               
        // 0x00B322D4: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00B322D8: LDR x8, [x8]               | X8 = typeof(System.IO.FileInfo);        
        // 0x00B322DC: MOV x0, x8                 | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        System.IO.FileInfo val_8 = null;
        // 0x00B322E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileInfo), ????);
        // 0x00B322E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B322E8: MOV x1, x23                | X1 = val_7;//m1                         
        // 0x00B322EC: MOV x22, x0                | X22 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B322F0: BL #0x1e6e0a0              | .ctor(fileName:  val_7);                
        val_8 = new System.IO.FileInfo(fileName:  val_7);
        // 0x00B322F4: CBNZ x22, #0xb322fc        | if ( != 0) goto label_22;               
        if(null != 0)
        {
            goto label_22;
        }
        // 0x00B322F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(fileName:  val_7), ????);
        label_22:
        // 0x00B322FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32300: MOV x0, x22                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B32304: BL #0x1e72848              | X0 = get_Directory();                   
        System.IO.DirectoryInfo val_9 = Directory;
        // 0x00B32308: MOV x24, x0                | X24 = val_9;//m1                        
        // 0x00B3230C: CBNZ x24, #0xb32314        | if (val_9 != null) goto label_23;       
        if(val_9 != null)
        {
            goto label_23;
        }
        // 0x00B32310: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_23:
        // 0x00B32314: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32318: MOV x0, x24                | X0 = val_9;//m1                         
        // 0x00B3231C: BL #0x1e698c4              | val_9.Create();                         
        val_9.Create();
        // 0x00B32320: CBNZ x19, #0xb32328        | if (assetName != null) goto label_24;   
        if(assetName != null)
        {
            goto label_24;
        }
        // 0x00B32324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_24:
        // 0x00B32328: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
        // 0x00B3232C: LDR x8, [x8, #0xa8]        | X8 = (string**)(1152921515142833760)("assets_bin_Data");
        // 0x00B32330: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B32334: MOV x0, x19                | X0 = assetName;//m1                     
        // 0x00B32338: LDR x1, [x8]               | X1 = "assets_bin_Data";                 
        // 0x00B3233C: BL #0x18ad42c              | X0 = assetName.Contains(value:  "assets_bin_Data");
        bool val_10 = assetName.Contains(value:  "assets_bin_Data");
        // 0x00B32340: TBZ w0, #0, #0xb323b0      | if (val_10 == false) goto label_25;     
        if(val_10 == false)
        {
            goto label_25;
        }
        // 0x00B32344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32348: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3234C: MOV x1, x21                | X1 = bytes;//m1                         
        // 0x00B32350: BL #0xab7c8c               | X0 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  0);
        System.Byte[] val_11 = Mihua.Assets.UnzipAssetMgr.BZip2DeCompression(bytes:  0);
        // 0x00B32354: LDR x8, [x28]              | X8 = typeof(System.String);             
        val_31 = null;
        // 0x00B32358: MOV x24, x0                | X24 = val_11;//m1                       
        // 0x00B3235C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00B32360: TBZ w9, #0, #0xb32378      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00B32364: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B32368: CBNZ w9, #0xb32378         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00B3236C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00B32370: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B32374: LDR x8, [x28]              | X8 = typeof(System.String);             
        val_31 = null;
        label_27:
        // 0x00B32378: ADRP x9, #0x361f000        | X9 = 56750080 (0x361F000);              
        // 0x00B3237C: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B32380: LDR x9, [x9, #0xda8]       | X9 = (string**)(1152921515142907600)(".uab");
        // 0x00B32384: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32388: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B3238C: LDR x3, [x8]               | X3 = System.String.Empty;               
        // 0x00B32390: LDR x2, [x9]               | X2 = ".uab";                            
        // 0x00B32394: MOV x1, x23                | X1 = val_7;//m1                         
        // 0x00B32398: BL #0x27954f0              | X0 = EString.EReplace(t:  0, oldString:  val_7, newString:  ".uab");
        string val_12 = EString.EReplace(t:  0, oldString:  val_7, newString:  ".uab");
        // 0x00B3239C: MOV x1, x0                 | X1 = val_12;//m1                        
        // 0x00B323A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B323A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B323A8: MOV x2, x24                | X2 = val_11;//m1                        
        // 0x00B323AC: BL #0x1e71f34              | System.IO.File.WriteAllBytes(path:  0, bytes:  val_12);
        System.IO.File.WriteAllBytes(path:  0, bytes:  val_12);
        label_25:
        // 0x00B323B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B323B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B323B8: MOV x1, x23                | X1 = val_7;//m1                         
        // 0x00B323BC: MOV x2, x21                | X2 = bytes;//m1                         
        // 0x00B323C0: BL #0x1e71f34              | System.IO.File.WriteAllBytes(path:  0, bytes:  val_7);
        System.IO.File.WriteAllBytes(path:  0, bytes:  val_7);
        // 0x00B323C4: LDR x21, [x20, #0x38]      | X21 = this.writeFileData; //P2          
        // 0x00B323C8: CBNZ x21, #0xb323d0        | if (this.writeFileData != null) goto label_28;
        if(this.writeFileData != null)
        {
            goto label_28;
        }
        // 0x00B323CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_28:
        // 0x00B323D0: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B323D4: LDR x8, [x8, #0xf00]       | X8 = 1152921510891359184;               
        // 0x00B323D8: MOV x0, x21                | X0 = this.writeFileData;//m1            
        // 0x00B323DC: MOV x1, x19                | X1 = assetName;//m1                     
        // 0x00B323E0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Contains(System.String item);
        // 0x00B323E4: BL #0x25ead74              | X0 = this.writeFileData.Contains(item:  assetName);
        bool val_13 = this.writeFileData.Contains(item:  assetName);
        // 0x00B323E8: TBZ w0, #0, #0xb32410      | if (val_13 == false) goto label_29;     
        if(val_13 == false)
        {
            goto label_29;
        }
        // 0x00B323EC: LDR x21, [x20, #0x38]      | X21 = this.writeFileData; //P2          
        // 0x00B323F0: CBNZ x21, #0xb323f8        | if (this.writeFileData != null) goto label_30;
        if(this.writeFileData != null)
        {
            goto label_30;
        }
        // 0x00B323F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_30:
        // 0x00B323F8: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00B323FC: LDR x8, [x8, #0x298]       | X8 = 1152921510891749072;               
        // 0x00B32400: MOV x0, x21                | X0 = this.writeFileData;//m1            
        // 0x00B32404: MOV x1, x19                | X1 = assetName;//m1                     
        // 0x00B32408: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.String>::Remove(System.String item);
        // 0x00B3240C: BL #0x25ecd20              | X0 = this.writeFileData.Remove(item:  assetName);
        bool val_14 = this.writeFileData.Remove(item:  assetName);
        label_29:
        // 0x00B32410: LDR w8, [x20, #0x5c]       | W8 = this.curFileCount; //P2            
        int val_29 = this.curFileCount;
        // 0x00B32414: LDR x21, [x20, #0x38]      | X21 = this.writeFileData; //P2          
        // 0x00B32418: ADD w8, w8, #1             | W8 = (this.curFileCount + 1);           
        val_29 = val_29 + 1;
        // 0x00B3241C: STR w8, [x20, #0x5c]       | this.curFileCount = (this.curFileCount + 1);  //  dest_result_addr=1152921515155832412
        this.curFileCount = val_29;
        // 0x00B32420: CBNZ x21, #0xb32428        | if (this.writeFileData != null) goto label_31;
        if(this.writeFileData != null)
        {
            goto label_31;
        }
        // 0x00B32424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_31:
        // 0x00B32428: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00B3242C: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
        // 0x00B32430: MOV x0, x21                | X0 = this.writeFileData;//m1            
        // 0x00B32434: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
        // 0x00B32438: BL #0x25ed72c              | X0 = this.writeFileData.get_Count();    
        int val_15 = this.writeFileData.Count;
        // 0x00B3243C: LDR x21, [x20, #0x18]      | X21 = this.updateCrcDic; //P2           
        // 0x00B32440: CMP w0, #1                 | STATE = COMPARE(val_15, 0x1)            
        // 0x00B32444: CSET w8, lt                | W8 = val_15 < 1 ? 1 : 0;                
        bool val_16 = (val_15 < 1) ? 1 : 0;
        // 0x00B32448: STRB w8, [x20, #0x60]      | this.IsWriteFinish = val_15 < 1 ? 1 : 0;  //  dest_result_addr=1152921515155832416
        this.IsWriteFinish = val_16;
        // 0x00B3244C: CBNZ x21, #0xb32454        | if (this.updateCrcDic != null) goto label_32;
        if(this.updateCrcDic != null)
        {
            goto label_32;
        }
        // 0x00B32450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_32:
        // 0x00B32454: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00B32458: LDR x8, [x8, #0x90]        | X8 = 1152921510817398768;               
        // 0x00B3245C: MOV x0, x21                | X0 = this.updateCrcDic;//m1             
        // 0x00B32460: MOV x1, x19                | X1 = assetName;//m1                     
        // 0x00B32464: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B32468: BL #0x23fc26c              | X0 = this.updateCrcDic.get_Item(key:  assetName);
        string val_17 = this.updateCrcDic.Item[assetName];
        // 0x00B3246C: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x00B32470: LDR x8, [x8, #0xe08]       | X8 = 1152921504910946304;               
        // 0x00B32474: MOV x23, x0                | X23 = val_17;//m1                       
        // 0x00B32478: LDR x8, [x8]               | X8 = typeof(FileInfoCrc);               
        // 0x00B3247C: MOV x0, x8                 | X0 = 1152921504910946304 (0x1000000012203000);//ML01
        FileInfoCrc val_18 = null;
        // 0x00B32480: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(FileInfoCrc), ????);
        // 0x00B32484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32488: MOV x21, x0                | X21 = 1152921504910946304 (0x1000000012203000);//ML01
        // 0x00B3248C: BL #0xed49d4               | .ctor();                                
        val_18 = new FileInfoCrc();
        // 0x00B32490: CBZ x21, #0xb3249c         | if ( == 0) goto label_33;               
        if(null == 0)
        {
            goto label_33;
        }
        // 0x00B32494: STR x19, [x21, #0x10]      | typeof(FileInfoCrc).__il2cppRuntimeField_10 = assetName;  //  dest_result_addr=1152921504910946320
        typeof(FileInfoCrc).__il2cppRuntimeField_10 = assetName;
        // 0x00B32498: B #0xb324ac                |  goto label_34;                         
        goto label_34;
        label_33:
        // 0x00B3249C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        // 0x00B324A0: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
        // 0x00B324A4: STR x19, [x8]              | mem[16] = assetName;                     //  dest_result_addr=16
        mem[16] = assetName;
        // 0x00B324A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_34:
        // 0x00B324AC: STR x23, [x21, #0x18]      | typeof(FileInfoCrc).__il2cppRuntimeField_18 = val_17;  //  dest_result_addr=1152921504910946328
        typeof(FileInfoCrc).__il2cppRuntimeField_18 = val_17;
        // 0x00B324B0: ADRP x27, #0x3630000       | X27 = 56819712 (0x3630000);             
        // 0x00B324B4: LDR x27, [x27, #0x3d0]     | X27 = 1152921504954501264;              
        // 0x00B324B8: LDR x24, [x27]             | X24 = typeof(System.Object[]);          
        // 0x00B324BC: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B324C0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B324C4: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00B324C8: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B324CC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B324D0: MOV x24, x0                | X24 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B324D4: CBNZ x22, #0xb324dc        | if ( != 0) goto label_35;               
        if(null != 0)
        {
            goto label_35;
        }
        // 0x00B324D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_35:
        // 0x00B324DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B324E0: MOV x0, x22                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B324E4: BL #0x1e726dc              | X0 = get_Length();                      
        long val_19 = Length;
        // 0x00B324E8: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B324EC: LDR x8, [x8, #0x4b0]       | X8 = 1152921504607592448;               
        // 0x00B324F0: STR x0, [sp, #0x18]        | stack[1152921515155820216] = val_19;     //  dest_result_addr=1152921515155820216
        // 0x00B324F4: ADD x1, sp, #0x18          | X1 = (1152921515155820192 + 24) = 1152921515155820216 (0x1000000274C48EB8);
        // 0x00B324F8: LDR x8, [x8]               | X8 = typeof(System.Int64);              
        // 0x00B324FC: MOV x0, x8                 | X0 = 1152921504607592448 (0x10000000000B6000);//ML01
        // 0x00B32500: BL #0x27bc028              | X0 = 1152921515155995392 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int64), val_19);
        // 0x00B32504: MOV x25, x0                | X25 = 1152921515155995392 (0x1000000274C73B00);//ML01
        // 0x00B32508: CBNZ x24, #0xb32510        | if ( != null) goto label_36;            
        if(null != null)
        {
            goto label_36;
        }
        // 0x00B3250C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_36:
        // 0x00B32510: CBZ x25, #0xb32534         | if (val_19 == 0) goto label_38;         
        if(val_19 == 0)
        {
            goto label_38;
        }
        // 0x00B32514: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B32518: MOV x0, x25                | X0 = 1152921515155995392 (0x1000000274C73B00);//ML01
        // 0x00B3251C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B32520: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
        // 0x00B32524: CBNZ x0, #0xb32534         | if (val_19 != 0) goto label_38;         
        if(val_19 != 0)
        {
            goto label_38;
        }
        // 0x00B32528: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
        // 0x00B3252C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32530: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
        label_38:
        // 0x00B32534: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B32538: CBNZ w8, #0xb32548         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_39;
        // 0x00B3253C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
        // 0x00B32540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32544: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
        label_39:
        // 0x00B32548: STR x25, [x24, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_19;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_19;
        // 0x00B3254C: CBNZ x22, #0xb32554        | if ( != 0) goto label_40;               
        if(null != 0)
        {
            goto label_40;
        }
        // 0x00B32550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_40:
        // 0x00B32554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32558: MOV x0, x22                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B3255C: BL #0x1e78290              | X0 = get_LastWriteTime();               
        System.DateTime val_20 = LastWriteTime;
        // 0x00B32560: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B32564: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00B32568: LDR x8, [x8]               | X8 = typeof(System.DateTime);           
        // 0x00B3256C: STP x0, x1, [sp, #8]       | stack[1152921515155820200] = val_20.ticks._ticks;  stack[1152921515155820208] = val_20.kind;  //  dest_result_addr=1152921515155820200 |  dest_result_addr=1152921515155820208
        // 0x00B32570: ADD x1, sp, #8             | X1 = (1152921515155820192 + 8) = 1152921515155820200 (0x1000000274C48EA8);
        // 0x00B32574: MOV x0, x8                 | X0 = 1152921504652693504 (0x1000000002BB9000);//ML01
        // 0x00B32578: BL #0x27bc028              | X0 = 1152921515156000512 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.DateTime), val_20);
        // 0x00B3257C: MOV x22, x0                | X22 = 1152921515156000512 (0x1000000274C74F00);//ML01
        // 0x00B32580: CBZ x22, #0xb325a4         | if (val_20 == 0) goto label_42;         
        if(val_20 == 0)
        {
            goto label_42;
        }
        // 0x00B32584: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B32588: MOV x0, x22                | X0 = 1152921515156000512 (0x1000000274C74F00);//ML01
        // 0x00B3258C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B32590: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
        // 0x00B32594: CBNZ x0, #0xb325a4         | if (val_20 != 0) goto label_42;         
        if(val_20 != 0)
        {
            goto label_42;
        }
        // 0x00B32598: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
        // 0x00B3259C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B325A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
        label_42:
        // 0x00B325A4: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B325A8: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B325AC: B.HI #0xb325bc             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_43;
        // 0x00B325B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
        // 0x00B325B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B325B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
        label_43:
        // 0x00B325BC: STR x22, [x24, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_20;  //  dest_result_addr=1152921504954501304
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_20;
        // 0x00B325C0: CBZ x23, #0xb325e4         | if (val_17 == null) goto label_45;      
        if(val_17 == null)
        {
            goto label_45;
        }
        // 0x00B325C4: LDR x8, [x24]              | X8 = ;                                  
        // 0x00B325C8: MOV x0, x23                | X0 = val_17;//m1                        
        // 0x00B325CC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B325D0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
        // 0x00B325D4: CBNZ x0, #0xb325e4         | if (val_17 != null) goto label_45;      
        if(val_17 != null)
        {
            goto label_45;
        }
        // 0x00B325D8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
        // 0x00B325DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B325E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
        label_45:
        // 0x00B325E4: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B325E8: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x00B325EC: B.HI #0xb325fc             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_46;
        // 0x00B325F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
        // 0x00B325F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B325F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
        label_46:
        // 0x00B325FC: STR x23, [x24, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = val_17;  //  dest_result_addr=1152921504954501312
        typeof(System.Object[]).__il2cppRuntimeField_30 = val_17;
        // 0x00B32600: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B32604: LDR x8, [x8, #0x1a8]       | X8 = (string**)(1152921514966421632)("{0}{1}{2}");
        // 0x00B32608: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B3260C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B32610: MOV x2, x24                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B32614: LDR x1, [x8]               | X1 = "{0}{1}{2}";                       
        // 0x00B32618: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "{0}{1}{2}");
        string val_21 = EString.EFormat(format:  0, args:  "{0}{1}{2}");
        // 0x00B3261C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B32620: LDR x8, [x8, #0xd90]       | X8 = 1152921504910839808;               
        // 0x00B32624: MOV x22, x0                | X22 = val_21;//m1                       
        // 0x00B32628: LDR x8, [x8]               | X8 = typeof(Mihua.Update.VSTools);      
        // 0x00B3262C: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_10A;
        // 0x00B32630: TBZ w9, #0, #0xb32644      | if (Mihua.Update.VSTools.__il2cppRuntimeField_has_cctor == 0) goto label_48;
        // 0x00B32634: LDR w9, [x8, #0xbc]        | W9 = Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished;
        // 0x00B32638: CBNZ w9, #0xb32644         | if (Mihua.Update.VSTools.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
        // 0x00B3263C: MOV x0, x8                 | X0 = 1152921504910839808 (0x10000000121E9000);//ML01
        // 0x00B32640: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Update.VSTools), ????);
        label_48:
        // 0x00B32644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32648: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B3264C: MOV x1, x22                | X1 = val_21;//m1                        
        // 0x00B32650: BL #0xabf710               | X0 = Mihua.Update.VSTools.GetCRC32(str:  0);
        string val_22 = Mihua.Update.VSTools.GetCRC32(str:  0);
        // 0x00B32654: MOV x22, x0                | X22 = val_22;//m1                       
        // 0x00B32658: CBNZ x21, #0xb32660        | if ( != 0) goto label_49;               
        if(null != 0)
        {
            goto label_49;
        }
        // 0x00B3265C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_49:
        // 0x00B32660: STR x22, [x21, #0x20]      | typeof(FileInfoCrc).__il2cppRuntimeField_20 = val_22;  //  dest_result_addr=1152921504910946336
        typeof(FileInfoCrc).__il2cppRuntimeField_20 = val_22;
        // 0x00B32664: LDR x22, [x20, #0x10]      | X22 = this.fileCrcList; //P2            
        // 0x00B32668: CBNZ x22, #0xb32670        | if (this.fileCrcList != null) goto label_50;
        if(this.fileCrcList != null)
        {
            goto label_50;
        }
        // 0x00B3266C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_50:
        // 0x00B32670: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B32674: LDR x8, [x8, #0x188]       | X8 = 1152921514966434016;               
        // 0x00B32678: MOV x0, x22                | X0 = this.fileCrcList;//m1              
        // 0x00B3267C: MOV x1, x21                | X1 = 1152921504910946304 (0x1000000012203000);//ML01
        // 0x00B32680: LDR x2, [x8]               | X2 = public System.Void Filelist<FileInfoCrc>::AddOrReplaceResData(FileInfoCrc data);
        // 0x00B32684: BL #0x19cd1c4              | this.fileCrcList.AddOrReplaceResData(data:  val_18);
        this.fileCrcList.AddOrReplaceResData(data:  val_18);
        // 0x00B32688: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        val_32 = null;
        // 0x00B3268C: LDRB w8, [x0, #0x10a]      | W8 = Loader.PathUtil.__il2cppRuntimeField_10A;
        // 0x00B32690: TBZ w8, #0, #0xb326a4      | if (Loader.PathUtil.__il2cppRuntimeField_has_cctor == 0) goto label_52;
        // 0x00B32694: LDR w8, [x0, #0xbc]        | W8 = Loader.PathUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B32698: CBNZ w8, #0xb326a4         | if (Loader.PathUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_52;
        // 0x00B3269C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Loader.PathUtil), ????);
        // 0x00B326A0: LDR x0, [x26]              | X0 = typeof(Loader.PathUtil);           
        val_32 = null;
        label_52:
        // 0x00B326A4: LDR x8, [x0, #0xa0]        | X8 = Loader.PathUtil.__il2cppRuntimeField_static_fields;
        // 0x00B326A8: LDR x0, [x28]              | X0 = typeof(System.String);             
        // 0x00B326AC: LDR x21, [x8, #0x28]       | X21 = Loader.PathUtil.persistentDataPath;
        // 0x00B326B0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B326B4: TBZ w8, #0, #0xb326c4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_54;
        // 0x00B326B8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B326BC: CBNZ w8, #0xb326c4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_54;
        // 0x00B326C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_54:
        // 0x00B326C4: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B326C8: LDR x8, [x8, #0x888]       | X8 = (string**)(1152921510474838464)("eff_crc.uab");
        // 0x00B326CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B326D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B326D4: MOV x1, x21                | X1 = Loader.PathUtil.persistentDataPath;//m1
        // 0x00B326D8: LDR x2, [x8]               | X2 = "eff_crc.uab";                     
        // 0x00B326DC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        string val_23 = System.String.Concat(str0:  0, str1:  Loader.PathUtil.persistentDataPath);
        // 0x00B326E0: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00B326E4: LDR x8, [x8, #0x48]        | X8 = 1152921504621170688;               
        // 0x00B326E8: MOV x22, x0                | X22 = val_23;//m1                       
        // 0x00B326EC: LDR x8, [x8]               | X8 = typeof(System.IO.FileInfo);        
        // 0x00B326F0: MOV x0, x8                 | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        System.IO.FileInfo val_24 = null;
        // 0x00B326F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileInfo), ????);
        // 0x00B326F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B326FC: MOV x1, x22                | X1 = val_23;//m1                        
        // 0x00B32700: MOV x21, x0                | X21 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B32704: BL #0x1e6e0a0              | .ctor(fileName:  val_23);               
        val_24 = new System.IO.FileInfo(fileName:  val_23);
        // 0x00B32708: CBNZ x21, #0xb32710        | if ( != 0) goto label_55;               
        if(null != 0)
        {
            goto label_55;
        }
        // 0x00B3270C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(fileName:  val_23), ????);
        label_55:
        // 0x00B32710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32714: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B32718: BL #0x1e72848              | X0 = get_Directory();                   
        System.IO.DirectoryInfo val_25 = Directory;
        // 0x00B3271C: MOV x22, x0                | X22 = val_25;//m1                       
        // 0x00B32720: CBNZ x22, #0xb32728        | if (val_25 != null) goto label_56;      
        if(val_25 != null)
        {
            goto label_56;
        }
        // 0x00B32724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_56:
        // 0x00B32728: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3272C: MOV x0, x22                | X0 = val_25;//m1                        
        // 0x00B32730: BL #0x1e698c4              | val_25.Create();                        
        val_25.Create();
        // 0x00B32734: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00B32738: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00B3273C: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00B32740: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00B32744: TBZ w8, #0, #0xb32754      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_58;
        // 0x00B32748: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00B3274C: CBNZ w8, #0xb32754         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_58;
        // 0x00B32750: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_58:
        // 0x00B32754: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3275C: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_26 = System.Text.Encoding.UTF8;
        // 0x00B32760: LDR x23, [x20, #0x10]      | X23 = this.fileCrcList; //P2            
        // 0x00B32764: MOV x22, x0                | X22 = val_26;//m1                       
        // 0x00B32768: CBNZ x23, #0xb32770        | if (this.fileCrcList != null) goto label_59;
        if(this.fileCrcList != null)
        {
            goto label_59;
        }
        // 0x00B3276C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_59:
        // 0x00B32770: LDR x8, [x23]              | X8 = typeof(Filelist<FileInfoCrc>);     
        // 0x00B32774: MOV x0, x23                | X0 = this.fileCrcList;//m1              
        // 0x00B32778: LDP x9, x1, [x8, #0x140]   | X9 = typeof(Filelist<T>).__il2cppRuntimeField_140; X1 = typeof(Filelist<T>).__il2cppRuntimeField_148; //  | 
        // 0x00B3277C: BLR x9                     | X0 = typeof(Filelist<T>).__il2cppRuntimeField_140();
        // 0x00B32780: MOV x23, x0                | X23 = this.fileCrcList;//m1             
        // 0x00B32784: CBNZ x22, #0xb3278c        | if (val_26 != null) goto label_60;      
        if(val_26 != null)
        {
            goto label_60;
        }
        // 0x00B32788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.fileCrcList, ????);
        label_60:
        // 0x00B3278C: LDR x8, [x22]              | X8 = typeof(System.Text.Encoding);      
        // 0x00B32790: MOV x0, x22                | X0 = val_26;//m1                        
        // 0x00B32794: MOV x1, x23                | X1 = this.fileCrcList;//m1              
        // 0x00B32798: LDP x9, x2, [x8, #0x1c0]   | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_1C0; X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_1C8; //  | 
        // 0x00B3279C: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_1C0();
        // 0x00B327A0: MOV x22, x0                | X22 = val_26;//m1                       
        // 0x00B327A4: CBNZ x21, #0xb327ac        | if ( != 0) goto label_61;               
        if(null != 0)
        {
            goto label_61;
        }
        // 0x00B327A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_61:
        // 0x00B327AC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B327B0: MOV x0, x21                | X0 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B327B4: LDP x9, x1, [x8, #0x1b0]   |                                          //  not_find_field!1:432 |  not_find_field!1:440
        // 0x00B327B8: BLR x9                     | X0 = mem[null + 432]();                 
        // 0x00B327BC: MOV x1, x0                 | X1 = 1152921504621170688 (0x1000000000DA9000);//ML01
        // 0x00B327C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B327C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B327C8: MOV x2, x22                | X2 = val_26;//m1                        
        // 0x00B327CC: BL #0x1e71f34              | System.IO.File.WriteAllBytes(path:  0, bytes:  val_24);
        System.IO.File.WriteAllBytes(path:  0, bytes:  val_24);
        // 0x00B327D0: LDRB w8, [x20, #0x60]      | W8 = this.IsWriteFinish; //P2           
        // 0x00B327D4: CBZ w8, #0xb327f8          | if (this.IsWriteFinish == false) goto label_62;
        if(this.IsWriteFinish == false)
        {
            goto label_62;
        }
        // 0x00B327D8: LDR x21, [x20, #0x18]      | X21 = this.updateCrcDic; //P2           
        // 0x00B327DC: CBNZ x21, #0xb327e4        | if (this.updateCrcDic != null) goto label_63;
        if(this.updateCrcDic != null)
        {
            goto label_63;
        }
        // 0x00B327E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_63:
        // 0x00B327E4: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B327E8: LDR x8, [x8, #0x750]       | X8 = 1152921510817589616;               
        // 0x00B327EC: MOV x0, x21                | X0 = this.updateCrcDic;//m1             
        // 0x00B327F0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.String>::Clear();
        // 0x00B327F4: BL #0x23fd92c              | this.updateCrcDic.Clear();              
        this.updateCrcDic.Clear();
        label_62:
        // 0x00B327F8: LDR x21, [x27]             | X21 = typeof(System.Object[]);          
        // 0x00B327FC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B32800: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00B32804: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00B32808: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B3280C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00B32810: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B32814: CBNZ x21, #0xb3281c        | if ( != null) goto label_64;            
        if(null != null)
        {
            goto label_64;
        }
        // 0x00B32818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_64:
        // 0x00B3281C: CBZ x19, #0xb32840         | if (assetName == null) goto label_66;   
        if(assetName == null)
        {
            goto label_66;
        }
        // 0x00B32820: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B32824: MOV x0, x19                | X0 = assetName;//m1                     
        // 0x00B32828: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B3282C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? assetName, ????);  
        // 0x00B32830: CBNZ x0, #0xb32840         | if (assetName != null) goto label_66;   
        if(assetName != null)
        {
            goto label_66;
        }
        // 0x00B32834: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? assetName, ????);  
        // 0x00B32838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B3283C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? assetName, ????);  
        label_66:
        // 0x00B32840: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B32844: CBNZ w8, #0xb32854         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_67;
        // 0x00B32848: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? assetName, ????);  
        // 0x00B3284C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32850: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? assetName, ????);  
        label_67:
        // 0x00B32854: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = assetName;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = assetName;
        // 0x00B32858: LDR x8, [x20, #0x50]       | X8 = this.totalBytes; //P2              
        // 0x00B3285C: CBZ w8, #0xb32888          | if (this.totalBytes == 0) goto label_68;
        if(this.totalBytes == 0)
        {
            goto label_68;
        }
        // 0x00B32860: ADRP x10, #0x2a92000       | X10 = 44638208 (0x2A92000);             
        // 0x00B32864: LSR x9, x8, #0x20          | X9 = (this.totalBytes >> 32);           
        uint val_27 = this.totalBytes >> 32;
        // 0x00B32868: LDR s1, [x10, #0x4b0]      | S1 = 100;                               
        // 0x00B3286C: UCVTF d0, w9               | D0 = (double)((this.totalBytes >> 32)); 
        // 0x00B32870: UCVTF d2, w8               | D2 = (double)(this.totalBytes);         
        // 0x00B32874: FCVT s0, d0                | S0 = (float)(this.totalBytes >> 32));   
        float val_30 = (float)(double)val_27;
        // 0x00B32878: FCVT s2, d2                | S2 = (float)this.totalBytes);           
        // 0x00B3287C: FDIV s0, s0, s2            | S0 = ((this.totalBytes >> 32) / this.totalBytes);
        val_30 = val_30 / (float)(double)this.totalBytes;
        // 0x00B32880: FMUL s0, s0, s1            | S0 = (((this.totalBytes >> 32) / this.totalBytes) * 100f);
        val_33 = val_30 * 100f;
        // 0x00B32884: B #0xb3288c                |  goto label_69;                         
        goto label_69;
        label_68:
        // 0x00B32888: FMOV s0, wzr               | S0 = 0f;                                
        val_33 = 0f;
        label_69:
        // 0x00B3288C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00B32890: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00B32894: ADD x1, sp, #8             | X1 = (1152921515155820192 + 8) = 1152921515155820200 (0x1000000274C48EA8);
        // 0x00B32898: STR s0, [sp, #8]           | stack[1152921515155820200] = 0;          //  dest_result_addr=1152921515155820200
        // 0x00B3289C: LDR x0, [x8]               | X0 = typeof(System.Single);             
        // 0x00B328A0: BL #0x27bc028              | X0 = 1152921515156037376 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), 0);
        // 0x00B328A4: MOV x19, x0                | X19 = 1152921515156037376 (0x1000000274C7DF00);//ML01
        // 0x00B328A8: CBZ x19, #0xb328cc         | if (0 == 0) goto label_71;              
        if(val_33 == 0)
        {
            goto label_71;
        }
        // 0x00B328AC: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B328B0: MOV x0, x19                | X0 = 1152921515156037376 (0x1000000274C7DF00);//ML01
        // 0x00B328B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00B328B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0, ????);          
        // 0x00B328BC: CBNZ x0, #0xb328cc         | if (0 != 0) goto label_71;              
        if(val_33 != 0)
        {
            goto label_71;
        }
        // 0x00B328C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0, ????);          
        // 0x00B328C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B328C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0, ????);          
        label_71:
        // 0x00B328CC: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00B328D0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00B328D4: B.HI #0xb328e4             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_72;
        // 0x00B328D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0, ????);          
        // 0x00B328DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B328E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0, ????);          
        label_72:
        // 0x00B328E4: STR x19, [x21, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = 0; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_33;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00B328E8: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00B328EC: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921515155804096)("资源写入：{0} 加载完成 当前总进度：{1}%");
        // 0x00B328F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B328F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B328F8: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00B328FC: LDR x1, [x8]               | X1 = "资源写入：{0} 加载完成 当前总进度：{1}%";        
        // 0x00B32900: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "资源写入：{0} 加载完成 当前总进度：{1}%");
        string val_28 = EString.EFormat(format:  0, args:  "资源写入：{0} 加载完成 当前总进度：{1}%");
        // 0x00B32904: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B32908: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B3290C: MOV x19, x0                | X19 = val_28;//m1                       
        // 0x00B32910: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B32914: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B32918: TBZ w9, #0, #0xb3292c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_74;
        // 0x00B3291C: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B32920: CBNZ w9, #0xb3292c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_74;
        // 0x00B32924: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B32928: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_74:
        // 0x00B3292C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B32930: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B32934: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B32938: MOV x1, x19                | X1 = val_28;//m1                        
        // 0x00B3293C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_28);
        EDebug.Log(message:  0, isShowStack:  val_28);
        // 0x00B32940: SUB sp, x29, #0x50         | SP = (1152921515155820304 - 80) = 1152921515155820224 (0x1000000274C48EC0);
        // 0x00B32944: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B32948: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B3294C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B32950: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B32954: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B32958: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B3295C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B32960 (11741536), len: 448  VirtAddr: 0x00B32960 RVA: 0x00B32960 token: 100694326 methodIndex: 24937 delegateWrapperIndex: 0 methodInvoker: 0
    private void <ZUpdate>m__0()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        // 0x00B32960: STP x24, x23, [sp, #-0x40]! | stack[1152921515156129888] = ???;  stack[1152921515156129896] = ???;  //  dest_result_addr=1152921515156129888 |  dest_result_addr=1152921515156129896
        // 0x00B32964: STP x22, x21, [sp, #0x10]  | stack[1152921515156129904] = ???;  stack[1152921515156129912] = ???;  //  dest_result_addr=1152921515156129904 |  dest_result_addr=1152921515156129912
        // 0x00B32968: STP x20, x19, [sp, #0x20]  | stack[1152921515156129920] = ???;  stack[1152921515156129928] = ???;  //  dest_result_addr=1152921515156129920 |  dest_result_addr=1152921515156129928
        // 0x00B3296C: STP x29, x30, [sp, #0x30]  | stack[1152921515156129936] = ???;  stack[1152921515156129944] = ???;  //  dest_result_addr=1152921515156129936 |  dest_result_addr=1152921515156129944
        // 0x00B32970: ADD x29, sp, #0x30         | X29 = (1152921515156129888 + 48) = 1152921515156129936 (0x1000000274C94890);
        // 0x00B32974: SUB sp, sp, #0x20          | SP = (1152921515156129888 - 32) = 1152921515156129856 (0x1000000274C94840);
        // 0x00B32978: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B3297C: LDRB w8, [x20, #0x798]     | W8 = (bool)static_value_03733798;       
        // 0x00B32980: MOV x19, x0                | X19 = 1152921515156141952 (0x1000000274C97780);//ML01
        // 0x00B32984: TBNZ w8, #0, #0xb329a0     | if (static_value_03733798 == true) goto label_0;
        // 0x00B32988: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B3298C: LDR x8, [x8, #0xa10]       | X8 = 0x2B8EAF0;                         
        // 0x00B32990: LDR w0, [x8]               | W0 = 0x117C;                            
        // 0x00B32994: BL #0x2782188              | X0 = sub_2782188( ?? 0x117C, ????);     
        // 0x00B32998: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B3299C: STRB w8, [x20, #0x798]     | static_value_03733798 = true;            //  dest_result_addr=57882520
        label_0:
        // 0x00B329A0: STP xzr, xzr, [sp, #0x10]  | stack[1152921515156129872] = 0x0;  stack[1152921515156129880] = 0x0;  //  dest_result_addr=1152921515156129872 |  dest_result_addr=1152921515156129880
        // 0x00B329A4: STR xzr, [sp, #8]          | stack[1152921515156129864] = 0x0;        //  dest_result_addr=1152921515156129864
        // 0x00B329A8: LDR x0, [x19, #0x98]       | X0 = this.errorDownFiles; //P2          
        // 0x00B329AC: CBZ x0, #0xb32ab4          | if (this.errorDownFiles == null) goto label_8;
        if(this.errorDownFiles == null)
        {
            goto label_8;
        }
        // 0x00B329B0: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00B329B4: LDR x8, [x8, #0x810]       | X8 = 1152921513635465248;               
        // 0x00B329B8: LDR x1, [x8]               | X1 = public Dictionary.KeyCollection<TKey, TValue> System.Collections.Generic.Dictionary<System.String, System.Int32>::get_Keys();
        // 0x00B329BC: BL #0x23f6910              | X0 = this.errorDownFiles.get_Keys();    
        Dictionary.KeyCollection<TKey, TValue> val_1 = this.errorDownFiles.Keys;
        // 0x00B329C0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00B329C4: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
        // 0x00B329C8: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00B329CC: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
        // 0x00B329D0: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        System.Collections.Generic.List<System.String> val_2 = null;
        // 0x00B329D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B329D8: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00B329DC: LDR x8, [x8, #0xca0]       | X8 = 1152921510893230800;               
        // 0x00B329E0: MOV x1, x21                | X1 = val_1;//m1                         
        // 0x00B329E4: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B329E8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.String>::.ctor(System.Collections.Generic.IEnumerable<T> collection);
        // 0x00B329EC: BL #0x25e9524              | .ctor(collection:  val_1);              
        val_2 = new System.Collections.Generic.List<System.String>(collection:  val_1);
        // 0x00B329F0: CBNZ x20, #0xb329f8        | if ( != 0) goto label_2;                
        if(null != 0)
        {
            goto label_2;
        }
        // 0x00B329F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(collection:  val_1), ????);
        label_2:
        // 0x00B329F8: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00B329FC: LDR x8, [x8, #0xb00]       | X8 = 1152921510022785904;               
        // 0x00B32A00: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B32A04: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.String>::GetEnumerator();
        // 0x00B32A08: ADD x8, sp, #8             | X8 = (1152921515156129856 + 8) = 1152921515156129864 (0x1000000274C94848);
        // 0x00B32A0C: BL #0x25ebf2c              | X0 = GetEnumerator();                   
        List.Enumerator<T> val_3 = GetEnumerator();
        // 0x00B32A10: ADRP x22, #0x3637000       | X22 = 56848384 (0x3637000);             
        // 0x00B32A14: ADRP x23, #0x3640000       | X23 = 56885248 (0x3640000);             
        // 0x00B32A18: ADRP x24, #0x3630000       | X24 = 56819712 (0x3630000);             
        // 0x00B32A1C: LDR x22, [x22, #0x1a8]     | X22 = 1152921510022786928;              
        // 0x00B32A20: LDR x23, [x23, #0x8d0]     | X23 = 1152921510022787952;              
        // 0x00B32A24: LDR x24, [x24, #0x6b0]     | X24 = 1152921510000499136;              
        label_5:
        // 0x00B32A28: LDR x1, [x22]              | X1 = public System.Boolean List.Enumerator<System.String>::MoveNext();
        // 0x00B32A2C: ADD x0, sp, #8             | X0 = (1152921515156129856 + 8) = 1152921515156129864 (0x1000000274C94848);
        // 0x00B32A30: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
        // 0x00B32A34: AND w8, w0, #1             | W8 = (1152921515156129864 & 1) = 0 (0x00000000);
        // 0x00B32A38: TBZ w8, #0, #0xb32a84      | if ((0x0 & 0x1) == 0) goto label_3;     
        if((0 & 1) == 0)
        {
            goto label_3;
        }
        // 0x00B32A3C: LDR x1, [x23]              | X1 = public System.String List.Enumerator<System.String>::get_Current();
        // 0x00B32A40: ADD x0, sp, #8             | X0 = (1152921515156129856 + 8) = 1152921515156129864 (0x1000000274C94848);
        // 0x00B32A44: BL #0x13372d8              | X0 = null.get_InitialType();            
        System.Type val_4 = 0.InitialType;
        // 0x00B32A48: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B32A4C: LDR x21, [x19, #0x98]      | X21 = this.errorDownFiles; //P2         
        // 0x00B32A50: CBNZ x21, #0xb32a58        | if (this.errorDownFiles != null) goto label_4;
        if(this.errorDownFiles != null)
        {
            goto label_4;
        }
        // 0x00B32A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00B32A58: LDR x3, [x24]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Int32>::set_Item(System.String key, System.Int32 value);
        // 0x00B32A5C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B32A60: MOV x0, x21                | X0 = this.errorDownFiles;//m1           
        // 0x00B32A64: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00B32A68: BL #0x23f4398              | this.errorDownFiles.set_Item(key:  val_4, value:  1);
        this.errorDownFiles.set_Item(key:  val_4, value:  1);
        // 0x00B32A6C: B #0xb32a28                |  goto label_5;                          
        goto label_5;
        // 0x00B32A70: BL #0x981060               | X0 = sub_981060( ?? this.errorDownFiles, ????);
        // 0x00B32A74: LDR x20, [x0]              | X20 = typeof(System.Collections.Generic.Dictionary<System.String, System.Int32>);
        // 0x00B32A78: BL #0x980920               | X0 = sub_980920( ?? this.errorDownFiles, ????);
        // 0x00B32A7C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_6 = 0;
        // 0x00B32A80: B #0xb32a8c                |  goto label_6;                          
        goto label_6;
        label_3:
        // 0x00B32A84: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B32A88: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        val_6 = 1;
        label_6:
        // 0x00B32A8C: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
        // 0x00B32A90: LDR x8, [x8, #0xd70]       | X8 = 1152921510022801264;               
        // 0x00B32A94: ADD x0, sp, #8             | X0 = (1152921515156129856 + 8) = 1152921515156129864 (0x1000000274C94848);
        // 0x00B32A98: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.String>::Dispose();
        // 0x00B32A9C: BL #0x13371f4              | null.Dispose();                         
        0.Dispose();
        // 0x00B32AA0: TBNZ w21, #0, #0xb32ab4    | if ((0x1 & 0x1) != 0) goto label_8;     
        if((val_6 & 1) != 0)
        {
            goto label_8;
        }
        // 0x00B32AA4: CBZ x20, #0xb32ab4         | if (0x0 == 0) goto label_8;             
        if(val_5 == 0)
        {
            goto label_8;
        }
        // 0x00B32AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B32AAC: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
        // 0x00B32AB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_8:
        // 0x00B32AB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B32AB8: STRB w8, [x19, #0xa8]      | this.CanDownFile = true;                 //  dest_result_addr=1152921515156142120
        this.CanDownFile = true;
        // 0x00B32ABC: SUB sp, x29, #0x30         | SP = (1152921515156129936 - 48) = 1152921515156129888 (0x1000000274C94860);
        // 0x00B32AC0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B32AC4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B32AC8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B32ACC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00B32AD0: RET                        |  return;                                
        return;
        // 0x00B32AD4: STP x22, x21, [sp, #-0x30]! | 
        // 0x00B32AD8: STP x20, x19, [sp, #0x10]  | 
        // 0x00B32ADC: STP x29, x30, [sp, #0x20]  | 
        // 0x00B32AE0: ADD x29, sp, #0x20         | 
        // 0x00B32AE4: LDR x8, [x0, #0x28]        | 
        // 0x00B32AE8: MOV x0, x1                 | 
        // 0x00B32AEC: MOV x19, x2                | 
        // 0x00B32AF0: LDR x21, [x8]              | 
        // 0x00B32AF4: BL #0x27b1038              | 
        // 0x00B32AF8: MOV x20, x0                | 
        // 0x00B32AFC: ADD x8, x19, #0x20         | 
        // 0x00B32B00: CMP x19, #0                | 
        // 0x00B32B04: CSEL x1, xzr, x8, eq       | 
        // 0x00B32B08: BLR x21                    | 
        // 0x00B32B0C: MOV x0, x20                | 
        // 0x00B32B10: LDP x29, x30, [sp, #0x20]  | 
        // 0x00B32B14: LDP x20, x19, [sp, #0x10]  | 
        // 0x00B32B18: LDP x22, x21, [sp], #0x30  | 
        // 0x00B32B1C: B #0x27b102c               | 
    
    }

}
