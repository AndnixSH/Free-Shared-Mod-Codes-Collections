using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x281A440
[UnityEngine.RequireComponent] // 0x281A440
[UnityEngine.AddComponentMenu] // 0x281A440
[Serializable]
public class AntialiasingAsPostEffect : PostEffectsBase
{
    // Fields
    public AAMode mode; //  0x0000001C
    public bool showGeneratedNormals; //  0x00000020
    public float offsetScale; //  0x00000024
    public float blurRadius; //  0x00000028
    public float edgeThresholdMin; //  0x0000002C
    public float edgeThreshold; //  0x00000030
    public float edgeSharpness; //  0x00000034
    public bool dlaaSharp; //  0x00000038
    public UnityEngine.Shader ssaaShader; //  0x00000040
    private UnityEngine.Material ssaa; //  0x00000048
    public UnityEngine.Shader dlaaShader; //  0x00000050
    private UnityEngine.Material dlaa; //  0x00000058
    public UnityEngine.Shader nfaaShader; //  0x00000060
    private UnityEngine.Material nfaa; //  0x00000068
    public UnityEngine.Shader shaderFXAAPreset2; //  0x00000070
    private UnityEngine.Material materialFXAAPreset2; //  0x00000078
    public UnityEngine.Shader shaderFXAAPreset3; //  0x00000080
    private UnityEngine.Material materialFXAAPreset3; //  0x00000088
    public UnityEngine.Shader shaderFXAAII; //  0x00000090
    private UnityEngine.Material materialFXAAII; //  0x00000098
    public UnityEngine.Shader shaderFXAAIII; //  0x000000A0
    private UnityEngine.Material materialFXAAIII; //  0x000000A8
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02671CE8 (40312040), len: 72  VirtAddr: 0x02671CE8 RVA: 0x02671CE8 token: 100663302 methodIndex: 24386 delegateWrapperIndex: 0 methodInvoker: 0
    public AntialiasingAsPostEffect()
    {
        //
        // Disasemble & Code
        // 0x02671CE8: STP x20, x19, [sp, #-0x20]! | stack[1152921509943655360] = ???;  stack[1152921509943655368] = ???;  //  dest_result_addr=1152921509943655360 |  dest_result_addr=1152921509943655368
        // 0x02671CEC: STP x29, x30, [sp, #0x10]  | stack[1152921509943655376] = ???;  stack[1152921509943655384] = ???;  //  dest_result_addr=1152921509943655376 |  dest_result_addr=1152921509943655384
        // 0x02671CF0: ADD x29, sp, #0x10         | X29 = (1152921509943655360 + 16) = 1152921509943655376 (0x100000013E193BD0);
        // 0x02671CF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02671CF8: MOV x19, x0                | X19 = 1152921509943667392 (0x100000013E196AC0);//ML01
        // 0x02671CFC: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02671D00: ADRP x9, #0x2ac3000        | X9 = 44838912 (0x2AC3000);              
        // 0x02671D04: LDR q0, [x9, #0xc40]       | Q0 = ;                                  
        // 0x02671D08: MOVZ w10, #0x4080, lsl #16 | W10 = 1082130432 (0x40800000);//ML01    
        // 0x02671D0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02671D10: STR w10, [x19, #0x34]      | this.edgeSharpness = 4;                  //  dest_result_addr=1152921509943667444
        this.edgeSharpness = 4f;
        // 0x02671D14: STRB w8, [x19, #0x18]      | mem[1152921509943667416] = 0x1;          //  dest_result_addr=1152921509943667416
        mem[1152921509943667416] = 1;
        // 0x02671D18: STRB w8, [x19, #0x1a]      | mem[1152921509943667418] = 0x1;          //  dest_result_addr=1152921509943667418
        mem[1152921509943667418] = 1;
        // 0x02671D1C: STR w8, [x19, #0x1c]       | this.mode = 0x1;                         //  dest_result_addr=1152921509943667420
        this.mode = 1;
        // 0x02671D20: STUR q0, [x19, #0x24]      | this.offsetScale = ; this.blurRadius = ; this.edgeThresholdMin = 0.05; this.edgeThreshold = 0.2;  //  dest_result_addr=1152921509943667428 dest_result_addr=1152921509943667432 dest_result_addr=1152921509943667436 dest_result_addr=1152921509943667440
        this.offsetScale = ;
        this.blurRadius = ;
        this.edgeThresholdMin = 0.05f;
        this.edgeThreshold = 0.2f;
        // 0x02671D24: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02671D28: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02671D2C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02671D30 (40312112), len: 96  VirtAddr: 0x02671D30 RVA: 0x02671D30 token: 100663303 methodIndex: 24387 delegateWrapperIndex: 0 methodInvoker: 0
    public override UnityEngine.Material CurrentAAMaterial()
    {
        //
        // Disasemble & Code
        // 0x02671D30: LDR w8, [x0, #0x1c]        | W8 = this.mode; //P2                    
        // 0x02671D34: CMP w8, #6                 | STATE = COMPARE(this.mode, 0x6)         
        // 0x02671D38: B.HI #0x2671d58            | if (this.mode > 0x6) goto label_0;      
        if(this.mode > 6)
        {
            goto label_0;
        }
        // 0x02671D3C: ADRP x9, #0x2ac3000        | X9 = 44838912 (0x2AC3000);              
        // 0x02671D40: ADD x9, x9, #0xd00         | X9 = (44838912 + 3328) = 44842240 (0x02AC3D00);
        // 0x02671D44: LDRSW x8, [x9, x8, lsl #2] | X8 = 44842240 + (this.mode) << 2;       
        var val_1 = 44842240 + (this.mode) << 2;
        // 0x02671D48: ADD x8, x8, x9             | X8 = (44842240 + (this.mode) << 2 + 44842240);
        val_1 = val_1 + 44842240;
        // 0x02671D4C: BR x8                      | goto (44842240 + (this.mode) << 2 + 44842240);
        goto (44842240 + (this.mode) << 2 + 44842240);
        // 0x02671D50: LDR x0, [x0, #0x98]        | X0 = this.materialFXAAII; //P2          
        // 0x02671D54: RET                        |  return (UnityEngine.Material)this.materialFXAAII;
        return this.materialFXAAII;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
        label_0:
        // 0x02671D58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671D5C: RET                        |  return (UnityEngine.Material)null;     
        return (UnityEngine.Material)0;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
        // 0x02671D60: LDR x0, [x0, #0xa8]        | 
        // 0x02671D64: RET                        | 
        // 0x02671D68: LDR x0, [x0, #0x78]        | 
        // 0x02671D6C: RET                        | 
        // 0x02671D70: LDR x0, [x0, #0x88]        | 
        // 0x02671D74: RET                        | 
        // 0x02671D78: LDR x0, [x0, #0x68]        | 
        // 0x02671D7C: RET                        | 
        // 0x02671D80: LDR x0, [x0, #0x48]        | 
        // 0x02671D84: RET                        | 
        // 0x02671D88: LDR x0, [x0, #0x58]        | 
        // 0x02671D8C: RET                        | 
    
    }
    //
    // Offset in libil2cpp.so: 0x02671D90 (40312208), len: 284  VirtAddr: 0x02671D90 RVA: 0x02671D90 token: 100663304 methodIndex: 24388 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        // 0x02671D90: STP x20, x19, [sp, #-0x20]! | stack[1152921509943957184] = ???;  stack[1152921509943957192] = ???;  //  dest_result_addr=1152921509943957184 |  dest_result_addr=1152921509943957192
        // 0x02671D94: STP x29, x30, [sp, #0x10]  | stack[1152921509943957200] = ???;  stack[1152921509943957208] = ???;  //  dest_result_addr=1152921509943957200 |  dest_result_addr=1152921509943957208
        // 0x02671D98: ADD x29, sp, #0x10         | X29 = (1152921509943957184 + 16) = 1152921509943957200 (0x100000013E1DD6D0);
        // 0x02671D9C: MOV x19, x0                | X19 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671DA0: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671DA4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02671DA8: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_1B0; X2 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_1B8; //  | 
        // 0x02671DAC: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_1B0();
        // 0x02671DB0: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671DB4: LDP x1, x2, [x19, #0x70]   | X1 = this.shaderFXAAPreset2; //P2  X2 = this.materialFXAAPreset2; //P2  //  | 
        // 0x02671DB8: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671DBC: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671DC0: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671DC4: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671DC8: STR x0, [x19, #0x78]       | this.materialFXAAPreset2 = this;         //  dest_result_addr=1152921509943969336
        this.materialFXAAPreset2 = this;
        // 0x02671DCC: LDP x1, x2, [x19, #0x80]   | X1 = this.shaderFXAAPreset3; //P2  X2 = this.materialFXAAPreset3; //P2  //  | 
        // 0x02671DD0: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671DD4: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671DD8: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671DDC: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671DE0: STR x0, [x19, #0x88]       | this.materialFXAAPreset3 = this;         //  dest_result_addr=1152921509943969352
        this.materialFXAAPreset3 = this;
        // 0x02671DE4: LDP x1, x2, [x19, #0x90]   | X1 = this.shaderFXAAII; //P2  X2 = this.materialFXAAII; //P2  //  | 
        // 0x02671DE8: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671DEC: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671DF0: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671DF4: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671DF8: STR x0, [x19, #0x98]       | this.materialFXAAII = this;              //  dest_result_addr=1152921509943969368
        this.materialFXAAII = this;
        // 0x02671DFC: LDP x1, x2, [x19, #0xa0]   | X1 = this.shaderFXAAIII; //P2  X2 = this.materialFXAAIII; //P2  //  | 
        // 0x02671E00: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671E04: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671E08: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671E0C: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671E10: STR x0, [x19, #0xa8]       | this.materialFXAAIII = this;             //  dest_result_addr=1152921509943969384
        this.materialFXAAIII = this;
        // 0x02671E14: LDP x1, x2, [x19, #0x60]   | X1 = this.nfaaShader; //P2  X2 = this.nfaa; //P2  //  | 
        // 0x02671E18: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671E1C: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671E20: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671E24: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671E28: STR x0, [x19, #0x68]       | this.nfaa = this;                        //  dest_result_addr=1152921509943969320
        this.nfaa = this;
        // 0x02671E2C: LDP x1, x2, [x19, #0x40]   | X1 = this.ssaaShader; //P2  X2 = this.ssaa; //P2  //  | 
        // 0x02671E30: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671E34: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671E38: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671E3C: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671E40: STR x0, [x19, #0x48]       | this.ssaa = this;                        //  dest_result_addr=1152921509943969288
        this.ssaa = this;
        // 0x02671E44: LDP x1, x2, [x19, #0x50]   | X1 = this.dlaaShader; //P2  X2 = this.dlaa; //P2  //  | 
        // 0x02671E48: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671E4C: LDP x9, x3, [x8, #0x160]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160; X3 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_168; //  | 
        // 0x02671E50: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_160();
        // 0x02671E54: LDR x20, [x19, #0x40]      | X20 = this.ssaaShader; //P2             
        // 0x02671E58: STR x0, [x19, #0x58]       | this.dlaa = this;                        //  dest_result_addr=1152921509943969304
        this.dlaa = this;
        // 0x02671E5C: CBNZ x20, #0x2671e64       | if (this.ssaaShader != null) goto label_0;
        if(this.ssaaShader != null)
        {
            goto label_0;
        }
        // 0x02671E60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x02671E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02671E68: MOV x0, x20                | X0 = this.ssaaShader;//m1               
        // 0x02671E6C: BL #0x1b8e0d8              | X0 = this.ssaaShader.get_isSupported(); 
        bool val_1 = this.ssaaShader.isSupported;
        // 0x02671E70: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x02671E74: TBNZ w8, #0, #0x2671e9c    | if ((val_1 & 1) == true) goto label_1;  
        if(val_2 == true)
        {
            goto label_1;
        }
        // 0x02671E78: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671E7C: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671E80: LDR x9, [x8, #0x200]       | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_200;
        // 0x02671E84: LDR x1, [x8, #0x208]       | X1 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_208;
        // 0x02671E88: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_200();
        // 0x02671E8C: LDR x8, [x19]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671E90: MOV x0, x19                | X0 = 1152921509943969216 (0x100000013E1E05C0);//ML01
        // 0x02671E94: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_1E0; X1 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_1E8; //  | 
        // 0x02671E98: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_1E0();
        label_1:
        // 0x02671E9C: LDRB w0, [x19, #0x1a]      | 
        // 0x02671EA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02671EA4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02671EA8: RET                        |  return (System.Boolean)this;           
        return (bool)this;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02671EAC (40312492), len: 1580  VirtAddr: 0x02671EAC RVA: 0x02671EAC token: 100663305 methodIndex: 24389 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        AAMode val_13;
        //  | 
        UnityEngine.Material val_14;
        //  | 
        var val_15;
        //  | 
        AAMode val_16;
        //  | 
        AAMode val_17;
        //  | 
        var val_18;
        //  | 
        UnityEngine.RenderTexture val_19;
        // 0x02671EAC: STP d9, d8, [sp, #-0x50]!  | stack[1152921509944253952] = ???;  stack[1152921509944253960] = ???;  //  dest_result_addr=1152921509944253952 |  dest_result_addr=1152921509944253960
        // 0x02671EB0: STP x24, x23, [sp, #0x10]  | stack[1152921509944253968] = ???;  stack[1152921509944253976] = ???;  //  dest_result_addr=1152921509944253968 |  dest_result_addr=1152921509944253976
        // 0x02671EB4: STP x22, x21, [sp, #0x20]  | stack[1152921509944253984] = ???;  stack[1152921509944253992] = ???;  //  dest_result_addr=1152921509944253984 |  dest_result_addr=1152921509944253992
        // 0x02671EB8: STP x20, x19, [sp, #0x30]  | stack[1152921509944254000] = ???;  stack[1152921509944254008] = ???;  //  dest_result_addr=1152921509944254000 |  dest_result_addr=1152921509944254008
        // 0x02671EBC: STP x29, x30, [sp, #0x40]  | stack[1152921509944254016] = ???;  stack[1152921509944254024] = ???;  //  dest_result_addr=1152921509944254016 |  dest_result_addr=1152921509944254024
        // 0x02671EC0: ADD x29, sp, #0x40         | X29 = (1152921509944253952 + 64) = 1152921509944254016 (0x100000013E225E40);
        // 0x02671EC4: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02671EC8: LDRB w8, [x22, #0xe45]     | W8 = (bool)static_value_03740E45;       
        // 0x02671ECC: MOV x19, x2                | X19 = destination;//m1                  
        // 0x02671ED0: MOV x20, x1                | X20 = source;//m1                       
        // 0x02671ED4: MOV x21, x0                | X21 = 1152921509944266032 (0x100000013E228D30);//ML01
        // 0x02671ED8: TBNZ w8, #0, #0x2671ef4    | if (static_value_03740E45 == true) goto label_0;
        // 0x02671EDC: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x02671EE0: LDR x8, [x8, #0x510]       | X8 = 0x2B8AF44;                         
        // 0x02671EE4: LDR w0, [x8]               | W0 = 0x28F;                             
        // 0x02671EE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x28F, ????);      
        // 0x02671EEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02671EF0: STRB w8, [x22, #0xe45]     | static_value_03740E45 = true;            //  dest_result_addr=57937477
        label_0:
        // 0x02671EF4: LDR x8, [x21]              | X8 = typeof(AntialiasingAsPostEffect);  
        // 0x02671EF8: MOV x0, x21                | X0 = 1152921509944266032 (0x100000013E228D30);//ML01
        // 0x02671EFC: LDP x9, x1, [x8, #0x190]   | X9 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_190; X1 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_198; //  | 
        // 0x02671F00: BLR x9                     | X0 = typeof(AntialiasingAsPostEffect).__il2cppRuntimeField_190();
        // 0x02671F04: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x02671F08: TBZ w8, #0, #0x2672380     | if (((AntialiasingAsPostEffect)[1152921509944266032] & 0x1) == 0) goto label_43;
        if((0 & 1) == 0)
        {
            goto label_43;
        }
        // 0x02671F0C: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_13 = this.mode;
        // 0x02671F10: CMP w8, #1                 | STATE = COMPARE(this.mode, 0x1)         
        // 0x02671F14: B.NE #0x2671ff0            | if (val_13 != 0x1) goto label_2;        
        if(val_13 != 1)
        {
            goto label_2;
        }
        // 0x02671F18: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02671F1C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02671F20: LDR x22, [x21, #0xa8]      | X22 = this.materialFXAAIII; //P2        
        // 0x02671F24: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02671F28: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02671F2C: TBZ w8, #0, #0x2671f3c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x02671F30: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02671F34: CBNZ w8, #0x2671f3c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02671F38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x02671F3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02671F40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671F44: MOV x1, x22                | X1 = this.materialFXAAIII;//m1          
        // 0x02671F48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02671F4C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAIII);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAIII);
        // 0x02671F50: TBZ w0, #0, #0x2671fec     | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x02671F54: LDR x22, [x21, #0xa8]      | X22 = this.materialFXAAIII; //P2        
        // 0x02671F58: LDR s8, [x21, #0x2c]       | S8 = this.edgeThresholdMin; //P2        
        // 0x02671F5C: CBNZ x22, #0x2671f64       | if (this.materialFXAAIII != null) goto label_6;
        if(this.materialFXAAIII != null)
        {
            goto label_6;
        }
        // 0x02671F60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x02671F64: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
        // 0x02671F68: LDR x8, [x8, #0x360]       | X8 = (string**)(1152921509944139136)("_EdgeThresholdMin");
        // 0x02671F6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671F70: MOV x0, x22                | X0 = this.materialFXAAIII;//m1          
        // 0x02671F74: MOV v0.16b, v8.16b         | V0 = this.edgeThresholdMin;//m1         
        // 0x02671F78: LDR x1, [x8]               | X1 = "_EdgeThresholdMin";               
        // 0x02671F7C: BL #0x1a79ef8              | this.materialFXAAIII.SetFloat(name:  "_EdgeThresholdMin", value:  this.edgeThresholdMin);
        this.materialFXAAIII.SetFloat(name:  "_EdgeThresholdMin", value:  this.edgeThresholdMin);
        // 0x02671F80: LDR x22, [x21, #0xa8]      | X22 = this.materialFXAAIII; //P2        
        // 0x02671F84: LDR s8, [x21, #0x30]       | S8 = this.edgeThreshold; //P2           
        // 0x02671F88: CBNZ x22, #0x2671f90       | if (this.materialFXAAIII != null) goto label_7;
        if(this.materialFXAAIII != null)
        {
            goto label_7;
        }
        // 0x02671F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.materialFXAAIII, ????);
        label_7:
        // 0x02671F90: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x02671F94: LDR x8, [x8, #0x5a8]       | X8 = (string**)(1152921509944143344)("_EdgeThreshold");
        // 0x02671F98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671F9C: MOV x0, x22                | X0 = this.materialFXAAIII;//m1          
        // 0x02671FA0: MOV v0.16b, v8.16b         | V0 = this.edgeThreshold;//m1            
        // 0x02671FA4: LDR x1, [x8]               | X1 = "_EdgeThreshold";                  
        // 0x02671FA8: BL #0x1a79ef8              | this.materialFXAAIII.SetFloat(name:  "_EdgeThreshold", value:  this.edgeThreshold);
        this.materialFXAAIII.SetFloat(name:  "_EdgeThreshold", value:  this.edgeThreshold);
        // 0x02671FAC: LDR x22, [x21, #0xa8]      | X22 = this.materialFXAAIII; //P2        
        // 0x02671FB0: LDR s8, [x21, #0x34]       | S8 = this.edgeSharpness; //P2           
        // 0x02671FB4: CBNZ x22, #0x2671fbc       | if (this.materialFXAAIII != null) goto label_8;
        if(this.materialFXAAIII != null)
        {
            goto label_8;
        }
        // 0x02671FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.materialFXAAIII, ????);
        label_8:
        // 0x02671FBC: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x02671FC0: LDR x8, [x8, #0x4b0]       | X8 = (string**)(1152921509944147536)("_EdgeSharpness");
        // 0x02671FC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02671FC8: MOV x0, x22                | X0 = this.materialFXAAIII;//m1          
        // 0x02671FCC: MOV v0.16b, v8.16b         | V0 = this.edgeSharpness;//m1            
        // 0x02671FD0: LDR x1, [x8]               | X1 = "_EdgeSharpness";                  
        // 0x02671FD4: BL #0x1a79ef8              | this.materialFXAAIII.SetFloat(name:  "_EdgeSharpness", value:  this.edgeSharpness);
        this.materialFXAAIII.SetFloat(name:  "_EdgeSharpness", value:  this.edgeSharpness);
        // 0x02671FD8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02671FDC: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02671FE0: LDR x21, [x21, #0xa8]      | X21 = this.materialFXAAIII; //P2        
        val_14 = this.materialFXAAIII;
        // 0x02671FE4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        val_15 = null;
        // 0x02671FE8: B #0x26721c8               |  goto label_27;                         
        goto label_27;
        label_5:
        // 0x02671FEC: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_13 = this.mode;
        label_2:
        // 0x02671FF0: CMP w8, #3                 | STATE = COMPARE(this.mode, 0x3)         
        // 0x02671FF4: B.NE #0x2672050            | if (val_13 != 0x3) goto label_10;       
        if(val_13 != 3)
        {
            goto label_10;
        }
        // 0x02671FF8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02671FFC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02672000: LDR x22, [x21, #0x88]      | X22 = this.materialFXAAPreset3; //P2    
        // 0x02672004: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02672008: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0267200C: TBZ w8, #0, #0x267201c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x02672010: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02672014: CBNZ w8, #0x267201c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x02672018: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x0267201C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672024: MOV x1, x22                | X1 = this.materialFXAAPreset3;//m1      
        // 0x02672028: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267202C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAPreset3);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAPreset3);
        // 0x02672030: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x02672034: TBZ w8, #0, #0x267204c     | if ((val_2 & 1) == false) goto label_13;
        if(val_3 == false)
        {
            goto label_13;
        }
        // 0x02672038: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267203C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672040: LDR x21, [x21, #0x88]      | X21 = this.materialFXAAPreset3; //P2    
        val_14 = this.materialFXAAPreset3;
        // 0x02672044: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        val_15 = null;
        // 0x02672048: B #0x26721c8               |  goto label_27;                         
        goto label_27;
        label_13:
        // 0x0267204C: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_13 = this.mode;
        label_10:
        // 0x02672050: CMP w8, #2                 | STATE = COMPARE(this.mode, 0x2)         
        // 0x02672054: B.NE #0x2672118            | if (val_13 != 0x2) goto label_15;       
        if(val_13 != 2)
        {
            goto label_15;
        }
        // 0x02672058: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x0267205C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02672060: LDR x22, [x21, #0x78]      | X22 = this.materialFXAAPreset2; //P2    
        // 0x02672064: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02672068: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0267206C: TBZ w8, #0, #0x267207c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x02672070: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02672074: CBNZ w8, #0x267207c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x02672078: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_17:
        // 0x0267207C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672080: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672084: MOV x1, x22                | X1 = this.materialFXAAPreset2;//m1      
        // 0x02672088: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267208C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAPreset2);
        bool val_4 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAPreset2);
        // 0x02672090: TBZ w0, #0, #0x2672114     | if (val_4 == false) goto label_18;      
        if(val_4 == false)
        {
            goto label_18;
        }
        // 0x02672094: CBNZ x20, #0x267209c       | if (source != null) goto label_19;      
        if(source != null)
        {
            goto label_19;
        }
        // 0x02672098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_19:
        // 0x0267209C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026720A0: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x026720A4: MOV x0, x20                | X0 = source;//m1                        
        // 0x026720A8: BL #0x268efc8              | source.set_anisoLevel(value:  4);       
        source.anisoLevel = 4;
        // 0x026720AC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026720B0: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026720B4: LDR x21, [x21, #0x78]      | X21 = this.materialFXAAPreset2; //P2    
        // 0x026720B8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x026720BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026720C0: TBZ w8, #0, #0x26720d0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x026720C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026720C8: CBNZ w8, #0x26720d0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x026720CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_21:
        // 0x026720D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026720D4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x026720D8: MOV x1, x20                | X1 = source;//m1                        
        // 0x026720DC: MOV x2, x19                | X2 = destination;//m1                   
        // 0x026720E0: MOV x3, x21                | X3 = this.materialFXAAPreset2;//m1      
        // 0x026720E4: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        // 0x026720E8: CBNZ x20, #0x26720f0       | if (source != null) goto label_22;      
        if(source != null)
        {
            goto label_22;
        }
        // 0x026720EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_22:
        // 0x026720F0: MOV x0, x20                | X0 = source;//m1                        
        // 0x026720F4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x026720F8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x026720FC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02672100: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x02672104: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02672108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267210C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x02672110: B #0x268efc8               | source.set_anisoLevel(value:  0); return;
        source.anisoLevel = 0;
        return;
        label_18:
        // 0x02672114: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_16 = this.mode;
        label_15:
        // 0x02672118: CBNZ w8, #0x2672174        | if (this.mode != 0) goto label_23;      
        if(val_16 != 0)
        {
            goto label_23;
        }
        // 0x0267211C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02672120: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02672124: LDR x22, [x21, #0x98]      | X22 = this.materialFXAAII; //P2         
        // 0x02672128: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x0267212C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02672130: TBZ w8, #0, #0x2672140     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x02672134: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02672138: CBNZ w8, #0x2672140        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x0267213C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_25:
        // 0x02672140: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672144: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672148: MOV x1, x22                | X1 = this.materialFXAAII;//m1           
        // 0x0267214C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02672150: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAII);
        bool val_5 = UnityEngine.Object.op_Inequality(x:  0, y:  this.materialFXAAII);
        // 0x02672154: AND w8, w0, #1             | W8 = (val_5 & 1);                       
        bool val_6 = val_5;
        // 0x02672158: TBZ w8, #0, #0x2672170     | if ((val_5 & 1) == false) goto label_26;
        if(val_6 == false)
        {
            goto label_26;
        }
        // 0x0267215C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672160: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672164: LDR x21, [x21, #0x98]      | X21 = this.materialFXAAII; //P2         
        val_14 = this.materialFXAAII;
        // 0x02672168: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        val_15 = null;
        // 0x0267216C: B #0x26721c8               |  goto label_27;                         
        goto label_27;
        label_26:
        // 0x02672170: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_17 = this.mode;
        label_23:
        // 0x02672174: CMP w8, #5                 | STATE = COMPARE(this.mode, 0x5)         
        // 0x02672178: B.NE #0x267220c            | if (val_17 != 0x5) goto label_28;       
        if(val_17 != 5)
        {
            goto label_28;
        }
        // 0x0267217C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02672180: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02672184: LDR x22, [x21, #0x48]      | X22 = this.ssaa; //P2                   
        // 0x02672188: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x0267218C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02672190: TBZ w8, #0, #0x26721a0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x02672194: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02672198: CBNZ w8, #0x26721a0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x0267219C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_30:
        // 0x026721A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026721A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026721A8: MOV x1, x22                | X1 = this.ssaa;//m1                     
        // 0x026721AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026721B0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.ssaa);
        bool val_7 = UnityEngine.Object.op_Inequality(x:  0, y:  this.ssaa);
        // 0x026721B4: TBZ w0, #0, #0x2672208     | if (val_7 == false) goto label_31;      
        if(val_7 == false)
        {
            goto label_31;
        }
        // 0x026721B8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x026721BC: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x026721C0: LDR x21, [x21, #0x48]      | X21 = this.ssaa; //P2                   
        val_14 = this.ssaa;
        // 0x026721C4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        val_15 = null;
        label_27:
        // 0x026721C8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026721CC: TBZ w8, #0, #0x26721dc     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x026721D0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026721D4: CBNZ w8, #0x26721dc        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x026721D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_33:
        // 0x026721DC: MOV x1, x20                | X1 = source;//m1                        
        // 0x026721E0: MOV x2, x19                | X2 = destination;//m1                   
        // 0x026721E4: MOV x3, x21                | X3 = this.ssaa;//m1                     
        // 0x026721E8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x026721EC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x026721F0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x026721F4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x026721F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026721FC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02672200: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x02672204: B #0x1a6bc04               | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination);
        return;
        label_31:
        // 0x02672208: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_17 = this.mode;
        label_28:
        // 0x0267220C: CMP w8, #6                 | STATE = COMPARE(this.mode, 0x6)         
        // 0x02672210: B.NE #0x2672274            | if (val_17 != 0x6) goto label_34;       
        if(val_17 != 6)
        {
            goto label_34;
        }
        // 0x02672214: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02672218: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x0267221C: LDR x22, [x21, #0x58]      | X22 = this.dlaa; //P2                   
        // 0x02672220: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02672224: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02672228: TBZ w8, #0, #0x2672238     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_36;
        // 0x0267222C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02672230: CBNZ w8, #0x2672238        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
        // 0x02672234: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_36:
        // 0x02672238: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267223C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672240: MOV x1, x22                | X1 = this.dlaa;//m1                     
        // 0x02672244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02672248: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.dlaa);
        bool val_8 = UnityEngine.Object.op_Inequality(x:  0, y:  this.dlaa);
        // 0x0267224C: AND w8, w0, #1             | W8 = (val_8 & 1);                       
        bool val_9 = val_8;
        // 0x02672250: TBZ w8, #0, #0x2672270     | if ((val_8 & 1) == false) goto label_37;
        if(val_9 == false)
        {
            goto label_37;
        }
        // 0x02672254: CBZ x20, #0x26723c8        | if (source == null) goto label_38;      
        if(source == null)
        {
            goto label_38;
        }
        // 0x02672258: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        val_18 = 0;
        // 0x0267225C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672260: MOV x0, x20                | X0 = source;//m1                        
        // 0x02672264: BL #0x268efc8              | source.set_anisoLevel(value:  0);       
        source.anisoLevel = 0;
        // 0x02672268: MOV x22, x20               | X22 = source;//m1                       
        val_19 = source;
        // 0x0267226C: B #0x26723e4               |  goto label_39;                         
        goto label_39;
        label_37:
        // 0x02672270: LDR w8, [x21, #0x1c]       | W8 = this.mode; //P2                    
        val_17 = this.mode;
        label_34:
        // 0x02672274: CMP w8, #4                 | STATE = COMPARE(this.mode, 0x4)         
        // 0x02672278: B.NE #0x2672380            | if (val_17 != 0x4) goto label_43;       
        if(val_17 != 4)
        {
            goto label_43;
        }
        // 0x0267227C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02672280: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02672284: LDR x22, [x21, #0x68]      | X22 = this.nfaa; //P2                   
        // 0x02672288: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x0267228C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02672290: TBZ w8, #0, #0x26722a0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_42;
        // 0x02672294: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02672298: CBNZ w8, #0x26722a0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
        // 0x0267229C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_42:
        // 0x026722A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026722A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026722A8: MOV x1, x22                | X1 = this.nfaa;//m1                     
        // 0x026722AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026722B0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.nfaa);
        bool val_10 = UnityEngine.Object.op_Inequality(x:  0, y:  this.nfaa);
        // 0x026722B4: TBZ w0, #0, #0x2672380     | if (val_10 == false) goto label_43;     
        if(val_10 == false)
        {
            goto label_43;
        }
        // 0x026722B8: CBNZ x20, #0x26722c0       | if (source != null) goto label_44;      
        if(source != null)
        {
            goto label_44;
        }
        // 0x026722BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_44:
        // 0x026722C0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x026722C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026722C8: MOV x0, x20                | X0 = source;//m1                        
        // 0x026722CC: BL #0x268efc8              | source.set_anisoLevel(value:  0);       
        source.anisoLevel = 0;
        // 0x026722D0: LDR x22, [x21, #0x68]      | X22 = this.nfaa; //P2                   
        // 0x026722D4: LDR s8, [x21, #0x24]       | S8 = this.offsetScale; //P2             
        // 0x026722D8: CBNZ x22, #0x26722e0       | if (this.nfaa != null) goto label_45;   
        if(this.nfaa != null)
        {
            goto label_45;
        }
        // 0x026722DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_45:
        // 0x026722E0: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x026722E4: LDR x8, [x8, #0x850]       | X8 = (string**)(1152921509944221360)("_OffsetScale");
        // 0x026722E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026722EC: MOV x0, x22                | X0 = this.nfaa;//m1                     
        // 0x026722F0: MOV v0.16b, v8.16b         | V0 = this.offsetScale;//m1              
        // 0x026722F4: LDR x1, [x8]               | X1 = "_OffsetScale";                    
        // 0x026722F8: BL #0x1a79ef8              | this.nfaa.SetFloat(name:  "_OffsetScale", value:  this.offsetScale);
        this.nfaa.SetFloat(name:  "_OffsetScale", value:  this.offsetScale);
        // 0x026722FC: LDR x22, [x21, #0x68]      | X22 = this.nfaa; //P2                   
        // 0x02672300: LDR s8, [x21, #0x28]       | S8 = this.blurRadius; //P2              
        // 0x02672304: CBNZ x22, #0x267230c       | if (this.nfaa != null) goto label_46;   
        if(this.nfaa != null)
        {
            goto label_46;
        }
        // 0x02672308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.nfaa, ????);  
        label_46:
        // 0x0267230C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x02672310: LDR x8, [x8, #0x818]       | X8 = (string**)(1152921509944225552)("_BlurRadius");
        // 0x02672314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02672318: MOV x0, x22                | X0 = this.nfaa;//m1                     
        // 0x0267231C: MOV v0.16b, v8.16b         | V0 = this.blurRadius;//m1               
        // 0x02672320: LDR x1, [x8]               | X1 = "_BlurRadius";                     
        // 0x02672324: BL #0x1a79ef8              | this.nfaa.SetFloat(name:  "_BlurRadius", value:  this.blurRadius);
        this.nfaa.SetFloat(name:  "_BlurRadius", value:  this.blurRadius);
        // 0x02672328: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267232C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672330: LDR x22, [x21, #0x68]      | X22 = this.nfaa; //P2                   
        // 0x02672334: LDRB w21, [x21, #0x20]     | W21 = this.showGeneratedNormals; //P2   
        // 0x02672338: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267233C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672340: TBZ w8, #0, #0x2672350     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_48;
        // 0x02672344: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672348: CBNZ w8, #0x2672350        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
        // 0x0267234C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_48:
        // 0x02672350: MOV x1, x20                | X1 = source;//m1                        
        // 0x02672354: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02672358: MOV x3, x22                | X3 = this.nfaa;//m1                     
        // 0x0267235C: MOV w4, w21                | W4 = this.showGeneratedNormals;//m1     
        // 0x02672360: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02672364: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02672368: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x0267236C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x02672370: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672374: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672378: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x0267237C: B #0x1a6bc84               | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination, pass:  this.nfaa); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination, pass:  this.nfaa);
        return;
        label_43:
        // 0x02672380: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02672384: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02672388: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267238C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02672390: TBZ w8, #0, #0x26723a0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_50;
        // 0x02672394: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672398: CBNZ w8, #0x26723a0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_50;
        // 0x0267239C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_50:
        // 0x026723A0: MOV x1, x20                | X1 = source;//m1                        
        // 0x026723A4: MOV x2, x19                | X2 = destination;//m1                   
        // 0x026723A8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x026723AC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x026723B0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x026723B4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x026723B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026723BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026723C0: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x026723C4: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
        label_38:
        // 0x026723C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        // 0x026723CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026723D0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        val_18 = 0;
        // 0x026723D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026723D8: BL #0x268efc8              | 0.set_anisoLevel(value:  0);            
        0.anisoLevel = 0;
        // 0x026723DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x026723E0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_19 = 0;
        label_39:
        // 0x026723E4: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026723E8: MOV x0, x20                | X0 = source;//m1                        
        // 0x026723EC: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026723F0: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026723F4: MOV w23, w0                | W23 = source;//m1                       
        // 0x026723F8: CBNZ x20, #0x2672400       | if (source != null) goto label_51;      
        if(source != null)
        {
            goto label_51;
        }
        // 0x026723FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_51:
        // 0x02672400: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02672404: MOV x0, x20                | X0 = source;//m1                        
        // 0x02672408: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x0267240C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02672410: MOV w2, w0                 | W2 = source;//m1                        
        // 0x02672414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672418: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0267241C: MOV w1, w23                | W1 = source;//m1                        
        // 0x02672420: BL #0x1b89198              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        UnityEngine.RenderTexture val_11 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  source);
        // 0x02672424: ADRP x24, #0x3641000       | X24 = 56889344 (0x3641000);             
        // 0x02672428: LDR x24, [x24, #0x800]     | X24 = 1152921504693481472;              
        // 0x0267242C: LDR x23, [x21, #0x58]      | X23 = this.dlaa; //P2                   
        // 0x02672430: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x02672434: LDR x8, [x24]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02672438: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267243C: TBZ w9, #0, #0x2672450     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_53;
        // 0x02672440: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672444: CBNZ w9, #0x2672450        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
        // 0x02672448: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x0267244C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_53:
        // 0x02672450: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02672454: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x02672458: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
        // 0x0267245C: MOV x2, x20                | X2 = val_11;//m1                        
        // 0x02672460: MOV x3, x23                | X3 = this.dlaa;//m1                     
        // 0x02672464: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02672468: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_11, pass:  this.dlaa);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_19, mat:  val_11, pass:  this.dlaa);
        // 0x0267246C: LDR x0, [x24]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x02672470: LDRB w8, [x21, #0x38]      | W8 = this.dlaaSharp; //P2               
        // 0x02672474: LDR x21, [x21, #0x58]      | X21 = this.dlaa; //P2                   
        // 0x02672478: LDRB w9, [x0, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267247C: CMP w8, #0                 | STATE = COMPARE(this.dlaaSharp, 0x0)    
        // 0x02672480: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02672484: CINC w22, w8, ne           | W22 = this.dlaaSharp == true ? (1 + 1) : 1;
        var val_12 = (this.dlaaSharp == true) ? (1 + 1) : (1);
        // 0x02672488: TBZ w9, #0, #0x2672498     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_55;
        // 0x0267248C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02672490: CBNZ w8, #0x2672498        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
        // 0x02672494: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_55:
        // 0x02672498: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267249C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026724A0: MOV x1, x20                | X1 = val_11;//m1                        
        // 0x026724A4: MOV x2, x19                | X2 = destination;//m1                   
        // 0x026724A8: MOV x3, x21                | X3 = this.dlaa;//m1                     
        // 0x026724AC: MOV w4, w22                | W4 = this.dlaaSharp == true ? (1 + 1) : 1;//m1
        // 0x026724B0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_11, mat:  destination, pass:  this.dlaa);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_11, mat:  destination, pass:  this.dlaa);
        // 0x026724B4: MOV x1, x20                | X1 = val_11;//m1                        
        // 0x026724B8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x026724BC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x026724C0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x026724C4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x026724C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026724CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026724D0: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x026724D4: B #0x1b892ac               | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0); return;
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026724D8 (40314072), len: 4  VirtAddr: 0x026724D8 RVA: 0x026724D8 token: 100663306 methodIndex: 24390 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x026724D8: RET                        |  return;                                
        return;
    
    }

}
