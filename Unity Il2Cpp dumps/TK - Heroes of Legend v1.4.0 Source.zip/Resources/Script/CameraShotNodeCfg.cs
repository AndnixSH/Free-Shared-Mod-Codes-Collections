using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286CAF0
[Serializable]
public class CameraShotNodeCfg : IExtensible
{
    // Fields
    private float _posX; //  0x00000010
    private float _posY; //  0x00000014
    private float _posZ; //  0x00000018
    private float _rotX; //  0x0000001C
    private float _rotY; //  0x00000020
    private float _rotZ; //  0x00000024
    private float _speed; //  0x00000028
    private int _focusId; //  0x0000002C
    private float _smooth; //  0x00000030
    private float _view; //  0x00000034
    private float _bright; //  0x00000038
    private float _orthographic; //  0x0000003C
    private int _isHero; //  0x00000040
    private ProtoBuf.IExtension extensionObject; //  0x00000048
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286CB34
    [System.ComponentModel.DefaultValueAttribute] // 0x286CB34
    public float posX { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CBB4
    [System.ComponentModel.DefaultValueAttribute] // 0x286CBB4
    public float posY { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CC34
    [System.ComponentModel.DefaultValueAttribute] // 0x286CC34
    public float posZ { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CCB4
    [System.ComponentModel.DefaultValueAttribute] // 0x286CCB4
    public float rotX { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CD34
    [System.ComponentModel.DefaultValueAttribute] // 0x286CD34
    public float rotY { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CDB4
    [System.ComponentModel.DefaultValueAttribute] // 0x286CDB4
    public float rotZ { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CE34
    [System.ComponentModel.DefaultValueAttribute] // 0x286CE34
    public float speed { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CEB4
    [System.ComponentModel.DefaultValueAttribute] // 0x286CEB4
    public int focusId { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CF34
    [System.ComponentModel.DefaultValueAttribute] // 0x286CF34
    public float smooth { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286CFB4
    [System.ComponentModel.DefaultValueAttribute] // 0x286CFB4
    public float view { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D034
    [System.ComponentModel.DefaultValueAttribute] // 0x286D034
    public float bright { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D0B4
    [System.ComponentModel.DefaultValueAttribute] // 0x286D0B4
    public float orthographic { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286D134
    [System.ComponentModel.DefaultValueAttribute] // 0x286D134
    public int isHero { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D7F070 (14151792), len: 8  VirtAddr: 0x00D7F070 RVA: 0x00D7F070 token: 100690372 methodIndex: 25866 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotNodeCfg()
    {
        //
        // Disasemble & Code
        // 0x00D7F070: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F074: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F078 (14151800), len: 8  VirtAddr: 0x00D7F078 RVA: 0x00D7F078 token: 100690373 methodIndex: 25867 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posX()
    {
        //
        // Disasemble & Code
        // 0x00D7F078: LDR s0, [x0, #0x10]        | S0 = this._posX; //P2                   
        // 0x00D7F07C: RET                        |  return (System.Single)this._posX;      
        return this._posX;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F080 (14151808), len: 8  VirtAddr: 0x00D7F080 RVA: 0x00D7F080 token: 100690374 methodIndex: 25868 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posX(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F080: STR s0, [x0, #0x10]        | this._posX = value;                      //  dest_result_addr=1152921514514013360
        this._posX = value;
        // 0x00D7F084: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F088 (14151816), len: 8  VirtAddr: 0x00D7F088 RVA: 0x00D7F088 token: 100690375 methodIndex: 25869 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posY()
    {
        //
        // Disasemble & Code
        // 0x00D7F088: LDR s0, [x0, #0x14]        | S0 = this._posY; //P2                   
        // 0x00D7F08C: RET                        |  return (System.Single)this._posY;      
        return this._posY;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F090 (14151824), len: 8  VirtAddr: 0x00D7F090 RVA: 0x00D7F090 token: 100690376 methodIndex: 25870 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posY(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F090: STR s0, [x0, #0x14]        | this._posY = value;                      //  dest_result_addr=1152921514514237364
        this._posY = value;
        // 0x00D7F094: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F098 (14151832), len: 8  VirtAddr: 0x00D7F098 RVA: 0x00D7F098 token: 100690377 methodIndex: 25871 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_posZ()
    {
        //
        // Disasemble & Code
        // 0x00D7F098: LDR s0, [x0, #0x18]        | S0 = this._posZ; //P2                   
        // 0x00D7F09C: RET                        |  return (System.Single)this._posZ;      
        return this._posZ;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0A0 (14151840), len: 8  VirtAddr: 0x00D7F0A0 RVA: 0x00D7F0A0 token: 100690378 methodIndex: 25872 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_posZ(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F0A0: STR s0, [x0, #0x18]        | this._posZ = value;                      //  dest_result_addr=1152921514514461368
        this._posZ = value;
        // 0x00D7F0A4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0A8 (14151848), len: 8  VirtAddr: 0x00D7F0A8 RVA: 0x00D7F0A8 token: 100690379 methodIndex: 25873 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_rotX()
    {
        //
        // Disasemble & Code
        // 0x00D7F0A8: LDR s0, [x0, #0x1c]        | S0 = this._rotX; //P2                   
        // 0x00D7F0AC: RET                        |  return (System.Single)this._rotX;      
        return this._rotX;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0B0 (14151856), len: 8  VirtAddr: 0x00D7F0B0 RVA: 0x00D7F0B0 token: 100690380 methodIndex: 25874 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_rotX(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F0B0: STR s0, [x0, #0x1c]        | this._rotX = value;                      //  dest_result_addr=1152921514514685372
        this._rotX = value;
        // 0x00D7F0B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0B8 (14151864), len: 8  VirtAddr: 0x00D7F0B8 RVA: 0x00D7F0B8 token: 100690381 methodIndex: 25875 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_rotY()
    {
        //
        // Disasemble & Code
        // 0x00D7F0B8: LDR s0, [x0, #0x20]        | S0 = this._rotY; //P2                   
        // 0x00D7F0BC: RET                        |  return (System.Single)this._rotY;      
        return this._rotY;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0C0 (14151872), len: 8  VirtAddr: 0x00D7F0C0 RVA: 0x00D7F0C0 token: 100690382 methodIndex: 25876 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_rotY(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F0C0: STR s0, [x0, #0x20]        | this._rotY = value;                      //  dest_result_addr=1152921514514909376
        this._rotY = value;
        // 0x00D7F0C4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0C8 (14151880), len: 8  VirtAddr: 0x00D7F0C8 RVA: 0x00D7F0C8 token: 100690383 methodIndex: 25877 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_rotZ()
    {
        //
        // Disasemble & Code
        // 0x00D7F0C8: LDR s0, [x0, #0x24]        | S0 = this._rotZ; //P2                   
        // 0x00D7F0CC: RET                        |  return (System.Single)this._rotZ;      
        return this._rotZ;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0D0 (14151888), len: 8  VirtAddr: 0x00D7F0D0 RVA: 0x00D7F0D0 token: 100690384 methodIndex: 25878 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_rotZ(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F0D0: STR s0, [x0, #0x24]        | this._rotZ = value;                      //  dest_result_addr=1152921514515133380
        this._rotZ = value;
        // 0x00D7F0D4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0D8 (14151896), len: 8  VirtAddr: 0x00D7F0D8 RVA: 0x00D7F0D8 token: 100690385 methodIndex: 25879 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_speed()
    {
        //
        // Disasemble & Code
        // 0x00D7F0D8: LDR s0, [x0, #0x28]        | S0 = this._speed; //P2                  
        // 0x00D7F0DC: RET                        |  return (System.Single)this._speed;     
        return this._speed;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0E0 (14151904), len: 8  VirtAddr: 0x00D7F0E0 RVA: 0x00D7F0E0 token: 100690386 methodIndex: 25880 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_speed(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F0E0: STR s0, [x0, #0x28]        | this._speed = value;                     //  dest_result_addr=1152921514515357384
        this._speed = value;
        // 0x00D7F0E4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0E8 (14151912), len: 8  VirtAddr: 0x00D7F0E8 RVA: 0x00D7F0E8 token: 100690387 methodIndex: 25881 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_focusId()
    {
        //
        // Disasemble & Code
        // 0x00D7F0E8: LDR w0, [x0, #0x2c]        | W0 = this._focusId; //P2                
        // 0x00D7F0EC: RET                        |  return (System.Int32)this._focusId;    
        return this._focusId;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0F0 (14151920), len: 8  VirtAddr: 0x00D7F0F0 RVA: 0x00D7F0F0 token: 100690388 methodIndex: 25882 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_focusId(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F0F0: STR w1, [x0, #0x2c]        | this._focusId = value;                   //  dest_result_addr=1152921514515581388
        this._focusId = value;
        // 0x00D7F0F4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F0F8 (14151928), len: 8  VirtAddr: 0x00D7F0F8 RVA: 0x00D7F0F8 token: 100690389 methodIndex: 25883 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_smooth()
    {
        //
        // Disasemble & Code
        // 0x00D7F0F8: LDR s0, [x0, #0x30]        | S0 = this._smooth; //P2                 
        // 0x00D7F0FC: RET                        |  return (System.Single)this._smooth;    
        return this._smooth;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F100 (14151936), len: 8  VirtAddr: 0x00D7F100 RVA: 0x00D7F100 token: 100690390 methodIndex: 25884 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_smooth(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F100: STR s0, [x0, #0x30]        | this._smooth = value;                    //  dest_result_addr=1152921514515805392
        this._smooth = value;
        // 0x00D7F104: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F108 (14151944), len: 8  VirtAddr: 0x00D7F108 RVA: 0x00D7F108 token: 100690391 methodIndex: 25885 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_view()
    {
        //
        // Disasemble & Code
        // 0x00D7F108: LDR s0, [x0, #0x34]        | S0 = this._view; //P2                   
        // 0x00D7F10C: RET                        |  return (System.Single)this._view;      
        return this._view;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F110 (14151952), len: 8  VirtAddr: 0x00D7F110 RVA: 0x00D7F110 token: 100690392 methodIndex: 25886 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_view(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F110: STR s0, [x0, #0x34]        | this._view = value;                      //  dest_result_addr=1152921514516029396
        this._view = value;
        // 0x00D7F114: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F118 (14151960), len: 8  VirtAddr: 0x00D7F118 RVA: 0x00D7F118 token: 100690393 methodIndex: 25887 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_bright()
    {
        //
        // Disasemble & Code
        // 0x00D7F118: LDR s0, [x0, #0x38]        | S0 = this._bright; //P2                 
        // 0x00D7F11C: RET                        |  return (System.Single)this._bright;    
        return this._bright;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F120 (14151968), len: 8  VirtAddr: 0x00D7F120 RVA: 0x00D7F120 token: 100690394 methodIndex: 25888 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_bright(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F120: STR s0, [x0, #0x38]        | this._bright = value;                    //  dest_result_addr=1152921514516253400
        this._bright = value;
        // 0x00D7F124: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F128 (14151976), len: 8  VirtAddr: 0x00D7F128 RVA: 0x00D7F128 token: 100690395 methodIndex: 25889 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_orthographic()
    {
        //
        // Disasemble & Code
        // 0x00D7F128: LDR s0, [x0, #0x3c]        | S0 = this._orthographic; //P2           
        // 0x00D7F12C: RET                        |  return (System.Single)this._orthographic;
        return this._orthographic;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F130 (14151984), len: 8  VirtAddr: 0x00D7F130 RVA: 0x00D7F130 token: 100690396 methodIndex: 25890 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_orthographic(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F130: STR s0, [x0, #0x3c]        | this._orthographic = value;              //  dest_result_addr=1152921514516477404
        this._orthographic = value;
        // 0x00D7F134: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F138 (14151992), len: 8  VirtAddr: 0x00D7F138 RVA: 0x00D7F138 token: 100690397 methodIndex: 25891 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_isHero()
    {
        //
        // Disasemble & Code
        // 0x00D7F138: LDR w0, [x0, #0x40]        | W0 = this._isHero; //P2                 
        // 0x00D7F13C: RET                        |  return (System.Int32)this._isHero;     
        return this._isHero;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F140 (14152000), len: 8  VirtAddr: 0x00D7F140 RVA: 0x00D7F140 token: 100690398 methodIndex: 25892 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_isHero(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F140: STR w1, [x0, #0x40]        | this._isHero = value;                    //  dest_result_addr=1152921514516701408
        this._isHero = value;
        // 0x00D7F144: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F148 (14152008), len: 24  VirtAddr: 0x00D7F148 RVA: 0x00D7F148 token: 100690399 methodIndex: 25893 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00D7F148: ADD x8, x0, #0x48          | X8 = this.extensionObject;//AP2 res_addr=1152921514516813416
        // 0x00D7F14C: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00D7F150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00D7F154: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00D7F158: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F15C: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
