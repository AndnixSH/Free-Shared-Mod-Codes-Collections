using UnityEngine;

namespace Pathfinding
{
    public class AnimationLink : NodeLink2
    {
        // Fields
        public string clip; //  0x00000078
        public float animSpeed; //  0x00000080
        public bool reverseAnim; //  0x00000084
        public UnityEngine.GameObject referenceMesh; //  0x00000088
        public Pathfinding.AnimationLink.LinkClip[] sequence; //  0x00000090
        public string boneRoot; //  0x00000098
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0167E23C (23585340), len: 136  VirtAddr: 0x0167E23C RVA: 0x0167E23C token: 100682122 methodIndex: 49750 delegateWrapperIndex: 0 methodInvoker: 0
        public AnimationLink()
        {
            //
            // Disasemble & Code
            // 0x0167E23C: STP x20, x19, [sp, #-0x20]! | stack[1152921513192859568] = ???;  stack[1152921513192859576] = ???;  //  dest_result_addr=1152921513192859568 |  dest_result_addr=1152921513192859576
            // 0x0167E240: STP x29, x30, [sp, #0x10]  | stack[1152921513192859584] = ???;  stack[1152921513192859592] = ???;  //  dest_result_addr=1152921513192859584 |  dest_result_addr=1152921513192859592
            // 0x0167E244: ADD x29, sp, #0x10         | X29 = (1152921513192859568 + 16) = 1152921513192859584 (0x10000001FFC427C0);
            // 0x0167E248: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167E24C: LDRB w8, [x20, #0xac]      | W8 = (bool)static_value_037380AC;       
            // 0x0167E250: MOV x19, x0                | X19 = 1152921513192871600 (0x10000001FFC456B0);//ML01
            // 0x0167E254: TBNZ w8, #0, #0x167e270    | if (static_value_037380AC == true) goto label_0;
            // 0x0167E258: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x0167E25C: LDR x8, [x8, #0xbd0]       | X8 = 0x2B8ADEC;                         
            // 0x0167E260: LDR w0, [x8]               | W0 = 0x239;                             
            // 0x0167E264: BL #0x2782188              | X0 = sub_2782188( ?? 0x239, ????);      
            // 0x0167E268: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167E26C: STRB w8, [x20, #0xac]      | static_value_037380AC = true;            //  dest_result_addr=57901228
            label_0:
            // 0x0167E270: ADRP x10, #0x3669000       | X10 = 57053184 (0x3669000);             
            // 0x0167E274: LDR x10, [x10, #0x60]      | X10 = (string**)(1152921513192847504)("bn_COG_Root");
            // 0x0167E278: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x0167E27C: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
            // 0x0167E280: STRB w9, [x19, #0x84]      | this.reverseAnim = true;                 //  dest_result_addr=1152921513192871732
            this.reverseAnim = true;
            // 0x0167E284: STR w8, [x19, #0x80]       | this.animSpeed = 1;                      //  dest_result_addr=1152921513192871728
            this.animSpeed = 1f;
            // 0x0167E288: LDR x8, [x10]              | X8 = "bn_COG_Root";                     
            // 0x0167E28C: STR x8, [x19, #0x98]       | this.boneRoot = "bn_COG_Root";           //  dest_result_addr=1152921513192871752
            this.boneRoot = "bn_COG_Root";
            // 0x0167E290: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
            // 0x0167E294: LDR x8, [x8, #0x610]       | X8 = 1152921504839593984;               
            // 0x0167E298: LDR x0, [x8]               | X0 = typeof(Pathfinding.NodeLink2);     
            // 0x0167E29C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.NodeLink2.__il2cppRuntimeField_10A;
            // 0x0167E2A0: TBZ w8, #0, #0x167e2b0     | if (Pathfinding.NodeLink2.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167E2A4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.NodeLink2.__il2cppRuntimeField_cctor_finished;
            // 0x0167E2A8: CBNZ w8, #0x167e2b0        | if (Pathfinding.NodeLink2.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167E2AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.NodeLink2), ????);
            label_2:
            // 0x0167E2B0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167E2B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E2B8: MOV x0, x19                | X0 = 1152921513192871600 (0x10000001FFC456B0);//ML01
            // 0x0167E2BC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167E2C0: B #0x156bbd0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167E2C4 (23585476), len: 348  VirtAddr: 0x0167E2C4 RVA: 0x0167E2C4 token: 100682123 methodIndex: 49751 delegateWrapperIndex: 0 methodInvoker: 0
        private static UnityEngine.Transform SearchRec(UnityEngine.Transform tr, string name)
        {
            //
            // Disasemble & Code
            //  | 
            UnityEngine.Object val_8;
            label_8:
            // 0x0167E2C4: STP x26, x25, [sp, #-0x50]! | stack[1152921513192987904] = ???;  stack[1152921513192987912] = ???;  //  dest_result_addr=1152921513192987904 |  dest_result_addr=1152921513192987912
            // 0x0167E2C8: STP x24, x23, [sp, #0x10]  | stack[1152921513192987920] = ???;  stack[1152921513192987928] = ???;  //  dest_result_addr=1152921513192987920 |  dest_result_addr=1152921513192987928
            // 0x0167E2CC: STP x22, x21, [sp, #0x20]  | stack[1152921513192987936] = ???;  stack[1152921513192987944] = ???;  //  dest_result_addr=1152921513192987936 |  dest_result_addr=1152921513192987944
            // 0x0167E2D0: STP x20, x19, [sp, #0x30]  | stack[1152921513192987952] = ???;  stack[1152921513192987960] = ???;  //  dest_result_addr=1152921513192987952 |  dest_result_addr=1152921513192987960
            // 0x0167E2D4: STP x29, x30, [sp, #0x40]  | stack[1152921513192987968] = ???;  stack[1152921513192987976] = ???;  //  dest_result_addr=1152921513192987968 |  dest_result_addr=1152921513192987976
            // 0x0167E2D8: ADD x29, sp, #0x40         | X29 = (1152921513192987904 + 64) = 1152921513192987968 (0x10000001FFC61D40);
            // 0x0167E2DC: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x0167E2E0: LDRB w8, [x21, #0xad]      | W8 = (bool)static_value_037380AD;       
            // 0x0167E2E4: MOV x19, x2                | X19 = X2;//m1                           
            // 0x0167E2E8: MOV x20, x1                | X20 = name;//m1                         
            // 0x0167E2EC: TBNZ w8, #0, #0x167e308    | if (static_value_037380AD == true) goto label_0;
            // 0x0167E2F0: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x0167E2F4: LDR x8, [x8, #0xe38]       | X8 = 0x2B8ADF8;                         
            // 0x0167E2F8: LDR w0, [x8]               | W0 = 0x23C;                             
            // 0x0167E2FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x23C, ????);      
            // 0x0167E300: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167E304: STRB w8, [x21, #0xad]      | static_value_037380AD = true;            //  dest_result_addr=57901229
            label_0:
            // 0x0167E308: CBNZ x20, #0x167e310       | if (name != null) goto label_1;         
            if(name != null)
            {
                goto label_1;
            }
            // 0x0167E30C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x23C, ????);      
            label_1:
            // 0x0167E310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E314: MOV x0, x20                | X0 = name;//m1                          
            // 0x0167E318: BL #0x2695840              | X0 = name.get_childCount();             
            int val_1 = name.childCount;
            // 0x0167E31C: MOV w21, w0                | W21 = val_1;//m1                        
            // 0x0167E320: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x0167E324: CMP w21, #1                | STATE = COMPARE(val_1, 0x1)             
            // 0x0167E328: B.LT #0x167e404            | if (val_1 < 1) goto label_11;           
            if(val_1 < 1)
            {
                goto label_11;
            }
            // 0x0167E32C: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
            // 0x0167E330: ADRP x26, #0x35fe000       | X26 = 56614912 (0x35FE000);             
            // 0x0167E334: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
            // 0x0167E338: LDR x26, [x26, #0x810]     | X26 = 1152921504697475072;              
            // 0x0167E33C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_8 = 0;
            label_12:
            // 0x0167E340: CBNZ x20, #0x167e348       | if (name != null) goto label_3;         
            if(name != null)
            {
                goto label_3;
            }
            // 0x0167E344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x0167E348: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E34C: MOV x0, x20                | X0 = name;//m1                          
            // 0x0167E350: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
            // 0x0167E354: BL #0x2695dd8              | X0 = name.GetChild(index:  0);          
            UnityEngine.Transform val_2 = name.GetChild(index:  0);
            // 0x0167E358: MOV x23, x0                | X23 = val_2;//m1                        
            val_8 = val_2;
            // 0x0167E35C: CBNZ x23, #0x167e364       | if (val_2 != null) goto label_4;        
            if(val_8 != null)
            {
                goto label_4;
            }
            // 0x0167E360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x0167E364: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E368: MOV x0, x23                | X0 = val_2;//m1                         
            // 0x0167E36C: BL #0x1b759fc              | X0 = val_2.get_name();                  
            string val_3 = val_8.name;
            // 0x0167E370: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0167E374: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0167E378: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0167E37C: TBZ w9, #0, #0x167e390     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0167E380: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0167E384: CBNZ w9, #0x167e390        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x0167E388: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0167E38C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_6:
            // 0x0167E390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E394: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167E398: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x0167E39C: MOV x2, x19                | X2 = X2;//m1                            
            // 0x0167E3A0: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_3);
            bool val_4 = System.String.op_Equality(a:  0, b:  val_3);
            // 0x0167E3A4: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x0167E3A8: TBNZ w8, #0, #0x167e404    | if ((val_4 & 1) == true) goto label_11; 
            if(val_5 == true)
            {
                goto label_11;
            }
            // 0x0167E3AC: MOV x1, x23                | X1 = val_2;//m1                         
            // 0x0167E3B0: MOV x2, x19                | X2 = X2;//m1                            
            // 0x0167E3B4: BL #0x167e2c4              |  R0 = label_8();                        
            // 0x0167E3B8: LDR x8, [x26]              | X8 = typeof(UnityEngine.Object);        
            // 0x0167E3BC: MOV x23, x0                | X23 = val_4;//m1                        
            val_8 = val_4;
            // 0x0167E3C0: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167E3C4: TBZ w9, #0, #0x167e3d8     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x0167E3C8: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167E3CC: CBNZ w9, #0x167e3d8        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x0167E3D0: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
            // 0x0167E3D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_10:
            // 0x0167E3D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E3DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E3E0: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x0167E3E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167E3E8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_8);
            bool val_6 = UnityEngine.Object.op_Inequality(x:  0, y:  val_8);
            // 0x0167E3EC: AND w8, w0, #1             | W8 = (val_6 & 1);                       
            bool val_7 = val_6;
            // 0x0167E3F0: TBNZ w8, #0, #0x167e404    | if ((val_6 & 1) == true) goto label_11; 
            if(val_7 == true)
            {
                goto label_11;
            }
            // 0x0167E3F4: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x0167E3F8: CMP w22, w21               | STATE = COMPARE((0 + 1), val_1)         
            // 0x0167E3FC: B.LT #0x167e340            | if (0 < val_1) goto label_12;           
            if(val_8 < val_1)
            {
                goto label_12;
            }
            // 0x0167E400: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_11:
            // 0x0167E404: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x0167E408: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167E40C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167E410: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167E414: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x0167E418: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0167E41C: RET                        |  return (UnityEngine.Transform)null;    
            return (UnityEngine.Transform)val_8;
            //  |  // // {name=val_0, type=UnityEngine.Transform, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0167E420 (23585824), len: 2900  VirtAddr: 0x0167E420 RVA: 0x0167E420 token: 100682124 methodIndex: 49752 delegateWrapperIndex: 0 methodInvoker: 0
        public void CalculateOffsets(System.Collections.Generic.List<UnityEngine.Vector3> trace, out UnityEngine.Vector3 endPosition)
        {
            //
            // Disasemble & Code
            //  | 
            LinkClip[] val_60;
            //  | 
            float val_61;
            //  | 
            float val_62;
            //  | 
            var val_63;
            //  | 
            UnityEngine.Object val_64;
            //  | 
            var val_65;
            //  | 
            float val_66;
            //  | 
            float val_67;
            //  | 
            float val_68;
            //  | 
            var val_69;
            //  | 
            float val_70;
            //  | 
            var val_71;
            //  | 
            var val_72;
            //  | 
            float val_73;
            //  | 
            float val_74;
            //  | 
            float val_75;
            //  | 
            var val_76;
            //  | 
            var val_77;
            //  | 
            float val_78;
            //  | 
            float val_79;
            // 0x0167E420: STP d15, d14, [sp, #-0xa0]! | stack[1152921513193478784] = ???;  stack[1152921513193478792] = ???;  //  dest_result_addr=1152921513193478784 |  dest_result_addr=1152921513193478792
            // 0x0167E424: STP d13, d12, [sp, #0x10]  | stack[1152921513193478800] = ???;  stack[1152921513193478808] = ???;  //  dest_result_addr=1152921513193478800 |  dest_result_addr=1152921513193478808
            // 0x0167E428: STP d11, d10, [sp, #0x20]  | stack[1152921513193478816] = ???;  stack[1152921513193478824] = ???;  //  dest_result_addr=1152921513193478816 |  dest_result_addr=1152921513193478824
            // 0x0167E42C: STP d9, d8, [sp, #0x30]    | stack[1152921513193478832] = ???;  stack[1152921513193478840] = ???;  //  dest_result_addr=1152921513193478832 |  dest_result_addr=1152921513193478840
            // 0x0167E430: STP x28, x27, [sp, #0x40]  | stack[1152921513193478848] = ???;  stack[1152921513193478856] = ???;  //  dest_result_addr=1152921513193478848 |  dest_result_addr=1152921513193478856
            // 0x0167E434: STP x26, x25, [sp, #0x50]  | stack[1152921513193478864] = ???;  stack[1152921513193478872] = ???;  //  dest_result_addr=1152921513193478864 |  dest_result_addr=1152921513193478872
            // 0x0167E438: STP x24, x23, [sp, #0x60]  | stack[1152921513193478880] = ???;  stack[1152921513193478888] = ???;  //  dest_result_addr=1152921513193478880 |  dest_result_addr=1152921513193478888
            // 0x0167E43C: STP x22, x21, [sp, #0x70]  | stack[1152921513193478896] = ???;  stack[1152921513193478904] = ???;  //  dest_result_addr=1152921513193478896 |  dest_result_addr=1152921513193478904
            // 0x0167E440: STP x20, x19, [sp, #0x80]  | stack[1152921513193478912] = ???;  stack[1152921513193478920] = ???;  //  dest_result_addr=1152921513193478912 |  dest_result_addr=1152921513193478920
            // 0x0167E444: STP x29, x30, [sp, #0x90]  | stack[1152921513193478928] = ???;  stack[1152921513193478936] = ???;  //  dest_result_addr=1152921513193478928 |  dest_result_addr=1152921513193478936
            // 0x0167E448: ADD x29, sp, #0x90         | X29 = (1152921513193478784 + 144) = 1152921513193478928 (0x10000001FFCD9B10);
            // 0x0167E44C: SUB sp, sp, #0x40          | SP = (1152921513193478784 - 64) = 1152921513193478720 (0x10000001FFCD9A40);
            // 0x0167E450: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167E454: LDRB w8, [x19, #0xae]      | W8 = (bool)static_value_037380AE;       
            // 0x0167E458: MOV x24, x2                | X24 = 1152921513193527040 (0x10000001FFCE5700);//ML01
            // 0x0167E45C: MOV x20, x1                | X20 = trace;//m1                        
            // 0x0167E460: MOV x21, x0                | X21 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167E464: TBNZ w8, #0, #0x167e480    | if (static_value_037380AE == true) goto label_0;
            // 0x0167E468: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0167E46C: LDR x8, [x8, #0xe60]       | X8 = 0x2B8ADF0;                         
            // 0x0167E470: LDR w0, [x8]               | W0 = 0x23A;                             
            // 0x0167E474: BL #0x2782188              | X0 = sub_2782188( ?? 0x23A, ????);      
            // 0x0167E478: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167E47C: STRB w8, [x19, #0xae]      | static_value_037380AE = true;            //  dest_result_addr=57901230
            label_0:
            // 0x0167E480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E484: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167E488: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_1 = this.transform;
            // 0x0167E48C: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x0167E490: CBNZ x22, #0x167e498       | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x0167E494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x0167E498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E49C: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x0167E4A0: BL #0x2693510              | X0 = val_1.get_position();              
            UnityEngine.Vector3 val_2 = val_1.position;
            // 0x0167E4A4: STP s0, s1, [x24]          | endPosition.x = val_2.x;  endPosition.y = val_2.y;  //  dest_result_addr=1152921513193527040 |  dest_result_addr=1152921513193527044
            endPosition.x = val_2.x;
            endPosition.y = val_2.y;
            // 0x0167E4A8: STR s2, [x24, #8]          | endPosition.z = val_2.z;                 //  dest_result_addr=1152921513193527048
            endPosition.z = val_2.z;
            // 0x0167E4AC: ADRP x19, #0x35fe000       | X19 = 56614912 (0x35FE000);             
            // 0x0167E4B0: LDR x19, [x19, #0x810]     | X19 = 1152921504697475072;              
            val_60 = 1152921504697475072;
            // 0x0167E4B4: LDR x22, [x21, #0x88]      | X22 = this.referenceMesh; //P2          
            // 0x0167E4B8: LDR x0, [x19]              | X0 = typeof(UnityEngine.Object);        
            // 0x0167E4BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167E4C0: TBZ w8, #0, #0x167e4d0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0167E4C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167E4C8: CBNZ w8, #0x167e4d0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0167E4CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_3:
            // 0x0167E4D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E4D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E4D8: MOV x1, x22                | X1 = this.referenceMesh;//m1            
            // 0x0167E4DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167E4E0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.referenceMesh);
            bool val_3 = UnityEngine.Object.op_Equality(x:  0, y:  this.referenceMesh);
            // 0x0167E4E4: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x0167E4E8: TBNZ w8, #0, #0x167ef04    | if ((val_3 & 1) == true) goto label_87; 
            if(val_4 == true)
            {
                goto label_87;
            }
            // 0x0167E4EC: LDR x22, [x21, #0x88]      | X22 = this.referenceMesh; //P2          
            // 0x0167E4F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E4F4: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167E4F8: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_5 = this.transform;
            // 0x0167E4FC: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x0167E500: CBNZ x23, #0x167e508       | if (val_5 != null) goto label_5;        
            if(val_5 != null)
            {
                goto label_5;
            }
            // 0x0167E504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_5:
            // 0x0167E508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E50C: MOV x0, x23                | X0 = val_5;//m1                         
            // 0x0167E510: BL #0x2693510              | X0 = val_5.get_position();              
            UnityEngine.Vector3 val_6 = val_5.position;
            // 0x0167E514: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E518: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167E51C: MOV v8.16b, v0.16b         | V8 = val_6.x;//m1                       
            // 0x0167E520: MOV v9.16b, v1.16b         | V9 = val_6.y;//m1                       
            // 0x0167E524: MOV v10.16b, v2.16b        | V10 = val_6.z;//m1                      
            // 0x0167E528: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_7 = this.transform;
            // 0x0167E52C: MOV x23, x0                | X23 = val_7;//m1                        
            // 0x0167E530: CBNZ x23, #0x167e538       | if (val_7 != null) goto label_6;        
            if(val_7 != null)
            {
                goto label_6;
            }
            // 0x0167E534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_6:
            // 0x0167E538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E53C: MOV x0, x23                | X0 = val_7;//m1                         
            // 0x0167E540: BL #0x26937d8              | X0 = val_7.get_rotation();              
            UnityEngine.Quaternion val_8 = val_7.rotation;
            // 0x0167E544: LDR x0, [x19]              | X0 = typeof(UnityEngine.Object);        
            // 0x0167E548: MOV v11.16b, v0.16b        | V11 = val_8.x;//m1                      
            // 0x0167E54C: MOV v12.16b, v1.16b        | V12 = val_8.y;//m1                      
            // 0x0167E550: MOV v14.16b, v2.16b        | V14 = val_8.z;//m1                      
            // 0x0167E554: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167E558: MOV v13.16b, v3.16b        | V13 = val_8.w;//m1                      
            // 0x0167E55C: TBZ w8, #0, #0x167e56c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x0167E560: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167E564: CBNZ w8, #0x167e56c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x0167E568: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_8:
            // 0x0167E56C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0167E570: LDR x8, [x8, #0x390]       | X8 = 1152921509942573888;               
            // 0x0167E574: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E578: MOV x1, x22                | X1 = this.referenceMesh;//m1            
            // 0x0167E57C: MOV v0.16b, v8.16b         | V0 = val_6.x;//m1                       
            // 0x0167E580: LDR x2, [x8]               | X2 = public static UnityEngine.GameObject UnityEngine.Object::Instantiate<UnityEngine.GameObject>(UnityEngine.GameObject original, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation);
            // 0x0167E584: MOV v1.16b, v9.16b         | V1 = val_6.y;//m1                       
            val_61 = val_6.y;
            // 0x0167E588: MOV v2.16b, v10.16b        | V2 = val_6.z;//m1                       
            val_62 = val_6.z;
            // 0x0167E58C: MOV v3.16b, v11.16b        | V3 = val_8.x;//m1                       
            // 0x0167E590: MOV v4.16b, v12.16b        | V4 = val_8.y;//m1                       
            // 0x0167E594: MOV v5.16b, v14.16b        | V5 = val_8.z;//m1                       
            // 0x0167E598: MOV v6.16b, v13.16b        | V6 = val_8.w;//m1                       
            // 0x0167E59C: BL #0x23d60c8              | X0 = UnityEngine.Object.Instantiate<UnityEngine.GameObject>(original:  0, position:  new UnityEngine.Vector3() {x = val_6.x, y = val_61, z = val_62}, rotation:  new UnityEngine.Quaternion() {x = val_8.x, y = val_8.y, z = val_8.z, w = val_8.w});
            UnityEngine.GameObject val_9 = UnityEngine.Object.Instantiate<UnityEngine.GameObject>(original:  0, position:  new UnityEngine.Vector3() {x = val_6.x, y = val_61, z = val_62}, rotation:  new UnityEngine.Quaternion() {x = val_8.x, y = val_8.y, z = val_8.z, w = val_8.w});
            // 0x0167E5A0: MOV x25, x0                | X25 = val_9;//m1                        
            // 0x0167E5A4: CBZ x25, #0x167e5c0        | if (val_9 == null) goto label_9;        
            if(val_9 == null)
            {
                goto label_9;
            }
            // 0x0167E5A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E5AC: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
            // 0x0167E5B0: MOV x0, x25                | X0 = val_9;//m1                         
            // 0x0167E5B4: BL #0x1b77b04              | val_9.set_hideFlags(value:  61);        
            val_9.hideFlags = 61;
            // 0x0167E5B8: MOV x22, x25               | X22 = val_9;//m1                        
            val_63 = val_9;
            // 0x0167E5BC: B #0x167e5dc               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x0167E5C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x0167E5C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E5C8: MOVZ w1, #0x3d             | W1 = 61 (0x3D);//ML01                   
            // 0x0167E5CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E5D0: BL #0x1b77b04              | 0.set_hideFlags(value:  61);            
            0.hideFlags = 61;
            // 0x0167E5D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x0167E5D8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_63 = 0;
            label_10:
            // 0x0167E5DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E5E0: MOV x0, x25                | X0 = val_9;//m1                         
            // 0x0167E5E4: BL #0x1a62c1c              | X0 = val_9.get_transform();             
            UnityEngine.Transform val_10 = val_9.transform;
            // 0x0167E5E8: LDR x2, [x21, #0x98]       | X2 = this.boneRoot; //P2                
            // 0x0167E5EC: MOV x1, x0                 | X1 = val_10;//m1                        
            // 0x0167E5F0: BL #0x167e2c4              | X0 = Pathfinding.AnimationLink.SearchRec(tr:  UnityEngine.Transform val_10 = val_9.transform, name:  val_10);
            UnityEngine.Transform val_11 = Pathfinding.AnimationLink.SearchRec(tr:  val_10, name:  val_10);
            // 0x0167E5F4: MOV x23, x0                | X23 = val_11;//m1                       
            // 0x0167E5F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E5FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E600: MOV x1, x23                | X1 = val_11;//m1                        
            // 0x0167E604: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167E608: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_11);
            bool val_12 = UnityEngine.Object.op_Equality(x:  0, y:  val_11);
            // 0x0167E60C: TBNZ w0, #0, #0x167ef34    | if (val_12 == true) goto label_11;      
            if(val_12 == true)
            {
                goto label_11;
            }
            // 0x0167E610: STR x24, [sp, #0x10]       | stack[1152921513193478736] = endPosition;  //  dest_result_addr=1152921513193478736
            // 0x0167E614: CBNZ x25, #0x167e61c       | if (val_9 != null) goto label_12;       
            if(val_9 != null)
            {
                goto label_12;
            }
            // 0x0167E618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_12:
            // 0x0167E61C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x0167E620: LDR x8, [x8, #0xf28]       | X8 = 1152921509942579008;               
            // 0x0167E624: MOV x0, x25                | X0 = val_9;//m1                         
            // 0x0167E628: LDR x1, [x8]               | X1 = public UnityEngine.Animation UnityEngine.GameObject::GetComponent<UnityEngine.Animation>();
            // 0x0167E62C: BL #0x23d5abc              | X0 = val_9.GetComponent<UnityEngine.Animation>();
            UnityEngine.Animation val_13 = val_9.GetComponent<UnityEngine.Animation>();
            // 0x0167E630: LDR x8, [x19]              | X8 = typeof(UnityEngine.Object);        
            // 0x0167E634: MOV x24, x0                | X24 = val_13;//m1                       
            val_64 = val_13;
            // 0x0167E638: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167E63C: TBZ w9, #0, #0x167e650     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x0167E640: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167E644: CBNZ w9, #0x167e650        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x0167E648: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
            // 0x0167E64C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_14:
            // 0x0167E650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E654: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E658: MOV x1, x24                | X1 = val_13;//m1                        
            // 0x0167E65C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167E660: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_64);
            bool val_14 = UnityEngine.Object.op_Equality(x:  0, y:  val_64);
            // 0x0167E664: TBZ w0, #0, #0x167e688     | if (val_14 == false) goto label_15;     
            if(val_14 == false)
            {
                goto label_15;
            }
            // 0x0167E668: CBNZ x25, #0x167e670       | if (val_9 != null) goto label_16;       
            if(val_9 != null)
            {
                goto label_16;
            }
            // 0x0167E66C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_16:
            // 0x0167E670: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x0167E674: LDR x8, [x8, #0x88]        | X8 = 1152921513193153472;               
            // 0x0167E678: MOV x0, x25                | X0 = val_9;//m1                         
            // 0x0167E67C: LDR x1, [x8]               | X1 = public UnityEngine.Animation UnityEngine.GameObject::AddComponent<UnityEngine.Animation>();
            // 0x0167E680: BL #0x23d5984              | X0 = val_9.AddComponent<UnityEngine.Animation>();
            UnityEngine.Animation val_15 = val_9.AddComponent<UnityEngine.Animation>();
            // 0x0167E684: MOV x24, x0                | X24 = val_15;//m1                       
            val_64 = val_15;
            label_15:
            // 0x0167E688: STR x22, [sp, #8]          | stack[1152921513193478728] = 0x0;        //  dest_result_addr=1152921513193478728
            // 0x0167E68C: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_65 = 0;
            // 0x0167E690: B #0x167e6ac               |  goto label_17;                         
            goto label_17;
            label_28:
            // 0x0167E694: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167E698: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167E69C: MOV x1, x25                | X1 = val_9;//m1                         
            // 0x0167E6A0: MOV x2, x26                | X2 = X26;//m1                           
            // 0x0167E6A4: BL #0x270c8dc              | val_15.AddClip(clip:  val_9, newName:  X26);
            val_64.AddClip(clip:  val_9, newName:  X26);
            // 0x0167E6A8: ADD w19, w19, #1           | W19 = (val_65 + 1) = val_65 (0x00000001);
            val_65 = 1;
            label_17:
            // 0x0167E6AC: LDR x22, [x21, #0x90]      | X22 = this.sequence; //P2               
            // 0x0167E6B0: CBNZ x22, #0x167e6b8       | if (this.sequence != null) goto label_18;
            if(this.sequence != null)
            {
                goto label_18;
            }
            // 0x0167E6B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_18:
            // 0x0167E6B8: LDR w8, [x22, #0x18]       | W8 = this.sequence.Length; //P2         
            // 0x0167E6BC: CMP w19, w8                | STATE = COMPARE(0x1, this.sequence.Length)
            // 0x0167E6C0: B.GE #0x167e75c            | if (val_65 >= this.sequence.Length) goto label_19;
            if(val_65 >= this.sequence.Length)
            {
                goto label_19;
            }
            // 0x0167E6C4: LDR x25, [x21, #0x90]      | X25 = this.sequence; //P2               
            // 0x0167E6C8: CBNZ x25, #0x167e6d0       | if (this.sequence != null) goto label_20;
            if(this.sequence != null)
            {
                goto label_20;
            }
            // 0x0167E6CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_20:
            // 0x0167E6D0: LDR w8, [x25, #0x18]       | W8 = this.sequence.Length; //P2         
            // 0x0167E6D4: SXTW x22, w19              | X22 = 1 (0x00000001);                   
            // 0x0167E6D8: CMP w19, w8                | STATE = COMPARE(0x1, this.sequence.Length)
            // 0x0167E6DC: B.LO #0x167e6ec            | if (val_65 < this.sequence.Length) goto label_21;
            if(val_65 < this.sequence.Length)
            {
                goto label_21;
            }
            // 0x0167E6E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x0167E6E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E6E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_21:
            // 0x0167E6EC: ADD x8, x25, x22, lsl #3   | X8 = this.sequence[0x1]; //PARR1        
            // 0x0167E6F0: LDR x25, [x8, #0x20]       | X25 = this.sequence[0x1][0]             
            LinkClip val_60 = this.sequence[1];
            // 0x0167E6F4: CBNZ x25, #0x167e6fc       | if (this.sequence[0x1][0] != null) goto label_22;
            if(val_60 != null)
            {
                goto label_22;
            }
            // 0x0167E6F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_22:
            // 0x0167E6FC: LDR x25, [x25, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167E700: LDR x26, [x21, #0x90]      | X26 = this.sequence; //P2               
            // 0x0167E704: CBNZ x26, #0x167e70c       | if (this.sequence != null) goto label_23;
            if(this.sequence != null)
            {
                goto label_23;
            }
            // 0x0167E708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_23:
            // 0x0167E70C: LDR w8, [x26, #0x18]       | W8 = this.sequence.Length; //P2         
            // 0x0167E710: CMP w19, w8                | STATE = COMPARE(0x1, this.sequence.Length)
            // 0x0167E714: B.LO #0x167e724            | if (val_65 < this.sequence.Length) goto label_24;
            if(val_65 < this.sequence.Length)
            {
                goto label_24;
            }
            // 0x0167E718: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x0167E71C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E720: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_24:
            // 0x0167E724: ADD x8, x26, x22, lsl #3   | X8 = this.sequence[0x1]; //PARR1        
            // 0x0167E728: LDR x22, [x8, #0x20]       | X22 = this.sequence[0x1][0]             
            LinkClip val_61 = this.sequence[1];
            // 0x0167E72C: CBNZ x22, #0x167e734       | if (this.sequence[0x1][0] != null) goto label_25;
            if(val_61 != null)
            {
                goto label_25;
            }
            // 0x0167E730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_25:
            // 0x0167E734: LDR x26, [x22, #0x10]      | X26 = this.sequence[0x1][0].clip; //P2  
            // 0x0167E738: CBNZ x26, #0x167e740       | if (this.sequence[0x1][0].clip != null) goto label_26;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_26;
            }
            // 0x0167E73C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_26:
            // 0x0167E740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E744: MOV x0, x26                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167E748: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_16 = this.sequence[0x1][0].clip.name;
            // 0x0167E74C: MOV x26, x0                | X26 = val_16;//m1                       
            // 0x0167E750: CBNZ x24, #0x167e694       | if (val_15 != null) goto label_28;      
            if(val_64 != null)
            {
                goto label_28;
            }
            // 0x0167E754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            // 0x0167E758: B #0x167e694               |  goto label_28;                         
            goto label_28;
            label_19:
            // 0x0167E75C: ADRP x26, #0x3673000       | X26 = 57094144 (0x3673000);             
            // 0x0167E760: LDR x26, [x26, #0x488]     | X26 = 1152921504695078912;              
            // 0x0167E764: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x0167E768: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167E76C: TBZ w8, #0, #0x167e77c     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x0167E770: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167E774: CBNZ w8, #0x167e77c        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x0167E778: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_30:
            // 0x0167E77C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E784: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_17 = UnityEngine.Vector3.zero;
            // 0x0167E788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E78C: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167E790: MOV v9.16b, v0.16b         | V9 = val_17.x;//m1                      
            val_66 = val_17.x;
            // 0x0167E794: MOV v8.16b, v1.16b         | V8 = val_17.y;//m1                      
            val_67 = val_17.y;
            // 0x0167E798: MOV v11.16b, v2.16b        | V11 = val_17.z;//m1                     
            val_68 = val_17.z;
            // 0x0167E79C: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_18 = this.transform;
            // 0x0167E7A0: MOV x25, x0                | X25 = val_18;//m1                       
            val_69 = val_18;
            // 0x0167E7A4: CBNZ x25, #0x167e7ac       | if (val_18 != null) goto label_31;      
            if(val_69 != null)
            {
                goto label_31;
            }
            // 0x0167E7A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_31:
            // 0x0167E7AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E7B0: MOV x0, x25                | X0 = val_18;//m1                        
            // 0x0167E7B4: BL #0x2693510              | X0 = val_18.get_position();             
            UnityEngine.Vector3 val_19 = val_69.position;
            // 0x0167E7B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E7BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E7C0: MOV v10.16b, v0.16b        | V10 = val_19.x;//m1                     
            val_70 = val_19.x;
            // 0x0167E7C4: STP s2, s1, [sp, #0x38]    | stack[1152921513193478776] = val_19.z;  stack[1152921513193478780] = val_19.y;  //  dest_result_addr=1152921513193478776 |  dest_result_addr=1152921513193478780
            // 0x0167E7C8: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_20 = UnityEngine.Vector3.zero;
            // 0x0167E7CC: STP s1, s0, [sp, #0x20]    | stack[1152921513193478752] = val_20.y;  stack[1152921513193478756] = val_20.x;  //  dest_result_addr=1152921513193478752 |  dest_result_addr=1152921513193478756
            // 0x0167E7D0: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            // 0x0167E7D4: ADRP x22, #0x361b000       | X22 = 56733696 (0x361B000);             
            // 0x0167E7D8: STR s2, [sp, #0x1c]        | stack[1152921513193478748] = val_20.z;   //  dest_result_addr=1152921513193478748
            // 0x0167E7DC: STR x8, [sp, #0x28]        | stack[1152921513193478760] = 0x0;        //  dest_result_addr=1152921513193478760
            // 0x0167E7E0: LDR x22, [x22, #0x7b0]     | X22 = 1152921510909120752;              
            // 0x0167E7E4: B #0x167e804               |  goto label_32;                         
            goto label_32;
            label_82:
            // 0x0167E7E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E7EC: MOV x0, x25                | X0 = val_18;//m1                        
            // 0x0167E7F0: FMOV s0, wzr               | S0 = 0f;                                
            // 0x0167E7F4: BL #0x270e680              | val_18.set_weight(value:  0f);          
            val_69.weight = 0f;
            // 0x0167E7F8: LDR x8, [sp, #0x28]        | X8 = 0x0;                               
            // 0x0167E7FC: ADD w8, w8, #1             | W8 = (0 + 1) = 1 (0x00000001);          
            // 0x0167E800: STR x8, [sp, #0x28]        | stack[1152921513193478760] = 0x1;        //  dest_result_addr=1152921513193478760
            label_32:
            // 0x0167E804: LDR x19, [x21, #0x90]      | X19 = this.sequence; //P2               
            // 0x0167E808: CBNZ x19, #0x167e810       | if (this.sequence != null) goto label_33;
            if(this.sequence != null)
            {
                goto label_33;
            }
            // 0x0167E80C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_33:
            // 0x0167E810: LDR w8, [x19, #0x18]       | W8 = this.sequence.Length; //P2         
            // 0x0167E814: LDR x9, [sp, #0x28]        | X9 = 0x1;                               
            // 0x0167E818: CMP w9, w8                 | STATE = COMPARE(0x1, this.sequence.Length)
            // 0x0167E81C: B.GE #0x167ee48            | if (1 >= this.sequence.Length) goto label_34;
            if(1 >= this.sequence.Length)
            {
                goto label_34;
            }
            // 0x0167E820: LDR x19, [x21, #0x90]      | X19 = this.sequence; //P2               
            val_60 = this.sequence;
            // 0x0167E824: CBNZ x19, #0x167e82c       | if (this.sequence != null) goto label_35;
            if(val_60 != null)
            {
                goto label_35;
            }
            // 0x0167E828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_35:
            // 0x0167E82C: LDR x9, [sp, #0x28]        | X9 = 0x1;                               
            // 0x0167E830: LDR w8, [x19, #0x18]       | W8 = this.sequence.Length; //P2         
            // 0x0167E834: SXTW x25, w9               | X25 = 1 (0x00000001);                   
            val_69 = 1;
            // 0x0167E838: CMP w9, w8                 | STATE = COMPARE(0x1, this.sequence.Length)
            // 0x0167E83C: B.LO #0x167e84c            | if (1 < this.sequence.Length) goto label_36;
            if(1 < this.sequence.Length)
            {
                goto label_36;
            }
            // 0x0167E840: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x0167E844: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E848: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_36:
            // 0x0167E84C: ADD x8, x19, x25, lsl #3   | X8 = this.sequence[0x1]; //PARR1        
            // 0x0167E850: LDR x27, [x8, #0x20]       | X27 = this.sequence[0x1][0]             
            LinkClip val_62 = val_60[val_69];
            // 0x0167E854: CBZ x27, #0x167eeec        | if (this.sequence[0x1][0] == null) goto label_37;
            if(val_62 == null)
            {
                goto label_37;
            }
            // 0x0167E858: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167E85C: CBNZ x25, #0x167e864       | if (this.sequence[0x1][0].clip != null) goto label_38;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_38;
            }
            // 0x0167E860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_38:
            // 0x0167E864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E868: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167E86C: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_21 = this.sequence[0x1][0].clip.name;
            // 0x0167E870: MOV x25, x0                | X25 = val_21;//m1                       
            // 0x0167E874: CBNZ x24, #0x167e87c       | if (val_15 != null) goto label_39;      
            if(val_64 != null)
            {
                goto label_39;
            }
            // 0x0167E878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_39:
            // 0x0167E87C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E880: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167E884: MOV x1, x25                | X1 = val_21;//m1                        
            // 0x0167E888: BL #0x270c494              | X0 = val_15.get_Item(name:  val_21);    
            UnityEngine.AnimationState val_22 = val_64.Item[val_21];
            // 0x0167E88C: MOV x25, x0                | X25 = val_22;//m1                       
            // 0x0167E890: CBNZ x25, #0x167e898       | if (val_22 != null) goto label_40;      
            if(val_22 != null)
            {
                goto label_40;
            }
            // 0x0167E894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_40:
            // 0x0167E898: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E89C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x0167E8A0: MOV x0, x25                | X0 = val_22;//m1                        
            // 0x0167E8A4: BL #0x270e5a0              | val_22.set_enabled(value:  true);       
            val_22.enabled = true;
            // 0x0167E8A8: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167E8AC: CBNZ x25, #0x167e8b4       | if (this.sequence[0x1][0].clip != null) goto label_41;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_41;
            }
            // 0x0167E8B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_41:
            // 0x0167E8B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E8B8: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167E8BC: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_23 = this.sequence[0x1][0].clip.name;
            // 0x0167E8C0: MOV x25, x0                | X25 = val_23;//m1                       
            // 0x0167E8C4: CBNZ x24, #0x167e8cc       | if (val_15 != null) goto label_42;      
            if(val_64 != null)
            {
                goto label_42;
            }
            // 0x0167E8C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_42:
            // 0x0167E8CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E8D0: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167E8D4: MOV x1, x25                | X1 = val_23;//m1                        
            // 0x0167E8D8: BL #0x270c494              | X0 = val_15.get_Item(name:  val_23);    
            UnityEngine.AnimationState val_24 = val_64.Item[val_23];
            // 0x0167E8DC: MOV x25, x0                | X25 = val_24;//m1                       
            // 0x0167E8E0: CBNZ x25, #0x167e8e8       | if (val_24 != null) goto label_43;      
            if(val_24 != null)
            {
                goto label_43;
            }
            // 0x0167E8E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_43:
            // 0x0167E8E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E8EC: MOV x0, x25                | X0 = val_24;//m1                        
            // 0x0167E8F0: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x0167E8F4: BL #0x270e680              | val_24.set_weight(value:  1f);          
            val_24.weight = 1f;
            // 0x0167E8F8: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_72 = 0;
            // 0x0167E8FC: B #0x167e940               |  goto label_44;                         
            goto label_44;
            label_78:
            // 0x0167E900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E904: MOV x0, x25                | X0 = val_24;//m1                        
            // 0x0167E908: BL #0x2693510              | X0 = val_24.get_position();             
            UnityEngine.Vector3 val_25 = val_24.position;
            // 0x0167E90C: MOV v3.16b, v0.16b         | V3 = val_25.x;//m1                      
            // 0x0167E910: MOV v4.16b, v1.16b         | V4 = val_25.y;//m1                      
            // 0x0167E914: MOV v5.16b, v2.16b         | V5 = val_25.z;//m1                      
            // 0x0167E918: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167E91C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E920: MOV v0.16b, v11.16b        | V0 = val_17.z;//m1                      
            // 0x0167E924: MOV v1.16b, v12.16b        | V1 = val_8.y;//m1                       
            val_61 = val_8.y;
            // 0x0167E928: MOV v2.16b, v13.16b        | V2 = val_8.w;//m1                       
            val_62 = val_8.w;
            // 0x0167E92C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_68, y = val_61, z = val_62}, b:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z});
            UnityEngine.Vector3 val_26 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_68, y = val_61, z = val_62}, b:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z});
            // 0x0167E930: MOV v9.16b, v0.16b         | V9 = val_26.x;//m1                      
            val_66 = val_26.x;
            // 0x0167E934: MOV v8.16b, v1.16b         | V8 = val_26.y;//m1                      
            val_73 = val_26.y;
            // 0x0167E938: MOV v11.16b, v2.16b        | V11 = val_26.z;//m1                     
            val_68 = val_26.z;
            // 0x0167E93C: ADD w19, w19, #1           | W19 = (val_72 + 1) = val_72 (0x00000001);
            val_72 = 1;
            label_44:
            // 0x0167E940: LDR w28, [x27, #0x24]      | W28 = this.sequence[0x1][0].loopCount; //P2 
            // 0x0167E944: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167E948: CBNZ x25, #0x167e950       | if (this.sequence[0x1][0].clip != null) goto label_45;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_45;
            }
            // 0x0167E94C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_45:
            // 0x0167E950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E954: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167E958: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_27 = this.sequence[0x1][0].clip.name;
            // 0x0167E95C: MOV x25, x0                | X25 = val_27;//m1                       
            // 0x0167E960: CBNZ x24, #0x167e968       | if (val_15 != null) goto label_46;      
            if(val_64 != null)
            {
                goto label_46;
            }
            // 0x0167E964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_46:
            // 0x0167E968: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167E96C: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167E970: MOV x1, x25                | X1 = val_27;//m1                        
            // 0x0167E974: BL #0x270c494              | X0 = val_15.get_Item(name:  val_27);    
            UnityEngine.AnimationState val_28 = val_64.Item[val_27];
            // 0x0167E978: MOV x25, x0                | X25 = val_28;//m1                       
            // 0x0167E97C: CBNZ x25, #0x167e984       | if (val_28 != null) goto label_47;      
            if(val_28 != null)
            {
                goto label_47;
            }
            // 0x0167E980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_47:
            // 0x0167E984: CMP w19, w28               | STATE = COMPARE(0x1, this.sequence[0x1][0].loopCount)
            // 0x0167E988: B.GE #0x167edf4            | if (val_72 >= this.sequence[0x1][0].loopCount) goto label_48;
            if(val_72 >= this.sequence[0x1][0].loopCount)
            {
                goto label_48;
            }
            // 0x0167E98C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E990: MOV x0, x25                | X0 = val_28;//m1                        
            // 0x0167E994: FMOV s0, wzr               | S0 = 0f;                                
            // 0x0167E998: BL #0x270e920              | val_28.set_normalizedTime(value:  0f);  
            val_28.normalizedTime = 0f;
            // 0x0167E99C: CBNZ x24, #0x167e9a4       | if (val_15 != null) goto label_49;      
            if(val_64 != null)
            {
                goto label_49;
            }
            // 0x0167E9A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_49:
            // 0x0167E9A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E9A8: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167E9AC: STP s11, s9, [sp, #0x30]   | stack[1152921513193478768] = val_26.z;  stack[1152921513193478772] = val_26.x;  //  dest_result_addr=1152921513193478768 |  dest_result_addr=1152921513193478772
            // 0x0167E9B0: BL #0x270c344              | val_15.Sample();                        
            val_64.Sample();
            // 0x0167E9B4: CBNZ x23, #0x167e9bc       | if (val_11 != null) goto label_50;      
            if(val_11 != null)
            {
                goto label_50;
            }
            // 0x0167E9B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_50:
            // 0x0167E9BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E9C0: MOV x0, x23                | X0 = val_11;//m1                        
            // 0x0167E9C4: MOV v9.16b, v8.16b         | V9 = val_26.y;//m1                      
            // 0x0167E9C8: BL #0x2693510              | X0 = val_11.get_position();             
            UnityEngine.Vector3 val_29 = val_11.position;
            // 0x0167E9CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E9D0: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167E9D4: MOV v15.16b, v0.16b        | V15 = val_29.x;//m1                     
            // 0x0167E9D8: MOV v14.16b, v1.16b        | V14 = val_29.y;//m1                     
            // 0x0167E9DC: MOV v11.16b, v2.16b        | V11 = val_29.z;//m1                     
            // 0x0167E9E0: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_30 = this.transform;
            // 0x0167E9E4: MOV x25, x0                | X25 = val_30;//m1                       
            // 0x0167E9E8: CBNZ x25, #0x167e9f0       | if (val_30 != null) goto label_51;      
            if(val_30 != null)
            {
                goto label_51;
            }
            // 0x0167E9EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
            label_51:
            // 0x0167E9F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167E9F4: MOV x0, x25                | X0 = val_30;//m1                        
            // 0x0167E9F8: BL #0x2693510              | X0 = val_30.get_position();             
            UnityEngine.Vector3 val_31 = val_30.position;
            // 0x0167E9FC: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x0167EA00: MOV v12.16b, v0.16b        | V12 = val_31.x;//m1                     
            // 0x0167EA04: MOV v13.16b, v1.16b        | V13 = val_31.y;//m1                     
            // 0x0167EA08: MOV v8.16b, v2.16b         | V8 = val_31.z;//m1                      
            // 0x0167EA0C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167EA10: TBZ w8, #0, #0x167ea20     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_53;
            // 0x0167EA14: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167EA18: CBNZ w8, #0x167ea20        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
            // 0x0167EA1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_53:
            // 0x0167EA20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EA28: MOV v0.16b, v15.16b        | V0 = val_29.x;//m1                      
            // 0x0167EA2C: MOV v1.16b, v14.16b        | V1 = val_29.y;//m1                      
            val_74 = val_29.y;
            // 0x0167EA30: MOV v2.16b, v11.16b        | V2 = val_29.z;//m1                      
            val_75 = val_29.z;
            // 0x0167EA34: MOV v3.16b, v12.16b        | V3 = val_31.x;//m1                      
            // 0x0167EA38: MOV v4.16b, v13.16b        | V4 = val_31.y;//m1                      
            // 0x0167EA3C: MOV v5.16b, v8.16b         | V5 = val_31.z;//m1                      
            // 0x0167EA40: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_29.x, y = val_74, z = val_75}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z});
            UnityEngine.Vector3 val_32 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_29.x, y = val_74, z = val_75}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z});
            // 0x0167EA44: LDR x8, [sp, #0x28]        | X8 = 0x1;                               
            // 0x0167EA48: MOV v15.16b, v0.16b        | V15 = val_32.x;//m1                     
            // 0x0167EA4C: MOV v14.16b, v1.16b        | V14 = val_32.y;//m1                     
            // 0x0167EA50: MOV v11.16b, v2.16b        | V11 = val_32.z;//m1                     
            // 0x0167EA54: CMP w8, #1                 | STATE = COMPARE(0x1, 0x1)               
            // 0x0167EA58: B.LT #0x167eac0            | if (1 < 0x1) goto label_54;             
            if(1 < 1)
            {
                goto label_54;
            }
            // 0x0167EA5C: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x0167EA60: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167EA64: TBZ w8, #0, #0x167ea74     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_56;
            // 0x0167EA68: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167EA6C: CBNZ w8, #0x167ea74        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_56;
            // 0x0167EA70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_56:
            // 0x0167EA74: LDP s2, s0, [sp, #0x30]    | S2 = val_26.z; S0 = val_26.x;            //  | 
            // 0x0167EA78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EA7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EA80: MOV v1.16b, v9.16b         | V1 = val_26.y;//m1                      
            // 0x0167EA84: MOV v3.16b, v15.16b        | V3 = val_32.x;//m1                      
            // 0x0167EA88: MOV v4.16b, v14.16b        | V4 = val_32.y;//m1                      
            // 0x0167EA8C: MOV v5.16b, v11.16b        | V5 = val_32.z;//m1                      
            // 0x0167EA90: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_66, y = val_73, z = val_68}, b:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z});
            UnityEngine.Vector3 val_33 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_66, y = val_73, z = val_68}, b:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z});
            // 0x0167EA94: MOV v4.16b, v1.16b         | V4 = val_33.y;//m1                      
            // 0x0167EA98: MOV v5.16b, v2.16b         | V5 = val_33.z;//m1                      
            // 0x0167EA9C: LDP s2, s1, [sp, #0x38]    | S2 = val_19.z; S1 = val_19.y;            //  | 
            val_75 = val_19.z;
            val_74 = val_19.y;
            // 0x0167EAA0: MOV v3.16b, v0.16b         | V3 = val_33.x;//m1                      
            // 0x0167EAA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EAA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EAAC: MOV v0.16b, v10.16b        | V0 = val_19.x;//m1                      
            // 0x0167EAB0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_74, z = val_75}, b:  new UnityEngine.Vector3() {x = val_33.x, y = val_33.y, z = val_33.z});
            UnityEngine.Vector3 val_34 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_74, z = val_75}, b:  new UnityEngine.Vector3() {x = val_33.x, y = val_33.y, z = val_33.z});
            // 0x0167EAB4: MOV v10.16b, v0.16b        | V10 = val_34.x;//m1                     
            val_77 = val_34.x;
            // 0x0167EAB8: STP s2, s1, [sp, #0x38]    | stack[1152921513193478776] = val_34.z;  stack[1152921513193478780] = val_34.y;  //  dest_result_addr=1152921513193478776 |  dest_result_addr=1152921513193478780
            // 0x0167EABC: B #0x167eac8               |  goto label_57;                         
            goto label_57;
            label_54:
            // 0x0167EAC0: STP s14, s15, [sp, #0x20]  | stack[1152921513193478752] = val_32.y;  stack[1152921513193478756] = val_32.x;  //  dest_result_addr=1152921513193478752 |  dest_result_addr=1152921513193478756
            // 0x0167EAC4: STR s11, [sp, #0x1c]       | stack[1152921513193478748] = val_32.z;   //  dest_result_addr=1152921513193478748
            label_57:
            // 0x0167EAC8: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            var val_63 = 0;
            label_68:
            // 0x0167EACC: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167EAD0: CBNZ x25, #0x167ead8       | if (this.sequence[0x1][0].clip != null) goto label_58;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_58;
            }
            // 0x0167EAD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_58:
            // 0x0167EAD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EADC: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167EAE0: SCVTF s8, w28              | S8 = 0;                                 
            // 0x0167EAE4: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_35 = this.sequence[0x1][0].clip.name;
            // 0x0167EAE8: MOV x25, x0                | X25 = val_35;//m1                       
            // 0x0167EAEC: CBNZ x24, #0x167eaf4       | if (val_15 != null) goto label_59;      
            if(val_64 != null)
            {
                goto label_59;
            }
            // 0x0167EAF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_59:
            // 0x0167EAF4: FMOV s0, #20.00000000      | S0 = 20;                                
            // 0x0167EAF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167EAFC: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167EB00: MOV x1, x25                | X1 = val_35;//m1                        
            // 0x0167EB04: FDIV s11, s8, s0           | S11 = (0f / 20f);                       
            float val_36 = 0f / 20f;
            // 0x0167EB08: BL #0x270c494              | X0 = val_15.get_Item(name:  val_35);    
            UnityEngine.AnimationState val_37 = val_64.Item[val_35];
            // 0x0167EB0C: MOV x25, x0                | X25 = val_37;//m1                       
            // 0x0167EB10: CBNZ x25, #0x167eb18       | if (val_37 != null) goto label_60;      
            if(val_37 != null)
            {
                goto label_60;
            }
            // 0x0167EB14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_60:
            // 0x0167EB18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EB1C: MOV x0, x25                | X0 = val_37;//m1                        
            // 0x0167EB20: MOV v0.16b, v11.16b        | V0 = (0f / 20f);//m1                    
            // 0x0167EB24: BL #0x270e920              | val_37.set_normalizedTime(value:  val_36);
            val_37.normalizedTime = val_36;
            // 0x0167EB28: CBNZ x24, #0x167eb30       | if (val_15 != null) goto label_61;      
            if(val_64 != null)
            {
                goto label_61;
            }
            // 0x0167EB2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_61:
            // 0x0167EB30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EB34: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167EB38: BL #0x270c344              | val_15.Sample();                        
            val_64.Sample();
            // 0x0167EB3C: CBNZ x23, #0x167eb44       | if (val_11 != null) goto label_62;      
            if(val_11 != null)
            {
                goto label_62;
            }
            // 0x0167EB40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_62:
            // 0x0167EB44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EB48: MOV x0, x23                | X0 = val_11;//m1                        
            // 0x0167EB4C: BL #0x2693510              | X0 = val_11.get_position();             
            UnityEngine.Vector3 val_38 = val_11.position;
            // 0x0167EB50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EB54: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167EB58: MOV v12.16b, v0.16b        | V12 = val_38.x;//m1                     
            // 0x0167EB5C: MOV v13.16b, v1.16b        | V13 = val_38.y;//m1                     
            // 0x0167EB60: MOV v14.16b, v2.16b        | V14 = val_38.z;//m1                     
            // 0x0167EB64: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_39 = this.transform;
            // 0x0167EB68: MOV x25, x0                | X25 = val_39;//m1                       
            // 0x0167EB6C: CBNZ x25, #0x167eb74       | if (val_39 != null) goto label_63;      
            if(val_39 != null)
            {
                goto label_63;
            }
            // 0x0167EB70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_63:
            // 0x0167EB74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EB78: MOV x0, x25                | X0 = val_39;//m1                        
            // 0x0167EB7C: BL #0x2693510              | X0 = val_39.get_position();             
            UnityEngine.Vector3 val_40 = val_39.position;
            // 0x0167EB80: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x0167EB84: MOV v15.16b, v0.16b        | V15 = val_40.x;//m1                     
            // 0x0167EB88: MOV v8.16b, v1.16b         | V8 = val_40.y;//m1                      
            // 0x0167EB8C: MOV v9.16b, v2.16b         | V9 = val_40.z;//m1                      
            // 0x0167EB90: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167EB94: TBZ w8, #0, #0x167eba4     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_65;
            // 0x0167EB98: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167EB9C: CBNZ w8, #0x167eba4        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
            // 0x0167EBA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_65:
            // 0x0167EBA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EBA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EBAC: MOV v0.16b, v12.16b        | V0 = val_38.x;//m1                      
            // 0x0167EBB0: MOV v1.16b, v13.16b        | V1 = val_38.y;//m1                      
            // 0x0167EBB4: MOV v2.16b, v14.16b        | V2 = val_38.z;//m1                      
            // 0x0167EBB8: MOV v3.16b, v15.16b        | V3 = val_40.x;//m1                      
            // 0x0167EBBC: MOV v4.16b, v8.16b         | V4 = val_40.y;//m1                      
            // 0x0167EBC0: MOV v5.16b, v9.16b         | V5 = val_40.z;//m1                      
            // 0x0167EBC4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, b:  new UnityEngine.Vector3() {x = val_40.x, y = val_40.y, z = val_40.z});
            UnityEngine.Vector3 val_41 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, b:  new UnityEngine.Vector3() {x = val_40.x, y = val_40.y, z = val_40.z});
            // 0x0167EBC8: MOV v4.16b, v1.16b         | V4 = val_41.y;//m1                      
            // 0x0167EBCC: MOV v5.16b, v2.16b         | V5 = val_41.z;//m1                      
            // 0x0167EBD0: LDP s2, s1, [sp, #0x38]    | S2 = val_34.z; S1 = val_34.y;            //  | 
            // 0x0167EBD4: MOV v3.16b, v0.16b         | V3 = val_41.x;//m1                      
            // 0x0167EBD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EBDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EBE0: MOV v0.16b, v10.16b        | V0 = val_19.x;//m1                      
            // 0x0167EBE4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_34.y, z = val_34.z}, b:  new UnityEngine.Vector3() {x = val_41.x, y = val_41.y, z = val_41.z});
            UnityEngine.Vector3 val_42 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_34.y, z = val_34.z}, b:  new UnityEngine.Vector3() {x = val_41.x, y = val_41.y, z = val_41.z});
            // 0x0167EBE8: MOV v12.16b, v0.16b        | V12 = val_42.x;//m1                     
            // 0x0167EBEC: MOV v13.16b, v1.16b        | V13 = val_42.y;//m1                     
            // 0x0167EBF0: LDP s0, s1, [x27, #0x18]   | S0 = this.sequence[0x1][0].velocity; //P2   //  | 
            // 0x0167EBF4: LDR s3, [x27, #0x20]       | 
            // 0x0167EBF8: MOV v14.16b, v2.16b        | V14 = val_42.z;//m1                     
            // 0x0167EBFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EC00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EC04: MOV v2.16b, v3.16b         | V2 = val_41.x;//m1                      
            // 0x0167EC08: MOV v3.16b, v11.16b        | V3 = (0f / 20f);//m1                    
            // 0x0167EC0C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.sequence[0x1][0].velocity, y = val_42.y, z = val_41.x}, d:  val_36);
            UnityEngine.Vector3 val_43 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.sequence[0x1][0].velocity, y = val_42.y, z = val_41.x}, d:  val_36);
            // 0x0167EC10: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167EC14: MOV v8.16b, v0.16b         | V8 = val_43.x;//m1                      
            // 0x0167EC18: MOV v11.16b, v1.16b        | V11 = val_43.y;//m1                     
            // 0x0167EC1C: MOV v9.16b, v2.16b         | V9 = val_43.z;//m1                      
            // 0x0167EC20: CBNZ x25, #0x167ec28       | if (this.sequence[0x1][0].clip != null) goto label_66;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_66;
            }
            // 0x0167EC24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_66:
            // 0x0167EC28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EC2C: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167EC30: BL #0x270d2ac              | X0 = this.sequence[0x1][0].clip.get_length();
            float val_44 = this.sequence[0x1][0].clip.length;
            // 0x0167EC34: MOV v3.16b, v0.16b         | V3 = val_44;//m1                        
            // 0x0167EC38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EC3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EC40: MOV v0.16b, v8.16b         | V0 = val_43.x;//m1                      
            // 0x0167EC44: MOV v1.16b, v11.16b        | V1 = val_43.y;//m1                      
            // 0x0167EC48: MOV v2.16b, v9.16b         | V2 = val_43.z;//m1                      
            // 0x0167EC4C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_43.x, y = val_43.y, z = val_43.z}, d:  val_44);
            UnityEngine.Vector3 val_45 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_43.x, y = val_43.y, z = val_43.z}, d:  val_44);
            // 0x0167EC50: MOV v3.16b, v0.16b         | V3 = val_45.x;//m1                      
            // 0x0167EC54: MOV v4.16b, v1.16b         | V4 = val_45.y;//m1                      
            // 0x0167EC58: MOV v5.16b, v2.16b         | V5 = val_45.z;//m1                      
            // 0x0167EC5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EC60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EC64: MOV v0.16b, v12.16b        | V0 = val_42.x;//m1                      
            // 0x0167EC68: MOV v1.16b, v13.16b        | V1 = val_42.y;//m1                      
            // 0x0167EC6C: MOV v2.16b, v14.16b        | V2 = val_42.z;//m1                      
            // 0x0167EC70: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_42.x, y = val_42.y, z = val_42.z}, b:  new UnityEngine.Vector3() {x = val_45.x, y = val_45.y, z = val_45.z});
            UnityEngine.Vector3 val_46 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_42.x, y = val_42.y, z = val_42.z}, b:  new UnityEngine.Vector3() {x = val_45.x, y = val_45.y, z = val_45.z});
            // 0x0167EC74: MOV v8.16b, v0.16b         | V8 = val_46.x;//m1                      
            // 0x0167EC78: MOV v9.16b, v1.16b         | V9 = val_46.y;//m1                      
            // 0x0167EC7C: MOV v11.16b, v2.16b        | V11 = val_46.z;//m1                     
            // 0x0167EC80: CBNZ x20, #0x167ec88       | if (trace != null) goto label_67;       
            if(trace != null)
            {
                goto label_67;
            }
            // 0x0167EC84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_67:
            // 0x0167EC88: LDR x1, [x22]              | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
            // 0x0167EC8C: MOV x0, x20                | X0 = trace;//m1                         
            // 0x0167EC90: MOV v0.16b, v8.16b         | V0 = val_46.x;//m1                      
            // 0x0167EC94: MOV v1.16b, v9.16b         | V1 = val_46.y;//m1                      
            // 0x0167EC98: MOV v2.16b, v11.16b        | V2 = val_46.z;//m1                      
            // 0x0167EC9C: BL #0x263fe28              | trace.Add(item:  new UnityEngine.Vector3() {x = val_46.x, y = val_46.y, z = val_46.z});
            trace.Add(item:  new UnityEngine.Vector3() {x = val_46.x, y = val_46.y, z = val_46.z});
            // 0x0167ECA0: ADD w28, w28, #1           | W28 = (0 + 1);                          
            val_63 = val_63 + 1;
            // 0x0167ECA4: CMP w28, #0x15             | STATE = COMPARE((0 + 1), 0x15)          
            // 0x0167ECA8: B.NE #0x167eacc            | if (0 != 0x15) goto label_68;           
            if(val_63 != 21)
            {
                goto label_68;
            }
            // 0x0167ECAC: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x0167ECB0: LDP s11, s9, [x27, #0x18]  | S11 = this.sequence[0x1][0].velocity; //P2   //  | 
            // 0x0167ECB4: LDR s8, [x27, #0x20]       | 
            // 0x0167ECB8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167ECBC: TBZ w8, #0, #0x167eccc     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_70;
            // 0x0167ECC0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167ECC4: CBNZ w8, #0x167eccc        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_70;
            // 0x0167ECC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_70:
            // 0x0167ECCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167ECD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167ECD4: MOV v0.16b, v11.16b        | V0 = this.sequence[0x1][0].velocity;//m1
            // 0x0167ECD8: MOV v1.16b, v9.16b         | V1 = val_46.y;//m1                      
            // 0x0167ECDC: MOV v2.16b, v8.16b         | V2 = val_46.x;//m1                      
            // 0x0167ECE0: FMOV s3, #1.00000000       | S3 = 1;                                 
            // 0x0167ECE4: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.sequence[0x1][0].velocity, y = val_46.y, z = val_46.x}, d:  1f);
            UnityEngine.Vector3 val_47 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = this.sequence[0x1][0].velocity, y = val_46.y, z = val_46.x}, d:  1f);
            // 0x0167ECE8: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167ECEC: MOV v8.16b, v0.16b         | V8 = val_47.x;//m1                      
            // 0x0167ECF0: MOV v11.16b, v1.16b        | V11 = val_47.y;//m1                     
            // 0x0167ECF4: MOV v9.16b, v2.16b         | V9 = val_47.z;//m1                      
            // 0x0167ECF8: CBNZ x25, #0x167ed00       | if (this.sequence[0x1][0].clip != null) goto label_71;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_71;
            }
            // 0x0167ECFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_71:
            // 0x0167ED00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167ED04: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167ED08: BL #0x270d2ac              | X0 = this.sequence[0x1][0].clip.get_length();
            float val_48 = this.sequence[0x1][0].clip.length;
            // 0x0167ED0C: MOV v3.16b, v0.16b         | V3 = val_48;//m1                        
            // 0x0167ED10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167ED14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167ED18: MOV v0.16b, v8.16b         | V0 = val_47.x;//m1                      
            // 0x0167ED1C: MOV v1.16b, v11.16b        | V1 = val_47.y;//m1                      
            // 0x0167ED20: MOV v2.16b, v9.16b         | V2 = val_47.z;//m1                      
            // 0x0167ED24: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_47.x, y = val_47.y, z = val_47.z}, d:  val_48);
            UnityEngine.Vector3 val_49 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_47.x, y = val_47.y, z = val_47.z}, d:  val_48);
            // 0x0167ED28: MOV v4.16b, v1.16b         | V4 = val_49.y;//m1                      
            // 0x0167ED2C: MOV v5.16b, v2.16b         | V5 = val_49.z;//m1                      
            // 0x0167ED30: LDP s2, s1, [sp, #0x38]    | S2 = val_34.z; S1 = val_34.y;            //  | 
            // 0x0167ED34: MOV v3.16b, v0.16b         | V3 = val_49.x;//m1                      
            // 0x0167ED38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167ED3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167ED40: MOV v0.16b, v10.16b        | V0 = val_19.x;//m1                      
            // 0x0167ED44: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_34.y, z = val_34.z}, b:  new UnityEngine.Vector3() {x = val_49.x, y = val_49.y, z = val_49.z});
            UnityEngine.Vector3 val_50 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_34.y, z = val_34.z}, b:  new UnityEngine.Vector3() {x = val_49.x, y = val_49.y, z = val_49.z});
            // 0x0167ED48: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167ED4C: MOV v10.16b, v0.16b        | V10 = val_50.x;//m1                     
            // 0x0167ED50: STR s1, [sp, #0x3c]        | stack[1152921513193478780] = val_50.y;   //  dest_result_addr=1152921513193478780
            // 0x0167ED54: STR s2, [sp, #0x38]        | stack[1152921513193478776] = val_50.z;   //  dest_result_addr=1152921513193478776
            // 0x0167ED58: CBNZ x25, #0x167ed60       | if (this.sequence[0x1][0].clip != null) goto label_72;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_72;
            }
            // 0x0167ED5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_72:
            // 0x0167ED60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167ED64: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167ED68: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_51 = this.sequence[0x1][0].clip.name;
            // 0x0167ED6C: MOV x25, x0                | X25 = val_51;//m1                       
            // 0x0167ED70: CBNZ x24, #0x167ed78       | if (val_15 != null) goto label_73;      
            if(val_64 != null)
            {
                goto label_73;
            }
            // 0x0167ED74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            label_73:
            // 0x0167ED78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167ED7C: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167ED80: MOV x1, x25                | X1 = val_51;//m1                        
            // 0x0167ED84: BL #0x270c494              | X0 = val_15.get_Item(name:  val_51);    
            UnityEngine.AnimationState val_52 = val_64.Item[val_51];
            // 0x0167ED88: MOV x25, x0                | X25 = val_52;//m1                       
            // 0x0167ED8C: CBNZ x25, #0x167ed94       | if (val_52 != null) goto label_74;      
            if(val_52 != null)
            {
                goto label_74;
            }
            // 0x0167ED90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
            label_74:
            // 0x0167ED94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167ED98: MOV x0, x25                | X0 = val_52;//m1                        
            // 0x0167ED9C: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x0167EDA0: BL #0x270e920              | val_52.set_normalizedTime(value:  1f);  
            val_52.normalizedTime = 1f;
            // 0x0167EDA4: CBNZ x24, #0x167edac       | if (val_15 != null) goto label_75;      
            if(val_64 != null)
            {
                goto label_75;
            }
            // 0x0167EDA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
            label_75:
            // 0x0167EDAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EDB0: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167EDB4: BL #0x270c344              | val_15.Sample();                        
            val_64.Sample();
            // 0x0167EDB8: CBNZ x23, #0x167edc0       | if (val_11 != null) goto label_76;      
            if(val_11 != null)
            {
                goto label_76;
            }
            // 0x0167EDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_76:
            // 0x0167EDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EDC4: MOV x0, x23                | X0 = val_11;//m1                        
            // 0x0167EDC8: BL #0x2693510              | X0 = val_11.get_position();             
            UnityEngine.Vector3 val_53 = val_11.position;
            // 0x0167EDCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EDD0: MOV x0, x21                | X0 = 1152921513193490944 (0x10000001FFCDCA00);//ML01
            // 0x0167EDD4: MOV v11.16b, v0.16b        | V11 = val_53.x;//m1                     
            // 0x0167EDD8: MOV v12.16b, v1.16b        | V12 = val_53.y;//m1                     
            // 0x0167EDDC: MOV v13.16b, v2.16b        | V13 = val_53.z;//m1                     
            // 0x0167EDE0: BL #0x20d5094              | X0 = this.get_transform();              
            UnityEngine.Transform val_54 = this.transform;
            // 0x0167EDE4: MOV x25, x0                | X25 = val_54;//m1                       
            // 0x0167EDE8: CBNZ x25, #0x167e900       | if (val_54 != null) goto label_78;      
            if(val_54 != null)
            {
                goto label_78;
            }
            // 0x0167EDEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
            // 0x0167EDF0: B #0x167e900               |  goto label_78;                         
            goto label_78;
            label_48:
            // 0x0167EDF4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x0167EDF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167EDFC: MOV x0, x25                | X0 = val_28;//m1                        
            // 0x0167EE00: BL #0x270e5a0              | val_28.set_enabled(value:  false);      
            val_28.enabled = false;
            // 0x0167EE04: LDR x25, [x27, #0x10]      | X25 = this.sequence[0x1][0].clip; //P2  
            // 0x0167EE08: CBNZ x25, #0x167ee10       | if (this.sequence[0x1][0].clip != null) goto label_79;
            if(this.sequence[0x1][0].clip != null)
            {
                goto label_79;
            }
            // 0x0167EE0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_79:
            // 0x0167EE10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EE14: MOV x0, x25                | X0 = this.sequence[0x1][0].clip;//m1    
            // 0x0167EE18: BL #0x1b759fc              | X0 = this.sequence[0x1][0].clip.get_name();
            string val_55 = this.sequence[0x1][0].clip.name;
            // 0x0167EE1C: MOV x25, x0                | X25 = val_55;//m1                       
            // 0x0167EE20: CBNZ x24, #0x167ee28       | if (val_15 != null) goto label_80;      
            if(val_64 != null)
            {
                goto label_80;
            }
            // 0x0167EE24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
            label_80:
            // 0x0167EE28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167EE2C: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x0167EE30: MOV x1, x25                | X1 = val_55;//m1                        
            // 0x0167EE34: BL #0x270c494              | X0 = val_15.get_Item(name:  val_55);    
            UnityEngine.AnimationState val_56 = val_64.Item[val_55];
            // 0x0167EE38: MOV x25, x0                | X25 = val_56;//m1                       
            // 0x0167EE3C: CBNZ x25, #0x167e7e8       | if (val_56 != null) goto label_82;      
            if(val_56 != null)
            {
                goto label_82;
            }
            // 0x0167EE40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
            // 0x0167EE44: B #0x167e7e8               |  goto label_82;                         
            goto label_82;
            label_34:
            // 0x0167EE48: LDR x0, [x26]              | X0 = typeof(UnityEngine.Vector3);       
            // 0x0167EE4C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167EE50: TBZ w8, #0, #0x167ee60     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_84;
            // 0x0167EE54: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167EE58: CBNZ w8, #0x167ee60        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_84;
            // 0x0167EE5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_84:
            // 0x0167EE60: LDP s4, s3, [sp, #0x20]    | S4 = val_32.y; S3 = val_32.x;            //  | 
            // 0x0167EE64: LDR s5, [sp, #0x1c]        | S5 = val_32.z;                          
            // 0x0167EE68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EE6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EE70: MOV v0.16b, v9.16b         | V0 = val_17.x;//m1                      
            // 0x0167EE74: MOV v1.16b, v8.16b         | V1 = val_17.y;//m1                      
            // 0x0167EE78: MOV v2.16b, v11.16b        | V2 = val_17.z;//m1                      
            // 0x0167EE7C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_68}, b:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z});
            UnityEngine.Vector3 val_57 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_68}, b:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z});
            // 0x0167EE80: MOV v4.16b, v1.16b         | V4 = val_57.y;//m1                      
            // 0x0167EE84: MOV v5.16b, v2.16b         | V5 = val_57.z;//m1                      
            // 0x0167EE88: LDP s2, s1, [sp, #0x38]    | S2 = val_50.z; S1 = val_50.y;            //  | 
            // 0x0167EE8C: MOV v3.16b, v0.16b         | V3 = val_57.x;//m1                      
            // 0x0167EE90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EE94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EE98: MOV v0.16b, v10.16b        | V0 = val_19.x;//m1                      
            // 0x0167EE9C: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_50.y, z = val_50.z}, b:  new UnityEngine.Vector3() {x = val_57.x, y = val_57.y, z = val_57.z});
            UnityEngine.Vector3 val_58 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_70, y = val_50.y, z = val_50.z}, b:  new UnityEngine.Vector3() {x = val_57.x, y = val_57.y, z = val_57.z});
            // 0x0167EEA0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0167EEA4: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x0167EEA8: MOV v8.16b, v0.16b         | V8 = val_58.x;//m1                      
            val_78 = val_58.x;
            // 0x0167EEAC: MOV v9.16b, v1.16b         | V9 = val_58.y;//m1                      
            // 0x0167EEB0: MOV v10.16b, v2.16b        | V10 = val_58.z;//m1                     
            val_79 = val_58.z;
            // 0x0167EEB4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
            // 0x0167EEB8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167EEBC: LDP x20, x19, [sp, #8]     | X20 = 0x0; X19 = endPosition;            //  | 
            val_60 = 1152921513193527040;
            // 0x0167EEC0: TBZ w8, #0, #0x167eed0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_86;
            // 0x0167EEC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167EEC8: CBNZ w8, #0x167eed0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
            // 0x0167EECC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_86:
            // 0x0167EED0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EED4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167EED8: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x0167EEDC: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
            UnityEngine.Object.DestroyImmediate(obj:  0);
            // 0x0167EEE0: STP s8, s9, [x19]          | endPosition.x = val_58.x;  endPosition.y = val_58.y;  //  dest_result_addr=1152921513193527040 |  dest_result_addr=1152921513193527044
            endPosition.x = val_78;
            endPosition.y = val_58.y;
            // 0x0167EEE4: STR s10, [x19, #8]         | endPosition.z = val_58.z;                //  dest_result_addr=1152921513193527048
            endPosition.z = val_79;
            // 0x0167EEE8: B #0x167ef04               |  goto label_87;                         
            goto label_87;
            label_37:
            // 0x0167EEEC: LDR x8, [sp, #0x10]        | X8 = endPosition;                       
            // 0x0167EEF0: LDR s0, [sp, #0x3c]        | S0 = val_50.y;                          
            // 0x0167EEF4: STR s10, [x8]              | endPosition.x = val_19.x;                //  dest_result_addr=1152921513193527040
            endPosition.x = val_70;
            // 0x0167EEF8: STR s0, [x8, #4]           | endPosition.y = val_50.y;                //  dest_result_addr=1152921513193527044
            endPosition.y = val_50.y;
            // 0x0167EEFC: LDR s0, [sp, #0x38]        | S0 = val_50.z;                          
            // 0x0167EF00: STR s0, [x8, #8]           | endPosition.z = val_50.z;                //  dest_result_addr=1152921513193527048
            endPosition.z = val_50.z;
            label_87:
            // 0x0167EF04: SUB sp, x29, #0x90         | SP = (1152921513193478928 - 144) = 1152921513193478784 (0x10000001FFCD9A80);
            // 0x0167EF08: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
            // 0x0167EF0C: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
            // 0x0167EF10: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
            // 0x0167EF14: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
            // 0x0167EF18: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
            // 0x0167EF1C: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
            // 0x0167EF20: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x0167EF24: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x0167EF28: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x0167EF2C: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
            // 0x0167EF30: RET                        |  return;                                
            return;
            label_11:
            // 0x0167EF34: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0167EF38: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x0167EF3C: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_59 = null;
            // 0x0167EF40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x0167EF44: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x0167EF48: LDR x8, [x8, #0x420]       | X8 = (string**)(1152921513193465792)("Could not find root transform");
            // 0x0167EF4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167EF50: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0167EF54: LDR x1, [x8]               | X1 = "Could not find root transform";   
            // 0x0167EF58: BL #0x1c32b48              | .ctor(message:  "Could not find root transform");
            val_59 = new System.Exception(message:  "Could not find root transform");
            // 0x0167EF5C: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x0167EF60: LDR x8, [x8, #0x748]       | X8 = 1152921513193465920;               
            // 0x0167EF64: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x0167EF68: LDR x1, [x8]               | X1 = public System.Void Pathfinding.AnimationLink::CalculateOffsets(System.Collections.Generic.List<UnityEngine.Vector3> trace, out UnityEngine.Vector3 endPosition);
            // 0x0167EF6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x0167EF70: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x0167EF74 (23588724), len: 428  VirtAddr: 0x0167EF74 RVA: 0x0167EF74 token: 100682125 methodIndex: 49753 delegateWrapperIndex: 0 methodInvoker: 0
        public override void OnDrawGizmosSelected()
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            // 0x0167EF74: STP d11, d10, [sp, #-0x50]! | stack[1152921513193955360] = ???;  stack[1152921513193955368] = ???;  //  dest_result_addr=1152921513193955360 |  dest_result_addr=1152921513193955368
            // 0x0167EF78: STP d9, d8, [sp, #0x10]    | stack[1152921513193955376] = ???;  stack[1152921513193955384] = ???;  //  dest_result_addr=1152921513193955376 |  dest_result_addr=1152921513193955384
            // 0x0167EF7C: STP x22, x21, [sp, #0x20]  | stack[1152921513193955392] = ???;  stack[1152921513193955400] = ???;  //  dest_result_addr=1152921513193955392 |  dest_result_addr=1152921513193955400
            // 0x0167EF80: STP x20, x19, [sp, #0x30]  | stack[1152921513193955408] = ???;  stack[1152921513193955416] = ???;  //  dest_result_addr=1152921513193955408 |  dest_result_addr=1152921513193955416
            // 0x0167EF84: STP x29, x30, [sp, #0x40]  | stack[1152921513193955424] = ???;  stack[1152921513193955432] = ???;  //  dest_result_addr=1152921513193955424 |  dest_result_addr=1152921513193955432
            // 0x0167EF88: ADD x29, sp, #0x40         | X29 = (1152921513193955360 + 64) = 1152921513193955424 (0x10000001FFD4E060);
            // 0x0167EF8C: SUB sp, sp, #0x10          | SP = (1152921513193955360 - 16) = 1152921513193955344 (0x10000001FFD4E010);
            // 0x0167EF90: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167EF94: LDRB w8, [x19, #0xaf]      | W8 = (bool)static_value_037380AF;       
            // 0x0167EF98: MOV x20, x0                | X20 = 1152921513193967440 (0x10000001FFD50F50);//ML01
            // 0x0167EF9C: TBNZ w8, #0, #0x167efb8    | if (static_value_037380AF == true) goto label_0;
            // 0x0167EFA0: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x0167EFA4: LDR x8, [x8, #0xa10]       | X8 = 0x2B8ADF4;                         
            // 0x0167EFA8: LDR w0, [x8]               | W0 = 0x23B;                             
            // 0x0167EFAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x23B, ????);      
            // 0x0167EFB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167EFB4: STRB w8, [x19, #0xaf]      | static_value_037380AF = true;            //  dest_result_addr=57901231
            label_0:
            // 0x0167EFB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167EFBC: MOV x0, x20                | X0 = 1152921513193967440 (0x10000001FFD50F50);//ML01
            // 0x0167EFC0: STR wzr, [sp, #8]          | stack[1152921513193955352] = 0x0;        //  dest_result_addr=1152921513193955352
            // 0x0167EFC4: STR xzr, [sp]              | stack[1152921513193955344] = 0x0;        //  dest_result_addr=1152921513193955344
            // 0x0167EFC8: BL #0x156d814              | this.OnDrawGizmosSelected();            
            this.OnDrawGizmosSelected();
            // 0x0167EFCC: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x0167EFD0: LDR x8, [x8, #0x720]       | X8 = 1152921504839487488;               
            // 0x0167EFD4: LDR x0, [x8]               | X0 = typeof(Pathfinding.Util.ListPool<T>);
            // 0x0167EFD8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_10A;
            // 0x0167EFDC: TBZ w8, #0, #0x167efec     | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167EFE0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished;
            // 0x0167EFE4: CBNZ w8, #0x167efec        | if (Pathfinding.Util.ListPool<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167EFE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.ListPool<T>), ????);
            label_2:
            // 0x0167EFEC: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0167EFF0: LDR x8, [x8, #0x1e8]       | X8 = 1152921513123913344;               
            // 0x0167EFF4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167EFF8: LDR x1, [x8]               | X1 = public static System.Collections.Generic.List<T> Pathfinding.Util.ListPool<UnityEngine.Vector3>::Claim();
            // 0x0167EFFC: BL #0x1a00c94              | X0 = Pathfinding.Util.ListPool<UnityEngine.Vector3>.Claim();
            System.Collections.Generic.List<T> val_1 = Pathfinding.Util.ListPool<UnityEngine.Vector3>.Claim();
            // 0x0167F000: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x0167F004: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x0167F008: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x0167F00C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Vector3);       
            // 0x0167F010: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x0167F014: TBZ w9, #0, #0x167f028     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x0167F018: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x0167F01C: CBNZ w9, #0x167f028        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x0167F020: MOV x0, x8                 | X0 = 1152921504695078912 (0x1000000005425000);//ML01
            // 0x0167F024: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_4:
            // 0x0167F028: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167F02C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F030: BL #0x2699c40              | X0 = UnityEngine.Vector3.get_zero();    
            UnityEngine.Vector3 val_2 = UnityEngine.Vector3.zero;
            // 0x0167F034: MOV x2, sp                 | X2 = 1152921513193955344 (0x10000001FFD4E010);//ML01
            // 0x0167F038: MOV x0, x20                | X0 = 1152921513193967440 (0x10000001FFD50F50);//ML01
            // 0x0167F03C: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x0167F040: STP s0, s1, [sp]           | stack[1152921513193955344] = val_2.x;  stack[1152921513193955348] = val_2.y;  //  dest_result_addr=1152921513193955344 |  dest_result_addr=1152921513193955348
            // 0x0167F044: STR s2, [sp, #8]           | stack[1152921513193955352] = val_2.z;    //  dest_result_addr=1152921513193955352
            // 0x0167F048: BL #0x167e420              | this.CalculateOffsets(trace:  val_1, endPosition: out  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
            this.CalculateOffsets(trace:  val_1, endPosition: out  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
            // 0x0167F04C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167F050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F054: BL #0x20d3bd0              | X0 = UnityEngine.Color.get_blue();      
            UnityEngine.Color val_3 = UnityEngine.Color.blue;
            // 0x0167F058: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167F05C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F060: BL #0x1a654c8              | UnityEngine.Gizmos.set_color(value:  new UnityEngine.Color() {r = val_3.r, g = val_3.g, b = val_3.b, a = val_3.a});
            UnityEngine.Gizmos.color = new UnityEngine.Color() {r = val_3.r, g = val_3.g, b = val_3.b, a = val_3.a};
            // 0x0167F064: ADRP x21, #0x35fc000       | X21 = 56606720 (0x35FC000);             
            // 0x0167F068: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
            // 0x0167F06C: LDR x21, [x21, #0x5e0]     | X21 = 1152921510909311600;              
            // 0x0167F070: LDR x22, [x22, #0x1f0]     | X22 = 1152921510909481968;              
            // 0x0167F074: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x0167F078: B #0x167f0b4               |  goto label_5;                          
            goto label_5;
            label_10:
            // 0x0167F07C: LDR x2, [x22]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
            // 0x0167F080: ADD w20, w20, #1           | W20 = (val_8 + 1) = val_8 (0x00000001); 
            val_8 = 1;
            // 0x0167F084: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x0167F088: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x0167F08C: BL #0x264334c              | X0 = val_1.get_Item(index:  1);         
            UnityEngine.Vector3 val_4 = val_1.Item[1];
            // 0x0167F090: MOV v3.16b, v0.16b         | V3 = val_4.x;//m1                       
            // 0x0167F094: MOV v4.16b, v1.16b         | V4 = val_4.y;//m1                       
            // 0x0167F098: MOV v5.16b, v2.16b         | V5 = val_4.z;//m1                       
            // 0x0167F09C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167F0A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F0A4: MOV v0.16b, v8.16b         | V0 = V8.16B;//m1                        
            // 0x0167F0A8: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
            // 0x0167F0AC: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
            // 0x0167F0B0: BL #0x1a64030              | UnityEngine.Gizmos.DrawLine(from:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B}, to:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
            UnityEngine.Gizmos.DrawLine(from:  new UnityEngine.Vector3() {x = V8.16B, y = V9.16B, z = V10.16B}, to:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
            label_5:
            // 0x0167F0B4: CBNZ x19, #0x167f0bc       | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x0167F0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_6:
            // 0x0167F0BC: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
            // 0x0167F0C0: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x0167F0C4: BL #0x2643344              | X0 = val_1.get_Count();                 
            int val_5 = val_1.Count;
            // 0x0167F0C8: SUB w8, w0, #1             | W8 = (val_5 - 1);                       
            int val_6 = val_5 - 1;
            // 0x0167F0CC: CMP w20, w8                | STATE = COMPARE(0x1, (val_5 - 1))       
            // 0x0167F0D0: B.GE #0x167f104            | if (val_8 >= val_6) goto label_7;       
            if(val_8 >= val_6)
            {
                goto label_7;
            }
            // 0x0167F0D4: CBNZ x19, #0x167f0dc       | if (val_1 != null) goto label_8;        
            if(val_1 != null)
            {
                goto label_8;
            }
            // 0x0167F0D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_8:
            // 0x0167F0DC: LDR x2, [x22]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
            // 0x0167F0E0: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x0167F0E4: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
            // 0x0167F0E8: BL #0x264334c              | X0 = val_1.get_Item(index:  1);         
            UnityEngine.Vector3 val_7 = val_1.Item[1];
            // 0x0167F0EC: MOV v8.16b, v0.16b         | V8 = val_7.x;//m1                       
            // 0x0167F0F0: MOV v9.16b, v1.16b         | V9 = val_7.y;//m1                       
            // 0x0167F0F4: MOV v10.16b, v2.16b        | V10 = val_7.z;//m1                      
            // 0x0167F0F8: CBNZ x19, #0x167f07c       | if (val_1 != null) goto label_10;       
            if(val_1 != null)
            {
                goto label_10;
            }
            // 0x0167F0FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x0167F100: B #0x167f07c               |  goto label_10;                         
            goto label_10;
            label_7:
            // 0x0167F104: SUB sp, x29, #0x40         | SP = (1152921513193955424 - 64) = 1152921513193955360 (0x10000001FFD4E020);
            // 0x0167F108: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F10C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x0167F110: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x0167F114: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
            // 0x0167F118: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
            // 0x0167F11C: RET                        |  return;                                
            return;
        
        }
    
    }

}
