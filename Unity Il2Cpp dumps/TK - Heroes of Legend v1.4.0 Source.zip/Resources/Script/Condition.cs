using UnityEngine;

namespace LitJson
{
    internal enum Condition
    {
        // Fields
        InArray = 0
        ,InObject = 1
        ,NotAProperty = 2
        ,Property = 3
        ,Value = 4
        
    
    }

}
