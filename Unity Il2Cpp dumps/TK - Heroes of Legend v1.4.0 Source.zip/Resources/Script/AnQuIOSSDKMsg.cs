using UnityEngine;
public class AnQuIOSSDKMsg
{
    // Fields
    public static AnQuIOSSDKMsg _inst; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B29B00 (11705088), len: 8  VirtAddr: 0x00B29B00 RVA: 0x00B29B00 token: 100690097 methodIndex: 24850 delegateWrapperIndex: 0 methodInvoker: 0
    public AnQuIOSSDKMsg()
    {
        //
        // Disasemble & Code
        // 0x00B29B00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29B04: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B08 (11705096), len: 128  VirtAddr: 0x00B29B08 RVA: 0x00B29B08 token: 100690098 methodIndex: 24851 delegateWrapperIndex: 0 methodInvoker: 0
    public static AnQuIOSSDKMsg Instance()
    {
        //
        // Disasemble & Code
        //  | 
        AnQuIOSSDKMsg val_2;
        //  | 
        AnQuIOSSDKMsg val_3;
        // 0x00B29B08: STP x20, x19, [sp, #-0x20]! | stack[1152921514472300064] = ???;  stack[1152921514472300072] = ???;  //  dest_result_addr=1152921514472300064 |  dest_result_addr=1152921514472300072
        // 0x00B29B0C: STP x29, x30, [sp, #0x10]  | stack[1152921514472300080] = ???;  stack[1152921514472300088] = ???;  //  dest_result_addr=1152921514472300080 |  dest_result_addr=1152921514472300088
        // 0x00B29B10: ADD x29, sp, #0x10         | X29 = (1152921514472300064 + 16) = 1152921514472300080 (0x100000024C06DE30);
        // 0x00B29B14: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B29B18: LDRB w8, [x19, #0x75c]     | W8 = (bool)static_value_0373375C;       
        // 0x00B29B1C: TBNZ w8, #0, #0xb29b38     | if (static_value_0373375C == true) goto label_0;
        // 0x00B29B20: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B29B24: LDR x8, [x8, #0x798]       | X8 = 0x2B8AF40;                         
        // 0x00B29B28: LDR w0, [x8]               | W0 = 0x28E;                             
        // 0x00B29B2C: BL #0x2782188              | X0 = sub_2782188( ?? 0x28E, ????);      
        // 0x00B29B30: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B29B34: STRB w8, [x19, #0x75c]     | static_value_0373375C = true;            //  dest_result_addr=57882460
        label_0:
        // 0x00B29B38: ADRP x20, #0x35e4000       | X20 = 56508416 (0x35E4000);             
        // 0x00B29B3C: LDR x20, [x20, #0xaf0]     | X20 = 1152921504887091200;              
        // 0x00B29B40: LDR x0, [x20]              | X0 = typeof(AnQuIOSSDKMsg);             
        object val_1 = null;
        // 0x00B29B44: LDR x8, [x0, #0xa0]        | X8 = AnQuIOSSDKMsg.__il2cppRuntimeField_static_fields;
        // 0x00B29B48: LDR x8, [x8]               | X8 = AnQuIOSSDKMsg._inst;               
        val_3 = AnQuIOSSDKMsg._inst;
        // 0x00B29B4C: CBNZ x8, #0xb29b78         | if (AnQuIOSSDKMsg._inst != null) goto label_1;
        if(val_3 != null)
        {
            goto label_1;
        }
        // 0x00B29B50: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnQuIOSSDKMsg), ????);
        // 0x00B29B54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B29B58: MOV x19, x0                | X19 = 1152921504887091200 (0x1000000010B43000);//ML01
        val_2 = val_1;
        // 0x00B29B5C: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00B29B60: LDR x8, [x20]              | X8 = typeof(AnQuIOSSDKMsg);             
        // 0x00B29B64: LDR x8, [x8, #0xa0]        | X8 = AnQuIOSSDKMsg.__il2cppRuntimeField_static_fields;
        // 0x00B29B68: STR x19, [x8]              | AnQuIOSSDKMsg._inst = typeof(AnQuIOSSDKMsg);  //  dest_result_addr=1152921504887095296
        AnQuIOSSDKMsg._inst = val_2;
        // 0x00B29B6C: LDR x8, [x20]              | X8 = typeof(AnQuIOSSDKMsg);             
        // 0x00B29B70: LDR x8, [x8, #0xa0]        | X8 = AnQuIOSSDKMsg.__il2cppRuntimeField_static_fields;
        // 0x00B29B74: LDR x8, [x8]               | X8 = typeof(AnQuIOSSDKMsg);             
        val_3 = AnQuIOSSDKMsg._inst;
        label_1:
        // 0x00B29B78: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B29B7C: MOV x0, x8                 | X0 = 1152921504887091200 (0x1000000010B43000);//ML01
        // 0x00B29B80: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B29B84: RET                        |  return (AnQuIOSSDKMsg)typeof(AnQuIOSSDKMsg);
        return (AnQuIOSSDKMsg)val_3;
        //  |  // // {name=val_0, type=AnQuIOSSDKMsg, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B88 (11705224), len: 4  VirtAddr: 0x00B29B88 RVA: 0x00B29B88 token: 100690099 methodIndex: 24852 delegateWrapperIndex: 0 methodInvoker: 0
    public void chuShiHua()
    {
        //
        // Disasemble & Code
        // 0x00B29B88: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B8C (11705228), len: 4  VirtAddr: 0x00B29B8C RVA: 0x00B29B8C token: 100690100 methodIndex: 24853 delegateWrapperIndex: 0 methodInvoker: 0
    public void openDengLu()
    {
        //
        // Disasemble & Code
        // 0x00B29B8C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B90 (11705232), len: 4  VirtAddr: 0x00B29B90 RVA: 0x00B29B90 token: 100690101 methodIndex: 24854 delegateWrapperIndex: 0 methodInvoker: 0
    public void zhuXiaoDengLu()
    {
        //
        // Disasemble & Code
        // 0x00B29B90: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B94 (11705236), len: 4  VirtAddr: 0x00B29B94 RVA: 0x00B29B94 token: 100690102 methodIndex: 24855 delegateWrapperIndex: 0 methodInvoker: 0
    public void zhiFu(string amount, string name, string Level, string ID, string s_id, string s_name, string subject, string order_no, string ext = "")
    {
        //
        // Disasemble & Code
        // 0x00B29B94: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B98 (11705240), len: 4  VirtAddr: 0x00B29B98 RVA: 0x00B29B98 token: 100690103 methodIndex: 24856 delegateWrapperIndex: 0 methodInvoker: 0
    public void chuangJieJueSe(string roleID, string roleName, string roleLevel, string serverID, string serverName, string balance, string vip, string partyName, string extra = "无")
    {
        //
        // Disasemble & Code
        // 0x00B29B98: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29B9C (11705244), len: 4  VirtAddr: 0x00B29B9C RVA: 0x00B29B9C token: 100690104 methodIndex: 24857 delegateWrapperIndex: 0 methodInvoker: 0
    public void jinRuFuWuQiEvent(string roleID, string roleName, string roleLevel, string serverID, string serverName, string balance, string vip, string partyName, string extra = "0")
    {
        //
        // Disasemble & Code
        // 0x00B29B9C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B29BA0 (11705248), len: 4  VirtAddr: 0x00B29BA0 RVA: 0x00B29BA0 token: 100690105 methodIndex: 24858 delegateWrapperIndex: 0 methodInvoker: 0
    public void jueSeShengJi(string roleID, string roleName, string roleLevel, string serverID, string serverName, string balance, string vip, string partyName, string extra = "0")
    {
        //
        // Disasemble & Code
        // 0x00B29BA0: RET                        |  return;                                
        return;
    
    }

}
