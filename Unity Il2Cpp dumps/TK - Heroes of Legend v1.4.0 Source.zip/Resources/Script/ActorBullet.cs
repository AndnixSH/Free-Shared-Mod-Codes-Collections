using UnityEngine;
public class ActorBullet : IEffComponent
{
    // Fields
    public bool isatk; //  0x00000018
    public CombatEntity host; //  0x00000020
    public int skillID; //  0x00000028
    public skillCfg mpJson; //  0x00000030
    public int Hurt_times; //  0x00000038
    public float damage_time; //  0x0000003C
    public bool isPause; //  0x00000040
    private UnityEngine.Transform targetTr; //  0x00000048
    private float speed; //  0x00000050
    private UnityEngine.Vector3 targetPosition; //  0x00000054
    private bool IsDo; //  0x00000060
    private float trailtime; //  0x00000064
    private CombatEntity targetEntity; //  0x00000068
    private UnityEngine.Transform tr; //  0x00000070
    private System.Collections.Generic.List<UnityEngine.Vector3> paths; //  0x00000078
    private System.Collections.Generic.List<uint> delayList; //  0x00000080
    private UnityEngine.Collider c; //  0x00000088
    private float beforflyAngle; //  0x00000090
    private float curflyAngle; //  0x00000094
    private System.Collections.Generic.List<CombatEntity> triggerEntityList; //  0x00000098
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B1E6B8 (11658936), len: 192  VirtAddr: 0x00B1E6B8 RVA: 0x00B1E6B8 token: 100693573 methodIndex: 24682 delegateWrapperIndex: 0 methodInvoker: 0
    public ActorBullet()
    {
        //
        // Disasemble & Code
        // 0x00B1E6B8: STP x20, x19, [sp, #-0x20]! | stack[1152921515014945776] = ???;  stack[1152921515014945784] = ???;  //  dest_result_addr=1152921515014945776 |  dest_result_addr=1152921515014945784
        // 0x00B1E6BC: STP x29, x30, [sp, #0x10]  | stack[1152921515014945792] = ???;  stack[1152921515014945800] = ???;  //  dest_result_addr=1152921515014945792 |  dest_result_addr=1152921515014945800
        // 0x00B1E6C0: ADD x29, sp, #0x10         | X29 = (1152921515014945776 + 16) = 1152921515014945792 (0x100000026C5EFC00);
        // 0x00B1E6C4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1E6C8: LDRB w8, [x20, #0x711]     | W8 = (bool)static_value_03733711;       
        // 0x00B1E6CC: MOV x19, x0                | X19 = 1152921515014957808 (0x100000026C5F2AF0);//ML01
        // 0x00B1E6D0: TBNZ w8, #0, #0xb1e6ec     | if (static_value_03733711 == true) goto label_0;
        // 0x00B1E6D4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x00B1E6D8: LDR x8, [x8, #0x6b8]       | X8 = 0x2B8A9BC;                         
        // 0x00B1E6DC: LDR w0, [x8]               | W0 = 0x12D;                             
        // 0x00B1E6E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x12D, ????);      
        // 0x00B1E6E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1E6E8: STRB w8, [x20, #0x711]     | static_value_03733711 = true;            //  dest_result_addr=57882385
        label_0:
        // 0x00B1E6EC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B1E6F0: LDR x8, [x8, #0x968]       | X8 = 1152921504616644608;               
        // 0x00B1E6F4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<UnityEngine.Vector3> val_1 = null;
        // 0x00B1E6F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1E6FC: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x00B1E700: LDR x8, [x8, #0xe90]       | X8 = 1152921510909820656;               
        // 0x00B1E704: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1E708: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::.ctor();
        // 0x00B1E70C: BL #0x263edc8              | .ctor();                                
        val_1 = new System.Collections.Generic.List<UnityEngine.Vector3>();
        // 0x00B1E710: STR x20, [x19, #0x78]      | this.paths = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515014957928
        this.paths = val_1;
        // 0x00B1E714: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
        // 0x00B1E718: LDR x8, [x8, #0xe18]       | X8 = 1152921504616644608;               
        // 0x00B1E71C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<System.UInt32> val_2 = null;
        // 0x00B1E720: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1E724: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B1E728: LDR x8, [x8, #0xcf0]       | X8 = 1152921510903021008;               
        // 0x00B1E72C: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1E730: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.UInt32>::.ctor();
        // 0x00B1E734: BL #0x256c46c              | .ctor();                                
        val_2 = new System.Collections.Generic.List<System.UInt32>();
        // 0x00B1E738: STR x20, [x19, #0x80]      | this.delayList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515014957936
        this.delayList = val_2;
        // 0x00B1E73C: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00B1E740: LDR x8, [x8, #0xf08]       | X8 = 1152921504616644608;               
        // 0x00B1E744: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CombatEntity> val_3 = null;
        // 0x00B1E748: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1E74C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B1E750: LDR x8, [x8, #0xea8]       | X8 = 1152921514597515904;               
        // 0x00B1E754: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1E758: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CombatEntity>::.ctor();
        // 0x00B1E75C: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<CombatEntity>();
        // 0x00B1E760: STR x20, [x19, #0x98]      | this.triggerEntityList = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515014957960
        this.triggerEntityList = val_3;
        // 0x00B1E764: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1E768: MOV x0, x19                | X0 = 1152921515014957808 (0x100000026C5F2AF0);//ML01
        // 0x00B1E76C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E770: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1E774: B #0x28a4a40               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1E778 (11659128), len: 1312  VirtAddr: 0x00B1E778 RVA: 0x00B1E778 token: 100693574 methodIndex: 24683 delegateWrapperIndex: 0 methodInvoker: 0
    public void Setup(CombatEntity target, float speed, UnityEngine.Vector3 targetPosition, EntityEnum.UnitTag tag, CombatEntity host, bool isatk, UnityEngine.Transform startTr, int skillID)
    {
        //
        // Disasemble & Code
        //  | 
        int val_23;
        //  | 
        float val_24;
        //  | 
        float val_25;
        //  | 
        IntPtr val_26;
        //  | 
        UnityEngine.Object val_27;
        //  | 
        float val_28;
        //  | 
        effectCfg val_29;
        //  | 
        float val_30;
        //  | 
        bool val_31;
        // 0x00B1E778: STP d13, d12, [sp, #-0x80]! | stack[1152921515015181776] = ???;  stack[1152921515015181784] = ???;  //  dest_result_addr=1152921515015181776 |  dest_result_addr=1152921515015181784
        // 0x00B1E77C: STP d11, d10, [sp, #0x10]  | stack[1152921515015181792] = ???;  stack[1152921515015181800] = ???;  //  dest_result_addr=1152921515015181792 |  dest_result_addr=1152921515015181800
        // 0x00B1E780: STP d9, d8, [sp, #0x20]    | stack[1152921515015181808] = ???;  stack[1152921515015181816] = ???;  //  dest_result_addr=1152921515015181808 |  dest_result_addr=1152921515015181816
        // 0x00B1E784: STP x26, x25, [sp, #0x30]  | stack[1152921515015181824] = ???;  stack[1152921515015181832] = ???;  //  dest_result_addr=1152921515015181824 |  dest_result_addr=1152921515015181832
        // 0x00B1E788: STP x24, x23, [sp, #0x40]  | stack[1152921515015181840] = ???;  stack[1152921515015181848] = ???;  //  dest_result_addr=1152921515015181840 |  dest_result_addr=1152921515015181848
        // 0x00B1E78C: STP x22, x21, [sp, #0x50]  | stack[1152921515015181856] = ???;  stack[1152921515015181864] = ???;  //  dest_result_addr=1152921515015181856 |  dest_result_addr=1152921515015181864
        // 0x00B1E790: STP x20, x19, [sp, #0x60]  | stack[1152921515015181872] = ???;  stack[1152921515015181880] = ???;  //  dest_result_addr=1152921515015181872 |  dest_result_addr=1152921515015181880
        // 0x00B1E794: STP x29, x30, [sp, #0x70]  | stack[1152921515015181888] = ???;  stack[1152921515015181896] = ???;  //  dest_result_addr=1152921515015181888 |  dest_result_addr=1152921515015181896
        // 0x00B1E798: ADD x29, sp, #0x70         | X29 = (1152921515015181776 + 112) = 1152921515015181888 (0x100000026C629640);
        // 0x00B1E79C: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00B1E7A0: LDRB w8, [x24, #0x712]     | W8 = (bool)static_value_03733712;       
        // 0x00B1E7A4: MOV w21, w6                | W21 = skillID;//m1                      
        val_23 = skillID;
        // 0x00B1E7A8: MOV w20, w4                | W20 = isatk;//m1                        
        // 0x00B1E7AC: MOV x22, x3                | X22 = host;//m1                         
        // 0x00B1E7B0: MOV v8.16b, v3.16b         | V8 = targetPosition.z;//m1              
        val_24 = targetPosition.z;
        // 0x00B1E7B4: MOV v11.16b, v2.16b        | V11 = targetPosition.y;//m1             
        // 0x00B1E7B8: MOV v9.16b, v1.16b         | V9 = targetPosition.x;//m1              
        val_25 = targetPosition.x;
        // 0x00B1E7BC: MOV v10.16b, v0.16b        | V10 = speed;//m1                        
        // 0x00B1E7C0: MOV x23, x1                | X23 = target;//m1                       
        // 0x00B1E7C4: MOV x19, x0                | X19 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1E7C8: TBNZ w8, #0, #0xb1e7e4     | if (static_value_03733712 == true) goto label_0;
        // 0x00B1E7CC: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B1E7D0: LDR x8, [x8, #0x290]       | X8 = 0x2B8A9E0;                         
        // 0x00B1E7D4: LDR w0, [x8]               | W0 = 0x136;                             
        // 0x00B1E7D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x136, ????);      
        // 0x00B1E7DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1E7E0: STRB w8, [x24, #0x712]     | static_value_03733712 = true;            //  dest_result_addr=57882386
        label_0:
        // 0x00B1E7E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E7E8: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1E7EC: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_1 = this.effCtrl;
        // 0x00B1E7F0: MOV x24, x0                | X24 = val_1;//m1                        
        // 0x00B1E7F4: CBNZ x24, #0xb1e7fc        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B1E7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B1E7FC: LDRB w8, [x24, #0xc0]      | W8 = val_1.isTrail; //P2                
        // 0x00B1E800: CBZ w8, #0xb1e8d4          | if (val_1.isTrail == false) goto label_9;
        if(val_1.isTrail == false)
        {
            goto label_9;
        }
        // 0x00B1E804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E808: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1E80C: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_2 = this.effCtrl;
        // 0x00B1E810: MOV x24, x0                | X24 = val_2;//m1                        
        // 0x00B1E814: CBNZ x24, #0xb1e81c        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00B1E818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B1E81C: LDR x24, [x24, #0xc8]      | X24 = val_2.trailTr; //P2               
        // 0x00B1E820: CBNZ x24, #0xb1e828        | if (val_2.trailTr != null) goto label_4;
        if(val_2.trailTr != null)
        {
            goto label_4;
        }
        // 0x00B1E824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B1E828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E82C: MOV x0, x24                | X0 = val_2.trailTr;//m1                 
        // 0x00B1E830: BL #0x20d50fc              | X0 = val_2.trailTr.get_gameObject();    
        UnityEngine.GameObject val_3 = val_2.trailTr.gameObject;
        // 0x00B1E834: MOV x24, x0                | X24 = val_3;//m1                        
        // 0x00B1E838: CBNZ x24, #0xb1e840        | if (val_3 != null) goto label_5;        
        if(val_3 != null)
        {
            goto label_5;
        }
        // 0x00B1E83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_5:
        // 0x00B1E840: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E844: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1E848: MOV x0, x24                | X0 = val_3;//m1                         
        // 0x00B1E84C: BL #0x1a62d64              | val_3.SetActive(value:  true);          
        val_3.SetActive(value:  true);
        // 0x00B1E850: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E854: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1E858: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_4 = this.effCtrl;
        // 0x00B1E85C: MOV x24, x0                | X24 = val_4;//m1                        
        // 0x00B1E860: CBNZ x24, #0xb1e868        | if (val_4 != null) goto label_6;        
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00B1E864: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x00B1E868: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1E86C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B1E870: LDR x24, [x24, #0xb8]      | X24 = val_4.trailrendere; //P2          
        // 0x00B1E874: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B1E878: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E87C: TBZ w8, #0, #0xb1e88c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B1E880: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E884: CBNZ w8, #0xb1e88c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B1E888: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x00B1E88C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E894: MOV x1, x24                | X1 = val_4.trailrendere;//m1            
        // 0x00B1E898: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E89C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_4.trailrendere);
        bool val_5 = UnityEngine.Object.op_Inequality(x:  0, y:  val_4.trailrendere);
        // 0x00B1E8A0: TBZ w0, #0, #0xb1e8d4      | if (val_5 == false) goto label_9;       
        if(val_5 == false)
        {
            goto label_9;
        }
        // 0x00B1E8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E8A8: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1E8AC: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_6 = this.effCtrl;
        // 0x00B1E8B0: MOV x24, x0                | X24 = val_6;//m1                        
        // 0x00B1E8B4: CBNZ x24, #0xb1e8bc        | if (val_6 != null) goto label_10;       
        if(val_6 != null)
        {
            goto label_10;
        }
        // 0x00B1E8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_10:
        // 0x00B1E8BC: LDR x24, [x24, #0xb8]      | X24 = val_6.trailrendere; //P2          
        // 0x00B1E8C0: CBNZ x24, #0xb1e8c8        | if (val_6.trailrendere != null) goto label_11;
        if(val_6.trailrendere != null)
        {
            goto label_11;
        }
        // 0x00B1E8C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B1E8C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E8CC: MOV x0, x24                | X0 = val_6.trailrendere;//m1            
        // 0x00B1E8D0: BL #0x26934a0              | val_6.trailrendere.Clear();             
        val_6.trailrendere.Clear();
        label_9:
        // 0x00B1E8D4: ADRP x25, #0x35fe000       | X25 = 56614912 (0x35FE000);             
        // 0x00B1E8D8: LDR x25, [x25, #0x810]     | X25 = 1152921504697475072;              
        val_26 = 1152921504697475072;
        // 0x00B1E8DC: LDR x0, [x25]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1E8E0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E8E4: TBZ w8, #0, #0xb1e8f4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B1E8E8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E8EC: CBNZ w8, #0xb1e8f4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B1E8F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_13:
        // 0x00B1E8F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E8F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E8FC: MOV x1, x23                | X1 = target;//m1                        
        // 0x00B1E900: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E904: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  target);
        bool val_7 = UnityEngine.Object.op_Inequality(x:  0, y:  target);
        // 0x00B1E908: TBZ w0, #0, #0xb1e9c8      | if (val_7 == false) goto label_14;      
        if(val_7 == false)
        {
            goto label_14;
        }
        // 0x00B1E90C: CBNZ x23, #0xb1e914        | if (target != null) goto label_15;      
        if(target != null)
        {
            goto label_15;
        }
        // 0x00B1E910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_15:
        // 0x00B1E914: LDR x24, [x23, #0x58]      | 
        // 0x00B1E918: CBNZ x24, #0xb1e920        | if (val_6.trailrendere != null) goto label_16;
        if(val_6.trailrendere != null)
        {
            goto label_16;
        }
        // 0x00B1E91C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_16:
        // 0x00B1E920: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00B1E924: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921515015094960)("Bipbehit");
        // 0x00B1E928: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E92C: MOV x0, x24                | X0 = val_6.trailrendere;//m1            
        // 0x00B1E930: LDR x1, [x8]               | X1 = "Bipbehit";                        
        // 0x00B1E934: BL #0x2695ac0              | X0 = val_6.trailrendere.Find(name:  "Bipbehit");
        UnityEngine.Transform val_8 = val_6.trailrendere.Find(name:  "Bipbehit");
        // 0x00B1E938: LDR x8, [x25]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B1E93C: MOV x24, x0                | X24 = val_8;//m1                        
        val_27 = val_8;
        // 0x00B1E940: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E944: TBZ w9, #0, #0xb1e958      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B1E948: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E94C: CBNZ w9, #0xb1e958         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B1E950: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B1E954: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_18:
        // 0x00B1E958: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E95C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E960: MOV x1, x24                | X1 = val_8;//m1                         
        // 0x00B1E964: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E968: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_27);
        bool val_9 = UnityEngine.Object.op_Equality(x:  0, y:  val_27);
        // 0x00B1E96C: TBZ w0, #0, #0xb1e9a0      | if (val_9 == false) goto label_19;      
        if(val_9 == false)
        {
            goto label_19;
        }
        // 0x00B1E970: CBNZ x23, #0xb1e978        | if (target != null) goto label_20;      
        if(target != null)
        {
            goto label_20;
        }
        // 0x00B1E974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_20:
        // 0x00B1E978: LDR x24, [x23, #0x58]      | 
        // 0x00B1E97C: CBNZ x24, #0xb1e984        | if (val_8 != null) goto label_21;       
        if(val_27 != null)
        {
            goto label_21;
        }
        // 0x00B1E980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_21:
        // 0x00B1E984: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00B1E988: LDR x8, [x8, #0xbd0]       | X8 = (string**)(1152921515015099152)("waistpoint");
        // 0x00B1E98C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E990: MOV x0, x24                | X0 = val_8;//m1                         
        // 0x00B1E994: LDR x1, [x8]               | X1 = "waistpoint";                      
        // 0x00B1E998: BL #0x2695ac0              | X0 = val_8.Find(name:  "waistpoint");   
        UnityEngine.Transform val_10 = val_27.Find(name:  "waistpoint");
        // 0x00B1E99C: MOV x24, x0                | X24 = val_10;//m1                       
        val_27 = val_10;
        label_19:
        // 0x00B1E9A0: STR x24, [x19, #0x48]      | this.targetTr = val_10;                  //  dest_result_addr=1152921515015193976
        this.targetTr = val_27;
        // 0x00B1E9A4: CBNZ x24, #0xb1e9ac        | if (val_10 != null) goto label_22;      
        if(val_27 != null)
        {
            goto label_22;
        }
        // 0x00B1E9A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_22:
        // 0x00B1E9AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E9B0: MOV x0, x24                | X0 = val_10;//m1                        
        // 0x00B1E9B4: BL #0x2693510              | X0 = val_10.get_position();             
        UnityEngine.Vector3 val_11 = val_27.position;
        // 0x00B1E9B8: MOV v9.16b, v0.16b         | V9 = val_11.x;//m1                      
        val_25 = val_11.x;
        // 0x00B1E9BC: MOV v11.16b, v1.16b        | V11 = val_11.y;//m1                     
        val_28 = val_11.y;
        // 0x00B1E9C0: MOV v8.16b, v2.16b         | V8 = val_11.z;//m1                      
        val_24 = val_11.z;
        // 0x00B1E9C4: B #0xb1e9d4                |  goto label_23;                         
        goto label_23;
        label_14:
        // 0x00B1E9C8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1E9CC: LDR s0, [x8, #0x78c]       | S0 = 0.85;                              
        // 0x00B1E9D0: FADD s11, s11, s0          | S11 = (targetPosition.y + 0.85f);       
        val_28 = targetPosition.y + 0.85f;
        label_23:
        // 0x00B1E9D4: STR x23, [x19, #0x68]      | this.targetEntity = target;              //  dest_result_addr=1152921515015194008
        this.targetEntity = target;
        // 0x00B1E9D8: LDR x23, [x19, #0x70]      | X23 = this.tr; //P2                     
        // 0x00B1E9DC: STP s9, s11, [x19, #0x54]  | this.targetPosition = targetPosition;  mem[1152921515015193992] = (targetPosition.y + 0.85f);  //  dest_result_addr=1152921515015193988 |  dest_result_addr=1152921515015193992
        this.targetPosition = targetPosition;
        mem[1152921515015193992] = val_28;
        // 0x00B1E9E0: STR s8, [x19, #0x5c]       | mem[1152921515015193996] = targetPosition.z;  //  dest_result_addr=1152921515015193996
        mem[1152921515015193996] = val_24;
        // 0x00B1E9E4: CBNZ x23, #0xb1e9ec        | if (this.tr != null) goto label_24;     
        if(this.tr != null)
        {
            goto label_24;
        }
        // 0x00B1E9E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_24:
        // 0x00B1E9EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E9F0: MOV x0, x23                | X0 = this.tr;//m1                       
        // 0x00B1E9F4: MOV v0.16b, v9.16b         | V0 = targetPosition.x;//m1              
        // 0x00B1E9F8: MOV v1.16b, v11.16b        | V1 = (targetPosition.y + 0.85f);//m1    
        // 0x00B1E9FC: MOV v2.16b, v8.16b         | V2 = targetPosition.z;//m1              
        // 0x00B1EA00: BL #0x26952ec              | this.tr.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_25, y = val_28, z = val_24});
        this.tr.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_25, y = val_28, z = val_24});
        // 0x00B1EA04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EA08: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1EA0C: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_12 = this.effCtrl;
        // 0x00B1EA10: MOV x23, x0                | X23 = val_12;//m1                       
        // 0x00B1EA14: CBNZ x23, #0xb1ea1c        | if (val_12 != null) goto label_25;      
        if(val_12 != null)
        {
            goto label_25;
        }
        // 0x00B1EA18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_25:
        // 0x00B1EA1C: LDR x23, [x23, #0x20]      | X23 = val_12.effectVO; //P2             
        val_29 = val_12.effectVO;
        // 0x00B1EA20: CBNZ x23, #0xb1ea28        | if (val_12.effectVO != null) goto label_26;
        if(val_29 != null)
        {
            goto label_26;
        }
        // 0x00B1EA24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_26:
        // 0x00B1EA28: LDR s0, [x23, #0x50]       | S0 = val_12.effectVO.showtime; //P2     
        val_30 = val_12.effectVO.showtime;
        // 0x00B1EA2C: FCMP s0, #0.0              | STATE = COMPARE(val_12.effectVO.showtime, 0)
        // 0x00B1EA30: B.LE #0xb1eaec             | if (val_30 <= 0) goto label_27;         
        if(val_30 <= 0f)
        {
            goto label_27;
        }
        // 0x00B1EA34: LDR x23, [x19, #0x80]      | X23 = this.delayList; //P2              
        val_29 = this.delayList;
        // 0x00B1EA38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EA3C: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1EA40: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_13 = this.effCtrl;
        // 0x00B1EA44: MOV x24, x0                | X24 = val_13;//m1                       
        // 0x00B1EA48: CBNZ x24, #0xb1ea50        | if (val_13 != null) goto label_28;      
        if(val_13 != null)
        {
            goto label_28;
        }
        // 0x00B1EA4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_28:
        // 0x00B1EA50: LDR x24, [x24, #0x20]      | X24 = val_13.effectVO; //P2             
        // 0x00B1EA54: CBNZ x24, #0xb1ea5c        | if (val_13.effectVO != null) goto label_29;
        if(val_13.effectVO != null)
        {
            goto label_29;
        }
        // 0x00B1EA58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_29:
        // 0x00B1EA5C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x00B1EA60: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B1EA64: LDR s12, [x24, #0x50]      | S12 = val_13.effectVO.showtime; //P2    
        // 0x00B1EA68: LDR x8, [x8, #0xd30]       | X8 = 1152921515015127920;               
        // 0x00B1EA6C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B1EA70: LDR x25, [x8]              | X25 = System.Void ActorBullet::<Setup>m__0();
        val_26 = System.Void ActorBullet::<Setup>m__0();
        // 0x00B1EA74: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_14 = null;
        // 0x00B1EA78: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1EA7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1EA80: MOV x1, x19                | X1 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1EA84: MOV x2, x25                | X2 = 1152921515015127920 (0x100000026C61C370);//ML01
        // 0x00B1EA88: MOV x24, x0                | X24 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1EA8C: BL #0x26e30f0              | .ctor(object:  this, method:  val_26);  
        val_14 = new System.Action(object:  this, method:  val_26);
        // 0x00B1EA90: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B1EA94: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00B1EA98: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00B1EA9C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B1EAA0: TBZ w8, #0, #0xb1eab0      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_31;
        // 0x00B1EAA4: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1EAA8: CBNZ w8, #0xb1eab0         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
        // 0x00B1EAAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_31:
        // 0x00B1EAB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EAB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1EAB8: MOV v0.16b, v12.16b        | V0 = val_13.effectVO.showtime;//m1      
        val_30 = val_13.effectVO.showtime;
        // 0x00B1EABC: MOV x1, x24                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1EAC0: BL #0xb8e194               | X0 = BehaviourUtil.DelayCall(delaytime:  val_30 = val_13.effectVO.showtime, act:  0);
        uint val_15 = BehaviourUtil.DelayCall(delaytime:  val_30, act:  0);
        // 0x00B1EAC4: MOV w24, w0                | W24 = val_15;//m1                       
        // 0x00B1EAC8: CBNZ x23, #0xb1ead0        | if (this.delayList != null) goto label_32;
        if(val_29 != null)
        {
            goto label_32;
        }
        // 0x00B1EACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_32:
        // 0x00B1EAD0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1EAD4: LDR x8, [x8, #0xc78]       | X8 = 1152921510901563856;               
        // 0x00B1EAD8: MOV x0, x23                | X0 = this.delayList;//m1                
        // 0x00B1EADC: MOV w1, w24                | W1 = val_15;//m1                        
        // 0x00B1EAE0: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.UInt32>::Add(System.UInt32 item);
        // 0x00B1EAE4: BL #0x256d4c0              | this.delayList.Add(item:  val_15);      
        val_29.Add(item:  val_15);
        // 0x00B1EAE8: B #0xb1eaf4                |  goto label_33;                         
        goto label_33;
        label_27:
        // 0x00B1EAEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1EAF0: STRB w8, [x19, #0x60]      | this.IsDo = true;                        //  dest_result_addr=1152921515015194000
        this.IsDo = true;
        label_33:
        // 0x00B1EAF4: STR s10, [x19, #0x50]      | this.speed = speed;                      //  dest_result_addr=1152921515015193984
        this.speed = speed;
        // 0x00B1EAF8: STR x22, [x19, #0x20]      | this.host = host;                        //  dest_result_addr=1152921515015193936
        this.host = host;
        // 0x00B1EAFC: STR w21, [x19, #0x28]      | this.skillID = skillID;                  //  dest_result_addr=1152921515015193944
        this.skillID = val_23;
        // 0x00B1EB00: CBZ w21, #0xb1eb64         | if (skillID == 0) goto label_34;        
        if(val_23 == 0)
        {
            goto label_34;
        }
        // 0x00B1EB04: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00B1EB08: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00B1EB0C: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00B1EB10: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B1EB14: TBZ w8, #0, #0xb1eb24      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_36;
        // 0x00B1EB18: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B1EB1C: CBNZ w8, #0xb1eb24         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
        // 0x00B1EB20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_36:
        // 0x00B1EB24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EB2C: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_16 = ZMG.CfgDataMgr;
        // 0x00B1EB30: MOV x22, x0                | X22 = val_16;//m1                       
        // 0x00B1EB34: CBNZ x22, #0xb1eb3c        | if (val_16 != null) goto label_37;      
        if(val_16 != null)
        {
            goto label_37;
        }
        // 0x00B1EB38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_37:
        // 0x00B1EB3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1EB40: MOV x0, x22                | X0 = val_16;//m1                        
        // 0x00B1EB44: MOV w1, w21                | W1 = skillID;//m1                       
        // 0x00B1EB48: BL #0xb493f8               | X0 = val_16.GetskillCfg(id:  val_23);   
        skillCfg val_17 = val_16.GetskillCfg(id:  val_23);
        // 0x00B1EB4C: MOV x21, x0                | X21 = val_17;//m1                       
        val_23 = val_17;
        // 0x00B1EB50: STR x21, [x19, #0x30]      | this.mpJson = val_17;                    //  dest_result_addr=1152921515015193952
        this.mpJson = val_23;
        // 0x00B1EB54: CBZ x21, #0xb1eb6c         | if (val_17 == null) goto label_38;      
        if(val_23 == null)
        {
            goto label_38;
        }
        // 0x00B1EB58: LDR w8, [x21, #0x44]       | W8 = val_17.Hurt_times; //P2            
        // 0x00B1EB5C: STR w8, [x19, #0x38]       | this.Hurt_times = val_17.Hurt_times;     //  dest_result_addr=1152921515015193960
        this.Hurt_times = val_17.Hurt_times;
        // 0x00B1EB60: B #0xb1eb84                |  goto label_39;                         
        goto label_39;
        label_34:
        // 0x00B1EB64: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
        val_31 = 0;
        // 0x00B1EB68: B #0xb1eb90                |  goto label_40;                         
        goto label_40;
        label_38:
        // 0x00B1EB6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00B1EB70: LDR x8, [x19, #0x30]       | X8 = this.mpJson; //P2                  
        // 0x00B1EB74: LDR w9, [x21, #0x44]       | W9 = val_17.Hurt_times; //P2            
        // 0x00B1EB78: MOV x21, x8                | X21 = this.mpJson;//m1                  
        val_23 = this.mpJson;
        // 0x00B1EB7C: STR w9, [x19, #0x38]       | this.Hurt_times = val_17.Hurt_times;     //  dest_result_addr=1152921515015193960
        this.Hurt_times = val_17.Hurt_times;
        // 0x00B1EB80: CBZ x8, #0xb1ec94          | if (this.mpJson == null) goto label_41; 
        if(this.mpJson == null)
        {
            goto label_41;
        }
        label_39:
        // 0x00B1EB84: LDR w8, [x21, #0x3c]       | W8 = this.mpJson.damage_time; //P2      
        // 0x00B1EB88: STR w8, [x19, #0x3c]       | this.damage_time = this.mpJson.damage_time;  //  dest_result_addr=1152921515015193964
        this.damage_time = this.mpJson.damage_time;
        // 0x00B1EB8C: AND w8, w20, #1            | W8 = (isatk & 1);                       
        val_31 = isatk;
        label_40:
        // 0x00B1EB90: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1EB94: STRB w8, [x19, #0x18]      | this.isatk = (isatk & 1);                //  dest_result_addr=1152921515015193928
        this.isatk = val_31;
        // 0x00B1EB98: CBNZ x20, #0xb1eba0        | if (this.paths != null) goto label_42;  
        if(this.paths != null)
        {
            goto label_42;
        }
        // 0x00B1EB9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_42:
        // 0x00B1EBA0: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1EBA4: LDR x8, [x8, #0xe88]       | X8 = 1152921510909662576;               
        // 0x00B1EBA8: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1EBAC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Clear();
        // 0x00B1EBB0: BL #0x264071c              | this.paths.Clear();                     
        this.paths.Clear();
        // 0x00B1EBB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EBB8: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1EBBC: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_18 = this.effCtrl;
        // 0x00B1EBC0: MOV x20, x0                | X20 = val_18;//m1                       
        // 0x00B1EBC4: CBNZ x20, #0xb1ebcc        | if (val_18 != null) goto label_43;      
        if(val_18 != null)
        {
            goto label_43;
        }
        // 0x00B1EBC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_43:
        // 0x00B1EBCC: LDR x20, [x20, #0x20]      | X20 = val_18.effectVO; //P2             
        // 0x00B1EBD0: CBNZ x20, #0xb1ebd8        | if (val_18.effectVO != null) goto label_44;
        if(val_18.effectVO != null)
        {
            goto label_44;
        }
        // 0x00B1EBD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_44:
        // 0x00B1EBD8: LDR w8, [x20, #0x48]       | W8 = val_18.effectVO.isparabola; //P2   
        // 0x00B1EBDC: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1EBE0: CBZ w8, #0xb1ec1c          | if (val_18.effectVO.isparabola == 0) goto label_45;
        if(val_18.effectVO.isparabola == 0)
        {
            goto label_45;
        }
        // 0x00B1EBE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EBE8: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1EBEC: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_19 = this.effCtrl;
        // 0x00B1EBF0: MOV x21, x0                | X21 = val_19;//m1                       
        // 0x00B1EBF4: CBNZ x21, #0xb1ebfc        | if (val_19 != null) goto label_46;      
        if(val_19 != null)
        {
            goto label_46;
        }
        // 0x00B1EBF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_46:
        // 0x00B1EBFC: LDR x21, [x21, #0x20]      | X21 = val_19.effectVO; //P2             
        val_23 = val_19.effectVO;
        // 0x00B1EC00: CBNZ x21, #0xb1ec08        | if (val_19.effectVO != null) goto label_47;
        if(val_23 != null)
        {
            goto label_47;
        }
        // 0x00B1EC04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_47:
        // 0x00B1EC08: LDR w2, [x21, #0x48]       | W2 = val_19.effectVO.isparabola; //P2   
        // 0x00B1EC0C: MOV x0, x19                | X0 = 1152921515015193904 (0x100000026C62C530);//ML01
        // 0x00B1EC10: MOV x1, x20                | X1 = this.paths;//m1                    
        // 0x00B1EC14: BL #0xb1ec98               | this.SetParabolaPath(_paths:  this.paths, type:  val_19.effectVO.isparabola);
        this.SetParabolaPath(_paths:  this.paths, type:  val_19.effectVO.isparabola);
        // 0x00B1EC18: B #0xb1ec44                |  goto label_48;                         
        goto label_48;
        label_45:
        // 0x00B1EC1C: CBNZ x20, #0xb1ec24        | if (this.paths != null) goto label_49;  
        if(this.paths != null)
        {
            goto label_49;
        }
        // 0x00B1EC20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_49:
        // 0x00B1EC24: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00B1EC28: LDR x8, [x8, #0x7b0]       | X8 = 1152921510909120752;               
        // 0x00B1EC2C: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1EC30: MOV v0.16b, v9.16b         | V0 = targetPosition.x;//m1              
        val_30 = val_25;
        // 0x00B1EC34: MOV v1.16b, v11.16b        | V1 = (targetPosition.y + 0.85f);//m1    
        // 0x00B1EC38: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
        // 0x00B1EC3C: MOV v2.16b, v8.16b         | V2 = targetPosition.z;//m1              
        // 0x00B1EC40: BL #0x263fe28              | this.paths.Add(item:  new UnityEngine.Vector3() {x = val_30, y = val_28, z = val_24});
        this.paths.Add(item:  new UnityEngine.Vector3() {x = val_30, y = val_28, z = val_24});
        label_48:
        // 0x00B1EC44: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1EC48: CBNZ x20, #0xb1ec50        | if (this.tr != null) goto label_50;     
        if(this.tr != null)
        {
            goto label_50;
        }
        // 0x00B1EC4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.paths, ????); 
        label_50:
        // 0x00B1EC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EC54: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1EC58: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_20 = this.tr.position;
        // 0x00B1EC5C: MOV v3.16b, v9.16b         | V3 = targetPosition.x;//m1              
        // 0x00B1EC60: MOV v4.16b, v11.16b        | V4 = (targetPosition.y + 0.85f);//m1    
        // 0x00B1EC64: MOV v5.16b, v8.16b         | V5 = targetPosition.z;//m1              
        // 0x00B1EC68: BL #0xb1f0b8               | X0 = this.tr.VectorAngle(from:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z}, to:  new UnityEngine.Vector3() {x = val_25, y = val_28, z = val_24});
        float val_21 = this.tr.VectorAngle(from:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z}, to:  new UnityEngine.Vector3() {x = val_25, y = val_28, z = val_24});
        // 0x00B1EC6C: STR s0, [x19, #0x90]       | this.beforflyAngle = val_21;             //  dest_result_addr=1152921515015194048
        this.beforflyAngle = val_21;
        // 0x00B1EC70: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1EC74: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1EC78: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1EC7C: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1EC80: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1EC84: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B1EC88: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B1EC8C: LDP d13, d12, [sp], #0x80  | D13 = ; D12 = ;                          //  | 
        // 0x00B1EC90: RET                        |  return;                                
        return;
        label_41:
        // 0x00B1EC94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F0B8 (11661496), len: 308  VirtAddr: 0x00B1F0B8 RVA: 0x00B1F0B8 token: 100693575 methodIndex: 24684 delegateWrapperIndex: 0 methodInvoker: 0
    private float VectorAngle(UnityEngine.Vector3 from, UnityEngine.Vector3 to)
    {
        //
        // Disasemble & Code
        // 0x00B1F0B8: STP d13, d12, [sp, #-0x50]! | stack[1152921515015416704] = ???;  stack[1152921515015416712] = ???;  //  dest_result_addr=1152921515015416704 |  dest_result_addr=1152921515015416712
        // 0x00B1F0BC: STP d11, d10, [sp, #0x10]  | stack[1152921515015416720] = ???;  stack[1152921515015416728] = ???;  //  dest_result_addr=1152921515015416720 |  dest_result_addr=1152921515015416728
        // 0x00B1F0C0: STP d9, d8, [sp, #0x20]    | stack[1152921515015416736] = ???;  stack[1152921515015416744] = ???;  //  dest_result_addr=1152921515015416736 |  dest_result_addr=1152921515015416744
        // 0x00B1F0C4: STP x20, x19, [sp, #0x30]  | stack[1152921515015416752] = ???;  stack[1152921515015416760] = ???;  //  dest_result_addr=1152921515015416752 |  dest_result_addr=1152921515015416760
        // 0x00B1F0C8: STP x29, x30, [sp, #0x40]  | stack[1152921515015416768] = ???;  stack[1152921515015416776] = ???;  //  dest_result_addr=1152921515015416768 |  dest_result_addr=1152921515015416776
        // 0x00B1F0CC: ADD x29, sp, #0x40         | X29 = (1152921515015416704 + 64) = 1152921515015416768 (0x100000026C662BC0);
        // 0x00B1F0D0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1F0D4: LDRB w8, [x19, #0x713]     | W8 = (bool)static_value_03733713;       
        // 0x00B1F0D8: MOV v8.16b, v5.16b         | V8 = to.z;//m1                          
        // 0x00B1F0DC: MOV v9.16b, v4.16b         | V9 = to.y;//m1                          
        // 0x00B1F0E0: MOV v13.16b, v3.16b        | V13 = to.x;//m1                         
        // 0x00B1F0E4: MOV v10.16b, v2.16b        | V10 = from.z;//m1                       
        // 0x00B1F0E8: MOV v11.16b, v1.16b        | V11 = from.y;//m1                       
        // 0x00B1F0EC: MOV v12.16b, v0.16b        | V12 = from.x;//m1                       
        // 0x00B1F0F0: TBNZ w8, #0, #0xb1f10c     | if (static_value_03733713 == true) goto label_0;
        // 0x00B1F0F4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B1F0F8: LDR x8, [x8, #0x4b8]       | X8 = 0x2B8A9E8;                         
        // 0x00B1F0FC: LDR w0, [x8]               | W0 = 0x138;                             
        // 0x00B1F100: BL #0x2782188              | X0 = sub_2782188( ?? 0x138, ????);      
        // 0x00B1F104: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F108: STRB w8, [x19, #0x713]     | static_value_03733713 = true;            //  dest_result_addr=57882387
        label_0:
        // 0x00B1F10C: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B1F110: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B1F114: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B1F118: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B1F11C: TBZ w8, #0, #0xb1f12c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1F120: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F124: CBNZ w8, #0xb1f12c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1F128: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_2:
        // 0x00B1F12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F134: MOV v0.16b, v13.16b        | V0 = to.x;//m1                          
        // 0x00B1F138: MOV v1.16b, v9.16b         | V1 = to.y;//m1                          
        // 0x00B1F13C: MOV v2.16b, v8.16b         | V2 = to.z;//m1                          
        // 0x00B1F140: MOV v3.16b, v12.16b        | V3 = from.x;//m1                        
        // 0x00B1F144: MOV v4.16b, v11.16b        | V4 = from.y;//m1                        
        // 0x00B1F148: MOV v5.16b, v10.16b        | V5 = from.z;//m1                        
        // 0x00B1F14C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = to.x, y = to.y, z = to.z}, b:  new UnityEngine.Vector3() {x = from.x, y = from.y, z = from.z});
        UnityEngine.Vector3 val_1 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = to.x, y = to.y, z = to.z}, b:  new UnityEngine.Vector3() {x = from.x, y = from.y, z = from.z});
        // 0x00B1F150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F154: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F158: MOV v8.16b, v0.16b         | V8 = val_1.x;//m1                       
        // 0x00B1F15C: MOV v9.16b, v1.16b         | V9 = val_1.y;//m1                       
        // 0x00B1F160: MOV v10.16b, v2.16b        | V10 = val_1.z;//m1                      
        // 0x00B1F164: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.forward;
        // 0x00B1F168: MOV v3.16b, v0.16b         | V3 = val_2.x;//m1                       
        // 0x00B1F16C: MOV v4.16b, v1.16b         | V4 = val_2.y;//m1                       
        // 0x00B1F170: MOV v5.16b, v2.16b         | V5 = val_2.z;//m1                       
        // 0x00B1F174: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F17C: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
        // 0x00B1F180: MOV v1.16b, v9.16b         | V1 = val_1.y;//m1                       
        // 0x00B1F184: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        // 0x00B1F188: BL #0x269988c              | X0 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, rhs:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.Cross(lhs:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, rhs:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z});
        // 0x00B1F18C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F194: MOV v11.16b, v1.16b        | V11 = val_3.y;//m1                      
        // 0x00B1F198: BL #0x2693fb8              | X0 = UnityEngine.Vector3.get_forward(); 
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.forward;
        // 0x00B1F19C: MOV v3.16b, v0.16b         | V3 = val_4.x;//m1                       
        // 0x00B1F1A0: MOV v4.16b, v1.16b         | V4 = val_4.y;//m1                       
        // 0x00B1F1A4: MOV v5.16b, v2.16b         | V5 = val_4.z;//m1                       
        // 0x00B1F1A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F1AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F1B0: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
        // 0x00B1F1B4: MOV v1.16b, v9.16b         | V1 = val_1.y;//m1                       
        // 0x00B1F1B8: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        // 0x00B1F1BC: BL #0x269a014              | X0 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, to:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        float val_5 = UnityEngine.Vector3.Angle(from:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z}, to:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        // 0x00B1F1C0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1F1C4: LDR s1, [x8, #0x76c]       | S1 = 360;                               
        float val_6 = 360f;
        // 0x00B1F1C8: FCMP s11, #0.0             | STATE = COMPARE(val_3.y, 0)             
        // 0x00B1F1CC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F1D0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F1D4: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B1F1D8: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B1F1DC: FSUB s1, s1, s0            | S1 = (360f - val_5);                    
        val_6 = val_6 - val_5;
        // 0x00B1F1E0: FCSEL s0, s1, s0, gt       | S0 = val_3.y > 0 ? (360f - val_5) : val_5;
        val_5 = (val_3.y > 0f) ? (val_6) : (val_5);
        // 0x00B1F1E4: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
        // 0x00B1F1E8: RET                        |  return (System.Single)val_3.y > 0 ? (360f - val_5) : val_5;
        return (float)val_5;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1EC98 (11660440), len: 1056  VirtAddr: 0x00B1EC98 RVA: 0x00B1EC98 token: 100693576 methodIndex: 24685 delegateWrapperIndex: 0 methodInvoker: 0
    private void SetParabolaPath(System.Collections.Generic.List<UnityEngine.Vector3> _paths, int type)
    {
        //
        // Disasemble & Code
        //  | 
        float val_22;
        //  | 
        float val_23;
        //  | 
        float val_24;
        //  | 
        float val_25;
        //  | 
        float val_26;
        // 0x00B1EC98: STP d15, d14, [sp, #-0x80]! | stack[1152921515015561424] = ???;  stack[1152921515015561432] = ???;  //  dest_result_addr=1152921515015561424 |  dest_result_addr=1152921515015561432
        // 0x00B1EC9C: STP d13, d12, [sp, #0x10]  | stack[1152921515015561440] = ???;  stack[1152921515015561448] = ???;  //  dest_result_addr=1152921515015561440 |  dest_result_addr=1152921515015561448
        // 0x00B1ECA0: STP d11, d10, [sp, #0x20]  | stack[1152921515015561456] = ???;  stack[1152921515015561464] = ???;  //  dest_result_addr=1152921515015561456 |  dest_result_addr=1152921515015561464
        // 0x00B1ECA4: STP d9, d8, [sp, #0x30]    | stack[1152921515015561472] = ???;  stack[1152921515015561480] = ???;  //  dest_result_addr=1152921515015561472 |  dest_result_addr=1152921515015561480
        // 0x00B1ECA8: STP x24, x23, [sp, #0x40]  | stack[1152921515015561488] = ???;  stack[1152921515015561496] = ???;  //  dest_result_addr=1152921515015561488 |  dest_result_addr=1152921515015561496
        // 0x00B1ECAC: STP x22, x21, [sp, #0x50]  | stack[1152921515015561504] = ???;  stack[1152921515015561512] = ???;  //  dest_result_addr=1152921515015561504 |  dest_result_addr=1152921515015561512
        // 0x00B1ECB0: STP x20, x19, [sp, #0x60]  | stack[1152921515015561520] = ???;  stack[1152921515015561528] = ???;  //  dest_result_addr=1152921515015561520 |  dest_result_addr=1152921515015561528
        // 0x00B1ECB4: STP x29, x30, [sp, #0x70]  | stack[1152921515015561536] = ???;  stack[1152921515015561544] = ???;  //  dest_result_addr=1152921515015561536 |  dest_result_addr=1152921515015561544
        // 0x00B1ECB8: ADD x29, sp, #0x70         | X29 = (1152921515015561424 + 112) = 1152921515015561536 (0x100000026C686140);
        // 0x00B1ECBC: SUB sp, sp, #0x20          | SP = (1152921515015561424 - 32) = 1152921515015561392 (0x100000026C6860B0);
        // 0x00B1ECC0: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B1ECC4: LDRB w8, [x22, #0x714]     | W8 = (bool)static_value_03733714;       
        // 0x00B1ECC8: MOV w21, w2                | W21 = type;//m1                         
        // 0x00B1ECCC: MOV x20, x1                | X20 = _paths;//m1                       
        // 0x00B1ECD0: MOV x19, x0                | X19 = 1152921515015573552 (0x100000026C689030);//ML01
        // 0x00B1ECD4: TBNZ w8, #0, #0xb1ecf0     | if (static_value_03733714 == true) goto label_0;
        // 0x00B1ECD8: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00B1ECDC: LDR x8, [x8, #0x698]       | X8 = 0x2B8A9DC;                         
        // 0x00B1ECE0: LDR w0, [x8]               | W0 = 0x135;                             
        // 0x00B1ECE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x135, ????);      
        // 0x00B1ECE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1ECEC: STRB w8, [x22, #0x714]     | static_value_03733714 = true;            //  dest_result_addr=57882388
        label_0:
        // 0x00B1ECF0: STR wzr, [sp, #0x18]       | stack[1152921515015561416] = 0x0;        //  dest_result_addr=1152921515015561416
        // 0x00B1ECF4: STR xzr, [sp, #0x10]       | stack[1152921515015561408] = 0x0;        //  dest_result_addr=1152921515015561408
        // 0x00B1ECF8: LDP s8, s9, [x19, #0x54]   | S8 = this.targetPosition; //P2           //  | 
        // 0x00B1ECFC: LDR s10, [x19, #0x5c]      | 
        // 0x00B1ED00: LDR x22, [x19, #0x70]      | X22 = this.tr; //P2                     
        // 0x00B1ED04: CBNZ x22, #0xb1ed0c        | if (this.tr != null) goto label_1;      
        if(this.tr != null)
        {
            goto label_1;
        }
        // 0x00B1ED08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x135, ????);      
        label_1:
        // 0x00B1ED0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1ED10: MOV x0, x22                | X0 = this.tr;//m1                       
        // 0x00B1ED14: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_1 = this.tr.position;
        // 0x00B1ED18: ADRP x23, #0x3673000       | X23 = 57094144 (0x3673000);             
        // 0x00B1ED1C: LDR x23, [x23, #0x488]     | X23 = 1152921504695078912;              
        // 0x00B1ED20: MOV v11.16b, v0.16b        | V11 = val_1.x;//m1                      
        // 0x00B1ED24: MOV v12.16b, v1.16b        | V12 = val_1.y;//m1                      
        // 0x00B1ED28: MOV v13.16b, v2.16b        | V13 = val_1.z;//m1                      
        // 0x00B1ED2C: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B1ED30: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B1ED34: TBZ w8, #0, #0xb1ed44      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B1ED38: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B1ED3C: CBNZ w8, #0xb1ed44         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1ED40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_3:
        // 0x00B1ED44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1ED48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1ED4C: MOV v0.16b, v8.16b         | V0 = this.targetPosition;//m1           
        // 0x00B1ED50: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B1ED54: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B1ED58: MOV v3.16b, v11.16b        | V3 = val_1.x;//m1                       
        // 0x00B1ED5C: MOV v4.16b, v12.16b        | V4 = val_1.y;//m1                       
        // 0x00B1ED60: MOV v5.16b, v13.16b        | V5 = val_1.z;//m1                       
        // 0x00B1ED64: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.targetPosition, y = V9.16B, z = V10.16B}, b:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
        UnityEngine.Vector3 val_2 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = this.targetPosition, y = V9.16B, z = V10.16B}, b:  new UnityEngine.Vector3() {x = val_1.x, y = val_1.y, z = val_1.z});
        // 0x00B1ED68: FMOV s9, #9.00000000       | S9 = 9;                                 
        val_22 = 9f;
        // 0x00B1ED6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1ED70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1ED74: MOV v3.16b, v9.16b         | V3 = 9;//m1                             
        // 0x00B1ED78: BL #0x2699130              | X0 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, d:  val_22);
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Division(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, d:  val_22);
        // 0x00B1ED7C: STP s1, s0, [sp, #8]       | stack[1152921515015561400] = val_3.y;  stack[1152921515015561404] = val_3.x;  //  dest_result_addr=1152921515015561400 |  dest_result_addr=1152921515015561404
        // 0x00B1ED80: LDR x22, [x19, #0x70]      | X22 = this.tr; //P2                     
        // 0x00B1ED84: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x00B1ED88: CBNZ x22, #0xb1ed90        | if (this.tr != null) goto label_4;      
        if(this.tr != null)
        {
            goto label_4;
        }
        // 0x00B1ED8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x00B1ED90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1ED94: MOV x0, x22                | X0 = this.tr;//m1                       
        // 0x00B1ED98: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_4 = this.tr.position;
        // 0x00B1ED9C: LDP s3, s4, [x19, #0x54]   | S3 = this.targetPosition; //P2           //  | 
        // 0x00B1EDA0: LDR s5, [x19, #0x5c]       | 
        // 0x00B1EDA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EDA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EDAC: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = this.targetPosition, y = val_1.y, z = val_1.z});
        float val_5 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = this.targetPosition, y = val_1.y, z = val_1.z});
        // 0x00B1EDB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EDB4: MOV x0, x19                | X0 = 1152921515015573552 (0x100000026C689030);//ML01
        // 0x00B1EDB8: MOV v12.16b, v0.16b        | V12 = val_5;//m1                        
        float val_22 = val_5;
        // 0x00B1EDBC: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_6 = this.effCtrl;
        // 0x00B1EDC0: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00B1EDC4: CBNZ x22, #0xb1edcc        | if (val_6 != null) goto label_5;        
        if(val_6 != null)
        {
            goto label_5;
        }
        // 0x00B1EDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_5:
        // 0x00B1EDCC: LDR x22, [x22, #0x20]      | X22 = val_6.effectVO; //P2              
        // 0x00B1EDD0: FMOV s8, #0.50000000       | S8 = 0.5;                               
        // 0x00B1EDD4: CBNZ x22, #0xb1eddc        | if (val_6.effectVO != null) goto label_6;
        if(val_6.effectVO != null)
        {
            goto label_6;
        }
        // 0x00B1EDD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_6:
        // 0x00B1EDDC: ADRP x24, #0x363f000       | X24 = 56881152 (0x363F000);             
        // 0x00B1EDE0: LDR x24, [x24, #0x3b0]     | X24 = 1152921504695345152;              
        // 0x00B1EDE4: LDR s11, [x22, #0x4c]      | S11 = val_6.effectVO.parabolaHight; //P2 
        // 0x00B1EDE8: FMUL s12, s12, s8          | S12 = (val_5 * 0.5f);                   
        val_22 = val_22 * 0.5f;
        // 0x00B1EDEC: LDR x0, [x24]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B1EDF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B1EDF4: TBZ w8, #0, #0xb1ee04      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B1EDF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B1EDFC: CBNZ w8, #0xb1ee04         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B1EE00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_8:
        // 0x00B1EE04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EE08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EE0C: MOV v0.16b, v12.16b        | V0 = (val_5 * 0.5f);//m1                
        val_23 = val_22;
        // 0x00B1EE10: MOV v1.16b, v11.16b        | V1 = val_6.effectVO.parabolaHight;//m1  
        val_24 = val_6.effectVO.parabolaHight;
        // 0x00B1EE14: BL #0x1a7d7bc              | X0 = UnityEngine.Mathf.Min(a:  val_23 = val_5, b:  val_24 = val_6.effectVO.parabolaHight);
        float val_7 = UnityEngine.Mathf.Min(a:  val_23, b:  val_24);
        // 0x00B1EE18: MOV v8.16b, v0.16b         | V8 = val_7;//m1                         
        val_25 = val_7;
        // 0x00B1EE1C: CMP w21, #2                | STATE = COMPARE(type, 0x2)              
        // 0x00B1EE20: B.NE #0xb1ee44             | if (type != 2) goto label_9;            
        if(type != 2)
        {
            goto label_9;
        }
        // 0x00B1EE24: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1EE28: LDR s0, [x8, #0x918]       | S0 = 0.8;                               
        // 0x00B1EE2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EE30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EE34: FMUL s1, s8, s0            | S1 = (val_7 * 0.8f);                    
        val_24 = val_25 * 0.8f;
        // 0x00B1EE38: MOV v0.16b, v8.16b         | V0 = val_7;//m1                         
        val_23 = val_25;
        // 0x00B1EE3C: BL #0x1b806dc              | X0 = UnityEngine.Random.Range(min:  val_23 = val_25, max:  val_24 = val_25 * 0.8f);
        float val_8 = UnityEngine.Random.Range(min:  val_23, max:  val_24);
        // 0x00B1EE40: MOV v8.16b, v0.16b         | V8 = val_8;//m1                         
        val_25 = val_8;
        label_9:
        // 0x00B1EE44: LDR x22, [x19, #0x70]      | X22 = this.tr; //P2                     
        // 0x00B1EE48: CBNZ x22, #0xb1ee50        | if (this.tr != null) goto label_10;     
        if(this.tr != null)
        {
            goto label_10;
        }
        // 0x00B1EE4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_10:
        // 0x00B1EE50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EE54: MOV x0, x22                | X0 = this.tr;//m1                       
        // 0x00B1EE58: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_9 = this.tr.position;
        // 0x00B1EE5C: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B1EE60: LDP s12, s11, [x19, #0x54] | S12 = this.targetPosition; //P2          //  | 
        // 0x00B1EE64: LDR s15, [x19, #0x5c]      | 
        // 0x00B1EE68: MOV v14.16b, v1.16b        | V14 = val_9.y;//m1                      
        // 0x00B1EE6C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B1EE70: MOV v13.16b, v2.16b        | V13 = val_9.z;//m1                      
        // 0x00B1EE74: TBZ w8, #0, #0xb1ee90      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B1EE78: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B1EE7C: CBNZ w8, #0xb1ee90         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B1EE80: MOV v9.16b, v0.16b         | V9 = val_9.x;//m1                       
        // 0x00B1EE84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        // 0x00B1EE88: MOV v0.16b, v9.16b         | V0 = val_9.x;//m1                       
        val_23 = val_9.x;
        // 0x00B1EE8C: FMOV s9, #9.00000000       | S9 = 9;                                 
        val_22 = 9f;
        label_12:
        // 0x00B1EE90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EE94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EE98: MOV v1.16b, v14.16b        | V1 = val_9.y;//m1                       
        // 0x00B1EE9C: MOV v2.16b, v13.16b        | V2 = val_9.z;//m1                       
        // 0x00B1EEA0: MOV v3.16b, v12.16b        | V3 = this.targetPosition;//m1           
        // 0x00B1EEA4: MOV v4.16b, v11.16b        | V4 = val_6.effectVO.parabolaHight;//m1  
        // 0x00B1EEA8: MOV v5.16b, v15.16b        | V5 = V15.16B;//m1                       
        // 0x00B1EEAC: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_23, y = val_9.y, z = val_9.z}, b:  new UnityEngine.Vector3() {x = this.targetPosition, y = val_6.effectVO.parabolaHight, z = V15.16B});
        float val_10 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_23, y = val_9.y, z = val_9.z}, b:  new UnityEngine.Vector3() {x = this.targetPosition, y = val_6.effectVO.parabolaHight, z = V15.16B});
        // 0x00B1EEB0: MOV v13.16b, v0.16b        | V13 = val_10;//m1                       
        // 0x00B1EEB4: CMP w21, #2                | STATE = COMPARE(type, 0x2)              
        // 0x00B1EEB8: B.NE #0xb1eee0             | if (type != 2) goto label_13;           
        if(type != 2)
        {
            goto label_13;
        }
        // 0x00B1EEBC: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1EEC0: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B1EEC4: LDR s0, [x8, #0x920]       | S0 = 0.3490659;                         
        // 0x00B1EEC8: LDR s1, [x9, #0x924]       | S1 = 2.792527;                          
        // 0x00B1EECC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EED4: BL #0x1b806dc              | X0 = UnityEngine.Random.Range(min:  0.3490659f, max:  2.792527f);
        float val_11 = UnityEngine.Random.Range(min:  0.3490659f, max:  2.792527f);
        // 0x00B1EED8: MOV v14.16b, v0.16b        | V14 = val_11;//m1                       
        val_26 = val_11;
        // 0x00B1EEDC: B #0xb1eee8                |  goto label_14;                         
        goto label_14;
        label_13:
        // 0x00B1EEE0: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1EEE4: LDR s14, [x8, #0x91c]      | S14 = 1.570796;                         
        val_26 = 1.570796f;
        label_14:
        // 0x00B1EEE8: LDR x0, [x24]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B1EEEC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B1EEF0: TBZ w8, #0, #0xb1ef00      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B1EEF4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B1EEF8: CBNZ w8, #0xb1ef00         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B1EEFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_16:
        // 0x00B1EF00: MOV v0.16b, v14.16b        | V0 = 1070141403 (0x3FC90FDB);//ML01     
        // 0x00B1EF04: BL #0x981480               | X0 = sub_981480( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00B1EF08: MOV v11.16b, v0.16b        | V11 = 1070141403 (0x3FC90FDB);//ML01    
        // 0x00B1EF0C: MOV v0.16b, v14.16b        | V0 = 1070141403 (0x3FC90FDB);//ML01     
        // 0x00B1EF10: BL #0x9811b0               | X0 = sub_9811B0( ?? typeof(UnityEngine.Mathf), ????);
        // 0x00B1EF14: MOV v1.16b, v0.16b         | V1 = 1070141403 (0x3FC90FDB);//ML01     
        // 0x00B1EF18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EF1C: FMOV s2, wzr               | S2 = 0f;                                
        // 0x00B1EF20: ADD x0, sp, #0x10          | X0 = (1152921515015561392 + 16) = 1152921515015561408 (0x100000026C6860C0);
        // 0x00B1EF24: MOV v0.16b, v11.16b        | V0 = 1070141403 (0x3FC90FDB);//ML01     
        // 0x00B1EF28: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B1EF2C: ADRP x24, #0x361b000       | X24 = 56733696 (0x361B000);             
        // 0x00B1EF30: LDR x24, [x24, #0x7b0]     | X24 = 1152921510909120752;              
        // 0x00B1EF34: FMOV s0, #-4.00000000      | S0 = -4;                                
        float val_23 = -4f;
        // 0x00B1EF38: FMOV s2, #4.00000000       | S2 = 4;                                 
        float val_24 = 4f;
        // 0x00B1EF3C: FMUL s1, s13, s13          | S1 = (val_10 * val_10);                 
        float val_12 = val_10 * val_10;
        // 0x00B1EF40: FMUL s0, s8, s0            | S0 = (val_8 * -4f);                     
        val_23 = val_25 * val_23;
        // 0x00B1EF44: FMUL s2, s8, s2            | S2 = (val_8 * 4f);                      
        val_24 = val_25 * val_24;
        // 0x00B1EF48: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        var val_25 = 0;
        // 0x00B1EF4C: FDIV s15, s13, s9          | S15 = (val_10 / val_22);                
        float val_13 = val_10 / val_22;
        // 0x00B1EF50: FDIV s8, s0, s1            | S8 = ((val_8 * -4f) / (val_10 * val_10));
        val_25 = val_23 / val_12;
        // 0x00B1EF54: FDIV s9, s2, s13           | S9 = ((val_8 * 4f) / val_10);           
        float val_14 = val_24 / val_10;
        label_21:
        // 0x00B1EF58: LDR x21, [x19, #0x70]      | X21 = this.tr; //P2                     
        // 0x00B1EF5C: CBNZ x21, #0xb1ef64        | if (this.tr != null) goto label_17;     
        if(this.tr != null)
        {
            goto label_17;
        }
        // 0x00B1EF60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000026C6860C0, ????);
        label_17:
        // 0x00B1EF64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EF68: MOV x0, x21                | X0 = this.tr;//m1                       
        // 0x00B1EF6C: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_15 = this.tr.position;
        // 0x00B1EF70: LDR x0, [x23]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B1EF74: MOV v11.16b, v0.16b        | V11 = val_15.x;//m1                     
        // 0x00B1EF78: MOV v12.16b, v1.16b        | V12 = val_15.y;//m1                     
        // 0x00B1EF7C: MOV v13.16b, v2.16b        | V13 = val_15.z;//m1                     
        // 0x00B1EF80: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B1EF84: TBZ w8, #0, #0xb1ef94      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B1EF88: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B1EF8C: CBNZ w8, #0xb1ef94         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B1EF90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_19:
        // 0x00B1EF94: LDP s2, s1, [sp, #8]       | S2 = val_3.y; S1 = val_3.x;              //  | 
        // 0x00B1EF98: SCVTF s14, w22             | S14 = 0;                                
        // 0x00B1EF9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EFA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EFA4: MOV v0.16b, v14.16b        | V0 = 0;//m1                             
        // 0x00B1EFA8: MOV v3.16b, v10.16b        | V3 = val_3.z;//m1                       
        // 0x00B1EFAC: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  0f, a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Multiply(d:  0f, a:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        // 0x00B1EFB0: MOV v3.16b, v0.16b         | V3 = val_16.x;//m1                      
        // 0x00B1EFB4: MOV v4.16b, v1.16b         | V4 = val_16.y;//m1                      
        // 0x00B1EFB8: MOV v5.16b, v2.16b         | V5 = val_16.z;//m1                      
        // 0x00B1EFBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1EFC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1EFC4: MOV v0.16b, v11.16b        | V0 = val_15.x;//m1                      
        // 0x00B1EFC8: MOV v1.16b, v12.16b        | V1 = val_15.y;//m1                      
        // 0x00B1EFCC: MOV v2.16b, v13.16b        | V2 = val_15.z;//m1                      
        // 0x00B1EFD0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        UnityEngine.Vector3 val_17 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z}, b:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z});
        // 0x00B1EFD4: MOV v11.16b, v0.16b        | V11 = val_17.x;//m1                     
        // 0x00B1EFD8: MOV v12.16b, v1.16b        | V12 = val_17.y;//m1                     
        // 0x00B1EFDC: MOV v13.16b, v2.16b        | V13 = val_17.z;//m1                     
        // 0x00B1EFE0: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B1EFE4: LDR s2, [sp, #0x18]        | S2 = 0;                                 
        // 0x00B1EFE8: FMUL s3, s15, s14          | S3 = ((val_10 / val_22) * 0f);          
        float val_18 = val_13 * 0f;
        // 0x00B1EFEC: FMUL s4, s8, s3            | S4 = (((val_8 * -4f) / (val_10 * val_10)) * ((val_10 / val_22) * 0f));
        float val_19 = val_25 * val_18;
        // 0x00B1EFF0: FMUL s4, s3, s4            | S4 = (((val_10 / val_22) * 0f) * (((val_8 * -4f) / (val_10 * val_10)) * ((val_10 / val_22) * 0f)));
        val_19 = val_18 * val_19;
        // 0x00B1EFF4: FMUL s3, s9, s3            | S3 = (((val_8 * 4f) / val_10) * ((val_10 / val_22) * 0f));
        val_18 = val_14 * val_18;
        // 0x00B1EFF8: FADD s3, s3, s4            | S3 = ((((val_8 * 4f) / val_10) * ((val_10 / val_22) * 0f)) + (((val_10 / val_22) * 0f) * (((val_8 * -4f) / (val_10 * val_10)) * ((val_10 / val_22) * 0f))));
        val_18 = val_18 + val_19;
        // 0x00B1EFFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F004: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, d:  val_18 = val_18 + val_19);
        UnityEngine.Vector3 val_20 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f}, d:  val_18);
        // 0x00B1F008: MOV v3.16b, v0.16b         | V3 = val_20.x;//m1                      
        // 0x00B1F00C: MOV v4.16b, v1.16b         | V4 = val_20.y;//m1                      
        // 0x00B1F010: MOV v5.16b, v2.16b         | V5 = val_20.z;//m1                      
        // 0x00B1F014: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F01C: MOV v0.16b, v11.16b        | V0 = val_17.x;//m1                      
        // 0x00B1F020: MOV v1.16b, v12.16b        | V1 = val_17.y;//m1                      
        // 0x00B1F024: MOV v2.16b, v13.16b        | V2 = val_17.z;//m1                      
        // 0x00B1F028: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, b:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z});
        UnityEngine.Vector3 val_21 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, b:  new UnityEngine.Vector3() {x = val_20.x, y = val_20.y, z = val_20.z});
        // 0x00B1F02C: MOV v11.16b, v0.16b        | V11 = val_21.x;//m1                     
        // 0x00B1F030: MOV v12.16b, v1.16b        | V12 = val_21.y;//m1                     
        // 0x00B1F034: MOV v13.16b, v2.16b        | V13 = val_21.z;//m1                     
        // 0x00B1F038: CBNZ x20, #0xb1f040        | if (_paths != null) goto label_20;      
        if(_paths != null)
        {
            goto label_20;
        }
        // 0x00B1F03C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_20:
        // 0x00B1F040: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
        // 0x00B1F044: MOV x0, x20                | X0 = _paths;//m1                        
        // 0x00B1F048: MOV v0.16b, v11.16b        | V0 = val_21.x;//m1                      
        // 0x00B1F04C: MOV v1.16b, v12.16b        | V1 = val_21.y;//m1                      
        // 0x00B1F050: MOV v2.16b, v13.16b        | V2 = val_21.z;//m1                      
        // 0x00B1F054: BL #0x263fe28              | _paths.Add(item:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        _paths.Add(item:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        // 0x00B1F058: ADD w22, w22, #1           | W22 = (0 + 1);                          
        val_25 = val_25 + 1;
        // 0x00B1F05C: CMP w22, #9                | STATE = COMPARE((0 + 1), 0x9)           
        // 0x00B1F060: B.NE #0xb1ef58             | if (0 != 0x9) goto label_21;            
        if(val_25 != 9)
        {
            goto label_21;
        }
        // 0x00B1F064: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1F068: LDP s8, s9, [x19, #0x54]   | S8 = this.targetPosition; //P2           //  | 
        // 0x00B1F06C: LDR s10, [x19, #0x5c]      | 
        // 0x00B1F070: CBNZ x20, #0xb1f078        | if (this.paths != null) goto label_22;  
        if(this.paths != null)
        {
            goto label_22;
        }
        // 0x00B1F074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? _paths, ????);     
        label_22:
        // 0x00B1F078: LDR x1, [x24]              | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
        // 0x00B1F07C: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1F080: MOV v0.16b, v8.16b         | V0 = this.targetPosition;//m1           
        // 0x00B1F084: MOV v1.16b, v9.16b         | V1 = ((val_8 * 4f) / val_10);//m1       
        // 0x00B1F088: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x00B1F08C: BL #0x263fe28              | this.paths.Add(item:  new UnityEngine.Vector3() {x = this.targetPosition, y = val_14, z = val_3.z});
        this.paths.Add(item:  new UnityEngine.Vector3() {x = this.targetPosition, y = val_14, z = val_3.z});
        // 0x00B1F090: SUB sp, x29, #0x70         | SP = (1152921515015561536 - 112) = 1152921515015561424 (0x100000026C6860D0);
        // 0x00B1F094: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F098: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F09C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F0A0: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1F0A4: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B1F0A8: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B1F0AC: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B1F0B0: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00B1F0B4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F1EC (11661804), len: 456  VirtAddr: 0x00B1F1EC RVA: 0x00B1F1EC token: 100693577 methodIndex: 24686 delegateWrapperIndex: 0 methodInvoker: 0
    private void MoveEnd()
    {
        //
        // Disasemble & Code
        // 0x00B1F1EC: STP d9, d8, [sp, #-0x40]!  | stack[1152921515015731856] = ???;  stack[1152921515015731864] = ???;  //  dest_result_addr=1152921515015731856 |  dest_result_addr=1152921515015731864
        // 0x00B1F1F0: STP x22, x21, [sp, #0x10]  | stack[1152921515015731872] = ???;  stack[1152921515015731880] = ???;  //  dest_result_addr=1152921515015731872 |  dest_result_addr=1152921515015731880
        // 0x00B1F1F4: STP x20, x19, [sp, #0x20]  | stack[1152921515015731888] = ???;  stack[1152921515015731896] = ???;  //  dest_result_addr=1152921515015731888 |  dest_result_addr=1152921515015731896
        // 0x00B1F1F8: STP x29, x30, [sp, #0x30]  | stack[1152921515015731904] = ???;  stack[1152921515015731912] = ???;  //  dest_result_addr=1152921515015731904 |  dest_result_addr=1152921515015731912
        // 0x00B1F1FC: ADD x29, sp, #0x30         | X29 = (1152921515015731856 + 48) = 1152921515015731904 (0x100000026C6AFAC0);
        // 0x00B1F200: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1F204: LDRB w8, [x20, #0x715]     | W8 = (bool)static_value_03733715;       
        // 0x00B1F208: MOV x19, x0                | X19 = 1152921515015743920 (0x100000026C6B29B0);//ML01
        // 0x00B1F20C: TBNZ w8, #0, #0xb1f228     | if (static_value_03733715 == true) goto label_0;
        // 0x00B1F210: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00B1F214: LDR x8, [x8, #0x488]       | X8 = 0x2B8A9C8;                         
        // 0x00B1F218: LDR w0, [x8]               | W0 = 0x130;                             
        // 0x00B1F21C: BL #0x2782188              | X0 = sub_2782188( ?? 0x130, ????);      
        // 0x00B1F220: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F224: STRB w8, [x20, #0x715]     | static_value_03733715 = true;            //  dest_result_addr=57882389
        label_0:
        // 0x00B1F228: LDR x8, [x19, #0x60]       | X8 = this.IsDo; //P2                    
        bool val_8 = this.IsDo;
        // 0x00B1F22C: STRB wzr, [x19, #0x60]     | this.IsDo = false;                       //  dest_result_addr=1152921515015744016
        this.IsDo = false;
        // 0x00B1F230: AND w9, w8, #0xff          | W9 = (this.IsDo & 255);                 
        bool val_1 = val_8 & 255;
        // 0x00B1F234: CBZ w9, #0xb1f388          | if ((this.IsDo & 255) == false) goto label_1;
        if(val_1 == false)
        {
            goto label_1;
        }
        // 0x00B1F238: LSR x8, x8, #0x20          | X8 = (this.IsDo >> 32);                 
        val_8 = val_8 >> 32;
        // 0x00B1F23C: FMOV s0, w8                | S0 = ((this.IsDo >> 32));               
        // 0x00B1F240: FCMP s0, #0.0              | STATE = COMPARE((this.IsDo >> 32), 0)   
        // 0x00B1F244: B.LE #0xb1f39c             | if (this.IsDo <= 0) goto label_2;       
        if(val_8 <= 0f)
        {
            goto label_2;
        }
        // 0x00B1F248: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F24C: MOV x0, x19                | X0 = 1152921515015743920 (0x100000026C6B29B0);//ML01
        // 0x00B1F250: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_2 = this.effCtrl;
        // 0x00B1F254: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1F258: CBNZ x20, #0xb1f260        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00B1F25C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B1F260: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1F264: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B1F268: LDR x20, [x20, #0xc8]      | X20 = val_2.trailTr; //P2               
        // 0x00B1F26C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B1F270: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1F274: TBZ w8, #0, #0xb1f284      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B1F278: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F27C: CBNZ w8, #0xb1f284         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B1F280: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00B1F284: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F288: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F28C: MOV x1, x20                | X1 = val_2.trailTr;//m1                 
        // 0x00B1F290: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1F294: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_2.trailTr);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  val_2.trailTr);
        // 0x00B1F298: TBZ w0, #0, #0xb1f2e8      | if (val_3 == false) goto label_6;       
        if(val_3 == false)
        {
            goto label_6;
        }
        // 0x00B1F29C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F2A0: MOV x0, x19                | X0 = 1152921515015743920 (0x100000026C6B29B0);//ML01
        // 0x00B1F2A4: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_4 = this.effCtrl;
        // 0x00B1F2A8: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B1F2AC: CBNZ x20, #0xb1f2b4        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00B1F2B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00B1F2B4: LDR x20, [x20, #0xc8]      | X20 = val_4.trailTr; //P2               
        // 0x00B1F2B8: CBNZ x20, #0xb1f2c0        | if (val_4.trailTr != null) goto label_8;
        if(val_4.trailTr != null)
        {
            goto label_8;
        }
        // 0x00B1F2BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00B1F2C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F2C4: MOV x0, x20                | X0 = val_4.trailTr;//m1                 
        // 0x00B1F2C8: BL #0x20d50fc              | X0 = val_4.trailTr.get_gameObject();    
        UnityEngine.GameObject val_5 = val_4.trailTr.gameObject;
        // 0x00B1F2CC: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B1F2D0: CBNZ x20, #0xb1f2d8        | if (val_5 != null) goto label_9;        
        if(val_5 != null)
        {
            goto label_9;
        }
        // 0x00B1F2D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B1F2D8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1F2DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F2E0: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B1F2E4: BL #0x1a62d64              | val_5.SetActive(value:  false);         
        val_5.SetActive(value:  false);
        label_6:
        // 0x00B1F2E8: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B1F2EC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00B1F2F0: LDR x20, [x19, #0x80]      | X20 = this.delayList; //P2              
        // 0x00B1F2F4: LDR s8, [x19, #0x64]       | S8 = this.trailtime; //P2               
        // 0x00B1F2F8: LDR x8, [x8, #0xcc8]       | X8 = 1152921515015718896;               
        // 0x00B1F2FC: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00B1F300: LDR x22, [x8]              | X22 = System.Void ActorBullet::OnEnd(); 
        // 0x00B1F304: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_6 = null;
        // 0x00B1F308: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00B1F30C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1F310: MOV x1, x19                | X1 = 1152921515015743920 (0x100000026C6B29B0);//ML01
        // 0x00B1F314: MOV x2, x22                | X2 = 1152921515015718896 (0x100000026C6AC7F0);//ML01
        // 0x00B1F318: MOV x21, x0                | X21 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1F31C: BL #0x26e30f0              | .ctor(object:  this, method:  System.Void ActorBullet::OnEnd());
        val_6 = new System.Action(object:  this, method:  System.Void ActorBullet::OnEnd());
        // 0x00B1F320: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00B1F324: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00B1F328: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00B1F32C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B1F330: TBZ w8, #0, #0xb1f340      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B1F334: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F338: CBNZ w8, #0xb1f340         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B1F33C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_11:
        // 0x00B1F340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F344: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F348: MOV v0.16b, v8.16b         | V0 = this.trailtime;//m1                
        // 0x00B1F34C: MOV x1, x21                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00B1F350: BL #0xb8e194               | X0 = BehaviourUtil.DelayCall(delaytime:  this.trailtime, act:  0);
        uint val_7 = BehaviourUtil.DelayCall(delaytime:  this.trailtime, act:  0);
        // 0x00B1F354: MOV w19, w0                | W19 = val_7;//m1                        
        // 0x00B1F358: CBNZ x20, #0xb1f360        | if (this.delayList != null) goto label_12;
        if(this.delayList != null)
        {
            goto label_12;
        }
        // 0x00B1F35C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_12:
        // 0x00B1F360: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B1F364: LDR x8, [x8, #0xc78]       | X8 = 1152921510901563856;               
        // 0x00B1F368: MOV x0, x20                | X0 = this.delayList;//m1                
        // 0x00B1F36C: MOV w1, w19                | W1 = val_7;//m1                         
        // 0x00B1F370: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<System.UInt32>::Add(System.UInt32 item);
        // 0x00B1F374: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F378: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F37C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F380: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B1F384: B #0x256d4c0               | this.delayList.Add(item:  val_7); return;
        this.delayList.Add(item:  val_7);
        return;
        label_1:
        // 0x00B1F388: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F38C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F390: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F394: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B1F398: RET                        |  return;                                
        return;
        label_2:
        // 0x00B1F39C: MOV x0, x19                | X0 = 1152921515015743920 (0x100000026C6B29B0);//ML01
        // 0x00B1F3A0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F3A4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F3A8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F3AC: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x00B1F3B0: B #0xb1f3b4                | this.OnEnd(); return;                   
        this.OnEnd();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F3B4 (11662260), len: 520  VirtAddr: 0x00B1F3B4 RVA: 0x00B1F3B4 token: 100693578 methodIndex: 24687 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEnd()
    {
        //
        // Disasemble & Code
        //  | 
        CombatEntity val_6;
        // 0x00B1F3B4: STP x22, x21, [sp, #-0x30]! | stack[1152921515015905312] = ???;  stack[1152921515015905320] = ???;  //  dest_result_addr=1152921515015905312 |  dest_result_addr=1152921515015905320
        // 0x00B1F3B8: STP x20, x19, [sp, #0x10]  | stack[1152921515015905328] = ???;  stack[1152921515015905336] = ???;  //  dest_result_addr=1152921515015905328 |  dest_result_addr=1152921515015905336
        // 0x00B1F3BC: STP x29, x30, [sp, #0x20]  | stack[1152921515015905344] = ???;  stack[1152921515015905352] = ???;  //  dest_result_addr=1152921515015905344 |  dest_result_addr=1152921515015905352
        // 0x00B1F3C0: ADD x29, sp, #0x20         | X29 = (1152921515015905312 + 32) = 1152921515015905344 (0x100000026C6DA040);
        // 0x00B1F3C4: SUB sp, sp, #0x10          | SP = (1152921515015905312 - 16) = 1152921515015905296 (0x100000026C6DA010);
        // 0x00B1F3C8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1F3CC: LDRB w8, [x20, #0x716]     | W8 = (bool)static_value_03733716;       
        // 0x00B1F3D0: MOV x19, x0                | X19 = 1152921515015917360 (0x100000026C6DCF30);//ML01
        // 0x00B1F3D4: TBNZ w8, #0, #0xb1f3f0     | if (static_value_03733716 == true) goto label_0;
        // 0x00B1F3D8: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
        // 0x00B1F3DC: LDR x8, [x8, #0x600]       | X8 = 0x2B8A9CC;                         
        // 0x00B1F3E0: LDR w0, [x8]               | W0 = 0x131;                             
        // 0x00B1F3E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x131, ????);      
        // 0x00B1F3E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F3EC: STRB w8, [x20, #0x716]     | static_value_03733716 = true;            //  dest_result_addr=57882390
        label_0:
        // 0x00B1F3F0: LDR x20, [x19, #0x80]      | X20 = this.delayList; //P2              
        // 0x00B1F3F4: CBNZ x20, #0xb1f3fc        | if (this.delayList != null) goto label_1;
        if(this.delayList != null)
        {
            goto label_1;
        }
        // 0x00B1F3F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x131, ????);      
        label_1:
        // 0x00B1F3FC: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B1F400: LDR x8, [x8, #0x390]       | X8 = 1152921510901223120;               
        // 0x00B1F404: MOV x0, x20                | X0 = this.delayList;//m1                
        // 0x00B1F408: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.UInt32>::Clear();
        // 0x00B1F40C: BL #0x256dd68              | this.delayList.Clear();                 
        this.delayList.Clear();
        // 0x00B1F410: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00B1F414: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00B1F418: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00B1F41C: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B1F420: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B1F424: CBNZ x20, #0xb1f42c        | if (GameMgr.UPDATEOnOffEffect != null) goto label_2;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_2;
        }
        // 0x00B1F428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.delayList, ????);
        label_2:
        // 0x00B1F42C: LDR x20, [x20, #0x48]      | X20 = GameMgr.UPDATEOnOffEffect + 72;    //  not_find_field!2:72
        // 0x00B1F430: LDR x21, [x19, #0x20]      | X21 = this.host; //P2                   
        val_6 = this.host;
        // 0x00B1F434: LDR w22, [x19, #0x28]      | W22 = this.skillID; //P2                
        // 0x00B1F438: CBNZ x20, #0xb1f440        | if (GameMgr.UPDATEOnOffEffect + 72 != 0) goto label_3;
        if((GameMgr.UPDATEOnOffEffect + 72) != 0)
        {
            goto label_3;
        }
        // 0x00B1F43C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.delayList, ????);
        label_3:
        // 0x00B1F440: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1F444: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect + 72;//m1
        // 0x00B1F448: MOV x1, x21                | X1 = this.host;//m1                     
        // 0x00B1F44C: MOV w2, w22                | W2 = this.skillID;//m1                  
        // 0x00B1F450: BL #0xae6230               | GameMgr.UPDATEOnOffEffect + 72.RemoveShootSkillChild(hero:  val_6, skillId:  this.skillID);
        GameMgr.UPDATEOnOffEffect + 72.RemoveShootSkillChild(hero:  val_6, skillId:  this.skillID);
        // 0x00B1F454: LDR x20, [x19, #0x98]      | X20 = this.triggerEntityList; //P2      
        // 0x00B1F458: CBNZ x20, #0xb1f460        | if (this.triggerEntityList != null) goto label_4;
        if(this.triggerEntityList != null)
        {
            goto label_4;
        }
        // 0x00B1F45C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? GameMgr.UPDATEOnOffEffect + 72, ????);
        label_4:
        // 0x00B1F460: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B1F464: LDR x8, [x8, #0xf48]       | X8 = 1152921514610604624;               
        // 0x00B1F468: MOV x0, x20                | X0 = this.triggerEntityList;//m1        
        // 0x00B1F46C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CombatEntity>::Clear();
        // 0x00B1F470: BL #0x25ead28              | this.triggerEntityList.Clear();         
        this.triggerEntityList.Clear();
        // 0x00B1F474: ADRP x22, #0x3668000       | X22 = 57049088 (0x3668000);             
        // 0x00B1F478: LDR x22, [x22, #0x960]     | X22 = 1152921504911851520;              
        // 0x00B1F47C: LDR x0, [x22]              | X0 = typeof(ZMG);                       
        // 0x00B1F480: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B1F484: TBZ w8, #0, #0xb1f494      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B1F488: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F48C: CBNZ w8, #0xb1f494         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B1F490: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_6:
        // 0x00B1F494: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F49C: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_1 = ZMG.CameraShotMgr;
        // 0x00B1F4A0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B1F4A4: CBNZ x20, #0xb1f4ac        | if (val_1 != null) goto label_7;        
        if(val_1 != null)
        {
            goto label_7;
        }
        // 0x00B1F4A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x00B1F4AC: LDRB w8, [x20, #0x44]      | W8 = val_1.isCameraShotRunning; //P2    
        // 0x00B1F4B0: CBZ w8, #0xb1f558          | if (val_1.isCameraShotRunning == false) goto label_8;
        if(val_1.isCameraShotRunning == false)
        {
            goto label_8;
        }
        // 0x00B1F4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F4B8: MOV x0, x19                | X0 = 1152921515015917360 (0x100000026C6DCF30);//ML01
        // 0x00B1F4BC: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_2 = this.effCtrl;
        // 0x00B1F4C0: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1F4C4: CBNZ x20, #0xb1f4cc        | if (val_2 != null) goto label_9;        
        if(val_2 != null)
        {
            goto label_9;
        }
        // 0x00B1F4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_9:
        // 0x00B1F4CC: LDR x20, [x20, #0x20]      | X20 = val_2.effectVO; //P2              
        // 0x00B1F4D0: CBNZ x20, #0xb1f4d8        | if (val_2.effectVO != null) goto label_10;
        if(val_2.effectVO != null)
        {
            goto label_10;
        }
        // 0x00B1F4D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_10:
        // 0x00B1F4D8: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
        // 0x00B1F4DC: LDR w8, [x20, #0x10]       | W8 = val_2.effectVO.id; //P2            
        // 0x00B1F4E0: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
        // 0x00B1F4E4: ADD x1, sp, #0xc           | X1 = (1152921515015905296 + 12) = 1152921515015905308 (0x100000026C6DA01C);
        // 0x00B1F4E8: STR w8, [sp, #0xc]         | stack[1152921515015905308] = val_2.effectVO.id;  //  dest_result_addr=1152921515015905308
        // 0x00B1F4EC: LDR x0, [x9]               | X0 = typeof(System.Int32);              
        // 0x00B1F4F0: BL #0x27bc028              | X0 = 1152921515015973936 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_2.effectVO.id);
        // 0x00B1F4F4: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00B1F4F8: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00B1F4FC: MOV x21, x0                | X21 = 1152921515015973936 (0x100000026C6EAC30);//ML01
        val_6 = val_2.effectVO.id;
        // 0x00B1F500: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00B1F504: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        CEvent.ZEvent val_3 = null;
        // 0x00B1F508: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00B1F50C: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00B1F510: LDR x8, [x8, #0xb0]        | X8 = (string**)(1152921510322335888)("SHOOTEFFECT_DONE");
        // 0x00B1F514: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1F518: MOV x2, x21                | X2 = 1152921515015973936 (0x100000026C6EAC30);//ML01
        // 0x00B1F51C: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B1F520: LDR x1, [x8]               | X1 = "SHOOTEFFECT_DONE";                
        // 0x00B1F524: BL #0xd7de54               | .ctor(name:  "SHOOTEFFECT_DONE", arg:  val_2.effectVO.id);
        val_3 = new CEvent.ZEvent(name:  "SHOOTEFFECT_DONE", arg:  val_2.effectVO.id);
        // 0x00B1F528: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00B1F52C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00B1F530: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00B1F534: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00B1F538: TBZ w8, #0, #0xb1f548      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B1F53C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F540: CBNZ w8, #0xb1f548         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B1F544: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_12:
        // 0x00B1F548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F54C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F550: MOV x1, x20                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00B1F554: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  0);
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        label_8:
        // 0x00B1F558: LDR x0, [x22]              | X0 = typeof(ZMG);                       
        // 0x00B1F55C: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00B1F560: TBZ w8, #0, #0xb1f570      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B1F564: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F568: CBNZ w8, #0xb1f570         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B1F56C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_14:
        // 0x00B1F570: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F578: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_4 = ZMG.EffectMgr;
        // 0x00B1F57C: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B1F580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F584: MOV x0, x19                | X0 = 1152921515015917360 (0x100000026C6DCF30);//ML01
        // 0x00B1F588: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_5 = this.effCtrl;
        // 0x00B1F58C: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B1F590: CBNZ x20, #0xb1f598        | if (val_4 != null) goto label_15;       
        if(val_4 != null)
        {
            goto label_15;
        }
        // 0x00B1F594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_15:
        // 0x00B1F598: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F59C: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B1F5A0: MOV x1, x19                | X1 = val_5;//m1                         
        // 0x00B1F5A4: BL #0xb60074               | val_4.ResetEffectGameObject(effectObj:  val_5);
        val_4.ResetEffectGameObject(effectObj:  val_5);
        // 0x00B1F5A8: SUB sp, x29, #0x20         | SP = (1152921515015905344 - 32) = 1152921515015905312 (0x100000026C6DA020);
        // 0x00B1F5AC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F5B0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F5B4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F5B8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F5BC (11662780), len: 148  VirtAddr: 0x00B1F5BC RVA: 0x00B1F5BC token: 100693579 methodIndex: 24688 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(UnityEngine.GameObject effGO)
    {
        //
        // Disasemble & Code
        // 0x00B1F5BC: STP x22, x21, [sp, #-0x30]! | stack[1152921515016070560] = ???;  stack[1152921515016070568] = ???;  //  dest_result_addr=1152921515016070560 |  dest_result_addr=1152921515016070568
        // 0x00B1F5C0: STP x20, x19, [sp, #0x10]  | stack[1152921515016070576] = ???;  stack[1152921515016070584] = ???;  //  dest_result_addr=1152921515016070576 |  dest_result_addr=1152921515016070584
        // 0x00B1F5C4: STP x29, x30, [sp, #0x20]  | stack[1152921515016070592] = ???;  stack[1152921515016070600] = ???;  //  dest_result_addr=1152921515016070592 |  dest_result_addr=1152921515016070600
        // 0x00B1F5C8: ADD x29, sp, #0x20         | X29 = (1152921515016070560 + 32) = 1152921515016070592 (0x100000026C7025C0);
        // 0x00B1F5CC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B1F5D0: LDRB w8, [x21, #0x717]     | W8 = (bool)static_value_03733717;       
        // 0x00B1F5D4: MOV x20, x1                | X20 = effGO;//m1                        
        // 0x00B1F5D8: MOV x19, x0                | X19 = 1152921515016082608 (0x100000026C7054B0);//ML01
        // 0x00B1F5DC: TBNZ w8, #0, #0xb1f5f8     | if (static_value_03733717 == true) goto label_0;
        // 0x00B1F5E0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B1F5E4: LDR x8, [x8, #0x9b8]       | X8 = 0x2B8A9C4;                         
        // 0x00B1F5E8: LDR w0, [x8]               | W0 = 0x12F;                             
        // 0x00B1F5EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x12F, ????);      
        // 0x00B1F5F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F5F4: STRB w8, [x21, #0x717]     | static_value_03733717 = true;            //  dest_result_addr=57882391
        label_0:
        // 0x00B1F5F8: CBZ x20, #0xb1f610         | if (effGO == null) goto label_1;        
        if(effGO == null)
        {
            goto label_1;
        }
        // 0x00B1F5FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F600: MOV x0, x20                | X0 = effGO;//m1                         
        // 0x00B1F604: BL #0x1a62c1c              | X0 = effGO.get_transform();             
        UnityEngine.Transform val_1 = effGO.transform;
        // 0x00B1F608: STR x0, [x19, #0x70]       | this.tr = val_1;                         //  dest_result_addr=1152921515016082720
        this.tr = val_1;
        // 0x00B1F60C: B #0xb1f628                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B1F610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12F, ????);      
        // 0x00B1F614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F61C: BL #0x1a62c1c              | X0 = 0.get_transform();                 
        UnityEngine.Transform val_2 = 0.transform;
        // 0x00B1F620: STR x0, [x19, #0x70]       | this.tr = val_2;                         //  dest_result_addr=1152921515016082720
        this.tr = val_2;
        // 0x00B1F624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B1F628: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00B1F62C: LDR x8, [x8, #0xf18]       | X8 = 1152921513315039216;               
        // 0x00B1F630: MOV x0, x20                | X0 = effGO;//m1                         
        // 0x00B1F634: LDR x1, [x8]               | X1 = public UnityEngine.Collider UnityEngine.GameObject::GetComponent<UnityEngine.Collider>();
        // 0x00B1F638: BL #0x23d5abc              | X0 = effGO.GetComponent<UnityEngine.Collider>();
        UnityEngine.Collider val_3 = effGO.GetComponent<UnityEngine.Collider>();
        // 0x00B1F63C: STR x0, [x19, #0x88]       | this.c = val_3;                          //  dest_result_addr=1152921515016082744
        this.c = val_3;
        // 0x00B1F640: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F644: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F648: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F64C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F650 (11662928), len: 4  VirtAddr: 0x00B1F650 RVA: 0x00B1F650 token: 100693580 methodIndex: 24689 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Play()
    {
        //
        // Disasemble & Code
        // 0x00B1F650: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F654 (11662932), len: 4  VirtAddr: 0x00B1F654 RVA: 0x00B1F654 token: 100693581 methodIndex: 24690 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Stop()
    {
        //
        // Disasemble & Code
        // 0x00B1F654: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F658 (11662936), len: 108  VirtAddr: 0x00B1F658 RVA: 0x00B1F658 token: 100693582 methodIndex: 24691 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Reset()
    {
        //
        // Disasemble & Code
        // 0x00B1F658: STP x20, x19, [sp, #-0x20]! | stack[1152921515016427056] = ???;  stack[1152921515016427064] = ???;  //  dest_result_addr=1152921515016427056 |  dest_result_addr=1152921515016427064
        // 0x00B1F65C: STP x29, x30, [sp, #0x10]  | stack[1152921515016427072] = ???;  stack[1152921515016427080] = ???;  //  dest_result_addr=1152921515016427072 |  dest_result_addr=1152921515016427080
        // 0x00B1F660: ADD x29, sp, #0x10         | X29 = (1152921515016427056 + 16) = 1152921515016427072 (0x100000026C759640);
        // 0x00B1F664: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1F668: LDRB w8, [x20, #0x718]     | W8 = (bool)static_value_03733718;       
        // 0x00B1F66C: MOV x19, x0                | X19 = 1152921515016439088 (0x100000026C75C530);//ML01
        // 0x00B1F670: TBNZ w8, #0, #0xb1f68c     | if (static_value_03733718 == true) goto label_0;
        // 0x00B1F674: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00B1F678: LDR x8, [x8, #0xa8]        | X8 = 0x2B8A9D8;                         
        // 0x00B1F67C: LDR w0, [x8]               | W0 = 0x134;                             
        // 0x00B1F680: BL #0x2782188              | X0 = sub_2782188( ?? 0x134, ????);      
        // 0x00B1F684: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F688: STRB w8, [x20, #0x718]     | static_value_03733718 = true;            //  dest_result_addr=57882392
        label_0:
        // 0x00B1F68C: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1F690: STR xzr, [x19, #0x20]      | this.host = null;                        //  dest_result_addr=1152921515016439120
        this.host = 0;
        // 0x00B1F694: STR xzr, [x19, #0x30]      | this.mpJson = null;                      //  dest_result_addr=1152921515016439136
        this.mpJson = 0;
        // 0x00B1F698: STR xzr, [x19, #0x48]      | this.targetTr = null;                    //  dest_result_addr=1152921515016439160
        this.targetTr = 0;
        // 0x00B1F69C: STR xzr, [x19, #0x68]      | this.targetEntity = null;                //  dest_result_addr=1152921515016439192
        this.targetEntity = 0;
        // 0x00B1F6A0: CBNZ x20, #0xb1f6a8        | if (this.paths != null) goto label_1;   
        if(this.paths != null)
        {
            goto label_1;
        }
        // 0x00B1F6A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x134, ????);      
        label_1:
        // 0x00B1F6A8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1F6AC: LDR x8, [x8, #0xe88]       | X8 = 1152921510909662576;               
        // 0x00B1F6B0: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1F6B4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Clear();
        // 0x00B1F6B8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F6BC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F6C0: B #0x264071c               | this.paths.Clear(); return;             
        this.paths.Clear();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F6C4 (11663044), len: 316  VirtAddr: 0x00B1F6C4 RVA: 0x00B1F6C4 token: 100693583 methodIndex: 24692 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Clear()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00B1F6C4: STP x26, x25, [sp, #-0x50]! | stack[1152921515016555392] = ???;  stack[1152921515016555400] = ???;  //  dest_result_addr=1152921515016555392 |  dest_result_addr=1152921515016555400
        // 0x00B1F6C8: STP x24, x23, [sp, #0x10]  | stack[1152921515016555408] = ???;  stack[1152921515016555416] = ???;  //  dest_result_addr=1152921515016555408 |  dest_result_addr=1152921515016555416
        // 0x00B1F6CC: STP x22, x21, [sp, #0x20]  | stack[1152921515016555424] = ???;  stack[1152921515016555432] = ???;  //  dest_result_addr=1152921515016555424 |  dest_result_addr=1152921515016555432
        // 0x00B1F6D0: STP x20, x19, [sp, #0x30]  | stack[1152921515016555440] = ???;  stack[1152921515016555448] = ???;  //  dest_result_addr=1152921515016555440 |  dest_result_addr=1152921515016555448
        // 0x00B1F6D4: STP x29, x30, [sp, #0x40]  | stack[1152921515016555456] = ???;  stack[1152921515016555464] = ???;  //  dest_result_addr=1152921515016555456 |  dest_result_addr=1152921515016555464
        // 0x00B1F6D8: ADD x29, sp, #0x40         | X29 = (1152921515016555392 + 64) = 1152921515016555456 (0x100000026C778BC0);
        // 0x00B1F6DC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1F6E0: LDRB w8, [x20, #0x719]     | W8 = (bool)static_value_03733719;       
        // 0x00B1F6E4: MOV x19, x0                | X19 = 1152921515016567472 (0x100000026C77BAB0);//ML01
        // 0x00B1F6E8: TBNZ w8, #0, #0xb1f704     | if (static_value_03733719 == true) goto label_0;
        // 0x00B1F6EC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00B1F6F0: LDR x8, [x8, #0x9a0]       | X8 = 0x2B8A9C0;                         
        // 0x00B1F6F4: LDR w0, [x8]               | W0 = 0x12E;                             
        // 0x00B1F6F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x12E, ????);      
        // 0x00B1F6FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F700: STRB w8, [x20, #0x719]     | static_value_03733719 = true;            //  dest_result_addr=57882393
        label_0:
        // 0x00B1F704: ADRP x23, #0x35ea000       | X23 = 56532992 (0x35EA000);             
        // 0x00B1F708: ADRP x24, #0x35cd000       | X24 = 56414208 (0x35CD000);             
        // 0x00B1F70C: ADRP x25, #0x365d000       | X25 = 57004032 (0x365D000);             
        // 0x00B1F710: LDR x23, [x23, #0xde0]     | X23 = 1152921510901904592;              
        // 0x00B1F714: LDR x24, [x24, #0x20]      | X24 = 1152921510901734224;              
        // 0x00B1F718: LDR x25, [x25, #0x4b8]     | X25 = 1152921504922660864;              
        // 0x00B1F71C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_3 = 0;
        // 0x00B1F720: B #0xb1f738                |  goto label_1;                          
        goto label_1;
        label_7:
        // 0x00B1F724: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F728: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F72C: MOV w1, w21                | W1 = W21;//m1                           
        // 0x00B1F730: BL #0xb8dc54               | BehaviourUtil.StopCoroutine(id:  0);    
        BehaviourUtil.StopCoroutine(id:  0);
        // 0x00B1F734: ADD w20, w20, #1           | W20 = (val_3 + 1) = val_3 (0x00000001); 
        val_3 = 1;
        label_1:
        // 0x00B1F738: LDR x21, [x19, #0x80]      | X21 = this.delayList; //P2              
        // 0x00B1F73C: CBNZ x21, #0xb1f744        | if (this.delayList != null) goto label_2;
        if(this.delayList != null)
        {
            goto label_2;
        }
        // 0x00B1F740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_2:
        // 0x00B1F744: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<System.UInt32>::get_Count();
        // 0x00B1F748: MOV x0, x21                | X0 = this.delayList;//m1                
        // 0x00B1F74C: BL #0x2570768              | X0 = this.delayList.get_Count();        
        int val_1 = this.delayList.Count;
        // 0x00B1F750: LDR x21, [x19, #0x80]      | X21 = this.delayList; //P2              
        // 0x00B1F754: MOV w22, w0                | W22 = val_1;//m1                        
        // 0x00B1F758: CBNZ x21, #0xb1f760        | if (this.delayList != null) goto label_3;
        if(this.delayList != null)
        {
            goto label_3;
        }
        // 0x00B1F75C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B1F760: CMP w20, w22               | STATE = COMPARE(0x1, val_1)             
        // 0x00B1F764: B.GE #0xb1f79c             | if (val_3 >= val_1) goto label_4;       
        if(val_3 >= val_1)
        {
            goto label_4;
        }
        // 0x00B1F768: LDR x2, [x24]              | X2 = public System.UInt32 System.Collections.Generic.List<System.UInt32>::get_Item(int index);
        // 0x00B1F76C: MOV x0, x21                | X0 = this.delayList;//m1                
        // 0x00B1F770: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B1F774: BL #0x2570770              | X0 = this.delayList.get_Item(index:  1);
        uint val_2 = this.delayList.Item[1];
        // 0x00B1F778: LDR x8, [x25]              | X8 = typeof(BehaviourUtil);             
        // 0x00B1F77C: MOV w21, w0                | W21 = val_2;//m1                        
        // 0x00B1F780: LDRB w9, [x8, #0x10a]      | W9 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00B1F784: TBZ w9, #0, #0xb1f724      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B1F788: LDR w9, [x8, #0xbc]        | W9 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F78C: CBNZ w9, #0xb1f724         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B1F790: MOV x0, x8                 | X0 = 1152921504922660864 (0x1000000012D2F000);//ML01
        // 0x00B1F794: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        // 0x00B1F798: B #0xb1f724                |  goto label_7;                          
        goto label_7;
        label_4:
        // 0x00B1F79C: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00B1F7A0: LDR x8, [x8, #0x390]       | X8 = 1152921510901223120;               
        // 0x00B1F7A4: MOV x0, x21                | X0 = this.delayList;//m1                
        // 0x00B1F7A8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.UInt32>::Clear();
        // 0x00B1F7AC: BL #0x256dd68              | this.delayList.Clear();                 
        this.delayList.Clear();
        // 0x00B1F7B0: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1F7B4: STR xzr, [x19, #0x20]      | this.host = null;                        //  dest_result_addr=1152921515016567504
        this.host = 0;
        // 0x00B1F7B8: STR xzr, [x19, #0x30]      | this.mpJson = null;                      //  dest_result_addr=1152921515016567520
        this.mpJson = 0;
        // 0x00B1F7BC: STR xzr, [x19, #0x48]      | this.targetTr = null;                    //  dest_result_addr=1152921515016567544
        this.targetTr = 0;
        // 0x00B1F7C0: STR xzr, [x19, #0x68]      | this.targetEntity = null;                //  dest_result_addr=1152921515016567576
        this.targetEntity = 0;
        // 0x00B1F7C4: CBNZ x20, #0xb1f7cc        | if (this.paths != null) goto label_8;   
        if(this.paths != null)
        {
            goto label_8;
        }
        // 0x00B1F7C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.delayList, ????);
        label_8:
        // 0x00B1F7CC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1F7D0: LDR x8, [x8, #0xe88]       | X8 = 1152921510909662576;               
        // 0x00B1F7D4: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1F7D8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Clear();
        // 0x00B1F7DC: BL #0x264071c              | this.paths.Clear();                     
        this.paths.Clear();
        // 0x00B1F7E0: STR xzr, [x19, #0x88]      | this.c = null;                           //  dest_result_addr=1152921515016567608
        this.c = 0;
        // 0x00B1F7E4: STP xzr, xzr, [x19, #0x70] | this.tr = null;  this.paths = null;      //  dest_result_addr=1152921515016567584 |  dest_result_addr=1152921515016567592
        this.tr = 0;
        this.paths = 0;
        // 0x00B1F7E8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1F7EC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1F7F0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1F7F4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1F7F8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00B1F7FC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1F800 (11663360), len: 2392  VirtAddr: 0x00B1F800 RVA: 0x00B1F800 token: 100693584 methodIndex: 24693 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Update()
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_61;
        //  | 
        var val_62;
        //  | 
        CombatEntity val_63;
        //  | 
        float val_64;
        //  | 
        float val_65;
        //  | 
        float val_66;
        //  | 
        float val_67;
        //  | 
        float val_68;
        //  | 
        float val_69;
        //  | 
        float val_70;
        //  | 
        var val_71;
        //  | 
        var val_72;
        //  | 
        var val_73;
        //  | 
        var val_74;
        //  | 
        var val_75;
        //  | 
        var val_76;
        //  | 
        var val_77;
        //  | 
        var val_78;
        // 0x00B1F800: STP d13, d12, [sp, #-0x90]! | stack[1152921515016865856] = ???;  stack[1152921515016865864] = ???;  //  dest_result_addr=1152921515016865856 |  dest_result_addr=1152921515016865864
        // 0x00B1F804: STP d11, d10, [sp, #0x10]  | stack[1152921515016865872] = ???;  stack[1152921515016865880] = ???;  //  dest_result_addr=1152921515016865872 |  dest_result_addr=1152921515016865880
        // 0x00B1F808: STP d9, d8, [sp, #0x20]    | stack[1152921515016865888] = ???;  stack[1152921515016865896] = ???;  //  dest_result_addr=1152921515016865888 |  dest_result_addr=1152921515016865896
        // 0x00B1F80C: STP x28, x27, [sp, #0x30]  | stack[1152921515016865904] = ???;  stack[1152921515016865912] = ???;  //  dest_result_addr=1152921515016865904 |  dest_result_addr=1152921515016865912
        // 0x00B1F810: STP x26, x25, [sp, #0x40]  | stack[1152921515016865920] = ???;  stack[1152921515016865928] = ???;  //  dest_result_addr=1152921515016865920 |  dest_result_addr=1152921515016865928
        // 0x00B1F814: STP x24, x23, [sp, #0x50]  | stack[1152921515016865936] = ???;  stack[1152921515016865944] = ???;  //  dest_result_addr=1152921515016865936 |  dest_result_addr=1152921515016865944
        // 0x00B1F818: STP x22, x21, [sp, #0x60]  | stack[1152921515016865952] = ???;  stack[1152921515016865960] = ???;  //  dest_result_addr=1152921515016865952 |  dest_result_addr=1152921515016865960
        // 0x00B1F81C: STP x20, x19, [sp, #0x70]  | stack[1152921515016865968] = ???;  stack[1152921515016865976] = ???;  //  dest_result_addr=1152921515016865968 |  dest_result_addr=1152921515016865976
        // 0x00B1F820: STP x29, x30, [sp, #0x80]  | stack[1152921515016865984] = ???;  stack[1152921515016865992] = ???;  //  dest_result_addr=1152921515016865984 |  dest_result_addr=1152921515016865992
        // 0x00B1F824: ADD x29, sp, #0x80         | X29 = (1152921515016865856 + 128) = 1152921515016865984 (0x100000026C7C48C0);
        // 0x00B1F828: SUB sp, sp, #0xd0          | SP = (1152921515016865856 - 208) = 1152921515016865648 (0x100000026C7C4770);
        // 0x00B1F82C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1F830: LDRB w8, [x20, #0x71a]     | W8 = (bool)static_value_0373371A;       
        // 0x00B1F834: MOV x19, x0                | X19 = 1152921515016878000 (0x100000026C7C77B0);//ML01
        // 0x00B1F838: TBNZ w8, #0, #0xb1f854     | if (static_value_0373371A == true) goto label_0;
        // 0x00B1F83C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00B1F840: LDR x8, [x8, #0xeb8]       | X8 = 0x2B8A9E4;                         
        // 0x00B1F844: LDR w0, [x8]               | W0 = 0x137;                             
        // 0x00B1F848: BL #0x2782188              | X0 = sub_2782188( ?? 0x137, ????);      
        // 0x00B1F84C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1F850: STRB w8, [x20, #0x71a]     | static_value_0373371A = true;            //  dest_result_addr=57882394
        label_0:
        // 0x00B1F854: STP xzr, xzr, [x29, #-0x98] | stack[1152921515016865832] = 0x0;  stack[1152921515016865840] = 0x0;  //  dest_result_addr=1152921515016865832 |  dest_result_addr=1152921515016865840
        // 0x00B1F858: STUR xzr, [x29, #-0xa0]    | stack[1152921515016865824] = 0x0;        //  dest_result_addr=1152921515016865824
        // 0x00B1F85C: STR wzr, [sp, #0xa8]       | stack[1152921515016865816] = 0x0;        //  dest_result_addr=1152921515016865816
        // 0x00B1F860: STR xzr, [sp, #0xa0]       | stack[1152921515016865808] = 0x0;        //  dest_result_addr=1152921515016865808
        // 0x00B1F864: STP xzr, xzr, [sp, #0x88]  | stack[1152921515016865784] = 0x0;  stack[1152921515016865792] = 0x0;  //  dest_result_addr=1152921515016865784 |  dest_result_addr=1152921515016865792
        // 0x00B1F868: STR xzr, [sp, #0x80]       | stack[1152921515016865776] = 0x0;        //  dest_result_addr=1152921515016865776
        // 0x00B1F86C: LDRB w8, [x19, #0x60]      | W8 = this.IsDo; //P2                    
        // 0x00B1F870: CBZ w8, #0xb1fe54          | if (this.IsDo == false) goto label_2;   
        if(this.IsDo == false)
        {
            goto label_2;
        }
        // 0x00B1F874: LDRB w8, [x19, #0x40]      | W8 = this.isPause; //P2                 
        // 0x00B1F878: CBNZ w8, #0xb1fe54         | if (this.isPause == true) goto label_2; 
        if(this.isPause == true)
        {
            goto label_2;
        }
        // 0x00B1F87C: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1F880: CBNZ x20, #0xb1f888        | if (this.paths != null) goto label_3;   
        if(this.paths != null)
        {
            goto label_3;
        }
        // 0x00B1F884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x137, ????);      
        label_3:
        // 0x00B1F888: ADRP x23, #0x35fc000       | X23 = 56606720 (0x35FC000);             
        // 0x00B1F88C: LDR x23, [x23, #0x5e0]     | X23 = 1152921510909311600;              
        val_62 = 1152921510909311600;
        // 0x00B1F890: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1F894: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B1F898: BL #0x2643344              | X0 = this.paths.get_Count();            
        int val_1 = this.paths.Count;
        // 0x00B1F89C: CBZ w0, #0xb20124          | if (val_1 == 0) goto label_29;          
        if(val_1 == 0)
        {
            goto label_29;
        }
        // 0x00B1F8A0: ADRP x24, #0x35fe000       | X24 = 56614912 (0x35FE000);             
        // 0x00B1F8A4: LDR x24, [x24, #0x810]     | X24 = 1152921504697475072;              
        // 0x00B1F8A8: LDR x20, [x19, #0x68]      | X20 = this.targetEntity; //P2           
        // 0x00B1F8AC: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1F8B0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1F8B4: TBZ w8, #0, #0xb1f8c4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B1F8B8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F8BC: CBNZ w8, #0xb1f8c4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B1F8C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_6:
        // 0x00B1F8C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F8C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F8CC: MOV x1, x20                | X1 = this.targetEntity;//m1             
        // 0x00B1F8D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1F8D4: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.targetEntity);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.targetEntity);
        // 0x00B1F8D8: TBZ w0, #0, #0xb1fabc      | if (val_2 == false) goto label_26;      
        if(val_2 == false)
        {
            goto label_26;
        }
        // 0x00B1F8DC: LDR x20, [x19, #0x68]      | X20 = this.targetEntity; //P2           
        // 0x00B1F8E0: CBNZ x20, #0xb1f8e8        | if (this.targetEntity != null) goto label_8;
        if(this.targetEntity != null)
        {
            goto label_8;
        }
        // 0x00B1F8E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00B1F8E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F8EC: MOV x0, x20                | X0 = this.targetEntity;//m1             
        // 0x00B1F8F0: BL #0xd89cfc               | X0 = this.targetEntity.get_isDeath();   
        bool val_3 = this.targetEntity.isDeath;
        // 0x00B1F8F4: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B1F8F8: TBNZ w8, #0, #0xb1fabc     | if ((val_3 & 1) == true) goto label_26; 
        if(val_4 == true)
        {
            goto label_26;
        }
        // 0x00B1F8FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F900: MOV x0, x19                | X0 = 1152921515016878000 (0x100000026C7C77B0);//ML01
        // 0x00B1F904: BL #0x28a4a48              | X0 = this.get_effCtrl();                
        EffectCtrl val_5 = this.effCtrl;
        // 0x00B1F908: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B1F90C: CBNZ x20, #0xb1f914        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B1F910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B1F914: LDR x20, [x20, #0x20]      | X20 = val_5.effectVO; //P2              
        // 0x00B1F918: CBNZ x20, #0xb1f920        | if (val_5.effectVO != null) goto label_11;
        if(val_5.effectVO != null)
        {
            goto label_11;
        }
        // 0x00B1F91C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00B1F920: LDRB w8, [x20, #0x44]      | W8 = val_5.effectVO.isflow; //P2        
        // 0x00B1F924: CBZ w8, #0xb1fabc          | if (val_5.effectVO.isflow == false) goto label_26;
        if(val_5.effectVO.isflow == false)
        {
            goto label_26;
        }
        // 0x00B1F928: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1F92C: CBNZ x20, #0xb1f934        | if (this.paths != null) goto label_13;  
        if(this.paths != null)
        {
            goto label_13;
        }
        // 0x00B1F930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_13:
        // 0x00B1F934: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B1F938: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1F93C: BL #0x2643344              | X0 = this.paths.get_Count();            
        int val_6 = this.paths.Count;
        // 0x00B1F940: LDR x22, [x19, #0x48]      | X22 = this.targetTr; //P2               
        // 0x00B1F944: MOV w21, w0                | W21 = val_6;//m1                        
        val_63 = val_6;
        // 0x00B1F948: CBNZ x22, #0xb1f950        | if (this.targetTr != null) goto label_14;
        if(this.targetTr != null)
        {
            goto label_14;
        }
        // 0x00B1F94C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00B1F950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F954: MOV x0, x22                | X0 = this.targetTr;//m1                 
        // 0x00B1F958: BL #0x2693510              | X0 = this.targetTr.get_position();      
        UnityEngine.Vector3 val_7 = this.targetTr.position;
        // 0x00B1F95C: MOV v8.16b, v0.16b         | V8 = val_7.x;//m1                       
        val_64 = val_7.x;
        // 0x00B1F960: MOV v9.16b, v1.16b         | V9 = val_7.y;//m1                       
        // 0x00B1F964: MOV v10.16b, v2.16b        | V10 = val_7.z;//m1                      
        val_65 = val_7.z;
        // 0x00B1F968: CBNZ x20, #0xb1f970        | if (this.paths != null) goto label_15;  
        if(this.paths != null)
        {
            goto label_15;
        }
        // 0x00B1F96C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.targetTr, ????);
        label_15:
        // 0x00B1F970: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B1F974: LDR x8, [x8, #0xc88]       | X8 = 1152921513304446496;               
        // 0x00B1F978: SUB w1, w21, #1            | W1 = (val_6 - 1);                       
        int val_8 = val_63 - 1;
        // 0x00B1F97C: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1F980: MOV v0.16b, v8.16b         | V0 = val_7.x;//m1                       
        // 0x00B1F984: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::set_Item(int index, UnityEngine.Vector3 value);
        // 0x00B1F988: MOV v1.16b, v9.16b         | V1 = val_7.y;//m1                       
        // 0x00B1F98C: MOV v2.16b, v10.16b        | V2 = val_7.z;//m1                       
        // 0x00B1F990: BL #0x264341c              | this.paths.set_Item(index:  int val_8 = val_63 - 1, value:  new UnityEngine.Vector3() {x = val_64, y = val_7.y, z = val_65});
        this.paths.set_Item(index:  val_8, value:  new UnityEngine.Vector3() {x = val_64, y = val_7.y, z = val_65});
        // 0x00B1F994: LDR x20, [x19, #0x68]      | X20 = this.targetEntity; //P2           
        // 0x00B1F998: CBNZ x20, #0xb1f9a0        | if (this.targetEntity != null) goto label_16;
        if(this.targetEntity != null)
        {
            goto label_16;
        }
        // 0x00B1F99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.paths, ????); 
        label_16:
        // 0x00B1F9A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1F9A4: MOV x0, x20                | X0 = this.targetEntity;//m1             
        // 0x00B1F9A8: BL #0xd8ee20               | X0 = this.targetEntity.get_boxCollider();
        UnityEngine.Collider val_9 = this.targetEntity.boxCollider;
        // 0x00B1F9AC: LDR x8, [x24]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B1F9B0: MOV x20, x0                | X20 = val_9;//m1                        
        // 0x00B1F9B4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1F9B8: TBZ w9, #0, #0xb1f9cc      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00B1F9BC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F9C0: CBNZ w9, #0xb1f9cc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00B1F9C4: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B1F9C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_18:
        // 0x00B1F9CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1F9D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1F9D4: MOV x1, x20                | X1 = val_9;//m1                         
        // 0x00B1F9D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1F9DC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_9);
        bool val_10 = UnityEngine.Object.op_Inequality(x:  0, y:  val_9);
        // 0x00B1F9E0: TBZ w0, #0, #0xb1fabc      | if (val_10 == false) goto label_26;     
        if(val_10 == false)
        {
            goto label_26;
        }
        // 0x00B1F9E4: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1F9E8: LDR x20, [x19, #0x88]      | X20 = this.c; //P2                      
        // 0x00B1F9EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1F9F0: TBZ w8, #0, #0xb1fa00      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x00B1F9F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1F9F8: CBNZ w8, #0xb1fa00         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x00B1F9FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_21:
        // 0x00B1FA00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FA04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FA08: MOV x1, x20                | X1 = this.c;//m1                        
        // 0x00B1FA0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1FA10: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.c);
        bool val_11 = UnityEngine.Object.op_Inequality(x:  0, y:  this.c);
        // 0x00B1FA14: TBZ w0, #0, #0xb1fabc      | if (val_11 == false) goto label_26;     
        if(val_11 == false)
        {
            goto label_26;
        }
        // 0x00B1FA18: LDR x20, [x19, #0x88]      | X20 = this.c; //P2                      
        // 0x00B1FA1C: CBNZ x20, #0xb1fa24        | if (this.c != null) goto label_23;      
        if(this.c != null)
        {
            goto label_23;
        }
        // 0x00B1FA20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_23:
        // 0x00B1FA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FA28: ADD x8, sp, #0x68          | X8 = (1152921515016865648 + 104) = 1152921515016865752 (0x100000026C7C47D8);
        // 0x00B1FA2C: MOV x0, x20                | X0 = this.c;//m1                        
        // 0x00B1FA30: BL #0x26f4a6c              | X0 = this.c.get_bounds();               
        UnityEngine.Bounds val_12 = this.c.bounds;
        // 0x00B1FA34: LDR x8, [sp, #0x78]        | X8 = val_13;                             //  find_add[1152921515016854000]
        // 0x00B1FA38: LDUR q0, [sp, #0x68]       | Q0 = val_14;                             //  find_add[1152921515016854000]
        // 0x00B1FA3C: STUR x8, [x29, #-0x90]     | stack[1152921515016865840] = val_13;     //  dest_result_addr=1152921515016865840
        // 0x00B1FA40: STUR q0, [x29, #-0xa0]     | stack[1152921515016865824] = val_14;     //  dest_result_addr=1152921515016865824
        // 0x00B1FA44: LDR x20, [x19, #0x68]      | X20 = this.targetEntity; //P2           
        // 0x00B1FA48: CBNZ x20, #0xb1fa50        | if (this.targetEntity != null) goto label_24;
        if(this.targetEntity != null)
        {
            goto label_24;
        }
        // 0x00B1FA4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.c, ????);     
        label_24:
        // 0x00B1FA50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FA54: MOV x0, x20                | X0 = this.targetEntity;//m1             
        // 0x00B1FA58: BL #0xd8ee20               | X0 = this.targetEntity.get_boxCollider();
        UnityEngine.Collider val_15 = this.targetEntity.boxCollider;
        // 0x00B1FA5C: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00B1FA60: CBNZ x20, #0xb1fa68        | if (val_15 != null) goto label_25;      
        if(val_15 != null)
        {
            goto label_25;
        }
        // 0x00B1FA64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_25:
        // 0x00B1FA68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FA6C: ADD x8, sp, #0x50          | X8 = (1152921515016865648 + 80) = 1152921515016865728 (0x100000026C7C47C0);
        // 0x00B1FA70: MOV x0, x20                | X0 = val_15;//m1                        
        // 0x00B1FA74: BL #0x26f4a6c              | X0 = val_15.get_bounds();               
        UnityEngine.Bounds val_16 = val_15.bounds;
        // 0x00B1FA78: LDR x8, [sp, #0x60]        | X8 = val_17;                             //  find_add[1152921515016854000]
        // 0x00B1FA7C: LDR q0, [sp, #0x50]        | Q0 = val_18;                             //  find_add[1152921515016854000]
        // 0x00B1FA80: SUB x0, x29, #0xa0         | X0 = (1152921515016865984 - 160) = 1152921515016865824 (0x100000026C7C4820);
        // 0x00B1FA84: ADD x1, sp, #0x30          | X1 = (1152921515016865648 + 48) = 1152921515016865696 (0x100000026C7C47A0);
        // 0x00B1FA88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FA8C: STR x8, [sp, #0x40]        | stack[1152921515016865712] = val_17;     //  dest_result_addr=1152921515016865712
        // 0x00B1FA90: STR q0, [sp, #0x30]        | stack[1152921515016865696] = val_18;     //  dest_result_addr=1152921515016865696
        // 0x00B1FA94: BL #0x20ccb80              | X0 = label_UnityEngine_Bounds_Expand_GL020CCB80();
        // 0x00B1FA98: TBZ w0, #0, #0xb1fabc      | if ((0x100000026C7C4820 & 0x1) == 0) goto label_26;
        if((1820084256 & 1) == 0)
        {
            goto label_26;
        }
        // 0x00B1FA9C: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FAA0: CBNZ x20, #0xb1faa8        | if (this.paths != null) goto label_27;  
        if(this.paths != null)
        {
            goto label_27;
        }
        // 0x00B1FAA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000026C7C4820, ????);
        label_27:
        // 0x00B1FAA8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1FAAC: LDR x8, [x8, #0xe88]       | X8 = 1152921510909662576;               
        // 0x00B1FAB0: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FAB4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Clear();
        // 0x00B1FAB8: BL #0x264071c              | this.paths.Clear();                     
        this.paths.Clear();
        label_26:
        // 0x00B1FABC: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FAC0: CBNZ x20, #0xb1fac8        | if (this.paths != null) goto label_28;  
        if(this.paths != null)
        {
            goto label_28;
        }
        // 0x00B1FAC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.paths, ????); 
        label_28:
        // 0x00B1FAC8: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B1FACC: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FAD0: BL #0x2643344              | X0 = this.paths.get_Count();            
        int val_19 = this.paths.Count;
        // 0x00B1FAD4: CBZ w0, #0xb20124          | if (val_19 == 0) goto label_29;         
        if(val_19 == 0)
        {
            goto label_29;
        }
        // 0x00B1FAD8: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FADC: CBNZ x20, #0xb1fae4        | if (this.paths != null) goto label_30;  
        if(this.paths != null)
        {
            goto label_30;
        }
        // 0x00B1FAE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_30:
        // 0x00B1FAE4: ADRP x21, #0x363e000       | X21 = 56877056 (0x363E000);             
        // 0x00B1FAE8: LDR x21, [x21, #0x1f0]     | X21 = 1152921510909481968;              
        val_63 = 1152921510909481968;
        // 0x00B1FAEC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1FAF0: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FAF4: LDR x2, [x21]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B1FAF8: BL #0x264334c              | X0 = this.paths.get_Item(index:  0);    
        UnityEngine.Vector3 val_20 = this.paths.Item[0];
        // 0x00B1FAFC: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1FB00: MOV v8.16b, v0.16b         | V8 = val_20.x;//m1                      
        val_66 = val_20.x;
        // 0x00B1FB04: MOV v9.16b, v1.16b         | V9 = val_20.y;//m1                      
        val_67 = val_20.y;
        // 0x00B1FB08: MOV v10.16b, v2.16b        | V10 = val_20.z;//m1                     
        val_65 = val_20.z;
        // 0x00B1FB0C: CBNZ x20, #0xb1fb14        | if (this.tr != null) goto label_31;     
        if(this.tr != null)
        {
            goto label_31;
        }
        // 0x00B1FB10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.paths, ????); 
        label_31:
        // 0x00B1FB14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FB18: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FB1C: MOV v0.16b, v8.16b         | V0 = val_20.x;//m1                      
        // 0x00B1FB20: MOV v1.16b, v9.16b         | V1 = val_20.y;//m1                      
        // 0x00B1FB24: MOV v2.16b, v10.16b        | V2 = val_20.z;//m1                      
        // 0x00B1FB28: BL #0x26952ec              | this.tr.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        this.tr.LookAt(worldPosition:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        // 0x00B1FB2C: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1FB30: CBNZ x20, #0xb1fb38        | if (this.tr != null) goto label_32;     
        if(this.tr != null)
        {
            goto label_32;
        }
        // 0x00B1FB34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tr, ????);    
        label_32:
        // 0x00B1FB38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FB3C: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FB40: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_21 = this.tr.position;
        // 0x00B1FB44: ADRP x22, #0x3673000       | X22 = 57094144 (0x3673000);             
        // 0x00B1FB48: LDR x22, [x22, #0x488]     | X22 = 1152921504695078912;              
        // 0x00B1FB4C: MOV v11.16b, v0.16b        | V11 = val_21.x;//m1                     
        // 0x00B1FB50: MOV v12.16b, v1.16b        | V12 = val_21.y;//m1                     
        // 0x00B1FB54: MOV v13.16b, v2.16b        | V13 = val_21.z;//m1                     
        // 0x00B1FB58: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B1FB5C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B1FB60: TBZ w8, #0, #0xb1fb70      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_34;
        // 0x00B1FB64: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B1FB68: CBNZ w8, #0xb1fb70         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
        // 0x00B1FB6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_34:
        // 0x00B1FB70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FB74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FB78: MOV v0.16b, v8.16b         | V0 = val_20.x;//m1                      
        // 0x00B1FB7C: MOV v1.16b, v9.16b         | V1 = val_20.y;//m1                      
        // 0x00B1FB80: MOV v2.16b, v10.16b        | V2 = val_20.z;//m1                      
        // 0x00B1FB84: MOV v3.16b, v11.16b        | V3 = val_21.x;//m1                      
        // 0x00B1FB88: MOV v4.16b, v12.16b        | V4 = val_21.y;//m1                      
        // 0x00B1FB8C: MOV v5.16b, v13.16b        | V5 = val_21.z;//m1                      
        // 0x00B1FB90: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65}, b:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        UnityEngine.Vector3 val_22 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65}, b:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z});
        // 0x00B1FB94: ADD x0, sp, #0xa0          | X0 = (1152921515016865648 + 160) = 1152921515016865808 (0x100000026C7C4810);
        // 0x00B1FB98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FB9C: STP s0, s1, [sp, #0xa0]    | stack[1152921515016865808] = val_22.x;  stack[1152921515016865812] = val_22.y;  //  dest_result_addr=1152921515016865808 |  dest_result_addr=1152921515016865812
        // 0x00B1FBA0: STR s2, [sp, #0xa8]        | stack[1152921515016865816] = val_22.z;   //  dest_result_addr=1152921515016865816
        // 0x00B1FBA4: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B1FBA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FBAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FBB0: MOV v11.16b, v0.16b        | V11 = val_22.x;//m1                     
        // 0x00B1FBB4: MOV v12.16b, v1.16b        | V12 = val_22.y;//m1                     
        // 0x00B1FBB8: MOV v13.16b, v2.16b        | V13 = val_22.z;//m1                     
        // 0x00B1FBBC: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_23 = UnityEngine.Time.deltaTime;
        // 0x00B1FBC0: MOV v3.16b, v0.16b         | V3 = val_23;//m1                        
        // 0x00B1FBC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FBC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FBCC: MOV v0.16b, v11.16b        | V0 = val_22.x;//m1                      
        // 0x00B1FBD0: MOV v1.16b, v12.16b        | V1 = val_22.y;//m1                      
        // 0x00B1FBD4: MOV v2.16b, v13.16b        | V2 = val_22.z;//m1                      
        // 0x00B1FBD8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, d:  val_23);
        UnityEngine.Vector3 val_24 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z}, d:  val_23);
        // 0x00B1FBDC: LDR s3, [x19, #0x50]       | S3 = this.speed; //P2                   
        // 0x00B1FBE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FBE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FBE8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z}, d:  this.speed);
        UnityEngine.Vector3 val_25 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z}, d:  this.speed);
        // 0x00B1FBEC: MOV v11.16b, v0.16b        | V11 = val_25.x;//m1                     
        // 0x00B1FBF0: MOV v12.16b, v1.16b        | V12 = val_25.y;//m1                     
        // 0x00B1FBF4: MOV v13.16b, v2.16b        | V13 = val_25.z;//m1                     
        // 0x00B1FBF8: CBNZ x20, #0xb1fc00        | if (this.tr != null) goto label_35;     
        if(this.tr != null)
        {
            goto label_35;
        }
        // 0x00B1FBFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_35:
        // 0x00B1FC00: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1FC04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FC08: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FC0C: MOV v0.16b, v11.16b        | V0 = val_25.x;//m1                      
        val_68 = val_25.x;
        // 0x00B1FC10: MOV v1.16b, v12.16b        | V1 = val_25.y;//m1                      
        // 0x00B1FC14: MOV v2.16b, v13.16b        | V2 = val_25.z;//m1                      
        val_69 = val_25.z;
        // 0x00B1FC18: BL #0x2694858              | this.tr.Translate(translation:  new UnityEngine.Vector3() {x = val_68, y = val_25.y, z = val_69}, relativeTo:  0);
        this.tr.Translate(translation:  new UnityEngine.Vector3() {x = val_68, y = val_25.y, z = val_69}, relativeTo:  0);
        // 0x00B1FC1C: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1FC20: CBNZ x20, #0xb1fc28        | if (this.tr != null) goto label_36;     
        if(this.tr != null)
        {
            goto label_36;
        }
        // 0x00B1FC24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tr, ????);    
        label_36:
        // 0x00B1FC28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FC2C: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FC30: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_26 = this.tr.position;
        // 0x00B1FC34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FC38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FC3C: MOV v3.16b, v8.16b         | V3 = val_20.x;//m1                      
        // 0x00B1FC40: MOV v4.16b, v9.16b         | V4 = val_20.y;//m1                      
        // 0x00B1FC44: MOV v5.16b, v10.16b        | V5 = val_20.z;//m1                      
        // 0x00B1FC48: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        float val_27 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        // 0x00B1FC4C: FMOV s1, #1.00000000       | S1 = 1;                                 
        val_70 = 1f;
        // 0x00B1FC50: FCMP s0, s1                | STATE = COMPARE(val_27, 1)              
        // 0x00B1FC54: B.HI #0xb1fdb4             | if (val_27 > val_70) goto label_49;     
        if(val_27 > val_70)
        {
            goto label_49;
        }
        // 0x00B1FC58: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1FC5C: CBNZ x20, #0xb1fc64        | if (this.tr != null) goto label_38;     
        if(this.tr != null)
        {
            goto label_38;
        }
        // 0x00B1FC60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_38:
        // 0x00B1FC64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FC68: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FC6C: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_28 = this.tr.position;
        // 0x00B1FC70: LDR x0, [x22]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B1FC74: MOV v11.16b, v0.16b        | V11 = val_28.x;//m1                     
        // 0x00B1FC78: MOV v12.16b, v1.16b        | V12 = val_28.y;//m1                     
        // 0x00B1FC7C: MOV v13.16b, v2.16b        | V13 = val_28.z;//m1                     
        // 0x00B1FC80: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B1FC84: TBZ w8, #0, #0xb1fc94      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00B1FC88: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B1FC8C: CBNZ w8, #0xb1fc94         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00B1FC90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_40:
        // 0x00B1FC94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FC98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FC9C: MOV v0.16b, v11.16b        | V0 = val_28.x;//m1                      
        // 0x00B1FCA0: MOV v1.16b, v12.16b        | V1 = val_28.y;//m1                      
        // 0x00B1FCA4: MOV v2.16b, v13.16b        | V2 = val_28.z;//m1                      
        val_69 = val_28.z;
        // 0x00B1FCA8: MOV v3.16b, v8.16b         | V3 = val_20.x;//m1                      
        // 0x00B1FCAC: MOV v4.16b, v9.16b         | V4 = val_20.y;//m1                      
        // 0x00B1FCB0: MOV v5.16b, v10.16b        | V5 = val_20.z;//m1                      
        // 0x00B1FCB4: BL #0x269a2a0              | X0 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_69}, b:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        float val_29 = UnityEngine.Vector3.Distance(a:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_69}, b:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        // 0x00B1FCB8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1FCBC: LDR s1, [x8, #0x4b4]       | S1 = 0.1;                               
        // 0x00B1FCC0: FCMP s0, s1                | STATE = COMPARE(val_29, 0.100000001490116)
        // 0x00B1FCC4: B.LS #0xb1fd34             | if (val_29 <= 0.1f) goto label_41;      
        if(val_29 <= 0.1f)
        {
            goto label_41;
        }
        // 0x00B1FCC8: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1FCCC: CBNZ x20, #0xb1fcd4        | if (this.tr != null) goto label_42;     
        if(this.tr != null)
        {
            goto label_42;
        }
        // 0x00B1FCD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_42:
        // 0x00B1FCD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FCD8: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FCDC: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_30 = this.tr.position;
        // 0x00B1FCE0: MOV v3.16b, v8.16b         | V3 = val_20.x;//m1                      
        // 0x00B1FCE4: MOV v4.16b, v9.16b         | V4 = val_20.y;//m1                      
        // 0x00B1FCE8: MOV v5.16b, v10.16b        | V5 = val_20.z;//m1                      
        // 0x00B1FCEC: BL #0xb1f0b8               | X0 = this.tr.VectorAngle(from:  new UnityEngine.Vector3() {x = val_30.x, y = val_30.y, z = val_30.z}, to:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        float val_31 = this.tr.VectorAngle(from:  new UnityEngine.Vector3() {x = val_30.x, y = val_30.y, z = val_30.z}, to:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        // 0x00B1FCF0: MOV v11.16b, v0.16b        | V11 = val_31;//m1                       
        // 0x00B1FCF4: STR s11, [x19, #0x94]      | this.curflyAngle = val_31;               //  dest_result_addr=1152921515016878148
        this.curflyAngle = val_31;
        // 0x00B1FCF8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B1FCFC: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B1FD00: LDR s12, [x19, #0x90]      | S12 = this.beforflyAngle; //P2          
        // 0x00B1FD04: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B1FD08: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B1FD0C: TBZ w8, #0, #0xb1fd1c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_44;
        // 0x00B1FD10: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B1FD14: CBNZ w8, #0xb1fd1c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
        // 0x00B1FD18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_44:
        // 0x00B1FD1C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B1FD20: LDR s0, [x8, #0x928]       | S0 = 170;                               
        val_68 = 170f;
        // 0x00B1FD24: FSUB s1, s11, s12          | S1 = (val_31 - this.beforflyAngle);     
        val_30.y = val_31 - this.beforflyAngle;
        // 0x00B1FD28: FABS s1, s1                | S1 = System.Math.Abs((val_31 - this.beforflyAngle));
        val_70 = System.Math.Abs(val_30.y);
        // 0x00B1FD2C: FCMP s1, s0                | STATE = COMPARE((val_31 - this.beforflyAngle), 170)
        // 0x00B1FD30: B.LE #0xb1fdb4             | if (val_70 <= val_68) goto label_49;    
        if(val_70 <= val_68)
        {
            goto label_49;
        }
        label_41:
        // 0x00B1FD34: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FD38: CBNZ x20, #0xb1fd40        | if (this.paths != null) goto label_46;  
        if(this.paths != null)
        {
            goto label_46;
        }
        // 0x00B1FD3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_46:
        // 0x00B1FD40: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
        // 0x00B1FD44: LDR x8, [x8, #0xd30]       | X8 = 1152921515016766000;               
        // 0x00B1FD48: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FD4C: MOV v0.16b, v8.16b         | V0 = val_20.x;//m1                      
        val_68 = val_66;
        // 0x00B1FD50: MOV v1.16b, v9.16b         | V1 = val_20.y;//m1                      
        val_70 = val_67;
        // 0x00B1FD54: LDR x1, [x8]               | X1 = public System.Boolean System.Collections.Generic.List<UnityEngine.Vector3>::Contains(UnityEngine.Vector3 item);
        // 0x00B1FD58: MOV v2.16b, v10.16b        | V2 = val_20.z;//m1                      
        val_69 = val_65;
        // 0x00B1FD5C: BL #0x2640768              | X0 = this.paths.Contains(item:  new UnityEngine.Vector3() {x = val_68, y = val_70, z = val_69});
        bool val_32 = this.paths.Contains(item:  new UnityEngine.Vector3() {x = val_68, y = val_70, z = val_69});
        // 0x00B1FD60: AND w8, w0, #1             | W8 = (val_32 & 1);                      
        bool val_33 = val_32;
        // 0x00B1FD64: TBNZ w8, #0, #0xb1fd88     | if ((val_32 & 1) == true) goto label_47;
        if(val_33 == true)
        {
            goto label_47;
        }
        // 0x00B1FD68: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FD6C: CBNZ x20, #0xb1fd74        | if (this.paths != null) goto label_48;  
        if(this.paths != null)
        {
            goto label_48;
        }
        // 0x00B1FD70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_48:
        // 0x00B1FD74: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B1FD78: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FD7C: BL #0x2643344              | X0 = this.paths.get_Count();            
        int val_34 = this.paths.Count;
        // 0x00B1FD80: CMP w0, #1                 | STATE = COMPARE(val_34, 0x1)            
        // 0x00B1FD84: B.NE #0xb1fdb4             | if (val_34 != 1) goto label_49;         
        if(val_34 != 1)
        {
            goto label_49;
        }
        label_47:
        // 0x00B1FD88: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FD8C: CBNZ x20, #0xb1fd94        | if (this.paths != null) goto label_50;  
        if(this.paths != null)
        {
            goto label_50;
        }
        // 0x00B1FD90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
        label_50:
        // 0x00B1FD94: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00B1FD98: LDR x8, [x8, #0xc18]       | X8 = 1152921515016775216;               
        // 0x00B1FD9C: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FDA0: MOV v0.16b, v8.16b         | V0 = val_20.x;//m1                      
        val_68 = val_66;
        // 0x00B1FDA4: MOV v1.16b, v9.16b         | V1 = val_20.y;//m1                      
        val_70 = val_67;
        // 0x00B1FDA8: LDR x1, [x8]               | X1 = public System.Boolean System.Collections.Generic.List<UnityEngine.Vector3>::Remove(UnityEngine.Vector3 item);
        // 0x00B1FDAC: MOV v2.16b, v10.16b        | V2 = val_20.z;//m1                      
        val_69 = val_65;
        // 0x00B1FDB0: BL #0x2642894              | X0 = this.paths.Remove(item:  new UnityEngine.Vector3() {x = val_68, y = val_70, z = val_69});
        bool val_35 = this.paths.Remove(item:  new UnityEngine.Vector3() {x = val_68, y = val_70, z = val_69});
        label_49:
        // 0x00B1FDB4: LDR x20, [x19, #0x70]      | X20 = this.tr; //P2                     
        // 0x00B1FDB8: CBNZ x20, #0xb1fdc0        | if (this.tr != null) goto label_51;     
        if(this.tr != null)
        {
            goto label_51;
        }
        // 0x00B1FDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_51:
        // 0x00B1FDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FDC4: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B1FDC8: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_36 = this.tr.position;
        // 0x00B1FDCC: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FDD0: MOV v11.16b, v0.16b        | V11 = val_36.x;//m1                     
        // 0x00B1FDD4: MOV v12.16b, v1.16b        | V12 = val_36.y;//m1                     
        // 0x00B1FDD8: MOV v13.16b, v2.16b        | V13 = val_36.z;//m1                     
        // 0x00B1FDDC: CBNZ x20, #0xb1fde4        | if (this.paths != null) goto label_52;  
        if(this.paths != null)
        {
            goto label_52;
        }
        // 0x00B1FDE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tr, ????);    
        label_52:
        // 0x00B1FDE4: LDR x1, [x23]              | X1 = public System.Int32 System.Collections.Generic.List<UnityEngine.Vector3>::get_Count();
        // 0x00B1FDE8: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FDEC: BL #0x2643344              | X0 = this.paths.get_Count();            
        int val_37 = this.paths.Count;
        // 0x00B1FDF0: CMP w0, #1                 | STATE = COMPARE(val_37, 0x1)            
        // 0x00B1FDF4: B.LT #0xb1fe20             | if (val_37 < 1) goto label_53;          
        if(val_37 < 1)
        {
            goto label_53;
        }
        // 0x00B1FDF8: LDR x20, [x19, #0x78]      | X20 = this.paths; //P2                  
        // 0x00B1FDFC: CBNZ x20, #0xb1fe04        | if (this.paths != null) goto label_54;  
        if(this.paths != null)
        {
            goto label_54;
        }
        // 0x00B1FE00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
        label_54:
        // 0x00B1FE04: LDR x2, [x21]              | X2 = public UnityEngine.Vector3 System.Collections.Generic.List<UnityEngine.Vector3>::get_Item(int index);
        // 0x00B1FE08: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1FE0C: MOV x0, x20                | X0 = this.paths;//m1                    
        // 0x00B1FE10: BL #0x264334c              | X0 = this.paths.get_Item(index:  0);    
        UnityEngine.Vector3 val_38 = this.paths.Item[0];
        // 0x00B1FE14: MOV v8.16b, v0.16b         | V8 = val_38.x;//m1                      
        val_66 = val_38.x;
        // 0x00B1FE18: MOV v9.16b, v1.16b         | V9 = val_38.y;//m1                      
        val_67 = val_38.y;
        // 0x00B1FE1C: MOV v10.16b, v2.16b        | V10 = val_38.z;//m1                     
        val_65 = val_38.z;
        label_53:
        // 0x00B1FE20: CBNZ x19, #0xb1fe28        | if (this != null) goto label_55;        
        if(this != null)
        {
            goto label_55;
        }
        // 0x00B1FE24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.paths, ????); 
        label_55:
        // 0x00B1FE28: MOV v0.16b, v11.16b        | V0 = val_36.x;//m1                      
        // 0x00B1FE2C: MOV v1.16b, v12.16b        | V1 = val_36.y;//m1                      
        // 0x00B1FE30: MOV v2.16b, v13.16b        | V2 = val_36.z;//m1                      
        // 0x00B1FE34: MOV v3.16b, v8.16b         | V3 = val_38.x;//m1                      
        // 0x00B1FE38: MOV v4.16b, v9.16b         | V4 = val_38.y;//m1                      
        // 0x00B1FE3C: MOV v5.16b, v10.16b        | V5 = val_38.z;//m1                      
        // 0x00B1FE40: BL #0xb1f0b8               | X0 = this.paths.VectorAngle(from:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z}, to:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        float val_39 = this.paths.VectorAngle(from:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z}, to:  new UnityEngine.Vector3() {x = val_66, y = val_67, z = val_65});
        // 0x00B1FE44: MOV v8.16b, v0.16b         | V8 = val_39;//m1                        
        val_64 = val_39;
        // 0x00B1FE48: CBNZ x19, #0xb1fe50        | if (this != null) goto label_56;        
        if(this != null)
        {
            goto label_56;
        }
        // 0x00B1FE4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.paths, ????); 
        label_56:
        // 0x00B1FE50: STR s8, [x19, #0x90]       | this.beforflyAngle = val_39;             //  dest_result_addr=1152921515016878144
        this.beforflyAngle = val_64;
        label_2:
        // 0x00B1FE54: ADRP x23, #0x35fe000       | X23 = 56614912 (0x35FE000);             
        // 0x00B1FE58: LDR x23, [x23, #0x810]     | X23 = 1152921504697475072;              
        val_62 = 1152921504697475072;
        // 0x00B1FE5C: LDR x20, [x19, #0x20]      | X20 = this.host; //P2                   
        // 0x00B1FE60: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1FE64: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1FE68: TBZ w8, #0, #0xb1fe78      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_58;
        // 0x00B1FE6C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1FE70: CBNZ w8, #0xb1fe78         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_58;
        // 0x00B1FE74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_58:
        // 0x00B1FE78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FE7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FE80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1FE84: MOV x2, x20                | X2 = this.host;//m1                     
        // 0x00B1FE88: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  0);
        bool val_40 = UnityEngine.Object.op_Equality(x:  0, y:  0);
        // 0x00B1FE8C: AND w8, w0, #1             | W8 = (val_40 & 1);                      
        bool val_41 = val_40;
        // 0x00B1FE90: TBNZ w8, #0, #0xb2012c     | if ((val_40 & 1) == true) goto label_88;
        if(val_41 == true)
        {
            goto label_88;
        }
        // 0x00B1FE94: ADRP x24, #0x35f7000       | X24 = 56586240 (0x35F7000);             
        // 0x00B1FE98: ADRP x25, #0x3646000       | X25 = 56909824 (0x3646000);             
        // 0x00B1FE9C: ADRP x26, #0x35cf000       | X26 = 56422400 (0x35CF000);             
        // 0x00B1FEA0: ADRP x27, #0x3638000       | X27 = 56852480 (0x3638000);             
        // 0x00B1FEA4: ADRP x28, #0x35bf000       | X28 = 56356864 (0x35BF000);             
        // 0x00B1FEA8: LDR x24, [x24, #0xb20]     | X24 = 1152921504901574656;              
        // 0x00B1FEAC: LDR x25, [x25, #0xa00]     | X25 = 1152921510857364848;              
        // 0x00B1FEB0: LDR x26, [x26, #0x628]     | X26 = 1152921510857186288;              
        // 0x00B1FEB4: LDR x27, [x27, #0x2a8]     | X27 = 1152921514932187616;              
        // 0x00B1FEB8: LDR x28, [x28, #0xe98]     | X28 = 1152921514734472752;              
        // 0x00B1FEBC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_77 = 0;
        // 0x00B1FEC0: B #0xb1fec8                |  goto label_60;                         
        goto label_60;
        label_87:
        // 0x00B1FEC4: ADD w20, w20, #1           | W20 = (val_77 + 1) = val_77 (0x00000001);
        val_77 = 1;
        label_60:
        // 0x00B1FEC8: LDR x8, [x24]              | X8 = typeof(GameMgr);                   
        // 0x00B1FECC: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B1FED0: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B1FED4: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B1FED8: CBNZ x21, #0xb1fee0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_61;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_61;
        }
        // 0x00B1FEDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
        label_61:
        // 0x00B1FEE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FEE4: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B1FEE8: MOV x1, x22                | X1 = this.host;//m1                     
        // 0x00B1FEEC: BL #0xc18d48               | X0 = GameMgr.UPDATEOnOffEffect.GetAllEnemy(entity:  this.host);
        System.Collections.Generic.List<CombatEntity> val_42 = GameMgr.UPDATEOnOffEffect.GetAllEnemy(entity:  this.host);
        // 0x00B1FEF0: MOV x21, x0                | X21 = val_42;//m1                       
        val_63 = val_42;
        // 0x00B1FEF4: CBNZ x21, #0xb1fefc        | if (val_42 != null) goto label_62;      
        if(val_63 != null)
        {
            goto label_62;
        }
        // 0x00B1FEF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
        label_62:
        // 0x00B1FEFC: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<CombatEntity>::get_Count();
        // 0x00B1FF00: MOV x0, x21                | X0 = val_42;//m1                        
        // 0x00B1FF04: BL #0x25ed72c              | X0 = val_42.get_Count();                
        int val_43 = val_63.Count;
        // 0x00B1FF08: CMP w20, w0                | STATE = COMPARE(0x1, val_43)            
        // 0x00B1FF0C: B.GE #0xb2012c             | if (val_77 >= val_43) goto label_88;    
        if(val_77 >= val_43)
        {
            goto label_88;
        }
        // 0x00B1FF10: LDR x8, [x24]              | X8 = typeof(GameMgr);                   
        // 0x00B1FF14: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B1FF18: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B1FF1C: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B1FF20: CBNZ x21, #0xb1ff28        | if (GameMgr.UPDATEOnOffEffect != null) goto label_64;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_64;
        }
        // 0x00B1FF24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_64:
        // 0x00B1FF28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FF2C: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B1FF30: MOV x1, x22                | X1 = this.host;//m1                     
        // 0x00B1FF34: BL #0xc18d48               | X0 = GameMgr.UPDATEOnOffEffect.GetAllEnemy(entity:  this.host);
        System.Collections.Generic.List<CombatEntity> val_44 = GameMgr.UPDATEOnOffEffect.GetAllEnemy(entity:  this.host);
        // 0x00B1FF38: MOV x21, x0                | X21 = val_44;//m1                       
        // 0x00B1FF3C: CBNZ x21, #0xb1ff44        | if (val_44 != null) goto label_65;      
        if(val_44 != null)
        {
            goto label_65;
        }
        // 0x00B1FF40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_44, ????);     
        label_65:
        // 0x00B1FF44: LDR x2, [x26]              | X2 = public CombatEntity System.Collections.Generic.List<CombatEntity>::get_Item(int index);
        // 0x00B1FF48: MOV x0, x21                | X0 = val_44;//m1                        
        // 0x00B1FF4C: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00B1FF50: BL #0x25ed734              | X0 = val_44.get_Item(index:  1);        
        CombatEntity val_45 = val_44.Item[1];
        // 0x00B1FF54: MOV x21, x0                | X21 = val_45;//m1                       
        val_63 = val_45;
        // 0x00B1FF58: CBNZ x21, #0xb1ff60        | if (val_45 != null) goto label_66;      
        if(val_63 != null)
        {
            goto label_66;
        }
        // 0x00B1FF5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_66:
        // 0x00B1FF60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FF64: MOV x0, x21                | X0 = val_45;//m1                        
        // 0x00B1FF68: BL #0xd89d88               | X0 = val_45.get_isNotSelected();        
        bool val_46 = val_63.isNotSelected;
        // 0x00B1FF6C: AND w8, w0, #1             | W8 = (val_46 & 1);                      
        bool val_47 = val_46;
        // 0x00B1FF70: TBNZ w8, #0, #0xb1fec4     | if ((val_46 & 1) == true) goto label_87;
        if(val_47 == true)
        {
            goto label_87;
        }
        // 0x00B1FF74: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1FF78: LDR x22, [x19, #0x88]      | X22 = this.c; //P2                      
        // 0x00B1FF7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1FF80: TBZ w8, #0, #0xb1ff90      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_69;
        // 0x00B1FF84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1FF88: CBNZ w8, #0xb1ff90         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
        // 0x00B1FF8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_69:
        // 0x00B1FF90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FF94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FF98: MOV x1, x22                | X1 = this.c;//m1                        
        // 0x00B1FF9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1FFA0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.c);
        bool val_48 = UnityEngine.Object.op_Inequality(x:  0, y:  this.c);
        // 0x00B1FFA4: TBZ w0, #0, #0xb200a8      | if (val_48 == false) goto label_78;     
        if(val_48 == false)
        {
            goto label_78;
        }
        // 0x00B1FFA8: CBNZ x21, #0xb1ffb0        | if (val_45 != null) goto label_71;      
        if(val_63 != null)
        {
            goto label_71;
        }
        // 0x00B1FFAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_71:
        // 0x00B1FFB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1FFB4: MOV x0, x21                | X0 = val_45;//m1                        
        // 0x00B1FFB8: BL #0xd8ee20               | X0 = val_45.get_boxCollider();          
        UnityEngine.Collider val_49 = val_63.boxCollider;
        // 0x00B1FFBC: LDR x8, [x23]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B1FFC0: MOV x22, x0                | X22 = val_49;//m1                       
        // 0x00B1FFC4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1FFC8: TBZ w9, #0, #0xb1ffdc      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_73;
        // 0x00B1FFCC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1FFD0: CBNZ w9, #0xb1ffdc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_73;
        // 0x00B1FFD4: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B1FFD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_73:
        // 0x00B1FFDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1FFE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1FFE4: MOV x1, x22                | X1 = val_49;//m1                        
        // 0x00B1FFE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1FFEC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_49);
        bool val_50 = UnityEngine.Object.op_Inequality(x:  0, y:  val_49);
        // 0x00B1FFF0: TBZ w0, #0, #0xb200a8      | if (val_50 == false) goto label_78;     
        if(val_50 == false)
        {
            goto label_78;
        }
        // 0x00B1FFF4: LDR x22, [x19, #0x88]      | X22 = this.c; //P2                      
        // 0x00B1FFF8: CBNZ x22, #0xb20000        | if (this.c != null) goto label_75;      
        if(this.c != null)
        {
            goto label_75;
        }
        // 0x00B1FFFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_75:
        // 0x00B20000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20004: ADD x8, sp, #0x68          | X8 = (1152921515016865648 + 104) = 1152921515016865752 (0x100000026C7C47D8);
        // 0x00B20008: MOV x0, x22                | X0 = this.c;//m1                        
        // 0x00B2000C: BL #0x26f4a6c              | X0 = this.c.get_bounds();               
        UnityEngine.Bounds val_51 = this.c.bounds;
        // 0x00B20010: LDR x8, [sp, #0x78]        | X8 = val_13;                             //  find_add[1152921515016854000]
        // 0x00B20014: LDUR q0, [sp, #0x68]       | Q0 = val_14;                             //  find_add[1152921515016854000]
        // 0x00B20018: STR x8, [sp, #0x90]        | stack[1152921515016865792] = val_13;     //  dest_result_addr=1152921515016865792
        // 0x00B2001C: STR q0, [sp, #0x80]        | stack[1152921515016865776] = val_14;     //  dest_result_addr=1152921515016865776
        // 0x00B20020: CBNZ x21, #0xb20028        | if (val_45 != null) goto label_76;      
        if(val_63 != null)
        {
            goto label_76;
        }
        // 0x00B20024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.c, ????);     
        label_76:
        // 0x00B20028: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2002C: MOV x0, x21                | X0 = val_45;//m1                        
        // 0x00B20030: BL #0xd8ee20               | X0 = val_45.get_boxCollider();          
        UnityEngine.Collider val_52 = val_63.boxCollider;
        // 0x00B20034: MOV x22, x0                | X22 = val_52;//m1                       
        // 0x00B20038: CBNZ x22, #0xb20040        | if (val_52 != null) goto label_77;      
        if(val_52 != null)
        {
            goto label_77;
        }
        // 0x00B2003C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
        label_77:
        // 0x00B20040: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20044: ADD x8, sp, #0x50          | X8 = (1152921515016865648 + 80) = 1152921515016865728 (0x100000026C7C47C0);
        // 0x00B20048: MOV x0, x22                | X0 = val_52;//m1                        
        // 0x00B2004C: BL #0x26f4a6c              | X0 = val_52.get_bounds();               
        UnityEngine.Bounds val_53 = val_52.bounds;
        // 0x00B20050: LDR x8, [sp, #0x60]        | X8 = val_17;                             //  find_add[1152921515016854000]
        // 0x00B20054: LDR q0, [sp, #0x50]        | Q0 = val_18;                             //  find_add[1152921515016854000]
        // 0x00B20058: ADD x0, sp, #0x80          | X0 = (1152921515016865648 + 128) = 1152921515016865776 (0x100000026C7C47F0);
        // 0x00B2005C: ADD x1, sp, #0x10          | X1 = (1152921515016865648 + 16) = 1152921515016865664 (0x100000026C7C4780);
        // 0x00B20060: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20064: STR x8, [sp, #0x20]        | stack[1152921515016865680] = val_17;     //  dest_result_addr=1152921515016865680
        // 0x00B20068: STR q0, [sp, #0x10]        | stack[1152921515016865664] = val_18;     //  dest_result_addr=1152921515016865664
        // 0x00B2006C: BL #0x20ccb80              | X0 = label_UnityEngine_Bounds_Expand_GL020CCB80();
        // 0x00B20070: TBZ w0, #0, #0xb200a8      | if ((0x100000026C7C47F0 & 0x1) == 0) goto label_78;
        if((1820084208 & 1) == 0)
        {
            goto label_78;
        }
        // 0x00B20074: LDR x22, [x19, #0x98]      | X22 = this.triggerEntityList; //P2      
        // 0x00B20078: CBNZ x22, #0xb20080        | if (this.triggerEntityList != null) goto label_79;
        if(this.triggerEntityList != null)
        {
            goto label_79;
        }
        // 0x00B2007C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000026C7C47F0, ????);
        label_79:
        // 0x00B20080: LDR x2, [x27]              | X2 = public System.Boolean System.Collections.Generic.List<CombatEntity>::Contains(CombatEntity item);
        // 0x00B20084: MOV x0, x22                | X0 = this.triggerEntityList;//m1        
        // 0x00B20088: MOV x1, x21                | X1 = val_45;//m1                        
        // 0x00B2008C: BL #0x25ead74              | X0 = this.triggerEntityList.Contains(item:  val_63);
        bool val_54 = this.triggerEntityList.Contains(item:  val_63);
        // 0x00B20090: AND w8, w0, #1             | W8 = (val_54 & 1);                      
        bool val_55 = val_54;
        // 0x00B20094: TBZ w8, #0, #0xb200e8      | if ((val_54 & 1) == false) goto label_80;
        if(val_55 == false)
        {
            goto label_80;
        }
        // 0x00B20098: MOV x0, x19                | X0 = 1152921515016878000 (0x100000026C7C77B0);//ML01
        val_78 = this;
        // 0x00B2009C: MOV x1, x21                | X1 = val_45;//m1                        
        // 0x00B200A0: BL #0xb20420               | X0 = this.OnStay(entity:  val_63);      
        bool val_56 = this.OnStay(entity:  val_63);
        // 0x00B200A4: B #0xb20118                |  goto label_81;                         
        goto label_81;
        label_78:
        // 0x00B200A8: LDR x22, [x19, #0x98]      | X22 = this.triggerEntityList; //P2      
        // 0x00B200AC: CBNZ x22, #0xb200b4        | if (this.triggerEntityList != null) goto label_82;
        if(this.triggerEntityList != null)
        {
            goto label_82;
        }
        // 0x00B200B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_82:
        // 0x00B200B4: LDR x2, [x27]              | X2 = public System.Boolean System.Collections.Generic.List<CombatEntity>::Contains(CombatEntity item);
        // 0x00B200B8: MOV x0, x22                | X0 = this.triggerEntityList;//m1        
        // 0x00B200BC: MOV x1, x21                | X1 = val_45;//m1                        
        // 0x00B200C0: BL #0x25ead74              | X0 = this.triggerEntityList.Contains(item:  val_63);
        bool val_57 = this.triggerEntityList.Contains(item:  val_63);
        // 0x00B200C4: TBZ w0, #0, #0xb1fec4      | if (val_57 == false) goto label_87;     
        if(val_57 == false)
        {
            goto label_87;
        }
        // 0x00B200C8: LDR x22, [x19, #0x98]      | X22 = this.triggerEntityList; //P2      
        // 0x00B200CC: CBNZ x22, #0xb200d4        | if (this.triggerEntityList != null) goto label_84;
        if(this.triggerEntityList != null)
        {
            goto label_84;
        }
        // 0x00B200D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
        label_84:
        // 0x00B200D4: LDR x2, [x28]              | X2 = public System.Boolean System.Collections.Generic.List<CombatEntity>::Remove(CombatEntity item);
        // 0x00B200D8: MOV x0, x22                | X0 = this.triggerEntityList;//m1        
        // 0x00B200DC: MOV x1, x21                | X1 = val_45;//m1                        
        // 0x00B200E0: BL #0x25ecd20              | X0 = this.triggerEntityList.Remove(item:  val_63);
        bool val_58 = this.triggerEntityList.Remove(item:  val_63);
        // 0x00B200E4: B #0xb1fec4                |  goto label_87;                         
        goto label_87;
        label_80:
        // 0x00B200E8: LDR x22, [x19, #0x98]      | X22 = this.triggerEntityList; //P2      
        // 0x00B200EC: CBNZ x22, #0xb200f4        | if (this.triggerEntityList != null) goto label_86;
        if(this.triggerEntityList != null)
        {
            goto label_86;
        }
        // 0x00B200F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        label_86:
        // 0x00B200F4: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B200F8: LDR x8, [x8, #0xbd0]       | X8 = 1152921514609516304;               
        // 0x00B200FC: MOV x0, x22                | X0 = this.triggerEntityList;//m1        
        // 0x00B20100: MOV x1, x21                | X1 = val_45;//m1                        
        // 0x00B20104: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<CombatEntity>::Add(CombatEntity item);
        // 0x00B20108: BL #0x25ea480              | this.triggerEntityList.Add(item:  val_63);
        this.triggerEntityList.Add(item:  val_63);
        // 0x00B2010C: MOV x0, x19                | X0 = 1152921515016878000 (0x100000026C7C77B0);//ML01
        val_78 = this;
        // 0x00B20110: MOV x1, x21                | X1 = val_45;//m1                        
        // 0x00B20114: BL #0xb20158               | X0 = this.OnEnter(target:  val_63);     
        bool val_59 = this.OnEnter(target:  val_63);
        label_81:
        // 0x00B20118: AND w8, w0, #1             | W8 = (val_59 & 1);                      
        bool val_60 = val_59;
        // 0x00B2011C: TBNZ w8, #0, #0xb1fec4     | if ((val_59 & 1) == true) goto label_87;
        if(val_60 == true)
        {
            goto label_87;
        }
        // 0x00B20120: B #0xb2012c                |  goto label_88;                         
        goto label_88;
        label_29:
        // 0x00B20124: MOV x0, x19                | X0 = 1152921515016878000 (0x100000026C7C77B0);//ML01
        // 0x00B20128: BL #0xb1f1ec               | this.MoveEnd();                         
        this.MoveEnd();
        label_88:
        // 0x00B2012C: SUB sp, x29, #0x80         | SP = (1152921515016865984 - 128) = 1152921515016865856 (0x100000026C7C4840);
        // 0x00B20130: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00B20134: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00B20138: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2013C: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00B20140: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00B20144: LDP x28, x27, [sp, #0x30]  | X28 = ; X27 = ;                          //  | 
        // 0x00B20148: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B2014C: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B20150: LDP d13, d12, [sp], #0x90  | D13 = ; D12 = ;                          //  | 
        // 0x00B20154: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B206E0 (11667168), len: 12  VirtAddr: 0x00B206E0 RVA: 0x00B206E0 token: 100693585 methodIndex: 24694 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetPause()
    {
        //
        // Disasemble & Code
        // 0x00B206E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B206E4: STRB w8, [x0, #0x40]       | this.isPause = true;                     //  dest_result_addr=1152921515017174256
        this.isPause = true;
        // 0x00B206E8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B206EC (11667180), len: 8  VirtAddr: 0x00B206EC RVA: 0x00B206EC token: 100693586 methodIndex: 24695 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetCancelPauer()
    {
        //
        // Disasemble & Code
        // 0x00B206EC: STRB wzr, [x0, #0x40]      | this.isPause = false;                    //  dest_result_addr=1152921515017286256
        this.isPause = false;
        // 0x00B206F0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20158 (11665752), len: 712  VirtAddr: 0x00B20158 RVA: 0x00B20158 token: 100693587 methodIndex: 24696 delegateWrapperIndex: 0 methodInvoker: 0
    private bool OnEnter(CombatEntity target)
    {
        //
        // Disasemble & Code
        //  | 
        string val_17;
        //  | 
        int val_18;
        //  | 
        var val_19;
        // 0x00B20158: STP d9, d8, [sp, #-0x60]!  | stack[1152921515017435248] = ???;  stack[1152921515017435256] = ???;  //  dest_result_addr=1152921515017435248 |  dest_result_addr=1152921515017435256
        // 0x00B2015C: STP x26, x25, [sp, #0x10]  | stack[1152921515017435264] = ???;  stack[1152921515017435272] = ???;  //  dest_result_addr=1152921515017435264 |  dest_result_addr=1152921515017435272
        // 0x00B20160: STP x24, x23, [sp, #0x20]  | stack[1152921515017435280] = ???;  stack[1152921515017435288] = ???;  //  dest_result_addr=1152921515017435280 |  dest_result_addr=1152921515017435288
        // 0x00B20164: STP x22, x21, [sp, #0x30]  | stack[1152921515017435296] = ???;  stack[1152921515017435304] = ???;  //  dest_result_addr=1152921515017435296 |  dest_result_addr=1152921515017435304
        // 0x00B20168: STP x20, x19, [sp, #0x40]  | stack[1152921515017435312] = ???;  stack[1152921515017435320] = ???;  //  dest_result_addr=1152921515017435312 |  dest_result_addr=1152921515017435320
        // 0x00B2016C: STP x29, x30, [sp, #0x50]  | stack[1152921515017435328] = ???;  stack[1152921515017435336] = ???;  //  dest_result_addr=1152921515017435328 |  dest_result_addr=1152921515017435336
        // 0x00B20170: ADD x29, sp, #0x50         | X29 = (1152921515017435248 + 80) = 1152921515017435328 (0x100000026C84F8C0);
        // 0x00B20174: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B20178: LDRB w8, [x21, #0x71b]     | W8 = (bool)static_value_0373371B;       
        // 0x00B2017C: MOV x20, x1                | X20 = target;//m1                       
        // 0x00B20180: MOV x19, x0                | X19 = 1152921515017447344 (0x100000026C8527B0);//ML01
        // 0x00B20184: TBNZ w8, #0, #0xb201a0     | if (static_value_0373371B == true) goto label_0;
        // 0x00B20188: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
        // 0x00B2018C: LDR x8, [x8, #0x2b8]       | X8 = 0x2B8A9D0;                         
        // 0x00B20190: LDR w0, [x8]               | W0 = 0x132;                             
        // 0x00B20194: BL #0x2782188              | X0 = sub_2782188( ?? 0x132, ????);      
        // 0x00B20198: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2019C: STRB w8, [x21, #0x71b]     | static_value_0373371B = true;            //  dest_result_addr=57882395
        label_0:
        // 0x00B201A0: ADRP x25, #0x35f7000       | X25 = 56586240 (0x35F7000);             
        // 0x00B201A4: LDR x25, [x25, #0xb20]     | X25 = 1152921504901574656;              
        // 0x00B201A8: LDR x8, [x25]              | X8 = typeof(GameMgr);                   
        // 0x00B201AC: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B201B0: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        val_17 = GameMgr.UPDATEOnOffEffect;
        // 0x00B201B4: CBNZ x21, #0xb201bc        | if (GameMgr.UPDATEOnOffEffect != null) goto label_1;
        if(val_17 != null)
        {
            goto label_1;
        }
        // 0x00B201B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x132, ????);      
        label_1:
        // 0x00B201BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B201C0: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B201C4: BL #0xc148b8               | X0 = GameMgr.UPDATEOnOffEffect.get_isBattleStart();
        bool val_1 = val_17.isBattleStart;
        // 0x00B201C8: TBZ w0, #0, #0xb20400      | if (val_1 == false) goto label_13;      
        if(val_1 == false)
        {
            goto label_13;
        }
        // 0x00B201CC: LDRB w8, [x19, #0x18]      | W8 = this.isatk; //P2                   
        // 0x00B201D0: CBZ w8, #0xb20400          | if (this.isatk == false) goto label_13; 
        if(this.isatk == false)
        {
            goto label_13;
        }
        // 0x00B201D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B201D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B201DC: BL #0xc9b08c               | X0 = ReplayMgr.get_Instance();          
        ReplayMgr val_2 = ReplayMgr.Instance;
        // 0x00B201E0: MOV x21, x0                | X21 = val_2;//m1                        
        val_17 = val_2;
        // 0x00B201E4: CBNZ x21, #0xb201ec        | if (val_2 != null) goto label_4;        
        if(val_17 != null)
        {
            goto label_4;
        }
        // 0x00B201E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00B201EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B201F0: MOV x0, x21                | X0 = val_2;//m1                         
        // 0x00B201F4: BL #0xc9b1dc               | X0 = val_2.get_IsPlayREC();             
        bool val_3 = val_17.IsPlayREC;
        // 0x00B201F8: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B201FC: TBNZ w8, #0, #0xb20400     | if ((val_3 & 1) == true) goto label_13; 
        if(val_4 == true)
        {
            goto label_13;
        }
        // 0x00B20200: LDR x21, [x19, #0x20]      | X21 = this.host; //P2                   
        val_17 = this.host;
        // 0x00B20204: CBNZ x21, #0xb2020c        | if (this.host != null) goto label_6;    
        if(val_17 != null)
        {
            goto label_6;
        }
        // 0x00B20208: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00B2020C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20210: MOV x0, x21                | X0 = this.host;//m1                     
        // 0x00B20214: BL #0xd89cfc               | X0 = this.host.get_isDeath();           
        bool val_5 = val_17.isDeath;
        // 0x00B20218: AND w8, w0, #1             | W8 = (val_5 & 1);                       
        bool val_6 = val_5;
        // 0x00B2021C: TBNZ w8, #0, #0xb20400     | if ((val_5 & 1) == true) goto label_13; 
        if(val_6 == true)
        {
            goto label_13;
        }
        // 0x00B20220: LDR x21, [x19, #0x20]      | X21 = this.host; //P2                   
        // 0x00B20224: CBNZ x21, #0xb2022c        | if (this.host != null) goto label_8;    
        if(this.host != null)
        {
            goto label_8;
        }
        // 0x00B20228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00B2022C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20230: MOV x0, x21                | X0 = this.host;//m1                     
        // 0x00B20234: BL #0xd89a3c               | X0 = this.host.get_unitCamp();          
        EntityEnum.UnitCamp val_7 = this.host.unitCamp;
        // 0x00B20238: MOV w21, w0                | W21 = val_7;//m1                        
        val_17 = val_7;
        // 0x00B2023C: CBNZ x20, #0xb20244        | if (target != null) goto label_9;       
        if(target != null)
        {
            goto label_9;
        }
        // 0x00B20240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_9:
        // 0x00B20244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20248: MOV x0, x20                | X0 = target;//m1                        
        // 0x00B2024C: BL #0xd89a3c               | X0 = target.get_unitCamp();             
        EntityEnum.UnitCamp val_8 = target.unitCamp;
        // 0x00B20250: CMP w21, w0                | STATE = COMPARE(val_7, val_8)           
        // 0x00B20254: B.EQ #0xb20400             | if (val_17 == val_8) goto label_13;     
        if(val_17 == val_8)
        {
            goto label_13;
        }
        // 0x00B20258: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00B2025C: LDR x8, [x8, #0xfe0]       | X8 = 1152921504899444736;               
        // 0x00B20260: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B20264: LDR w21, [x19, #0x28]      | W21 = this.skillID; //P2                
        // 0x00B20268: LDR x0, [x8]               | X0 = typeof(FightFormula);              
        // 0x00B2026C: LDRB w8, [x0, #0x10a]      | W8 = FightFormula.__il2cppRuntimeField_10A;
        // 0x00B20270: TBZ w8, #0, #0xb20280      | if (FightFormula.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00B20274: LDR w8, [x0, #0xbc]        | W8 = FightFormula.__il2cppRuntimeField_cctor_finished;
        // 0x00B20278: CBNZ w8, #0xb20280         | if (FightFormula.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00B2027C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(FightFormula), ????);
        label_12:
        // 0x00B20280: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20284: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B20288: MOV x1, x22                | X1 = this.host;//m1                     
        // 0x00B2028C: MOV x2, x20                | X2 = target;//m1                        
        // 0x00B20290: MOV w3, w21                | W3 = this.skillID;//m1                  
        // 0x00B20294: BL #0xec979c               | X0 = FightFormula.Damage(self:  0, target:  this.host, skillID:  target);
        DamageResult val_9 = FightFormula.Damage(self:  0, target:  this.host, skillID:  target);
        // 0x00B20298: MOV x21, x0                | X21 = val_9.value;//m1                  
        val_17 = val_9.value;
        // 0x00B2029C: AND w8, w1, #0xff          | W8 = (val_9.damageType & 255);          
        FightEnum.EDamageType val_10 = val_9.damageType & 255;
        // 0x00B202A0: CBZ w8, #0xb20400          | if ((val_9.damageType & 255) == 0) goto label_13;
        if(val_10 == 0)
        {
            goto label_13;
        }
        // 0x00B202A4: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B202A8: LDR w23, [x19, #0x28]      | W23 = this.skillID; //P2                
        val_18 = this.skillID;
        // 0x00B202AC: LSR x24, x21, #0x20        | X24 = (val_9.value >> 32);              
        int val_11 = val_17 >> 32;
        // 0x00B202B0: CBNZ x20, #0xb202b8        | if (target != null) goto label_14;      
        if(target != null)
        {
            goto label_14;
        }
        // 0x00B202B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9.value, ????);
        label_14:
        // 0x00B202B8: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
        // 0x00B202BC: MOV x0, x20                | X0 = target;//m1                        
        // 0x00B202C0: MOV w1, w21                | W1 = val_9.value;//m1                   
        // 0x00B202C4: MOV x2, x22                | X2 = this.host;//m1                     
        // 0x00B202C8: LDR x9, [x8, #0x320]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_320;
        // 0x00B202CC: LDR x5, [x8, #0x328]       | X5 = typeof(CombatEntity).__il2cppRuntimeField_328;
        // 0x00B202D0: MOV w3, w24                | W3 = (val_9.value >> 32);//m1           
        // 0x00B202D4: MOV w4, w23                | W4 = this.skillID;//m1                  
        // 0x00B202D8: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_320();
        // 0x00B202DC: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B202E0: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B202E4: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B202E8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B202EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B202F0: TBZ w8, #0, #0xb20300      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_16;
        // 0x00B202F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B202F8: CBNZ w8, #0xb20300         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
        // 0x00B202FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_16:
        // 0x00B20300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20304: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B20308: MOV x1, x22                | X1 = this.host;//m1                     
        // 0x00B2030C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B20310: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.host);
        bool val_12 = UnityEngine.Object.op_Equality(x:  0, y:  this.host);
        // 0x00B20314: AND w8, w0, #1             | W8 = (val_12 & 1);                      
        bool val_13 = val_12;
        // 0x00B20318: TBZ w8, #0, #0xb20324      | if ((val_12 & 1) == false) goto label_17;
        if(val_13 == false)
        {
            goto label_17;
        }
        // 0x00B2031C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_19 = 0;
        // 0x00B20320: B #0xb20404                |  goto label_18;                         
        goto label_18;
        label_17:
        // 0x00B20324: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B20328: CBNZ x22, #0xb20330        | if (this.host != null) goto label_19;   
        if(this.host != null)
        {
            goto label_19;
        }
        // 0x00B2032C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_19:
        // 0x00B20330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20334: MOV x0, x22                | X0 = this.host;//m1                     
        // 0x00B20338: BL #0xd9b1cc               | X0 = this.host.get_vampire();           
        float val_14 = this.host.vampire;
        // 0x00B2033C: FCMP s0, #0.0              | STATE = COMPARE(val_14, 0)              
        // 0x00B20340: B.LE #0xb203b0             | if (val_14 <= 0) goto label_20;         
        if(val_14 <= 0f)
        {
            goto label_20;
        }
        // 0x00B20344: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B20348: CBNZ x22, #0xb20350        | if (this.host != null) goto label_21;   
        if(this.host != null)
        {
            goto label_21;
        }
        // 0x00B2034C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_21:
        // 0x00B20350: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20354: MOV x0, x22                | X0 = this.host;//m1                     
        // 0x00B20358: BL #0xd9b1cc               | X0 = this.host.get_vampire();           
        float val_15 = this.host.vampire;
        // 0x00B2035C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B20360: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B20364: MOV v8.16b, v0.16b         | V8 = val_15;//m1                        
        // 0x00B20368: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B2036C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B20370: TBZ w8, #0, #0xb20380      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x00B20374: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B20378: CBNZ w8, #0xb20380         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x00B2037C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_23:
        // 0x00B20380: SCVTF s0, w21              | S0 = (float)(val_9.value);              
        float val_17 = (float)val_17;
        // 0x00B20384: FMUL s0, s0, s8            | S0 = (val_9.value * val_15);            
        val_17 = val_17 * val_15;
        // 0x00B20388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2038C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20390: BL #0x1a7dc10              | X0 = UnityEngine.Mathf.CeilToInt(f:  (float)val_17 = (float)val_17 * val_15);
        int val_16 = UnityEngine.Mathf.CeilToInt(f:  val_17);
        // 0x00B20394: MOV w23, w0                | W23 = val_16;//m1                       
        // 0x00B20398: CBNZ x22, #0xb203a0        | if (this.host != null) goto label_24;   
        if(this.host != null)
        {
            goto label_24;
        }
        // 0x00B2039C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_24:
        // 0x00B203A0: SCVTF s0, w23              | S0 = (float)(val_16);                   
        // 0x00B203A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B203A8: MOV x0, x22                | X0 = this.host;//m1                     
        // 0x00B203AC: BL #0xd92c0c               | this.host.AddHP(delta:  (float)val_16); 
        this.host.AddHP(delta:  (float)val_16);
        label_20:
        // 0x00B203B0: LDR x8, [x25]              | X8 = typeof(GameMgr);                   
        // 0x00B203B4: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B203B8: LDR x22, [x8]              | X22 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B203BC: CBNZ x22, #0xb203c4        | if (GameMgr.UPDATEOnOffEffect != null) goto label_25;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_25;
        }
        // 0x00B203C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_25:
        // 0x00B203C4: LDR x22, [x22, #0x48]      | X22 = GameMgr.UPDATEOnOffEffect + 72;    //  not_find_field!2:72
        // 0x00B203C8: LDR x24, [x19, #0x20]      | X24 = this.host; //P2                   
        // 0x00B203CC: LDR w23, [x19, #0x28]      | W23 = this.skillID; //P2                
        val_18 = this.skillID;
        // 0x00B203D0: CBNZ x22, #0xb203d8        | if (GameMgr.UPDATEOnOffEffect + 72 != 0) goto label_26;
        if((GameMgr.UPDATEOnOffEffect + 72) != 0)
        {
            goto label_26;
        }
        // 0x00B203D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_26:
        // 0x00B203D8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B203DC: MOV x0, x22                | X0 = GameMgr.UPDATEOnOffEffect + 72;//m1
        // 0x00B203E0: MOV x1, x24                | X1 = this.host;//m1                     
        // 0x00B203E4: MOV x2, x20                | X2 = target;//m1                        
        // 0x00B203E8: MOV w3, w21                | W3 = val_9.value;//m1                   
        // 0x00B203EC: MOV w4, w23                | W4 = this.skillID;//m1                  
        // 0x00B203F0: BL #0xae67c8               | GameMgr.UPDATEOnOffEffect + 72.AddSkillHurt(hero:  this.host, monster:  target, hurt:  val_17, skillId:  val_18);
        GameMgr.UPDATEOnOffEffect + 72.AddSkillHurt(hero:  this.host, monster:  target, hurt:  val_17, skillId:  val_18);
        // 0x00B203F4: LDR w8, [x19, #0x38]       | W8 = this.Hurt_times; //P2              
        int val_18 = this.Hurt_times;
        // 0x00B203F8: SUB w8, w8, #1             | W8 = (this.Hurt_times - 1);             
        val_18 = val_18 - 1;
        // 0x00B203FC: STR w8, [x19, #0x38]       | this.Hurt_times = (this.Hurt_times - 1);  //  dest_result_addr=1152921515017447400
        this.Hurt_times = val_18;
        label_13:
        // 0x00B20400: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_19 = 1;
        label_18:
        // 0x00B20404: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B20408: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2040C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B20410: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B20414: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B20418: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00B2041C: RET                        |  return (System.Boolean)true;           
        return (bool)val_19;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B20420 (11666464), len: 700  VirtAddr: 0x00B20420 RVA: 0x00B20420 token: 100693588 methodIndex: 24697 delegateWrapperIndex: 0 methodInvoker: 0
    private bool OnStay(CombatEntity entity)
    {
        //
        // Disasemble & Code
        //  | 
        string val_13;
        //  | 
        float val_14;
        //  | 
        int val_15;
        //  | 
        var val_16;
        // 0x00B20420: STP d9, d8, [sp, #-0x60]!  | stack[1152921515017641456] = ???;  stack[1152921515017641464] = ???;  //  dest_result_addr=1152921515017641456 |  dest_result_addr=1152921515017641464
        // 0x00B20424: STP x26, x25, [sp, #0x10]  | stack[1152921515017641472] = ???;  stack[1152921515017641480] = ???;  //  dest_result_addr=1152921515017641472 |  dest_result_addr=1152921515017641480
        // 0x00B20428: STP x24, x23, [sp, #0x20]  | stack[1152921515017641488] = ???;  stack[1152921515017641496] = ???;  //  dest_result_addr=1152921515017641488 |  dest_result_addr=1152921515017641496
        // 0x00B2042C: STP x22, x21, [sp, #0x30]  | stack[1152921515017641504] = ???;  stack[1152921515017641512] = ???;  //  dest_result_addr=1152921515017641504 |  dest_result_addr=1152921515017641512
        // 0x00B20430: STP x20, x19, [sp, #0x40]  | stack[1152921515017641520] = ???;  stack[1152921515017641528] = ???;  //  dest_result_addr=1152921515017641520 |  dest_result_addr=1152921515017641528
        // 0x00B20434: STP x29, x30, [sp, #0x50]  | stack[1152921515017641536] = ???;  stack[1152921515017641544] = ???;  //  dest_result_addr=1152921515017641536 |  dest_result_addr=1152921515017641544
        // 0x00B20438: ADD x29, sp, #0x50         | X29 = (1152921515017641456 + 80) = 1152921515017641536 (0x100000026C881E40);
        // 0x00B2043C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B20440: LDRB w8, [x21, #0x71c]     | W8 = (bool)static_value_0373371C;       
        // 0x00B20444: MOV x20, x1                | X20 = entity;//m1                       
        // 0x00B20448: MOV x19, x0                | X19 = 1152921515017653552 (0x100000026C884D30);//ML01
        // 0x00B2044C: TBNZ w8, #0, #0xb20468     | if (static_value_0373371C == true) goto label_0;
        // 0x00B20450: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
        // 0x00B20454: LDR x8, [x8, #0x788]       | X8 = 0x2B8A9D4;                         
        // 0x00B20458: LDR w0, [x8]               | W0 = 0x133;                             
        // 0x00B2045C: BL #0x2782188              | X0 = sub_2782188( ?? 0x133, ????);      
        // 0x00B20460: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B20464: STRB w8, [x21, #0x71c]     | static_value_0373371C = true;            //  dest_result_addr=57882396
        label_0:
        // 0x00B20468: ADRP x25, #0x35f7000       | X25 = 56586240 (0x35F7000);             
        // 0x00B2046C: LDR x25, [x25, #0xb20]     | X25 = 1152921504901574656;              
        // 0x00B20470: LDR x8, [x25]              | X8 = typeof(GameMgr);                   
        // 0x00B20474: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B20478: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        val_13 = GameMgr.UPDATEOnOffEffect;
        // 0x00B2047C: CBNZ x21, #0xb20484        | if (GameMgr.UPDATEOnOffEffect != null) goto label_1;
        if(val_13 != null)
        {
            goto label_1;
        }
        // 0x00B20480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x133, ????);      
        label_1:
        // 0x00B20484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20488: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00B2048C: BL #0xc148b8               | X0 = GameMgr.UPDATEOnOffEffect.get_isBattleStart();
        bool val_1 = val_13.isBattleStart;
        // 0x00B20490: TBZ w0, #0, #0xb206bc      | if (val_1 == false) goto label_12;      
        if(val_1 == false)
        {
            goto label_12;
        }
        // 0x00B20494: LDRB w8, [x19, #0x18]      | W8 = this.isatk; //P2                   
        // 0x00B20498: CBZ w8, #0xb206bc          | if (this.isatk == false) goto label_12; 
        if(this.isatk == false)
        {
            goto label_12;
        }
        // 0x00B2049C: LDR s8, [x19, #0x3c]       | S8 = this.damage_time; //P2             
        val_14 = this.damage_time;
        // 0x00B204A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B204A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B204A8: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_2 = UnityEngine.Time.time;
        // 0x00B204AC: FSUB s0, s8, s0            | S0 = (this.damage_time - val_2);        
        val_2 = val_14 - val_2;
        // 0x00B204B0: STR s0, [x19, #0x3c]       | this.damage_time = (this.damage_time - val_2);  //  dest_result_addr=1152921515017653612
        this.damage_time = val_2;
        // 0x00B204B4: FCMP s0, #0.0              | STATE = COMPARE((this.damage_time - val_2), 0)
        // 0x00B204B8: B.LS #0xb206bc             | if (val_2 <= 0) goto label_12;          
        if(val_2 <= 0f)
        {
            goto label_12;
        }
        // 0x00B204BC: LDR x21, [x19, #0x30]      | X21 = this.mpJson; //P2                 
        val_13 = this.mpJson;
        // 0x00B204C0: CBNZ x21, #0xb204c8        | if (this.mpJson != null) goto label_5;  
        if(val_13 != null)
        {
            goto label_5;
        }
        // 0x00B204C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x00B204C8: LDR w8, [x21, #0x3c]       | W8 = this.mpJson.damage_time; //P2      
        // 0x00B204CC: LDR w9, [x19, #0x38]       | W9 = this.Hurt_times; //P2              
        // 0x00B204D0: STR w8, [x19, #0x3c]       | this.damage_time = this.mpJson.damage_time;  //  dest_result_addr=1152921515017653612
        this.damage_time = this.mpJson.damage_time;
        // 0x00B204D4: CMP w9, #1                 | STATE = COMPARE(this.Hurt_times, 0x1)   
        // 0x00B204D8: B.LT #0xb206bc             | if (this.Hurt_times < 1) goto label_12; 
        if(this.Hurt_times < 1)
        {
            goto label_12;
        }
        // 0x00B204DC: LDR x21, [x19, #0x20]      | X21 = this.host; //P2                   
        // 0x00B204E0: CBNZ x21, #0xb204e8        | if (this.host != null) goto label_7;    
        if(this.host != null)
        {
            goto label_7;
        }
        // 0x00B204E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_7:
        // 0x00B204E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B204EC: MOV x0, x21                | X0 = this.host;//m1                     
        // 0x00B204F0: BL #0xd89a3c               | X0 = this.host.get_unitCamp();          
        EntityEnum.UnitCamp val_3 = this.host.unitCamp;
        // 0x00B204F4: MOV w21, w0                | W21 = val_3;//m1                        
        val_13 = val_3;
        // 0x00B204F8: CBNZ x20, #0xb20500        | if (entity != null) goto label_8;       
        if(entity != null)
        {
            goto label_8;
        }
        // 0x00B204FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B20500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20504: MOV x0, x20                | X0 = entity;//m1                        
        // 0x00B20508: BL #0xd89a3c               | X0 = entity.get_unitCamp();             
        EntityEnum.UnitCamp val_4 = entity.unitCamp;
        // 0x00B2050C: CMP w21, w0                | STATE = COMPARE(val_3, val_4)           
        // 0x00B20510: B.EQ #0xb206bc             | if (val_13 == val_4) goto label_12;     
        if(val_13 == val_4)
        {
            goto label_12;
        }
        // 0x00B20514: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00B20518: LDR x8, [x8, #0xfe0]       | X8 = 1152921504899444736;               
        // 0x00B2051C: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B20520: LDR w21, [x19, #0x28]      | W21 = this.skillID; //P2                
        // 0x00B20524: LDR x0, [x8]               | X0 = typeof(FightFormula);              
        // 0x00B20528: LDRB w8, [x0, #0x10a]      | W8 = FightFormula.__il2cppRuntimeField_10A;
        // 0x00B2052C: TBZ w8, #0, #0xb2053c      | if (FightFormula.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B20530: LDR w8, [x0, #0xbc]        | W8 = FightFormula.__il2cppRuntimeField_cctor_finished;
        // 0x00B20534: CBNZ w8, #0xb2053c         | if (FightFormula.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B20538: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(FightFormula), ????);
        label_11:
        // 0x00B2053C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20540: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B20544: MOV x1, x22                | X1 = this.host;//m1                     
        // 0x00B20548: MOV x2, x20                | X2 = entity;//m1                        
        // 0x00B2054C: MOV w3, w21                | W3 = this.skillID;//m1                  
        // 0x00B20550: BL #0xec979c               | X0 = FightFormula.Damage(self:  0, target:  this.host, skillID:  entity);
        DamageResult val_5 = FightFormula.Damage(self:  0, target:  this.host, skillID:  entity);
        // 0x00B20554: MOV x21, x0                | X21 = val_5.value;//m1                  
        val_13 = val_5.value;
        // 0x00B20558: AND w8, w1, #0xff          | W8 = (val_5.damageType & 255);          
        FightEnum.EDamageType val_6 = val_5.damageType & 255;
        // 0x00B2055C: CBZ w8, #0xb206bc          | if ((val_5.damageType & 255) == 0) goto label_12;
        if(val_6 == 0)
        {
            goto label_12;
        }
        // 0x00B20560: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B20564: LDR w23, [x19, #0x28]      | W23 = this.skillID; //P2                
        val_15 = this.skillID;
        // 0x00B20568: LSR x24, x21, #0x20        | X24 = (val_5.value >> 32);              
        int val_7 = val_13 >> 32;
        // 0x00B2056C: CBNZ x20, #0xb20574        | if (entity != null) goto label_13;      
        if(entity != null)
        {
            goto label_13;
        }
        // 0x00B20570: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5.value, ????);
        label_13:
        // 0x00B20574: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
        // 0x00B20578: MOV x0, x20                | X0 = entity;//m1                        
        // 0x00B2057C: MOV w1, w21                | W1 = val_5.value;//m1                   
        // 0x00B20580: MOV x2, x22                | X2 = this.host;//m1                     
        // 0x00B20584: LDR x9, [x8, #0x320]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_320;
        // 0x00B20588: LDR x5, [x8, #0x328]       | X5 = typeof(CombatEntity).__il2cppRuntimeField_328;
        // 0x00B2058C: MOV w3, w24                | W3 = (val_5.value >> 32);//m1           
        // 0x00B20590: MOV w4, w23                | W4 = this.skillID;//m1                  
        // 0x00B20594: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_320();
        // 0x00B20598: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B2059C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B205A0: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B205A4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B205A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B205AC: TBZ w8, #0, #0xb205bc      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B205B0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B205B4: CBNZ w8, #0xb205bc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B205B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_15:
        // 0x00B205BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B205C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B205C4: MOV x1, x22                | X1 = this.host;//m1                     
        // 0x00B205C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B205CC: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.host);
        bool val_8 = UnityEngine.Object.op_Equality(x:  0, y:  this.host);
        // 0x00B205D0: AND w8, w0, #1             | W8 = (val_8 & 1);                       
        bool val_9 = val_8;
        // 0x00B205D4: TBZ w8, #0, #0xb205e0      | if ((val_8 & 1) == false) goto label_16;
        if(val_9 == false)
        {
            goto label_16;
        }
        // 0x00B205D8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_16 = 0;
        // 0x00B205DC: B #0xb206c0                |  goto label_17;                         
        goto label_17;
        label_16:
        // 0x00B205E0: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B205E4: CBNZ x22, #0xb205ec        | if (this.host != null) goto label_18;   
        if(this.host != null)
        {
            goto label_18;
        }
        // 0x00B205E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_18:
        // 0x00B205EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B205F0: MOV x0, x22                | X0 = this.host;//m1                     
        // 0x00B205F4: BL #0xd9b1cc               | X0 = this.host.get_vampire();           
        float val_10 = this.host.vampire;
        // 0x00B205F8: FCMP s0, #0.0              | STATE = COMPARE(val_10, 0)              
        // 0x00B205FC: B.LE #0xb2066c             | if (val_10 <= 0) goto label_19;         
        if(val_10 <= 0f)
        {
            goto label_19;
        }
        // 0x00B20600: LDR x22, [x19, #0x20]      | X22 = this.host; //P2                   
        // 0x00B20604: CBNZ x22, #0xb2060c        | if (this.host != null) goto label_20;   
        if(this.host != null)
        {
            goto label_20;
        }
        // 0x00B20608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_20:
        // 0x00B2060C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20610: MOV x0, x22                | X0 = this.host;//m1                     
        // 0x00B20614: BL #0xd9b1cc               | X0 = this.host.get_vampire();           
        float val_11 = this.host.vampire;
        // 0x00B20618: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B2061C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B20620: MOV v8.16b, v0.16b         | V8 = val_11;//m1                        
        val_14 = val_11;
        // 0x00B20624: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B20628: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B2062C: TBZ w8, #0, #0xb2063c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x00B20630: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B20634: CBNZ w8, #0xb2063c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x00B20638: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_22:
        // 0x00B2063C: SCVTF s0, w21              | S0 = (float)(val_5.value);              
        float val_13 = (float)val_13;
        // 0x00B20640: FMUL s0, s0, s8            | S0 = (val_5.value * val_11);            
        val_13 = val_13 * val_14;
        // 0x00B20644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B20648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2064C: BL #0x1a7dc10              | X0 = UnityEngine.Mathf.CeilToInt(f:  (float)val_13 = (float)val_13 * val_14);
        int val_12 = UnityEngine.Mathf.CeilToInt(f:  val_13);
        // 0x00B20650: MOV w23, w0                | W23 = val_12;//m1                       
        // 0x00B20654: CBNZ x22, #0xb2065c        | if (this.host != null) goto label_23;   
        if(this.host != null)
        {
            goto label_23;
        }
        // 0x00B20658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_23:
        // 0x00B2065C: SCVTF s0, w23              | S0 = (float)(val_12);                   
        // 0x00B20660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B20664: MOV x0, x22                | X0 = this.host;//m1                     
        // 0x00B20668: BL #0xd92c0c               | this.host.AddHP(delta:  (float)val_12); 
        this.host.AddHP(delta:  (float)val_12);
        label_19:
        // 0x00B2066C: LDR x8, [x25]              | X8 = typeof(GameMgr);                   
        // 0x00B20670: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00B20674: LDR x22, [x8]              | X22 = GameMgr.UPDATEOnOffEffect;        
        // 0x00B20678: CBNZ x22, #0xb20680        | if (GameMgr.UPDATEOnOffEffect != null) goto label_24;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_24;
        }
        // 0x00B2067C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_24:
        // 0x00B20680: LDR x22, [x22, #0x48]      | X22 = GameMgr.UPDATEOnOffEffect + 72;    //  not_find_field!2:72
        // 0x00B20684: LDR x24, [x19, #0x20]      | X24 = this.host; //P2                   
        // 0x00B20688: LDR w23, [x19, #0x28]      | W23 = this.skillID; //P2                
        val_15 = this.skillID;
        // 0x00B2068C: CBNZ x22, #0xb20694        | if (GameMgr.UPDATEOnOffEffect + 72 != 0) goto label_25;
        if((GameMgr.UPDATEOnOffEffect + 72) != 0)
        {
            goto label_25;
        }
        // 0x00B20690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.host, ????);  
        label_25:
        // 0x00B20694: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00B20698: MOV x0, x22                | X0 = GameMgr.UPDATEOnOffEffect + 72;//m1
        // 0x00B2069C: MOV x1, x24                | X1 = this.host;//m1                     
        // 0x00B206A0: MOV x2, x20                | X2 = entity;//m1                        
        // 0x00B206A4: MOV w3, w21                | W3 = val_5.value;//m1                   
        // 0x00B206A8: MOV w4, w23                | W4 = this.skillID;//m1                  
        // 0x00B206AC: BL #0xae67c8               | GameMgr.UPDATEOnOffEffect + 72.AddSkillHurt(hero:  this.host, monster:  entity, hurt:  val_13, skillId:  val_15);
        GameMgr.UPDATEOnOffEffect + 72.AddSkillHurt(hero:  this.host, monster:  entity, hurt:  val_13, skillId:  val_15);
        // 0x00B206B0: LDR w8, [x19, #0x38]       | W8 = this.Hurt_times; //P2              
        int val_14 = this.Hurt_times;
        // 0x00B206B4: SUB w8, w8, #1             | W8 = (this.Hurt_times - 1);             
        val_14 = val_14 - 1;
        // 0x00B206B8: STR w8, [x19, #0x38]       | this.Hurt_times = (this.Hurt_times - 1);  //  dest_result_addr=1152921515017653608
        this.Hurt_times = val_14;
        label_12:
        // 0x00B206BC: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_16 = 1;
        label_17:
        // 0x00B206C0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B206C4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B206C8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B206CC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B206D0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B206D4: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00B206D8: RET                        |  return (System.Boolean)true;           
        return (bool)val_16;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B206DC (11667164), len: 4  VirtAddr: 0x00B206DC RVA: 0x00B206DC token: 100693589 methodIndex: 24698 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnExit(CombatEntity entity)
    {
        //
        // Disasemble & Code
        // 0x00B206DC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B206F4 (11667188), len: 4  VirtAddr: 0x00B206F4 RVA: 0x00B206F4 token: 100693590 methodIndex: 24699 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetData(System.Action timeOutCall)
    {
        //
        // Disasemble & Code
        // 0x00B206F4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B206F8 (11667192), len: 12  VirtAddr: 0x00B206F8 RVA: 0x00B206F8 token: 100693591 methodIndex: 24700 delegateWrapperIndex: 0 methodInvoker: 0
    private void <Setup>m__0()
    {
        //
        // Disasemble & Code
        // 0x00B206F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B206FC: STRB w8, [x0, #0x60]       | this.IsDo = true;                        //  dest_result_addr=1152921515018051088
        this.IsDo = true;
        // 0x00B20700: RET                        |  return;                                
        return;
    
    }

}
