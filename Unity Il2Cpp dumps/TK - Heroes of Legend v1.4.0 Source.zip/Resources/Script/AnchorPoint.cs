using UnityEngine;
[Serializable]
public class UIRect.AnchorPoint
{
    // Fields
    public UnityEngine.Transform target; //  0x00000010
    public float relative; //  0x00000018
    public int absolute; //  0x0000001C
    public UIRect rect; //  0x00000020
    public UnityEngine.Camera targetCam; //  0x00000028
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0152DDF4 (22207988), len: 8  VirtAddr: 0x0152DDF4 RVA: 0x0152DDF4 token: 100688327 methodIndex: 56609 delegateWrapperIndex: 0 methodInvoker: 0
    public UIRect.AnchorPoint()
    {
        //
        // Disasemble & Code
        // 0x0152DDF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0152DDF8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0152DDFC (22207996), len: 52  VirtAddr: 0x0152DDFC RVA: 0x0152DDFC token: 100688328 methodIndex: 56610 delegateWrapperIndex: 0 methodInvoker: 0
    public UIRect.AnchorPoint(float relative)
    {
        //
        // Disasemble & Code
        // 0x0152DDFC: STP d9, d8, [sp, #-0x30]!  | stack[1152921514223227392] = ???;  stack[1152921514223227400] = ???;  //  dest_result_addr=1152921514223227392 |  dest_result_addr=1152921514223227400
        // 0x0152DE00: STP x20, x19, [sp, #0x10]  | stack[1152921514223227408] = ???;  stack[1152921514223227416] = ???;  //  dest_result_addr=1152921514223227408 |  dest_result_addr=1152921514223227416
        // 0x0152DE04: STP x29, x30, [sp, #0x20]  | stack[1152921514223227424] = ???;  stack[1152921514223227432] = ???;  //  dest_result_addr=1152921514223227424 |  dest_result_addr=1152921514223227432
        // 0x0152DE08: ADD x29, sp, #0x20         | X29 = (1152921514223227392 + 32) = 1152921514223227424 (0x100000023D2E5220);
        // 0x0152DE0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0152DE10: MOV v8.16b, v0.16b         | V8 = relative;//m1                      
        // 0x0152DE14: MOV x19, x0                | X19 = 1152921514223239440 (0x100000023D2E8110);//ML01
        // 0x0152DE18: BL #0x16f59f0              | this..ctor();                           
        // 0x0152DE1C: STR s8, [x19, #0x18]       | this.relative = relative;                //  dest_result_addr=1152921514223239464
        this.relative = relative;
        // 0x0152DE20: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0152DE24: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0152DE28: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x0152DE2C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x01530044 (22216772), len: 140  VirtAddr: 0x01530044 RVA: 0x01530044 token: 100688329 methodIndex: 56611 delegateWrapperIndex: 0 methodInvoker: 0
    public void Set(float relative, float absolute)
    {
        //
        // Disasemble & Code
        // 0x01530044: STP d9, d8, [sp, #-0x30]!  | stack[1152921514223339392] = ???;  stack[1152921514223339400] = ???;  //  dest_result_addr=1152921514223339392 |  dest_result_addr=1152921514223339400
        // 0x01530048: STP x20, x19, [sp, #0x10]  | stack[1152921514223339408] = ???;  stack[1152921514223339416] = ???;  //  dest_result_addr=1152921514223339408 |  dest_result_addr=1152921514223339416
        // 0x0153004C: STP x29, x30, [sp, #0x20]  | stack[1152921514223339424] = ???;  stack[1152921514223339432] = ???;  //  dest_result_addr=1152921514223339424 |  dest_result_addr=1152921514223339432
        // 0x01530050: ADD x29, sp, #0x20         | X29 = (1152921514223339392 + 32) = 1152921514223339424 (0x100000023D3007A0);
        // 0x01530054: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
        // 0x01530058: LDRB w8, [x20, #0x886]     | W8 = (bool)static_value_03737886;       
        // 0x0153005C: MOV v8.16b, v1.16b         | V8 = absolute;//m1                      
        // 0x01530060: MOV v9.16b, v0.16b         | V9 = relative;//m1                      
        // 0x01530064: MOV x19, x0                | X19 = 1152921514223351440 (0x100000023D303690);//ML01
        // 0x01530068: TBNZ w8, #0, #0x1530084    | if (static_value_03737886 == true) goto label_0;
        // 0x0153006C: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
        // 0x01530070: LDR x8, [x8, #0x5f8]       | X8 = 0x2B8AC70;                         
        // 0x01530074: LDR w0, [x8]               | W0 = 0x1DA;                             
        // 0x01530078: BL #0x2782188              | X0 = sub_2782188( ?? 0x1DA, ????);      
        // 0x0153007C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x01530080: STRB w8, [x20, #0x886]     | static_value_03737886 = true;            //  dest_result_addr=57899142
        label_0:
        // 0x01530084: STR s9, [x19, #0x18]       | this.relative = relative;                //  dest_result_addr=1152921514223351464
        this.relative = relative;
        // 0x01530088: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x0153008C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x01530090: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x01530094: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x01530098: TBZ w8, #0, #0x15300a8     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0153009C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x015300A0: CBNZ w8, #0x15300a8        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x015300A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_2:
        // 0x015300A8: FMOV s0, #0.50000000       | S0 = 0.5;                               
        float val_2 = 0.5f;
        // 0x015300AC: FADD s0, s8, s0            | S0 = (absolute + 0.5f);                 
        val_2 = absolute + val_2;
        // 0x015300B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015300B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x015300B8: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  0.5f = absolute + 0.5f);
        int val_1 = UnityEngine.Mathf.FloorToInt(f:  val_2);
        // 0x015300BC: STR w0, [x19, #0x1c]       | this.absolute = val_1;                   //  dest_result_addr=1152921514223351468
        this.absolute = val_1;
        // 0x015300C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x015300C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x015300C8: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x015300CC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x015300D0 (22216912), len: 156  VirtAddr: 0x015300D0 RVA: 0x015300D0 token: 100688330 methodIndex: 56612 delegateWrapperIndex: 0 methodInvoker: 0
    public void Set(UnityEngine.Transform target, float relative, float absolute)
    {
        //
        // Disasemble & Code
        // 0x015300D0: STP d9, d8, [sp, #-0x40]!  | stack[1152921514223455472] = ???;  stack[1152921514223455480] = ???;  //  dest_result_addr=1152921514223455472 |  dest_result_addr=1152921514223455480
        // 0x015300D4: STP x22, x21, [sp, #0x10]  | stack[1152921514223455488] = ???;  stack[1152921514223455496] = ???;  //  dest_result_addr=1152921514223455488 |  dest_result_addr=1152921514223455496
        // 0x015300D8: STP x20, x19, [sp, #0x20]  | stack[1152921514223455504] = ???;  stack[1152921514223455512] = ???;  //  dest_result_addr=1152921514223455504 |  dest_result_addr=1152921514223455512
        // 0x015300DC: STP x29, x30, [sp, #0x30]  | stack[1152921514223455520] = ???;  stack[1152921514223455528] = ???;  //  dest_result_addr=1152921514223455520 |  dest_result_addr=1152921514223455528
        // 0x015300E0: ADD x29, sp, #0x30         | X29 = (1152921514223455472 + 48) = 1152921514223455520 (0x100000023D31CD20);
        // 0x015300E4: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
        // 0x015300E8: LDRB w8, [x21, #0x887]     | W8 = (bool)static_value_03737887;       
        // 0x015300EC: MOV v8.16b, v1.16b         | V8 = absolute;//m1                      
        // 0x015300F0: MOV v9.16b, v0.16b         | V9 = relative;//m1                      
        // 0x015300F4: MOV x20, x1                | X20 = target;//m1                       
        // 0x015300F8: MOV x19, x0                | X19 = 1152921514223467536 (0x100000023D31FC10);//ML01
        // 0x015300FC: TBNZ w8, #0, #0x1530118    | if (static_value_03737887 == true) goto label_0;
        // 0x01530100: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x01530104: LDR x8, [x8, #0x688]       | X8 = 0x2B8AC6C;                         
        // 0x01530108: LDR w0, [x8]               | W0 = 0x1D9;                             
        // 0x0153010C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D9, ????);      
        // 0x01530110: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x01530114: STRB w8, [x21, #0x887]     | static_value_03737887 = true;            //  dest_result_addr=57899143
        label_0:
        // 0x01530118: STR s9, [x19, #0x18]       | this.relative = relative;                //  dest_result_addr=1152921514223467560
        this.relative = relative;
        // 0x0153011C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x01530120: STR x20, [x19, #0x10]      | this.target = target;                    //  dest_result_addr=1152921514223467552
        this.target = target;
        // 0x01530124: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x01530128: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x0153012C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x01530130: TBZ w8, #0, #0x1530140     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x01530134: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x01530138: CBNZ w8, #0x1530140        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0153013C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_2:
        // 0x01530140: FMOV s0, #0.50000000       | S0 = 0.5;                               
        float val_2 = 0.5f;
        // 0x01530144: FADD s0, s8, s0            | S0 = (absolute + 0.5f);                 
        val_2 = absolute + val_2;
        // 0x01530148: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0153014C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530150: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  0.5f = absolute + 0.5f);
        int val_1 = UnityEngine.Mathf.FloorToInt(f:  val_2);
        // 0x01530154: STR w0, [x19, #0x1c]       | this.absolute = val_1;                   //  dest_result_addr=1152921514223467564
        this.absolute = val_1;
        // 0x01530158: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0153015C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x01530160: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x01530164: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x01530168: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0153016C (22217068), len: 28  VirtAddr: 0x0153016C RVA: 0x0153016C token: 100688331 methodIndex: 56613 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetToNearest(float abs0, float abs1, float abs2)
    {
        //
        // Disasemble & Code
        // 0x0153016C: MOV v5.16b, v2.16b         | V5 = abs2;//m1                          
        // 0x01530170: MOV v4.16b, v1.16b         | V4 = abs1;//m1                          
        // 0x01530174: MOV v3.16b, v0.16b         | V3 = abs0;//m1                          
        // 0x01530178: FMOV s0, wzr               | S0 = 0f;                                
        // 0x0153017C: FMOV s1, #0.50000000       | S1 = 0.5;                               
        // 0x01530180: FMOV s2, #1.00000000       | S2 = 1;                                 
        // 0x01530184: B #0x1530188               | this.SetToNearest(rel0:  0f, rel1:  0.5f, rel2:  1f, abs0:  abs0, abs1:  abs1, abs2:  abs2); return;
        this.SetToNearest(rel0:  0f, rel1:  0.5f, rel2:  1f, abs0:  abs0, abs1:  abs1, abs2:  abs2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x01530188 (22217096), len: 232  VirtAddr: 0x01530188 RVA: 0x01530188 token: 100688332 methodIndex: 56614 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetToNearest(float rel0, float rel1, float rel2, float abs0, float abs1, float abs2)
    {
        //
        // Disasemble & Code
        // 0x01530188: STP d13, d12, [sp, #-0x50]! | stack[1152921514223683552] = ???;  stack[1152921514223683560] = ???;  //  dest_result_addr=1152921514223683552 |  dest_result_addr=1152921514223683560
        // 0x0153018C: STP d11, d10, [sp, #0x10]  | stack[1152921514223683568] = ???;  stack[1152921514223683576] = ???;  //  dest_result_addr=1152921514223683568 |  dest_result_addr=1152921514223683576
        // 0x01530190: STP d9, d8, [sp, #0x20]    | stack[1152921514223683584] = ???;  stack[1152921514223683592] = ???;  //  dest_result_addr=1152921514223683584 |  dest_result_addr=1152921514223683592
        // 0x01530194: STP x20, x19, [sp, #0x30]  | stack[1152921514223683600] = ???;  stack[1152921514223683608] = ???;  //  dest_result_addr=1152921514223683600 |  dest_result_addr=1152921514223683608
        // 0x01530198: STP x29, x30, [sp, #0x40]  | stack[1152921514223683616] = ???;  stack[1152921514223683624] = ???;  //  dest_result_addr=1152921514223683616 |  dest_result_addr=1152921514223683624
        // 0x0153019C: ADD x29, sp, #0x40         | X29 = (1152921514223683552 + 64) = 1152921514223683616 (0x100000023D354820);
        // 0x015301A0: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
        // 0x015301A4: LDRB w8, [x20, #0x888]     | W8 = (bool)static_value_03737888;       
        // 0x015301A8: MOV v8.16b, v5.16b         | V8 = abs2;//m1                          
        // 0x015301AC: MOV v9.16b, v4.16b         | V9 = abs1;//m1                          
        // 0x015301B0: MOV v12.16b, v3.16b        | V12 = abs0;//m1                         
        // 0x015301B4: MOV v10.16b, v2.16b        | V10 = rel2;//m1                         
        // 0x015301B8: MOV v11.16b, v1.16b        | V11 = rel1;//m1                         
        // 0x015301BC: MOV v13.16b, v0.16b        | V13 = rel0;//m1                         
        // 0x015301C0: MOV x19, x0                | X19 = 1152921514223695632 (0x100000023D357710);//ML01
        // 0x015301C4: TBNZ w8, #0, #0x15301e0    | if (static_value_03737888 == true) goto label_0;
        // 0x015301C8: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x015301CC: LDR x8, [x8, #0x738]       | X8 = 0x2B8AC78;                         
        // 0x015301D0: LDR w0, [x8]               | W0 = 0x1DC;                             
        // 0x015301D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1DC, ????);      
        // 0x015301D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x015301DC: STRB w8, [x20, #0x888]     | static_value_03737888 = true;            //  dest_result_addr=57899144
        label_0:
        // 0x015301E0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x015301E4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x015301E8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x015301EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x015301F0: TBZ w8, #0, #0x1530200     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x015301F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x015301F8: CBNZ w8, #0x1530200        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x015301FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_2:
        // 0x01530200: FABS s2, s12               | S2 = System.Math.Abs(abs0);             
        float val_1 = System.Math.Abs(abs0);
        // 0x01530204: FABS s0, s9                | S0 = System.Math.Abs(abs1);             
        float val_2 = System.Math.Abs(abs1);
        // 0x01530208: FABS s1, s8                | S1 = System.Math.Abs(abs2);             
        float val_3 = System.Math.Abs(abs2);
        // 0x0153020C: FCMP s2, s0                | STATE = COMPARE(abs0, abs1)             
        // 0x01530210: B.PL #0x153022c            | if (System.Math.Abs(abs0) >= 0) goto label_4;
        if(val_1 >= 0)
        {
            goto label_4;
        }
        // 0x01530214: FCMP s2, s1                | STATE = COMPARE(abs0, abs2)             
        // 0x01530218: B.PL #0x153022c            | if (System.Math.Abs(abs0) >= 0) goto label_4;
        if(val_1 >= 0)
        {
            goto label_4;
        }
        // 0x0153021C: MOV x0, x19                | X0 = 1152921514223695632 (0x100000023D357710);//ML01
        // 0x01530220: MOV v0.16b, v13.16b        | V0 = rel0;//m1                          
        // 0x01530224: MOV v1.16b, v12.16b        | V1 = abs0;//m1                          
        // 0x01530228: B #0x1530258               |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x0153022C: FCMP s0, s2                | STATE = COMPARE(abs1, abs0)             
        // 0x01530230: B.PL #0x153024c            | if (System.Math.Abs(abs1) >= 0) goto label_7;
        if(val_2 >= 0)
        {
            goto label_7;
        }
        // 0x01530234: FCMP s0, s1                | STATE = COMPARE(abs1, abs2)             
        // 0x01530238: B.PL #0x153024c            | if (System.Math.Abs(abs1) >= 0) goto label_7;
        if(val_2 >= 0)
        {
            goto label_7;
        }
        // 0x0153023C: MOV x0, x19                | X0 = 1152921514223695632 (0x100000023D357710);//ML01
        // 0x01530240: MOV v0.16b, v11.16b        | V0 = rel1;//m1                          
        // 0x01530244: MOV v1.16b, v9.16b         | V1 = abs1;//m1                          
        // 0x01530248: B #0x1530258               |  goto label_8;                          
        goto label_8;
        label_7:
        // 0x0153024C: MOV x0, x19                | X0 = 1152921514223695632 (0x100000023D357710);//ML01
        // 0x01530250: MOV v0.16b, v10.16b        | V0 = rel2;//m1                          
        // 0x01530254: MOV v1.16b, v8.16b         | V1 = abs2;//m1                          
        label_8:
        // 0x01530258: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0153025C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x01530260: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x01530264: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x01530268: LDP d13, d12, [sp], #0x50  | D13 = ; D12 = ;                          //  | 
        // 0x0153026C: B #0x1530044               | this.Set(relative:  rel2, absolute:  abs2); return;
        this.Set(relative:  rel2, absolute:  abs2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x01530270 (22217328), len: 496  VirtAddr: 0x01530270 RVA: 0x01530270 token: 100688333 methodIndex: 56615 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetHorizontal(UnityEngine.Transform parent, float localPos)
    {
        //
        // Disasemble & Code
        //  | 
        UIRect val_7;
        //  | 
        AnchorPoint val_8;
        //  | 
        float val_9;
        //  | 
        var val_10;
        //  | 
        float val_11;
        //  | 
        float val_12;
        // 0x01530270: STP d11, d10, [sp, #-0x50]! | stack[1152921514223828320] = ???;  stack[1152921514223828328] = ???;  //  dest_result_addr=1152921514223828320 |  dest_result_addr=1152921514223828328
        // 0x01530274: STP d9, d8, [sp, #0x10]    | stack[1152921514223828336] = ???;  stack[1152921514223828344] = ???;  //  dest_result_addr=1152921514223828336 |  dest_result_addr=1152921514223828344
        // 0x01530278: STP x22, x21, [sp, #0x20]  | stack[1152921514223828352] = ???;  stack[1152921514223828360] = ???;  //  dest_result_addr=1152921514223828352 |  dest_result_addr=1152921514223828360
        // 0x0153027C: STP x20, x19, [sp, #0x30]  | stack[1152921514223828368] = ???;  stack[1152921514223828376] = ???;  //  dest_result_addr=1152921514223828368 |  dest_result_addr=1152921514223828376
        // 0x01530280: STP x29, x30, [sp, #0x40]  | stack[1152921514223828384] = ???;  stack[1152921514223828392] = ???;  //  dest_result_addr=1152921514223828384 |  dest_result_addr=1152921514223828392
        // 0x01530284: ADD x29, sp, #0x40         | X29 = (1152921514223828320 + 64) = 1152921514223828384 (0x100000023D377DA0);
        // 0x01530288: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
        // 0x0153028C: LDRB w8, [x21, #0x889]     | W8 = (bool)static_value_03737889;       
        // 0x01530290: MOV v8.16b, v0.16b         | V8 = localPos;//m1                      
        // 0x01530294: MOV x20, x1                | X20 = parent;//m1                       
        // 0x01530298: MOV x19, x0                | X19 = 1152921514223840400 (0x100000023D37AC90);//ML01
        // 0x0153029C: TBNZ w8, #0, #0x15302b8    | if (static_value_03737889 == true) goto label_0;
        // 0x015302A0: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x015302A4: LDR x8, [x8, #0x6e8]       | X8 = 0x2B8AC74;                         
        // 0x015302A8: LDR w0, [x8]               | W0 = 0x1DB;                             
        // 0x015302AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1DB, ????);      
        // 0x015302B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x015302B4: STRB w8, [x21, #0x889]     | static_value_03737889 = true;            //  dest_result_addr=57899145
        label_0:
        // 0x015302B8: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x015302BC: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        // 0x015302C0: LDR x21, [x19, #0x20]      | X21 = this.rect; //P2                   
        // 0x015302C4: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x015302C8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x015302CC: TBZ w8, #0, #0x15302dc     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x015302D0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x015302D4: CBNZ w8, #0x15302dc        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x015302D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x015302DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015302E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x015302E4: MOV x1, x21                | X1 = this.rect;//m1                     
        // 0x015302E8: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x015302EC: TBZ w0, #0, #0x1530394     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x015302F0: LDR x21, [x19, #0x20]      | X21 = this.rect; //P2                   
        val_7 = this.rect;
        // 0x015302F4: CBNZ x21, #0x15302fc       | if (this.rect != null) goto label_4;    
        if(val_7 != null)
        {
            goto label_4;
        }
        // 0x015302F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x015302FC: LDR x8, [x21]              | X8 = typeof(UIRect);                    
        // 0x01530300: MOV x0, x21                | X0 = this.rect;//m1                     
        // 0x01530304: MOV x1, x20                | X1 = parent;//m1                        
        // 0x01530308: LDP x9, x2, [x8, #0x1e0]   | X9 = typeof(UIRect).__il2cppRuntimeField_1E0; X2 = typeof(UIRect).__il2cppRuntimeField_1E8; //  | 
        // 0x0153030C: BLR x9                     | X0 = typeof(UIRect).__il2cppRuntimeField_1E0();
        // 0x01530310: MOV x20, x0                | X20 = this.rect;//m1                    
        // 0x01530314: CBNZ x20, #0x153031c       | if (this.rect != null) goto label_5;    
        if(val_7 != null)
        {
            goto label_5;
        }
        // 0x01530318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rect, ????);  
        label_5:
        // 0x0153031C: LDR x8, [x20, #0x18]       | X8 = this.rect.leftAnchor; //P2         
        val_8 = this.rect.leftAnchor;
        // 0x01530320: CBNZ w8, #0x1530334        | if (this.rect.leftAnchor != null) goto label_6;
        if(val_8 != null)
        {
            goto label_6;
        }
        // 0x01530324: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.rect, ????);  
        // 0x01530328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0153032C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.rect, ????);  
        // 0x01530330: LDR x8, [x20, #0x18]       | X8 = this.rect.leftAnchor; //P2         
        val_8 = this.rect.leftAnchor;
        label_6:
        // 0x01530334: LDR s9, [x20, #0x20]       | S9 = this.rect.rightAnchor; //P2        
        // 0x01530338: CMP w8, #2                 | STATE = COMPARE(this.rect.leftAnchor, 0x2)
        // 0x0153033C: B.HI #0x153034c            | if (val_8 > 0x2) goto label_7;          
        if(val_8 > 2)
        {
            goto label_7;
        }
        // 0x01530340: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.rect, ????);  
        // 0x01530344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530348: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.rect, ????);  
        label_7:
        // 0x0153034C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x01530350: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x01530354: LDR s11, [x20, #0x38]      | S11 = this.rect.updateAnchors; //P2     
        // 0x01530358: LDR s10, [x19, #0x18]      | S10 = this.relative; //P2               
        val_9 = this.relative;
        // 0x0153035C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x01530360: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x01530364: TBZ w8, #0, #0x1530374     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x01530368: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x0153036C: CBNZ w8, #0x1530374        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x01530370: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_9:
        // 0x01530374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01530378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0153037C: MOV v0.16b, v9.16b         | V0 = this.rect.rightAnchor;//m1         
        // 0x01530380: MOV v1.16b, v11.16b        | V1 = this.rect.updateAnchors;//m1       
        // 0x01530384: MOV v2.16b, v10.16b        | V2 = this.relative;//m1                 
        // 0x01530388: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  this.rect.rightAnchor, b:  this.rect.updateAnchors, t:  val_9);
        float val_2 = UnityEngine.Mathf.Lerp(a:  this.rect.rightAnchor, b:  this.rect.updateAnchors, t:  val_9);
        // 0x0153038C: FSUB s0, s8, s0            | S0 = (localPos - val_2);                
        val_11 = localPos - val_2;
        // 0x01530390: B #0x1530430               |  goto label_10;                         
        goto label_10;
        label_3:
        // 0x01530394: LDR x21, [x19, #0x10]      | X21 = this.target; //P2                 
        val_7 = this.target;
        // 0x01530398: CBNZ x21, #0x15303a0       | if (this.target != null) goto label_11; 
        if(val_7 != null)
        {
            goto label_11;
        }
        // 0x0153039C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_11:
        // 0x015303A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x015303A4: MOV x0, x21                | X0 = this.target;//m1                   
        // 0x015303A8: BL #0x2693510              | X0 = this.target.get_position();        
        UnityEngine.Vector3 val_3 = val_7.position;
        // 0x015303AC: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x015303B0: MOV v9.16b, v0.16b         | V9 = val_3.x;//m1                       
        val_12 = val_3.x;
        // 0x015303B4: MOV v10.16b, v1.16b        | V10 = val_3.y;//m1                      
        val_9 = val_3.y;
        // 0x015303B8: MOV v11.16b, v2.16b        | V11 = val_3.z;//m1                      
        // 0x015303BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x015303C0: TBZ w8, #0, #0x15303d0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x015303C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x015303C8: CBNZ w8, #0x15303d0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x015303CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_13:
        // 0x015303D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015303D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x015303D8: MOV x1, x20                | X1 = parent;//m1                        
        // 0x015303DC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x015303E0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  parent);
        bool val_4 = UnityEngine.Object.op_Inequality(x:  0, y:  parent);
        // 0x015303E4: TBZ w0, #0, #0x153040c     | if (val_4 == false) goto label_14;      
        if(val_4 == false)
        {
            goto label_14;
        }
        // 0x015303E8: CBNZ x20, #0x15303f0       | if (parent != null) goto label_15;      
        if(parent != null)
        {
            goto label_15;
        }
        // 0x015303EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_15:
        // 0x015303F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x015303F4: MOV x0, x20                | X0 = parent;//m1                        
        // 0x015303F8: MOV v0.16b, v9.16b         | V0 = val_3.x;//m1                       
        // 0x015303FC: MOV v1.16b, v10.16b        | V1 = val_3.y;//m1                       
        // 0x01530400: MOV v2.16b, v11.16b        | V2 = val_3.z;//m1                       
        // 0x01530404: BL #0x2695714              | X0 = parent.InverseTransformPoint(position:  new UnityEngine.Vector3() {x = val_12, y = val_9, z = val_3.z});
        UnityEngine.Vector3 val_5 = parent.InverseTransformPoint(position:  new UnityEngine.Vector3() {x = val_12, y = val_9, z = val_3.z});
        // 0x01530408: MOV v9.16b, v0.16b         | V9 = val_5.x;//m1                       
        val_12 = val_5.x;
        label_14:
        // 0x0153040C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x01530410: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x01530414: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x01530418: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x0153041C: TBZ w8, #0, #0x153042c     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x01530420: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x01530424: CBNZ w8, #0x153042c        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x01530428: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_17:
        // 0x0153042C: FSUB s0, s8, s9            | S0 = (localPos - val_5.x);              
        val_11 = localPos - val_12;
        label_10:
        // 0x01530430: FMOV s1, #0.50000000       | S1 = 0.5;                               
        // 0x01530434: FADD s0, s0, s1            | S0 = ((localPos - val_5.x) + 0.5f);     
        val_11 = val_11 + 0.5f;
        // 0x01530438: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0153043C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530440: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  val_11 = val_11 + 0.5f);
        int val_6 = UnityEngine.Mathf.FloorToInt(f:  val_11);
        // 0x01530444: STR w0, [x19, #0x1c]       | this.absolute = val_6;                   //  dest_result_addr=1152921514223840428
        this.absolute = val_6;
        // 0x01530448: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0153044C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x01530450: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x01530454: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x01530458: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x0153045C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x01530460 (22217824), len: 500  VirtAddr: 0x01530460 RVA: 0x01530460 token: 100688334 methodIndex: 56616 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetVertical(UnityEngine.Transform parent, float localPos)
    {
        //
        // Disasemble & Code
        //  | 
        UIRect val_8;
        //  | 
        AnchorPoint val_9;
        //  | 
        float val_10;
        //  | 
        var val_11;
        //  | 
        float val_12;
        //  | 
        float val_13;
        // 0x01530460: STP d11, d10, [sp, #-0x50]! | stack[1152921514224005856] = ???;  stack[1152921514224005864] = ???;  //  dest_result_addr=1152921514224005856 |  dest_result_addr=1152921514224005864
        // 0x01530464: STP d9, d8, [sp, #0x10]    | stack[1152921514224005872] = ???;  stack[1152921514224005880] = ???;  //  dest_result_addr=1152921514224005872 |  dest_result_addr=1152921514224005880
        // 0x01530468: STP x22, x21, [sp, #0x20]  | stack[1152921514224005888] = ???;  stack[1152921514224005896] = ???;  //  dest_result_addr=1152921514224005888 |  dest_result_addr=1152921514224005896
        // 0x0153046C: STP x20, x19, [sp, #0x30]  | stack[1152921514224005904] = ???;  stack[1152921514224005912] = ???;  //  dest_result_addr=1152921514224005904 |  dest_result_addr=1152921514224005912
        // 0x01530470: STP x29, x30, [sp, #0x40]  | stack[1152921514224005920] = ???;  stack[1152921514224005928] = ???;  //  dest_result_addr=1152921514224005920 |  dest_result_addr=1152921514224005928
        // 0x01530474: ADD x29, sp, #0x40         | X29 = (1152921514224005856 + 64) = 1152921514224005920 (0x100000023D3A3320);
        // 0x01530478: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
        // 0x0153047C: LDRB w8, [x21, #0x88a]     | W8 = (bool)static_value_0373788A;       
        // 0x01530480: MOV v8.16b, v0.16b         | V8 = localPos;//m1                      
        // 0x01530484: MOV x20, x1                | X20 = parent;//m1                       
        // 0x01530488: MOV x19, x0                | X19 = 1152921514224017936 (0x100000023D3A6210);//ML01
        // 0x0153048C: TBNZ w8, #0, #0x15304a8    | if (static_value_0373788A == true) goto label_0;
        // 0x01530490: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
        // 0x01530494: LDR x8, [x8, #0x10]        | X8 = 0x2B8AC7C;                         
        // 0x01530498: LDR w0, [x8]               | W0 = 0x1DD;                             
        // 0x0153049C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1DD, ????);      
        // 0x015304A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x015304A4: STRB w8, [x21, #0x88a]     | static_value_0373788A = true;            //  dest_result_addr=57899146
        label_0:
        // 0x015304A8: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x015304AC: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        // 0x015304B0: LDR x21, [x19, #0x20]      | X21 = this.rect; //P2                   
        // 0x015304B4: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x015304B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x015304BC: TBZ w8, #0, #0x15304cc     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x015304C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x015304C4: CBNZ w8, #0x15304cc        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x015304C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x015304CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015304D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x015304D4: MOV x1, x21                | X1 = this.rect;//m1                     
        // 0x015304D8: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x015304DC: TBZ w0, #0, #0x1530588     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x015304E0: LDR x21, [x19, #0x20]      | X21 = this.rect; //P2                   
        val_8 = this.rect;
        // 0x015304E4: CBNZ x21, #0x15304ec       | if (this.rect != null) goto label_4;    
        if(val_8 != null)
        {
            goto label_4;
        }
        // 0x015304E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x015304EC: LDR x8, [x21]              | X8 = typeof(UIRect);                    
        // 0x015304F0: MOV x0, x21                | X0 = this.rect;//m1                     
        // 0x015304F4: MOV x1, x20                | X1 = parent;//m1                        
        // 0x015304F8: LDP x9, x2, [x8, #0x1e0]   | X9 = typeof(UIRect).__il2cppRuntimeField_1E0; X2 = typeof(UIRect).__il2cppRuntimeField_1E8; //  | 
        // 0x015304FC: BLR x9                     | X0 = typeof(UIRect).__il2cppRuntimeField_1E0();
        // 0x01530500: MOV x20, x0                | X20 = this.rect;//m1                    
        // 0x01530504: CBNZ x20, #0x153050c       | if (this.rect != null) goto label_5;    
        if(val_8 != null)
        {
            goto label_5;
        }
        // 0x01530508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rect, ????);  
        label_5:
        // 0x0153050C: LDR x8, [x20, #0x18]       | X8 = this.rect.leftAnchor; //P2         
        val_9 = this.rect.leftAnchor;
        // 0x01530510: CMP w8, #3                 | STATE = COMPARE(this.rect.leftAnchor, 0x3)
        // 0x01530514: B.HI #0x1530528            | if (val_9 > 0x3) goto label_6;          
        if(val_9 > 3)
        {
            goto label_6;
        }
        // 0x01530518: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.rect, ????);  
        // 0x0153051C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530520: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.rect, ????);  
        // 0x01530524: LDR x8, [x20, #0x18]       | X8 = this.rect.leftAnchor; //P2         
        val_9 = this.rect.leftAnchor;
        label_6:
        // 0x01530528: LDR s9, [x20, #0x48]       | S9 = this.rect.mTrans; //P2             
        // 0x0153052C: CMP w8, #1                 | STATE = COMPARE(this.rect.leftAnchor, 0x1)
        // 0x01530530: B.HI #0x1530540            | if (val_9 > 0x1) goto label_7;          
        if(val_9 > 1)
        {
            goto label_7;
        }
        // 0x01530534: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.rect, ????);  
        // 0x01530538: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0153053C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.rect, ????);  
        label_7:
        // 0x01530540: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x01530544: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x01530548: LDR s11, [x20, #0x30]      | S11 = this.rect.topAnchor; //P2         
        // 0x0153054C: LDR s10, [x19, #0x18]      | S10 = this.relative; //P2               
        val_10 = this.relative;
        // 0x01530550: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x01530554: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x01530558: TBZ w8, #0, #0x1530568     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x0153055C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x01530560: CBNZ w8, #0x1530568        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x01530564: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_9:
        // 0x01530568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0153056C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530570: MOV v0.16b, v9.16b         | V0 = this.rect.mTrans;//m1              
        // 0x01530574: MOV v1.16b, v11.16b        | V1 = this.rect.topAnchor;//m1           
        // 0x01530578: MOV v2.16b, v10.16b        | V2 = this.relative;//m1                 
        // 0x0153057C: BL #0x1a7dd1c              | X0 = UnityEngine.Mathf.Lerp(a:  this.rect.mTrans, b:  this.rect.topAnchor, t:  val_10);
        float val_2 = UnityEngine.Mathf.Lerp(a:  this.rect.mTrans, b:  this.rect.topAnchor, t:  val_10);
        // 0x01530580: FSUB s0, s8, s0            | S0 = (localPos - val_2);                
        val_12 = localPos - val_2;
        // 0x01530584: B #0x1530624               |  goto label_10;                         
        goto label_10;
        label_3:
        // 0x01530588: LDR x21, [x19, #0x10]      | X21 = this.target; //P2                 
        val_8 = this.target;
        // 0x0153058C: CBNZ x21, #0x1530594       | if (this.target != null) goto label_11; 
        if(val_8 != null)
        {
            goto label_11;
        }
        // 0x01530590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_11:
        // 0x01530594: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530598: MOV x0, x21                | X0 = this.target;//m1                   
        // 0x0153059C: BL #0x2693510              | X0 = this.target.get_position();        
        UnityEngine.Vector3 val_3 = val_8.position;
        // 0x015305A0: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x015305A4: MOV v10.16b, v0.16b        | V10 = val_3.x;//m1                      
        val_10 = val_3.x;
        // 0x015305A8: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        val_13 = val_3.y;
        // 0x015305AC: MOV v11.16b, v2.16b        | V11 = val_3.z;//m1                      
        // 0x015305B0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x015305B4: TBZ w8, #0, #0x15305c4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x015305B8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x015305BC: CBNZ w8, #0x15305c4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x015305C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_13:
        // 0x015305C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015305C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x015305CC: MOV x1, x20                | X1 = parent;//m1                        
        // 0x015305D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x015305D4: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  parent);
        bool val_4 = UnityEngine.Object.op_Inequality(x:  0, y:  parent);
        // 0x015305D8: TBZ w0, #0, #0x1530600     | if (val_4 == false) goto label_14;      
        if(val_4 == false)
        {
            goto label_14;
        }
        // 0x015305DC: CBNZ x20, #0x15305e4       | if (parent != null) goto label_15;      
        if(parent != null)
        {
            goto label_15;
        }
        // 0x015305E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_15:
        // 0x015305E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x015305E8: MOV x0, x20                | X0 = parent;//m1                        
        // 0x015305EC: MOV v0.16b, v10.16b        | V0 = val_3.x;//m1                       
        // 0x015305F0: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x015305F4: MOV v2.16b, v11.16b        | V2 = val_3.z;//m1                       
        // 0x015305F8: BL #0x2695714              | X0 = parent.InverseTransformPoint(position:  new UnityEngine.Vector3() {x = val_10, y = val_13, z = val_3.z});
        UnityEngine.Vector3 val_5 = parent.InverseTransformPoint(position:  new UnityEngine.Vector3() {x = val_10, y = val_13, z = val_3.z});
        // 0x015305FC: MOV v9.16b, v1.16b         | V9 = val_5.y;//m1                       
        val_13 = val_5.y;
        label_14:
        // 0x01530600: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x01530604: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x01530608: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x0153060C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x01530610: TBZ w8, #0, #0x1530620     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x01530614: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x01530618: CBNZ w8, #0x1530620        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x0153061C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_17:
        // 0x01530620: FSUB s0, s8, s9            | S0 = (localPos - val_5.y);              
        val_12 = localPos - val_13;
        label_10:
        // 0x01530624: FMOV s1, #0.50000000       | S1 = 0.5;                               
        // 0x01530628: FADD s0, s0, s1            | S0 = ((localPos - val_5.y) + 0.5f);     
        val_12 = val_12 + 0.5f;
        // 0x0153062C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01530630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01530634: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  val_12 = val_12 + 0.5f);
        int val_6 = UnityEngine.Mathf.FloorToInt(f:  val_12);
        // 0x01530638: STR w0, [x19, #0x1c]       | this.absolute = val_6;                   //  dest_result_addr=1152921514224017964
        this.absolute = val_6;
        // 0x0153063C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x01530640: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x01530644: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x01530648: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x0153064C: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x01530650: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x01530654 (22218324), len: 436  VirtAddr: 0x01530654 RVA: 0x01530654 token: 100688335 methodIndex: 56617 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Vector3[] GetSides(UnityEngine.Transform relativeTo)
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        UnityEngine.Transform val_17;
        // 0x01530654: STP x24, x23, [sp, #-0x40]! | stack[1152921514224175216] = ???;  stack[1152921514224175224] = ???;  //  dest_result_addr=1152921514224175216 |  dest_result_addr=1152921514224175224
        // 0x01530658: STP x22, x21, [sp, #0x10]  | stack[1152921514224175232] = ???;  stack[1152921514224175240] = ???;  //  dest_result_addr=1152921514224175232 |  dest_result_addr=1152921514224175240
        // 0x0153065C: STP x20, x19, [sp, #0x20]  | stack[1152921514224175248] = ???;  stack[1152921514224175256] = ???;  //  dest_result_addr=1152921514224175248 |  dest_result_addr=1152921514224175256
        // 0x01530660: STP x29, x30, [sp, #0x30]  | stack[1152921514224175264] = ???;  stack[1152921514224175272] = ???;  //  dest_result_addr=1152921514224175264 |  dest_result_addr=1152921514224175272
        // 0x01530664: ADD x29, sp, #0x30         | X29 = (1152921514224175216 + 48) = 1152921514224175264 (0x100000023D3CC8A0);
        // 0x01530668: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
        // 0x0153066C: LDRB w8, [x21, #0x88b]     | W8 = (bool)static_value_0373788B;       
        // 0x01530670: MOV x19, x1                | X19 = relativeTo;//m1                   
        val_14 = relativeTo;
        // 0x01530674: MOV x20, x0                | X20 = 1152921514224187280 (0x100000023D3CF790);//ML01
        val_15 = this;
        // 0x01530678: TBNZ w8, #0, #0x1530694    | if (static_value_0373788B == true) goto label_0;
        // 0x0153067C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x01530680: LDR x8, [x8, #0x630]       | X8 = 0x2B8AC68;                         
        // 0x01530684: LDR w0, [x8]               | W0 = 0x1D8;                             
        // 0x01530688: BL #0x2782188              | X0 = sub_2782188( ?? 0x1D8, ????);      
        // 0x0153068C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x01530690: STRB w8, [x21, #0x88b]     | static_value_0373788B = true;            //  dest_result_addr=57899147
        label_0:
        // 0x01530694: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x01530698: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        val_16 = 1152921504697475072;
        // 0x0153069C: LDR x21, [x20, #0x10]      | X21 = this.target; //P2                 
        val_17 = this.target;
        // 0x015306A0: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x015306A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x015306A8: TBZ w8, #0, #0x15306b8     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x015306AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x015306B0: CBNZ w8, #0x15306b8        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x015306B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x015306B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015306BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x015306C0: MOV x1, x21                | X1 = this.target;//m1                   
        // 0x015306C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x015306C8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_17);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  val_17);
        // 0x015306CC: TBZ w0, #0, #0x15307f0     | if (val_1 == false) goto label_11;      
        if(val_1 == false)
        {
            goto label_11;
        }
        // 0x015306D0: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x015306D4: LDR x21, [x20, #0x20]      | X21 = this.rect; //P2                   
        // 0x015306D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x015306DC: TBZ w8, #0, #0x15306ec     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x015306E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x015306E4: CBNZ w8, #0x15306ec        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x015306E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x015306EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015306F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x015306F4: MOV x1, x21                | X1 = this.rect;//m1                     
        // 0x015306F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x015306FC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.rect);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.rect);
        // 0x01530700: TBZ w0, #0, #0x1530734     | if (val_2 == false) goto label_6;       
        if(val_2 == false)
        {
            goto label_6;
        }
        // 0x01530704: LDR x20, [x20, #0x20]      | X20 = this.rect; //P2                   
        // 0x01530708: CBNZ x20, #0x1530710       | if (this.rect != null) goto label_7;    
        if(this.rect != null)
        {
            goto label_7;
        }
        // 0x0153070C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x01530710: LDR x8, [x20]              | X8 = typeof(UIRect);                    
        // 0x01530714: MOV x0, x20                | X0 = this.rect;//m1                     
        // 0x01530718: MOV x1, x19                | X1 = relativeTo;//m1                    
        // 0x0153071C: LDP x3, x2, [x8, #0x1e0]   | X3 = typeof(UIRect).__il2cppRuntimeField_1E0; X2 = typeof(UIRect).__il2cppRuntimeField_1E8; //  | 
        // 0x01530720: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x01530724: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        val_15 = ???;
        val_14 = ???;
        // 0x01530728: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        val_16 = ???;
        // 0x0153072C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x01530730: BR x3                      | goto typeof(UIRect).__il2cppRuntimeField_1E0;
        goto typeof(UIRect).__il2cppRuntimeField_1E0;
        label_6:
        // 0x01530734: LDR x21, [x20, #0x10]      | X21 = val_15 + 16;                      
        // 0x01530738: CBNZ x21, #0x1530740       | if (val_15 + 16 != 0) goto label_8;     
        if((val_15 + 16) != 0)
        {
            goto label_8;
        }
        // 0x0153073C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.rect, ????);  
        label_8:
        // 0x01530740: ADRP x23, #0x3668000       | X23 = 57049088 (0x3668000);             
        // 0x01530744: LDR x23, [x23, #0x338]     | X23 = 1152921509941328016;              
        // 0x01530748: MOV x0, x21                | X0 = val_15 + 16;//m1                   
        // 0x0153074C: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x01530750: BL #0x23d5410              | X0 = val_15 + 16.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_3 = val_15 + 16.GetComponent<UnityEngine.Camera>();
        // 0x01530754: LDR x8, [x22]              | X8 = ;                                  
        // 0x01530758: MOV x21, x0                | X21 = val_3;//m1                        
        val_17 = val_3;
        // 0x0153075C: LDRB w9, [x8, #0x10a]      | W9 = val_16 + 266;                      
        // 0x01530760: TBZ w9, #0, #0x1530774     | if ((val_16 + 266 & 0x1) == 0) goto label_10;
        if(((val_16 + 266) & 1) == 0)
        {
            goto label_10;
        }
        // 0x01530764: LDR w9, [x8, #0xbc]        | W9 = val_16 + 188;                      
        // 0x01530768: CBNZ w9, #0x1530774        | if (val_16 + 188 != 0) goto label_10;   
        if((val_16 + 188) != 0)
        {
            goto label_10;
        }
        // 0x0153076C: MOV x0, x8                 | X0 = X8;//m1                            
        // 0x01530770: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
        label_10:
        // 0x01530774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01530778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0153077C: MOV x1, x21                | X1 = val_3;//m1                         
        // 0x01530780: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x01530784: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_17);
        bool val_4 = UnityEngine.Object.op_Inequality(x:  0, y:  val_17);
        // 0x01530788: TBZ w0, #0, #0x15307f0     | if (val_4 == false) goto label_11;      
        if(val_4 == false)
        {
            goto label_11;
        }
        // 0x0153078C: LDR x20, [x20, #0x10]      | X20 = val_15 + 16;                      
        // 0x01530790: CBNZ x20, #0x1530798       | if (val_15 + 16 != 0) goto label_12;    
        if((val_15 + 16) != 0)
        {
            goto label_12;
        }
        // 0x01530794: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_12:
        // 0x01530798: LDR x1, [x23]              | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x0153079C: MOV x0, x20                | X0 = val_15 + 16;//m1                   
        // 0x015307A0: BL #0x23d5410              | X0 = val_15 + 16.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_5 = val_15 + 16.GetComponent<UnityEngine.Camera>();
        // 0x015307A4: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x015307A8: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x015307AC: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x015307B0: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x015307B4: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x015307B8: TBZ w9, #0, #0x15307cc     | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x015307BC: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x015307C0: CBNZ w9, #0x15307cc        | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x015307C4: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x015307C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_14:
        // 0x015307CC: MOV x1, x20                | X1 = val_5;//m1                         
        // 0x015307D0: MOV x2, x19                | X2 = X19;//m1                           
        // 0x015307D4: LDP x29, x30, [sp, #0x30]  | X29 = val_6; X30 = val_7;                //  find_add[1152921514224163280] |  find_add[1152921514224163280]
        // 0x015307D8: LDP x20, x19, [sp, #0x20]  | X20 = val_8; X19 = val_9;                //  find_add[1152921514224163280] |  find_add[1152921514224163280]
        // 0x015307DC: LDP x22, x21, [sp, #0x10]  | X22 = val_10; X21 = val_11;              //  find_add[1152921514224163280] |  find_add[1152921514224163280]
        // 0x015307E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x015307E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x015307E8: LDP x24, x23, [sp], #0x40  | X24 = val_12; X23 = val_13;              //  find_add[1152921514224163280] |  find_add[1152921514224163280]
        // 0x015307EC: B #0xd0cb3c                | return NGUITools.GetSides(cam:  0, relativeTo:  val_5);
        return NGUITools.GetSides(cam:  0, relativeTo:  val_5);
        label_11:
        // 0x015307F0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x015307F4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x015307F8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x015307FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x01530800: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x01530804: RET                        |  return (UnityEngine.Vector3[])null;    
        return (UnityEngine.Vector3[])0;
        //  |  // // {name=val_0, type=UnityEngine.Vector3[], size=8, nGRN=0 }
    
    }

}
