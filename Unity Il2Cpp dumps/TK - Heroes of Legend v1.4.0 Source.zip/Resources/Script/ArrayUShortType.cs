using UnityEngine;

namespace wxb
{
    internal class ArrayUShortType : ArraySerialize<ushort>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2C97C (14862716), len: 80  VirtAddr: 0x00E2C97C RVA: 0x00E2C97C token: 100681201 methodIndex: 57241 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayUShortType()
        {
            //
            // Disasemble & Code
            // 0x00E2C97C: STP x20, x19, [sp, #-0x20]! | stack[1152921513025855392] = ???;  stack[1152921513025855400] = ???;  //  dest_result_addr=1152921513025855392 |  dest_result_addr=1152921513025855400
            // 0x00E2C980: STP x29, x30, [sp, #0x10]  | stack[1152921513025855408] = ???;  stack[1152921513025855416] = ???;  //  dest_result_addr=1152921513025855408 |  dest_result_addr=1152921513025855416
            // 0x00E2C984: ADD x29, sp, #0x10         | X29 = (1152921513025855392 + 16) = 1152921513025855408 (0x10000001F5CFDFB0);
            // 0x00E2C988: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C98C: LDRB w8, [x20, #0x8fa]     | W8 = (bool)static_value_037348FA;       
            // 0x00E2C990: MOV x19, x0                | X19 = 1152921513025867424 (0x10000001F5D00EA0);//ML01
            // 0x00E2C994: TBNZ w8, #0, #0xe2c9b0     | if (static_value_037348FA == true) goto label_0;
            // 0x00E2C998: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00E2C99C: LDR x8, [x8, #0x198]       | X8 = 0x2B8E874;                         
            // 0x00E2C9A0: LDR w0, [x8]               | W0 = 0x10DB;                            
            // 0x00E2C9A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x10DB, ????);     
            // 0x00E2C9A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C9AC: STRB w8, [x20, #0x8fa]     | static_value_037348FA = true;            //  dest_result_addr=57886970
            label_0:
            // 0x00E2C9B0: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00E2C9B4: LDR x8, [x8, #0x910]       | X8 = 1152921513025842400;               
            // 0x00E2C9B8: MOV x0, x19                | X0 = 1152921513025867424 (0x10000001F5D00EA0);//ML01
            // 0x00E2C9BC: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.UInt16>::.ctor();
            // 0x00E2C9C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C9C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C9C8: B #0x1d872e0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C9CC (14862796), len: 8  VirtAddr: 0x00E2C9CC RVA: 0x00E2C9CC token: 100681202 methodIndex: 57242 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2C9CC: ORR w0, wzr, #2            | W0 = 2(0x2);                            
            // 0x00E2C9D0: RET                        |  return (System.Int32)2;                
            return (int)2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C9D4 (14862804), len: 52  VirtAddr: 0x00E2C9D4 RVA: 0x00E2C9D4 token: 100681203 methodIndex: 57243 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, ushort value)
        {
            //
            // Disasemble & Code
            // 0x00E2C9D4: STP x20, x19, [sp, #-0x20]! | stack[1152921513026083488] = ???;  stack[1152921513026083496] = ???;  //  dest_result_addr=1152921513026083488 |  dest_result_addr=1152921513026083496
            // 0x00E2C9D8: STP x29, x30, [sp, #0x10]  | stack[1152921513026083504] = ???;  stack[1152921513026083512] = ???;  //  dest_result_addr=1152921513026083504 |  dest_result_addr=1152921513026083512
            // 0x00E2C9DC: ADD x29, sp, #0x10         | X29 = (1152921513026083488 + 16) = 1152921513026083504 (0x10000001F5D35AB0);
            // 0x00E2C9E0: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2C9E4: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2C9E8: CBNZ x20, #0xe2c9f0        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C9EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C9F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C9F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C9F8: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2C9FC: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2CA00: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CA04: B #0x26a478c               | stream.WriteInt16(value:  value); return;
            stream.WriteInt16(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2CA08 (14862856), len: 44  VirtAddr: 0x00E2CA08 RVA: 0x00E2CA08 token: 100681204 methodIndex: 57244 delegateWrapperIndex: 0 methodInvoker: 0
        protected override ushort Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2CA08: STP x20, x19, [sp, #-0x20]! | stack[1152921513026203680] = ???;  stack[1152921513026203688] = ???;  //  dest_result_addr=1152921513026203680 |  dest_result_addr=1152921513026203688
            // 0x00E2CA0C: STP x29, x30, [sp, #0x10]  | stack[1152921513026203696] = ???;  stack[1152921513026203704] = ???;  //  dest_result_addr=1152921513026203696 |  dest_result_addr=1152921513026203704
            // 0x00E2CA10: ADD x29, sp, #0x10         | X29 = (1152921513026203680 + 16) = 1152921513026203696 (0x10000001F5D53030);
            // 0x00E2CA14: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2CA18: CBNZ x19, #0xe2ca20        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2CA1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2CA20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2CA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2CA28: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2CA2C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2CA30: B #0x26a4858               | return stream.ReadUInt16();             
            return stream.ReadUInt16();
        
        }
    
    }

}
