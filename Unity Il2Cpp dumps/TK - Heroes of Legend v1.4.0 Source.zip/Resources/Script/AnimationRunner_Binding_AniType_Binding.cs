using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AnimationRunner_Binding_AniType_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache10; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache11; // static_offset: 0x00000088
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache12; // static_offset: 0x00000090
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache13; // static_offset: 0x00000098
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x000000A0
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x000000A8
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BBE470 (12313712), len: 8  VirtAddr: 0x00BBE470 RVA: 0x00BBE470 token: 100663782 methodIndex: 29827 delegateWrapperIndex: 0 methodInvoker: 0
        public AnimationRunner_Binding_AniType_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BBE470: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE474: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBE478 (12313720), len: 3660  VirtAddr: 0x00BBE478 RVA: 0x00BBE478 token: 100663783 methodIndex: 29828 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_24;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_25;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_26;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_27;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_28;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_45;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_46;
            // 0x00BBE478: STP x24, x23, [sp, #-0x40]! | stack[1152921510047688512] = ???;  stack[1152921510047688520] = ???;  //  dest_result_addr=1152921510047688512 |  dest_result_addr=1152921510047688520
            // 0x00BBE47C: STP x22, x21, [sp, #0x10]  | stack[1152921510047688528] = ???;  stack[1152921510047688536] = ???;  //  dest_result_addr=1152921510047688528 |  dest_result_addr=1152921510047688536
            // 0x00BBE480: STP x20, x19, [sp, #0x20]  | stack[1152921510047688544] = ???;  stack[1152921510047688552] = ???;  //  dest_result_addr=1152921510047688544 |  dest_result_addr=1152921510047688552
            // 0x00BBE484: STP x29, x30, [sp, #0x30]  | stack[1152921510047688560] = ???;  stack[1152921510047688568] = ???;  //  dest_result_addr=1152921510047688560 |  dest_result_addr=1152921510047688568
            // 0x00BBE488: ADD x29, sp, #0x30         | X29 = (1152921510047688512 + 48) = 1152921510047688560 (0x10000001444CA770);
            // 0x00BBE48C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BBE490: LDRB w8, [x20, #0xb72]     | W8 = (bool)static_value_03733B72;       
            // 0x00BBE494: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BBE498: TBNZ w8, #0, #0xbbe4b4     | if (static_value_03733B72 == true) goto label_0;
            // 0x00BBE49C: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00BBE4A0: LDR x8, [x8, #0x2d8]       | X8 = 0x2B8AE70;                         
            // 0x00BBE4A4: LDR w0, [x8]               | W0 = 0x25A;                             
            // 0x00BBE4A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x25A, ????);      
            // 0x00BBE4AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBE4B0: STRB w8, [x20, #0xb72]     | static_value_03733B72 = true;            //  dest_result_addr=57883506
            label_0:
            // 0x00BBE4B4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BBE4B8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BBE4BC: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BBE4C0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00BBE4C4: LDR x8, [x8, #0x1f0]       | X8 = 1152921504922341376;               
            // 0x00BBE4C8: LDR x20, [x8]              | X20 = typeof(AnimationRunner.AniType);  
            // 0x00BBE4CC: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BBE4D0: TBZ w8, #0, #0xbbe4e0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BBE4D4: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BBE4D8: CBNZ w8, #0xbbe4e0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BBE4DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BBE4E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBE4E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBE4E8: MOV x1, x20                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BBE4EC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BBE4F0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BBE4F4: CBNZ x20, #0xbbe4fc        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BBE4F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00BBE4FC: ADRP x9, #0x3667000        | X9 = 57044992 (0x3667000);              
            // 0x00BBE500: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE504: LDR x9, [x9, #0x48]        | X9 = (string**)(1152921510047652384)("none");
            // 0x00BBE508: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE50C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE510: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE514: LDR x1, [x9]               | X1 = "none";                            
            // 0x00BBE518: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE51C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE520: ADRP x24, #0x3616000       | X24 = 56713216 (0x3616000);             
            // 0x00BBE524: LDR x24, [x24, #0x9e8]     | X24 = 1152921504782884864;              
            // 0x00BBE528: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE52C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE530: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE534: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache0;
            val_24 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache0;
            // 0x00BBE538: CBNZ x22, #0xbbe584        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_24 != null)
            {
                goto label_4;
            }
            // 0x00BBE53C: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x00BBE540: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE544: LDR x8, [x8, #0xd58]       | X8 = 1152921510047652464;               
            // 0x00BBE548: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE54C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_none_0(ref object o);
            // 0x00BBE550: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x00BBE554: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE558: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE55C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE560: MOV x2, x22                | X2 = 1152921510047652464 (0x10000001444C1A70);//ML01
            // 0x00BBE564: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_2;
            // 0x00BBE568: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_none_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_none_0(ref object o));
            // 0x00BBE56C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE570: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE574: STR x23, [x8]              | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782888960
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache0 = val_25;
            // 0x00BBE578: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE57C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE580: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_24 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BBE584: CBNZ x19, #0xbbe58c        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BBE588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_none_0(ref object o)), ????);
            label_5:
            // 0x00BBE58C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE590: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE594: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE598: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE59C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_24);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_24);
            // 0x00BBE5A0: CBNZ x20, #0xbbe5a8        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00BBE5A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_6:
            // 0x00BBE5A8: ADRP x9, #0x35de000        | X9 = 56483840 (0x35DE000);              
            // 0x00BBE5AC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE5B0: LDR x9, [x9, #0x4a8]       | X9 = (string**)(1152921510047653488)("win");
            // 0x00BBE5B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE5B8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE5BC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE5C0: LDR x1, [x9]               | X1 = "win";                             
            // 0x00BBE5C4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE5C8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE5CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE5D0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE5D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE5D8: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache1;
            val_26 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache1;
            // 0x00BBE5DC: CBNZ x22, #0xbbe628        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache1 != null) goto label_7;
            if(val_26 != null)
            {
                goto label_7;
            }
            // 0x00BBE5E0: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x00BBE5E4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE5E8: LDR x8, [x8, #0xe10]       | X8 = 1152921510047653568;               
            // 0x00BBE5EC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE5F0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_win_1(ref object o);
            // 0x00BBE5F4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_3 = null;
            // 0x00BBE5F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE5FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE604: MOV x2, x22                | X2 = 1152921510047653568 (0x10000001444C1EC0);//ML01
            // 0x00BBE608: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_3;
            // 0x00BBE60C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_win_1(ref object o));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_win_1(ref object o));
            // 0x00BBE610: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE614: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE618: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782888968
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache1 = val_25;
            // 0x00BBE61C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE620: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE624: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_26 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache1;
            label_7:
            // 0x00BBE628: CBNZ x19, #0xbbe630        | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x00BBE62C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_win_1(ref object o)), ????);
            label_8:
            // 0x00BBE630: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE634: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE638: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE63C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE640: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_26);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_26);
            // 0x00BBE644: CBNZ x20, #0xbbe64c        | if (val_1 != null) goto label_9;        
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x00BBE648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_9:
            // 0x00BBE64C: ADRP x9, #0x35c5000        | X9 = 56381440 (0x35C5000);              
            // 0x00BBE650: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE654: LDR x9, [x9, #0x150]       | X9 = (string**)(1152921510047654592)("idle");
            // 0x00BBE658: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE65C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE660: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE664: LDR x1, [x9]               | X1 = "idle";                            
            // 0x00BBE668: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE66C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE670: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE674: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE678: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE67C: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache2;
            val_27 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache2;
            // 0x00BBE680: CBNZ x22, #0xbbe6cc        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache2 != null) goto label_10;
            if(val_27 != null)
            {
                goto label_10;
            }
            // 0x00BBE684: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00BBE688: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE68C: LDR x8, [x8, #0x520]       | X8 = 1152921510047654672;               
            // 0x00BBE690: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE694: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_idle_2(ref object o);
            // 0x00BBE698: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4 = null;
            // 0x00BBE69C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE6A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE6A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE6A8: MOV x2, x22                | X2 = 1152921510047654672 (0x10000001444C2310);//ML01
            // 0x00BBE6AC: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_4;
            // 0x00BBE6B0: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_idle_2(ref object o));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_idle_2(ref object o));
            // 0x00BBE6B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE6B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE6BC: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782888976
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache2 = val_25;
            // 0x00BBE6C0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE6C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE6C8: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_27 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache2;
            label_10:
            // 0x00BBE6CC: CBNZ x19, #0xbbe6d4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BBE6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_idle_2(ref object o)), ????);
            label_11:
            // 0x00BBE6D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE6D8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE6DC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE6E0: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE6E4: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_27);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_27);
            // 0x00BBE6E8: CBNZ x20, #0xbbe6f0        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BBE6EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BBE6F0: ADRP x9, #0x3674000        | X9 = 57098240 (0x3674000);              
            // 0x00BBE6F4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE6F8: LDR x9, [x9, #0x948]       | X9 = (string**)(1152921510047655696)("run");
            // 0x00BBE6FC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE700: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE704: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE708: LDR x1, [x9]               | X1 = "run";                             
            // 0x00BBE70C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE710: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE714: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE718: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE71C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE720: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache3;
            val_28 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache3;
            // 0x00BBE724: CBNZ x22, #0xbbe770        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache3 != null) goto label_13;
            if(val_28 != null)
            {
                goto label_13;
            }
            // 0x00BBE728: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x00BBE72C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE730: LDR x8, [x8, #0xf08]       | X8 = 1152921510047655776;               
            // 0x00BBE734: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE738: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_run_3(ref object o);
            // 0x00BBE73C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_5 = null;
            // 0x00BBE740: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE74C: MOV x2, x22                | X2 = 1152921510047655776 (0x10000001444C2760);//ML01
            // 0x00BBE750: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_5;
            // 0x00BBE754: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_run_3(ref object o));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_run_3(ref object o));
            // 0x00BBE758: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE75C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE760: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782888984
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache3 = val_25;
            // 0x00BBE764: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE768: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE76C: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_28 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache3;
            label_13:
            // 0x00BBE770: CBNZ x19, #0xbbe778        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BBE774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_run_3(ref object o)), ????);
            label_14:
            // 0x00BBE778: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE77C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE780: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE784: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE788: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_28);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_28);
            // 0x00BBE78C: CBNZ x20, #0xbbe794        | if (val_1 != null) goto label_15;       
            if(val_1 != null)
            {
                goto label_15;
            }
            // 0x00BBE790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_15:
            // 0x00BBE794: ADRP x9, #0x364a000        | X9 = 56926208 (0x364A000);              
            // 0x00BBE798: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE79C: LDR x9, [x9, #0xbe8]       | X9 = (string**)(1152921510047656800)("attack");
            // 0x00BBE7A0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE7A4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE7A8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE7AC: LDR x1, [x9]               | X1 = "attack";                          
            // 0x00BBE7B0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE7B4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE7B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE7BC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE7C0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE7C4: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache4;
            val_29 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache4;
            // 0x00BBE7C8: CBNZ x22, #0xbbe814        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache4 != null) goto label_16;
            if(val_29 != null)
            {
                goto label_16;
            }
            // 0x00BBE7CC: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00BBE7D0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE7D4: LDR x8, [x8, #0xa98]       | X8 = 1152921510047656880;               
            // 0x00BBE7D8: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE7DC: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attack_4(ref object o);
            // 0x00BBE7E0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_6 = null;
            // 0x00BBE7E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE7E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE7EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE7F0: MOV x2, x22                | X2 = 1152921510047656880 (0x10000001444C2BB0);//ML01
            // 0x00BBE7F4: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_6;
            // 0x00BBE7F8: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attack_4(ref object o));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attack_4(ref object o));
            // 0x00BBE7FC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE800: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE804: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782888992
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache4 = val_25;
            // 0x00BBE808: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE80C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE810: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_29 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache4;
            label_16:
            // 0x00BBE814: CBNZ x19, #0xbbe81c        | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x00BBE818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attack_4(ref object o)), ????);
            label_17:
            // 0x00BBE81C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE820: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE824: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE828: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE82C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_29);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_29);
            // 0x00BBE830: CBNZ x20, #0xbbe838        | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x00BBE834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x00BBE838: ADRP x9, #0x362a000        | X9 = 56795136 (0x362A000);              
            // 0x00BBE83C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE840: LDR x9, [x9, #0x7e8]       | X9 = (string**)(1152921510047657904)("attacked");
            // 0x00BBE844: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE848: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE84C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE850: LDR x1, [x9]               | X1 = "attacked";                        
            // 0x00BBE854: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE858: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE85C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE860: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE864: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE868: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache5;
            val_30 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache5;
            // 0x00BBE86C: CBNZ x22, #0xbbe8b8        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache5 != null) goto label_19;
            if(val_30 != null)
            {
                goto label_19;
            }
            // 0x00BBE870: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00BBE874: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE878: LDR x8, [x8, #0xdc8]       | X8 = 1152921510047658000;               
            // 0x00BBE87C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE880: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attacked_5(ref object o);
            // 0x00BBE884: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_7 = null;
            // 0x00BBE888: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE88C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE890: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE894: MOV x2, x22                | X2 = 1152921510047658000 (0x10000001444C3010);//ML01
            // 0x00BBE898: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_7;
            // 0x00BBE89C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attacked_5(ref object o));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attacked_5(ref object o));
            // 0x00BBE8A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE8A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE8A8: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889000
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache5 = val_25;
            // 0x00BBE8AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE8B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE8B4: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_30 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache5;
            label_19:
            // 0x00BBE8B8: CBNZ x19, #0xbbe8c0        | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x00BBE8BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_attacked_5(ref object o)), ????);
            label_20:
            // 0x00BBE8C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE8C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE8C8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE8CC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE8D0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            // 0x00BBE8D4: CBNZ x20, #0xbbe8dc        | if (val_1 != null) goto label_21;       
            if(val_1 != null)
            {
                goto label_21;
            }
            // 0x00BBE8D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_21:
            // 0x00BBE8DC: ADRP x9, #0x367c000        | X9 = 57131008 (0x367C000);              
            // 0x00BBE8E0: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE8E4: LDR x9, [x9, #0x9d0]       | X9 = (string**)(1152921510047659024)("death");
            // 0x00BBE8E8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE8EC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE8F0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE8F4: LDR x1, [x9]               | X1 = "death";                           
            // 0x00BBE8F8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE8FC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE900: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE904: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE908: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE90C: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache6;
            val_31 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache6;
            // 0x00BBE910: CBNZ x22, #0xbbe95c        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache6 != null) goto label_22;
            if(val_31 != null)
            {
                goto label_22;
            }
            // 0x00BBE914: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BBE918: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE91C: LDR x8, [x8, #0x880]       | X8 = 1152921510047659104;               
            // 0x00BBE920: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE924: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_death_6(ref object o);
            // 0x00BBE928: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8 = null;
            // 0x00BBE92C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE934: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE938: MOV x2, x22                | X2 = 1152921510047659104 (0x10000001444C3460);//ML01
            // 0x00BBE93C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_8;
            // 0x00BBE940: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_death_6(ref object o));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_death_6(ref object o));
            // 0x00BBE944: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE948: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE94C: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889008
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache6 = val_25;
            // 0x00BBE950: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE954: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE958: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_31 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache6;
            label_22:
            // 0x00BBE95C: CBNZ x19, #0xbbe964        | if (X1 != 0) goto label_23;             
            if(X1 != 0)
            {
                goto label_23;
            }
            // 0x00BBE960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_death_6(ref object o)), ????);
            label_23:
            // 0x00BBE964: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE968: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBE96C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBE970: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBE974: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_31);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_31);
            // 0x00BBE978: CBNZ x20, #0xbbe980        | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x00BBE97C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_24:
            // 0x00BBE980: ADRP x9, #0x35c9000        | X9 = 56397824 (0x35C9000);              
            // 0x00BBE984: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBE988: LDR x9, [x9, #0x438]       | X9 = (string**)(1152921510047660128)("active");
            // 0x00BBE98C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBE990: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBE994: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBE998: LDR x1, [x9]               | X1 = "active";                          
            // 0x00BBE99C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBE9A0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBE9A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE9A8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBE9AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE9B0: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache7;
            val_32 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache7;
            // 0x00BBE9B4: CBNZ x22, #0xbbea00        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache7 != null) goto label_25;
            if(val_32 != null)
            {
                goto label_25;
            }
            // 0x00BBE9B8: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00BBE9BC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBE9C0: LDR x8, [x8, #0xc30]       | X8 = 1152921510047660208;               
            // 0x00BBE9C4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBE9C8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_active_7(ref object o);
            // 0x00BBE9CC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_9 = null;
            // 0x00BBE9D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBE9D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBE9D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBE9DC: MOV x2, x22                | X2 = 1152921510047660208 (0x10000001444C38B0);//ML01
            // 0x00BBE9E0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_9;
            // 0x00BBE9E4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_active_7(ref object o));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_active_7(ref object o));
            // 0x00BBE9E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE9EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE9F0: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889016
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache7 = val_25;
            // 0x00BBE9F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBE9F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBE9FC: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_32 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache7;
            label_25:
            // 0x00BBEA00: CBNZ x19, #0xbbea08        | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x00BBEA04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_active_7(ref object o)), ????);
            label_26:
            // 0x00BBEA08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEA0C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEA10: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEA14: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEA18: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            // 0x00BBEA1C: CBNZ x20, #0xbbea24        | if (val_1 != null) goto label_27;       
            if(val_1 != null)
            {
                goto label_27;
            }
            // 0x00BBEA20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_27:
            // 0x00BBEA24: ADRP x9, #0x363b000        | X9 = 56864768 (0x363B000);              
            // 0x00BBEA28: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEA2C: LDR x9, [x9, #0xf18]       | X9 = (string**)(1152921510047661232)("rise");
            // 0x00BBEA30: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEA34: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEA38: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEA3C: LDR x1, [x9]               | X1 = "rise";                            
            // 0x00BBEA40: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEA44: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEA48: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEA4C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEA50: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEA54: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache8;
            val_33 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache8;
            // 0x00BBEA58: CBNZ x22, #0xbbeaa4        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache8 != null) goto label_28;
            if(val_33 != null)
            {
                goto label_28;
            }
            // 0x00BBEA5C: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00BBEA60: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEA64: LDR x8, [x8, #0xdf8]       | X8 = 1152921510047661312;               
            // 0x00BBEA68: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEA6C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rise_8(ref object o);
            // 0x00BBEA70: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_10 = null;
            // 0x00BBEA74: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEA78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEA7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEA80: MOV x2, x22                | X2 = 1152921510047661312 (0x10000001444C3D00);//ML01
            // 0x00BBEA84: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_10;
            // 0x00BBEA88: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rise_8(ref object o));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rise_8(ref object o));
            // 0x00BBEA8C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEA90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEA94: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889024
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache8 = val_25;
            // 0x00BBEA98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEA9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEAA0: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_33 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache8;
            label_28:
            // 0x00BBEAA4: CBNZ x19, #0xbbeaac        | if (X1 != 0) goto label_29;             
            if(X1 != 0)
            {
                goto label_29;
            }
            // 0x00BBEAA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rise_8(ref object o)), ????);
            label_29:
            // 0x00BBEAAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEAB0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEAB4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEAB8: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEABC: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_33);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_33);
            // 0x00BBEAC0: CBNZ x20, #0xbbeac8        | if (val_1 != null) goto label_30;       
            if(val_1 != null)
            {
                goto label_30;
            }
            // 0x00BBEAC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_30:
            // 0x00BBEAC8: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
            // 0x00BBEACC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEAD0: LDR x9, [x9, #0xbb0]       | X9 = (string**)(1152921510047662336)("dump");
            // 0x00BBEAD4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEAD8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEADC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEAE0: LDR x1, [x9]               | X1 = "dump";                            
            // 0x00BBEAE4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEAE8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEAEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEAF0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEAF4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEAF8: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache9;
            val_34 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache9;
            // 0x00BBEAFC: CBNZ x22, #0xbbeb48        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache9 != null) goto label_31;
            if(val_34 != null)
            {
                goto label_31;
            }
            // 0x00BBEB00: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00BBEB04: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEB08: LDR x8, [x8, #0xe90]       | X8 = 1152921510047662416;               
            // 0x00BBEB0C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEB10: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_dump_9(ref object o);
            // 0x00BBEB14: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_11 = null;
            // 0x00BBEB18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEB1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEB20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEB24: MOV x2, x22                | X2 = 1152921510047662416 (0x10000001444C4150);//ML01
            // 0x00BBEB28: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_11;
            // 0x00BBEB2C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_dump_9(ref object o));
            val_11 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_dump_9(ref object o));
            // 0x00BBEB30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEB34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEB38: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889032
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache9 = val_25;
            // 0x00BBEB3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEB40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEB44: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_34 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache9;
            label_31:
            // 0x00BBEB48: CBNZ x19, #0xbbeb50        | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x00BBEB4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_dump_9(ref object o)), ????);
            label_32:
            // 0x00BBEB50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEB54: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEB58: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEB5C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEB60: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_34);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_34);
            // 0x00BBEB64: CBNZ x20, #0xbbeb6c        | if (val_1 != null) goto label_33;       
            if(val_1 != null)
            {
                goto label_33;
            }
            // 0x00BBEB68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_33:
            // 0x00BBEB6C: ADRP x9, #0x3673000        | X9 = 57094144 (0x3673000);              
            // 0x00BBEB70: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEB74: LDR x9, [x9, #0x1e0]       | X9 = (string**)(1152921510047663440)("fly");
            // 0x00BBEB78: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEB7C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEB80: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEB84: LDR x1, [x9]               | X1 = "fly";                             
            // 0x00BBEB88: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEB8C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEB90: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEB94: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEB98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEB9C: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheA;
            val_35 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheA;
            // 0x00BBEBA0: CBNZ x22, #0xbbebec        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheA != null) goto label_34;
            if(val_35 != null)
            {
                goto label_34;
            }
            // 0x00BBEBA4: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00BBEBA8: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEBAC: LDR x8, [x8, #0x268]       | X8 = 1152921510047663520;               
            // 0x00BBEBB0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEBB4: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_fly_10(ref object o);
            // 0x00BBEBB8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_12 = null;
            // 0x00BBEBBC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEBC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEBC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEBC8: MOV x2, x22                | X2 = 1152921510047663520 (0x10000001444C45A0);//ML01
            // 0x00BBEBCC: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_12;
            // 0x00BBEBD0: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_fly_10(ref object o));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_fly_10(ref object o));
            // 0x00BBEBD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEBD8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEBDC: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889040
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheA = val_25;
            // 0x00BBEBE0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEBE4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEBE8: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_35 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheA;
            label_34:
            // 0x00BBEBEC: CBNZ x19, #0xbbebf4        | if (X1 != 0) goto label_35;             
            if(X1 != 0)
            {
                goto label_35;
            }
            // 0x00BBEBF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_fly_10(ref object o)), ????);
            label_35:
            // 0x00BBEBF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEBF8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEBFC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEC00: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEC04: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_35);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_35);
            // 0x00BBEC08: CBNZ x20, #0xbbec10        | if (val_1 != null) goto label_36;       
            if(val_1 != null)
            {
                goto label_36;
            }
            // 0x00BBEC0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_36:
            // 0x00BBEC10: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00BBEC14: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEC18: LDR x9, [x9, #0xb0]        | X9 = (string**)(1152921510047664544)("flying");
            // 0x00BBEC1C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEC20: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEC24: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEC28: LDR x1, [x9]               | X1 = "flying";                          
            // 0x00BBEC2C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEC30: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEC34: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEC38: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEC3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEC40: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheB;
            val_36 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheB;
            // 0x00BBEC44: CBNZ x22, #0xbbec90        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheB != null) goto label_37;
            if(val_36 != null)
            {
                goto label_37;
            }
            // 0x00BBEC48: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00BBEC4C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEC50: LDR x8, [x8, #0x780]       | X8 = 1152921510047664624;               
            // 0x00BBEC54: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEC58: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_flying_11(ref object o);
            // 0x00BBEC5C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_13 = null;
            // 0x00BBEC60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEC64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEC68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEC6C: MOV x2, x22                | X2 = 1152921510047664624 (0x10000001444C49F0);//ML01
            // 0x00BBEC70: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_13;
            // 0x00BBEC74: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_flying_11(ref object o));
            val_13 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_flying_11(ref object o));
            // 0x00BBEC78: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEC7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEC80: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889048
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheB = val_25;
            // 0x00BBEC84: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEC88: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEC8C: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_36 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheB;
            label_37:
            // 0x00BBEC90: CBNZ x19, #0xbbec98        | if (X1 != 0) goto label_38;             
            if(X1 != 0)
            {
                goto label_38;
            }
            // 0x00BBEC94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_flying_11(ref object o)), ????);
            label_38:
            // 0x00BBEC98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEC9C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBECA0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBECA4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBECA8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_36);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_36);
            // 0x00BBECAC: CBNZ x20, #0xbbecb4        | if (val_1 != null) goto label_39;       
            if(val_1 != null)
            {
                goto label_39;
            }
            // 0x00BBECB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_39:
            // 0x00BBECB4: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x00BBECB8: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBECBC: LDR x9, [x9, #0x1a0]       | X9 = (string**)(1152921510047665648)("down");
            // 0x00BBECC0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBECC4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBECC8: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBECCC: LDR x1, [x9]               | X1 = "down";                            
            // 0x00BBECD0: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBECD4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBECD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBECDC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBECE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBECE4: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheC;
            val_37 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheC;
            // 0x00BBECE8: CBNZ x22, #0xbbed34        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheC != null) goto label_40;
            if(val_37 != null)
            {
                goto label_40;
            }
            // 0x00BBECEC: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x00BBECF0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBECF4: LDR x8, [x8, #0x778]       | X8 = 1152921510047665728;               
            // 0x00BBECF8: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBECFC: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_down_12(ref object o);
            // 0x00BBED00: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_14 = null;
            // 0x00BBED04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBED08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBED0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBED10: MOV x2, x22                | X2 = 1152921510047665728 (0x10000001444C4E40);//ML01
            // 0x00BBED14: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_14;
            // 0x00BBED18: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_down_12(ref object o));
            val_14 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_down_12(ref object o));
            // 0x00BBED1C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBED20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBED24: STR x23, [x8, #0x60]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889056
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheC = val_25;
            // 0x00BBED28: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBED2C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBED30: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_37 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheC;
            label_40:
            // 0x00BBED34: CBNZ x19, #0xbbed3c        | if (X1 != 0) goto label_41;             
            if(X1 != 0)
            {
                goto label_41;
            }
            // 0x00BBED38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_down_12(ref object o)), ????);
            label_41:
            // 0x00BBED3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBED40: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBED44: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBED48: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBED4C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_37);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_37);
            // 0x00BBED50: CBNZ x20, #0xbbed58        | if (val_1 != null) goto label_42;       
            if(val_1 != null)
            {
                goto label_42;
            }
            // 0x00BBED54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_42:
            // 0x00BBED58: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00BBED5C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBED60: LDR x9, [x9, #0x18]        | X9 = (string**)(1152921510047666752)("Take001");
            // 0x00BBED64: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBED68: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBED6C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBED70: LDR x1, [x9]               | X1 = "Take001";                         
            // 0x00BBED74: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBED78: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBED7C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBED80: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBED84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBED88: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheD;
            val_38 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheD;
            // 0x00BBED8C: CBNZ x22, #0xbbedd8        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheD != null) goto label_43;
            if(val_38 != null)
            {
                goto label_43;
            }
            // 0x00BBED90: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00BBED94: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBED98: LDR x8, [x8, #0x2d0]       | X8 = 1152921510047666848;               
            // 0x00BBED9C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEDA0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_Take001_13(ref object o);
            // 0x00BBEDA4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_15 = null;
            // 0x00BBEDA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEDAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEDB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEDB4: MOV x2, x22                | X2 = 1152921510047666848 (0x10000001444C52A0);//ML01
            // 0x00BBEDB8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_15;
            // 0x00BBEDBC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_Take001_13(ref object o));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_Take001_13(ref object o));
            // 0x00BBEDC0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEDC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEDC8: STR x23, [x8, #0x68]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889064
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheD = val_25;
            // 0x00BBEDCC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEDD0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEDD4: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_38 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheD;
            label_43:
            // 0x00BBEDD8: CBNZ x19, #0xbbede0        | if (X1 != 0) goto label_44;             
            if(X1 != 0)
            {
                goto label_44;
            }
            // 0x00BBEDDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_Take001_13(ref object o)), ????);
            label_44:
            // 0x00BBEDE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEDE4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEDE8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEDEC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEDF0: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_38);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_38);
            // 0x00BBEDF4: CBNZ x20, #0xbbedfc        | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x00BBEDF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_45:
            // 0x00BBEDFC: ADRP x9, #0x35e1000        | X9 = 56496128 (0x35E1000);              
            // 0x00BBEE00: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEE04: LDR x9, [x9, #0xfb8]       | X9 = (string**)(1152921510047667872)("rage");
            // 0x00BBEE08: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEE0C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEE10: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEE14: LDR x1, [x9]               | X1 = "rage";                            
            // 0x00BBEE18: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEE1C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEE20: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEE24: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEE28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEE2C: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheE;
            val_39 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheE;
            // 0x00BBEE30: CBNZ x22, #0xbbee7c        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheE != null) goto label_46;
            if(val_39 != null)
            {
                goto label_46;
            }
            // 0x00BBEE34: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00BBEE38: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEE3C: LDR x8, [x8, #0x870]       | X8 = 1152921510047667952;               
            // 0x00BBEE40: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEE44: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rage_14(ref object o);
            // 0x00BBEE48: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_16 = null;
            // 0x00BBEE4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEE50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEE54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEE58: MOV x2, x22                | X2 = 1152921510047667952 (0x10000001444C56F0);//ML01
            // 0x00BBEE5C: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_16;
            // 0x00BBEE60: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rage_14(ref object o));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rage_14(ref object o));
            // 0x00BBEE64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEE68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEE6C: STR x23, [x8, #0x70]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889072
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheE = val_25;
            // 0x00BBEE70: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEE74: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEE78: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_39 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheE;
            label_46:
            // 0x00BBEE7C: CBNZ x19, #0xbbee84        | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x00BBEE80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_rage_14(ref object o)), ????);
            label_47:
            // 0x00BBEE84: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEE88: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEE8C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEE90: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEE94: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            // 0x00BBEE98: CBNZ x20, #0xbbeea0        | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x00BBEE9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_48:
            // 0x00BBEEA0: ADRP x9, #0x361b000        | X9 = 56733696 (0x361B000);              
            // 0x00BBEEA4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEEA8: LDR x9, [x9, #0x580]       | X9 = (string**)(1152921510047668976)("reborn");
            // 0x00BBEEAC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEEB0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEEB4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEEB8: LDR x1, [x9]               | X1 = "reborn";                          
            // 0x00BBEEBC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEEC0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEEC4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEEC8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEECC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEED0: LDR x22, [x8, #0x78]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheF;
            val_40 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheF;
            // 0x00BBEED4: CBNZ x22, #0xbbef20        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheF != null) goto label_49;
            if(val_40 != null)
            {
                goto label_49;
            }
            // 0x00BBEED8: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
            // 0x00BBEEDC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEEE0: LDR x8, [x8, #0x7c0]       | X8 = 1152921510047669056;               
            // 0x00BBEEE4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEEE8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_reborn_15(ref object o);
            // 0x00BBEEEC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_17 = null;
            // 0x00BBEEF0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEEF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEEF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEEFC: MOV x2, x22                | X2 = 1152921510047669056 (0x10000001444C5B40);//ML01
            // 0x00BBEF00: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_17;
            // 0x00BBEF04: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_reborn_15(ref object o));
            val_17 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_reborn_15(ref object o));
            // 0x00BBEF08: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEF0C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEF10: STR x23, [x8, #0x78]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889080
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheF = val_25;
            // 0x00BBEF14: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEF18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEF1C: LDR x22, [x8, #0x78]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_40 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cacheF;
            label_49:
            // 0x00BBEF20: CBNZ x19, #0xbbef28        | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x00BBEF24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_reborn_15(ref object o)), ????);
            label_50:
            // 0x00BBEF28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEF2C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEF30: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEF34: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEF38: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_40);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_40);
            // 0x00BBEF3C: CBNZ x20, #0xbbef44        | if (val_1 != null) goto label_51;       
            if(val_1 != null)
            {
                goto label_51;
            }
            // 0x00BBEF40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_51:
            // 0x00BBEF44: ADRP x9, #0x35b9000        | X9 = 56332288 (0x35B9000);              
            // 0x00BBEF48: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEF4C: LDR x9, [x9, #0xec8]       | X9 = (string**)(1152921510047670080)("show");
            // 0x00BBEF50: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEF54: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEF58: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBEF5C: LDR x1, [x9]               | X1 = "show";                            
            // 0x00BBEF60: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBEF64: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBEF68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEF6C: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBEF70: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEF74: LDR x22, [x8, #0x80]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache10;
            val_41 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache10;
            // 0x00BBEF78: CBNZ x22, #0xbbefc4        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache10 != null) goto label_52;
            if(val_41 != null)
            {
                goto label_52;
            }
            // 0x00BBEF7C: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BBEF80: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBEF84: LDR x8, [x8, #0x9c0]       | X8 = 1152921510047670160;               
            // 0x00BBEF88: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBEF8C: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_show_16(ref object o);
            // 0x00BBEF90: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_18 = null;
            // 0x00BBEF94: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBEF98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBEF9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEFA0: MOV x2, x22                | X2 = 1152921510047670160 (0x10000001444C5F90);//ML01
            // 0x00BBEFA4: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_18;
            // 0x00BBEFA8: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_show_16(ref object o));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_show_16(ref object o));
            // 0x00BBEFAC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEFB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEFB4: STR x23, [x8, #0x80]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache10 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889088
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache10 = val_25;
            // 0x00BBEFB8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBEFBC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBEFC0: LDR x22, [x8, #0x80]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_41 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache10;
            label_52:
            // 0x00BBEFC4: CBNZ x19, #0xbbefcc        | if (X1 != 0) goto label_53;             
            if(X1 != 0)
            {
                goto label_53;
            }
            // 0x00BBEFC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_show_16(ref object o)), ????);
            label_53:
            // 0x00BBEFCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBEFD0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBEFD4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBEFD8: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBEFDC: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_41);
            // 0x00BBEFE0: CBNZ x20, #0xbbefe8        | if (val_1 != null) goto label_54;       
            if(val_1 != null)
            {
                goto label_54;
            }
            // 0x00BBEFE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_54:
            // 0x00BBEFE8: ADRP x9, #0x365c000        | X9 = 56999936 (0x365C000);              
            // 0x00BBEFEC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBEFF0: LDR x9, [x9, #0xf68]       | X9 = (string**)(1152921510047671184)("qiyuan");
            // 0x00BBEFF4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBEFF8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBEFFC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBF000: LDR x1, [x9]               | X1 = "qiyuan";                          
            // 0x00BBF004: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBF008: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBF00C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF010: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBF014: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF018: LDR x22, [x8, #0x88]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache11;
            val_42 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache11;
            // 0x00BBF01C: CBNZ x22, #0xbbf068        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache11 != null) goto label_55;
            if(val_42 != null)
            {
                goto label_55;
            }
            // 0x00BBF020: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00BBF024: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBF028: LDR x8, [x8, #0xcf0]       | X8 = 1152921510047671264;               
            // 0x00BBF02C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBF030: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_qiyuan_17(ref object o);
            // 0x00BBF034: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_19 = null;
            // 0x00BBF038: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBF03C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF040: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF044: MOV x2, x22                | X2 = 1152921510047671264 (0x10000001444C63E0);//ML01
            // 0x00BBF048: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_19;
            // 0x00BBF04C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_qiyuan_17(ref object o));
            val_19 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_qiyuan_17(ref object o));
            // 0x00BBF050: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF054: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF058: STR x23, [x8, #0x88]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache11 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889096
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache11 = val_25;
            // 0x00BBF05C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF060: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF064: LDR x22, [x8, #0x88]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_42 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache11;
            label_55:
            // 0x00BBF068: CBNZ x19, #0xbbf070        | if (X1 != 0) goto label_56;             
            if(X1 != 0)
            {
                goto label_56;
            }
            // 0x00BBF06C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_qiyuan_17(ref object o)), ????);
            label_56:
            // 0x00BBF070: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF074: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBF078: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBF07C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBF080: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_42);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_42);
            // 0x00BBF084: CBNZ x20, #0xbbf08c        | if (val_1 != null) goto label_57;       
            if(val_1 != null)
            {
                goto label_57;
            }
            // 0x00BBF088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_57:
            // 0x00BBF08C: ADRP x9, #0x35f7000        | X9 = 56586240 (0x35F7000);              
            // 0x00BBF090: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBF094: LDR x9, [x9, #0x4b0]       | X9 = (string**)(1152921510047672288)("passive1");
            // 0x00BBF098: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBF09C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBF0A0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBF0A4: LDR x1, [x9]               | X1 = "passive1";                        
            // 0x00BBF0A8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBF0AC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBF0B0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF0B4: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBF0B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF0BC: LDR x22, [x8, #0x90]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache12;
            val_43 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache12;
            // 0x00BBF0C0: CBNZ x22, #0xbbf10c        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache12 != null) goto label_58;
            if(val_43 != null)
            {
                goto label_58;
            }
            // 0x00BBF0C4: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00BBF0C8: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBF0CC: LDR x8, [x8, #0x510]       | X8 = 1152921510047672384;               
            // 0x00BBF0D0: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBF0D4: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_passive1_18(ref object o);
            // 0x00BBF0D8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_20 = null;
            // 0x00BBF0DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBF0E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF0E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF0E8: MOV x2, x22                | X2 = 1152921510047672384 (0x10000001444C6840);//ML01
            // 0x00BBF0EC: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_20;
            // 0x00BBF0F0: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_passive1_18(ref object o));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_passive1_18(ref object o));
            // 0x00BBF0F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF0F8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF0FC: STR x23, [x8, #0x90]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache12 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889104
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache12 = val_25;
            // 0x00BBF100: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF104: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF108: LDR x22, [x8, #0x90]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_43 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache12;
            label_58:
            // 0x00BBF10C: CBNZ x19, #0xbbf114        | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x00BBF110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_passive1_18(ref object o)), ????);
            label_59:
            // 0x00BBF114: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF118: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBF11C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBF120: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBF124: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_43);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_43);
            // 0x00BBF128: CBNZ x20, #0xbbf130        | if (val_1 != null) goto label_60;       
            if(val_1 != null)
            {
                goto label_60;
            }
            // 0x00BBF12C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_60:
            // 0x00BBF130: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x00BBF134: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BBF138: LDR x9, [x9, #0x5a0]       | X9 = (string**)(1152921510047673408)("showidle");
            // 0x00BBF13C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BBF140: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BBF144: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BBF148: LDR x1, [x9]               | X1 = "showidle";                        
            // 0x00BBF14C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BBF150: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BBF154: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF158: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BBF15C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF160: LDR x22, [x8, #0x98]       | X22 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache13;
            val_44 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache13;
            // 0x00BBF164: CBNZ x22, #0xbbf1b0        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache13 != null) goto label_61;
            if(val_44 != null)
            {
                goto label_61;
            }
            // 0x00BBF168: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00BBF16C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BBF170: LDR x8, [x8, #0xfe8]       | X8 = 1152921510047673504;               
            // 0x00BBF174: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BBF178: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_showidle_19(ref object o);
            // 0x00BBF17C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_21 = null;
            // 0x00BBF180: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BBF184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF188: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF18C: MOV x2, x22                | X2 = 1152921510047673504 (0x10000001444C6CA0);//ML01
            // 0x00BBF190: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_25 = val_21;
            // 0x00BBF194: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_showidle_19(ref object o));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_showidle_19(ref object o));
            // 0x00BBF198: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF19C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF1A0: STR x23, [x8, #0x98]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache13 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782889112
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache13 = val_25;
            // 0x00BBF1A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF1A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF1AC: LDR x22, [x8, #0x98]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_44 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__mg$cache13;
            label_61:
            // 0x00BBF1B0: CBNZ x19, #0xbbf1b8        | if (X1 != 0) goto label_62;             
            if(X1 != 0)
            {
                goto label_62;
            }
            // 0x00BBF1B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::get_showidle_19(ref object o)), ????);
            label_62:
            // 0x00BBF1B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF1BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBF1C0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BBF1C4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BBF1C8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_44);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_44);
            // 0x00BBF1CC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF1D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF1D4: LDR x21, [x8, #0xa0]       | X21 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache0;
            val_45 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache0;
            // 0x00BBF1D8: CBNZ x21, #0xbbf224        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache0 != null) goto label_63;
            if(val_45 != null)
            {
                goto label_63;
            }
            // 0x00BBF1DC: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00BBF1E0: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BBF1E4: LDR x8, [x8, #0xd68]       | X8 = 1152921510047674528;               
            // 0x00BBF1E8: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BBF1EC: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__0();
            // 0x00BBF1F0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_22 = null;
            // 0x00BBF1F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BBF1F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF1FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF200: MOV x2, x21                | X2 = 1152921510047674528 (0x10000001444C70A0);//ML01
            // 0x00BBF204: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BBF208: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__0());
            val_22 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__0());
            // 0x00BBF20C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF210: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF214: STR x22, [x8, #0xa0]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504782889120
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache0 = val_22;
            // 0x00BBF218: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF21C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF220: LDR x21, [x8, #0xa0]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_45 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache0;
            label_63:
            // 0x00BBF224: CBNZ x19, #0xbbf22c        | if (X1 != 0) goto label_64;             
            if(X1 != 0)
            {
                goto label_64;
            }
            // 0x00BBF228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__0()), ????);
            label_64:
            // 0x00BBF22C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF230: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBF234: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BBF238: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BBF23C: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_45);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_45);
            // 0x00BBF240: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF244: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF248: LDR x21, [x8, #0xa8]       | X21 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache1;
            val_46 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache1;
            // 0x00BBF24C: CBNZ x21, #0xbbf298        | if (ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache1 != null) goto label_65;
            if(val_46 != null)
            {
                goto label_65;
            }
            // 0x00BBF250: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x00BBF254: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BBF258: LDR x8, [x8, #0x288]       | X8 = 1152921510047675552;               
            // 0x00BBF25C: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BBF260: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__1(int s);
            // 0x00BBF264: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_23 = null;
            // 0x00BBF268: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BBF26C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF270: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF274: MOV x2, x21                | X2 = 1152921510047675552 (0x10000001444C74A0);//ML01
            // 0x00BBF278: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BBF27C: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__1(int s));
            val_23 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__1(int s));
            // 0x00BBF280: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF284: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF288: STR x22, [x8, #0xa8]       | ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504782889128
            ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache1 = val_23;
            // 0x00BBF28C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding);
            // 0x00BBF290: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BBF294: LDR x21, [x8, #0xa8]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_46 = ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding.<>f__am$cache1;
            label_65:
            // 0x00BBF298: CBNZ x19, #0xbbf2a0        | if (X1 != 0) goto label_66;             
            if(X1 != 0)
            {
                goto label_66;
            }
            // 0x00BBF29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimationRunner_Binding_AniType_Binding::<Register>m__1(int s)), ????);
            label_66:
            // 0x00BBF2A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BBF2A4: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BBF2A8: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BBF2AC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBF2B0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBF2B4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBF2B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF2BC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BBF2C0: B #0x28e5bd8               | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_46); return;
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_46);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBF2C4 (12317380), len: 1644  VirtAddr: 0x00BBF2C4 RVA: 0x00BBF2C4 token: 100663784 methodIndex: 29829 delegateWrapperIndex: 0 methodInvoker: 0
        private static void WriteBackInstance(ILRuntime.Runtime.Enviorment.AppDomain __domain, ILRuntime.Runtime.Stack.StackObject* ptr_of_this_method, System.Collections.Generic.IList<object> __mStack, ref AnimationRunner.AniType instance_of_this_method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_10;
            //  | 
            var val_12;
            //  | 
            var val_20;
            //  | 
            object val_21;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            int val_26;
            // 0x00BBF2C4: STP x24, x23, [sp, #-0x40]! | stack[1152921510047861888] = ???;  stack[1152921510047861896] = ???;  //  dest_result_addr=1152921510047861888 |  dest_result_addr=1152921510047861896
            // 0x00BBF2C8: STP x22, x21, [sp, #0x10]  | stack[1152921510047861904] = ???;  stack[1152921510047861912] = ???;  //  dest_result_addr=1152921510047861904 |  dest_result_addr=1152921510047861912
            // 0x00BBF2CC: STP x20, x19, [sp, #0x20]  | stack[1152921510047861920] = ???;  stack[1152921510047861928] = ???;  //  dest_result_addr=1152921510047861920 |  dest_result_addr=1152921510047861928
            // 0x00BBF2D0: STP x29, x30, [sp, #0x30]  | stack[1152921510047861936] = ???;  stack[1152921510047861944] = ???;  //  dest_result_addr=1152921510047861936 |  dest_result_addr=1152921510047861944
            // 0x00BBF2D4: ADD x29, sp, #0x30         | X29 = (1152921510047861888 + 48) = 1152921510047861936 (0x10000001444F4CB0);
            // 0x00BBF2D8: SUB sp, sp, #0x40          | SP = (1152921510047861888 - 64) = 1152921510047861824 (0x10000001444F4C40);
            // 0x00BBF2DC: ADRP x23, #0x3733000       | X23 = 57880576 (0x3733000);             
            // 0x00BBF2E0: LDRB w8, [x23, #0xb73]     | W8 = (bool)static_value_03733B73;       
            // 0x00BBF2E4: MOV x19, x4                | X19 = X4;//m1                           
            val_21 = X4;
            // 0x00BBF2E8: MOV x21, x3                | X21 = X3;//m1                           
            val_22 = X3;
            // 0x00BBF2EC: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BBF2F0: MOV x22, x1                | X22 = X1;//m1                           
            // 0x00BBF2F4: TBNZ w8, #0, #0xbbf310     | if (static_value_03733B73 == true) goto label_0;
            // 0x00BBF2F8: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00BBF2FC: LDR x8, [x8, #0x1a8]       | X8 = 0x2B8AE7C;                         
            // 0x00BBF300: LDR w0, [x8]               | W0 = 0x25D;                             
            // 0x00BBF304: BL #0x2782188              | X0 = sub_2782188( ?? 0x25D, ????);      
            // 0x00BBF308: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBF30C: STRB w8, [x23, #0xb73]     | static_value_03733B73 = true;            //  dest_result_addr=57883507
            label_0:
            // 0x00BBF310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BBF314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBF318: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BBF31C: STR xzr, [sp, #0x18]       | stack[1152921510047861848] = 0x0;        //  dest_result_addr=1152921510047861848
            // 0x00BBF320: BL #0x1f93c50              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.GetObjectAndResolveReference(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_1 = ILRuntime.Runtime.Intepreter.ILIntepreter.GetObjectAndResolveReference(esp:  null);
            // 0x00BBF324: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BBF328: CBNZ x20, #0xbbf330        | if (val_1 != 0) goto label_1;           
            if(val_1 != 0)
            {
                goto label_1;
            }
            // 0x00BBF32C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x00BBF330: LDR w8, [x20]              | W8 = val_1;                             
            var val_20 = val_1;
            // 0x00BBF334: SUB w8, w8, #6             | W8 = (val_1 - 6);                       
            val_20 = val_20 - 6;
            // 0x00BBF338: CMP w8, #5                 | STATE = COMPARE((val_1 - 6), 0x5)       
            // 0x00BBF33C: B.HI #0xbbf8e0             | if (val_1 > 0x5) goto label_51;         
            if(val_20 > 5)
            {
                goto label_51;
            }
            // 0x00BBF340: ADRP x9, #0x2a93000        | X9 = 44642304 (0x2A93000);              
            // 0x00BBF344: ADD x9, x9, #0x3f0         | X9 = (44642304 + 1008) = 44643312 (0x02A933F0);
            // 0x00BBF348: LDR w8, [x9, w8, sxtw #2]  | W8 = 44643312 + ((val_1 - 6)) << 2;     
            var val_21 = 44643312 + ((val_1 - 6)) << 2;
            // 0x00BBF34C: SUB w8, w8, #3             | W8 = (44643312 + ((val_1 - 6)) << 2 - 3);
            val_21 = val_21 - 3;
            // 0x00BBF350: CMP w8, #4                 | STATE = COMPARE((44643312 + ((val_1 - 6)) << 2 - 3), 0x4)
            // 0x00BBF354: B.HI #0xbbf8e0             | if (44643312 + ((val_1 - 6)) << 2 > 0x4) goto label_51;
            if(val_21 > 4)
            {
                goto label_51;
            }
            // 0x00BBF358: ADRP x9, #0x2a93000        | X9 = 44642304 (0x2A93000);              
            // 0x00BBF35C: ADD x9, x9, #0x3d4         | X9 = (44642304 + 980) = 44643284 (0x02A933D4);
            // 0x00BBF360: LDRSW x8, [x9, x8, lsl #2] | X8 = 44643284 + ((44643312 + ((val_1 - 6)) << 2 - 3)) << 2;
            var val_22 = 44643284 + ((44643312 + ((val_1 - 6)) << 2 - 3)) << 2;
            // 0x00BBF364: ADD x8, x8, x9             | X8 = (44643284 + ((44643312 + ((val_1 - 6)) << 2 - 3)) << 2 + 44643284);
            val_22 = val_22 + 44643284;
            // 0x00BBF368: BR x8                      | goto (44643284 + ((44643312 + ((val_1 - 6)) << 2 - 3)) << 2 + 44643284);
            goto (44643284 + ((44643312 + ((val_1 - 6)) << 2 - 3)) << 2 + 44643284);
            // 0x00BBF36C: LDR w21, [x20, #4]         | W21 = val_1 + 4;                        
            // 0x00BBF370: CBNZ x22, #0xbbf378        | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x00BBF374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00BBF378: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBF37C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x00BBF380: MOV w1, w21                | W1 = val_1 + 4;//m1                     
            // 0x00BBF384: BL #0x28df874              | X0 = X1.GetType(hash:  val_1 + 4);      
            ILRuntime.CLR.TypeSystem.IType val_2 = X1.GetType(hash:  val_1 + 4);
            // 0x00BBF388: MOV x21, x0                | X21 = val_2;//m1                        
            val_22 = val_2;
            // 0x00BBF38C: CBZ x21, #0xbbf3c4         | if (val_2 == null) goto label_6;        
            if(val_22 == null)
            {
                goto label_6;
            }
            // 0x00BBF390: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x00BBF394: LDR x8, [x8, #0x108]       | X8 = 1152921504782192640;               
            // 0x00BBF398: LDR x9, [x21]              | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF39C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.ILType);
            // 0x00BBF3A0: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF3A4: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF3A8: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF3AC: B.LO #0xbbf3c4             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) goto label_6;
            // 0x00BBF3B0: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF3B4: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x00BBF3B8: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF3BC: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.ILType))
            // 0x00BBF3C0: B.EQ #0xbbf888             | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_7;
            label_6:
            // 0x00BBF3C4: CBNZ x20, #0xbbf3cc        | if (val_1 != 0) goto label_8;           
            if(val_1 != 0)
            {
                goto label_8;
            }
            // 0x00BBF3C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x00BBF3CC: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00BBF3D0: LDR w20, [x20, #8]         | W20 = val_1 + 8;                        
            // 0x00BBF3D4: LDR w8, [x19]              | W8 = X4;                                
            // 0x00BBF3D8: LDR x9, [x9, #0x808]       | X9 = 1152921504922341376;               
            // 0x00BBF3DC: ADD x1, sp, #0xc           | X1 = (1152921510047861824 + 12) = 1152921510047861836 (0x10000001444F4C4C);
            // 0x00BBF3E0: STR w8, [sp, #0xc]         | stack[1152921510047861836] = X4;         //  dest_result_addr=1152921510047861836
            // 0x00BBF3E4: LDR x0, [x9]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF3E8: BL #0x27bc028              | X0 = 1152921510047922272 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), X4);
            // 0x00BBF3EC: MOV x19, x0                | X19 = 1152921510047922272 (0x1000000144503860);//ML01
            val_21 = val_21;
            // 0x00BBF3F0: CBZ x21, #0xbbf5d8         | if (val_2 == null) goto label_9;        
            if(val_22 == null)
            {
                goto label_9;
            }
            // 0x00BBF3F4: ADRP x22, #0x35c2000       | X22 = 56369152 (0x35C2000);             
            // 0x00BBF3F8: LDR x22, [x22, #0x290]     | X22 = 1152921504782032896;              
            // 0x00BBF3FC: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF400: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x00BBF404: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF408: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF40C: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF410: B.LO #0xbbf428             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BBF414: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF418: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x00BBF41C: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF420: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x00BBF424: B.EQ #0xbbf450             | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BBF428: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x00BBF42C: ADD x8, sp, #0x30          | X8 = (1152921510047861824 + 48) = 1152921510047861872 (0x10000001444F4C70);
            // 0x00BBF430: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x00BBF434: LDR x0, [sp, #0x30]        | X0 = val_4;                              //  find_add[1152921510047849952]
            // 0x00BBF438: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BBF43C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF440: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BBF444: ADD x0, sp, #0x30          | X0 = (1152921510047861824 + 48) = 1152921510047861872 (0x10000001444F4C70);
            // 0x00BBF448: BL #0x299a140              | 
            // 0x00BBF44C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001444F4C70, ????);
            label_11:
            // 0x00BBF450: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF454: LDR x1, [x22]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x00BBF458: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF45C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF460: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF464: B.LO #0xbbf47c             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            // 0x00BBF468: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF46C: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x00BBF470: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF474: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x00BBF478: B.EQ #0xbbf5e0             | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_13;
            label_12:
            // 0x00BBF47C: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x00BBF480: ADD x8, sp, #0x38          | X8 = (1152921510047861824 + 56) = 1152921510047861880 (0x10000001444F4C78);
            // 0x00BBF484: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x00BBF488: LDR x0, [sp, #0x38]        | X0 = val_6;                              //  find_add[1152921510047849952]
            // 0x00BBF48C: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00BBF490: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF494: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00BBF498: ADD x0, sp, #0x38          | X0 = (1152921510047861824 + 56) = 1152921510047861880 (0x10000001444F4C78);
            // 0x00BBF49C: BL #0x299a140              | 
            // 0x00BBF4A0: B #0xbbf5dc                |  goto label_14;                         
            goto label_14;
            // 0x00BBF4A4: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00BBF4A8: LDR w20, [x20, #4]         | W20 = val_1 + 8 + 4;                    
            // 0x00BBF4AC: LDR w8, [x19]              | W8 = typeof(AnimationRunner.AniType);   
            // 0x00BBF4B0: LDR x9, [x9, #0x808]       | X9 = 1152921504922341376;               
            // 0x00BBF4B4: ADD x1, sp, #0x14          | X1 = (1152921510047861824 + 20) = 1152921510047861844 (0x10000001444F4C54);
            // 0x00BBF4B8: STR w8, [sp, #0x14]        | stack[1152921510047861844] = typeof(AnimationRunner.AniType);  //  dest_result_addr=1152921510047861844
            // 0x00BBF4BC: LDR x0, [x9]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF4C0: BL #0x27bc028              | X0 = 1152921510047926368 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), typeof(AnimationRunner.AniType));
            // 0x00BBF4C4: MOV x19, x0                | X19 = 1152921510047926368 (0x1000000144504860);//ML01
            val_21 = null;
            // 0x00BBF4C8: CBNZ x21, #0xbbf4d0        | if (val_2 != null) goto label_15;       
            if(val_22 != null)
            {
                goto label_15;
            }
            // 0x00BBF4CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AnimationRunner.AniType), ????);
            label_15:
            // 0x00BBF4D0: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BBF4D4: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF4D8: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x00BBF4DC: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x00BBF4E0: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x00BBF4E4: CBZ x9, #0xbbf510          | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_16;
            // 0x00BBF4E8: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x00BBF4EC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_23 = 0;
            // 0x00BBF4F0: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_18:
            // 0x00BBF4F4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00BBF4F8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x00BBF4FC: B.EQ #0xbbf5f8             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_17;
            // 0x00BBF500: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_23 = val_23 + 1;
            // 0x00BBF504: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x00BBF508: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x00BBF50C: B.LO #0xbbf4f4             | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_18;
            label_16:
            // 0x00BBF510: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x00BBF514: MOV x0, x21                | X0 = val_2;//m1                         
            val_23 = val_22;
            // 0x00BBF518: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x00BBF51C: B #0xbbf608                |  goto label_19;                         
            goto label_19;
            // 0x00BBF520: LDR w23, [x20, #4]         | W23 = val_1 + 8 + 4 + 4;                
            val_20 = mem[val_1 + 8 + 4 + 4];
            val_20 = val_1 + 8 + 4 + 4;
            // 0x00BBF524: CBNZ x21, #0xbbf52c        | if (val_2 != null) goto label_20;       
            if(val_22 != null)
            {
                goto label_20;
            }
            // 0x00BBF528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_20:
            // 0x00BBF52C: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BBF530: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF534: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x00BBF538: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x00BBF53C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x00BBF540: CBZ x9, #0xbbf56c          | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_21;
            // 0x00BBF544: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x00BBF548: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x00BBF54C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_23:
            // 0x00BBF550: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00BBF554: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x00BBF558: B.EQ #0xbbf620             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_22;
            // 0x00BBF55C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x00BBF560: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x00BBF564: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x00BBF568: B.LO #0xbbf550             | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_23;
            label_21:
            // 0x00BBF56C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBF570: MOV x0, x21                | X0 = val_2;//m1                         
            val_24 = val_22;
            // 0x00BBF574: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x00BBF578: B #0xbbf630                |  goto label_24;                         
            goto label_24;
            // 0x00BBF57C: LDR w22, [x20, #4]         | W22 = val_1 + 8 + 4 + 4;                
            // 0x00BBF580: CBNZ x21, #0xbbf588        | if (val_2 != null) goto label_25;       
            if(val_22 != null)
            {
                goto label_25;
            }
            // 0x00BBF584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_25:
            // 0x00BBF588: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BBF58C: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF590: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x00BBF594: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x00BBF598: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x00BBF59C: CBZ x9, #0xbbf5c8          | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_26;
            // 0x00BBF5A0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x00BBF5A4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_25 = 0;
            // 0x00BBF5A8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_28:
            // 0x00BBF5AC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00BBF5B0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IList<T>))
            // 0x00BBF5B4: B.EQ #0xbbf7b4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_27;
            // 0x00BBF5B8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_25 = val_25 + 1;
            // 0x00BBF5BC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x00BBF5C0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x00BBF5C4: B.LO #0xbbf5ac             | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_28;
            label_26:
            // 0x00BBF5C8: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BBF5CC: MOV x0, x21                | X0 = val_2;//m1                         
            val_25 = val_22;
            // 0x00BBF5D0: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x00BBF5D4: B #0xbbf7c4                |  goto label_29;                         
            goto label_29;
            label_9:
            // 0x00BBF5D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4, ????);         
            label_14:
            // 0x00BBF5DC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_13:
            // 0x00BBF5E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF5E4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BBF5E8: MOV w1, w20                | W1 = val_1 + 8;//m1                     
            // 0x00BBF5EC: MOV x2, x19                | X2 = 1152921510047922272 (0x1000000144503860);//ML01
            // 0x00BBF5F0: BL #0x10eece4              | val_22.SetStaticFieldValue(hash:  val_1 + 8, value:  val_21);
            val_22.SetStaticFieldValue(hash:  val_1 + 8, value:  val_21);
            // 0x00BBF5F4: B #0xbbf8e0                |  goto label_51;                         
            goto label_51;
            label_17:
            // 0x00BBF5F8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00BBF5FC: ADD w9, w9, #4             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4);
            // 0x00BBF600: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4));
            // 0x00BBF604: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4)).272
            label_19:
            // 0x00BBF608: LDP x8, x3, [x0]           | X8 = typeof(AnimationRunner.AniType);    //  | 
            // 0x00BBF60C: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00BBF610: MOV w1, w20                | W1 = val_1 + 8 + 4;//m1                 
            // 0x00BBF614: MOV x2, x19                | X2 = 1152921510047926368 (0x1000000144504860);//ML01
            // 0x00BBF618: BLR x8                     | X0 = sub_1000000012CE1000( ?? val_2, ????);
            // 0x00BBF61C: B #0xbbf8e0                |  goto label_51;                         
            goto label_51;
            label_22:
            // 0x00BBF620: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00BBF624: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x00BBF628: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x00BBF62C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_24:
            // 0x00BBF630: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x00BBF634: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00BBF638: MOV w1, w23                | W1 = val_1 + 8 + 4 + 4;//m1             
            // 0x00BBF63C: BLR x8                     | X0 = sub_100000000A746000( ?? val_2, ????);
            // 0x00BBF640: MOV x21, x0                | X21 = val_2;//m1                        
            val_22 = val_22;
            // 0x00BBF644: STR x21, [sp, #0x18]       | stack[1152921510047861848] = val_2;      //  dest_result_addr=1152921510047861848
            ILRuntime.CLR.TypeSystem.IType val_18 = val_22;
            // 0x00BBF648: CBZ x21, #0xbbf758         | if (val_2 == null) goto label_32;       
            if(val_22 == null)
            {
                goto label_32;
            }
            // 0x00BBF64C: ADRP x23, #0x35dd000       | X23 = 56479744 (0x35DD000);             
            // 0x00BBF650: LDR x23, [x23, #0xb50]     | X23 = 1152921504825909248;              
            val_20 = 1152921504825909248;
            // 0x00BBF654: LDR x9, [x21]              | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF658: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BBF65C: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF660: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF664: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF668: B.LO #0xbbf75c             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_34;
            // 0x00BBF66C: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF670: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepre
            // 0x00BBF674: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF678: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x00BBF67C: B.NE #0xbbf75c             | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_34;
            // 0x00BBF680: CBNZ x20, #0xbbf688        | if (val_1 + 8 + 4 != 0) goto label_35;  
            if((val_1 + 8 + 4) != 0)
            {
                goto label_35;
            }
            // 0x00BBF684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_35:
            // 0x00BBF688: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00BBF68C: LDR w20, [x20, #8]         | W20 = val_1 + 8 + 4 + 8;                
            val_26 = mem[val_1 + 8 + 4 + 8];
            val_26 = val_1 + 8 + 4 + 8;
            // 0x00BBF690: LDR w8, [x19]              | W8 = typeof(AnimationRunner.AniType);   
            // 0x00BBF694: LDR x9, [x9, #0x808]       | X9 = 1152921504922341376;               
            // 0x00BBF698: ADD x1, sp, #0x10          | X1 = (1152921510047861824 + 16) = 1152921510047861840 (0x10000001444F4C50);
            // 0x00BBF69C: STR w8, [sp, #0x10]        | stack[1152921510047861840] = typeof(AnimationRunner.AniType);  //  dest_result_addr=1152921510047861840
            // 0x00BBF6A0: LDR x0, [x9]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF6A4: BL #0x27bc028              | X0 = 1152921510047930464 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), typeof(AnimationRunner.AniType));
            // 0x00BBF6A8: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF6AC: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BBF6B0: MOV x19, x0                | X19 = 1152921510047930464 (0x1000000144505860);//ML01
            val_21 = null;
            // 0x00BBF6B4: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF6B8: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF6BC: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF6C0: B.LO #0xbbf6d8             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_36;
            // 0x00BBF6C4: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF6C8: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepre
            // 0x00BBF6CC: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF6D0: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x00BBF6D4: B.EQ #0xbbf700             | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_37;
            label_36:
            // 0x00BBF6D8: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x00BBF6DC: ADD x8, sp, #0x20          | X8 = (1152921510047861824 + 32) = 1152921510047861856 (0x10000001444F4C60);
            // 0x00BBF6E0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x00BBF6E4: LDR x0, [sp, #0x20]        | X0 = val_10;                             //  find_add[1152921510047849952]
            // 0x00BBF6E8: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x00BBF6EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF6F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x00BBF6F4: ADD x0, sp, #0x20          | X0 = (1152921510047861824 + 32) = 1152921510047861856 (0x10000001444F4C60);
            // 0x00BBF6F8: BL #0x299a140              | 
            // 0x00BBF6FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001444F4C60, ????);
            label_37:
            // 0x00BBF700: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF704: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x00BBF708: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF70C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF710: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF714: B.LO #0xbbf72c             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_38;
            // 0x00BBF718: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF71C: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepre
            // 0x00BBF720: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF724: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x00BBF728: B.EQ #0xbbf8cc             | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_53;
            label_38:
            // 0x00BBF72C: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x00BBF730: ADD x8, sp, #0x28          | X8 = (1152921510047861824 + 40) = 1152921510047861864 (0x10000001444F4C68);
            // 0x00BBF734: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x00BBF738: LDR x0, [sp, #0x28]        | X0 = val_12;                             //  find_add[1152921510047849952]
            // 0x00BBF73C: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00BBF740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF744: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00BBF748: ADD x0, sp, #0x28          | X0 = (1152921510047861824 + 40) = 1152921510047861864 (0x10000001444F4C68);
            // 0x00BBF74C: BL #0x299a140              | 
            // 0x00BBF750: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BBF754: B #0xbbf8cc                |  goto label_53;                         
            goto label_53;
            label_32:
            // 0x00BBF758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_34:
            // 0x00BBF75C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF760: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00BBF764: BL #0x16fb28c              | X0 = val_2.GetType();                   
            System.Type val_13 = val_22.GetType();
            // 0x00BBF768: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x00BBF76C: CBNZ x22, #0xbbf774        | if (typeof(ILRuntime.CLR.TypeSystem.CLRType) != 0) goto label_41;
            if(null != 0)
            {
                goto label_41;
            }
            // 0x00BBF770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_41:
            // 0x00BBF774: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BBF778: MOV x0, x22                | X0 = 57998160 (0x374FB50);//ML01        
            // 0x00BBF77C: MOV x1, x21                | X1 = val_13;//m1                        
            // 0x00BBF780: BL #0x28e5da8              | X0 = GetType(t:  val_13);               
            ILRuntime.CLR.TypeSystem.IType val_14 = GetType(t:  val_13);
            // 0x00BBF784: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BBF788: CBZ x0, #0xbbf838          | if (val_14 == null) goto label_44;      
            if(val_14 == null)
            {
                goto label_44;
            }
            // 0x00BBF78C: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x00BBF790: LDR x8, [x8, #0x290]       | X8 = 1152921504782032896;               
            // 0x00BBF794: LDR x9, [x0]               | X9 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x00BBF798: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x00BBF79C: LDRB w11, [x9, #0x104]     | W11 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF7A0: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BBF7A4: CMP w11, w10               | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BBF7A8: B.HS #0xbbf824             | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth >= ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_43;
            // 0x00BBF7AC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BBF7B0: B #0xbbf838                |  goto label_44;                         
            goto label_44;
            label_27:
            // 0x00BBF7B4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00BBF7B8: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x00BBF7BC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x00BBF7C0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_29:
            // 0x00BBF7C4: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x00BBF7C8: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00BBF7CC: MOV w1, w22                | W1 = val_1 + 8 + 4 + 4;//m1             
            // 0x00BBF7D0: BLR x8                     | X0 = sub_100000000A746000( ?? val_2, ????);
            // 0x00BBF7D4: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00BBF7D8: LDR x8, [x8, #0xa88]       | X8 = 1152921510047833568;               
            // 0x00BBF7DC: LDR x1, [x8]               | X1 = typeof(AniType[]);                 
            // 0x00BBF7E0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00BBF7E4: MOV x21, x0                | X21 = val_2;//m1                        
            val_22 = val_22;
            // 0x00BBF7E8: CBNZ x20, #0xbbf7f0        | if (val_1 + 8 + 4 != 0) goto label_45;  
            if((val_1 + 8 + 4) != 0)
            {
                goto label_45;
            }
            // 0x00BBF7EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_45:
            // 0x00BBF7F0: LDRSW x20, [x20, #8]       | X20 = val_1 + 8 + 4 + 8;                
            // 0x00BBF7F4: CBNZ x21, #0xbbf7fc        | if (val_2 != null) goto label_46;       
            if(val_22 != null)
            {
                goto label_46;
            }
            // 0x00BBF7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_46:
            // 0x00BBF7FC: LDR w8, [x21, #0x18]       | 
            // 0x00BBF800: LDR w19, [x19]             | W19 = typeof(AnimationRunner.AniType);  
            // 0x00BBF804: CMP w20, w8                | STATE = COMPARE(val_1 + 8 + 4 + 8, 1152921510047833568)
            // 0x00BBF808: B.LO #0xbbf818             | if (val_1 + 8 + 4 + 8 < 1152921510047833568) goto label_47;
            if((val_1 + 8 + 4 + 8) < 1152921510047833568)
            {
                goto label_47;
            }
            // 0x00BBF80C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00BBF810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF814: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_47:
            // 0x00BBF818: ADD x8, x21, x20, lsl #2   | X8 = (val_2 + (val_1 + 8 + 4 + 8) << 2);
            ILRuntime.CLR.TypeSystem.IType val_16 = val_22 + ((val_1 + 8 + 4 + 8) << 2);
            // 0x00BBF81C: STR w19, [x8, #0x20]       | mem2[0] = typeof(AnimationRunner.AniType);  //  dest_result_addr=0
            mem2[0] = null;
            // 0x00BBF820: B #0xbbf8e0                |  goto label_51;                         
            goto label_51;
            label_43:
            // 0x00BBF824: LDR x9, [x9, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x00BBF828: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x00BBF82C: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BBF830: CMP x9, x8                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x00BBF834: CSEL x21, x0, xzr, eq      | X21 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0;
            var val_17 = (((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_14) : 0;
            label_44:
            // 0x00BBF838: CBNZ x20, #0xbbf840        | if (val_1 + 8 + 4 != 0) goto label_49;  
            if((val_1 + 8 + 4) != 0)
            {
                goto label_49;
            }
            // 0x00BBF83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_49:
            // 0x00BBF840: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00BBF844: LDR w20, [x20, #8]         | W20 = val_1 + 8 + 4 + 8;                
            // 0x00BBF848: LDR w8, [x19]              | W8 = typeof(AnimationRunner.AniType);   
            // 0x00BBF84C: LDR x9, [x9, #0x808]       | X9 = 1152921504922341376;               
            // 0x00BBF850: ADD x1, sp, #0x14          | X1 = (1152921510047861824 + 20) = 1152921510047861844 (0x10000001444F4C54);
            // 0x00BBF854: STR w8, [sp, #0x14]        | stack[1152921510047861844] = typeof(AnimationRunner.AniType);  //  dest_result_addr=1152921510047861844
            // 0x00BBF858: LDR x0, [x9]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF85C: BL #0x27bc028              | X0 = 1152921510047942752 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), typeof(AnimationRunner.AniType));
            // 0x00BBF860: MOV x19, x0                | X19 = 1152921510047942752 (0x1000000144508860);//ML01
            val_21 = null;
            // 0x00BBF864: CBNZ x21, #0xbbf86c        | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0 != 0) goto label_50;
            // 0x00BBF868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AnimationRunner.AniType), ????);
            label_50:
            // 0x00BBF86C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BBF870: ADD x2, sp, #0x18          | X2 = (1152921510047861824 + 24) = 1152921510047861848 (0x10000001444F4C58);
            // 0x00BBF874: MOV x0, x21                | X0 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0;//m1
            // 0x00BBF878: MOV w1, w20                | W1 = val_1 + 8 + 4 + 8;//m1             
            // 0x00BBF87C: MOV x3, x19                | X3 = 1152921510047942752 (0x1000000144508860);//ML01
            // 0x00BBF880: BL #0x10f426c              | (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_14 : 0.SetFieldValue(hash:  val_1 + 8 + 4 + 8, target: ref  ILRuntime.CLR.TypeSystem.IType val_18 = val_22, value:  null);
            val_17.SetFieldValue(hash:  val_1 + 8 + 4 + 8, target: ref  val_18, value:  null);
            // 0x00BBF884: B #0xbbf8e0                |  goto label_51;                         
            goto label_51;
            label_7:
            // 0x00BBF888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BBF88C: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00BBF890: BL #0x10eeca4              | X0 = val_2.get_StaticInstance();        
            ILRuntime.Runtime.Intepreter.ILTypeStaticInstance val_19 = val_22.StaticInstance;
            // 0x00BBF894: MOV x21, x0                | X21 = val_19;//m1                       
            val_22 = val_19;
            // 0x00BBF898: CBNZ x20, #0xbbf8a0        | if (val_1 != 0) goto label_52;          
            if(val_1 != 0)
            {
                goto label_52;
            }
            // 0x00BBF89C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_52:
            // 0x00BBF8A0: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
            // 0x00BBF8A4: LDR w20, [x20, #8]         | W20 = val_1 + 8;                        
            val_26 = mem[val_1 + 8];
            val_26 = val_1 + 8;
            // 0x00BBF8A8: LDR w8, [x19]              | W8 = X4;                                
            // 0x00BBF8AC: LDR x9, [x9, #0x808]       | X9 = 1152921504922341376;               
            // 0x00BBF8B0: ADD x1, sp, #0x14          | X1 = (1152921510047861824 + 20) = 1152921510047861844 (0x10000001444F4C54);
            // 0x00BBF8B4: STR w8, [sp, #0x14]        | stack[1152921510047861844] = X4;         //  dest_result_addr=1152921510047861844
            // 0x00BBF8B8: LDR x0, [x9]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF8BC: BL #0x27bc028              | X0 = 1152921510047950944 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), X4);
            // 0x00BBF8C0: MOV x19, x0                | X19 = 1152921510047950944 (0x100000014450A860);//ML01
            val_21 = val_21;
            // 0x00BBF8C4: CBNZ x21, #0xbbf8cc        | if (val_19 != null) goto label_53;      
            if(val_22 != null)
            {
                goto label_53;
            }
            // 0x00BBF8C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X4, ????);         
            label_53:
            // 0x00BBF8CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BBF8D0: MOV x0, x21                | X0 = val_19;//m1                        
            // 0x00BBF8D4: MOV w1, w20                | W1 = val_1 + 8;//m1                     
            // 0x00BBF8D8: MOV x2, x19                | X2 = 1152921510047950944 (0x100000014450A860);//ML01
            // 0x00BBF8DC: BL #0x1f96638              | val_19.set_Item(index:  val_26, value:  val_21);
            val_22.set_Item(index:  val_26, value:  val_21);
            label_51:
            // 0x00BBF8E0: SUB sp, x29, #0x30         | SP = (1152921510047861936 - 48) = 1152921510047861888 (0x10000001444F4C80);
            // 0x00BBF8E4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBF8E8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BBF8EC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BBF8F0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BBF8F4: RET                        |  return;                                
            return;
            // 0x00BBF8F8: MOV x19, x0                | 
            // 0x00BBF8FC: ADD x0, sp, #0x30          | 
            // 0x00BBF900: B #0xbbf924                | 
            // 0x00BBF904: MOV x19, x0                | 
            // 0x00BBF908: ADD x0, sp, #0x38          | 
            // 0x00BBF90C: B #0xbbf924                | 
            // 0x00BBF910: MOV x19, x0                | 
            // 0x00BBF914: ADD x0, sp, #0x20          | 
            // 0x00BBF918: B #0xbbf924                | 
            // 0x00BBF91C: MOV x19, x0                | 
            // 0x00BBF920: ADD x0, sp, #0x28          | 
            label_56:
            // 0x00BBF924: BL #0x299a140              | 
            // 0x00BBF928: MOV x0, x19                | 
            // 0x00BBF92C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBF930 (12319024), len: 92  VirtAddr: 0x00BBF930 RVA: 0x00BBF930 token: 100663785 methodIndex: 29830 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_none_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBF930: STP x20, x19, [sp, #-0x20]! | stack[1152921510048031120] = ???;  stack[1152921510048031128] = ???;  //  dest_result_addr=1152921510048031120 |  dest_result_addr=1152921510048031128
            // 0x00BBF934: STP x29, x30, [sp, #0x10]  | stack[1152921510048031136] = ???;  stack[1152921510048031144] = ???;  //  dest_result_addr=1152921510048031136 |  dest_result_addr=1152921510048031144
            // 0x00BBF938: ADD x29, sp, #0x10         | X29 = (1152921510048031120 + 16) = 1152921510048031136 (0x100000014451E1A0);
            // 0x00BBF93C: SUB sp, sp, #0x10          | SP = (1152921510048031120 - 16) = 1152921510048031104 (0x100000014451E180);
            // 0x00BBF940: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBF944: LDRB w8, [x19, #0xb74]     | W8 = (bool)static_value_03733B74;       
            // 0x00BBF948: TBNZ w8, #0, #0xbbf964     | if (static_value_03733B74 == true) goto label_0;
            // 0x00BBF94C: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00BBF950: LDR x8, [x8, #0x2b8]       | X8 = 0x2B8AE40;                         
            // 0x00BBF954: LDR w0, [x8]               | W0 = 0x24E;                             
            // 0x00BBF958: BL #0x2782188              | X0 = sub_2782188( ?? 0x24E, ????);      
            // 0x00BBF95C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBF960: STRB w8, [x19, #0xb74]     | static_value_03733B74 = true;            //  dest_result_addr=57883508
            label_0:
            // 0x00BBF964: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBF968: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBF96C: ADD x1, sp, #0xc           | X1 = (1152921510048031104 + 12) = 1152921510048031116 (0x100000014451E18C);
            // 0x00BBF970: STR wzr, [sp, #0xc]        | stack[1152921510048031116] = 0x0;        //  dest_result_addr=1152921510048031116
            // 0x00BBF974: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF978: BL #0x27bc028              | X0 = 1152921510048079168 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), null);
            // 0x00BBF97C: SUB sp, x29, #0x10         | SP = (1152921510048031136 - 16) = 1152921510048031120 (0x100000014451E190);
            // 0x00BBF980: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBF984: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBF988: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBF98C (12319116), len: 96  VirtAddr: 0x00BBF98C RVA: 0x00BBF98C token: 100663786 methodIndex: 29831 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_win_1(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBF98C: STP x20, x19, [sp, #-0x20]! | stack[1152921510048159344] = ???;  stack[1152921510048159352] = ???;  //  dest_result_addr=1152921510048159344 |  dest_result_addr=1152921510048159352
            // 0x00BBF990: STP x29, x30, [sp, #0x10]  | stack[1152921510048159360] = ???;  stack[1152921510048159368] = ???;  //  dest_result_addr=1152921510048159360 |  dest_result_addr=1152921510048159368
            // 0x00BBF994: ADD x29, sp, #0x10         | X29 = (1152921510048159344 + 16) = 1152921510048159360 (0x100000014453D680);
            // 0x00BBF998: SUB sp, sp, #0x10          | SP = (1152921510048159344 - 16) = 1152921510048159328 (0x100000014453D660);
            // 0x00BBF99C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBF9A0: LDRB w8, [x19, #0xb75]     | W8 = (bool)static_value_03733B75;       
            // 0x00BBF9A4: TBNZ w8, #0, #0xbbf9c0     | if (static_value_03733B75 == true) goto label_0;
            // 0x00BBF9A8: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x00BBF9AC: LDR x8, [x8, #0x790]       | X8 = 0x2B8AE68;                         
            // 0x00BBF9B0: LDR w0, [x8]               | W0 = 0x258;                             
            // 0x00BBF9B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x258, ????);      
            // 0x00BBF9B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBF9BC: STRB w8, [x19, #0xb75]     | static_value_03733B75 = true;            //  dest_result_addr=57883509
            label_0:
            // 0x00BBF9C0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBF9C4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBF9C8: ADD x1, sp, #0xc           | X1 = (1152921510048159328 + 12) = 1152921510048159340 (0x100000014453D66C);
            // 0x00BBF9CC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBF9D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBF9D4: STR w8, [sp, #0xc]         | stack[1152921510048159340] = 0x1;        //  dest_result_addr=1152921510048159340
            // 0x00BBF9D8: BL #0x27bc028              | X0 = 1152921510048207392 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x1);
            // 0x00BBF9DC: SUB sp, x29, #0x10         | SP = (1152921510048159360 - 16) = 1152921510048159344 (0x100000014453D670);
            // 0x00BBF9E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBF9E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBF9E8: RET                        |  return (System.Object)0x1;             
            return (object)1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBF9EC (12319212), len: 96  VirtAddr: 0x00BBF9EC RVA: 0x00BBF9EC token: 100663787 methodIndex: 29832 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_idle_2(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBF9EC: STP x20, x19, [sp, #-0x20]! | stack[1152921510048287568] = ???;  stack[1152921510048287576] = ???;  //  dest_result_addr=1152921510048287568 |  dest_result_addr=1152921510048287576
            // 0x00BBF9F0: STP x29, x30, [sp, #0x10]  | stack[1152921510048287584] = ???;  stack[1152921510048287592] = ???;  //  dest_result_addr=1152921510048287584 |  dest_result_addr=1152921510048287592
            // 0x00BBF9F4: ADD x29, sp, #0x10         | X29 = (1152921510048287568 + 16) = 1152921510048287584 (0x100000014455CB60);
            // 0x00BBF9F8: SUB sp, sp, #0x10          | SP = (1152921510048287568 - 16) = 1152921510048287552 (0x100000014455CB40);
            // 0x00BBF9FC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFA00: LDRB w8, [x19, #0xb76]     | W8 = (bool)static_value_03733B76;       
            // 0x00BBFA04: TBNZ w8, #0, #0xbbfa20     | if (static_value_03733B76 == true) goto label_0;
            // 0x00BBFA08: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00BBFA0C: LDR x8, [x8, #0xd8]        | X8 = 0x2B8AE3C;                         
            // 0x00BBFA10: LDR w0, [x8]               | W0 = 0x24D;                             
            // 0x00BBFA14: BL #0x2782188              | X0 = sub_2782188( ?? 0x24D, ????);      
            // 0x00BBFA18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFA1C: STRB w8, [x19, #0xb76]     | static_value_03733B76 = true;            //  dest_result_addr=57883510
            label_0:
            // 0x00BBFA20: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFA24: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFA28: ADD x1, sp, #0xc           | X1 = (1152921510048287552 + 12) = 1152921510048287564 (0x100000014455CB4C);
            // 0x00BBFA2C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFA30: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00BBFA34: STR w8, [sp, #0xc]         | stack[1152921510048287564] = 0x2;        //  dest_result_addr=1152921510048287564
            // 0x00BBFA38: BL #0x27bc028              | X0 = 1152921510048335616 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x2);
            // 0x00BBFA3C: SUB sp, x29, #0x10         | SP = (1152921510048287584 - 16) = 1152921510048287568 (0x100000014455CB50);
            // 0x00BBFA40: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFA44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFA48: RET                        |  return (System.Object)0x2;             
            return (object)2;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFA4C (12319308), len: 96  VirtAddr: 0x00BBFA4C RVA: 0x00BBFA4C token: 100663788 methodIndex: 29833 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_run_3(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFA4C: STP x20, x19, [sp, #-0x20]! | stack[1152921510048415792] = ???;  stack[1152921510048415800] = ???;  //  dest_result_addr=1152921510048415792 |  dest_result_addr=1152921510048415800
            // 0x00BBFA50: STP x29, x30, [sp, #0x10]  | stack[1152921510048415808] = ???;  stack[1152921510048415816] = ???;  //  dest_result_addr=1152921510048415808 |  dest_result_addr=1152921510048415816
            // 0x00BBFA54: ADD x29, sp, #0x10         | X29 = (1152921510048415792 + 16) = 1152921510048415808 (0x100000014457C040);
            // 0x00BBFA58: SUB sp, sp, #0x10          | SP = (1152921510048415792 - 16) = 1152921510048415776 (0x100000014457C020);
            // 0x00BBFA5C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFA60: LDRB w8, [x19, #0xb77]     | W8 = (bool)static_value_03733B77;       
            // 0x00BBFA64: TBNZ w8, #0, #0xbbfa80     | if (static_value_03733B77 == true) goto label_0;
            // 0x00BBFA68: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00BBFA6C: LDR x8, [x8, #0xd08]       | X8 = 0x2B8AE58;                         
            // 0x00BBFA70: LDR w0, [x8]               | W0 = 0x254;                             
            // 0x00BBFA74: BL #0x2782188              | X0 = sub_2782188( ?? 0x254, ????);      
            // 0x00BBFA78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFA7C: STRB w8, [x19, #0xb77]     | static_value_03733B77 = true;            //  dest_result_addr=57883511
            label_0:
            // 0x00BBFA80: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFA84: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFA88: ADD x1, sp, #0xc           | X1 = (1152921510048415776 + 12) = 1152921510048415788 (0x100000014457C02C);
            // 0x00BBFA8C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFA90: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BBFA94: STR w8, [sp, #0xc]         | stack[1152921510048415788] = 0x3;        //  dest_result_addr=1152921510048415788
            // 0x00BBFA98: BL #0x27bc028              | X0 = 1152921510048463840 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x3);
            // 0x00BBFA9C: SUB sp, x29, #0x10         | SP = (1152921510048415808 - 16) = 1152921510048415792 (0x100000014457C030);
            // 0x00BBFAA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFAA4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFAA8: RET                        |  return (System.Object)0x3;             
            return (object)3;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFAAC (12319404), len: 96  VirtAddr: 0x00BBFAAC RVA: 0x00BBFAAC token: 100663789 methodIndex: 29834 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_attack_4(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFAAC: STP x20, x19, [sp, #-0x20]! | stack[1152921510048544016] = ???;  stack[1152921510048544024] = ???;  //  dest_result_addr=1152921510048544016 |  dest_result_addr=1152921510048544024
            // 0x00BBFAB0: STP x29, x30, [sp, #0x10]  | stack[1152921510048544032] = ???;  stack[1152921510048544040] = ???;  //  dest_result_addr=1152921510048544032 |  dest_result_addr=1152921510048544040
            // 0x00BBFAB4: ADD x29, sp, #0x10         | X29 = (1152921510048544016 + 16) = 1152921510048544032 (0x100000014459B520);
            // 0x00BBFAB8: SUB sp, sp, #0x10          | SP = (1152921510048544016 - 16) = 1152921510048544000 (0x100000014459B500);
            // 0x00BBFABC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFAC0: LDRB w8, [x19, #0xb78]     | W8 = (bool)static_value_03733B78;       
            // 0x00BBFAC4: TBNZ w8, #0, #0xbbfae0     | if (static_value_03733B78 == true) goto label_0;
            // 0x00BBFAC8: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00BBFACC: LDR x8, [x8, #0x760]       | X8 = 0x2B8AE20;                         
            // 0x00BBFAD0: LDR w0, [x8]               | W0 = 0x246;                             
            // 0x00BBFAD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x246, ????);      
            // 0x00BBFAD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFADC: STRB w8, [x19, #0xb78]     | static_value_03733B78 = true;            //  dest_result_addr=57883512
            label_0:
            // 0x00BBFAE0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFAE4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFAE8: ADD x1, sp, #0xc           | X1 = (1152921510048544000 + 12) = 1152921510048544012 (0x100000014459B50C);
            // 0x00BBFAEC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFAF0: ORR w8, wzr, #4            | W8 = 4(0x4);                            
            // 0x00BBFAF4: STR w8, [sp, #0xc]         | stack[1152921510048544012] = 0x4;        //  dest_result_addr=1152921510048544012
            // 0x00BBFAF8: BL #0x27bc028              | X0 = 1152921510048592064 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x4);
            // 0x00BBFAFC: SUB sp, x29, #0x10         | SP = (1152921510048544032 - 16) = 1152921510048544016 (0x100000014459B510);
            // 0x00BBFB00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFB04: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFB08: RET                        |  return (System.Object)0x4;             
            return (object)4;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFB0C (12319500), len: 96  VirtAddr: 0x00BBFB0C RVA: 0x00BBFB0C token: 100663790 methodIndex: 29835 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_attacked_5(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFB0C: STP x20, x19, [sp, #-0x20]! | stack[1152921510048672240] = ???;  stack[1152921510048672248] = ???;  //  dest_result_addr=1152921510048672240 |  dest_result_addr=1152921510048672248
            // 0x00BBFB10: STP x29, x30, [sp, #0x10]  | stack[1152921510048672256] = ???;  stack[1152921510048672264] = ???;  //  dest_result_addr=1152921510048672256 |  dest_result_addr=1152921510048672264
            // 0x00BBFB14: ADD x29, sp, #0x10         | X29 = (1152921510048672240 + 16) = 1152921510048672256 (0x10000001445BAA00);
            // 0x00BBFB18: SUB sp, sp, #0x10          | SP = (1152921510048672240 - 16) = 1152921510048672224 (0x10000001445BA9E0);
            // 0x00BBFB1C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFB20: LDRB w8, [x19, #0xb79]     | W8 = (bool)static_value_03733B79;       
            // 0x00BBFB24: TBNZ w8, #0, #0xbbfb40     | if (static_value_03733B79 == true) goto label_0;
            // 0x00BBFB28: ADRP x8, #0x3684000        | X8 = 57163776 (0x3684000);              
            // 0x00BBFB2C: LDR x8, [x8, #0x2d0]       | X8 = 0x2B8AE24;                         
            // 0x00BBFB30: LDR w0, [x8]               | W0 = 0x247;                             
            // 0x00BBFB34: BL #0x2782188              | X0 = sub_2782188( ?? 0x247, ????);      
            // 0x00BBFB38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFB3C: STRB w8, [x19, #0xb79]     | static_value_03733B79 = true;            //  dest_result_addr=57883513
            label_0:
            // 0x00BBFB40: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFB44: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFB48: ADD x1, sp, #0xc           | X1 = (1152921510048672224 + 12) = 1152921510048672236 (0x10000001445BA9EC);
            // 0x00BBFB4C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFB50: MOVZ w8, #0x5              | W8 = 5 (0x5);//ML01                     
            // 0x00BBFB54: STR w8, [sp, #0xc]         | stack[1152921510048672236] = 0x5;        //  dest_result_addr=1152921510048672236
            // 0x00BBFB58: BL #0x27bc028              | X0 = 1152921510048720288 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x5);
            // 0x00BBFB5C: SUB sp, x29, #0x10         | SP = (1152921510048672256 - 16) = 1152921510048672240 (0x10000001445BA9F0);
            // 0x00BBFB60: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFB64: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFB68: RET                        |  return (System.Object)0x5;             
            return (object)5;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFB6C (12319596), len: 96  VirtAddr: 0x00BBFB6C RVA: 0x00BBFB6C token: 100663791 methodIndex: 29836 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_death_6(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFB6C: STP x20, x19, [sp, #-0x20]! | stack[1152921510048800464] = ???;  stack[1152921510048800472] = ???;  //  dest_result_addr=1152921510048800464 |  dest_result_addr=1152921510048800472
            // 0x00BBFB70: STP x29, x30, [sp, #0x10]  | stack[1152921510048800480] = ???;  stack[1152921510048800488] = ???;  //  dest_result_addr=1152921510048800480 |  dest_result_addr=1152921510048800488
            // 0x00BBFB74: ADD x29, sp, #0x10         | X29 = (1152921510048800464 + 16) = 1152921510048800480 (0x10000001445D9EE0);
            // 0x00BBFB78: SUB sp, sp, #0x10          | SP = (1152921510048800464 - 16) = 1152921510048800448 (0x10000001445D9EC0);
            // 0x00BBFB7C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFB80: LDRB w8, [x19, #0xb7a]     | W8 = (bool)static_value_03733B7A;       
            // 0x00BBFB84: TBNZ w8, #0, #0xbbfba0     | if (static_value_03733B7A == true) goto label_0;
            // 0x00BBFB88: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00BBFB8C: LDR x8, [x8, #0x638]       | X8 = 0x2B8AE28;                         
            // 0x00BBFB90: LDR w0, [x8]               | W0 = 0x248;                             
            // 0x00BBFB94: BL #0x2782188              | X0 = sub_2782188( ?? 0x248, ????);      
            // 0x00BBFB98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFB9C: STRB w8, [x19, #0xb7a]     | static_value_03733B7A = true;            //  dest_result_addr=57883514
            label_0:
            // 0x00BBFBA0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFBA4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFBA8: ADD x1, sp, #0xc           | X1 = (1152921510048800448 + 12) = 1152921510048800460 (0x10000001445D9ECC);
            // 0x00BBFBAC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFBB0: ORR w8, wzr, #6            | W8 = 6(0x6);                            
            // 0x00BBFBB4: STR w8, [sp, #0xc]         | stack[1152921510048800460] = 0x6;        //  dest_result_addr=1152921510048800460
            // 0x00BBFBB8: BL #0x27bc028              | X0 = 1152921510048848512 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x6);
            // 0x00BBFBBC: SUB sp, x29, #0x10         | SP = (1152921510048800480 - 16) = 1152921510048800464 (0x10000001445D9ED0);
            // 0x00BBFBC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFBC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFBC8: RET                        |  return (System.Object)0x6;             
            return (object)6;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFBCC (12319692), len: 96  VirtAddr: 0x00BBFBCC RVA: 0x00BBFBCC token: 100663792 methodIndex: 29837 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_active_7(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFBCC: STP x20, x19, [sp, #-0x20]! | stack[1152921510048928688] = ???;  stack[1152921510048928696] = ???;  //  dest_result_addr=1152921510048928688 |  dest_result_addr=1152921510048928696
            // 0x00BBFBD0: STP x29, x30, [sp, #0x10]  | stack[1152921510048928704] = ???;  stack[1152921510048928712] = ???;  //  dest_result_addr=1152921510048928704 |  dest_result_addr=1152921510048928712
            // 0x00BBFBD4: ADD x29, sp, #0x10         | X29 = (1152921510048928688 + 16) = 1152921510048928704 (0x10000001445F93C0);
            // 0x00BBFBD8: SUB sp, sp, #0x10          | SP = (1152921510048928688 - 16) = 1152921510048928672 (0x10000001445F93A0);
            // 0x00BBFBDC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFBE0: LDRB w8, [x19, #0xb7b]     | W8 = (bool)static_value_03733B7B;       
            // 0x00BBFBE4: TBNZ w8, #0, #0xbbfc00     | if (static_value_03733B7B == true) goto label_0;
            // 0x00BBFBE8: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x00BBFBEC: LDR x8, [x8, #0xfa8]       | X8 = 0x2B8AE1C;                         
            // 0x00BBFBF0: LDR w0, [x8]               | W0 = 0x245;                             
            // 0x00BBFBF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x245, ????);      
            // 0x00BBFBF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFBFC: STRB w8, [x19, #0xb7b]     | static_value_03733B7B = true;            //  dest_result_addr=57883515
            label_0:
            // 0x00BBFC00: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFC04: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFC08: ADD x1, sp, #0xc           | X1 = (1152921510048928672 + 12) = 1152921510048928684 (0x10000001445F93AC);
            // 0x00BBFC0C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFC10: ORR w8, wzr, #7            | W8 = 7(0x7);                            
            // 0x00BBFC14: STR w8, [sp, #0xc]         | stack[1152921510048928684] = 0x7;        //  dest_result_addr=1152921510048928684
            // 0x00BBFC18: BL #0x27bc028              | X0 = 1152921510048976736 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x7);
            // 0x00BBFC1C: SUB sp, x29, #0x10         | SP = (1152921510048928704 - 16) = 1152921510048928688 (0x10000001445F93B0);
            // 0x00BBFC20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFC24: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFC28: RET                        |  return (System.Object)0x7;             
            return (object)7;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFC2C (12319788), len: 96  VirtAddr: 0x00BBFC2C RVA: 0x00BBFC2C token: 100663793 methodIndex: 29838 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_rise_8(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFC2C: STP x20, x19, [sp, #-0x20]! | stack[1152921510049056912] = ???;  stack[1152921510049056920] = ???;  //  dest_result_addr=1152921510049056912 |  dest_result_addr=1152921510049056920
            // 0x00BBFC30: STP x29, x30, [sp, #0x10]  | stack[1152921510049056928] = ???;  stack[1152921510049056936] = ???;  //  dest_result_addr=1152921510049056928 |  dest_result_addr=1152921510049056936
            // 0x00BBFC34: ADD x29, sp, #0x10         | X29 = (1152921510049056912 + 16) = 1152921510049056928 (0x10000001446188A0);
            // 0x00BBFC38: SUB sp, sp, #0x10          | SP = (1152921510049056912 - 16) = 1152921510049056896 (0x1000000144618880);
            // 0x00BBFC3C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFC40: LDRB w8, [x19, #0xb7c]     | W8 = (bool)static_value_03733B7C;       
            // 0x00BBFC44: TBNZ w8, #0, #0xbbfc60     | if (static_value_03733B7C == true) goto label_0;
            // 0x00BBFC48: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x00BBFC4C: LDR x8, [x8, #0xae0]       | X8 = 0x2B8AE54;                         
            // 0x00BBFC50: LDR w0, [x8]               | W0 = 0x253;                             
            // 0x00BBFC54: BL #0x2782188              | X0 = sub_2782188( ?? 0x253, ????);      
            // 0x00BBFC58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFC5C: STRB w8, [x19, #0xb7c]     | static_value_03733B7C = true;            //  dest_result_addr=57883516
            label_0:
            // 0x00BBFC60: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFC64: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFC68: ADD x1, sp, #0xc           | X1 = (1152921510049056896 + 12) = 1152921510049056908 (0x100000014461888C);
            // 0x00BBFC6C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFC70: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            // 0x00BBFC74: STR w8, [sp, #0xc]         | stack[1152921510049056908] = 0x8;        //  dest_result_addr=1152921510049056908
            // 0x00BBFC78: BL #0x27bc028              | X0 = 1152921510049104960 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x8);
            // 0x00BBFC7C: SUB sp, x29, #0x10         | SP = (1152921510049056928 - 16) = 1152921510049056912 (0x1000000144618890);
            // 0x00BBFC80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFC84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFC88: RET                        |  return (System.Object)0x8;             
            return (object)8;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFC8C (12319884), len: 96  VirtAddr: 0x00BBFC8C RVA: 0x00BBFC8C token: 100663794 methodIndex: 29839 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_dump_9(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFC8C: STP x20, x19, [sp, #-0x20]! | stack[1152921510049185136] = ???;  stack[1152921510049185144] = ???;  //  dest_result_addr=1152921510049185136 |  dest_result_addr=1152921510049185144
            // 0x00BBFC90: STP x29, x30, [sp, #0x10]  | stack[1152921510049185152] = ???;  stack[1152921510049185160] = ???;  //  dest_result_addr=1152921510049185152 |  dest_result_addr=1152921510049185160
            // 0x00BBFC94: ADD x29, sp, #0x10         | X29 = (1152921510049185136 + 16) = 1152921510049185152 (0x1000000144637D80);
            // 0x00BBFC98: SUB sp, sp, #0x10          | SP = (1152921510049185136 - 16) = 1152921510049185120 (0x1000000144637D60);
            // 0x00BBFC9C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFCA0: LDRB w8, [x19, #0xb7d]     | W8 = (bool)static_value_03733B7D;       
            // 0x00BBFCA4: TBNZ w8, #0, #0xbbfcc0     | if (static_value_03733B7D == true) goto label_0;
            // 0x00BBFCA8: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00BBFCAC: LDR x8, [x8, #0x310]       | X8 = 0x2B8AE30;                         
            // 0x00BBFCB0: LDR w0, [x8]               | W0 = 0x24A;                             
            // 0x00BBFCB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x24A, ????);      
            // 0x00BBFCB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFCBC: STRB w8, [x19, #0xb7d]     | static_value_03733B7D = true;            //  dest_result_addr=57883517
            label_0:
            // 0x00BBFCC0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFCC4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFCC8: ADD x1, sp, #0xc           | X1 = (1152921510049185120 + 12) = 1152921510049185132 (0x1000000144637D6C);
            // 0x00BBFCCC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFCD0: MOVZ w8, #0x9              | W8 = 9 (0x9);//ML01                     
            // 0x00BBFCD4: STR w8, [sp, #0xc]         | stack[1152921510049185132] = 0x9;        //  dest_result_addr=1152921510049185132
            // 0x00BBFCD8: BL #0x27bc028              | X0 = 1152921510049233184 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x9);
            // 0x00BBFCDC: SUB sp, x29, #0x10         | SP = (1152921510049185152 - 16) = 1152921510049185136 (0x1000000144637D70);
            // 0x00BBFCE0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFCE4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFCE8: RET                        |  return (System.Object)0x9;             
            return (object)9;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFCEC (12319980), len: 96  VirtAddr: 0x00BBFCEC RVA: 0x00BBFCEC token: 100663795 methodIndex: 29840 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_fly_10(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFCEC: STP x20, x19, [sp, #-0x20]! | stack[1152921510049313360] = ???;  stack[1152921510049313368] = ???;  //  dest_result_addr=1152921510049313360 |  dest_result_addr=1152921510049313368
            // 0x00BBFCF0: STP x29, x30, [sp, #0x10]  | stack[1152921510049313376] = ???;  stack[1152921510049313384] = ???;  //  dest_result_addr=1152921510049313376 |  dest_result_addr=1152921510049313384
            // 0x00BBFCF4: ADD x29, sp, #0x10         | X29 = (1152921510049313360 + 16) = 1152921510049313376 (0x1000000144657260);
            // 0x00BBFCF8: SUB sp, sp, #0x10          | SP = (1152921510049313360 - 16) = 1152921510049313344 (0x1000000144657240);
            // 0x00BBFCFC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFD00: LDRB w8, [x19, #0xb7e]     | W8 = (bool)static_value_03733B7E;       
            // 0x00BBFD04: TBNZ w8, #0, #0xbbfd20     | if (static_value_03733B7E == true) goto label_0;
            // 0x00BBFD08: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x00BBFD0C: LDR x8, [x8, #0xe58]       | X8 = 0x2B8AE34;                         
            // 0x00BBFD10: LDR w0, [x8]               | W0 = 0x24B;                             
            // 0x00BBFD14: BL #0x2782188              | X0 = sub_2782188( ?? 0x24B, ????);      
            // 0x00BBFD18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFD1C: STRB w8, [x19, #0xb7e]     | static_value_03733B7E = true;            //  dest_result_addr=57883518
            label_0:
            // 0x00BBFD20: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFD24: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFD28: ADD x1, sp, #0xc           | X1 = (1152921510049313344 + 12) = 1152921510049313356 (0x100000014465724C);
            // 0x00BBFD2C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFD30: MOVZ w8, #0xa              | W8 = 10 (0xA);//ML01                    
            // 0x00BBFD34: STR w8, [sp, #0xc]         | stack[1152921510049313356] = 0xA;        //  dest_result_addr=1152921510049313356
            // 0x00BBFD38: BL #0x27bc028              | X0 = 1152921510049361408 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0xA);
            // 0x00BBFD3C: SUB sp, x29, #0x10         | SP = (1152921510049313376 - 16) = 1152921510049313360 (0x1000000144657250);
            // 0x00BBFD40: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFD44: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFD48: RET                        |  return (System.Object)0xA;             
            return (object)10;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFD4C (12320076), len: 96  VirtAddr: 0x00BBFD4C RVA: 0x00BBFD4C token: 100663796 methodIndex: 29841 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_flying_11(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFD4C: STP x20, x19, [sp, #-0x20]! | stack[1152921510049441584] = ???;  stack[1152921510049441592] = ???;  //  dest_result_addr=1152921510049441584 |  dest_result_addr=1152921510049441592
            // 0x00BBFD50: STP x29, x30, [sp, #0x10]  | stack[1152921510049441600] = ???;  stack[1152921510049441608] = ???;  //  dest_result_addr=1152921510049441600 |  dest_result_addr=1152921510049441608
            // 0x00BBFD54: ADD x29, sp, #0x10         | X29 = (1152921510049441584 + 16) = 1152921510049441600 (0x1000000144676740);
            // 0x00BBFD58: SUB sp, sp, #0x10          | SP = (1152921510049441584 - 16) = 1152921510049441568 (0x1000000144676720);
            // 0x00BBFD5C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFD60: LDRB w8, [x19, #0xb7f]     | W8 = (bool)static_value_03733B7F;       
            // 0x00BBFD64: TBNZ w8, #0, #0xbbfd80     | if (static_value_03733B7F == true) goto label_0;
            // 0x00BBFD68: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00BBFD6C: LDR x8, [x8, #0x538]       | X8 = 0x2B8AE38;                         
            // 0x00BBFD70: LDR w0, [x8]               | W0 = 0x24C;                             
            // 0x00BBFD74: BL #0x2782188              | X0 = sub_2782188( ?? 0x24C, ????);      
            // 0x00BBFD78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFD7C: STRB w8, [x19, #0xb7f]     | static_value_03733B7F = true;            //  dest_result_addr=57883519
            label_0:
            // 0x00BBFD80: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFD84: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFD88: ADD x1, sp, #0xc           | X1 = (1152921510049441568 + 12) = 1152921510049441580 (0x100000014467672C);
            // 0x00BBFD8C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFD90: MOVZ w8, #0xb              | W8 = 11 (0xB);//ML01                    
            // 0x00BBFD94: STR w8, [sp, #0xc]         | stack[1152921510049441580] = 0xB;        //  dest_result_addr=1152921510049441580
            // 0x00BBFD98: BL #0x27bc028              | X0 = 1152921510049489632 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0xB);
            // 0x00BBFD9C: SUB sp, x29, #0x10         | SP = (1152921510049441600 - 16) = 1152921510049441584 (0x1000000144676730);
            // 0x00BBFDA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFDA4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFDA8: RET                        |  return (System.Object)0xB;             
            return (object)11;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFDAC (12320172), len: 96  VirtAddr: 0x00BBFDAC RVA: 0x00BBFDAC token: 100663797 methodIndex: 29842 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_down_12(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFDAC: STP x20, x19, [sp, #-0x20]! | stack[1152921510049569808] = ???;  stack[1152921510049569816] = ???;  //  dest_result_addr=1152921510049569808 |  dest_result_addr=1152921510049569816
            // 0x00BBFDB0: STP x29, x30, [sp, #0x10]  | stack[1152921510049569824] = ???;  stack[1152921510049569832] = ???;  //  dest_result_addr=1152921510049569824 |  dest_result_addr=1152921510049569832
            // 0x00BBFDB4: ADD x29, sp, #0x10         | X29 = (1152921510049569808 + 16) = 1152921510049569824 (0x1000000144695C20);
            // 0x00BBFDB8: SUB sp, sp, #0x10          | SP = (1152921510049569808 - 16) = 1152921510049569792 (0x1000000144695C00);
            // 0x00BBFDBC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFDC0: LDRB w8, [x19, #0xb80]     | W8 = (bool)static_value_03733B80;       
            // 0x00BBFDC4: TBNZ w8, #0, #0xbbfde0     | if (static_value_03733B80 == true) goto label_0;
            // 0x00BBFDC8: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00BBFDCC: LDR x8, [x8, #0xb50]       | X8 = 0x2B8AE2C;                         
            // 0x00BBFDD0: LDR w0, [x8]               | W0 = 0x249;                             
            // 0x00BBFDD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x249, ????);      
            // 0x00BBFDD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFDDC: STRB w8, [x19, #0xb80]     | static_value_03733B80 = true;            //  dest_result_addr=57883520
            label_0:
            // 0x00BBFDE0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFDE4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFDE8: ADD x1, sp, #0xc           | X1 = (1152921510049569792 + 12) = 1152921510049569804 (0x1000000144695C0C);
            // 0x00BBFDEC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFDF0: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
            // 0x00BBFDF4: STR w8, [sp, #0xc]         | stack[1152921510049569804] = 0xC;        //  dest_result_addr=1152921510049569804
            // 0x00BBFDF8: BL #0x27bc028              | X0 = 1152921510049617856 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0xC);
            // 0x00BBFDFC: SUB sp, x29, #0x10         | SP = (1152921510049569824 - 16) = 1152921510049569808 (0x1000000144695C10);
            // 0x00BBFE00: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFE04: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFE08: RET                        |  return (System.Object)0xC;             
            return (object)12;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFE0C (12320268), len: 96  VirtAddr: 0x00BBFE0C RVA: 0x00BBFE0C token: 100663798 methodIndex: 29843 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_Take001_13(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFE0C: STP x20, x19, [sp, #-0x20]! | stack[1152921510049698032] = ???;  stack[1152921510049698040] = ???;  //  dest_result_addr=1152921510049698032 |  dest_result_addr=1152921510049698040
            // 0x00BBFE10: STP x29, x30, [sp, #0x10]  | stack[1152921510049698048] = ???;  stack[1152921510049698056] = ???;  //  dest_result_addr=1152921510049698048 |  dest_result_addr=1152921510049698056
            // 0x00BBFE14: ADD x29, sp, #0x10         | X29 = (1152921510049698032 + 16) = 1152921510049698048 (0x10000001446B5100);
            // 0x00BBFE18: SUB sp, sp, #0x10          | SP = (1152921510049698032 - 16) = 1152921510049698016 (0x10000001446B50E0);
            // 0x00BBFE1C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFE20: LDRB w8, [x19, #0xb81]     | W8 = (bool)static_value_03733B81;       
            // 0x00BBFE24: TBNZ w8, #0, #0xbbfe40     | if (static_value_03733B81 == true) goto label_0;
            // 0x00BBFE28: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00BBFE2C: LDR x8, [x8, #0x438]       | X8 = 0x2B8AE64;                         
            // 0x00BBFE30: LDR w0, [x8]               | W0 = 0x257;                             
            // 0x00BBFE34: BL #0x2782188              | X0 = sub_2782188( ?? 0x257, ????);      
            // 0x00BBFE38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFE3C: STRB w8, [x19, #0xb81]     | static_value_03733B81 = true;            //  dest_result_addr=57883521
            label_0:
            // 0x00BBFE40: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFE44: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFE48: ADD x1, sp, #0xc           | X1 = (1152921510049698016 + 12) = 1152921510049698028 (0x10000001446B50EC);
            // 0x00BBFE4C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFE50: MOVZ w8, #0xd              | W8 = 13 (0xD);//ML01                    
            // 0x00BBFE54: STR w8, [sp, #0xc]         | stack[1152921510049698028] = 0xD;        //  dest_result_addr=1152921510049698028
            // 0x00BBFE58: BL #0x27bc028              | X0 = 1152921510049746080 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0xD);
            // 0x00BBFE5C: SUB sp, x29, #0x10         | SP = (1152921510049698048 - 16) = 1152921510049698032 (0x10000001446B50F0);
            // 0x00BBFE60: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFE64: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFE68: RET                        |  return (System.Object)0xD;             
            return (object)13;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFE6C (12320364), len: 96  VirtAddr: 0x00BBFE6C RVA: 0x00BBFE6C token: 100663799 methodIndex: 29844 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_rage_14(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFE6C: STP x20, x19, [sp, #-0x20]! | stack[1152921510049826256] = ???;  stack[1152921510049826264] = ???;  //  dest_result_addr=1152921510049826256 |  dest_result_addr=1152921510049826264
            // 0x00BBFE70: STP x29, x30, [sp, #0x10]  | stack[1152921510049826272] = ???;  stack[1152921510049826280] = ???;  //  dest_result_addr=1152921510049826272 |  dest_result_addr=1152921510049826280
            // 0x00BBFE74: ADD x29, sp, #0x10         | X29 = (1152921510049826256 + 16) = 1152921510049826272 (0x10000001446D45E0);
            // 0x00BBFE78: SUB sp, sp, #0x10          | SP = (1152921510049826256 - 16) = 1152921510049826240 (0x10000001446D45C0);
            // 0x00BBFE7C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFE80: LDRB w8, [x19, #0xb82]     | W8 = (bool)static_value_03733B82;       
            // 0x00BBFE84: TBNZ w8, #0, #0xbbfea0     | if (static_value_03733B82 == true) goto label_0;
            // 0x00BBFE88: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x00BBFE8C: LDR x8, [x8, #0x248]       | X8 = 0x2B8AE4C;                         
            // 0x00BBFE90: LDR w0, [x8]               | W0 = 0x251;                             
            // 0x00BBFE94: BL #0x2782188              | X0 = sub_2782188( ?? 0x251, ????);      
            // 0x00BBFE98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFE9C: STRB w8, [x19, #0xb82]     | static_value_03733B82 = true;            //  dest_result_addr=57883522
            label_0:
            // 0x00BBFEA0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFEA4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFEA8: ADD x1, sp, #0xc           | X1 = (1152921510049826240 + 12) = 1152921510049826252 (0x10000001446D45CC);
            // 0x00BBFEAC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFEB0: ORR w8, wzr, #0xe          | W8 = 14(0xE);                           
            // 0x00BBFEB4: STR w8, [sp, #0xc]         | stack[1152921510049826252] = 0xE;        //  dest_result_addr=1152921510049826252
            // 0x00BBFEB8: BL #0x27bc028              | X0 = 1152921510049874304 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0xE);
            // 0x00BBFEBC: SUB sp, x29, #0x10         | SP = (1152921510049826272 - 16) = 1152921510049826256 (0x10000001446D45D0);
            // 0x00BBFEC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFEC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFEC8: RET                        |  return (System.Object)0xE;             
            return (object)14;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFECC (12320460), len: 96  VirtAddr: 0x00BBFECC RVA: 0x00BBFECC token: 100663800 methodIndex: 29845 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_reborn_15(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFECC: STP x20, x19, [sp, #-0x20]! | stack[1152921510049954480] = ???;  stack[1152921510049954488] = ???;  //  dest_result_addr=1152921510049954480 |  dest_result_addr=1152921510049954488
            // 0x00BBFED0: STP x29, x30, [sp, #0x10]  | stack[1152921510049954496] = ???;  stack[1152921510049954504] = ???;  //  dest_result_addr=1152921510049954496 |  dest_result_addr=1152921510049954504
            // 0x00BBFED4: ADD x29, sp, #0x10         | X29 = (1152921510049954480 + 16) = 1152921510049954496 (0x10000001446F3AC0);
            // 0x00BBFED8: SUB sp, sp, #0x10          | SP = (1152921510049954480 - 16) = 1152921510049954464 (0x10000001446F3AA0);
            // 0x00BBFEDC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFEE0: LDRB w8, [x19, #0xb83]     | W8 = (bool)static_value_03733B83;       
            // 0x00BBFEE4: TBNZ w8, #0, #0xbbff00     | if (static_value_03733B83 == true) goto label_0;
            // 0x00BBFEE8: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00BBFEEC: LDR x8, [x8, #0x40]        | X8 = 0x2B8AE50;                         
            // 0x00BBFEF0: LDR w0, [x8]               | W0 = 0x252;                             
            // 0x00BBFEF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x252, ????);      
            // 0x00BBFEF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFEFC: STRB w8, [x19, #0xb83]     | static_value_03733B83 = true;            //  dest_result_addr=57883523
            label_0:
            // 0x00BBFF00: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFF04: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFF08: ADD x1, sp, #0xc           | X1 = (1152921510049954464 + 12) = 1152921510049954476 (0x10000001446F3AAC);
            // 0x00BBFF0C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFF10: ORR w8, wzr, #0xf          | W8 = 15(0xF);                           
            // 0x00BBFF14: STR w8, [sp, #0xc]         | stack[1152921510049954476] = 0xF;        //  dest_result_addr=1152921510049954476
            // 0x00BBFF18: BL #0x27bc028              | X0 = 1152921510050002528 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0xF);
            // 0x00BBFF1C: SUB sp, x29, #0x10         | SP = (1152921510049954496 - 16) = 1152921510049954480 (0x10000001446F3AB0);
            // 0x00BBFF20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFF24: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFF28: RET                        |  return (System.Object)0xF;             
            return (object)15;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFF2C (12320556), len: 96  VirtAddr: 0x00BBFF2C RVA: 0x00BBFF2C token: 100663801 methodIndex: 29846 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_show_16(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFF2C: STP x20, x19, [sp, #-0x20]! | stack[1152921510050082704] = ???;  stack[1152921510050082712] = ???;  //  dest_result_addr=1152921510050082704 |  dest_result_addr=1152921510050082712
            // 0x00BBFF30: STP x29, x30, [sp, #0x10]  | stack[1152921510050082720] = ???;  stack[1152921510050082728] = ???;  //  dest_result_addr=1152921510050082720 |  dest_result_addr=1152921510050082728
            // 0x00BBFF34: ADD x29, sp, #0x10         | X29 = (1152921510050082704 + 16) = 1152921510050082720 (0x1000000144712FA0);
            // 0x00BBFF38: SUB sp, sp, #0x10          | SP = (1152921510050082704 - 16) = 1152921510050082688 (0x1000000144712F80);
            // 0x00BBFF3C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFF40: LDRB w8, [x19, #0xb84]     | W8 = (bool)static_value_03733B84;       
            // 0x00BBFF44: TBNZ w8, #0, #0xbbff60     | if (static_value_03733B84 == true) goto label_0;
            // 0x00BBFF48: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x00BBFF4C: LDR x8, [x8, #0xd78]       | X8 = 0x2B8AE5C;                         
            // 0x00BBFF50: LDR w0, [x8]               | W0 = 0x255;                             
            // 0x00BBFF54: BL #0x2782188              | X0 = sub_2782188( ?? 0x255, ????);      
            // 0x00BBFF58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFF5C: STRB w8, [x19, #0xb84]     | static_value_03733B84 = true;            //  dest_result_addr=57883524
            label_0:
            // 0x00BBFF60: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFF64: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFF68: ADD x1, sp, #0xc           | X1 = (1152921510050082688 + 12) = 1152921510050082700 (0x1000000144712F8C);
            // 0x00BBFF6C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFF70: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x00BBFF74: STR w8, [sp, #0xc]         | stack[1152921510050082700] = 0x10;       //  dest_result_addr=1152921510050082700
            // 0x00BBFF78: BL #0x27bc028              | X0 = 1152921510050130752 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x10);
            // 0x00BBFF7C: SUB sp, x29, #0x10         | SP = (1152921510050082720 - 16) = 1152921510050082704 (0x1000000144712F90);
            // 0x00BBFF80: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFF84: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFF88: RET                        |  return (System.Object)0x10;            
            return (object)16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFF8C (12320652), len: 96  VirtAddr: 0x00BBFF8C RVA: 0x00BBFF8C token: 100663802 methodIndex: 29847 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_qiyuan_17(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFF8C: STP x20, x19, [sp, #-0x20]! | stack[1152921510050210928] = ???;  stack[1152921510050210936] = ???;  //  dest_result_addr=1152921510050210928 |  dest_result_addr=1152921510050210936
            // 0x00BBFF90: STP x29, x30, [sp, #0x10]  | stack[1152921510050210944] = ???;  stack[1152921510050210952] = ???;  //  dest_result_addr=1152921510050210944 |  dest_result_addr=1152921510050210952
            // 0x00BBFF94: ADD x29, sp, #0x10         | X29 = (1152921510050210928 + 16) = 1152921510050210944 (0x1000000144732480);
            // 0x00BBFF98: SUB sp, sp, #0x10          | SP = (1152921510050210928 - 16) = 1152921510050210912 (0x1000000144732460);
            // 0x00BBFF9C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BBFFA0: LDRB w8, [x19, #0xb85]     | W8 = (bool)static_value_03733B85;       
            // 0x00BBFFA4: TBNZ w8, #0, #0xbbffc0     | if (static_value_03733B85 == true) goto label_0;
            // 0x00BBFFA8: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x00BBFFAC: LDR x8, [x8, #0xb60]       | X8 = 0x2B8AE48;                         
            // 0x00BBFFB0: LDR w0, [x8]               | W0 = 0x250;                             
            // 0x00BBFFB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x250, ????);      
            // 0x00BBFFB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BBFFBC: STRB w8, [x19, #0xb85]     | static_value_03733B85 = true;            //  dest_result_addr=57883525
            label_0:
            // 0x00BBFFC0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BBFFC4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BBFFC8: ADD x1, sp, #0xc           | X1 = (1152921510050210912 + 12) = 1152921510050210924 (0x100000014473246C);
            // 0x00BBFFCC: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BBFFD0: MOVZ w8, #0x11             | W8 = 17 (0x11);//ML01                   
            // 0x00BBFFD4: STR w8, [sp, #0xc]         | stack[1152921510050210924] = 0x11;       //  dest_result_addr=1152921510050210924
            // 0x00BBFFD8: BL #0x27bc028              | X0 = 1152921510050258976 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x11);
            // 0x00BBFFDC: SUB sp, x29, #0x10         | SP = (1152921510050210944 - 16) = 1152921510050210928 (0x1000000144732470);
            // 0x00BBFFE0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BBFFE4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BBFFE8: RET                        |  return (System.Object)0x11;            
            return (object)17;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BBFFEC (12320748), len: 96  VirtAddr: 0x00BBFFEC RVA: 0x00BBFFEC token: 100663803 methodIndex: 29848 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_passive1_18(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BBFFEC: STP x20, x19, [sp, #-0x20]! | stack[1152921510050339152] = ???;  stack[1152921510050339160] = ???;  //  dest_result_addr=1152921510050339152 |  dest_result_addr=1152921510050339160
            // 0x00BBFFF0: STP x29, x30, [sp, #0x10]  | stack[1152921510050339168] = ???;  stack[1152921510050339176] = ???;  //  dest_result_addr=1152921510050339168 |  dest_result_addr=1152921510050339176
            // 0x00BBFFF4: ADD x29, sp, #0x10         | X29 = (1152921510050339152 + 16) = 1152921510050339168 (0x1000000144751960);
            // 0x00BBFFF8: SUB sp, sp, #0x10          | SP = (1152921510050339152 - 16) = 1152921510050339136 (0x1000000144751940);
            // 0x00BBFFFC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC0000: LDRB w8, [x19, #0xb86]     | W8 = (bool)static_value_03733B86;       
            // 0x00BC0004: TBNZ w8, #0, #0xbc0020     | if (static_value_03733B86 == true) goto label_0;
            // 0x00BC0008: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00BC000C: LDR x8, [x8, #0x418]       | X8 = 0x2B8AE44;                         
            // 0x00BC0010: LDR w0, [x8]               | W0 = 0x24F;                             
            // 0x00BC0014: BL #0x2782188              | X0 = sub_2782188( ?? 0x24F, ????);      
            // 0x00BC0018: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC001C: STRB w8, [x19, #0xb86]     | static_value_03733B86 = true;            //  dest_result_addr=57883526
            label_0:
            // 0x00BC0020: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BC0024: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BC0028: ADD x1, sp, #0xc           | X1 = (1152921510050339136 + 12) = 1152921510050339148 (0x100000014475194C);
            // 0x00BC002C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BC0030: MOVZ w8, #0x12             | W8 = 18 (0x12);//ML01                   
            // 0x00BC0034: STR w8, [sp, #0xc]         | stack[1152921510050339148] = 0x12;       //  dest_result_addr=1152921510050339148
            // 0x00BC0038: BL #0x27bc028              | X0 = 1152921510050387200 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x12);
            // 0x00BC003C: SUB sp, x29, #0x10         | SP = (1152921510050339168 - 16) = 1152921510050339152 (0x1000000144751950);
            // 0x00BC0040: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC0044: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC0048: RET                        |  return (System.Object)0x12;            
            return (object)18;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC004C (12320844), len: 96  VirtAddr: 0x00BC004C RVA: 0x00BC004C token: 100663804 methodIndex: 29849 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_showidle_19(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BC004C: STP x20, x19, [sp, #-0x20]! | stack[1152921510050467376] = ???;  stack[1152921510050467384] = ???;  //  dest_result_addr=1152921510050467376 |  dest_result_addr=1152921510050467384
            // 0x00BC0050: STP x29, x30, [sp, #0x10]  | stack[1152921510050467392] = ???;  stack[1152921510050467400] = ???;  //  dest_result_addr=1152921510050467392 |  dest_result_addr=1152921510050467400
            // 0x00BC0054: ADD x29, sp, #0x10         | X29 = (1152921510050467376 + 16) = 1152921510050467392 (0x1000000144770E40);
            // 0x00BC0058: SUB sp, sp, #0x10          | SP = (1152921510050467376 - 16) = 1152921510050467360 (0x1000000144770E20);
            // 0x00BC005C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC0060: LDRB w8, [x19, #0xb87]     | W8 = (bool)static_value_03733B87;       
            // 0x00BC0064: TBNZ w8, #0, #0xbc0080     | if (static_value_03733B87 == true) goto label_0;
            // 0x00BC0068: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00BC006C: LDR x8, [x8, #0x7b8]       | X8 = 0x2B8AE60;                         
            // 0x00BC0070: LDR w0, [x8]               | W0 = 0x256;                             
            // 0x00BC0074: BL #0x2782188              | X0 = sub_2782188( ?? 0x256, ????);      
            // 0x00BC0078: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC007C: STRB w8, [x19, #0xb87]     | static_value_03733B87 = true;            //  dest_result_addr=57883527
            label_0:
            // 0x00BC0080: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BC0084: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BC0088: ADD x1, sp, #0xc           | X1 = (1152921510050467360 + 12) = 1152921510050467372 (0x1000000144770E2C);
            // 0x00BC008C: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BC0090: MOVZ w8, #0x13             | W8 = 19 (0x13);//ML01                   
            // 0x00BC0094: STR w8, [sp, #0xc]         | stack[1152921510050467372] = 0x13;       //  dest_result_addr=1152921510050467372
            // 0x00BC0098: BL #0x27bc028              | X0 = 1152921510050515424 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), 0x13);
            // 0x00BC009C: SUB sp, x29, #0x10         | SP = (1152921510050467392 - 16) = 1152921510050467376 (0x1000000144770E30);
            // 0x00BC00A0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC00A4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC00A8: RET                        |  return (System.Object)0x13;            
            return (object)19;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC00AC (12320940), len: 208  VirtAddr: 0x00BC00AC RVA: 0x00BC00AC token: 100663805 methodIndex: 29850 delegateWrapperIndex: 0 methodInvoker: 0
        private static object PerformMemberwiseClone(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x00BC00AC: STP x22, x21, [sp, #-0x30]! | stack[1152921510050595584] = ???;  stack[1152921510050595592] = ???;  //  dest_result_addr=1152921510050595584 |  dest_result_addr=1152921510050595592
            // 0x00BC00B0: STP x20, x19, [sp, #0x10]  | stack[1152921510050595600] = ???;  stack[1152921510050595608] = ???;  //  dest_result_addr=1152921510050595600 |  dest_result_addr=1152921510050595608
            // 0x00BC00B4: STP x29, x30, [sp, #0x20]  | stack[1152921510050595616] = ???;  stack[1152921510050595624] = ???;  //  dest_result_addr=1152921510050595616 |  dest_result_addr=1152921510050595624
            // 0x00BC00B8: ADD x29, sp, #0x20         | X29 = (1152921510050595584 + 32) = 1152921510050595616 (0x1000000144790320);
            // 0x00BC00BC: SUB sp, sp, #0x10          | SP = (1152921510050595584 - 16) = 1152921510050595568 (0x10000001447902F0);
            // 0x00BC00C0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC00C4: LDRB w8, [x20, #0xb88]     | W8 = (bool)static_value_03733B88;       
            // 0x00BC00C8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC00CC: TBNZ w8, #0, #0xbc00e8     | if (static_value_03733B88 == true) goto label_0;
            // 0x00BC00D0: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00BC00D4: LDR x8, [x8, #0x630]       | X8 = 0x2B8AE6C;                         
            // 0x00BC00D8: LDR w0, [x8]               | W0 = 0x259;                             
            // 0x00BC00DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x259, ????);      
            // 0x00BC00E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC00E4: STRB w8, [x20, #0xb88]     | static_value_03733B88 = true;            //  dest_result_addr=57883528
            label_0:
            // 0x00BC00E8: ADRP x21, #0x35db000       | X21 = 56471552 (0x35DB000);             
            // 0x00BC00EC: LDR x20, [x19]             | X20 = X1;                               
            // 0x00BC00F0: LDR x21, [x21, #0x808]     | X21 = 1152921504922341376;              
            // 0x00BC00F4: LDR x19, [x21]             | X19 = typeof(AnimationRunner.AniType);  
            // 0x00BC00F8: CBNZ x20, #0xbc0100        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BC00FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x259, ????);      
            label_1:
            // 0x00BC0100: LDR x8, [x20]              | X8 = X1;                                
            // 0x00BC0104: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC0108: LDR x8, [x19, #0x30]       | X8 = AnimationRunner.AniType.__il2cppRuntimeField_element_class;
            // 0x00BC010C: CMP x0, x8                 | STATE = COMPARE(X1 + 48, AnimationRunner.AniType.__il2cppRuntimeField_element_class)
            // 0x00BC0110: B.NE #0xbc0144             | if (X1 + 48 != AnimationRunner.AniType.__il2cppRuntimeField_element_class) goto label_2;
            // 0x00BC0114: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BC0118: BL #0x27bc4e8              | X1.System.IDisposable.Dispose();        
            X1.System.IDisposable.Dispose();
            // 0x00BC011C: LDR w8, [x0]               | W8 = X1;                                
            // 0x00BC0120: LDR x0, [x21]              | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BC0124: ADD x1, sp, #4             | X1 = (1152921510050595568 + 4) = 1152921510050595572 (0x10000001447902F4);
            // 0x00BC0128: STR w8, [sp, #4]           | stack[1152921510050595572] = X1;         //  dest_result_addr=1152921510050595572
            // 0x00BC012C: BL #0x27bc028              | X0 = 1152921510050643648 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), X1);
            // 0x00BC0130: SUB sp, x29, #0x20         | SP = (1152921510050595616 - 32) = 1152921510050595584 (0x1000000144790300);
            // 0x00BC0134: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC0138: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC013C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC0140: RET                        |  return (System.Object)X1;              
            return (object)X1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_2:
            // 0x00BC0144: ADD x8, sp, #8             | X8 = (1152921510050595568 + 8) = 1152921510050595576 (0x10000001447902F8);
            // 0x00BC0148: MOV x1, x19                | X1 = 1152921504922341376 (0x1000000012CE1000);//ML01
            // 0x00BC014C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC0150: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921510050583632]
            // 0x00BC0154: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x00BC0158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC015C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00BC0160: ADD x0, sp, #8             | X0 = (1152921510050595568 + 8) = 1152921510050595576 (0x10000001447902F8);
            // 0x00BC0164: BL #0x299a140              | 
            // 0x00BC0168: MOV x19, x0                | X19 = 1152921510050595576 (0x10000001447902F8);//ML01
            // 0x00BC016C: ADD x0, sp, #8             | X0 = (1152921510050595568 + 8) = 1152921510050595576 (0x10000001447902F8);
            // 0x00BC0170: BL #0x299a140              | 
            // 0x00BC0174: MOV x0, x19                | X0 = 1152921510050595576 (0x10000001447902F8);//ML01
            // 0x00BC0178: BL #0x980800               | X0 = sub_980800( ?? 0x10000001447902F8, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC017C (12321148), len: 92  VirtAddr: 0x00BC017C RVA: 0x00BC017C token: 100663806 methodIndex: 29851 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BC017C: STP x20, x19, [sp, #-0x20]! | stack[1152921510050719808] = ???;  stack[1152921510050719816] = ???;  //  dest_result_addr=1152921510050719808 |  dest_result_addr=1152921510050719816
            // 0x00BC0180: STP x29, x30, [sp, #0x10]  | stack[1152921510050719824] = ???;  stack[1152921510050719832] = ???;  //  dest_result_addr=1152921510050719824 |  dest_result_addr=1152921510050719832
            // 0x00BC0184: ADD x29, sp, #0x10         | X29 = (1152921510050719808 + 16) = 1152921510050719824 (0x10000001447AE850);
            // 0x00BC0188: SUB sp, sp, #0x10          | SP = (1152921510050719808 - 16) = 1152921510050719792 (0x10000001447AE830);
            // 0x00BC018C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BC0190: LDRB w8, [x19, #0xb89]     | W8 = (bool)static_value_03733B89;       
            // 0x00BC0194: TBNZ w8, #0, #0xbc01b0     | if (static_value_03733B89 == true) goto label_0;
            // 0x00BC0198: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x00BC019C: LDR x8, [x8, #0x538]       | X8 = 0x2B8AE74;                         
            // 0x00BC01A0: LDR w0, [x8]               | W0 = 0x25B;                             
            // 0x00BC01A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x25B, ????);      
            // 0x00BC01A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC01AC: STRB w8, [x19, #0xb89]     | static_value_03733B89 = true;            //  dest_result_addr=57883529
            label_0:
            // 0x00BC01B0: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00BC01B4: LDR x8, [x8, #0x808]       | X8 = 1152921504922341376;               
            // 0x00BC01B8: ADD x1, sp, #0xc           | X1 = (1152921510050719792 + 12) = 1152921510050719804 (0x10000001447AE83C);
            // 0x00BC01BC: STR wzr, [sp, #0xc]        | stack[1152921510050719804] = 0x0;        //  dest_result_addr=1152921510050719804
            // 0x00BC01C0: LDR x0, [x8]               | X0 = typeof(AnimationRunner.AniType);   
            // 0x00BC01C4: BL #0x27bc028              | X0 = 1152921510050763840 = (Il2CppObject*)Box((RuntimeClass*)typeof(AnimationRunner.AniType), null);
            // 0x00BC01C8: SUB sp, x29, #0x10         | SP = (1152921510050719824 - 16) = 1152921510050719808 (0x10000001447AE840);
            // 0x00BC01CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC01D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC01D4: RET                        |  return (System.Object)null;            
            return (object)0;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC01D8 (12321240), len: 92  VirtAddr: 0x00BC01D8 RVA: 0x00BC01D8 token: 100663807 methodIndex: 29852 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BC01D8: STP x20, x19, [sp, #-0x20]! | stack[1152921510050835904] = ???;  stack[1152921510050835912] = ???;  //  dest_result_addr=1152921510050835904 |  dest_result_addr=1152921510050835912
            // 0x00BC01DC: STP x29, x30, [sp, #0x10]  | stack[1152921510050835920] = ???;  stack[1152921510050835928] = ???;  //  dest_result_addr=1152921510050835920 |  dest_result_addr=1152921510050835928
            // 0x00BC01E0: ADD x29, sp, #0x10         | X29 = (1152921510050835904 + 16) = 1152921510050835920 (0x10000001447CADD0);
            // 0x00BC01E4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC01E8: LDRB w8, [x20, #0xb8a]     | W8 = (bool)static_value_03733B8A;       
            // 0x00BC01EC: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BC01F0: TBNZ w8, #0, #0xbc020c     | if (static_value_03733B8A == true) goto label_0;
            // 0x00BC01F4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00BC01F8: LDR x8, [x8, #0xad8]       | X8 = 0x2B8AE78;                         
            // 0x00BC01FC: LDR w0, [x8]               | W0 = 0x25C;                             
            // 0x00BC0200: BL #0x2782188              | X0 = sub_2782188( ?? 0x25C, ????);      
            // 0x00BC0204: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC0208: STRB w8, [x20, #0xb8a]     | static_value_03733B8A = true;            //  dest_result_addr=57883530
            label_0:
            // 0x00BC020C: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00BC0210: LDR x8, [x8, #0xa88]       | X8 = 1152921510047833568;               
            // 0x00BC0214: LDR x20, [x8]              | X20 = typeof(AniType[]);                
            // 0x00BC0218: MOV x0, x20                | X0 = 1152921510047833568 (0x10000001444EDDE0);//ML01
            // 0x00BC021C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(AniType[]), ????);
            // 0x00BC0220: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC0224: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BC0228: MOV x0, x20                | X0 = 1152921510047833568 (0x10000001444EDDE0);//ML01
            // 0x00BC022C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC0230: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(AniType[]), ????);
        
        }
    
    }

}
