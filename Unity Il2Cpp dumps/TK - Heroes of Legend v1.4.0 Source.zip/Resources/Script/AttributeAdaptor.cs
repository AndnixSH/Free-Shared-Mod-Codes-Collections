using UnityEngine;

namespace ILRuntime.Runtime.Adaptors
{
    internal class AttributeAdaptor : CrossBindingAdaptor
    {
        // Properties
        public override System.Type AdaptorType { get; }
        public override System.Type BaseCLRType { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01108070 (17858672), len: 8  VirtAddr: 0x01108070 RVA: 0x01108070 token: 100679912 methodIndex: 29199 delegateWrapperIndex: 0 methodInvoker: 0
        public AttributeAdaptor()
        {
            //
            // Disasemble & Code
            // 0x01108070: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01108074: B #0x28ef918               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01108078 (17858680), len: 116  VirtAddr: 0x01108078 RVA: 0x01108078 token: 100679913 methodIndex: 29200 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_AdaptorType()
        {
            //
            // Disasemble & Code
            // 0x01108078: STP x20, x19, [sp, #-0x20]! | stack[1152921512829033472] = ???;  stack[1152921512829033480] = ???;  //  dest_result_addr=1152921512829033472 |  dest_result_addr=1152921512829033480
            // 0x0110807C: STP x29, x30, [sp, #0x10]  | stack[1152921512829033488] = ???;  stack[1152921512829033496] = ???;  //  dest_result_addr=1152921512829033488 |  dest_result_addr=1152921512829033496
            // 0x01108080: ADD x29, sp, #0x10         | X29 = (1152921512829033472 + 16) = 1152921512829033488 (0x10000001EA149C10);
            // 0x01108084: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x01108088: LDRB w8, [x19, #0xb91]     | W8 = (bool)static_value_03735B91;       
            // 0x0110808C: TBNZ w8, #0, #0x11080a8    | if (static_value_03735B91 == true) goto label_0;
            // 0x01108090: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x01108094: LDR x8, [x8, #0x718]       | X8 = 0x2B8EE70;                         
            // 0x01108098: LDR w0, [x8]               | W0 = 0x125E;                            
            // 0x0110809C: BL #0x2782188              | X0 = sub_2782188( ?? 0x125E, ????);     
            // 0x011080A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x011080A4: STRB w8, [x19, #0xb91]     | static_value_03735B91 = true;            //  dest_result_addr=57891729
            label_0:
            // 0x011080A8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x011080AC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x011080B0: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x011080B4: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x011080B8: LDR x8, [x8, #0x400]       | X8 = 1152921504821755904;               
            // 0x011080BC: LDR x19, [x8]              | X19 = typeof(AttributeAdaptor.Adaptor); 
            // 0x011080C0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x011080C4: TBZ w8, #0, #0x11080d4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x011080C8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x011080CC: CBNZ w8, #0x11080d4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x011080D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x011080D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x011080D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x011080DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x011080E0: MOV x1, x19                | X1 = 1152921504821755904 (0x100000000CCF4000);//ML01
            // 0x011080E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x011080E8: B #0x1b6d31c               | return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        
        }
        //
        // Offset in libil2cpp.so: 0x011080EC (17858796), len: 116  VirtAddr: 0x011080EC RVA: 0x011080EC token: 100679914 methodIndex: 29201 delegateWrapperIndex: 0 methodInvoker: 0
        public override System.Type get_BaseCLRType()
        {
            //
            // Disasemble & Code
            // 0x011080EC: STP x20, x19, [sp, #-0x20]! | stack[1152921512829145472] = ???;  stack[1152921512829145480] = ???;  //  dest_result_addr=1152921512829145472 |  dest_result_addr=1152921512829145480
            // 0x011080F0: STP x29, x30, [sp, #0x10]  | stack[1152921512829145488] = ???;  stack[1152921512829145496] = ???;  //  dest_result_addr=1152921512829145488 |  dest_result_addr=1152921512829145496
            // 0x011080F4: ADD x29, sp, #0x10         | X29 = (1152921512829145472 + 16) = 1152921512829145488 (0x10000001EA165190);
            // 0x011080F8: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x011080FC: LDRB w8, [x19, #0xb92]     | W8 = (bool)static_value_03735B92;       
            // 0x01108100: TBNZ w8, #0, #0x110811c    | if (static_value_03735B92 == true) goto label_0;
            // 0x01108104: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x01108108: LDR x8, [x8, #0xca8]       | X8 = 0x2B8EE74;                         
            // 0x0110810C: LDR w0, [x8]               | W0 = 0x125F;                            
            // 0x01108110: BL #0x2782188              | X0 = sub_2782188( ?? 0x125F, ????);     
            // 0x01108114: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01108118: STRB w8, [x19, #0xb92]     | static_value_03735B92 = true;            //  dest_result_addr=57891730
            label_0:
            // 0x0110811C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01108120: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01108124: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x01108128: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x0110812C: LDR x8, [x8, #0x8a8]       | X8 = 1152921504607006720;               
            // 0x01108130: LDR x19, [x8]              | X19 = typeof(System.Attribute);         
            // 0x01108134: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01108138: TBZ w8, #0, #0x1108148     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0110813C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01108140: CBNZ w8, #0x1108148        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01108144: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01108148: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0110814C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01108150: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01108154: MOV x1, x19                | X1 = 1152921504607006720 (0x1000000000027000);//ML01
            // 0x01108158: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0110815C: B #0x1b6d31c               | return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            return System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        
        }
        //
        // Offset in libil2cpp.so: 0x01108160 (17858912), len: 112  VirtAddr: 0x01108160 RVA: 0x01108160 token: 100679915 methodIndex: 29202 delegateWrapperIndex: 0 methodInvoker: 0
        public override object CreateCLRInstance(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILRuntime.Runtime.Intepreter.ILTypeInstance instance)
        {
            //
            // Disasemble & Code
            // 0x01108160: STP x22, x21, [sp, #-0x30]! | stack[1152921512829265648] = ???;  stack[1152921512829265656] = ???;  //  dest_result_addr=1152921512829265648 |  dest_result_addr=1152921512829265656
            // 0x01108164: STP x20, x19, [sp, #0x10]  | stack[1152921512829265664] = ???;  stack[1152921512829265672] = ???;  //  dest_result_addr=1152921512829265664 |  dest_result_addr=1152921512829265672
            // 0x01108168: STP x29, x30, [sp, #0x20]  | stack[1152921512829265680] = ???;  stack[1152921512829265688] = ???;  //  dest_result_addr=1152921512829265680 |  dest_result_addr=1152921512829265688
            // 0x0110816C: ADD x29, sp, #0x20         | X29 = (1152921512829265648 + 32) = 1152921512829265680 (0x10000001EA182710);
            // 0x01108170: ADRP x21, #0x3735000       | X21 = 57888768 (0x3735000);             
            // 0x01108174: LDRB w8, [x21, #0xb93]     | W8 = (bool)static_value_03735B93;       
            // 0x01108178: MOV x19, x2                | X19 = instance;//m1                     
            // 0x0110817C: MOV x20, x1                | X20 = appdomain;//m1                    
            // 0x01108180: TBNZ w8, #0, #0x110819c    | if (static_value_03735B93 == true) goto label_0;
            // 0x01108184: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x01108188: LDR x8, [x8, #0x8e0]       | X8 = 0x2B8EE6C;                         
            // 0x0110818C: LDR w0, [x8]               | W0 = 0x125D;                            
            // 0x01108190: BL #0x2782188              | X0 = sub_2782188( ?? 0x125D, ????);     
            // 0x01108194: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01108198: STRB w8, [x21, #0xb93]     | static_value_03735B93 = true;            //  dest_result_addr=57891731
            label_0:
            // 0x0110819C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x011081A0: LDR x8, [x8, #0x208]       | X8 = 1152921504821755904;               
            // 0x011081A4: LDR x0, [x8]               | X0 = typeof(AttributeAdaptor.Adaptor);  
            System.Attribute val_1 = null;
            // 0x011081A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AttributeAdaptor.Adaptor), ????);
            // 0x011081AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x011081B0: MOV x21, x0                | X21 = 1152921504821755904 (0x100000000CCF4000);//ML01
            // 0x011081B4: BL #0x18d1dd4              | .ctor();                                
            val_1 = new System.Attribute();
            // 0x011081B8: STP x19, x20, [x21, #0x10] | typeof(AttributeAdaptor.Adaptor).__il2cppRuntimeField_10 = instance;  typeof(AttributeAdaptor.Adaptor).__il2cppRuntimeField_18 = appdomain;  //  dest_result_addr=1152921504821755920 |  dest_result_addr=1152921504821755928
            typeof(AttributeAdaptor.Adaptor).__il2cppRuntimeField_10 = instance;
            typeof(AttributeAdaptor.Adaptor).__il2cppRuntimeField_18 = appdomain;
            // 0x011081BC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x011081C0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x011081C4: MOV x0, x21                | X0 = 1152921504821755904 (0x100000000CCF4000);//ML01
            // 0x011081C8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x011081CC: RET                        |  return (System.Object)typeof(AttributeAdaptor.Adaptor);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
