using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x2865F68
public class ActiveAnimation : MonoBehaviour
{
    // Fields
    public static ActiveAnimation current; // static_offset: 0x00000000
    public System.Collections.Generic.List<EventDelegate> onFinished; //  0x00000018
    [UnityEngine.HideInInspector] // 0x2865FA0
    public UnityEngine.GameObject eventReceiver; //  0x00000020
    [UnityEngine.HideInInspector] // 0x2865FB0
    public string callWhenFinished; //  0x00000028
    private UnityEngine.Animation mAnim; //  0x00000030
    private AnimationOrTween.Direction mLastDirection; //  0x00000038
    private AnimationOrTween.Direction mDisableDirection; //  0x0000003C
    private bool mNotify; //  0x00000040
    private UnityEngine.Animator mAnimator; //  0x00000048
    private string mClip; //  0x00000050
    
    // Properties
    private float playbackTime { get; }
    public bool isPlaying { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B1C4EC (11650284), len: 160  VirtAddr: 0x00B1C4EC RVA: 0x00B1C4EC token: 100687834 methodIndex: 24669 delegateWrapperIndex: 0 methodInvoker: 0
    public ActiveAnimation()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00B1C4EC: STP x20, x19, [sp, #-0x20]! | stack[1152921514150052176] = ???;  stack[1152921514150052184] = ???;  //  dest_result_addr=1152921514150052176 |  dest_result_addr=1152921514150052184
        // 0x00B1C4F0: STP x29, x30, [sp, #0x10]  | stack[1152921514150052192] = ???;  stack[1152921514150052200] = ???;  //  dest_result_addr=1152921514150052192 |  dest_result_addr=1152921514150052200
        // 0x00B1C4F4: ADD x29, sp, #0x10         | X29 = (1152921514150052176 + 16) = 1152921514150052192 (0x1000000238D1C160);
        // 0x00B1C4F8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1C4FC: LDRB w8, [x20, #0x706]     | W8 = (bool)static_value_03733706;       
        // 0x00B1C500: MOV x19, x0                | X19 = 1152921514150064208 (0x1000000238D1F050);//ML01
        // 0x00B1C504: TBNZ w8, #0, #0xb1c520     | if (static_value_03733706 == true) goto label_0;
        // 0x00B1C508: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00B1C50C: LDR x8, [x8, #0x3e0]       | X8 = 0x2B8A944;                         
        // 0x00B1C510: LDR w0, [x8]               | W0 = 0x10F;                             
        // 0x00B1C514: BL #0x2782188              | X0 = sub_2782188( ?? 0x10F, ????);      
        // 0x00B1C518: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C51C: STRB w8, [x20, #0x706]     | static_value_03733706 = true;            //  dest_result_addr=57882374
        label_0:
        // 0x00B1C520: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00B1C524: LDR x8, [x8, #0x460]       | X8 = 1152921504616644608;               
        // 0x00B1C528: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<EventDelegate> val_1 = null;
        // 0x00B1C52C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00B1C530: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
        // 0x00B1C534: LDR x8, [x8, #0x648]       | X8 = 1152921514083953520;               
        // 0x00B1C538: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00B1C53C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<EventDelegate>::.ctor();
        // 0x00B1C540: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<EventDelegate>();
        // 0x00B1C544: STR x20, [x19, #0x18]      | this.onFinished = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514150064232
        this.onFinished = val_1;
        // 0x00B1C548: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x00B1C54C: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x00B1C550: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_2 = null;
        // 0x00B1C554: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1C558: TBZ w8, #0, #0xb1c56c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1C55C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C560: CBNZ w8, #0xb1c56c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1C564: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00B1C568: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_2 = null;
        label_2:
        // 0x00B1C56C: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00B1C570: MOV x0, x19                | X0 = 1152921514150064208 (0x1000000238D1F050);//ML01
        // 0x00B1C574: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C578: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x00B1C57C: STR x8, [x19, #0x50]       | this.mClip = System.String.Empty;        //  dest_result_addr=1152921514150064288
        this.mClip = System.String.Empty;
        // 0x00B1C580: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C584: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C588: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C58C (11650444), len: 208  VirtAddr: 0x00B1C58C RVA: 0x00B1C58C token: 100687835 methodIndex: 24670 delegateWrapperIndex: 0 methodInvoker: 0
    private float get_playbackTime()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        float val_3;
        //  | 
        var val_4;
        // 0x00B1C58C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514150172336] = ???;  stack[1152921514150172344] = ???;  //  dest_result_addr=1152921514150172336 |  dest_result_addr=1152921514150172344
        // 0x00B1C590: STP x20, x19, [sp, #0x10]  | stack[1152921514150172352] = ???;  stack[1152921514150172360] = ???;  //  dest_result_addr=1152921514150172352 |  dest_result_addr=1152921514150172360
        // 0x00B1C594: STP x29, x30, [sp, #0x20]  | stack[1152921514150172368] = ???;  stack[1152921514150172376] = ???;  //  dest_result_addr=1152921514150172368 |  dest_result_addr=1152921514150172376
        // 0x00B1C598: ADD x29, sp, #0x20         | X29 = (1152921514150172336 + 32) = 1152921514150172368 (0x1000000238D396D0);
        // 0x00B1C59C: SUB sp, sp, #0x60          | SP = (1152921514150172336 - 96) = 1152921514150172240 (0x1000000238D39650);
        // 0x00B1C5A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1C5A4: LDRB w8, [x20, #0x707]     | W8 = (bool)static_value_03733707;       
        // 0x00B1C5A8: MOV x19, x0                | X19 = 1152921514150184384 (0x1000000238D3C5C0);//ML01
        // 0x00B1C5AC: TBNZ w8, #0, #0xb1c5c8     | if (static_value_03733707 == true) goto label_0;
        // 0x00B1C5B0: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00B1C5B4: LDR x8, [x8, #0x5a8]       | X8 = 0x2B8A99C;                         
        // 0x00B1C5B8: LDR w0, [x8]               | W0 = 0x125;                             
        // 0x00B1C5BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x125, ????);      
        // 0x00B1C5C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C5C4: STRB w8, [x20, #0x707]     | static_value_03733707 = true;            //  dest_result_addr=57882375
        label_0:
        // 0x00B1C5C8: STR wzr, [sp, #0x50]       | stack[1152921514150172320] = 0x0;        //  dest_result_addr=1152921514150172320
        // 0x00B1C5CC: STP xzr, xzr, [sp, #0x40]  | stack[1152921514150172304] = 0x0;  stack[1152921514150172312] = 0x0;  //  dest_result_addr=1152921514150172304 |  dest_result_addr=1152921514150172312
        // 0x00B1C5D0: STP xzr, xzr, [sp, #0x30]  | stack[1152921514150172288] = 0x0;  stack[1152921514150172296] = 0x0;  //  dest_result_addr=1152921514150172288 |  dest_result_addr=1152921514150172296
        // 0x00B1C5D4: LDR x19, [x19, #0x48]      | X19 = this.mAnimator; //P2              
        // 0x00B1C5D8: CBNZ x19, #0xb1c5e0        | if (this.mAnimator != null) goto label_1;
        if(this.mAnimator != null)
        {
            goto label_1;
        }
        // 0x00B1C5DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x125, ????);      
        label_1:
        // 0x00B1C5E0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1C5E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1C5E8: ADD x8, sp, #8             | X8 = (1152921514150172240 + 8) = 1152921514150172248 (0x1000000238D39658);
        // 0x00B1C5EC: MOV x0, x19                | X0 = this.mAnimator;//m1                
        // 0x00B1C5F0: BL #0x2711bc8              | X0 = this.mAnimator.GetCurrentAnimatorStateInfo(layerIndex:  0);
        UnityEngine.AnimatorStateInfo val_1 = this.mAnimator.GetCurrentAnimatorStateInfo(layerIndex:  0);
        // 0x00B1C5F4: LDR w8, [sp, #0x28]        | W8 = val_2;                              //  find_add[1152921514150160384]
        // 0x00B1C5F8: LDUR q0, [sp, #0x18]       | Q0 = val_3;                              //  find_add[1152921514150160384]
        // 0x00B1C5FC: LDUR q1, [sp, #8]          | Q1 = val_4;                              //  find_add[1152921514150160384]
        // 0x00B1C600: ADD x0, sp, #0x30          | X0 = (1152921514150172240 + 48) = 1152921514150172288 (0x1000000238D39680);
        // 0x00B1C604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C608: STR w8, [sp, #0x50]        | stack[1152921514150172320] = val_2;      //  dest_result_addr=1152921514150172320
        // 0x00B1C60C: STP q1, q0, [sp, #0x30]    | stack[1152921514150172288] = val_4;  stack[1152921514150172304] = val_3;  //  dest_result_addr=1152921514150172288 |  dest_result_addr=1152921514150172304
        // 0x00B1C610: BL #0x2714d44              | X0 = label_UnityEngine_AnimatorStateInfo_get_shortNameHash_GL02714D44();
        // 0x00B1C614: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B1C618: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B1C61C: MOV v8.16b, v0.16b         | V8 = val_3;//m1                         
        // 0x00B1C620: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B1C624: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B1C628: TBZ w8, #0, #0xb1c638      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B1C62C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C630: CBNZ w8, #0xb1c638         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1C634: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x00B1C638: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C63C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C640: MOV v0.16b, v8.16b         | V0 = val_3;//m1                         
        // 0x00B1C644: BL #0x1a7dd00              | X0 = UnityEngine.Mathf.Clamp01(value:  val_3);
        float val_5 = UnityEngine.Mathf.Clamp01(value:  val_3);
        // 0x00B1C648: SUB sp, x29, #0x20         | SP = (1152921514150172368 - 32) = 1152921514150172336 (0x1000000238D396B0);
        // 0x00B1C64C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1C650: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1C654: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B1C658: RET                        |  return (System.Single)val_5;           
        return val_5;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1C65C (11650652), len: 1036  VirtAddr: 0x00B1C65C RVA: 0x00B1C65C token: 100687836 methodIndex: 24671 delegateWrapperIndex: 0 methodInvoker: 0
    public bool get_isPlaying()
    {
        //
        // Disasemble & Code
        //  | 
        var val_8;
        //  | 
        UnityEngine.Animator val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        //  | 
        UnityEngine.Animation val_20;
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        var val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        // 0x00B1C65C: STP d9, d8, [sp, #-0x60]!  | stack[1152921514150329328] = ???;  stack[1152921514150329336] = ???;  //  dest_result_addr=1152921514150329328 |  dest_result_addr=1152921514150329336
        // 0x00B1C660: STP x26, x25, [sp, #0x10]  | stack[1152921514150329344] = ???;  stack[1152921514150329352] = ???;  //  dest_result_addr=1152921514150329344 |  dest_result_addr=1152921514150329352
        // 0x00B1C664: STP x24, x23, [sp, #0x20]  | stack[1152921514150329360] = ???;  stack[1152921514150329368] = ???;  //  dest_result_addr=1152921514150329360 |  dest_result_addr=1152921514150329368
        // 0x00B1C668: STP x22, x21, [sp, #0x30]  | stack[1152921514150329376] = ???;  stack[1152921514150329384] = ???;  //  dest_result_addr=1152921514150329376 |  dest_result_addr=1152921514150329384
        // 0x00B1C66C: STP x20, x19, [sp, #0x40]  | stack[1152921514150329392] = ???;  stack[1152921514150329400] = ???;  //  dest_result_addr=1152921514150329392 |  dest_result_addr=1152921514150329400
        // 0x00B1C670: STP x29, x30, [sp, #0x50]  | stack[1152921514150329408] = ???;  stack[1152921514150329416] = ???;  //  dest_result_addr=1152921514150329408 |  dest_result_addr=1152921514150329416
        // 0x00B1C674: ADD x29, sp, #0x50         | X29 = (1152921514150329328 + 80) = 1152921514150329408 (0x1000000238D5FC40);
        // 0x00B1C678: SUB sp, sp, #0x10          | SP = (1152921514150329328 - 16) = 1152921514150329312 (0x1000000238D5FBE0);
        // 0x00B1C67C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B1C680: LDRB w8, [x19, #0x708]     | W8 = (bool)static_value_03733708;       
        // 0x00B1C684: MOV x20, x0                | X20 = 1152921514150341424 (0x1000000238D62B30);//ML01
        // 0x00B1C688: TBNZ w8, #0, #0xb1c6a4     | if (static_value_03733708 == true) goto label_0;
        // 0x00B1C68C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B1C690: LDR x8, [x8, #0x60]        | X8 = 0x2B8A998;                         
        // 0x00B1C694: LDR w0, [x8]               | W0 = 0x124;                             
        // 0x00B1C698: BL #0x2782188              | X0 = sub_2782188( ?? 0x124, ????);      
        // 0x00B1C69C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1C6A0: STRB w8, [x19, #0x708]     | static_value_03733708 = true;            //  dest_result_addr=57882376
        label_0:
        // 0x00B1C6A4: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B1C6A8: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00B1C6AC: LDR x19, [x20, #0x30]      | X19 = this.mAnim; //P2                  
        // 0x00B1C6B0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1C6B4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1C6B8: TBZ w8, #0, #0xb1c6c8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1C6BC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C6C0: CBNZ w8, #0xb1c6c8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1C6C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B1C6C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C6CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1C6D0: MOV x1, x19                | X1 = this.mAnim;//m1                    
        // 0x00B1C6D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1C6D8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.mAnim);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.mAnim);
        // 0x00B1C6DC: TBZ w0, #0, #0xb1c738      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B1C6E0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1C6E4: LDR x19, [x20, #0x48]      | X19 = this.mAnimator; //P2              
        val_16 = this.mAnimator;
        // 0x00B1C6E8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1C6EC: TBZ w8, #0, #0xb1c6fc      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B1C6F0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1C6F4: CBNZ w8, #0xb1c6fc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B1C6F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00B1C6FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1C700: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1C704: MOV x1, x19                | X1 = this.mAnimator;//m1                
        // 0x00B1C708: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1C70C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_16);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_16);
        // 0x00B1C710: TBZ w0, #0, #0xb1ca18      | if (val_2 == false) goto label_46;      
        if(val_2 == false)
        {
            goto label_46;
        }
        // 0x00B1C714: LDR w19, [x20, #0x38]      | W19 = this.mLastDirection; //P2         
        val_16 = this.mLastDirection;
        // 0x00B1C718: MOV x0, x20                | X0 = 1152921514150341424 (0x1000000238D62B30);//ML01
        // 0x00B1C71C: BL #0xb1c58c               | X0 = this.get_playbackTime();           
        float val_3 = this.playbackTime;
        // 0x00B1C720: CMN w19, #1                | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1C724: B.EQ #0xb1ca08             | if (val_16 == 0x1) goto label_7;        
        if(val_16 == 1)
        {
            goto label_7;
        }
        // 0x00B1C728: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B1C72C: FCMP s0, s1                | STATE = COMPARE(val_3, 1)               
        // 0x00B1C730: B.NE #0xb1ca10             | if (val_3 != 1f) goto label_8;          
        if(val_3 != 1f)
        {
            goto label_8;
        }
        // 0x00B1C734: B #0xb1ca18                |  goto label_46;                         
        goto label_46;
        label_3:
        // 0x00B1C738: LDR x19, [x20, #0x30]      | X19 = this.mAnim; //P2                  
        // 0x00B1C73C: CBNZ x19, #0xb1c744        | if (this.mAnim != null) goto label_10;  
        if(this.mAnim != null)
        {
            goto label_10;
        }
        // 0x00B1C740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_10:
        // 0x00B1C744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C748: MOV x0, x19                | X0 = this.mAnim;//m1                    
        // 0x00B1C74C: BL #0x270cb80              | X0 = this.mAnim.GetEnumerator();        
        System.Collections.IEnumerator val_4 = this.mAnim.GetEnumerator();
        // 0x00B1C750: ADRP x24, #0x361c000       | X24 = 56737792 (0x361C000);             
        // 0x00B1C754: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
        // 0x00B1C758: LDR x24, [x24, #0x358]     | X24 = 1152921504608018432;              
        // 0x00B1C75C: LDR x25, [x25, #0x990]     | X25 = 1152921504723460096;              
        // 0x00B1C760: MOV x19, x0                | X19 = val_4;//m1                        
        label_34:
        // 0x00B1C764: CBNZ x19, #0xb1c76c        | if (val_4 != null) goto label_11;       
        if(val_4 != null)
        {
            goto label_11;
        }
        // 0x00B1C768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_11:
        // 0x00B1C76C: LDR x8, [x19]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1C770: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1C774: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1C778: CBZ x9, #0xb1c7a4          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
        // 0x00B1C77C: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1C780: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_16 = 0;
        // 0x00B1C784: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_14:
        // 0x00B1C788: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1C78C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1C790: B.EQ #0xb1c7b4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
        // 0x00B1C794: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_16 = val_16 + 1;
        // 0x00B1C798: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1C79C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1C7A0: B.LO #0xb1c788             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_14;
        label_12:
        // 0x00B1C7A4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1C7A8: MOV x0, x19                | X0 = val_4;//m1                         
        val_17 = val_4;
        // 0x00B1C7AC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_4, ????);      
        // 0x00B1C7B0: B #0xb1c7c4                |  goto label_15;                         
        goto label_15;
        label_13:
        // 0x00B1C7B4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1C7B8: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
        // 0x00B1C7BC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
        // 0x00B1C7C0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
        label_15:
        // 0x00B1C7C4: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1C7C8: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B1C7CC: BLR x8                     | X0 = sub_100000000011E000( ?? val_4, ????);
        // 0x00B1C7D0: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        System.Collections.IEnumerator val_6 = val_4 & 1;
        // 0x00B1C7D4: TBZ w8, #0, #0xb1ca40      | if (((val_4 & 1) & 0x1) == 0) goto label_16;
        if((val_6 & 1) == 0)
        {
            goto label_16;
        }
        // 0x00B1C7D8: CBNZ x19, #0xb1c7e0        | if (val_4 != null) goto label_17;       
        if(val_4 != null)
        {
            goto label_17;
        }
        // 0x00B1C7DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_17:
        // 0x00B1C7E0: LDR x8, [x19]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1C7E4: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1C7E8: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1C7EC: CBZ x9, #0xb1c818          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_18;
        // 0x00B1C7F0: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1C7F4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_17 = 0;
        // 0x00B1C7F8: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_20:
        // 0x00B1C7FC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1C800: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1C804: B.EQ #0xb1c828             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_19;
        // 0x00B1C808: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_17 = val_17 + 1;
        // 0x00B1C80C: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1C810: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1C814: B.LO #0xb1c7fc             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_20;
        label_18:
        // 0x00B1C818: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1C81C: MOV x0, x19                | X0 = val_4;//m1                         
        val_18 = val_4;
        // 0x00B1C820: BL #0x2776c24              | X0 = sub_2776C24( ?? val_4, ????);      
        // 0x00B1C824: B #0xb1c834                |  goto label_21;                         
        goto label_21;
        label_19:
        // 0x00B1C828: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1C82C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1C830: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_21:
        // 0x00B1C834: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1C838: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B1C83C: BLR x8                     | X0 = sub_100000000011E000( ?? val_4, ????);
        // 0x00B1C840: MOV x21, x0                | X21 = val_4;//m1                        
        val_19 = val_4;
        // 0x00B1C844: CBZ x21, #0xb1c87c         | if (val_4 == null) goto label_22;       
        if(val_19 == null)
        {
            goto label_22;
        }
        // 0x00B1C848: LDR x1, [x25]              | X1 = typeof(UnityEngine.AnimationState);
        // 0x00B1C84C: LDR x8, [x21]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1C850: CMP x8, x1                 | STATE = COMPARE(typeof(System.Collections.IEnumerator), typeof(UnityEngine.AnimationState))
        // 0x00B1C854: B.EQ #0xb1c890             | if (typeof(System.Collections.IEnumerator) == null) goto label_23;
        if(null == null)
        {
            goto label_23;
        }
        // 0x00B1C858: LDR x0, [x8, #0x30]        | X0 = System.Collections.IEnumerator.__il2cppRuntimeField_element_class;
        // 0x00B1C85C: ADD x8, sp, #8             | X8 = (1152921514150329312 + 8) = 1152921514150329320 (0x1000000238D5FBE8);
        // 0x00B1C860: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IEnumerator.__il2cppRuntimeField_element_class, ????);
        // 0x00B1C864: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921514150317424]
        // 0x00B1C868: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
        // 0x00B1C86C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C870: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        // 0x00B1C874: ADD x0, sp, #8             | X0 = (1152921514150329312 + 8) = 1152921514150329320 (0x1000000238D5FBE8);
        // 0x00B1C878: BL #0x299a140              | 
        label_22:
        // 0x00B1C87C: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        val_20 = this.mAnim;
        // 0x00B1C880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000238D5FBE8, ????);
        // 0x00B1C884: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_19 = 0;
        // 0x00B1C888: ORR w26, wzr, #1           | W26 = 1(0x1);                           
        val_21 = 1;
        // 0x00B1C88C: B #0xb1c898                |  goto label_24;                         
        goto label_24;
        label_23:
        // 0x00B1C890: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        val_20 = this.mAnim;
        // 0x00B1C894: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
        val_21 = 0;
        label_24:
        // 0x00B1C898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C89C: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B1C8A0: BL #0x270eda0              | X0 = val_4.get_name();                  
        string val_9 = val_19.name;
        // 0x00B1C8A4: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x00B1C8A8: CBNZ x22, #0xb1c8b0        | if (this.mAnim != null) goto label_25;  
        if(val_20 != null)
        {
            goto label_25;
        }
        // 0x00B1C8AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_25:
        // 0x00B1C8B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1C8B4: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1C8B8: MOV x1, x23                | X1 = val_9;//m1                         
        // 0x00B1C8BC: BL #0x270c41c              | X0 = this.mAnim.IsPlaying(name:  val_9);
        bool val_10 = val_20.IsPlaying(name:  val_9);
        // 0x00B1C8C0: AND w8, w0, #1             | W8 = (val_10 & 1);                      
        bool val_11 = val_10;
        // 0x00B1C8C4: TBZ w8, #0, #0xb1c764      | if ((val_10 & 1) == false) goto label_34;
        if(val_11 == false)
        {
            goto label_34;
        }
        // 0x00B1C8C8: LDR w8, [x20, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1C8CC: CMN w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1C8D0: B.EQ #0xb1c914             | if (this.mLastDirection == 0x1) goto label_27;
        if(this.mLastDirection == 1)
        {
            goto label_27;
        }
        // 0x00B1C8D4: CMP w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1C8D8: B.NE #0xb1c930             | if (this.mLastDirection != 0x1) goto label_32;
        if(this.mLastDirection != 1)
        {
            goto label_32;
        }
        // 0x00B1C8DC: CBZ w26, #0xb1c8e4         | if (0x0 == 0) goto label_29;            
        if(val_21 == 0)
        {
            goto label_29;
        }
        // 0x00B1C8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_29:
        // 0x00B1C8E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C8E8: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B1C8EC: BL #0x270e7d8              | X0 = val_4.get_time();                  
        float val_12 = val_19.time;
        // 0x00B1C8F0: MOV v8.16b, v0.16b         | V8 = val_12;//m1                        
        // 0x00B1C8F4: CBZ w26, #0xb1c8fc         | if (0x0 == 0) goto label_30;            
        if(val_21 == 0)
        {
            goto label_30;
        }
        // 0x00B1C8F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_30:
        // 0x00B1C8FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C900: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B1C904: BL #0x270eb58              | X0 = val_4.get_length();                
        float val_13 = val_19.length;
        // 0x00B1C908: FCMP s8, s0                | STATE = COMPARE(val_12, val_13)         
        // 0x00B1C90C: B.PL #0xb1c764             | if (val_12 >= 0) goto label_34;         
        if(val_12 >= 0)
        {
            goto label_34;
        }
        // 0x00B1C910: B #0xb1c930                |  goto label_32;                         
        goto label_32;
        label_27:
        // 0x00B1C914: CBZ w26, #0xb1c91c         | if (0x0 == 0) goto label_33;            
        if(val_21 == 0)
        {
            goto label_33;
        }
        // 0x00B1C918: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_33:
        // 0x00B1C91C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C920: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B1C924: BL #0x270e7d8              | X0 = val_4.get_time();                  
        float val_14 = val_19.time;
        // 0x00B1C928: FCMP s0, #0.0              | STATE = COMPARE(val_14, 0)              
        // 0x00B1C92C: B.LE #0xb1c764             | if (val_14 <= 0) goto label_34;         
        if(val_14 <= 0f)
        {
            goto label_34;
        }
        label_32:
        // 0x00B1C930: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_22 = 0;
        // 0x00B1C934: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        val_23 = 1;
        // 0x00B1C938: MOVZ w22, #0x111           | W22 = 273 (0x111);//ML01                
        val_24 = 273;
        // 0x00B1C93C: B #0xb1c968                |  goto label_48;                         
        goto label_48;
        // 0x00B1C940: MOV x21, x1                | X21 = 0 (0x0);//ML01                    
        // 0x00B1C944: MOV x20, x0                | X20 = val_4;//m1                        
        label_49:
        // 0x00B1C948: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00B1C94C: CMP w21, #1                | STATE = COMPARE(0x0, 0x1)               
        // 0x00B1C950: B.NE #0xb1ca64             | if (0 != 0x1) goto label_36;            
        if(0 != 1)
        {
            goto label_36;
        }
        // 0x00B1C954: BL #0x981060               | X0 = sub_981060( ?? val_4, ????);       
        // 0x00B1C958: LDR x20, [x0]              | X20 = typeof(System.Collections.IEnumerator);
        // 0x00B1C95C: BL #0x980920               | X0 = sub_980920( ?? val_4, ????);       
        // 0x00B1C960: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_24 = 0;
        // 0x00B1C964: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_23 = 0;
        label_48:
        // 0x00B1C968: ADRP x23, #0x35df000       | X23 = 56487936 (0x35DF000);             
        // 0x00B1C96C: LDR x23, [x23, #0x7a8]     | X23 = 1152921504608124928;              
        // 0x00B1C970: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B1C974: LDR x1, [x23]              | X1 = typeof(System.IDisposable);        
        // 0x00B1C978: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
        // 0x00B1C97C: MOV x19, x0                | X19 = val_4;//m1                        
        val_16 = val_4;
        // 0x00B1C980: CBZ x19, #0xb1c9e4         | if (val_4 == null) goto label_37;       
        if(val_16 == null)
        {
            goto label_37;
        }
        // 0x00B1C984: LDR x8, [x19]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1C988: LDR x1, [x23]              | X1 = typeof(System.IDisposable);        
        // 0x00B1C98C: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1C990: CBZ x9, #0xb1c9bc          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_38;
        // 0x00B1C994: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1C998: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_18 = 0;
        // 0x00B1C99C: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_40:
        // 0x00B1C9A0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1C9A4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B1C9A8: B.EQ #0xb1c9cc             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_39;
        // 0x00B1C9AC: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_18 = val_18 + 1;
        // 0x00B1C9B0: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1C9B4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1C9B8: B.LO #0xb1c9a0             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_40;
        label_38:
        // 0x00B1C9BC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1C9C0: MOV x0, x19                | X0 = val_4;//m1                         
        val_25 = val_16;
        // 0x00B1C9C4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_4, ????);      
        // 0x00B1C9C8: B #0xb1c9d8                |  goto label_41;                         
        goto label_41;
        label_39:
        // 0x00B1C9CC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1C9D0: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1C9D4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_41:
        // 0x00B1C9D8: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1C9DC: MOV x0, x19                | X0 = val_4;//m1                         
        // 0x00B1C9E0: BLR x8                     | X0 = sub_100000000011E000( ?? val_4, ????);
        label_37:
        // 0x00B1C9E4: CMP w22, #0x10f            | STATE = COMPARE(0x0, 0x10F)             
        // 0x00B1C9E8: B.EQ #0xb1ca18             | if (val_24 == 0x10F) goto label_46;     
        if(val_24 == 271)
        {
            goto label_46;
        }
        // 0x00B1C9EC: CMP w22, #0x111            | STATE = COMPARE(0x0, 0x111)             
        // 0x00B1C9F0: B.EQ #0xb1ca1c             | if (val_24 == 0x111) goto label_47;     
        if(val_24 == 273)
        {
            goto label_47;
        }
        // 0x00B1C9F4: CBZ x20, #0xb1ca18         | if (typeof(System.Collections.IEnumerator) == null) goto label_46;
        if(null == null)
        {
            goto label_46;
        }
        // 0x00B1C9F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1C9FC: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
        // 0x00B1CA00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.IEnumerator), ????);
        // 0x00B1CA04: B #0xb1ca18                |  goto label_46;                         
        goto label_46;
        label_7:
        // 0x00B1CA08: FCMP s0, #0.0              | STATE = COMPARE(val_3, 0)               
        // 0x00B1CA0C: B.EQ #0xb1ca18             | if (val_3 == 0) goto label_46;          
        if(val_3 == 0f)
        {
            goto label_46;
        }
        label_8:
        // 0x00B1CA10: ORR w21, wzr, #1           | W21 = 1(0x1);                           
        val_23 = 1;
        // 0x00B1CA14: B #0xb1ca1c                |  goto label_47;                         
        goto label_47;
        label_46:
        // 0x00B1CA18: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_23 = 0;
        label_47:
        // 0x00B1CA1C: MOV w0, w21                | W0 = 0 (0x0);//ML01                     
        // 0x00B1CA20: SUB sp, x29, #0x50         | SP = (1152921514150329408 - 80) = 1152921514150329328 (0x1000000238D5FBF0);
        // 0x00B1CA24: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1CA28: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1CA2C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1CA30: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1CA34: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1CA38: LDP d9, d8, [sp], #0x60    | D9 = ; D8 = ;                            //  | 
        // 0x00B1CA3C: RET                        |  return (System.Boolean)false;          
        return (bool)val_23;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_16:
        // 0x00B1CA40: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        // 0x00B1CA44: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        // 0x00B1CA48: MOVZ w22, #0x10f           | W22 = 271 (0x10F);//ML01                
        // 0x00B1CA4C: B #0xb1c968                |  goto label_48;                         
        goto label_48;
        // 0x00B1CA50: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00B1CA54: ADD x0, sp, #8             | X0 = (1152921514150329312 + 8) = 1152921514150329320 (0x1000000238D5FBE8);
        // 0x00B1CA58: MOV x21, x1                | X21 = 1152921504608018432 (0x100000000011E000);//ML01
        // 0x00B1CA5C: BL #0x299a140              | 
        // 0x00B1CA60: B #0xb1c948                |  goto label_49;                         
        goto label_49;
        label_36:
        // 0x00B1CA64: BL #0x980800               | X0 = sub_980800( ?? val_4, ????);       
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1CA68 (11651688), len: 964  VirtAddr: 0x00B1CA68 RVA: 0x00B1CA68 token: 100687837 methodIndex: 24672 delegateWrapperIndex: 0 methodInvoker: 0
    public void Finish()
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        UnityEngine.Animation val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        // 0x00B1CA68: STP d9, d8, [sp, #-0x50]!  | stack[1152921514150515072] = ???;  stack[1152921514150515080] = ???;  //  dest_result_addr=1152921514150515072 |  dest_result_addr=1152921514150515080
        // 0x00B1CA6C: STP x24, x23, [sp, #0x10]  | stack[1152921514150515088] = ???;  stack[1152921514150515096] = ???;  //  dest_result_addr=1152921514150515088 |  dest_result_addr=1152921514150515096
        // 0x00B1CA70: STP x22, x21, [sp, #0x20]  | stack[1152921514150515104] = ???;  stack[1152921514150515112] = ???;  //  dest_result_addr=1152921514150515104 |  dest_result_addr=1152921514150515112
        // 0x00B1CA74: STP x20, x19, [sp, #0x30]  | stack[1152921514150515120] = ???;  stack[1152921514150515128] = ???;  //  dest_result_addr=1152921514150515120 |  dest_result_addr=1152921514150515128
        // 0x00B1CA78: STP x29, x30, [sp, #0x40]  | stack[1152921514150515136] = ???;  stack[1152921514150515144] = ???;  //  dest_result_addr=1152921514150515136 |  dest_result_addr=1152921514150515144
        // 0x00B1CA7C: ADD x29, sp, #0x40         | X29 = (1152921514150515072 + 64) = 1152921514150515136 (0x1000000238D8D1C0);
        // 0x00B1CA80: SUB sp, sp, #0x10          | SP = (1152921514150515072 - 16) = 1152921514150515056 (0x1000000238D8D170);
        // 0x00B1CA84: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1CA88: LDRB w8, [x20, #0x709]     | W8 = (bool)static_value_03733709;       
        // 0x00B1CA8C: MOV x19, x0                | X19 = 1152921514150527152 (0x1000000238D900B0);//ML01
        val_11 = this;
        // 0x00B1CA90: TBNZ w8, #0, #0xb1caac     | if (static_value_03733709 == true) goto label_0;
        // 0x00B1CA94: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00B1CA98: LDR x8, [x8, #0x420]       | X8 = 0x2B8A994;                         
        // 0x00B1CA9C: LDR w0, [x8]               | W0 = 0x123;                             
        // 0x00B1CAA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x123, ????);      
        // 0x00B1CAA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1CAA8: STRB w8, [x20, #0x709]     | static_value_03733709 = true;            //  dest_result_addr=57882377
        label_0:
        // 0x00B1CAAC: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B1CAB0: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        val_12 = 1152921504697475072;
        // 0x00B1CAB4: LDR x20, [x19, #0x30]      | X20 = this.mAnim; //P2                  
        // 0x00B1CAB8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1CABC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1CAC0: TBZ w8, #0, #0xb1cad0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1CAC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1CAC8: CBNZ w8, #0xb1cad0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1CACC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B1CAD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CAD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1CAD8: MOV x1, x20                | X1 = this.mAnim;//m1                    
        // 0x00B1CADC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1CAE0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        // 0x00B1CAE4: TBZ w0, #0, #0xb1cd20      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B1CAE8: LDR x20, [x19, #0x30]      | X20 = this.mAnim; //P2                  
        // 0x00B1CAEC: CBNZ x20, #0xb1caf4        | if (this.mAnim != null) goto label_4;   
        if(this.mAnim != null)
        {
            goto label_4;
        }
        // 0x00B1CAF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B1CAF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CAF8: MOV x0, x20                | X0 = this.mAnim;//m1                    
        // 0x00B1CAFC: BL #0x270cb80              | X0 = this.mAnim.GetEnumerator();        
        System.Collections.IEnumerator val_2 = this.mAnim.GetEnumerator();
        // 0x00B1CB00: ADRP x22, #0x361c000       | X22 = 56737792 (0x361C000);             
        // 0x00B1CB04: ADRP x23, #0x366f000       | X23 = 57077760 (0x366F000);             
        // 0x00B1CB08: LDR x22, [x22, #0x358]     | X22 = 1152921504608018432;              
        // 0x00B1CB0C: LDR x23, [x23, #0x990]     | X23 = 1152921504723460096;              
        // 0x00B1CB10: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1CB14: FMOV s8, wzr               | S8 = 0f;                                
        label_24:
        // 0x00B1CB18: CBNZ x20, #0xb1cb20        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00B1CB1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B1CB20: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CB24: LDR x1, [x22]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1CB28: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1CB2C: CBZ x9, #0xb1cb58          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_6;
        // 0x00B1CB30: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1CB34: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_11 = 0;
        // 0x00B1CB38: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_8:
        // 0x00B1CB3C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1CB40: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1CB44: B.EQ #0xb1cb68             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_7;
        // 0x00B1CB48: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_11 = val_11 + 1;
        // 0x00B1CB4C: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1CB50: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1CB54: B.LO #0xb1cb3c             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_8;
        label_6:
        // 0x00B1CB58: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1CB5C: MOV x0, x20                | X0 = val_2;//m1                         
        val_13 = val_2;
        // 0x00B1CB60: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B1CB64: B #0xb1cb78                |  goto label_9;                          
        goto label_9;
        label_7:
        // 0x00B1CB68: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1CB6C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
        // 0x00B1CB70: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
        // 0x00B1CB74: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
        label_9:
        // 0x00B1CB78: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1CB7C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1CB80: BLR x8                     | X0 = sub_100000000011E000( ?? val_2, ????);
        // 0x00B1CB84: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        System.Collections.IEnumerator val_4 = val_2 & 1;
        // 0x00B1CB88: TBZ w8, #0, #0xb1ce08      | if (((val_2 & 1) & 0x1) == 0) goto label_10;
        if((val_4 & 1) == 0)
        {
            goto label_10;
        }
        // 0x00B1CB8C: CBNZ x20, #0xb1cb94        | if (val_2 != null) goto label_11;       
        if(val_2 != null)
        {
            goto label_11;
        }
        // 0x00B1CB90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_11:
        // 0x00B1CB94: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CB98: LDR x1, [x22]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1CB9C: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1CBA0: CBZ x9, #0xb1cbcc          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
        // 0x00B1CBA4: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1CBA8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x00B1CBAC: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_14:
        // 0x00B1CBB0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1CBB4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1CBB8: B.EQ #0xb1cbdc             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
        // 0x00B1CBBC: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00B1CBC0: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1CBC4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1CBC8: B.LO #0xb1cbb0             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_14;
        label_12:
        // 0x00B1CBCC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1CBD0: MOV x0, x20                | X0 = val_2;//m1                         
        val_14 = val_2;
        // 0x00B1CBD4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B1CBD8: B #0xb1cbe8                |  goto label_15;                         
        goto label_15;
        label_13:
        // 0x00B1CBDC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1CBE0: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1CBE4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_15:
        // 0x00B1CBE8: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1CBEC: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1CBF0: BLR x8                     | X0 = sub_100000000011E000( ?? val_2, ????);
        // 0x00B1CBF4: MOV x21, x0                | X21 = val_2;//m1                        
        val_15 = val_2;
        // 0x00B1CBF8: CBZ x21, #0xb1cc30         | if (val_2 == null) goto label_16;       
        if(val_15 == null)
        {
            goto label_16;
        }
        // 0x00B1CBFC: LDR x1, [x23]              | X1 = typeof(UnityEngine.AnimationState);
        // 0x00B1CC00: LDR x8, [x21]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CC04: CMP x8, x1                 | STATE = COMPARE(typeof(System.Collections.IEnumerator), typeof(UnityEngine.AnimationState))
        // 0x00B1CC08: B.EQ #0xb1cc34             | if (typeof(System.Collections.IEnumerator) == null) goto label_17;
        if(null == null)
        {
            goto label_17;
        }
        // 0x00B1CC0C: LDR x0, [x8, #0x30]        | X0 = System.Collections.IEnumerator.__il2cppRuntimeField_element_class;
        // 0x00B1CC10: ADD x8, sp, #8             | X8 = (1152921514150515056 + 8) = 1152921514150515064 (0x1000000238D8D178);
        // 0x00B1CC14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IEnumerator.__il2cppRuntimeField_element_class, ????);
        // 0x00B1CC18: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921514150503152]
        // 0x00B1CC1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
        // 0x00B1CC20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CC24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        // 0x00B1CC28: ADD x0, sp, #8             | X0 = (1152921514150515056 + 8) = 1152921514150515064 (0x1000000238D8D178);
        // 0x00B1CC2C: BL #0x299a140              | 
        label_16:
        // 0x00B1CC30: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_15 = 0;
        label_17:
        // 0x00B1CC34: LDR w8, [x19, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1CC38: CMN w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1CC3C: B.EQ #0xb1cc7c             | if (this.mLastDirection == 0x1) goto label_18;
        if(this.mLastDirection == 1)
        {
            goto label_18;
        }
        // 0x00B1CC40: CMP w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1CC44: B.NE #0xb1cb18             | if (this.mLastDirection != 0x1) goto label_24;
        if(this.mLastDirection != 1)
        {
            goto label_24;
        }
        // 0x00B1CC48: CBNZ x21, #0xb1cc50        | if (0x0 != 0) goto label_20;            
        if(val_15 != 0)
        {
            goto label_20;
        }
        // 0x00B1CC4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000238D8D178, ????);
        label_20:
        // 0x00B1CC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CC54: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CC58: BL #0x270eb58              | X0 = val_15.get_length();               
        float val_7 = val_15.length;
        // 0x00B1CC5C: MOV v9.16b, v0.16b         | V9 = val_7;//m1                         
        // 0x00B1CC60: CBNZ x21, #0xb1cc68        | if (0x0 != 0) goto label_21;            
        if(val_15 != 0)
        {
            goto label_21;
        }
        // 0x00B1CC64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_21:
        // 0x00B1CC68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CC6C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CC70: MOV v0.16b, v9.16b         | V0 = val_7;//m1                         
        // 0x00B1CC74: BL #0x270e840              | val_15.set_time(value:  val_7);         
        val_15.time = val_7;
        // 0x00B1CC78: B #0xb1cb18                |  goto label_24;                         
        goto label_24;
        label_18:
        // 0x00B1CC7C: CBNZ x21, #0xb1cc84        | if (0x0 != 0) goto label_23;            
        if(val_15 != 0)
        {
            goto label_23;
        }
        // 0x00B1CC80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000238D8D178, ????);
        label_23:
        // 0x00B1CC84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CC88: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CC8C: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B1CC90: BL #0x270e840              | val_15.set_time(value:  0f);            
        val_15.time = 0f;
        // 0x00B1CC94: B #0xb1cb18                |  goto label_24;                         
        goto label_24;
        // 0x00B1CC98: MOV x22, x1                | X22 = 0 (0x0);//ML01                    
        // 0x00B1CC9C: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
        label_39:
        // 0x00B1CCA0: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CCA4: CMP w22, #1                | STATE = COMPARE(0x0, 0x1)               
        // 0x00B1CCA8: B.NE #0xb1ce28             | if (0 != 0x1) goto label_25;            
        if(0 != 1)
        {
            goto label_25;
        }
        // 0x00B1CCAC: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
        // 0x00B1CCB0: LDR x21, [x0]              | X21 = 0x10102464C457F;                  
        val_12 = 1179403647;
        // 0x00B1CCB4: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
        // 0x00B1CCB8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        label_38:
        // 0x00B1CCBC: ADRP x23, #0x35df000       | X23 = 56487936 (0x35DF000);             
        // 0x00B1CCC0: LDR x23, [x23, #0x7a8]     | X23 = 1152921504608124928;              
        // 0x00B1CCC4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1CCC8: LDR x1, [x23]              | X1 = typeof(System.IDisposable);        
        // 0x00B1CCCC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B1CCD0: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1CCD4: CBZ x20, #0xb1cdbc         | if (val_2 == null) goto label_26;       
        if(val_2 == null)
        {
            goto label_26;
        }
        // 0x00B1CCD8: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CCDC: LDR x1, [x23]              | X1 = typeof(System.IDisposable);        
        // 0x00B1CCE0: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1CCE4: CBZ x9, #0xb1cd10          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_27;
        // 0x00B1CCE8: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1CCEC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x00B1CCF0: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_29:
        // 0x00B1CCF4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1CCF8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B1CCFC: B.EQ #0xb1cda4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_28;
        // 0x00B1CD00: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x00B1CD04: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1CD08: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1CD0C: B.LO #0xb1ccf4             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_29;
        label_27:
        // 0x00B1CD10: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1CD14: MOV x0, x20                | X0 = val_2;//m1                         
        val_16 = val_2;
        // 0x00B1CD18: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B1CD1C: B #0xb1cdb0                |  goto label_30;                         
        goto label_30;
        label_3:
        // 0x00B1CD20: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1CD24: LDR x20, [x19, #0x48]      | X20 = this.mAnimator; //P2              
        // 0x00B1CD28: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1CD2C: TBZ w8, #0, #0xb1cd3c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x00B1CD30: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1CD34: CBNZ w8, #0xb1cd3c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x00B1CD38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_32:
        // 0x00B1CD3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CD40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1CD44: MOV x1, x20                | X1 = this.mAnimator;//m1                
        // 0x00B1CD48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1CD4C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        bool val_8 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        // 0x00B1CD50: TBZ w0, #0, #0xb1cdec      | if (val_8 == false) goto label_33;      
        if(val_8 == false)
        {
            goto label_33;
        }
        // 0x00B1CD54: LDP x20, x21, [x19, #0x48] | X20 = this.mAnimator; //P2  X21 = this.mClip; //P2  //  | 
        // 0x00B1CD58: LDR w8, [x19, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1CD5C: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B1CD60: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B1CD64: CMP w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1CD68: FCSEL s8, s1, s0, eq       | S8 = this.mLastDirection == 0x1 ? 1f : 0f;
        float val_9 = (this.mLastDirection == 1) ? (1f) : (0f);
        // 0x00B1CD6C: CBNZ x20, #0xb1cd74        | if (this.mAnimator != null) goto label_34;
        if(this.mAnimator != null)
        {
            goto label_34;
        }
        // 0x00B1CD70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_34:
        // 0x00B1CD74: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1CD78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1CD7C: MOV x0, x20                | X0 = this.mAnimator;//m1                
        // 0x00B1CD80: MOV x1, x21                | X1 = this.mClip;//m1                    
        // 0x00B1CD84: MOV v0.16b, v8.16b         | V0 = this.mLastDirection == 0x1 ? 1f : 0f;//m1
        // 0x00B1CD88: SUB sp, x29, #0x40         | SP = (1152921514150515136 - 64) = 1152921514150515072 (0x1000000238D8D180);
        // 0x00B1CD8C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1CD90: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1CD94: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1CD98: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1CD9C: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B1CDA0: B #0x2712f14               | this.mAnimator.Play(stateName:  this.mClip, layer:  0, normalizedTime:  val_9); return;
        this.mAnimator.Play(stateName:  this.mClip, layer:  0, normalizedTime:  val_9);
        return;
        label_28:
        // 0x00B1CDA4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1CDA8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1CDAC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_30:
        // 0x00B1CDB0: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1CDB4: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1CDB8: BLR x8                     | X0 = sub_100000000011E000( ?? val_2, ????);
        label_26:
        // 0x00B1CDBC: CMP w22, #0x86             | STATE = COMPARE(0x0, 0x86)              
        // 0x00B1CDC0: B.EQ #0xb1cdd4             | if (0 == 0x86) goto label_36;           
        if(0 == 134)
        {
            goto label_36;
        }
        // 0x00B1CDC4: CBZ x21, #0xb1cdd4         | if (0x10102464C457F == 0) goto label_36;
        if(val_12 == 0)
        {
            goto label_36;
        }
        // 0x00B1CDC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CDCC: MOV x0, x21                | X0 = 282584257676671 (0x10102464C457F);//ML01
        // 0x00B1CDD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
        label_36:
        // 0x00B1CDD4: LDR x19, [x19, #0x30]      | X19 = this.mAnim; //P2                  
        val_11 = this.mAnim;
        // 0x00B1CDD8: CBNZ x19, #0xb1cde0        | if (this.mAnim != null) goto label_37;  
        if(val_11 != null)
        {
            goto label_37;
        }
        // 0x00B1CDDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10102464C457F, ????);
        label_37:
        // 0x00B1CDE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CDE4: MOV x0, x19                | X0 = this.mAnim;//m1                    
        // 0x00B1CDE8: BL #0x270c344              | this.mAnim.Sample();                    
        val_11.Sample();
        label_33:
        // 0x00B1CDEC: SUB sp, x29, #0x40         | SP = (1152921514150515136 - 64) = 1152921514150515072 (0x1000000238D8D180);
        // 0x00B1CDF0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1CDF4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1CDF8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1CDFC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1CE00: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B1CE04: RET                        |  return;                                
        return;
        label_10:
        // 0x00B1CE08: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00B1CE0C: MOVZ w22, #0x86            | W22 = 134 (0x86);//ML01                 
        // 0x00B1CE10: B #0xb1ccbc                |  goto label_38;                         
        goto label_38;
        // 0x00B1CE14: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00B1CE18: ADD x0, sp, #8             | X0 = (1152921514150515056 + 8) = 1152921514150515064 (0x1000000238D8D178);
        // 0x00B1CE1C: MOV x22, x1                | X22 = 1152921504608018432 (0x100000000011E000);//ML01
        // 0x00B1CE20: BL #0x299a140              | 
        // 0x00B1CE24: B #0xb1cca0                |  goto label_39;                         
        goto label_39;
        label_25:
        // 0x00B1CE28: BL #0x980800               | X0 = sub_980800( ?? 0x0, ????);         
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1CE2C (11652652), len: 940  VirtAddr: 0x00B1CE2C RVA: 0x00B1CE2C token: 100687838 methodIndex: 24673 delegateWrapperIndex: 0 methodInvoker: 0
    public void Reset()
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        // 0x00B1CE2C: STP d9, d8, [sp, #-0x50]!  | stack[1152921514150696704] = ???;  stack[1152921514150696712] = ???;  //  dest_result_addr=1152921514150696704 |  dest_result_addr=1152921514150696712
        // 0x00B1CE30: STP x24, x23, [sp, #0x10]  | stack[1152921514150696720] = ???;  stack[1152921514150696728] = ???;  //  dest_result_addr=1152921514150696720 |  dest_result_addr=1152921514150696728
        // 0x00B1CE34: STP x22, x21, [sp, #0x20]  | stack[1152921514150696736] = ???;  stack[1152921514150696744] = ???;  //  dest_result_addr=1152921514150696736 |  dest_result_addr=1152921514150696744
        // 0x00B1CE38: STP x20, x19, [sp, #0x30]  | stack[1152921514150696752] = ???;  stack[1152921514150696760] = ???;  //  dest_result_addr=1152921514150696752 |  dest_result_addr=1152921514150696760
        // 0x00B1CE3C: STP x29, x30, [sp, #0x40]  | stack[1152921514150696768] = ???;  stack[1152921514150696776] = ???;  //  dest_result_addr=1152921514150696768 |  dest_result_addr=1152921514150696776
        // 0x00B1CE40: ADD x29, sp, #0x40         | X29 = (1152921514150696704 + 64) = 1152921514150696768 (0x1000000238DB9740);
        // 0x00B1CE44: SUB sp, sp, #0x10          | SP = (1152921514150696704 - 16) = 1152921514150696688 (0x1000000238DB96F0);
        // 0x00B1CE48: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1CE4C: LDRB w8, [x20, #0x70a]     | W8 = (bool)static_value_0373370A;       
        // 0x00B1CE50: MOV x19, x0                | X19 = 1152921514150708784 (0x1000000238DBC630);//ML01
        val_11 = this;
        // 0x00B1CE54: TBNZ w8, #0, #0xb1ce70     | if (static_value_0373370A == true) goto label_0;
        // 0x00B1CE58: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00B1CE5C: LDR x8, [x8, #0x960]       | X8 = 0x2B8A9B0;                         
        // 0x00B1CE60: LDR w0, [x8]               | W0 = 0x12A;                             
        // 0x00B1CE64: BL #0x2782188              | X0 = sub_2782188( ?? 0x12A, ????);      
        // 0x00B1CE68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1CE6C: STRB w8, [x20, #0x70a]     | static_value_0373370A = true;            //  dest_result_addr=57882378
        label_0:
        // 0x00B1CE70: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B1CE74: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        val_12 = 1152921504697475072;
        // 0x00B1CE78: LDR x20, [x19, #0x30]      | X20 = this.mAnim; //P2                  
        // 0x00B1CE7C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1CE80: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1CE84: TBZ w8, #0, #0xb1ce94      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1CE88: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1CE8C: CBNZ w8, #0xb1ce94         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1CE90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B1CE94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1CE98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1CE9C: MOV x1, x20                | X1 = this.mAnim;//m1                    
        // 0x00B1CEA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1CEA4: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        // 0x00B1CEA8: TBZ w0, #0, #0xb1d0e4      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B1CEAC: LDR x20, [x19, #0x30]      | X20 = this.mAnim; //P2                  
        // 0x00B1CEB0: CBNZ x20, #0xb1ceb8        | if (this.mAnim != null) goto label_4;   
        if(this.mAnim != null)
        {
            goto label_4;
        }
        // 0x00B1CEB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B1CEB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CEBC: MOV x0, x20                | X0 = this.mAnim;//m1                    
        // 0x00B1CEC0: BL #0x270cb80              | X0 = this.mAnim.GetEnumerator();        
        System.Collections.IEnumerator val_2 = this.mAnim.GetEnumerator();
        // 0x00B1CEC4: ADRP x22, #0x361c000       | X22 = 56737792 (0x361C000);             
        // 0x00B1CEC8: ADRP x23, #0x366f000       | X23 = 57077760 (0x366F000);             
        // 0x00B1CECC: LDR x22, [x22, #0x358]     | X22 = 1152921504608018432;              
        // 0x00B1CED0: LDR x23, [x23, #0x990]     | X23 = 1152921504723460096;              
        // 0x00B1CED4: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1CED8: FMOV s8, wzr               | S8 = 0f;                                
        label_24:
        // 0x00B1CEDC: CBNZ x20, #0xb1cee4        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00B1CEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B1CEE4: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CEE8: LDR x1, [x22]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1CEEC: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1CEF0: CBZ x9, #0xb1cf1c          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_6;
        // 0x00B1CEF4: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1CEF8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_11 = 0;
        // 0x00B1CEFC: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_8:
        // 0x00B1CF00: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1CF04: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1CF08: B.EQ #0xb1cf2c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_7;
        // 0x00B1CF0C: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_11 = val_11 + 1;
        // 0x00B1CF10: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1CF14: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1CF18: B.LO #0xb1cf00             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_8;
        label_6:
        // 0x00B1CF1C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1CF20: MOV x0, x20                | X0 = val_2;//m1                         
        val_13 = val_2;
        // 0x00B1CF24: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B1CF28: B #0xb1cf3c                |  goto label_9;                          
        goto label_9;
        label_7:
        // 0x00B1CF2C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1CF30: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
        // 0x00B1CF34: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
        // 0x00B1CF38: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
        label_9:
        // 0x00B1CF3C: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1CF40: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1CF44: BLR x8                     | X0 = sub_100000000011E000( ?? val_2, ????);
        // 0x00B1CF48: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        System.Collections.IEnumerator val_4 = val_2 & 1;
        // 0x00B1CF4C: TBZ w8, #0, #0xb1d1b4      | if (((val_2 & 1) & 0x1) == 0) goto label_10;
        if((val_4 & 1) == 0)
        {
            goto label_10;
        }
        // 0x00B1CF50: CBNZ x20, #0xb1cf58        | if (val_2 != null) goto label_11;       
        if(val_2 != null)
        {
            goto label_11;
        }
        // 0x00B1CF54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_11:
        // 0x00B1CF58: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CF5C: LDR x1, [x22]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1CF60: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1CF64: CBZ x9, #0xb1cf90          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
        // 0x00B1CF68: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1CF6C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x00B1CF70: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_14:
        // 0x00B1CF74: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1CF78: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1CF7C: B.EQ #0xb1cfa0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
        // 0x00B1CF80: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x00B1CF84: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1CF88: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1CF8C: B.LO #0xb1cf74             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_14;
        label_12:
        // 0x00B1CF90: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1CF94: MOV x0, x20                | X0 = val_2;//m1                         
        val_14 = val_2;
        // 0x00B1CF98: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B1CF9C: B #0xb1cfac                |  goto label_15;                         
        goto label_15;
        label_13:
        // 0x00B1CFA0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1CFA4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1CFA8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_15:
        // 0x00B1CFAC: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1CFB0: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1CFB4: BLR x8                     | X0 = sub_100000000011E000( ?? val_2, ????);
        // 0x00B1CFB8: MOV x21, x0                | X21 = val_2;//m1                        
        val_15 = val_2;
        // 0x00B1CFBC: CBZ x21, #0xb1cff4         | if (val_2 == null) goto label_16;       
        if(val_15 == null)
        {
            goto label_16;
        }
        // 0x00B1CFC0: LDR x1, [x23]              | X1 = typeof(UnityEngine.AnimationState);
        // 0x00B1CFC4: LDR x8, [x21]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1CFC8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Collections.IEnumerator), typeof(UnityEngine.AnimationState))
        // 0x00B1CFCC: B.EQ #0xb1cff8             | if (typeof(System.Collections.IEnumerator) == null) goto label_17;
        if(null == null)
        {
            goto label_17;
        }
        // 0x00B1CFD0: LDR x0, [x8, #0x30]        | X0 = System.Collections.IEnumerator.__il2cppRuntimeField_element_class;
        // 0x00B1CFD4: ADD x8, sp, #8             | X8 = (1152921514150696688 + 8) = 1152921514150696696 (0x1000000238DB96F8);
        // 0x00B1CFD8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IEnumerator.__il2cppRuntimeField_element_class, ????);
        // 0x00B1CFDC: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921514150684784]
        // 0x00B1CFE0: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
        // 0x00B1CFE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1CFE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        // 0x00B1CFEC: ADD x0, sp, #8             | X0 = (1152921514150696688 + 8) = 1152921514150696696 (0x1000000238DB96F8);
        // 0x00B1CFF0: BL #0x299a140              | 
        label_16:
        // 0x00B1CFF4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_15 = 0;
        label_17:
        // 0x00B1CFF8: LDR w8, [x19, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1CFFC: CMN w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1D000: B.EQ #0xb1d028             | if (this.mLastDirection == 0x1) goto label_18;
        if(this.mLastDirection == 1)
        {
            goto label_18;
        }
        // 0x00B1D004: CMP w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1D008: B.NE #0xb1cedc             | if (this.mLastDirection != 0x1) goto label_24;
        if(this.mLastDirection != 1)
        {
            goto label_24;
        }
        // 0x00B1D00C: CBNZ x21, #0xb1d014        | if (0x0 != 0) goto label_20;            
        if(val_15 != 0)
        {
            goto label_20;
        }
        // 0x00B1D010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000238DB96F8, ????);
        label_20:
        // 0x00B1D014: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D018: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D01C: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B1D020: BL #0x270e840              | val_15.set_time(value:  0f);            
        val_15.time = 0f;
        // 0x00B1D024: B #0xb1cedc                |  goto label_24;                         
        goto label_24;
        label_18:
        // 0x00B1D028: CBNZ x21, #0xb1d030        | if (0x0 != 0) goto label_22;            
        if(val_15 != 0)
        {
            goto label_22;
        }
        // 0x00B1D02C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000238DB96F8, ????);
        label_22:
        // 0x00B1D030: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D034: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D038: BL #0x270eb58              | X0 = val_15.get_length();               
        float val_7 = val_15.length;
        // 0x00B1D03C: MOV v9.16b, v0.16b         | V9 = val_7;//m1                         
        // 0x00B1D040: CBNZ x21, #0xb1d048        | if (0x0 != 0) goto label_23;            
        if(val_15 != 0)
        {
            goto label_23;
        }
        // 0x00B1D044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_23:
        // 0x00B1D048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D04C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D050: MOV v0.16b, v9.16b         | V0 = val_7;//m1                         
        // 0x00B1D054: BL #0x270e840              | val_15.set_time(value:  val_7);         
        val_15.time = val_7;
        // 0x00B1D058: B #0xb1cedc                |  goto label_24;                         
        goto label_24;
        // 0x00B1D05C: MOV x21, x1                | X21 = 0 (0x0);//ML01                    
        // 0x00B1D060: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
        label_38:
        // 0x00B1D064: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D068: CMP w21, #1                | STATE = COMPARE(0x0, 0x1)               
        // 0x00B1D06C: B.NE #0xb1d1d4             | if (0 != 0x1) goto label_25;            
        if(0 != 1)
        {
            goto label_25;
        }
        // 0x00B1D070: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
        // 0x00B1D074: LDR x19, [x0]              | X19 = 0x10102464C457F;                  
        val_11 = 1179403647;
        // 0x00B1D078: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
        // 0x00B1D07C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_12 = 0;
        label_37:
        // 0x00B1D080: ADRP x22, #0x35df000       | X22 = 56487936 (0x35DF000);             
        // 0x00B1D084: LDR x22, [x22, #0x7a8]     | X22 = 1152921504608124928;              
        // 0x00B1D088: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1D08C: LDR x1, [x22]              | X1 = typeof(System.IDisposable);        
        // 0x00B1D090: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
        // 0x00B1D094: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B1D098: CBZ x20, #0xb1d180         | if (val_2 == null) goto label_26;       
        if(val_2 == null)
        {
            goto label_26;
        }
        // 0x00B1D09C: LDR x8, [x20]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1D0A0: LDR x1, [x22]              | X1 = typeof(System.IDisposable);        
        // 0x00B1D0A4: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1D0A8: CBZ x9, #0xb1d0d4          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_27;
        // 0x00B1D0AC: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1D0B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x00B1D0B4: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_29:
        // 0x00B1D0B8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1D0BC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B1D0C0: B.EQ #0xb1d168             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_28;
        // 0x00B1D0C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x00B1D0C8: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1D0CC: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1D0D0: B.LO #0xb1d0b8             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_29;
        label_27:
        // 0x00B1D0D4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1D0D8: MOV x0, x20                | X0 = val_2;//m1                         
        val_16 = val_2;
        // 0x00B1D0DC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
        // 0x00B1D0E0: B #0xb1d174                |  goto label_30;                         
        goto label_30;
        label_3:
        // 0x00B1D0E4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1D0E8: LDR x20, [x19, #0x48]      | X20 = this.mAnimator; //P2              
        // 0x00B1D0EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1D0F0: TBZ w8, #0, #0xb1d100      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x00B1D0F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D0F8: CBNZ w8, #0xb1d100         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x00B1D0FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_32:
        // 0x00B1D100: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D104: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D108: MOV x1, x20                | X1 = this.mAnimator;//m1                
        // 0x00B1D10C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D110: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        bool val_8 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        // 0x00B1D114: TBZ w0, #0, #0xb1d198      | if (val_8 == false) goto label_36;      
        if(val_8 == false)
        {
            goto label_36;
        }
        // 0x00B1D118: LDP x20, x21, [x19, #0x48] | X20 = this.mAnimator; //P2  X21 = this.mClip; //P2  //  | 
        // 0x00B1D11C: LDR w8, [x19, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1D120: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B1D124: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x00B1D128: CMN w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1D12C: FCSEL s8, s1, s0, eq       | S8 = this.mLastDirection == 0x1 ? 1f : 0f;
        float val_9 = (this.mLastDirection == 1) ? (1f) : (0f);
        // 0x00B1D130: CBNZ x20, #0xb1d138        | if (this.mAnimator != null) goto label_34;
        if(this.mAnimator != null)
        {
            goto label_34;
        }
        // 0x00B1D134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_34:
        // 0x00B1D138: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1D13C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D140: MOV x0, x20                | X0 = this.mAnimator;//m1                
        // 0x00B1D144: MOV x1, x21                | X1 = this.mClip;//m1                    
        // 0x00B1D148: MOV v0.16b, v8.16b         | V0 = this.mLastDirection == 0x1 ? 1f : 0f;//m1
        // 0x00B1D14C: SUB sp, x29, #0x40         | SP = (1152921514150696768 - 64) = 1152921514150696704 (0x1000000238DB9700);
        // 0x00B1D150: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1D154: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1D158: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1D15C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1D160: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B1D164: B #0x2712f14               | this.mAnimator.Play(stateName:  this.mClip, layer:  0, normalizedTime:  val_9); return;
        this.mAnimator.Play(stateName:  this.mClip, layer:  0, normalizedTime:  val_9);
        return;
        label_28:
        // 0x00B1D168: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1D16C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1D170: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_30:
        // 0x00B1D174: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1D178: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B1D17C: BLR x8                     | X0 = sub_100000000011E000( ?? val_2, ????);
        label_26:
        // 0x00B1D180: CMP w21, #0x86             | STATE = COMPARE(0x0, 0x86)              
        // 0x00B1D184: B.EQ #0xb1d198             | if (val_12 == 0x86) goto label_36;      
        if(val_12 == 134)
        {
            goto label_36;
        }
        // 0x00B1D188: CBZ x19, #0xb1d198         | if (0x10102464C457F == 0) goto label_36;
        if(val_11 == 0)
        {
            goto label_36;
        }
        // 0x00B1D18C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D190: MOV x0, x19                | X0 = 282584257676671 (0x10102464C457F);//ML01
        // 0x00B1D194: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
        label_36:
        // 0x00B1D198: SUB sp, x29, #0x40         | SP = (1152921514150696768 - 64) = 1152921514150696704 (0x1000000238DB9700);
        // 0x00B1D19C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1D1A0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1D1A4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1D1A8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1D1AC: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B1D1B0: RET                        |  return;                                
        return;
        label_10:
        // 0x00B1D1B4: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        // 0x00B1D1B8: MOVZ w21, #0x86            | W21 = 134 (0x86);//ML01                 
        // 0x00B1D1BC: B #0xb1d080                |  goto label_37;                         
        goto label_37;
        // 0x00B1D1C0: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B1D1C4: ADD x0, sp, #8             | X0 = (1152921514150696688 + 8) = 1152921514150696696 (0x1000000238DB96F8);
        // 0x00B1D1C8: MOV x21, x1                | X21 = 1152921504608018432 (0x100000000011E000);//ML01
        // 0x00B1D1CC: BL #0x299a140              | 
        // 0x00B1D1D0: B #0xb1d064                |  goto label_38;                         
        goto label_38;
        label_25:
        // 0x00B1D1D4: BL #0x980800               | X0 = sub_980800( ?? 0x0, ????);         
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1D1D8 (11653592), len: 160  VirtAddr: 0x00B1D1D8 RVA: 0x00B1D1D8 token: 100687839 methodIndex: 24674 delegateWrapperIndex: 0 methodInvoker: 0
    private void Start()
    {
        //
        // Disasemble & Code
        // 0x00B1D1D8: STP x22, x21, [sp, #-0x30]! | stack[1152921514150849696] = ???;  stack[1152921514150849704] = ???;  //  dest_result_addr=1152921514150849696 |  dest_result_addr=1152921514150849704
        // 0x00B1D1DC: STP x20, x19, [sp, #0x10]  | stack[1152921514150849712] = ???;  stack[1152921514150849720] = ???;  //  dest_result_addr=1152921514150849712 |  dest_result_addr=1152921514150849720
        // 0x00B1D1E0: STP x29, x30, [sp, #0x20]  | stack[1152921514150849728] = ???;  stack[1152921514150849736] = ???;  //  dest_result_addr=1152921514150849728 |  dest_result_addr=1152921514150849736
        // 0x00B1D1E4: ADD x29, sp, #0x20         | X29 = (1152921514150849696 + 32) = 1152921514150849728 (0x1000000238DDECC0);
        // 0x00B1D1E8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1D1EC: LDRB w8, [x20, #0x70b]     | W8 = (bool)static_value_0373370B;       
        // 0x00B1D1F0: MOV x19, x0                | X19 = 1152921514150861744 (0x1000000238DE1BB0);//ML01
        // 0x00B1D1F4: TBNZ w8, #0, #0xb1d210     | if (static_value_0373370B == true) goto label_0;
        // 0x00B1D1F8: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00B1D1FC: LDR x8, [x8, #0xae8]       | X8 = 0x2B8A9B4;                         
        // 0x00B1D200: LDR w0, [x8]               | W0 = 0x12B;                             
        // 0x00B1D204: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B, ????);      
        // 0x00B1D208: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1D20C: STRB w8, [x20, #0x70b]     | static_value_0373370B = true;            //  dest_result_addr=57882379
        label_0:
        // 0x00B1D210: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B1D214: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B1D218: MOV x21, x19               | X21 = 1152921514150861744 (0x1000000238DE1BB0);//ML01
        // 0x00B1D21C: LDR x20, [x21, #0x20]!     | X20 = this.eventReceiver; //P2          
        // 0x00B1D220: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B1D224: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1D228: TBZ w8, #0, #0xb1d238      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B1D22C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D230: CBNZ w8, #0xb1d238         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B1D234: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B1D238: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D23C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D240: MOV x1, x20                | X1 = this.eventReceiver;//m1            
        // 0x00B1D244: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D248: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.eventReceiver);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.eventReceiver);
        // 0x00B1D24C: TBZ w0, #0, #0xb1d268      | if (val_1 == false) goto label_4;       
        if(val_1 == false)
        {
            goto label_4;
        }
        // 0x00B1D250: LDR x1, [x19, #0x18]       | X1 = this.onFinished; //P2              
        // 0x00B1D254: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D258: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D25C: BL #0xebfdd8               | X0 = EventDelegate.IsValid(list:  0);   
        bool val_2 = EventDelegate.IsValid(list:  0);
        // 0x00B1D260: TBZ w0, #0, #0xb1d268      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B1D264: STP xzr, xzr, [x21]        | this.eventReceiver = null;  mem[1152921514150861784] = 0x0;  //  dest_result_addr=1152921514150861776 |  dest_result_addr=1152921514150861784
        this.eventReceiver = 0;
        mem[1152921514150861784] = 0;
        label_4:
        // 0x00B1D268: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1D26C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1D270: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B1D274: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1D278 (11653752), len: 1684  VirtAddr: 0x00B1D278 RVA: 0x00B1D278 token: 100687840 methodIndex: 24675 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        bool val_27;
        //  | 
        float val_28;
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_32;
        //  | 
        var val_33;
        //  | 
        float val_34;
        //  | 
        var val_35;
        //  | 
        string val_36;
        //  | 
        var val_37;
        //  | 
        var val_38;
        // 0x00B1D278: STP d11, d10, [sp, #-0x80]! | stack[1152921514151006672] = ???;  stack[1152921514151006680] = ???;  //  dest_result_addr=1152921514151006672 |  dest_result_addr=1152921514151006680
        // 0x00B1D27C: STP d9, d8, [sp, #0x10]    | stack[1152921514151006688] = ???;  stack[1152921514151006696] = ???;  //  dest_result_addr=1152921514151006688 |  dest_result_addr=1152921514151006696
        // 0x00B1D280: STP x28, x27, [sp, #0x20]  | stack[1152921514151006704] = ???;  stack[1152921514151006712] = ???;  //  dest_result_addr=1152921514151006704 |  dest_result_addr=1152921514151006712
        // 0x00B1D284: STP x26, x25, [sp, #0x30]  | stack[1152921514151006720] = ???;  stack[1152921514151006728] = ???;  //  dest_result_addr=1152921514151006720 |  dest_result_addr=1152921514151006728
        // 0x00B1D288: STP x24, x23, [sp, #0x40]  | stack[1152921514151006736] = ???;  stack[1152921514151006744] = ???;  //  dest_result_addr=1152921514151006736 |  dest_result_addr=1152921514151006744
        // 0x00B1D28C: STP x22, x21, [sp, #0x50]  | stack[1152921514151006752] = ???;  stack[1152921514151006760] = ???;  //  dest_result_addr=1152921514151006752 |  dest_result_addr=1152921514151006760
        // 0x00B1D290: STP x20, x19, [sp, #0x60]  | stack[1152921514151006768] = ???;  stack[1152921514151006776] = ???;  //  dest_result_addr=1152921514151006768 |  dest_result_addr=1152921514151006776
        // 0x00B1D294: STP x29, x30, [sp, #0x70]  | stack[1152921514151006784] = ???;  stack[1152921514151006792] = ???;  //  dest_result_addr=1152921514151006784 |  dest_result_addr=1152921514151006792
        // 0x00B1D298: ADD x29, sp, #0x70         | X29 = (1152921514151006672 + 112) = 1152921514151006784 (0x1000000238E05240);
        // 0x00B1D29C: SUB sp, sp, #0x10          | SP = (1152921514151006672 - 16) = 1152921514151006656 (0x1000000238E051C0);
        // 0x00B1D2A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1D2A4: LDRB w8, [x20, #0x70c]     | W8 = (bool)static_value_0373370C;       
        // 0x00B1D2A8: MOV x19, x0                | X19 = 1152921514151018800 (0x1000000238E08130);//ML01
        val_27 = this;
        // 0x00B1D2AC: TBNZ w8, #0, #0xb1d2c8     | if (static_value_0373370C == true) goto label_0;
        // 0x00B1D2B0: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B1D2B4: LDR x8, [x8, #0x928]       | X8 = 0x2B8A9B8;                         
        // 0x00B1D2B8: LDR w0, [x8]               | W0 = 0x12C;                             
        // 0x00B1D2BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C, ????);      
        // 0x00B1D2C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1D2C4: STRB w8, [x20, #0x70c]     | static_value_0373370C = true;            //  dest_result_addr=57882380
        label_0:
        // 0x00B1D2C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D2CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D2D0: BL #0xc93d5c               | X0 = RealTime.get_deltaTime();          
        float val_1 = RealTime.deltaTime;
        // 0x00B1D2D4: MOV v8.16b, v0.16b         | V8 = val_1;//m1                         
        val_28 = val_1;
        // 0x00B1D2D8: FCMP s8, #0.0              | STATE = COMPARE(val_1, 0)               
        // 0x00B1D2DC: B.EQ #0xb1d8cc             | if (val_28 == 0) goto label_67;         
        if(val_28 == 0f)
        {
            goto label_67;
        }
        // 0x00B1D2E0: ADRP x24, #0x35fe000       | X24 = 56614912 (0x35FE000);             
        // 0x00B1D2E4: LDR x24, [x24, #0x810]     | X24 = 1152921504697475072;              
        // 0x00B1D2E8: LDR x20, [x19, #0x48]      | X20 = this.mAnimator; //P2              
        // 0x00B1D2EC: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1D2F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1D2F4: TBZ w8, #0, #0xb1d304      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B1D2F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D2FC: CBNZ w8, #0xb1d304         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1D300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B1D304: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D308: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D30C: MOV x1, x20                | X1 = this.mAnimator;//m1                
        // 0x00B1D310: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D314: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        // 0x00B1D318: TBZ w0, #0, #0xb1d378      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B1D31C: LDR w8, [x19, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1D320: LDR x20, [x19, #0x48]      | X20 = this.mAnimator; //P2              
        // 0x00B1D324: FNEG s0, s8                | S0 = -(val_1);                          
        // 0x00B1D328: CMN w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1D32C: FCSEL s8, s0, s8, eq       | S8 = this.mLastDirection == 0x1 ? val_1 : val_1;
        val_28 = (this.mLastDirection == 1) ? (-val_28) : (val_28);
        // 0x00B1D330: CBNZ x20, #0xb1d338        | if (this.mAnimator != null) goto label_5;
        if(this.mAnimator != null)
        {
            goto label_5;
        }
        // 0x00B1D334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B1D338: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D33C: MOV x0, x20                | X0 = this.mAnimator;//m1                
        // 0x00B1D340: MOV v0.16b, v8.16b         | V0 = this.mLastDirection == 0x1 ? val_1 : val_1;//m1
        // 0x00B1D344: BL #0x2713df0              | this.mAnimator.Update(deltaTime:  val_28);
        this.mAnimator.Update(deltaTime:  val_28);
        // 0x00B1D348: MOV x0, x19                | X0 = 1152921514151018800 (0x1000000238E08130);//ML01
        // 0x00B1D34C: BL #0xb1c65c               | X0 = this.get_isPlaying();              
        bool val_3 = this.isPlaying;
        // 0x00B1D350: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B1D354: TBNZ w8, #0, #0xb1d8cc     | if ((val_3 & 1) == true) goto label_67; 
        if(val_4 == true)
        {
            goto label_67;
        }
        // 0x00B1D358: LDR x20, [x19, #0x48]      | X20 = this.mAnimator; //P2              
        // 0x00B1D35C: CBNZ x20, #0xb1d364        | if (this.mAnimator != null) goto label_7;
        if(this.mAnimator != null)
        {
            goto label_7;
        }
        // 0x00B1D360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B1D364: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1D368: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D36C: MOV x0, x20                | X0 = this.mAnimator;//m1                
        // 0x00B1D370: BL #0x20cb458              | this.mAnimator.set_enabled(value:  false);
        this.mAnimator.enabled = false;
        // 0x00B1D374: B #0xb1d758                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00B1D378: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1D37C: LDR x20, [x19, #0x30]      | X20 = this.mAnim; //P2                  
        // 0x00B1D380: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1D384: TBZ w8, #0, #0xb1d394      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B1D388: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D38C: CBNZ w8, #0xb1d394         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B1D390: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_10:
        // 0x00B1D394: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D39C: MOV x1, x20                | X1 = this.mAnim;//m1                    
        // 0x00B1D3A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D3A4: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        bool val_5 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        // 0x00B1D3A8: TBZ w0, #0, #0xb1d3e4      | if (val_5 == false) goto label_11;      
        if(val_5 == false)
        {
            goto label_11;
        }
        // 0x00B1D3AC: LDR x20, [x19, #0x30]      | X20 = this.mAnim; //P2                  
        // 0x00B1D3B0: CBNZ x20, #0xb1d3b8        | if (this.mAnim != null) goto label_12;  
        if(this.mAnim != null)
        {
            goto label_12;
        }
        // 0x00B1D3B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_12:
        // 0x00B1D3B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D3BC: MOV x0, x20                | X0 = this.mAnim;//m1                    
        // 0x00B1D3C0: BL #0x270cb80              | X0 = this.mAnim.GetEnumerator();        
        System.Collections.IEnumerator val_6 = this.mAnim.GetEnumerator();
        // 0x00B1D3C4: ADRP x26, #0x361c000       | X26 = 56737792 (0x361C000);             
        // 0x00B1D3C8: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
        // 0x00B1D3CC: LDR x26, [x26, #0x358]     | X26 = 1152921504608018432;              
        // 0x00B1D3D0: LDR x27, [x27, #0x990]     | X27 = 1152921504723460096;              
        // 0x00B1D3D4: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00B1D3D8: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        val_29 = 0;
        // 0x00B1D3DC: FMOV s9, wzr               | S9 = 0f;                                
        // 0x00B1D3E0: B #0xb1d600                |  goto label_32;                         
        goto label_32;
        label_11:
        // 0x00B1D3E4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1D3E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D3EC: MOV x0, x19                | X0 = 1152921514151018800 (0x1000000238E08130);//ML01
        // 0x00B1D3F0: SUB sp, x29, #0x70         | SP = (1152921514151006784 - 112) = 1152921514151006672 (0x1000000238E051D0);
        // 0x00B1D3F4: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1D3F8: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1D3FC: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1D400: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1D404: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1D408: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
        // 0x00B1D40C: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B1D410: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
        // 0x00B1D414: B #0x20cb458               | this.set_enabled(value:  false); return;
        this.enabled = false;
        return;
        label_35:
        // 0x00B1D418: ORR w25, wzr, #1           | W25 = 1(0x1);                           
        val_29 = 1;
        // 0x00B1D41C: B #0xb1d600                |  goto label_32;                         
        goto label_32;
        label_43:
        // 0x00B1D420: CBNZ x20, #0xb1d428        | if ( != 0) goto label_15;               
        if((???) != 0)
        {
            goto label_15;
        }
        // 0x00B1D424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_15:
        // 0x00B1D428: LDR x8, [x20]              | X8 = ;                                  
        var val_28 = ???;
        // 0x00B1D42C: LDR x1, [x26]              | X1 = ;                                  
        // 0x00B1D430: LDRH w9, [x8, #0x102]      | W9 = ??? + 258;                         
        // 0x00B1D434: CBZ x9, #0xb1d460          | if (??? + 258 == 0) goto label_16;      
        if((??? + 258) == 0)
        {
            goto label_16;
        }
        // 0x00B1D438: LDR x10, [x8, #0x98]       | X10 = ??? + 152;                        
        var val_26 = ??? + 152;
        // 0x00B1D43C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_27 = 0;
        // 0x00B1D440: ADD x10, x10, #8           | X10 = (??? + 152 + 8);                  
        val_26 = val_26 + 8;
        label_18:
        // 0x00B1D444: LDUR x12, [x10, #-8]       | X12 = (??? + 152 + 8) + -8;             
        // 0x00B1D448: CMP x12, x1                | STATE = COMPARE((??? + 152 + 8) + -8, ) 
        // 0x00B1D44C: B.EQ #0xb1d470             | if ((??? + 152 + 8) + -8 == ???) goto label_17;
        if(((??? + 152 + 8) + -8) == (???))
        {
            goto label_17;
        }
        // 0x00B1D450: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_27 = val_27 + 1;
        // 0x00B1D454: ADD x10, x10, #0x10        | X10 = ((??? + 152 + 8) + 16);           
        val_26 = val_26 + 16;
        // 0x00B1D458: CMP x11, x9                | STATE = COMPARE((0 + 1), ??? + 258)     
        // 0x00B1D45C: B.LO #0xb1d444             | if (0 < ??? + 258) goto label_18;       
        if(val_27 < (??? + 258))
        {
            goto label_18;
        }
        label_16:
        // 0x00B1D460: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1D464: MOV x0, x20                | X0 = X20;//m1                           
        val_30 = ???;
        // 0x00B1D468: BL #0x2776c24              | X0 = sub_2776C24( ?? , ????);           
        // 0x00B1D46C: B #0xb1d47c                |  goto label_19;                         
        goto label_19;
        label_17:
        // 0x00B1D470: LDR w9, [x10]              | W9 = (??? + 152 + 8);                   
        // 0x00B1D474: ADD x8, x8, x9, lsl #4     | X8 = (??? + ((??? + 152 + 8)) << 4);    
        val_28 = val_28 + (((??? + 152 + 8)) << 4);
        // 0x00B1D478: ADD x0, x8, #0x110         | X0 = ((??? + ((??? + 152 + 8)) << 4) + 272);
        val_30 = val_28 + 272;
        label_19:
        // 0x00B1D47C: LDP x8, x1, [x0]           | X8 = ((??? + ((??? + 152 + 8)) << 4) + 272); X1 = ((??? + ((??? + 152 + 8)) << 4) + 272) + 8; //  | 
        // 0x00B1D480: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00B1D484: BLR x8                     | X0 = ((??? + ((??? + 152 + 8)) << 4) + 272)();
        // 0x00B1D488: MOV x21, x0                | X21 = X0;//m1                           
        val_31 = ???;
        // 0x00B1D48C: CBZ x21, #0xb1d4c4         | if ( == 0) goto label_20;               
        if(val_31 == 0)
        {
            goto label_20;
        }
        // 0x00B1D490: LDR x1, [x27]              | X1 = ;                                  
        // 0x00B1D494: LDR x8, [x21]              | X8 = ;                                  
        // 0x00B1D498: CMP x8, x1                 | STATE = COMPARE(, )                     
        // 0x00B1D49C: B.EQ #0xb1d4d8             | if (val_31 == ???) goto label_21;       
        if(val_31 == (???))
        {
            goto label_21;
        }
        // 0x00B1D4A0: LDR x0, [x8, #0x30]        | X0 = val_31 + 48;                       
        // 0x00B1D4A4: ADD x8, sp, #8             | X8 = (1152921514151006800 + 8) = 1152921514151006808 (0x1000000238E05258);
        // 0x00B1D4A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_31 + 48, ????);
        // 0x00B1D4AC: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921514150994800]
        // 0x00B1D4B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
        // 0x00B1D4B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D4B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        // 0x00B1D4BC: ADD x0, sp, #8             | X0 = (1152921514151006800 + 8) = 1152921514151006808 (0x1000000238E05258);
        // 0x00B1D4C0: BL #0x299a140              | 
        label_20:
        // 0x00B1D4C4: LDR x22, [x19, #0x30]      | X22 = ??? + 48;                         
        val_32 = mem[??? + 48];
        val_32 = ??? + 48;
        // 0x00B1D4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000238E05258, ????);
        // 0x00B1D4CC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_31 = 0;
        // 0x00B1D4D0: ORR w28, wzr, #1           | W28 = 1(0x1);                           
        val_33 = 1;
        // 0x00B1D4D4: B #0xb1d4e0                |  goto label_22;                         
        goto label_22;
        label_21:
        // 0x00B1D4D8: LDR x22, [x19, #0x30]      | X22 = ??? + 48;                         
        val_32 = mem[??? + 48];
        val_32 = ??? + 48;
        // 0x00B1D4DC: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        val_33 = 0;
        label_22:
        // 0x00B1D4E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D4E4: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D4E8: BL #0x270eda0              | X0 = get_name();                        
        string val_8 = val_31.name;
        // 0x00B1D4EC: MOV x23, x0                | X23 = val_8;//m1                        
        // 0x00B1D4F0: CBNZ x22, #0xb1d4f8        | if (??? + 48 != 0) goto label_23;       
        if(val_32 != 0)
        {
            goto label_23;
        }
        // 0x00B1D4F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_23:
        // 0x00B1D4F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D4FC: MOV x0, x22                | X0 = ??? + 48;//m1                      
        // 0x00B1D500: MOV x1, x23                | X1 = val_8;//m1                         
        // 0x00B1D504: BL #0x270c41c              | X0 = ??? + 48.IsPlaying(name:  val_8);  
        bool val_9 = val_32.IsPlaying(name:  val_8);
        // 0x00B1D508: AND w8, w0, #1             | W8 = (val_9 & 1);                       
        bool val_10 = val_9;
        // 0x00B1D50C: TBZ w8, #0, #0xb1d600      | if ((val_9 & 1) == false) goto label_32;
        if(val_10 == false)
        {
            goto label_32;
        }
        // 0x00B1D510: CBZ w28, #0xb1d518         | if (0x0 == 0) goto label_25;            
        if(val_33 == 0)
        {
            goto label_25;
        }
        // 0x00B1D514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_25:
        // 0x00B1D518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D51C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D520: BL #0x270e998              | X0 = get_speed();                       
        float val_11 = val_31.speed;
        // 0x00B1D524: MOV v10.16b, v0.16b        | V10 = val_11;//m1                       
        // 0x00B1D528: CBZ w28, #0xb1d530         | if (0x0 == 0) goto label_26;            
        if(val_33 == 0)
        {
            goto label_26;
        }
        // 0x00B1D52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_26:
        // 0x00B1D530: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D534: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D538: BL #0x270e7d8              | X0 = get_time();                        
        float val_12 = val_31.time;
        // 0x00B1D53C: MOV v11.16b, v0.16b        | V11 = val_12;//m1                       
        // 0x00B1D540: CBZ w28, #0xb1d548         | if (0x0 == 0) goto label_27;            
        if(val_33 == 0)
        {
            goto label_27;
        }
        // 0x00B1D544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_27:
        // 0x00B1D548: FMUL s10, s8, s10          | S10 = (??? * val_11);                   
        val_34 = (???) * val_11;
        // 0x00B1D54C: FADD s0, s10, s11          | S0 = ((??? * val_11) + val_12);         
        val_12 = val_34 + val_12;
        // 0x00B1D550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D554: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D558: BL #0x270e840              | set_time(value:  val_12 = val_34 + val_12);
        val_31.time = val_12;
        // 0x00B1D55C: FCMP s10, #0.0             | STATE = COMPARE((??? * val_11), 0)      
        // 0x00B1D560: B.PL #0xb1d59c             | if (val_34 >= 0) goto label_28;         
        if(val_34 >= 0)
        {
            goto label_28;
        }
        // 0x00B1D564: CBZ w28, #0xb1d56c         | if (0x0 == 0) goto label_29;            
        if(val_33 == 0)
        {
            goto label_29;
        }
        // 0x00B1D568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_29:
        // 0x00B1D56C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D570: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D574: BL #0x270e7d8              | X0 = get_time();                        
        float val_13 = val_31.time;
        // 0x00B1D578: FCMP s0, #0.0              | STATE = COMPARE(val_13, 0)              
        // 0x00B1D57C: B.GT #0xb1d418             | if (val_13 > 0) goto label_35;          
        if(val_13 > 0f)
        {
            goto label_35;
        }
        // 0x00B1D580: CBZ w28, #0xb1d588         | if (0x0 == 0) goto label_31;            
        if(val_33 == 0)
        {
            goto label_31;
        }
        // 0x00B1D584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_31:
        // 0x00B1D588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D58C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D590: MOV v0.16b, v9.16b         | V0 = V9;//m1                            
        // 0x00B1D594: BL #0x270e840              | set_time(value:  ???);                  
        val_31.time = ???;
        // 0x00B1D598: B #0xb1d600                |  goto label_32;                         
        goto label_32;
        label_28:
        // 0x00B1D59C: CBZ w28, #0xb1d5a4         | if (0x0 == 0) goto label_33;            
        if(val_33 == 0)
        {
            goto label_33;
        }
        // 0x00B1D5A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_33:
        // 0x00B1D5A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D5A8: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D5AC: BL #0x270e7d8              | X0 = get_time();                        
        float val_14 = val_31.time;
        // 0x00B1D5B0: MOV v10.16b, v0.16b        | V10 = val_14;//m1                       
        // 0x00B1D5B4: CBZ w28, #0xb1d5bc         | if (0x0 == 0) goto label_34;            
        if(val_33 == 0)
        {
            goto label_34;
        }
        // 0x00B1D5B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_34:
        // 0x00B1D5BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D5C0: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D5C4: BL #0x270eb58              | X0 = get_length();                      
        float val_15 = val_31.length;
        // 0x00B1D5C8: FCMP s10, s0               | STATE = COMPARE(val_14, val_15)         
        // 0x00B1D5CC: B.MI #0xb1d418             | if (val_14 < 0) goto label_35;          
        if(val_14 < 0)
        {
            goto label_35;
        }
        // 0x00B1D5D0: CBZ w28, #0xb1d5d8         | if (0x0 == 0) goto label_36;            
        if(val_33 == 0)
        {
            goto label_36;
        }
        // 0x00B1D5D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_36:
        // 0x00B1D5D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D5DC: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D5E0: BL #0x270eb58              | X0 = get_length();                      
        float val_16 = val_31.length;
        // 0x00B1D5E4: MOV v10.16b, v0.16b        | V10 = val_16;//m1                       
        val_34 = val_16;
        // 0x00B1D5E8: CBZ w28, #0xb1d5f0         | if (0x0 == 0) goto label_37;            
        if(val_33 == 0)
        {
            goto label_37;
        }
        // 0x00B1D5EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_37:
        // 0x00B1D5F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D5F4: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D5F8: MOV v0.16b, v10.16b        | V0 = val_16;//m1                        
        // 0x00B1D5FC: BL #0x270e840              | set_time(value:  val_34);               
        val_31.time = val_34;
        label_32:
        // 0x00B1D600: CBNZ x20, #0xb1d608        | if ( != 0) goto label_38;               
        if((???) != 0)
        {
            goto label_38;
        }
        // 0x00B1D604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_38:
        // 0x00B1D608: LDR x8, [x20]              | X8 = ;                                  
        var val_32 = ???;
        // 0x00B1D60C: LDR x1, [x26]              | X1 = ;                                  
        // 0x00B1D610: LDRH w9, [x8, #0x102]      | W9 = ??? + 258;                         
        // 0x00B1D614: CBZ x9, #0xb1d640          | if (??? + 258 == 0) goto label_39;      
        if((??? + 258) == 0)
        {
            goto label_39;
        }
        // 0x00B1D618: LDR x10, [x8, #0x98]       | X10 = ??? + 152;                        
        var val_29 = ??? + 152;
        // 0x00B1D61C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_30 = 0;
        // 0x00B1D620: ADD x10, x10, #8           | X10 = (??? + 152 + 8);                  
        val_29 = val_29 + 8;
        label_41:
        // 0x00B1D624: LDUR x12, [x10, #-8]       | X12 = (??? + 152 + 8) + -8;             
        // 0x00B1D628: CMP x12, x1                | STATE = COMPARE((??? + 152 + 8) + -8, ) 
        // 0x00B1D62C: B.EQ #0xb1d650             | if ((??? + 152 + 8) + -8 == ???) goto label_40;
        if(((??? + 152 + 8) + -8) == (???))
        {
            goto label_40;
        }
        // 0x00B1D630: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_30 = val_30 + 1;
        // 0x00B1D634: ADD x10, x10, #0x10        | X10 = ((??? + 152 + 8) + 16);           
        val_29 = val_29 + 16;
        // 0x00B1D638: CMP x11, x9                | STATE = COMPARE((0 + 1), ??? + 258)     
        // 0x00B1D63C: B.LO #0xb1d624             | if (0 < ??? + 258) goto label_41;       
        if(val_30 < (??? + 258))
        {
            goto label_41;
        }
        label_39:
        // 0x00B1D640: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1D644: MOV x0, x20                | X0 = X20;//m1                           
        val_35 = ???;
        // 0x00B1D648: BL #0x2776c24              | X0 = sub_2776C24( ?? , ????);           
        // 0x00B1D64C: B #0xb1d660                |  goto label_42;                         
        goto label_42;
        label_40:
        // 0x00B1D650: LDR w9, [x10]              | W9 = (??? + 152 + 8);                   
        var val_31 = val_29;
        // 0x00B1D654: ADD w9, w9, #1             | W9 = ((??? + 152 + 8) + 1);             
        val_31 = val_31 + 1;
        // 0x00B1D658: ADD x8, x8, w9, uxtw #4    | X8 = (??? + ((??? + 152 + 8) + 1));     
        val_32 = val_32 + val_31;
        // 0x00B1D65C: ADD x0, x8, #0x110         | X0 = ((??? + ((??? + 152 + 8) + 1)) + 272);
        val_35 = val_32 + 272;
        label_42:
        // 0x00B1D660: LDP x8, x1, [x0]           | X8 = ((??? + ((??? + 152 + 8) + 1)) + 272); X1 = ((??? + ((??? + 152 + 8) + 1)) + 272) + 8; //  | 
        // 0x00B1D664: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00B1D668: BLR x8                     | X0 = ((??? + ((??? + 152 + 8) + 1)) + 272)();
        // 0x00B1D66C: AND w8, w0, #1             | W8 = (??? & 1);                         
        var val_17 = (???) & 1;
        // 0x00B1D670: TBNZ w8, #0, #0xb1d420     | if (((??? & 1) & 0x1) != 0) goto label_43;
        if((val_17 & 1) != 0)
        {
            goto label_43;
        }
        // 0x00B1D674: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00B1D678: MOVZ w22, #0x147           | W22 = 327 (0x147);//ML01                
        val_37 = 327;
        // 0x00B1D67C: B #0xb1d6a4                |  goto label_44;                         
        goto label_44;
        // 0x00B1D680: MOV x22, x1                | X22 = ((??? + ((??? + 152 + 8) + 1)) + 272) + 8;//m1
        // 0x00B1D684: MOV x21, x0                | X21 = X0;//m1                           
        label_70:
        // 0x00B1D688: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D68C: CMP w22, #1                | STATE = COMPARE(((??? + ((??? + 152 + 8) + 1)) + 272) + 8, 0x1)
        // 0x00B1D690: B.NE #0xb1d908             | if (((??? + ((??? + 152 + 8) + 1)) + 272) + 8 != 0x1) goto label_45;
        if((((??? + ((??? + 152 + 8) + 1)) + 272) + 8) != 1)
        {
            goto label_45;
        }
        // 0x00B1D694: BL #0x981060               | X0 = sub_981060( ?? , ????);            
        // 0x00B1D698: LDR x21, [x0]              | X21 = ;                                 
        val_36 = mem[???];
        val_36 = ???;
        // 0x00B1D69C: BL #0x980920               | X0 = sub_980920( ?? , ????);            
        // 0x00B1D6A0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_37 = 0;
        label_44:
        // 0x00B1D6A4: ADRP x23, #0x35df000       | X23 = 56487936 (0x35DF000);             
        // 0x00B1D6A8: LDR x23, [x23, #0x7a8]     | X23 = 1152921504608124928;              
        // 0x00B1D6AC: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00B1D6B0: LDR x1, [x23]              | X1 = typeof(System.IDisposable);        
        // 0x00B1D6B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? , ????);           
        // 0x00B1D6B8: MOV x20, x0                | X20 = X0;//m1                           
        // 0x00B1D6BC: CBZ x20, #0xb1d720         | if ( == 0) goto label_46;               
        if((???) == 0)
        {
            goto label_46;
        }
        // 0x00B1D6C0: LDR x8, [x20]              | X8 = ;                                  
        var val_35 = ???;
        // 0x00B1D6C4: LDR x1, [x23]              | X1 = typeof(System.IDisposable);        
        // 0x00B1D6C8: LDRH w9, [x8, #0x102]      | W9 = ??? + 258;                         
        // 0x00B1D6CC: CBZ x9, #0xb1d6f8          | if (??? + 258 == 0) goto label_47;      
        if((??? + 258) == 0)
        {
            goto label_47;
        }
        // 0x00B1D6D0: LDR x10, [x8, #0x98]       | X10 = ??? + 152;                        
        var val_33 = ??? + 152;
        // 0x00B1D6D4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_34 = 0;
        // 0x00B1D6D8: ADD x10, x10, #8           | X10 = (??? + 152 + 8);                  
        val_33 = val_33 + 8;
        label_49:
        // 0x00B1D6DC: LDUR x12, [x10, #-8]       | X12 = (??? + 152 + 8) + -8;             
        // 0x00B1D6E0: CMP x12, x1                | STATE = COMPARE((??? + 152 + 8) + -8, typeof(System.IDisposable))
        // 0x00B1D6E4: B.EQ #0xb1d708             | if ((??? + 152 + 8) + -8 == null) goto label_48;
        if(((??? + 152 + 8) + -8) == null)
        {
            goto label_48;
        }
        // 0x00B1D6E8: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_34 = val_34 + 1;
        // 0x00B1D6EC: ADD x10, x10, #0x10        | X10 = ((??? + 152 + 8) + 16);           
        val_33 = val_33 + 16;
        // 0x00B1D6F0: CMP x11, x9                | STATE = COMPARE((0 + 1), ??? + 258)     
        // 0x00B1D6F4: B.LO #0xb1d6dc             | if (0 < ??? + 258) goto label_49;       
        if(val_34 < (??? + 258))
        {
            goto label_49;
        }
        label_47:
        // 0x00B1D6F8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1D6FC: MOV x0, x20                | X0 = X20;//m1                           
        val_38 = ???;
        // 0x00B1D700: BL #0x2776c24              | X0 = sub_2776C24( ?? , ????);           
        // 0x00B1D704: B #0xb1d714                |  goto label_50;                         
        goto label_50;
        label_48:
        // 0x00B1D708: LDR w9, [x10]              | W9 = (??? + 152 + 8);                   
        // 0x00B1D70C: ADD x8, x8, x9, lsl #4     | X8 = (??? + ((??? + 152 + 8)) << 4);    
        val_35 = val_35 + (((??? + 152 + 8)) << 4);
        // 0x00B1D710: ADD x0, x8, #0x110         | X0 = ((??? + ((??? + 152 + 8)) << 4) + 272);
        val_38 = val_35 + 272;
        label_50:
        // 0x00B1D714: LDP x8, x1, [x0]           | X8 = ((??? + ((??? + 152 + 8)) << 4) + 272); X1 = ((??? + ((??? + 152 + 8)) << 4) + 272) + 8; //  | 
        // 0x00B1D718: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00B1D71C: BLR x8                     | X0 = ((??? + ((??? + 152 + 8)) << 4) + 272)();
        label_46:
        // 0x00B1D720: CMP w22, #0x147            | STATE = COMPARE(0x0, 0x147)             
        // 0x00B1D724: B.EQ #0xb1d738             | if (val_37 == 0x147) goto label_52;     
        if(val_37 == 327)
        {
            goto label_52;
        }
        // 0x00B1D728: CBZ x21, #0xb1d738         | if ( == 0) goto label_52;               
        if(val_36 == 0)
        {
            goto label_52;
        }
        // 0x00B1D72C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D730: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00B1D734: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
        label_52:
        // 0x00B1D738: LDR x20, [x19, #0x30]      | X20 = ??? + 48;                         
        // 0x00B1D73C: CBNZ x20, #0xb1d744        | if (??? + 48 != 0) goto label_53;       
        if((??? + 48) != 0)
        {
            goto label_53;
        }
        // 0x00B1D740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_53:
        // 0x00B1D744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D748: MOV x0, x20                | X0 = ??? + 48;//m1                      
        // 0x00B1D74C: BL #0x270c344              | ??? + 48.Sample();                      
        ??? + 48.Sample();
        // 0x00B1D750: AND w8, w25, #1            | W8 = (val_29 & 1);                      
        var val_18 = val_29 & 1;
        // 0x00B1D754: TBNZ w8, #0, #0xb1d8cc     | if (((val_29 & 1) & 0x1) != 0) goto label_67;
        if((val_18 & 1) != 0)
        {
            goto label_67;
        }
        label_8:
        // 0x00B1D758: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1D75C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D760: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00B1D764: BL #0x20cb458              | set_enabled(value:  false);             
        ???.enabled = false;
        // 0x00B1D768: LDRB w8, [x19, #0x40]      | W8 = ??? + 64;                          
        // 0x00B1D76C: CBZ w8, #0xb1d8cc          | if (??? + 64 == 0) goto label_67;       
        if((??? + 64) == 0)
        {
            goto label_67;
        }
        // 0x00B1D770: STRB wzr, [x19, #0x40]     | mem2[0] = 0x0;                           //  dest_result_addr=0
        mem2[0] = 0;
        // 0x00B1D774: ADRP x22, #0x3676000       | X22 = 57106432 (0x3676000);             
        // 0x00B1D778: LDR x22, [x22, #0x698]     | X22 = 1152921504875483136;              
        // 0x00B1D77C: LDR x0, [x24]              | X0 = ;                                  
        // 0x00B1D780: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
        // 0x00B1D784: LDR x8, [x8, #0xa0]        | X8 = ActiveAnimation.__il2cppRuntimeField_static_fields;
        // 0x00B1D788: LDR x20, [x8]              | X20 = ActiveAnimation.current;          
        // 0x00B1D78C: LDRB w8, [x0, #0x10a]      | W8 = ??? + 266;                         
        // 0x00B1D790: TBZ w8, #0, #0xb1d7a0      | if ((??? + 266 & 0x1) == 0) goto label_57;
        if(((??? + 266) & 1) == 0)
        {
            goto label_57;
        }
        // 0x00B1D794: LDR w8, [x0, #0xbc]        | W8 = ??? + 188;                         
        // 0x00B1D798: CBNZ w8, #0xb1d7a0         | if (??? + 188 != 0) goto label_57;      
        if((??? + 188) != 0)
        {
            goto label_57;
        }
        // 0x00B1D79C: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
        label_57:
        // 0x00B1D7A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D7A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D7A8: MOV x1, x20                | X1 = ActiveAnimation.current;//m1       
        // 0x00B1D7AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D7B0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  ActiveAnimation.current);
        bool val_19 = UnityEngine.Object.op_Equality(x:  0, y:  ActiveAnimation.current);
        // 0x00B1D7B4: TBZ w0, #0, #0xb1d870      | if (val_19 == false) goto label_58;     
        if(val_19 == false)
        {
            goto label_58;
        }
        // 0x00B1D7B8: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
        // 0x00B1D7BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D7C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D7C4: LDR x8, [x8, #0xa0]        | X8 = ActiveAnimation.__il2cppRuntimeField_static_fields;
        // 0x00B1D7C8: STR x19, [x8]              | ActiveAnimation.current = ;              //  dest_result_addr=1152921504875487232
        ActiveAnimation.current = ???;
        // 0x00B1D7CC: LDR x1, [x19, #0x18]       | X1 = ??? + 24;                          
        // 0x00B1D7D0: BL #0xebfba8               | EventDelegate.Execute(list:  0);        
        EventDelegate.Execute(list:  0);
        // 0x00B1D7D4: LDR x0, [x24]              | X0 = ;                                  
        // 0x00B1D7D8: LDR x20, [x19, #0x20]      | X20 = ??? + 32;                         
        // 0x00B1D7DC: LDRB w8, [x0, #0x10a]      | W8 = ??? + 266;                         
        // 0x00B1D7E0: TBZ w8, #0, #0xb1d7f0      | if ((??? + 266 & 0x1) == 0) goto label_60;
        if(((??? + 266) & 1) == 0)
        {
            goto label_60;
        }
        // 0x00B1D7E4: LDR w8, [x0, #0xbc]        | W8 = ??? + 188;                         
        // 0x00B1D7E8: CBNZ w8, #0xb1d7f0         | if (??? + 188 != 0) goto label_60;      
        if((??? + 188) != 0)
        {
            goto label_60;
        }
        // 0x00B1D7EC: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
        label_60:
        // 0x00B1D7F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D7F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D7F8: MOV x1, x20                | X1 = ??? + 32;//m1                      
        // 0x00B1D7FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D800: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  ??? + 32);
        bool val_20 = UnityEngine.Object.op_Inequality(x:  0, y:  ??? + 32);
        // 0x00B1D804: TBZ w0, #0, #0xb1d864      | if (val_20 == false) goto label_64;     
        if(val_20 == false)
        {
            goto label_64;
        }
        // 0x00B1D808: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1D80C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1D810: LDR x20, [x19, #0x28]      | X20 = ??? + 40;                         
        // 0x00B1D814: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1D818: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1D81C: TBZ w8, #0, #0xb1d82c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_63;
        // 0x00B1D820: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D824: CBNZ w8, #0xb1d82c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_63;
        // 0x00B1D828: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_63:
        // 0x00B1D82C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D834: MOV x1, x20                | X1 = ??? + 40;//m1                      
        // 0x00B1D838: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_21 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B1D83C: AND w8, w0, #1             | W8 = (val_21 & 1);                      
        bool val_22 = val_21;
        // 0x00B1D840: TBNZ w8, #0, #0xb1d864     | if ((val_21 & 1) == true) goto label_64;
        if(val_22 == true)
        {
            goto label_64;
        }
        // 0x00B1D844: LDP x20, x21, [x19, #0x20] | X20 = ??? + 32; X21 = ??? + 32 + 8;      //  | 
        val_36 = mem[??? + 32 + 8];
        val_36 = ??? + 32 + 8;
        // 0x00B1D848: CBNZ x20, #0xb1d850        | if (??? + 32 != 0) goto label_65;       
        if((??? + 32) != 0)
        {
            goto label_65;
        }
        // 0x00B1D84C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_65:
        // 0x00B1D850: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D854: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1D858: MOV x0, x20                | X0 = ??? + 32;//m1                      
        // 0x00B1D85C: MOV x1, x21                | X1 = ??? + 32 + 8;//m1                  
        // 0x00B1D860: BL #0x1a63378              | ??? + 32.SendMessage(methodName:  val_36, options:  1);
        ??? + 32.SendMessage(methodName:  val_36, options:  1);
        label_64:
        // 0x00B1D864: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
        // 0x00B1D868: LDR x8, [x8, #0xa0]        | X8 = ActiveAnimation.__il2cppRuntimeField_static_fields;
        // 0x00B1D86C: STR xzr, [x8]              | ActiveAnimation.current = null;          //  dest_result_addr=1152921504875487232
        ActiveAnimation.current = 0;
        label_58:
        // 0x00B1D870: LDR w8, [x19, #0x3c]       | W8 = ??? + 60;                          
        // 0x00B1D874: CBZ w8, #0xb1d8cc          | if (??? + 60 == 0) goto label_67;       
        if((??? + 60) == 0)
        {
            goto label_67;
        }
        // 0x00B1D878: LDR w9, [x19, #0x38]       | W9 = ??? + 56;                          
        // 0x00B1D87C: CMP w9, w8                 | STATE = COMPARE(??? + 56, ??? + 60)     
        // 0x00B1D880: B.NE #0xb1d8cc             | if (??? + 56 != ??? + 60) goto label_67;
        if((??? + 56) != (??? + 60))
        {
            goto label_67;
        }
        // 0x00B1D884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1D888: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00B1D88C: BL #0x20d50fc              | X0 = get_gameObject();                  
        UnityEngine.GameObject val_23 = ???.gameObject;
        // 0x00B1D890: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
        // 0x00B1D894: LDR x8, [x8, #0xa58]       | X8 = 1152921504876654592;               
        // 0x00B1D898: MOV x19, x0                | X19 = val_23;//m1                       
        val_27 = val_23;
        // 0x00B1D89C: LDR x8, [x8]               | X8 = typeof(NGUITools);                 
        // 0x00B1D8A0: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B1D8A4: TBZ w9, #0, #0xb1d8b8      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_69;
        // 0x00B1D8A8: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D8AC: CBNZ w9, #0xb1d8b8         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
        // 0x00B1D8B0: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B1D8B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_69:
        // 0x00B1D8B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D8BC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1D8C0: MOV x1, x19                | X1 = val_23;//m1                        
        // 0x00B1D8C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D8C8: BL #0xd0b060               | NGUITools.SetActive(go:  0, state:  val_27);
        NGUITools.SetActive(go:  0, state:  val_27);
        label_67:
        // 0x00B1D8CC: SUB sp, x29, #0x70         | SP = (??? - 112);                       
        var val_24 = (???) - 112;
        // 0x00B1D8D0: LDP x29, x30, [sp, #0x70]  | X29 = (??? - 112) + 112; X30 = (??? - 112) + 112 + 8; //  | 
        // 0x00B1D8D4: LDP x20, x19, [sp, #0x60]  | X20 = (??? - 112) + 96; X19 = (??? - 112) + 96 + 8; //  | 
        // 0x00B1D8D8: LDP x22, x21, [sp, #0x50]  | X22 = (??? - 112) + 80; X21 = (??? - 112) + 80 + 8; //  | 
        // 0x00B1D8DC: LDP x24, x23, [sp, #0x40]  | X24 = (??? - 112) + 64; X23 = (??? - 112) + 64 + 8; //  | 
        // 0x00B1D8E0: LDP x26, x25, [sp, #0x30]  | X26 = (??? - 112) + 48; X25 = (??? - 112) + 48 + 8; //  | 
        // 0x00B1D8E4: LDP x28, x27, [sp, #0x20]  | X28 = (??? - 112) + 32; X27 = (??? - 112) + 32 + 8; //  | 
        // 0x00B1D8E8: LDP d9, d8, [sp, #0x10]    | D9 = (??? - 112) + 16; D8 = (??? - 112) + 16 + 8; //  | 
        // 0x00B1D8EC: LDP d11, d10, [sp], #0x80  | D11 = (??? - 112); D10 = (??? - 112) + 8; //  | 
        // 0x00B1D8F0: RET                        |  return;                                
        return;
        // 0x00B1D8F4: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
        // 0x00B1D8F8: ADD x0, sp, #8             | X0 = ((??? - 112) + 128 + 8);           
        var val_25 = ((??? - 112) + 128) + 8;
        // 0x00B1D8FC: MOV x22, x1                | X22 = val_23;//m1                       
        // 0x00B1D900: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)((??? - 112) + 128 + 8)); //ERROR_TYPE
        // 0x00B1D904: B #0xb1d688                |  goto label_70;                         
        goto label_70;
        label_45:
        // 0x00B1D908: BL #0x980800               | X0 = sub_980800( ?? , ????);            
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1D90C (11655436), len: 1668  VirtAddr: 0x00B1D90C RVA: 0x00B1D90C token: 100687841 methodIndex: 24676 delegateWrapperIndex: 0 methodInvoker: 0
    private void Play(string clipName, AnimationOrTween.Direction playDirection)
    {
        //
        // Disasemble & Code
        //  | 
        var val_18;
        //  | 
        var val_30;
        //  | 
        string val_31;
        //  | 
        var val_32;
        //  | 
        var val_33;
        //  | 
        var val_34;
        //  | 
        var val_35;
        //  | 
        var val_36;
        // 0x00B1D90C: STP d11, d10, [sp, #-0x80]! | stack[1152921514151216976] = ???;  stack[1152921514151216984] = ???;  //  dest_result_addr=1152921514151216976 |  dest_result_addr=1152921514151216984
        // 0x00B1D910: STP d9, d8, [sp, #0x10]    | stack[1152921514151216992] = ???;  stack[1152921514151217000] = ???;  //  dest_result_addr=1152921514151216992 |  dest_result_addr=1152921514151217000
        // 0x00B1D914: STP x28, x27, [sp, #0x20]  | stack[1152921514151217008] = ???;  stack[1152921514151217016] = ???;  //  dest_result_addr=1152921514151217008 |  dest_result_addr=1152921514151217016
        // 0x00B1D918: STP x26, x25, [sp, #0x30]  | stack[1152921514151217024] = ???;  stack[1152921514151217032] = ???;  //  dest_result_addr=1152921514151217024 |  dest_result_addr=1152921514151217032
        // 0x00B1D91C: STP x24, x23, [sp, #0x40]  | stack[1152921514151217040] = ???;  stack[1152921514151217048] = ???;  //  dest_result_addr=1152921514151217040 |  dest_result_addr=1152921514151217048
        // 0x00B1D920: STP x22, x21, [sp, #0x50]  | stack[1152921514151217056] = ???;  stack[1152921514151217064] = ???;  //  dest_result_addr=1152921514151217056 |  dest_result_addr=1152921514151217064
        // 0x00B1D924: STP x20, x19, [sp, #0x60]  | stack[1152921514151217072] = ???;  stack[1152921514151217080] = ???;  //  dest_result_addr=1152921514151217072 |  dest_result_addr=1152921514151217080
        // 0x00B1D928: STP x29, x30, [sp, #0x70]  | stack[1152921514151217088] = ???;  stack[1152921514151217096] = ???;  //  dest_result_addr=1152921514151217088 |  dest_result_addr=1152921514151217096
        // 0x00B1D92C: ADD x29, sp, #0x70         | X29 = (1152921514151216976 + 112) = 1152921514151217088 (0x1000000238E387C0);
        // 0x00B1D930: SUB sp, sp, #0x10          | SP = (1152921514151216976 - 16) = 1152921514151216960 (0x1000000238E38740);
        // 0x00B1D934: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00B1D938: LDRB w8, [x22, #0x70d]     | W8 = (bool)static_value_0373370D;       
        // 0x00B1D93C: MOV w19, w2                | W19 = playDirection;//m1                
        val_30 = playDirection;
        // 0x00B1D940: MOV x21, x1                | X21 = clipName;//m1                     
        val_31 = clipName;
        // 0x00B1D944: MOV x20, x0                | X20 = 1152921514151229104 (0x1000000238E3B6B0);//ML01
        // 0x00B1D948: TBNZ w8, #0, #0xb1d964     | if (static_value_0373370D == true) goto label_0;
        // 0x00B1D94C: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00B1D950: LDR x8, [x8, #0x3b0]       | X8 = 0x2B8A9A4;                         
        // 0x00B1D954: LDR w0, [x8]               | W0 = 0x127;                             
        // 0x00B1D958: BL #0x2782188              | X0 = sub_2782188( ?? 0x127, ????);      
        // 0x00B1D95C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1D960: STRB w8, [x22, #0x70d]     | static_value_0373370D = true;            //  dest_result_addr=57882381
        label_0:
        // 0x00B1D964: CBNZ w19, #0xb1d978        | if (playDirection != 0) goto label_1;   
        if(val_30 != 0)
        {
            goto label_1;
        }
        // 0x00B1D968: LDR w8, [x20, #0x38]       | W8 = this.mLastDirection; //P2          
        // 0x00B1D96C: CMP w8, #1                 | STATE = COMPARE(this.mLastDirection, 0x1)
        // 0x00B1D970: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
        // 0x00B1D974: CNEG w19, w8, ne           | W19 = this.mLastDirection != 0x1 ?  (-0) : 0;
        AnimationOrTween.Direction val_1 = (this.mLastDirection != 1) ? (-0) : (0);
        label_1:
        // 0x00B1D978: ADRP x23, #0x35fe000       | X23 = 56614912 (0x35FE000);             
        // 0x00B1D97C: LDR x23, [x23, #0x810]     | X23 = 1152921504697475072;              
        val_32 = 1152921504697475072;
        // 0x00B1D980: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        // 0x00B1D984: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1D988: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1D98C: TBZ w8, #0, #0xb1d99c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B1D990: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D994: CBNZ w8, #0xb1d99c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1D998: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B1D99C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1D9A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D9A4: MOV x1, x22                | X1 = this.mAnim;//m1                    
        // 0x00B1D9A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1D9AC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnim);
        // 0x00B1D9B0: TBZ w0, #0, #0xb1da54      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B1D9B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D9B8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1D9BC: MOV x0, x20                | X0 = 1152921514151229104 (0x1000000238E3B6B0);//ML01
        // 0x00B1D9C0: BL #0x20cb458              | this.set_enabled(value:  true);         
        this.enabled = true;
        // 0x00B1D9C4: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        // 0x00B1D9C8: CBNZ x22, #0xb1d9d0        | if (this.mAnim != null) goto label_5;   
        if(this.mAnim != null)
        {
            goto label_5;
        }
        // 0x00B1D9CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x00B1D9D0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B1D9D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1D9D8: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1D9DC: BL #0x20cb458              | this.mAnim.set_enabled(value:  false);  
        this.mAnim.enabled = false;
        // 0x00B1D9E0: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00B1D9E4: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        // 0x00B1D9E8: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B1D9EC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1D9F0: TBZ w8, #0, #0xb1da00      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B1D9F4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1D9F8: CBNZ w8, #0xb1da00         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B1D9FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_7:
        // 0x00B1DA00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DA04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1DA08: MOV x1, x21                | X1 = clipName;//m1                      
        // 0x00B1DA0C: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_3 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B1DA10: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        // 0x00B1DA14: MOV w23, w0                | W23 = val_3;//m1                        
        // 0x00B1DA18: CBNZ x22, #0xb1da20        | if (this.mAnim != null) goto label_8;   
        if(this.mAnim != null)
        {
            goto label_8;
        }
        // 0x00B1DA1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B1DA20: TBZ w23, #0, #0xb1dae8     | if (val_3 == false) goto label_9;       
        if(val_3 == false)
        {
            goto label_9;
        }
        // 0x00B1DA24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DA28: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1DA2C: BL #0x270c3b4              | X0 = this.mAnim.get_isPlaying();        
        bool val_4 = this.mAnim.isPlaying;
        // 0x00B1DA30: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x00B1DA34: TBNZ w8, #0, #0xb1db1c     | if ((val_4 & 1) == true) goto label_22; 
        if(val_5 == true)
        {
            goto label_22;
        }
        // 0x00B1DA38: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        // 0x00B1DA3C: CBNZ x22, #0xb1da44        | if (this.mAnim != null) goto label_11;  
        if(this.mAnim != null)
        {
            goto label_11;
        }
        // 0x00B1DA40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_11:
        // 0x00B1DA44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DA48: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1DA4C: BL #0x270c510              | X0 = this.mAnim.Play();                 
        bool val_6 = this.mAnim.Play();
        // 0x00B1DA50: B #0xb1db1c                |  goto label_22;                         
        goto label_22;
        label_4:
        // 0x00B1DA54: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1DA58: LDR x22, [x20, #0x48]      | X22 = this.mAnimator; //P2              
        // 0x00B1DA5C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1DA60: TBZ w8, #0, #0xb1da70      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00B1DA64: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1DA68: CBNZ w8, #0xb1da70         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00B1DA6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_14:
        // 0x00B1DA70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DA74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1DA78: MOV x1, x22                | X1 = this.mAnimator;//m1                
        // 0x00B1DA7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1DA80: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        bool val_7 = UnityEngine.Object.op_Inequality(x:  0, y:  this.mAnimator);
        // 0x00B1DA84: TBZ w0, #0, #0xb1df44      | if (val_7 == false) goto label_21;      
        if(val_7 == false)
        {
            goto label_21;
        }
        // 0x00B1DA88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DA8C: MOV x0, x20                | X0 = 1152921514151229104 (0x1000000238E3B6B0);//ML01
        // 0x00B1DA90: BL #0x20cb3f0              | X0 = this.get_enabled();                
        bool val_8 = this.enabled;
        // 0x00B1DA94: TBZ w0, #0, #0xb1de78      | if (val_8 == false) goto label_20;      
        if(val_8 == false)
        {
            goto label_20;
        }
        // 0x00B1DA98: MOV x0, x20                | X0 = 1152921514151229104 (0x1000000238E3B6B0);//ML01
        // 0x00B1DA9C: BL #0xb1c65c               | X0 = this.get_isPlaying();              
        bool val_9 = this.isPlaying;
        // 0x00B1DAA0: TBZ w0, #0, #0xb1de78      | if (val_9 == false) goto label_20;      
        if(val_9 == false)
        {
            goto label_20;
        }
        // 0x00B1DAA4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B1DAA8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B1DAAC: LDR x22, [x20, #0x50]      | X22 = this.mClip; //P2                  
        // 0x00B1DAB0: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B1DAB4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1DAB8: TBZ w8, #0, #0xb1dac8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B1DABC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1DAC0: CBNZ w8, #0xb1dac8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B1DAC4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_19:
        // 0x00B1DAC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DACC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1DAD0: MOV x1, x22                | X1 = this.mClip;//m1                    
        // 0x00B1DAD4: MOV x2, x21                | X2 = clipName;//m1                      
        // 0x00B1DAD8: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.mClip);
        bool val_10 = System.String.op_Equality(a:  0, b:  this.mClip);
        // 0x00B1DADC: TBZ w0, #0, #0xb1de78      | if (val_10 == false) goto label_20;     
        if(val_10 == false)
        {
            goto label_20;
        }
        // 0x00B1DAE0: STR w19, [x20, #0x38]      | this.mLastDirection = this.mLastDirection != 0x1 ?  (-0) : 0;  //  dest_result_addr=1152921514151229160
        this.mLastDirection = val_1;
        // 0x00B1DAE4: B #0xb1df44                |  goto label_21;                         
        goto label_21;
        label_9:
        // 0x00B1DAE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1DAEC: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1DAF0: MOV x1, x21                | X1 = clipName;//m1                      
        // 0x00B1DAF4: BL #0x270c41c              | X0 = this.mAnim.IsPlaying(name:  val_31);
        bool val_11 = this.mAnim.IsPlaying(name:  val_31);
        // 0x00B1DAF8: AND w8, w0, #1             | W8 = (val_11 & 1);                      
        bool val_12 = val_11;
        // 0x00B1DAFC: TBNZ w8, #0, #0xb1db1c     | if ((val_11 & 1) == true) goto label_22;
        if(val_12 == true)
        {
            goto label_22;
        }
        // 0x00B1DB00: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        // 0x00B1DB04: CBNZ x22, #0xb1db0c        | if (this.mAnim != null) goto label_23;  
        if(this.mAnim != null)
        {
            goto label_23;
        }
        // 0x00B1DB08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_23:
        // 0x00B1DB0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1DB10: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1DB14: MOV x1, x21                | X1 = clipName;//m1                      
        // 0x00B1DB18: BL #0x270c614              | X0 = this.mAnim.Play(animation:  val_31);
        bool val_13 = this.mAnim.Play(animation:  val_31);
        label_22:
        // 0x00B1DB1C: LDR x22, [x20, #0x30]      | X22 = this.mAnim; //P2                  
        // 0x00B1DB20: CBNZ x22, #0xb1db28        | if (this.mAnim != null) goto label_24;  
        if(this.mAnim != null)
        {
            goto label_24;
        }
        // 0x00B1DB24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_24:
        // 0x00B1DB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DB2C: MOV x0, x22                | X0 = this.mAnim;//m1                    
        // 0x00B1DB30: BL #0x270cb80              | X0 = this.mAnim.GetEnumerator();        
        System.Collections.IEnumerator val_14 = this.mAnim.GetEnumerator();
        // 0x00B1DB34: ADRP x26, #0x361c000       | X26 = 56737792 (0x361C000);             
        // 0x00B1DB38: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
        // 0x00B1DB3C: ADRP x28, #0x363f000       | X28 = 56881152 (0x363F000);             
        // 0x00B1DB40: LDR x26, [x26, #0x358]     | X26 = 1152921504608018432;              
        // 0x00B1DB44: LDR x27, [x27, #0x990]     | X27 = 1152921504723460096;              
        // 0x00B1DB48: LDR x28, [x28, #0x3b0]     | X28 = 1152921504695345152;              
        // 0x00B1DB4C: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00B1DB50: SCVTF s10, w19             | S10 = (float)(this.mLastDirection != 0x1 ?  (-0) : 0);
        // 0x00B1DB54: FMOV s8, wzr               | S8 = 0f;                                
        label_61:
        // 0x00B1DB58: CBNZ x22, #0xb1db60        | if (val_14 != null) goto label_25;      
        if(val_14 != null)
        {
            goto label_25;
        }
        // 0x00B1DB5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_25:
        // 0x00B1DB60: LDR x8, [x22]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1DB64: LDR x1, [x26]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1DB68: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1DB6C: CBZ x9, #0xb1db98          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_26;
        // 0x00B1DB70: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1DB74: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_30 = 0;
        // 0x00B1DB78: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_28:
        // 0x00B1DB7C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1DB80: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1DB84: B.EQ #0xb1dba8             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_27;
        // 0x00B1DB88: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_30 = val_30 + 1;
        // 0x00B1DB8C: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1DB90: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1DB94: B.LO #0xb1db7c             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_28;
        label_26:
        // 0x00B1DB98: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1DB9C: MOV x0, x22                | X0 = val_14;//m1                        
        val_33 = val_14;
        // 0x00B1DBA0: BL #0x2776c24              | X0 = sub_2776C24( ?? val_14, ????);     
        // 0x00B1DBA4: B #0xb1dbb8                |  goto label_29;                         
        goto label_29;
        label_27:
        // 0x00B1DBA8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1DBAC: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
        // 0x00B1DBB0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
        // 0x00B1DBB4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
        label_29:
        // 0x00B1DBB8: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1DBBC: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00B1DBC0: BLR x8                     | X0 = sub_100000000011E000( ?? val_14, ????);
        // 0x00B1DBC4: AND w8, w0, #1             | W8 = (val_14 & 1);                      
        System.Collections.IEnumerator val_16 = val_14 & 1;
        // 0x00B1DBC8: TBZ w8, #0, #0xb1df6c      | if (((val_14 & 1) & 0x1) == 0) goto label_30;
        if((val_16 & 1) == 0)
        {
            goto label_30;
        }
        // 0x00B1DBCC: CBNZ x22, #0xb1dbd4        | if (val_14 != null) goto label_31;      
        if(val_14 != null)
        {
            goto label_31;
        }
        // 0x00B1DBD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_31:
        // 0x00B1DBD4: LDR x8, [x22]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1DBD8: LDR x1, [x26]              | X1 = typeof(System.Collections.IEnumerator);
        // 0x00B1DBDC: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1DBE0: CBZ x9, #0xb1dc0c          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
        // 0x00B1DBE4: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1DBE8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_31 = 0;
        // 0x00B1DBEC: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_34:
        // 0x00B1DBF0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1DBF4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
        // 0x00B1DBF8: B.EQ #0xb1dc1c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_33;
        // 0x00B1DBFC: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_31 = val_31 + 1;
        // 0x00B1DC00: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1DC04: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1DC08: B.LO #0xb1dbf0             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_34;
        label_32:
        // 0x00B1DC0C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1DC10: MOV x0, x22                | X0 = val_14;//m1                        
        val_34 = val_14;
        // 0x00B1DC14: BL #0x2776c24              | X0 = sub_2776C24( ?? val_14, ????);     
        // 0x00B1DC18: B #0xb1dc28                |  goto label_35;                         
        goto label_35;
        label_33:
        // 0x00B1DC1C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1DC20: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1DC24: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_35:
        // 0x00B1DC28: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1DC2C: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00B1DC30: BLR x8                     | X0 = sub_100000000011E000( ?? val_14, ????);
        // 0x00B1DC34: MOV x23, x0                | X23 = val_14;//m1                       
        val_35 = val_14;
        // 0x00B1DC38: CBZ x23, #0xb1dc70         | if (val_14 == null) goto label_36;      
        if(val_35 == null)
        {
            goto label_36;
        }
        // 0x00B1DC3C: LDR x1, [x27]              | X1 = typeof(UnityEngine.AnimationState);
        // 0x00B1DC40: LDR x8, [x23]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1DC44: CMP x8, x1                 | STATE = COMPARE(typeof(System.Collections.IEnumerator), typeof(UnityEngine.AnimationState))
        // 0x00B1DC48: B.EQ #0xb1dc74             | if (typeof(System.Collections.IEnumerator) == null) goto label_37;
        if(null == null)
        {
            goto label_37;
        }
        // 0x00B1DC4C: LDR x0, [x8, #0x30]        | X0 = System.Collections.IEnumerator.__il2cppRuntimeField_element_class;
        // 0x00B1DC50: ADD x8, sp, #8             | X8 = (1152921514151216960 + 8) = 1152921514151216968 (0x1000000238E38748);
        // 0x00B1DC54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.IEnumerator.__il2cppRuntimeField_element_class, ????);
        // 0x00B1DC58: LDR x0, [sp, #8]           | X0 = val_18;                             //  find_add[1152921514151205104]
        // 0x00B1DC5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
        // 0x00B1DC60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DC64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
        // 0x00B1DC68: ADD x0, sp, #8             | X0 = (1152921514151216960 + 8) = 1152921514151216968 (0x1000000238E38748);
        // 0x00B1DC6C: BL #0x299a140              | 
        label_36:
        // 0x00B1DC70: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_35 = 0;
        label_37:
        // 0x00B1DC74: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B1DC78: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1DC7C: TBZ w8, #0, #0xb1dc8c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_39;
        // 0x00B1DC80: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1DC84: CBNZ w8, #0xb1dc8c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_39;
        // 0x00B1DC88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_39:
        // 0x00B1DC8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DC90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1DC94: MOV x1, x21                | X1 = clipName;//m1                      
        // 0x00B1DC98: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_19 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B1DC9C: AND w8, w0, #1             | W8 = (val_19 & 1);                      
        bool val_20 = val_19;
        // 0x00B1DCA0: TBNZ w8, #0, #0xb1dcec     | if ((val_19 & 1) == true) goto label_40;
        if(val_20 == true)
        {
            goto label_40;
        }
        // 0x00B1DCA4: CBNZ x23, #0xb1dcac        | if (0x0 != 0) goto label_41;            
        if(val_35 != 0)
        {
            goto label_41;
        }
        // 0x00B1DCA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_41:
        // 0x00B1DCAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DCB0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DCB4: BL #0x270eda0              | X0 = val_35.get_name();                 
        string val_21 = val_35.name;
        // 0x00B1DCB8: MOV x24, x0                | X24 = val_21;//m1                       
        // 0x00B1DCBC: LDR x0, [x25]              | X0 = typeof(System.String);             
        // 0x00B1DCC0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B1DCC4: TBZ w8, #0, #0xb1dcd4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00B1DCC8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B1DCCC: CBNZ w8, #0xb1dcd4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00B1DCD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_43:
        // 0x00B1DCD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DCD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1DCDC: MOV x1, x24                | X1 = val_21;//m1                        
        // 0x00B1DCE0: MOV x2, x21                | X2 = clipName;//m1                      
        // 0x00B1DCE4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_21);
        bool val_22 = System.String.op_Equality(a:  0, b:  val_21);
        // 0x00B1DCE8: TBZ w0, #0, #0xb1db58      | if (val_22 == false) goto label_61;     
        if(val_22 == false)
        {
            goto label_61;
        }
        label_40:
        // 0x00B1DCEC: CBNZ x23, #0xb1dcf4        | if (0x0 != 0) goto label_45;            
        if(val_35 != 0)
        {
            goto label_45;
        }
        // 0x00B1DCF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_45:
        // 0x00B1DCF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DCF8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DCFC: BL #0x270e998              | X0 = val_35.get_speed();                
        float val_23 = val_35.speed;
        // 0x00B1DD00: MOV v9.16b, v0.16b         | V9 = val_23;//m1                        
        // 0x00B1DD04: LDR x0, [x28]              | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B1DD08: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B1DD0C: TBZ w8, #0, #0xb1dd1c      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_47;
        // 0x00B1DD10: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B1DD14: CBNZ w8, #0xb1dd1c         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
        // 0x00B1DD18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_47:
        // 0x00B1DD1C: CBNZ x23, #0xb1dd24        | if (0x0 != 0) goto label_48;            
        if(val_35 != 0)
        {
            goto label_48;
        }
        // 0x00B1DD20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Mathf), ????);
        label_48:
        // 0x00B1DD24: FABS s0, s9                | S0 = System.Math.Abs(val_23);           
        float val_32 = System.Math.Abs(val_23);
        // 0x00B1DD28: FMUL s0, s10, s0           | S0 = (this.mLastDirection != 0x1 ?  (-0) : 0 * val_23);
        val_32 = (float)val_1 * val_32;
        // 0x00B1DD2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DD30: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DD34: BL #0x270ea00              | val_35.set_speed(value:  System.Math.Abs(val_23) = (float)val_1 * System.Math.Abs(val_23));
        val_35.speed = val_32;
        // 0x00B1DD38: CMP w19, #1                | STATE = COMPARE(this.mLastDirection != 0x1 ?  (-0) : 0, 0x1)
        // 0x00B1DD3C: B.EQ #0xb1dda0             | if (val_1 == 0x1) goto label_49;        
        if(val_1 == 1)
        {
            goto label_49;
        }
        // 0x00B1DD40: CMN w19, #1                | STATE = COMPARE(this.mLastDirection != 0x1 ?  (-0) : 0, 0x1)
        // 0x00B1DD44: B.NE #0xb1db58             | if (val_1 != 0x1) goto label_61;        
        if(val_1 != 1)
        {
            goto label_61;
        }
        // 0x00B1DD48: CBNZ x23, #0xb1dd50        | if (0x0 != 0) goto label_51;            
        if(val_35 != 0)
        {
            goto label_51;
        }
        // 0x00B1DD4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_51:
        // 0x00B1DD50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DD54: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DD58: BL #0x270e7d8              | X0 = val_35.get_time();                 
        float val_24 = val_35.time;
        // 0x00B1DD5C: FCMP s0, #0.0              | STATE = COMPARE(val_24, 0)              
        // 0x00B1DD60: B.NE #0xb1dd98             | if (val_24 != 0) goto label_52;         
        if(val_24 != 0f)
        {
            goto label_52;
        }
        // 0x00B1DD64: CBNZ x23, #0xb1dd6c        | if (0x0 != 0) goto label_53;            
        if(val_35 != 0)
        {
            goto label_53;
        }
        // 0x00B1DD68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_53:
        // 0x00B1DD6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DD70: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DD74: BL #0x270eb58              | X0 = val_35.get_length();               
        float val_25 = val_35.length;
        // 0x00B1DD78: MOV v9.16b, v0.16b         | V9 = val_25;//m1                        
        // 0x00B1DD7C: CBNZ x23, #0xb1dd84        | if (0x0 != 0) goto label_54;            
        if(val_35 != 0)
        {
            goto label_54;
        }
        // 0x00B1DD80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_54:
        // 0x00B1DD84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DD88: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DD8C: MOV v0.16b, v9.16b         | V0 = val_25;//m1                        
        // 0x00B1DD90: BL #0x270e840              | val_35.set_time(value:  val_25);        
        val_35.time = val_25;
        // 0x00B1DD94: B #0xb1db58                |  goto label_61;                         
        goto label_61;
        label_52:
        // 0x00B1DD98: CMP w19, #1                | STATE = COMPARE(this.mLastDirection != 0x1 ?  (-0) : 0, 0x1)
        // 0x00B1DD9C: B.NE #0xb1db58             | if (val_1 != 0x1) goto label_61;        
        if(val_1 != 1)
        {
            goto label_61;
        }
        label_49:
        // 0x00B1DDA0: CBNZ x23, #0xb1dda8        | if (0x0 != 0) goto label_57;            
        if(val_35 != 0)
        {
            goto label_57;
        }
        // 0x00B1DDA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_57:
        // 0x00B1DDA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DDAC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DDB0: BL #0x270e7d8              | X0 = val_35.get_time();                 
        float val_26 = val_35.time;
        // 0x00B1DDB4: MOV v9.16b, v0.16b         | V9 = val_26;//m1                        
        // 0x00B1DDB8: CBNZ x23, #0xb1ddc0        | if (0x0 != 0) goto label_58;            
        if(val_35 != 0)
        {
            goto label_58;
        }
        // 0x00B1DDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_58:
        // 0x00B1DDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DDC4: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DDC8: BL #0x270eb58              | X0 = val_35.get_length();               
        float val_27 = val_35.length;
        // 0x00B1DDCC: FCMP s9, s0                | STATE = COMPARE(val_26, val_27)         
        // 0x00B1DDD0: B.NE #0xb1db58             | if (val_26 != val_27) goto label_61;    
        if(val_26 != val_27)
        {
            goto label_61;
        }
        // 0x00B1DDD4: CBNZ x23, #0xb1dddc        | if (0x0 != 0) goto label_60;            
        if(val_35 != 0)
        {
            goto label_60;
        }
        // 0x00B1DDD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_60:
        // 0x00B1DDDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DDE0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DDE4: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x00B1DDE8: BL #0x270e840              | val_35.set_time(value:  0f);            
        val_35.time = 0f;
        // 0x00B1DDEC: B #0xb1db58                |  goto label_61;                         
        goto label_61;
        // 0x00B1DDF0: MOV x23, x1                | X23 = 0 (0x0);//ML01                    
        // 0x00B1DDF4: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
        label_73:
        // 0x00B1DDF8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x00B1DDFC: CMP w23, #1                | STATE = COMPARE(0x0, 0x1)               
        // 0x00B1DE00: B.NE #0xb1df8c             | if (0 != 0x1) goto label_62;            
        if(0 != 1)
        {
            goto label_62;
        }
        // 0x00B1DE04: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
        // 0x00B1DE08: LDR x21, [x0]              | X21 = 0x10102464C457F;                  
        // 0x00B1DE0C: BL #0x980920               | X0 = sub_980920( ?? 0x0, ????);         
        // 0x00B1DE10: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_32 = 0;
        label_72:
        // 0x00B1DE14: ADRP x24, #0x35df000       | X24 = 56487936 (0x35DF000);             
        // 0x00B1DE18: LDR x24, [x24, #0x7a8]     | X24 = 1152921504608124928;              
        // 0x00B1DE1C: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00B1DE20: LDR x1, [x24]              | X1 = typeof(System.IDisposable);        
        // 0x00B1DE24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
        // 0x00B1DE28: MOV x22, x0                | X22 = val_14;//m1                       
        // 0x00B1DE2C: CBZ x22, #0xb1df08         | if (val_14 == null) goto label_63;      
        if(val_14 == null)
        {
            goto label_63;
        }
        // 0x00B1DE30: LDR x8, [x22]              | X8 = typeof(System.Collections.IEnumerator);
        // 0x00B1DE34: LDR x1, [x24]              | X1 = typeof(System.IDisposable);        
        // 0x00B1DE38: LDRH w9, [x8, #0x102]      | W9 = System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count;
        // 0x00B1DE3C: CBZ x9, #0xb1de68          | if (System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count == 0) goto label_64;
        // 0x00B1DE40: LDR x10, [x8, #0x98]       | X10 = System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets;
        // 0x00B1DE44: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_33 = 0;
        // 0x00B1DE48: ADD x10, x10, #8           | X10 = (System.Collections.IEnumerator.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608055304 (0x1000000000127008);
        label_66:
        // 0x00B1DE4C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x00B1DE50: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
        // 0x00B1DE54: B.EQ #0xb1def0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_65;
        // 0x00B1DE58: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_33 = val_33 + 1;
        // 0x00B1DE5C: ADD x10, x10, #0x10        | X10 = (1152921504608055304 + 16) = 1152921504608055320 (0x1000000000127018);
        // 0x00B1DE60: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count)
        // 0x00B1DE64: B.LO #0xb1de4c             | if (0 < System.Collections.IEnumerator.__il2cppRuntimeField_interface_offsets_count) goto label_66;
        label_64:
        // 0x00B1DE68: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1DE6C: MOV x0, x22                | X0 = val_14;//m1                        
        val_36 = val_14;
        // 0x00B1DE70: BL #0x2776c24              | X0 = sub_2776C24( ?? val_14, ????);     
        // 0x00B1DE74: B #0xb1defc                |  goto label_67;                         
        goto label_67;
        label_20:
        // 0x00B1DE78: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B1DE7C: MOV x0, x20                | X0 = 1152921514151229104 (0x1000000238E3B6B0);//ML01
        // 0x00B1DE80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1DE84: ORR w22, wzr, #1           | W22 = 1(0x1);                           
        // 0x00B1DE88: BL #0x20cb458              | this.set_enabled(value:  true);         
        this.enabled = true;
        // 0x00B1DE8C: STRB w22, [x20, #0x40]     | this.mNotify = true;                     //  dest_result_addr=1152921514151229168
        this.mNotify = true;
        // 0x00B1DE90: STR w19, [x20, #0x38]      | this.mLastDirection = this.mLastDirection != 0x1 ?  (-0) : 0;  //  dest_result_addr=1152921514151229160
        this.mLastDirection = val_1;
        // 0x00B1DE94: STR x21, [x20, #0x50]      | this.mClip = clipName;                   //  dest_result_addr=1152921514151229184
        this.mClip = val_31;
        // 0x00B1DE98: LDR x20, [x20, #0x48]      | X20 = this.mAnimator; //P2              
        // 0x00B1DE9C: CMP w19, #1                | STATE = COMPARE(this.mLastDirection != 0x1 ?  (-0) : 0, 0x1)
        // 0x00B1DEA0: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x00B1DEA4: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B1DEA8: FCSEL s8, s1, s0, eq       | S8 = val_1 == 0x1 ? 0f : 1f;            
        float val_28 = (val_1 == 1) ? (0f) : (1f);
        // 0x00B1DEAC: CBNZ x20, #0xb1deb4        | if (this.mAnimator != null) goto label_68;
        if(this.mAnimator != null)
        {
            goto label_68;
        }
        // 0x00B1DEB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_68:
        // 0x00B1DEB4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00B1DEB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1DEBC: MOV x0, x20                | X0 = this.mAnimator;//m1                
        // 0x00B1DEC0: MOV x1, x21                | X1 = clipName;//m1                      
        // 0x00B1DEC4: MOV v0.16b, v8.16b         | V0 = val_1 == 0x1 ? 0f : 1f;//m1        
        // 0x00B1DEC8: SUB sp, x29, #0x70         | SP = (1152921514151217088 - 112) = 1152921514151216976 (0x1000000238E38750);
        // 0x00B1DECC: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1DED0: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1DED4: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1DED8: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1DEDC: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1DEE0: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
        // 0x00B1DEE4: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B1DEE8: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
        // 0x00B1DEEC: B #0x2712f14               | this.mAnimator.Play(stateName:  val_31, layer:  0, normalizedTime:  val_28); return;
        this.mAnimator.Play(stateName:  val_31, layer:  0, normalizedTime:  val_28);
        return;
        label_65:
        // 0x00B1DEF0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x00B1DEF4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
        // 0x00B1DEF8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608018432 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
        label_67:
        // 0x00B1DEFC: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.IEnumerator);  //  | 
        // 0x00B1DF00: MOV x0, x22                | X0 = val_14;//m1                        
        // 0x00B1DF04: BLR x8                     | X0 = sub_100000000011E000( ?? val_14, ????);
        label_63:
        // 0x00B1DF08: CMP w23, #0x14b            | STATE = COMPARE(0x0, 0x14B)             
        // 0x00B1DF0C: B.EQ #0xb1df20             | if (val_32 == 0x14B) goto label_70;     
        if(val_32 == 331)
        {
            goto label_70;
        }
        // 0x00B1DF10: CBZ x21, #0xb1df20         | if (0x10102464C457F == 0) goto label_70;
        if(1179403647 == 0)
        {
            goto label_70;
        }
        // 0x00B1DF14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DF18: MOV x0, x21                | X0 = 282584257676671 (0x10102464C457F);//ML01
        // 0x00B1DF1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
        label_70:
        // 0x00B1DF20: LDR x21, [x20, #0x30]      | X21 = this.mAnim; //P2                  
        val_31 = this.mAnim;
        // 0x00B1DF24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1DF28: STR w19, [x20, #0x38]      | this.mLastDirection = this.mLastDirection != 0x1 ?  (-0) : 0;  //  dest_result_addr=1152921514151229160
        this.mLastDirection = val_1;
        // 0x00B1DF2C: STRB w8, [x20, #0x40]      | this.mNotify = true;                     //  dest_result_addr=1152921514151229168
        this.mNotify = true;
        // 0x00B1DF30: CBNZ x21, #0xb1df38        | if (this.mAnim != null) goto label_71;  
        if(val_31 != null)
        {
            goto label_71;
        }
        // 0x00B1DF34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10102464C457F, ????);
        label_71:
        // 0x00B1DF38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DF3C: MOV x0, x21                | X0 = this.mAnim;//m1                    
        // 0x00B1DF40: BL #0x270c344              | this.mAnim.Sample();                    
        val_31.Sample();
        label_21:
        // 0x00B1DF44: SUB sp, x29, #0x70         | SP = (1152921514151217088 - 112) = 1152921514151216976 (0x1000000238E38750);
        // 0x00B1DF48: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1DF4C: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1DF50: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1DF54: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1DF58: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1DF5C: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
        // 0x00B1DF60: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B1DF64: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
        // 0x00B1DF68: RET                        |  return;                                
        return;
        label_30:
        // 0x00B1DF6C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        // 0x00B1DF70: MOVZ w23, #0x14b           | W23 = 331 (0x14B);//ML01                
        // 0x00B1DF74: B #0xb1de14                |  goto label_72;                         
        goto label_72;
        // 0x00B1DF78: MOV x21, x0                | X21 = val_14;//m1                       
        // 0x00B1DF7C: ADD x0, sp, #8             | X0 = (1152921514151216960 + 8) = 1152921514151216968 (0x1000000238E38748);
        // 0x00B1DF80: MOV x23, x1                | X23 = 1152921504608018432 (0x100000000011E000);//ML01
        // 0x00B1DF84: BL #0x299a140              | 
        // 0x00B1DF88: B #0xb1ddf8                |  goto label_73;                         
        goto label_73;
        label_62:
        // 0x00B1DF8C: BL #0x980800               | X0 = sub_980800( ?? 0x0, ????);         
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1DF90 (11657104), len: 848  VirtAddr: 0x00B1DF90 RVA: 0x00B1DF90 token: 100687842 methodIndex: 24677 delegateWrapperIndex: 0 methodInvoker: 0
    public static ActiveAnimation Play(UnityEngine.Animation anim, string clipName, AnimationOrTween.Direction playDirection, AnimationOrTween.EnableCondition enableBeforePlay, AnimationOrTween.DisableCondition disableCondition)
    {
        //
        // Disasemble & Code
        //  | 
        AnimationOrTween.Direction val_13;
        //  | 
        AnimationOrTween.Direction val_14;
        //  | 
        UnityEngine.Object val_15;
        //  | 
        UnityEngine.Object val_16;
        // 0x00B1DF90: STP x28, x27, [sp, #-0x60]! | stack[1152921514151487728] = ???;  stack[1152921514151487736] = ???;  //  dest_result_addr=1152921514151487728 |  dest_result_addr=1152921514151487736
        // 0x00B1DF94: STP x26, x25, [sp, #0x10]  | stack[1152921514151487744] = ???;  stack[1152921514151487752] = ???;  //  dest_result_addr=1152921514151487744 |  dest_result_addr=1152921514151487752
        // 0x00B1DF98: STP x24, x23, [sp, #0x20]  | stack[1152921514151487760] = ???;  stack[1152921514151487768] = ???;  //  dest_result_addr=1152921514151487760 |  dest_result_addr=1152921514151487768
        // 0x00B1DF9C: STP x22, x21, [sp, #0x30]  | stack[1152921514151487776] = ???;  stack[1152921514151487784] = ???;  //  dest_result_addr=1152921514151487776 |  dest_result_addr=1152921514151487784
        // 0x00B1DFA0: STP x20, x19, [sp, #0x40]  | stack[1152921514151487792] = ???;  stack[1152921514151487800] = ???;  //  dest_result_addr=1152921514151487792 |  dest_result_addr=1152921514151487800
        // 0x00B1DFA4: STP x29, x30, [sp, #0x50]  | stack[1152921514151487808] = ???;  stack[1152921514151487816] = ???;  //  dest_result_addr=1152921514151487808 |  dest_result_addr=1152921514151487816
        // 0x00B1DFA8: ADD x29, sp, #0x50         | X29 = (1152921514151487728 + 80) = 1152921514151487808 (0x1000000238E7A940);
        // 0x00B1DFAC: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00B1DFB0: LDRB w8, [x24, #0x70e]     | W8 = (bool)static_value_0373370E;       
        // 0x00B1DFB4: MOV w21, w5                | W21 = W5;//m1                           
        val_13 = W5;
        // 0x00B1DFB8: MOV w23, w4                | W23 = disableCondition;//m1             
        // 0x00B1DFBC: MOV w19, w3                | W19 = enableBeforePlay;//m1             
        val_14 = enableBeforePlay;
        // 0x00B1DFC0: MOV x20, x2                | X20 = playDirection;//m1                
        // 0x00B1DFC4: MOV x22, x1                | X22 = clipName;//m1                     
        // 0x00B1DFC8: TBNZ w8, #0, #0xb1dfe4     | if (static_value_0373370E == true) goto label_0;
        // 0x00B1DFCC: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B1DFD0: LDR x8, [x8, #0x968]       | X8 = 0x2B8A9A8;                         
        // 0x00B1DFD4: LDR w0, [x8]               | W0 = 0x128;                             
        // 0x00B1DFD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x128, ????);      
        // 0x00B1DFDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1DFE0: STRB w8, [x24, #0x70e]     | static_value_0373370E = true;            //  dest_result_addr=57882382
        label_0:
        // 0x00B1DFE4: CBNZ x22, #0xb1dfec        | if (clipName != null) goto label_1;     
        if(clipName != null)
        {
            goto label_1;
        }
        // 0x00B1DFE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x128, ????);      
        label_1:
        // 0x00B1DFEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1DFF0: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1DFF4: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_1 = clipName.gameObject;
        // 0x00B1DFF8: ADRP x25, #0x35cd000       | X25 = 56414208 (0x35CD000);             
        // 0x00B1DFFC: LDR x25, [x25, #0xa58]     | X25 = 1152921504876654592;              
        val_15 = 1152921504876654592;
        // 0x00B1E000: MOV x24, x0                | X24 = val_1;//m1                        
        // 0x00B1E004: LDR x8, [x25]              | X8 = typeof(NGUITools);                 
        // 0x00B1E008: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B1E00C: TBZ w9, #0, #0xb1e020      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B1E010: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E014: CBNZ w9, #0xb1e020         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B1E018: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B1E01C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_3:
        // 0x00B1E020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E024: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E028: MOV x1, x24                | X1 = val_1;//m1                         
        // 0x00B1E02C: BL #0xd06d90               | X0 = NGUITools.GetActive(go:  0);       
        bool val_2 = NGUITools.GetActive(go:  0);
        // 0x00B1E030: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B1E034: TBNZ w8, #0, #0xb1e120     | if ((val_2 & 1) == true) goto label_12; 
        if(val_3 == true)
        {
            goto label_12;
        }
        // 0x00B1E038: CMP w23, #1                | STATE = COMPARE(disableCondition, 0x1)  
        // 0x00B1E03C: B.NE #0xb1e2bc             | if (disableCondition != 0x1) goto label_5;
        if(disableCondition != 1)
        {
            goto label_5;
        }
        // 0x00B1E040: CBNZ x22, #0xb1e048        | if (clipName != null) goto label_6;     
        if(clipName != null)
        {
            goto label_6;
        }
        // 0x00B1E044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B1E048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E04C: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E050: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_4 = clipName.gameObject;
        // 0x00B1E054: LDR x8, [x25]              | X8 = typeof(NGUITools);                 
        // 0x00B1E058: MOV x23, x0                | X23 = val_4;//m1                        
        // 0x00B1E05C: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B1E060: TBZ w9, #0, #0xb1e074      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B1E064: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E068: CBNZ w9, #0xb1e074         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B1E06C: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B1E070: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_8:
        // 0x00B1E074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E078: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E07C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1E080: MOV x1, x23                | X1 = val_4;//m1                         
        // 0x00B1E084: BL #0xd0b060               | NGUITools.SetActive(go:  0, state:  val_4);
        NGUITools.SetActive(go:  0, state:  val_4);
        // 0x00B1E088: CBNZ x22, #0xb1e090        | if (clipName != null) goto label_9;     
        if(clipName != null)
        {
            goto label_9;
        }
        // 0x00B1E08C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x00B1E090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E094: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E098: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_5 = clipName.gameObject;
        // 0x00B1E09C: MOV x23, x0                | X23 = val_5;//m1                        
        // 0x00B1E0A0: CBNZ x23, #0xb1e0a8        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B1E0A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B1E0A8: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B1E0AC: LDR x8, [x8, #0xb30]       | X8 = 1152921514151411312;               
        // 0x00B1E0B0: MOV x0, x23                | X0 = val_5;//m1                         
        // 0x00B1E0B4: LDR x1, [x8]               | X1 = public T[] UnityEngine.GameObject::GetComponentsInChildren<UIPanel>();
        // 0x00B1E0B8: BL #0x23d8d60              | X0 = val_5.GetComponentsInChildren<UIPanel>();
        T[] val_6 = val_5.GetComponentsInChildren<UIPanel>();
        // 0x00B1E0BC: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x00B1E0C0: CBNZ x23, #0xb1e0c8        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B1E0C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B1E0C8: LDR x25, [x23, #0x18]      | X25 = val_6.Length; //P2                
        // 0x00B1E0CC: CMP w25, #1                | STATE = COMPARE(val_6.Length, 0x1)      
        // 0x00B1E0D0: B.LT #0xb1e120             | if (val_6.Length < 1) goto label_12;    
        if(val_6.Length < 1)
        {
            goto label_12;
        }
        // 0x00B1E0D4: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x00B1E0D8: ADD x27, x23, #0x20        | X27 = val_6[0x20]; //PARR1              
        label_16:
        // 0x00B1E0DC: CBNZ x23, #0xb1e0e4        | if (val_6 != null) goto label_13;       
        if(val_6 != null)
        {
            goto label_13;
        }
        // 0x00B1E0E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_13:
        // 0x00B1E0E4: LDR w8, [x23, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x00B1E0E8: CMP x26, x8                | STATE = COMPARE(0x0, val_6.Length)      
        // 0x00B1E0EC: B.LO #0xb1e0fc             | if (0 < val_6.Length) goto label_14;    
        if(val_13 < val_6.Length)
        {
            goto label_14;
        }
        // 0x00B1E0F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B1E0F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E0F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_14:
        // 0x00B1E0FC: LDR x24, [x27, x26, lsl #3] | X24 = typeof(T[]);                      
        // 0x00B1E100: CBNZ x24, #0xb1e108        | if (typeof(T[]) != null) goto label_15; 
        if(null != null)
        {
            goto label_15;
        }
        // 0x00B1E104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_15:
        // 0x00B1E108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E10C: MOV x0, x24                | X0 = 1152921505605890016 (0x100000003B8C2FE0);//ML01
        // 0x00B1E110: BL #0xfbdf18               | 1152921505605890016.Refresh();          
        1152921505605890016.Refresh();
        // 0x00B1E114: ADD x26, x26, #1           | X26 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x00B1E118: CMP w25, w26               | STATE = COMPARE(val_6.Length, (0 + 1))  
        // 0x00B1E11C: B.NE #0xb1e0dc             | if (val_6.Length != 0) goto label_16;   
        if(val_6.Length != val_13)
        {
            goto label_16;
        }
        label_12:
        // 0x00B1E120: CBNZ x22, #0xb1e128        | if (clipName != null) goto label_17;    
        if(clipName != null)
        {
            goto label_17;
        }
        // 0x00B1E124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(T[]), ????);
        label_17:
        // 0x00B1E128: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B1E12C: LDR x8, [x8, #0x598]       | X8 = 1152921514151449200;               
        // 0x00B1E130: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E134: LDR x1, [x8]               | X1 = public ActiveAnimation UnityEngine.Component::GetComponent<ActiveAnimation>();
        // 0x00B1E138: BL #0x23d5410              | X0 = clipName.GetComponent<ActiveAnimation>();
        ActiveAnimation val_7 = clipName.GetComponent<ActiveAnimation>();
        // 0x00B1E13C: ADRP x24, #0x35fe000       | X24 = 56614912 (0x35FE000);             
        // 0x00B1E140: LDR x24, [x24, #0x810]     | X24 = 1152921504697475072;              
        // 0x00B1E144: MOV x23, x0                | X23 = val_7;//m1                        
        val_16 = val_7;
        // 0x00B1E148: LDR x8, [x24]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B1E14C: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E150: TBZ w9, #0, #0xb1e164      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_19;
        // 0x00B1E154: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E158: CBNZ w9, #0xb1e164         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
        // 0x00B1E15C: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B1E160: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_19:
        // 0x00B1E164: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E16C: MOV x1, x23                | X1 = val_7;//m1                         
        // 0x00B1E170: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E174: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_16);
        bool val_8 = UnityEngine.Object.op_Equality(x:  0, y:  val_16);
        // 0x00B1E178: TBZ w0, #0, #0xb1e1b4      | if (val_8 == false) goto label_20;      
        if(val_8 == false)
        {
            goto label_20;
        }
        // 0x00B1E17C: CBNZ x22, #0xb1e184        | if (clipName != null) goto label_21;    
        if(clipName != null)
        {
            goto label_21;
        }
        // 0x00B1E180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_21:
        // 0x00B1E184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E188: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E18C: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_9 = clipName.gameObject;
        // 0x00B1E190: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x00B1E194: CBNZ x23, #0xb1e19c        | if (val_9 != null) goto label_22;       
        if(val_9 != null)
        {
            goto label_22;
        }
        // 0x00B1E198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_22:
        // 0x00B1E19C: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B1E1A0: LDR x8, [x8, #0xd18]       | X8 = 1152921514151458416;               
        // 0x00B1E1A4: MOV x0, x23                | X0 = val_9;//m1                         
        // 0x00B1E1A8: LDR x1, [x8]               | X1 = public ActiveAnimation UnityEngine.GameObject::AddComponent<ActiveAnimation>();
        // 0x00B1E1AC: BL #0x23d5984              | X0 = val_9.AddComponent<ActiveAnimation>();
        ActiveAnimation val_10 = val_9.AddComponent<ActiveAnimation>();
        // 0x00B1E1B0: MOV x23, x0                | X23 = val_10;//m1                       
        val_16 = val_10;
        label_20:
        // 0x00B1E1B4: CBZ x23, #0xb1e1c8         | if (val_10 == null) goto label_23;      
        if(val_16 == null)
        {
            goto label_23;
        }
        // 0x00B1E1B8: MOV x25, x23               | X25 = val_10;//m1                       
        val_15 = val_16;
        // 0x00B1E1BC: STR x22, [x25, #0x30]!     | val_10.mAnim = clipName;                 //  dest_result_addr=0
        val_10.mAnim = clipName;
        // 0x00B1E1C0: STR w21, [x25, #0xc]       | mem2[0] = W5;                            //  dest_result_addr=0
        mem2[0] = val_13;
        // 0x00B1E1C4: B #0xb1e1e0                |  goto label_24;                         
        goto label_24;
        label_23:
        // 0x00B1E1C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B1E1CC: ORR w25, wzr, #0x30        | W25 = 48(0x30);                         
        val_15 = 48;
        // 0x00B1E1D0: STR x22, [x25]             | mem[48] = clipName;                      //  dest_result_addr=48
        mem[48] = clipName;
        // 0x00B1E1D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B1E1D8: STR w21, [x23, #0x3c]      | val_10.mDisableDirection = W5;           //  dest_result_addr=0
        val_10.mDisableDirection = val_13;
        // 0x00B1E1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_24:
        // 0x00B1E1E0: LDR x21, [x23, #0x18]      | X21 = val_10.onFinished; //P2           
        val_13 = val_10.onFinished;
        // 0x00B1E1E4: CBNZ x21, #0xb1e1ec        | if (val_10.onFinished != null) goto label_25;
        if(val_13 != null)
        {
            goto label_25;
        }
        // 0x00B1E1E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_25:
        // 0x00B1E1EC: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B1E1F0: LDR x8, [x8, #0x638]       | X8 = 1152921510859177456;               
        // 0x00B1E1F4: MOV x0, x21                | X0 = val_10.onFinished;//m1             
        // 0x00B1E1F8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<EventDelegate>::Clear();
        // 0x00B1E1FC: BL #0x25ead28              | val_10.onFinished.Clear();              
        val_13.Clear();
        // 0x00B1E200: MOV x0, x23                | X0 = val_10;//m1                        
        // 0x00B1E204: MOV x1, x20                | X1 = playDirection;//m1                 
        // 0x00B1E208: MOV w2, w19                | W2 = enableBeforePlay;//m1              
        // 0x00B1E20C: BL #0xb1d90c               | val_10.Play(clipName:  playDirection, playDirection:  val_14);
        val_16.Play(clipName:  playDirection, playDirection:  val_14);
        // 0x00B1E210: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1E214: LDR x19, [x25]             | X19 = clipName;                         
        // 0x00B1E218: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E21C: TBZ w8, #0, #0xb1e22c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00B1E220: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E224: CBNZ w8, #0xb1e22c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00B1E228: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_27:
        // 0x00B1E22C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E230: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E234: MOV x1, x19                | X1 = clipName;//m1                      
        // 0x00B1E238: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E23C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_15);
        bool val_11 = UnityEngine.Object.op_Inequality(x:  0, y:  val_15);
        // 0x00B1E240: TBZ w0, #0, #0xb1e260      | if (val_11 == false) goto label_28;     
        if(val_11 == false)
        {
            goto label_28;
        }
        // 0x00B1E244: LDR x19, [x25]             | X19 = clipName;                         
        val_14 = mem[48];
        // 0x00B1E248: CBNZ x19, #0xb1e250        | if (clipName != 0) goto label_29;       
        if(val_14 != 0)
        {
            goto label_29;
        }
        // 0x00B1E24C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_29:
        // 0x00B1E250: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E254: MOV x0, x19                | X0 = clipName;//m1                      
        // 0x00B1E258: BL #0x270c344              | clipName.Sample();                      
        val_14.Sample();
        // 0x00B1E25C: B #0xb1e2c0                |  goto label_36;                         
        goto label_36;
        label_28:
        // 0x00B1E260: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1E264: LDR x19, [x23, #0x48]      | X19 = val_10.mAnimator; //P2            
        val_14 = val_10.mAnimator;
        // 0x00B1E268: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E26C: TBZ w8, #0, #0xb1e27c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_32;
        // 0x00B1E270: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E274: CBNZ w8, #0xb1e27c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
        // 0x00B1E278: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_32:
        // 0x00B1E27C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E280: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E284: MOV x1, x19                | X1 = val_10.mAnimator;//m1              
        // 0x00B1E288: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E28C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_14);
        bool val_12 = UnityEngine.Object.op_Inequality(x:  0, y:  val_14);
        // 0x00B1E290: TBZ w0, #0, #0xb1e2c0      | if (val_12 == false) goto label_36;     
        if(val_12 == false)
        {
            goto label_36;
        }
        // 0x00B1E294: CBNZ x23, #0xb1e29c        | if (val_10 != null) goto label_34;      
        if(val_16 != null)
        {
            goto label_34;
        }
        // 0x00B1E298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_34:
        // 0x00B1E29C: LDR x19, [x23, #0x48]      | X19 = val_10.mAnimator; //P2            
        val_14 = val_10.mAnimator;
        // 0x00B1E2A0: CBNZ x19, #0xb1e2a8        | if (val_10.mAnimator != null) goto label_35;
        if(val_14 != null)
        {
            goto label_35;
        }
        // 0x00B1E2A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_35:
        // 0x00B1E2A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E2AC: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B1E2B0: MOV x0, x19                | X0 = val_10.mAnimator;//m1              
        // 0x00B1E2B4: BL #0x2713df0              | val_10.mAnimator.Update(deltaTime:  0f);
        val_14.Update(deltaTime:  0f);
        // 0x00B1E2B8: B #0xb1e2c0                |  goto label_36;                         
        goto label_36;
        label_5:
        // 0x00B1E2BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_16 = 0;
        label_36:
        // 0x00B1E2C0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E2C4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1E2C8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1E2CC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1E2D0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1E2D4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1E2D8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1E2DC: RET                        |  return (ActiveAnimation)null;          
        return (ActiveAnimation)val_16;
        //  |  // // {name=val_0, type=ActiveAnimation, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1E2E0 (11657952), len: 12  VirtAddr: 0x00B1E2E0 RVA: 0x00B1E2E0 token: 100687843 methodIndex: 24678 delegateWrapperIndex: 0 methodInvoker: 0
    public static ActiveAnimation Play(UnityEngine.Animation anim, string clipName, AnimationOrTween.Direction playDirection)
    {
        //
        // Disasemble & Code
        // 0x00B1E2E0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x00B1E2E4: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
        // 0x00B1E2E8: B #0xb1df90                | return ActiveAnimation.Play(anim:  anim, clipName:  clipName, playDirection:  playDirection, enableBeforePlay:  null, disableCondition:  0);
        return ActiveAnimation.Play(anim:  anim, clipName:  clipName, playDirection:  playDirection, enableBeforePlay:  null, disableCondition:  0);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1E2EC (11657964), len: 24  VirtAddr: 0x00B1E2EC RVA: 0x00B1E2EC token: 100687844 methodIndex: 24679 delegateWrapperIndex: 0 methodInvoker: 0
    public static ActiveAnimation Play(UnityEngine.Animation anim, AnimationOrTween.Direction playDirection)
    {
        //
        // Disasemble & Code
        // 0x00B1E2EC: MOV w8, w2                 | W8 = W2;//m1                            
        // 0x00B1E2F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E2F4: MOV w3, w8                 | W3 = W2;//m1                            
        // 0x00B1E2F8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
        // 0x00B1E2FC: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
        // 0x00B1E300: B #0xb1df90                | return ActiveAnimation.Play(anim:  anim, clipName:  playDirection, playDirection:  0, enableBeforePlay:  W2, disableCondition:  0);
        return ActiveAnimation.Play(anim:  anim, clipName:  playDirection, playDirection:  0, enableBeforePlay:  W2, disableCondition:  0);
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1E304 (11657988), len: 856  VirtAddr: 0x00B1E304 RVA: 0x00B1E304 token: 100687845 methodIndex: 24680 delegateWrapperIndex: 0 methodInvoker: 0
    public static ActiveAnimation Play(UnityEngine.Animator anim, string clipName, AnimationOrTween.Direction playDirection, AnimationOrTween.EnableCondition enableBeforePlay, AnimationOrTween.DisableCondition disableCondition)
    {
        //
        // Disasemble & Code
        //  | 
        AnimationOrTween.Direction val_13;
        //  | 
        AnimationOrTween.Direction val_14;
        //  | 
        var val_15;
        //  | 
        UnityEngine.Object val_16;
        // 0x00B1E304: STP x28, x27, [sp, #-0x60]! | stack[1152921514152053104] = ???;  stack[1152921514152053112] = ???;  //  dest_result_addr=1152921514152053104 |  dest_result_addr=1152921514152053112
        // 0x00B1E308: STP x26, x25, [sp, #0x10]  | stack[1152921514152053120] = ???;  stack[1152921514152053128] = ???;  //  dest_result_addr=1152921514152053120 |  dest_result_addr=1152921514152053128
        // 0x00B1E30C: STP x24, x23, [sp, #0x20]  | stack[1152921514152053136] = ???;  stack[1152921514152053144] = ???;  //  dest_result_addr=1152921514152053136 |  dest_result_addr=1152921514152053144
        // 0x00B1E310: STP x22, x21, [sp, #0x30]  | stack[1152921514152053152] = ???;  stack[1152921514152053160] = ???;  //  dest_result_addr=1152921514152053152 |  dest_result_addr=1152921514152053160
        // 0x00B1E314: STP x20, x19, [sp, #0x40]  | stack[1152921514152053168] = ???;  stack[1152921514152053176] = ???;  //  dest_result_addr=1152921514152053168 |  dest_result_addr=1152921514152053176
        // 0x00B1E318: STP x29, x30, [sp, #0x50]  | stack[1152921514152053184] = ???;  stack[1152921514152053192] = ???;  //  dest_result_addr=1152921514152053184 |  dest_result_addr=1152921514152053192
        // 0x00B1E31C: ADD x29, sp, #0x50         | X29 = (1152921514152053104 + 80) = 1152921514152053184 (0x1000000238F049C0);
        // 0x00B1E320: ADRP x24, #0x3733000       | X24 = 57880576 (0x3733000);             
        // 0x00B1E324: LDRB w8, [x24, #0x70f]     | W8 = (bool)static_value_0373370F;       
        // 0x00B1E328: MOV w21, w5                | W21 = W5;//m1                           
        val_13 = W5;
        // 0x00B1E32C: MOV w23, w4                | W23 = disableCondition;//m1             
        // 0x00B1E330: MOV w19, w3                | W19 = enableBeforePlay;//m1             
        val_14 = enableBeforePlay;
        // 0x00B1E334: MOV x20, x2                | X20 = playDirection;//m1                
        // 0x00B1E338: MOV x22, x1                | X22 = clipName;//m1                     
        // 0x00B1E33C: TBNZ w8, #0, #0xb1e358     | if (static_value_0373370F == true) goto label_0;
        // 0x00B1E340: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
        // 0x00B1E344: LDR x8, [x8, #0xb20]       | X8 = 0x2B8A9AC;                         
        // 0x00B1E348: LDR w0, [x8]               | W0 = 0x129;                             
        // 0x00B1E34C: BL #0x2782188              | X0 = sub_2782188( ?? 0x129, ????);      
        // 0x00B1E350: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1E354: STRB w8, [x24, #0x70f]     | static_value_0373370F = true;            //  dest_result_addr=57882383
        label_0:
        // 0x00B1E358: CMP w23, #2                | STATE = COMPARE(disableCondition, 0x2)  
        // 0x00B1E35C: B.EQ #0xb1e49c             | if (disableCondition == 0x2) goto label_13;
        if(disableCondition == 2)
        {
            goto label_13;
        }
        // 0x00B1E360: CBNZ x22, #0xb1e368        | if (clipName != null) goto label_2;     
        if(clipName != null)
        {
            goto label_2;
        }
        // 0x00B1E364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x129, ????);      
        label_2:
        // 0x00B1E368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E36C: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E370: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_1 = clipName.gameObject;
        // 0x00B1E374: ADRP x25, #0x35cd000       | X25 = 56414208 (0x35CD000);             
        // 0x00B1E378: LDR x25, [x25, #0xa58]     | X25 = 1152921504876654592;              
        val_15 = 1152921504876654592;
        // 0x00B1E37C: MOV x24, x0                | X24 = val_1;//m1                        
        // 0x00B1E380: LDR x8, [x25]              | X8 = typeof(NGUITools);                 
        // 0x00B1E384: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B1E388: TBZ w9, #0, #0xb1e39c      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B1E38C: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E390: CBNZ w9, #0xb1e39c         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B1E394: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B1E398: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_4:
        // 0x00B1E39C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E3A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E3A4: MOV x1, x24                | X1 = val_1;//m1                         
        // 0x00B1E3A8: BL #0xd06d90               | X0 = NGUITools.GetActive(go:  0);       
        bool val_2 = NGUITools.GetActive(go:  0);
        // 0x00B1E3AC: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B1E3B0: TBNZ w8, #0, #0xb1e49c     | if ((val_2 & 1) == true) goto label_13; 
        if(val_3 == true)
        {
            goto label_13;
        }
        // 0x00B1E3B4: CMP w23, #1                | STATE = COMPARE(disableCondition, 0x1)  
        // 0x00B1E3B8: B.NE #0xb1e638             | if (disableCondition != 0x1) goto label_6;
        if(disableCondition != 1)
        {
            goto label_6;
        }
        // 0x00B1E3BC: CBNZ x22, #0xb1e3c4        | if (clipName != null) goto label_7;     
        if(clipName != null)
        {
            goto label_7;
        }
        // 0x00B1E3C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B1E3C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E3C8: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E3CC: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_4 = clipName.gameObject;
        // 0x00B1E3D0: LDR x8, [x25]              | X8 = typeof(NGUITools);                 
        // 0x00B1E3D4: MOV x23, x0                | X23 = val_4;//m1                        
        // 0x00B1E3D8: LDRB w9, [x8, #0x10a]      | W9 = NGUITools.__il2cppRuntimeField_10A;
        // 0x00B1E3DC: TBZ w9, #0, #0xb1e3f0      | if (NGUITools.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B1E3E0: LDR w9, [x8, #0xbc]        | W9 = NGUITools.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E3E4: CBNZ w9, #0xb1e3f0         | if (NGUITools.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B1E3E8: MOV x0, x8                 | X0 = 1152921504876654592 (0x100000001014F000);//ML01
        // 0x00B1E3EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(NGUITools), ????);
        label_9:
        // 0x00B1E3F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E3F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E3F8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B1E3FC: MOV x1, x23                | X1 = val_4;//m1                         
        // 0x00B1E400: BL #0xd0b060               | NGUITools.SetActive(go:  0, state:  val_4);
        NGUITools.SetActive(go:  0, state:  val_4);
        // 0x00B1E404: CBNZ x22, #0xb1e40c        | if (clipName != null) goto label_10;    
        if(clipName != null)
        {
            goto label_10;
        }
        // 0x00B1E408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_10:
        // 0x00B1E40C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E410: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E414: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_5 = clipName.gameObject;
        // 0x00B1E418: MOV x23, x0                | X23 = val_5;//m1                        
        // 0x00B1E41C: CBNZ x23, #0xb1e424        | if (val_5 != null) goto label_11;       
        if(val_5 != null)
        {
            goto label_11;
        }
        // 0x00B1E420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_11:
        // 0x00B1E424: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00B1E428: LDR x8, [x8, #0xb30]       | X8 = 1152921514151411312;               
        // 0x00B1E42C: MOV x0, x23                | X0 = val_5;//m1                         
        // 0x00B1E430: LDR x1, [x8]               | X1 = public T[] UnityEngine.GameObject::GetComponentsInChildren<UIPanel>();
        // 0x00B1E434: BL #0x23d8d60              | X0 = val_5.GetComponentsInChildren<UIPanel>();
        T[] val_6 = val_5.GetComponentsInChildren<UIPanel>();
        // 0x00B1E438: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x00B1E43C: CBNZ x23, #0xb1e444        | if (val_6 != null) goto label_12;       
        if(val_6 != null)
        {
            goto label_12;
        }
        // 0x00B1E440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00B1E444: LDR x25, [x23, #0x18]      | X25 = val_6.Length; //P2                
        // 0x00B1E448: CMP w25, #1                | STATE = COMPARE(val_6.Length, 0x1)      
        // 0x00B1E44C: B.LT #0xb1e49c             | if (val_6.Length < 1) goto label_13;    
        if(val_6.Length < 1)
        {
            goto label_13;
        }
        // 0x00B1E450: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x00B1E454: ADD x27, x23, #0x20        | X27 = val_6[0x20]; //PARR1              
        label_17:
        // 0x00B1E458: CBNZ x23, #0xb1e460        | if (val_6 != null) goto label_14;       
        if(val_6 != null)
        {
            goto label_14;
        }
        // 0x00B1E45C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00B1E460: LDR w8, [x23, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x00B1E464: CMP x26, x8                | STATE = COMPARE(0x0, val_6.Length)      
        // 0x00B1E468: B.LO #0xb1e478             | if (0 < val_6.Length) goto label_15;    
        if(val_13 < val_6.Length)
        {
            goto label_15;
        }
        // 0x00B1E46C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
        // 0x00B1E470: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E474: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
        label_15:
        // 0x00B1E478: LDR x24, [x27, x26, lsl #3] | X24 = typeof(T[]);                      
        // 0x00B1E47C: CBNZ x24, #0xb1e484        | if (typeof(T[]) != null) goto label_16; 
        if(null != null)
        {
            goto label_16;
        }
        // 0x00B1E480: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_16:
        // 0x00B1E484: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E488: MOV x0, x24                | X0 = 1152921505605890016 (0x100000003B8C2FE0);//ML01
        // 0x00B1E48C: BL #0xfbdf18               | 1152921505605890016.Refresh();          
        1152921505605890016.Refresh();
        // 0x00B1E490: ADD x26, x26, #1           | X26 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x00B1E494: CMP w25, w26               | STATE = COMPARE(val_6.Length, (0 + 1))  
        // 0x00B1E498: B.NE #0xb1e458             | if (val_6.Length != 0) goto label_17;   
        if(val_6.Length != val_13)
        {
            goto label_17;
        }
        label_13:
        // 0x00B1E49C: CBNZ x22, #0xb1e4a4        | if (clipName != null) goto label_18;    
        if(clipName != null)
        {
            goto label_18;
        }
        // 0x00B1E4A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(T[]), ????);
        label_18:
        // 0x00B1E4A4: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00B1E4A8: LDR x8, [x8, #0x598]       | X8 = 1152921514151449200;               
        // 0x00B1E4AC: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E4B0: LDR x1, [x8]               | X1 = public ActiveAnimation UnityEngine.Component::GetComponent<ActiveAnimation>();
        // 0x00B1E4B4: BL #0x23d5410              | X0 = clipName.GetComponent<ActiveAnimation>();
        ActiveAnimation val_7 = clipName.GetComponent<ActiveAnimation>();
        // 0x00B1E4B8: ADRP x24, #0x35fe000       | X24 = 56614912 (0x35FE000);             
        // 0x00B1E4BC: LDR x24, [x24, #0x810]     | X24 = 1152921504697475072;              
        // 0x00B1E4C0: MOV x23, x0                | X23 = val_7;//m1                        
        val_16 = val_7;
        // 0x00B1E4C4: LDR x8, [x24]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B1E4C8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E4CC: TBZ w9, #0, #0xb1e4e0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B1E4D0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E4D4: CBNZ w9, #0xb1e4e0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B1E4D8: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B1E4DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_20:
        // 0x00B1E4E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E4E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E4E8: MOV x1, x23                | X1 = val_7;//m1                         
        // 0x00B1E4EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E4F0: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_16);
        bool val_8 = UnityEngine.Object.op_Equality(x:  0, y:  val_16);
        // 0x00B1E4F4: TBZ w0, #0, #0xb1e530      | if (val_8 == false) goto label_21;      
        if(val_8 == false)
        {
            goto label_21;
        }
        // 0x00B1E4F8: CBNZ x22, #0xb1e500        | if (clipName != null) goto label_22;    
        if(clipName != null)
        {
            goto label_22;
        }
        // 0x00B1E4FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_22:
        // 0x00B1E500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E504: MOV x0, x22                | X0 = clipName;//m1                      
        // 0x00B1E508: BL #0x20d50fc              | X0 = clipName.get_gameObject();         
        UnityEngine.GameObject val_9 = clipName.gameObject;
        // 0x00B1E50C: MOV x23, x0                | X23 = val_9;//m1                        
        // 0x00B1E510: CBNZ x23, #0xb1e518        | if (val_9 != null) goto label_23;       
        if(val_9 != null)
        {
            goto label_23;
        }
        // 0x00B1E514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_23:
        // 0x00B1E518: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B1E51C: LDR x8, [x8, #0xd18]       | X8 = 1152921514151458416;               
        // 0x00B1E520: MOV x0, x23                | X0 = val_9;//m1                         
        // 0x00B1E524: LDR x1, [x8]               | X1 = public ActiveAnimation UnityEngine.GameObject::AddComponent<ActiveAnimation>();
        // 0x00B1E528: BL #0x23d5984              | X0 = val_9.AddComponent<ActiveAnimation>();
        ActiveAnimation val_10 = val_9.AddComponent<ActiveAnimation>();
        // 0x00B1E52C: MOV x23, x0                | X23 = val_10;//m1                       
        val_16 = val_10;
        label_21:
        // 0x00B1E530: CBZ x23, #0xb1e544         | if (val_10 == null) goto label_24;      
        if(val_16 == null)
        {
            goto label_24;
        }
        // 0x00B1E534: MOV x25, x23               | X25 = val_10;//m1                       
        val_15 = val_16;
        // 0x00B1E538: STR x22, [x25, #0x48]!     | val_10.mAnimator = clipName;             //  dest_result_addr=0
        val_10.mAnimator = clipName;
        // 0x00B1E53C: STUR w21, [x25, #-0xc]     | mem2[0] = W5;                            //  dest_result_addr=0
        mem2[0] = val_13;
        // 0x00B1E540: B #0xb1e55c                |  goto label_25;                         
        goto label_25;
        label_24:
        // 0x00B1E544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B1E548: MOVZ w25, #0x48            | W25 = 72 (0x48);//ML01                  
        val_15 = 72;
        // 0x00B1E54C: STR x22, [x25]             | mem[72] = clipName;                      //  dest_result_addr=72
        mem[72] = clipName;
        // 0x00B1E550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00B1E554: STR w21, [x23, #0x3c]      | val_10.mDisableDirection = W5;           //  dest_result_addr=0
        val_10.mDisableDirection = val_13;
        // 0x00B1E558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_25:
        // 0x00B1E55C: LDR x21, [x23, #0x18]      | X21 = val_10.onFinished; //P2           
        val_13 = val_10.onFinished;
        // 0x00B1E560: CBNZ x21, #0xb1e568        | if (val_10.onFinished != null) goto label_26;
        if(val_13 != null)
        {
            goto label_26;
        }
        // 0x00B1E564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_26:
        // 0x00B1E568: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B1E56C: LDR x8, [x8, #0x638]       | X8 = 1152921510859177456;               
        // 0x00B1E570: MOV x0, x21                | X0 = val_10.onFinished;//m1             
        // 0x00B1E574: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<EventDelegate>::Clear();
        // 0x00B1E578: BL #0x25ead28              | val_10.onFinished.Clear();              
        val_13.Clear();
        // 0x00B1E57C: MOV x0, x23                | X0 = val_10;//m1                        
        // 0x00B1E580: MOV x1, x20                | X1 = playDirection;//m1                 
        // 0x00B1E584: MOV w2, w19                | W2 = enableBeforePlay;//m1              
        // 0x00B1E588: BL #0xb1d90c               | val_10.Play(clipName:  playDirection, playDirection:  val_14);
        val_16.Play(clipName:  playDirection, playDirection:  val_14);
        // 0x00B1E58C: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1E590: LDR x19, [x23, #0x30]      | X19 = val_10.mAnim; //P2                
        // 0x00B1E594: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E598: TBZ w8, #0, #0xb1e5a8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x00B1E59C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E5A0: CBNZ w8, #0xb1e5a8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x00B1E5A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_28:
        // 0x00B1E5A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E5AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E5B0: MOV x1, x19                | X1 = val_10.mAnim;//m1                  
        // 0x00B1E5B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E5B8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_10.mAnim);
        bool val_11 = UnityEngine.Object.op_Inequality(x:  0, y:  val_10.mAnim);
        // 0x00B1E5BC: TBZ w0, #0, #0xb1e5dc      | if (val_11 == false) goto label_29;     
        if(val_11 == false)
        {
            goto label_29;
        }
        // 0x00B1E5C0: LDR x19, [x23, #0x30]      | X19 = val_10.mAnim; //P2                
        val_14 = val_10.mAnim;
        // 0x00B1E5C4: CBNZ x19, #0xb1e5cc        | if (val_10.mAnim != null) goto label_30;
        if(val_14 != null)
        {
            goto label_30;
        }
        // 0x00B1E5C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_30:
        // 0x00B1E5CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E5D0: MOV x0, x19                | X0 = val_10.mAnim;//m1                  
        // 0x00B1E5D4: BL #0x270c344              | val_10.mAnim.Sample();                  
        val_14.Sample();
        // 0x00B1E5D8: B #0xb1e63c                |  goto label_37;                         
        goto label_37;
        label_29:
        // 0x00B1E5DC: LDR x0, [x24]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B1E5E0: LDR x19, [x25]             | X19 = clipName;                         
        val_14 = mem[72];
        // 0x00B1E5E4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B1E5E8: TBZ w8, #0, #0xb1e5f8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x00B1E5EC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B1E5F0: CBNZ w8, #0xb1e5f8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x00B1E5F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_33:
        // 0x00B1E5F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E5FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B1E600: MOV x1, x19                | X1 = clipName;//m1                      
        // 0x00B1E604: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B1E608: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_14);
        bool val_12 = UnityEngine.Object.op_Inequality(x:  0, y:  val_14);
        // 0x00B1E60C: TBZ w0, #0, #0xb1e63c      | if (val_12 == false) goto label_37;     
        if(val_12 == false)
        {
            goto label_37;
        }
        // 0x00B1E610: CBNZ x23, #0xb1e618        | if (val_10 != null) goto label_35;      
        if(val_16 != null)
        {
            goto label_35;
        }
        // 0x00B1E614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_35:
        // 0x00B1E618: LDR x19, [x25]             | X19 = clipName;                         
        val_14 = mem[72];
        // 0x00B1E61C: CBNZ x19, #0xb1e624        | if (clipName != 0) goto label_36;       
        if(val_14 != 0)
        {
            goto label_36;
        }
        // 0x00B1E620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_36:
        // 0x00B1E624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B1E628: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B1E62C: MOV x0, x19                | X0 = clipName;//m1                      
        // 0x00B1E630: BL #0x2713df0              | clipName.Update(deltaTime:  0f);        
        val_14.Update(deltaTime:  0f);
        // 0x00B1E634: B #0xb1e63c                |  goto label_37;                         
        goto label_37;
        label_6:
        // 0x00B1E638: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_16 = 0;
        label_37:
        // 0x00B1E63C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
        // 0x00B1E640: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1E644: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B1E648: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B1E64C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B1E650: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B1E654: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B1E658: RET                        |  return (ActiveAnimation)null;          
        return (ActiveAnimation)val_16;
        //  |  // // {name=val_0, type=ActiveAnimation, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B1E65C (11658844), len: 92  VirtAddr: 0x00B1E65C RVA: 0x00B1E65C token: 100687846 methodIndex: 24681 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnDestory()
    {
        //
        // Disasemble & Code
        // 0x00B1E65C: STP x20, x19, [sp, #-0x20]! | stack[1152921514152263472] = ???;  stack[1152921514152263480] = ???;  //  dest_result_addr=1152921514152263472 |  dest_result_addr=1152921514152263480
        // 0x00B1E660: STP x29, x30, [sp, #0x10]  | stack[1152921514152263488] = ???;  stack[1152921514152263496] = ???;  //  dest_result_addr=1152921514152263488 |  dest_result_addr=1152921514152263496
        // 0x00B1E664: ADD x29, sp, #0x10         | X29 = (1152921514152263472 + 16) = 1152921514152263488 (0x1000000238F37F40);
        // 0x00B1E668: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B1E66C: LDRB w8, [x20, #0x710]     | W8 = (bool)static_value_03733710;       
        // 0x00B1E670: MOV x19, x0                | X19 = 1152921514152275504 (0x1000000238F3AE30);//ML01
        // 0x00B1E674: TBNZ w8, #0, #0xb1e690     | if (static_value_03733710 == true) goto label_0;
        // 0x00B1E678: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00B1E67C: LDR x8, [x8, #0xc90]       | X8 = 0x2B8A9A0;                         
        // 0x00B1E680: LDR w0, [x8]               | W0 = 0x126;                             
        // 0x00B1E684: BL #0x2782188              | X0 = sub_2782188( ?? 0x126, ????);      
        // 0x00B1E688: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B1E68C: STRB w8, [x20, #0x710]     | static_value_03733710 = true;            //  dest_result_addr=57882384
        label_0:
        // 0x00B1E690: LDR x19, [x19, #0x18]      | X19 = this.onFinished; //P2             
        // 0x00B1E694: CBNZ x19, #0xb1e69c        | if (this.onFinished != null) goto label_1;
        if(this.onFinished != null)
        {
            goto label_1;
        }
        // 0x00B1E698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x126, ????);      
        label_1:
        // 0x00B1E69C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B1E6A0: LDR x8, [x8, #0x638]       | X8 = 1152921510859177456;               
        // 0x00B1E6A4: MOV x0, x19                | X0 = this.onFinished;//m1               
        // 0x00B1E6A8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<EventDelegate>::Clear();
        // 0x00B1E6AC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B1E6B0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B1E6B4: B #0x25ead28               | this.onFinished.Clear(); return;        
        this.onFinished.Clear();
        return;
    
    }

}
