using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x286734C
[UnityEngine.RequireComponent] // 0x286734C
public class AnimatedColor : MonoBehaviour
{
    // Fields
    public UnityEngine.Color color; //  0x00000018
    private UIWidget mWidget; //  0x00000028
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B27460 (11695200), len: 56  VirtAddr: 0x00B27460 RVA: 0x00B27460 token: 100688420 methodIndex: 24781 delegateWrapperIndex: 0 methodInvoker: 0
    public AnimatedColor()
    {
        //
        // Disasemble & Code
        // 0x00B27460: STP x20, x19, [sp, #-0x20]! | stack[1152921514236992672] = ???;  stack[1152921514236992680] = ???;  //  dest_result_addr=1152921514236992672 |  dest_result_addr=1152921514236992680
        // 0x00B27464: STP x29, x30, [sp, #0x10]  | stack[1152921514236992688] = ???;  stack[1152921514236992696] = ???;  //  dest_result_addr=1152921514236992688 |  dest_result_addr=1152921514236992696
        // 0x00B27468: ADD x29, sp, #0x10         | X29 = (1152921514236992672 + 16) = 1152921514236992688 (0x100000023E005CB0);
        // 0x00B2746C: MOV x19, x0                | X19 = 1152921514237004704 (0x100000023E008BA0);//ML01
        // 0x00B27470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B27474: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27478: BL #0x20d3be4              | X0 = UnityEngine.Color.get_white();     
        UnityEngine.Color val_1 = UnityEngine.Color.white;
        // 0x00B2747C: STP s0, s1, [x19, #0x18]   | this.color = val_1;  mem[1152921514237004732] = val_1.g;  //  dest_result_addr=1152921514237004728 |  dest_result_addr=1152921514237004732
        this.color = val_1;
        mem[1152921514237004732] = val_1.g;
        // 0x00B27480: STP s2, s3, [x19, #0x20]   | mem[1152921514237004736] = val_1.b;  mem[1152921514237004740] = val_1.a;  //  dest_result_addr=1152921514237004736 |  dest_result_addr=1152921514237004740
        mem[1152921514237004736] = val_1.b;
        mem[1152921514237004740] = val_1.a;
        // 0x00B27484: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B27488: MOV x0, x19                | X0 = 1152921514237004704 (0x100000023E008BA0);//ML01
        // 0x00B2748C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27490: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B27494: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B27498 (11695256), len: 92  VirtAddr: 0x00B27498 RVA: 0x00B27498 token: 100688421 methodIndex: 24782 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEnable()
    {
        //
        // Disasemble & Code
        // 0x00B27498: STP x20, x19, [sp, #-0x20]! | stack[1152921514237108768] = ???;  stack[1152921514237108776] = ???;  //  dest_result_addr=1152921514237108768 |  dest_result_addr=1152921514237108776
        // 0x00B2749C: STP x29, x30, [sp, #0x10]  | stack[1152921514237108784] = ???;  stack[1152921514237108792] = ???;  //  dest_result_addr=1152921514237108784 |  dest_result_addr=1152921514237108792
        // 0x00B274A0: ADD x29, sp, #0x10         | X29 = (1152921514237108768 + 16) = 1152921514237108784 (0x100000023E022230);
        // 0x00B274A4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B274A8: LDRB w8, [x20, #0x74a]     | W8 = (bool)static_value_0373374A;       
        // 0x00B274AC: MOV x19, x0                | X19 = 1152921514237120800 (0x100000023E025120);//ML01
        // 0x00B274B0: TBNZ w8, #0, #0xb274cc     | if (static_value_0373374A == true) goto label_0;
        // 0x00B274B4: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00B274B8: LDR x8, [x8, #0x6d0]       | X8 = 0x2B8AD90;                         
        // 0x00B274BC: LDR w0, [x8]               | W0 = 0x222;                             
        // 0x00B274C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x222, ????);      
        // 0x00B274C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B274C8: STRB w8, [x20, #0x74a]     | static_value_0373374A = true;            //  dest_result_addr=57882442
        label_0:
        // 0x00B274CC: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00B274D0: LDR x8, [x8, #0x940]       | X8 = 1152921511725110736;               
        // 0x00B274D4: MOV x0, x19                | X0 = 1152921514237120800 (0x100000023E025120);//ML01
        // 0x00B274D8: LDR x1, [x8]               | X1 = public UIWidget UnityEngine.Component::GetComponent<UIWidget>();
        // 0x00B274DC: BL #0x23d5410              | X0 = this.GetComponent<UIWidget>();     
        UIWidget val_1 = this.GetComponent<UIWidget>();
        // 0x00B274E0: STR x0, [x19, #0x28]       | this.mWidget = val_1;                    //  dest_result_addr=1152921514237120840
        this.mWidget = val_1;
        // 0x00B274E4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B274E8: MOV x0, x19                | X0 = 1152921514237120800 (0x100000023E025120);//ML01
        // 0x00B274EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B274F0: B #0xb274f4                | this.LateUpdate(); return;              
        this.LateUpdate();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B274F4 (11695348), len: 84  VirtAddr: 0x00B274F4 RVA: 0x00B274F4 token: 100688422 methodIndex: 24783 delegateWrapperIndex: 0 methodInvoker: 0
    private void LateUpdate()
    {
        //
        // Disasemble & Code
        // 0x00B274F4: STP d11, d10, [sp, #-0x40]! | stack[1152921514237228928] = ???;  stack[1152921514237228936] = ???;  //  dest_result_addr=1152921514237228928 |  dest_result_addr=1152921514237228936
        // 0x00B274F8: STP d9, d8, [sp, #0x10]    | stack[1152921514237228944] = ???;  stack[1152921514237228952] = ???;  //  dest_result_addr=1152921514237228944 |  dest_result_addr=1152921514237228952
        // 0x00B274FC: STP x20, x19, [sp, #0x20]  | stack[1152921514237228960] = ???;  stack[1152921514237228968] = ???;  //  dest_result_addr=1152921514237228960 |  dest_result_addr=1152921514237228968
        // 0x00B27500: STP x29, x30, [sp, #0x30]  | stack[1152921514237228976] = ???;  stack[1152921514237228984] = ???;  //  dest_result_addr=1152921514237228976 |  dest_result_addr=1152921514237228984
        // 0x00B27504: ADD x29, sp, #0x30         | X29 = (1152921514237228928 + 48) = 1152921514237228976 (0x100000023E03F7B0);
        // 0x00B27508: LDR x19, [x0, #0x28]       | X19 = this.mWidget; //P2                
        // 0x00B2750C: LDP s8, s9, [x0, #0x18]    | S8 = this.color; //P2                    //  | 
        // 0x00B27510: LDP s10, s11, [x0, #0x20]  |                                          //  | 
        // 0x00B27514: CBNZ x19, #0xb2751c        | if (this.mWidget != null) goto label_0; 
        if(this.mWidget != null)
        {
            goto label_0;
        }
        // 0x00B27518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B2751C: MOV x0, x19                | X0 = this.mWidget;//m1                  
        // 0x00B27520: MOV v0.16b, v8.16b         | V0 = this.color;//m1                    
        // 0x00B27524: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00B27528: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00B2752C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00B27530: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B27534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B27538: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00B2753C: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x00B27540: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
        // 0x00B27544: B #0x1528e7c               | this.mWidget.set_color(value:  new UnityEngine.Color() {r = this.color, g = V9.16B, b = V10.16B, a = V11.16B}); return;
        this.mWidget.color = new UnityEngine.Color() {r = this.color, g = V9.16B, b = V10.16B, a = V11.16B};
        return;
    
    }

}
