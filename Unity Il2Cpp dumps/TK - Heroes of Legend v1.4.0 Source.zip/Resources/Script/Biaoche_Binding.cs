using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class Biaoche_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BC9944 (12360004), len: 8  VirtAddr: 0x00BC9944 RVA: 0x00BC9944 token: 100663849 methodIndex: 29894 delegateWrapperIndex: 0 methodInvoker: 0
        public Biaoche_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BC9944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9948: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC994C (12360012), len: 2304  VirtAddr: 0x00BC994C RVA: 0x00BC994C token: 100663850 methodIndex: 29895 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_22;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_23;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_24;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_26;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_28;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_30;
            // 0x00BC994C: STP x28, x27, [sp, #-0x60]! | stack[1152921510058818624] = ???;  stack[1152921510058818632] = ???;  //  dest_result_addr=1152921510058818624 |  dest_result_addr=1152921510058818632
            // 0x00BC9950: STP x26, x25, [sp, #0x10]  | stack[1152921510058818640] = ???;  stack[1152921510058818648] = ???;  //  dest_result_addr=1152921510058818640 |  dest_result_addr=1152921510058818648
            // 0x00BC9954: STP x24, x23, [sp, #0x20]  | stack[1152921510058818656] = ???;  stack[1152921510058818664] = ???;  //  dest_result_addr=1152921510058818656 |  dest_result_addr=1152921510058818664
            // 0x00BC9958: STP x22, x21, [sp, #0x30]  | stack[1152921510058818672] = ???;  stack[1152921510058818680] = ???;  //  dest_result_addr=1152921510058818672 |  dest_result_addr=1152921510058818680
            // 0x00BC995C: STP x20, x19, [sp, #0x40]  | stack[1152921510058818688] = ???;  stack[1152921510058818696] = ???;  //  dest_result_addr=1152921510058818688 |  dest_result_addr=1152921510058818696
            // 0x00BC9960: STP x29, x30, [sp, #0x50]  | stack[1152921510058818704] = ???;  stack[1152921510058818712] = ???;  //  dest_result_addr=1152921510058818704 |  dest_result_addr=1152921510058818712
            // 0x00BC9964: ADD x29, sp, #0x50         | X29 = (1152921510058818624 + 80) = 1152921510058818704 (0x1000000144F67C90);
            // 0x00BC9968: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC996C: LDRB w8, [x20, #0xbb1]     | W8 = (bool)static_value_03733BB1;       
            // 0x00BC9970: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC9974: TBNZ w8, #0, #0xbc9990     | if (static_value_03733BB1 == true) goto label_0;
            // 0x00BC9978: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00BC997C: LDR x8, [x8, #8]           | X8 = 0x2B8F3A0;                         
            // 0x00BC9980: LDR w0, [x8]               | W0 = 0x13AA;                            
            // 0x00BC9984: BL #0x2782188              | X0 = sub_2782188( ?? 0x13AA, ????);     
            // 0x00BC9988: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC998C: STRB w8, [x20, #0xbb1]     | static_value_03733BB1 = true;            //  dest_result_addr=57883569
            label_0:
            // 0x00BC9990: ADRP x26, #0x3620000       | X26 = 56754176 (0x3620000);             
            // 0x00BC9994: LDR x26, [x26, #0x340]     | X26 = 1152921504609562624;              
            // 0x00BC9998: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BC999C: LDR x0, [x26]              | X0 = typeof(System.Type);               
            // 0x00BC99A0: LDR x8, [x8, #0xc50]       | X8 = 1152921504893906944;               
            // 0x00BC99A4: LDR x20, [x8]              | X20 = typeof(Biaoche);                  
            // 0x00BC99A8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC99AC: TBZ w8, #0, #0xbc99bc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BC99B0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC99B4: CBNZ w8, #0xbc99bc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BC99B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BC99BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC99C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC99C4: MOV x1, x20                | X1 = 1152921504893906944 (0x10000000111C3000);//ML01
            // 0x00BC99C8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC99CC: ADRP x25, #0x35ef000       | X25 = 56553472 (0x35EF000);             
            // 0x00BC99D0: LDR x25, [x25, #0xff0]     | X25 = 1152921504987155056;              
            // 0x00BC99D4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BC99D8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BC99DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC99E0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC99E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC99E8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC99EC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC99F0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC99F4: CBNZ x20, #0xbc99fc        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BC99F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x00BC99FC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00BC9A00: LDR x8, [x8, #0x2a0]       | X8 = (string**)(1152921510058748816)("get_MoveJindu");
            // 0x00BC9A04: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9A08: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC9A0C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC9A10: LDR x1, [x8]               | X1 = "get_MoveJindu";                   
            // 0x00BC9A14: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC9A18: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9A1C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC9A20: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_MoveJindu", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_MoveJindu", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC9A24: ADRP x24, #0x365f000       | X24 = 57012224 (0x365F000);             
            // 0x00BC9A28: LDR x24, [x24, #0x900]     | X24 = 1152921504783097856;              
            // 0x00BC9A2C: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00BC9A30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9A34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9A38: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache0;
            val_22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache0;
            // 0x00BC9A3C: CBNZ x22, #0xbc9a88        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_22 != null)
            {
                goto label_4;
            }
            // 0x00BC9A40: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x00BC9A44: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC9A48: LDR x8, [x8, #0xfb0]       | X8 = 1152921510058753008;               
            // 0x00BC9A4C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC9A50: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::get_MoveJindu_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC9A54: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_3 = null;
            // 0x00BC9A58: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC9A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9A60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9A64: MOV x2, x22                | X2 = 1152921510058753008 (0x1000000144F57BF0);//ML01
            // 0x00BC9A68: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_3;
            // 0x00BC9A6C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::get_MoveJindu_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::get_MoveJindu_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC9A70: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9A74: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9A78: STR x23, [x8]              | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783101952
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache0 = val_23;
            // 0x00BC9A7C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9A80: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9A84: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BC9A88: CBNZ x19, #0xbc9a90        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BC9A8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::get_MoveJindu_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_5:
            // 0x00BC9A90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9A94: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC9A98: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x00BC9A9C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC9AA0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_22);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  val_22);
            // 0x00BC9AA4: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BC9AA8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9AAC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC9AB0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC9AB4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9AB8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC9ABC: ADRP x9, #0x3611000        | X9 = 56692736 (0x3611000);              
            // 0x00BC9AC0: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BC9AC4: LDR x9, [x9, #0x9a8]       | X9 = 1152921504607113216;               
            // 0x00BC9AC8: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9ACC: LDR x22, [x9]              | X22 = typeof(System.Int32);             
            // 0x00BC9AD0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC9AD4: TBZ w9, #0, #0xbc9ae8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BC9AD8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9ADC: CBNZ w9, #0xbc9ae8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BC9AE0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC9AE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_7:
            // 0x00BC9AE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9AEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9AF0: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x00BC9AF4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9AF8: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BC9AFC: CBNZ x21, #0xbc9b04        | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x00BC9B00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x00BC9B04: CBZ x22, #0xbc9b28         | if (val_4 == null) goto label_10;       
            if(val_4 == null)
            {
                goto label_10;
            }
            // 0x00BC9B08: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC9B0C: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00BC9B10: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC9B14: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00BC9B18: CBNZ x0, #0xbc9b28         | if (val_4 != null) goto label_10;       
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x00BC9B1C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00BC9B20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9B24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_10:
            // 0x00BC9B28: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC9B2C: CBNZ w8, #0xbc9b3c         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_11;
            // 0x00BC9B30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00BC9B34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9B38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_11:
            // 0x00BC9B3C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_4;
            // 0x00BC9B40: CBNZ x20, #0xbc9b48        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BC9B44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x00BC9B48: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00BC9B4C: LDR x8, [x8, #0xdc0]       | X8 = (string**)(1152921510058758128)("OnTriggerFun");
            // 0x00BC9B50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9B54: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC9B58: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC9B5C: LDR x1, [x8]               | X1 = "OnTriggerFun";                    
            // 0x00BC9B60: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC9B64: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9B68: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC9B6C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "OnTriggerFun", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_5 = val_1.GetMethod(name:  "OnTriggerFun", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC9B70: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9B74: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x00BC9B78: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9B7C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache1;
            val_24 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache1;
            // 0x00BC9B80: CBNZ x22, #0xbc9bcc        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache1 != null) goto label_13;
            if(val_24 != null)
            {
                goto label_13;
            }
            // 0x00BC9B84: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00BC9B88: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC9B8C: LDR x8, [x8, #0x9f8]       | X8 = 1152921510058762320;               
            // 0x00BC9B90: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC9B94: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::OnTriggerFun_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC9B98: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_6 = null;
            // 0x00BC9B9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC9BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9BA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9BA8: MOV x2, x22                | X2 = 1152921510058762320 (0x1000000144F5A050);//ML01
            // 0x00BC9BAC: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_6;
            // 0x00BC9BB0: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::OnTriggerFun_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::OnTriggerFun_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC9BB4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9BB8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9BBC: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783101960
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache1 = val_23;
            // 0x00BC9BC0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9BC4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9BC8: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_24 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache1;
            label_13:
            // 0x00BC9BCC: CBNZ x19, #0xbc9bd4        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BC9BD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::OnTriggerFun_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x00BC9BD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9BD8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC9BDC: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x00BC9BE0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC9BE4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_5, func:  val_24);
            X1.RegisterCLRMethodRedirection(mi:  val_5, func:  val_24);
            // 0x00BC9BE8: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BC9BEC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9BF0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC9BF4: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00BC9BF8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9BFC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC9C00: ADRP x9, #0x3608000        | X9 = 56655872 (0x3608000);              
            // 0x00BC9C04: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BC9C08: LDR x9, [x9, #0xf50]       | X9 = 1152921504890179584;               
            // 0x00BC9C0C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9C10: LDR x22, [x9]              | X22 = typeof(monstersCfg);              
            // 0x00BC9C14: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC9C18: TBZ w9, #0, #0xbc9c2c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00BC9C1C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9C20: CBNZ w9, #0xbc9c2c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00BC9C24: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC9C28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_16:
            // 0x00BC9C2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9C30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9C34: MOV x1, x22                | X1 = 1152921504890179584 (0x1000000010E35000);//ML01
            // 0x00BC9C38: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9C3C: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00BC9C40: CBNZ x21, #0xbc9c48        | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x00BC9C44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_17:
            // 0x00BC9C48: CBZ x22, #0xbc9c6c         | if (val_7 == null) goto label_19;       
            if(val_7 == null)
            {
                goto label_19;
            }
            // 0x00BC9C4C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC9C50: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x00BC9C54: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC9C58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x00BC9C5C: CBNZ x0, #0xbc9c6c         | if (val_7 != null) goto label_19;       
            if(val_7 != null)
            {
                goto label_19;
            }
            // 0x00BC9C60: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x00BC9C64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9C68: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_19:
            // 0x00BC9C6C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC9C70: CBNZ w8, #0xbc9c80         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_20;
            // 0x00BC9C74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x00BC9C78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9C7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_20:
            // 0x00BC9C80: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_7;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_7;
            // 0x00BC9C84: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00BC9C88: LDR x8, [x8, #0x6d8]       | X8 = 1152921504891351040;               
            // 0x00BC9C8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9C90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9C94: LDR x1, [x8]               | X1 = typeof(JSCLevelMonsterConfig);     
            // 0x00BC9C98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9C9C: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00BC9CA0: CBZ x22, #0xbc9cc4         | if (val_8 == null) goto label_22;       
            if(val_8 == null)
            {
                goto label_22;
            }
            // 0x00BC9CA4: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC9CA8: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x00BC9CAC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC9CB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x00BC9CB4: CBNZ x0, #0xbc9cc4         | if (val_8 != null) goto label_22;       
            if(val_8 != null)
            {
                goto label_22;
            }
            // 0x00BC9CB8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x00BC9CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9CC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_22:
            // 0x00BC9CC4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC9CC8: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00BC9CCC: B.HI #0xbc9cdc             | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_23;
            // 0x00BC9CD0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x00BC9CD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9CD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_23:
            // 0x00BC9CDC: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_8;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_8;
            // 0x00BC9CE0: CBNZ x20, #0xbc9ce8        | if (val_1 != null) goto label_24;       
            if(val_1 != null)
            {
                goto label_24;
            }
            // 0x00BC9CE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_24:
            // 0x00BC9CE8: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00BC9CEC: LDR x8, [x8, #0x60]        | X8 = (string**)(1152921510058771536)("Create");
            // 0x00BC9CF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9CF4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC9CF8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC9CFC: LDR x1, [x8]               | X1 = "Create";                          
            // 0x00BC9D00: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC9D04: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9D08: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC9D0C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Create", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_9 = val_1.GetMethod(name:  "Create", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC9D10: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9D14: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x00BC9D18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9D1C: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache2;
            val_25 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache2;
            // 0x00BC9D20: CBNZ x22, #0xbc9d6c        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache2 != null) goto label_25;
            if(val_25 != null)
            {
                goto label_25;
            }
            // 0x00BC9D24: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC9D28: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC9D2C: LDR x8, [x8, #0xa30]       | X8 = 1152921510058775712;               
            // 0x00BC9D30: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC9D34: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Create_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC9D38: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_10 = null;
            // 0x00BC9D3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC9D40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9D44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9D48: MOV x2, x22                | X2 = 1152921510058775712 (0x1000000144F5D4A0);//ML01
            // 0x00BC9D4C: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_10;
            // 0x00BC9D50: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Create_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_10 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Create_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC9D54: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9D58: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9D5C: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783101968
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache2 = val_23;
            // 0x00BC9D60: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9D64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9D68: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_25 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache2;
            label_25:
            // 0x00BC9D6C: CBNZ x19, #0xbc9d74        | if (X1 != 0) goto label_26;             
            if(X1 != 0)
            {
                goto label_26;
            }
            // 0x00BC9D70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Create_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_26:
            // 0x00BC9D74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9D78: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC9D7C: MOV x1, x21                | X1 = val_9;//m1                         
            // 0x00BC9D80: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC9D84: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_9, func:  val_25);
            X1.RegisterCLRMethodRedirection(mi:  val_9, func:  val_25);
            // 0x00BC9D88: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BC9D8C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9D90: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC9D94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9D98: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9D9C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC9DA0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9DA4: CBNZ x20, #0xbc9dac        | if (val_1 != null) goto label_27;       
            if(val_1 != null)
            {
                goto label_27;
            }
            // 0x00BC9DA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_27:
            // 0x00BC9DAC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00BC9DB0: LDR x8, [x8, #0x3a8]       | X8 = (string**)(1152921510033340128)("Update");
            // 0x00BC9DB4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9DB8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC9DBC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC9DC0: LDR x1, [x8]               | X1 = "Update";                          
            // 0x00BC9DC4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC9DC8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9DCC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC9DD0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Update", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_11 = val_1.GetMethod(name:  "Update", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC9DD4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9DD8: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x00BC9DDC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9DE0: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache3;
            val_26 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache3;
            // 0x00BC9DE4: CBNZ x22, #0xbc9e30        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache3 != null) goto label_28;
            if(val_26 != null)
            {
                goto label_28;
            }
            // 0x00BC9DE8: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x00BC9DEC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC9DF0: LDR x8, [x8, #0x848]       | X8 = 1152921510058780832;               
            // 0x00BC9DF4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC9DF8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Update_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC9DFC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12 = null;
            // 0x00BC9E00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC9E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9E08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9E0C: MOV x2, x22                | X2 = 1152921510058780832 (0x1000000144F5E8A0);//ML01
            // 0x00BC9E10: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_12;
            // 0x00BC9E14: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Update_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Update_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC9E18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9E1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9E20: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783101976
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache3 = val_23;
            // 0x00BC9E24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9E28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9E2C: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_26 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache3;
            label_28:
            // 0x00BC9E30: CBNZ x19, #0xbc9e38        | if (X1 != 0) goto label_29;             
            if(X1 != 0)
            {
                goto label_29;
            }
            // 0x00BC9E34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Update_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_29:
            // 0x00BC9E38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9E3C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC9E40: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x00BC9E44: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC9E48: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_11, func:  val_26);
            X1.RegisterCLRMethodRedirection(mi:  val_11, func:  val_26);
            // 0x00BC9E4C: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BC9E50: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9E54: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC9E58: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC9E5C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9E60: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC9E64: ADRP x27, #0x3615000       | X27 = 56709120 (0x3615000);             
            // 0x00BC9E68: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BC9E6C: LDR x27, [x27, #0x668]     | X27 = 1152921504898326528;              
            // 0x00BC9E70: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9E74: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC9E78: LDR x22, [x27]             | X22 = typeof(CEvent.ZEvent);            
            // 0x00BC9E7C: TBZ w9, #0, #0xbc9e90      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x00BC9E80: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9E84: CBNZ w9, #0xbc9e90         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x00BC9E88: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC9E8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_31:
            // 0x00BC9E90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9E94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9E98: MOV x1, x22                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00BC9E9C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9EA0: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x00BC9EA4: CBNZ x21, #0xbc9eac        | if ( != null) goto label_32;            
            if(null != null)
            {
                goto label_32;
            }
            // 0x00BC9EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_32:
            // 0x00BC9EAC: CBZ x22, #0xbc9ed0         | if (val_13 == null) goto label_34;      
            if(val_13 == null)
            {
                goto label_34;
            }
            // 0x00BC9EB0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC9EB4: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x00BC9EB8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC9EBC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x00BC9EC0: CBNZ x0, #0xbc9ed0         | if (val_13 != null) goto label_34;      
            if(val_13 != null)
            {
                goto label_34;
            }
            // 0x00BC9EC4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x00BC9EC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9ECC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_34:
            // 0x00BC9ED0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BC9ED4: CBNZ w8, #0xbc9ee4         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_35;
            // 0x00BC9ED8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x00BC9EDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9EE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_35:
            // 0x00BC9EE4: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;
            // 0x00BC9EE8: CBNZ x20, #0xbc9ef0        | if (val_1 != null) goto label_36;       
            if(val_1 != null)
            {
                goto label_36;
            }
            // 0x00BC9EEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_36:
            // 0x00BC9EF0: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x00BC9EF4: LDR x8, [x8, #0xe68]       | X8 = (string**)(1152921510058785952)("BattleStart");
            // 0x00BC9EF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9EFC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BC9F00: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC9F04: LDR x1, [x8]               | X1 = "BattleStart";                     
            // 0x00BC9F08: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC9F0C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9F10: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BC9F14: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "BattleStart", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "BattleStart", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BC9F18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9F1C: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x00BC9F20: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9F24: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache4;
            val_27 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache4;
            // 0x00BC9F28: CBNZ x22, #0xbc9f74        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache4 != null) goto label_37;
            if(val_27 != null)
            {
                goto label_37;
            }
            // 0x00BC9F2C: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00BC9F30: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BC9F34: LDR x8, [x8, #0x630]       | X8 = 1152921510058790144;               
            // 0x00BC9F38: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BC9F3C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleStart_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BC9F40: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_15 = null;
            // 0x00BC9F44: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BC9F48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC9F4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9F50: MOV x2, x22                | X2 = 1152921510058790144 (0x1000000144F60D00);//ML01
            // 0x00BC9F54: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_15;
            // 0x00BC9F58: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleStart_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_15 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleStart_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BC9F5C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9F60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9F64: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783101984
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache4 = val_23;
            // 0x00BC9F68: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BC9F6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC9F70: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_27 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache4;
            label_37:
            // 0x00BC9F74: CBNZ x19, #0xbc9f7c        | if (X1 != 0) goto label_38;             
            if(X1 != 0)
            {
                goto label_38;
            }
            // 0x00BC9F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleStart_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_38:
            // 0x00BC9F7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC9F80: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC9F84: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x00BC9F88: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BC9F8C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_27);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_27);
            // 0x00BC9F90: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BC9F94: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9F98: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BC9F9C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00BC9FA0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9FA4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BC9FA8: LDR x8, [x26]              | X8 = typeof(System.Type);               
            // 0x00BC9FAC: LDR x22, [x27]             | X22 = typeof(CEvent.ZEvent);            
            // 0x00BC9FB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BC9FB4: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC9FB8: TBZ w9, #0, #0xbc9fcc      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_40;
            // 0x00BC9FBC: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC9FC0: CBNZ w9, #0xbc9fcc         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
            // 0x00BC9FC4: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BC9FC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_40:
            // 0x00BC9FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC9FD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC9FD4: MOV x1, x22                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00BC9FD8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC9FDC: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x00BC9FE0: CBNZ x21, #0xbc9fe8        | if ( != null) goto label_41;            
            if(null != null)
            {
                goto label_41;
            }
            // 0x00BC9FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_41:
            // 0x00BC9FE8: CBZ x22, #0xbca00c         | if (val_16 == null) goto label_43;      
            if(val_16 == null)
            {
                goto label_43;
            }
            // 0x00BC9FEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC9FF0: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x00BC9FF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC9FF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x00BC9FFC: CBNZ x0, #0xbca00c         | if (val_16 != null) goto label_43;      
            if(val_16 != null)
            {
                goto label_43;
            }
            // 0x00BCA000: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x00BCA004: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA008: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_43:
            // 0x00BCA00C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x00BCA010: CBNZ w8, #0xbca020         | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_44;
            // 0x00BCA014: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x00BCA018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA01C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_44:
            // 0x00BCA020: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_16;
            // 0x00BCA024: CBNZ x20, #0xbca02c        | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x00BCA028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_45:
            // 0x00BCA02C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00BCA030: LDR x8, [x8, #0xb38]       | X8 = (string**)(1152921510058795264)("BattleWin");
            // 0x00BCA034: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA038: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCA03C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCA040: LDR x1, [x8]               | X1 = "BattleWin";                       
            // 0x00BCA044: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCA048: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCA04C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCA050: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "BattleWin", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "BattleWin", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCA054: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA058: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x00BCA05C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA060: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache5;
            val_28 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache5;
            // 0x00BCA064: CBNZ x22, #0xbca0b0        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache5 != null) goto label_46;
            if(val_28 != null)
            {
                goto label_46;
            }
            // 0x00BCA068: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00BCA06C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCA070: LDR x8, [x8, #0x810]       | X8 = 1152921510058799456;               
            // 0x00BCA074: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCA078: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleWin_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCA07C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_18 = null;
            // 0x00BCA080: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCA084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA088: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA08C: MOV x2, x22                | X2 = 1152921510058799456 (0x1000000144F63160);//ML01
            // 0x00BCA090: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_18;
            // 0x00BCA094: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleWin_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_18 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleWin_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCA098: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA09C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA0A0: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783101992
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache5 = val_23;
            // 0x00BCA0A4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA0A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA0AC: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_28 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache5;
            label_46:
            // 0x00BCA0B0: CBNZ x19, #0xbca0b8        | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x00BCA0B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::BattleWin_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_47:
            // 0x00BCA0B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA0BC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA0C0: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x00BCA0C4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCA0C8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_28);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_28);
            // 0x00BCA0CC: LDR x21, [x25]             | X21 = typeof(System.Type[]);            
            // 0x00BCA0D0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCA0D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BCA0D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA0DC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCA0E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BCA0E4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCA0E8: CBNZ x20, #0xbca0f0        | if (val_1 != null) goto label_48;       
            if(val_1 != null)
            {
                goto label_48;
            }
            // 0x00BCA0EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_48:
            // 0x00BCA0F0: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00BCA0F4: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921510043458688)("Clear");
            // 0x00BCA0F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA0FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BCA100: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCA104: LDR x1, [x8]               | X1 = "Clear";                           
            // 0x00BCA108: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCA10C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BCA110: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00BCA114: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_19 = val_1.GetMethod(name:  "Clear", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BCA118: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA11C: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x00BCA120: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA124: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache6;
            val_29 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache6;
            // 0x00BCA128: CBNZ x22, #0xbca174        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache6 != null) goto label_49;
            if(val_29 != null)
            {
                goto label_49;
            }
            // 0x00BCA12C: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x00BCA130: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BCA134: LDR x8, [x8, #0x760]       | X8 = 1152921510058804576;               
            // 0x00BCA138: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BCA13C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BCA140: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_20 = null;
            // 0x00BCA144: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BCA148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA14C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA150: MOV x2, x22                | X2 = 1152921510058804576 (0x1000000144F64560);//ML01
            // 0x00BCA154: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_23 = val_20;
            // 0x00BCA158: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_20 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BCA15C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA160: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA164: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783102000
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache6 = val_23;
            // 0x00BCA168: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA16C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA170: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_29 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache6;
            label_49:
            // 0x00BCA174: CBNZ x19, #0xbca17c        | if (X1 != 0) goto label_50;             
            if(X1 != 0)
            {
                goto label_50;
            }
            // 0x00BCA178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.Biaoche_Binding::Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_50:
            // 0x00BCA17C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA180: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA184: MOV x1, x21                | X1 = val_19;//m1                        
            // 0x00BCA188: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BCA18C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_29);
            X1.RegisterCLRMethodRedirection(mi:  val_19, func:  val_29);
            // 0x00BCA190: CBNZ x20, #0xbca198        | if (val_1 != null) goto label_51;       
            if(val_1 != null)
            {
                goto label_51;
            }
            // 0x00BCA194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_51:
            // 0x00BCA198: ADRP x9, #0x362a000        | X9 = 56795136 (0x362A000);              
            // 0x00BCA19C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BCA1A0: LDR x9, [x9, #0x558]       | X9 = (string**)(1152921510058805600)("MOVE_TO_END");
            // 0x00BCA1A4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BCA1A8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BCA1AC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BCA1B0: LDR x1, [x9]               | X1 = "MOVE_TO_END";                     
            // 0x00BCA1B4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BCA1B8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BCA1BC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA1C0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BCA1C4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA1C8: LDR x21, [x8, #0x38]       | X21 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache7;
            val_30 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache7;
            // 0x00BCA1CC: CBNZ x21, #0xbca218        | if (ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache7 != null) goto label_52;
            if(val_30 != null)
            {
                goto label_52;
            }
            // 0x00BCA1D0: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00BCA1D4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BCA1D8: LDR x8, [x8, #0x618]       | X8 = 1152921510058805696;               
            // 0x00BCA1DC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BCA1E0: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.Biaoche_Binding::get_MOVE_TO_END_0(ref object o);
            // 0x00BCA1E4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_21 = null;
            // 0x00BCA1E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BCA1EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA1F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA1F4: MOV x2, x21                | X2 = 1152921510058805696 (0x1000000144F649C0);//ML01
            // 0x00BCA1F8: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BCA1FC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Biaoche_Binding::get_MOVE_TO_END_0(ref object o));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Biaoche_Binding::get_MOVE_TO_END_0(ref object o));
            // 0x00BCA200: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA204: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA208: STR x22, [x8, #0x38]       | ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783102008
            ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache7 = val_21;
            // 0x00BCA20C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.Biaoche_Binding);
            // 0x00BCA210: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.Biaoche_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BCA214: LDR x21, [x8, #0x38]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_30 = ILRuntime.Runtime.Generated.Biaoche_Binding.<>f__mg$cache7;
            label_52:
            // 0x00BCA218: CBNZ x19, #0xbca220        | if (X1 != 0) goto label_53;             
            if(X1 != 0)
            {
                goto label_53;
            }
            // 0x00BCA21C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.Biaoche_Binding::get_MOVE_TO_END_0(ref object o)), ????);
            label_53:
            // 0x00BCA220: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA224: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BCA228: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BCA22C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCA230: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCA234: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCA238: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCA23C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00BCA240: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA244: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00BCA248: B #0x28e5914               | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30); return;
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCA24C (12362316), len: 588  VirtAddr: 0x00BCA24C RVA: 0x00BCA24C token: 100663851 methodIndex: 29896 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_MoveJindu_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00BCA24C: STP x26, x25, [sp, #-0x50]! | stack[1152921510059016656] = ???;  stack[1152921510059016664] = ???;  //  dest_result_addr=1152921510059016656 |  dest_result_addr=1152921510059016664
            // 0x00BCA250: STP x24, x23, [sp, #0x10]  | stack[1152921510059016672] = ???;  stack[1152921510059016680] = ???;  //  dest_result_addr=1152921510059016672 |  dest_result_addr=1152921510059016680
            // 0x00BCA254: STP x22, x21, [sp, #0x20]  | stack[1152921510059016688] = ???;  stack[1152921510059016696] = ???;  //  dest_result_addr=1152921510059016688 |  dest_result_addr=1152921510059016696
            // 0x00BCA258: STP x20, x19, [sp, #0x30]  | stack[1152921510059016704] = ???;  stack[1152921510059016712] = ???;  //  dest_result_addr=1152921510059016704 |  dest_result_addr=1152921510059016712
            // 0x00BCA25C: STP x29, x30, [sp, #0x40]  | stack[1152921510059016720] = ???;  stack[1152921510059016728] = ???;  //  dest_result_addr=1152921510059016720 |  dest_result_addr=1152921510059016728
            // 0x00BCA260: ADD x29, sp, #0x40         | X29 = (1152921510059016656 + 64) = 1152921510059016720 (0x1000000144F98210);
            // 0x00BCA264: SUB sp, sp, #0x10          | SP = (1152921510059016656 - 16) = 1152921510059016640 (0x1000000144F981C0);
            // 0x00BCA268: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCA26C: LDRB w8, [x19, #0xbb2]     | W8 = (bool)static_value_03733BB2;       
            // 0x00BCA270: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCA274: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCA278: MOV x20, x1                | X20 = X1;//m1                           
            // 0x00BCA27C: TBNZ w8, #0, #0xbca298     | if (static_value_03733BB2 == true) goto label_0;
            // 0x00BCA280: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00BCA284: LDR x8, [x8, #0x648]       | X8 = 0x2B8F398;                         
            // 0x00BCA288: LDR w0, [x8]               | W0 = 0x13A8;                            
            // 0x00BCA28C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A8, ????);     
            // 0x00BCA290: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCA294: STRB w8, [x19, #0xbb2]     | static_value_03733BB2 = true;            //  dest_result_addr=57883570
            label_0:
            // 0x00BCA298: CBNZ x20, #0xbca2a0        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCA29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A8, ????);     
            label_1:
            // 0x00BCA2A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA2A4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCA2A8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCA2AC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCA2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA2B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA2B8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCA2BC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCA2C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA2C4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00BCA2C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA2CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA2D0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCA2D4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCA2D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA2DC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCA2E0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCA2E4: ADRP x9, #0x35f1000        | X9 = 56561664 (0x35F1000);              
            // 0x00BCA2E8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCA2EC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCA2F0: LDR x9, [x9, #0xc50]       | X9 = 1152921504893906944;               
            // 0x00BCA2F4: LDR x24, [x9]              | X24 = typeof(Biaoche);                  
            // 0x00BCA2F8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCA2FC: TBZ w9, #0, #0xbca310      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCA300: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA304: CBNZ w9, #0xbca310         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCA308: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCA30C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCA310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA318: MOV x1, x24                | X1 = 1152921504893906944 (0x10000000111C3000);//ML01
            // 0x00BCA31C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCA320: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x00BCA324: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x00BCA328: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCA32C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCA330: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCA334: TBZ w9, #0, #0xbca348      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCA338: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA33C: CBNZ w9, #0xbca348         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCA340: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCA344: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCA348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA34C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCA350: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCA354: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCA358: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCA35C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCA360: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCA364: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCA368: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCA36C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCA370: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCA374: TBZ w9, #0, #0xbca388      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCA378: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA37C: CBNZ w9, #0xbca388         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCA380: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCA384: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCA388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA38C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA390: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCA394: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCA398: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCA39C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00BCA3A0: CBZ x0, #0xbca404          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCA3A4: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCA3A8: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCA3AC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCA3B0: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCA3B4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA3B8: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA3BC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCA3C0: B.LO #0xbca3dc             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCA3C4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCA3C8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCA3CC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCA3D0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCA3D4: MOV x22, x0                | X22 = val_6;//m1                        
            val_11 = val_6;
            // 0x00BCA3D8: B.EQ #0xbca404             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCA3DC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCA3E0: ADD x8, sp, #8             | X8 = (1152921510059016640 + 8) = 1152921510059016648 (0x1000000144F981C8);
            // 0x00BCA3E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCA3E8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510059004736]
            // 0x00BCA3EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCA3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA3F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCA3F8: ADD x0, sp, #8             | X0 = (1152921510059016640 + 8) = 1152921510059016648 (0x1000000144F981C8);
            // 0x00BCA3FC: BL #0x299a140              | 
            // 0x00BCA400: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_11 = 0;
            label_10:
            // 0x00BCA404: CBNZ x20, #0xbca40c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCA408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144F981C8, ????);
            label_11:
            // 0x00BCA40C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA410: MOV x0, x20                | X0 = X1;//m1                            
            // 0x00BCA414: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCA418: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCA41C: CBNZ x22, #0xbca424        | if (0x0 != 0) goto label_12;            
            if(val_11 != 0)
            {
                goto label_12;
            }
            // 0x00BCA420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCA424: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA428: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA42C: BL #0xb8f954               | X0 = val_11.get_MoveJindu();            
            float val_9 = val_11.MoveJindu;
            // 0x00BCA430: CBZ x19, #0xbca490         | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x00BCA434: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00BCA438: STR w8, [x19]              | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00BCA43C: STR s0, [x19, #4]          | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x00BCA440: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCA444: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_12 = 8;
            // 0x00BCA448: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x00BCA44C: TBZ w9, #0, #0xbca45c      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x00BCA450: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x00BCA454: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x00BCA458: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_12 = 219381744;
            label_14:
            // 0x00BCA45C: ADD x0, x8, x19            | X0 = (val_12 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_12 + val_2;
            // 0x00BCA460: SUB sp, x29, #0x40         | SP = (1152921510059016720 - 64) = 1152921510059016656 (0x1000000144F981D0);
            // 0x00BCA464: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCA468: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCA46C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCA470: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCA474: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCA478: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_12 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCA47C: MOV x19, x0                | X19 = (val_12 + val_2);//m1             
            // 0x00BCA480: ADD x0, sp, #8             | X0 = (1152921510059016736 + 8) = 1152921510059016744 (0x1000000144F98228);
            // 0x00BCA484: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x1000000144F98228); //ERROR_TYPE
            // 0x00BCA488: MOV x0, x19                | X0 = (val_12 + val_2);//m1              
            // 0x00BCA48C: BL #0x980800               | X0 = sub_980800( ?? (val_12 + val_2), ????);
            label_13:
            // 0x00BCA490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (val_12 + val_2), ????);
            // 0x00BCA494: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCA498 (12362904), len: 584  VirtAddr: 0x00BCA498 RVA: 0x00BCA498 token: 100663852 methodIndex: 29897 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* OnTriggerFun_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            // 0x00BCA498: STP x26, x25, [sp, #-0x50]! | stack[1152921510059186000] = ???;  stack[1152921510059186008] = ???;  //  dest_result_addr=1152921510059186000 |  dest_result_addr=1152921510059186008
            // 0x00BCA49C: STP x24, x23, [sp, #0x10]  | stack[1152921510059186016] = ???;  stack[1152921510059186024] = ???;  //  dest_result_addr=1152921510059186016 |  dest_result_addr=1152921510059186024
            // 0x00BCA4A0: STP x22, x21, [sp, #0x20]  | stack[1152921510059186032] = ???;  stack[1152921510059186040] = ???;  //  dest_result_addr=1152921510059186032 |  dest_result_addr=1152921510059186040
            // 0x00BCA4A4: STP x20, x19, [sp, #0x30]  | stack[1152921510059186048] = ???;  stack[1152921510059186056] = ???;  //  dest_result_addr=1152921510059186048 |  dest_result_addr=1152921510059186056
            // 0x00BCA4A8: STP x29, x30, [sp, #0x40]  | stack[1152921510059186064] = ???;  stack[1152921510059186072] = ???;  //  dest_result_addr=1152921510059186064 |  dest_result_addr=1152921510059186072
            // 0x00BCA4AC: ADD x29, sp, #0x40         | X29 = (1152921510059186000 + 64) = 1152921510059186064 (0x1000000144FC1790);
            // 0x00BCA4B0: SUB sp, sp, #0x10          | SP = (1152921510059186000 - 16) = 1152921510059185984 (0x1000000144FC1740);
            // 0x00BCA4B4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCA4B8: LDRB w8, [x20, #0xbb3]     | W8 = (bool)static_value_03733BB3;       
            // 0x00BCA4BC: MOV x23, x3                | X23 = X3;//m1                           
            // 0x00BCA4C0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCA4C4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCA4C8: TBNZ w8, #0, #0xbca4e4     | if (static_value_03733BB3 == true) goto label_0;
            // 0x00BCA4CC: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x00BCA4D0: LDR x8, [x8, #0xe8]        | X8 = 0x2B8F39C;                         
            // 0x00BCA4D4: LDR w0, [x8]               | W0 = 0x13A9;                            
            // 0x00BCA4D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A9, ????);     
            // 0x00BCA4DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCA4E0: STRB w8, [x20, #0xbb3]     | static_value_03733BB3 = true;            //  dest_result_addr=57883571
            label_0:
            // 0x00BCA4E4: CBNZ x19, #0xbca4ec        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCA4E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A9, ????);     
            label_1:
            // 0x00BCA4EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA4F0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA4F4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCA4F8: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x00BCA4FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA500: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA504: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCA508: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA50C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA510: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCA514: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA518: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA51C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCA520: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA524: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA528: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCA52C: CBNZ x21, #0xbca534        | if (val_3 != 0) goto label_2;           
            if(val_3 != 0)
            {
                goto label_2;
            }
            // 0x00BCA530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x00BCA534: LDR w21, [x21, #4]         | W21 = val_3 + 4;                        
            // 0x00BCA538: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA53C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA540: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCA544: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA548: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_4 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA54C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCA550: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCA554: ADRP x9, #0x35f1000        | X9 = 56561664 (0x35F1000);              
            // 0x00BCA558: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00BCA55C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCA560: LDR x9, [x9, #0xc50]       | X9 = 1152921504893906944;               
            // 0x00BCA564: LDR x25, [x9]              | X25 = typeof(Biaoche);                  
            // 0x00BCA568: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCA56C: TBZ w9, #0, #0xbca580      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00BCA570: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA574: CBNZ w9, #0xbca580         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00BCA578: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCA57C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_4:
            // 0x00BCA580: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA584: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA588: MOV x1, x25                | X1 = 1152921504893906944 (0x10000000111C3000);//ML01
            // 0x00BCA58C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCA590: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCA594: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCA598: MOV x25, x0                | X25 = val_5;//m1                        
            // 0x00BCA59C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCA5A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCA5A4: TBZ w9, #0, #0xbca5b8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00BCA5A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA5AC: CBNZ w9, #0xbca5b8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00BCA5B0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCA5B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x00BCA5B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA5BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCA5C0: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCA5C4: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x00BCA5C8: MOV x3, x23                | X3 = X3;//m1                            
            // 0x00BCA5CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCA5D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCA5D4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCA5D8: MOV x23, x0                | X23 = val_6;//m1                        
            // 0x00BCA5DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCA5E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCA5E4: TBZ w9, #0, #0xbca5f8      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00BCA5E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA5EC: CBNZ w9, #0xbca5f8         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00BCA5F0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCA5F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_8:
            // 0x00BCA5F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA5FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA600: MOV x1, x25                | X1 = val_5;//m1                         
            // 0x00BCA604: MOV x2, x23                | X2 = val_6;//m1                         
            // 0x00BCA608: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            object val_7 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_5);
            // 0x00BCA60C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00BCA610: CBZ x0, #0xbca674          | if (val_7 == null) goto label_11;       
            if(val_7 == null)
            {
                goto label_11;
            }
            // 0x00BCA614: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCA618: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCA61C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCA620: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCA624: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA628: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA62C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCA630: B.LO #0xbca64c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x00BCA634: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCA638: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCA63C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCA640: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCA644: MOV x23, x0                | X23 = val_7;//m1                        
            val_10 = val_7;
            // 0x00BCA648: B.EQ #0xbca674             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x00BCA64C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCA650: ADD x8, sp, #8             | X8 = (1152921510059185984 + 8) = 1152921510059185992 (0x1000000144FC1748);
            // 0x00BCA654: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCA658: LDR x0, [sp, #8]           | X0 = val_9;                              //  find_add[1152921510059174080]
            // 0x00BCA65C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x00BCA660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA664: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x00BCA668: ADD x0, sp, #8             | X0 = (1152921510059185984 + 8) = 1152921510059185992 (0x1000000144FC1748);
            // 0x00BCA66C: BL #0x299a140              | 
            // 0x00BCA670: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x00BCA674: CBNZ x19, #0xbca67c        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BCA678: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144FC1748, ????);
            label_12:
            // 0x00BCA67C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA680: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA684: MOV x1, x22                | X1 = val_4;//m1                         
            // 0x00BCA688: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCA68C: CBNZ x23, #0xbca694        | if (0x0 != 0) goto label_13;            
            if(val_10 != 0)
            {
                goto label_13;
            }
            // 0x00BCA690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x00BCA694: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x00BCA698: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA69C: MOV w1, w21                | W1 = val_3 + 4;//m1                     
            // 0x00BCA6A0: LDR x9, [x8, #0x260]       | X9 = mem[282584257677279];              
            // 0x00BCA6A4: LDR x2, [x8, #0x268]       | X2 = mem[282584257677287];              
            // 0x00BCA6A8: BLR x9                     | X0 = mem[282584257677279]();            
            // 0x00BCA6AC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCA6B0: SUB sp, x29, #0x40         | SP = (1152921510059186064 - 64) = 1152921510059186000 (0x1000000144FC1750);
            // 0x00BCA6B4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCA6B8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCA6BC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCA6C0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCA6C4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCA6C8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCA6CC: MOV x19, x0                | 
            // 0x00BCA6D0: ADD x0, sp, #8             | 
            // 0x00BCA6D4: BL #0x299a140              | 
            // 0x00BCA6D8: MOV x0, x19                | 
            // 0x00BCA6DC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCA6E0 (12363488), len: 1024  VirtAddr: 0x00BCA6E0 RVA: 0x00BCA6E0 token: 100663853 methodIndex: 29898 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Create_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            // 0x00BCA6E0: STP x26, x25, [sp, #-0x50]! | stack[1152921510059379920] = ???;  stack[1152921510059379928] = ???;  //  dest_result_addr=1152921510059379920 |  dest_result_addr=1152921510059379928
            // 0x00BCA6E4: STP x24, x23, [sp, #0x10]  | stack[1152921510059379936] = ???;  stack[1152921510059379944] = ???;  //  dest_result_addr=1152921510059379936 |  dest_result_addr=1152921510059379944
            // 0x00BCA6E8: STP x22, x21, [sp, #0x20]  | stack[1152921510059379952] = ???;  stack[1152921510059379960] = ???;  //  dest_result_addr=1152921510059379952 |  dest_result_addr=1152921510059379960
            // 0x00BCA6EC: STP x20, x19, [sp, #0x30]  | stack[1152921510059379968] = ???;  stack[1152921510059379976] = ???;  //  dest_result_addr=1152921510059379968 |  dest_result_addr=1152921510059379976
            // 0x00BCA6F0: STP x29, x30, [sp, #0x40]  | stack[1152921510059379984] = ???;  stack[1152921510059379992] = ???;  //  dest_result_addr=1152921510059379984 |  dest_result_addr=1152921510059379992
            // 0x00BCA6F4: ADD x29, sp, #0x40         | X29 = (1152921510059379920 + 64) = 1152921510059379984 (0x1000000144FF0D10);
            // 0x00BCA6F8: SUB sp, sp, #0x20          | SP = (1152921510059379920 - 32) = 1152921510059379888 (0x1000000144FF0CB0);
            // 0x00BCA6FC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCA700: LDRB w8, [x20, #0xbb4]     | W8 = (bool)static_value_03733BB4;       
            // 0x00BCA704: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BCA708: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCA70C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCA710: TBNZ w8, #0, #0xbca72c     | if (static_value_03733BB4 == true) goto label_0;
            // 0x00BCA714: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00BCA718: LDR x8, [x8, #0x1a0]       | X8 = 0x2B8F390;                         
            // 0x00BCA71C: LDR w0, [x8]               | W0 = 0x13A6;                            
            // 0x00BCA720: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A6, ????);     
            // 0x00BCA724: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCA728: STRB w8, [x20, #0xbb4]     | static_value_03733BB4 = true;            //  dest_result_addr=57883572
            label_0:
            // 0x00BCA72C: CBNZ x19, #0xbca734        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCA730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A6, ????);     
            label_1:
            // 0x00BCA734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA738: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA73C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCA740: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCA744: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA748: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA74C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BCA750: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA754: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA758: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCA75C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA760: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA764: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCA768: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA76C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA770: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCA774: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCA778: ADRP x9, #0x3603000        | X9 = 56635392 (0x3603000);              
            // 0x00BCA77C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00BCA780: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCA784: LDR x9, [x9, #0x6d8]       | X9 = 1152921504891351040;               
            // 0x00BCA788: LDR x24, [x9]              | X24 = typeof(JSCLevelMonsterConfig);    
            // 0x00BCA78C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCA790: TBZ w9, #0, #0xbca7a4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCA794: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA798: CBNZ w9, #0xbca7a4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCA79C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCA7A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCA7A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA7A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA7AC: MOV x1, x24                | X1 = 1152921504891351040 (0x1000000010F53000);//ML01
            // 0x00BCA7B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCA7B4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCA7B8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCA7BC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCA7C0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCA7C4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCA7C8: TBZ w9, #0, #0xbca7dc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCA7CC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA7D0: CBNZ w9, #0xbca7dc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCA7D4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCA7D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCA7DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA7E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCA7E4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BCA7E8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCA7EC: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCA7F0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BCA7F4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCA7F8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCA7FC: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BCA800: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCA804: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCA808: TBZ w9, #0, #0xbca81c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCA80C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCA810: CBNZ w9, #0xbca81c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCA814: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCA818: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCA81C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA820: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA824: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCA828: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BCA82C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCA830: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            // 0x00BCA834: CBZ x0, #0xbca898          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCA838: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x00BCA83C: LDR x9, [x9, #0xeb0]       | X9 = 1152921504891351040;               
            // 0x00BCA840: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCA844: LDR x1, [x9]               | X1 = typeof(JSCLevelMonsterConfig);     
            // 0x00BCA848: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA84C: LDRB w9, [x1, #0x104]      | W9 = JSCLevelMonsterConfig.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA850: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, JSCLevelMonsterConfig.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCA854: B.LO #0xbca870             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < JSCLevelMonsterConfig.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCA858: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCA85C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (JSCLevelMonsterConfig.__il2cppRuntimeField
            // 0x00BCA860: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (JSCLevelMonsterConfig.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCA864: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (JSCLevelMonsterConfig.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(JSCLevelMonsterConfig))
            // 0x00BCA868: MOV x24, x0                | X24 = val_6;//m1                        
            val_21 = val_6;
            // 0x00BCA86C: B.EQ #0xbca898             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (JSCLevelMonsterConfig.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCA870: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCA874: ADD x8, sp, #8             | X8 = (1152921510059379888 + 8) = 1152921510059379896 (0x1000000144FF0CB8);
            // 0x00BCA878: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCA87C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510059368000]
            // 0x00BCA880: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCA884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA888: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCA88C: ADD x0, sp, #8             | X0 = (1152921510059379888 + 8) = 1152921510059379896 (0x1000000144FF0CB8);
            // 0x00BCA890: BL #0x299a140              | 
            // 0x00BCA894: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_21 = 0;
            label_10:
            // 0x00BCA898: CBNZ x19, #0xbca8a0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCA89C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144FF0CB8, ????);
            label_11:
            // 0x00BCA8A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA8A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA8A8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x00BCA8AC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCA8B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA8B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA8B8: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCA8BC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA8C0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA8C4: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00BCA8C8: LDR x8, [x8, #0xf50]       | X8 = 1152921504890179584;               
            // 0x00BCA8CC: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x00BCA8D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA8D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA8D8: LDR x1, [x8]               | X1 = typeof(monstersCfg);               
            // 0x00BCA8DC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCA8E0: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00BCA8E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA8E8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCA8EC: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00BCA8F0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCA8F4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCA8F8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BCA8FC: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BCA900: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA904: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA908: MOV x1, x25                | X1 = val_10;//m1                        
            // 0x00BCA90C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BCA910: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x00BCA914: CBZ x0, #0xbca978          | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x00BCA918: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x00BCA91C: LDR x9, [x9, #0xbe8]       | X9 = 1152921504890179584;               
            // 0x00BCA920: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCA924: LDR x1, [x9]               | X1 = typeof(monstersCfg);               
            // 0x00BCA928: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA92C: LDRB w9, [x1, #0x104]      | W9 = monstersCfg.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCA930: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, monstersCfg.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCA934: B.LO #0xbca950             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < monstersCfg.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BCA938: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCA93C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (monstersCfg.__il2cppRuntimeField_typeHiera
            // 0x00BCA940: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (monstersCfg.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCA944: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (monstersCfg.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(monstersCfg))
            // 0x00BCA948: MOV x25, x0                | X25 = val_12;//m1                       
            val_22 = val_12;
            // 0x00BCA94C: B.EQ #0xbca978             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (monstersCfg.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BCA950: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCA954: ADD x8, sp, #0x10          | X8 = (1152921510059379888 + 16) = 1152921510059379904 (0x1000000144FF0CC0);
            // 0x00BCA958: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCA95C: LDR x0, [sp, #0x10]        | X0 = val_14;                             //  find_add[1152921510059368000]
            // 0x00BCA960: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BCA964: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCA968: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BCA96C: ADD x0, sp, #0x10          | X0 = (1152921510059379888 + 16) = 1152921510059379904 (0x1000000144FF0CC0);
            // 0x00BCA970: BL #0x299a140              | 
            // 0x00BCA974: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_14:
            // 0x00BCA978: CBNZ x19, #0xbca980        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BCA97C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144FF0CC0, ????);
            label_15:
            // 0x00BCA980: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA984: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCA988: MOV x1, x26                | X1 = val_9;//m1                         
            // 0x00BCA98C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCA990: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA994: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA998: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x00BCA99C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCA9A0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCA9A4: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BCA9A8: LDR x8, [x8, #0xc50]       | X8 = 1152921504893906944;               
            // 0x00BCA9AC: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x00BCA9B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA9B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCA9B8: LDR x1, [x8]               | X1 = typeof(Biaoche);                   
            // 0x00BCA9BC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCA9C0: MOV x26, x0                | X26 = val_16;//m1                       
            // 0x00BCA9C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA9C8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCA9CC: MOV x1, x22                | X1 = val_15;//m1                        
            // 0x00BCA9D0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCA9D4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCA9D8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_17 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x00BCA9DC: MOV x2, x0                 | X2 = val_17;//m1                        
            // 0x00BCA9E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCA9E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCA9E8: MOV x1, x26                | X1 = val_16;//m1                        
            // 0x00BCA9EC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            object val_18 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            // 0x00BCA9F0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            // 0x00BCA9F4: CBZ x0, #0xbcaa58          | if (val_18 == null) goto label_18;      
            if(val_18 == null)
            {
                goto label_18;
            }
            // 0x00BCA9F8: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCA9FC: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCAA00: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCAA04: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCAA08: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAA0C: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAA10: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCAA14: B.LO #0xbcaa30             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x00BCAA18: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCAA1C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCAA20: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCAA24: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCAA28: MOV x21, x0                | X21 = val_18;//m1                       
            val_23 = val_18;
            // 0x00BCAA2C: B.EQ #0xbcaa58             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_18;
            label_17:
            // 0x00BCAA30: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCAA34: ADD x8, sp, #0x18          | X8 = (1152921510059379888 + 24) = 1152921510059379912 (0x1000000144FF0CC8);
            // 0x00BCAA38: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCAA3C: LDR x0, [sp, #0x18]        | X0 = val_20;                             //  find_add[1152921510059368000]
            // 0x00BCAA40: BL #0x27af090              | X0 = sub_27AF090( ?? val_20, ????);     
            // 0x00BCAA44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAA48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            // 0x00BCAA4C: ADD x0, sp, #0x18          | X0 = (1152921510059379888 + 24) = 1152921510059379912 (0x1000000144FF0CC8);
            // 0x00BCAA50: BL #0x299a140              | 
            // 0x00BCAA54: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_18:
            // 0x00BCAA58: CBNZ x19, #0xbcaa60        | if (X1 != 0) goto label_19;             
            if(X1 != 0)
            {
                goto label_19;
            }
            // 0x00BCAA5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144FF0CC8, ????);
            label_19:
            // 0x00BCAA60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCAA64: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCAA68: MOV x1, x22                | X1 = val_15;//m1                        
            // 0x00BCAA6C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCAA70: CBNZ x21, #0xbcaa78        | if (0x0 != 0) goto label_20;            
            if(val_23 != 0)
            {
                goto label_20;
            }
            // 0x00BCAA74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_20:
            // 0x00BCAA78: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
            // 0x00BCAA7C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAA80: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAA84: MOV x2, x24                | X2 = 0 (0x0);//ML01                     
            // 0x00BCAA88: LDR x9, [x8, #0x490]       | X9 = mem[282584257677839];              
            // 0x00BCAA8C: LDR x3, [x8, #0x498]       | X3 = mem[282584257677847];              
            // 0x00BCAA90: BLR x9                     | X0 = mem[282584257677839]();            
            // 0x00BCAA94: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCAA98: SUB sp, x29, #0x40         | SP = (1152921510059379984 - 64) = 1152921510059379920 (0x1000000144FF0CD0);
            // 0x00BCAA9C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCAAA0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCAAA4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCAAA8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCAAAC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCAAB0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCAAB4: MOV x19, x0                | 
            // 0x00BCAAB8: ADD x0, sp, #8             | 
            // 0x00BCAABC: B #0xbcaad4                | 
            // 0x00BCAAC0: MOV x19, x0                | 
            // 0x00BCAAC4: ADD x0, sp, #0x10          | 
            // 0x00BCAAC8: B #0xbcaad4                | 
            // 0x00BCAACC: MOV x19, x0                | 
            // 0x00BCAAD0: ADD x0, sp, #0x18          | 
            label_22:
            // 0x00BCAAD4: BL #0x299a140              | 
            // 0x00BCAAD8: MOV x0, x19                | 
            // 0x00BCAADC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCAAE0 (12364512), len: 532  VirtAddr: 0x00BCAAE0 RVA: 0x00BCAAE0 token: 100663854 methodIndex: 29899 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Update_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BCAAE0: STP x24, x23, [sp, #-0x40]! | stack[1152921510059573856] = ???;  stack[1152921510059573864] = ???;  //  dest_result_addr=1152921510059573856 |  dest_result_addr=1152921510059573864
            // 0x00BCAAE4: STP x22, x21, [sp, #0x10]  | stack[1152921510059573872] = ???;  stack[1152921510059573880] = ???;  //  dest_result_addr=1152921510059573872 |  dest_result_addr=1152921510059573880
            // 0x00BCAAE8: STP x20, x19, [sp, #0x20]  | stack[1152921510059573888] = ???;  stack[1152921510059573896] = ???;  //  dest_result_addr=1152921510059573888 |  dest_result_addr=1152921510059573896
            // 0x00BCAAEC: STP x29, x30, [sp, #0x30]  | stack[1152921510059573904] = ???;  stack[1152921510059573912] = ???;  //  dest_result_addr=1152921510059573904 |  dest_result_addr=1152921510059573912
            // 0x00BCAAF0: ADD x29, sp, #0x30         | X29 = (1152921510059573856 + 48) = 1152921510059573904 (0x1000000145020290);
            // 0x00BCAAF4: SUB sp, sp, #0x10          | SP = (1152921510059573856 - 16) = 1152921510059573840 (0x1000000145020250);
            // 0x00BCAAF8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCAAFC: LDRB w8, [x20, #0xbb5]     | W8 = (bool)static_value_03733BB5;       
            // 0x00BCAB00: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCAB04: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCAB08: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCAB0C: TBNZ w8, #0, #0xbcab28     | if (static_value_03733BB5 == true) goto label_0;
            // 0x00BCAB10: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x00BCAB14: LDR x8, [x8, #0x688]       | X8 = 0x2B8F3A4;                         
            // 0x00BCAB18: LDR w0, [x8]               | W0 = 0x13AB;                            
            // 0x00BCAB1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13AB, ????);     
            // 0x00BCAB20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCAB24: STRB w8, [x20, #0xbb5]     | static_value_03733BB5 = true;            //  dest_result_addr=57883573
            label_0:
            // 0x00BCAB28: CBNZ x19, #0xbcab30        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCAB2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13AB, ????);     
            label_1:
            // 0x00BCAB30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAB34: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCAB38: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCAB3C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCAB40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAB44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAB48: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCAB4C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCAB50: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCAB54: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCAB58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAB5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAB60: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCAB64: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCAB68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCAB6C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCAB70: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCAB74: ADRP x9, #0x35f1000        | X9 = 56561664 (0x35F1000);              
            // 0x00BCAB78: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCAB7C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCAB80: LDR x9, [x9, #0xc50]       | X9 = 1152921504893906944;               
            // 0x00BCAB84: LDR x24, [x9]              | X24 = typeof(Biaoche);                  
            // 0x00BCAB88: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCAB8C: TBZ w9, #0, #0xbcaba0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCAB90: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCAB94: CBNZ w9, #0xbcaba0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCAB98: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCAB9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCABA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCABA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCABA8: MOV x1, x24                | X1 = 1152921504893906944 (0x10000000111C3000);//ML01
            // 0x00BCABAC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCABB0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCABB4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCABB8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCABBC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCABC0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCABC4: TBZ w9, #0, #0xbcabd8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCABC8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCABCC: CBNZ w9, #0xbcabd8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCABD0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCABD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCABD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCABDC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCABE0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCABE4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCABE8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCABEC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCABF0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCABF4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCABF8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCABFC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCAC00: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCAC04: TBZ w9, #0, #0xbcac18      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCAC08: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCAC0C: CBNZ w9, #0xbcac18         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCAC10: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCAC14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCAC18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAC1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAC20: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCAC24: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCAC28: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCAC2C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BCAC30: CBZ x0, #0xbcac94          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCAC34: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCAC38: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCAC3C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCAC40: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCAC44: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAC48: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAC4C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCAC50: B.LO #0xbcac6c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCAC54: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCAC58: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCAC5C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCAC60: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCAC64: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BCAC68: B.EQ #0xbcac94             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCAC6C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCAC70: ADD x8, sp, #8             | X8 = (1152921510059573840 + 8) = 1152921510059573848 (0x1000000145020258);
            // 0x00BCAC74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCAC78: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510059561920]
            // 0x00BCAC7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCAC80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAC84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCAC88: ADD x0, sp, #8             | X0 = (1152921510059573840 + 8) = 1152921510059573848 (0x1000000145020258);
            // 0x00BCAC8C: BL #0x299a140              | 
            // 0x00BCAC90: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BCAC94: CBNZ x19, #0xbcac9c        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCAC98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000145020258, ????);
            label_11:
            // 0x00BCAC9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCACA0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCACA4: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCACA8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCACAC: CBNZ x22, #0xbcacb4        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BCACB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCACB4: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BCACB8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCACBC: LDP x9, x1, [x8, #0x1e0]   | X9 = mem[282584257677151]; X1 = mem[282584257677159]; //  | 
            // 0x00BCACC0: BLR x9                     | X0 = mem[282584257677151]();            
            // 0x00BCACC4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCACC8: SUB sp, x29, #0x30         | SP = (1152921510059573904 - 48) = 1152921510059573856 (0x1000000145020260);
            // 0x00BCACCC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCACD0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCACD4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCACD8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BCACDC: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCACE0: MOV x19, x0                | 
            // 0x00BCACE4: ADD x0, sp, #8             | 
            // 0x00BCACE8: BL #0x299a140              | 
            // 0x00BCACEC: MOV x0, x19                | 
            // 0x00BCACF0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCACF4 (12365044), len: 776  VirtAddr: 0x00BCACF4 RVA: 0x00BCACF4 token: 100663855 methodIndex: 29900 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* BattleStart_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            CEvent.ZEvent val_15;
            //  | 
            var val_16;
            // 0x00BCACF4: STP x26, x25, [sp, #-0x50]! | stack[1152921510059755472] = ???;  stack[1152921510059755480] = ???;  //  dest_result_addr=1152921510059755472 |  dest_result_addr=1152921510059755480
            // 0x00BCACF8: STP x24, x23, [sp, #0x10]  | stack[1152921510059755488] = ???;  stack[1152921510059755496] = ???;  //  dest_result_addr=1152921510059755488 |  dest_result_addr=1152921510059755496
            // 0x00BCACFC: STP x22, x21, [sp, #0x20]  | stack[1152921510059755504] = ???;  stack[1152921510059755512] = ???;  //  dest_result_addr=1152921510059755504 |  dest_result_addr=1152921510059755512
            // 0x00BCAD00: STP x20, x19, [sp, #0x30]  | stack[1152921510059755520] = ???;  stack[1152921510059755528] = ???;  //  dest_result_addr=1152921510059755520 |  dest_result_addr=1152921510059755528
            // 0x00BCAD04: STP x29, x30, [sp, #0x40]  | stack[1152921510059755536] = ???;  stack[1152921510059755544] = ???;  //  dest_result_addr=1152921510059755536 |  dest_result_addr=1152921510059755544
            // 0x00BCAD08: ADD x29, sp, #0x40         | X29 = (1152921510059755472 + 64) = 1152921510059755536 (0x100000014504C810);
            // 0x00BCAD0C: SUB sp, sp, #0x10          | SP = (1152921510059755472 - 16) = 1152921510059755456 (0x100000014504C7C0);
            // 0x00BCAD10: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCAD14: LDRB w8, [x20, #0xbb6]     | W8 = (bool)static_value_03733BB6;       
            // 0x00BCAD18: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BCAD1C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCAD20: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCAD24: TBNZ w8, #0, #0xbcad40     | if (static_value_03733BB6 == true) goto label_0;
            // 0x00BCAD28: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00BCAD2C: LDR x8, [x8, #0x8a0]       | X8 = 0x2B8F384;                         
            // 0x00BCAD30: LDR w0, [x8]               | W0 = 0x13A3;                            
            // 0x00BCAD34: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A3, ????);     
            // 0x00BCAD38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCAD3C: STRB w8, [x20, #0xbb6]     | static_value_03733BB6 = true;            //  dest_result_addr=57883574
            label_0:
            // 0x00BCAD40: CBNZ x19, #0xbcad48        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCAD44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A3, ????);     
            label_1:
            // 0x00BCAD48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAD4C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCAD50: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCAD54: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCAD58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAD5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAD60: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCAD64: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCAD68: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCAD6C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCAD70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAD74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAD78: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCAD7C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCAD80: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCAD84: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCAD88: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCAD8C: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x00BCAD90: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BCAD94: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCAD98: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x00BCAD9C: LDR x25, [x9]              | X25 = typeof(CEvent.ZEvent);            
            // 0x00BCADA0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCADA4: TBZ w9, #0, #0xbcadb8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCADA8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCADAC: CBNZ w9, #0xbcadb8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCADB0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCADB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCADB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCADBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCADC0: MOV x1, x25                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00BCADC4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCADC8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCADCC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCADD0: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BCADD4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCADD8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCADDC: TBZ w9, #0, #0xbcadf0      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCADE0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCADE4: CBNZ w9, #0xbcadf0         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCADE8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCADEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCADF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCADF4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCADF8: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BCADFC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCAE00: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCAE04: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCAE08: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCAE0C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCAE10: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BCAE14: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCAE18: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCAE1C: TBZ w9, #0, #0xbcae30      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCAE20: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCAE24: CBNZ w9, #0xbcae30         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCAE28: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCAE2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCAE30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAE34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAE38: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BCAE3C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BCAE40: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCAE44: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BCAE48: CBZ x0, #0xbcaeac          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCAE4C: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x00BCAE50: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x00BCAE54: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCAE58: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x00BCAE5C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAE60: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAE64: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCAE68: B.LO #0xbcae84             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCAE6C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCAE70: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHie
            // 0x00BCAE74: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCAE78: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x00BCAE7C: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x00BCAE80: B.EQ #0xbcaeac             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCAE84: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCAE88: MOV x8, sp                 | X8 = 1152921510059755456 (0x100000014504C7C0);//ML01
            // 0x00BCAE8C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCAE90: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510059743552]
            // 0x00BCAE94: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCAE98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAE9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCAEA0: MOV x0, sp                 | X0 = 1152921510059755456 (0x100000014504C7C0);//ML01
            // 0x00BCAEA4: BL #0x299a140              | 
            // 0x00BCAEA8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x00BCAEAC: CBNZ x19, #0xbcaeb4        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCAEB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014504C7C0, ????);
            label_11:
            // 0x00BCAEB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCAEB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCAEBC: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BCAEC0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCAEC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAEC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAECC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCAED0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCAED4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCAED8: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BCAEDC: LDR x8, [x8, #0xc50]       | X8 = 1152921504893906944;               
            // 0x00BCAEE0: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BCAEE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAEE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCAEEC: LDR x1, [x8]               | X1 = typeof(Biaoche);                   
            // 0x00BCAEF0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCAEF4: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x00BCAEF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAEFC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCAF00: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BCAF04: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCAF08: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCAF0C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCAF10: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BCAF14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAF18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCAF1C: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x00BCAF20: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BCAF24: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BCAF28: CBZ x0, #0xbcaf8c          | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x00BCAF2C: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCAF30: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCAF34: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCAF38: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCAF3C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAF40: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCAF44: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCAF48: B.LO #0xbcaf64             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BCAF4C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCAF50: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCAF54: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCAF58: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCAF5C: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x00BCAF60: B.EQ #0xbcaf8c             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BCAF64: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCAF68: ADD x8, sp, #8             | X8 = (1152921510059755456 + 8) = 1152921510059755464 (0x100000014504C7C8);
            // 0x00BCAF6C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCAF70: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510059743552]
            // 0x00BCAF74: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BCAF78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAF7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BCAF80: ADD x0, sp, #8             | X0 = (1152921510059755456 + 8) = 1152921510059755464 (0x100000014504C7C8);
            // 0x00BCAF84: BL #0x299a140              | 
            // 0x00BCAF88: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x00BCAF8C: CBNZ x19, #0xbcaf94        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BCAF90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014504C7C8, ????);
            label_15:
            // 0x00BCAF94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCAF98: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCAF9C: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BCAFA0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCAFA4: CBNZ x21, #0xbcafac        | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x00BCAFA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BCAFAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCAFB0: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BCAFB4: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BCAFB8: BL #0xb901e8               | val_16.BattleStart(ev:  val_15);        
            val_16.BattleStart(ev:  val_15);
            // 0x00BCAFBC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCAFC0: SUB sp, x29, #0x40         | SP = (1152921510059755536 - 64) = 1152921510059755472 (0x100000014504C7D0);
            // 0x00BCAFC4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCAFC8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCAFCC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCAFD0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCAFD4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCAFD8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCAFDC: MOV x19, x0                | 
            // 0x00BCAFE0: MOV x0, sp                 | 
            // 0x00BCAFE4: B #0xbcaff0                | 
            // 0x00BCAFE8: MOV x19, x0                | 
            // 0x00BCAFEC: ADD x0, sp, #8             | 
            label_17:
            // 0x00BCAFF0: BL #0x299a140              | 
            // 0x00BCAFF4: MOV x0, x19                | 
            // 0x00BCAFF8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCAFFC (12365820), len: 776  VirtAddr: 0x00BCAFFC RVA: 0x00BCAFFC token: 100663856 methodIndex: 29901 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* BattleWin_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_14;
            //  | 
            CEvent.ZEvent val_15;
            //  | 
            var val_16;
            // 0x00BCAFFC: STP x26, x25, [sp, #-0x50]! | stack[1152921510059949392] = ???;  stack[1152921510059949400] = ???;  //  dest_result_addr=1152921510059949392 |  dest_result_addr=1152921510059949400
            // 0x00BCB000: STP x24, x23, [sp, #0x10]  | stack[1152921510059949408] = ???;  stack[1152921510059949416] = ???;  //  dest_result_addr=1152921510059949408 |  dest_result_addr=1152921510059949416
            // 0x00BCB004: STP x22, x21, [sp, #0x20]  | stack[1152921510059949424] = ???;  stack[1152921510059949432] = ???;  //  dest_result_addr=1152921510059949424 |  dest_result_addr=1152921510059949432
            // 0x00BCB008: STP x20, x19, [sp, #0x30]  | stack[1152921510059949440] = ???;  stack[1152921510059949448] = ???;  //  dest_result_addr=1152921510059949440 |  dest_result_addr=1152921510059949448
            // 0x00BCB00C: STP x29, x30, [sp, #0x40]  | stack[1152921510059949456] = ???;  stack[1152921510059949464] = ???;  //  dest_result_addr=1152921510059949456 |  dest_result_addr=1152921510059949464
            // 0x00BCB010: ADD x29, sp, #0x40         | X29 = (1152921510059949392 + 64) = 1152921510059949456 (0x100000014507BD90);
            // 0x00BCB014: SUB sp, sp, #0x10          | SP = (1152921510059949392 - 16) = 1152921510059949376 (0x100000014507BD40);
            // 0x00BCB018: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCB01C: LDRB w8, [x20, #0xbb7]     | W8 = (bool)static_value_03733BB7;       
            // 0x00BCB020: MOV x21, x3                | X21 = X3;//m1                           
            // 0x00BCB024: MOV x22, x2                | X22 = X2;//m1                           
            // 0x00BCB028: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCB02C: TBNZ w8, #0, #0xbcb048     | if (static_value_03733BB7 == true) goto label_0;
            // 0x00BCB030: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00BCB034: LDR x8, [x8, #0x3d8]       | X8 = 0x2B8F388;                         
            // 0x00BCB038: LDR w0, [x8]               | W0 = 0x13A4;                            
            // 0x00BCB03C: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A4, ????);     
            // 0x00BCB040: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCB044: STRB w8, [x20, #0xbb7]     | static_value_03733BB7 = true;            //  dest_result_addr=57883575
            label_0:
            // 0x00BCB048: CBNZ x19, #0xbcb050        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCB04C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A4, ????);     
            label_1:
            // 0x00BCB050: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB054: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB058: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCB05C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCB060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB064: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB068: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCB06C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCB070: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCB074: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCB078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB07C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB080: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCB084: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCB088: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCB08C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCB090: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCB094: ADRP x9, #0x3615000        | X9 = 56709120 (0x3615000);              
            // 0x00BCB098: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x00BCB09C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCB0A0: LDR x9, [x9, #0x668]       | X9 = 1152921504898326528;               
            // 0x00BCB0A4: LDR x25, [x9]              | X25 = typeof(CEvent.ZEvent);            
            // 0x00BCB0A8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCB0AC: TBZ w9, #0, #0xbcb0c0      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCB0B0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB0B4: CBNZ w9, #0xbcb0c0         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCB0B8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCB0BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCB0C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB0C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB0C8: MOV x1, x25                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x00BCB0CC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCB0D0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCB0D4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCB0D8: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x00BCB0DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCB0E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCB0E4: TBZ w9, #0, #0xbcb0f8      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCB0E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB0EC: CBNZ w9, #0xbcb0f8         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCB0F0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCB0F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCB0F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB0FC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCB100: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BCB104: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCB108: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCB10C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCB110: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCB114: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCB118: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x00BCB11C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCB120: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCB124: TBZ w9, #0, #0xbcb138      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCB128: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB12C: CBNZ w9, #0xbcb138         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCB130: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCB134: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCB138: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB13C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB140: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x00BCB144: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x00BCB148: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCB14C: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x00BCB150: CBZ x0, #0xbcb1b4          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCB154: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x00BCB158: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x00BCB15C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCB160: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x00BCB164: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCB168: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCB16C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCB170: B.LO #0xbcb18c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCB174: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCB178: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHie
            // 0x00BCB17C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCB180: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x00BCB184: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x00BCB188: B.EQ #0xbcb1b4             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCB18C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCB190: MOV x8, sp                 | X8 = 1152921510059949376 (0x100000014507BD40);//ML01
            // 0x00BCB194: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCB198: LDR x0, [sp]               | X0 = val_8;                              //  find_add[1152921510059937472]
            // 0x00BCB19C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCB1A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB1A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCB1A8: MOV x0, sp                 | X0 = 1152921510059949376 (0x100000014507BD40);//ML01
            // 0x00BCB1AC: BL #0x299a140              | 
            // 0x00BCB1B0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_10:
            // 0x00BCB1B4: CBNZ x19, #0xbcb1bc        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCB1B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014507BD40, ????);
            label_11:
            // 0x00BCB1BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB1C0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB1C4: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x00BCB1C8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCB1CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB1D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB1D4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00BCB1D8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x00BCB1DC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCB1E0: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00BCB1E4: LDR x8, [x8, #0xc50]       | X8 = 1152921504893906944;               
            // 0x00BCB1E8: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00BCB1EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB1F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB1F4: LDR x1, [x8]               | X1 = typeof(Biaoche);                   
            // 0x00BCB1F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCB1FC: MOV x24, x0                | X24 = val_10;//m1                       
            // 0x00BCB200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB204: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCB208: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BCB20C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCB210: MOV x3, x21                | X3 = X3;//m1                            
            // 0x00BCB214: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_11 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCB218: MOV x2, x0                 | X2 = val_11;//m1                        
            // 0x00BCB21C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB220: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB224: MOV x1, x24                | X1 = val_10;//m1                        
            // 0x00BCB228: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_12 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x00BCB22C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00BCB230: CBZ x0, #0xbcb294          | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x00BCB234: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCB238: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCB23C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCB240: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCB244: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCB248: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCB24C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCB250: B.LO #0xbcb26c             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00BCB254: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCB258: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCB25C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCB260: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCB264: MOV x21, x0                | X21 = val_12;//m1                       
            val_16 = val_12;
            // 0x00BCB268: B.EQ #0xbcb294             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x00BCB26C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCB270: ADD x8, sp, #8             | X8 = (1152921510059949376 + 8) = 1152921510059949384 (0x100000014507BD48);
            // 0x00BCB274: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCB278: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921510059937472]
            // 0x00BCB27C: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x00BCB280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB284: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x00BCB288: ADD x0, sp, #8             | X0 = (1152921510059949376 + 8) = 1152921510059949384 (0x100000014507BD48);
            // 0x00BCB28C: BL #0x299a140              | 
            // 0x00BCB290: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_14:
            // 0x00BCB294: CBNZ x19, #0xbcb29c        | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x00BCB298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014507BD48, ????);
            label_15:
            // 0x00BCB29C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB2A0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB2A4: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00BCB2A8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCB2AC: CBNZ x21, #0xbcb2b4        | if (0x0 != 0) goto label_16;            
            if(val_16 != 0)
            {
                goto label_16;
            }
            // 0x00BCB2B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_16:
            // 0x00BCB2B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB2B8: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB2BC: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB2C0: BL #0xb903f8               | val_16.BattleWin(ev:  val_15);          
            val_16.BattleWin(ev:  val_15);
            // 0x00BCB2C4: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCB2C8: SUB sp, x29, #0x40         | SP = (1152921510059949456 - 64) = 1152921510059949392 (0x100000014507BD50);
            // 0x00BCB2CC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCB2D0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCB2D4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCB2D8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00BCB2DC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00BCB2E0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCB2E4: MOV x19, x0                | 
            // 0x00BCB2E8: MOV x0, sp                 | 
            // 0x00BCB2EC: B #0xbcb2f8                | 
            // 0x00BCB2F0: MOV x19, x0                | 
            // 0x00BCB2F4: ADD x0, sp, #8             | 
            label_17:
            // 0x00BCB2F8: BL #0x299a140              | 
            // 0x00BCB2FC: MOV x0, x19                | 
            // 0x00BCB300: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCB304 (12366596), len: 536  VirtAddr: 0x00BCB304 RVA: 0x00BCB304 token: 100663857 methodIndex: 29902 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Clear_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00BCB304: STP x24, x23, [sp, #-0x40]! | stack[1152921510060131040] = ???;  stack[1152921510060131048] = ???;  //  dest_result_addr=1152921510060131040 |  dest_result_addr=1152921510060131048
            // 0x00BCB308: STP x22, x21, [sp, #0x10]  | stack[1152921510060131056] = ???;  stack[1152921510060131064] = ???;  //  dest_result_addr=1152921510060131056 |  dest_result_addr=1152921510060131064
            // 0x00BCB30C: STP x20, x19, [sp, #0x20]  | stack[1152921510060131072] = ???;  stack[1152921510060131080] = ???;  //  dest_result_addr=1152921510060131072 |  dest_result_addr=1152921510060131080
            // 0x00BCB310: STP x29, x30, [sp, #0x30]  | stack[1152921510060131088] = ???;  stack[1152921510060131096] = ???;  //  dest_result_addr=1152921510060131088 |  dest_result_addr=1152921510060131096
            // 0x00BCB314: ADD x29, sp, #0x30         | X29 = (1152921510060131040 + 48) = 1152921510060131088 (0x10000001450A8310);
            // 0x00BCB318: SUB sp, sp, #0x10          | SP = (1152921510060131040 - 16) = 1152921510060131024 (0x10000001450A82D0);
            // 0x00BCB31C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BCB320: LDRB w8, [x20, #0xbb8]     | W8 = (bool)static_value_03733BB8;       
            // 0x00BCB324: MOV x22, x3                | X22 = X3;//m1                           
            // 0x00BCB328: MOV x21, x2                | X21 = X2;//m1                           
            // 0x00BCB32C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BCB330: TBNZ w8, #0, #0xbcb34c     | if (static_value_03733BB8 == true) goto label_0;
            // 0x00BCB334: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00BCB338: LDR x8, [x8, #0x268]       | X8 = 0x2B8F38C;                         
            // 0x00BCB33C: LDR w0, [x8]               | W0 = 0x13A5;                            
            // 0x00BCB340: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A5, ????);     
            // 0x00BCB344: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCB348: STRB w8, [x20, #0xbb8]     | static_value_03733BB8 = true;            //  dest_result_addr=57883576
            label_0:
            // 0x00BCB34C: CBNZ x19, #0xbcb354        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BCB350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A5, ????);     
            label_1:
            // 0x00BCB354: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB358: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB35C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BCB360: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x00BCB364: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB368: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB36C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCB370: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCB374: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCB378: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BCB37C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB380: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB384: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00BCB388: MOV x1, x21                | X1 = X2;//m1                            
            // 0x00BCB38C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x00BCB390: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BCB394: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BCB398: ADRP x9, #0x35f1000        | X9 = 56561664 (0x35F1000);              
            // 0x00BCB39C: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00BCB3A0: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x00BCB3A4: LDR x9, [x9, #0xc50]       | X9 = 1152921504893906944;               
            // 0x00BCB3A8: LDR x24, [x9]              | X24 = typeof(Biaoche);                  
            // 0x00BCB3AC: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BCB3B0: TBZ w9, #0, #0xbcb3c4      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00BCB3B4: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB3B8: CBNZ w9, #0xbcb3c4         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00BCB3BC: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x00BCB3C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00BCB3C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB3C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB3CC: MOV x1, x24                | X1 = 1152921504893906944 (0x10000000111C3000);//ML01
            // 0x00BCB3D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BCB3D4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x00BCB3D8: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x00BCB3DC: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x00BCB3E0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x00BCB3E4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x00BCB3E8: TBZ w9, #0, #0xbcb3fc      | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00BCB3EC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB3F0: CBNZ w9, #0xbcb3fc         | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00BCB3F4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x00BCB3F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x00BCB3FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB400: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BCB404: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCB408: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x00BCB40C: MOV x3, x22                | X3 = X3;//m1                            
            // 0x00BCB410: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x00BCB414: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00BCB418: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x00BCB41C: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x00BCB420: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x00BCB424: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x00BCB428: TBZ w9, #0, #0xbcb43c      | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00BCB42C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x00BCB430: CBNZ w9, #0xbcb43c         | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00BCB434: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x00BCB438: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x00BCB43C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB440: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BCB444: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x00BCB448: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x00BCB44C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x00BCB450: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x00BCB454: CBZ x0, #0xbcb4b8          | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x00BCB458: ADRP x9, #0x35f5000        | X9 = 56578048 (0x35F5000);              
            // 0x00BCB45C: LDR x9, [x9, #0x330]       | X9 = 1152921504893906944;               
            // 0x00BCB460: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00BCB464: LDR x1, [x9]               | X1 = typeof(Biaoche);                   
            // 0x00BCB468: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCB46C: LDRB w9, [x1, #0x104]      | W9 = Biaoche.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BCB470: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Biaoche.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BCB474: B.LO #0xbcb490             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Biaoche.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x00BCB478: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00BCB47C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchy
            // 0x00BCB480: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BCB484: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Biaoche))
            // 0x00BCB488: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x00BCB48C: B.EQ #0xbcb4b8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Biaoche.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x00BCB490: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00BCB494: ADD x8, sp, #8             | X8 = (1152921510060131024 + 8) = 1152921510060131032 (0x10000001450A82D8);
            // 0x00BCB498: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00BCB49C: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510060119104]
            // 0x00BCB4A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00BCB4A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BCB4A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00BCB4AC: ADD x0, sp, #8             | X0 = (1152921510060131024 + 8) = 1152921510060131032 (0x10000001450A82D8);
            // 0x00BCB4B0: BL #0x299a140              | 
            // 0x00BCB4B4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x00BCB4B8: CBNZ x19, #0xbcb4c0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BCB4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001450A82D8, ????);
            label_11:
            // 0x00BCB4C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BCB4C4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BCB4C8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00BCB4CC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x00BCB4D0: CBNZ x22, #0xbcb4d8        | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x00BCB4D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x00BCB4D8: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00BCB4DC: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00BCB4E0: LDR x9, [x8, #0x400]       | X9 = mem[282584257677695];              
            // 0x00BCB4E4: LDR x1, [x8, #0x408]       | X1 = mem[282584257677703];              
            // 0x00BCB4E8: BLR x9                     | X0 = mem[282584257677695]();            
            // 0x00BCB4EC: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x00BCB4F0: SUB sp, x29, #0x30         | SP = (1152921510060131088 - 48) = 1152921510060131040 (0x10000001450A82E0);
            // 0x00BCB4F4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCB4F8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BCB4FC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BCB500: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BCB504: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x00BCB508: MOV x19, x0                | 
            // 0x00BCB50C: ADD x0, sp, #8             | 
            // 0x00BCB510: BL #0x299a140              | 
            // 0x00BCB514: MOV x0, x19                | 
            // 0x00BCB518: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00BCB51C (12367132), len: 72  VirtAddr: 0x00BCB51C RVA: 0x00BCB51C token: 100663858 methodIndex: 29903 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_MOVE_TO_END_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x00BCB51C: STP x20, x19, [sp, #-0x20]! | stack[1152921510060275760] = ???;  stack[1152921510060275768] = ???;  //  dest_result_addr=1152921510060275760 |  dest_result_addr=1152921510060275768
            // 0x00BCB520: STP x29, x30, [sp, #0x10]  | stack[1152921510060275776] = ???;  stack[1152921510060275784] = ???;  //  dest_result_addr=1152921510060275776 |  dest_result_addr=1152921510060275784
            // 0x00BCB524: ADD x29, sp, #0x10         | X29 = (1152921510060275760 + 16) = 1152921510060275776 (0x10000001450CB840);
            // 0x00BCB528: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BCB52C: LDRB w8, [x19, #0xbb9]     | W8 = (bool)static_value_03733BB9;       
            // 0x00BCB530: TBNZ w8, #0, #0xbcb54c     | if (static_value_03733BB9 == true) goto label_0;
            // 0x00BCB534: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x00BCB538: LDR x8, [x8, #0x7a0]       | X8 = 0x2B8F394;                         
            // 0x00BCB53C: LDR w0, [x8]               | W0 = 0x13A7;                            
            // 0x00BCB540: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A7, ????);     
            // 0x00BCB544: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BCB548: STRB w8, [x19, #0xbb9]     | static_value_03733BB9 = true;            //  dest_result_addr=57883577
            label_0:
            // 0x00BCB54C: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
            // 0x00BCB550: LDR x8, [x8, #0x558]       | X8 = (string**)(1152921510058805600)("MOVE_TO_END");
            // 0x00BCB554: LDR x0, [x8]               | X0 = "MOVE_TO_END";                     
            // 0x00BCB558: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BCB55C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BCB560: RET                        |  return (System.Object)"MOVE_TO_END";   
            return (object)"MOVE_TO_END";
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
