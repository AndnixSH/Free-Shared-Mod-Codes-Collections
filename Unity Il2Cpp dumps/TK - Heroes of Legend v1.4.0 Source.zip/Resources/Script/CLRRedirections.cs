using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    internal static class CLRRedirections
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E9C78 (42900600), len: 516  VirtAddr: 0x028E9C78 RVA: 0x028E9C78 token: 100680267 methodIndex: 29555 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* CreateInstance(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_5;
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x028E9C78: STP x22, x21, [sp, #-0x30]! | stack[1152921512888764304] = ???;  stack[1152921512888764312] = ???;  //  dest_result_addr=1152921512888764304 |  dest_result_addr=1152921512888764312
            // 0x028E9C7C: STP x20, x19, [sp, #0x10]  | stack[1152921512888764320] = ???;  stack[1152921512888764328] = ???;  //  dest_result_addr=1152921512888764320 |  dest_result_addr=1152921512888764328
            // 0x028E9C80: STP x29, x30, [sp, #0x20]  | stack[1152921512888764336] = ???;  stack[1152921512888764344] = ???;  //  dest_result_addr=1152921512888764336 |  dest_result_addr=1152921512888764344
            // 0x028E9C84: ADD x29, sp, #0x20         | X29 = (1152921512888764304 + 32) = 1152921512888764336 (0x10000001EDA407B0);
            // 0x028E9C88: SUB sp, sp, #0x10          | SP = (1152921512888764304 - 16) = 1152921512888764288 (0x10000001EDA40780);
            // 0x028E9C8C: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028E9C90: LDRB w8, [x22, #0x9fb]     | W8 = (bool)static_value_037B89FB;       
            // 0x028E9C94: MOV x21, x4                | X21 = X4;//m1                           
            // 0x028E9C98: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028E9C9C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x028E9CA0: TBNZ w8, #0, #0x28e9cbc    | if (static_value_037B89FB == true) goto label_0;
            // 0x028E9CA4: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x028E9CA8: LDR x8, [x8, #0xf68]       | X8 = 0x2B90CB8;                         
            // 0x028E9CAC: LDR w0, [x8]               | W0 = 0x19F2;                            
            // 0x028E9CB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F2, ????);     
            // 0x028E9CB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028E9CB8: STRB w8, [x22, #0x9fb]     | static_value_037B89FB = true;            //  dest_result_addr=58427899
            label_0:
            // 0x028E9CBC: CBNZ x21, #0x28e9cc4       | if (X4 != 0) goto label_1;              
            if(X4 != 0)
            {
                goto label_1;
            }
            // 0x028E9CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x19F2, ????);     
            label_1:
            // 0x028E9CC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E9CC8: MOV x0, x21                | X0 = X4;//m1                            
            // 0x028E9CCC: BL #0x10ecb74              | X0 = X4.get_GenericArguments();         
            ILRuntime.CLR.TypeSystem.IType[] val_1 = X4.GenericArguments;
            // 0x028E9CD0: CBZ x0, #0x28e9e28         | if (val_1 == null) goto label_3;        
            if(val_1 == null)
            {
                goto label_3;
            }
            // 0x028E9CD4: LDR w8, [x0, #0x18]        | W8 = val_1.Length; //P2                 
            // 0x028E9CD8: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
            // 0x028E9CDC: B.NE #0x28e9e28            | if (val_1.Length != 1) goto label_3;    
            if(val_1.Length != 1)
            {
                goto label_3;
            }
            // 0x028E9CE0: LDR x21, [x0, #0x20]       | X21 = val_1[0]                          
            val_10 = val_1[0];
            // 0x028E9CE4: CBZ x21, #0x28e9d6c        | if (val_1[0] == null) goto label_14;    
            if(val_10 == null)
            {
                goto label_14;
            }
            // 0x028E9CE8: ADRP x9, #0x366d000        | X9 = 57069568 (0x366D000);              
            // 0x028E9CEC: LDR x9, [x9, #0x108]       | X9 = 1152921504782192640;               
            // 0x028E9CF0: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028E9CF4: LDR x10, [x9]              | X10 = typeof(ILRuntime.CLR.TypeSystem.ILType);
            // 0x028E9CF8: LDRB w9, [x8, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9CFC: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9D00: CMP w9, w11                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028E9D04: B.LO #0x28e9d1c            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028E9D08: LDR x12, [x8, #0xb0]       | X12 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x028E9D0C: ADD x11, x12, x11, lsl #3  | X11 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem
            // 0x028E9D10: LDUR x11, [x11, #-8]       | X11 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028E9D14: CMP x11, x10               | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.ILType))
            // 0x028E9D18: B.EQ #0x28e9e0c            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.ILType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_6;
            label_5:
            // 0x028E9D1C: ADRP x10, #0x35c2000       | X10 = 56369152 (0x35C2000);             
            // 0x028E9D20: LDR x10, [x10, #0x290]     | X10 = 1152921504782032896;              
            // 0x028E9D24: LDR x1, [x10]              | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x028E9D28: LDRB w10, [x1, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9D2C: CMP w9, w10                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028E9D30: B.LO #0x28e9d48            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_7;
            // 0x028E9D34: LDR x9, [x8, #0xb0]        | X9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x028E9D38: ADD x9, x9, x10, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x028E9D3C: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028E9D40: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x028E9D44: B.EQ #0x28e9e20            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_8;
            label_7:
            // 0x028E9D48: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x028E9D4C: MOV x8, sp                 | X8 = 1152921512888764288 (0x10000001EDA40780);//ML01
            // 0x028E9D50: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x028E9D54: LDR x0, [sp]               | X0 = val_3;                              //  find_add[1152921512888752352]
            // 0x028E9D58: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x028E9D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E9D60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x028E9D64: MOV x0, sp                 | X0 = 1152921512888764288 (0x10000001EDA40780);//ML01
            // 0x028E9D68: BL #0x299a140              | 
            label_14:
            // 0x028E9D6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDA40780, ????);
            label_13:
            // 0x028E9D70: CBZ x21, #0x28e9dcc        | if (val_1[0] == null) goto label_9;     
            if(val_10 == null)
            {
                goto label_9;
            }
            // 0x028E9D74: ADRP x9, #0x35c2000        | X9 = 56369152 (0x35C2000);              
            // 0x028E9D78: LDR x9, [x9, #0x290]       | X9 = 1152921504782032896;               
            // 0x028E9D7C: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028E9D80: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.CLRType);
            // 0x028E9D84: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9D88: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9D8C: CMP w10, w9                | STATE = COMPARE(ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028E9D90: B.LO #0x28e9da8            | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x028E9D94: LDR x10, [x8, #0xb0]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy;
            // 0x028E9D98: ADD x9, x10, x9, lsl #3    | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.
            // 0x028E9D9C: LDUR x9, [x9, #-8]         | X9 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028E9DA0: CMP x9, x1                 | STATE = COMPARE((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.CLR.TypeSystem.CLRType))
            // 0x028E9DA4: B.EQ #0x28e9dd0            | if ((ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_typeHierarchy + (ILRuntime.CLR.TypeSystem.CLRType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x028E9DA8: LDR x0, [x8, #0x30]        | X0 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class;
            // 0x028E9DAC: ADD x8, sp, #8             | X8 = (1152921512888764288 + 8) = 1152921512888764296 (0x10000001EDA40788);
            // 0x028E9DB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_element_class, ????);
            // 0x028E9DB4: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921512888752352]
            // 0x028E9DB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028E9DBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E9DC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028E9DC4: ADD x0, sp, #8             | X0 = (1152921512888764288 + 8) = 1152921512888764296 (0x10000001EDA40788);
            // 0x028E9DC8: BL #0x299a140              | 
            label_9:
            // 0x028E9DCC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_11:
            // 0x028E9DD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E9DD4: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028E9DD8: BL #0x10f6834              | X0 = val_10.CreateDefaultInstance();    
            object val_6 = val_10.CreateDefaultInstance();
            label_12:
            // 0x028E9DDC: MOV x3, x0                 | X3 = val_6;//m1                         
            // 0x028E9DE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9DE4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028E9DE8: MOV x1, x20                | X1 = X2;//m1                            
            // 0x028E9DEC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028E9DF0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028E9DF4: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028E9DF8: SUB sp, x29, #0x20         | SP = (1152921512888764336 - 32) = 1152921512888764304 (0x10000001EDA40790);
            // 0x028E9DFC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9E00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9E04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E9E08: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_7;
            return val_7;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_6:
            // 0x028E9E0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028E9E10: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028E9E14: MOV x0, x21                | X0 = val_1[0];//m1                      
            // 0x028E9E18: BL #0x10fcde0              | X0 = val_1[0].Instantiate(callDefaultConstructor:  true);
            ILRuntime.Runtime.Intepreter.ILTypeInstance val_8 = val_10.Instantiate(callDefaultConstructor:  true);
            // 0x028E9E1C: B #0x28e9ddc               |  goto label_12;                         
            goto label_12;
            label_8:
            // 0x028E9E20: CBNZ x21, #0x28e9d70       | if (val_1[0] != null) goto label_13;    
            if(val_10 != null)
            {
                goto label_13;
            }
            // 0x028E9E24: B #0x28e9d6c               |  goto label_14;                         
            goto label_14;
            label_3:
            // 0x028E9E28: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x028E9E2C: LDR x8, [x8, #0xd18]       | X8 = 1152921504653279232;               
            // 0x028E9E30: LDR x0, [x8]               | X0 = typeof(System.EntryPointNotFoundException);
            System.EntryPointNotFoundException val_9 = null;
            // 0x028E9E34: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.EntryPointNotFoundException), ????);
            // 0x028E9E38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028E9E3C: MOV x19, x0                | X19 = 1152921504653279232 (0x1000000002C48000);//ML01
            // 0x028E9E40: BL #0x1c388e4              | .ctor();                                
            val_9 = new System.EntryPointNotFoundException();
            // 0x028E9E44: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x028E9E48: LDR x8, [x8, #0x650]       | X8 = 1152921512878257136;               
            // 0x028E9E4C: MOV x0, x19                | X0 = 1152921504653279232 (0x1000000002C48000);//ML01
            // 0x028E9E50: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::CreateInstance(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028E9E54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.EntryPointNotFoundException), ????);
            // 0x028E9E58: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
            // 0x028E9E5C: MOV x19, x0                | X19 = 1152921504653279232 (0x1000000002C48000);//ML01
            val_11 = val_9;
            // 0x028E9E60: MOV x0, sp                 | X0 = 1152921512888764288 (0x10000001EDA40780);//ML01
            val_12;
            // 0x028E9E64: B #0x28e9e70               |  goto label_15;                         
            goto label_15;
            // 0x028E9E68: MOV x19, x0                | X19 = 1152921512888764288 (0x10000001EDA40780);//ML01
            val_11 = val_12;
            // 0x028E9E6C: ADD x0, sp, #8             | X0 = (1152921512888764288 + 8) = 1152921512888764296 (0x10000001EDA40788);
            label_15:
            // 0x028E9E70: BL #0x299a140              | 
            // 0x028E9E74: MOV x0, x19                | X0 = 1152921512888764288 (0x10000001EDA40780);//ML01
            // 0x028E9E78: BL #0x980800               | X0 = sub_980800( ?? 0x10000001EDA40780, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9E7C (42901116), len: 548  VirtAddr: 0x028E9E7C RVA: 0x028E9E7C token: 100680268 methodIndex: 29556 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* CreateInstance2(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028E9E7C: STP x22, x21, [sp, #-0x30]! | stack[1152921512888962320] = ???;  stack[1152921512888962328] = ???;  //  dest_result_addr=1152921512888962320 |  dest_result_addr=1152921512888962328
            // 0x028E9E80: STP x20, x19, [sp, #0x10]  | stack[1152921512888962336] = ???;  stack[1152921512888962344] = ???;  //  dest_result_addr=1152921512888962336 |  dest_result_addr=1152921512888962344
            // 0x028E9E84: STP x29, x30, [sp, #0x20]  | stack[1152921512888962352] = ???;  stack[1152921512888962360] = ???;  //  dest_result_addr=1152921512888962352 |  dest_result_addr=1152921512888962360
            // 0x028E9E88: ADD x29, sp, #0x20         | X29 = (1152921512888962320 + 32) = 1152921512888962352 (0x10000001EDA70D30);
            // 0x028E9E8C: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028E9E90: LDRB w8, [x22, #0x9fc]     | W8 = (bool)static_value_037B89FC;       
            // 0x028E9E94: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028E9E98: MOV x20, x2                | X20 = X2;//m1                           
            var val_6 = X2;
            // 0x028E9E9C: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028E9EA0: TBNZ w8, #0, #0x28e9ebc    | if (static_value_037B89FC == true) goto label_0;
            // 0x028E9EA4: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x028E9EA8: LDR x8, [x8, #0x4d8]       | X8 = 0x2B90CBC;                         
            // 0x028E9EAC: LDR w0, [x8]               | W0 = 0x19F3;                            
            // 0x028E9EB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F3, ????);     
            // 0x028E9EB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028E9EB8: STRB w8, [x22, #0x9fc]     | static_value_037B89FC = true;            //  dest_result_addr=58427900
            label_0:
            // 0x028E9EBC: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028E9EC0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028E9EC4: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028E9EC8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_7 = 8;
            // 0x028E9ECC: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028E9ED0: TBZ w9, #0, #0x28e9ee0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_1;
            // 0x028E9ED4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028E9ED8: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028E9EDC: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_7 = 219381744;
            label_1:
            // 0x028E9EE0: SUBS x20, x20, x8          | X20 = (X2 - val_7);                     
            val_6 = val_6 - val_7;
            // 0x028E9EE4: B.NE #0x28e9eec            | if ( != ) goto label_2;                 
            if()
            {
                goto label_2;
            }
            // 0x028E9EE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_2:
            // 0x028E9EEC: LDR w22, [x20, #4]         | W22 = (X2 - val_7) + 4;                 
            // 0x028E9EF0: CBNZ x19, #0x28e9ef8       | if (X3 != 0) goto label_3;              
            if(X3 != 0)
            {
                goto label_3;
            }
            // 0x028E9EF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_3:
            // 0x028E9EF8: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x028E9EFC: LDR x8, [x19]              | X8 = X3;                                
            var val_10 = X3;
            // 0x028E9F00: LDR x9, [x9, #0x490]       | X9 = 1152921504609402880;               
            // 0x028E9F04: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x028E9F08: LDRH w9, [x8, #0x102]      | W9 = X3 + 258;                          
            // 0x028E9F0C: CBZ x9, #0x28e9f38         | if (X3 + 258 == 0) goto label_4;        
            if((X3 + 258) == 0)
            {
                goto label_4;
            }
            // 0x028E9F10: LDR x10, [x8, #0x98]       | X10 = X3 + 152;                         
            var val_7 = X3 + 152;
            // 0x028E9F14: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028E9F18: ADD x10, x10, #8           | X10 = (X3 + 152 + 8);                   
            val_7 = val_7 + 8;
            label_6:
            // 0x028E9F1C: LDUR x12, [x10, #-8]       | X12 = (X3 + 152 + 8) + -8;              
            // 0x028E9F20: CMP x12, x1                | STATE = COMPARE((X3 + 152 + 8) + -8, typeof(System.Collections.Generic.IList<T>))
            // 0x028E9F24: B.EQ #0x28e9f48            | if ((X3 + 152 + 8) + -8 == null) goto label_5;
            if(((X3 + 152 + 8) + -8) == null)
            {
                goto label_5;
            }
            // 0x028E9F28: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028E9F2C: ADD x10, x10, #0x10        | X10 = ((X3 + 152 + 8) + 16);            
            val_7 = val_7 + 16;
            // 0x028E9F30: CMP x11, x9                | STATE = COMPARE((0 + 1), X3 + 258)      
            // 0x028E9F34: B.LO #0x28e9f1c            | if (0 < X3 + 258) goto label_6;         
            if(val_8 < (X3 + 258))
            {
                goto label_6;
            }
            label_4:
            // 0x028E9F38: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028E9F3C: MOV x0, x19                | X0 = X3;//m1                            
            val_8 = X3;
            // 0x028E9F40: BL #0x2776c24              | X0 = sub_2776C24( ?? X3, ????);         
            // 0x028E9F44: B #0x28e9f58               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x028E9F48: LDR w9, [x10]              | W9 = (X3 + 152 + 8);                    
            var val_9 = val_7;
            // 0x028E9F4C: ADD w9, w9, #3             | W9 = ((X3 + 152 + 8) + 3);              
            val_9 = val_9 + 3;
            // 0x028E9F50: ADD x8, x8, w9, uxtw #4    | X8 = (X3 + ((X3 + 152 + 8) + 3));       
            val_10 = val_10 + val_9;
            // 0x028E9F54: ADD x0, x8, #0x110         | X0 = ((X3 + ((X3 + 152 + 8) + 3)) + 272);
            val_8 = val_10 + 272;
            label_7:
            // 0x028E9F58: LDP x8, x2, [x0]           | X8 = ((X3 + ((X3 + 152 + 8) + 3)) + 272); X2 = ((X3 + ((X3 + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x028E9F5C: MOV x0, x19                | X0 = X3;//m1                            
            // 0x028E9F60: MOV w1, w22                | W1 = (X2 - val_7) + 4;//m1              
            // 0x028E9F64: BLR x8                     | X0 = ((X3 + ((X3 + 152 + 8) + 3)) + 272)();
            // 0x028E9F68: CBZ x0, #0x28e9f8c         | if (X3 == 0) goto label_8;              
            if(X3 == 0)
            {
                goto label_8;
            }
            // 0x028E9F6C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028E9F70: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028E9F74: LDR x9, [x0]               | X9 = X3;                                
            // 0x028E9F78: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028E9F7C: LDRB w11, [x9, #0x104]     | W11 = X3 + 260;                         
            // 0x028E9F80: LDRB w10, [x8, #0x104]     | W10 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9F84: CMP w11, w10               | STATE = COMPARE(X3 + 260, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028E9F88: B.HS #0x28e9f94            | if (X3 + 260 >= System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            label_8:
            // 0x028E9F8C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028E9F90: B #0x28e9fa8               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x028E9F94: LDR x9, [x9, #0xb0]        | X9 = X3 + 176;                          
            // 0x028E9F98: ADD x9, x9, x10, lsl #3    | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028E9F9C: LDUR x9, [x9, #-8]         | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028E9FA0: CMP x9, x8                 | STATE = COMPARE((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028E9FA4: CSEL x22, x0, xzr, eq      | X22 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;
            var val_1 = (((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (X3) : 0;
            label_10:
            // 0x028E9FA8: CBNZ x21, #0x28e9fb0       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028E9FAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3, ????);         
            label_11:
            // 0x028E9FB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028E9FB4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028E9FB8: MOV x1, x20                | X1 = (X2 - val_7);//m1                  
            // 0x028E9FBC: BL #0x1f8e3a4              | X1.Free(esp:  ???);                     
            X1.Free(esp:  ???);
            // 0x028E9FC0: CBZ x22, #0x28ea030        | if ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 == 0) goto label_12;
            // 0x028E9FC4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x028E9FC8: LDR x8, [x8, #0x950]       | X8 = 1152921504821596160;               
            // 0x028E9FCC: LDR x9, [x22]              | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;
            // 0x028E9FD0: LDR x8, [x8]               | X8 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028E9FD4: LDRB w11, [x9, #0x104]     | W11 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 260;
            // 0x028E9FD8: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028E9FDC: CMP w11, w10               | STATE = COMPARE((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 260, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028E9FE0: B.LO #0x28e9ff8            | if ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 260 < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028E9FE4: LDR x9, [x9, #0xb0]        | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176;
            // 0x028E9FE8: ADD x9, x9, x10, lsl #3    | X9 = ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 
            // 0x028E9FEC: LDUR x9, [x9, #-8]         | X9 = ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176 + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028E9FF0: CMP x9, x8                 | STATE = COMPARE(((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176 + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028E9FF4: B.EQ #0x28ea04c            | if (((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176 + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028E9FF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9FFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA000: MOV x1, x22                | X1 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;//m1
            // 0x028EA004: BL #0x18c8eb0              | X0 = System.Activator.CreateInstance(type:  0);
            object val_2 = System.Activator.CreateInstance(type:  0);
            // 0x028EA008: MOV x1, x20                | X1 = (X2 - val_7);//m1                  
            // 0x028EA00C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EA010: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA014: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA018: MOV x3, x0                 | X3 = val_2;//m1                         
            // 0x028EA01C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA020: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EA024: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EA028: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EA02C: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            label_12:
            // 0x028EA030: MOV x1, x20                | X1 = (X2 - val_7);//m1                  
            // 0x028EA034: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA038: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA03C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA040: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA044: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EA048: B #0x1f94458               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  esp);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  esp);
            label_14:
            // 0x028EA04C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA050: MOV x0, x22                | X0 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;//m1
            // 0x028EA054: BL #0x1100c9c              | X0 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0.get_ILType();
            ILRuntime.CLR.TypeSystem.ILType val_3 = val_1.ILType;
            // 0x028EA058: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028EA05C: CBNZ x21, #0x28ea064       | if (val_3 != null) goto label_15;       
            if(val_3 != null)
            {
                goto label_15;
            }
            // 0x028EA060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_15:
            // 0x028EA064: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA068: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028EA06C: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EA070: BL #0x10fcde0              | X0 = val_3.Instantiate(callDefaultConstructor:  true);
            ILRuntime.Runtime.Intepreter.ILTypeInstance val_4 = val_3.Instantiate(callDefaultConstructor:  true);
            // 0x028EA074: MOV x3, x0                 | X3 = val_4;//m1                         
            // 0x028EA078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA07C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EA080: MOV x1, x20                | X1 = (X2 - val_7);//m1                  
            // 0x028EA084: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EA088: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EA08C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  ???, mStack:  ???, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  ???, mStack:  ???, obj:  ???, isBox:  ???);
            // 0x028EA090: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA094: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA098: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EA09C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_5;
            return val_5;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028EA0A0 (42901664), len: 924  VirtAddr: 0x028EA0A0 RVA: 0x028EA0A0 token: 100680269 methodIndex: 29557 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* CreateInstance3(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            System.Object[] val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x028EA0A0: STP x26, x25, [sp, #-0x50]! | stack[1152921512889123440] = ???;  stack[1152921512889123448] = ???;  //  dest_result_addr=1152921512889123440 |  dest_result_addr=1152921512889123448
            // 0x028EA0A4: STP x24, x23, [sp, #0x10]  | stack[1152921512889123456] = ???;  stack[1152921512889123464] = ???;  //  dest_result_addr=1152921512889123456 |  dest_result_addr=1152921512889123464
            // 0x028EA0A8: STP x22, x21, [sp, #0x20]  | stack[1152921512889123472] = ???;  stack[1152921512889123480] = ???;  //  dest_result_addr=1152921512889123472 |  dest_result_addr=1152921512889123480
            // 0x028EA0AC: STP x20, x19, [sp, #0x30]  | stack[1152921512889123488] = ???;  stack[1152921512889123496] = ???;  //  dest_result_addr=1152921512889123488 |  dest_result_addr=1152921512889123496
            // 0x028EA0B0: STP x29, x30, [sp, #0x40]  | stack[1152921512889123504] = ???;  stack[1152921512889123512] = ???;  //  dest_result_addr=1152921512889123504 |  dest_result_addr=1152921512889123512
            // 0x028EA0B4: ADD x29, sp, #0x40         | X29 = (1152921512889123440 + 64) = 1152921512889123504 (0x10000001EDA982B0);
            // 0x028EA0B8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EA0BC: LDRB w8, [x20, #0x9fd]     | W8 = (bool)static_value_037B89FD;       
            // 0x028EA0C0: MOV x19, x3                | X19 = X3;//m1                           
            val_11 = X3;
            // 0x028EA0C4: MOV x22, x2                | X22 = X2;//m1                           
            var val_13 = X2;
            // 0x028EA0C8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028EA0CC: TBNZ w8, #0, #0x28ea0e8    | if (static_value_037B89FD == true) goto label_0;
            // 0x028EA0D0: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x028EA0D4: LDR x8, [x8, #0x368]       | X8 = 0x2B90CC0;                         
            // 0x028EA0D8: LDR w0, [x8]               | W0 = 0x19F4;                            
            // 0x028EA0DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F4, ????);     
            // 0x028EA0E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EA0E4: STRB w8, [x20, #0x9fd]     | static_value_037B89FD = true;            //  dest_result_addr=58427901
            label_0:
            // 0x028EA0E8: ADRP x24, #0x366f000       | X24 = 57077760 (0x366F000);             
            // 0x028EA0EC: LDR x24, [x24, #0x7a0]     | X24 = 1152921504826228736;              
            // 0x028EA0F0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA0F4: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EA0F8: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EA0FC: TBNZ w9, #0, #0x28ea108    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EA100: ORR w20, wzr, #8           | W20 = 8(0x8);                           
            val_13 = 8;
            // 0x028EA104: B #0x28ea120               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EA108: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EA10C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EA110: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA114: SUB w20, w0, #0x10         | W20 = (null - 16) = val_13 (0x100000000D137FF0);
            val_13 = 1152921504826228720;
            // 0x028EA118: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EA11C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EA120: TBNZ w9, #0, #0x28ea12c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EA124: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_14 = 8;
            // 0x028EA128: B #0x28ea138               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EA12C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EA130: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EA134: SUB w8, w0, #0x10          | W8 = (null - 16) = val_14 (0x100000000D137FF0);
            val_14 = 1152921504826228720;
            label_4:
            // 0x028EA138: SUB x9, x22, w20, sxtw     | X9 = (X2 - (val_13) << );               
            var val_1 = val_13 - (val_13 << );
            // 0x028EA13C: SUBS x20, x9, w8, sxtw     | X20 = ((X2 - (val_13) << ) - (val_14) << );
            val_13 = val_1 - (val_14 << );
            // 0x028EA140: B.NE #0x28ea148            | if ( != ) goto label_5;                 
            if()
            {
                goto label_5;
            }
            // 0x028EA144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EA148: LDR w23, [x20, #4]         | W23 = ((X2 - (val_13) << ) - (val_14) << ) + 4;
            // 0x028EA14C: CBNZ x19, #0x28ea154       | if (X3 != 0) goto label_6;              
            if(val_11 != 0)
            {
                goto label_6;
            }
            // 0x028EA150: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x028EA154: ADRP x25, #0x35e6000       | X25 = 56516608 (0x35E6000);             
            // 0x028EA158: LDR x8, [x19]              | X8 = X3;                                
            var val_12 = val_11;
            // 0x028EA15C: LDR x25, [x25, #0x490]     | X25 = 1152921504609402880;              
            // 0x028EA160: LDRH w9, [x8, #0x102]      | W9 = X3 + 258;                          
            // 0x028EA164: LDR x1, [x25]              | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x028EA168: CBZ x9, #0x28ea194         | if (X3 + 258 == 0) goto label_7;        
            if((X3 + 258) == 0)
            {
                goto label_7;
            }
            // 0x028EA16C: LDR x10, [x8, #0x98]       | X10 = X3 + 152;                         
            var val_9 = X3 + 152;
            // 0x028EA170: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x028EA174: ADD x10, x10, #8           | X10 = (X3 + 152 + 8);                   
            val_9 = val_9 + 8;
            label_9:
            // 0x028EA178: LDUR x12, [x10, #-8]       | X12 = (X3 + 152 + 8) + -8;              
            // 0x028EA17C: CMP x12, x1                | STATE = COMPARE((X3 + 152 + 8) + -8, typeof(System.Collections.Generic.IList<T>))
            // 0x028EA180: B.EQ #0x28ea1a4            | if ((X3 + 152 + 8) + -8 == null) goto label_8;
            if(((X3 + 152 + 8) + -8) == null)
            {
                goto label_8;
            }
            // 0x028EA184: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x028EA188: ADD x10, x10, #0x10        | X10 = ((X3 + 152 + 8) + 16);            
            val_9 = val_9 + 16;
            // 0x028EA18C: CMP x11, x9                | STATE = COMPARE((0 + 1), X3 + 258)      
            // 0x028EA190: B.LO #0x28ea178            | if (0 < X3 + 258) goto label_9;         
            if(val_10 < (X3 + 258))
            {
                goto label_9;
            }
            label_7:
            // 0x028EA194: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028EA198: MOV x0, x19                | X0 = X3;//m1                            
            val_15 = val_11;
            // 0x028EA19C: BL #0x2776c24              | X0 = sub_2776C24( ?? X3, ????);         
            // 0x028EA1A0: B #0x28ea1b4               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x028EA1A4: LDR w9, [x10]              | W9 = (X3 + 152 + 8);                    
            var val_11 = val_9;
            // 0x028EA1A8: ADD w9, w9, #3             | W9 = ((X3 + 152 + 8) + 3);              
            val_11 = val_11 + 3;
            // 0x028EA1AC: ADD x8, x8, w9, uxtw #4    | X8 = (X3 + ((X3 + 152 + 8) + 3));       
            val_12 = val_12 + val_11;
            // 0x028EA1B0: ADD x0, x8, #0x110         | X0 = ((X3 + ((X3 + 152 + 8) + 3)) + 272);
            val_15 = val_12 + 272;
            label_10:
            // 0x028EA1B4: LDP x8, x2, [x0]           | X8 = ((X3 + ((X3 + 152 + 8) + 3)) + 272); X2 = ((X3 + ((X3 + 152 + 8) + 3)) + 272) + 8; //  | 
            val_16 = mem[((X3 + ((X3 + 152 + 8) + 3)) + 272) + 8];
            val_16 = ((X3 + ((X3 + 152 + 8) + 3)) + 272) + 8;
            // 0x028EA1B8: MOV x0, x19                | X0 = X3;//m1                            
            // 0x028EA1BC: MOV w1, w23                | W1 = ((X2 - (val_13) << ) - (val_14) << ) + 4;//m1
            // 0x028EA1C0: BLR x8                     | X0 = ((X3 + ((X3 + 152 + 8) + 3)) + 272)();
            // 0x028EA1C4: CBZ x0, #0x28ea1e8         | if (X3 == 0) goto label_11;             
            if(val_11 == 0)
            {
                goto label_11;
            }
            // 0x028EA1C8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028EA1CC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028EA1D0: LDR x9, [x0]               | X9 = X3;                                
            // 0x028EA1D4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028EA1D8: LDRB w11, [x9, #0x104]     | W11 = X3 + 260;                         
            // 0x028EA1DC: LDRB w10, [x8, #0x104]     | W10 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA1E0: CMP w11, w10               | STATE = COMPARE(X3 + 260, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA1E4: B.HS #0x28ea1f0            | if (X3 + 260 >= System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_12;
            label_11:
            // 0x028EA1E8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x028EA1EC: B #0x28ea204               |  goto label_13;                         
            goto label_13;
            label_12:
            // 0x028EA1F0: LDR x9, [x9, #0xb0]        | X9 = X3 + 176;                          
            // 0x028EA1F4: ADD x9, x9, x10, lsl #3    | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028EA1F8: LDUR x9, [x9, #-8]         | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EA1FC: CMP x9, x8                 | STATE = COMPARE((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EA200: CSEL x23, x0, xzr, eq      | X23 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;
            System.Object[] val_2 = (((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_11) : 0;
            label_13:
            // 0x028EA204: LDR x0, [x24]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA208: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_18 = 8;
            // 0x028EA20C: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EA210: TBZ w9, #0, #0x28ea220     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_14;
            // 0x028EA214: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EA218: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EA21C: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_18 = 219381744;
            label_14:
            // 0x028EA220: SUBS x22, x22, x8          | X22 = (X2 - val_18);                    
            val_13 = val_13 - val_18;
            // 0x028EA224: B.NE #0x28ea22c            | if ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_15;
            // 0x028EA228: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_15:
            // 0x028EA22C: LDR w22, [x22, #4]         | W22 = (X2 - val_18) + 4;                
            // 0x028EA230: CBNZ x19, #0x28ea238       | if (X3 != 0) goto label_16;             
            if(val_11 != 0)
            {
                goto label_16;
            }
            // 0x028EA234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_16:
            // 0x028EA238: LDR x8, [x19]              | X8 = X3;                                
            var val_17 = val_11;
            // 0x028EA23C: LDR x1, [x25]              | X1 = typeof(System.Collections.Generic.IList<T>);
            // 0x028EA240: LDRH w9, [x8, #0x102]      | W9 = X3 + 258;                          
            // 0x028EA244: CBZ x9, #0x28ea270         | if (X3 + 258 == 0) goto label_17;       
            if((X3 + 258) == 0)
            {
                goto label_17;
            }
            // 0x028EA248: LDR x10, [x8, #0x98]       | X10 = X3 + 152;                         
            var val_14 = X3 + 152;
            // 0x028EA24C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x028EA250: ADD x10, x10, #8           | X10 = (X3 + 152 + 8);                   
            val_14 = val_14 + 8;
            label_19:
            // 0x028EA254: LDUR x12, [x10, #-8]       | X12 = (X3 + 152 + 8) + -8;              
            // 0x028EA258: CMP x12, x1                | STATE = COMPARE((X3 + 152 + 8) + -8, typeof(System.Collections.Generic.IList<T>))
            // 0x028EA25C: B.EQ #0x28ea280            | if ((X3 + 152 + 8) + -8 == null) goto label_18;
            if(((X3 + 152 + 8) + -8) == null)
            {
                goto label_18;
            }
            // 0x028EA260: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x028EA264: ADD x10, x10, #0x10        | X10 = ((X3 + 152 + 8) + 16);            
            val_14 = val_14 + 16;
            // 0x028EA268: CMP x11, x9                | STATE = COMPARE((0 + 1), X3 + 258)      
            // 0x028EA26C: B.LO #0x28ea254            | if (0 < X3 + 258) goto label_19;        
            if(val_15 < (X3 + 258))
            {
                goto label_19;
            }
            label_17:
            // 0x028EA270: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            val_16 = 3;
            // 0x028EA274: MOV x0, x19                | X0 = X3;//m1                            
            val_19 = val_11;
            // 0x028EA278: BL #0x2776c24              | X0 = sub_2776C24( ?? X3, ????);         
            // 0x028EA27C: B #0x28ea290               |  goto label_20;                         
            goto label_20;
            label_18:
            // 0x028EA280: LDR w9, [x10]              | W9 = (X3 + 152 + 8);                    
            var val_16 = val_14;
            // 0x028EA284: ADD w9, w9, #3             | W9 = ((X3 + 152 + 8) + 3);              
            val_16 = val_16 + 3;
            // 0x028EA288: ADD x8, x8, w9, uxtw #4    | X8 = (X3 + ((X3 + 152 + 8) + 3));       
            val_17 = val_17 + val_16;
            // 0x028EA28C: ADD x0, x8, #0x110         | X0 = ((X3 + ((X3 + 152 + 8) + 3)) + 272);
            val_19 = val_17 + 272;
            label_20:
            // 0x028EA290: LDP x8, x2, [x0]           | X8 = ((X3 + ((X3 + 152 + 8) + 3)) + 272); X2 = ((X3 + ((X3 + 152 + 8) + 3)) + 272) + 8; //  | 
            // 0x028EA294: MOV x0, x19                | X0 = X3;//m1                            
            // 0x028EA298: MOV w1, w22                | W1 = (X2 - val_18) + 4;//m1             
            // 0x028EA29C: BLR x8                     | X0 = ((X3 + ((X3 + 152 + 8) + 3)) + 272)();
            // 0x028EA2A0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028EA2A4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x028EA2A8: LDR x1, [x8]               | X1 = typeof(System.Object[]);           
            // 0x028EA2AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X3, ????);         
            // 0x028EA2B0: MOV x22, x0                | X22 = X3;//m1                           
            // 0x028EA2B4: CBNZ x21, #0x28ea2bc       | if (X1 != 0) goto label_21;             
            if(X1 != 0)
            {
                goto label_21;
            }
            // 0x028EA2B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X3, ????);         
            label_21:
            // 0x028EA2BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA2C0: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA2C4: MOV x1, x20                | X1 = ((X2 - (val_13) << ) - (val_14) << );//m1
            // 0x028EA2C8: BL #0x1f8e3a4              | X1.Free(esp:  ???);                     
            X1.Free(esp:  ???);
            // 0x028EA2CC: CBZ x23, #0x28ea3bc        | if ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 == 0) goto label_22;
            // 0x028EA2D0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_26:
            // 0x028EA2D4: CBNZ x22, #0x28ea2dc       | if (X3 != 0) goto label_23;             
            if(val_11 != 0)
            {
                goto label_23;
            }
            // 0x028EA2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_23:
            // 0x028EA2DC: LDR w8, [x22, #0x18]       | W8 = X3 + 24;                           
            // 0x028EA2E0: CMP w21, w8                | STATE = COMPARE(0x0, X3 + 24)           
            // 0x028EA2E4: B.GE #0x28ea344            | if (val_20 >= X3 + 24) goto label_24;   
            if(val_20 >= (X3 + 24))
            {
                goto label_24;
            }
            // 0x028EA2E8: SXTW x24, w21              | X24 = 0 (0x00000000);                   
            // 0x028EA2EC: CMP w21, w8                | STATE = COMPARE(0x0, X3 + 24)           
            // 0x028EA2F0: B.LO #0x28ea300            | if (val_20 < X3 + 24) goto label_25;    
            if(val_20 < (X3 + 24))
            {
                goto label_25;
            }
            // 0x028EA2F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? X1, ????);         
            // 0x028EA2F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA2FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X1, ????);         
            label_25:
            // 0x028EA300: ADD x8, x22, x24, lsl #3   | X8 = (X3 + 0);                          
            var val_3 = val_11 + 0;
            // 0x028EA304: LDR x8, [x8, #0x20]        | X8 = (X3 + 0) + 32;                     
            // 0x028EA308: ADD w21, w21, #1           | W21 = (val_20 + 1);                     
            val_20 = val_20 + 1;
            // 0x028EA30C: CBNZ x8, #0x28ea2d4        | if ((X3 + 0) + 32 != 0) goto label_26;  
            if(((X3 + 0) + 32) != 0)
            {
                goto label_26;
            }
            // 0x028EA310: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x028EA314: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x028EA318: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_4 = null;
            // 0x028EA31C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x028EA320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA324: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_11 = val_4;
            // 0x028EA328: BL #0x18cb758              | .ctor();                                
            val_4 = new System.ArgumentNullException();
            // 0x028EA32C: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x028EA330: LDR x8, [x8, #0x890]       | X8 = 1152921512878263280;               
            // 0x028EA334: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x028EA338: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::CreateInstance3(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EA33C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x028EA340: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
            label_24:
            // 0x028EA344: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x028EA348: LDR x8, [x8, #0x950]       | X8 = 1152921504821596160;               
            // 0x028EA34C: LDR x9, [x23]              | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;
            // 0x028EA350: LDR x8, [x8]               | X8 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EA354: LDRB w11, [x9, #0x104]     | W11 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 260;
            // 0x028EA358: LDRB w10, [x8, #0x104]     | W10 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA35C: CMP w11, w10               | STATE = COMPARE((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 260, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA360: B.LO #0x28ea378            | if ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 260 < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_27;
            // 0x028EA364: LDR x9, [x9, #0xb0]        | X9 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176;
            // 0x028EA368: ADD x9, x9, x10, lsl #3    | X9 = ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 
            // 0x028EA36C: LDUR x9, [x9, #-8]         | X9 = ((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176 + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EA370: CMP x9, x8                 | STATE = COMPARE(((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176 + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EA374: B.EQ #0x28ea3e0            | if (((X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0 + 176 + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_28;
            label_27:
            // 0x028EA378: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA37C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EA380: MOV x1, x23                | X1 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;//m1
            // 0x028EA384: MOV x2, x22                | X2 = X3;//m1                            
            // 0x028EA388: BL #0x18c919c              | X0 = System.Activator.CreateInstance(type:  0, args:  val_2);
            object val_5 = System.Activator.CreateInstance(type:  0, args:  val_2);
            // 0x028EA38C: MOV x1, x20                | X1 = ((X2 - (val_13) << ) - (val_14) << );//m1
            // 0x028EA390: MOV x2, x19                | X2 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x028EA394: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA398: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA39C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028EA3A0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028EA3A4: MOV x3, x0                 | X3 = val_5;//m1                         
            // 0x028EA3A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA3AC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EA3B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EA3B4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028EA3B8: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            label_22:
            // 0x028EA3BC: MOV x1, x20                | X1 = ((X2 - (val_13) << ) - (val_14) << );//m1
            // 0x028EA3C0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA3C4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA3C8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028EA3CC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028EA3D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA3D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA3D8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028EA3DC: B #0x1f94458               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  esp);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  esp);
            label_28:
            // 0x028EA3E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA3E4: MOV x0, x23                | X0 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0;//m1
            // 0x028EA3E8: BL #0x1100c9c              | X0 = (X3 + 176 + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? X3 : 0.get_ILType();
            ILRuntime.CLR.TypeSystem.ILType val_6 = val_2.ILType;
            // 0x028EA3EC: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x028EA3F0: CBNZ x21, #0x28ea3f8       | if (val_6 != null) goto label_29;       
            if(val_6 != null)
            {
                goto label_29;
            }
            // 0x028EA3F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_29:
            // 0x028EA3F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA3FC: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028EA400: MOV x1, x22                | X1 = X3;//m1                            
            // 0x028EA404: BL #0x10fceb8              | X0 = val_6.Instantiate(args:  val_11);  
            ILRuntime.Runtime.Intepreter.ILTypeInstance val_7 = val_6.Instantiate(args:  val_11);
            // 0x028EA408: MOV x3, x0                 | X3 = val_7;//m1                         
            // 0x028EA40C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA410: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EA414: MOV x1, x20                | X1 = ((X2 - (val_13) << ) - (val_14) << );//m1
            // 0x028EA418: MOV x2, x19                | X2 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x028EA41C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EA420: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  ???, mStack:  ???, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  ???, mStack:  ???, obj:  ???, isBox:  ???);
            // 0x028EA424: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA428: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA42C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028EA430: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028EA434: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028EA438: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_8;
            return val_8;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028EA43C (42902588), len: 548  VirtAddr: 0x028EA43C RVA: 0x028EA43C token: 100680270 methodIndex: 29558 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* GetType(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_9;
            //  | 
            string val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x028EA43C: STP x22, x21, [sp, #-0x30]! | stack[1152921512889288720] = ???;  stack[1152921512889288728] = ???;  //  dest_result_addr=1152921512889288720 |  dest_result_addr=1152921512889288728
            // 0x028EA440: STP x20, x19, [sp, #0x10]  | stack[1152921512889288736] = ???;  stack[1152921512889288744] = ???;  //  dest_result_addr=1152921512889288736 |  dest_result_addr=1152921512889288744
            // 0x028EA444: STP x29, x30, [sp, #0x20]  | stack[1152921512889288752] = ???;  stack[1152921512889288760] = ???;  //  dest_result_addr=1152921512889288752 |  dest_result_addr=1152921512889288760
            // 0x028EA448: ADD x29, sp, #0x20         | X29 = (1152921512889288720 + 32) = 1152921512889288752 (0x10000001EDAC0830);
            // 0x028EA44C: SUB sp, sp, #0x10          | SP = (1152921512889288720 - 16) = 1152921512889288704 (0x10000001EDAC0800);
            // 0x028EA450: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028EA454: LDRB w8, [x22, #0x9fe]     | W8 = (bool)static_value_037B89FE;       
            // 0x028EA458: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EA45C: MOV x20, x2                | X20 = X2;//m1                           
            var val_9 = X2;
            // 0x028EA460: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028EA464: TBNZ w8, #0, #0x28ea480    | if (static_value_037B89FE == true) goto label_0;
            // 0x028EA468: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x028EA46C: LDR x8, [x8, #0x5d0]       | X8 = 0x2B90CE8;                         
            // 0x028EA470: LDR w0, [x8]               | W0 = 0x19FE;                            
            // 0x028EA474: BL #0x2782188              | X0 = sub_2782188( ?? 0x19FE, ????);     
            // 0x028EA478: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EA47C: STRB w8, [x22, #0x9fe]     | static_value_037B89FE = true;            //  dest_result_addr=58427902
            label_0:
            // 0x028EA480: ADRP x22, #0x366f000       | X22 = 57077760 (0x366F000);             
            // 0x028EA484: LDR x22, [x22, #0x7a0]     | X22 = 1152921504826228736;              
            // 0x028EA488: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_9 = 8;
            // 0x028EA48C: LDR x0, [x22]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA490: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EA494: TBZ w9, #0, #0x28ea4a4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_1;
            // 0x028EA498: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EA49C: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EA4A0: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_9 = 219381744;
            label_1:
            // 0x028EA4A4: SUB x20, x20, x8           | X20 = (X2 - val_9);                     
            val_9 = val_9 - val_9;
            // 0x028EA4A8: CBNZ x21, #0x28ea4b0       | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x028EA4AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_2:
            // 0x028EA4B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA4B4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA4B8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EA4BC: LDR x8, [x22]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA4C0: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x028EA4C4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028EA4C8: TBZ w9, #0, #0x28ea4dc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x028EA4CC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EA4D0: CBNZ w9, #0x28ea4dc        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x028EA4D4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EA4D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_4:
            // 0x028EA4DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA4E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EA4E4: MOV x1, x20                | X1 = (X2 - val_9);//m1                  
            // 0x028EA4E8: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x028EA4EC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EA4F0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_2 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028EA4F4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x028EA4F8: CBZ x0, #0x28ea540         | if (val_2 == null) goto label_6;        
            if(val_2 == null)
            {
                goto label_6;
            }
            // 0x028EA4FC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EA500: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028EA504: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028EA508: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EA50C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x028EA510: MOV x22, x0                | X22 = val_2;//m1                        
            val_10 = val_2;
            // 0x028EA514: B.EQ #0x28ea540            | if (typeof(System.Object) == null) goto label_6;
            if(null == null)
            {
                goto label_6;
            }
            // 0x028EA518: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EA51C: ADD x8, sp, #8             | X8 = (1152921512889288704 + 8) = 1152921512889288712 (0x10000001EDAC0808);
            // 0x028EA520: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EA524: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921512889276768]
            // 0x028EA528: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x028EA52C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA530: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x028EA534: ADD x0, sp, #8             | X0 = (1152921512889288704 + 8) = 1152921512889288712 (0x10000001EDAC0808);
            // 0x028EA538: BL #0x299a140              | 
            // 0x028EA53C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_6:
            // 0x028EA540: CBZ x21, #0x28ea558        | if (X1 == 0) goto label_7;              
            if(X1 == 0)
            {
                goto label_7;
            }
            // 0x028EA544: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA548: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA54C: MOV x1, x20                | X1 = (X2 - val_9);//m1                  
            // 0x028EA550: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EA554: B #0x28ea570               |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x028EA558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDAC0808, ????);
            // 0x028EA55C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA560: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA564: MOV x1, x20                | X1 = (X2 - val_9);//m1                  
            // 0x028EA568: BL #0x1f8e3a4              | 0.Free(esp:  null);                     
            0.Free(esp:  null);
            // 0x028EA56C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_8:
            // 0x028EA570: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA574: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA578: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_4 = X1.AppDomain;
            // 0x028EA57C: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x028EA580: CBNZ x21, #0x28ea588       | if (val_4 != null) goto label_9;        
            if(val_4 != null)
            {
                goto label_9;
            }
            // 0x028EA584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_9:
            // 0x028EA588: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x028EA58C: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x028EA590: BL #0x28e4a68              | X0 = val_4.GetType(fullname:  val_10);  
            ILRuntime.CLR.TypeSystem.IType val_5 = val_4.GetType(fullname:  val_10);
            // 0x028EA594: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x028EA598: CBZ x21, #0x28ea5ec        | if (val_5 == null) goto label_10;       
            if(val_5 == null)
            {
                goto label_10;
            }
            // 0x028EA59C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EA5A0: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EA5A4: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EA5A8: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EA5AC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EA5B0: CBZ x9, #0x28ea5dc         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_11;
            // 0x028EA5B4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EA5B8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_10 = 0;
            // 0x028EA5BC: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_13:
            // 0x028EA5C0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EA5C4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EA5C8: B.EQ #0x28ea600            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_12;
            // 0x028EA5CC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x028EA5D0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EA5D4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EA5D8: B.LO #0x28ea5c0            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_13;
            label_11:
            // 0x028EA5DC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028EA5E0: MOV x0, x21                | X0 = val_5;//m1                         
            val_11 = val_5;
            // 0x028EA5E4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_5, ????);      
            // 0x028EA5E8: B #0x28ea610               |  goto label_14;                         
            goto label_14;
            label_10:
            // 0x028EA5EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA5F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA5F4: MOV x1, x20                | X1 = (X2 - val_9);//m1                  
            // 0x028EA5F8: BL #0x1f94458              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_6 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  null);
            // 0x028EA5FC: B #0x28ea638               |  goto label_15;                         
            goto label_15;
            label_12:
            // 0x028EA600: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EA604: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x028EA608: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x028EA60C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_14:
            // 0x028EA610: LDP x8, x1, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x028EA614: MOV x0, x21                | X0 = val_5;//m1                         
            // 0x028EA618: BLR x8                     | X0 = sub_100000000A746000( ?? val_5, ????);
            // 0x028EA61C: MOV x3, x0                 | X3 = val_5;//m1                         
            // 0x028EA620: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA624: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EA628: MOV x1, x20                | X1 = (X2 - val_9);//m1                  
            // 0x028EA62C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EA630: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EA634: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            label_15:
            // 0x028EA638: SUB sp, x29, #0x20         | SP = (1152921512889288752 - 32) = 1152921512889288720 (0x10000001EDAC0810);
            // 0x028EA63C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA640: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA644: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EA648: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_8;
            return val_8;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028EA64C: MOV x19, x0                | 
            // 0x028EA650: ADD x0, sp, #8             | 
            // 0x028EA654: BL #0x299a140              | 
            // 0x028EA658: MOV x0, x19                | 
            // 0x028EA65C: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028EA660 (42903136), len: 1248  VirtAddr: 0x028EA660 RVA: 0x028EA660 token: 100680271 methodIndex: 29559 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* TypeEquals(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_13;
            //  | 
            var val_15;
            //  | 
            var val_17;
            //  | 
            var val_21;
            //  | 
            var val_23;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            System.Type val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            // 0x028EA660: STP x26, x25, [sp, #-0x50]! | stack[1152921512889478512] = ???;  stack[1152921512889478520] = ???;  //  dest_result_addr=1152921512889478512 |  dest_result_addr=1152921512889478520
            // 0x028EA664: STP x24, x23, [sp, #0x10]  | stack[1152921512889478528] = ???;  stack[1152921512889478536] = ???;  //  dest_result_addr=1152921512889478528 |  dest_result_addr=1152921512889478536
            // 0x028EA668: STP x22, x21, [sp, #0x20]  | stack[1152921512889478544] = ???;  stack[1152921512889478552] = ???;  //  dest_result_addr=1152921512889478544 |  dest_result_addr=1152921512889478552
            // 0x028EA66C: STP x20, x19, [sp, #0x30]  | stack[1152921512889478560] = ???;  stack[1152921512889478568] = ???;  //  dest_result_addr=1152921512889478560 |  dest_result_addr=1152921512889478568
            // 0x028EA670: STP x29, x30, [sp, #0x40]  | stack[1152921512889478576] = ???;  stack[1152921512889478584] = ???;  //  dest_result_addr=1152921512889478576 |  dest_result_addr=1152921512889478584
            // 0x028EA674: ADD x29, sp, #0x40         | X29 = (1152921512889478512 + 64) = 1152921512889478576 (0x10000001EDAEEDB0);
            // 0x028EA678: SUB sp, sp, #0x30          | SP = (1152921512889478512 - 48) = 1152921512889478464 (0x10000001EDAEED40);
            // 0x028EA67C: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028EA680: LDRB w8, [x19, #0x9ff]     | W8 = (bool)static_value_037B89FF;       
            // 0x028EA684: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028EA688: MOV x23, x2                | X23 = X2;//m1                           
            // 0x028EA68C: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028EA690: TBNZ w8, #0, #0x28ea6ac    | if (static_value_037B89FF == true) goto label_0;
            // 0x028EA694: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x028EA698: LDR x8, [x8, #0xe00]       | X8 = 0x2B90CF8;                         
            // 0x028EA69C: LDR w0, [x8]               | W0 = 0x1A02;                            
            // 0x028EA6A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A02, ????);     
            // 0x028EA6A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EA6A8: STRB w8, [x19, #0x9ff]     | static_value_037B89FF = true;            //  dest_result_addr=58427903
            label_0:
            // 0x028EA6AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA6B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EA6B4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028EA6B8: MOV x1, x23                | X1 = X2;//m1                            
            // 0x028EA6BC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_1 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028EA6C0: ADRP x20, #0x366f000       | X20 = 57077760 (0x366F000);             
            // 0x028EA6C4: LDR x20, [x20, #0x7a0]     | X20 = 1152921504826228736;              
            // 0x028EA6C8: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x028EA6CC: LDR x8, [x20]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA6D0: LDRB w9, [x8, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EA6D4: TBNZ w9, #0, #0x28ea6e0    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EA6D8: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_27 = 8;
            // 0x028EA6DC: B #0x28ea6ec               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EA6E0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EA6E4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EA6E8: SUB w8, w0, #0x10          | W8 = (null - 16) = val_27 (0x100000000D137FF0);
            val_27 = 1152921504826228720;
            label_2:
            // 0x028EA6EC: SUB x24, x23, w8, sxtw     | X24 = (X2 - (val_27) << );              
            var val_2 = X2 - (val_27 << );
            // 0x028EA6F0: CBNZ x21, #0x28ea6f8       | if (X1 != 0) goto label_3;              
            if(X1 != 0)
            {
                goto label_3;
            }
            // 0x028EA6F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_3:
            // 0x028EA6F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA6FC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA700: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_3 = X1.AppDomain;
            // 0x028EA704: LDR x8, [x20]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EA708: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x028EA70C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028EA710: TBZ w9, #0, #0x28ea724     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028EA714: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EA718: CBNZ w9, #0x28ea724        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028EA71C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EA720: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EA724: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA728: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EA72C: MOV x1, x24                | X1 = (X2 - (val_27) << );//m1           
            // 0x028EA730: MOV x2, x25                | X2 = val_3;//m1                         
            // 0x028EA734: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028EA738: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_4 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EA73C: MOV x20, x0                | X20 = val_4;//m1                        
            val_28 = val_4;
            // 0x028EA740: CBNZ x21, #0x28ea748       | if (X1 != 0) goto label_6;              
            if(X1 != 0)
            {
                goto label_6;
            }
            // 0x028EA744: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x028EA748: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA74C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA750: MOV x1, x24                | X1 = (X2 - (val_27) << );//m1           
            // 0x028EA754: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EA758: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA75C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EA760: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028EA764: MOV x1, x23                | X1 = X2;//m1                            
            // 0x028EA768: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_5 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028EA76C: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x028EA770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA774: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EA778: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x028EA77C: MOV x2, x25                | X2 = val_3;//m1                         
            // 0x028EA780: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028EA784: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EA788: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x028EA78C: CBNZ x21, #0x28ea794       | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x028EA790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_7:
            // 0x028EA794: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA798: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EA79C: MOV x1, x23                | X1 = val_5;//m1                         
            // 0x028EA7A0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EA7A4: CBZ x22, #0x28ea7dc        | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x028EA7A8: ADRP x23, #0x35eb000       | X23 = 56537088 (0x35EB000);             
            // 0x028EA7AC: LDR x23, [x23, #0x950]     | X23 = 1152921504821596160;              
            val_29 = 1152921504821596160;
            // 0x028EA7B0: LDR x10, [x22]             | X10 = typeof(System.Object);            
            // 0x028EA7B4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EA7B8: LDRB w11, [x10, #0x104]    | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA7BC: LDRB w9, [x8, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA7C0: CMP w11, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA7C4: B.LO #0x28ea7dc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028EA7C8: LDR x11, [x10, #0xb0]      | X11 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EA7CC: SUB x10, x9, #1            | X10 = (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth - 1);
            // 0x028EA7D0: LDR x11, [x11, x10, lsl #3] | X11 =  typeof(Il2CppClass**);           
            // 0x028EA7D4: CMP x11, x8                | STATE = COMPARE(__il2cppRuntimeField_typeHierarchy, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EA7D8: B.EQ #0x28ea9a4            | if (__il2cppRuntimeField_typeHierarchy == null) goto label_10;
            label_9:
            // 0x028EA7DC: ADRP x23, #0x3620000       | X23 = 56754176 (0x3620000);             
            // 0x028EA7E0: LDR x23, [x23, #0x340]     | X23 = 1152921504609562624;              
            val_29 = 1152921504609562624;
            // 0x028EA7E4: ADRP x24, #0x3630000       | X24 = 56819712 (0x3630000);             
            // 0x028EA7E8: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x028EA7EC: LDR x24, [x24, #0xac0]     | X24 = 1152921504609562624;              
            // 0x028EA7F0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028EA7F4: LDR x21, [x24]             | X21 = typeof(System.Type);              
            // 0x028EA7F8: TBZ w8, #0, #0x28ea808     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x028EA7FC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028EA800: CBNZ w8, #0x28ea808        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x028EA804: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_12:
            // 0x028EA808: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA80C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA810: MOV x1, x21                | X1 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028EA814: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028EA818: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028EA81C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028EA820: MOV x21, x0                | X21 = val_8;//m1                        
            // 0x028EA824: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028EA828: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028EA82C: TBZ w9, #0, #0x28ea840     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x028EA830: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028EA834: CBNZ w9, #0x28ea840        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x028EA838: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028EA83C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_14:
            // 0x028EA840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA844: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EA848: MOV x1, x21                | X1 = val_8;//m1                         
            // 0x028EA84C: MOV x2, x22                | X2 = val_6;//m1                         
            // 0x028EA850: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_9 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x028EA854: LDR x1, [x24]              | X1 = typeof(System.Type);               
            // 0x028EA858: MOV x21, x0                | X21 = val_9;//m1                        
            val_30 = val_9;
            // 0x028EA85C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA864: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028EA868: MOV x1, x0                 | X1 = val_10;//m1                        
            // 0x028EA86C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA870: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EA874: MOV x2, x20                | X2 = val_4;//m1                         
            // 0x028EA878: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_10);
            // 0x028EA87C: MOV x20, x0                | X20 = val_11;//m1                       
            val_31 = val_11;
            // 0x028EA880: CBZ x21, #0x28ea92c        | if (val_9 == null) goto label_15;       
            if(val_30 == null)
            {
                goto label_15;
            }
            // 0x028EA884: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EA888: LDR x1, [x23]              | X1 = typeof(System.Type);               
            // 0x028EA88C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA890: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA894: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA898: B.LO #0x28ea8b0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x028EA89C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EA8A0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EA8A4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EA8A8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EA8AC: B.EQ #0x28ea8d8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x028EA8B0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EA8B4: ADD x8, sp, #0x20          | X8 = (1152921512889478464 + 32) = 1152921512889478496 (0x10000001EDAEED60);
            // 0x028EA8B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EA8BC: LDR x0, [sp, #0x20]        | X0 = val_13;                             //  find_add[1152921512889466592]
            // 0x028EA8C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x028EA8C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA8C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x028EA8CC: ADD x0, sp, #0x20          | X0 = (1152921512889478464 + 32) = 1152921512889478496 (0x10000001EDAEED60);
            // 0x028EA8D0: BL #0x299a140              | 
            // 0x028EA8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDAEED60, ????);
            label_17:
            // 0x028EA8D8: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EA8DC: LDR x1, [x23]              | X1 = typeof(System.Type);               
            val_32 = null;
            // 0x028EA8E0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA8E4: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA8E8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA8EC: B.LO #0x28ea904            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_18;
            // 0x028EA8F0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EA8F4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EA8F8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EA8FC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EA900: B.EQ #0x28ea938            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_32) goto label_19;
            label_18:
            // 0x028EA904: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EA908: ADD x8, sp, #0x28          | X8 = (1152921512889478464 + 40) = 1152921512889478504 (0x10000001EDAEED68);
            // 0x028EA90C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EA910: LDR x0, [sp, #0x28]        | X0 = val_15;                             //  find_add[1152921512889466592]
            // 0x028EA914: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x028EA918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA91C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x028EA920: ADD x0, sp, #0x28          | X0 = (1152921512889478464 + 40) = 1152921512889478504 (0x10000001EDAEED68);
            // 0x028EA924: BL #0x299a140              | 
            // 0x028EA928: B #0x28ea930               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x028EA92C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_20:
            // 0x028EA930: LDR x1, [x23]              | X1 = typeof(System.Type);               
            val_32 = null;
            // 0x028EA934: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_30 = 0;
            label_19:
            // 0x028EA938: CBZ x20, #0x28ea988        | if (val_11 == null) goto label_21;      
            if(val_31 == null)
            {
                goto label_21;
            }
            // 0x028EA93C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EA940: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA944: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA948: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA94C: B.LO #0x28ea964            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_22;
            // 0x028EA950: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EA954: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EA958: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EA95C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EA960: B.EQ #0x28ea98c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_32) goto label_23;
            label_22:
            // 0x028EA964: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EA968: ADD x8, sp, #8             | X8 = (1152921512889478464 + 8) = 1152921512889478472 (0x10000001EDAEED48);
            // 0x028EA96C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EA970: LDR x0, [sp, #8]           | X0 = val_17;                             //  find_add[1152921512889466592]
            // 0x028EA974: BL #0x27af090              | X0 = sub_27AF090( ?? val_17, ????);     
            // 0x028EA978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA97C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            // 0x028EA980: ADD x0, sp, #8             | X0 = (1152921512889478464 + 8) = 1152921512889478472 (0x10000001EDAEED48);
            // 0x028EA984: BL #0x299a140              | 
            label_21:
            // 0x028EA988: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_31 = 0;
            label_23:
            // 0x028EA98C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA990: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028EA994: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x028EA998: BL #0x1b6d740              | X0 = val_30.Equals(o:  val_31);         
            bool val_18 = val_30.Equals(o:  val_31);
            // 0x028EA99C: TBNZ w0, #0, #0x28eaad0    | if (val_18 == true) goto label_33;      
            if(val_18 == true)
            {
                goto label_33;
            }
            // 0x028EA9A0: B #0x28eaabc               |  goto label_25;                         
            goto label_25;
            label_10:
            // 0x028EA9A4: CBZ x20, #0x28ea9c8        | if (val_4 == null) goto label_27;       
            if(val_28 == null)
            {
                goto label_27;
            }
            // 0x028EA9A8: LDR x11, [x20]             | X11 = typeof(System.Object);            
            // 0x028EA9AC: LDRB w12, [x11, #0x104]    | W12 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EA9B0: CMP w12, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EA9B4: B.LO #0x28ea9c8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_27;
            // 0x028EA9B8: LDR x9, [x11, #0xb0]       | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EA9BC: LDR x9, [x9, x10, lsl #3]  | X9 =  typeof(Il2CppClass**);            
            // 0x028EA9C0: CMP x9, x8                 | STATE = COMPARE(__il2cppRuntimeField_typeHierarchy, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EA9C4: B.EQ #0x28ea9f0            | if (__il2cppRuntimeField_typeHierarchy == null) goto label_28;
            label_27:
            // 0x028EA9C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EA9CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EA9D0: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x028EA9D4: SUB sp, x29, #0x40         | SP = (1152921512889478576 - 64) = 1152921512889478512 (0x10000001EDAEED70);
            // 0x028EA9D8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028EA9DC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028EA9E0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028EA9E4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028EA9E8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028EA9EC: B #0x1f96cf0               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  esp);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  esp);
            label_28:
            // 0x028EA9F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EA9F4: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x028EA9F8: BL #0x1100c9c              | X0 = val_6.get_ILType();                
            ILRuntime.CLR.TypeSystem.ILType val_19 = val_6.ILType;
            // 0x028EA9FC: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EAA00: LDR x1, [x23]              | X1 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EAA04: MOV x21, x0                | X21 = val_19;//m1                       
            val_30 = val_19;
            // 0x028EAA08: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EAA0C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EAA10: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EAA14: B.LO #0x28eaa2c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_29;
            // 0x028EAA18: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EAA1C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cp
            // 0x028EAA20: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EAA24: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EAA28: B.EQ #0x28eaa54            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_30;
            label_29:
            // 0x028EAA2C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EAA30: ADD x8, sp, #0x10          | X8 = (1152921512889478464 + 16) = 1152921512889478480 (0x10000001EDAEED50);
            // 0x028EAA34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EAA38: LDR x0, [sp, #0x10]        | X0 = val_21;                             //  find_add[1152921512889466592]
            // 0x028EAA3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_21, ????);     
            // 0x028EAA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EAA44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            // 0x028EAA48: ADD x0, sp, #0x10          | X0 = (1152921512889478464 + 16) = 1152921512889478480 (0x10000001EDAEED50);
            // 0x028EAA4C: BL #0x299a140              | 
            // 0x028EAA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDAEED50, ????);
            label_30:
            // 0x028EAA54: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EAA58: LDR x1, [x23]              | X1 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EAA5C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EAA60: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EAA64: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EAA68: B.LO #0x28eaa80            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_31;
            // 0x028EAA6C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EAA70: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cp
            // 0x028EAA74: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EAA78: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EAA7C: B.EQ #0x28eaaa8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_32;
            label_31:
            // 0x028EAA80: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EAA84: ADD x8, sp, #0x18          | X8 = (1152921512889478464 + 24) = 1152921512889478488 (0x10000001EDAEED58);
            // 0x028EAA88: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EAA8C: LDR x0, [sp, #0x18]        | X0 = val_23;                             //  find_add[1152921512889466592]
            // 0x028EAA90: BL #0x27af090              | X0 = sub_27AF090( ?? val_23, ????);     
            // 0x028EAA94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EAA98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            // 0x028EAA9C: ADD x0, sp, #0x18          | X0 = (1152921512889478464 + 24) = 1152921512889478488 (0x10000001EDAEED58);
            // 0x028EAAA0: BL #0x299a140              | 
            // 0x028EAAA4: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_28 = 0;
            label_32:
            // 0x028EAAA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EAAAC: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x028EAAB0: BL #0x1100c9c              | X0 = val_28.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_24 = val_28.ILType;
            // 0x028EAAB4: CMP x21, x0                | STATE = COMPARE(val_19, val_24)         
            // 0x028EAAB8: B.EQ #0x28eaad0            | if (val_30 == val_24) goto label_33;    
            if(val_30 == val_24)
            {
                goto label_33;
            }
            label_25:
            // 0x028EAABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EAAC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EAAC4: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x028EAAC8: BL #0x1f96cf0              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_25 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  null);
            // 0x028EAACC: B #0x28eaae0               |  goto label_34;                         
            goto label_34;
            label_33:
            // 0x028EAAD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EAAD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EAAD8: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x028EAADC: BL #0x1f96c74              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushOne(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_26 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushOne(esp:  null);
            label_34:
            // 0x028EAAE0: SUB sp, x29, #0x40         | SP = (1152921512889478576 - 64) = 1152921512889478512 (0x10000001EDAEED70);
            // 0x028EAAE4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028EAAE8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028EAAEC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028EAAF0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028EAAF4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028EAAF8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_26;
            return val_26;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028EAAFC: MOV x19, x0                | 
            // 0x028EAB00: ADD x0, sp, #0x20          | 
            // 0x028EAB04: B #0x28eab1c               | 
            // 0x028EAB08: MOV x19, x0                | 
            // 0x028EAB0C: ADD x0, sp, #0x28          | 
            // 0x028EAB10: B #0x28eab1c               | 
            // 0x028EAB14: MOV x19, x0                | 
            // 0x028EAB18: ADD x0, sp, #8             | 
            label_38:
            // 0x028EAB1C: BL #0x299a140              | 
            // 0x028EAB20: MOV x0, x19                | 
            // 0x028EAB24: BL #0x980800               | 
            // 0x028EAB28: MOV x19, x0                | 
            // 0x028EAB2C: ADD x0, sp, #0x10          | 
            // 0x028EAB30: B #0x28eab1c               | 
            // 0x028EAB34: MOV x19, x0                | 
            // 0x028EAB38: ADD x0, sp, #0x18          | 
            // 0x028EAB3C: B #0x28eab1c               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028EAB40 (42904384), len: 740  VirtAddr: 0x028EAB40 RVA: 0x028EAB40 token: 100680272 methodIndex: 29560 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* InitializeArray(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            System.Runtime.InteropServices.GCHandleType val_23;
            // 0x028EAB40: STP x28, x27, [sp, #-0x60]! | stack[1152921512889664224] = ???;  stack[1152921512889664232] = ???;  //  dest_result_addr=1152921512889664224 |  dest_result_addr=1152921512889664232
            // 0x028EAB44: STP x26, x25, [sp, #0x10]  | stack[1152921512889664240] = ???;  stack[1152921512889664248] = ???;  //  dest_result_addr=1152921512889664240 |  dest_result_addr=1152921512889664248
            // 0x028EAB48: STP x24, x23, [sp, #0x20]  | stack[1152921512889664256] = ???;  stack[1152921512889664264] = ???;  //  dest_result_addr=1152921512889664256 |  dest_result_addr=1152921512889664264
            // 0x028EAB4C: STP x22, x21, [sp, #0x30]  | stack[1152921512889664272] = ???;  stack[1152921512889664280] = ???;  //  dest_result_addr=1152921512889664272 |  dest_result_addr=1152921512889664280
            // 0x028EAB50: STP x20, x19, [sp, #0x40]  | stack[1152921512889664288] = ???;  stack[1152921512889664296] = ???;  //  dest_result_addr=1152921512889664288 |  dest_result_addr=1152921512889664296
            // 0x028EAB54: STP x29, x30, [sp, #0x50]  | stack[1152921512889664304] = ???;  stack[1152921512889664312] = ???;  //  dest_result_addr=1152921512889664304 |  dest_result_addr=1152921512889664312
            // 0x028EAB58: ADD x29, sp, #0x50         | X29 = (1152921512889664224 + 80) = 1152921512889664304 (0x10000001EDB1C330);
            // 0x028EAB5C: SUB sp, sp, #0x10          | SP = (1152921512889664224 - 16) = 1152921512889664208 (0x10000001EDB1C2D0);
            // 0x028EAB60: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028EAB64: LDRB w8, [x22, #0xa00]     | W8 = (bool)static_value_037B8A00;       
            // 0x028EAB68: MOV x21, x3                | X21 = X3;//m1                           
            // 0x028EAB6C: MOV x19, x2                | X19 = X2;//m1                           
            // 0x028EAB70: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028EAB74: TBNZ w8, #0, #0x28eab90    | if (static_value_037B8A00 == true) goto label_0;
            // 0x028EAB78: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028EAB7C: LDR x8, [x8, #0xf88]       | X8 = 0x2B90CEC;                         
            // 0x028EAB80: LDR w0, [x8]               | W0 = 0x19FF;                            
            // 0x028EAB84: BL #0x2782188              | X0 = sub_2782188( ?? 0x19FF, ????);     
            // 0x028EAB88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EAB8C: STRB w8, [x22, #0xa00]     | static_value_037B8A00 = true;            //  dest_result_addr=58427904
            label_0:
            // 0x028EAB90: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x028EAB94: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x028EAB98: STR wzr, [sp]              | stack[1152921512889664208] = 0x0;        //  dest_result_addr=1152921512889664208
            // 0x028EAB9C: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_12 = 8;
            // 0x028EABA0: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_13 = null;
            // 0x028EABA4: ADD x9, x8, #0x109         | X9 = (val_13 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EABA8: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EABAC: TBZ w9, #0, #0x28eabcc     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_1;
            // 0x028EABB0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EABB4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EABB8: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_13 = null;
            // 0x028EABBC: SUB w10, w0, #0x10         | W10 = (val_13 - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EABC0: SXTW x25, w10              | X25 = 219381744 (0x0D137FF0);           
            val_12 = 219381744;
            // 0x028EABC4: ADD x9, x8, #0x109         | X9 = (val_13 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EABC8: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_1:
            // 0x028EABCC: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_15 = 8;
            // 0x028EABD0: TBZ w9, #0, #0x28eabe4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_2;
            // 0x028EABD4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EABD8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EABDC: SUB w8, w0, #0x10          | W8 = (val_13 - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EABE0: SXTW x26, w8               | X26 = 219381744 (0x0D137FF0);           
            val_15 = 219381744;
            label_2:
            // 0x028EABE4: CBNZ x20, #0x28eabec       | if (X1 != 0) goto label_3;              
            if(X1 != 0)
            {
                goto label_3;
            }
            // 0x028EABE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_3:
            // 0x028EABEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EABF0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EABF4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EABF8: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_16 = null;
            // 0x028EABFC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028EAC00: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_17 = 8;
            // 0x028EAC04: ADD x9, x8, #0x109         | X9 = (val_16 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAC08: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EAC0C: TBZ w9, #0, #0x28eac2c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_4;
            // 0x028EAC10: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAC14: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EAC18: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_16 = null;
            // 0x028EAC1C: SUB w10, w0, #0x10         | W10 = (val_16 - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EAC20: SXTW x10, w10              | X10 = 219381744 (0x0D137FF0);           
            val_17 = 219381744;
            // 0x028EAC24: ADD x9, x8, #0x109         | X9 = (val_16 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAC28: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_4:
            // 0x028EAC2C: SUB x24, x19, x10          | X24 = (X2 - val_17);                    
            var val_2 = X2 - val_17;
            // 0x028EAC30: TBZ w9, #8, #0x28eac44     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_6;
            // 0x028EAC34: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EAC38: CBNZ w9, #0x28eac44        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x028EAC3C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAC40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_6:
            // 0x028EAC44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EAC48: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EAC4C: MOV x1, x24                | X1 = (X2 - val_17);//m1                 
            // 0x028EAC50: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EAC54: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028EAC58: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  0, appdomain:  null, mStack:  ???);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  0, appdomain:  null, mStack:  ???);
            // 0x028EAC5C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028EAC60: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x028EAC64: LDR x1, [x8]               | X1 = typeof(System.Byte[]);             
            // 0x028EAC68: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EAC6C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x028EAC70: CBNZ x20, #0x28eac78       | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x028EAC74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x028EAC78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EAC7C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EAC80: MOV x1, x24                | X1 = (X2 - val_17);//m1                 
            // 0x028EAC84: BL #0x1f8e3a4              | X1.Free(esp:  0);                       
            X1.Free(esp:  0);
            // 0x028EAC88: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_19 = null;
            // 0x028EAC8C: ORR w24, wzr, #8           | W24 = 8(0x8);                           
            val_20 = 8;
            // 0x028EAC90: ADD x9, x8, #0x109         | X9 = (val_19 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAC94: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EAC98: TBZ w9, #0, #0x28eacb8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_8;
            // 0x028EAC9C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EACA0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EACA4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_19 = null;
            // 0x028EACA8: SUB w10, w0, #0x10         | W10 = (val_19 - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EACAC: SXTW x24, w10              | X24 = 219381744 (0x0D137FF0);           
            val_20 = 219381744;
            // 0x028EACB0: ADD x9, x8, #0x109         | X9 = (val_19 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EACB4: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_8:
            // 0x028EACB8: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_22 = 8;
            // 0x028EACBC: TBZ w9, #0, #0x28eacd0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_9;
            // 0x028EACC0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EACC4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EACC8: SUB w8, w0, #0x10          | W8 = (val_19 - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028EACCC: SXTW x10, w8               | X10 = 219381744 (0x0D137FF0);           
            val_22 = 219381744;
            label_9:
            // 0x028EACD0: SUB x8, x19, x24           | X8 = (X2 - val_20);                     
            var val_4 = X2 - val_20;
            // 0x028EACD4: SUB x24, x8, x10           | X24 = ((X2 - val_20) - val_22);         
            val_20 = val_4 - val_22;
            // 0x028EACD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EACDC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EACE0: MOV x1, x24                | X1 = ((X2 - val_20) - val_22);//m1      
            // 0x028EACE4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EACE8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028EACEC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  0, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  0, appdomain:  null, mStack:  ???);
            // 0x028EACF0: MOV x21, x0                | X21 = val_5;//m1                        
            val_23 = val_5;
            // 0x028EACF4: CBNZ x20, #0x28eacfc       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x028EACF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_10:
            // 0x028EACFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EAD00: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EAD04: MOV x1, x24                | X1 = ((X2 - val_20) - val_22);//m1      
            // 0x028EAD08: BL #0x1f8e3a4              | X1.Free(esp:  0);                       
            X1.Free(esp:  0);
            // 0x028EAD0C: CBZ x22, #0x28eade8        | if (val_3 == null) goto label_11;       
            if(val_3 == null)
            {
                goto label_11;
            }
            // 0x028EAD10: CBZ x21, #0x28ead6c        | if (val_5 == null) goto label_12;       
            if(val_23 == null)
            {
                goto label_12;
            }
            // 0x028EAD14: ADRP x9, #0x35f1000        | X9 = 56561664 (0x35F1000);              
            // 0x028EAD18: LDR x9, [x9, #0xcc0]       | X9 = 1152921504608976896;               
            // 0x028EAD1C: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EAD20: LDR x1, [x9]               | X1 = typeof(System.Array);              
            // 0x028EAD24: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EAD28: LDRB w9, [x1, #0x104]      | W9 = System.Array.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EAD2C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Array.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EAD30: B.LO #0x28ead48            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Array.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028EAD34: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EAD38: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHier
            // 0x028EAD3C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EAD40: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Array))
            // 0x028EAD44: B.EQ #0x28ead70            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Array.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028EAD48: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EAD4C: ADD x8, sp, #8             | X8 = (1152921512889664208 + 8) = 1152921512889664216 (0x10000001EDB1C2D8);
            // 0x028EAD50: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EAD54: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921512889652320]
            // 0x028EAD58: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x028EAD5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EAD60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x028EAD64: ADD x0, sp, #8             | X0 = (1152921512889664208 + 8) = 1152921512889664216 (0x10000001EDB1C2D8);
            // 0x028EAD68: BL #0x299a140              | 
            label_12:
            // 0x028EAD6C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_23 = 0;
            label_14:
            // 0x028EAD70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EAD74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EAD78: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028EAD7C: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028EAD80: BL #0x13cb94c              | X0 = System.Runtime.InteropServices.GCHandle.Alloc(value:  0, type:  val_23);
            System.Runtime.InteropServices.GCHandle val_8 = System.Runtime.InteropServices.GCHandle.Alloc(value:  0, type:  val_23);
            // 0x028EAD84: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028EAD88: LDR x8, [x8, #0xca0]       | X8 = 1152921504631500800;               
            // 0x028EAD8C: STR w0, [sp]               | stack[1152921512889664208] = val_8.handle;  //  dest_result_addr=1152921512889664208
            // 0x028EAD90: LDR x8, [x8]               | X8 = typeof(System.Runtime.InteropServices.Marshal);
            // 0x028EAD94: LDRB w9, [x8, #0x10a]      | W9 = System.Runtime.InteropServices.Marshal.__il2cppRuntimeField_10A;
            // 0x028EAD98: TBZ w9, #0, #0x28eadac     | if (System.Runtime.InteropServices.Marshal.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x028EAD9C: LDR w9, [x8, #0xbc]        | W9 = System.Runtime.InteropServices.Marshal.__il2cppRuntimeField_cctor_finished;
            // 0x028EADA0: CBNZ w9, #0x28eadac        | if (System.Runtime.InteropServices.Marshal.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x028EADA4: MOV x0, x8                 | X0 = 1152921504631500800 (0x1000000001783000);//ML01
            // 0x028EADA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Runtime.InteropServices.Marshal), ????);
            label_16:
            // 0x028EADAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EADB0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028EADB4: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028EADB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EADBC: BL #0x13cbeec              | X0 = System.Runtime.InteropServices.Marshal.UnsafeAddrOfPinnedArrayElement(arr:  0, index:  0);
            IntPtr val_9 = System.Runtime.InteropServices.Marshal.UnsafeAddrOfPinnedArrayElement(arr:  0, index:  0);
            // 0x028EADC0: LDR w4, [x22, #0x18]       | 
            // 0x028EADC4: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x028EADC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EADCC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028EADD0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EADD4: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x028EADD8: BL #0x13cbd28              | System.Runtime.InteropServices.Marshal.Copy(source:  0, startIndex:  val_3, destination:  0, length:  val_9);
            System.Runtime.InteropServices.Marshal.Copy(source:  0, startIndex:  val_3, destination:  0, length:  val_9);
            // 0x028EADDC: MOV x0, sp                 | X0 = 1152921512889664208 (0x10000001EDB1C2D0);//ML01
            // 0x028EADE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EADE4: BL #0x13cb97c              | val_8.handle.Free();                    
            val_8.handle.Free();
            label_11:
            // 0x028EADE8: SUB x8, x19, x25           | X8 = (X2 - val_12);                     
            var val_10 = X2 - val_12;
            // 0x028EADEC: SUB x0, x8, x26            | X0 = ((X2 - val_12) - val_15);          
            var val_11 = val_10 - val_15;
            // 0x028EADF0: SUB sp, x29, #0x50         | SP = (1152921512889664304 - 80) = 1152921512889664224 (0x10000001EDB1C2E0);
            // 0x028EADF4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EADF8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EADFC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EAE00: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EAE04: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EAE08: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EAE0C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)((X2 - val_12) - val_15);
            return (ILRuntime.Runtime.Stack.StackObject*)val_11;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028EAE10: MOV x19, x0                | 
            // 0x028EAE14: ADD x0, sp, #8             | 
            // 0x028EAE18: BL #0x299a140              | 
            // 0x028EAE1C: MOV x0, x19                | 
            // 0x028EAE20: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028EAE24 (42905124), len: 3228  VirtAddr: 0x028EAE24 RVA: 0x028EAE24 token: 100680273 methodIndex: 29561 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* DelegateCombine(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_16;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_28;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            //  | 
            var val_62;
            //  | 
            var val_63;
            //  | 
            var val_64;
            //  | 
            System.Delegate val_65;
            //  | 
            var val_66;
            //  | 
            var val_67;
            //  | 
            var val_68;
            //  | 
            var val_69;
            //  | 
            var val_70;
            //  | 
            var val_71;
            //  | 
            var val_72;
            //  | 
            var val_73;
            //  | 
            var val_74;
            //  | 
            var val_75;
            //  | 
            var val_76;
            //  | 
            var val_77;
            //  | 
            var val_78;
            //  | 
            var val_79;
            //  | 
            var val_80;
            // 0x028EAE24: STP x28, x27, [sp, #-0x60]! | stack[1152921512889833568] = ???;  stack[1152921512889833576] = ???;  //  dest_result_addr=1152921512889833568 |  dest_result_addr=1152921512889833576
            // 0x028EAE28: STP x26, x25, [sp, #0x10]  | stack[1152921512889833584] = ???;  stack[1152921512889833592] = ???;  //  dest_result_addr=1152921512889833584 |  dest_result_addr=1152921512889833592
            // 0x028EAE2C: STP x24, x23, [sp, #0x20]  | stack[1152921512889833600] = ???;  stack[1152921512889833608] = ???;  //  dest_result_addr=1152921512889833600 |  dest_result_addr=1152921512889833608
            // 0x028EAE30: STP x22, x21, [sp, #0x30]  | stack[1152921512889833616] = ???;  stack[1152921512889833624] = ???;  //  dest_result_addr=1152921512889833616 |  dest_result_addr=1152921512889833624
            // 0x028EAE34: STP x20, x19, [sp, #0x40]  | stack[1152921512889833632] = ???;  stack[1152921512889833640] = ???;  //  dest_result_addr=1152921512889833632 |  dest_result_addr=1152921512889833640
            // 0x028EAE38: STP x29, x30, [sp, #0x50]  | stack[1152921512889833648] = ???;  stack[1152921512889833656] = ???;  //  dest_result_addr=1152921512889833648 |  dest_result_addr=1152921512889833656
            // 0x028EAE3C: ADD x29, sp, #0x50         | X29 = (1152921512889833568 + 80) = 1152921512889833648 (0x10000001EDB458B0);
            // 0x028EAE40: SUB sp, sp, #0x90          | SP = (1152921512889833568 - 144) = 1152921512889833424 (0x10000001EDB457D0);
            // 0x028EAE44: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EAE48: LDRB w8, [x20, #0xa01]     | W8 = (bool)static_value_037B8A01;       
            // 0x028EAE4C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EAE50: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028EAE54: MOV x23, x1                | X23 = X1;//m1                           
            // 0x028EAE58: TBNZ w8, #0, #0x28eae74    | if (static_value_037B8A01 == true) goto label_0;
            // 0x028EAE5C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x028EAE60: LDR x8, [x8, #0x628]       | X8 = 0x2B90CC4;                         
            // 0x028EAE64: LDR w0, [x8]               | W0 = 0x19F5;                            
            // 0x028EAE68: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F5, ????);     
            // 0x028EAE6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EAE70: STRB w8, [x20, #0xa01]     | static_value_037B8A01 = true;            //  dest_result_addr=58427905
            label_0:
            // 0x028EAE74: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x028EAE78: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x028EAE7C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EAE80: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAE84: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EAE88: TBNZ w9, #0, #0x28eae94    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EAE8C: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_40 = 8;
            // 0x028EAE90: B #0x28eaeac               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EAE94: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAE98: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EAE9C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EAEA0: SUB w25, w0, #0x10         | W25 = (null - 16) = val_40 (0x100000000D137FF0);
            val_40 = 1152921504826228720;
            // 0x028EAEA4: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAEA8: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EAEAC: TBNZ w9, #0, #0x28eaeb8    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EAEB0: ORR w27, wzr, #8           | W27 = 8(0x8);                           
            val_41 = 8;
            // 0x028EAEB4: B #0x28eaec4               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EAEB8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAEBC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EAEC0: SUB w27, w0, #0x10         | W27 = (null - 16) = val_41 (0x100000000D137FF0);
            val_41 = 1152921504826228720;
            label_4:
            // 0x028EAEC4: CBNZ x23, #0x28eaecc       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028EAEC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EAECC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EAED0: MOV x0, x23                | X0 = X1;//m1                            
            // 0x028EAED4: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EAED8: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_42 = null;
            // 0x028EAEDC: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x028EAEE0: ADD x9, x8, #0x109         | X9 = (val_42 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAEE4: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EAEE8: TBNZ w9, #0, #0x28eaef4    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028EAEEC: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_44 = 8;
            // 0x028EAEF0: B #0x28eaf0c               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028EAEF4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAEF8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EAEFC: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_42 = null;
            // 0x028EAF00: SUB w10, w0, #0x10         | W10 = (val_42 - 16) = val_44 (0x100000000D137FF0);
            val_44 = 1152921504826228720;
            // 0x028EAF04: ADD x9, x8, #0x109         | X9 = (val_42 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAF08: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_7:
            // 0x028EAF0C: SUB x20, x22, w10, sxtw    | X20 = (X2 - (val_44) << );              
            var val_2 = X2 - (val_44 << );
            // 0x028EAF10: TBZ w9, #8, #0x28eaf24     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_9;
            // 0x028EAF14: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EAF18: CBNZ w9, #0x28eaf24        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x028EAF1C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAF20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028EAF24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EAF28: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EAF2C: MOV x1, x20                | X1 = (X2 - (val_44) << );//m1           
            // 0x028EAF30: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028EAF34: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EAF38: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EAF3C: MOV x21, x0                | X21 = val_3;//m1                        
            val_45 = val_3;
            // 0x028EAF40: CBNZ x23, #0x28eaf48       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x028EAF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x028EAF48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EAF4C: MOV x0, x23                | X0 = X1;//m1                            
            // 0x028EAF50: MOV x1, x20                | X1 = (X2 - (val_44) << );//m1           
            // 0x028EAF54: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EAF58: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_46 = null;
            // 0x028EAF5C: ADD x9, x8, #0x109         | X9 = (val_46 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAF60: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EAF64: TBNZ w9, #0, #0x28eaf70    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_11;
            // 0x028EAF68: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_48 = 8;
            // 0x028EAF6C: B #0x28eaf88               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x028EAF70: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAF74: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EAF78: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_46 = null;
            // 0x028EAF7C: SUB w26, w0, #0x10         | W26 = (val_46 - 16) = val_48 (0x100000000D137FF0);
            val_48 = 1152921504826228720;
            // 0x028EAF80: ADD x9, x8, #0x109         | X9 = (val_46 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EAF84: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_12:
            // 0x028EAF88: SUB x20, x22, w25, sxtw    | X20 = (X2 - (val_40) << );              
            var val_4 = X2 - (val_40 << );
            // 0x028EAF8C: TBNZ w9, #0, #0x28eaf98    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_13;
            // 0x028EAF90: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_49 = 8;
            // 0x028EAF94: B #0x28eafa4               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028EAF98: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EAF9C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EAFA0: SUB w8, w0, #0x10          | W8 = (val_46 - 16) = val_49 (0x100000000D137FF0);
            val_49 = 1152921504826228720;
            label_14:
            // 0x028EAFA4: SUB x9, x22, w26, sxtw     | X9 = (X2 - (val_48) << );               
            var val_5 = X2 - (val_48 << );
            // 0x028EAFA8: SUB x25, x9, w8, sxtw      | X25 = ((X2 - (val_48) << ) - (val_49) << );
            var val_6 = val_5 - (val_49 << );
            // 0x028EAFAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EAFB0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EAFB4: MOV x1, x25                | X1 = ((X2 - (val_48) << ) - (val_49) << );//m1
            // 0x028EAFB8: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028EAFBC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EAFC0: SUB x20, x20, w27, sxtw    | X20 = ((X2 - (val_40) << ) - (val_41) << );
            val_4 = val_4 - (val_41 << );
            // 0x028EAFC4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EAFC8: MOV x22, x0                | X22 = val_7;//m1                        
            val_50 = val_7;
            // 0x028EAFCC: CBNZ x23, #0x28eafd4       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028EAFD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_15:
            // 0x028EAFD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_51 = 0;
            // 0x028EAFD8: MOV x0, x23                | X0 = X1;//m1                            
            // 0x028EAFDC: MOV x1, x25                | X1 = ((X2 - (val_48) << ) - (val_49) << );//m1
            // 0x028EAFE0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EAFE4: CBZ x22, #0x28eb038        | if (val_7 == null) goto label_16;       
            if(val_50 == null)
            {
                goto label_16;
            }
            // 0x028EAFE8: CBZ x21, #0x28eb050        | if (val_3 == null) goto label_17;       
            if(val_45 == null)
            {
                goto label_17;
            }
            // 0x028EAFEC: ADRP x26, #0x3657000       | X26 = 56979456 (0x3657000);             
            // 0x028EAFF0: LDR x26, [x26, #0xa28]     | X26 = 1152921504825589760;              
            // 0x028EAFF4: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028EAFF8: LDR x1, [x26]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EAFFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EB000: LDR x1, [x26]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB004: MOV x23, x0                | X23 = val_7;//m1                        
            // 0x028EB008: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB00C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB010: MOV x25, x0                | X25 = val_3;//m1                        
            val_52 = val_45;
            // 0x028EB014: CBZ x23, #0x28eb088        | if (val_7 == null) goto label_18;       
            if(val_50 == null)
            {
                goto label_18;
            }
            // 0x028EB018: LDR x24, [x26]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB01C: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028EB020: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_53 = null;
            // 0x028EB024: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EB028: MOV x23, x0                | X23 = val_7;//m1                        
            val_54 = val_50;
            // 0x028EB02C: CBZ x23, #0x28eb170        | if (val_7 == null) goto label_19;       
            if(val_54 == null)
            {
                goto label_19;
            }
            // 0x028EB030: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_41 = 0;
            // 0x028EB034: B #0x28eb1a8               |  goto label_20;                         
            goto label_20;
            label_16:
            // 0x028EB038: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EB03C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EB040: MOV x1, x20                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EB044: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EB048: MOV x3, x21                | X3 = val_3;//m1                         
            // 0x028EB04C: B #0x28eb064               |  goto label_21;                         
            goto label_21;
            label_17:
            // 0x028EB050: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EB054: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EB058: MOV x1, x20                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EB05C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EB060: MOV x3, x22                | X3 = val_7;//m1                         
            label_21:
            // 0x028EB064: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EB068: SUB sp, x29, #0x50         | SP = (1152921512889833648 - 80) = 1152921512889833568 (0x10000001EDB45860);
            // 0x028EB06C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EB070: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EB074: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EB078: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EB07C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EB080: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EB084: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            label_18:
            // 0x028EB088: CBZ x25, #0x28eb284        | if (val_3 == null) goto label_22;       
            if(val_52 == null)
            {
                goto label_22;
            }
            // 0x028EB08C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB090: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028EB094: BL #0x16fb28c              | X0 = val_7.GetType();                   
            System.Type val_8 = val_50.GetType();
            // 0x028EB098: LDR x24, [x26]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB09C: MOV x23, x0                | X23 = val_8;//m1                        
            val_54 = val_8;
            // 0x028EB0A0: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB0A4: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB0A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB0AC: CBNZ x0, #0x28eb0e0        | if (val_3 != null) goto label_23;       
            if(val_45 != null)
            {
                goto label_23;
            }
            // 0x028EB0B0: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB0B4: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB0B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB0BC: ADD x8, sp, #0x70          | X8 = (1152921512889833424 + 112) = 1152921512889833536 (0x10000001EDB45840);
            // 0x028EB0C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB0C4: LDR x0, [sp, #0x70]        | X0 = val_9;                              //  find_add[1152921512889821664]
            // 0x028EB0C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x028EB0CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB0D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x028EB0D4: ADD x0, sp, #0x70          | X0 = (1152921512889833424 + 112) = 1152921512889833536 (0x10000001EDB45840);
            // 0x028EB0D8: BL #0x299a140              | 
            // 0x028EB0DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB45840, ????);
            label_23:
            // 0x028EB0E0: LDR x24, [x26]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB0E4: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB0E8: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB0EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB0F0: MOV x25, x0                | X25 = val_3;//m1                        
            val_52 = val_45;
            // 0x028EB0F4: CBNZ x25, #0x28eb128       | if (val_3 != null) goto label_24;       
            if(val_52 != null)
            {
                goto label_24;
            }
            // 0x028EB0F8: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB0FC: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB100: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB104: SUB x8, x29, #0x68         | X8 = (1152921512889833648 - 104) = 1152921512889833544 (0x10000001EDB45848);
            // 0x028EB108: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB10C: LDUR x0, [x29, #-0x68]     | X0 = val_10;                             //  find_add[1152921512889821664]
            // 0x028EB110: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x028EB114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB118: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x028EB11C: SUB x0, x29, #0x68         | X0 = (1152921512889833648 - 104) = 1152921512889833544 (0x10000001EDB45848);
            // 0x028EB120: BL #0x299a140              | 
            // 0x028EB124: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_52 = 0;
            label_24:
            // 0x028EB128: LDR x8, [x25]              | X8 = 0x10102464C457F;                   
            // 0x028EB12C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB130: CBZ x9, #0x28eb15c         | if (mem[282584257676929] == 0) goto label_25;
            if(mem[282584257676929] == 0)
            {
                goto label_25;
            }
            // 0x028EB134: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_30 = mem[282584257676823];
            // 0x028EB138: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_31 = 0;
            // 0x028EB13C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_30 = val_30 + 8;
            label_27:
            // 0x028EB140: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB144: CMP x12, x24               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB148: B.EQ #0x28eb3ac            | if ((mem[282584257676823] + 8) + -8 == null) goto label_26;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_26;
            }
            // 0x028EB14C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_31 = val_31 + 1;
            // 0x028EB150: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_30 = val_30 + 16;
            // 0x028EB154: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB158: B.LO #0x28eb140            | if (0 < mem[282584257676929]) goto label_27;
            if(val_31 < mem[282584257676929])
            {
                goto label_27;
            }
            label_25:
            // 0x028EB15C: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            val_55 = 8;
            // 0x028EB160: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            val_56 = val_52;
            // 0x028EB164: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB168: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB16C: B #0x28eb3bc               |  goto label_28;                         
            goto label_28;
            label_19:
            // 0x028EB170: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EB174: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB178: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB17C: ADD x8, sp, #0x10          | X8 = (1152921512889833424 + 16) = 1152921512889833440 (0x10000001EDB457E0);
            // 0x028EB180: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB184: LDR x0, [sp, #0x10]        | X0 = val_11;                             //  find_add[1152921512889821664]
            // 0x028EB188: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x028EB18C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_53 = 0;
            // 0x028EB190: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x028EB194: ADD x0, sp, #0x10          | X0 = (1152921512889833424 + 16) = 1152921512889833440 (0x10000001EDB457E0);
            // 0x028EB198: BL #0x299a140              | 
            // 0x028EB19C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB457E0, ????);
            // 0x028EB1A0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_54 = 0;
            // 0x028EB1A4: ORR w27, wzr, #1           | W27 = 1(0x1);                           
            val_41 = 1;
            label_20:
            // 0x028EB1A8: LDR x24, [x26]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB1AC: CBZ x25, #0x28eb1f8        | if (val_3 == null) goto label_29;       
            if(val_52 == null)
            {
                goto label_29;
            }
            // 0x028EB1B0: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EB1B4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB1B8: CBZ x9, #0x28eb1e4         | if (mem[282584257676929] == 0) goto label_30;
            if(mem[282584257676929] == 0)
            {
                goto label_30;
            }
            // 0x028EB1BC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_32 = mem[282584257676823];
            // 0x028EB1C0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_33 = 0;
            // 0x028EB1C4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_32 = val_32 + 8;
            label_32:
            // 0x028EB1C8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB1CC: CMP x12, x24               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB1D0: B.EQ #0x28eb338            | if ((mem[282584257676823] + 8) + -8 == null) goto label_31;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_31;
            }
            // 0x028EB1D4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_33 = val_33 + 1;
            // 0x028EB1D8: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_32 = val_32 + 16;
            // 0x028EB1DC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB1E0: B.LO #0x28eb1c8            | if (0 < mem[282584257676929]) goto label_32;
            if(val_33 < mem[282584257676929])
            {
                goto label_32;
            }
            label_30:
            // 0x028EB1E4: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            val_57 = 6;
            // 0x028EB1E8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_58 = val_54;
            // 0x028EB1EC: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_53 = null;
            // 0x028EB1F0: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB1F4: B #0x28eb348               |  goto label_33;                         
            goto label_33;
            label_29:
            // 0x028EB1F8: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028EB1FC: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_59 = null;
            // 0x028EB200: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EB204: MOV x23, x0                | X23 = val_7;//m1                        
            val_60 = val_50;
            // 0x028EB208: CBNZ x23, #0x28eb23c       | if (val_7 != null) goto label_34;       
            if(val_60 != null)
            {
                goto label_34;
            }
            // 0x028EB20C: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EB210: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB214: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB218: ADD x8, sp, #0x40          | X8 = (1152921512889833424 + 64) = 1152921512889833488 (0x10000001EDB45810);
            // 0x028EB21C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB220: LDR x0, [sp, #0x40]        | X0 = val_12;                             //  find_add[1152921512889821664]
            // 0x028EB224: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x028EB228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_59 = 0;
            // 0x028EB22C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x028EB230: ADD x0, sp, #0x40          | X0 = (1152921512889833424 + 64) = 1152921512889833488 (0x10000001EDB45810);
            // 0x028EB234: BL #0x299a140              | 
            // 0x028EB238: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_60 = 0;
            label_34:
            // 0x028EB23C: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EB240: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB244: CBZ x9, #0x28eb270         | if (mem[282584257676929] == 0) goto label_35;
            if(mem[282584257676929] == 0)
            {
                goto label_35;
            }
            // 0x028EB248: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_34 = mem[282584257676823];
            // 0x028EB24C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_35 = 0;
            // 0x028EB250: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_34 = val_34 + 8;
            label_37:
            // 0x028EB254: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB258: CMP x12, x24               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB25C: B.EQ #0x28eb458            | if ((mem[282584257676823] + 8) + -8 == null) goto label_36;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_36;
            }
            // 0x028EB260: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_35 = val_35 + 1;
            // 0x028EB264: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_34 = val_34 + 16;
            // 0x028EB268: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB26C: B.LO #0x28eb254            | if (0 < mem[282584257676929]) goto label_37;
            if(val_35 < mem[282584257676929])
            {
                goto label_37;
            }
            label_35:
            // 0x028EB270: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            val_61 = 6;
            // 0x028EB274: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_62 = val_60;
            // 0x028EB278: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_59 = null;
            // 0x028EB27C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB280: B #0x28eb468               |  goto label_38;                         
            goto label_38;
            label_22:
            // 0x028EB284: ADRP x23, #0x3639000       | X23 = 56856576 (0x3639000);             
            // 0x028EB288: LDR x23, [x23, #0xbe8]     | X23 = 1152921504608870400;              
            val_54 = 1152921504608870400;
            // 0x028EB28C: LDR x9, [x22]              | X9 = typeof(System.Object);             
            // 0x028EB290: LDR x1, [x23]              | X1 = typeof(System.Delegate);           
            val_63 = null;
            // 0x028EB294: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB298: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB29C: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EB2A0: B.LO #0x28eb2b8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_39;
            // 0x028EB2A4: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EB2A8: ADD x10, x10, x8, lsl #3   | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_type
            // 0x028EB2AC: LDUR x10, [x10, #-8]       | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EB2B0: CMP x10, x1                | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EB2B4: B.EQ #0x28eb2e8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_63) goto label_40;
            label_39:
            // 0x028EB2B8: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB2BC: SUB x8, x29, #0x58         | X8 = (1152921512889833648 - 88) = 1152921512889833560 (0x10000001EDB45858);
            // 0x028EB2C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB2C4: LDUR x0, [x29, #-0x58]     | X0 = val_13;                             //  find_add[1152921512889821664]
            // 0x028EB2C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x028EB2CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB2D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x028EB2D4: SUB x0, x29, #0x58         | X0 = (1152921512889833648 - 88) = 1152921512889833560 (0x10000001EDB45858);
            // 0x028EB2D8: BL #0x299a140              | 
            // 0x028EB2DC: LDR x1, [x23]              | X1 = typeof(System.Delegate);           
            val_63 = null;
            // 0x028EB2E0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_65 = 0;
            // 0x028EB2E4: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            label_40:
            // 0x028EB2E8: LDR x9, [x21]              | X9 = typeof(System.Object);             
            // 0x028EB2EC: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB2F0: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EB2F4: B.LO #0x28eb30c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_41;
            // 0x028EB2F8: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EB2FC: ADD x8, x10, w8, uxtw #3   | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHi
            // 0x028EB300: LDUR x8, [x8, #-8]         | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8;
            // 0x028EB304: CMP x8, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8, typeof(System.Delegate))
            // 0x028EB308: B.EQ #0x28eb42c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8 == val_63) goto label_51;
            label_41:
            // 0x028EB30C: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB310: ADD x8, sp, #8             | X8 = (1152921512889833424 + 8) = 1152921512889833432 (0x10000001EDB457D8);
            // 0x028EB314: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB318: LDR x0, [sp, #8]           | X0 = val_14;                             //  find_add[1152921512889821664]
            // 0x028EB31C: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028EB320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB324: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028EB328: ADD x0, sp, #8             | X0 = (1152921512889833424 + 8) = 1152921512889833432 (0x10000001EDB457D8);
            // 0x028EB32C: BL #0x299a140              | 
            // 0x028EB330: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_45 = 0;
            // 0x028EB334: B #0x28eb42c               |  goto label_51;                         
            goto label_51;
            label_31:
            // 0x028EB338: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_36 = val_32;
            // 0x028EB33C: ADD w9, w9, #6             | W9 = ((mem[282584257676823] + 8) + 6);  
            val_36 = val_36 + 6;
            // 0x028EB340: ADD x8, x8, w9, uxtw #4    | X8 = (val_54 + ((mem[282584257676823] + 8) + 6));
            val_54 = val_54 + val_36;
            // 0x028EB344: ADD x0, x8, #0x110         | X0 = ((val_54 + ((mem[282584257676823] + 8) + 6)) + 272);
            val_58 = val_54 + 272;
            label_33:
            // 0x028EB348: LDP x8, x1, [x0]           | X8 = ((val_54 + ((mem[282584257676823] + 8) + 6)) + 272); X1 = ((val_54 + ((mem[282584257676823] + 8) + 6)) + 272) + 8; //  | 
            // 0x028EB34C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EB350: BLR x8                     | X0 = ((val_54 + ((mem[282584257676823] + 8) + 6)) + 272)();
            // 0x028EB354: AND w8, w0, #1             | W8 = (val_54 & 1) = 0 (0x00000000);     
            // 0x028EB358: TBNZ w8, #0, #0x28eb570    | if ((0x0 & 0x1) != 0) goto label_44;    
            if((0 & 1) != 0)
            {
                goto label_44;
            }
            // 0x028EB35C: CBZ w27, #0x28eb364        | if (0x1 == 0) goto label_45;            
            if(val_41 == 0)
            {
                goto label_45;
            }
            // 0x028EB360: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_45:
            // 0x028EB364: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            var val_44 = 1179403647;
            // 0x028EB368: LDR x1, [x26]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB36C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB370: CBZ x9, #0x28eb39c         | if (mem[282584257676929] == 0) goto label_46;
            if(mem[282584257676929] == 0)
            {
                goto label_46;
            }
            // 0x028EB374: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_37 = mem[282584257676823];
            // 0x028EB378: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_38 = 0;
            // 0x028EB37C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_37 = val_37 + 8;
            label_48:
            // 0x028EB380: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB384: CMP x12, x1                | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB388: B.EQ #0x28eb550            | if ((mem[282584257676823] + 8) + -8 == null) goto label_47;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_47;
            }
            // 0x028EB38C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_38 = val_38 + 1;
            // 0x028EB390: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_37 = val_37 + 16;
            // 0x028EB394: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB398: B.LO #0x28eb380            | if (0 < mem[282584257676929]) goto label_48;
            if(val_38 < mem[282584257676929])
            {
                goto label_48;
            }
            label_46:
            // 0x028EB39C: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            val_57 = 7;
            // 0x028EB3A0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_66 = val_54;
            // 0x028EB3A4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB3A8: B #0x28eb560               |  goto label_49;                         
            goto label_49;
            label_26:
            // 0x028EB3AC: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_39 = val_30;
            // 0x028EB3B0: ADD w9, w9, #8             | W9 = ((mem[282584257676823] + 8) + 8);  
            val_39 = val_39 + 8;
            // 0x028EB3B4: ADD x8, x8, w9, uxtw #4    | X8 = (val_52 + ((mem[282584257676823] + 8) + 8));
            val_52 = val_52 + val_39;
            // 0x028EB3B8: ADD x0, x8, #0x110         | X0 = ((val_52 + ((mem[282584257676823] + 8) + 8)) + 272);
            val_56 = val_52 + 272;
            label_28:
            // 0x028EB3BC: LDP x8, x2, [x0]           | X8 = ((val_52 + ((mem[282584257676823] + 8) + 8)) + 272); X2 = ((val_52 + ((mem[282584257676823] + 8) + 8)) + 272) + 8; //  | 
            // 0x028EB3C0: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x028EB3C4: MOV x1, x23                | X1 = val_8;//m1                         
            // 0x028EB3C8: BLR x8                     | X0 = ((val_52 + ((mem[282584257676823] + 8) + 8)) + 272)();
            // 0x028EB3CC: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028EB3D0: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028EB3D4: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EB3D8: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            val_45 = val_52;
            // 0x028EB3DC: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028EB3E0: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB3E4: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB3E8: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EB3EC: B.LO #0x28eb404            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_50;
            // 0x028EB3F0: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EB3F4: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028EB3F8: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EB3FC: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EB400: B.EQ #0x28eb42c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_51;
            label_50:
            // 0x028EB404: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB408: SUB x8, x29, #0x60         | X8 = (1152921512889833648 - 96) = 1152921512889833552 (0x10000001EDB45850);
            // 0x028EB40C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB410: LDUR x0, [x29, #-0x60]     | X0 = val_16;                             //  find_add[1152921512889821664]
            // 0x028EB414: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x028EB418: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB41C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x028EB420: SUB x0, x29, #0x60         | X0 = (1152921512889833648 - 96) = 1152921512889833552 (0x10000001EDB45850);
            // 0x028EB424: BL #0x299a140              | 
            // 0x028EB428: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_65 = 0;
            label_51:
            // 0x028EB42C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EB430: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EB434: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x028EB438: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x028EB43C: BL #0x1c34bb4              | X0 = System.Delegate.Combine(a:  0, b:  val_65);
            System.Delegate val_17 = System.Delegate.Combine(a:  0, b:  val_65);
            // 0x028EB440: MOV x3, x0                 | X3 = val_17;//m1                        
            // 0x028EB444: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EB448: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EB44C: MOV x1, x20                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EB450: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EB454: B #0x28eb9c4               |  goto label_80;                         
            goto label_80;
            label_36:
            // 0x028EB458: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_40 = val_34;
            // 0x028EB45C: ADD w9, w9, #6             | W9 = ((mem[282584257676823] + 8) + 6);  
            val_40 = val_40 + 6;
            // 0x028EB460: ADD x8, x8, w9, uxtw #4    | X8 = (val_60 + ((mem[282584257676823] + 8) + 6));
            val_60 = val_60 + val_40;
            // 0x028EB464: ADD x0, x8, #0x110         | X0 = ((val_60 + ((mem[282584257676823] + 8) + 6)) + 272);
            val_62 = val_60 + 272;
            label_38:
            // 0x028EB468: LDP x8, x1, [x0]           | X8 = ((val_60 + ((mem[282584257676823] + 8) + 6)) + 272); X1 = ((val_60 + ((mem[282584257676823] + 8) + 6)) + 272) + 8; //  | 
            // 0x028EB46C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EB470: BLR x8                     | X0 = ((val_60 + ((mem[282584257676823] + 8) + 6)) + 272)();
            // 0x028EB474: AND w8, w0, #1             | W8 = (val_60 & 1) = 0 (0x00000000);     
            // 0x028EB478: TBNZ w8, #0, #0x28eb850    | if ((0x0 & 0x1) != 0) goto label_53;    
            if((0 & 1) != 0)
            {
                goto label_53;
            }
            // 0x028EB47C: LDR x23, [x26]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB480: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028EB484: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB488: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EB48C: CBNZ x0, #0x28eb4c0        | if (val_7 != null) goto label_54;       
            if(val_50 != null)
            {
                goto label_54;
            }
            // 0x028EB490: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EB494: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB498: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB49C: ADD x8, sp, #0x48          | X8 = (1152921512889833424 + 72) = 1152921512889833496 (0x10000001EDB45818);
            // 0x028EB4A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB4A4: LDR x0, [sp, #0x48]        | X0 = val_18;                             //  find_add[1152921512889821664]
            // 0x028EB4A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x028EB4AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB4B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x028EB4B4: ADD x0, sp, #0x48          | X0 = (1152921512889833424 + 72) = 1152921512889833496 (0x10000001EDB45818);
            // 0x028EB4B8: BL #0x299a140              | 
            // 0x028EB4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB45818, ????);
            label_54:
            // 0x028EB4C0: LDR x23, [x26]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB4C4: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028EB4C8: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_67 = null;
            // 0x028EB4CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EB4D0: MOV x24, x0                | X24 = val_7;//m1                        
            val_68 = val_50;
            // 0x028EB4D4: CBNZ x24, #0x28eb508       | if (val_7 != null) goto label_55;       
            if(val_68 != null)
            {
                goto label_55;
            }
            // 0x028EB4D8: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EB4DC: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB4E0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB4E4: ADD x8, sp, #0x50          | X8 = (1152921512889833424 + 80) = 1152921512889833504 (0x10000001EDB45820);
            // 0x028EB4E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB4EC: LDR x0, [sp, #0x50]        | X0 = val_19;                             //  find_add[1152921512889821664]
            // 0x028EB4F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x028EB4F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_67 = 0;
            // 0x028EB4F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x028EB4FC: ADD x0, sp, #0x50          | X0 = (1152921512889833424 + 80) = 1152921512889833504 (0x10000001EDB45820);
            // 0x028EB500: BL #0x299a140              | 
            // 0x028EB504: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_68 = 0;
            label_55:
            // 0x028EB508: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EB50C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB510: CBZ x9, #0x28eb53c         | if (mem[282584257676929] == 0) goto label_56;
            if(mem[282584257676929] == 0)
            {
                goto label_56;
            }
            // 0x028EB514: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_41 = mem[282584257676823];
            // 0x028EB518: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_42 = 0;
            // 0x028EB51C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_41 = val_41 + 8;
            label_58:
            // 0x028EB520: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB524: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB528: B.EQ #0x28eb830            | if ((mem[282584257676823] + 8) + -8 == null) goto label_57;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_57;
            }
            // 0x028EB52C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_42 = val_42 + 1;
            // 0x028EB530: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_41 = val_41 + 16;
            // 0x028EB534: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB538: B.LO #0x28eb520            | if (0 < mem[282584257676929]) goto label_58;
            if(val_42 < mem[282584257676929])
            {
                goto label_58;
            }
            label_56:
            // 0x028EB53C: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            val_61 = 7;
            // 0x028EB540: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_69 = val_68;
            // 0x028EB544: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_67 = null;
            // 0x028EB548: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB54C: B #0x28eb840               |  goto label_59;                         
            goto label_59;
            label_47:
            // 0x028EB550: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_43 = val_37;
            // 0x028EB554: ADD w9, w9, #7             | W9 = ((mem[282584257676823] + 8) + 7);  
            val_43 = val_43 + 7;
            // 0x028EB558: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 7));
            val_44 = val_44 + val_43;
            // 0x028EB55C: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 7)) + 272);
            val_66 = val_44 + 272;
            label_49:
            // 0x028EB560: LDP x8, x1, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 7)) + 272); X1 = ((1179403647 + ((mem[282584257676823] + 8) + 7)) + 272) + 8; //  | 
            // 0x028EB564: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EB568: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 7)) + 272)();
            // 0x028EB56C: MOV x23, x0                | X23 = 0 (0x0);//ML01                    
            val_54 = val_54;
            label_44:
            // 0x028EB570: LDR x22, [x26]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB574: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB578: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB57C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB580: CBNZ x0, #0x28eb5b4        | if (val_3 != null) goto label_60;       
            if(val_45 != null)
            {
                goto label_60;
            }
            // 0x028EB584: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB588: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB58C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB590: ADD x8, sp, #0x18          | X8 = (1152921512889833424 + 24) = 1152921512889833448 (0x10000001EDB457E8);
            // 0x028EB594: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB598: LDR x0, [sp, #0x18]        | X0 = val_20;                             //  find_add[1152921512889821664]
            // 0x028EB59C: BL #0x27af090              | X0 = sub_27AF090( ?? val_20, ????);     
            // 0x028EB5A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB5A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            // 0x028EB5A8: ADD x0, sp, #0x18          | X0 = (1152921512889833424 + 24) = 1152921512889833448 (0x10000001EDB457E8);
            // 0x028EB5AC: BL #0x299a140              | 
            // 0x028EB5B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB457E8, ????);
            label_60:
            // 0x028EB5B4: LDR x22, [x26]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB5B8: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB5BC: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_70 = null;
            // 0x028EB5C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB5C4: MOV x24, x0                | X24 = val_3;//m1                        
            val_71 = val_45;
            // 0x028EB5C8: CBNZ x24, #0x28eb5fc       | if (val_3 != null) goto label_61;       
            if(val_71 != null)
            {
                goto label_61;
            }
            // 0x028EB5CC: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB5D0: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB5D4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB5D8: ADD x8, sp, #0x20          | X8 = (1152921512889833424 + 32) = 1152921512889833456 (0x10000001EDB457F0);
            // 0x028EB5DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB5E0: LDR x0, [sp, #0x20]        | X0 = val_21;                             //  find_add[1152921512889821664]
            // 0x028EB5E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_21, ????);     
            // 0x028EB5E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_70 = 0;
            // 0x028EB5EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            // 0x028EB5F0: ADD x0, sp, #0x20          | X0 = (1152921512889833424 + 32) = 1152921512889833456 (0x10000001EDB457F0);
            // 0x028EB5F4: BL #0x299a140              | 
            // 0x028EB5F8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_71 = 0;
            label_61:
            // 0x028EB5FC: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EB600: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB604: CBZ x9, #0x28eb630         | if (mem[282584257676929] == 0) goto label_62;
            if(mem[282584257676929] == 0)
            {
                goto label_62;
            }
            // 0x028EB608: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_45 = mem[282584257676823];
            // 0x028EB60C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_46 = 0;
            // 0x028EB610: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_45 = val_45 + 8;
            label_64:
            // 0x028EB614: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB618: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB61C: B.EQ #0x28eb644            | if ((mem[282584257676823] + 8) + -8 == null) goto label_63;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_63;
            }
            // 0x028EB620: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_46 = val_46 + 1;
            // 0x028EB624: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_45 = val_45 + 16;
            // 0x028EB628: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB62C: B.LO #0x28eb614            | if (0 < mem[282584257676929]) goto label_64;
            if(val_46 < mem[282584257676929])
            {
                goto label_64;
            }
            label_62:
            // 0x028EB630: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            val_57 = 6;
            // 0x028EB634: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_72 = val_71;
            // 0x028EB638: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_70 = null;
            // 0x028EB63C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB640: B #0x28eb654               |  goto label_65;                         
            goto label_65;
            label_63:
            // 0x028EB644: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_47 = val_45;
            // 0x028EB648: ADD w9, w9, #6             | W9 = ((mem[282584257676823] + 8) + 6);  
            val_47 = val_47 + 6;
            // 0x028EB64C: ADD x8, x8, w9, uxtw #4    | X8 = (val_71 + ((mem[282584257676823] + 8) + 6));
            val_71 = val_71 + val_47;
            // 0x028EB650: ADD x0, x8, #0x110         | X0 = ((val_71 + ((mem[282584257676823] + 8) + 6)) + 272);
            val_72 = val_71 + 272;
            label_65:
            // 0x028EB654: LDP x8, x1, [x0]           | X8 = ((val_71 + ((mem[282584257676823] + 8) + 6)) + 272); X1 = ((val_71 + ((mem[282584257676823] + 8) + 6)) + 272) + 8; //  | 
            // 0x028EB658: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EB65C: BLR x8                     | X0 = ((val_71 + ((mem[282584257676823] + 8) + 6)) + 272)();
            // 0x028EB660: AND w8, w0, #1             | W8 = (val_71 & 1) = 0 (0x00000000);     
            // 0x028EB664: TBNZ w8, #0, #0x28eb75c    | if ((0x0 & 0x1) != 0) goto label_66;    
            if((0 & 1) != 0)
            {
                goto label_66;
            }
            // 0x028EB668: LDR x22, [x26]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB66C: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB670: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB674: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB678: CBNZ x0, #0x28eb6ac        | if (val_3 != null) goto label_67;       
            if(val_45 != null)
            {
                goto label_67;
            }
            // 0x028EB67C: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB680: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB684: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB688: ADD x8, sp, #0x28          | X8 = (1152921512889833424 + 40) = 1152921512889833464 (0x10000001EDB457F8);
            // 0x028EB68C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB690: LDR x0, [sp, #0x28]        | X0 = val_22;                             //  find_add[1152921512889821664]
            // 0x028EB694: BL #0x27af090              | X0 = sub_27AF090( ?? val_22, ????);     
            // 0x028EB698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB69C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            // 0x028EB6A0: ADD x0, sp, #0x28          | X0 = (1152921512889833424 + 40) = 1152921512889833464 (0x10000001EDB457F8);
            // 0x028EB6A4: BL #0x299a140              | 
            // 0x028EB6A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB457F8, ????);
            label_67:
            // 0x028EB6AC: LDR x22, [x26]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB6B0: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EB6B4: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_73 = null;
            // 0x028EB6B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EB6BC: MOV x24, x0                | X24 = val_3;//m1                        
            val_74 = val_45;
            // 0x028EB6C0: CBNZ x24, #0x28eb6f4       | if (val_3 != null) goto label_68;       
            if(val_74 != null)
            {
                goto label_68;
            }
            // 0x028EB6C4: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB6C8: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB6CC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB6D0: ADD x8, sp, #0x30          | X8 = (1152921512889833424 + 48) = 1152921512889833472 (0x10000001EDB45800);
            // 0x028EB6D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB6D8: LDR x0, [sp, #0x30]        | X0 = val_23;                             //  find_add[1152921512889821664]
            // 0x028EB6DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_23, ????);     
            // 0x028EB6E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_73 = 0;
            // 0x028EB6E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            // 0x028EB6E8: ADD x0, sp, #0x30          | X0 = (1152921512889833424 + 48) = 1152921512889833472 (0x10000001EDB45800);
            // 0x028EB6EC: BL #0x299a140              | 
            // 0x028EB6F0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_74 = 0;
            label_68:
            // 0x028EB6F4: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EB6F8: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB6FC: CBZ x9, #0x28eb728         | if (mem[282584257676929] == 0) goto label_69;
            if(mem[282584257676929] == 0)
            {
                goto label_69;
            }
            // 0x028EB700: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_48 = mem[282584257676823];
            // 0x028EB704: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_49 = 0;
            // 0x028EB708: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_48 = val_48 + 8;
            label_71:
            // 0x028EB70C: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB710: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB714: B.EQ #0x28eb73c            | if ((mem[282584257676823] + 8) + -8 == null) goto label_70;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_70;
            }
            // 0x028EB718: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_49 = val_49 + 1;
            // 0x028EB71C: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_48 = val_48 + 16;
            // 0x028EB720: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB724: B.LO #0x28eb70c            | if (0 < mem[282584257676929]) goto label_71;
            if(val_49 < mem[282584257676929])
            {
                goto label_71;
            }
            label_69:
            // 0x028EB728: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            val_57 = 7;
            // 0x028EB72C: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_75 = val_74;
            // 0x028EB730: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_73 = null;
            // 0x028EB734: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB738: B #0x28eb74c               |  goto label_72;                         
            goto label_72;
            label_70:
            // 0x028EB73C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_50 = val_48;
            // 0x028EB740: ADD w9, w9, #7             | W9 = ((mem[282584257676823] + 8) + 7);  
            val_50 = val_50 + 7;
            // 0x028EB744: ADD x8, x8, w9, uxtw #4    | X8 = (val_74 + ((mem[282584257676823] + 8) + 7));
            val_74 = val_74 + val_50;
            // 0x028EB748: ADD x0, x8, #0x110         | X0 = ((val_74 + ((mem[282584257676823] + 8) + 7)) + 272);
            val_75 = val_74 + 272;
            label_72:
            // 0x028EB74C: LDP x8, x1, [x0]           | X8 = ((val_74 + ((mem[282584257676823] + 8) + 7)) + 272); X1 = ((val_74 + ((mem[282584257676823] + 8) + 7)) + 272) + 8; //  | 
            // 0x028EB750: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EB754: BLR x8                     | X0 = ((val_74 + ((mem[282584257676823] + 8) + 7)) + 272)();
            // 0x028EB758: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
            val_45 = val_74;
            label_66:
            // 0x028EB75C: CBNZ x23, #0x28eb764       | if (0x0 != 0) goto label_73;            
            if(val_54 != 0)
            {
                goto label_73;
            }
            // 0x028EB760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_73:
            // 0x028EB764: LDR x22, [x26]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB768: CBZ x21, #0x28eb7ac        | if (0x0 == 0) goto label_74;            
            if(val_45 == 0)
            {
                goto label_74;
            }
            // 0x028EB76C: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028EB770: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB774: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x028EB778: MOV x24, x0                | X24 = 0 (0x0);//ML01                    
            val_76 = val_45;
            // 0x028EB77C: CBNZ x24, #0x28eb7b0       | if (0x0 != 0) goto label_75;            
            if(val_76 != 0)
            {
                goto label_75;
            }
            // 0x028EB780: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
            // 0x028EB784: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB788: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x028EB78C: ADD x8, sp, #0x38          | X8 = (1152921512889833424 + 56) = 1152921512889833480 (0x10000001EDB45808);
            // 0x028EB790: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x028EB794: LDR x0, [sp, #0x38]        | X0 = val_24;                             //  find_add[1152921512889821664]
            // 0x028EB798: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
            // 0x028EB79C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB7A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x028EB7A4: ADD x0, sp, #0x38          | X0 = (1152921512889833424 + 56) = 1152921512889833480 (0x10000001EDB45808);
            // 0x028EB7A8: BL #0x299a140              | 
            label_74:
            // 0x028EB7AC: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_76 = 0;
            label_75:
            // 0x028EB7B0: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            var val_54 = 1179403647;
            // 0x028EB7B4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB7B8: CBZ x9, #0x28eb7e4         | if (mem[282584257676929] == 0) goto label_76;
            if(mem[282584257676929] == 0)
            {
                goto label_76;
            }
            // 0x028EB7BC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_51 = mem[282584257676823];
            // 0x028EB7C0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_52 = 0;
            // 0x028EB7C4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_51 = val_51 + 8;
            label_78:
            // 0x028EB7C8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB7CC: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB7D0: B.EQ #0x28eb7f8            | if ((mem[282584257676823] + 8) + -8 == null) goto label_77;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_77;
            }
            // 0x028EB7D4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_52 = val_52 + 1;
            // 0x028EB7D8: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_51 = val_51 + 16;
            // 0x028EB7DC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB7E0: B.LO #0x28eb7c8            | if (0 < mem[282584257676929]) goto label_78;
            if(val_52 < mem[282584257676929])
            {
                goto label_78;
            }
            label_76:
            // 0x028EB7E4: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
            val_57 = 9;
            // 0x028EB7E8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_77 = val_54;
            // 0x028EB7EC: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB7F0: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB7F4: B #0x28eb808               |  goto label_79;                         
            goto label_79;
            label_77:
            // 0x028EB7F8: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_53 = val_51;
            // 0x028EB7FC: ADD w9, w9, #9             | W9 = ((mem[282584257676823] + 8) + 9);  
            val_53 = val_53 + 9;
            // 0x028EB800: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 9));
            val_54 = val_54 + val_53;
            // 0x028EB804: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 9)) + 272);
            val_77 = val_54 + 272;
            label_79:
            // 0x028EB808: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 9)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 9)) + 272) + 8; //  | 
            // 0x028EB80C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EB810: MOV x1, x24                | X1 = 0 (0x0);//ML01                     
            // 0x028EB814: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 9)) + 272)();
            // 0x028EB818: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EB81C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EB820: MOV x1, x20                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EB824: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EB828: MOV x3, x23                | X3 = 0 (0x0);//ML01                     
            // 0x028EB82C: B #0x28eb9c4               |  goto label_80;                         
            goto label_80;
            label_57:
            // 0x028EB830: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_55 = val_41;
            // 0x028EB834: ADD w9, w9, #7             | W9 = ((mem[282584257676823] + 8) + 7);  
            val_55 = val_55 + 7;
            // 0x028EB838: ADD x8, x8, w9, uxtw #4    | X8 = (val_68 + ((mem[282584257676823] + 8) + 7));
            val_68 = val_68 + val_55;
            // 0x028EB83C: ADD x0, x8, #0x110         | X0 = ((val_68 + ((mem[282584257676823] + 8) + 7)) + 272);
            val_69 = val_68 + 272;
            label_59:
            // 0x028EB840: LDP x8, x1, [x0]           | X8 = ((val_68 + ((mem[282584257676823] + 8) + 7)) + 272); X1 = ((val_68 + ((mem[282584257676823] + 8) + 7)) + 272) + 8; //  | 
            // 0x028EB844: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EB848: BLR x8                     | X0 = ((val_68 + ((mem[282584257676823] + 8) + 7)) + 272)();
            // 0x028EB84C: MOV x22, x0                | X22 = 0 (0x0);//ML01                    
            val_78 = val_68;
            label_53:
            // 0x028EB850: CBZ x22, #0x28eb8e0        | if (0x0 == 0) goto label_81;            
            if(val_78 == 0)
            {
                goto label_81;
            }
            // 0x028EB854: LDR x23, [x26]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EB858: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EB85C: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB860: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x028EB864: CBNZ x0, #0x28eb898        | if (0x0 != 0) goto label_82;            
            if(val_78 != 0)
            {
                goto label_82;
            }
            // 0x028EB868: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x028EB86C: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB870: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x028EB874: ADD x8, sp, #0x58          | X8 = (1152921512889833424 + 88) = 1152921512889833512 (0x10000001EDB45828);
            // 0x028EB878: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x028EB87C: LDR x0, [sp, #0x58]        | X0 = val_25;                             //  find_add[1152921512889821664]
            // 0x028EB880: BL #0x27af090              | X0 = sub_27AF090( ?? val_25, ????);     
            // 0x028EB884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB888: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            // 0x028EB88C: ADD x0, sp, #0x58          | X0 = (1152921512889833424 + 88) = 1152921512889833512 (0x10000001EDB45828);
            // 0x028EB890: BL #0x299a140              | 
            // 0x028EB894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB45828, ????);
            label_82:
            // 0x028EB898: LDR x23, [x26]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            val_54 = null;
            // 0x028EB89C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EB8A0: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB8A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x028EB8A8: MOV x24, x0                | X24 = 0 (0x0);//ML01                    
            val_79 = val_78;
            // 0x028EB8AC: CBNZ x24, #0x28eb8ec       | if (0x0 != 0) goto label_83;            
            if(val_79 != 0)
            {
                goto label_83;
            }
            // 0x028EB8B0: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x028EB8B4: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB8B8: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x028EB8BC: ADD x8, sp, #0x60          | X8 = (1152921512889833424 + 96) = 1152921512889833520 (0x10000001EDB45830);
            // 0x028EB8C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x028EB8C4: LDR x0, [sp, #0x60]        | X0 = val_26;                             //  find_add[1152921512889821664]
            // 0x028EB8C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_26, ????);     
            // 0x028EB8CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB8D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            // 0x028EB8D4: ADD x0, sp, #0x60          | X0 = (1152921512889833424 + 96) = 1152921512889833520 (0x10000001EDB45830);
            // 0x028EB8D8: BL #0x299a140              | 
            // 0x028EB8DC: B #0x28eb8e8               |  goto label_84;                         
            goto label_84;
            label_81:
            // 0x028EB8E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028EB8E4: LDR x23, [x26]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            val_54 = null;
            label_84:
            // 0x028EB8E8: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_79 = 0;
            label_83:
            // 0x028EB8EC: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028EB8F0: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028EB8F4: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EB8F8: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028EB8FC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB900: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EB904: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EB908: B.LO #0x28eb920            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_85;
            // 0x028EB90C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EB910: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028EB914: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EB918: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EB91C: B.EQ #0x28eb948            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_86;
            label_85:
            // 0x028EB920: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EB924: ADD x8, sp, #0x68          | X8 = (1152921512889833424 + 104) = 1152921512889833528 (0x10000001EDB45838);
            // 0x028EB928: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EB92C: LDR x0, [sp, #0x68]        | X0 = val_28;                             //  find_add[1152921512889821664]
            // 0x028EB930: BL #0x27af090              | X0 = sub_27AF090( ?? val_28, ????);     
            // 0x028EB934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EB938: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            // 0x028EB93C: ADD x0, sp, #0x68          | X0 = (1152921512889833424 + 104) = 1152921512889833528 (0x10000001EDB45838);
            // 0x028EB940: BL #0x299a140              | 
            // 0x028EB944: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_45 = 0;
            label_86:
            // 0x028EB948: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EB94C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EB950: CBZ x9, #0x28eb97c         | if (mem[282584257676929] == 0) goto label_87;
            if(mem[282584257676929] == 0)
            {
                goto label_87;
            }
            // 0x028EB954: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_56 = mem[282584257676823];
            // 0x028EB958: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_57 = 0;
            // 0x028EB95C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_56 = val_56 + 8;
            label_89:
            // 0x028EB960: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EB964: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EB968: B.EQ #0x28eb990            | if ((mem[282584257676823] + 8) + -8 == val_54) goto label_88;
            if(((mem[282584257676823] + 8) + -8) == val_54)
            {
                goto label_88;
            }
            // 0x028EB96C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_57 = val_57 + 1;
            // 0x028EB970: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_56 = val_56 + 16;
            // 0x028EB974: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EB978: B.LO #0x28eb960            | if (0 < mem[282584257676929]) goto label_89;
            if(val_57 < mem[282584257676929])
            {
                goto label_89;
            }
            label_87:
            // 0x028EB97C: MOVZ w2, #0xa              | W2 = 10 (0xA);//ML01                    
            val_61 = 10;
            // 0x028EB980: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_80 = val_79;
            // 0x028EB984: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EB988: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EB98C: B #0x28eb9a0               |  goto label_90;                         
            goto label_90;
            label_88:
            // 0x028EB990: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_58 = val_56;
            // 0x028EB994: ADD w9, w9, #0xa           | W9 = ((mem[282584257676823] + 8) + 10); 
            val_58 = val_58 + 10;
            // 0x028EB998: ADD x8, x8, w9, uxtw #4    | X8 = (val_79 + ((mem[282584257676823] + 8) + 10));
            val_79 = val_79 + val_58;
            // 0x028EB99C: ADD x0, x8, #0x110         | X0 = ((val_79 + ((mem[282584257676823] + 8) + 10)) + 272);
            val_80 = val_79 + 272;
            label_90:
            // 0x028EB9A0: LDP x8, x2, [x0]           | X8 = ((val_79 + ((mem[282584257676823] + 8) + 10)) + 272); X2 = ((val_79 + ((mem[282584257676823] + 8) + 10)) + 272) + 8; //  | 
            // 0x028EB9A4: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EB9A8: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028EB9AC: BLR x8                     | X0 = ((val_79 + ((mem[282584257676823] + 8) + 10)) + 272)();
            // 0x028EB9B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EB9B4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EB9B8: MOV x1, x20                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EB9BC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EB9C0: MOV x3, x22                | X3 = 0 (0x0);//ML01                     
            label_80:
            // 0x028EB9C4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EB9C8: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_29 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028EB9CC: SUB sp, x29, #0x50         | SP = (1152921512889833648 - 80) = 1152921512889833568 (0x10000001EDB45860);
            // 0x028EB9D0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EB9D4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EB9D8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EB9DC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EB9E0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EB9E4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EB9E8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_29;
            return val_29;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028EBAC0 (42908352), len: 2340  VirtAddr: 0x028EBAC0 RVA: 0x028EBAC0 token: 100680274 methodIndex: 29562 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* DelegateRemove(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_22;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            System.Delegate val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            // 0x028EBAC0: STP x28, x27, [sp, #-0x60]! | stack[1152921512890011104] = ???;  stack[1152921512890011112] = ???;  //  dest_result_addr=1152921512890011104 |  dest_result_addr=1152921512890011112
            // 0x028EBAC4: STP x26, x25, [sp, #0x10]  | stack[1152921512890011120] = ???;  stack[1152921512890011128] = ???;  //  dest_result_addr=1152921512890011120 |  dest_result_addr=1152921512890011128
            // 0x028EBAC8: STP x24, x23, [sp, #0x20]  | stack[1152921512890011136] = ???;  stack[1152921512890011144] = ???;  //  dest_result_addr=1152921512890011136 |  dest_result_addr=1152921512890011144
            // 0x028EBACC: STP x22, x21, [sp, #0x30]  | stack[1152921512890011152] = ???;  stack[1152921512890011160] = ???;  //  dest_result_addr=1152921512890011152 |  dest_result_addr=1152921512890011160
            // 0x028EBAD0: STP x20, x19, [sp, #0x40]  | stack[1152921512890011168] = ???;  stack[1152921512890011176] = ???;  //  dest_result_addr=1152921512890011168 |  dest_result_addr=1152921512890011176
            // 0x028EBAD4: STP x29, x30, [sp, #0x50]  | stack[1152921512890011184] = ???;  stack[1152921512890011192] = ???;  //  dest_result_addr=1152921512890011184 |  dest_result_addr=1152921512890011192
            // 0x028EBAD8: ADD x29, sp, #0x50         | X29 = (1152921512890011104 + 80) = 1152921512890011184 (0x10000001EDB70E30);
            // 0x028EBADC: SUB sp, sp, #0x60          | SP = (1152921512890011104 - 96) = 1152921512890011008 (0x10000001EDB70D80);
            // 0x028EBAE0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EBAE4: LDRB w8, [x20, #0xa02]     | W8 = (bool)static_value_037B8A02;       
            // 0x028EBAE8: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EBAEC: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028EBAF0: MOV x23, x1                | X23 = X1;//m1                           
            // 0x028EBAF4: TBNZ w8, #0, #0x28ebb10    | if (static_value_037B8A02 == true) goto label_0;
            // 0x028EBAF8: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x028EBAFC: LDR x8, [x8, #0x320]       | X8 = 0x2B90CD0;                         
            // 0x028EBB00: LDR w0, [x8]               | W0 = 0x19F8;                            
            // 0x028EBB04: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F8, ????);     
            // 0x028EBB08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EBB0C: STRB w8, [x20, #0xa02]     | static_value_037B8A02 = true;            //  dest_result_addr=58427906
            label_0:
            // 0x028EBB10: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x028EBB14: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x028EBB18: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EBB1C: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EBB20: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EBB24: TBNZ w9, #0, #0x28ebb30    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EBB28: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_31 = 8;
            // 0x028EBB2C: B #0x28ebb48               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EBB30: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EBB34: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EBB38: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EBB3C: SUB w25, w0, #0x10         | W25 = (null - 16) = val_31 (0x100000000D137FF0);
            val_31 = 1152921504826228720;
            // 0x028EBB40: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EBB44: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EBB48: TBNZ w9, #0, #0x28ebb54    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EBB4C: ORR w27, wzr, #8           | W27 = 8(0x8);                           
            val_32 = 8;
            // 0x028EBB50: B #0x28ebb60               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EBB54: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EBB58: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EBB5C: SUB w27, w0, #0x10         | W27 = (null - 16) = val_32 (0x100000000D137FF0);
            val_32 = 1152921504826228720;
            label_4:
            // 0x028EBB60: CBNZ x23, #0x28ebb68       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028EBB64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EBB68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBB6C: MOV x0, x23                | X0 = X1;//m1                            
            // 0x028EBB70: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EBB74: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_33 = null;
            // 0x028EBB78: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x028EBB7C: ADD x9, x8, #0x109         | X9 = (val_33 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EBB80: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EBB84: TBNZ w9, #0, #0x28ebb90    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028EBB88: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_35 = 8;
            // 0x028EBB8C: B #0x28ebba8               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028EBB90: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EBB94: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EBB98: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_33 = null;
            // 0x028EBB9C: SUB w10, w0, #0x10         | W10 = (val_33 - 16) = val_35 (0x100000000D137FF0);
            val_35 = 1152921504826228720;
            // 0x028EBBA0: ADD x9, x8, #0x109         | X9 = (val_33 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EBBA4: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_7:
            // 0x028EBBA8: SUB x20, x21, w10, sxtw    | X20 = (X2 - (val_35) << );              
            var val_2 = X2 - (val_35 << );
            // 0x028EBBAC: TBZ w9, #8, #0x28ebbc0     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_9;
            // 0x028EBBB0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EBBB4: CBNZ w9, #0x28ebbc0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x028EBBB8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EBBBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028EBBC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EBBC4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EBBC8: MOV x1, x20                | X1 = (X2 - (val_35) << );//m1           
            // 0x028EBBCC: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028EBBD0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EBBD4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EBBD8: MOV x22, x0                | X22 = val_3;//m1                        
            val_36 = val_3;
            // 0x028EBBDC: CBNZ x23, #0x28ebbe4       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x028EBBE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x028EBBE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EBBE8: MOV x0, x23                | X0 = X1;//m1                            
            // 0x028EBBEC: MOV x1, x20                | X1 = (X2 - (val_35) << );//m1           
            // 0x028EBBF0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EBBF4: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_37 = null;
            // 0x028EBBF8: ADD x9, x8, #0x109         | X9 = (val_37 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EBBFC: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EBC00: TBNZ w9, #0, #0x28ebc0c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_11;
            // 0x028EBC04: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_39 = 8;
            // 0x028EBC08: B #0x28ebc24               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x028EBC0C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EBC10: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EBC14: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_37 = null;
            // 0x028EBC18: SUB w26, w0, #0x10         | W26 = (val_37 - 16) = val_39 (0x100000000D137FF0);
            val_39 = 1152921504826228720;
            // 0x028EBC1C: ADD x9, x8, #0x109         | X9 = (val_37 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EBC20: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_12:
            // 0x028EBC24: SUB x20, x21, w25, sxtw    | X20 = (X2 - (val_31) << );              
            var val_4 = X2 - (val_31 << );
            // 0x028EBC28: TBNZ w9, #0, #0x28ebc34    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_13;
            // 0x028EBC2C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_40 = 8;
            // 0x028EBC30: B #0x28ebc40               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028EBC34: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EBC38: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EBC3C: SUB w8, w0, #0x10          | W8 = (val_37 - 16) = val_40 (0x100000000D137FF0);
            val_40 = 1152921504826228720;
            label_14:
            // 0x028EBC40: SUB x9, x21, w26, sxtw     | X9 = (X2 - (val_39) << );               
            var val_5 = X2 - (val_39 << );
            // 0x028EBC44: SUB x25, x9, w8, sxtw      | X25 = ((X2 - (val_39) << ) - (val_40) << );
            var val_6 = val_5 - (val_40 << );
            // 0x028EBC48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EBC4C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EBC50: MOV x1, x25                | X1 = ((X2 - (val_39) << ) - (val_40) << );//m1
            // 0x028EBC54: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028EBC58: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EBC5C: SUB x20, x20, w27, sxtw    | X20 = ((X2 - (val_31) << ) - (val_32) << );
            val_4 = val_4 - (val_32 << );
            // 0x028EBC60: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EBC64: MOV x21, x0                | X21 = val_7;//m1                        
            val_41 = val_7;
            // 0x028EBC68: CBNZ x23, #0x28ebc70       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028EBC6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_15:
            // 0x028EBC70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_42 = 0;
            // 0x028EBC74: MOV x0, x23                | X0 = X1;//m1                            
            // 0x028EBC78: MOV x1, x25                | X1 = ((X2 - (val_39) << ) - (val_40) << );//m1
            // 0x028EBC7C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EBC80: CBZ x21, #0x28ebdd4        | if (val_7 == null) goto label_16;       
            if(val_41 == null)
            {
                goto label_16;
            }
            // 0x028EBC84: CBZ x22, #0x28ebe00        | if (val_3 == null) goto label_17;       
            if(val_36 == null)
            {
                goto label_17;
            }
            // 0x028EBC88: ADRP x27, #0x3657000       | X27 = 56979456 (0x3657000);             
            // 0x028EBC8C: LDR x27, [x27, #0xa28]     | X27 = 1152921504825589760;              
            // 0x028EBC90: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x028EBC94: LDR x1, [x27]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EBC98: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EBC9C: LDR x1, [x27]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EBCA0: MOV x23, x0                | X23 = val_7;//m1                        
            // 0x028EBCA4: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x028EBCA8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EBCAC: MOV x25, x0                | X25 = val_3;//m1                        
            val_43 = val_36;
            // 0x028EBCB0: CBZ x23, #0x28ebe38        | if (val_7 == null) goto label_18;       
            if(val_41 == null)
            {
                goto label_18;
            }
            // 0x028EBCB4: LDR x23, [x27]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EBCB8: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x028EBCBC: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBCC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EBCC4: CBNZ x0, #0x28ebcf8        | if (val_7 != null) goto label_19;       
            if(val_41 != null)
            {
                goto label_19;
            }
            // 0x028EBCC8: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EBCCC: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBCD0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBCD4: ADD x8, sp, #8             | X8 = (1152921512890011008 + 8) = 1152921512890011016 (0x10000001EDB70D88);
            // 0x028EBCD8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EBCDC: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921512889999200]
            // 0x028EBCE0: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028EBCE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBCE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028EBCEC: ADD x0, sp, #8             | X0 = (1152921512890011008 + 8) = 1152921512890011016 (0x10000001EDB70D88);
            // 0x028EBCF0: BL #0x299a140              | 
            // 0x028EBCF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB70D88, ????);
            label_19:
            // 0x028EBCF8: LDR x23, [x27]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            val_44 = null;
            // 0x028EBCFC: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x028EBD00: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBD04: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EBD08: MOV x24, x0                | X24 = val_7;//m1                        
            val_45 = val_41;
            // 0x028EBD0C: CBNZ x24, #0x28ebd40       | if (val_7 != null) goto label_20;       
            if(val_45 != null)
            {
                goto label_20;
            }
            // 0x028EBD10: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EBD14: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBD18: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBD1C: ADD x8, sp, #0x10          | X8 = (1152921512890011008 + 16) = 1152921512890011024 (0x10000001EDB70D90);
            // 0x028EBD20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EBD24: LDR x0, [sp, #0x10]        | X0 = val_9;                              //  find_add[1152921512889999200]
            // 0x028EBD28: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x028EBD2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBD30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x028EBD34: ADD x0, sp, #0x10          | X0 = (1152921512890011008 + 16) = 1152921512890011024 (0x10000001EDB70D90);
            // 0x028EBD38: BL #0x299a140              | 
            // 0x028EBD3C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_45 = 0;
            label_20:
            // 0x028EBD40: CBZ x25, #0x28ebf20        | if (val_3 == null) goto label_21;       
            if(val_43 == null)
            {
                goto label_21;
            }
            // 0x028EBD44: LDR x26, [x27]             | X26 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EBD48: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x028EBD4C: MOV x1, x26                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBD50: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EBD54: MOV x25, x0                | X25 = val_3;//m1                        
            val_46 = val_36;
            // 0x028EBD58: CBNZ x25, #0x28ebd8c       | if (val_3 != null) goto label_22;       
            if(val_46 != null)
            {
                goto label_22;
            }
            // 0x028EBD5C: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EBD60: MOV x1, x26                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBD64: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBD68: ADD x8, sp, #0x18          | X8 = (1152921512890011008 + 24) = 1152921512890011032 (0x10000001EDB70D98);
            // 0x028EBD6C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EBD70: LDR x0, [sp, #0x18]        | X0 = val_10;                             //  find_add[1152921512889999200]
            // 0x028EBD74: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x028EBD78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBD7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x028EBD80: ADD x0, sp, #0x18          | X0 = (1152921512890011008 + 24) = 1152921512890011032 (0x10000001EDB70D98);
            // 0x028EBD84: BL #0x299a140              | 
            // 0x028EBD88: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_46 = 0;
            label_22:
            // 0x028EBD8C: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EBD90: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EBD94: CBZ x9, #0x28ebdc0         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x028EBD98: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_25 = mem[282584257676823];
            // 0x028EBD9C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_26 = 0;
            // 0x028EBDA0: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_25 = val_25 + 8;
            label_25:
            // 0x028EBDA4: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EBDA8: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EBDAC: B.EQ #0x28ec078            | if ((mem[282584257676823] + 8) + -8 == val_44) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == val_44)
            {
                goto label_24;
            }
            // 0x028EBDB0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_26 = val_26 + 1;
            // 0x028EBDB4: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_25 = val_25 + 16;
            // 0x028EBDB8: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EBDBC: B.LO #0x28ebda4            | if (0 < mem[282584257676929]) goto label_25;
            if(val_26 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x028EBDC0: MOVZ w2, #0xd              | W2 = 13 (0xD);//ML01                    
            val_47 = 13;
            // 0x028EBDC4: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_48 = val_45;
            // 0x028EBDC8: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBDCC: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EBDD0: B #0x28ec088               |  goto label_26;                         
            goto label_26;
            label_16:
            // 0x028EBDD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EBDD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EBDDC: MOV x1, x20                | X1 = ((X2 - (val_31) << ) - (val_32) << );//m1
            // 0x028EBDE0: SUB sp, x29, #0x50         | SP = (1152921512890011184 - 80) = 1152921512890011104 (0x10000001EDB70DE0);
            // 0x028EBDE4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EBDE8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EBDEC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EBDF0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EBDF4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EBDF8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EBDFC: B #0x1f94458               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  esp);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  esp);
            label_17:
            // 0x028EBE00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EBE04: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EBE08: MOV x1, x20                | X1 = ((X2 - (val_31) << ) - (val_32) << );//m1
            // 0x028EBE0C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EBE10: MOV x3, x21                | X3 = val_7;//m1                         
            // 0x028EBE14: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EBE18: SUB sp, x29, #0x50         | SP = (1152921512890011184 - 80) = 1152921512890011104 (0x10000001EDB70DE0);
            // 0x028EBE1C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EBE20: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EBE24: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EBE28: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EBE2C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EBE30: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EBE34: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            label_18:
            // 0x028EBE38: CBZ x25, #0x28ebfc4        | if (val_3 == null) goto label_27;       
            if(val_43 == null)
            {
                goto label_27;
            }
            // 0x028EBE3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBE40: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x028EBE44: BL #0x16fb28c              | X0 = val_7.GetType();                   
            System.Type val_11 = val_41.GetType();
            // 0x028EBE48: LDR x24, [x27]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EBE4C: MOV x23, x0                | X23 = val_11;//m1                       
            val_44 = val_11;
            // 0x028EBE50: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x028EBE54: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBE58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EBE5C: CBNZ x0, #0x28ebe90        | if (val_3 != null) goto label_28;       
            if(val_36 != null)
            {
                goto label_28;
            }
            // 0x028EBE60: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EBE64: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBE68: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBE6C: ADD x8, sp, #0x40          | X8 = (1152921512890011008 + 64) = 1152921512890011072 (0x10000001EDB70DC0);
            // 0x028EBE70: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EBE74: LDR x0, [sp, #0x40]        | X0 = val_12;                             //  find_add[1152921512889999200]
            // 0x028EBE78: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x028EBE7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBE80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x028EBE84: ADD x0, sp, #0x40          | X0 = (1152921512890011008 + 64) = 1152921512890011072 (0x10000001EDB70DC0);
            // 0x028EBE88: BL #0x299a140              | 
            // 0x028EBE8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB70DC0, ????);
            label_28:
            // 0x028EBE90: LDR x24, [x27]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EBE94: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x028EBE98: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBE9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EBEA0: MOV x25, x0                | X25 = val_3;//m1                        
            val_43 = val_36;
            // 0x028EBEA4: CBNZ x25, #0x28ebed8       | if (val_3 != null) goto label_29;       
            if(val_43 != null)
            {
                goto label_29;
            }
            // 0x028EBEA8: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EBEAC: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBEB0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBEB4: ADD x8, sp, #0x48          | X8 = (1152921512890011008 + 72) = 1152921512890011080 (0x10000001EDB70DC8);
            // 0x028EBEB8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EBEBC: LDR x0, [sp, #0x48]        | X0 = val_13;                             //  find_add[1152921512889999200]
            // 0x028EBEC0: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x028EBEC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBEC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x028EBECC: ADD x0, sp, #0x48          | X0 = (1152921512890011008 + 72) = 1152921512890011080 (0x10000001EDB70DC8);
            // 0x028EBED0: BL #0x299a140              | 
            // 0x028EBED4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_43 = 0;
            label_29:
            // 0x028EBED8: LDR x8, [x25]              | X8 = 0x10102464C457F;                   
            // 0x028EBEDC: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EBEE0: CBZ x9, #0x28ebf0c         | if (mem[282584257676929] == 0) goto label_30;
            if(mem[282584257676929] == 0)
            {
                goto label_30;
            }
            // 0x028EBEE4: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_27 = mem[282584257676823];
            // 0x028EBEE8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_28 = 0;
            // 0x028EBEEC: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_27 = val_27 + 8;
            label_32:
            // 0x028EBEF0: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EBEF4: CMP x12, x24               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EBEF8: B.EQ #0x28ec204            | if ((mem[282584257676823] + 8) + -8 == null) goto label_31;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_31;
            }
            // 0x028EBEFC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_28 = val_28 + 1;
            // 0x028EBF00: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_27 = val_27 + 16;
            // 0x028EBF04: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EBF08: B.LO #0x28ebef0            | if (0 < mem[282584257676929]) goto label_32;
            if(val_28 < mem[282584257676929])
            {
                goto label_32;
            }
            label_30:
            // 0x028EBF0C: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            val_49 = 8;
            // 0x028EBF10: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            val_50 = val_43;
            // 0x028EBF14: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBF18: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EBF1C: B #0x28ec214               |  goto label_33;                         
            goto label_33;
            label_21:
            // 0x028EBF20: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028EBF24: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028EBF28: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EBF2C: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028EBF30: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EBF34: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EBF38: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EBF3C: B.LO #0x28ebf54            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_34;
            // 0x028EBF40: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EBF44: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028EBF48: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EBF4C: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EBF50: B.EQ #0x28ebf7c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_35;
            label_34:
            // 0x028EBF54: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBF58: ADD x8, sp, #0x38          | X8 = (1152921512890011008 + 56) = 1152921512890011064 (0x10000001EDB70DB8);
            // 0x028EBF5C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EBF60: LDR x0, [sp, #0x38]        | X0 = val_15;                             //  find_add[1152921512889999200]
            // 0x028EBF64: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x028EBF68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EBF6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x028EBF70: ADD x0, sp, #0x38          | X0 = (1152921512890011008 + 56) = 1152921512890011064 (0x10000001EDB70DB8);
            // 0x028EBF74: BL #0x299a140              | 
            // 0x028EBF78: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_36 = 0;
            label_35:
            // 0x028EBF7C: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            var val_38 = 1179403647;
            // 0x028EBF80: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EBF84: CBZ x9, #0x28ebfb0         | if (mem[282584257676929] == 0) goto label_36;
            if(mem[282584257676929] == 0)
            {
                goto label_36;
            }
            // 0x028EBF88: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_29 = mem[282584257676823];
            // 0x028EBF8C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_30 = 0;
            // 0x028EBF90: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_29 = val_29 + 8;
            label_38:
            // 0x028EBF94: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EBF98: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EBF9C: B.EQ #0x28ec29c            | if ((mem[282584257676823] + 8) + -8 == val_44) goto label_37;
            if(((mem[282584257676823] + 8) + -8) == val_44)
            {
                goto label_37;
            }
            // 0x028EBFA0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_30 = val_30 + 1;
            // 0x028EBFA4: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_29 = val_29 + 16;
            // 0x028EBFA8: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EBFAC: B.LO #0x28ebf94            | if (0 < mem[282584257676929]) goto label_38;
            if(val_30 < mem[282584257676929])
            {
                goto label_38;
            }
            label_36:
            // 0x028EBFB0: ORR w2, wzr, #0xc          | W2 = 12(0xC);                           
            val_51 = 12;
            // 0x028EBFB4: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_52 = val_45;
            // 0x028EBFB8: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EBFBC: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EBFC0: B #0x28ec2ac               |  goto label_39;                         
            goto label_39;
            label_27:
            // 0x028EBFC4: ADRP x23, #0x3639000       | X23 = 56856576 (0x3639000);             
            // 0x028EBFC8: LDR x23, [x23, #0xbe8]     | X23 = 1152921504608870400;              
            val_44 = 1152921504608870400;
            // 0x028EBFCC: LDR x9, [x21]              | X9 = typeof(System.Object);             
            // 0x028EBFD0: LDR x1, [x23]              | X1 = typeof(System.Delegate);           
            val_53 = null;
            // 0x028EBFD4: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EBFD8: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EBFDC: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EBFE0: B.LO #0x28ebff8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_40;
            // 0x028EBFE4: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EBFE8: ADD x10, x10, x8, lsl #3   | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_type
            // 0x028EBFEC: LDUR x10, [x10, #-8]       | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EBFF0: CMP x10, x1                | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EBFF4: B.EQ #0x28ec028            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_53) goto label_41;
            label_40:
            // 0x028EBFF8: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EBFFC: ADD x8, sp, #0x58          | X8 = (1152921512890011008 + 88) = 1152921512890011096 (0x10000001EDB70DD8);
            // 0x028EC000: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC004: LDR x0, [sp, #0x58]        | X0 = val_16;                             //  find_add[1152921512889999200]
            // 0x028EC008: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x028EC00C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC010: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x028EC014: ADD x0, sp, #0x58          | X0 = (1152921512890011008 + 88) = 1152921512890011096 (0x10000001EDB70DD8);
            // 0x028EC018: BL #0x299a140              | 
            // 0x028EC01C: LDR x1, [x23]              | X1 = typeof(System.Delegate);           
            val_53 = null;
            // 0x028EC020: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_41 = 0;
            // 0x028EC024: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            label_41:
            // 0x028EC028: LDR x9, [x22]              | X9 = typeof(System.Object);             
            // 0x028EC02C: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC030: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EC034: B.LO #0x28ec04c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_42;
            // 0x028EC038: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EC03C: ADD x8, x10, w8, uxtw #3   | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHi
            // 0x028EC040: LDUR x8, [x8, #-8]         | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8;
            // 0x028EC044: CMP x8, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8, typeof(System.Delegate))
            // 0x028EC048: B.EQ #0x28ec284            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8 == val_53) goto label_58;
            label_42:
            // 0x028EC04C: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC050: MOV x8, sp                 | X8 = 1152921512890011008 (0x10000001EDB70D80);//ML01
            // 0x028EC054: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC058: LDR x0, [sp]               | X0 = val_17;                             //  find_add[1152921512889999200]
            // 0x028EC05C: BL #0x27af090              | X0 = sub_27AF090( ?? val_17, ????);     
            // 0x028EC060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC064: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            // 0x028EC068: MOV x0, sp                 | X0 = 1152921512890011008 (0x10000001EDB70D80);//ML01
            // 0x028EC06C: BL #0x299a140              | 
            // 0x028EC070: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_55 = 0;
            // 0x028EC074: B #0x28ec284               |  goto label_58;                         
            goto label_58;
            label_24:
            // 0x028EC078: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_31 = val_25;
            // 0x028EC07C: ADD w9, w9, #0xd           | W9 = ((mem[282584257676823] + 8) + 13); 
            val_31 = val_31 + 13;
            // 0x028EC080: ADD x8, x8, w9, uxtw #4    | X8 = (val_45 + ((mem[282584257676823] + 8) + 13));
            val_45 = val_45 + val_31;
            // 0x028EC084: ADD x0, x8, #0x110         | X0 = ((val_45 + ((mem[282584257676823] + 8) + 13)) + 272);
            val_48 = val_45 + 272;
            label_26:
            // 0x028EC088: LDP x8, x2, [x0]           | X8 = ((val_45 + ((mem[282584257676823] + 8) + 13)) + 272); X2 = ((val_45 + ((mem[282584257676823] + 8) + 13)) + 272) + 8; //  | 
            val_56 = mem[((val_45 + ((mem[282584257676823] + 8) + 13)) + 272) + 8];
            val_56 = ((val_45 + ((mem[282584257676823] + 8) + 13)) + 272) + 8;
            // 0x028EC08C: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EC090: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x028EC094: BLR x8                     | X0 = ((val_45 + ((mem[282584257676823] + 8) + 13)) + 272)();
            // 0x028EC098: LDR x23, [x27]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC09C: MOV w25, w0                | W25 = 0 (0x0);//ML01                    
            val_43 = val_45;
            // 0x028EC0A0: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x028EC0A4: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC0A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EC0AC: CBNZ x0, #0x28ec0e0        | if (val_7 != null) goto label_45;       
            if(val_41 != null)
            {
                goto label_45;
            }
            // 0x028EC0B0: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EC0B4: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC0B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC0BC: ADD x8, sp, #0x20          | X8 = (1152921512890011008 + 32) = 1152921512890011040 (0x10000001EDB70DA0);
            // 0x028EC0C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC0C4: LDR x0, [sp, #0x20]        | X0 = val_18;                             //  find_add[1152921512889999200]
            // 0x028EC0C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x028EC0CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC0D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x028EC0D4: ADD x0, sp, #0x20          | X0 = (1152921512890011008 + 32) = 1152921512890011040 (0x10000001EDB70DA0);
            // 0x028EC0D8: BL #0x299a140              | 
            // 0x028EC0DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB70DA0, ????);
            label_45:
            // 0x028EC0E0: LDR x23, [x27]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            val_44 = null;
            // 0x028EC0E4: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x028EC0E8: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_57 = val_44;
            // 0x028EC0EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028EC0F0: MOV x24, x0                | X24 = val_7;//m1                        
            val_58 = val_41;
            // 0x028EC0F4: CBNZ x24, #0x28ec128       | if (val_7 != null) goto label_46;       
            if(val_58 != null)
            {
                goto label_46;
            }
            // 0x028EC0F8: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EC0FC: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC100: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC104: ADD x8, sp, #0x28          | X8 = (1152921512890011008 + 40) = 1152921512890011048 (0x10000001EDB70DA8);
            // 0x028EC108: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC10C: LDR x0, [sp, #0x28]        | X0 = val_19;                             //  find_add[1152921512889999200]
            // 0x028EC110: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x028EC114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_57 = 0;
            // 0x028EC118: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x028EC11C: ADD x0, sp, #0x28          | X0 = (1152921512890011008 + 40) = 1152921512890011048 (0x10000001EDB70DA8);
            // 0x028EC120: BL #0x299a140              | 
            // 0x028EC124: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_58 = 0;
            label_46:
            // 0x028EC128: TBZ w25, #0, #0x28ec174    | if ((0x0 & 0x1) == 0) goto label_47;    
            if((val_43 & 1) == 0)
            {
                goto label_47;
            }
            // 0x028EC12C: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EC130: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EC134: CBZ x9, #0x28ec160         | if (mem[282584257676929] == 0) goto label_48;
            if(mem[282584257676929] == 0)
            {
                goto label_48;
            }
            // 0x028EC138: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_32 = mem[282584257676823];
            // 0x028EC13C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_33 = 0;
            // 0x028EC140: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_32 = val_32 + 8;
            label_50:
            // 0x028EC144: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EC148: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EC14C: B.EQ #0x28ec2bc            | if ((mem[282584257676823] + 8) + -8 == val_44) goto label_49;
            if(((mem[282584257676823] + 8) + -8) == val_44)
            {
                goto label_49;
            }
            // 0x028EC150: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_33 = val_33 + 1;
            // 0x028EC154: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_32 = val_32 + 16;
            // 0x028EC158: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EC15C: B.LO #0x28ec144            | if (0 < mem[282584257676929]) goto label_50;
            if(val_33 < mem[282584257676929])
            {
                goto label_50;
            }
            label_48:
            // 0x028EC160: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028EC164: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_59 = val_58;
            // 0x028EC168: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            val_57 = val_44;
            // 0x028EC16C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EC170: B #0x28ec2cc               |  goto label_51;                         
            goto label_51;
            label_47:
            // 0x028EC174: LDR x26, [x27]             | X26 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC178: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x028EC17C: MOV x1, x26                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC180: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EC184: MOV x25, x0                | X25 = val_3;//m1                        
            val_43 = val_36;
            // 0x028EC188: CBNZ x25, #0x28ec1bc       | if (val_3 != null) goto label_52;       
            if(val_43 != null)
            {
                goto label_52;
            }
            // 0x028EC18C: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028EC190: MOV x1, x26                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC194: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC198: ADD x8, sp, #0x30          | X8 = (1152921512890011008 + 48) = 1152921512890011056 (0x10000001EDB70DB0);
            // 0x028EC19C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC1A0: LDR x0, [sp, #0x30]        | X0 = val_20;                             //  find_add[1152921512889999200]
            // 0x028EC1A4: BL #0x27af090              | X0 = sub_27AF090( ?? val_20, ????);     
            // 0x028EC1A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC1AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            // 0x028EC1B0: ADD x0, sp, #0x30          | X0 = (1152921512890011008 + 48) = 1152921512890011056 (0x10000001EDB70DB0);
            // 0x028EC1B4: BL #0x299a140              | 
            // 0x028EC1B8: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_43 = 0;
            label_52:
            // 0x028EC1BC: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            var val_41 = 1179403647;
            // 0x028EC1C0: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EC1C4: CBZ x9, #0x28ec1f0         | if (mem[282584257676929] == 0) goto label_53;
            if(mem[282584257676929] == 0)
            {
                goto label_53;
            }
            // 0x028EC1C8: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_34 = mem[282584257676823];
            // 0x028EC1CC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_35 = 0;
            // 0x028EC1D0: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_34 = val_34 + 8;
            label_55:
            // 0x028EC1D4: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EC1D8: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EC1DC: B.EQ #0x28ec2f0            | if ((mem[282584257676823] + 8) + -8 == val_44) goto label_54;
            if(((mem[282584257676823] + 8) + -8) == val_44)
            {
                goto label_54;
            }
            // 0x028EC1E0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_35 = val_35 + 1;
            // 0x028EC1E4: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_34 = val_34 + 16;
            // 0x028EC1E8: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EC1EC: B.LO #0x28ec1d4            | if (0 < mem[282584257676929]) goto label_55;
            if(val_35 < mem[282584257676929])
            {
                goto label_55;
            }
            label_53:
            // 0x028EC1F0: MOVZ w2, #0xb              | W2 = 11 (0xB);//ML01                    
            val_56 = 11;
            // 0x028EC1F4: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_60 = val_58;
            // 0x028EC1F8: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC1FC: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EC200: B #0x28ec300               |  goto label_56;                         
            goto label_56;
            label_31:
            // 0x028EC204: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_36 = val_27;
            // 0x028EC208: ADD w9, w9, #8             | W9 = ((mem[282584257676823] + 8) + 8);  
            val_36 = val_36 + 8;
            // 0x028EC20C: ADD x8, x8, w9, uxtw #4    | X8 = (val_43 + ((mem[282584257676823] + 8) + 8));
            val_43 = val_43 + val_36;
            // 0x028EC210: ADD x0, x8, #0x110         | X0 = ((val_43 + ((mem[282584257676823] + 8) + 8)) + 272);
            val_50 = val_43 + 272;
            label_33:
            // 0x028EC214: LDP x8, x2, [x0]           | X8 = ((val_43 + ((mem[282584257676823] + 8) + 8)) + 272); X2 = ((val_43 + ((mem[282584257676823] + 8) + 8)) + 272) + 8; //  | 
            // 0x028EC218: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x028EC21C: MOV x1, x23                | X1 = val_11;//m1                        
            // 0x028EC220: BLR x8                     | X0 = ((val_43 + ((mem[282584257676823] + 8) + 8)) + 272)();
            // 0x028EC224: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028EC228: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028EC22C: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EC230: MOV x22, x0                | X22 = 0 (0x0);//ML01                    
            val_55 = val_43;
            // 0x028EC234: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028EC238: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC23C: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC240: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EC244: B.LO #0x28ec25c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_57;
            // 0x028EC248: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EC24C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028EC250: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EC254: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EC258: B.EQ #0x28ec284            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_58;
            label_57:
            // 0x028EC25C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC260: ADD x8, sp, #0x50          | X8 = (1152921512890011008 + 80) = 1152921512890011088 (0x10000001EDB70DD0);
            // 0x028EC264: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC268: LDR x0, [sp, #0x50]        | X0 = val_22;                             //  find_add[1152921512889999200]
            // 0x028EC26C: BL #0x27af090              | X0 = sub_27AF090( ?? val_22, ????);     
            // 0x028EC270: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC274: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            // 0x028EC278: ADD x0, sp, #0x50          | X0 = (1152921512890011008 + 80) = 1152921512890011088 (0x10000001EDB70DD0);
            // 0x028EC27C: BL #0x299a140              | 
            // 0x028EC280: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_41 = 0;
            label_58:
            // 0x028EC284: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EC288: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EC28C: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028EC290: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            // 0x028EC294: BL #0x1c34dc4              | X0 = System.Delegate.Remove(source:  0, value:  val_41);
            System.Delegate val_23 = System.Delegate.Remove(source:  0, value:  val_41);
            // 0x028EC298: B #0x28ec2d8               |  goto label_59;                         
            goto label_59;
            label_37:
            // 0x028EC29C: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_37 = val_29;
            // 0x028EC2A0: ADD w9, w9, #0xc           | W9 = ((mem[282584257676823] + 8) + 12); 
            val_37 = val_37 + 12;
            // 0x028EC2A4: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 12));
            val_38 = val_38 + val_37;
            // 0x028EC2A8: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 12)) + 272);
            val_52 = val_38 + 272;
            label_39:
            // 0x028EC2AC: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 12)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 12)) + 272) + 8; //  | 
            // 0x028EC2B0: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EC2B4: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x028EC2B8: B #0x28ec30c               |  goto label_60;                         
            goto label_60;
            label_49:
            // 0x028EC2BC: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_39 = val_32;
            // 0x028EC2C0: ADD w9, w9, #1             | W9 = ((mem[282584257676823] + 8) + 1);  
            val_39 = val_39 + 1;
            // 0x028EC2C4: ADD x8, x8, w9, uxtw #4    | X8 = (val_58 + ((mem[282584257676823] + 8) + 1));
            val_58 = val_58 + val_39;
            // 0x028EC2C8: ADD x0, x8, #0x110         | X0 = ((val_58 + ((mem[282584257676823] + 8) + 1)) + 272);
            val_59 = val_58 + 272;
            label_51:
            // 0x028EC2CC: LDP x8, x1, [x0]           | X8 = ((val_58 + ((mem[282584257676823] + 8) + 1)) + 272); X1 = ((val_58 + ((mem[282584257676823] + 8) + 1)) + 272) + 8; //  | 
            // 0x028EC2D0: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_61 = val_58;
            // 0x028EC2D4: BLR x8                     | X0 = ((val_58 + ((mem[282584257676823] + 8) + 1)) + 272)();
            label_59:
            // 0x028EC2D8: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x028EC2DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EC2E0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EC2E4: MOV x1, x20                | X1 = ((X2 - (val_31) << ) - (val_32) << );//m1
            // 0x028EC2E8: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EC2EC: B #0x28ec324               |  goto label_61;                         
            goto label_61;
            label_54:
            // 0x028EC2F0: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_40 = val_34;
            // 0x028EC2F4: ADD w9, w9, #0xb           | W9 = ((mem[282584257676823] + 8) + 11); 
            val_40 = val_40 + 11;
            // 0x028EC2F8: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 11));
            val_41 = val_41 + val_40;
            // 0x028EC2FC: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 11)) + 272);
            val_60 = val_41 + 272;
            label_56:
            // 0x028EC300: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 11)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 11)) + 272) + 8; //  | 
            // 0x028EC304: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EC308: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            label_60:
            // 0x028EC30C: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 11)) + 272)();
            // 0x028EC310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EC314: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EC318: MOV x1, x20                | X1 = ((X2 - (val_31) << ) - (val_32) << );//m1
            // 0x028EC31C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EC320: MOV x3, x21                | X3 = val_7;//m1                         
            label_61:
            // 0x028EC324: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EC328: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_24 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028EC32C: SUB sp, x29, #0x50         | SP = (1152921512890011184 - 80) = 1152921512890011104 (0x10000001EDB70DE0);
            // 0x028EC330: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EC334: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EC338: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EC33C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EC340: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EC344: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EC348: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_24;
            return val_24;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028EC3E4 (42910692), len: 1780  VirtAddr: 0x028EC3E4 RVA: 0x028EC3E4 token: 100680275 methodIndex: 29563 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* DelegateEqulity(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_18;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            System.Delegate val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            System.Delegate val_49;
            //  | 
            var val_50;
            // 0x028EC3E4: STP x28, x27, [sp, #-0x60]! | stack[1152921512890184544] = ???;  stack[1152921512890184552] = ???;  //  dest_result_addr=1152921512890184544 |  dest_result_addr=1152921512890184552
            // 0x028EC3E8: STP x26, x25, [sp, #0x10]  | stack[1152921512890184560] = ???;  stack[1152921512890184568] = ???;  //  dest_result_addr=1152921512890184560 |  dest_result_addr=1152921512890184568
            // 0x028EC3EC: STP x24, x23, [sp, #0x20]  | stack[1152921512890184576] = ???;  stack[1152921512890184584] = ???;  //  dest_result_addr=1152921512890184576 |  dest_result_addr=1152921512890184584
            // 0x028EC3F0: STP x22, x21, [sp, #0x30]  | stack[1152921512890184592] = ???;  stack[1152921512890184600] = ???;  //  dest_result_addr=1152921512890184592 |  dest_result_addr=1152921512890184600
            // 0x028EC3F4: STP x20, x19, [sp, #0x40]  | stack[1152921512890184608] = ???;  stack[1152921512890184616] = ???;  //  dest_result_addr=1152921512890184608 |  dest_result_addr=1152921512890184616
            // 0x028EC3F8: STP x29, x30, [sp, #0x50]  | stack[1152921512890184624] = ???;  stack[1152921512890184632] = ???;  //  dest_result_addr=1152921512890184624 |  dest_result_addr=1152921512890184632
            // 0x028EC3FC: ADD x29, sp, #0x50         | X29 = (1152921512890184544 + 80) = 1152921512890184624 (0x10000001EDB9B3B0);
            // 0x028EC400: SUB sp, sp, #0x50          | SP = (1152921512890184544 - 80) = 1152921512890184464 (0x10000001EDB9B310);
            // 0x028EC404: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028EC408: LDRB w8, [x19, #0xa03]     | W8 = (bool)static_value_037B8A03;       
            // 0x028EC40C: MOV x21, x3                | X21 = X3;//m1                           
            // 0x028EC410: MOV x23, x2                | X23 = X2;//m1                           
            // 0x028EC414: MOV x22, x1                | X22 = X1;//m1                           
            // 0x028EC418: TBNZ w8, #0, #0x28ec434    | if (static_value_037B8A03 == true) goto label_0;
            // 0x028EC41C: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x028EC420: LDR x8, [x8, #0x2c0]       | X8 = 0x2B90CC8;                         
            // 0x028EC424: LDR w0, [x8]               | W0 = 0x19F6;                            
            // 0x028EC428: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F6, ????);     
            // 0x028EC42C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EC430: STRB w8, [x19, #0xa03]     | static_value_037B8A03 = true;            //  dest_result_addr=58427907
            label_0:
            // 0x028EC434: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x028EC438: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x028EC43C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EC440: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EC444: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EC448: TBNZ w9, #0, #0x28ec454    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EC44C: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_26 = 8;
            // 0x028EC450: B #0x28ec46c               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EC454: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EC458: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EC45C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EC460: SUB w25, w0, #0x10         | W25 = (null - 16) = val_26 (0x100000000D137FF0);
            val_26 = 1152921504826228720;
            // 0x028EC464: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EC468: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EC46C: TBNZ w9, #0, #0x28ec478    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EC470: ORR w27, wzr, #8           | W27 = 8(0x8);                           
            val_27 = 8;
            // 0x028EC474: B #0x28ec484               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EC478: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EC47C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EC480: SUB w27, w0, #0x10         | W27 = (null - 16) = val_27 (0x100000000D137FF0);
            val_27 = 1152921504826228720;
            label_4:
            // 0x028EC484: CBNZ x22, #0x28ec48c       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028EC488: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EC48C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC490: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EC494: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EC498: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_28 = null;
            // 0x028EC49C: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x028EC4A0: ADD x9, x8, #0x109         | X9 = (val_28 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EC4A4: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EC4A8: TBNZ w9, #0, #0x28ec4b4    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028EC4AC: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_30 = 8;
            // 0x028EC4B0: B #0x28ec4cc               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028EC4B4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EC4B8: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EC4BC: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_28 = null;
            // 0x028EC4C0: SUB w10, w0, #0x10         | W10 = (val_28 - 16) = val_30 (0x100000000D137FF0);
            val_30 = 1152921504826228720;
            // 0x028EC4C4: ADD x9, x8, #0x109         | X9 = (val_28 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EC4C8: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_7:
            // 0x028EC4CC: SUB x19, x23, w10, sxtw    | X19 = (X2 - (val_30) << );              
            var val_2 = X2 - (val_30 << );
            // 0x028EC4D0: TBZ w9, #8, #0x28ec4e4     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_9;
            // 0x028EC4D4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EC4D8: CBNZ w9, #0x28ec4e4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x028EC4DC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EC4E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028EC4E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EC4E8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EC4EC: MOV x1, x19                | X1 = (X2 - (val_30) << );//m1           
            // 0x028EC4F0: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028EC4F4: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028EC4F8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EC4FC: MOV x20, x0                | X20 = val_3;//m1                        
            val_31 = val_3;
            // 0x028EC500: CBNZ x22, #0x28ec508       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x028EC504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x028EC508: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EC50C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EC510: MOV x1, x19                | X1 = (X2 - (val_30) << );//m1           
            // 0x028EC514: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EC518: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_32 = null;
            // 0x028EC51C: ADD x9, x8, #0x109         | X9 = (val_32 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EC520: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EC524: TBNZ w9, #0, #0x28ec530    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_11;
            // 0x028EC528: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_34 = 8;
            // 0x028EC52C: B #0x28ec548               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x028EC530: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EC534: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EC538: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_32 = null;
            // 0x028EC53C: SUB w26, w0, #0x10         | W26 = (val_32 - 16) = val_34 (0x100000000D137FF0);
            val_34 = 1152921504826228720;
            // 0x028EC540: ADD x9, x8, #0x109         | X9 = (val_32 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EC544: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_12:
            // 0x028EC548: SUB x19, x23, w25, sxtw    | X19 = (X2 - (val_26) << );              
            var val_4 = X2 - (val_26 << );
            // 0x028EC54C: TBNZ w9, #0, #0x28ec558    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_13;
            // 0x028EC550: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_35 = 8;
            // 0x028EC554: B #0x28ec564               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028EC558: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EC55C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EC560: SUB w8, w0, #0x10          | W8 = (val_32 - 16) = val_35 (0x100000000D137FF0);
            val_35 = 1152921504826228720;
            label_14:
            // 0x028EC564: SUB x9, x23, w26, sxtw     | X9 = (X2 - (val_34) << );               
            var val_5 = X2 - (val_34 << );
            // 0x028EC568: SUB x23, x9, w8, sxtw      | X23 = ((X2 - (val_34) << ) - (val_35) << );
            val_36 = val_5 - (val_35 << );
            // 0x028EC56C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EC570: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EC574: MOV x1, x23                | X1 = ((X2 - (val_34) << ) - (val_35) << );//m1
            // 0x028EC578: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028EC57C: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028EC580: SUB x19, x19, w27, sxtw    | X19 = ((X2 - (val_26) << ) - (val_27) << );
            val_4 = val_4 - (val_27 << );
            // 0x028EC584: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EC588: MOV x21, x0                | X21 = val_6;//m1                        
            val_37 = val_6;
            // 0x028EC58C: CBNZ x22, #0x28ec594       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028EC590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x028EC594: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_38 = 0;
            // 0x028EC598: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EC59C: MOV x1, x23                | X1 = ((X2 - (val_34) << ) - (val_35) << );//m1
            // 0x028EC5A0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EC5A4: CBZ x21, #0x28ec6f8        | if (val_6 == null) goto label_16;       
            if(val_37 == null)
            {
                goto label_16;
            }
            // 0x028EC5A8: CBZ x20, #0x28eca34        | if (val_3 == null) goto label_51;       
            if(val_31 == null)
            {
                goto label_51;
            }
            // 0x028EC5AC: ADRP x25, #0x3657000       | X25 = 56979456 (0x3657000);             
            // 0x028EC5B0: LDR x25, [x25, #0xa28]     | X25 = 1152921504825589760;              
            val_26 = 1152921504825589760;
            // 0x028EC5B4: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028EC5B8: LDR x1, [x25]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC5BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028EC5C0: LDR x1, [x25]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC5C4: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x028EC5C8: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028EC5CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EC5D0: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x028EC5D4: CBZ x22, #0x28ec700        | if (val_6 == null) goto label_18;       
            if(val_37 == null)
            {
                goto label_18;
            }
            // 0x028EC5D8: LDR x22, [x25]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC5DC: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028EC5E0: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC5E4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028EC5E8: CBNZ x0, #0x28ec61c        | if (val_6 != null) goto label_19;       
            if(val_37 != null)
            {
                goto label_19;
            }
            // 0x028EC5EC: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EC5F0: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC5F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC5F8: ADD x8, sp, #0x10          | X8 = (1152921512890184464 + 16) = 1152921512890184480 (0x10000001EDB9B320);
            // 0x028EC5FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC600: LDR x0, [sp, #0x10]        | X0 = val_7;                              //  find_add[1152921512890172640]
            // 0x028EC604: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x028EC608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC60C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x028EC610: ADD x0, sp, #0x10          | X0 = (1152921512890184464 + 16) = 1152921512890184480 (0x10000001EDB9B320);
            // 0x028EC614: BL #0x299a140              | 
            // 0x028EC618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB9B320, ????);
            label_19:
            // 0x028EC61C: LDR x22, [x25]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC620: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028EC624: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC628: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028EC62C: MOV x23, x0                | X23 = val_6;//m1                        
            val_36 = val_37;
            // 0x028EC630: CBNZ x23, #0x28ec664       | if (val_6 != null) goto label_20;       
            if(val_36 != null)
            {
                goto label_20;
            }
            // 0x028EC634: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EC638: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC63C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC640: ADD x8, sp, #0x18          | X8 = (1152921512890184464 + 24) = 1152921512890184488 (0x10000001EDB9B328);
            // 0x028EC644: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC648: LDR x0, [sp, #0x18]        | X0 = val_8;                              //  find_add[1152921512890172640]
            // 0x028EC64C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028EC650: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC654: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028EC658: ADD x0, sp, #0x18          | X0 = (1152921512890184464 + 24) = 1152921512890184488 (0x10000001EDB9B328);
            // 0x028EC65C: BL #0x299a140              | 
            // 0x028EC660: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_36 = 0;
            label_20:
            // 0x028EC664: CBZ x24, #0x28ec7e8        | if (val_3 == null) goto label_21;       
            if(val_31 == null)
            {
                goto label_21;
            }
            // 0x028EC668: LDR x24, [x25]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC66C: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028EC670: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC674: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EC678: MOV x21, x0                | X21 = val_3;//m1                        
            val_37 = val_31;
            // 0x028EC67C: CBNZ x21, #0x28ec6b0       | if (val_3 != null) goto label_22;       
            if(val_37 != null)
            {
                goto label_22;
            }
            // 0x028EC680: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EC684: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC688: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC68C: ADD x8, sp, #0x20          | X8 = (1152921512890184464 + 32) = 1152921512890184496 (0x10000001EDB9B330);
            // 0x028EC690: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC694: LDR x0, [sp, #0x20]        | X0 = val_9;                              //  find_add[1152921512890172640]
            // 0x028EC698: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x028EC69C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC6A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x028EC6A4: ADD x0, sp, #0x20          | X0 = (1152921512890184464 + 32) = 1152921512890184496 (0x10000001EDB9B330);
            // 0x028EC6A8: BL #0x299a140              | 
            // 0x028EC6AC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_37 = 0;
            label_22:
            // 0x028EC6B0: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EC6B4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EC6B8: CBZ x9, #0x28ec6e4         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x028EC6BC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_23 = mem[282584257676823];
            // 0x028EC6C0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_24 = 0;
            // 0x028EC6C4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_23 = val_23 + 8;
            label_25:
            // 0x028EC6C8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EC6CC: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EC6D0: B.EQ #0x28ec940            | if ((mem[282584257676823] + 8) + -8 == null) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_24;
            }
            // 0x028EC6D4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_24 = val_24 + 1;
            // 0x028EC6D8: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_23 = val_23 + 16;
            // 0x028EC6DC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EC6E0: B.LO #0x28ec6c8            | if (0 < mem[282584257676929]) goto label_25;
            if(val_24 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x028EC6E4: MOVZ w2, #0xd              | W2 = 13 (0xD);//ML01                    
            val_39 = 13;
            // 0x028EC6E8: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_40 = val_36;
            // 0x028EC6EC: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC6F0: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EC6F4: B #0x28ec950               |  goto label_26;                         
            goto label_26;
            label_16:
            // 0x028EC6F8: CBNZ x20, #0x28eca34       | if (val_3 != null) goto label_51;       
            if(val_31 != null)
            {
                goto label_51;
            }
            // 0x028EC6FC: B #0x28eca20               |  goto label_28;                         
            goto label_28;
            label_18:
            // 0x028EC700: CBZ x24, #0x28ec88c        | if (val_3 == null) goto label_29;       
            if(val_31 == null)
            {
                goto label_29;
            }
            // 0x028EC704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC708: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028EC70C: BL #0x16fb28c              | X0 = val_6.GetType();                   
            System.Type val_10 = val_37.GetType();
            // 0x028EC710: LDR x23, [x25]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028EC714: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x028EC718: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028EC71C: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC720: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EC724: CBNZ x0, #0x28ec758        | if (val_3 != null) goto label_30;       
            if(val_31 != null)
            {
                goto label_30;
            }
            // 0x028EC728: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EC72C: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC730: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC734: ADD x8, sp, #0x30          | X8 = (1152921512890184464 + 48) = 1152921512890184512 (0x10000001EDB9B340);
            // 0x028EC738: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC73C: LDR x0, [sp, #0x30]        | X0 = val_11;                             //  find_add[1152921512890172640]
            // 0x028EC740: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x028EC744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC748: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x028EC74C: ADD x0, sp, #0x30          | X0 = (1152921512890184464 + 48) = 1152921512890184512 (0x10000001EDB9B340);
            // 0x028EC750: BL #0x299a140              | 
            // 0x028EC754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDB9B340, ????);
            label_30:
            // 0x028EC758: LDR x23, [x25]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            val_36 = null;
            // 0x028EC75C: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028EC760: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC764: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028EC768: MOV x24, x0                | X24 = val_3;//m1                        
            val_41 = val_31;
            // 0x028EC76C: CBNZ x24, #0x28ec7a0       | if (val_3 != null) goto label_31;       
            if(val_41 != null)
            {
                goto label_31;
            }
            // 0x028EC770: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EC774: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC778: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC77C: ADD x8, sp, #0x38          | X8 = (1152921512890184464 + 56) = 1152921512890184520 (0x10000001EDB9B348);
            // 0x028EC780: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC784: LDR x0, [sp, #0x38]        | X0 = val_12;                             //  find_add[1152921512890172640]
            // 0x028EC788: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x028EC78C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC790: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x028EC794: ADD x0, sp, #0x38          | X0 = (1152921512890184464 + 56) = 1152921512890184520 (0x10000001EDB9B348);
            // 0x028EC798: BL #0x299a140              | 
            // 0x028EC79C: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_41 = 0;
            label_31:
            // 0x028EC7A0: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028EC7A4: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EC7A8: CBZ x9, #0x28ec7d4         | if (mem[282584257676929] == 0) goto label_32;
            if(mem[282584257676929] == 0)
            {
                goto label_32;
            }
            // 0x028EC7AC: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_25 = mem[282584257676823];
            // 0x028EC7B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_26 = 0;
            // 0x028EC7B4: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_25 = val_25 + 8;
            label_34:
            // 0x028EC7B8: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EC7BC: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EC7C0: B.EQ #0x28ec960            | if ((mem[282584257676823] + 8) + -8 == val_36) goto label_33;
            if(((mem[282584257676823] + 8) + -8) == val_36)
            {
                goto label_33;
            }
            // 0x028EC7C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_26 = val_26 + 1;
            // 0x028EC7C8: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_25 = val_25 + 16;
            // 0x028EC7CC: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EC7D0: B.LO #0x28ec7b8            | if (0 < mem[282584257676929]) goto label_34;
            if(val_26 < mem[282584257676929])
            {
                goto label_34;
            }
            label_32:
            // 0x028EC7D4: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            val_42 = 8;
            // 0x028EC7D8: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_43 = val_41;
            // 0x028EC7DC: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC7E0: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EC7E4: B #0x28ec970               |  goto label_35;                         
            goto label_35;
            label_21:
            // 0x028EC7E8: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028EC7EC: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028EC7F0: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EC7F4: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028EC7F8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC7FC: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC800: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EC804: B.LO #0x28ec81c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_36;
            // 0x028EC808: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EC80C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028EC810: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EC814: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EC818: B.EQ #0x28ec844            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_37;
            label_36:
            // 0x028EC81C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC820: ADD x8, sp, #0x28          | X8 = (1152921512890184464 + 40) = 1152921512890184504 (0x10000001EDB9B338);
            // 0x028EC824: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC828: LDR x0, [sp, #0x28]        | X0 = val_14;                             //  find_add[1152921512890172640]
            // 0x028EC82C: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028EC830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC834: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028EC838: ADD x0, sp, #0x28          | X0 = (1152921512890184464 + 40) = 1152921512890184504 (0x10000001EDB9B338);
            // 0x028EC83C: BL #0x299a140              | 
            // 0x028EC840: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_31 = 0;
            label_37:
            // 0x028EC844: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            var val_32 = 1179403647;
            // 0x028EC848: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EC84C: CBZ x9, #0x28ec878         | if (mem[282584257676929] == 0) goto label_38;
            if(mem[282584257676929] == 0)
            {
                goto label_38;
            }
            // 0x028EC850: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_27 = mem[282584257676823];
            // 0x028EC854: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_28 = 0;
            // 0x028EC858: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_27 = val_27 + 8;
            label_40:
            // 0x028EC85C: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EC860: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028EC864: B.EQ #0x28ec9f8            | if ((mem[282584257676823] + 8) + -8 == null) goto label_39;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_39;
            }
            // 0x028EC868: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_28 = val_28 + 1;
            // 0x028EC86C: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_27 = val_27 + 16;
            // 0x028EC870: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EC874: B.LO #0x28ec85c            | if (0 < mem[282584257676929]) goto label_40;
            if(val_28 < mem[282584257676929])
            {
                goto label_40;
            }
            label_38:
            // 0x028EC878: ORR w2, wzr, #0xe          | W2 = 14(0xE);                           
            val_44 = 14;
            // 0x028EC87C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_45 = val_36;
            // 0x028EC880: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028EC884: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EC888: B #0x28eca08               |  goto label_41;                         
            goto label_41;
            label_29:
            // 0x028EC88C: ADRP x22, #0x3639000       | X22 = 56856576 (0x3639000);             
            // 0x028EC890: LDR x22, [x22, #0xbe8]     | X22 = 1152921504608870400;              
            // 0x028EC894: LDR x9, [x21]              | X9 = typeof(System.Object);             
            // 0x028EC898: LDR x1, [x22]              | X1 = typeof(System.Delegate);           
            val_46 = null;
            // 0x028EC89C: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC8A0: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC8A4: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EC8A8: B.LO #0x28ec8c0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_42;
            // 0x028EC8AC: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EC8B0: ADD x10, x10, x8, lsl #3   | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_type
            // 0x028EC8B4: LDUR x10, [x10, #-8]       | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EC8B8: CMP x10, x1                | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EC8BC: B.EQ #0x28ec8f0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_46) goto label_43;
            label_42:
            // 0x028EC8C0: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC8C4: ADD x8, sp, #0x48          | X8 = (1152921512890184464 + 72) = 1152921512890184536 (0x10000001EDB9B358);
            // 0x028EC8C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC8CC: LDR x0, [sp, #0x48]        | X0 = val_15;                             //  find_add[1152921512890172640]
            // 0x028EC8D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x028EC8D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC8D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x028EC8DC: ADD x0, sp, #0x48          | X0 = (1152921512890184464 + 72) = 1152921512890184536 (0x10000001EDB9B358);
            // 0x028EC8E0: BL #0x299a140              | 
            // 0x028EC8E4: LDR x1, [x22]              | X1 = typeof(System.Delegate);           
            val_46 = null;
            // 0x028EC8E8: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_37 = 0;
            // 0x028EC8EC: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            label_43:
            // 0x028EC8F0: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x028EC8F4: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC8F8: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EC8FC: B.LO #0x28ec914            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_44;
            // 0x028EC900: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EC904: ADD x8, x10, w8, uxtw #3   | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHi
            // 0x028EC908: LDUR x8, [x8, #-8]         | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8;
            // 0x028EC90C: CMP x8, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8, typeof(System.Delegate))
            // 0x028EC910: B.EQ #0x28ec9e0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8 == val_46) goto label_49;
            label_44:
            // 0x028EC914: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC918: ADD x8, sp, #8             | X8 = (1152921512890184464 + 8) = 1152921512890184472 (0x10000001EDB9B318);
            // 0x028EC91C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC920: LDR x0, [sp, #8]           | X0 = val_16;                             //  find_add[1152921512890172640]
            // 0x028EC924: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x028EC928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC92C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x028EC930: ADD x0, sp, #8             | X0 = (1152921512890184464 + 8) = 1152921512890184472 (0x10000001EDB9B318);
            // 0x028EC934: BL #0x299a140              | 
            // 0x028EC938: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x028EC93C: B #0x28ec9e0               |  goto label_49;                         
            goto label_49;
            label_24:
            // 0x028EC940: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_29 = val_23;
            // 0x028EC944: ADD w9, w9, #0xd           | W9 = ((mem[282584257676823] + 8) + 13); 
            val_29 = val_29 + 13;
            // 0x028EC948: ADD x8, x8, w9, uxtw #4    | X8 = (val_36 + ((mem[282584257676823] + 8) + 13));
            val_36 = val_36 + val_29;
            // 0x028EC94C: ADD x0, x8, #0x110         | X0 = ((val_36 + ((mem[282584257676823] + 8) + 13)) + 272);
            val_40 = val_36 + 272;
            label_26:
            // 0x028EC950: LDP x8, x2, [x0]           | X8 = ((val_36 + ((mem[282584257676823] + 8) + 13)) + 272); X2 = ((val_36 + ((mem[282584257676823] + 8) + 13)) + 272) + 8; //  | 
            // 0x028EC954: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_49 = val_36;
            // 0x028EC958: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028EC95C: B #0x28eca14               |  goto label_47;                         
            goto label_47;
            label_33:
            // 0x028EC960: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_30 = val_25;
            // 0x028EC964: ADD w9, w9, #8             | W9 = ((mem[282584257676823] + 8) + 8);  
            val_30 = val_30 + 8;
            // 0x028EC968: ADD x8, x8, w9, uxtw #4    | X8 = (val_41 + ((mem[282584257676823] + 8) + 8));
            val_41 = val_41 + val_30;
            // 0x028EC96C: ADD x0, x8, #0x110         | X0 = ((val_41 + ((mem[282584257676823] + 8) + 8)) + 272);
            val_43 = val_41 + 272;
            label_35:
            // 0x028EC970: LDP x8, x2, [x0]           | X8 = ((val_41 + ((mem[282584257676823] + 8) + 8)) + 272); X2 = ((val_41 + ((mem[282584257676823] + 8) + 8)) + 272) + 8; //  | 
            // 0x028EC974: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028EC978: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x028EC97C: BLR x8                     | X0 = ((val_41 + ((mem[282584257676823] + 8) + 8)) + 272)();
            // 0x028EC980: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028EC984: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028EC988: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EC98C: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            val_48 = val_41;
            // 0x028EC990: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028EC994: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC998: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EC99C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EC9A0: B.LO #0x28ec9b8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_48;
            // 0x028EC9A4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EC9A8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028EC9AC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EC9B0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028EC9B4: B.EQ #0x28ec9e0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_49;
            label_48:
            // 0x028EC9B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EC9BC: ADD x8, sp, #0x40          | X8 = (1152921512890184464 + 64) = 1152921512890184528 (0x10000001EDB9B350);
            // 0x028EC9C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EC9C4: LDR x0, [sp, #0x40]        | X0 = val_18;                             //  find_add[1152921512890172640]
            // 0x028EC9C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x028EC9CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EC9D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x028EC9D4: ADD x0, sp, #0x40          | X0 = (1152921512890184464 + 64) = 1152921512890184528 (0x10000001EDB9B350);
            // 0x028EC9D8: BL #0x299a140              | 
            // 0x028EC9DC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_37 = 0;
            label_49:
            // 0x028EC9E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_49 = 0;
            // 0x028EC9E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EC9E8: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028EC9EC: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x028EC9F0: BL #0x1c34e18              | X0 = System.Delegate.op_Equality(d1:  val_49 = 0, d2:  val_37);
            bool val_19 = System.Delegate.op_Equality(d1:  val_49, d2:  val_37);
            // 0x028EC9F4: B #0x28eca18               |  goto label_50;                         
            goto label_50;
            label_39:
            // 0x028EC9F8: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_31 = val_27;
            // 0x028EC9FC: ADD w9, w9, #0xe           | W9 = ((mem[282584257676823] + 8) + 14); 
            val_31 = val_31 + 14;
            // 0x028ECA00: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 14));
            val_32 = val_32 + val_31;
            // 0x028ECA04: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272);
            val_45 = val_32 + 272;
            label_41:
            // 0x028ECA08: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272) + 8; //  | 
            // 0x028ECA0C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_49 = val_36;
            // 0x028ECA10: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            label_47:
            // 0x028ECA14: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272)();
            label_50:
            // 0x028ECA18: AND w8, w0, #1             | W8 = (val_49 & 1);                      
            var val_20 = val_49 & 1;
            // 0x028ECA1C: TBZ w8, #0, #0x28eca34     | if (((val_49 & 1) & 0x1) == 0) goto label_51;
            if((val_20 & 1) == 0)
            {
                goto label_51;
            }
            label_28:
            // 0x028ECA20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ECA24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ECA28: MOV x1, x19                | X1 = ((X2 - (val_26) << ) - (val_27) << );//m1
            // 0x028ECA2C: BL #0x1f96c74              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushOne(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_21 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushOne(esp:  null);
            // 0x028ECA30: B #0x28eca44               |  goto label_52;                         
            goto label_52;
            label_51:
            // 0x028ECA34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ECA38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ECA3C: MOV x1, x19                | X1 = ((X2 - (val_26) << ) - (val_27) << );//m1
            // 0x028ECA40: BL #0x1f96cf0              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_22 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  null);
            label_52:
            // 0x028ECA44: SUB sp, x29, #0x50         | SP = (1152921512890184624 - 80) = 1152921512890184544 (0x10000001EDB9B360);
            // 0x028ECA48: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028ECA4C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028ECA50: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028ECA54: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028ECA58: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028ECA5C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028ECA60: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_22;
            return val_22;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028ECAD8 (42912472), len: 1788  VirtAddr: 0x028ECAD8 RVA: 0x028ECAD8 token: 100680276 methodIndex: 29564 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* DelegateInequlity(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_18;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            System.Delegate val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            // 0x028ECAD8: STP x28, x27, [sp, #-0x60]! | stack[1152921512890353888] = ???;  stack[1152921512890353896] = ???;  //  dest_result_addr=1152921512890353888 |  dest_result_addr=1152921512890353896
            // 0x028ECADC: STP x26, x25, [sp, #0x10]  | stack[1152921512890353904] = ???;  stack[1152921512890353912] = ???;  //  dest_result_addr=1152921512890353904 |  dest_result_addr=1152921512890353912
            // 0x028ECAE0: STP x24, x23, [sp, #0x20]  | stack[1152921512890353920] = ???;  stack[1152921512890353928] = ???;  //  dest_result_addr=1152921512890353920 |  dest_result_addr=1152921512890353928
            // 0x028ECAE4: STP x22, x21, [sp, #0x30]  | stack[1152921512890353936] = ???;  stack[1152921512890353944] = ???;  //  dest_result_addr=1152921512890353936 |  dest_result_addr=1152921512890353944
            // 0x028ECAE8: STP x20, x19, [sp, #0x40]  | stack[1152921512890353952] = ???;  stack[1152921512890353960] = ???;  //  dest_result_addr=1152921512890353952 |  dest_result_addr=1152921512890353960
            // 0x028ECAEC: STP x29, x30, [sp, #0x50]  | stack[1152921512890353968] = ???;  stack[1152921512890353976] = ???;  //  dest_result_addr=1152921512890353968 |  dest_result_addr=1152921512890353976
            // 0x028ECAF0: ADD x29, sp, #0x50         | X29 = (1152921512890353888 + 80) = 1152921512890353968 (0x10000001EDBC4930);
            // 0x028ECAF4: SUB sp, sp, #0x50          | SP = (1152921512890353888 - 80) = 1152921512890353808 (0x10000001EDBC4890);
            // 0x028ECAF8: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028ECAFC: LDRB w8, [x19, #0xa04]     | W8 = (bool)static_value_037B8A04;       
            // 0x028ECB00: MOV x21, x3                | X21 = X3;//m1                           
            // 0x028ECB04: MOV x23, x2                | X23 = X2;//m1                           
            // 0x028ECB08: MOV x22, x1                | X22 = X1;//m1                           
            // 0x028ECB0C: TBNZ w8, #0, #0x28ecb28    | if (static_value_037B8A04 == true) goto label_0;
            // 0x028ECB10: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x028ECB14: LDR x8, [x8, #0xb98]       | X8 = 0x2B90CCC;                         
            // 0x028ECB18: LDR w0, [x8]               | W0 = 0x19F7;                            
            // 0x028ECB1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F7, ????);     
            // 0x028ECB20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028ECB24: STRB w8, [x19, #0xa04]     | static_value_037B8A04 = true;            //  dest_result_addr=58427908
            label_0:
            // 0x028ECB28: ADRP x26, #0x366f000       | X26 = 57077760 (0x366F000);             
            // 0x028ECB2C: LDR x26, [x26, #0x7a0]     | X26 = 1152921504826228736;              
            // 0x028ECB30: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028ECB34: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ECB38: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028ECB3C: TBNZ w9, #0, #0x28ecb48    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028ECB40: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_27 = 8;
            // 0x028ECB44: B #0x28ecb60               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028ECB48: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ECB4C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ECB50: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028ECB54: SUB w25, w0, #0x10         | W25 = (null - 16) = val_27 (0x100000000D137FF0);
            val_27 = 1152921504826228720;
            // 0x028ECB58: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ECB5C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028ECB60: TBNZ w9, #0, #0x28ecb6c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028ECB64: ORR w27, wzr, #8           | W27 = 8(0x8);                           
            val_28 = 8;
            // 0x028ECB68: B #0x28ecb78               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028ECB6C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ECB70: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ECB74: SUB w27, w0, #0x10         | W27 = (null - 16) = val_28 (0x100000000D137FF0);
            val_28 = 1152921504826228720;
            label_4:
            // 0x028ECB78: CBNZ x22, #0x28ecb80       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028ECB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028ECB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECB84: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ECB88: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028ECB8C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_29 = null;
            // 0x028ECB90: MOV x24, x0                | X24 = val_1;//m1                        
            // 0x028ECB94: ADD x9, x8, #0x109         | X9 = (val_29 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ECB98: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028ECB9C: TBNZ w9, #0, #0x28ecba8    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028ECBA0: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_31 = 8;
            // 0x028ECBA4: B #0x28ecbc0               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028ECBA8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ECBAC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ECBB0: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_29 = null;
            // 0x028ECBB4: SUB w10, w0, #0x10         | W10 = (val_29 - 16) = val_31 (0x100000000D137FF0);
            val_31 = 1152921504826228720;
            // 0x028ECBB8: ADD x9, x8, #0x109         | X9 = (val_29 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ECBBC: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_7:
            // 0x028ECBC0: SUB x19, x23, w10, sxtw    | X19 = (X2 - (val_31) << );              
            var val_2 = X2 - (val_31 << );
            // 0x028ECBC4: TBZ w9, #8, #0x28ecbd8     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_9;
            // 0x028ECBC8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028ECBCC: CBNZ w9, #0x28ecbd8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x028ECBD0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ECBD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028ECBD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ECBDC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ECBE0: MOV x1, x19                | X1 = (X2 - (val_31) << );//m1           
            // 0x028ECBE4: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028ECBE8: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028ECBEC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028ECBF0: MOV x20, x0                | X20 = val_3;//m1                        
            val_32 = val_3;
            // 0x028ECBF4: CBNZ x22, #0x28ecbfc       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x028ECBF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x028ECBFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ECC00: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ECC04: MOV x1, x19                | X1 = (X2 - (val_31) << );//m1           
            // 0x028ECC08: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028ECC0C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_33 = null;
            // 0x028ECC10: ADD x9, x8, #0x109         | X9 = (val_33 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ECC14: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028ECC18: TBNZ w9, #0, #0x28ecc24    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_11;
            // 0x028ECC1C: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_35 = 8;
            // 0x028ECC20: B #0x28ecc3c               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x028ECC24: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ECC28: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ECC2C: LDR x8, [x26]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_33 = null;
            // 0x028ECC30: SUB w26, w0, #0x10         | W26 = (val_33 - 16) = val_35 (0x100000000D137FF0);
            val_35 = 1152921504826228720;
            // 0x028ECC34: ADD x9, x8, #0x109         | X9 = (val_33 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ECC38: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_12:
            // 0x028ECC3C: SUB x19, x23, w25, sxtw    | X19 = (X2 - (val_27) << );              
            var val_4 = X2 - (val_27 << );
            // 0x028ECC40: TBNZ w9, #0, #0x28ecc4c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_13;
            // 0x028ECC44: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_36 = 8;
            // 0x028ECC48: B #0x28ecc58               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028ECC4C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ECC50: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ECC54: SUB w8, w0, #0x10          | W8 = (val_33 - 16) = val_36 (0x100000000D137FF0);
            val_36 = 1152921504826228720;
            label_14:
            // 0x028ECC58: SUB x9, x23, w26, sxtw     | X9 = (X2 - (val_35) << );               
            var val_5 = X2 - (val_35 << );
            // 0x028ECC5C: SUB x23, x9, w8, sxtw      | X23 = ((X2 - (val_35) << ) - (val_36) << );
            val_37 = val_5 - (val_36 << );
            // 0x028ECC60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ECC64: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ECC68: MOV x1, x23                | X1 = ((X2 - (val_35) << ) - (val_36) << );//m1
            // 0x028ECC6C: MOV x2, x24                | X2 = val_1;//m1                         
            // 0x028ECC70: MOV x3, x21                | X3 = X3;//m1                            
            // 0x028ECC74: SUB x19, x19, w27, sxtw    | X19 = ((X2 - (val_27) << ) - (val_28) << );
            val_4 = val_4 - (val_28 << );
            // 0x028ECC78: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028ECC7C: MOV x21, x0                | X21 = val_6;//m1                        
            val_38 = val_6;
            // 0x028ECC80: CBNZ x22, #0x28ecc88       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x028ECC84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x028ECC88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_39 = 0;
            // 0x028ECC8C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ECC90: MOV x1, x23                | X1 = ((X2 - (val_35) << ) - (val_36) << );//m1
            // 0x028ECC94: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028ECC98: CBZ x21, #0x28ecdec        | if (val_6 == null) goto label_16;       
            if(val_38 == null)
            {
                goto label_16;
            }
            // 0x028ECC9C: CBZ x20, #0x28ed130        | if (val_3 == null) goto label_52;       
            if(val_32 == null)
            {
                goto label_52;
            }
            // 0x028ECCA0: ADRP x25, #0x3657000       | X25 = 56979456 (0x3657000);             
            // 0x028ECCA4: LDR x25, [x25, #0xa28]     | X25 = 1152921504825589760;              
            val_27 = 1152921504825589760;
            // 0x028ECCA8: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028ECCAC: LDR x1, [x25]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028ECCB0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028ECCB4: LDR x1, [x25]              | X1 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028ECCB8: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x028ECCBC: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028ECCC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028ECCC4: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x028ECCC8: CBZ x22, #0x28ecdf4        | if (val_6 == null) goto label_18;       
            if(val_38 == null)
            {
                goto label_18;
            }
            // 0x028ECCCC: LDR x22, [x25]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028ECCD0: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028ECCD4: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECCD8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028ECCDC: CBNZ x0, #0x28ecd10        | if (val_6 != null) goto label_19;       
            if(val_38 != null)
            {
                goto label_19;
            }
            // 0x028ECCE0: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028ECCE4: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECCE8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECCEC: ADD x8, sp, #0x10          | X8 = (1152921512890353808 + 16) = 1152921512890353824 (0x10000001EDBC48A0);
            // 0x028ECCF0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECCF4: LDR x0, [sp, #0x10]        | X0 = val_7;                              //  find_add[1152921512890341984]
            // 0x028ECCF8: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x028ECCFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECD00: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x028ECD04: ADD x0, sp, #0x10          | X0 = (1152921512890353808 + 16) = 1152921512890353824 (0x10000001EDBC48A0);
            // 0x028ECD08: BL #0x299a140              | 
            // 0x028ECD0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDBC48A0, ????);
            label_19:
            // 0x028ECD10: LDR x22, [x25]             | X22 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028ECD14: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028ECD18: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECD1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028ECD20: MOV x23, x0                | X23 = val_6;//m1                        
            val_37 = val_38;
            // 0x028ECD24: CBNZ x23, #0x28ecd58       | if (val_6 != null) goto label_20;       
            if(val_37 != null)
            {
                goto label_20;
            }
            // 0x028ECD28: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028ECD2C: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECD30: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECD34: ADD x8, sp, #0x18          | X8 = (1152921512890353808 + 24) = 1152921512890353832 (0x10000001EDBC48A8);
            // 0x028ECD38: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECD3C: LDR x0, [sp, #0x18]        | X0 = val_8;                              //  find_add[1152921512890341984]
            // 0x028ECD40: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028ECD44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECD48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028ECD4C: ADD x0, sp, #0x18          | X0 = (1152921512890353808 + 24) = 1152921512890353832 (0x10000001EDBC48A8);
            // 0x028ECD50: BL #0x299a140              | 
            // 0x028ECD54: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_37 = 0;
            label_20:
            // 0x028ECD58: CBZ x24, #0x28ecedc        | if (val_3 == null) goto label_21;       
            if(val_32 == null)
            {
                goto label_21;
            }
            // 0x028ECD5C: LDR x24, [x25]             | X24 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028ECD60: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028ECD64: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECD68: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028ECD6C: MOV x21, x0                | X21 = val_3;//m1                        
            val_38 = val_32;
            // 0x028ECD70: CBNZ x21, #0x28ecda4       | if (val_3 != null) goto label_22;       
            if(val_38 != null)
            {
                goto label_22;
            }
            // 0x028ECD74: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028ECD78: MOV x1, x24                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECD7C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECD80: ADD x8, sp, #0x20          | X8 = (1152921512890353808 + 32) = 1152921512890353840 (0x10000001EDBC48B0);
            // 0x028ECD84: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECD88: LDR x0, [sp, #0x20]        | X0 = val_9;                              //  find_add[1152921512890341984]
            // 0x028ECD8C: BL #0x27af090              | X0 = sub_27AF090( ?? val_9, ????);      
            // 0x028ECD90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECD94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            // 0x028ECD98: ADD x0, sp, #0x20          | X0 = (1152921512890353808 + 32) = 1152921512890353840 (0x10000001EDBC48B0);
            // 0x028ECD9C: BL #0x299a140              | 
            // 0x028ECDA0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_38 = 0;
            label_22:
            // 0x028ECDA4: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028ECDA8: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028ECDAC: CBZ x9, #0x28ecdd8         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x028ECDB0: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_24 = mem[282584257676823];
            // 0x028ECDB4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_25 = 0;
            // 0x028ECDB8: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_24 = val_24 + 8;
            label_25:
            // 0x028ECDBC: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028ECDC0: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028ECDC4: B.EQ #0x28ed034            | if ((mem[282584257676823] + 8) + -8 == null) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_24;
            }
            // 0x028ECDC8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_25 = val_25 + 1;
            // 0x028ECDCC: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_24 = val_24 + 16;
            // 0x028ECDD0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028ECDD4: B.LO #0x28ecdbc            | if (0 < mem[282584257676929]) goto label_25;
            if(val_25 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x028ECDD8: MOVZ w2, #0xd              | W2 = 13 (0xD);//ML01                    
            val_40 = 13;
            // 0x028ECDDC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_41 = val_37;
            // 0x028ECDE0: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECDE4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028ECDE8: B #0x28ed044               |  goto label_26;                         
            goto label_26;
            label_16:
            // 0x028ECDEC: CBNZ x20, #0x28ed130       | if (val_3 != null) goto label_52;       
            if(val_32 != null)
            {
                goto label_52;
            }
            // 0x028ECDF0: B #0x28ed11c               |  goto label_51;                         
            goto label_51;
            label_18:
            // 0x028ECDF4: CBZ x24, #0x28ecf80        | if (val_3 == null) goto label_29;       
            if(val_32 == null)
            {
                goto label_29;
            }
            // 0x028ECDF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECDFC: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x028ECE00: BL #0x16fb28c              | X0 = val_6.GetType();                   
            System.Type val_10 = val_38.GetType();
            // 0x028ECE04: LDR x23, [x25]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            // 0x028ECE08: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x028ECE0C: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028ECE10: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECE14: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028ECE18: CBNZ x0, #0x28ece4c        | if (val_3 != null) goto label_30;       
            if(val_32 != null)
            {
                goto label_30;
            }
            // 0x028ECE1C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028ECE20: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECE24: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECE28: ADD x8, sp, #0x30          | X8 = (1152921512890353808 + 48) = 1152921512890353856 (0x10000001EDBC48C0);
            // 0x028ECE2C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECE30: LDR x0, [sp, #0x30]        | X0 = val_11;                             //  find_add[1152921512890341984]
            // 0x028ECE34: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x028ECE38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECE3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x028ECE40: ADD x0, sp, #0x30          | X0 = (1152921512890353808 + 48) = 1152921512890353856 (0x10000001EDBC48C0);
            // 0x028ECE44: BL #0x299a140              | 
            // 0x028ECE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDBC48C0, ????);
            label_30:
            // 0x028ECE4C: LDR x23, [x25]             | X23 = typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter);
            val_37 = null;
            // 0x028ECE50: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028ECE54: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECE58: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
            // 0x028ECE5C: MOV x24, x0                | X24 = val_3;//m1                        
            val_42 = val_32;
            // 0x028ECE60: CBNZ x24, #0x28ece94       | if (val_3 != null) goto label_31;       
            if(val_42 != null)
            {
                goto label_31;
            }
            // 0x028ECE64: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028ECE68: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECE6C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECE70: ADD x8, sp, #0x38          | X8 = (1152921512890353808 + 56) = 1152921512890353864 (0x10000001EDBC48C8);
            // 0x028ECE74: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECE78: LDR x0, [sp, #0x38]        | X0 = val_12;                             //  find_add[1152921512890341984]
            // 0x028ECE7C: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x028ECE80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECE84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x028ECE88: ADD x0, sp, #0x38          | X0 = (1152921512890353808 + 56) = 1152921512890353864 (0x10000001EDBC48C8);
            // 0x028ECE8C: BL #0x299a140              | 
            // 0x028ECE90: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            val_42 = 0;
            label_31:
            // 0x028ECE94: LDR x8, [x24]              | X8 = 0x10102464C457F;                   
            // 0x028ECE98: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028ECE9C: CBZ x9, #0x28ecec8         | if (mem[282584257676929] == 0) goto label_32;
            if(mem[282584257676929] == 0)
            {
                goto label_32;
            }
            // 0x028ECEA0: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_26 = mem[282584257676823];
            // 0x028ECEA4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_27 = 0;
            // 0x028ECEA8: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_26 = val_26 + 8;
            label_34:
            // 0x028ECEAC: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028ECEB0: CMP x12, x23               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028ECEB4: B.EQ #0x28ed054            | if ((mem[282584257676823] + 8) + -8 == val_37) goto label_33;
            if(((mem[282584257676823] + 8) + -8) == val_37)
            {
                goto label_33;
            }
            // 0x028ECEB8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_27 = val_27 + 1;
            // 0x028ECEBC: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_26 = val_26 + 16;
            // 0x028ECEC0: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028ECEC4: B.LO #0x28eceac            | if (0 < mem[282584257676929]) goto label_34;
            if(val_27 < mem[282584257676929])
            {
                goto label_34;
            }
            label_32:
            // 0x028ECEC8: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            val_43 = 8;
            // 0x028ECECC: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            val_44 = val_42;
            // 0x028ECED0: MOV x1, x23                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECED4: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028ECED8: B #0x28ed064               |  goto label_35;                         
            goto label_35;
            label_21:
            // 0x028ECEDC: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028ECEE0: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028ECEE4: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028ECEE8: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028ECEEC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ECEF0: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ECEF4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ECEF8: B.LO #0x28ecf10            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_36;
            // 0x028ECEFC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ECF00: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028ECF04: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ECF08: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028ECF0C: B.EQ #0x28ecf38            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_37;
            label_36:
            // 0x028ECF10: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECF14: ADD x8, sp, #0x28          | X8 = (1152921512890353808 + 40) = 1152921512890353848 (0x10000001EDBC48B8);
            // 0x028ECF18: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECF1C: LDR x0, [sp, #0x28]        | X0 = val_14;                             //  find_add[1152921512890341984]
            // 0x028ECF20: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028ECF24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECF28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028ECF2C: ADD x0, sp, #0x28          | X0 = (1152921512890353808 + 40) = 1152921512890353848 (0x10000001EDBC48B8);
            // 0x028ECF30: BL #0x299a140              | 
            // 0x028ECF34: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_32 = 0;
            label_37:
            // 0x028ECF38: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            var val_33 = 1179403647;
            // 0x028ECF3C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028ECF40: CBZ x9, #0x28ecf6c         | if (mem[282584257676929] == 0) goto label_38;
            if(mem[282584257676929] == 0)
            {
                goto label_38;
            }
            // 0x028ECF44: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_28 = mem[282584257676823];
            // 0x028ECF48: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_29 = 0;
            // 0x028ECF4C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_28 = val_28 + 8;
            label_40:
            // 0x028ECF50: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028ECF54: CMP x12, x22               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Intepreter.IDelegateAdapter))
            // 0x028ECF58: B.EQ #0x28ed0f4            | if ((mem[282584257676823] + 8) + -8 == null) goto label_39;
            if(((mem[282584257676823] + 8) + -8) == null)
            {
                goto label_39;
            }
            // 0x028ECF5C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_29 = val_29 + 1;
            // 0x028ECF60: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_28 = val_28 + 16;
            // 0x028ECF64: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028ECF68: B.LO #0x28ecf50            | if (0 < mem[282584257676929]) goto label_40;
            if(val_29 < mem[282584257676929])
            {
                goto label_40;
            }
            label_38:
            // 0x028ECF6C: ORR w2, wzr, #0xe          | W2 = 14(0xE);                           
            val_45 = 14;
            // 0x028ECF70: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_46 = val_37;
            // 0x028ECF74: MOV x1, x22                | X1 = 1152921504825589760 (0x100000000D09C000);//ML01
            // 0x028ECF78: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028ECF7C: B #0x28ed104               |  goto label_41;                         
            goto label_41;
            label_29:
            // 0x028ECF80: ADRP x22, #0x3639000       | X22 = 56856576 (0x3639000);             
            // 0x028ECF84: LDR x22, [x22, #0xbe8]     | X22 = 1152921504608870400;              
            // 0x028ECF88: LDR x9, [x21]              | X9 = typeof(System.Object);             
            // 0x028ECF8C: LDR x1, [x22]              | X1 = typeof(System.Delegate);           
            val_47 = null;
            // 0x028ECF90: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ECF94: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ECF98: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ECF9C: B.LO #0x28ecfb4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_42;
            // 0x028ECFA0: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ECFA4: ADD x10, x10, x8, lsl #3   | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_type
            // 0x028ECFA8: LDUR x10, [x10, #-8]       | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ECFAC: CMP x10, x1                | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028ECFB0: B.EQ #0x28ecfe4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == val_47) goto label_43;
            label_42:
            // 0x028ECFB4: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ECFB8: ADD x8, sp, #0x48          | X8 = (1152921512890353808 + 72) = 1152921512890353880 (0x10000001EDBC48D8);
            // 0x028ECFBC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ECFC0: LDR x0, [sp, #0x48]        | X0 = val_15;                             //  find_add[1152921512890341984]
            // 0x028ECFC4: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x028ECFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ECFCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x028ECFD0: ADD x0, sp, #0x48          | X0 = (1152921512890353808 + 72) = 1152921512890353880 (0x10000001EDBC48D8);
            // 0x028ECFD4: BL #0x299a140              | 
            // 0x028ECFD8: LDR x1, [x22]              | X1 = typeof(System.Delegate);           
            val_47 = null;
            // 0x028ECFDC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_38 = 0;
            // 0x028ECFE0: LDRB w8, [x1, #0x104]      | W8 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            label_43:
            // 0x028ECFE4: LDR x9, [x20]              | X9 = typeof(System.Object);             
            // 0x028ECFE8: LDRB w10, [x9, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ECFEC: CMP w10, w8                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ECFF0: B.LO #0x28ed008            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_44;
            // 0x028ECFF4: LDR x10, [x9, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ECFF8: ADD x8, x10, w8, uxtw #3   | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHi
            // 0x028ECFFC: LDUR x8, [x8, #-8]         | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8;
            // 0x028ED000: CMP x8, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8, typeof(System.Delegate))
            // 0x028ED004: B.EQ #0x28ed0d4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) + -8 == val_47) goto label_49;
            label_44:
            // 0x028ED008: LDR x0, [x9, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED00C: ADD x8, sp, #8             | X8 = (1152921512890353808 + 8) = 1152921512890353816 (0x10000001EDBC4898);
            // 0x028ED010: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED014: LDR x0, [sp, #8]           | X0 = val_16;                             //  find_add[1152921512890341984]
            // 0x028ED018: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x028ED01C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED020: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x028ED024: ADD x0, sp, #8             | X0 = (1152921512890353808 + 8) = 1152921512890353816 (0x10000001EDBC4898);
            // 0x028ED028: BL #0x299a140              | 
            // 0x028ED02C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_49 = 0;
            // 0x028ED030: B #0x28ed0d4               |  goto label_49;                         
            goto label_49;
            label_24:
            // 0x028ED034: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_30 = val_24;
            // 0x028ED038: ADD w9, w9, #0xd           | W9 = ((mem[282584257676823] + 8) + 13); 
            val_30 = val_30 + 13;
            // 0x028ED03C: ADD x8, x8, w9, uxtw #4    | X8 = (val_37 + ((mem[282584257676823] + 8) + 13));
            val_37 = val_37 + val_30;
            // 0x028ED040: ADD x0, x8, #0x110         | X0 = ((val_37 + ((mem[282584257676823] + 8) + 13)) + 272);
            val_41 = val_37 + 272;
            label_26:
            // 0x028ED044: LDP x8, x2, [x0]           | X8 = ((val_37 + ((mem[282584257676823] + 8) + 13)) + 272); X2 = ((val_37 + ((mem[282584257676823] + 8) + 13)) + 272) + 8; //  | 
            // 0x028ED048: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_50 = val_37;
            // 0x028ED04C: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028ED050: B #0x28ed110               |  goto label_47;                         
            goto label_47;
            label_33:
            // 0x028ED054: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_31 = val_26;
            // 0x028ED058: ADD w9, w9, #8             | W9 = ((mem[282584257676823] + 8) + 8);  
            val_31 = val_31 + 8;
            // 0x028ED05C: ADD x8, x8, w9, uxtw #4    | X8 = (val_42 + ((mem[282584257676823] + 8) + 8));
            val_42 = val_42 + val_31;
            // 0x028ED060: ADD x0, x8, #0x110         | X0 = ((val_42 + ((mem[282584257676823] + 8) + 8)) + 272);
            val_44 = val_42 + 272;
            label_35:
            // 0x028ED064: LDP x8, x2, [x0]           | X8 = ((val_42 + ((mem[282584257676823] + 8) + 8)) + 272); X2 = ((val_42 + ((mem[282584257676823] + 8) + 8)) + 272) + 8; //  | 
            // 0x028ED068: MOV x0, x24                | X0 = 0 (0x0);//ML01                     
            // 0x028ED06C: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x028ED070: BLR x8                     | X0 = ((val_42 + ((mem[282584257676823] + 8) + 8)) + 272)();
            // 0x028ED074: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x028ED078: LDR x9, [x9, #0xbe8]       | X9 = 1152921504608870400;               
            // 0x028ED07C: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028ED080: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            val_49 = val_42;
            // 0x028ED084: LDR x1, [x9]               | X1 = typeof(System.Delegate);           
            // 0x028ED088: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED08C: LDRB w9, [x1, #0x104]      | W9 = System.Delegate.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED090: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Delegate.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED094: B.LO #0x28ed0ac            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) goto label_48;
            // 0x028ED098: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED09C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeH
            // 0x028ED0A0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED0A4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Delegate))
            // 0x028ED0A8: B.EQ #0x28ed0d4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Delegate.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_49;
            label_48:
            // 0x028ED0AC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED0B0: ADD x8, sp, #0x40          | X8 = (1152921512890353808 + 64) = 1152921512890353872 (0x10000001EDBC48D0);
            // 0x028ED0B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED0B8: LDR x0, [sp, #0x40]        | X0 = val_18;                             //  find_add[1152921512890341984]
            // 0x028ED0BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x028ED0C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED0C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x028ED0C8: ADD x0, sp, #0x40          | X0 = (1152921512890353808 + 64) = 1152921512890353872 (0x10000001EDBC48D0);
            // 0x028ED0CC: BL #0x299a140              | 
            // 0x028ED0D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_38 = 0;
            label_49:
            // 0x028ED0D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED0D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028ED0DC: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x028ED0E0: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x028ED0E4: BL #0x1c34e48              | X0 = System.Delegate.op_Inequality(d1:  0, d2:  val_38);
            bool val_19 = System.Delegate.op_Inequality(d1:  0, d2:  val_38);
            // 0x028ED0E8: AND w8, w0, #1             | W8 = (val_19 & 1);                      
            bool val_20 = val_19;
            // 0x028ED0EC: TBNZ w8, #0, #0x28ed130    | if ((val_19 & 1) == true) goto label_52;
            if(val_20 == true)
            {
                goto label_52;
            }
            // 0x028ED0F0: B #0x28ed11c               |  goto label_51;                         
            goto label_51;
            label_39:
            // 0x028ED0F4: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            var val_32 = val_28;
            // 0x028ED0F8: ADD w9, w9, #0xe           | W9 = ((mem[282584257676823] + 8) + 14); 
            val_32 = val_32 + 14;
            // 0x028ED0FC: ADD x8, x8, w9, uxtw #4    | X8 = (1179403647 + ((mem[282584257676823] + 8) + 14));
            val_33 = val_33 + val_32;
            // 0x028ED100: ADD x0, x8, #0x110         | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272);
            val_46 = val_33 + 272;
            label_41:
            // 0x028ED104: LDP x8, x2, [x0]           | X8 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272); X2 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272) + 8; //  | 
            // 0x028ED108: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_50 = val_37;
            // 0x028ED10C: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            label_47:
            // 0x028ED110: BLR x8                     | X0 = ((1179403647 + ((mem[282584257676823] + 8) + 14)) + 272)();
            // 0x028ED114: AND w8, w0, #1             | W8 = (val_50 & 1);                      
            var val_21 = val_50 & 1;
            // 0x028ED118: TBZ w8, #0, #0x28ed130     | if (((val_50 & 1) & 0x1) == 0) goto label_52;
            if((val_21 & 1) == 0)
            {
                goto label_52;
            }
            label_51:
            // 0x028ED11C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ED124: MOV x1, x19                | X1 = ((X2 - (val_27) << ) - (val_28) << );//m1
            // 0x028ED128: BL #0x1f96cf0              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_22 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushZero(esp:  null);
            // 0x028ED12C: B #0x28ed140               |  goto label_53;                         
            goto label_53;
            label_52:
            // 0x028ED130: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED134: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ED138: MOV x1, x19                | X1 = ((X2 - (val_27) << ) - (val_28) << );//m1
            // 0x028ED13C: BL #0x1f96c74              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushOne(esp:  null);
            ILRuntime.Runtime.Stack.StackObject* val_23 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushOne(esp:  null);
            label_53:
            // 0x028ED140: SUB sp, x29, #0x50         | SP = (1152921512890353968 - 80) = 1152921512890353888 (0x10000001EDBC48E0);
            // 0x028ED144: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028ED148: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028ED14C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028ED150: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028ED154: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028ED158: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028ED15C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_23;
            return val_23;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028ED1D4 (42914260), len: 8  VirtAddr: 0x028ED1D4 RVA: 0x028ED1D4 token: 100680277 methodIndex: 29565 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* GetTypeFromHandle(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x028ED1D4: MOV x0, x2                 | X0 = X2;//m1                            
            // 0x028ED1D8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)X2;
            return (ILRuntime.Runtime.Stack.StackObject*)X2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028ED1DC (42914268), len: 2132  VirtAddr: 0x028ED1DC RVA: 0x028ED1DC token: 100680278 methodIndex: 29566 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* MethodInfoInvoke(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            object val_19;
            //  | 
            var val_23;
            //  | 
            var val_25;
            //  | 
            var val_32;
            //  | 
            var val_36;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            System.Object[] val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            object val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            // 0x028ED1DC: STP x28, x27, [sp, #-0x60]! | stack[1152921512890704864] = ???;  stack[1152921512890704872] = ???;  //  dest_result_addr=1152921512890704864 |  dest_result_addr=1152921512890704872
            // 0x028ED1E0: STP x26, x25, [sp, #0x10]  | stack[1152921512890704880] = ???;  stack[1152921512890704888] = ???;  //  dest_result_addr=1152921512890704880 |  dest_result_addr=1152921512890704888
            // 0x028ED1E4: STP x24, x23, [sp, #0x20]  | stack[1152921512890704896] = ???;  stack[1152921512890704904] = ???;  //  dest_result_addr=1152921512890704896 |  dest_result_addr=1152921512890704904
            // 0x028ED1E8: STP x22, x21, [sp, #0x30]  | stack[1152921512890704912] = ???;  stack[1152921512890704920] = ???;  //  dest_result_addr=1152921512890704912 |  dest_result_addr=1152921512890704920
            // 0x028ED1EC: STP x20, x19, [sp, #0x40]  | stack[1152921512890704928] = ???;  stack[1152921512890704936] = ???;  //  dest_result_addr=1152921512890704928 |  dest_result_addr=1152921512890704936
            // 0x028ED1F0: STP x29, x30, [sp, #0x50]  | stack[1152921512890704944] = ???;  stack[1152921512890704952] = ???;  //  dest_result_addr=1152921512890704944 |  dest_result_addr=1152921512890704952
            // 0x028ED1F4: ADD x29, sp, #0x50         | X29 = (1152921512890704864 + 80) = 1152921512890704944 (0x10000001EDC1A430);
            // 0x028ED1F8: SUB sp, sp, #0x50          | SP = (1152921512890704864 - 80) = 1152921512890704784 (0x10000001EDC1A390);
            // 0x028ED1FC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028ED200: LDRB w8, [x20, #0xa05]     | W8 = (bool)static_value_037B8A05;       
            // 0x028ED204: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028ED208: MOV x23, x2                | X23 = X2;//m1                           
            // 0x028ED20C: MOV x22, x1                | X22 = X1;//m1                           
            // 0x028ED210: TBNZ w8, #0, #0x28ed22c    | if (static_value_037B8A05 == true) goto label_0;
            // 0x028ED214: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028ED218: LDR x8, [x8, #0x608]       | X8 = 0x2B90CF0;                         
            // 0x028ED21C: LDR w0, [x8]               | W0 = 0x1A00;                            
            // 0x028ED220: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A00, ????);     
            // 0x028ED224: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028ED228: STRB w8, [x20, #0xa05]     | static_value_037B8A05 = true;            //  dest_result_addr=58427909
            label_0:
            // 0x028ED22C: STRB wzr, [sp, #7]         | stack[1152921512890704791] = 0x0;        //  dest_result_addr=1152921512890704791
            // 0x028ED230: CBNZ x22, #0x28ed238       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028ED234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A00, ????);     
            label_1:
            // 0x028ED238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED23C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ED240: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028ED244: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028ED248: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED24C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028ED250: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028ED254: MOV x1, x23                | X1 = X2;//m1                            
            // 0x028ED258: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028ED25C: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x028ED260: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x028ED264: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028ED268: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_42 = null;
            // 0x028ED26C: ADD x9, x8, #0x109         | X9 = (val_42 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ED270: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028ED274: TBNZ w9, #0, #0x28ed280    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_2;
            // 0x028ED278: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_44 = 8;
            // 0x028ED27C: B #0x28ed298               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x028ED280: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ED284: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ED288: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_42 = null;
            // 0x028ED28C: SUB w10, w0, #0x10         | W10 = (val_42 - 16) = val_44 (0x100000000D137FF0);
            val_44 = 1152921504826228720;
            // 0x028ED290: ADD x9, x8, #0x109         | X9 = (val_42 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ED294: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_3:
            // 0x028ED298: SUB x25, x23, w10, sxtw    | X25 = (X2 - (val_44) << );              
            var val_3 = X2 - (val_44 << );
            // 0x028ED29C: TBZ w9, #8, #0x28ed2b0     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_5;
            // 0x028ED2A0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028ED2A4: CBNZ w9, #0x28ed2b0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028ED2A8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ED2AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028ED2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED2B4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ED2B8: MOV x1, x25                | X1 = (X2 - (val_44) << );//m1           
            // 0x028ED2BC: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x028ED2C0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028ED2C4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_4 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028ED2C8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028ED2CC: CBNZ x22, #0x28ed2d4       | if (X1 != 0) goto label_6;              
            if(X1 != 0)
            {
                goto label_6;
            }
            // 0x028ED2D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x028ED2D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ED2D8: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ED2DC: MOV x1, x25                | X1 = (X2 - (val_44) << );//m1           
            // 0x028ED2E0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028ED2E4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028ED2E8: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ED2EC: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028ED2F0: TBNZ w9, #0, #0x28ed2fc    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_7;
            // 0x028ED2F4: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_46 = 8;
            // 0x028ED2F8: B #0x28ed314               |  goto label_8;                          
            goto label_8;
            label_7:
            // 0x028ED2FC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ED300: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ED304: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028ED308: SUB w25, w0, #0x10         | W25 = (null - 16) = val_46 (0x100000000D137FF0);
            val_46 = 1152921504826228720;
            // 0x028ED30C: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028ED310: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_8:
            // 0x028ED314: TBNZ w9, #0, #0x28ed320    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_9;
            // 0x028ED318: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_47 = 8;
            // 0x028ED31C: B #0x28ed32c               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x028ED320: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028ED324: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ED328: SUB w8, w0, #0x10          | W8 = (null - 16) = val_47 (0x100000000D137FF0);
            val_47 = 1152921504826228720;
            label_10:
            // 0x028ED32C: SUB x9, x23, w25, sxtw     | X9 = (X2 - (val_46) << );               
            var val_5 = X2 - (val_46 << );
            // 0x028ED330: SUB x26, x9, w8, sxtw      | X26 = ((X2 - (val_46) << ) - (val_47) << );
            var val_6 = val_5 - (val_47 << );
            // 0x028ED334: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED338: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ED33C: MOV x1, x26                | X1 = ((X2 - (val_46) << ) - (val_47) << );//m1
            // 0x028ED340: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x028ED344: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028ED348: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_7 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028ED34C: MOV x25, x0                | X25 = val_7;//m1                        
            // 0x028ED350: CBNZ x22, #0x28ed358       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028ED354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_11:
            // 0x028ED358: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ED35C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ED360: MOV x1, x26                | X1 = ((X2 - (val_46) << ) - (val_47) << );//m1
            // 0x028ED364: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028ED368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED36C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028ED370: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028ED374: MOV x1, x23                | X1 = X2;//m1                            
            // 0x028ED378: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028ED37C: MOV x26, x0                | X26 = val_8;//m1                        
            // 0x028ED380: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED384: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ED388: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x028ED38C: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x028ED390: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028ED394: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028ED398: MOV x1, x0                 | X1 = val_9;//m1                         
            // 0x028ED39C: BL #0x28eda30              | X0 = ILRuntime.Runtime.Enviorment.CLRRedirections.CheckCrossBindingAdapter(obj:  object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null));
            object val_10 = ILRuntime.Runtime.Enviorment.CLRRedirections.CheckCrossBindingAdapter(obj:  val_9);
            // 0x028ED3A0: MOV x23, x0                | X23 = val_10;//m1                       
            val_48 = val_10;
            // 0x028ED3A4: CBNZ x22, #0x28ed3ac       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x028ED3A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_12:
            // 0x028ED3AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028ED3B0: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ED3B4: MOV x1, x26                | X1 = val_8;//m1                         
            // 0x028ED3B8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028ED3BC: CBZ x23, #0x28ed444        | if (val_10 == null) goto label_13;      
            if(val_48 == null)
            {
                goto label_13;
            }
            // 0x028ED3C0: ADRP x28, #0x35e0000       | X28 = 56492032 (0x35E0000);             
            // 0x028ED3C4: LDR x28, [x28, #0x530]     | X28 = 1152921504821436416;              
            // 0x028ED3C8: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x028ED3CC: LDR x10, [x28]             | X10 = typeof(ILRuntime.Reflection.ILRuntimeMethodInfo);
            // 0x028ED3D0: LDRB w9, [x8, #0x104]      | W9 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED3D4: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED3D8: CMP w9, w11                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED3DC: B.LO #0x28ed3f4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x028ED3E0: LDR x12, [x8, #0xb0]       | X12 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED3E4: ADD x11, x12, x11, lsl #3  | X11 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.
            // 0x028ED3E8: LDUR x11, [x11, #-8]       | X11 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED3EC: CMP x11, x10               | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeMethodInfo))
            // 0x028ED3F0: B.EQ #0x28ed550            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x028ED3F4: ADRP x10, #0x35b8000       | X10 = 56328192 (0x35B8000);             
            // 0x028ED3F8: LDR x10, [x10, #0x408]     | X10 = 1152921504627560448;              
            // 0x028ED3FC: LDR x1, [x10]              | X1 = typeof(System.Reflection.MethodInfo);
            // 0x028ED400: LDRB w10, [x1, #0x104]     | W10 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED404: CMP w9, w10                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED408: B.LO #0x28ed420            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x028ED40C: LDR x9, [x8, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED410: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRunti
            // 0x028ED414: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED418: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.MethodInfo))
            // 0x028ED41C: B.EQ #0x28ed448            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x028ED420: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED424: ADD x8, sp, #0x40          | X8 = (1152921512890704784 + 64) = 1152921512890704848 (0x10000001EDC1A3D0);
            // 0x028ED428: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED42C: LDR x0, [sp, #0x40]        | X0 = val_12;                             //  find_add[1152921512890692960]
            // 0x028ED430: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x028ED434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED438: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x028ED43C: ADD x0, sp, #0x40          | X0 = (1152921512890704784 + 64) = 1152921512890704848 (0x10000001EDC1A3D0);
            // 0x028ED440: BL #0x299a140              | 
            label_13:
            // 0x028ED444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDC1A3D0, ????);
            label_17:
            // 0x028ED448: CBZ x23, #0x28ed4a4        | if (val_10 == null) goto label_18;      
            if(val_48 == null)
            {
                goto label_18;
            }
            // 0x028ED44C: ADRP x9, #0x35b8000        | X9 = 56328192 (0x35B8000);              
            // 0x028ED450: LDR x9, [x9, #0x408]       | X9 = 1152921504627560448;               
            // 0x028ED454: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x028ED458: LDR x1, [x9]               | X1 = typeof(System.Reflection.MethodInfo);
            // 0x028ED45C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED460: LDRB w9, [x1, #0x104]      | W9 = System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED464: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED468: B.LO #0x28ed480            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_19;
            // 0x028ED46C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED470: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRunti
            // 0x028ED474: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED478: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Reflection.MethodInfo))
            // 0x028ED47C: B.EQ #0x28ed4a8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Reflection.MethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_20;
            label_19:
            // 0x028ED480: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED484: ADD x8, sp, #0x48          | X8 = (1152921512890704784 + 72) = 1152921512890704856 (0x10000001EDC1A3D8);
            // 0x028ED488: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED48C: LDR x0, [sp, #0x48]        | X0 = val_14;                             //  find_add[1152921512890692960]
            // 0x028ED490: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028ED494: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED498: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028ED49C: ADD x0, sp, #0x48          | X0 = (1152921512890704784 + 72) = 1152921512890704856 (0x10000001EDC1A3D8);
            // 0x028ED4A0: BL #0x299a140              | 
            label_18:
            // 0x028ED4A4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_48 = 0;
            label_20:
            // 0x028ED4A8: CBZ x24, #0x28ed4f8        | if (val_4 == null) goto label_21;       
            if(val_4 == null)
            {
                goto label_21;
            }
            // 0x028ED4AC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028ED4B0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x028ED4B4: MOV x0, x24                | X0 = val_4;//m1                         
            // 0x028ED4B8: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x028ED4BC: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028ED4C0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x028ED4C4: MOV x2, x0                 | X2 = val_4;//m1                         
            val_49 = val_4;
            // 0x028ED4C8: CBNZ x2, #0x28ed4fc        | if (val_4 != null) goto label_22;       
            if(val_49 != null)
            {
                goto label_22;
            }
            // 0x028ED4CC: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x028ED4D0: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028ED4D4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED4D8: ADD x8, sp, #8             | X8 = (1152921512890704784 + 8) = 1152921512890704792 (0x10000001EDC1A398);
            // 0x028ED4DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED4E0: LDR x0, [sp, #8]           | X0 = val_15;                             //  find_add[1152921512890692960]
            // 0x028ED4E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x028ED4E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED4EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x028ED4F0: ADD x0, sp, #8             | X0 = (1152921512890704784 + 8) = 1152921512890704792 (0x10000001EDC1A398);
            // 0x028ED4F4: BL #0x299a140              | 
            label_21:
            // 0x028ED4F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_49 = 0;
            label_22:
            // 0x028ED4FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028ED500: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028ED504: MOV x1, x25                | X1 = val_7;//m1                         
            // 0x028ED508: BL #0x13be768              | X0 = val_48.Invoke(obj:  val_7, parameters:  val_49 = 0);
            object val_16 = val_48.Invoke(obj:  val_7, parameters:  val_49);
            // 0x028ED50C: MOV x3, x0                 | X3 = val_16;//m1                        
            // 0x028ED510: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED514: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028ED518: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028ED51C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028ED520: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            label_62:
            // 0x028ED524: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_17 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028ED528: MOV x24, x0                | X24 = val_17;//m1                       
            label_43:
            // 0x028ED52C: MOV x0, x24                | X0 = val_17;//m1                        
            // 0x028ED530: SUB sp, x29, #0x50         | SP = (1152921512890704944 - 80) = 1152921512890704864 (0x10000001EDC1A3E0);
            // 0x028ED534: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028ED538: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028ED53C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028ED540: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028ED544: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028ED548: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028ED54C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_17;
            return (ILRuntime.Runtime.Stack.StackObject*)val_17;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_15:
            // 0x028ED550: CBZ x25, #0x28ed574        | if (val_7 == null) goto label_23;       
            if(val_7 == null)
            {
                goto label_23;
            }
            // 0x028ED554: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED558: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028ED55C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028ED560: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028ED564: MOV x3, x25                | X3 = val_7;//m1                         
            // 0x028ED568: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028ED56C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_18 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028ED570: MOV x21, x0                | X21 = val_18;//m1                       
            val_50 = val_18;
            label_23:
            // 0x028ED574: CBZ x24, #0x28ed630        | if (val_4 == null) goto label_28;       
            if(val_4 == null)
            {
                goto label_28;
            }
            // 0x028ED578: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x028ED57C: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x028ED580: MOV x0, x24                | X0 = val_4;//m1                         
            // 0x028ED584: LDR x26, [x8]              | X26 = typeof(System.Object[]);          
            // 0x028ED588: MOV x1, x26                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028ED58C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x028ED590: MOV x25, x0                | X25 = val_4;//m1                        
            val_51 = val_4;
            // 0x028ED594: CBNZ x25, #0x28ed5c8       | if (val_4 != null) goto label_25;       
            if(val_51 != null)
            {
                goto label_25;
            }
            // 0x028ED598: LDR x8, [x24]              | X8 = typeof(System.Object);             
            // 0x028ED59C: MOV x1, x26                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x028ED5A0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED5A4: ADD x8, sp, #0x10          | X8 = (1152921512890704784 + 16) = 1152921512890704800 (0x10000001EDC1A3A0);
            // 0x028ED5A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED5AC: LDR x0, [sp, #0x10]        | X0 = val_19;                             //  find_add[1152921512890692960]
            // 0x028ED5B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x028ED5B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED5B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x028ED5BC: ADD x0, sp, #0x10          | X0 = (1152921512890704784 + 16) = 1152921512890704800 (0x10000001EDC1A3A0);
            // 0x028ED5C0: BL #0x299a140              | 
            // 0x028ED5C4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_51 = 0;
            label_25:
            // 0x028ED5C8: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_52 = 0;
            // 0x028ED5CC: B #0x28ed600               |  goto label_26;                         
            goto label_26;
            label_30:
            // 0x028ED5D0: ADD x8, x25, x26, lsl #3   | X8 = (val_51 + -9223372034073541504) = -9223372034073541504 (0x80000000A5C64480);
            // 0x028ED5D4: LDR x1, [x8, #0x20]        | X1 = mem[-9223372034073541472];         
            // 0x028ED5D8: BL #0x28eda30              | X0 = ILRuntime.Runtime.Enviorment.CLRRedirections.CheckCrossBindingAdapter(obj:  object val_19);
            object val_20 = ILRuntime.Runtime.Enviorment.CLRRedirections.CheckCrossBindingAdapter(obj:  val_19);
            // 0x028ED5DC: MOV x3, x0                 | X3 = val_20;//m1                        
            // 0x028ED5E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED5E4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028ED5E8: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x028ED5EC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028ED5F0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028ED5F4: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_21 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028ED5F8: MOV x21, x0                | X21 = val_21;//m1                       
            val_50 = val_21;
            // 0x028ED5FC: ADD w24, w24, #1           | W24 = (val_52 + 1) = val_52 (0x00000001);
            val_52 = 1;
            label_26:
            // 0x028ED600: CBNZ x25, #0x28ed608       | if (0x0 != 0) goto label_27;            
            if(val_51 != 0)
            {
                goto label_27;
            }
            // 0x028ED604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_27:
            // 0x028ED608: LDR w8, [x25, #0x18]       | W8 = 0x9814C0;                          
            // 0x028ED60C: CMP w24, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x028ED610: B.GE #0x28ed630            | if (val_52 >= 9966784) goto label_28;   
            if(val_52 >= 9966784)
            {
                goto label_28;
            }
            // 0x028ED614: SXTW x26, w24              | X26 = 1 (0x00000001);                   
            // 0x028ED618: CMP w24, w8                | STATE = COMPARE(0x1, 0x9814C0)          
            // 0x028ED61C: B.LO #0x28ed5d0            | if (val_52 < 9966784) goto label_30;    
            if(val_52 < 9966784)
            {
                goto label_30;
            }
            // 0x028ED620: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
            // 0x028ED624: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED628: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            // 0x028ED62C: B #0x28ed5d0               |  goto label_30;                         
            goto label_30;
            label_28:
            // 0x028ED630: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x028ED634: LDR x1, [x28]              | X1 = typeof(ILRuntime.Reflection.ILRuntimeMethodInfo);
            // 0x028ED638: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED63C: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED640: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED644: B.LO #0x28ed65c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_31;
            // 0x028ED648: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED64C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo._
            // 0x028ED650: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED654: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeMethodInfo))
            // 0x028ED658: B.EQ #0x28ed684            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_32;
            label_31:
            // 0x028ED65C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED660: ADD x8, sp, #0x18          | X8 = (1152921512890704784 + 24) = 1152921512890704808 (0x10000001EDC1A3A8);
            // 0x028ED664: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED668: LDR x0, [sp, #0x18]        | X0 = val_23;                             //  find_add[1152921512890692960]
            // 0x028ED66C: BL #0x27af090              | X0 = sub_27AF090( ?? val_23, ????);     
            // 0x028ED670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED674: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            // 0x028ED678: ADD x0, sp, #0x18          | X0 = (1152921512890704784 + 24) = 1152921512890704808 (0x10000001EDC1A3A8);
            // 0x028ED67C: BL #0x299a140              | 
            // 0x028ED680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDC1A3A8, ????);
            label_32:
            // 0x028ED684: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x028ED688: LDR x1, [x28]              | X1 = typeof(ILRuntime.Reflection.ILRuntimeMethodInfo);
            // 0x028ED68C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED690: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED694: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED698: B.LO #0x28ed6b4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_33;
            // 0x028ED69C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED6A0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo._
            // 0x028ED6A4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED6A8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeMethodInfo))
            // 0x028ED6AC: MOV x0, x23                | X0 = val_10;//m1                        
            // 0x028ED6B0: B.EQ #0x28ed6dc            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_34;
            label_33:
            // 0x028ED6B4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED6B8: ADD x8, sp, #0x20          | X8 = (1152921512890704784 + 32) = 1152921512890704816 (0x10000001EDC1A3B0);
            // 0x028ED6BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED6C0: LDR x0, [sp, #0x20]        | X0 = val_25;                             //  find_add[1152921512890692960]
            // 0x028ED6C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_25, ????);     
            // 0x028ED6C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED6CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
            // 0x028ED6D0: ADD x0, sp, #0x20          | X0 = (1152921512890704784 + 32) = 1152921512890704816 (0x10000001EDC1A3B0);
            // 0x028ED6D4: BL #0x299a140              | 
            // 0x028ED6D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_34:
            // 0x028ED6DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED6E0: BL #0x1101f40              | X0 = 0.get_ILMethod();                  
            ILRuntime.CLR.Method.ILMethod val_26 = 0.ILMethod;
            // 0x028ED6E4: MOV x24, x0                | X24 = val_26;//m1                       
            // 0x028ED6E8: CBNZ x22, #0x28ed6f0       | if (X1 != 0) goto label_35;             
            if(X1 != 0)
            {
                goto label_35;
            }
            // 0x028ED6EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_35:
            // 0x028ED6F0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ED6F4: ADD x3, sp, #7             | X3 = (1152921512890704784 + 7) = 1152921512890704791 (0x10000001EDC1A397);
            // 0x028ED6F8: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028ED6FC: MOV x1, x24                | X1 = val_26;//m1                        
            // 0x028ED700: MOV x2, x21                | X2 = val_18;//m1                        
            // 0x028ED704: BL #0x1f65d90              | X0 = X1.Execute(method:  val_26, esp:  null, unhandledException: out  bool val_27 = false);
            ILRuntime.Runtime.Stack.StackObject* val_28 = X1.Execute(method:  val_26, esp:  null, unhandledException: out  bool val_27 = false);
            // 0x028ED708: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x028ED70C: LDR x1, [x28]              | X1 = typeof(ILRuntime.Reflection.ILRuntimeMethodInfo);
            // 0x028ED710: MOV x24, x0                | X24 = val_28;//m1                       
            // 0x028ED714: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED718: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED71C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED720: B.LO #0x28ed9b8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) goto label_37;
            // 0x028ED724: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED728: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo._
            // 0x028ED72C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED730: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeMethodInfo))
            // 0x028ED734: B.NE #0x28ed9b8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeMethodInfo.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_37;
            // 0x028ED738: LDR x8, [x23]              | X8 = typeof(System.Object);             
            // 0x028ED73C: MOV x0, x23                | X0 = val_10;//m1                        
            // 0x028ED740: LDR x9, [x8, #0x380]       | X9 = typeof(System.Object).__il2cppRuntimeField_380;
            // 0x028ED744: LDR x1, [x8, #0x388]       | X1 = typeof(System.Object).__il2cppRuntimeField_388;
            // 0x028ED748: BLR x9                     | X0 = typeof(System.Object).__il2cppRuntimeField_380();
            // 0x028ED74C: MOV x22, x0                | X22 = val_10;//m1                       
            val_53 = val_48;
            // 0x028ED750: CBNZ x20, #0x28ed758       | if (val_1 != null) goto label_38;       
            if(val_1 != null)
            {
                goto label_38;
            }
            // 0x028ED754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_38:
            // 0x028ED758: LDR x8, [x20, #0x88]       | X8 = val_1.voidType; //P2               
            // 0x028ED75C: CMP x22, x8                | STATE = COMPARE(val_10, val_1.voidType) 
            // 0x028ED760: B.EQ #0x28ed52c            | if (val_53 == val_1.voidType) goto label_43;
            if(val_53 == val_1.voidType)
            {
                goto label_43;
            }
            // 0x028ED764: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028ED768: LDRB w8, [x0, #0x109]      | W8 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028ED76C: TBNZ w8, #0, #0x28ed778    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_40;
            // 0x028ED770: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_54 = 8;
            // 0x028ED774: B #0x28ed780               |  goto label_41;                         
            goto label_41;
            label_40:
            // 0x028ED778: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028ED77C: SUB w8, w0, #0x10          | W8 = (null - 16) = val_54 (0x100000000D137FF0);
            val_54 = 1152921504826228720;
            label_41:
            // 0x028ED780: SUBS x21, x24, w8, sxtw    | X21 = (val_28 - (val_54) << );          
            ILRuntime.Runtime.Stack.StackObject* val_30 = val_28 - (val_54 << );
            // 0x028ED784: B.NE #0x28ed78c            | if (val_53 != val_1.voidType) goto label_42;
            if(val_53 != val_1.voidType)
            {
                goto label_42;
            }
            // 0x028ED788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_42:
            // 0x028ED78C: LDR w8, [x21]              | W8 = (val_28 - (val_54) << );           
            // 0x028ED790: CMP w8, #8                 | STATE = COMPARE((val_28 - (val_54) << ), 0x8)
            // 0x028ED794: B.GT #0x28ed52c            | if (val_30 > 0x8) goto label_43;        
            if(val_30 > 8)
            {
                goto label_43;
            }
            // 0x028ED798: CBZ x22, #0x28ed88c        | if (val_10 == null) goto label_44;      
            if(val_53 == null)
            {
                goto label_44;
            }
            // 0x028ED79C: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x028ED7A0: LDR x9, [x9, #0xc30]       | X9 = 1152921504821649408;               
            // 0x028ED7A4: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028ED7A8: LDR x1, [x9]               | X1 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x028ED7AC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED7B0: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED7B4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED7B8: B.LO #0x28ed850            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_46;
            // 0x028ED7BC: LDR x8, [x8, #0xb0]        | X8 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED7C0: ADD x8, x8, x9, lsl #3     | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.
            // 0x028ED7C4: LDUR x8, [x8, #-8]         | X8 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED7C8: CMP x8, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028ED7CC: B.NE #0x28ed850            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_46;
            // 0x028ED7D0: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x028ED7D4: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED7D8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED7DC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED7E0: B.LO #0x28ed7f8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_47;
            // 0x028ED7E4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED7E8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.
            // 0x028ED7EC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED7F0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028ED7F4: B.EQ #0x28ed820            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_48;
            label_47:
            // 0x028ED7F8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED7FC: ADD x8, sp, #0x30          | X8 = (1152921512890704784 + 48) = 1152921512890704832 (0x10000001EDC1A3C0);
            // 0x028ED800: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED804: LDR x0, [sp, #0x30]        | X0 = val_32;                             //  find_add[1152921512890692960]
            // 0x028ED808: BL #0x27af090              | X0 = sub_27AF090( ?? val_32, ????);     
            // 0x028ED80C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED810: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            // 0x028ED814: ADD x0, sp, #0x30          | X0 = (1152921512890704784 + 48) = 1152921512890704832 (0x10000001EDC1A3C0);
            // 0x028ED818: BL #0x299a140              | 
            // 0x028ED81C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_55 = 0;
            label_48:
            // 0x028ED820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED824: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028ED828: BL #0x1105520              | X0 = val_55.get_CLRType();              
            ILRuntime.CLR.TypeSystem.CLRType val_33 = val_55.CLRType;
            // 0x028ED82C: MOV x22, x0                | X22 = val_33;//m1                       
            // 0x028ED830: CBNZ x22, #0x28ed838       | if (val_33 != null) goto label_49;      
            if(val_33 != null)
            {
                goto label_49;
            }
            // 0x028ED834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_49:
            // 0x028ED838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED83C: MOV x0, x22                | X0 = val_33;//m1                        
            // 0x028ED840: BL #0x10ee250              | X0 = val_33.get_TypeForCLR();           
            System.Type val_34 = val_33.TypeForCLR;
            // 0x028ED844: MOV x22, x0                | X22 = val_34;//m1                       
            val_56 = val_34;
            // 0x028ED848: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_57 = 0;
            // 0x028ED84C: CBZ x22, #0x28ed90c        | if (val_34 == null) goto label_54;      
            if(val_56 == null)
            {
                goto label_54;
            }
            label_46:
            // 0x028ED850: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x028ED854: LDR x9, [x9, #0x950]       | X9 = 1152921504821596160;               
            // 0x028ED858: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x028ED85C: LDR x1, [x9]               | X1 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028ED860: LDRB w10, [x8, #0x104]     | W10 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED864: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED868: CMP w10, w9                | STATE = COMPARE(System.Type.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED86C: B.LO #0x28ed884            | if (System.Type.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_51;
            // 0x028ED870: LDR x8, [x8, #0xb0]        | X8 = System.Type.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED874: ADD x8, x8, x9, lsl #3     | X8 = (System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppR
            // 0x028ED878: LDUR x8, [x8, #-8]         | X8 = (System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED87C: CMP x8, x1                 | STATE = COMPARE((System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028ED880: B.EQ #0x28ed894            | if ((System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_52;
            label_51:
            // 0x028ED884: MOV x23, x22               | X23 = val_34;//m1                       
            val_57 = val_56;
            // 0x028ED888: B #0x28ed90c               |  goto label_54;                         
            goto label_54;
            label_44:
            // 0x028ED88C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_57 = 0;
            // 0x028ED890: B #0x28ed90c               |  goto label_54;                         
            goto label_54;
            label_52:
            // 0x028ED894: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x028ED898: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED89C: LDRB w10, [x8, #0x104]     | W10 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028ED8A0: CMP w10, w9                | STATE = COMPARE(System.Type.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028ED8A4: B.LO #0x28ed8bc            | if (System.Type.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_55;
            // 0x028ED8A8: LDR x10, [x8, #0xb0]       | X10 = System.Type.__il2cppRuntimeField_typeHierarchy;
            // 0x028ED8AC: ADD x9, x10, x9, lsl #3    | X9 = (System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppR
            // 0x028ED8B0: LDUR x9, [x9, #-8]         | X9 = (System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028ED8B4: CMP x9, x1                 | STATE = COMPARE((System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028ED8B8: B.EQ #0x28ed8e4            | if ((System.Type.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_56;
            label_55:
            // 0x028ED8BC: LDR x0, [x8, #0x30]        | X0 = System.Type.__il2cppRuntimeField_element_class;
            // 0x028ED8C0: ADD x8, sp, #0x38          | X8 = (1152921512890704784 + 56) = 1152921512890704840 (0x10000001EDC1A3C8);
            // 0x028ED8C4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Type.__il2cppRuntimeField_element_class, ????);
            // 0x028ED8C8: LDR x0, [sp, #0x38]        | X0 = val_36;                             //  find_add[1152921512890692960]
            // 0x028ED8CC: BL #0x27af090              | X0 = sub_27AF090( ?? val_36, ????);     
            // 0x028ED8D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED8D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_36, ????);     
            // 0x028ED8D8: ADD x0, sp, #0x38          | X0 = (1152921512890704784 + 56) = 1152921512890704840 (0x10000001EDC1A3C8);
            // 0x028ED8DC: BL #0x299a140              | 
            // 0x028ED8E0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_56 = 0;
            label_56:
            // 0x028ED8E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED8E8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028ED8EC: BL #0x1100c9c              | X0 = val_56.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_37 = val_56.ILType;
            // 0x028ED8F0: MOV x22, x0                | X22 = val_37;//m1                       
            // 0x028ED8F4: CBNZ x22, #0x28ed8fc       | if (val_37 != null) goto label_57;      
            if(val_37 != null)
            {
                goto label_57;
            }
            // 0x028ED8F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_57:
            // 0x028ED8FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED900: MOV x0, x22                | X0 = val_37;//m1                        
            // 0x028ED904: BL #0x10faa2c              | X0 = val_37.get_TypeForCLR();           
            System.Type val_38 = val_37.TypeForCLR;
            // 0x028ED908: MOV x23, x0                | X23 = val_38;//m1                       
            val_57 = val_38;
            label_54:
            // 0x028ED90C: LDR x0, [x27]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028ED910: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028ED914: TBZ w8, #0, #0x28ed924     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_59;
            // 0x028ED918: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028ED91C: CBNZ w8, #0x28ed924        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_59;
            // 0x028ED920: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_59:
            // 0x028ED924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED928: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028ED92C: MOV x1, x21                | X1 = (val_28 - (val_54) << );//m1       
            // 0x028ED930: MOV x2, x20                | X2 = val_1;//m1                         
            // 0x028ED934: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028ED938: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_39 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028ED93C: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028ED940: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028ED944: MOV x20, x0                | X20 = val_39;//m1                       
            // 0x028ED948: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028ED94C: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028ED950: TBZ w9, #0, #0x28ed964     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_61;
            // 0x028ED954: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028ED958: CBNZ w9, #0x28ed964        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x028ED95C: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028ED960: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_61:
            // 0x028ED964: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED968: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028ED96C: MOV x1, x23                | X1 = val_38;//m1                        
            // 0x028ED970: MOV x2, x20                | X2 = val_39;//m1                        
            // 0x028ED974: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_57);
            object val_40 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_57);
            // 0x028ED978: MOV x3, x0                 | X3 = val_40;//m1                        
            // 0x028ED97C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028ED980: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028ED984: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028ED988: MOV x1, x21                | X1 = (val_28 - (val_54) << );//m1       
            // 0x028ED98C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028ED990: B #0x28ed524               |  goto label_62;                         
            goto label_62;
            // 0x028ED994: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            val_58 = 0;
            // 0x028ED998: ADD x0, sp, #0x48          | X0 = (1152921512890704784 + 72) = 1152921512890704856 (0x10000001EDC1A3D8);
            // 0x028ED99C: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            // 0x028ED9A0: MOV x19, x0                | X19 = 1152921512890704856 (0x10000001EDC1A3D8);//ML01
            val_58;
            // 0x028ED9A4: ADD x0, sp, #0x40          | X0 = (1152921512890704784 + 64) = 1152921512890704848 (0x10000001EDC1A3D0);
            // 0x028ED9A8: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            // 0x028ED9AC: MOV x19, x0                | X19 = 1152921512890704848 (0x10000001EDC1A3D0);//ML01
            val_58;
            // 0x028ED9B0: ADD x0, sp, #8             | X0 = (1152921512890704784 + 8) = 1152921512890704792 (0x10000001EDC1A398);
            // 0x028ED9B4: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            label_37:
            // 0x028ED9B8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028ED9BC: ADD x8, sp, #0x28          | X8 = (1152921512890704784 + 40) = 1152921512890704824 (0x10000001EDC1A3B8);
            // 0x028ED9C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028ED9C4: LDR x0, [sp, #0x28]        | X0 = val_41;                             //  find_add[1152921512890692960]
            // 0x028ED9C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_41, ????);     
            // 0x028ED9CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028ED9D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_41, ????);     
            // 0x028ED9D4: ADD x0, sp, #0x28          | X0 = (1152921512890704784 + 40) = 1152921512890704824 (0x10000001EDC1A3B8);
            // 0x028ED9D8: BL #0x299a140              | 
            // 0x028ED9DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDC1A3B8, ????);
            // 0x028ED9E0: MOV x19, x0                | X19 = 1152921512890704824 (0x10000001EDC1A3B8);//ML01
            val_58;
            // 0x028ED9E4: ADD x0, sp, #0x18          | X0 = (1152921512890704784 + 24) = 1152921512890704808 (0x10000001EDC1A3A8);
            // 0x028ED9E8: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            // 0x028ED9EC: MOV x19, x0                | X19 = 1152921512890704808 (0x10000001EDC1A3A8);//ML01
            val_58;
            // 0x028ED9F0: ADD x0, sp, #0x20          | X0 = (1152921512890704784 + 32) = 1152921512890704816 (0x10000001EDC1A3B0);
            // 0x028ED9F4: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            // 0x028ED9F8: MOV x19, x0                | X19 = 1152921512890704816 (0x10000001EDC1A3B0);//ML01
            val_58;
            // 0x028ED9FC: ADD x0, sp, #0x10          | X0 = (1152921512890704784 + 16) = 1152921512890704800 (0x10000001EDC1A3A0);
            label_70:
            // 0x028EDA00: BL #0x299a140              | 
            // 0x028EDA04: MOV x0, x19                | X0 = 1152921512890704816 (0x10000001EDC1A3B0);//ML01
            // 0x028EDA08: BL #0x980800               | X0 = sub_980800( ?? 0x10000001EDC1A3B0, ????);
            // 0x028EDA0C: MOV x19, x0                | X19 = 1152921512890704816 (0x10000001EDC1A3B0);//ML01
            // 0x028EDA10: ADD x0, sp, #0x30          | X0 = (1152921512890704784 + 48) = 1152921512890704832 (0x10000001EDC1A3C0);
            // 0x028EDA14: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            // 0x028EDA18: MOV x19, x0                | X19 = 1152921512890704832 (0x10000001EDC1A3C0);//ML01
            // 0x028EDA1C: ADD x0, sp, #0x38          | X0 = (1152921512890704784 + 56) = 1152921512890704840 (0x10000001EDC1A3C8);
            // 0x028EDA20: B #0x28eda00               |  goto label_70;                         
            goto label_70;
            // 0x028EDA24: MOV x19, x0                | X19 = 1152921512890704840 (0x10000001EDC1A3C8);//ML01
            // 0x028EDA28: ADD x0, sp, #0x28          | X0 = (1152921512890704784 + 40) = 1152921512890704824 (0x10000001EDC1A3B8);
            // 0x028EDA2C: B #0x28eda00               |  goto label_70;                         
            goto label_70;
        
        }
        //
        // Offset in libil2cpp.so: 0x028EDA30 (42916400), len: 396  VirtAddr: 0x028EDA30 RVA: 0x028EDA30 token: 100680279 methodIndex: 29567 delegateWrapperIndex: 0 methodInvoker: 0
        private static object CheckCrossBindingAdapter(object obj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028EDA30: STP x22, x21, [sp, #-0x30]! | stack[1152921512890894736] = ???;  stack[1152921512890894744] = ???;  //  dest_result_addr=1152921512890894736 |  dest_result_addr=1152921512890894744
            // 0x028EDA34: STP x20, x19, [sp, #0x10]  | stack[1152921512890894752] = ???;  stack[1152921512890894760] = ???;  //  dest_result_addr=1152921512890894752 |  dest_result_addr=1152921512890894760
            // 0x028EDA38: STP x29, x30, [sp, #0x20]  | stack[1152921512890894768] = ???;  stack[1152921512890894776] = ???;  //  dest_result_addr=1152921512890894768 |  dest_result_addr=1152921512890894776
            // 0x028EDA3C: ADD x29, sp, #0x20         | X29 = (1152921512890894736 + 32) = 1152921512890894768 (0x10000001EDC489B0);
            // 0x028EDA40: SUB sp, sp, #0x10          | SP = (1152921512890894736 - 16) = 1152921512890894720 (0x10000001EDC48980);
            // 0x028EDA44: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028EDA48: LDRB w8, [x19, #0xa06]     | W8 = (bool)static_value_037B8A06;       
            // 0x028EDA4C: MOV x20, x1                | X20 = X1;//m1                           
            val_5 = X1;
            // 0x028EDA50: TBNZ w8, #0, #0x28eda6c    | if (static_value_037B8A06 == true) goto label_0;
            // 0x028EDA54: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
            // 0x028EDA58: LDR x8, [x8, #0x780]       | X8 = 0x2B90CB4;                         
            // 0x028EDA5C: LDR w0, [x8]               | W0 = 0x19F1;                            
            // 0x028EDA60: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F1, ????);     
            // 0x028EDA64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EDA68: STRB w8, [x19, #0xa06]     | static_value_037B8A06 = true;            //  dest_result_addr=58427910
            label_0:
            // 0x028EDA6C: ADRP x21, #0x365d000       | X21 = 57004032 (0x365D000);             
            // 0x028EDA70: LDR x21, [x21, #0xa58]     | X21 = 1152921504824418304;              
            val_6 = 1152921504824418304;
            // 0x028EDA74: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EDA78: LDR x1, [x21]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_7 = null;
            // 0x028EDA7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x028EDA80: CBZ x0, #0x28edb84         | if (X1 == 0) goto label_1;              
            if(val_5 == 0)
            {
                goto label_1;
            }
            // 0x028EDA84: CBZ x20, #0x28edb14        | if (X1 == 0) goto label_2;              
            if(val_5 == 0)
            {
                goto label_2;
            }
            // 0x028EDA88: LDR x19, [x21]             | X19 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x028EDA8C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EDA90: MOV x1, x19                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028EDA94: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x028EDA98: CBNZ x0, #0x28edacc        | if (X1 != 0) goto label_3;              
            if(val_5 != 0)
            {
                goto label_3;
            }
            // 0x028EDA9C: LDR x8, [x20]              | X8 = X1;                                
            // 0x028EDAA0: MOV x1, x19                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028EDAA4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028EDAA8: MOV x8, sp                 | X8 = 1152921512890894720 (0x10000001EDC48980);//ML01
            // 0x028EDAAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028EDAB0: LDR x0, [sp]               | X0 = val_1;                              //  find_add[1152921512890882784]
            // 0x028EDAB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x028EDAB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDABC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x028EDAC0: MOV x0, sp                 | X0 = 1152921512890894720 (0x10000001EDC48980);//ML01
            // 0x028EDAC4: BL #0x299a140              | 
            // 0x028EDAC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDC48980, ????);
            label_3:
            // 0x028EDACC: LDR x19, [x21]             | X19 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_4 = null;
            // 0x028EDAD0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EDAD4: MOV x1, x19                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_7 = val_4;
            // 0x028EDAD8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X1, ????);         
            // 0x028EDADC: MOV x21, x0                | X21 = X1;//m1                           
            val_6 = val_5;
            // 0x028EDAE0: CBNZ x21, #0x28edb20       | if (X1 != 0) goto label_4;              
            if(val_6 != 0)
            {
                goto label_4;
            }
            // 0x028EDAE4: LDR x8, [x20]              | X8 = X1;                                
            // 0x028EDAE8: MOV x1, x19                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028EDAEC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028EDAF0: ADD x8, sp, #8             | X8 = (1152921512890894720 + 8) = 1152921512890894728 (0x10000001EDC48988);
            // 0x028EDAF4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028EDAF8: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921512890882784]
            // 0x028EDAFC: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028EDB00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_7 = 0;
            // 0x028EDB04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028EDB08: ADD x0, sp, #8             | X0 = (1152921512890894720 + 8) = 1152921512890894728 (0x10000001EDC48988);
            // 0x028EDB0C: BL #0x299a140              | 
            // 0x028EDB10: B #0x28edb1c               |  goto label_5;                          
            goto label_5;
            label_2:
            // 0x028EDB14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            // 0x028EDB18: LDR x19, [x21]             | X19 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_4 = null;
            label_5:
            // 0x028EDB1C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_4:
            // 0x028EDB20: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
            // 0x028EDB24: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028EDB28: CBZ x9, #0x28edb54         | if (mem[282584257676929] == 0) goto label_6;
            if(mem[282584257676929] == 0)
            {
                goto label_6;
            }
            // 0x028EDB2C: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_3 = mem[282584257676823];
            // 0x028EDB30: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x028EDB34: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_3 = val_3 + 8;
            label_8:
            // 0x028EDB38: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028EDB3C: CMP x12, x19               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x028EDB40: B.EQ #0x28edb68            | if ((mem[282584257676823] + 8) + -8 == val_4) goto label_7;
            if(((mem[282584257676823] + 8) + -8) == val_4)
            {
                goto label_7;
            }
            // 0x028EDB44: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x028EDB48: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_3 = val_3 + 16;
            // 0x028EDB4C: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028EDB50: B.LO #0x28edb38            | if (0 < mem[282584257676929]) goto label_8;
            if(val_4 < mem[282584257676929])
            {
                goto label_8;
            }
            label_6:
            // 0x028EDB54: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028EDB58: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            val_8 = val_6;
            // 0x028EDB5C: MOV x1, x19                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_7 = val_4;
            // 0x028EDB60: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028EDB64: B #0x28edb74               |  goto label_9;                          
            goto label_9;
            label_7:
            // 0x028EDB68: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x028EDB6C: ADD x8, x8, x9, lsl #4     | X8 = (val_6 + ((mem[282584257676823] + 8)) << 4);
            val_6 = val_6 + (((mem[282584257676823] + 8)) << 4);
            // 0x028EDB70: ADD x0, x8, #0x110         | X0 = ((val_6 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_8 = val_6 + 272;
            label_9:
            // 0x028EDB74: LDP x8, x1, [x0]           | X8 = ((val_6 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_6 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x028EDB78: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028EDB7C: BLR x8                     | X0 = ((val_6 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x028EDB80: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            val_5 = val_6;
            label_1:
            // 0x028EDB84: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x028EDB88: SUB sp, x29, #0x20         | SP = (1152921512890894768 - 32) = 1152921512890894736 (0x10000001EDC48990);
            // 0x028EDB8C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EDB90: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EDB94: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EDB98: RET                        |  return (System.Object)null;            
            return (object)val_5;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x028EDB9C: MOV x19, x0                | 
            // 0x028EDBA0: MOV x0, sp                 | 
            // 0x028EDBA4: B #0x28edbb0               | 
            // 0x028EDBA8: MOV x19, x0                | 
            // 0x028EDBAC: ADD x0, sp, #8             | 
            label_10:
            // 0x028EDBB0: BL #0x299a140              | 
            // 0x028EDBB4: MOV x0, x19                | 
            // 0x028EDBB8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028EDBBC (42916796), len: 780  VirtAddr: 0x028EDBBC RVA: 0x028EDBBC token: 100680280 methodIndex: 29568 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* ObjectGetType(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x028EDBBC: STP x24, x23, [sp, #-0x40]! | stack[1152921512891051776] = ???;  stack[1152921512891051784] = ???;  //  dest_result_addr=1152921512891051776 |  dest_result_addr=1152921512891051784
            // 0x028EDBC0: STP x22, x21, [sp, #0x10]  | stack[1152921512891051792] = ???;  stack[1152921512891051800] = ???;  //  dest_result_addr=1152921512891051792 |  dest_result_addr=1152921512891051800
            // 0x028EDBC4: STP x20, x19, [sp, #0x20]  | stack[1152921512891051808] = ???;  stack[1152921512891051816] = ???;  //  dest_result_addr=1152921512891051808 |  dest_result_addr=1152921512891051816
            // 0x028EDBC8: STP x29, x30, [sp, #0x30]  | stack[1152921512891051824] = ???;  stack[1152921512891051832] = ???;  //  dest_result_addr=1152921512891051824 |  dest_result_addr=1152921512891051832
            // 0x028EDBCC: ADD x29, sp, #0x30         | X29 = (1152921512891051776 + 48) = 1152921512891051824 (0x10000001EDC6EF30);
            // 0x028EDBD0: SUB sp, sp, #0x10          | SP = (1152921512891051776 - 16) = 1152921512891051760 (0x10000001EDC6EEF0);
            // 0x028EDBD4: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028EDBD8: LDRB w8, [x21, #0xa07]     | W8 = (bool)static_value_037B8A07;       
            // 0x028EDBDC: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EDBE0: MOV x20, x2                | X20 = X2;//m1                           
            var val_14 = X2;
            // 0x028EDBE4: MOV x22, x1                | X22 = X1;//m1                           
            // 0x028EDBE8: TBNZ w8, #0, #0x28edc04    | if (static_value_037B8A07 == true) goto label_0;
            // 0x028EDBEC: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x028EDBF0: LDR x8, [x8, #0x688]       | X8 = 0x2B90CF4;                         
            // 0x028EDBF4: LDR w0, [x8]               | W0 = 0x1A01;                            
            // 0x028EDBF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A01, ????);     
            // 0x028EDBFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EDC00: STRB w8, [x21, #0xa07]     | static_value_037B8A07 = true;            //  dest_result_addr=58427911
            label_0:
            // 0x028EDC04: CBNZ x22, #0x28edc0c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028EDC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A01, ????);     
            label_1:
            // 0x028EDC0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDC10: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EDC14: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EDC18: ADRP x23, #0x366f000       | X23 = 57077760 (0x366F000);             
            // 0x028EDC1C: LDR x23, [x23, #0x7a0]     | X23 = 1152921504826228736;              
            // 0x028EDC20: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028EDC24: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_14 = null;
            // 0x028EDC28: ADD x9, x8, #0x109         | X9 = (val_14 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDC2C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EDC30: TBNZ w9, #0, #0x28edc3c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_2;
            // 0x028EDC34: ORR w24, wzr, #8           | W24 = 8(0x8);                           
            val_16 = 8;
            // 0x028EDC38: B #0x28edc54               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x028EDC3C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDC40: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EDC44: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_14 = null;
            // 0x028EDC48: SUB w24, w0, #0x10         | W24 = (val_14 - 16) = val_16 (0x100000000D137FF0);
            val_16 = 1152921504826228720;
            // 0x028EDC4C: ADD x9, x8, #0x109         | X9 = (val_14 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDC50: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_3:
            // 0x028EDC54: TBNZ w9, #0, #0x28edc60    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_4;
            // 0x028EDC58: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_17 = 8;
            // 0x028EDC5C: B #0x28edc78               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x028EDC60: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDC64: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EDC68: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_14 = null;
            // 0x028EDC6C: SUB w10, w0, #0x10         | W10 = (val_14 - 16) = val_17 (0x100000000D137FF0);
            val_17 = 1152921504826228720;
            // 0x028EDC70: ADD x9, x8, #0x109         | X9 = (val_14 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDC74: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_5:
            // 0x028EDC78: SUB x23, x20, w10, sxtw    | X23 = (X2 - (val_17) << );              
            var val_2 = val_14 - (val_17 << );
            // 0x028EDC7C: TBZ w9, #8, #0x28edc90     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_7;
            // 0x028EDC80: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EDC84: CBNZ w9, #0x28edc90        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028EDC88: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDC8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x028EDC90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EDC94: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EDC98: MOV x1, x23                | X1 = (X2 - (val_17) << );//m1           
            // 0x028EDC9C: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x028EDCA0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EDCA4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028EDCA8: MOV x21, x0                | X21 = val_3;//m1                        
            val_18 = val_3;
            // 0x028EDCAC: CBNZ x22, #0x28edcb4       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x028EDCB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_8:
            // 0x028EDCB4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EDCB8: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EDCBC: MOV x1, x23                | X1 = (X2 - (val_17) << );//m1           
            // 0x028EDCC0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EDCC4: CBNZ x21, #0x28edccc       | if (val_3 != null) goto label_9;        
            if(val_18 != null)
            {
                goto label_9;
            }
            // 0x028EDCC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_9:
            // 0x028EDCCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDCD0: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x028EDCD4: SUB x20, x20, w24, sxtw    | X20 = (X2 - (val_16) << );              
            val_14 = val_14 - (val_16 << );
            // 0x028EDCD8: BL #0x16fb28c              | X0 = val_3.GetType();                   
            System.Type val_4 = val_18.GetType();
            // 0x028EDCDC: ADRP x24, #0x3620000       | X24 = 56754176 (0x3620000);             
            // 0x028EDCE0: LDR x24, [x24, #0x340]     | X24 = 1152921504609562624;              
            // 0x028EDCE4: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x028EDCE8: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x028EDCEC: LDR x8, [x24]              | X8 = typeof(System.Type);               
            // 0x028EDCF0: LDR x9, [x9, #0xd20]       | X9 = 1152921504825909248;               
            // 0x028EDCF4: LDR x23, [x9]              | X23 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            val_19 = null;
            // 0x028EDCF8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028EDCFC: TBZ w9, #0, #0x28edd10     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x028EDD00: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028EDD04: CBNZ w9, #0x28edd10        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x028EDD08: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028EDD0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_11:
            // 0x028EDD10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EDD14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EDD18: MOV x1, x23                | X1 = 1152921504825909248 (0x100000000D0EA000);//ML01
            // 0x028EDD1C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028EDD20: CMP x22, x0                | STATE = COMPARE(val_4, val_5)           
            // 0x028EDD24: B.EQ #0x28edd94            | if (val_4 == val_5) goto label_15;      
            if(val_4 == val_5)
            {
                goto label_15;
            }
            // 0x028EDD28: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EDD2C: LDR x0, [x24]              | X0 = typeof(System.Type);               
            // 0x028EDD30: LDR x8, [x8, #0xb78]       | X8 = 1152921504825856000;               
            // 0x028EDD34: LDR x23, [x8]              | X23 = typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance);
            val_19 = null;
            // 0x028EDD38: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028EDD3C: TBZ w8, #0, #0x28edd4c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x028EDD40: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028EDD44: CBNZ w8, #0x28edd4c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x028EDD48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_14:
            // 0x028EDD4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EDD50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EDD54: MOV x1, x23                | X1 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EDD58: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028EDD5C: CMP x22, x0                | STATE = COMPARE(val_4, val_6)           
            // 0x028EDD60: B.EQ #0x28edd94            | if (val_4 == val_6) goto label_15;      
            if(val_4 == val_6)
            {
                goto label_15;
            }
            // 0x028EDD64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EDD68: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EDD6C: MOV x1, x20                | X1 = (X2 - (val_16) << );//m1           
            // 0x028EDD70: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EDD74: MOV x3, x22                | X3 = val_4;//m1                         
            // 0x028EDD78: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EDD7C: SUB sp, x29, #0x30         | SP = (1152921512891051824 - 48) = 1152921512891051776 (0x10000001EDC6EF00);
            // 0x028EDD80: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028EDD84: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028EDD88: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028EDD8C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028EDD90: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  esp, mStack:  mStack, obj:  method, isBox:  isNewObj);
            label_15:
            // 0x028EDD94: CBZ x21, #0x28ede48        | if (val_3 == null) goto label_16;       
            if(val_18 == null)
            {
                goto label_16;
            }
            // 0x028EDD98: ADRP x22, #0x35dd000       | X22 = 56479744 (0x35DD000);             
            // 0x028EDD9C: LDR x22, [x22, #0xb50]     | X22 = 1152921504825909248;              
            // 0x028EDDA0: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EDDA4: LDR x1, [x22]              | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x028EDDA8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EDDAC: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EDDB0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EDDB4: B.LO #0x28eddcc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x028EDDB8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EDDBC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstanc
            // 0x028EDDC0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EDDC4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x028EDDC8: B.EQ #0x28eddf4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_18;
            label_17:
            // 0x028EDDCC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EDDD0: ADD x8, sp, #8             | X8 = (1152921512891051760 + 8) = 1152921512891051768 (0x10000001EDC6EEF8);
            // 0x028EDDD4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EDDD8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921512891039840]
            // 0x028EDDDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028EDDE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDDE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028EDDE8: ADD x0, sp, #8             | X0 = (1152921512891051760 + 8) = 1152921512891051768 (0x10000001EDC6EEF8);
            // 0x028EDDEC: BL #0x299a140              | 
            // 0x028EDDF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDC6EEF8, ????);
            label_18:
            // 0x028EDDF4: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x028EDDF8: LDR x1, [x22]              | X1 = typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance);
            // 0x028EDDFC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EDE00: LDRB w9, [x1, #0x104]      | W9 = ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EDE04: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EDE08: B.LO #0x28ede20            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_19;
            // 0x028EDE0C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EDE10: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstanc
            // 0x028EDE14: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EDE18: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILTypeInstance))
            // 0x028EDE1C: B.EQ #0x28ede50            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_20;
            label_19:
            // 0x028EDE20: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EDE24: MOV x8, sp                 | X8 = 1152921512891051760 (0x10000001EDC6EEF0);//ML01
            // 0x028EDE28: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EDE2C: LDR x0, [sp]               | X0 = val_10;                             //  find_add[1152921512891039840]
            // 0x028EDE30: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x028EDE34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDE38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x028EDE3C: MOV x0, sp                 | X0 = 1152921512891051760 (0x10000001EDC6EEF0);//ML01
            // 0x028EDE40: BL #0x299a140              | 
            // 0x028EDE44: B #0x28ede4c               |  goto label_21;                         
            goto label_21;
            label_16:
            // 0x028EDE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_21:
            // 0x028EDE4C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_20:
            // 0x028EDE50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDE54: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x028EDE58: BL #0x1f95a54              | X0 = val_18.get_Type();                 
            ILRuntime.CLR.TypeSystem.ILType val_11 = val_18.Type;
            // 0x028EDE5C: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x028EDE60: CBNZ x21, #0x28ede68       | if (val_11 != null) goto label_22;      
            if(val_11 != null)
            {
                goto label_22;
            }
            // 0x028EDE64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_22:
            // 0x028EDE68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDE6C: MOV x0, x21                | X0 = val_11;//m1                        
            // 0x028EDE70: BL #0x10faf48              | X0 = val_11.get_ReflectionType();       
            System.Type val_12 = val_11.ReflectionType;
            // 0x028EDE74: MOV x3, x0                 | X3 = val_12;//m1                        
            // 0x028EDE78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EDE7C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028EDE80: MOV x1, x20                | X1 = (X2 - (val_16) << );//m1           
            // 0x028EDE84: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EDE88: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EDE8C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028EDE90: SUB sp, x29, #0x30         | SP = (1152921512891051824 - 48) = 1152921512891051776 (0x10000001EDC6EF00);
            // 0x028EDE94: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028EDE98: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028EDE9C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028EDEA0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028EDEA4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_13;
            return val_13;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028EDEA8: MOV x19, x0                | 
            // 0x028EDEAC: ADD x0, sp, #8             | 
            // 0x028EDEB0: B #0x28edebc               | 
            // 0x028EDEB4: MOV x19, x0                | 
            // 0x028EDEB8: MOV x0, sp                 | 
            label_23:
            // 0x028EDEBC: BL #0x299a140              | 
            // 0x028EDEC0: MOV x0, x19                | 
            // 0x028EDEC4: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028EDEC8 (42917576), len: 1712  VirtAddr: 0x028EDEC8 RVA: 0x028EDEC8 token: 100680281 methodIndex: 29569 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* EnumParse(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_8;
            //  | 
            var val_28;
            //  | 
            var val_31;
            //  | 
            var val_32;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            int val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            string val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            // 0x028EDEC8: STP x28, x27, [sp, #-0x60]! | stack[1152921512891266256] = ???;  stack[1152921512891266264] = ???;  //  dest_result_addr=1152921512891266256 |  dest_result_addr=1152921512891266264
            // 0x028EDECC: STP x26, x25, [sp, #0x10]  | stack[1152921512891266272] = ???;  stack[1152921512891266280] = ???;  //  dest_result_addr=1152921512891266272 |  dest_result_addr=1152921512891266280
            // 0x028EDED0: STP x24, x23, [sp, #0x20]  | stack[1152921512891266288] = ???;  stack[1152921512891266296] = ???;  //  dest_result_addr=1152921512891266288 |  dest_result_addr=1152921512891266296
            // 0x028EDED4: STP x22, x21, [sp, #0x30]  | stack[1152921512891266304] = ???;  stack[1152921512891266312] = ???;  //  dest_result_addr=1152921512891266304 |  dest_result_addr=1152921512891266312
            // 0x028EDED8: STP x20, x19, [sp, #0x40]  | stack[1152921512891266320] = ???;  stack[1152921512891266328] = ???;  //  dest_result_addr=1152921512891266320 |  dest_result_addr=1152921512891266328
            // 0x028EDEDC: STP x29, x30, [sp, #0x50]  | stack[1152921512891266336] = ???;  stack[1152921512891266344] = ???;  //  dest_result_addr=1152921512891266336 |  dest_result_addr=1152921512891266344
            // 0x028EDEE0: ADD x29, sp, #0x50         | X29 = (1152921512891266256 + 80) = 1152921512891266336 (0x10000001EDCA3520);
            // 0x028EDEE4: SUB sp, sp, #0x30          | SP = (1152921512891266256 - 48) = 1152921512891266208 (0x10000001EDCA34A0);
            // 0x028EDEE8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028EDEEC: LDRB w8, [x21, #0xa08]     | W8 = (bool)static_value_037B8A08;       
            // 0x028EDEF0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EDEF4: MOV x20, x2                | X20 = X2;//m1                           
            var val_31 = X2;
            // 0x028EDEF8: MOV x22, x1                | X22 = X1;//m1                           
            // 0x028EDEFC: TBNZ w8, #0, #0x28edf18    | if (static_value_037B8A08 == true) goto label_0;
            // 0x028EDF00: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x028EDF04: LDR x8, [x8, #0x410]       | X8 = 0x2B90CE0;                         
            // 0x028EDF08: LDR w0, [x8]               | W0 = 0x19FC;                            
            // 0x028EDF0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x19FC, ????);     
            // 0x028EDF10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EDF14: STRB w8, [x21, #0xa08]     | static_value_037B8A08 = true;            //  dest_result_addr=58427912
            label_0:
            // 0x028EDF18: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x028EDF1C: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x028EDF20: STR wzr, [sp, #0x14]       | stack[1152921512891266228] = 0x0;        //  dest_result_addr=1152921512891266228
            // 0x028EDF24: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EDF28: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDF2C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EDF30: TBNZ w9, #0, #0x28edf3c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EDF34: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_32 = 8;
            // 0x028EDF38: B #0x28edf54               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EDF3C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDF40: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EDF44: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EDF48: SUB w25, w0, #0x10         | W25 = (null - 16) = val_32 (0x100000000D137FF0);
            val_32 = 1152921504826228720;
            // 0x028EDF4C: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDF50: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EDF54: TBNZ w9, #0, #0x28edf60    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EDF58: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_33 = 8;
            // 0x028EDF5C: B #0x28edf6c               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EDF60: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDF64: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EDF68: SUB w26, w0, #0x10         | W26 = (null - 16) = val_33 (0x100000000D137FF0);
            val_33 = 1152921504826228720;
            label_4:
            // 0x028EDF6C: CBNZ x22, #0x28edf74       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028EDF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EDF74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EDF78: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EDF7C: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EDF80: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_34 = null;
            // 0x028EDF84: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028EDF88: ADD x9, x8, #0x109         | X9 = (val_34 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDF8C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EDF90: TBNZ w9, #0, #0x28edf9c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028EDF94: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_36 = 8;
            // 0x028EDF98: B #0x28edfb4               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028EDF9C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDFA0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EDFA4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_34 = null;
            // 0x028EDFA8: SUB w10, w0, #0x10         | W10 = (val_34 - 16) = val_36 (0x100000000D137FF0);
            val_36 = 1152921504826228720;
            // 0x028EDFAC: ADD x9, x8, #0x109         | X9 = (val_34 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EDFB0: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_7:
            // 0x028EDFB4: SUB x24, x20, w10, sxtw    | X24 = (X2 - (val_36) << );              
            var val_2 = val_31 - (val_36 << );
            // 0x028EDFB8: TBZ w9, #8, #0x28edfcc     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_9;
            // 0x028EDFBC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EDFC0: CBNZ w9, #0x28edfcc        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x028EDFC4: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EDFC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028EDFCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EDFD0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EDFD4: MOV x1, x24                | X1 = (X2 - (val_36) << );//m1           
            // 0x028EDFD8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EDFDC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EDFE0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EDFE4: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
            // 0x028EDFE8: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
            val_37 = 1152921504608284672;
            // 0x028EDFEC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_38 = 0;
            // 0x028EDFF0: CBZ x0, #0x28ee030         | if (val_3 == null) goto label_11;       
            if(val_3 == null)
            {
                goto label_11;
            }
            // 0x028EDFF4: LDR x1, [x28]              | X1 = typeof(System.String);             
            // 0x028EDFF8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EDFFC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x028EE000: MOV x21, x0                | X21 = val_3;//m1                        
            val_38 = val_3;
            // 0x028EE004: B.EQ #0x28ee030            | if (typeof(System.Object) == null) goto label_11;
            if(null == null)
            {
                goto label_11;
            }
            // 0x028EE008: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EE00C: ADD x8, sp, #0x18          | X8 = (1152921512891266208 + 24) = 1152921512891266232 (0x10000001EDCA34B8);
            // 0x028EE010: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EE014: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921512891254352]
            // 0x028EE018: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028EE01C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE020: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028EE024: ADD x0, sp, #0x18          | X0 = (1152921512891266208 + 24) = 1152921512891266232 (0x10000001EDCA34B8);
            // 0x028EE028: BL #0x299a140              | 
            // 0x028EE02C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_38 = 0;
            label_11:
            // 0x028EE030: CBNZ x22, #0x28ee038       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x028EE034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDCA34B8, ????);
            label_12:
            // 0x028EE038: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE03C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EE040: MOV x1, x24                | X1 = (X2 - (val_36) << );//m1           
            // 0x028EE044: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EE048: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EE04C: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EE050: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EE054: TBNZ w9, #0, #0x28ee060    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_13;
            // 0x028EE058: ORR w24, wzr, #8           | W24 = 8(0x8);                           
            val_40 = 8;
            // 0x028EE05C: B #0x28ee078               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028EE060: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EE064: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EE068: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EE06C: SUB w24, w0, #0x10         | W24 = (null - 16) = val_40 (0x100000000D137FF0);
            val_40 = 1152921504826228720;
            // 0x028EE070: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EE074: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_14:
            // 0x028EE078: TBNZ w9, #0, #0x28ee084    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_15;
            // 0x028EE07C: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_41 = 8;
            // 0x028EE080: B #0x28ee090               |  goto label_16;                         
            goto label_16;
            label_15:
            // 0x028EE084: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EE088: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EE08C: SUB w8, w0, #0x10          | W8 = (null - 16) = val_41 (0x100000000D137FF0);
            val_41 = 1152921504826228720;
            label_16:
            // 0x028EE090: SUB x9, x20, w24, sxtw     | X9 = (X2 - (val_40) << );               
            var val_5 = val_31 - (val_40 << );
            // 0x028EE094: SUB x24, x9, w8, sxtw      | X24 = ((X2 - (val_40) << ) - (val_41) << );
            val_40 = val_5 - (val_41 << );
            // 0x028EE098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE09C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EE0A0: MOV x1, x24                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EE0A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EE0A8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EE0AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_6 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EE0B0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_42 = 0;
            // 0x028EE0B4: CBZ x0, #0x28ee118         | if (val_6 == null) goto label_19;       
            if(val_6 == null)
            {
                goto label_19;
            }
            // 0x028EE0B8: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x028EE0BC: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x028EE0C0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EE0C4: LDR x1, [x9]               | X1 = typeof(System.Type);               
            // 0x028EE0C8: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE0CC: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE0D0: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EE0D4: B.LO #0x28ee0f0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_18;
            // 0x028EE0D8: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EE0DC: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EE0E0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EE0E4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EE0E8: MOV x23, x0                | X23 = val_6;//m1                        
            val_42 = val_6;
            // 0x028EE0EC: B.EQ #0x28ee118            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_19;
            label_18:
            // 0x028EE0F0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EE0F4: ADD x8, sp, #0x20          | X8 = (1152921512891266208 + 32) = 1152921512891266240 (0x10000001EDCA34C0);
            // 0x028EE0F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EE0FC: LDR x0, [sp, #0x20]        | X0 = val_8;                              //  find_add[1152921512891254352]
            // 0x028EE100: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028EE104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE108: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028EE10C: ADD x0, sp, #0x20          | X0 = (1152921512891266208 + 32) = 1152921512891266240 (0x10000001EDCA34C0);
            // 0x028EE110: BL #0x299a140              | 
            // 0x028EE114: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_42 = 0;
            label_19:
            // 0x028EE118: SUB x8, x20, w25, sxtw     | X8 = (X2 - (val_32) << );               
            var val_9 = val_31 - (val_32 << );
            // 0x028EE11C: SUB x20, x8, w26, sxtw     | X20 = ((X2 - (val_32) << ) - (val_33) << );
            val_31 = val_9 - (val_33 << );
            // 0x028EE120: CBNZ x22, #0x28ee128       | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x028EE124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDCA34C0, ????);
            label_20:
            // 0x028EE128: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE12C: MOV x0, x22                | X0 = X1;//m1                            
            // 0x028EE130: MOV x1, x24                | X1 = ((X2 - (val_40) << ) - (val_41) << );//m1
            // 0x028EE134: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EE138: CBZ x23, #0x28ee19c        | if (0x0 == 0) goto label_24;            
            if(val_42 == 0)
            {
                goto label_24;
            }
            // 0x028EE13C: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x028EE140: LDR x9, [x9, #0x950]       | X9 = 1152921504821596160;               
            // 0x028EE144: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EE148: LDR x10, [x9]              | X10 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EE14C: LDRB w9, [x8, #0x104]      | W9 = (bool)mem[282584257676931];        
            // 0x028EE150: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE154: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EE158: B.LO #0x28ee170            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_22;
            // 0x028EE15C: LDR x12, [x8, #0xb0]       | X12 = mem[282584257676847];             
            // 0x028EE160: ADD x11, x12, x11, lsl #3  | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchy
            // 0x028EE164: LDUR x11, [x11, #-8]       | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EE168: CMP x11, x10               | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EE16C: B.EQ #0x28ee20c            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_23;
            label_22:
            // 0x028EE170: ADRP x10, #0x362d000       | X10 = 56807424 (0x362D000);             
            // 0x028EE174: LDR x10, [x10, #0xc30]     | X10 = 1152921504821649408;              
            // 0x028EE178: LDR x10, [x10]             | X10 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x028EE17C: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE180: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EE184: B.LO #0x28ee19c            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_24;
            // 0x028EE188: LDR x8, [x8, #0xb0]        | X8 = mem[282584257676847];              
            // 0x028EE18C: ADD x8, x8, x11, lsl #3    | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHie
            // 0x028EE190: LDUR x8, [x8, #-8]         | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EE194: CMP x8, x10                | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028EE198: B.EQ #0x28ee3f8            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_25;
            label_24:
            // 0x028EE19C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EE1A0: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EE1A4: LDR x0, [x8]               | X0 = typeof(System.Enum);               
            // 0x028EE1A8: LDRB w8, [x0, #0x10a]      | W8 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EE1AC: TBZ w8, #0, #0x28ee1bc     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x028EE1B0: LDR w8, [x0, #0xbc]        | W8 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EE1B4: CBNZ w8, #0x28ee1bc        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x028EE1B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_27:
            // 0x028EE1BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE1C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE1C4: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            label_52:
            // 0x028EE1C8: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x028EE1CC: BL #0x1c39ef0              | X0 = System.Enum.Parse(enumType:  0, value:  val_42);
            object val_11 = System.Enum.Parse(enumType:  0, value:  val_42);
            // 0x028EE1D0: MOV x3, x0                 | X3 = val_11;//m1                        
            // 0x028EE1D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE1D8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EE1DC: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EE1E0: MOV x1, x20                | X1 = ((X2 - (val_32) << ) - (val_33) << );//m1
            // 0x028EE1E4: MOV x2, x19                | X2 = X3;//m1                            
            label_54:
            // 0x028EE1E8: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            label_53:
            // 0x028EE1EC: SUB sp, x29, #0x50         | SP = (1152921512891266336 - 80) = 1152921512891266256 (0x10000001EDCA34D0);
            // 0x028EE1F0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EE1F4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EE1F8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EE1FC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EE200: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EE204: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EE208: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_12;
            return val_12;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_23:
            // 0x028EE20C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE210: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EE214: BL #0x1100c9c              | X0 = val_42.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_13 = val_42.ILType;
            // 0x028EE218: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x028EE21C: CBNZ x22, #0x28ee224       | if (val_13 != null) goto label_28;      
            if(val_13 != null)
            {
                goto label_28;
            }
            // 0x028EE220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_28:
            // 0x028EE224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE228: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x028EE22C: BL #0x10fb0b0              | X0 = val_13.get_IsEnum();               
            bool val_14 = val_13.IsEnum;
            // 0x028EE230: TBZ w0, #0, #0x28ee4dc     | if (val_14 == false) goto label_29;     
            if(val_14 == false)
            {
                goto label_29;
            }
            // 0x028EE234: CBNZ x22, #0x28ee23c       | if (val_13 != null) goto label_30;      
            if(val_13 != null)
            {
                goto label_30;
            }
            // 0x028EE238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_30:
            // 0x028EE23C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE240: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x028EE244: STP x22, x20, [sp]         | stack[1152921512891266208] = val_13;  stack[1152921512891266216] = ((X2 - (val_32) << ) - (val_33) << );  //  dest_result_addr=1152921512891266208 |  dest_result_addr=1152921512891266216
            // 0x028EE248: BL #0x10f7750              | X0 = val_13.get_TypeDefinition();       
            ILRuntime.Mono.Cecil.TypeDefinition val_15 = val_13.TypeDefinition;
            // 0x028EE24C: MOV x23, x0                | X23 = val_15;//m1                       
            // 0x028EE250: CBNZ x23, #0x28ee258       | if (val_15 != null) goto label_31;      
            if(val_15 != null)
            {
                goto label_31;
            }
            // 0x028EE254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_31:
            // 0x028EE258: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE25C: MOV x0, x23                | X0 = val_15;//m1                        
            // 0x028EE260: BL #0x11da880              | X0 = val_15.get_Fields();               
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition> val_16 = val_15.Fields;
            // 0x028EE264: ADRP x22, #0x35b8000       | X22 = 56328192 (0x35B8000);             
            // 0x028EE268: ADRP x28, #0x35bf000       | X28 = 56356864 (0x35BF000);             
            // 0x028EE26C: LDR x22, [x22, #0xa90]     | X22 = 1152921509413618864;              
            // 0x028EE270: LDR x28, [x28, #0xf30]     | X28 = 1152921509413619888;              
            val_37 = 1152921509413619888;
            // 0x028EE274: MOV x24, x0                | X24 = val_16;//m1                       
            // 0x028EE278: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_43 = 0;
            // 0x028EE27C: B #0x28ee284               |  goto label_32;                         
            goto label_32;
            label_46:
            // 0x028EE280: ADD w25, w25, #1           | W25 = (val_43 + 1) = val_43 (0x00000001);
            val_43 = 1;
            label_32:
            // 0x028EE284: CBNZ x24, #0x28ee28c       | if (val_16 != null) goto label_33;      
            if(val_16 != null)
            {
                goto label_33;
            }
            // 0x028EE288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_33:
            // 0x028EE28C: LDR x1, [x22]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Count();
            // 0x028EE290: MOV x0, x24                | X0 = val_16;//m1                        
            // 0x028EE294: BL #0x1d46b60              | X0 = val_16.get_Count();                
            int val_17 = val_16.Count;
            // 0x028EE298: CMP w25, w0                | STATE = COMPARE(0x1, val_17)            
            // 0x028EE29C: B.GE #0x28ee43c            | if (val_43 >= val_17) goto label_34;    
            if(val_43 >= val_17)
            {
                goto label_34;
            }
            // 0x028EE2A0: CBNZ x24, #0x28ee2a8       | if (val_16 != null) goto label_35;      
            if(val_16 != null)
            {
                goto label_35;
            }
            // 0x028EE2A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_35:
            // 0x028EE2A8: LDR x2, [x28]              | X2 = public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index);
            // 0x028EE2AC: MOV x0, x24                | X0 = val_16;//m1                        
            // 0x028EE2B0: MOV w1, w25                | W1 = 1 (0x1);//ML01                     
            // 0x028EE2B4: BL #0x1d46b68              | X0 = val_16.get_Item(index:  1);        
            ILRuntime.Mono.Cecil.FieldDefinition val_18 = val_16.Item[1];
            // 0x028EE2B8: MOV x23, x0                | X23 = val_18;//m1                       
            val_42 = val_18;
            // 0x028EE2BC: CBNZ x23, #0x28ee2c4       | if (val_18 != null) goto label_36;      
            if(val_42 != null)
            {
                goto label_36;
            }
            // 0x028EE2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_36:
            // 0x028EE2C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE2C8: MOV x0, x23                | X0 = val_18;//m1                        
            // 0x028EE2CC: BL #0xe66f34               | X0 = val_18.get_IsStatic();             
            bool val_19 = val_42.IsStatic;
            // 0x028EE2D0: TBZ w0, #0, #0x28ee280     | if (val_19 == false) goto label_46;     
            if(val_19 == false)
            {
                goto label_46;
            }
            // 0x028EE2D4: CBNZ x23, #0x28ee2dc       | if (val_18 != null) goto label_38;      
            if(val_42 != null)
            {
                goto label_38;
            }
            // 0x028EE2D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_38:
            // 0x028EE2DC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Mono.Cecil.FieldDefinition);
            // 0x028EE2E0: MOV x0, x23                | X0 = val_18;//m1                        
            // 0x028EE2E4: LDP x9, x1, [x8, #0x160]   | X9 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_160; X1 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_168; //  | 
            // 0x028EE2E8: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_160();
            // 0x028EE2EC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EE2F0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028EE2F4: MOV x26, x0                | X26 = val_18;//m1                       
            // 0x028EE2F8: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028EE2FC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028EE300: TBZ w9, #0, #0x28ee314     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_40;
            // 0x028EE304: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028EE308: CBNZ w9, #0x28ee314        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
            // 0x028EE30C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028EE310: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_40:
            // 0x028EE314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE318: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE31C: MOV x1, x26                | X1 = val_18;//m1                        
            // 0x028EE320: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x028EE324: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_42);
            bool val_20 = System.String.op_Equality(a:  0, b:  val_42);
            // 0x028EE328: TBNZ w0, #0, #0x28ee39c    | if (val_20 == true) goto label_41;      
            if(val_20 == true)
            {
                goto label_41;
            }
            // 0x028EE32C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE330: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE334: ADD x2, sp, #0x14          | X2 = (1152921512891266208 + 20) = 1152921512891266228 (0x10000001EDCA34B4);
            // 0x028EE338: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            int val_21 = val_38;
            // 0x028EE33C: BL #0x1e63c5c              | X0 = System.Int32.TryParse(s:  0, result: out  int val_21 = val_38);
            bool val_22 = System.Int32.TryParse(s:  0, result: out  val_21);
            // 0x028EE340: TBZ w0, #0, #0x28ee280     | if (val_22 == false) goto label_46;     
            if(val_22 == false)
            {
                goto label_46;
            }
            // 0x028EE344: CBNZ x23, #0x28ee34c       | if (val_18 != null) goto label_43;      
            if(val_42 != null)
            {
                goto label_43;
            }
            // 0x028EE348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_43:
            // 0x028EE34C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE350: MOV x0, x23                | X0 = val_18;//m1                        
            // 0x028EE354: BL #0xe66bd8               | X0 = val_18.get_Constant();             
            object val_23 = val_42.Constant;
            // 0x028EE358: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028EE35C: LDR w20, [sp, #0x14]       | W20 = 0x0;                              
            // 0x028EE360: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028EE364: MOV x27, x0                | X27 = val_23;//m1                       
            // 0x028EE368: LDR x26, [x8]              | X26 = typeof(System.Int32);             
            // 0x028EE36C: CBNZ x27, #0x28ee374       | if (val_23 != null) goto label_44;      
            if(val_23 != null)
            {
                goto label_44;
            }
            // 0x028EE370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_44:
            // 0x028EE374: LDR x8, [x27]              | X8 = typeof(System.Object);             
            // 0x028EE378: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EE37C: LDR x8, [x26, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
            // 0x028EE380: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
            // 0x028EE384: B.NE #0x28ee4b8            | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_45;
            // 0x028EE388: MOV x0, x27                | X0 = val_23;//m1                        
            // 0x028EE38C: BL #0x27bc4e8              | val_23.System.IDisposable.Dispose();    
            val_23.System.IDisposable.Dispose();
            // 0x028EE390: LDR w8, [x0]               | W8 = typeof(System.Object);             
            // 0x028EE394: CMP w8, w20                | STATE = COMPARE(typeof(System.Object), 0x0)
            // 0x028EE398: B.NE #0x28ee280            | if (typeof(System.Object) != 0) goto label_46;
            if(null != 0)
            {
                goto label_46;
            }
            label_41:
            // 0x028EE39C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x028EE3A0: LDR x8, [x8, #0x210]       | X8 = 1152921504825856000;               
            // 0x028EE3A4: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance);
            ILRuntime.Runtime.Intepreter.ILEnumTypeInstance val_24 = null;
            // 0x028EE3A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance), ????);
            // 0x028EE3AC: LDR x1, [sp]               | X1 = val_13;                            
            // 0x028EE3B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE3B4: MOV x21, x0                | X21 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE3B8: BL #0x1f8f700              | .ctor(type:  val_13);                   
            val_24 = new ILRuntime.Runtime.Intepreter.ILEnumTypeInstance(type:  val_13);
            // 0x028EE3BC: CBNZ x23, #0x28ee3c4       | if (val_18 != null) goto label_47;      
            if(val_42 != null)
            {
                goto label_47;
            }
            // 0x028EE3C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(type:  val_13), ????);
            label_47:
            // 0x028EE3C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE3C8: MOV x0, x23                | X0 = val_18;//m1                        
            // 0x028EE3CC: BL #0xe66bd8               | X0 = val_18.get_Constant();             
            object val_25 = val_42.Constant;
            // 0x028EE3D0: LDR x20, [sp, #8]          | X20 = ((X2 - (val_32) << ) - (val_33) << );
            // 0x028EE3D4: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x028EE3D8: CBZ x21, #0x28ee450        | if ( == 0) goto label_48;               
            if(null == 0)
            {
                goto label_48;
            }
            // 0x028EE3DC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028EE3E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE3E4: MOV x0, x21                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE3E8: MOV x2, x22                | X2 = val_25;//m1                        
            // 0x028EE3EC: BL #0x1f96638              | set_Item(index:  0, value:  val_25);    
            set_Item(index:  0, value:  val_25);
            // 0x028EE3F0: MOV x0, x21                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE3F4: B #0x28ee470               |  goto label_49;                         
            goto label_49;
            label_25:
            // 0x028EE3F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE3FC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EE400: BL #0x10ff500              | X0 = val_42.get_RealType();             
            System.Type val_26 = val_42.RealType;
            // 0x028EE404: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EE408: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EE40C: MOV x22, x0                | X22 = val_26;//m1                       
            // 0x028EE410: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x028EE414: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EE418: TBZ w9, #0, #0x28ee42c     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x028EE41C: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EE420: CBNZ w9, #0x28ee42c        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x028EE424: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x028EE428: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_51:
            // 0x028EE42C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE430: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE434: MOV x1, x22                | X1 = val_26;//m1                        
            // 0x028EE438: B #0x28ee1c8               |  goto label_52;                         
            goto label_52;
            label_34:
            // 0x028EE43C: LDR x1, [sp, #8]           | X1 = ((X2 - (val_32) << ) - (val_33) << );
            // 0x028EE440: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE444: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE448: BL #0x1f94458              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  val_13);
            ILRuntime.Runtime.Stack.StackObject* val_27 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushNull(esp:  val_13);
            // 0x028EE44C: B #0x28ee1ec               |  goto label_53;                         
            goto label_53;
            label_48:
            // 0x028EE450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            // 0x028EE454: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE458: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028EE45C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE460: MOV x2, x22                | X2 = val_25;//m1                        
            // 0x028EE464: BL #0x1f96638              | 0.set_Item(index:  0, value:  val_25);  
            0.set_Item(index:  0, value:  val_25);
            // 0x028EE468: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028EE46C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_49:
            // 0x028EE470: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE474: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028EE478: BL #0x1f96e30              | 0.set_Boxed(value:  true);              
            0.Boxed = true;
            // 0x028EE47C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE480: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EE484: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EE488: MOV x1, x20                | X1 = ((X2 - (val_32) << ) - (val_33) << );//m1
            // 0x028EE48C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EE490: MOV x3, x21                | X3 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE494: B #0x28ee1e8               |  goto label_54;                         
            goto label_54;
            // 0x028EE498: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            val_44 = 0;
            // 0x028EE49C: ADD x0, sp, #0x20          | X0 = (1152921512891266208 + 32) = 1152921512891266240 (0x10000001EDCA34C0);
            // 0x028EE4A0: B #0x28ee4ac               |  goto label_58;                         
            goto label_58;
            // 0x028EE4A4: MOV x19, x0                | X19 = 1152921512891266240 (0x10000001EDCA34C0);//ML01
            val_44;
            // 0x028EE4A8: ADD x0, sp, #0x18          | X0 = (1152921512891266208 + 24) = 1152921512891266232 (0x10000001EDCA34B8);
            label_58:
            // 0x028EE4AC: BL #0x299a140              | 
            // 0x028EE4B0: MOV x0, x19                | X0 = 1152921512891266240 (0x10000001EDCA34C0);//ML01
            // 0x028EE4B4: BL #0x980800               | X0 = sub_980800( ?? 0x10000001EDCA34C0, ????);
            label_45:
            // 0x028EE4B8: ADD x8, sp, #0x28          | X8 = (1152921512891266208 + 40) = 1152921512891266248 (0x10000001EDCA34C8);
            // 0x028EE4BC: MOV x1, x26                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x028EE4C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001EDCA34C0, ????);
            // 0x028EE4C4: LDR x0, [sp, #0x28]        | X0 = val_28;                             //  find_add[1152921512891254352]
            // 0x028EE4C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_28, ????);     
            // 0x028EE4CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE4D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            // 0x028EE4D4: ADD x0, sp, #0x28          | X0 = (1152921512891266208 + 40) = 1152921512891266248 (0x10000001EDCA34C8);
            // 0x028EE4D8: BL #0x299a140              | 
            label_29:
            // 0x028EE4DC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Mono.Cecil.FieldDefinition);
            // 0x028EE4E0: MOV x0, x23                | X0 = val_18;//m1                        
            // 0x028EE4E4: LDR x9, [x8, #0x230]       | X9 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_230;
            // 0x028EE4E8: LDR x1, [x8, #0x238]       | X1 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_238;
            // 0x028EE4EC: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_230();
            // 0x028EE4F0: LDR x8, [x28]              | X8 = public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index);
            // 0x028EE4F4: MOV x19, x0                | X19 = val_18;//m1                       
            // 0x028EE4F8: LDRB w9, [x8, #0x10a]      | W9 = public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index).__il2cppRuntimeField_10A;
            // 0x028EE4FC: TBZ w9, #0, #0x28ee510     | if ((public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index).__il2cppRuntimeField_10A & 0x1) == 0) goto label_57;
            // 0x028EE500: LDR w9, [x8, #0xbc]        | W9 = public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index).__il2cppRuntimeField_BC;
            // 0x028EE504: CBNZ w9, #0x28ee510        | if (public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index).__il2cppRuntimeField_BC != 0) goto label_57;
            // 0x028EE508: MOV x0, x8                 | X0 = 1152921509413619888 (0x100000011E8188B0);//ML01
            // 0x028EE50C: BL #0x27977a4              | X0 = sub_27977A4( ?? public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index), ????);
            label_57:
            // 0x028EE510: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x028EE514: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921512891250144)("{0} is not Enum");
            // 0x028EE518: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE51C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE520: MOV x2, x19                | X2 = val_18;//m1                        
            // 0x028EE524: LDR x1, [x8]               | X1 = "{0} is not Enum";                 
            // 0x028EE528: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            string val_29 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            // 0x028EE52C: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028EE530: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028EE534: MOV x19, x0                | X19 = val_29;//m1                       
            // 0x028EE538: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028EE53C: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_30 = null;
            // 0x028EE540: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028EE544: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE548: MOV x1, x19                | X1 = val_29;//m1                        
            // 0x028EE54C: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EE550: BL #0x1c32b48              | .ctor(message:  val_29);                
            val_30 = new System.Exception(message:  val_29);
            // 0x028EE554: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x028EE558: LDR x8, [x8, #0x560]       | X8 = 1152921512878455792;               
            // 0x028EE55C: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EE560: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::EnumParse(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EE564: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028EE568: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
            // 0x028EE56C: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EE570: ADD x0, sp, #0x28          | X0 = (1152921512891266208 + 40) = 1152921512891266248 (0x10000001EDCA34C8);
            // 0x028EE574: B #0x28ee4ac               |  goto label_58;                         
            goto label_58;
        
        }
        //
        // Offset in libil2cpp.so: 0x028EE578 (42919288), len: 1276  VirtAddr: 0x028EE578 RVA: 0x028EE578 token: 100680282 methodIndex: 29570 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* EnumGetValues(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            // 0x028EE578: STP x28, x27, [sp, #-0x60]! | stack[1152921512891529808] = ???;  stack[1152921512891529816] = ???;  //  dest_result_addr=1152921512891529808 |  dest_result_addr=1152921512891529816
            // 0x028EE57C: STP x26, x25, [sp, #0x10]  | stack[1152921512891529824] = ???;  stack[1152921512891529832] = ???;  //  dest_result_addr=1152921512891529824 |  dest_result_addr=1152921512891529832
            // 0x028EE580: STP x24, x23, [sp, #0x20]  | stack[1152921512891529840] = ???;  stack[1152921512891529848] = ???;  //  dest_result_addr=1152921512891529840 |  dest_result_addr=1152921512891529848
            // 0x028EE584: STP x22, x21, [sp, #0x30]  | stack[1152921512891529856] = ???;  stack[1152921512891529864] = ???;  //  dest_result_addr=1152921512891529856 |  dest_result_addr=1152921512891529864
            // 0x028EE588: STP x20, x19, [sp, #0x40]  | stack[1152921512891529872] = ???;  stack[1152921512891529880] = ???;  //  dest_result_addr=1152921512891529872 |  dest_result_addr=1152921512891529880
            // 0x028EE58C: STP x29, x30, [sp, #0x50]  | stack[1152921512891529888] = ???;  stack[1152921512891529896] = ???;  //  dest_result_addr=1152921512891529888 |  dest_result_addr=1152921512891529896
            // 0x028EE590: ADD x29, sp, #0x50         | X29 = (1152921512891529808 + 80) = 1152921512891529888 (0x10000001EDCE3AA0);
            // 0x028EE594: SUB sp, sp, #0x20          | SP = (1152921512891529808 - 32) = 1152921512891529776 (0x10000001EDCE3A30);
            // 0x028EE598: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028EE59C: LDRB w8, [x19, #0xa09]     | W8 = (bool)static_value_037B8A09;       
            // 0x028EE5A0: MOV x25, x3                | X25 = X3;//m1                           
            // 0x028EE5A4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x028EE5A8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028EE5AC: TBNZ w8, #0, #0x28ee5c8    | if (static_value_037B8A09 == true) goto label_0;
            // 0x028EE5B0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028EE5B4: LDR x8, [x8, #0x5e8]       | X8 = 0x2B90CDC;                         
            // 0x028EE5B8: LDR w0, [x8]               | W0 = 0x19FB;                            
            // 0x028EE5BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x19FB, ????);     
            // 0x028EE5C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EE5C4: STRB w8, [x19, #0xa09]     | static_value_037B8A09 = true;            //  dest_result_addr=58427913
            label_0:
            // 0x028EE5C8: ADRP x19, #0x366f000       | X19 = 57077760 (0x366F000);             
            // 0x028EE5CC: LDR x19, [x19, #0x7a0]     | X19 = 1152921504826228736;              
            // 0x028EE5D0: LDR x0, [x19]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EE5D4: LDRB w8, [x0, #0x109]      | W8 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EE5D8: TBNZ w8, #0, #0x28ee5e4    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EE5DC: ORR w24, wzr, #8           | W24 = 8(0x8);                           
            val_24 = 8;
            // 0x028EE5E0: B #0x28ee5ec               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EE5E4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EE5E8: SUB w24, w0, #0x10         | W24 = (null - 16) = val_24 (0x100000000D137FF0);
            val_24 = 1152921504826228720;
            label_2:
            // 0x028EE5EC: CBNZ x21, #0x28ee5f4       | if (X1 != 0) goto label_3;              
            if(X1 != 0)
            {
                goto label_3;
            }
            // 0x028EE5F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_3:
            // 0x028EE5F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE5F8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EE5FC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EE600: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_25 = null;
            // 0x028EE604: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028EE608: ADD x9, x8, #0x109         | X9 = (val_25 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EE60C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EE610: TBNZ w9, #0, #0x28ee61c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_4;
            // 0x028EE614: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_27 = 8;
            // 0x028EE618: B #0x28ee634               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x028EE61C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EE620: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EE624: LDR x8, [x19]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_25 = null;
            // 0x028EE628: SUB w10, w0, #0x10         | W10 = (val_25 - 16) = val_27 (0x100000000D137FF0);
            val_27 = 1152921504826228720;
            // 0x028EE62C: ADD x9, x8, #0x109         | X9 = (val_25 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EE630: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_5:
            // 0x028EE634: SUB x22, x20, w10, sxtw    | X22 = (X2 - (val_27) << );              
            var val_2 = X2 - (val_27 << );
            // 0x028EE638: TBZ w9, #8, #0x28ee64c     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_7;
            // 0x028EE63C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EE640: CBNZ w9, #0x28ee64c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028EE644: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EE648: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x028EE64C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE650: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EE654: MOV x1, x22                | X1 = (X2 - (val_27) << );//m1           
            // 0x028EE658: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EE65C: MOV x3, x25                | X3 = X3;//m1                            
            // 0x028EE660: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028EE664: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x028EE668: CBZ x0, #0x28ee6cc         | if (val_3 == null) goto label_10;       
            if(val_3 == null)
            {
                goto label_10;
            }
            // 0x028EE66C: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x028EE670: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x028EE674: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EE678: LDR x1, [x9]               | X1 = typeof(System.Type);               
            // 0x028EE67C: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE680: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE684: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EE688: B.LO #0x28ee6a4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028EE68C: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EE690: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EE694: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EE698: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EE69C: MOV x23, x0                | X23 = val_3;//m1                        
            val_28 = val_3;
            // 0x028EE6A0: B.EQ #0x28ee6cc            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028EE6A4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EE6A8: ADD x8, sp, #0x18          | X8 = (1152921512891529776 + 24) = 1152921512891529800 (0x10000001EDCE3A48);
            // 0x028EE6AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EE6B0: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921512891517904]
            // 0x028EE6B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028EE6B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE6BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028EE6C0: ADD x0, sp, #0x18          | X0 = (1152921512891529776 + 24) = 1152921512891529800 (0x10000001EDCE3A48);
            // 0x028EE6C4: BL #0x299a140              | 
            // 0x028EE6C8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_28 = 0;
            label_10:
            // 0x028EE6CC: SUB x19, x20, w24, sxtw    | X19 = (X2 - (val_24) << );              
            var val_6 = X2 - (val_24 << );
            // 0x028EE6D0: CBNZ x21, #0x28ee6d8       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028EE6D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDCE3A48, ????);
            label_11:
            // 0x028EE6D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE6DC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EE6E0: MOV x1, x22                | X1 = (X2 - (val_27) << );//m1           
            // 0x028EE6E4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EE6E8: CBZ x23, #0x28ee74c        | if (0x0 == 0) goto label_15;            
            if(val_28 == 0)
            {
                goto label_15;
            }
            // 0x028EE6EC: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x028EE6F0: LDR x9, [x9, #0x950]       | X9 = 1152921504821596160;               
            // 0x028EE6F4: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EE6F8: LDR x10, [x9]              | X10 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EE6FC: LDRB w9, [x8, #0x104]      | W9 = (bool)mem[282584257676931];        
            // 0x028EE700: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE704: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EE708: B.LO #0x28ee720            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028EE70C: LDR x12, [x8, #0xb0]       | X12 = mem[282584257676847];             
            // 0x028EE710: ADD x11, x12, x11, lsl #3  | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchy
            // 0x028EE714: LDUR x11, [x11, #-8]       | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EE718: CMP x11, x10               | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EE71C: B.EQ #0x28ee7b8            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028EE720: ADRP x10, #0x362d000       | X10 = 56807424 (0x362D000);             
            // 0x028EE724: LDR x10, [x10, #0xc30]     | X10 = 1152921504821649408;              
            // 0x028EE728: LDR x10, [x10]             | X10 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x028EE72C: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EE730: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EE734: B.LO #0x28ee74c            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x028EE738: LDR x8, [x8, #0xb0]        | X8 = mem[282584257676847];              
            // 0x028EE73C: ADD x8, x8, x11, lsl #3    | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHie
            // 0x028EE740: LDUR x8, [x8, #-8]         | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EE744: CMP x8, x10                | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028EE748: B.EQ #0x28ee984            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x028EE74C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EE750: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EE754: LDR x0, [x8]               | X0 = typeof(System.Enum);               
            // 0x028EE758: LDRB w8, [x0, #0x10a]      | W8 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EE75C: TBZ w8, #0, #0x28ee76c     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x028EE760: LDR w8, [x0, #0xbc]        | W8 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EE764: CBNZ w8, #0x28ee76c        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x028EE768: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_18:
            // 0x028EE76C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE770: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE774: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            label_38:
            // 0x028EE778: BL #0x1c394e8              | X0 = System.Enum.GetValues(enumType:  0);
            System.Array val_8 = System.Enum.GetValues(enumType:  0);
            // 0x028EE77C: MOV x3, x0                 | X3 = val_8;//m1                         
            // 0x028EE780: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE784: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EE788: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EE78C: MOV x1, x19                | X1 = (X2 - (val_24) << );//m1           
            // 0x028EE790: MOV x2, x25                | X2 = X3;//m1                            
            label_35:
            // 0x028EE794: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028EE798: SUB sp, x29, #0x50         | SP = (1152921512891529888 - 80) = 1152921512891529808 (0x10000001EDCE3A50);
            // 0x028EE79C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EE7A0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EE7A4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EE7A8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EE7AC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EE7B0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EE7B4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_14:
            // 0x028EE7B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE7BC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EE7C0: BL #0x1100c9c              | X0 = val_28.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_10 = val_28.ILType;
            // 0x028EE7C4: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x028EE7C8: LDR x8, [x8, #0xd68]       | X8 = 1152921504616644608;               
            // 0x028EE7CC: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x028EE7D0: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x028EE7D4: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<ILRuntime.Runtime.Intepreter.ILTypeInstance> val_11 = null;
            // 0x028EE7D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028EE7DC: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x028EE7E0: LDR x8, [x8, #0x7d8]       | X8 = 1152921510874333200;               
            // 0x028EE7E4: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028EE7E8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<ILRuntime.Runtime.Intepreter.ILTypeInstance>::.ctor();
            // 0x028EE7EC: BL #0x25e9474              | .ctor();                                
            val_11 = new System.Collections.Generic.List<ILRuntime.Runtime.Intepreter.ILTypeInstance>();
            // 0x028EE7F0: CBNZ x22, #0x28ee7f8       | if (val_10 != null) goto label_19;      
            if(val_10 != null)
            {
                goto label_19;
            }
            // 0x028EE7F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_19:
            // 0x028EE7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE7FC: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x028EE800: BL #0x10fb0b0              | X0 = val_10.get_IsEnum();               
            bool val_12 = val_10.IsEnum;
            // 0x028EE804: TBZ w0, #0, #0x28ee9dc     | if (val_12 == false) goto label_20;     
            if(val_12 == false)
            {
                goto label_20;
            }
            // 0x028EE808: CBNZ x22, #0x28ee810       | if (val_10 != null) goto label_21;      
            if(val_10 != null)
            {
                goto label_21;
            }
            // 0x028EE80C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_21:
            // 0x028EE810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE814: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x028EE818: STP x19, x25, [sp, #8]     | stack[1152921512891529784] = (X2 - (val_24) << );  stack[1152921512891529792] = X3;  //  dest_result_addr=1152921512891529784 |  dest_result_addr=1152921512891529792
            // 0x028EE81C: BL #0x10f7750              | X0 = val_10.get_TypeDefinition();       
            ILRuntime.Mono.Cecil.TypeDefinition val_13 = val_10.TypeDefinition;
            // 0x028EE820: MOV x23, x0                | X23 = val_13;//m1                       
            // 0x028EE824: CBNZ x23, #0x28ee82c       | if (val_13 != null) goto label_22;      
            if(val_13 != null)
            {
                goto label_22;
            }
            // 0x028EE828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_22:
            // 0x028EE82C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE830: MOV x0, x23                | X0 = val_13;//m1                        
            // 0x028EE834: BL #0x11da880              | X0 = val_13.get_Fields();               
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition> val_14 = val_13.Fields;
            // 0x028EE838: ADRP x27, #0x35b8000       | X27 = 56328192 (0x35B8000);             
            // 0x028EE83C: ADRP x28, #0x35bf000       | X28 = 56356864 (0x35BF000);             
            // 0x028EE840: ADRP x20, #0x35be000       | X20 = 56352768 (0x35BE000);             
            // 0x028EE844: ADRP x19, #0x3621000       | X19 = 56758272 (0x3621000);             
            // 0x028EE848: LDR x27, [x27, #0xa90]     | X27 = 1152921509413618864;              
            // 0x028EE84C: LDR x28, [x28, #0xf30]     | X28 = 1152921509413619888;              
            // 0x028EE850: LDR x20, [x20, #0x210]     | X20 = 1152921504825856000;              
            // 0x028EE854: LDR x19, [x19, #0xfa8]     | X19 = 1152921510864798992;              
            // 0x028EE858: MOV x23, x0                | X23 = val_14;//m1                       
            // 0x028EE85C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_29 = 0;
            // 0x028EE860: B #0x28ee868               |  goto label_23;                         
            goto label_23;
            label_33:
            // 0x028EE864: ADD w24, w24, #1           | W24 = (val_29 + 1) = val_29 (0x00000001);
            val_29 = 1;
            label_23:
            // 0x028EE868: CBNZ x23, #0x28ee870       | if (val_14 != null) goto label_24;      
            if(val_14 != null)
            {
                goto label_24;
            }
            // 0x028EE86C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_24:
            // 0x028EE870: LDR x1, [x27]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Count();
            // 0x028EE874: MOV x0, x23                | X0 = val_14;//m1                        
            // 0x028EE878: BL #0x1d46b60              | X0 = val_14.get_Count();                
            int val_15 = val_14.Count;
            // 0x028EE87C: CMP w24, w0                | STATE = COMPARE(0x1, val_15)            
            // 0x028EE880: B.GE #0x28ee950            | if (val_29 >= val_15) goto label_25;    
            if(val_29 >= val_15)
            {
                goto label_25;
            }
            // 0x028EE884: CBNZ x23, #0x28ee88c       | if (val_14 != null) goto label_26;      
            if(val_14 != null)
            {
                goto label_26;
            }
            // 0x028EE888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_26:
            // 0x028EE88C: LDR x2, [x28]              | X2 = public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index);
            // 0x028EE890: MOV x0, x23                | X0 = val_14;//m1                        
            // 0x028EE894: MOV w1, w24                | W1 = 1 (0x1);//ML01                     
            // 0x028EE898: BL #0x1d46b68              | X0 = val_14.get_Item(index:  1);        
            ILRuntime.Mono.Cecil.FieldDefinition val_16 = val_14.Item[1];
            // 0x028EE89C: MOV x26, x0                | X26 = val_16;//m1                       
            // 0x028EE8A0: CBNZ x26, #0x28ee8a8       | if (val_16 != null) goto label_27;      
            if(val_16 != null)
            {
                goto label_27;
            }
            // 0x028EE8A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_27:
            // 0x028EE8A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE8AC: MOV x0, x26                | X0 = val_16;//m1                        
            // 0x028EE8B0: BL #0xe66f34               | X0 = val_16.get_IsStatic();             
            bool val_17 = val_16.IsStatic;
            // 0x028EE8B4: TBZ w0, #0, #0x28ee864     | if (val_17 == false) goto label_33;     
            if(val_17 == false)
            {
                goto label_33;
            }
            // 0x028EE8B8: LDR x0, [x20]              | X0 = typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance);
            ILRuntime.Runtime.Intepreter.ILEnumTypeInstance val_18 = null;
            // 0x028EE8BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance), ????);
            // 0x028EE8C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE8C4: MOV x1, x22                | X1 = val_10;//m1                        
            // 0x028EE8C8: MOV x25, x0                | X25 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE8CC: BL #0x1f8f700              | .ctor(type:  val_10);                   
            val_18 = new ILRuntime.Runtime.Intepreter.ILEnumTypeInstance(type:  val_10);
            // 0x028EE8D0: CBNZ x26, #0x28ee8d8       | if (val_16 != null) goto label_29;      
            if(val_16 != null)
            {
                goto label_29;
            }
            // 0x028EE8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(type:  val_10), ????);
            label_29:
            // 0x028EE8D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE8DC: MOV x0, x26                | X0 = val_16;//m1                        
            // 0x028EE8E0: BL #0xe66bd8               | X0 = val_16.get_Constant();             
            object val_19 = val_16.Constant;
            // 0x028EE8E4: MOV x26, x0                | X26 = val_19;//m1                       
            // 0x028EE8E8: CBZ x25, #0x28ee908        | if ( == 0) goto label_30;               
            if(null == 0)
            {
                goto label_30;
            }
            // 0x028EE8EC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028EE8F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE8F4: MOV x0, x25                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE8F8: MOV x2, x26                | X2 = val_19;//m1                        
            // 0x028EE8FC: BL #0x1f96638              | set_Item(index:  0, value:  val_19);    
            set_Item(index:  0, value:  val_19);
            // 0x028EE900: MOV x0, x25                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE904: B #0x28ee928               |  goto label_31;                         
            goto label_31;
            label_30:
            // 0x028EE908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            // 0x028EE90C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE910: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x028EE914: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EE918: MOV x2, x26                | X2 = val_19;//m1                        
            // 0x028EE91C: BL #0x1f96638              | 0.set_Item(index:  0, value:  val_19);  
            0.set_Item(index:  0, value:  val_19);
            // 0x028EE920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x028EE924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            label_31:
            // 0x028EE928: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE92C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x028EE930: BL #0x1f96e30              | 0.set_Boxed(value:  true);              
            0.Boxed = true;
            // 0x028EE934: CBNZ x21, #0x28ee93c       | if ( != 0) goto label_32;               
            if(null != 0)
            {
                goto label_32;
            }
            // 0x028EE938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_32:
            // 0x028EE93C: LDR x2, [x19]              | X2 = public System.Void System.Collections.Generic.List<ILRuntime.Runtime.Intepreter.ILTypeInstance>::Add(ILRuntime.Runtime.Intepreter.ILTypeInstance item);
            // 0x028EE940: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028EE944: MOV x1, x25                | X1 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EE948: BL #0x25ea480              | Add(item:  val_18);                     
            Add(item:  val_18);
            // 0x028EE94C: B #0x28ee864               |  goto label_33;                         
            goto label_33;
            label_25:
            // 0x028EE950: CBNZ x21, #0x28ee958       | if ( != 0) goto label_34;               
            if(null != 0)
            {
                goto label_34;
            }
            // 0x028EE954: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_34:
            // 0x028EE958: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x028EE95C: LDR x8, [x8, #0x4c0]       | X8 = 1152921510872851472;               
            // 0x028EE960: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028EE964: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<ILRuntime.Runtime.Intepreter.ILTypeInstance>::ToArray();
            // 0x028EE968: BL #0x25ed474              | X0 = ToArray();                         
            T[] val_20 = ToArray();
            // 0x028EE96C: LDP x1, x2, [sp, #8]       | X1 = (X2 - (val_24) << ); X2 = X3;       //  | 
            // 0x028EE970: MOV x3, x0                 | X3 = val_20;//m1                        
            // 0x028EE974: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE978: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EE97C: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EE980: B #0x28ee794               |  goto label_35;                         
            goto label_35;
            label_16:
            // 0x028EE984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EE988: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EE98C: BL #0x10ff500              | X0 = val_28.get_RealType();             
            System.Type val_21 = val_28.RealType;
            // 0x028EE990: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EE994: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EE998: MOV x21, x0                | X21 = val_21;//m1                       
            // 0x028EE99C: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x028EE9A0: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EE9A4: TBZ w9, #0, #0x28ee9b8     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x028EE9A8: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EE9AC: CBNZ w9, #0x28ee9b8        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x028EE9B0: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x028EE9B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_37:
            // 0x028EE9B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EE9BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EE9C0: MOV x1, x21                | X1 = val_21;//m1                        
            // 0x028EE9C4: B #0x28ee778               |  goto label_38;                         
            goto label_38;
            // 0x028EE9C8: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            // 0x028EE9CC: ADD x0, sp, #0x18          | X0 = (1152921512891529776 + 24) = 1152921512891529800 (0x10000001EDCE3A48);
            // 0x028EE9D0: BL #0x299a140              | 
            // 0x028EE9D4: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x028EE9D8: BL #0x980800               | X0 = sub_980800( ?? 0x0, ????);         
            label_20:
            // 0x028EE9DC: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EE9E0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EE9E4: LDR x9, [x8, #0x230]       | X9 = mem[282584257677231];              
            // 0x028EE9E8: LDR x1, [x8, #0x238]       | X1 = mem[282584257677239];              
            // 0x028EE9EC: BLR x9                     | X0 = mem[282584257677231]();            
            // 0x028EE9F0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EE9F4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028EE9F8: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            // 0x028EE9FC: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028EEA00: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028EEA04: TBZ w9, #0, #0x28eea18     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_40;
            // 0x028EEA08: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028EEA0C: CBNZ w9, #0x28eea18        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
            // 0x028EEA10: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028EEA14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_40:
            // 0x028EEA18: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x028EEA1C: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921512891250144)("{0} is not Enum");
            // 0x028EEA20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEA24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EEA28: MOV x2, x19                | X2 = 0 (0x0);//ML01                     
            // 0x028EEA2C: LDR x1, [x8]               | X1 = "{0} is not Enum";                 
            // 0x028EEA30: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            string val_22 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            // 0x028EEA34: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028EEA38: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028EEA3C: MOV x19, x0                | X19 = val_22;//m1                       
            // 0x028EEA40: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028EEA44: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_23 = null;
            // 0x028EEA48: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028EEA4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EEA50: MOV x1, x19                | X1 = val_22;//m1                        
            // 0x028EEA54: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EEA58: BL #0x1c32b48              | .ctor(message:  val_22);                
            val_23 = new System.Exception(message:  val_22);
            // 0x028EEA5C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x028EEA60: LDR x8, [x8, #0x4a8]       | X8 = 1152921512878456816;               
            // 0x028EEA64: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EEA68: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::EnumGetValues(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EEA6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028EEA70: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
        
        }
        //
        // Offset in libil2cpp.so: 0x028EEA74 (42920564), len: 1148  VirtAddr: 0x028EEA74 RVA: 0x028EEA74 token: 100680283 methodIndex: 29571 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* EnumGetNames(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            // 0x028EEA74: STP x28, x27, [sp, #-0x60]! | stack[1152921512891850704] = ???;  stack[1152921512891850712] = ???;  //  dest_result_addr=1152921512891850704 |  dest_result_addr=1152921512891850712
            // 0x028EEA78: STP x26, x25, [sp, #0x10]  | stack[1152921512891850720] = ???;  stack[1152921512891850728] = ???;  //  dest_result_addr=1152921512891850720 |  dest_result_addr=1152921512891850728
            // 0x028EEA7C: STP x24, x23, [sp, #0x20]  | stack[1152921512891850736] = ???;  stack[1152921512891850744] = ???;  //  dest_result_addr=1152921512891850736 |  dest_result_addr=1152921512891850744
            // 0x028EEA80: STP x22, x21, [sp, #0x30]  | stack[1152921512891850752] = ???;  stack[1152921512891850760] = ???;  //  dest_result_addr=1152921512891850752 |  dest_result_addr=1152921512891850760
            // 0x028EEA84: STP x20, x19, [sp, #0x40]  | stack[1152921512891850768] = ???;  stack[1152921512891850776] = ???;  //  dest_result_addr=1152921512891850768 |  dest_result_addr=1152921512891850776
            // 0x028EEA88: STP x29, x30, [sp, #0x50]  | stack[1152921512891850784] = ???;  stack[1152921512891850792] = ???;  //  dest_result_addr=1152921512891850784 |  dest_result_addr=1152921512891850792
            // 0x028EEA8C: ADD x29, sp, #0x50         | X29 = (1152921512891850704 + 80) = 1152921512891850784 (0x10000001EDD32020);
            // 0x028EEA90: SUB sp, sp, #0x10          | SP = (1152921512891850704 - 16) = 1152921512891850688 (0x10000001EDD31FC0);
            // 0x028EEA94: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028EEA98: LDRB w8, [x22, #0xa0a]     | W8 = (bool)static_value_037B8A0A;       
            // 0x028EEA9C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EEAA0: MOV x20, x2                | X20 = X2;//m1                           
            var val_21 = X2;
            // 0x028EEAA4: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028EEAA8: TBNZ w8, #0, #0x28eeac4    | if (static_value_037B8A0A == true) goto label_0;
            // 0x028EEAAC: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x028EEAB0: LDR x8, [x8, #0xc38]       | X8 = 0x2B90CD8;                         
            // 0x028EEAB4: LDR w0, [x8]               | W0 = 0x19FA;                            
            // 0x028EEAB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x19FA, ????);     
            // 0x028EEABC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EEAC0: STRB w8, [x22, #0xa0a]     | static_value_037B8A0A = true;            //  dest_result_addr=58427914
            label_0:
            // 0x028EEAC4: ADRP x23, #0x366f000       | X23 = 57077760 (0x366F000);             
            // 0x028EEAC8: LDR x23, [x23, #0x7a0]     | X23 = 1152921504826228736;              
            // 0x028EEACC: LDR x0, [x23]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EEAD0: LDRB w8, [x0, #0x109]      | W8 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EEAD4: TBNZ w8, #0, #0x28eeae0    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EEAD8: ORR w24, wzr, #8           | W24 = 8(0x8);                           
            val_21 = 8;
            // 0x028EEADC: B #0x28eeae8               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EEAE0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EEAE4: SUB w24, w0, #0x10         | W24 = (null - 16) = val_21 (0x100000000D137FF0);
            val_21 = 1152921504826228720;
            label_2:
            // 0x028EEAE8: CBNZ x21, #0x28eeaf0       | if (X1 != 0) goto label_3;              
            if(X1 != 0)
            {
                goto label_3;
            }
            // 0x028EEAEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_3:
            // 0x028EEAF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EEAF4: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EEAF8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EEAFC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_22 = null;
            // 0x028EEB00: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x028EEB04: ADD x9, x8, #0x109         | X9 = (val_22 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EEB08: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EEB0C: TBNZ w9, #0, #0x28eeb18    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_4;
            // 0x028EEB10: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_24 = 8;
            // 0x028EEB14: B #0x28eeb30               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x028EEB18: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EEB1C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EEB20: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_22 = null;
            // 0x028EEB24: SUB w10, w0, #0x10         | W10 = (val_22 - 16) = val_24 (0x100000000D137FF0);
            val_24 = 1152921504826228720;
            // 0x028EEB28: ADD x9, x8, #0x109         | X9 = (val_22 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EEB2C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_5:
            // 0x028EEB30: SUB x23, x20, w10, sxtw    | X23 = (X2 - (val_24) << );              
            var val_2 = val_21 - (val_24 << );
            // 0x028EEB34: TBZ w9, #8, #0x28eeb48     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_7;
            // 0x028EEB38: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EEB3C: CBNZ w9, #0x28eeb48        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028EEB40: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EEB44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_7:
            // 0x028EEB48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEB4C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EEB50: MOV x1, x23                | X1 = (X2 - (val_24) << );//m1           
            // 0x028EEB54: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x028EEB58: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EEB5C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028EEB60: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x028EEB64: CBZ x0, #0x28eebc8         | if (val_3 == null) goto label_10;       
            if(val_3 == null)
            {
                goto label_10;
            }
            // 0x028EEB68: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x028EEB6C: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x028EEB70: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EEB74: LDR x1, [x9]               | X1 = typeof(System.Type);               
            // 0x028EEB78: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EEB7C: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EEB80: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EEB84: B.LO #0x28eeba0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028EEB88: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EEB8C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EEB90: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EEB94: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EEB98: MOV x22, x0                | X22 = val_3;//m1                        
            val_25 = val_3;
            // 0x028EEB9C: B.EQ #0x28eebc8            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028EEBA0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EEBA4: ADD x8, sp, #8             | X8 = (1152921512891850688 + 8) = 1152921512891850696 (0x10000001EDD31FC8);
            // 0x028EEBA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EEBAC: LDR x0, [sp, #8]           | X0 = val_5;                              //  find_add[1152921512891838800]
            // 0x028EEBB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028EEBB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EEBB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028EEBBC: ADD x0, sp, #8             | X0 = (1152921512891850688 + 8) = 1152921512891850696 (0x10000001EDD31FC8);
            // 0x028EEBC0: BL #0x299a140              | 
            // 0x028EEBC4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_25 = 0;
            label_10:
            // 0x028EEBC8: SUB x20, x20, w24, sxtw    | X20 = (X2 - (val_21) << );              
            val_21 = val_21 - (val_21 << );
            // 0x028EEBCC: CBNZ x21, #0x28eebd4       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028EEBD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDD31FC8, ????);
            label_11:
            // 0x028EEBD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EEBD8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EEBDC: MOV x1, x23                | X1 = (X2 - (val_24) << );//m1           
            // 0x028EEBE0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EEBE4: CBZ x22, #0x28eec48        | if (0x0 == 0) goto label_15;            
            if(val_25 == 0)
            {
                goto label_15;
            }
            // 0x028EEBE8: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x028EEBEC: LDR x9, [x9, #0x950]       | X9 = 1152921504821596160;               
            // 0x028EEBF0: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x028EEBF4: LDR x10, [x9]              | X10 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EEBF8: LDRB w9, [x8, #0x104]      | W9 = (bool)mem[282584257676931];        
            // 0x028EEBFC: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EEC00: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EEC04: B.LO #0x28eec1c            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x028EEC08: LDR x12, [x8, #0xb0]       | X12 = mem[282584257676847];             
            // 0x028EEC0C: ADD x11, x12, x11, lsl #3  | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchy
            // 0x028EEC10: LDUR x11, [x11, #-8]       | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EEC14: CMP x11, x10               | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EEC18: B.EQ #0x28eecb4            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x028EEC1C: ADRP x10, #0x362d000       | X10 = 56807424 (0x362D000);             
            // 0x028EEC20: LDR x10, [x10, #0xc30]     | X10 = 1152921504821649408;              
            // 0x028EEC24: LDR x10, [x10]             | X10 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x028EEC28: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EEC2C: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EEC30: B.LO #0x28eec48            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_15;
            // 0x028EEC34: LDR x8, [x8, #0xb0]        | X8 = mem[282584257676847];              
            // 0x028EEC38: ADD x8, x8, x11, lsl #3    | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHie
            // 0x028EEC3C: LDUR x8, [x8, #-8]         | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EEC40: CMP x8, x10                | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028EEC44: B.EQ #0x28eee00            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_16;
            label_15:
            // 0x028EEC48: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EEC4C: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EEC50: LDR x0, [x8]               | X0 = typeof(System.Enum);               
            // 0x028EEC54: LDRB w8, [x0, #0x10a]      | W8 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EEC58: TBZ w8, #0, #0x28eec68     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x028EEC5C: LDR w8, [x0, #0xbc]        | W8 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EEC60: CBNZ w8, #0x28eec68        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x028EEC64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_18:
            // 0x028EEC68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEC6C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EEC70: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            label_36:
            // 0x028EEC74: BL #0x1c39694              | X0 = System.Enum.GetNames(enumType:  0);
            System.String[] val_7 = System.Enum.GetNames(enumType:  0);
            label_33:
            // 0x028EEC78: MOV x3, x0                 | X3 = val_7;//m1                         
            // 0x028EEC7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEC80: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EEC84: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EEC88: MOV x1, x20                | X1 = (X2 - (val_21) << );//m1           
            // 0x028EEC8C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EEC90: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028EEC94: SUB sp, x29, #0x50         | SP = (1152921512891850784 - 80) = 1152921512891850704 (0x10000001EDD31FD0);
            // 0x028EEC98: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EEC9C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EECA0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EECA4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EECA8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EECAC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EECB0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_8;
            return val_8;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_14:
            // 0x028EECB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EECB8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EECBC: BL #0x1100c9c              | X0 = val_25.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_9 = val_25.ILType;
            // 0x028EECC0: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x028EECC4: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x028EECC8: MOV x23, x0                | X23 = val_9;//m1                        
            // 0x028EECCC: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x028EECD0: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_10 = null;
            // 0x028EECD4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028EECD8: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028EECDC: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x028EECE0: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028EECE4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x028EECE8: BL #0x25e9474              | .ctor();                                
            val_10 = new System.Collections.Generic.List<System.String>();
            // 0x028EECEC: CBNZ x23, #0x28eecf4       | if (val_9 != null) goto label_19;       
            if(val_9 != null)
            {
                goto label_19;
            }
            // 0x028EECF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_19:
            // 0x028EECF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EECF8: MOV x0, x23                | X0 = val_9;//m1                         
            // 0x028EECFC: BL #0x10fb0b0              | X0 = val_9.get_IsEnum();                
            bool val_11 = val_9.IsEnum;
            // 0x028EED00: TBZ w0, #0, #0x28eee58     | if (val_11 == false) goto label_20;     
            if(val_11 == false)
            {
                goto label_20;
            }
            // 0x028EED04: CBNZ x23, #0x28eed0c       | if (val_9 != null) goto label_21;       
            if(val_9 != null)
            {
                goto label_21;
            }
            // 0x028EED08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_21:
            // 0x028EED0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EED10: MOV x0, x23                | X0 = val_9;//m1                         
            // 0x028EED14: BL #0x10f7750              | X0 = val_9.get_TypeDefinition();        
            ILRuntime.Mono.Cecil.TypeDefinition val_12 = val_9.TypeDefinition;
            // 0x028EED18: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x028EED1C: CBNZ x22, #0x28eed24       | if (val_12 != null) goto label_22;      
            if(val_12 != null)
            {
                goto label_22;
            }
            // 0x028EED20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_22:
            // 0x028EED24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EED28: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x028EED2C: BL #0x11da880              | X0 = val_12.get_Fields();               
            ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition> val_13 = val_12.Fields;
            // 0x028EED30: ADRP x25, #0x35b8000       | X25 = 56328192 (0x35B8000);             
            // 0x028EED34: ADRP x26, #0x35bf000       | X26 = 56356864 (0x35BF000);             
            // 0x028EED38: ADRP x27, #0x35e6000       | X27 = 56516608 (0x35E6000);             
            // 0x028EED3C: LDR x25, [x25, #0xa90]     | X25 = 1152921509413618864;              
            // 0x028EED40: LDR x26, [x26, #0xf30]     | X26 = 1152921509413619888;              
            // 0x028EED44: LDR x27, [x27, #0x500]     | X27 = 1152921510890816336;              
            // 0x028EED48: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x028EED4C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_26 = 0;
            // 0x028EED50: B #0x28eed58               |  goto label_23;                         
            goto label_23;
            label_31:
            // 0x028EED54: ADD w23, w23, #1           | W23 = (val_26 + 1) = val_26 (0x00000001);
            val_26 = 1;
            label_23:
            // 0x028EED58: CBNZ x22, #0x28eed60       | if (val_13 != null) goto label_24;      
            if(val_13 != null)
            {
                goto label_24;
            }
            // 0x028EED5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_24:
            // 0x028EED60: LDR x1, [x25]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Count();
            // 0x028EED64: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x028EED68: BL #0x1d46b60              | X0 = val_13.get_Count();                
            int val_14 = val_13.Count;
            // 0x028EED6C: CMP w23, w0                | STATE = COMPARE(0x1, val_14)            
            // 0x028EED70: B.GE #0x28eede0            | if (val_26 >= val_14) goto label_25;    
            if(val_26 >= val_14)
            {
                goto label_25;
            }
            // 0x028EED74: CBNZ x22, #0x28eed7c       | if (val_13 != null) goto label_26;      
            if(val_13 != null)
            {
                goto label_26;
            }
            // 0x028EED78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_26:
            // 0x028EED7C: LDR x2, [x26]              | X2 = public ILRuntime.Mono.Cecil.FieldDefinition ILRuntime.Mono.Collections.Generic.Collection<ILRuntime.Mono.Cecil.FieldDefinition>::get_Item(int index);
            // 0x028EED80: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x028EED84: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x028EED88: BL #0x1d46b68              | X0 = val_13.get_Item(index:  1);        
            ILRuntime.Mono.Cecil.FieldDefinition val_15 = val_13.Item[1];
            // 0x028EED8C: MOV x24, x0                | X24 = val_15;//m1                       
            // 0x028EED90: CBNZ x24, #0x28eed98       | if (val_15 != null) goto label_27;      
            if(val_15 != null)
            {
                goto label_27;
            }
            // 0x028EED94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_27:
            // 0x028EED98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EED9C: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x028EEDA0: BL #0xe66f34               | X0 = val_15.get_IsStatic();             
            bool val_16 = val_15.IsStatic;
            // 0x028EEDA4: TBZ w0, #0, #0x28eed54     | if (val_16 == false) goto label_31;     
            if(val_16 == false)
            {
                goto label_31;
            }
            // 0x028EEDA8: CBNZ x24, #0x28eedb0       | if (val_15 != null) goto label_29;      
            if(val_15 != null)
            {
                goto label_29;
            }
            // 0x028EEDAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_29:
            // 0x028EEDB0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Mono.Cecil.FieldDefinition);
            // 0x028EEDB4: MOV x0, x24                | X0 = val_15;//m1                        
            // 0x028EEDB8: LDP x9, x1, [x8, #0x160]   | X9 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_160; X1 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_168; //  | 
            // 0x028EEDBC: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.FieldDefinition).__il2cppRuntimeField_160();
            // 0x028EEDC0: MOV x24, x0                | X24 = val_15;//m1                       
            // 0x028EEDC4: CBNZ x21, #0x28eedcc       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x028EEDC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_30:
            // 0x028EEDCC: LDR x2, [x27]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x028EEDD0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028EEDD4: MOV x1, x24                | X1 = val_15;//m1                        
            // 0x028EEDD8: BL #0x25ea480              | Add(item:  val_15);                     
            Add(item:  val_15);
            // 0x028EEDDC: B #0x28eed54               |  goto label_31;                         
            goto label_31;
            label_25:
            // 0x028EEDE0: CBNZ x21, #0x28eede8       | if ( != 0) goto label_32;               
            if(null != 0)
            {
                goto label_32;
            }
            // 0x028EEDE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_32:
            // 0x028EEDE8: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x028EEDEC: LDR x8, [x8, #0xa50]       | X8 = 1152921510891931728;               
            // 0x028EEDF0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x028EEDF4: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<System.String>::ToArray();
            // 0x028EEDF8: BL #0x25ed474              | X0 = ToArray();                         
            T[] val_17 = ToArray();
            // 0x028EEDFC: B #0x28eec78               |  goto label_33;                         
            goto label_33;
            label_16:
            // 0x028EEE00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EEE04: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EEE08: BL #0x10ff500              | X0 = val_25.get_RealType();             
            System.Type val_18 = val_25.RealType;
            // 0x028EEE0C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EEE10: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EEE14: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x028EEE18: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x028EEE1C: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EEE20: TBZ w9, #0, #0x28eee34     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_35;
            // 0x028EEE24: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EEE28: CBNZ w9, #0x28eee34        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
            // 0x028EEE2C: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x028EEE30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_35:
            // 0x028EEE34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEE38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EEE3C: MOV x1, x21                | X1 = val_18;//m1                        
            // 0x028EEE40: B #0x28eec74               |  goto label_36;                         
            goto label_36;
            // 0x028EEE44: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            // 0x028EEE48: ADD x0, sp, #8             | X0 = (1152921512891850688 + 8) = 1152921512891850696 (0x10000001EDD31FC8);
            // 0x028EEE4C: BL #0x299a140              | 
            // 0x028EEE50: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x028EEE54: BL #0x980800               | X0 = sub_980800( ?? 0x0, ????);         
            label_20:
            // 0x028EEE58: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x028EEE5C: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EEE60: LDR x9, [x8, #0x230]       | X9 = mem[282584257677231];              
            // 0x028EEE64: LDR x1, [x8, #0x238]       | X1 = mem[282584257677239];              
            // 0x028EEE68: BLR x9                     | X0 = mem[282584257677231]();            
            // 0x028EEE6C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EEE70: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028EEE74: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            // 0x028EEE78: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028EEE7C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028EEE80: TBZ w9, #0, #0x28eee94     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x028EEE84: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028EEE88: CBNZ w9, #0x28eee94        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x028EEE8C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028EEE90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_38:
            // 0x028EEE94: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x028EEE98: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921512891250144)("{0} is not Enum");
            // 0x028EEE9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEEA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EEEA4: MOV x2, x19                | X2 = 0 (0x0);//ML01                     
            // 0x028EEEA8: LDR x1, [x8]               | X1 = "{0} is not Enum";                 
            // 0x028EEEAC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            string val_19 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            // 0x028EEEB0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028EEEB4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028EEEB8: MOV x19, x0                | X19 = val_19;//m1                       
            // 0x028EEEBC: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028EEEC0: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_20 = null;
            // 0x028EEEC4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028EEEC8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EEECC: MOV x1, x19                | X1 = val_19;//m1                        
            // 0x028EEED0: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EEED4: BL #0x1c32b48              | .ctor(message:  val_19);                
            val_20 = new System.Exception(message:  val_19);
            // 0x028EEED8: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x028EEEDC: LDR x8, [x8, #0x568]       | X8 = 1152921512878457840;               
            // 0x028EEEE0: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EEEE4: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::EnumGetNames(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EEEE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028EEEEC: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
        
        }
        //
        // Offset in libil2cpp.so: 0x028EEEF0 (42921712), len: 1340  VirtAddr: 0x028EEEF0 RVA: 0x028EEEF0 token: 100680284 methodIndex: 29572 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* EnumGetName(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            object val_32;
            //  | 
            var val_33;
            // 0x028EEEF0: STP x28, x27, [sp, #-0x60]! | stack[1152921512892126544] = ???;  stack[1152921512892126552] = ???;  //  dest_result_addr=1152921512892126544 |  dest_result_addr=1152921512892126552
            // 0x028EEEF4: STP x26, x25, [sp, #0x10]  | stack[1152921512892126560] = ???;  stack[1152921512892126568] = ???;  //  dest_result_addr=1152921512892126560 |  dest_result_addr=1152921512892126568
            // 0x028EEEF8: STP x24, x23, [sp, #0x20]  | stack[1152921512892126576] = ???;  stack[1152921512892126584] = ???;  //  dest_result_addr=1152921512892126576 |  dest_result_addr=1152921512892126584
            // 0x028EEEFC: STP x22, x21, [sp, #0x30]  | stack[1152921512892126592] = ???;  stack[1152921512892126600] = ???;  //  dest_result_addr=1152921512892126592 |  dest_result_addr=1152921512892126600
            // 0x028EEF00: STP x20, x19, [sp, #0x40]  | stack[1152921512892126608] = ???;  stack[1152921512892126616] = ???;  //  dest_result_addr=1152921512892126608 |  dest_result_addr=1152921512892126616
            // 0x028EEF04: STP x29, x30, [sp, #0x50]  | stack[1152921512892126624] = ???;  stack[1152921512892126632] = ???;  //  dest_result_addr=1152921512892126624 |  dest_result_addr=1152921512892126632
            // 0x028EEF08: ADD x29, sp, #0x50         | X29 = (1152921512892126544 + 80) = 1152921512892126624 (0x10000001EDD755A0);
            // 0x028EEF0C: SUB sp, sp, #0x10          | SP = (1152921512892126544 - 16) = 1152921512892126528 (0x10000001EDD75540);
            // 0x028EEF10: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EEF14: LDRB w8, [x20, #0xa0b]     | W8 = (bool)static_value_037B8A0B;       
            // 0x028EEF18: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EEF1C: MOV x22, x2                | X22 = X2;//m1                           
            var val_23 = X2;
            // 0x028EEF20: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028EEF24: TBNZ w8, #0, #0x28eef40    | if (static_value_037B8A0B == true) goto label_0;
            // 0x028EEF28: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x028EEF2C: LDR x8, [x8, #0x488]       | X8 = 0x2B90CD4;                         
            // 0x028EEF30: LDR w0, [x8]               | W0 = 0x19F9;                            
            // 0x028EEF34: BL #0x2782188              | X0 = sub_2782188( ?? 0x19F9, ????);     
            // 0x028EEF38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EEF3C: STRB w8, [x20, #0xa0b]     | static_value_037B8A0B = true;            //  dest_result_addr=58427915
            label_0:
            // 0x028EEF40: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x028EEF44: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x028EEF48: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EEF4C: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EEF50: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EEF54: TBNZ w9, #0, #0x28eef60    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EEF58: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_24 = 8;
            // 0x028EEF5C: B #0x28eef78               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EEF60: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EEF64: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EEF68: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EEF6C: SUB w25, w0, #0x10         | W25 = (null - 16) = val_24 (0x100000000D137FF0);
            val_24 = 1152921504826228720;
            // 0x028EEF70: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EEF74: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EEF78: TBNZ w9, #0, #0x28eef84    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EEF7C: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_25 = 8;
            // 0x028EEF80: B #0x28eef90               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EEF84: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EEF88: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EEF8C: SUB w26, w0, #0x10         | W26 = (null - 16) = val_25 (0x100000000D137FF0);
            val_25 = 1152921504826228720;
            label_4:
            // 0x028EEF90: CBNZ x21, #0x28eef98       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028EEF94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EEF98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EEF9C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EEFA0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EEFA4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_26 = null;
            // 0x028EEFA8: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028EEFAC: ADD x9, x8, #0x109         | X9 = (val_26 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EEFB0: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EEFB4: TBNZ w9, #0, #0x28eefc0    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028EEFB8: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_28 = 8;
            // 0x028EEFBC: B #0x28eefd8               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028EEFC0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EEFC4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EEFC8: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_26 = null;
            // 0x028EEFCC: SUB w10, w0, #0x10         | W10 = (val_26 - 16) = val_28 (0x100000000D137FF0);
            val_28 = 1152921504826228720;
            // 0x028EEFD0: ADD x9, x8, #0x109         | X9 = (val_26 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EEFD4: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_7:
            // 0x028EEFD8: SUB x24, x22, w10, sxtw    | X24 = (X2 - (val_28) << );              
            var val_2 = val_23 - (val_28 << );
            // 0x028EEFDC: TBZ w9, #8, #0x28eeff0     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_9;
            // 0x028EEFE0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EEFE4: CBNZ w9, #0x28eeff0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x028EEFE8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EEFEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028EEFF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EEFF4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EEFF8: MOV x1, x24                | X1 = (X2 - (val_28) << );//m1           
            // 0x028EEFFC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EF000: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EF004: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_3 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028EF008: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x028EF00C: CBNZ x21, #0x28ef014       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x028EF010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x028EF014: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF018: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EF01C: MOV x1, x24                | X1 = (X2 - (val_28) << );//m1           
            // 0x028EF020: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EF024: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EF028: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF02C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EF030: TBNZ w9, #0, #0x28ef03c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_11;
            // 0x028EF034: ORR w24, wzr, #8           | W24 = 8(0x8);                           
            val_30 = 8;
            // 0x028EF038: B #0x28ef054               |  goto label_12;                         
            goto label_12;
            label_11:
            // 0x028EF03C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF040: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF044: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EF048: SUB w24, w0, #0x10         | W24 = (null - 16) = val_30 (0x100000000D137FF0);
            val_30 = 1152921504826228720;
            // 0x028EF04C: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF050: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_12:
            // 0x028EF054: TBNZ w9, #0, #0x28ef060    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_13;
            // 0x028EF058: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_31 = 8;
            // 0x028EF05C: B #0x28ef06c               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028EF060: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF064: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF068: SUB w8, w0, #0x10          | W8 = (null - 16) = val_31 (0x100000000D137FF0);
            val_31 = 1152921504826228720;
            label_14:
            // 0x028EF06C: SUB x9, x22, w24, sxtw     | X9 = (X2 - (val_30) << );               
            var val_4 = val_23 - (val_30 << );
            // 0x028EF070: SUB x24, x9, w8, sxtw      | X24 = ((X2 - (val_30) << ) - (val_31) << );
            val_30 = val_4 - (val_31 << );
            // 0x028EF074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF078: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EF07C: MOV x1, x24                | X1 = ((X2 - (val_30) << ) - (val_31) << );//m1
            // 0x028EF080: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028EF084: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EF088: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028EF08C: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_32 = 0;
            // 0x028EF090: CBZ x0, #0x28ef0f4         | if (val_5 == null) goto label_17;       
            if(val_5 == null)
            {
                goto label_17;
            }
            // 0x028EF094: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x028EF098: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x028EF09C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EF0A0: LDR x1, [x9]               | X1 = typeof(System.Type);               
            // 0x028EF0A4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF0A8: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF0AC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF0B0: B.LO #0x28ef0cc            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_16;
            // 0x028EF0B4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EF0B8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EF0BC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF0C0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EF0C4: MOV x23, x0                | X23 = val_5;//m1                        
            val_32 = val_5;
            // 0x028EF0C8: B.EQ #0x28ef0f4            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_17;
            label_16:
            // 0x028EF0CC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EF0D0: ADD x8, sp, #8             | X8 = (1152921512892126528 + 8) = 1152921512892126536 (0x10000001EDD75548);
            // 0x028EF0D4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EF0D8: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921512892114640]
            // 0x028EF0DC: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x028EF0E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF0E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x028EF0E8: ADD x0, sp, #8             | X0 = (1152921512892126528 + 8) = 1152921512892126536 (0x10000001EDD75548);
            // 0x028EF0EC: BL #0x299a140              | 
            // 0x028EF0F0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_32 = 0;
            label_17:
            // 0x028EF0F4: SUB x8, x22, w25, sxtw     | X8 = (X2 - (val_24) << );               
            var val_8 = val_23 - (val_24 << );
            // 0x028EF0F8: SUB x22, x8, w26, sxtw     | X22 = ((X2 - (val_24) << ) - (val_25) << );
            val_23 = val_8 - (val_25 << );
            // 0x028EF0FC: CBNZ x21, #0x28ef104       | if (X1 != 0) goto label_18;             
            if(X1 != 0)
            {
                goto label_18;
            }
            // 0x028EF100: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDD75548, ????);
            label_18:
            // 0x028EF104: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF108: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028EF10C: MOV x1, x24                | X1 = ((X2 - (val_30) << ) - (val_31) << );//m1
            // 0x028EF110: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EF114: CBZ x23, #0x28ef178        | if (0x0 == 0) goto label_22;            
            if(val_32 == 0)
            {
                goto label_22;
            }
            // 0x028EF118: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x028EF11C: LDR x9, [x9, #0x950]       | X9 = 1152921504821596160;               
            // 0x028EF120: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028EF124: LDR x10, [x9]              | X10 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EF128: LDRB w9, [x8, #0x104]      | W9 = (bool)mem[282584257676931];        
            // 0x028EF12C: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF130: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF134: B.LO #0x28ef14c            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_20;
            // 0x028EF138: LDR x12, [x8, #0xb0]       | X12 = mem[282584257676847];             
            // 0x028EF13C: ADD x11, x12, x11, lsl #3  | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchy
            // 0x028EF140: LDUR x11, [x11, #-8]       | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF144: CMP x11, x10               | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EF148: B.EQ #0x28ef1e8            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_21;
            label_20:
            // 0x028EF14C: ADRP x10, #0x362d000       | X10 = 56807424 (0x362D000);             
            // 0x028EF150: LDR x10, [x10, #0xc30]     | X10 = 1152921504821649408;              
            // 0x028EF154: LDR x10, [x10]             | X10 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x028EF158: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF15C: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF160: B.LO #0x28ef178            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_22;
            // 0x028EF164: LDR x8, [x8, #0xb0]        | X8 = mem[282584257676847];              
            // 0x028EF168: ADD x8, x8, x11, lsl #3    | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHie
            // 0x028EF16C: LDUR x8, [x8, #-8]         | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF170: CMP x8, x10                | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028EF174: B.EQ #0x28ef278            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_23;
            label_22:
            // 0x028EF178: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EF17C: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EF180: LDR x0, [x8]               | X0 = typeof(System.Enum);               
            // 0x028EF184: LDRB w8, [x0, #0x10a]      | W8 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EF188: TBZ w8, #0, #0x28ef198     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x028EF18C: LDR w8, [x0, #0xbc]        | W8 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EF190: CBNZ w8, #0x28ef198        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x028EF194: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_25:
            // 0x028EF198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF19C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF1A0: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            label_34:
            // 0x028EF1A4: MOV x2, x20                | X2 = val_3;//m1                         
            // 0x028EF1A8: BL #0x1c39a40              | X0 = System.Enum.GetName(enumType:  0, value:  val_32);
            string val_10 = System.Enum.GetName(enumType:  0, value:  val_32);
            label_39:
            // 0x028EF1AC: MOV x3, x0                 | X3 = val_10;//m1                        
            // 0x028EF1B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF1B4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EF1B8: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EF1BC: MOV x1, x22                | X1 = ((X2 - (val_24) << ) - (val_25) << );//m1
            // 0x028EF1C0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EF1C4: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x028EF1C8: SUB sp, x29, #0x50         | SP = (1152921512892126624 - 80) = 1152921512892126544 (0x10000001EDD75550);
            // 0x028EF1CC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EF1D0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EF1D4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EF1D8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EF1DC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EF1E0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EF1E4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_11;
            return val_11;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_21:
            // 0x028EF1E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF1EC: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EF1F0: BL #0x1100c9c              | X0 = val_32.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_12 = val_32.ILType;
            // 0x028EF1F4: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x028EF1F8: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x028EF1FC: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x028EF200: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x028EF204: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_13 = null;
            // 0x028EF208: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028EF20C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028EF210: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x028EF214: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x028EF218: BL #0x25e9474              | .ctor();                                
            val_13 = new System.Collections.Generic.List<System.String>();
            // 0x028EF21C: CBNZ x21, #0x28ef224       | if (val_12 != null) goto label_26;      
            if(val_12 != null)
            {
                goto label_26;
            }
            // 0x028EF220: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_26:
            // 0x028EF224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF228: MOV x0, x21                | X0 = val_12;//m1                        
            // 0x028EF22C: BL #0x10fb0b0              | X0 = val_12.get_IsEnum();               
            bool val_14 = val_12.IsEnum;
            // 0x028EF230: TBZ w0, #0, #0x28ef360     | if (val_14 == false) goto label_27;     
            if(val_14 == false)
            {
                goto label_27;
            }
            // 0x028EF234: ADRP x24, #0x35be000       | X24 = 56352768 (0x35BE000);             
            // 0x028EF238: LDR x24, [x24, #0x210]     | X24 = 1152921504825856000;              
            // 0x028EF23C: CBZ x20, #0x28ef2bc        | if (val_3 == null) goto label_28;       
            if(val_3 == null)
            {
                goto label_28;
            }
            // 0x028EF240: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x028EF244: LDR x9, [x24]              | X9 = typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance);
            // 0x028EF248: LDRB w11, [x8, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF24C: LDRB w10, [x9, #0x104]     | W10 = ILRuntime.Runtime.Intepreter.ILEnumTypeInstance.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF250: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ILRuntime.Runtime.Intepreter.ILEnumTypeInstance.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF254: B.LO #0x28ef2c0            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ILRuntime.Runtime.Intepreter.ILEnumTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) goto label_30;
            // 0x028EF258: LDR x11, [x8, #0xb0]       | X11 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EF25C: ADD x10, x11, x10, lsl #3  | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILEnumTypeIn
            // 0x028EF260: LDUR x10, [x10, #-8]       | X10 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILEnumTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF264: CMP x10, x9                | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILEnumTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance))
            // 0x028EF268: B.NE #0x28ef2c0            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ILRuntime.Runtime.Intepreter.ILEnumTypeInstance.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_30;
            // 0x028EF26C: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Object).__il2cppRuntimeField_140; X1 = typeof(System.Object).__il2cppRuntimeField_148; //  | 
            // 0x028EF270: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028EF274: B #0x28ef344               |  goto label_31;                         
            goto label_31;
            label_23:
            // 0x028EF278: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF27C: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028EF280: BL #0x10ff500              | X0 = val_32.get_RealType();             
            System.Type val_16 = val_32.RealType;
            // 0x028EF284: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EF288: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EF28C: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x028EF290: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x028EF294: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EF298: TBZ w9, #0, #0x28ef2ac     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x028EF29C: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EF2A0: CBNZ w9, #0x28ef2ac        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x028EF2A4: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x028EF2A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_33:
            // 0x028EF2AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF2B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF2B4: MOV x1, x21                | X1 = val_16;//m1                        
            // 0x028EF2B8: B #0x28ef1a4               |  goto label_34;                         
            goto label_34;
            label_28:
            // 0x028EF2BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_30:
            // 0x028EF2C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF2C4: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x028EF2C8: BL #0x16fb28c              | X0 = val_3.GetType();                   
            System.Type val_17 = val_3.GetType();
            // 0x028EF2CC: MOV x23, x0                | X23 = val_17;//m1                       
            // 0x028EF2D0: CBNZ x23, #0x28ef2d8       | if (val_17 != null) goto label_35;      
            if(val_17 != null)
            {
                goto label_35;
            }
            // 0x028EF2D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_35:
            // 0x028EF2D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF2DC: MOV x0, x23                | X0 = val_17;//m1                        
            // 0x028EF2E0: BL #0x1b6d41c              | X0 = val_17.get_IsPrimitive();          
            bool val_18 = val_17.IsPrimitive;
            // 0x028EF2E4: TBZ w0, #0, #0x28ef3f8     | if (val_18 == false) goto label_36;     
            if(val_18 == false)
            {
                goto label_36;
            }
            // 0x028EF2E8: LDR x0, [x24]              | X0 = typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance);
            ILRuntime.Runtime.Intepreter.ILEnumTypeInstance val_19 = null;
            // 0x028EF2EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance), ????);
            // 0x028EF2F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF2F4: MOV x1, x21                | X1 = val_12;//m1                        
            // 0x028EF2F8: MOV x23, x0                | X23 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF2FC: BL #0x1f8f700              | .ctor(type:  val_12);                   
            val_19 = new ILRuntime.Runtime.Intepreter.ILEnumTypeInstance(type:  val_12);
            // 0x028EF300: CBZ x23, #0x28ef31c        | if ( == 0) goto label_37;               
            if(null == 0)
            {
                goto label_37;
            }
            // 0x028EF304: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            val_33 = 0;
            // 0x028EF308: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF30C: MOV x0, x23                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF310: MOV x2, x20                | X2 = val_3;//m1                         
            // 0x028EF314: BL #0x1f96638              | set_Item(index:  0, value:  val_3);     
            set_Item(index:  0, value:  val_3);
            // 0x028EF318: B #0x28ef338               |  goto label_38;                         
            goto label_38;
            label_37:
            // 0x028EF31C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(type:  val_12), ????);
            // 0x028EF320: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF324: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            val_33 = 0;
            // 0x028EF328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF32C: MOV x2, x20                | X2 = val_3;//m1                         
            // 0x028EF330: BL #0x1f96638              | 0.set_Item(index:  0, value:  val_3);   
            0.set_Item(index:  0, value:  val_3);
            // 0x028EF334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_38:
            // 0x028EF338: LDR x8, [x23]              | X8 = ;                                  
            // 0x028EF33C: MOV x0, x23                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF340: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            label_31:
            // 0x028EF344: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x028EF348: B #0x28ef1ac               |  goto label_39;                         
            goto label_39;
            // 0x028EF34C: MOV x19, x0                | X19 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF350: ADD x0, sp, #8             | X0 = (1152921512892126528 + 8) = 1152921512892126536 (0x10000001EDD75548);
            // 0x028EF354: BL #0x299a140              | 
            // 0x028EF358: MOV x0, x19                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF35C: BL #0x980800               | X0 = sub_980800( ?? typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance), ????);
            label_27:
            // 0x028EF360: LDR x8, [x23]              | X8 = ;                                  
            // 0x028EF364: MOV x0, x23                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF368: LDR x9, [x8, #0x230]       |  //  not_find_field!1:560
            // 0x028EF36C: LDR x1, [x8, #0x238]       |  //  not_find_field!1:568
            // 0x028EF370: BLR x9                     | X0 = mem[null + 560]();                 
            // 0x028EF374: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EF378: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028EF37C: MOV x19, x0                | X19 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF380: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028EF384: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028EF388: TBZ w9, #0, #0x28ef39c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_41;
            // 0x028EF38C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028EF390: CBNZ w9, #0x28ef39c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x028EF394: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028EF398: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_41:
            // 0x028EF39C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x028EF3A0: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921512891250144)("{0} is not Enum");
            // 0x028EF3A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF3A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF3AC: MOV x2, x19                | X2 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF3B0: LDR x1, [x8]               | X1 = "{0} is not Enum";                 
            // 0x028EF3B4: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            string val_20 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            // 0x028EF3B8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028EF3BC: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028EF3C0: MOV x19, x0                | X19 = val_20;//m1                       
            // 0x028EF3C4: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028EF3C8: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_21 = null;
            // 0x028EF3CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028EF3D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF3D4: MOV x1, x19                | X1 = val_20;//m1                        
            // 0x028EF3D8: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EF3DC: BL #0x1c32b48              | .ctor(message:  val_20);                
            val_21 = new System.Exception(message:  val_20);
            // 0x028EF3E0: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x028EF3E4: LDR x8, [x8, #0x568]       | X8 = 1152921512878458864;               
            // 0x028EF3E8: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EF3EC: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::EnumGetName(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EF3F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028EF3F4: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
            label_36:
            // 0x028EF3F8: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x028EF3FC: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x028EF400: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_22 = null;
            // 0x028EF404: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x028EF408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF40C: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x028EF410: BL #0x17014c0              | .ctor();                                
            val_22 = new System.NotImplementedException();
            // 0x028EF414: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x028EF418: LDR x8, [x8, #0x568]       | X8 = 1152921512878458864;               
            // 0x028EF41C: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x028EF420: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::EnumGetName(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EF424: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x028EF428: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
        
        }
        //
        // Offset in libil2cpp.so: 0x028EF42C (42923052), len: 1260  VirtAddr: 0x028EF42C RVA: 0x028EF42C token: 100680285 methodIndex: 29573 delegateWrapperIndex: 0 methodInvoker: 0
        public static ILRuntime.Runtime.Stack.StackObject* EnumToObject(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.IList<System.Object> val_6;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            //  | 
            var val_25;
            //  | 
            object val_26;
            //  | 
            var val_27;
            // 0x028EF42C: STP x28, x27, [sp, #-0x60]! | stack[1152921512892332752] = ???;  stack[1152921512892332760] = ???;  //  dest_result_addr=1152921512892332752 |  dest_result_addr=1152921512892332760
            // 0x028EF430: STP x26, x25, [sp, #0x10]  | stack[1152921512892332768] = ???;  stack[1152921512892332776] = ???;  //  dest_result_addr=1152921512892332768 |  dest_result_addr=1152921512892332776
            // 0x028EF434: STP x24, x23, [sp, #0x20]  | stack[1152921512892332784] = ???;  stack[1152921512892332792] = ???;  //  dest_result_addr=1152921512892332784 |  dest_result_addr=1152921512892332792
            // 0x028EF438: STP x22, x21, [sp, #0x30]  | stack[1152921512892332800] = ???;  stack[1152921512892332808] = ???;  //  dest_result_addr=1152921512892332800 |  dest_result_addr=1152921512892332808
            // 0x028EF43C: STP x20, x19, [sp, #0x40]  | stack[1152921512892332816] = ???;  stack[1152921512892332824] = ???;  //  dest_result_addr=1152921512892332816 |  dest_result_addr=1152921512892332824
            // 0x028EF440: STP x29, x30, [sp, #0x50]  | stack[1152921512892332832] = ???;  stack[1152921512892332840] = ???;  //  dest_result_addr=1152921512892332832 |  dest_result_addr=1152921512892332840
            // 0x028EF444: ADD x29, sp, #0x50         | X29 = (1152921512892332752 + 80) = 1152921512892332832 (0x10000001EDDA7B20);
            // 0x028EF448: SUB sp, sp, #0x10          | SP = (1152921512892332752 - 16) = 1152921512892332736 (0x10000001EDDA7AC0);
            // 0x028EF44C: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028EF450: LDRB w8, [x22, #0xa0c]     | W8 = (bool)static_value_037B8A0C;       
            // 0x028EF454: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028EF458: MOV x21, x2                | X21 = X2;//m1                           
            var val_18 = X2;
            // 0x028EF45C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028EF460: TBNZ w8, #0, #0x28ef47c    | if (static_value_037B8A0C == true) goto label_0;
            // 0x028EF464: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x028EF468: LDR x8, [x8, #0xf78]       | X8 = 0x2B90CE4;                         
            // 0x028EF46C: LDR w0, [x8]               | W0 = 0x19FD;                            
            // 0x028EF470: BL #0x2782188              | X0 = sub_2782188( ?? 0x19FD, ????);     
            // 0x028EF474: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EF478: STRB w8, [x22, #0xa0c]     | static_value_037B8A0C = true;            //  dest_result_addr=58427916
            label_0:
            // 0x028EF47C: ADRP x27, #0x366f000       | X27 = 57077760 (0x366F000);             
            // 0x028EF480: LDR x27, [x27, #0x7a0]     | X27 = 1152921504826228736;              
            // 0x028EF484: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EF488: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF48C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EF490: TBNZ w9, #0, #0x28ef49c    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_1;
            // 0x028EF494: ORR w25, wzr, #8           | W25 = 8(0x8);                           
            val_19 = 8;
            // 0x028EF498: B #0x28ef4b4               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x028EF49C: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF4A0: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF4A4: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EF4A8: SUB w25, w0, #0x10         | W25 = (null - 16) = val_19 (0x100000000D137FF0);
            val_19 = 1152921504826228720;
            // 0x028EF4AC: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF4B0: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_2:
            // 0x028EF4B4: TBNZ w9, #0, #0x28ef4c0    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_3;
            // 0x028EF4B8: ORR w26, wzr, #8           | W26 = 8(0x8);                           
            val_20 = 8;
            // 0x028EF4BC: B #0x28ef4cc               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x028EF4C0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF4C4: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF4C8: SUB w26, w0, #0x10         | W26 = (null - 16) = val_20 (0x100000000D137FF0);
            val_20 = 1152921504826228720;
            label_4:
            // 0x028EF4CC: CBNZ x20, #0x28ef4d4       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028EF4D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028EF4D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF4D8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EF4DC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028EF4E0: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028EF4E4: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x028EF4E8: LDRB w9, [x8, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EF4EC: TBNZ w9, #0, #0x28ef4f8    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_6;
            // 0x028EF4F0: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_21 = 8;
            // 0x028EF4F4: B #0x28ef504               |  goto label_7;                          
            goto label_7;
            label_6:
            // 0x028EF4F8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF4FC: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF500: SUB w8, w0, #0x10          | W8 = (null - 16) = val_21 (0x100000000D137FF0);
            val_21 = 1152921504826228720;
            label_7:
            // 0x028EF504: SUBS x23, x21, w8, sxtw    | X23 = (X2 - (val_21) << );              
            var val_2 = val_18 - (val_21 << );
            // 0x028EF508: B.NE #0x28ef510            | if ( != ) goto label_8;                 
            if()
            {
                goto label_8;
            }
            // 0x028EF50C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_8:
            // 0x028EF510: LDR w24, [x23, #4]         | W24 = (X2 - (val_21) << ) + 4;          
            // 0x028EF514: CBNZ x20, #0x28ef51c       | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x028EF518: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_9:
            // 0x028EF51C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF520: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EF524: MOV x1, x23                | X1 = (X2 - (val_21) << );//m1           
            // 0x028EF528: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EF52C: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_22 = null;
            // 0x028EF530: ADD x9, x8, #0x109         | X9 = (val_22 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF534: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028EF538: TBNZ w9, #0, #0x28ef544    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_10;
            // 0x028EF53C: ORR w23, wzr, #8           | W23 = 8(0x8);                           
            val_24 = 8;
            // 0x028EF540: B #0x28ef55c               |  goto label_11;                         
            goto label_11;
            label_10:
            // 0x028EF544: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF548: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF54C: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_22 = null;
            // 0x028EF550: SUB w23, w0, #0x10         | W23 = (val_22 - 16) = val_24 (0x100000000D137FF0);
            val_24 = 1152921504826228720;
            // 0x028EF554: ADD x9, x8, #0x109         | X9 = (val_22 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF558: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_11:
            // 0x028EF55C: TBNZ w9, #0, #0x28ef568    | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype != 0) goto label_12;
            // 0x028EF560: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            val_25 = 8;
            // 0x028EF564: B #0x28ef580               |  goto label_13;                         
            goto label_13;
            label_12:
            // 0x028EF568: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF56C: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028EF570: LDR x8, [x27]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            val_22 = null;
            // 0x028EF574: SUB w10, w0, #0x10         | W10 = (val_22 - 16) = val_25 (0x100000000D137FF0);
            val_25 = 1152921504826228720;
            // 0x028EF578: ADD x9, x8, #0x109         | X9 = (val_22 + 265) = 1152921504826229001 (0x100000000D138109);
            // 0x028EF57C: LDRH w9, [x9]              | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            label_13:
            // 0x028EF580: SUB x11, x21, w23, sxtw    | X11 = (X2 - (val_24) << );              
            var val_3 = val_18 - (val_24 << );
            // 0x028EF584: SUB x23, x11, w10, sxtw    | X23 = ((X2 - (val_24) << ) - (val_25) << );
            val_24 = val_3 - (val_25 << );
            // 0x028EF588: TBZ w9, #8, #0x28ef59c     | if ((ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109 & 0x100) == 0) goto label_15;
            // 0x028EF58C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028EF590: CBNZ w9, #0x28ef59c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x028EF594: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028EF598: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_15:
            // 0x028EF59C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF5A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028EF5A4: MOV x1, x23                | X1 = ((X2 - (val_24) << ) - (val_25) << );//m1
            // 0x028EF5A8: MOV x2, x22                | X2 = val_1;//m1                         
            // 0x028EF5AC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028EF5B0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_4 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028EF5B4: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_26 = 0;
            // 0x028EF5B8: CBZ x0, #0x28ef61c         | if (val_4 == null) goto label_18;       
            if(val_4 == null)
            {
                goto label_18;
            }
            // 0x028EF5BC: ADRP x9, #0x3620000        | X9 = 56754176 (0x3620000);              
            // 0x028EF5C0: LDR x9, [x9, #0x340]       | X9 = 1152921504609562624;               
            // 0x028EF5C4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028EF5C8: LDR x1, [x9]               | X1 = typeof(System.Type);               
            // 0x028EF5CC: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF5D0: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF5D4: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF5D8: B.LO #0x28ef5f4            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_17;
            // 0x028EF5DC: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028EF5E0: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x028EF5E4: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF5E8: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x028EF5EC: MOV x22, x0                | X22 = val_4;//m1                        
            val_26 = val_4;
            // 0x028EF5F0: B.EQ #0x28ef61c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_18;
            label_17:
            // 0x028EF5F4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028EF5F8: ADD x8, sp, #8             | X8 = (1152921512892332736 + 8) = 1152921512892332744 (0x10000001EDDA7AC8);
            // 0x028EF5FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028EF600: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921512892320848]
            // 0x028EF604: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x028EF608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF60C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x028EF610: ADD x0, sp, #8             | X0 = (1152921512892332736 + 8) = 1152921512892332744 (0x10000001EDDA7AC8);
            // 0x028EF614: BL #0x299a140              | 
            // 0x028EF618: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_26 = 0;
            label_18:
            // 0x028EF61C: SUB x8, x21, w25, sxtw     | X8 = (X2 - (val_19) << );               
            var val_7 = val_18 - (val_19 << );
            // 0x028EF620: SUB x21, x8, w26, sxtw     | X21 = ((X2 - (val_19) << ) - (val_20) << );
            val_18 = val_7 - (val_20 << );
            // 0x028EF624: CBNZ x20, #0x28ef62c       | if (X1 != 0) goto label_19;             
            if(X1 != 0)
            {
                goto label_19;
            }
            // 0x028EF628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001EDDA7AC8, ????);
            label_19:
            // 0x028EF62C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF630: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028EF634: MOV x1, x23                | X1 = ((X2 - (val_24) << ) - (val_25) << );//m1
            // 0x028EF638: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028EF63C: CBZ x22, #0x28ef6a0        | if (0x0 == 0) goto label_23;            
            if(val_26 == 0)
            {
                goto label_23;
            }
            // 0x028EF640: ADRP x9, #0x35eb000        | X9 = 56537088 (0x35EB000);              
            // 0x028EF644: LDR x9, [x9, #0x950]       | X9 = 1152921504821596160;               
            // 0x028EF648: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x028EF64C: LDR x10, [x9]              | X10 = typeof(ILRuntime.Reflection.ILRuntimeType);
            // 0x028EF650: LDRB w9, [x8, #0x104]      | W9 = (bool)mem[282584257676931];        
            // 0x028EF654: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF658: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF65C: B.LO #0x28ef674            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) goto label_21;
            // 0x028EF660: LDR x12, [x8, #0xb0]       | X12 = mem[282584257676847];             
            // 0x028EF664: ADD x11, x12, x11, lsl #3  | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchy
            // 0x028EF668: LDUR x11, [x11, #-8]       | X11 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF66C: CMP x11, x10               | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeType))
            // 0x028EF670: B.EQ #0x28ef730            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_22;
            label_21:
            // 0x028EF674: ADRP x10, #0x362d000       | X10 = 56807424 (0x362D000);             
            // 0x028EF678: LDR x10, [x10, #0xc30]     | X10 = 1152921504821649408;              
            // 0x028EF67C: LDR x10, [x10]             | X10 = typeof(ILRuntime.Reflection.ILRuntimeWrapperType);
            // 0x028EF680: LDRB w11, [x10, #0x104]    | W11 = ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028EF684: CMP w9, w11                | STATE = COMPARE(mem[282584257676931], ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028EF688: B.LO #0x28ef6a0            | if (mem[282584257676931] < ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) goto label_23;
            // 0x028EF68C: LDR x8, [x8, #0xb0]        | X8 = mem[282584257676847];              
            // 0x028EF690: ADD x8, x8, x11, lsl #3    | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHie
            // 0x028EF694: LDUR x8, [x8, #-8]         | X8 = (mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028EF698: CMP x8, x10                | STATE = COMPARE((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ILRuntime.Reflection.ILRuntimeWrapperType))
            // 0x028EF69C: B.EQ #0x28ef7d4            | if ((mem[282584257676847] + (ILRuntime.Reflection.ILRuntimeWrapperType.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_24;
            label_23:
            // 0x028EF6A0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028EF6A4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028EF6A8: ADD x1, sp, #8             | X1 = (1152921512892332736 + 8) = 1152921512892332744 (0x10000001EDDA7AC8);
            // 0x028EF6AC: STR w24, [sp, #8]          | val_6 = (X2 - (val_21) << ) + 4;         //  dest_result_addr=1152921512892332744
            val_6 = (X2 - (val_21) << ) + 4;
            // 0x028EF6B0: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028EF6B4: BL #0x27bc028              | X0 = 1152921512892397328 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (X2 - (val_21) << ) + 4);
            // 0x028EF6B8: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EF6BC: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EF6C0: MOV x20, x0                | X20 = 1152921512892397328 (0x10000001EDDB7710);//ML01
            // 0x028EF6C4: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x028EF6C8: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EF6CC: TBZ w9, #0, #0x28ef6e0     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x028EF6D0: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EF6D4: CBNZ w9, #0x28ef6e0        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x028EF6D8: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x028EF6DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_26:
            // 0x028EF6E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF6E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF6E8: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x028EF6EC: MOV x2, x20                | X2 = 1152921512892397328 (0x10000001EDDB7710);//ML01
            label_33:
            // 0x028EF6F0: BL #0x1c39a40              | X0 = System.Enum.GetName(enumType:  0, value:  val_26);
            string val_9 = System.Enum.GetName(enumType:  0, value:  val_26);
            label_34:
            // 0x028EF6F4: MOV x3, x0                 | X3 = val_9;//m1                         
            // 0x028EF6F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF6FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028EF700: ORR w4, wzr, #1            | W4 = 1(0x1);                            
            // 0x028EF704: MOV x1, x21                | X1 = ((X2 - (val_19) << ) - (val_20) << );//m1
            // 0x028EF708: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028EF70C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  val_6 = (X2 - (val_21) << ) + 4, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_10 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  val_6, obj:  ???, isBox:  ???);
            // 0x028EF710: SUB sp, x29, #0x50         | SP = (1152921512892332832 - 80) = 1152921512892332752 (0x10000001EDDA7AD0);
            // 0x028EF714: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028EF718: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028EF71C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028EF720: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028EF724: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028EF728: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028EF72C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_22:
            // 0x028EF730: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF734: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EF738: BL #0x1100c9c              | X0 = val_26.get_ILType();               
            ILRuntime.CLR.TypeSystem.ILType val_11 = val_26.ILType;
            // 0x028EF73C: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x028EF740: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x028EF744: MOV x23, x0                | X23 = val_11;//m1                       
            // 0x028EF748: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x028EF74C: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_12 = null;
            // 0x028EF750: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x028EF754: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028EF758: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x028EF75C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x028EF760: BL #0x25e9474              | .ctor();                                
            val_12 = new System.Collections.Generic.List<System.String>();
            // 0x028EF764: CBNZ x23, #0x28ef76c       | if (val_11 != null) goto label_27;      
            if(val_11 != null)
            {
                goto label_27;
            }
            // 0x028EF768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_27:
            // 0x028EF76C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF770: MOV x0, x23                | X0 = val_11;//m1                        
            // 0x028EF774: BL #0x10fb0b0              | X0 = val_11.get_IsEnum();               
            bool val_13 = val_11.IsEnum;
            // 0x028EF778: TBZ w0, #0, #0x28ef880     | if (val_13 == false) goto label_28;     
            if(val_13 == false)
            {
                goto label_28;
            }
            // 0x028EF77C: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
            // 0x028EF780: LDR x8, [x8, #0x210]       | X8 = 1152921504825856000;               
            // 0x028EF784: LDR x0, [x8]               | X0 = typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance);
            ILRuntime.Runtime.Intepreter.ILEnumTypeInstance val_14 = null;
            // 0x028EF788: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance), ????);
            // 0x028EF78C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF790: MOV x1, x23                | X1 = val_11;//m1                        
            // 0x028EF794: MOV x20, x0                | X20 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF798: BL #0x1f8f700              | .ctor(type:  val_11);                   
            val_14 = new ILRuntime.Runtime.Intepreter.ILEnumTypeInstance(type:  val_11);
            // 0x028EF79C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028EF7A0: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028EF7A4: ADD x1, sp, #8             | X1 = (1152921512892332736 + 8) = 1152921512892332744 (0x10000001EDDA7AC8);
            // 0x028EF7A8: STR w24, [sp, #8]          | val_6 = (X2 - (val_21) << ) + 4;         //  dest_result_addr=1152921512892332744
            val_6 = (X2 - (val_21) << ) + 4;
            // 0x028EF7AC: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x028EF7B0: BL #0x27bc028              | X0 = 1152921512892409616 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (X2 - (val_21) << ) + 4);
            // 0x028EF7B4: MOV x22, x0                | X22 = 1152921512892409616 (0x10000001EDDBA710);//ML01
            // 0x028EF7B8: CBZ x20, #0x28ef83c        | if ( == 0) goto label_29;               
            if(null == 0)
            {
                goto label_29;
            }
            // 0x028EF7BC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x028EF7C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF7C4: MOV x0, x20                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF7C8: MOV x2, x22                | X2 = 1152921512892409616 (0x10000001EDDBA710);//ML01
            // 0x028EF7CC: BL #0x1f96638              | set_Item(index:  0, value:  val_6 = (X2 - (val_21) << ) + 4);
            set_Item(index:  0, value:  val_6);
            // 0x028EF7D0: B #0x28ef858               |  goto label_30;                         
            goto label_30;
            label_24:
            // 0x028EF7D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF7D8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028EF7DC: BL #0x10ff500              | X0 = val_26.get_RealType();             
            System.Type val_15 = val_26.RealType;
            // 0x028EF7E0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x028EF7E4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x028EF7E8: MOV x20, x0                | X20 = val_15;//m1                       
            // 0x028EF7EC: ADD x1, sp, #8             | X1 = (1152921512892332736 + 8) = 1152921512892332744 (0x10000001EDDA7AC8);
            // 0x028EF7F0: STR w24, [sp, #8]          | val_6 = (X2 - (val_21) << ) + 4;         //  dest_result_addr=1152921512892332744
            val_6 = (X2 - (val_21) << ) + 4;
            // 0x028EF7F4: LDR x8, [x8]               | X8 = typeof(System.Int32);              
            // 0x028EF7F8: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x028EF7FC: BL #0x27bc028              | X0 = 1152921512892417808 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), (X2 - (val_21) << ) + 4);
            // 0x028EF800: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028EF804: LDR x8, [x8, #0x9e8]       | X8 = 1152921504608923648;               
            // 0x028EF808: MOV x22, x0                | X22 = 1152921512892417808 (0x10000001EDDBC710);//ML01
            // 0x028EF80C: LDR x8, [x8]               | X8 = typeof(System.Enum);               
            // 0x028EF810: LDRB w9, [x8, #0x10a]      | W9 = System.Enum.__il2cppRuntimeField_10A;
            // 0x028EF814: TBZ w9, #0, #0x28ef828     | if (System.Enum.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x028EF818: LDR w9, [x8, #0xbc]        | W9 = System.Enum.__il2cppRuntimeField_cctor_finished;
            // 0x028EF81C: CBNZ w9, #0x28ef828        | if (System.Enum.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x028EF820: MOV x0, x8                 | X0 = 1152921504608923648 (0x10000000001FB000);//ML01
            // 0x028EF824: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Enum), ????);
            label_32:
            // 0x028EF828: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF82C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF830: MOV x1, x20                | X1 = val_15;//m1                        
            // 0x028EF834: MOV x2, x22                | X2 = 1152921512892417808 (0x10000001EDDBC710);//ML01
            // 0x028EF838: B #0x28ef6f0               |  goto label_33;                         
            goto label_33;
            label_29:
            // 0x028EF83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X2 - (val_21) << ) + 4, ????);
            // 0x028EF840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF844: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x028EF848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF84C: MOV x2, x22                | X2 = 1152921512892409616 (0x10000001EDDBA710);//ML01
            // 0x028EF850: BL #0x1f96638              | 0.set_Item(index:  0, value:  val_6);   
            0.set_Item(index:  0, value:  val_6);
            // 0x028EF854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_30:
            // 0x028EF858: LDR x8, [x20]              | X8 = ;                                  
            // 0x028EF85C: MOV x0, x20                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF860: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x028EF864: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x028EF868: B #0x28ef6f4               |  goto label_34;                         
            goto label_34;
            // 0x028EF86C: MOV x19, x0                | X19 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF870: ADD x0, sp, #8             | X0 = (1152921512892332736 + 8) = 1152921512892332744 (0x10000001EDDA7AC8);
            // 0x028EF874: BL #0x299a140              | (RuntimeObject*)Object::New((RuntimeClass*)0x10000001EDDA7AC8); //ERROR_TYPE
            // 0x028EF878: MOV x0, x19                | X0 = 1152921504825856000 (0x100000000D0DD000);//ML01
            // 0x028EF87C: BL #0x980800               | X0 = sub_980800( ?? typeof(ILRuntime.Runtime.Intepreter.ILEnumTypeInstance), ????);
            label_28:
            // 0x028EF880: LDR x8, [x22]              | X8 = typeof(System.Int32);              
            // 0x028EF884: MOV x0, x22                | X0 = 1152921512892409616 (0x10000001EDDBA710);//ML01
            // 0x028EF888: LDR x9, [x8, #0x230]       | X9 = typeof(System.Int32).__il2cppRuntimeField_230;
            // 0x028EF88C: LDR x1, [x8, #0x238]       | X1 = typeof(System.Int32).__il2cppRuntimeField_238;
            // 0x028EF890: BLR x9                     | X0 = typeof(System.Int32).__il2cppRuntimeField_230();
            // 0x028EF894: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028EF898: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028EF89C: MOV x19, x0                | X19 = 1152921512892409616 (0x10000001EDDBA710);//ML01
            // 0x028EF8A0: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x028EF8A4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x028EF8A8: TBZ w9, #0, #0x28ef8bc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x028EF8AC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x028EF8B0: CBNZ w9, #0x28ef8bc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x028EF8B4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x028EF8B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_36:
            // 0x028EF8BC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x028EF8C0: LDR x8, [x8, #0xd08]       | X8 = (string**)(1152921512891250144)("{0} is not Enum");
            // 0x028EF8C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF8C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028EF8CC: MOV x2, x19                | X2 = 1152921512892409616 (0x10000001EDDBA710);//ML01
            // 0x028EF8D0: LDR x1, [x8]               | X1 = "{0} is not Enum";                 
            // 0x028EF8D4: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            string val_16 = System.String.Format(format:  0, arg0:  "{0} is not Enum");
            // 0x028EF8D8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x028EF8DC: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x028EF8E0: MOV x19, x0                | X19 = val_16;//m1                       
            // 0x028EF8E4: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x028EF8E8: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_17 = null;
            // 0x028EF8EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x028EF8F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028EF8F4: MOV x1, x19                | X1 = val_16;//m1                        
            // 0x028EF8F8: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EF8FC: BL #0x1c32b48              | .ctor(message:  val_16);                
            val_17 = new System.Exception(message:  val_16);
            // 0x028EF900: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x028EF904: LDR x8, [x8, #0x6a8]       | X8 = 1152921512878463984;               
            // 0x028EF908: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x028EF90C: LDR x1, [x8]               | X1 = public static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Enviorment.CLRRedirections::EnumToObject(ILRuntime.Runtime.Intepreter.ILIntepreter intp, ILRuntime.Runtime.Stack.StackObject* esp, System.Collections.Generic.IList<object> mStack, ILRuntime.CLR.Method.CLRMethod method, bool isNewObj);
            // 0x028EF910: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x028EF914: BL #0x28dd4ec              | ResolvePendingRequests();               
            ResolvePendingRequests();
        
        }
    
    }

}
