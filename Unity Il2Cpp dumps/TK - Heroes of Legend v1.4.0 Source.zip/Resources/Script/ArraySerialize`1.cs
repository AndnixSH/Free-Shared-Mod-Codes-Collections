using UnityEngine;

namespace wxb
{
    internal abstract class ArraySerialize<T> : IListSerialize<T>
    {
        // Methods
        // Generic instance method:
        //
        // file offset: 0x01D8716C VirtAddr: 0x01D8716C -RVA: 0x01D8716C 
        // -ArraySerialize<object>..ctor
        //
        // file offset: 0x01D86E84 VirtAddr: 0x01D86E84 -RVA: 0x01D86E84 
        // -ArraySerialize<byte>..ctor
        //
        // file offset: 0x01D86F00 VirtAddr: 0x01D86F00 -RVA: 0x01D86F00 
        // -ArraySerialize<char>..ctor
        //
        // file offset: 0x01D86F7C VirtAddr: 0x01D86F7C -RVA: 0x01D86F7C 
        // -ArraySerialize<double>..ctor
        //
        // file offset: 0x01D87264 VirtAddr: 0x01D87264 -RVA: 0x01D87264 
        // -ArraySerialize<float>..ctor
        //
        // file offset: 0x01D87074 VirtAddr: 0x01D87074 -RVA: 0x01D87074 
        // -ArraySerialize<int>..ctor
        //
        // file offset: 0x01D870F0 VirtAddr: 0x01D870F0 -RVA: 0x01D870F0 
        // -ArraySerialize<long>..ctor
        //
        // file offset: 0x01D871E8 VirtAddr: 0x01D871E8 -RVA: 0x01D871E8 
        // -ArraySerialize<sbyte>..ctor
        //
        // file offset: 0x01D86FF8 VirtAddr: 0x01D86FF8 -RVA: 0x01D86FF8 
        // -ArraySerialize<short>..ctor
        //
        // file offset: 0x01D8735C VirtAddr: 0x01D8735C -RVA: 0x01D8735C 
        // -ArraySerialize<uint>..ctor
        //
        // file offset: 0x01D873D8 VirtAddr: 0x01D873D8 -RVA: 0x01D873D8 
        // -ArraySerialize<ulong>..ctor
        //
        // file offset: 0x01D872E0 VirtAddr: 0x01D872E0 -RVA: 0x01D872E0 
        // -ArraySerialize<ushort>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x01D8716C (30962028), len: 60  VirtAddr: 0x01D8716C RVA: 0x01D8716C token: 100681175 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected ArraySerialize<T>()
        {
            //
            // Disasemble & Code
            // 0x01D8716C: STP x20, x19, [sp, #-0x20]! | stack[1152921513022837920] = ???;  stack[1152921513022837928] = ???;  //  dest_result_addr=1152921513022837920 |  dest_result_addr=1152921513022837928
            // 0x01D87170: STP x29, x30, [sp, #0x10]  | stack[1152921513022837936] = ???;  stack[1152921513022837944] = ???;  //  dest_result_addr=1152921513022837936 |  dest_result_addr=1152921513022837944
            // 0x01D87174: ADD x29, sp, #0x10         | X29 = (1152921513022837920 + 16) = 1152921513022837936 (0x10000001F5A1D4B0);
            // 0x01D87178: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D8717C: MOV x20, x0                | X20 = 1152921513022849952 (0x10000001F5A203A0);//ML01
            // 0x01D87180: CBNZ x20, #0x1d87188       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D87184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D87188: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D8718C: MOV x0, x20                | X0 = 1152921513022849952 (0x10000001F5A203A0);//ML01
            // 0x01D87190: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D87194: LDR x1, [x8]               | X1 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D87198: LDR x2, [x1]               | X2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D8719C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D871A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D871A4: BR x2                      | goto __RuntimeMethodHiddenParam + 24 + 168;
            goto __RuntimeMethodHiddenParam + 24 + 168;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D871A8 VirtAddr: 0x01D871A8 -RVA: 0x01D871A8 
        // -ArraySerialize<object>.Create
        //
        // file offset: 0x01D86EC0 VirtAddr: 0x01D86EC0 -RVA: 0x01D86EC0 
        // -ArraySerialize<byte>.Create
        //
        // file offset: 0x01D86F3C VirtAddr: 0x01D86F3C -RVA: 0x01D86F3C 
        // -ArraySerialize<char>.Create
        //
        // file offset: 0x01D86FB8 VirtAddr: 0x01D86FB8 -RVA: 0x01D86FB8 
        // -ArraySerialize<double>.Create
        //
        // file offset: 0x01D87034 VirtAddr: 0x01D87034 -RVA: 0x01D87034 
        // -ArraySerialize<short>.Create
        //
        // file offset: 0x01D870B0 VirtAddr: 0x01D870B0 -RVA: 0x01D870B0 
        // -ArraySerialize<int>.Create
        //
        // file offset: 0x01D8712C VirtAddr: 0x01D8712C -RVA: 0x01D8712C 
        // -ArraySerialize<long>.Create
        //
        // file offset: 0x01D87224 VirtAddr: 0x01D87224 -RVA: 0x01D87224 
        // -ArraySerialize<sbyte>.Create
        //
        // file offset: 0x01D872A0 VirtAddr: 0x01D872A0 -RVA: 0x01D872A0 
        // -ArraySerialize<float>.Create
        //
        // file offset: 0x01D8731C VirtAddr: 0x01D8731C -RVA: 0x01D8731C 
        // -ArraySerialize<ushort>.Create
        //
        // file offset: 0x01D87398 VirtAddr: 0x01D87398 -RVA: 0x01D87398 
        // -ArraySerialize<uint>.Create
        //
        // file offset: 0x01D87414 VirtAddr: 0x01D87414 -RVA: 0x01D87414 
        // -ArraySerialize<ulong>.Create
        //
        //
        // Offset in libil2cpp.so: 0x01D871A8 (30962088), len: 64  VirtAddr: 0x01D871A8 RVA: 0x01D871A8 token: 100681176 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected override System.Collections.Generic.IList<T> Create(int lenght)
        {
            //
            // Disasemble & Code
            // 0x01D871A8: STP x20, x19, [sp, #-0x20]! | stack[1152921513022949920] = ???;  stack[1152921513022949928] = ???;  //  dest_result_addr=1152921513022949920 |  dest_result_addr=1152921513022949928
            // 0x01D871AC: STP x29, x30, [sp, #0x10]  | stack[1152921513022949936] = ???;  stack[1152921513022949944] = ???;  //  dest_result_addr=1152921513022949936 |  dest_result_addr=1152921513022949944
            // 0x01D871B0: ADD x29, sp, #0x10         | X29 = (1152921513022949920 + 16) = 1152921513022949936 (0x10000001F5A38A30);
            // 0x01D871B4: LDR x8, [x2, #0x18]        | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D871B8: MOV w20, w1                | W20 = lenght;//m1                       
            // 0x01D871BC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D871C0: LDR x19, [x8, #0x10]       | X19 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x01D871C4: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x01D871C8: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
            // 0x01D871CC: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x01D871D0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
            // 0x01D871D4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D871D8: MOV w1, w20                | W1 = lenght;//m1                        
            // 0x01D871DC: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
            // 0x01D871E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D871E4: B #0x27c1608               | X0 = sub_27C1608( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        
        }
    
    }

}
