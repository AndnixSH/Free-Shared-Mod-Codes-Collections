using UnityEngine;

namespace ProtoBuf
{
    public static class BclHelpers
    {
        // Fields
        private const int FieldTimeSpanValue = 1;
        private const int FieldTimeSpanScale = 2;
        internal static readonly System.DateTime EpochOrigin; // static_offset: 0x00000000
        private const int FieldDecimalLow = 1;
        private const int FieldDecimalHigh = 2;
        private const int FieldDecimalSignScale = 3;
        private const int FieldGuidLow = 1;
        private const int FieldGuidHigh = 2;
        private const int FieldExistingObjectKey = 1;
        private const int FieldNewObjectKey = 2;
        private const int FieldExistingTypeKey = 3;
        private const int FieldNewTypeKey = 4;
        private const int FieldTypeName = 8;
        private const int FieldObject = 10;
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00C79CE8 (13081832), len: 112  VirtAddr: 0x00C79CE8 RVA: 0x00C79CE8 token: 100689115 methodIndex: 53346 delegateWrapperIndex: 0 methodInvoker: 0
        public static object GetUninitializedObject(System.Type type)
        {
            //
            // Disasemble & Code
            // 0x00C79CE8: STP x20, x19, [sp, #-0x20]! | stack[1152921514332060384] = ???;  stack[1152921514332060392] = ???;  //  dest_result_addr=1152921514332060384 |  dest_result_addr=1152921514332060392
            // 0x00C79CEC: STP x29, x30, [sp, #0x10]  | stack[1152921514332060400] = ???;  stack[1152921514332060408] = ???;  //  dest_result_addr=1152921514332060400 |  dest_result_addr=1152921514332060408
            // 0x00C79CF0: ADD x29, sp, #0x10         | X29 = (1152921514332060384 + 16) = 1152921514332060400 (0x1000000243AAFAF0);
            // 0x00C79CF4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00C79CF8: LDRB w8, [x19, #0xf76]     | W8 = (bool)static_value_03733F76;       
            // 0x00C79CFC: TBNZ w8, #0, #0xc79d18     | if (static_value_03733F76 == true) goto label_0;
            // 0x00C79D00: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00C79D04: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8F140;                         
            // 0x00C79D08: LDR w0, [x8]               | W0 = 0x1312;                            
            // 0x00C79D0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1312, ????);     
            // 0x00C79D10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C79D14: STRB w8, [x19, #0xf76]     | static_value_03733F76 = true;            //  dest_result_addr=57884534
            label_0:
            // 0x00C79D18: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00C79D1C: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x00C79D20: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_1 = null;
            // 0x00C79D24: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x00C79D28: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00C79D2C: LDR x8, [x8, #0x6a8]       | X8 = (string**)(1152921514332010352)("Constructor-skipping is not supported on this platform");
            // 0x00C79D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C79D34: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00C79D38: LDR x1, [x8]               | X1 = "Constructor-skipping is not supported on this platform";
            // 0x00C79D3C: BL #0x16f7cac              | .ctor(message:  "Constructor-skipping is not supported on this platform");
            val_1 = new System.NotSupportedException(message:  "Constructor-skipping is not supported on this platform");
            // 0x00C79D40: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x00C79D44: LDR x8, [x8, #0xc28]       | X8 = 1152921514332010528;               
            // 0x00C79D48: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00C79D4C: LDR x1, [x8]               | X1 = public static System.Object ProtoBuf.BclHelpers::GetUninitializedObject(System.Type type);
            // 0x00C79D50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x00C79D54: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  48562176);
            System.Byte[] val_2 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  48562176);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C79D58 (13081944), len: 1228  VirtAddr: 0x00C79D58 RVA: 0x00C79D58 token: 100689116 methodIndex: 53347 delegateWrapperIndex: 0 methodInvoker: 0
        public static void WriteTimeSpan(System.TimeSpan timeSpan, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            string val_26;
            //  | 
            var val_27;
            //  | 
            ProtoBuf.ProtoWriter val_28;
            //  | 
            var val_29;
            // 0x00C79D58: STP x24, x23, [sp, #-0x40]! | stack[1152921514332321024] = ???;  stack[1152921514332321032] = ???;  //  dest_result_addr=1152921514332321024 |  dest_result_addr=1152921514332321032
            // 0x00C79D5C: STP x22, x21, [sp, #0x10]  | stack[1152921514332321040] = ???;  stack[1152921514332321048] = ???;  //  dest_result_addr=1152921514332321040 |  dest_result_addr=1152921514332321048
            // 0x00C79D60: STP x20, x19, [sp, #0x20]  | stack[1152921514332321056] = ???;  stack[1152921514332321064] = ???;  //  dest_result_addr=1152921514332321056 |  dest_result_addr=1152921514332321064
            // 0x00C79D64: STP x29, x30, [sp, #0x30]  | stack[1152921514332321072] = ???;  stack[1152921514332321080] = ???;  //  dest_result_addr=1152921514332321072 |  dest_result_addr=1152921514332321080
            // 0x00C79D68: ADD x29, sp, #0x30         | X29 = (1152921514332321024 + 48) = 1152921514332321072 (0x1000000243AEF530);
            // 0x00C79D6C: SUB sp, sp, #0x10          | SP = (1152921514332321024 - 16) = 1152921514332321008 (0x1000000243AEF4F0);
            // 0x00C79D70: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C79D74: LDRB w8, [x20, #0xf77]     | W8 = (bool)static_value_03733F77;       
            // 0x00C79D78: MOV x19, x2                | X19 = X2;//m1                           
            val_26 = X2;
            // 0x00C79D7C: STR x1, [sp, #8]           | stack[1152921514332321016] = dest;       //  dest_result_addr=1152921514332321016
            // 0x00C79D80: TBNZ w8, #0, #0xc79d9c     | if (static_value_03733F77 == true) goto label_0;
            // 0x00C79D84: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x00C79D88: LDR x8, [x8, #0x810]       | X8 = 0x2B8F16C;                         
            // 0x00C79D8C: LDR w0, [x8]               | W0 = 0x131D;                            
            // 0x00C79D90: BL #0x2782188              | X0 = sub_2782188( ?? 0x131D, ????);     
            // 0x00C79D94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C79D98: STRB w8, [x20, #0xf77]     | static_value_03733F77 = true;            //  dest_result_addr=57884535
            label_0:
            // 0x00C79D9C: STR wzr, [sp, #4]          | stack[1152921514332321012] = 0x0;        //  dest_result_addr=1152921514332321012
            // 0x00C79DA0: CBZ x19, #0xc7a1e4         | if (X2 == 0) goto label_1;              
            if(val_26 == 0)
            {
                goto label_1;
            }
            // 0x00C79DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C79DA8: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00C79DAC: BL #0x2988c04              | X0 = X2.get_WireType();                 
            ProtoBuf.WireType val_1 = val_26.WireType;
            // 0x00C79DB0: SUB w8, w0, #1             | W8 = (val_1 - 1);                       
            ProtoBuf.WireType val_2 = val_1 - 1;
            // 0x00C79DB4: CMP w8, #2                 | STATE = COMPARE((val_1 - 1), 0x2)       
            // 0x00C79DB8: B.HI #0xc79ddc             | if (val_2 > 0x2) goto label_2;          
            if(val_2 > 2)
            {
                goto label_2;
            }
            // 0x00C79DBC: ADRP x9, #0x2a93000        | X9 = 44642304 (0x2A93000);              
            // 0x00C79DC0: ADD x9, x9, #0x9cc         | X9 = (44642304 + 2508) = 44644812 (0x02A939CC);
            // 0x00C79DC4: LDR w8, [x9, w8, sxtw #2]  | W8 = 44644812 + ((val_1 - 1)) << 2;     
            // 0x00C79DC8: CMP w8, #6                 | STATE = COMPARE(44644812 + ((val_1 - 1)) << 2, 0x6)
            // 0x00C79DCC: B.EQ #0xc79eb8             | if (44644812 + ((val_1 - 1)) << 2 == 0x6) goto label_3;
            if((44644812 + ((val_1 - 1)) << 2) == 6)
            {
                goto label_3;
            }
            // 0x00C79DD0: CMP w8, #7                 | STATE = COMPARE(44644812 + ((val_1 - 1)) << 2, 0x7)
            // 0x00C79DD4: B.EQ #0xc79f04             | if (44644812 + ((val_1 - 1)) << 2 == 0x7) goto label_4;
            if((44644812 + ((val_1 - 1)) << 2) == 7)
            {
                goto label_4;
            }
            // 0x00C79DD8: CBNZ w8, #0xc7a0a0         | if (44644812 + ((val_1 - 1)) << 2 != 0) goto label_12;
            if((44644812 + ((val_1 - 1)) << 2) != 0)
            {
                goto label_12;
            }
            label_2:
            // 0x00C79DDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C79DE0: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00C79DE4: BL #0x2988c04              | X0 = X2.get_WireType();                 
            ProtoBuf.WireType val_3 = val_26.WireType;
            // 0x00C79DE8: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00C79DEC: LDR x8, [x8, #0x5c8]       | X8 = 1152921504886984704;               
            // 0x00C79DF0: STR w0, [sp, #4]           | stack[1152921514332321012] = val_3;      //  dest_result_addr=1152921514332321012
            // 0x00C79DF4: ADD x1, sp, #4             | X1 = (1152921514332321008 + 4) = 1152921514332321012 (0x1000000243AEF4F4);
            // 0x00C79DF8: LDR x8, [x8]               | X8 = typeof(ProtoBuf.WireType);         
            // 0x00C79DFC: MOV x0, x8                 | X0 = 1152921504886984704 (0x1000000010B29000);//ML01
            // 0x00C79E00: BL #0x27bc028              | X0 = 1152921514332377376 = (Il2CppObject*)Box((RuntimeClass*)typeof(ProtoBuf.WireType), val_3);
            // 0x00C79E04: MOV x20, x0                | X20 = 1152921514332377376 (0x1000000243AFD120);//ML01
            // 0x00C79E08: CBNZ x20, #0xc79e10        | if (val_3 != 0) goto label_6;           
            if(val_3 != 0)
            {
                goto label_6;
            }
            // 0x00C79E0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x00C79E10: LDR x8, [x20]              | X8 = typeof(ProtoBuf.WireType);         
            // 0x00C79E14: MOV x0, x20                | X0 = 1152921514332377376 (0x1000000243AFD120);//ML01
            // 0x00C79E18: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
            // 0x00C79E1C: BLR x9                     | X0 = val_3.ToString();                  
            string val_4 = val_3.ToString();
            // 0x00C79E20: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00C79E24: CBNZ x20, #0xc79e2c        | if (val_3 != 0) goto label_7;           
            if(val_3 != 0)
            {
                goto label_7;
            }
            // 0x00C79E28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_7:
            // 0x00C79E2C: MOV x0, x20                | X0 = 1152921514332377376 (0x1000000243AFD120);//ML01
            // 0x00C79E30: BL #0x27bc4e8              | val_3.System.IDisposable.Dispose();     
            val_3.System.IDisposable.Dispose();
            // 0x00C79E34: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00C79E38: LDR w8, [x0]               | W8 = typeof(ProtoBuf.WireType);         
            // 0x00C79E3C: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x00C79E40: STR w8, [sp, #4]           | stack[1152921514332321012] = typeof(ProtoBuf.WireType);  //  dest_result_addr=1152921514332321012
            // 0x00C79E44: LDR x0, [x9]               | X0 = typeof(System.String);             
            // 0x00C79E48: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00C79E4C: TBZ w8, #0, #0xc79e5c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00C79E50: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C79E54: CBNZ w8, #0xc79e5c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00C79E58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_9:
            // 0x00C79E5C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00C79E60: LDR x8, [x8, #0x4a8]       | X8 = (string**)(1152921514332221856)("Unexpected wire-type: ");
            // 0x00C79E64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C79E68: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C79E6C: MOV x2, x19                | X2 = val_4;//m1                         
            // 0x00C79E70: LDR x1, [x8]               | X1 = "Unexpected wire-type: ";          
            // 0x00C79E74: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Unexpected wire-type: ");
            string val_5 = System.String.Concat(str0:  0, str1:  "Unexpected wire-type: ");
            // 0x00C79E78: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00C79E7C: LDR x8, [x8, #0x720]       | X8 = 1152921504884002816;               
            // 0x00C79E80: MOV x19, x0                | X19 = val_5;//m1                        
            val_26 = val_5;
            // 0x00C79E84: LDR x8, [x8]               | X8 = typeof(ProtoBuf.ProtoException);   
            // 0x00C79E88: MOV x0, x8                 | X0 = 1152921504884002816 (0x1000000010851000);//ML01
            ProtoBuf.ProtoException val_6 = null;
            // 0x00C79E8C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C79E90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C79E94: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x00C79E98: MOV x20, x0                | X20 = 1152921504884002816 (0x1000000010851000);//ML01
            // 0x00C79E9C: BL #0x2980224              | .ctor(message:  val_26);                
            val_6 = new ProtoBuf.ProtoException(message:  val_26);
            // 0x00C79EA0: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00C79EA4: LDR x8, [x8, #0xdf8]       | X8 = 1152921514332226064;               
            // 0x00C79EA8: MOV x0, x20                | X0 = 1152921504884002816 (0x1000000010851000);//ML01
            // 0x00C79EAC: LDR x1, [x8]               | X1 = public static System.Void ProtoBuf.BclHelpers::WriteTimeSpan(System.TimeSpan timeSpan, ProtoBuf.ProtoWriter dest);
            // 0x00C79EB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C79EB4: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  277155840);
            System.Byte[] val_7 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  277155840);
            label_3:
            // 0x00C79EB8: ADD x0, sp, #8             | X0 = (1152921514332321008 + 8) = 1152921514332321016 (0x1000000243AEF4F8);
            // 0x00C79EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C79EC0: BL #0x1b69f78              | X0 = dest.get_InitialType();            
            System.Type val_8 = dest.InitialType;
            // 0x00C79EC4: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
            // 0x00C79EC8: LDR x8, [x8, #0x778]       | X8 = 1152921504884428800;               
            // 0x00C79ECC: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00C79ED0: LDR x8, [x8]               | X8 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C79ED4: LDRB w9, [x8, #0x10a]      | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C79ED8: TBZ w9, #0, #0xc79eec      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00C79EDC: LDR w9, [x8, #0xbc]        | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C79EE0: CBNZ w9, #0xc79eec         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00C79EE4: MOV x0, x8                 | X0 = 1152921504884428800 (0x10000000108B9000);//ML01
            // 0x00C79EE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_11:
            // 0x00C79EEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C79EF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C79EF4: MOV x1, x20                | X1 = val_8;//m1                         
            // 0x00C79EF8: MOV x2, x19                | X2 = val_5;//m1                         
            // 0x00C79EFC: BL #0x2978620              | ProtoBuf.ProtoWriter.WriteInt64(value:  0, writer:  val_8);
            ProtoBuf.ProtoWriter.WriteInt64(value:  0, writer:  val_8);
            // 0x00C79F00: B #0xc7a0a0                |  goto label_12;                         
            goto label_12;
            label_4:
            // 0x00C79F04: ADD x0, sp, #8             | X0 = (1152921514332321008 + 8) = 1152921514332321016 (0x1000000243AEF4F8);
            // 0x00C79F08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C79F0C: BL #0x1b69f78              | X0 = dest.get_InitialType();            
            System.Type val_9 = dest.InitialType;
            // 0x00C79F10: ADRP x23, #0x3610000       | X23 = 56688640 (0x3610000);             
            // 0x00C79F14: LDR x23, [x23, #0x6d0]     | X23 = 1152921504656633856;              
            // 0x00C79F18: LDR x21, [sp, #8]          | X21 = dest;                             
            // 0x00C79F1C: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00C79F20: LDR x8, [x23]              | X8 = typeof(System.TimeSpan);           
            val_27 = null;
            // 0x00C79F24: LDRB w9, [x8, #0x10a]      | W9 = System.TimeSpan.__il2cppRuntimeField_10A;
            // 0x00C79F28: TBZ w9, #0, #0xc79f40      | if (System.TimeSpan.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00C79F2C: LDR w9, [x8, #0xbc]        | W9 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C79F30: CBNZ w9, #0xc79f40         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00C79F34: MOV x0, x8                 | X0 = 1152921504656633856 (0x1000000002F7B000);//ML01
            // 0x00C79F38: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            // 0x00C79F3C: LDR x8, [x23]              | X8 = typeof(System.TimeSpan);           
            val_27 = null;
            label_14:
            // 0x00C79F40: LDR x8, [x8, #0xa0]        | X8 = System.TimeSpan.__il2cppRuntimeField_static_fields;
            // 0x00C79F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C79F48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C79F4C: MOV x1, x21                | X1 = dest;//m1                          
            // 0x00C79F50: LDR x2, [x8]               | X2 = System.TimeSpan.MaxValue;          
            // 0x00C79F54: BL #0x1b6b4d8              | X0 = System.TimeSpan.op_Equality(t1:  new System.TimeSpan(), t2:  new System.TimeSpan() {_ticks = dest});
            bool val_10 = System.TimeSpan.op_Equality(t1:  new System.TimeSpan(), t2:  new System.TimeSpan() {_ticks = dest});
            // 0x00C79F58: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_28 = 1;
            // 0x00C79F5C: AND w8, w0, #1             | W8 = (val_10 & 1);                      
            bool val_11 = val_10;
            // 0x00C79F60: TBNZ w8, #0, #0xc79fa8     | if ((val_10 & 1) == true) goto label_15;
            if(val_11 == true)
            {
                goto label_15;
            }
            // 0x00C79F64: LDR x0, [x23]              | X0 = typeof(System.TimeSpan);           
            val_29 = null;
            // 0x00C79F68: LDR x21, [sp, #8]          | X21 = dest;                             
            // 0x00C79F6C: LDRB w8, [x0, #0x10a]      | W8 = System.TimeSpan.__il2cppRuntimeField_10A;
            // 0x00C79F70: TBZ w8, #0, #0xc79f84      | if (System.TimeSpan.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00C79F74: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C79F78: CBNZ w8, #0xc79f84         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00C79F7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            // 0x00C79F80: LDR x0, [x23]              | X0 = typeof(System.TimeSpan);           
            val_29 = null;
            label_17:
            // 0x00C79F84: LDR x8, [x0, #0xa0]        | X8 = System.TimeSpan.__il2cppRuntimeField_static_fields;
            // 0x00C79F88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C79F8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C79F90: MOV x1, x21                | X1 = dest;//m1                          
            // 0x00C79F94: LDR x2, [x8, #8]           | X2 = System.TimeSpan.MinValue;          
            // 0x00C79F98: BL #0x1b6b4d8              | X0 = System.TimeSpan.op_Equality(t1:  new System.TimeSpan(), t2:  new System.TimeSpan() {_ticks = dest});
            bool val_12 = System.TimeSpan.op_Equality(t1:  new System.TimeSpan(), t2:  new System.TimeSpan() {_ticks = dest});
            // 0x00C79F9C: AND w8, w0, #1             | W8 = (val_12 & 1);                      
            bool val_13 = val_12;
            // 0x00C79FA0: TBZ w8, #0, #0xc7a0b8      | if ((val_12 & 1) == false) goto label_18;
            if(val_13 == false)
            {
                goto label_18;
            }
            // 0x00C79FA4: MOVN x22, #0               | X22 = 0 (0x0);//ML01                    
            val_28 = 0;
            label_15:
            // 0x00C79FA8: ORR w21, wzr, #0xf         | W21 = 15(0xF);                          
            label_39:
            // 0x00C79FAC: ADRP x23, #0x35fb000       | X23 = 56602624 (0x35FB000);             
            // 0x00C79FB0: LDR x23, [x23, #0x778]     | X23 = 1152921504884428800;              
            // 0x00C79FB4: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C79FB8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C79FBC: TBZ w8, #0, #0xc79fcc      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00C79FC0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C79FC4: CBNZ w8, #0xc79fcc         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00C79FC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_20:
            // 0x00C79FCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C79FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C79FD4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C79FD8: MOV x2, x19                | X2 = X2;//m1                            
            // 0x00C79FDC: BL #0x2977f50              | X0 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            ProtoBuf.SubItemToken val_14 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            // 0x00C79FE0: MOV x20, x0                | X20 = val_14.value;//m1                 
            // 0x00C79FE4: CBZ x22, #0xc7a02c         | if (0x0 == 0) goto label_21;            
            if(val_28 == 0)
            {
                goto label_21;
            }
            // 0x00C79FE8: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C79FEC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C79FF0: TBZ w8, #0, #0xc7a000      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00C79FF4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C79FF8: CBNZ w8, #0xc7a000         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00C79FFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_23:
            // 0x00C7A000: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A004: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7A008: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00C7A00C: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x00C7A010: MOV x3, x19                | X3 = X2;//m1                            
            // 0x00C7A014: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  1, writer:  8);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  1, writer:  8);
            // 0x00C7A018: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A01C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7A020: MOV x1, x22                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A024: MOV x2, x19                | X2 = X2;//m1                            
            // 0x00C7A028: BL #0x2978620              | ProtoBuf.ProtoWriter.WriteInt64(value:  0, writer:  val_28);
            ProtoBuf.ProtoWriter.WriteInt64(value:  0, writer:  val_28);
            label_21:
            // 0x00C7A02C: CBZ w21, #0xc7a074         | if (0xF == 0) goto label_24;            
            if(15 == 0)
            {
                goto label_24;
            }
            // 0x00C7A030: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7A034: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7A038: TBZ w8, #0, #0xc7a048      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x00C7A03C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A040: CBNZ w8, #0xc7a048         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x00C7A044: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_26:
            // 0x00C7A048: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A04C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7A050: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7A054: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00C7A058: MOV x3, x19                | X3 = X2;//m1                            
            // 0x00C7A05C: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  2, writer:  0);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  2, writer:  0);
            // 0x00C7A060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A064: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7A068: MOV w1, w21                | W1 = 15 (0xF);//ML01                    
            // 0x00C7A06C: MOV x2, x19                | X2 = X2;//m1                            
            // 0x00C7A070: BL #0x29780bc              | ProtoBuf.ProtoWriter.WriteInt32(value:  0, writer:  15);
            ProtoBuf.ProtoWriter.WriteInt32(value:  0, writer:  15);
            label_24:
            // 0x00C7A074: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7A078: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7A07C: TBZ w8, #0, #0xc7a08c      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_28;
            // 0x00C7A080: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A084: CBNZ w8, #0xc7a08c         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
            // 0x00C7A088: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_28:
            // 0x00C7A08C: AND x1, x20, #0xffffffff   | X1 = (val_14.value & 4294967295);       
            int val_15 = val_14.value & 4294967295;
            // 0x00C7A090: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A094: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7A098: MOV x2, x19                | X2 = X2;//m1                            
            // 0x00C7A09C: BL #0x2977fd0              | ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  int val_15 = val_14.value & 4294967295);
            ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  val_15);
            label_12:
            // 0x00C7A0A0: SUB sp, x29, #0x30         | SP = (1152921514332321072 - 48) = 1152921514332321024 (0x1000000243AEF500);
            // 0x00C7A0A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7A0A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7A0AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7A0B0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00C7A0B4: RET                        |  return;                                
            return;
            label_18:
            // 0x00C7A0B8: MOVZ x9, #0xa2e3, lsl #48  | X9 = -6709519019851907072 (0xA2E3000000000000);//ML01
            // 0x00C7A0BC: MOVK x9, #0xff1d, lsl #32  | X9 = -6709238519832772608 (0xA2E3FF1D00000000);
            // 0x00C7A0C0: MOVK x9, #0xe205, lsl #16  | X9 = -6709238516040794112 (0xA2E3FF1DE2050000);
            // 0x00C7A0C4: MOVK x9, #0x81e3           | X9 = -6709238516040760861 (0xA2E3FF1DE20581E3);
            // 0x00C7A0C8: SMULH x9, x20, x9          | 
            // 0x00C7A0CC: MOVZ x8, #0xc9, lsl #32    | X8 = 863288426496 (0xC900000000);//ML01 
            // 0x00C7A0D0: ADD x9, x9, x20            | X9 = (-6709238516040760861 + val_9);    
            System.Type val_16 = (-6709238516040760861) + val_9;
            // 0x00C7A0D4: MOVK x8, #0x2a69, lsl #16  | X8 = 863999950848 (0xC92A690000);       
            // 0x00C7A0D8: ASR x10, x9, #0x27         | X10 = ((-6709238516040760861 + val_9) >> 39);
            System.Type val_17 = val_16 >> 39;
            // 0x00C7A0DC: MOVK x8, #0xc000           | X8 = 864000000000 (0xC92A69C000);       
            // 0x00C7A0E0: ADD x9, x10, x9, lsr #63   | X9 = (((-6709238516040760861 + val_9) >> 39) + ((-6709238516040760861 + val_9)) >> 63);
            val_16 = val_17 + (val_16 >> 63);
            // 0x00C7A0E4: MSUB x9, x9, x8, x20       | X9 = val_9 - ((((-6709238516040760861 + val_9) >> 39) + ((-6709238516040760861 + val_9)) >> 63) * 86
            val_16 = val_9 - (val_16 * 864000000000);
            // 0x00C7A0E8: CBZ x9, #0xc7a1ac          | if (val_9 - ((((-6709238516040760861 + val_9) >> 39) + ((-6709238516040760861 + val_9)) >> 63) * 864000000000) == null) goto label_29;
            if(val_16 == null)
            {
                goto label_29;
            }
            // 0x00C7A0EC: MOVZ x9, #0x3d15, lsl #48  | X9 = 4401424210824527872 (0x3D15000000000000);//ML01
            // 0x00C7A0F0: MOVK x9, #0x7fab, lsl #32  | X9 = 4401564583240663040 (0x3D157FAB00000000);
            // 0x00C7A0F4: MOVK x9, #0x34c2, lsl #16  | X9 = 4401564584125792256 (0x3D157FAB34C20000);
            // 0x00C7A0F8: MOVK x9, #0x10b5           | X9 = 4401564584125796533 (0x3D157FAB34C210B5);
            // 0x00C7A0FC: MOVZ x8, #0x8, lsl #32     | X8 = 34359738368 (0x800000000);//ML01   
            // 0x00C7A100: SMULH x9, x20, x9          | 
            // 0x00C7A104: MOVK x8, #0x61c4, lsl #16  | X8 = 35999973376 (0x861C40000);         
            // 0x00C7A108: ASR x10, x9, #0x21         | X10 = (4401564584125796533 >> 33) = 0 (0x00000000);
            // 0x00C7A10C: MOVK x8, #0x6800           | X8 = 36000000000 (0x861C46800);         
            // 0x00C7A110: ADD x9, x10, x9, lsr #63   | X9 = (0 + 0) = 512409557 (0x1E8ABFD5);  
            // 0x00C7A114: MSUB x9, x9, x8, x20       | X9 = (val_9 - 512409557 * 36000000000) = 21709551616 (0x50DFD7800);
            // 0x00C7A118: CBZ x9, #0xc7a1b8          | if (0x50DFD7800 == 0) goto label_30;    
            if(21709551616 == 0)
            {
                goto label_30;
            }
            // 0x00C7A11C: MOVZ x9, #0x1ca2, lsl #48  | X9 = 2063211579289108480 (0x1CA2000000000000);//ML01
            // 0x00C7A120: MOVK x9, #0x13d8, lsl #32  | X9 = 2063233397722972160 (0x1CA213D800000000);
            // 0x00C7A124: MOVK x9, #0x40ba, lsl #16  | X9 = 2063233398808903680 (0x1CA213D840BA0000);
            // 0x00C7A128: MOVK x9, #0xf7d5           | X9 = 2063233398808967125 (0x1CA213D840BAF7D5);
            // 0x00C7A12C: SMULH x9, x20, x9          | 
            // 0x00C7A130: MOVZ w8, #0x23c3, lsl #16  | W8 = 599982080 (0x23C30000);//ML01      
            // 0x00C7A134: ASR x10, x9, #0x1a         | X10 = (2063233398808967125 >> 26) = 0 (0x00000000);
            // 0x00C7A138: MOVK w8, #0x4600           | W8 = 600000000 (0x23C34600);            
            // 0x00C7A13C: ADD x9, x10, x9, lsr #63   | X9 = (0 + 0) = 30744573456 (0x72884F610);
            // 0x00C7A140: MSUB x9, x9, x8, x20       | X9 = (val_9 - 30744573456 * 600000000) = 109551616 (0x0687A000);
            // 0x00C7A144: CBZ x9, #0xc7a1c4          | if (0x687A000 == 0) goto label_31;      
            if(109551616 == 0)
            {
                goto label_31;
            }
            // 0x00C7A148: MOVZ x9, #0xd6bf, lsl #48  | X9 = -2972657229041238016 (0xD6BF000000000000);//ML01
            // 0x00C7A14C: MOVK x9, #0x94d5, lsl #32  | X9 = -2972493586492293120 (0xD6BF94D500000000);
            // 0x00C7A150: MOVK x9, #0xe57a, lsl #16  | X9 = -2972493582642315264 (0xD6BF94D5E57A0000);
            // 0x00C7A154: MOVK x9, #0x42bd           | X9 = -2972493582642298179 (0xD6BF94D5E57A42BD);
            // 0x00C7A158: SMULH x9, x20, x9          | 
            // 0x00C7A15C: ADD x9, x9, x20            | X9 = (-2972493582642298179 + val_9);    
            System.Type val_18 = (-2972493582642298179) + val_9;
            // 0x00C7A160: MOVZ w8, #0x98, lsl #16    | W8 = 9961472 (0x980000);//ML01          
            // 0x00C7A164: ASR x10, x9, #0x17         | X10 = ((-2972493582642298179 + val_9) >> 23);
            System.Type val_19 = val_18 >> 23;
            // 0x00C7A168: MOVK w8, #0x9680           | W8 = 10000000 (0x989680);               
            // 0x00C7A16C: ADD x9, x10, x9, lsr #63   | X9 = (((-2972493582642298179 + val_9) >> 23) + ((-2972493582642298179 + val_9)) >> 63);
            val_18 = val_19 + (val_18 >> 63);
            // 0x00C7A170: MSUB x9, x9, x8, x20       | X9 = val_9 - ((((-2972493582642298179 + val_9) >> 23) + ((-2972493582642298179 + val_9)) >> 63) * 10
            val_18 = val_9 - (val_18 * 10000000);
            // 0x00C7A174: CBZ x9, #0xc7a1d0          | if (val_9 - ((((-2972493582642298179 + val_9) >> 23) + ((-2972493582642298179 + val_9)) >> 63) * 10000000) == null) goto label_32;
            if(val_18 == null)
            {
                goto label_32;
            }
            // 0x00C7A178: MOVZ x8, #0x346d, lsl #48  | X8 = 3777675662433714176 (0x346D000000000000);//ML01
            // 0x00C7A17C: MOVK x8, #0xc5d6, lsl #32  | X8 = 3777893185347387392 (0x346DC5D600000000);
            // 0x00C7A180: MOVK x8, #0x3886, lsl #16  | X8 = 3777893186295693312 (0x346DC5D638860000);
            // 0x00C7A184: MOVK x8, #0x594b           | X8 = 3777893186295716171 (0x346DC5D63886594B);
            // 0x00C7A188: SMULH x8, x20, x8          | 
            // 0x00C7A18C: ASR x9, x8, #0xb           | X9 = (3777893186295716171 >> 11) = 0 (0x00000000);
            // 0x00C7A190: ADD x22, x9, x8, lsr #63   | X22 = (0 + 0) = 1844674407370955 (0x68DB8BAC710CB);
            // 0x00C7A194: MOVZ w8, #0x2710           | W8 = 10000 (0x2710);//ML01              
            // 0x00C7A198: MSUB x8, x22, x8, x20      | X8 = (val_9 - 1844674407370955 * 10000) = 1616 (0x00000650);
            // 0x00C7A19C: CBZ x8, #0xc7a1dc          | if (0x650 == 0) goto label_33;          
            if(1616 == 0)
            {
                goto label_33;
            }
            // 0x00C7A1A0: MOVZ w21, #0x5             | W21 = 5 (0x5);//ML01                    
            // 0x00C7A1A4: MOV x22, x20               | X22 = val_9;//m1                        
            // 0x00C7A1A8: B #0xc79fac                |  goto label_39;                         
            goto label_39;
            label_29:
            // 0x00C7A1AC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            // 0x00C7A1B0: SDIV x22, x20, x8          | X22 = (val_9 / 864000000000);           
            System.Type val_20 = val_9 / 864000000000;
            // 0x00C7A1B4: B #0xc79fac                |  goto label_39;                         
            goto label_39;
            label_30:
            // 0x00C7A1B8: SDIV x22, x20, x8          | X22 = (val_9 / 36000000000);            
            System.Type val_21 = val_9 / 36000000000;
            // 0x00C7A1BC: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            // 0x00C7A1C0: B #0xc79fac                |  goto label_39;                         
            goto label_39;
            label_31:
            // 0x00C7A1C4: SDIV x22, x20, x8          | X22 = (val_9 / 600000000);              
            System.Type val_22 = val_9 / 600000000;
            // 0x00C7A1C8: ORR w21, wzr, #2           | W21 = 2(0x2);                           
            // 0x00C7A1CC: B #0xc79fac                |  goto label_39;                         
            goto label_39;
            label_32:
            // 0x00C7A1D0: SDIV x22, x20, x8          | X22 = (val_9 / 10000000);               
            System.Type val_23 = val_9 / 10000000;
            // 0x00C7A1D4: ORR w21, wzr, #3           | W21 = 3(0x3);                           
            // 0x00C7A1D8: B #0xc79fac                |  goto label_39;                         
            goto label_39;
            label_33:
            // 0x00C7A1DC: ORR w21, wzr, #4           | W21 = 4(0x4);                           
            // 0x00C7A1E0: B #0xc79fac                |  goto label_39;                         
            goto label_39;
            label_1:
            // 0x00C7A1E4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00C7A1E8: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00C7A1EC: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_24 = null;
            // 0x00C7A1F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7A1F4: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00C7A1F8: LDR x8, [x8, #0x5d8]       | X8 = (string**)(1152921514332272144)("dest");
            // 0x00C7A1FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A200: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C7A204: LDR x1, [x8]               | X1 = "dest";                            
            // 0x00C7A208: BL #0x18b3df0              | .ctor(paramName:  "dest");              
            val_24 = new System.ArgumentNullException(paramName:  "dest");
            // 0x00C7A20C: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00C7A210: LDR x8, [x8, #0xdf8]       | X8 = 1152921514332226064;               
            // 0x00C7A214: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C7A218: LDR x1, [x8]               | X1 = public static System.Void ProtoBuf.BclHelpers::WriteTimeSpan(System.TimeSpan timeSpan, ProtoBuf.ProtoWriter dest);
            // 0x00C7A21C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7A220: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
            System.Byte[] val_25 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7A224 (13083172), len: 276  VirtAddr: 0x00C7A224 RVA: 0x00C7A224 token: 100689117 methodIndex: 53348 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.TimeSpan ReadTimeSpan(ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            System.TimeSpan val_6;
            //  | 
            var val_7;
            // 0x00C7A224: STP x20, x19, [sp, #-0x20]! | stack[1152921514332543648] = ???;  stack[1152921514332543656] = ???;  //  dest_result_addr=1152921514332543648 |  dest_result_addr=1152921514332543656
            // 0x00C7A228: STP x29, x30, [sp, #0x10]  | stack[1152921514332543664] = ???;  stack[1152921514332543672] = ???;  //  dest_result_addr=1152921514332543664 |  dest_result_addr=1152921514332543672
            // 0x00C7A22C: ADD x29, sp, #0x10         | X29 = (1152921514332543648 + 16) = 1152921514332543664 (0x1000000243B25AB0);
            // 0x00C7A230: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7A234: LDRB w8, [x20, #0xf78]     | W8 = (bool)static_value_03733F78;       
            // 0x00C7A238: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00C7A23C: TBNZ w8, #0, #0xc7a258     | if (static_value_03733F78 == true) goto label_0;
            // 0x00C7A240: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00C7A244: LDR x8, [x8, #0xa0]        | X8 = 0x2B8F154;                         
            // 0x00C7A248: LDR w0, [x8]               | W0 = 0x1317;                            
            // 0x00C7A24C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1317, ????);     
            // 0x00C7A250: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7A254: STRB w8, [x20, #0xf78]     | static_value_03733F78 = true;            //  dest_result_addr=57884536
            label_0:
            // 0x00C7A258: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00C7A25C: LDR x8, [x8, #0xd90]       | X8 = 1152921504881287168;               
            // 0x00C7A260: LDR x0, [x8]               | X0 = typeof(ProtoBuf.BclHelpers);       
            // 0x00C7A264: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_10A;
            // 0x00C7A268: TBZ w8, #0, #0xc7a278      | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7A26C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A270: CBNZ w8, #0xc7a278         | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7A274: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BclHelpers), ????);
            label_2:
            // 0x00C7A278: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00C7A27C: BL #0xc7a338               | X0 = ProtoBuf.BclHelpers.ReadTimeSpanTicks(source:  null);
            long val_1 = ProtoBuf.BclHelpers.ReadTimeSpanTicks(source:  null);
            // 0x00C7A280: MOV x19, x0                | X19 = val_1;//m1                        
            val_4 = val_1;
            // 0x00C7A284: ORR x8, xzr, #0x8000000000000000 | X8 = -9223372036854775808(0x8000000000000000);
            // 0x00C7A288: CMP x19, x8                | STATE = COMPARE(val_1, 0x8000000000000000)
            // 0x00C7A28C: B.NE #0xc7a2c0             | if (val_4 != -9223372036854775808) goto label_3;
            if(val_4 != (-9223372036854775808))
            {
                goto label_3;
            }
            // 0x00C7A290: ADRP x19, #0x3610000       | X19 = 56688640 (0x3610000);             
            // 0x00C7A294: LDR x19, [x19, #0x6d0]     | X19 = 1152921504656633856;              
            val_4 = 1152921504656633856;
            // 0x00C7A298: LDR x0, [x19]              | X0 = typeof(System.TimeSpan);           
            val_5 = null;
            // 0x00C7A29C: LDRB w8, [x0, #0x10a]      | W8 = System.TimeSpan.__il2cppRuntimeField_10A;
            // 0x00C7A2A0: TBZ w8, #0, #0xc7a2b4      | if (System.TimeSpan.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00C7A2A4: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A2A8: CBNZ w8, #0xc7a2b4         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00C7A2AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            // 0x00C7A2B0: LDR x0, [x19]              | X0 = typeof(System.TimeSpan);           
            val_5 = null;
            label_5:
            // 0x00C7A2B4: LDR x8, [x0, #0xa0]        | X8 = System.TimeSpan.__il2cppRuntimeField_static_fields;
            // 0x00C7A2B8: LDR x0, [x8, #8]           | X0 = System.TimeSpan.MinValue;          
            val_6 = System.TimeSpan.MinValue;
            // 0x00C7A2BC: B #0xc7a304                |  goto label_6;                          
            goto label_6;
            label_3:
            // 0x00C7A2C0: ADRP x20, #0x3610000       | X20 = 56688640 (0x3610000);             
            // 0x00C7A2C4: LDR x20, [x20, #0x6d0]     | X20 = 1152921504656633856;              
            // 0x00C7A2C8: ORR x9, xzr, #0x7fffffffffffffff | X9 = 9223372036854775807(0x7FFFFFFFFFFFFFFF);
            // 0x00C7A2CC: CMP x19, x9                | STATE = COMPARE(val_1, 0x7FFFFFFFFFFFFFFF)
            // 0x00C7A2D0: LDR x0, [x20]              | X0 = typeof(System.TimeSpan);           
            val_7 = null;
            // 0x00C7A2D4: ADD x8, x0, #0x109         | X8 = (val_7 + 265) = 1152921504656634121 (0x1000000002F7B109);
            // 0x00C7A2D8: LDRH w8, [x8]              | W8 = System.TimeSpan.__il2cppRuntimeField_109;
            // 0x00C7A2DC: AND w8, w8, #0x100         | W8 = (System.TimeSpan.__il2cppRuntimeField_109 & 256);
            // 0x00C7A2E0: AND w8, w8, #0xffff        | W8 = ((System.TimeSpan.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00C7A2E4: B.NE #0xc7a310             | if (val_4 != 9223372036854775807) goto label_7;
            if(val_4 != 9223372036854775807)
            {
                goto label_7;
            }
            // 0x00C7A2E8: CBZ w8, #0xc7a2fc          | if (((System.TimeSpan.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_9;
            // 0x00C7A2EC: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A2F0: CBNZ w8, #0xc7a2fc         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00C7A2F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            // 0x00C7A2F8: LDR x0, [x20]              | X0 = typeof(System.TimeSpan);           
            val_7 = null;
            label_9:
            // 0x00C7A2FC: LDR x8, [x0, #0xa0]        | X8 = System.TimeSpan.__il2cppRuntimeField_static_fields;
            // 0x00C7A300: LDR x0, [x8]               | X0 = System.TimeSpan.MaxValue;          
            val_6 = System.TimeSpan.MaxValue;
            label_6:
            // 0x00C7A304: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7A308: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7A30C: RET                        |  return (System.TimeSpan)System.TimeSpan.MaxValue;
            return val_6;
            //  |  // // {name=val_0._ticks, type=System.Int64, size=8, nGRN=0 offset=0 }
            label_7:
            // 0x00C7A310: CBZ w8, #0xc7a320          | if (((System.TimeSpan.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_11;
            // 0x00C7A314: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A318: CBNZ w8, #0xc7a320         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00C7A31C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            label_11:
            // 0x00C7A320: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7A324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A32C: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00C7A330: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7A334: B #0x1b6aaa8               | return System.TimeSpan.FromTicks(value:  0);
            return System.TimeSpan.FromTicks(value:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7A750 (13084496), len: 296  VirtAddr: 0x00C7A750 RVA: 0x00C7A750 token: 100689118 methodIndex: 53349 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.DateTime ReadDateTime(ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            //  | 
            System.DateTimeKind val_2;
            //  | 
            var val_3;
            //  | 
            System.DateTime val_4;
            //  | 
            System.DateTimeKind val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00C7A750: STP x20, x19, [sp, #-0x20]! | stack[1152921514332663840] = ???;  stack[1152921514332663848] = ???;  //  dest_result_addr=1152921514332663840 |  dest_result_addr=1152921514332663848
            // 0x00C7A754: STP x29, x30, [sp, #0x10]  | stack[1152921514332663856] = ???;  stack[1152921514332663864] = ???;  //  dest_result_addr=1152921514332663856 |  dest_result_addr=1152921514332663864
            // 0x00C7A758: ADD x29, sp, #0x10         | X29 = (1152921514332663840 + 16) = 1152921514332663856 (0x1000000243B43030);
            // 0x00C7A75C: SUB sp, sp, #0x10          | SP = (1152921514332663840 - 16) = 1152921514332663824 (0x1000000243B43010);
            // 0x00C7A760: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7A764: LDRB w8, [x20, #0xf79]     | W8 = (bool)static_value_03733F79;       
            // 0x00C7A768: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00C7A76C: TBNZ w8, #0, #0xc7a788     | if (static_value_03733F79 == true) goto label_0;
            // 0x00C7A770: ADRP x8, #0x3664000        | X8 = 57032704 (0x3664000);              
            // 0x00C7A774: LDR x8, [x8, #0x720]       | X8 = 0x2B8F144;                         
            // 0x00C7A778: LDR w0, [x8]               | W0 = 0x1313;                            
            // 0x00C7A77C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1313, ????);     
            // 0x00C7A780: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7A784: STRB w8, [x20, #0xf79]     | static_value_03733F79 = true;            //  dest_result_addr=57884537
            label_0:
            // 0x00C7A788: ADRP x20, #0x35ee000       | X20 = 56549376 (0x35EE000);             
            // 0x00C7A78C: LDR x20, [x20, #0xd90]     | X20 = 1152921504881287168;              
            // 0x00C7A790: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BclHelpers);       
            // 0x00C7A794: STP xzr, xzr, [sp]         | stack[1152921514332663824] = 0x0;  stack[1152921514332663832] = 0x0;  //  dest_result_addr=1152921514332663824 |  dest_result_addr=1152921514332663832
            // 0x00C7A798: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_10A;
            // 0x00C7A79C: TBZ w8, #0, #0xc7a7ac      | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7A7A0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A7A4: CBNZ w8, #0xc7a7ac         | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7A7A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BclHelpers), ????);
            label_2:
            // 0x00C7A7AC: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00C7A7B0: BL #0xc7a338               | X0 = ProtoBuf.BclHelpers.ReadTimeSpanTicks(source:  null);
            long val_1 = ProtoBuf.BclHelpers.ReadTimeSpanTicks(source:  null);
            // 0x00C7A7B4: MOV x19, x0                | X19 = val_1;//m1                        
            val_2 = val_1;
            // 0x00C7A7B8: ORR x8, xzr, #0x7fffffffffffffff | X8 = 9223372036854775807(0x7FFFFFFFFFFFFFFF);
            // 0x00C7A7BC: CMP x19, x8                | STATE = COMPARE(val_1, 0x7FFFFFFFFFFFFFFF)
            // 0x00C7A7C0: B.EQ #0xc7a800             | if (val_2 == 9223372036854775807) goto label_3;
            if(val_2 == 9223372036854775807)
            {
                goto label_3;
            }
            // 0x00C7A7C4: ORR x8, xzr, #0x8000000000000000 | X8 = -9223372036854775808(0x8000000000000000);
            // 0x00C7A7C8: CMP x19, x8                | STATE = COMPARE(val_1, 0x8000000000000000)
            // 0x00C7A7CC: B.NE #0xc7a830             | if (val_2 != -9223372036854775808) goto label_4;
            if(val_2 != (-9223372036854775808))
            {
                goto label_4;
            }
            // 0x00C7A7D0: ADRP x19, #0x364f000       | X19 = 56946688 (0x364F000);             
            // 0x00C7A7D4: LDR x19, [x19, #0x9e0]     | X19 = 1152921504652693504;              
            val_2 = 1152921504652693504;
            // 0x00C7A7D8: LDR x0, [x19]              | X0 = typeof(System.DateTime);           
            val_3 = null;
            // 0x00C7A7DC: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00C7A7E0: TBZ w8, #0, #0xc7a7f4      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00C7A7E4: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A7E8: CBNZ w8, #0xc7a7f4         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00C7A7EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            // 0x00C7A7F0: LDR x0, [x19]              | X0 = typeof(System.DateTime);           
            val_3 = null;
            label_6:
            // 0x00C7A7F4: LDR x8, [x0, #0xa0]        | X8 = System.DateTime.__il2cppRuntimeField_static_fields;
            // 0x00C7A7F8: LDP x0, x1, [x8, #0x10]    | X0 = System.DateTime.MinValue; X1 = System.DateTime.MaxValue.__il2cppRuntimeField_18; //  | 
            val_4 = System.DateTime.MinValue;
            // 0x00C7A7FC: B #0xc7a868                |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x00C7A800: ADRP x19, #0x364f000       | X19 = 56946688 (0x364F000);             
            // 0x00C7A804: LDR x19, [x19, #0x9e0]     | X19 = 1152921504652693504;              
            val_2 = 1152921504652693504;
            // 0x00C7A808: LDR x0, [x19]              | X0 = typeof(System.DateTime);           
            val_6 = null;
            // 0x00C7A80C: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00C7A810: TBZ w8, #0, #0xc7a824      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00C7A814: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A818: CBNZ w8, #0xc7a824         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00C7A81C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            // 0x00C7A820: LDR x0, [x19]              | X0 = typeof(System.DateTime);           
            val_6 = null;
            label_9:
            // 0x00C7A824: LDR x8, [x0, #0xa0]        | X8 = System.DateTime.__il2cppRuntimeField_static_fields;
            // 0x00C7A828: LDP x0, x1, [x8]           | X0 = System.DateTime.MaxValue; X1 = System.DateTime.MaxValue.__il2cppRuntimeField_8; //  | 
            val_4 = System.DateTime.MaxValue;
            // 0x00C7A82C: B #0xc7a868                |  goto label_10;                         
            goto label_10;
            label_4:
            // 0x00C7A830: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BclHelpers);       
            val_7 = null;
            // 0x00C7A834: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_10A;
            // 0x00C7A838: TBZ w8, #0, #0xc7a84c      | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00C7A83C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A840: CBNZ w8, #0xc7a84c         | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00C7A844: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BclHelpers), ????);
            // 0x00C7A848: LDR x0, [x20]              | X0 = typeof(ProtoBuf.BclHelpers);       
            val_7 = null;
            label_12:
            // 0x00C7A84C: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_static_fields;
            // 0x00C7A850: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A854: MOV x0, sp                 | X0 = 1152921514332663824 (0x1000000243B43010);//ML01
            val_4;
            // 0x00C7A858: MOV x1, x19                | X1 = val_1;//m1                         
            val_5 = val_2;
            // 0x00C7A85C: LDP x9, x8, [x8]           | X9 = ProtoBuf.BclHelpers.FieldObject; X8 = ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_8; //  | 
            // 0x00C7A860: STP x9, x8, [sp]           | stack[1152921514332663824] = ProtoBuf.BclHelpers.FieldObject;  stack[1152921514332663832] = ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_8;  //  dest_result_addr=1152921514332663824 |  dest_result_addr=1152921514332663832
            // 0x00C7A864: BL #0x1bafdd8              | X0 = label_System_DateTime_get_Kind_GL01BAFDD8();
            label_10:
            // 0x00C7A868: SUB sp, x29, #0x10         | SP = (1152921514332663856 - 16) = 1152921514332663840 (0x1000000243B43020);
            // 0x00C7A86C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7A870: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7A874: RET                        |  return new System.DateTime() {ticks = new System.TimeSpan() {_ticks = val_4}, kind = val_5};
            return new System.DateTime() {ticks = new System.TimeSpan() {_ticks = val_4}, kind = val_5};
            //  |  // // {name=val_0.ticks._ticks, type=System.Int64, size=8, nGRN=0 offset=0 }
            //  |  // // {name=val_0.kind, type=System.DateTimeKind, size=8, nGRN=1 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7A878 (13084792), len: 604  VirtAddr: 0x00C7A878 RVA: 0x00C7A878 token: 100689119 methodIndex: 53350 delegateWrapperIndex: 0 methodInvoker: 0
        public static void WriteDateTime(System.DateTime value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            System.TimeSpan val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            // 0x00C7A878: STP x24, x23, [sp, #-0x40]! | stack[1152921514332825984] = ???;  stack[1152921514332825992] = ???;  //  dest_result_addr=1152921514332825984 |  dest_result_addr=1152921514332825992
            // 0x00C7A87C: STP x22, x21, [sp, #0x10]  | stack[1152921514332826000] = ???;  stack[1152921514332826008] = ???;  //  dest_result_addr=1152921514332826000 |  dest_result_addr=1152921514332826008
            // 0x00C7A880: STP x20, x19, [sp, #0x20]  | stack[1152921514332826016] = ???;  stack[1152921514332826024] = ???;  //  dest_result_addr=1152921514332826016 |  dest_result_addr=1152921514332826024
            // 0x00C7A884: STP x29, x30, [sp, #0x30]  | stack[1152921514332826032] = ???;  stack[1152921514332826040] = ???;  //  dest_result_addr=1152921514332826032 |  dest_result_addr=1152921514332826040
            // 0x00C7A888: ADD x29, sp, #0x30         | X29 = (1152921514332825984 + 48) = 1152921514332826032 (0x1000000243B6A9B0);
            // 0x00C7A88C: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00C7A890: LDRB w8, [x22, #0xf7a]     | W8 = (bool)static_value_03733F7A;       
            // 0x00C7A894: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00C7A898: MOV x20, x2                | X20 = dest;//m1                         
            // 0x00C7A89C: MOV x21, x1                | X21 = value.kind;//m1                   
            // 0x00C7A8A0: TBNZ w8, #0, #0xc7a8bc     | if (static_value_03733F7A == true) goto label_0;
            // 0x00C7A8A4: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x00C7A8A8: LDR x8, [x8, #0xda8]       | X8 = 0x2B8F15C;                         
            // 0x00C7A8AC: LDR w0, [x8]               | W0 = 0x1319;                            
            // 0x00C7A8B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1319, ????);     
            // 0x00C7A8B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7A8B8: STRB w8, [x22, #0xf7a]     | static_value_03733F7A = true;            //  dest_result_addr=57884538
            label_0:
            // 0x00C7A8BC: CBZ x19, #0xc7aa94         | if (X3 == 0) goto label_1;              
            if(X3 == 0)
            {
                goto label_1;
            }
            // 0x00C7A8C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A8C4: MOV x0, x19                | X0 = X3;//m1                            
            // 0x00C7A8C8: BL #0x2988c04              | X0 = X3.get_WireType();                 
            ProtoBuf.WireType val_1 = X3.WireType;
            // 0x00C7A8CC: AND w8, w0, #0xfffffffe    | W8 = (val_1 & 4294967294);              
            ProtoBuf.WireType val_2 = val_1 & 4294967294;
            // 0x00C7A8D0: CMP w8, #2                 | STATE = COMPARE((val_1 & 4294967294), 0x2)
            // 0x00C7A8D4: B.NE #0xc7a94c             | if (val_2 != 0x2) goto label_2;         
            if(val_2 != 2)
            {
                goto label_2;
            }
            // 0x00C7A8D8: ADRP x22, #0x364f000       | X22 = 56946688 (0x364F000);             
            // 0x00C7A8DC: LDR x22, [x22, #0x9e0]     | X22 = 1152921504652693504;              
            // 0x00C7A8E0: LDR x0, [x22]              | X0 = typeof(System.DateTime);           
            val_8 = null;
            // 0x00C7A8E4: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00C7A8E8: TBZ w8, #0, #0xc7a8fc      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C7A8EC: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A8F0: CBNZ w8, #0xc7a8fc         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C7A8F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            // 0x00C7A8F8: LDR x0, [x22]              | X0 = typeof(System.DateTime);           
            val_8 = null;
            label_4:
            // 0x00C7A8FC: LDR x8, [x0, #0xa0]        | X8 = System.DateTime.__il2cppRuntimeField_static_fields;
            // 0x00C7A900: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A904: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7A908: MOV x1, x21                | X1 = value.kind;//m1                    
            // 0x00C7A90C: LDP x3, x4, [x8]           | X3 = System.DateTime.MaxValue; X4 = System.DateTime.MaxValue.__il2cppRuntimeField_8; //  | 
            // 0x00C7A910: MOV x2, x20                | X2 = dest;//m1                          
            // 0x00C7A914: BL #0x1bb7174              | X0 = System.DateTime.op_Equality(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = value.kind}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = dest}, kind = System.DateTime.MaxValue});
            bool val_3 = System.DateTime.op_Equality(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = value.kind}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = dest}, kind = System.DateTime.MaxValue});
            // 0x00C7A918: TBZ w0, #0, #0xc7a984      | if (val_3 == false) goto label_5;       
            if(val_3 == false)
            {
                goto label_5;
            }
            // 0x00C7A91C: ADRP x20, #0x3610000       | X20 = 56688640 (0x3610000);             
            // 0x00C7A920: LDR x20, [x20, #0x6d0]     | X20 = 1152921504656633856;              
            // 0x00C7A924: LDR x0, [x20]              | X0 = typeof(System.TimeSpan);           
            val_9 = null;
            // 0x00C7A928: LDRB w8, [x0, #0x10a]      | W8 = System.TimeSpan.__il2cppRuntimeField_10A;
            // 0x00C7A92C: TBZ w8, #0, #0xc7a940      | if (System.TimeSpan.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00C7A930: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A934: CBNZ w8, #0xc7a940         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00C7A938: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            // 0x00C7A93C: LDR x0, [x20]              | X0 = typeof(System.TimeSpan);           
            val_9 = null;
            label_7:
            // 0x00C7A940: LDR x8, [x0, #0xa0]        | X8 = System.TimeSpan.__il2cppRuntimeField_static_fields;
            // 0x00C7A944: LDR x20, [x8]              | X20 = System.TimeSpan.MaxValue;         
            val_10 = System.TimeSpan.MaxValue;
            // 0x00C7A948: B #0xc7aa58                |  goto label_17;                         
            goto label_17;
            label_2:
            // 0x00C7A94C: ADRP x22, #0x35ee000       | X22 = 56549376 (0x35EE000);             
            // 0x00C7A950: LDR x22, [x22, #0xd90]     | X22 = 1152921504881287168;              
            // 0x00C7A954: LDR x0, [x22]              | X0 = typeof(ProtoBuf.BclHelpers);       
            val_11 = null;
            // 0x00C7A958: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_10A;
            // 0x00C7A95C: TBZ w8, #0, #0xc7a970      | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00C7A960: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A964: CBNZ w8, #0xc7a970         | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00C7A968: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BclHelpers), ????);
            // 0x00C7A96C: LDR x0, [x22]              | X0 = typeof(ProtoBuf.BclHelpers);       
            val_11 = null;
            label_10:
            // 0x00C7A970: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x00C7A974: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_static_fields;
            // 0x00C7A978: LDR x9, [x9, #0x9e0]       | X9 = 1152921504652693504;               
            // 0x00C7A97C: LDR x0, [x9]               | X0 = typeof(System.DateTime);           
            val_13 = null;
            // 0x00C7A980: B #0xc7aa1c                |  goto label_11;                         
            goto label_11;
            label_5:
            // 0x00C7A984: LDR x0, [x22]              | X0 = typeof(System.DateTime);           
            val_14 = null;
            // 0x00C7A988: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00C7A98C: TBZ w8, #0, #0xc7a9a0      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00C7A990: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A994: CBNZ w8, #0xc7a9a0         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00C7A998: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            // 0x00C7A99C: LDR x0, [x22]              | X0 = typeof(System.DateTime);           
            val_14 = null;
            label_13:
            // 0x00C7A9A0: LDR x8, [x0, #0xa0]        | X8 = System.DateTime.__il2cppRuntimeField_static_fields;
            // 0x00C7A9A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A9A8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7A9AC: MOV x1, x21                | X1 = value.kind;//m1                    
            // 0x00C7A9B0: LDP x3, x4, [x8, #0x10]    | X3 = System.DateTime.MinValue; X4 = System.DateTime.MaxValue.__il2cppRuntimeField_18; //  | 
            // 0x00C7A9B4: MOV x2, x20                | X2 = dest;//m1                          
            // 0x00C7A9B8: BL #0x1bb7174              | X0 = System.DateTime.op_Equality(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = value.kind}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = dest}, kind = System.DateTime.MinValue});
            bool val_4 = System.DateTime.op_Equality(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = value.kind}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = dest}, kind = System.DateTime.MinValue});
            // 0x00C7A9BC: TBZ w0, #0, #0xc7a9f0      | if (val_4 == false) goto label_14;      
            if(val_4 == false)
            {
                goto label_14;
            }
            // 0x00C7A9C0: ADRP x20, #0x3610000       | X20 = 56688640 (0x3610000);             
            // 0x00C7A9C4: LDR x20, [x20, #0x6d0]     | X20 = 1152921504656633856;              
            // 0x00C7A9C8: LDR x0, [x20]              | X0 = typeof(System.TimeSpan);           
            val_15 = null;
            // 0x00C7A9CC: LDRB w8, [x0, #0x10a]      | W8 = System.TimeSpan.__il2cppRuntimeField_10A;
            // 0x00C7A9D0: TBZ w8, #0, #0xc7a9e4      | if (System.TimeSpan.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00C7A9D4: LDR w8, [x0, #0xbc]        | W8 = System.TimeSpan.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A9D8: CBNZ w8, #0xc7a9e4         | if (System.TimeSpan.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00C7A9DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.TimeSpan), ????);
            // 0x00C7A9E0: LDR x0, [x20]              | X0 = typeof(System.TimeSpan);           
            val_15 = null;
            label_16:
            // 0x00C7A9E4: LDR x8, [x0, #0xa0]        | X8 = System.TimeSpan.__il2cppRuntimeField_static_fields;
            // 0x00C7A9E8: LDR x20, [x8, #8]          | X20 = System.TimeSpan.MinValue;         
            val_10 = System.TimeSpan.MinValue;
            // 0x00C7A9EC: B #0xc7aa58                |  goto label_17;                         
            goto label_17;
            label_14:
            // 0x00C7A9F0: ADRP x23, #0x35ee000       | X23 = 56549376 (0x35EE000);             
            // 0x00C7A9F4: LDR x23, [x23, #0xd90]     | X23 = 1152921504881287168;              
            // 0x00C7A9F8: LDR x0, [x23]              | X0 = typeof(ProtoBuf.BclHelpers);       
            val_16 = null;
            // 0x00C7A9FC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_10A;
            // 0x00C7AA00: TBZ w8, #0, #0xc7aa14      | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00C7AA04: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AA08: CBNZ w8, #0xc7aa14         | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00C7AA0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BclHelpers), ????);
            // 0x00C7AA10: LDR x0, [x23]              | X0 = typeof(ProtoBuf.BclHelpers);       
            val_16 = null;
            label_19:
            // 0x00C7AA14: LDR x8, [x0, #0xa0]        | X8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_static_fields;
            // 0x00C7AA18: LDR x0, [x22]              | X0 = typeof(System.DateTime);           
            val_13 = null;
            label_11:
            // 0x00C7AA1C: LDR x23, [x8]              | X23 = ProtoBuf.BclHelpers.FieldObject;  
            // 0x00C7AA20: LDR x22, [x8, #8]          | X22 = ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_8;
            // 0x00C7AA24: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x00C7AA28: TBZ w8, #0, #0xc7aa38      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00C7AA2C: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AA30: CBNZ w8, #0xc7aa38         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00C7AA34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_21:
            // 0x00C7AA38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AA3C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7AA40: MOV x1, x21                | X1 = value.kind;//m1                    
            // 0x00C7AA44: MOV x2, x20                | X2 = dest;//m1                          
            // 0x00C7AA48: MOV x3, x23                | X3 = ProtoBuf.BclHelpers.FieldObject;//m1
            // 0x00C7AA4C: MOV x4, x22                | X4 = ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_8;//m1
            // 0x00C7AA50: BL #0x1bb73e0              | X0 = System.DateTime.op_Subtraction(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = value.kind}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = dest}, kind = ProtoBuf.BclHelpers.__il2cppRuntimeField_static_fields});
            System.TimeSpan val_5 = System.DateTime.op_Subtraction(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = value.kind}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = dest}, kind = ProtoBuf.BclHelpers.__il2cppRuntimeField_static_fields});
            // 0x00C7AA54: MOV x20, x0                | X20 = val_5._ticks;//m1                 
            val_10 = val_5._ticks;
            label_17:
            // 0x00C7AA58: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00C7AA5C: LDR x8, [x8, #0xd90]       | X8 = 1152921504881287168;               
            // 0x00C7AA60: LDR x0, [x8]               | X0 = typeof(ProtoBuf.BclHelpers);       
            // 0x00C7AA64: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_10A;
            // 0x00C7AA68: TBZ w8, #0, #0xc7aa78      | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_has_cctor == 0) goto label_23;
            // 0x00C7AA6C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AA70: CBNZ w8, #0xc7aa78         | if (ProtoBuf.BclHelpers.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
            // 0x00C7AA74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.BclHelpers), ????);
            label_23:
            // 0x00C7AA78: MOV x1, x20                | X1 = val_5._ticks;//m1                  
            // 0x00C7AA7C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7AA80: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7AA84: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7AA88: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7AA8C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00C7AA90: B #0xc79d58                | ProtoBuf.BclHelpers.WriteTimeSpan(timeSpan:  new System.TimeSpan(), dest:  val_10); return;
            ProtoBuf.BclHelpers.WriteTimeSpan(timeSpan:  new System.TimeSpan(), dest:  val_10);
            return;
            label_1:
            // 0x00C7AA94: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00C7AA98: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00C7AA9C: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_6 = null;
            // 0x00C7AAA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7AAA4: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00C7AAA8: LDR x8, [x8, #0x5d8]       | X8 = (string**)(1152921514332272144)("dest");
            // 0x00C7AAAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7AAB0: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C7AAB4: LDR x1, [x8]               | X1 = "dest";                            
            // 0x00C7AAB8: BL #0x18b3df0              | .ctor(paramName:  "dest");              
            val_6 = new System.ArgumentNullException(paramName:  "dest");
            // 0x00C7AABC: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x00C7AAC0: LDR x8, [x8, #0x5a0]       | X8 = 1152921514332776160;               
            // 0x00C7AAC4: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C7AAC8: LDR x1, [x8]               | X1 = public static System.Void ProtoBuf.BclHelpers::WriteDateTime(System.DateTime value, ProtoBuf.ProtoWriter dest);
            // 0x00C7AACC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7AAD0: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
            System.Byte[] val_7 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7A338 (13083448), len: 1048  VirtAddr: 0x00C7A338 RVA: 0x00C7A338 token: 100689120 methodIndex: 53351 delegateWrapperIndex: 0 methodInvoker: 0
        private static long ReadTimeSpanTicks(ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_17;
            //  | 
            string val_18;
            //  | 
            long val_19;
            //  | 
            var val_20;
            // 0x00C7A338: STP x24, x23, [sp, #-0x40]! | stack[1152921514333053936] = ???;  stack[1152921514333053944] = ???;  //  dest_result_addr=1152921514333053936 |  dest_result_addr=1152921514333053944
            // 0x00C7A33C: STP x22, x21, [sp, #0x10]  | stack[1152921514333053952] = ???;  stack[1152921514333053960] = ???;  //  dest_result_addr=1152921514333053952 |  dest_result_addr=1152921514333053960
            // 0x00C7A340: STP x20, x19, [sp, #0x20]  | stack[1152921514333053968] = ???;  stack[1152921514333053976] = ???;  //  dest_result_addr=1152921514333053968 |  dest_result_addr=1152921514333053976
            // 0x00C7A344: STP x29, x30, [sp, #0x30]  | stack[1152921514333053984] = ???;  stack[1152921514333053992] = ???;  //  dest_result_addr=1152921514333053984 |  dest_result_addr=1152921514333053992
            // 0x00C7A348: ADD x29, sp, #0x30         | X29 = (1152921514333053936 + 48) = 1152921514333053984 (0x1000000243BA2420);
            // 0x00C7A34C: SUB sp, sp, #0x20          | SP = (1152921514333053936 - 32) = 1152921514333053904 (0x1000000243BA23D0);
            // 0x00C7A350: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7A354: LDRB w8, [x20, #0xf7b]     | W8 = (bool)static_value_03733F7B;       
            // 0x00C7A358: MOV x19, x1                | X19 = X1;//m1                           
            val_18 = X1;
            // 0x00C7A35C: TBNZ w8, #0, #0xc7a378     | if (static_value_03733F7B == true) goto label_0;
            // 0x00C7A360: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x00C7A364: LDR x8, [x8, #0x7b0]       | X8 = 0x2B8F158;                         
            // 0x00C7A368: LDR w0, [x8]               | W0 = 0x1318;                            
            // 0x00C7A36C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1318, ????);     
            // 0x00C7A370: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7A374: STRB w8, [x20, #0xf7b]     | static_value_03733F7B = true;            //  dest_result_addr=57884539
            label_0:
            // 0x00C7A378: STR wzr, [sp, #0x1c]       | stack[1152921514333053932] = 0x0;        //  dest_result_addr=1152921514333053932
            // 0x00C7A37C: STR xzr, [sp, #0x10]       | stack[1152921514333053920] = 0x0;        //  dest_result_addr=1152921514333053920
            // 0x00C7A380: STR wzr, [sp, #0xc]        | stack[1152921514333053916] = 0x0;        //  dest_result_addr=1152921514333053916
            // 0x00C7A384: CBNZ x19, #0xc7a38c        | if (X1 != 0) goto label_1;              
            if(val_18 != 0)
            {
                goto label_1;
            }
            // 0x00C7A388: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1318, ????);     
            label_1:
            // 0x00C7A38C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A390: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A394: BL #0x2985428              | X0 = X1.get_WireType();                 
            ProtoBuf.WireType val_1 = val_18.WireType;
            // 0x00C7A398: SUB w8, w0, #1             | W8 = (val_1 - 1);                       
            ProtoBuf.WireType val_2 = val_1 - 1;
            // 0x00C7A39C: CMP w8, #2                 | STATE = COMPARE((val_1 - 1), 0x2)       
            // 0x00C7A3A0: B.HI #0xc7a3c4             | if (val_2 > 0x2) goto label_2;          
            if(val_2 > 2)
            {
                goto label_2;
            }
            // 0x00C7A3A4: ADRP x9, #0x2a93000        | X9 = 44642304 (0x2A93000);              
            // 0x00C7A3A8: ADD x9, x9, #0xa08         | X9 = (44642304 + 2568) = 44644872 (0x02A93A08);
            // 0x00C7A3AC: LDR w8, [x9, w8, sxtw #2]  | W8 = 44644872 + ((val_1 - 1)) << 2;     
            // 0x00C7A3B0: CMP w8, #3                 | STATE = COMPARE(44644872 + ((val_1 - 1)) << 2, 0x3)
            // 0x00C7A3B4: B.EQ #0xc7a4a8             | if (44644872 + ((val_1 - 1)) << 2 == 0x3) goto label_3;
            if((44644872 + ((val_1 - 1)) << 2) == 3)
            {
                goto label_3;
            }
            // 0x00C7A3B8: CMP w8, #4                 | STATE = COMPARE(44644872 + ((val_1 - 1)) << 2, 0x4)
            // 0x00C7A3BC: B.EQ #0xc7a4c4             | if (44644872 + ((val_1 - 1)) << 2 == 0x4) goto label_4;
            if((44644872 + ((val_1 - 1)) << 2) == 4)
            {
                goto label_4;
            }
            // 0x00C7A3C0: CBNZ w8, #0xc7a66c         | if (44644872 + ((val_1 - 1)) << 2 != 0) goto label_40;
            if((44644872 + ((val_1 - 1)) << 2) != 0)
            {
                goto label_40;
            }
            label_2:
            // 0x00C7A3C4: CBNZ x19, #0xc7a3cc        | if (X1 != 0) goto label_6;              
            if(val_18 != 0)
            {
                goto label_6;
            }
            // 0x00C7A3C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00C7A3CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A3D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A3D4: BL #0x2985428              | X0 = X1.get_WireType();                 
            ProtoBuf.WireType val_3 = val_18.WireType;
            // 0x00C7A3D8: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00C7A3DC: LDR x8, [x8, #0x5c8]       | X8 = 1152921504886984704;               
            // 0x00C7A3E0: STR w0, [sp, #0xc]         | stack[1152921514333053916] = val_3;      //  dest_result_addr=1152921514333053916
            // 0x00C7A3E4: ADD x1, sp, #0xc           | X1 = (1152921514333053904 + 12) = 1152921514333053916 (0x1000000243BA23DC);
            // 0x00C7A3E8: LDR x8, [x8]               | X8 = typeof(ProtoBuf.WireType);         
            // 0x00C7A3EC: MOV x0, x8                 | X0 = 1152921504886984704 (0x1000000010B29000);//ML01
            // 0x00C7A3F0: BL #0x27bc028              | X0 = 1152921514333110288 = (Il2CppObject*)Box((RuntimeClass*)typeof(ProtoBuf.WireType), val_3);
            // 0x00C7A3F4: MOV x20, x0                | X20 = 1152921514333110288 (0x1000000243BB0010);//ML01
            // 0x00C7A3F8: CBNZ x20, #0xc7a400        | if (val_3 != 0) goto label_7;           
            if(val_3 != 0)
            {
                goto label_7;
            }
            // 0x00C7A3FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x00C7A400: LDR x8, [x20]              | X8 = typeof(ProtoBuf.WireType);         
            // 0x00C7A404: MOV x0, x20                | X0 = 1152921514333110288 (0x1000000243BB0010);//ML01
            // 0x00C7A408: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
            // 0x00C7A40C: BLR x9                     | X0 = val_3.ToString();                  
            string val_4 = val_3.ToString();
            // 0x00C7A410: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x00C7A414: CBNZ x20, #0xc7a41c        | if (val_3 != 0) goto label_8;           
            if(val_3 != 0)
            {
                goto label_8;
            }
            // 0x00C7A418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x00C7A41C: MOV x0, x20                | X0 = 1152921514333110288 (0x1000000243BB0010);//ML01
            // 0x00C7A420: BL #0x27bc4e8              | val_3.System.IDisposable.Dispose();     
            val_3.System.IDisposable.Dispose();
            // 0x00C7A424: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00C7A428: LDR w8, [x0]               | W8 = typeof(ProtoBuf.WireType);         
            // 0x00C7A42C: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x00C7A430: STR w8, [sp, #0xc]         | stack[1152921514333053916] = typeof(ProtoBuf.WireType);  //  dest_result_addr=1152921514333053916
            // 0x00C7A434: LDR x0, [x9]               | X0 = typeof(System.String);             
            // 0x00C7A438: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00C7A43C: TBZ w8, #0, #0xc7a44c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00C7A440: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A444: CBNZ w8, #0xc7a44c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00C7A448: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_10:
            // 0x00C7A44C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00C7A450: LDR x8, [x8, #0x4a8]       | X8 = (string**)(1152921514332221856)("Unexpected wire-type: ");
            label_48:
            // 0x00C7A454: LDR x1, [x8]               | X1 = "Unexpected wire-type: ";          
            // 0x00C7A458: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A45C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7A460: MOV x2, x19                | X2 = val_4;//m1                         
            // 0x00C7A464: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Unexpected wire-type: ");
            string val_5 = System.String.Concat(str0:  0, str1:  "Unexpected wire-type: ");
            // 0x00C7A468: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00C7A46C: LDR x8, [x8, #0x720]       | X8 = 1152921504884002816;               
            // 0x00C7A470: MOV x19, x0                | X19 = val_5;//m1                        
            val_18 = val_5;
            // 0x00C7A474: LDR x8, [x8]               | X8 = typeof(ProtoBuf.ProtoException);   
            // 0x00C7A478: MOV x0, x8                 | X0 = 1152921504884002816 (0x1000000010851000);//ML01
            ProtoBuf.ProtoException val_6 = null;
            // 0x00C7A47C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C7A480: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A484: MOV x1, x19                | X1 = val_5;//m1                         
            // 0x00C7A488: MOV x20, x0                | X20 = 1152921504884002816 (0x1000000010851000);//ML01
            // 0x00C7A48C: BL #0x2980224              | .ctor(message:  val_18);                
            val_6 = new ProtoBuf.ProtoException(message:  val_18);
            // 0x00C7A490: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x00C7A494: LDR x8, [x8, #0x3c0]       | X8 = 1152921514332995680;               
            // 0x00C7A498: MOV x0, x20                | X0 = 1152921504884002816 (0x1000000010851000);//ML01
            // 0x00C7A49C: LDR x1, [x8]               | X1 = static System.Int64 ProtoBuf.BclHelpers::ReadTimeSpanTicks(ProtoBuf.ProtoReader source);
            // 0x00C7A4A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C7A4A4: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  277155840);
            System.Byte[] val_7 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  277155840);
            label_3:
            // 0x00C7A4A8: CBNZ x19, #0xc7a4b0        | if (val_5 != null) goto label_11;       
            if(val_18 != null)
            {
                goto label_11;
            }
            // 0x00C7A4AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_11:
            // 0x00C7A4B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A4B4: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x00C7A4B8: BL #0x297e744              | X0 = val_5.ReadInt64();                 
            long val_8 = val_18.ReadInt64();
            // 0x00C7A4BC: MOV x20, x0                | X20 = val_8;//m1                        
            val_17 = val_8;
            // 0x00C7A4C0: B #0xc7a66c                |  goto label_40;                         
            goto label_40;
            label_4:
            // 0x00C7A4C4: ADRP x23, #0x367b000       | X23 = 57126912 (0x367B000);             
            // 0x00C7A4C8: LDR x23, [x23, #0x668]     | X23 = 1152921504884375552;              
            // 0x00C7A4CC: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7A4D0: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7A4D4: TBZ w8, #0, #0xc7a4e4      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00C7A4D8: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A4DC: CBNZ w8, #0xc7a4e4         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
            // 0x00C7A4E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_14:
            // 0x00C7A4E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A4E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A4EC: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00C7A4F0: BL #0x297e198              | X0 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            ProtoBuf.SubItemToken val_9 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            // 0x00C7A4F4: MOV x22, x0                | X22 = val_9.value;//m1                  
            // 0x00C7A4F8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x00C7A4FC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            // 0x00C7A500: STR wzr, [sp, #0x1c]       | stack[1152921514333053932] = 0x0;        //  dest_result_addr=1152921514333053932
            // 0x00C7A504: B #0xc7a518                |  goto label_15;                         
            goto label_15;
            label_27:
            // 0x00C7A508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A50C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A510: BL #0x297e744              | X0 = X1.ReadInt64();                    
            long val_10 = val_18.ReadInt64();
            // 0x00C7A514: MOV x20, x0                | X20 = val_10;//m1                       
            val_19 = val_10;
            label_15:
            // 0x00C7A518: STR x20, [sp, #0x10]       | stack[1152921514333053920] = val_10;     //  dest_result_addr=1152921514333053920
            // 0x00C7A51C: B #0xc7a52c                |  goto label_24;                         
            goto label_24;
            label_22:
            // 0x00C7A520: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A524: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A528: BL #0x297dbac              | X1.SkipField();                         
            val_18.SkipField();
            label_24:
            // 0x00C7A52C: CBNZ x19, #0xc7a534        | if (X1 != 0) goto label_17;             
            if(val_18 != 0)
            {
                goto label_17;
            }
            // 0x00C7A530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_17:
            // 0x00C7A534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A538: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A53C: BL #0x297da18              | X0 = X1.ReadFieldHeader();              
            int val_11 = val_18.ReadFieldHeader();
            // 0x00C7A540: CMP w0, #0                 | STATE = COMPARE(val_11, 0x0)            
            // 0x00C7A544: B.LE #0xc7a5b8             | if (val_11 <= 0) goto label_18;         
            if(val_11 <= 0)
            {
                goto label_18;
            }
            // 0x00C7A548: CMP w0, #1                 | STATE = COMPARE(val_11, 0x1)            
            // 0x00C7A54C: B.EQ #0xc7a584             | if (val_11 == 1) goto label_19;         
            if(val_11 == 1)
            {
                goto label_19;
            }
            // 0x00C7A550: CMP w0, #2                 | STATE = COMPARE(val_11, 0x2)            
            // 0x00C7A554: B.EQ #0xc7a564             | if (val_11 == 2) goto label_20;         
            if(val_11 == 2)
            {
                goto label_20;
            }
            // 0x00C7A558: CBNZ x19, #0xc7a520        | if (X1 != 0) goto label_22;             
            if(val_18 != 0)
            {
                goto label_22;
            }
            // 0x00C7A55C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x00C7A560: B #0xc7a520                |  goto label_22;                         
            goto label_22;
            label_20:
            // 0x00C7A564: CBNZ x19, #0xc7a56c        | if (X1 != 0) goto label_23;             
            if(val_18 != 0)
            {
                goto label_23;
            }
            // 0x00C7A568: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_23:
            // 0x00C7A56C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A570: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A574: BL #0x297e4f8              | X0 = X1.ReadInt32();                    
            int val_12 = val_18.ReadInt32();
            // 0x00C7A578: MOV w21, w0                | W21 = val_12;//m1                       
            // 0x00C7A57C: STR w21, [sp, #0x1c]       | stack[1152921514333053932] = val_12;     //  dest_result_addr=1152921514333053932
            // 0x00C7A580: B #0xc7a52c                |  goto label_24;                         
            goto label_24;
            label_19:
            // 0x00C7A584: CBZ x19, #0xc7a59c         | if (X1 == 0) goto label_25;             
            if(val_18 == 0)
            {
                goto label_25;
            }
            // 0x00C7A588: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A58C: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00C7A590: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7A594: BL #0x2986b08              | X1.Assert(wireType:  8);                
            val_18.Assert(wireType:  8);
            // 0x00C7A598: B #0xc7a508                |  goto label_27;                         
            goto label_27;
            label_25:
            // 0x00C7A59C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            // 0x00C7A5A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A5A4: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00C7A5A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7A5AC: BL #0x2986b08              | 0.Assert(wireType:  8);                 
            0.Assert(wireType:  8);
            // 0x00C7A5B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x00C7A5B4: B #0xc7a508                |  goto label_27;                         
            goto label_27;
            label_18:
            // 0x00C7A5B8: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7A5BC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7A5C0: TBZ w8, #0, #0xc7a5d0      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x00C7A5C4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A5C8: CBNZ w8, #0xc7a5d0         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x00C7A5CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_29:
            // 0x00C7A5D0: AND x1, x22, #0xffffffff   | X1 = (val_9.value & 4294967295);        
            int val_13 = val_9.value & 4294967295;
            // 0x00C7A5D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7A5D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7A5DC: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00C7A5E0: BL #0x297e2fc              | ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  int val_13 = val_9.value & 4294967295);
            ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  val_13);
            // 0x00C7A5E4: ADD w8, w21, #0x10         | W8 = (0 + 16);                          
            var val_14 = 0 + 16;
            // 0x00C7A5E8: CMP w21, #6                | STATE = COMPARE(0x0, 0x6)               
            // 0x00C7A5EC: CSEL w8, w8, wzr, lo       | W8 = 0 < 0x6 ? (0 + 16) : 0;            
            var val_15 = (0 < 6) ? (val_14) : 0;
            // 0x00C7A5F0: SUB w9, w8, #0x10          | W9 = (0 < 0x6 ? (0 + 16) : 0 - 16);     
            var val_16 = val_15 - 16;
            // 0x00C7A5F4: CMP w9, #4                 | STATE = COMPARE((0 < 0x6 ? (0 + 16) : 0 - 16), 0x4)
            // 0x00C7A5F8: B.HI #0xc7a620             | if (val_16 > 0x4) goto label_30;        
            if(val_16 > 4)
            {
                goto label_30;
            }
            // 0x00C7A5FC: ADRP x8, #0x2a93000        | X8 = 44642304 (0x2A93000);              
            // 0x00C7A600: ADD x8, x8, #0x858         | X8 = (44642304 + 2136) = 44644440 (0x02A93858);
            var val_18 = 44644440;
            // 0x00C7A604: LDRSW x9, [x8, x9, lsl #2] | X9 = 44644440 + ((0 < 0x6 ? (0 + 16) : 0 - 16)) << 2;
            // 0x00C7A608: ADD x8, x9, x8             | X8 = (44644440 + ((0 < 0x6 ? (0 + 16) : 0 - 16)) << 2 + 44644440);
            val_18 = (44644440 + ((0 < 0x6 ? (0 + 16) : 0 - 16)) << 2) + val_18;
            // 0x00C7A60C: BR x8                      | goto (44644440 + ((0 < 0x6 ? (0 + 16) : 0 - 16)) << 2 + 44644440);
            goto (44644440 + ((0 < 0x6 ? (0 + 16) : 0 - 16)) << 2 + 44644440);
            // 0x00C7A610: MOVZ x8, #0xc9, lsl #32    | X8 = 863288426496 (0xC900000000);//ML01 
            // 0x00C7A614: MOVK x8, #0x2a69, lsl #16  | X8 = 863999950848 (0xC92A690000);       
            // 0x00C7A618: MOVK x8, #0xc000           | X8 = 864000000000 (0xC92A69C000);       
            val_20 = 49152;
            // 0x00C7A61C: B #0xc7a668                |  goto label_38;                         
            goto label_38;
            label_30:
            // 0x00C7A620: CBNZ w8, #0xc7a66c         | if (0 < 0x6 ? (0 + 16) : 0 != 0) goto label_40;
            if(val_15 != 0)
            {
                goto label_40;
            }
            // 0x00C7A624: CMP w21, #0xf              | STATE = COMPARE(0x0, 0xF)               
            // 0x00C7A628: B.NE #0xc7a698             | if (0 != 0xF) goto label_33;            
            if(0 != 15)
            {
                goto label_33;
            }
            // 0x00C7A62C: CMP x20, #1                | STATE = COMPARE(val_10, 0x1)            
            // 0x00C7A630: B.NE #0xc7a688             | if (val_19 != 1) goto label_34;         
            if(val_19 != 1)
            {
                goto label_34;
            }
            // 0x00C7A634: ORR x20, xzr, #0x7fffffffffffffff | X20 = 9223372036854775807(0x7FFFFFFFFFFFFFFF);
            val_17 = 9223372036854775807;
            // 0x00C7A638: B #0xc7a66c                |  goto label_40;                         
            goto label_40;
            // 0x00C7A63C: MOVZ x8, #0x8, lsl #32     | X8 = 34359738368 (0x800000000);//ML01   
            // 0x00C7A640: MOVK x8, #0x61c4, lsl #16  | X8 = 35999973376 (0x861C40000);         
            // 0x00C7A644: MOVK x8, #0x6800           | X8 = 36000000000 (0x861C46800);         
            val_20 = 26624;
            // 0x00C7A648: B #0xc7a668                |  goto label_38;                         
            goto label_38;
            // 0x00C7A64C: MOVZ w8, #0x23c3, lsl #16  | W8 = 599982080 (0x23C30000);//ML01      
            // 0x00C7A650: MOVK w8, #0x4600           | W8 = 600000000 (0x23C34600);            
            val_20 = 17920;
            // 0x00C7A654: B #0xc7a668                |  goto label_38;                         
            goto label_38;
            // 0x00C7A658: MOVZ w8, #0x98, lsl #16    | W8 = 9961472 (0x980000);//ML01          
            // 0x00C7A65C: MOVK w8, #0x9680           | W8 = 10000000 (0x989680);               
            val_20 = 38528;
            // 0x00C7A660: B #0xc7a668                |  goto label_38;                         
            goto label_38;
            // 0x00C7A664: MOVZ w8, #0x2710           | W8 = 10000 (0x2710);//ML01              
            val_20 = 10000;
            label_38:
            // 0x00C7A668: MUL x20, x20, x8           | X20 = (val_17 * 10000);                 
            val_17 = val_17 * 10000;
            label_40:
            // 0x00C7A66C: MOV x0, x20                | X0 = (val_17 * 10000);//m1              
            // 0x00C7A670: SUB sp, x29, #0x30         | SP = (1152921514333053984 - 48) = 1152921514333053936 (0x1000000243BA23F0);
            // 0x00C7A674: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7A678: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7A67C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7A680: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00C7A684: RET                        |  return (System.Int64)(val_17 * 10000); 
            return (long)val_17;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
            label_34:
            // 0x00C7A688: CMN x20, #1                | STATE = COMPARE(val_10, 0x1)            
            // 0x00C7A68C: B.NE #0xc7a710             | if (val_19 != 1) goto label_39;         
            if(val_19 != 1)
            {
                goto label_39;
            }
            // 0x00C7A690: ORR x20, xzr, #0x8000000000000000 | X20 = -9223372036854775808(0x8000000000000000);
            // 0x00C7A694: B #0xc7a66c                |  goto label_40;                         
            goto label_40;
            label_33:
            // 0x00C7A698: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00C7A69C: LDR x8, [x8, #0x210]       | X8 = 1152921504881233920;               
            // 0x00C7A6A0: ADD x1, sp, #0x1c          | X1 = (1152921514333053904 + 28) = 1152921514333053932 (0x1000000243BA23EC);
            // 0x00C7A6A4: LDR x0, [x8]               | X0 = typeof(ProtoBuf.TimeSpanScale);    
            // 0x00C7A6A8: BL #0x27bc028              | X0 = 1152921514333159440 = (Il2CppObject*)Box((RuntimeClass*)typeof(ProtoBuf.TimeSpanScale), val_12);
            // 0x00C7A6AC: MOV x20, x0                | X20 = 1152921514333159440 (0x1000000243BBC010);//ML01
            // 0x00C7A6B0: CBNZ x20, #0xc7a6b8        | if (val_12 != 0) goto label_41;         
            if(val_12 != 0)
            {
                goto label_41;
            }
            // 0x00C7A6B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_41:
            // 0x00C7A6B8: LDR x8, [x20]              | X8 = typeof(ProtoBuf.TimeSpanScale);    
            // 0x00C7A6BC: MOV x0, x20                | X0 = 1152921514333159440 (0x1000000243BBC010);//ML01
            // 0x00C7A6C0: LDP x9, x1, [x8, #0x140]   | X9 = public System.String System.Enum::ToString(); X1 = public System.String System.Enum::ToString(); //  | 
            // 0x00C7A6C4: BLR x9                     | X0 = val_12.ToString();                 
            string val_17 = val_12.ToString();
            // 0x00C7A6C8: MOV x19, x0                | X19 = val_17;//m1                       
            // 0x00C7A6CC: CBNZ x20, #0xc7a6d4        | if (val_12 != 0) goto label_42;         
            if(val_12 != 0)
            {
                goto label_42;
            }
            // 0x00C7A6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_42:
            // 0x00C7A6D4: MOV x0, x20                | X0 = 1152921514333159440 (0x1000000243BBC010);//ML01
            // 0x00C7A6D8: BL #0x27bc4e8              | val_12.System.IDisposable.Dispose();    
            val_12.System.IDisposable.Dispose();
            // 0x00C7A6DC: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x00C7A6E0: LDR w8, [x0]               | W8 = typeof(ProtoBuf.TimeSpanScale);    
            // 0x00C7A6E4: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x00C7A6E8: STR w8, [sp, #0x1c]        | stack[1152921514333053932] = typeof(ProtoBuf.TimeSpanScale);  //  dest_result_addr=1152921514333053932
            // 0x00C7A6EC: LDR x0, [x9]               | X0 = typeof(System.String);             
            // 0x00C7A6F0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00C7A6F4: TBZ w8, #0, #0xc7a704      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_44;
            // 0x00C7A6F8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A6FC: CBNZ w8, #0xc7a704         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_44;
            // 0x00C7A700: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_44:
            // 0x00C7A704: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00C7A708: LDR x8, [x8, #0xfd8]       | X8 = (string**)(1152921514333041760)("Unknown timescale: ");
            // 0x00C7A70C: B #0xc7a454                |  goto label_48;                         
            goto label_48;
            label_39:
            // 0x00C7A710: ADD x0, sp, #0x10          | X0 = (1152921514333053904 + 16) = 1152921514333053920 (0x1000000243BA23E0);
            // 0x00C7A714: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7A718: BL #0x1e65e0c              | X0 = label_System_Int64_TryParse_GL01E65E0C();
            // 0x00C7A71C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C7A720: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00C7A724: MOV x19, x0                | X19 = 1152921514333053920 (0x1000000243BA23E0);//ML01
            // 0x00C7A728: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00C7A72C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00C7A730: TBZ w9, #0, #0xc7a744      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x00C7A734: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C7A738: CBNZ w9, #0xc7a744         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x00C7A73C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00C7A740: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_47:
            // 0x00C7A744: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x00C7A748: LDR x8, [x8, #0xcd8]       | X8 = (string**)(1152921514333041872)("Unknown min/max value: ");
            // 0x00C7A74C: B #0xc7a454                |  goto label_48;                         
            goto label_48;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7AAD4 (13085396), len: 460  VirtAddr: 0x00C7AAD4 RVA: 0x00C7AAD4 token: 100689121 methodIndex: 53352 delegateWrapperIndex: 0 methodInvoker: 0
        public static decimal ReadDecimal(ProtoBuf.ProtoReader reader)
        {
            //
            // Disasemble & Code
            //  | 
            var val_10;
            // 0x00C7AAD4: STP x26, x25, [sp, #-0x50]! | stack[1152921514333239648] = ???;  stack[1152921514333239656] = ???;  //  dest_result_addr=1152921514333239648 |  dest_result_addr=1152921514333239656
            // 0x00C7AAD8: STP x24, x23, [sp, #0x10]  | stack[1152921514333239664] = ???;  stack[1152921514333239672] = ???;  //  dest_result_addr=1152921514333239664 |  dest_result_addr=1152921514333239672
            // 0x00C7AADC: STP x22, x21, [sp, #0x20]  | stack[1152921514333239680] = ???;  stack[1152921514333239688] = ???;  //  dest_result_addr=1152921514333239680 |  dest_result_addr=1152921514333239688
            // 0x00C7AAE0: STP x20, x19, [sp, #0x30]  | stack[1152921514333239696] = ???;  stack[1152921514333239704] = ???;  //  dest_result_addr=1152921514333239696 |  dest_result_addr=1152921514333239704
            // 0x00C7AAE4: STP x29, x30, [sp, #0x40]  | stack[1152921514333239712] = ???;  stack[1152921514333239720] = ???;  //  dest_result_addr=1152921514333239712 |  dest_result_addr=1152921514333239720
            // 0x00C7AAE8: ADD x29, sp, #0x40         | X29 = (1152921514333239648 + 64) = 1152921514333239712 (0x1000000243BCF9A0);
            // 0x00C7AAEC: SUB sp, sp, #0x10          | SP = (1152921514333239648 - 16) = 1152921514333239632 (0x1000000243BCF950);
            // 0x00C7AAF0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7AAF4: LDRB w8, [x20, #0xf7c]     | W8 = (bool)static_value_03733F7C;       
            // 0x00C7AAF8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00C7AAFC: TBNZ w8, #0, #0xc7ab18     | if (static_value_03733F7C == true) goto label_0;
            // 0x00C7AB00: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00C7AB04: LDR x8, [x8, #0xe08]       | X8 = 0x2B8F148;                         
            // 0x00C7AB08: LDR w0, [x8]               | W0 = 0x1314;                            
            // 0x00C7AB0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1314, ????);     
            // 0x00C7AB10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7AB14: STRB w8, [x20, #0xf7c]     | static_value_03733F7C = true;            //  dest_result_addr=57884540
            label_0:
            // 0x00C7AB18: ADRP x24, #0x367b000       | X24 = 57126912 (0x367B000);             
            // 0x00C7AB1C: LDR x24, [x24, #0x668]     | X24 = 1152921504884375552;              
            // 0x00C7AB20: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7AB24: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7AB28: TBZ w8, #0, #0xc7ab38      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7AB2C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AB30: CBNZ w8, #0xc7ab38         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7AB34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_2:
            // 0x00C7AB38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AB3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7AB40: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00C7AB44: BL #0x297e198              | X0 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            ProtoBuf.SubItemToken val_1 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            // 0x00C7AB48: ADRP x25, #0x2a93000       | X25 = 44642304 (0x2A93000);             
            // 0x00C7AB4C: MOV x22, x0                | X22 = val_1.value;//m1                  
            // 0x00C7AB50: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            // 0x00C7AB54: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            // 0x00C7AB58: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x00C7AB5C: ADD x25, x25, #0x86c       | X25 = (44642304 + 2156) = 44644460 (0x02A9386C);
            // 0x00C7AB60: B #0xc7ab70                |  goto label_14;                         
            goto label_14;
            label_8:
            // 0x00C7AB64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AB68: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7AB6C: BL #0x297dbac              | X1.SkipField();                         
            X1.SkipField();
            label_14:
            // 0x00C7AB70: CBNZ x19, #0xc7ab78        | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x00C7AB74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_4:
            // 0x00C7AB78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x00C7AB7C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7AB80: BL #0x297da18              | X0 = X1.ReadFieldHeader();              
            int val_2 = X1.ReadFieldHeader();
            // 0x00C7AB84: CMP w0, #0                 | STATE = COMPARE(val_2, 0x0)             
            // 0x00C7AB88: B.LE #0xc7ac10             | if (val_2 <= 0) goto label_5;           
            if(val_2 <= 0)
            {
                goto label_5;
            }
            // 0x00C7AB8C: SUB w8, w0, #1             | W8 = (val_2 - 1);                       
            int val_3 = val_2 - 1;
            // 0x00C7AB90: ADD w9, w0, #6             | W9 = (val_2 + 6);                       
            int val_4 = val_2 + 6;
            // 0x00C7AB94: CMP w8, #3                 | STATE = COMPARE((val_2 - 1), 0x3)       
            // 0x00C7AB98: CSEL w8, w9, wzr, lo       | W8 = val_3 < 3 ? (val_2 + 6) : 0;       
            var val_5 = (val_3 < 3) ? (val_4) : 0;
            // 0x00C7AB9C: CMP w8, #9                 | STATE = COMPARE(val_3 < 3 ? (val_2 + 6) : 0, 0x9)
            // 0x00C7ABA0: B.HI #0xc7ac80             | if (val_5 > 0x9) goto label_19;         
            if(val_5 > 9)
            {
                goto label_19;
            }
            // 0x00C7ABA4: LDRSW x8, [x25, x8, lsl #2] | X8 = 44644460 + (val_3 < 3 ? (val_2 + 6) : 0) << 2;
            var val_11 = 44644460 + (val_3 < 3 ? (val_2 + 6) : 0) << 2;
            // 0x00C7ABA8: ADD x8, x8, x25            | X8 = (44644460 + (val_3 < 3 ? (val_2 + 6) : 0) << 2 + 44644460);
            val_11 = val_11 + 44644460;
            // 0x00C7ABAC: BR x8                      | goto (44644460 + (val_3 < 3 ? (val_2 + 6) : 0) << 2 + 44644460);
            goto (44644460 + (val_3 < 3 ? (val_2 + 6) : 0) << 2 + 44644460);
            // 0x00C7ABB0: CBNZ x19, #0xc7ab64        | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x00C7ABB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00C7ABB8: B #0xc7ab64                |  goto label_8;                          
            goto label_8;
            // 0x00C7ABBC: CBNZ x19, #0xc7abc4        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00C7ABC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x00C7ABC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7ABC8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7ABCC: BL #0x297ece0              | X0 = X1.ReadUInt64();                   
            ulong val_6 = X1.ReadUInt64();
            // 0x00C7ABD0: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00C7ABD4: B #0xc7ab70                |  goto label_14;                         
            goto label_14;
            // 0x00C7ABD8: CBNZ x19, #0xc7abe0        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00C7ABDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_11:
            // 0x00C7ABE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7ABE4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7ABE8: BL #0x297eae4              | X0 = X1.ReadUInt32();                   
            uint val_7 = X1.ReadUInt32();
            // 0x00C7ABEC: MOV w20, w0                | W20 = val_7;//m1                        
            // 0x00C7ABF0: B #0xc7ab70                |  goto label_14;                         
            goto label_14;
            // 0x00C7ABF4: CBNZ x19, #0xc7abfc        | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x00C7ABF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_13:
            // 0x00C7ABFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AC00: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7AC04: BL #0x297eae4              | X0 = X1.ReadUInt32();                   
            uint val_8 = X1.ReadUInt32();
            // 0x00C7AC08: MOV w23, w0                | W23 = val_8;//m1                        
            // 0x00C7AC0C: B #0xc7ab70                |  goto label_14;                         
            goto label_14;
            label_5:
            // 0x00C7AC10: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7AC14: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7AC18: TBZ w8, #0, #0xc7ac28      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00C7AC1C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AC20: CBNZ w8, #0xc7ac28         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00C7AC24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_16:
            // 0x00C7AC28: AND x1, x22, #0xffffffff   | X1 = (val_1.value & 4294967295);        
            int val_9 = val_1.value & 4294967295;
            // 0x00C7AC2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AC30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AC34: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00C7AC38: BL #0x297e2fc              | ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  int val_9 = val_1.value & 4294967295);
            ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  val_9);
            // 0x00C7AC3C: CBNZ w20, #0xc7ac5c        | if (0x0 != 0) goto label_18;            
            if(0 != 0)
            {
                goto label_18;
            }
            // 0x00C7AC40: CBNZ x21, #0xc7ac5c        | if (0x0 != 0) goto label_18;            
            if(0 != 0)
            {
                goto label_18;
            }
            // 0x00C7AC44: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x00C7AC48: MOV x0, sp                 | X0 = 1152921514333239632 (0x1000000243BCF950);//ML01
            // 0x00C7AC4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7AC50: STP xzr, xzr, [sp]         | stack[1152921514333239632] = 0x0;  stack[1152921514333239640] = 0x0;  //  dest_result_addr=1152921514333239632 |  dest_result_addr=1152921514333239640
            // 0x00C7AC54: BL #0x1c2ee20              | X0 = label_System_Decimal__ctor_GL01C2EE20();
            // 0x00C7AC58: B #0xc7ac80                |  goto label_19;                         
            goto label_19;
            label_18:
            // 0x00C7AC5C: LSR x2, x21, #0x20         | X2 = (0 >> 32) = 0 (0x00000000);        
            // 0x00C7AC60: AND w4, w23, #1            | W4 = (0 & 1);                           
            var val_10 = 0 & 1;
            // 0x00C7AC64: LSR w5, w23, #1            | W5 = (0 >> 1) = 0 (0x00000000);         
            // 0x00C7AC68: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00C7AC6C: MOV x0, sp                 | X0 = 1152921514333239632 (0x1000000243BCF950);//ML01
            // 0x00C7AC70: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x00C7AC74: MOV w3, w20                | W3 = 0 (0x0);//ML01                     
            // 0x00C7AC78: STP xzr, xzr, [sp]         | stack[1152921514333239632] = 0x0;  stack[1152921514333239640] = 0x0;  //  dest_result_addr=1152921514333239632 |  dest_result_addr=1152921514333239640
            // 0x00C7AC7C: BL #0x1c2ed24              | X0 = label_System_DBNull_ToString_GL01C2ED24();
            label_19:
            // 0x00C7AC80: LDP x0, x1, [sp]           | X0 = 0x0; X1 = 0x0;                      //  | 
            // 0x00C7AC84: SUB sp, x29, #0x40         | SP = (1152921514333239712 - 64) = 1152921514333239648 (0x1000000243BCF960);
            // 0x00C7AC88: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7AC8C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7AC90: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7AC94: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7AC98: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7AC9C: RET                        |  return new System.Decimal();           
            return new System.Decimal();
            //  |  // // {name=val_0.flags, type=System.UInt32, size=4, nGRN=0 offset=0 }
            //  |  // // {name=val_0.hi, type=System.UInt32, size=4, nGRN=0 offset=4 }
            //  |  // // {name=val_0.lo, type=System.UInt32, size=4, nGRN=1 offset=0 }
            //  |  // // {name=val_0.mid, type=System.UInt32, size=4, nGRN=1 offset=4 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7ACA0 (13085856), len: 632  VirtAddr: 0x00C7ACA0 RVA: 0x00C7ACA0 token: 100689122 methodIndex: 53353 delegateWrapperIndex: 0 methodInvoker: 0
        public static void WriteDecimal(decimal value, ProtoBuf.ProtoWriter writer)
        {
            //
            // Disasemble & Code
            //  | 
            int val_5;
            //  | 
            int val_6;
            // 0x00C7ACA0: STP x26, x25, [sp, #-0x50]! | stack[1152921514333396704] = ???;  stack[1152921514333396712] = ???;  //  dest_result_addr=1152921514333396704 |  dest_result_addr=1152921514333396712
            // 0x00C7ACA4: STP x24, x23, [sp, #0x10]  | stack[1152921514333396720] = ???;  stack[1152921514333396728] = ???;  //  dest_result_addr=1152921514333396720 |  dest_result_addr=1152921514333396728
            // 0x00C7ACA8: STP x22, x21, [sp, #0x20]  | stack[1152921514333396736] = ???;  stack[1152921514333396744] = ???;  //  dest_result_addr=1152921514333396736 |  dest_result_addr=1152921514333396744
            // 0x00C7ACAC: STP x20, x19, [sp, #0x30]  | stack[1152921514333396752] = ???;  stack[1152921514333396760] = ???;  //  dest_result_addr=1152921514333396752 |  dest_result_addr=1152921514333396760
            // 0x00C7ACB0: STP x29, x30, [sp, #0x40]  | stack[1152921514333396768] = ???;  stack[1152921514333396776] = ???;  //  dest_result_addr=1152921514333396768 |  dest_result_addr=1152921514333396776
            // 0x00C7ACB4: ADD x29, sp, #0x40         | X29 = (1152921514333396704 + 64) = 1152921514333396768 (0x1000000243BF5F20);
            // 0x00C7ACB8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00C7ACBC: LDRB w8, [x22, #0xf7d]     | W8 = (bool)static_value_03733F7D;       
            // 0x00C7ACC0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00C7ACC4: MOV x20, x2                | X20 = writer;//m1                       
            // 0x00C7ACC8: MOV x21, x1                | X21 = value.lo;//m1                     
            // 0x00C7ACCC: TBNZ w8, #0, #0xc7ace8     | if (static_value_03733F7D == true) goto label_0;
            // 0x00C7ACD0: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x00C7ACD4: LDR x8, [x8, #0xd70]       | X8 = 0x2B8F160;                         
            // 0x00C7ACD8: LDR w0, [x8]               | W0 = 0x131A;                            
            // 0x00C7ACDC: BL #0x2782188              | X0 = sub_2782188( ?? 0x131A, ????);     
            // 0x00C7ACE0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7ACE4: STRB w8, [x22, #0xf7d]     | static_value_03733F7D = true;            //  dest_result_addr=57884541
            label_0:
            // 0x00C7ACE8: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
            // 0x00C7ACEC: LDR x8, [x8, #0x480]       | X8 = 1152921504608550912;               
            // 0x00C7ACF0: LDR x0, [x8]               | X0 = typeof(System.Decimal);            
            // 0x00C7ACF4: LDRB w8, [x0, #0x10a]      | W8 = System.Decimal.__il2cppRuntimeField_10A;
            // 0x00C7ACF8: TBZ w8, #0, #0xc7ad08      | if (System.Decimal.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7ACFC: LDR w8, [x0, #0xbc]        | W8 = System.Decimal.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AD00: CBNZ w8, #0xc7ad08         | if (System.Decimal.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7AD04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Decimal), ????);
            label_2:
            // 0x00C7AD08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AD0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AD10: MOV x1, x21                | X1 = value.lo;//m1                      
            // 0x00C7AD14: MOV x2, x20                | X2 = writer;//m1                        
            // 0x00C7AD18: BL #0x1c2fd7c              | X0 = System.Decimal.GetBits(d:  new System.Decimal() {lo = value.lo, mid = value.mid});
            System.Int32[] val_1 = System.Decimal.GetBits(d:  new System.Decimal() {lo = value.lo, mid = value.mid});
            // 0x00C7AD1C: MOV x21, x0                | X21 = val_1;//m1                        
            var val_9 = val_1;
            // 0x00C7AD20: CBNZ x21, #0xc7ad28        | if (val_1 != null) goto label_3;        
            if(val_9 != null)
            {
                goto label_3;
            }
            // 0x00C7AD24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00C7AD28: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_5 = val_1.Length;
            // 0x00C7AD2C: CMP w8, #1                 | STATE = COMPARE(val_1.Length, 0x1)      
            // 0x00C7AD30: B.HI #0xc7ad44             | if (val_5 > 1) goto label_4;            
            if(val_5 > 1)
            {
                goto label_4;
            }
            // 0x00C7AD34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00C7AD38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AD3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00C7AD40: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_5 = val_1.Length;
            label_4:
            // 0x00C7AD44: LDR w23, [x21, #0x24]      | W23 = val_1[1]                          
            int val_5 = val_9[1];
            // 0x00C7AD48: CBNZ w8, #0xc7ad5c         | if (val_1.Length != 0) goto label_5;    
            if(val_5 != 0)
            {
                goto label_5;
            }
            // 0x00C7AD4C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00C7AD50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AD54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00C7AD58: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_5 = val_1.Length;
            label_5:
            // 0x00C7AD5C: LDR w22, [x21, #0x20]      | W22 = val_1[0]                          
            int val_6 = val_9[0];
            // 0x00C7AD60: CMP w8, #2                 | STATE = COMPARE(val_1.Length, 0x2)      
            // 0x00C7AD64: B.HI #0xc7ad78             | if (val_5 > 2) goto label_6;            
            if(val_5 > 2)
            {
                goto label_6;
            }
            // 0x00C7AD68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00C7AD6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AD70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00C7AD74: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_5 = val_1.Length;
            label_6:
            // 0x00C7AD78: LDR w20, [x21, #0x28]      | W20 = val_1[2]                          
            int val_7 = val_9[2];
            // 0x00C7AD7C: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
            // 0x00C7AD80: B.HI #0xc7ad94             | if (val_5 > 3) goto label_7;            
            if(val_5 > 3)
            {
                goto label_7;
            }
            // 0x00C7AD84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00C7AD88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AD8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00C7AD90: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_5 = val_1.Length;
            label_7:
            // 0x00C7AD94: LDR w26, [x21, #0x2c]      | W26 = val_1[3]                          
            int val_8 = val_9[3];
            // 0x00C7AD98: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
            // 0x00C7AD9C: LSL x23, x23, #0x20        | X23 = (val_1[1] << 32);                 
            val_5 = val_5 << 32;
            // 0x00C7ADA0: MOV w25, w26               | W25 = val_1[3];//m1                     
            val_6 = val_8;
            // 0x00C7ADA4: B.HI #0xc7adb8             | if (val_5 > 3) goto label_8;            
            if(val_5 > 3)
            {
                goto label_8;
            }
            // 0x00C7ADA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00C7ADAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7ADB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x00C7ADB4: LDR w25, [x21, #0x2c]      | W25 = val_1[3]                          
            val_6 = val_9[3];
            label_8:
            // 0x00C7ADB8: ADRP x24, #0x35fb000       | X24 = 56602624 (0x35FB000);             
            // 0x00C7ADBC: LDR x24, [x24, #0x778]     | X24 = 1152921504884428800;              
            // 0x00C7ADC0: ORR x23, x22, x23          | X23 = (val_1[0] | (val_1[1] << 32));    
            val_5 = val_6 | val_5;
            // 0x00C7ADC4: LSR w21, w26, #0xf         | W21 = (val_1[3] >> 15);                 
            val_9 = val_8 >> 15;
            // 0x00C7ADC8: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7ADCC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7ADD0: TBZ w8, #0, #0xc7ade0      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00C7ADD4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7ADD8: CBNZ w8, #0xc7ade0         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00C7ADDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_10:
            // 0x00C7ADE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7ADE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7ADE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7ADEC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7ADF0: AND w22, w21, #0x1fe       | W22 = ((val_1[3] >> 15) & 510);         
            int val_2 = val_9 & 510;
            // 0x00C7ADF4: BL #0x2977f50              | X0 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            ProtoBuf.SubItemToken val_3 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            // 0x00C7ADF8: MOV x21, x0                | X21 = val_3.value;//m1                  
            // 0x00C7ADFC: CBZ x23, #0xc7ae44         | if ((val_1[0] | (val_1[1] << 32)) == 0) goto label_11;
            if(val_5 == 0)
            {
                goto label_11;
            }
            // 0x00C7AE00: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7AE04: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7AE08: TBZ w8, #0, #0xc7ae18      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00C7AE0C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AE10: CBNZ w8, #0xc7ae18         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00C7AE14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_13:
            // 0x00C7AE18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AE1C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7AE20: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7AE24: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00C7AE28: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00C7AE2C: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  1, writer:  0);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  1, writer:  0);
            // 0x00C7AE30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AE34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AE38: MOV x1, x23                | X1 = (val_1[0] | (val_1[1] << 32));//m1 
            // 0x00C7AE3C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7AE40: BL #0x2978dd8              | ProtoBuf.ProtoWriter.WriteUInt64(value:  0, writer:  val_1[1]);
            ProtoBuf.ProtoWriter.WriteUInt64(value:  0, writer:  val_5);
            label_11:
            // 0x00C7AE44: BFXIL w22, w25, #0x1f, #1  | 
            // 0x00C7AE48: CBZ w20, #0xc7ae90         | if (val_1[2] == 0) goto label_14;       
            if(val_7 == 0)
            {
                goto label_14;
            }
            // 0x00C7AE4C: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7AE50: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7AE54: TBZ w8, #0, #0xc7ae64      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00C7AE58: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AE5C: CBNZ w8, #0xc7ae64         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00C7AE60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_16:
            // 0x00C7AE64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AE68: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7AE6C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7AE70: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00C7AE74: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00C7AE78: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  2, writer:  0);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  2, writer:  0);
            // 0x00C7AE7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AE80: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AE84: MOV w1, w20                | W1 = val_1[2];//m1                      
            // 0x00C7AE88: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7AE8C: BL #0x2978c34              | ProtoBuf.ProtoWriter.WriteUInt32(value:  0, writer:  val_1[2]);
            ProtoBuf.ProtoWriter.WriteUInt32(value:  0, writer:  val_7);
            label_14:
            // 0x00C7AE90: CBZ w22, #0xc7aed8         | if (((val_1[3] >> 15) & 510) == 0) goto label_17;
            if(val_2 == 0)
            {
                goto label_17;
            }
            // 0x00C7AE94: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7AE98: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7AE9C: TBZ w8, #0, #0xc7aeac      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00C7AEA0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AEA4: CBNZ w8, #0xc7aeac         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00C7AEA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_19:
            // 0x00C7AEAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AEB0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7AEB4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7AEB8: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x00C7AEBC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00C7AEC0: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  3, writer:  0);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  3, writer:  0);
            // 0x00C7AEC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AEC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AECC: MOV w1, w22                | W1 = ((val_1[3] >> 15) & 510);//m1      
            // 0x00C7AED0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7AED4: BL #0x2978c34              | ProtoBuf.ProtoWriter.WriteUInt32(value:  0, writer:  val_2);
            ProtoBuf.ProtoWriter.WriteUInt32(value:  0, writer:  val_2);
            label_17:
            // 0x00C7AED8: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7AEDC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7AEE0: TBZ w8, #0, #0xc7aef0      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00C7AEE4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AEE8: CBNZ w8, #0xc7aef0         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00C7AEEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_21:
            // 0x00C7AEF0: AND x1, x21, #0xffffffff   | X1 = (val_3.value & 4294967295);        
            int val_4 = val_3.value & 4294967295;
            // 0x00C7AEF4: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7AEF8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7AEFC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7AF00: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7AF04: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7AF08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AF0C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AF10: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7AF14: B #0x2977fd0               | ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  int val_4 = val_3.value & 4294967295); return;
            ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  val_4);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7AF18 (13086488), len: 420  VirtAddr: 0x00C7AF18 RVA: 0x00C7AF18 token: 100689123 methodIndex: 53354 delegateWrapperIndex: 0 methodInvoker: 0
        public static void WriteGuid(System.Guid value, ProtoBuf.ProtoWriter dest)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00C7AF18: STP x26, x25, [sp, #-0x50]! | stack[1152921514333553760] = ???;  stack[1152921514333553768] = ???;  //  dest_result_addr=1152921514333553760 |  dest_result_addr=1152921514333553768
            // 0x00C7AF1C: STP x24, x23, [sp, #0x10]  | stack[1152921514333553776] = ???;  stack[1152921514333553784] = ???;  //  dest_result_addr=1152921514333553776 |  dest_result_addr=1152921514333553784
            // 0x00C7AF20: STP x22, x21, [sp, #0x20]  | stack[1152921514333553792] = ???;  stack[1152921514333553800] = ???;  //  dest_result_addr=1152921514333553792 |  dest_result_addr=1152921514333553800
            // 0x00C7AF24: STP x20, x19, [sp, #0x30]  | stack[1152921514333553808] = ???;  stack[1152921514333553816] = ???;  //  dest_result_addr=1152921514333553808 |  dest_result_addr=1152921514333553816
            // 0x00C7AF28: STP x29, x30, [sp, #0x40]  | stack[1152921514333553824] = ???;  stack[1152921514333553832] = ???;  //  dest_result_addr=1152921514333553824 |  dest_result_addr=1152921514333553832
            // 0x00C7AF2C: ADD x29, sp, #0x40         | X29 = (1152921514333553760 + 64) = 1152921514333553824 (0x1000000243C1C4A0);
            // 0x00C7AF30: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7AF34: LDRB w8, [x20, #0xf7e]     | W8 = (bool)static_value_03733F7E;       
            // 0x00C7AF38: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00C7AF3C: STP x1, x2, [sp, #-0x10]!  | stack[1152921514333553744] = value._d; stack[1152921514333553745] = value._e; stack[1152921514333553746] = value._f; stack[1152921514333553747] = value._g; stack[1152921514333553748] = value._h; stack[1152921514333553749] = value._i; stack[1152921514333553750] = value._j; stack[1152921514333553751] = value._k;  stack[1152921514333553752] = dest;  //  dest_result_addr=1152921514333553744 dest_result_addr=1152921514333553745 dest_result_addr=1152921514333553746 dest_result_addr=1152921514333553747 dest_result_addr=1152921514333553748 dest_result_addr=1152921514333553749 dest_result_addr=1152921514333553750 dest_result_addr=1152921514333553751 |  dest_result_addr=1152921514333553752
            // 0x00C7AF40: TBNZ w8, #0, #0xc7af5c     | if (static_value_03733F7E == true) goto label_0;
            // 0x00C7AF44: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00C7AF48: LDR x8, [x8, #0x640]       | X8 = 0x2B8F164;                         
            // 0x00C7AF4C: LDR w0, [x8]               | W0 = 0x131B;                            
            // 0x00C7AF50: BL #0x2782188              | X0 = sub_2782188( ?? 0x131B, ????);     
            // 0x00C7AF54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7AF58: STRB w8, [x20, #0xf7e]     | static_value_03733F7E = true;            //  dest_result_addr=57884542
            label_0:
            // 0x00C7AF5C: MOV x0, sp                 | X0 = 1152921514333553744 (0x1000000243C1C450);//ML01
            // 0x00C7AF60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AF64: BL #0x1c49984              | X0 = sub_1C49984( ?? 0x1000000243C1C450, ????);
            // 0x00C7AF68: ADRP x24, #0x35fb000       | X24 = 56602624 (0x35FB000);             
            // 0x00C7AF6C: LDR x24, [x24, #0x778]     | X24 = 1152921504884428800;              
            // 0x00C7AF70: MOV x20, x0                | X20 = 1152921514333553744 (0x1000000243C1C450);//ML01
            // 0x00C7AF74: LDR x8, [x24]              | X8 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7AF78: LDRB w9, [x8, #0x10a]      | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7AF7C: TBZ w9, #0, #0xc7af90      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7AF80: LDR w9, [x8, #0xbc]        | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AF84: CBNZ w9, #0xc7af90         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7AF88: MOV x0, x8                 | X0 = 1152921504884428800 (0x10000000108B9000);//ML01
            // 0x00C7AF8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_2:
            // 0x00C7AF90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7AF98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7AF9C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7AFA0: BL #0x2977f50              | X0 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            ProtoBuf.SubItemToken val_1 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            // 0x00C7AFA4: ADRP x25, #0x35f2000       | X25 = 56565760 (0x35F2000);             
            // 0x00C7AFA8: LDR x25, [x25, #0x868]     | X25 = 1152921504654024704;              
            // 0x00C7AFAC: MOV x21, x0                | X21 = val_1.value;//m1                  
            // 0x00C7AFB0: LDR x8, [x25]              | X8 = typeof(System.Guid);               
            val_4 = null;
            // 0x00C7AFB4: LDP x23, x22, [sp]         | X23 = value._d; X22 = dest;              //  | 
            // 0x00C7AFB8: LDRB w9, [x8, #0x10a]      | W9 = System.Guid.__il2cppRuntimeField_10A;
            // 0x00C7AFBC: TBZ w9, #0, #0xc7afd4      | if (System.Guid.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00C7AFC0: LDR w9, [x8, #0xbc]        | W9 = System.Guid.__il2cppRuntimeField_cctor_finished;
            // 0x00C7AFC4: CBNZ w9, #0xc7afd4         | if (System.Guid.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00C7AFC8: MOV x0, x8                 | X0 = 1152921504654024704 (0x1000000002CFE000);//ML01
            // 0x00C7AFCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Guid), ????);
            // 0x00C7AFD0: LDR x8, [x25]              | X8 = typeof(System.Guid);               
            val_4 = null;
            label_4:
            // 0x00C7AFD4: LDR x8, [x8, #0xa0]        | X8 = System.Guid.__il2cppRuntimeField_static_fields;
            // 0x00C7AFD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7AFDC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7AFE0: MOV x1, x23                | X1 = value._d;//m1                      
            // 0x00C7AFE4: LDP x3, x4, [x8]           | X3 = System.Guid.Empty; X4 = System.Guid.Empty.__il2cppRuntimeField_8; //  | 
            // 0x00C7AFE8: MOV x2, x22                | X2 = dest;//m1                          
            // 0x00C7AFEC: BL #0x1c4a55c              | X0 = System.Guid.op_Inequality(a:  new System.Guid() {_d = value._d, _e = value._e, _f = value._f, _g = value._g, _h = value._h, _i = value._i, _j = value._j, _k = value._k}, b:  new System.Guid() {_a = dest, _b = dest, _c = dest, _d = System.Guid.Empty, _e = System.Guid.Empty, _f = System.Guid.Empty, _g = System.Guid.Empty, _h = System.Guid.Empty, _i = System.Guid.Empty, _j = System.Guid.Empty, _k = System.Guid.Empty});
            bool val_2 = System.Guid.op_Inequality(a:  new System.Guid() {_d = value._d, _e = value._e, _f = value._f, _g = value._g, _h = value._h, _i = value._i, _j = value._j, _k = value._k}, b:  new System.Guid() {_a = dest, _b = dest, _c = dest, _d = System.Guid.Empty, _e = System.Guid.Empty, _f = System.Guid.Empty, _g = System.Guid.Empty, _h = System.Guid.Empty, _i = System.Guid.Empty, _j = System.Guid.Empty, _k = System.Guid.Empty});
            // 0x00C7AFF0: TBZ w0, #0, #0xc7b074      | if (val_2 == false) goto label_5;       
            if(val_2 == false)
            {
                goto label_5;
            }
            // 0x00C7AFF4: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7AFF8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7AFFC: TBZ w8, #0, #0xc7b00c      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00C7B000: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B004: CBNZ w8, #0xc7b00c         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00C7B008: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_7:
            // 0x00C7B00C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B010: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7B014: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00C7B018: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00C7B01C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00C7B020: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  1, writer:  1);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  1, writer:  1);
            // 0x00C7B024: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B028: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7B02C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7B030: ORR w3, wzr, #8            | W3 = 8(0x8);                            
            // 0x00C7B034: MOV x1, x20                | X1 = 1152921514333553744 (0x1000000243C1C450);//ML01
            // 0x00C7B038: MOV x4, x19                | X4 = X3;//m1                            
            // 0x00C7B03C: BL #0x2988d78              | ProtoBuf.ProtoWriter.WriteBytes(data:  0, offset:  1136772176, length:  0, writer:  8);
            ProtoBuf.ProtoWriter.WriteBytes(data:  0, offset:  1136772176, length:  0, writer:  8);
            // 0x00C7B040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B044: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7B048: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00C7B04C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00C7B050: MOV x3, x19                | X3 = X3;//m1                            
            // 0x00C7B054: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  2, writer:  1);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  2, writer:  1);
            // 0x00C7B058: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B05C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7B060: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x00C7B064: ORR w3, wzr, #8            | W3 = 8(0x8);                            
            // 0x00C7B068: MOV x1, x20                | X1 = 1152921514333553744 (0x1000000243C1C450);//ML01
            // 0x00C7B06C: MOV x4, x19                | X4 = X3;//m1                            
            // 0x00C7B070: BL #0x2988d78              | ProtoBuf.ProtoWriter.WriteBytes(data:  0, offset:  1136772176, length:  8, writer:  8);
            ProtoBuf.ProtoWriter.WriteBytes(data:  0, offset:  1136772176, length:  8, writer:  8);
            label_5:
            // 0x00C7B074: LDR x0, [x24]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7B078: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7B07C: TBZ w8, #0, #0xc7b08c      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00C7B080: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B084: CBNZ w8, #0xc7b08c         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00C7B088: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_9:
            // 0x00C7B08C: AND x1, x21, #0xffffffff   | X1 = (val_1.value & 4294967295);        
            int val_3 = val_1.value & 4294967295;
            // 0x00C7B090: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B094: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B098: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00C7B09C: BL #0x2977fd0              | ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  int val_3 = val_1.value & 4294967295);
            ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  val_3);
            // 0x00C7B0A0: SUB sp, x29, #0x40         | SP = (1152921514333553824 - 64) = 1152921514333553760 (0x1000000243C1C460);
            // 0x00C7B0A4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7B0A8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7B0AC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7B0B0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7B0B4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00C7B0B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7B0BC (13086908), len: 460  VirtAddr: 0x00C7B0BC RVA: 0x00C7B0BC token: 100689124 methodIndex: 53355 delegateWrapperIndex: 0 methodInvoker: 0
        public static System.Guid ReadGuid(ProtoBuf.ProtoReader source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            System.Guid val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00C7B0BC: STP x24, x23, [sp, #-0x40]! | stack[1152921514333673968] = ???;  stack[1152921514333673976] = ???;  //  dest_result_addr=1152921514333673968 |  dest_result_addr=1152921514333673976
            // 0x00C7B0C0: STP x22, x21, [sp, #0x10]  | stack[1152921514333673984] = ???;  stack[1152921514333673992] = ???;  //  dest_result_addr=1152921514333673984 |  dest_result_addr=1152921514333673992
            // 0x00C7B0C4: STP x20, x19, [sp, #0x20]  | stack[1152921514333674000] = ???;  stack[1152921514333674008] = ???;  //  dest_result_addr=1152921514333674000 |  dest_result_addr=1152921514333674008
            // 0x00C7B0C8: STP x29, x30, [sp, #0x30]  | stack[1152921514333674016] = ???;  stack[1152921514333674024] = ???;  //  dest_result_addr=1152921514333674016 |  dest_result_addr=1152921514333674024
            // 0x00C7B0CC: ADD x29, sp, #0x30         | X29 = (1152921514333673968 + 48) = 1152921514333674016 (0x1000000243C39A20);
            // 0x00C7B0D0: SUB sp, sp, #0x40          | SP = (1152921514333673968 - 64) = 1152921514333673904 (0x1000000243C399B0);
            // 0x00C7B0D4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7B0D8: LDRB w8, [x20, #0xf7f]     | W8 = (bool)static_value_03733F7F;       
            // 0x00C7B0DC: MOV x19, x1                | X19 = X1;//m1                           
            val_6 = X1;
            // 0x00C7B0E0: TBNZ w8, #0, #0xc7b0fc     | if (static_value_03733F7F == true) goto label_0;
            // 0x00C7B0E4: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x00C7B0E8: LDR x8, [x8, #0xdd0]       | X8 = 0x2B8F14C;                         
            // 0x00C7B0EC: LDR w0, [x8]               | W0 = 0x1315;                            
            // 0x00C7B0F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1315, ????);     
            // 0x00C7B0F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7B0F8: STRB w8, [x20, #0xf7f]     | static_value_03733F7F = true;            //  dest_result_addr=57884543
            label_0:
            // 0x00C7B0FC: ADRP x23, #0x367b000       | X23 = 57126912 (0x367B000);             
            // 0x00C7B100: LDR x23, [x23, #0x668]     | X23 = 1152921504884375552;              
            // 0x00C7B104: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7B108: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7B10C: TBZ w8, #0, #0xc7b11c      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7B110: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B114: CBNZ w8, #0xc7b11c         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7B118: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_2:
            // 0x00C7B11C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B124: MOV x1, x19                | X1 = X1;//m1                            
            // 0x00C7B128: BL #0x297e198              | X0 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            ProtoBuf.SubItemToken val_1 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            // 0x00C7B12C: MOV x22, x0                | X22 = val_1.value;//m1                  
            // 0x00C7B130: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00C7B134: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x00C7B138: B #0xc7b148                |  goto label_13;                         
            goto label_13;
            label_9:
            // 0x00C7B13C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B140: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7B144: BL #0x297dbac              | X1.SkipField();                         
            val_6.SkipField();
            label_13:
            // 0x00C7B148: CBNZ x19, #0xc7b150        | if (X1 != 0) goto label_4;              
            if(val_6 != 0)
            {
                goto label_4;
            }
            // 0x00C7B14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_4:
            // 0x00C7B150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B154: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7B158: BL #0x297da18              | X0 = X1.ReadFieldHeader();              
            int val_2 = val_6.ReadFieldHeader();
            // 0x00C7B15C: CMP w0, #0                 | STATE = COMPARE(val_2, 0x0)             
            // 0x00C7B160: B.LE #0xc7b1b8             | if (val_2 <= 0) goto label_5;           
            if(val_2 <= 0)
            {
                goto label_5;
            }
            // 0x00C7B164: CMP w0, #2                 | STATE = COMPARE(val_2, 0x2)             
            // 0x00C7B168: B.EQ #0xc7b180             | if (val_2 == 2) goto label_6;           
            if(val_2 == 2)
            {
                goto label_6;
            }
            // 0x00C7B16C: CMP w0, #1                 | STATE = COMPARE(val_2, 0x1)             
            // 0x00C7B170: B.EQ #0xc7b19c             | if (val_2 == 1) goto label_7;           
            if(val_2 == 1)
            {
                goto label_7;
            }
            // 0x00C7B174: CBNZ x19, #0xc7b13c        | if (X1 != 0) goto label_9;              
            if(val_6 != 0)
            {
                goto label_9;
            }
            // 0x00C7B178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00C7B17C: B #0xc7b13c                |  goto label_9;                          
            goto label_9;
            label_6:
            // 0x00C7B180: CBNZ x19, #0xc7b188        | if (X1 != 0) goto label_10;             
            if(val_6 != 0)
            {
                goto label_10;
            }
            // 0x00C7B184: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_10:
            // 0x00C7B188: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B18C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7B190: BL #0x297ece0              | X0 = X1.ReadUInt64();                   
            ulong val_3 = val_6.ReadUInt64();
            // 0x00C7B194: MOV x20, x0                | X20 = val_3;//m1                        
            // 0x00C7B198: B #0xc7b148                |  goto label_13;                         
            goto label_13;
            label_7:
            // 0x00C7B19C: CBNZ x19, #0xc7b1a4        | if (X1 != 0) goto label_12;             
            if(val_6 != 0)
            {
                goto label_12;
            }
            // 0x00C7B1A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_12:
            // 0x00C7B1A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B1A8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00C7B1AC: BL #0x297ece0              | X0 = X1.ReadUInt64();                   
            ulong val_4 = val_6.ReadUInt64();
            // 0x00C7B1B0: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00C7B1B4: B #0xc7b148                |  goto label_13;                         
            goto label_13;
            label_5:
            // 0x00C7B1B8: LDR x0, [x23]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7B1BC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7B1C0: TBZ w8, #0, #0xc7b1d0      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00C7B1C4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B1C8: CBNZ w8, #0xc7b1d0         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00C7B1CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_15:
            // 0x00C7B1D0: AND x1, x22, #0xffffffff   | X1 = (val_1.value & 4294967295);        
            int val_5 = val_1.value & 4294967295;
            // 0x00C7B1D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B1D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B1DC: MOV x2, x19                | X2 = X1;//m1                            
            // 0x00C7B1E0: BL #0x297e2fc              | ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  int val_5 = val_1.value & 4294967295);
            ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  val_5);
            // 0x00C7B1E4: ORR x8, x21, x20           | X8 = (0 | 0);                           
            var val_6 = 0 | 0;
            // 0x00C7B1E8: CBZ x8, #0xc7b240          | if ((0 | 0) == 0) goto label_16;        
            if(val_6 == 0)
            {
                goto label_16;
            }
            // 0x00C7B1EC: LSR x2, x21, #0x20         | X2 = (0 >> 32) = 0 (0x00000000);        
            // 0x00C7B1F0: LSR x8, x20, #0x20         | X8 = (0 >> 32) = 0 (0x00000000);        
            // 0x00C7B1F4: LSR x3, x21, #0x30         | X3 = (0 >> 48) = 0 (0x00000000);        
            // 0x00C7B1F8: UBFX x5, x20, #8, #0x18    | X5 = 0 (0x00000000);                    
            // 0x00C7B1FC: UBFX x6, x20, #0x10, #0x10 | X6 = 0 (0x00000000);                    
            // 0x00C7B200: UBFX x7, x20, #0x18, #8    | X7 = 0 (0x00000000);                    
            // 0x00C7B204: LSR x9, x20, #0x28         | X9 = (0 >> 40) = 0 (0x00000000);        
            // 0x00C7B208: LSR x10, x20, #0x30        | X10 = (0 >> 48) = 0 (0x00000000);       
            // 0x00C7B20C: LSR x11, x20, #0x38        | X11 = (0 >> 56) = 0 (0x00000000);       
            // 0x00C7B210: ADD x0, sp, #0x30          | X0 = (1152921514333673904 + 48) = 1152921514333673952 (0x1000000243C399E0);
            // 0x00C7B214: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x00C7B218: MOV w4, w20                | W4 = 0 (0x0);//ML01                     
            // 0x00C7B21C: STP xzr, xzr, [sp, #0x30]  | stack[1152921514333673952] = 0x0;  stack[1152921514333673960] = 0x0;  //  dest_result_addr=1152921514333673952 |  dest_result_addr=1152921514333673960
            // 0x00C7B220: STR xzr, [sp, #0x20]       | stack[1152921514333673936] = 0x0;        //  dest_result_addr=1152921514333673936
            // 0x00C7B224: STRB w11, [sp, #0x18]      | stack[1152921514333673928] = 0x0;        //  dest_result_addr=1152921514333673928
            // 0x00C7B228: STRB w10, [sp, #0x10]      | stack[1152921514333673920] = 0x0;        //  dest_result_addr=1152921514333673920
            // 0x00C7B22C: STRB w9, [sp, #8]          | stack[1152921514333673912] = 0x0;        //  dest_result_addr=1152921514333673912
            // 0x00C7B230: STRB w8, [sp]              | stack[1152921514333673904] = 0x0;        //  dest_result_addr=1152921514333673904
            // 0x00C7B234: BL #0x1c48d60              | X0 = label_System_Guid__ctor_GL01C48D60();
            // 0x00C7B238: LDP x0, x1, [sp, #0x30]    | X0 = 0x0; X1 = 0x0;                      //  | 
            val_7 = 0;
            val_8 = 0;
            // 0x00C7B23C: B #0xc7b270                |  goto label_17;                         
            goto label_17;
            label_16:
            // 0x00C7B240: ADRP x19, #0x35f2000       | X19 = 56565760 (0x35F2000);             
            // 0x00C7B244: LDR x19, [x19, #0x868]     | X19 = 1152921504654024704;              
            val_6 = 1152921504654024704;
            // 0x00C7B248: LDR x0, [x19]              | X0 = typeof(System.Guid);               
            val_9 = null;
            // 0x00C7B24C: LDRB w8, [x0, #0x10a]      | W8 = System.Guid.__il2cppRuntimeField_10A;
            // 0x00C7B250: TBZ w8, #0, #0xc7b264      | if (System.Guid.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00C7B254: LDR w8, [x0, #0xbc]        | W8 = System.Guid.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B258: CBNZ w8, #0xc7b264         | if (System.Guid.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00C7B25C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Guid), ????);
            // 0x00C7B260: LDR x0, [x19]              | X0 = typeof(System.Guid);               
            val_9 = null;
            label_19:
            // 0x00C7B264: LDR x8, [x0, #0xa0]        | X8 = System.Guid.__il2cppRuntimeField_static_fields;
            // 0x00C7B268: LDP x0, x1, [x8]           | X0 = System.Guid.Empty; X1 = System.Guid.Empty.__il2cppRuntimeField_8; //  | 
            val_7 = System.Guid.Empty;
            // 0x00C7B26C: STP x0, x1, [sp, #0x30]    | stack[1152921514333673952] = System.Guid.Empty;  stack[1152921514333673960] = System.Guid.Empty.__il2cppRuntimeField_8;  //  dest_result_addr=1152921514333673952 |  dest_result_addr=1152921514333673960
            label_17:
            // 0x00C7B270: SUB sp, x29, #0x30         | SP = (1152921514333674016 - 48) = 1152921514333673968 (0x1000000243C399F0);
            // 0x00C7B274: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7B278: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7B27C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7B280: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00C7B284: RET                        |  return new System.Guid() {_a = val_7, _b = val_7, _c = val_7, _d = System.Guid.Empty.__il2cppRuntimeField_8>>0&0xFF, _e = System.Guid.Empty.__il2cppRuntimeField_8>>8&0xFF, _f = System.Guid.Empty.__il2cppRuntimeField_8>>16&0xFF, _g = System.Guid.Empty.__il2cppRuntimeField_8>>24&0xFF, _h = System.Guid.Empty.__il2cppRuntimeField_8>>32&0xFF, _i = System.Guid.Empty.__il2cppRuntimeField_8>>40&0xFF, _j = System.Guid.Empty.__il2cppRuntimeField_8>>48&0xFF, _k = System.Guid.Empty.__il2cppRuntimeField_8>>
            return new System.Guid() {_a = val_7, _b = val_7, _c = val_7, _d = System.Guid.Empty.__il2cppRuntimeField_8>>0&0xFF, _e = System.Guid.Empty.__il2cppRuntimeField_8>>8&0xFF, _f = System.Guid.Empty.__il2cppRuntimeField_8>>16&0xFF, _g = System.Guid.Empty.__il2cppRuntimeField_8>>24&0xFF, _h = System.Guid.Empty.__il2cppRuntimeField_8>>32&0xFF, _i = System.Guid.Empty.__il2cppRuntimeField_8>>40&0xFF, _j = System.Guid.Empty.__il2cppRuntimeField_8>>48&0xFF, _k = System.Guid.Empty.__il2cppRuntimeField_8>>56&0x0};
            //  |  // // {name=val_0._a, type=System.Int32, size=4, nGRN=0 offset=0 }
            //  |  // // {name=val_0._b, type=System.Int16, size=2, nGRN=0 offset=4 }
            //  |  // // {name=val_0._c, type=System.Int16, size=2, nGRN=0 offset=6 }
            //  |  // // {name=val_0._d, type=System.Byte, size=1, nGRN=1 offset=0 }
            //  |  // // {name=val_0._e, type=System.Byte, size=1, nGRN=1 offset=1 }
            //  |  // // {name=val_0._f, type=System.Byte, size=1, nGRN=1 offset=2 }
            //  |  // // {name=val_0._g, type=System.Byte, size=1, nGRN=1 offset=3 }
            //  |  // // {name=val_0._h, type=System.Byte, size=1, nGRN=1 offset=4 }
            //  |  // // {name=val_0._i, type=System.Byte, size=1, nGRN=1 offset=5 }
            //  |  // // {name=val_0._j, type=System.Byte, size=1, nGRN=1 offset=6 }
            //  |  // // {name=val_0._k, type=System.Byte, size=1, nGRN=1 offset=7 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7B288 (13087368), len: 2112  VirtAddr: 0x00C7B288 RVA: 0x00C7B288 token: 100689125 methodIndex: 53356 delegateWrapperIndex: 0 methodInvoker: 0
        public static object ReadNetObject(object value, ProtoBuf.ProtoReader source, int key, System.Type type, ProtoBuf.BclHelpers.NetObjectOptions options)
        {
            //
            // Disasemble & Code
            //  | 
            var val_24;
            //  | 
            object val_51;
            //  | 
            int val_52;
            //  | 
            string val_53;
            //  | 
            var val_54;
            //  | 
            System.Type val_55;
            //  | 
            var val_56;
            //  | 
            string val_57;
            //  | 
            var val_58;
            //  | 
            int val_59;
            //  | 
            object val_60;
            //  | 
            var val_61;
            //  | 
            ProtoBuf.ProtoException val_62;
            //  | 
            string val_63;
            // 0x00C7B288: STP x28, x27, [sp, #-0x60]! | stack[1152921514333964016] = ???;  stack[1152921514333964024] = ???;  //  dest_result_addr=1152921514333964016 |  dest_result_addr=1152921514333964024
            // 0x00C7B28C: STP x26, x25, [sp, #0x10]  | stack[1152921514333964032] = ???;  stack[1152921514333964040] = ???;  //  dest_result_addr=1152921514333964032 |  dest_result_addr=1152921514333964040
            // 0x00C7B290: STP x24, x23, [sp, #0x20]  | stack[1152921514333964048] = ???;  stack[1152921514333964056] = ???;  //  dest_result_addr=1152921514333964048 |  dest_result_addr=1152921514333964056
            // 0x00C7B294: STP x22, x21, [sp, #0x30]  | stack[1152921514333964064] = ???;  stack[1152921514333964072] = ???;  //  dest_result_addr=1152921514333964064 |  dest_result_addr=1152921514333964072
            // 0x00C7B298: STP x20, x19, [sp, #0x40]  | stack[1152921514333964080] = ???;  stack[1152921514333964088] = ???;  //  dest_result_addr=1152921514333964080 |  dest_result_addr=1152921514333964088
            // 0x00C7B29C: STP x29, x30, [sp, #0x50]  | stack[1152921514333964096] = ???;  stack[1152921514333964104] = ???;  //  dest_result_addr=1152921514333964096 |  dest_result_addr=1152921514333964104
            // 0x00C7B2A0: ADD x29, sp, #0x50         | X29 = (1152921514333964016 + 80) = 1152921514333964096 (0x1000000243C80740);
            // 0x00C7B2A4: SUB sp, sp, #0x40          | SP = (1152921514333964016 - 64) = 1152921514333963952 (0x1000000243C806B0);
            // 0x00C7B2A8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7B2AC: LDRB w8, [x20, #0xf80]     | W8 = (bool)static_value_03733F80;       
            // 0x00C7B2B0: MOV w22, w5                | W22 = W5;//m1                           
            // 0x00C7B2B4: MOV w25, w3                | W25 = type;//m1                         
            // 0x00C7B2B8: MOV x19, x2                | X19 = key;//m1                          
            // 0x00C7B2BC: MOV x24, x1                | X24 = source;//m1                       
            // 0x00C7B2C0: STR x4, [sp, #0x30]        | stack[1152921514333964000] = options;    //  dest_result_addr=1152921514333964000
            // 0x00C7B2C4: TBNZ w8, #0, #0xc7b2e0     | if (static_value_03733F80 == true) goto label_0;
            // 0x00C7B2C8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x00C7B2CC: LDR x8, [x8, #0xe0]        | X8 = 0x2B8F150;                         
            // 0x00C7B2D0: LDR w0, [x8]               | W0 = 0x1316;                            
            // 0x00C7B2D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1316, ????);     
            // 0x00C7B2D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7B2DC: STRB w8, [x20, #0xf80]     | static_value_03733F80 = true;            //  dest_result_addr=57884544
            label_0:
            // 0x00C7B2E0: ADRP x21, #0x367b000       | X21 = 57126912 (0x367B000);             
            // 0x00C7B2E4: LDR x21, [x21, #0x668]     | X21 = 1152921504884375552;              
            // 0x00C7B2E8: LDR x0, [x21]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7B2EC: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7B2F0: TBZ w8, #0, #0xc7b300      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00C7B2F4: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B2F8: CBNZ w8, #0xc7b300         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00C7B2FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_2:
            // 0x00C7B300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B304: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B308: MOV x1, x19                | X1 = key;//m1                           
            // 0x00C7B30C: BL #0x297e198              | X0 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            ProtoBuf.SubItemToken val_1 = ProtoBuf.ProtoReader.StartSubItem(reader:  0);
            // 0x00C7B310: UBFX w8, w22, #3, #1       | W8 = (uint)((W5>>3) & 0x1);             
            // 0x00C7B314: STR x0, [sp, #0x10]        | stack[1152921514333963968] = val_1.value;  //  dest_result_addr=1152921514333963968
            // 0x00C7B318: STP w22, w8, [sp, #0x1c]   | stack[1152921514333963980] = W5;  stack[1152921514333963984] = (uint)((W5>>3) & 0x1);  //  dest_result_addr=1152921514333963980 |  dest_result_addr=1152921514333963984
            // 0x00C7B31C: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
            // 0x00C7B320: ADRP x27, #0x3620000       | X27 = 56754176 (0x3620000);             
            // 0x00C7B324: STR w8, [sp, #0x2c]        | stack[1152921514333963996] = 0x0;        //  dest_result_addr=1152921514333963996
            // 0x00C7B328: LDR x27, [x27, #0x340]     | X27 = 1152921504609562624;              
            // 0x00C7B32C: ADRP x22, #0x2a93000       | X22 = 44642304 (0x2A93000);             
            // 0x00C7B330: ADRP x23, #0x2a93000       | X23 = 44642304 (0x2A93000);             
            // 0x00C7B334: ADD x22, x22, #0x9e0       | X22 = (44642304 + 2528) = 44644832 (0x02A939E0);
            // 0x00C7B338: ADD x23, x23, #0x894       | X23 = (44642304 + 2196) = 44644500 (0x02A93894);
            // 0x00C7B33C: MOVN w28, #0               | W28 = 0 (0x0);//ML01                    
            // 0x00C7B340: B #0xc7b350                |  goto label_68;                         
            goto label_68;
            label_9:
            // 0x00C7B344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B348: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B34C: BL #0x297dbac              | key.SkipField();                        
            key.SkipField();
            label_68:
            // 0x00C7B350: CBNZ x19, #0xc7b358        | if (key != 0) goto label_4;             
            if(key != 0)
            {
                goto label_4;
            }
            // 0x00C7B354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? key, ????);        
            label_4:
            // 0x00C7B358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B35C: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B360: BL #0x297da18              | X0 = key.ReadFieldHeader();             
            int val_2 = key.ReadFieldHeader();
            // 0x00C7B364: CMP w0, #0                 | STATE = COMPARE(val_2, 0x0)             
            // 0x00C7B368: B.LE #0xc7b8e0             | if (val_2 <= 0) goto label_5;           
            if(val_2 <= 0)
            {
                goto label_5;
            }
            // 0x00C7B36C: SUB w8, w0, #1             | W8 = (val_2 - 1);                       
            int val_3 = val_2 - 1;
            // 0x00C7B370: CMP w8, #9                 | STATE = COMPARE((val_2 - 1), 0x9)       
            // 0x00C7B374: B.HI #0xc7b390             | if (val_3 > 9) goto label_6;            
            if(val_3 > 9)
            {
                goto label_6;
            }
            // 0x00C7B378: LDR w8, [x22, w8, sxtw #2] | W8 = 44644832 + ((val_2 - 1)) << 2;     
            // 0x00C7B37C: CMP w8, #0xd               | STATE = COMPARE(44644832 + ((val_2 - 1)) << 2, 0xD)
            // 0x00C7B380: B.HI #0xc7b920             | if (44644832 + ((val_2 - 1)) << 2 > 0xD) goto label_7;
            if((44644832 + ((val_2 - 1)) << 2) > 13)
            {
                goto label_7;
            }
            // 0x00C7B384: LDRSW x8, [x23, x8, lsl #2] | X8 = 44644500 + (44644832 + ((val_2 - 1)) << 2) << 2;
            var val_50 = 44644500 + (44644832 + ((val_2 - 1)) << 2) << 2;
            // 0x00C7B388: ADD x8, x8, x23            | X8 = (44644500 + (44644832 + ((val_2 - 1)) << 2) << 2 + 44644500);
            val_50 = val_50 + 44644500;
            // 0x00C7B38C: BR x8                      | goto (44644500 + (44644832 + ((val_2 - 1)) << 2) << 2 + 44644500);
            goto (44644500 + (44644832 + ((val_2 - 1)) << 2) << 2 + 44644500);
            label_6:
            // 0x00C7B390: CBNZ x19, #0xc7b344        | if (key != 0) goto label_9;             
            if(key != 0)
            {
                goto label_9;
            }
            // 0x00C7B394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00C7B398: B #0xc7b344                |  goto label_9;                          
            goto label_9;
            // 0x00C7B39C: CBZ x19, #0xc7b4f0         | if (key == 0) goto label_10;            
            if(key == 0)
            {
                goto label_10;
            }
            // 0x00C7B3A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B3A4: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B3A8: BL #0x297e4f8              | X0 = key.ReadInt32();                   
            int val_4 = key.ReadInt32();
            // 0x00C7B3AC: MOV w24, w0                | W24 = val_4;//m1                        
            val_51 = val_4;
            // 0x00C7B3B0: B #0xc7b508                |  goto label_11;                         
            goto label_11;
            // 0x00C7B3B4: CBNZ x19, #0xc7b3bc        | if (key != 0) goto label_12;            
            if(key != 0)
            {
                goto label_12;
            }
            // 0x00C7B3B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x00C7B3BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B3C0: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B3C4: BL #0x297e4f8              | X0 = key.ReadInt32();                   
            int val_5 = key.ReadInt32();
            // 0x00C7B3C8: MOV w28, w0                | W28 = val_5;//m1                        
            // 0x00C7B3CC: B #0xc7b350                |  goto label_68;                         
            goto label_68;
            // 0x00C7B3D0: CBZ x19, #0xc7b538         | if (key == 0) goto label_14;            
            if(key == 0)
            {
                goto label_14;
            }
            // 0x00C7B3D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B3D8: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B3DC: BL #0x297e4f8              | X0 = key.ReadInt32();                   
            int val_6 = key.ReadInt32();
            // 0x00C7B3E0: MOV w25, w0                | W25 = val_6;//m1                        
            val_52 = val_6;
            // 0x00C7B3E4: B #0xc7b550                |  goto label_15;                         
            goto label_15;
            // 0x00C7B3E8: CBNZ x19, #0xc7b3f0        | if (key != 0) goto label_16;            
            if(key != 0)
            {
                goto label_16;
            }
            // 0x00C7B3EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_16:
            // 0x00C7B3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B3F4: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B3F8: BL #0x297e4f8              | X0 = key.ReadInt32();                   
            int val_7 = key.ReadInt32();
            // 0x00C7B3FC: STR w0, [sp, #0x2c]        | stack[1152921514333963996] = val_7;      //  dest_result_addr=1152921514333963996
            // 0x00C7B400: B #0xc7b350                |  goto label_68;                         
            goto label_68;
            // 0x00C7B404: CBZ x19, #0xc7b5fc         | if (key == 0) goto label_18;            
            if(key == 0)
            {
                goto label_18;
            }
            // 0x00C7B408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B40C: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B410: BL #0x297f2fc              | X0 = key.ReadString();                  
            string val_8 = key.ReadString();
            // 0x00C7B414: MOV x25, x0                | X25 = val_8;//m1                        
            val_53 = val_8;
            // 0x00C7B418: B #0xc7b614                |  goto label_19;                         
            goto label_19;
            // 0x00C7B41C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00C7B420: STR w25, [sp, #0x28]       | stack[1152921514333963992] = val_8;      //  dest_result_addr=1152921514333963992
            // 0x00C7B424: LDR x0, [x27]              | X0 = typeof(System.Type);               
            // 0x00C7B428: LDR x25, [sp, #0x30]       | X25 = options;                          
            // 0x00C7B42C: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00C7B430: LDR x26, [x8]              | X26 = typeof(System.String);            
            // 0x00C7B434: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00C7B438: TBZ w8, #0, #0xc7b448      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00C7B43C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B440: CBNZ w8, #0xc7b448         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00C7B444: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_21:
            // 0x00C7B448: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B44C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B450: MOV x1, x26                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00C7B454: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00C7B458: MOV x26, x0                | X26 = val_9;//m1                        
            // 0x00C7B45C: CMP x25, x26               | STATE = COMPARE(options, val_9)         
            // 0x00C7B460: CSET w8, eq                | W8 = options == val_9 ? 1 : 0;          
            var val_10 = (options == val_9) ? 1 : 0;
            // 0x00C7B464: CMP x24, #0                | STATE = COMPARE(val_4, 0x0)             
            // 0x00C7B468: CSET w23, ne               | W23 = val_51 != 0 ? 1 : 0;              
            var val_11 = (val_51 != 0) ? 1 : 0;
            // 0x00C7B46C: ORR w8, w8, w23            | W8 = (options == val_9 ? 1 : 0 | val_51 != 0 ? 1 : 0);
            val_10 = val_10 | val_11;
            // 0x00C7B470: MOV x20, x24               | X20 = val_4;//m1                        
            // 0x00C7B474: CSET w9, eq                | W9 = val_51 == 0 ? 1 : 0;               
            var val_12 = (val_51 == 0) ? 1 : 0;
            // 0x00C7B478: CMP w8, #0                 | STATE = COMPARE((options == val_9 ? 1 : 0 | val_51 != 0 ? 1 : 0), 0x0)
            // 0x00C7B47C: LDR w8, [sp, #0x20]        | W8 = (uint)((W5>>3) & 0x1);             
            // 0x00C7B480: CSEL w22, w9, w8, ne       | W22 = val_10 != 0x0 ? val_51 == 0 ? 1 : 0 : (uint)((W5>>3) & 0x1);
            var val_13 = (val_10 != 0) ? (val_12) : ((uint)(W5 >> 3) & 1);
            // 0x00C7B484: CMP w22, #0                | STATE = COMPARE(val_10 != 0x0 ? val_51 == 0 ? 1 : 0 : (uint)((W5>>3) & 0x1), 0x0)
            // 0x00C7B488: CSET w8, ne                | W8 = val_13 != 0x0 ? 1 : 0;             
            var val_14 = (val_13 != 0) ? 1 : 0;
            // 0x00C7B48C: CMP w28, #0                | STATE = COMPARE(val_5, 0x0)             
            // 0x00C7B490: CSET w9, lt                | W9 = val_5 < 0 ? 1 : 0;                 
            var val_15 = (val_5 < 0) ? 1 : 0;
            // 0x00C7B494: MOV w24, w28               | W24 = val_5;//m1                        
            // 0x00C7B498: ORR w8, w9, w8             | W8 = (val_5 < 0 ? 1 : 0 | val_13 != 0x0 ? 1 : 0);
            val_14 = val_15 | val_14;
            // 0x00C7B49C: STR w8, [sp, #0x24]        | stack[1152921514333963988] = (val_5 < 0 ? 1 : 0 | val_13 != 0x0 ? 1 : 0);  //  dest_result_addr=1152921514333963988
            // 0x00C7B4A0: TBNZ w8, #0, #0xc7b6ec     | if (((val_5 < 0 ? 1 : 0 | val_13 != 0x0 ? 1 : 0) & 0x1) != 0) goto label_42;
            if((val_14 & 1) != 0)
            {
                goto label_42;
            }
            // 0x00C7B4A4: CBNZ x19, #0xc7b4ac        | if (key != 0) goto label_23;            
            if(key != 0)
            {
                goto label_23;
            }
            // 0x00C7B4A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_23:
            // 0x00C7B4AC: CBZ x20, #0xc7b694         | if (val_4 == 0) goto label_24;          
            if(val_51 == 0)
            {
                goto label_24;
            }
            // 0x00C7B4B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B4B4: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B4B8: MOV x28, x27               | X28 = 57977376 (0x374AA20);//ML01       
            // 0x00C7B4BC: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_16 = key.NetCache;
            // 0x00C7B4C0: MOV x27, x0                | X27 = val_16;//m1                       
            // 0x00C7B4C4: CBNZ x27, #0xc7b4cc        | if (val_16 != null) goto label_25;      
            if(val_16 != null)
            {
                goto label_25;
            }
            // 0x00C7B4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_25:
            // 0x00C7B4CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B4D0: MOV x0, x27                | X0 = val_16;//m1                        
            // 0x00C7B4D4: MOV w1, w24                | W1 = val_5;//m1                         
            // 0x00C7B4D8: MOV x2, x20                | X2 = val_4;//m1                         
            // 0x00C7B4DC: BL #0x2984044              | val_16.SetKeyedObject(key:  val_5, value:  val_51);
            val_16.SetKeyedObject(key:  val_5, value:  val_51);
            // 0x00C7B4E0: ADRP x21, #0x367b000       | X21 = 57126912 (0x367B000);             
            // 0x00C7B4E4: LDR x21, [x21, #0x668]     | X21 = 1152921504884375552;              
            // 0x00C7B4E8: MOV x27, x28               | X27 = 57977376 (0x374AA20);//ML01       
            val_54 = 1152921504609562624;
            // 0x00C7B4EC: B #0xc7b6a4                |  goto label_26;                         
            goto label_26;
            label_10:
            // 0x00C7B4F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x00C7B4F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B4F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B4FC: BL #0x297e4f8              | X0 = 0.ReadInt32();                     
            int val_17 = 0.ReadInt32();
            // 0x00C7B500: MOV w24, w0                | W24 = val_17;//m1                       
            val_51 = val_17;
            // 0x00C7B504: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_11:
            // 0x00C7B508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B50C: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B510: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_18 = key.NetCache;
            // 0x00C7B514: MOV x26, x0                | X26 = val_18;//m1                       
            // 0x00C7B518: CBNZ x26, #0xc7b520        | if (val_18 != null) goto label_27;      
            if(val_18 != null)
            {
                goto label_27;
            }
            // 0x00C7B51C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_27:
            // 0x00C7B520: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B524: MOV x0, x26                | X0 = val_18;//m1                        
            // 0x00C7B528: MOV w1, w24                | W1 = val_17;//m1                        
            // 0x00C7B52C: BL #0x2983f28              | X0 = val_18.GetKeyedObject(key:  val_51);
            object val_19 = val_18.GetKeyedObject(key:  val_51);
            // 0x00C7B530: MOV x24, x0                | X24 = val_19;//m1                       
            // 0x00C7B534: B #0xc7b350                |  goto label_68;                         
            goto label_68;
            label_14:
            // 0x00C7B538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x00C7B53C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B540: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B544: BL #0x297e4f8              | X0 = 0.ReadInt32();                     
            int val_20 = 0.ReadInt32();
            // 0x00C7B548: MOV w25, w0                | W25 = val_20;//m1                       
            val_52 = val_20;
            // 0x00C7B54C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_15:
            // 0x00C7B550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B554: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B558: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_21 = key.NetCache;
            // 0x00C7B55C: MOV x26, x0                | X26 = val_21;//m1                       
            // 0x00C7B560: CBNZ x26, #0xc7b568        | if (val_21 != null) goto label_29;      
            if(val_21 != null)
            {
                goto label_29;
            }
            // 0x00C7B564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_29:
            // 0x00C7B568: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B56C: MOV x0, x26                | X0 = val_21;//m1                        
            // 0x00C7B570: MOV w1, w25                | W1 = val_20;//m1                        
            // 0x00C7B574: BL #0x2983f28              | X0 = val_21.GetKeyedObject(key:  val_52);
            object val_22 = val_21.GetKeyedObject(key:  val_52);
            // 0x00C7B578: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_55 = 0;
            // 0x00C7B57C: CBZ x0, #0xc7b5d8          | if (val_22 == null) goto label_32;      
            if(val_22 == null)
            {
                goto label_32;
            }
            // 0x00C7B580: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x00C7B584: LDR x1, [x27]              | X1 = typeof(System.Type);               
            // 0x00C7B588: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7B58C: LDRB w9, [x1, #0x104]      | W9 = System.Type.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00C7B590: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, System.Type.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00C7B594: B.LO #0xc7b5b0             | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < System.Type.__il2cppRuntimeField_typeHierarchyDepth) goto label_31;
            // 0x00C7B598: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x00C7B59C: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHiera
            // 0x00C7B5A0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00C7B5A4: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Type))
            // 0x00C7B5A8: MOV x9, x0                 | X9 = val_22;//m1                        
            val_55 = val_22;
            // 0x00C7B5AC: B.EQ #0xc7b5d8             | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (System.Type.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_32;
            label_31:
            // 0x00C7B5B0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00C7B5B4: ADD x8, sp, #0x38          | X8 = (1152921514333963952 + 56) = 1152921514333964008 (0x1000000243C806E8);
            // 0x00C7B5B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00C7B5BC: LDR x0, [sp, #0x38]        | X0 = val_24;                             //  find_add[1152921514333952112]
            // 0x00C7B5C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
            // 0x00C7B5C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B5C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x00C7B5CC: ADD x0, sp, #0x38          | X0 = (1152921514333963952 + 56) = 1152921514333964008 (0x1000000243C806E8);
            // 0x00C7B5D0: BL #0x299a140              | 
            // 0x00C7B5D4: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_55 = 0;
            label_32:
            // 0x00C7B5D8: STR x9, [sp, #0x30]        | stack[1152921514333964000] = 0x0;        //  dest_result_addr=1152921514333964000
            System.Type val_25 = val_55;
            // 0x00C7B5DC: CBNZ x19, #0xc7b5e4        | if (key != 0) goto label_33;            
            if(key != 0)
            {
                goto label_33;
            }
            // 0x00C7B5E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000243C806E8, ????);
            label_33:
            // 0x00C7B5E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B5E8: ADD x1, sp, #0x30          | X1 = (1152921514333963952 + 48) = 1152921514333964000 (0x1000000243C806E0);
            // 0x00C7B5EC: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B5F0: BL #0x2987a08              | X0 = key.GetTypeKey(type: ref  System.Type val_25 = val_55);
            int val_26 = key.GetTypeKey(type: ref  val_25);
            // 0x00C7B5F4: MOV w25, w0                | W25 = val_26;//m1                       
            // 0x00C7B5F8: B #0xc7b350                |  goto label_68;                         
            goto label_68;
            label_18:
            // 0x00C7B5FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            // 0x00C7B600: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B608: BL #0x297f2fc              | X0 = 0.ReadString();                    
            string val_27 = 0.ReadString();
            // 0x00C7B60C: MOV x25, x0                | X25 = val_27;//m1                       
            val_53 = val_27;
            // 0x00C7B610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_19:
            // 0x00C7B614: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B618: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B61C: MOV x1, x25                | X1 = val_27;//m1                        
            // 0x00C7B620: BL #0x2987a40              | X0 = key.DeserializeType(value:  val_53);
            System.Type val_28 = key.DeserializeType(value:  val_53);
            // 0x00C7B624: MOV x26, x0                | X26 = val_28;//m1                       
            // 0x00C7B628: STR x26, [sp, #0x30]       | stack[1152921514333964000] = val_28;     //  dest_result_addr=1152921514333964000
            System.Type val_30 = val_28;
            // 0x00C7B62C: CBZ x26, #0xc7b958         | if (val_28 == null) goto label_35;      
            if(val_28 == null)
            {
                goto label_35;
            }
            // 0x00C7B630: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x00C7B634: LDR x0, [x27]              | X0 = typeof(System.Type);               
            // 0x00C7B638: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x00C7B63C: LDR x25, [x8]              | X25 = typeof(System.String);            
            // 0x00C7B640: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00C7B644: TBZ w8, #0, #0xc7b654      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x00C7B648: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B64C: CBNZ w8, #0xc7b654         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x00C7B650: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_37:
            // 0x00C7B654: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B65C: MOV x1, x25                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00C7B660: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_29 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00C7B664: MOVN w25, #0               | W25 = 0 (0x0);//ML01                    
            // 0x00C7B668: CMP x26, x0                | STATE = COMPARE(val_28, val_29)         
            // 0x00C7B66C: B.EQ #0xc7b350             | if (val_28 == val_29) goto label_68;    
            if(val_28 == val_29)
            {
                goto label_68;
            }
            // 0x00C7B670: CBNZ x19, #0xc7b678        | if (key != 0) goto label_39;            
            if(key != 0)
            {
                goto label_39;
            }
            // 0x00C7B674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_39:
            // 0x00C7B678: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B67C: ADD x1, sp, #0x30          | X1 = (1152921514333963952 + 48) = 1152921514333964000 (0x1000000243C806E0);
            // 0x00C7B680: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B684: BL #0x2987a08              | X0 = key.GetTypeKey(type: ref  System.Type val_30 = val_28);
            int val_31 = key.GetTypeKey(type: ref  val_30);
            // 0x00C7B688: MOV w25, w0                | W25 = val_31;//m1                       
            // 0x00C7B68C: TBZ w25, #0x1f, #0xc7b350  | if ((val_31 & 0x80000000) == 0) goto label_68;
            if((val_31 & 2147483648) == 0)
            {
                goto label_68;
            }
            // 0x00C7B690: B #0xc7ba28                |  goto label_41;                         
            goto label_41;
            label_24:
            // 0x00C7B694: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B698: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B69C: MOV w1, w24                | W1 = val_5;//m1                         
            // 0x00C7B6A0: BL #0x2987bf0              | key.TrapNextObject(newObjectKey:  val_5);
            key.TrapNextObject(newObjectKey:  val_5);
            label_26:
            // 0x00C7B6A4: LDR w8, [sp, #0x2c]        | W8 = val_7;                             
            // 0x00C7B6A8: TBNZ w8, #0x1f, #0xc7b6ec  | if ((val_7 & 0x80000000) != 0) goto label_42;
            if((val_7 & 2147483648) != 0)
            {
                goto label_42;
            }
            // 0x00C7B6AC: CBNZ x19, #0xc7b6b4        | if (key != 0) goto label_43;            
            if(key != 0)
            {
                goto label_43;
            }
            // 0x00C7B6B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? key, ????);        
            label_43:
            // 0x00C7B6B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B6B8: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B6BC: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_32 = key.NetCache;
            // 0x00C7B6C0: LDR x27, [sp, #0x30]       | X27 = val_28;                           
            // 0x00C7B6C4: MOV x28, x0                | X28 = val_32;//m1                       
            // 0x00C7B6C8: CBNZ x28, #0xc7b6d0        | if (val_32 != null) goto label_44;      
            if(val_32 != null)
            {
                goto label_44;
            }
            // 0x00C7B6CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_44:
            // 0x00C7B6D0: LDR w1, [sp, #0x2c]        | W1 = val_7;                             
            // 0x00C7B6D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B6D8: MOV x0, x28                | X0 = val_32;//m1                        
            // 0x00C7B6DC: MOV x2, x27                | X2 = val_28;//m1                        
            // 0x00C7B6E0: BL #0x2984044              | val_32.SetKeyedObject(key:  val_7, value:  val_30);
            val_32.SetKeyedObject(key:  val_7, value:  val_30);
            // 0x00C7B6E4: ADRP x27, #0x3620000       | X27 = 56754176 (0x3620000);             
            // 0x00C7B6E8: LDR x27, [x27, #0x340]     | X27 = 1152921504609562624;              
            val_54 = 1152921504609562624;
            label_42:
            // 0x00C7B6EC: CMP x25, x26               | STATE = COMPARE(options, val_9)         
            // 0x00C7B6F0: B.EQ #0xc7b734             | if (options == val_9) goto label_45;    
            if(options == val_9)
            {
                goto label_45;
            }
            // 0x00C7B6F4: LDR x0, [x21]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7B6F8: LDR x26, [sp, #0x30]       | X26 = val_28;                           
            // 0x00C7B6FC: LDR w25, [sp, #0x28]       | W25 = val_8;                            
            val_57 = val_53;
            // 0x00C7B700: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7B704: TBZ w8, #0, #0xc7b714      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x00C7B708: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B70C: CBNZ w8, #0xc7b714         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x00C7B710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_47:
            // 0x00C7B714: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B718: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00C7B71C: MOV x1, x20                | X1 = val_4;//m1                         
            // 0x00C7B720: MOV w2, w25                | W2 = val_8;//m1                         
            // 0x00C7B724: MOV x3, x19                | X3 = key;//m1                           
            // 0x00C7B728: MOV x4, x26                | X4 = val_28;//m1                        
            // 0x00C7B72C: BL #0x29866cc              | X0 = ProtoBuf.ProtoReader.ReadTypedObject(value:  0, key:  val_51, reader:  val_57, type:  key);
            object val_33 = ProtoBuf.ProtoReader.ReadTypedObject(value:  0, key:  val_51, reader:  val_57, type:  key);
            // 0x00C7B730: B #0xc7b74c                |  goto label_48;                         
            goto label_48;
            label_45:
            // 0x00C7B734: LDR w25, [sp, #0x28]       | W25 = val_8;                            
            val_57 = val_53;
            // 0x00C7B738: CBNZ x19, #0xc7b740        | if (key != 0) goto label_49;            
            if(key != 0)
            {
                goto label_49;
            }
            // 0x00C7B73C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_49:
            // 0x00C7B740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B744: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B748: BL #0x297f2fc              | X0 = key.ReadString();                  
            string val_34 = key.ReadString();
            label_48:
            // 0x00C7B74C: MOV x26, x0                | X26 = val_34;//m1                       
            // 0x00C7B750: MOV w28, w24               | W28 = val_5;//m1                        
            val_59 = val_5;
            // 0x00C7B754: TBNZ w28, #0x1f, #0xc7b838 | if ((val_5 & 0x80000000) != 0) goto label_50;
            if((val_59 & 2147483648) != 0)
            {
                goto label_50;
            }
            // 0x00C7B758: CMP w22, #0                | STATE = COMPARE(val_10 != 0x0 ? val_51 == 0 ? 1 : 0 : (uint)((W5>>3) & 0x1), 0x0)
            // 0x00C7B75C: CSET w8, ne                | W8 = val_13 != 0x0 ? 1 : 0;             
            var val_35 = (val_13 != 0) ? 1 : 0;
            // 0x00C7B760: MOV x24, x20               | X24 = val_4;//m1                        
            val_60 = val_51;
            // 0x00C7B764: ORR w8, w8, w23            | W8 = (val_13 != 0x0 ? 1 : 0 | val_51 != 0 ? 1 : 0);
            val_35 = val_35 | val_11;
            // 0x00C7B768: TBNZ w8, #0, #0xc7b7a0     | if (((val_13 != 0x0 ? 1 : 0 | val_51 != 0 ? 1 : 0) & 0x1) != 0) goto label_51;
            if((val_35 & 1) != 0)
            {
                goto label_51;
            }
            // 0x00C7B76C: CBNZ x19, #0xc7b774        | if (key != 0) goto label_52;            
            if(key != 0)
            {
                goto label_52;
            }
            // 0x00C7B770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_52:
            // 0x00C7B774: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B778: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B77C: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_36 = key.NetCache;
            // 0x00C7B780: MOV x24, x0                | X24 = val_36;//m1                       
            // 0x00C7B784: CBNZ x24, #0xc7b78c        | if (val_36 != null) goto label_53;      
            if(val_36 != null)
            {
                goto label_53;
            }
            // 0x00C7B788: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_53:
            // 0x00C7B78C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B790: MOV x0, x24                | X0 = val_36;//m1                        
            // 0x00C7B794: MOV w1, w28                | W1 = val_5;//m1                         
            // 0x00C7B798: BL #0x2983f28              | X0 = val_36.GetKeyedObject(key:  val_59);
            object val_37 = val_36.GetKeyedObject(key:  val_59);
            // 0x00C7B79C: MOV x24, x0                | X24 = val_37;//m1                       
            val_60 = val_37;
            label_51:
            // 0x00C7B7A0: ADRP x23, #0x2a93000       | X23 = 44642304 (0x2A93000);             
            // 0x00C7B7A4: ADD x23, x23, #0x894       | X23 = (44642304 + 2196) = 44644500 (0x02A93894);
            // 0x00C7B7A8: CBZ w22, #0xc7b850         | if (val_10 != 0x0 ? val_51 == 0 ? 1 : 0 : (uint)((W5>>3) & 0x1) == 0) goto label_61;
            if(val_13 == 0)
            {
                goto label_61;
            }
            // 0x00C7B7AC: MOV w20, w25               | W20 = val_8;//m1                        
            // 0x00C7B7B0: MOV x25, x27               | X25 = 57977376 (0x374AA20);//ML01       
            // 0x00C7B7B4: CBNZ x19, #0xc7b7bc        | if (key != 0) goto label_55;            
            if(key != 0)
            {
                goto label_55;
            }
            // 0x00C7B7B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_55:
            // 0x00C7B7BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B7C0: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B7C4: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_38 = key.NetCache;
            // 0x00C7B7C8: MOV x27, x0                | X27 = val_38;//m1                       
            // 0x00C7B7CC: CBNZ x27, #0xc7b7d4        | if (val_38 != null) goto label_56;      
            if(val_38 != null)
            {
                goto label_56;
            }
            // 0x00C7B7D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_56:
            // 0x00C7B7D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B7D8: MOV x0, x27                | X0 = val_38;//m1                        
            // 0x00C7B7DC: MOV w1, w28                | W1 = val_5;//m1                         
            // 0x00C7B7E0: MOV x2, x26                | X2 = val_34;//m1                        
            // 0x00C7B7E4: BL #0x2984044              | val_38.SetKeyedObject(key:  val_59, value:  val_34);
            val_38.SetKeyedObject(key:  val_59, value:  val_34);
            // 0x00C7B7E8: LDR w8, [sp, #0x2c]        | W8 = val_7;                             
            // 0x00C7B7EC: TBNZ w8, #0x1f, #0xc7b848  | if ((val_7 & 0x80000000) != 0) goto label_57;
            if((val_7 & 2147483648) != 0)
            {
                goto label_57;
            }
            // 0x00C7B7F0: MOV w22, w28               | W22 = val_5;//m1                        
            // 0x00C7B7F4: CBNZ x19, #0xc7b7fc        | if (key != 0) goto label_58;            
            if(key != 0)
            {
                goto label_58;
            }
            // 0x00C7B7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_58:
            // 0x00C7B7FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B800: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B804: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_39 = key.NetCache;
            // 0x00C7B808: LDR x27, [sp, #0x30]       | X27 = val_28;                           
            // 0x00C7B80C: MOV x28, x0                | X28 = val_39;//m1                       
            // 0x00C7B810: CBNZ x28, #0xc7b818        | if (val_39 != null) goto label_59;      
            if(val_39 != null)
            {
                goto label_59;
            }
            // 0x00C7B814: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_59:
            // 0x00C7B818: LDR w1, [sp, #0x2c]        | W1 = val_7;                             
            // 0x00C7B81C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B820: MOV x0, x28                | X0 = val_39;//m1                        
            // 0x00C7B824: MOV x2, x27                | X2 = val_28;//m1                        
            // 0x00C7B828: BL #0x2984044              | val_39.SetKeyedObject(key:  val_7, value:  val_30);
            val_39.SetKeyedObject(key:  val_7, value:  val_30);
            // 0x00C7B82C: MOV x27, x25               | X27 = 57977376 (0x374AA20);//ML01       
            val_54 = val_54;
            // 0x00C7B830: MOV w28, w22               | W28 = val_5;//m1                        
            val_59 = val_59;
            // 0x00C7B834: B #0xc7b84c                |  goto label_60;                         
            goto label_60;
            label_50:
            // 0x00C7B838: ADRP x23, #0x2a93000       | X23 = 44642304 (0x2A93000);             
            // 0x00C7B83C: ADD x23, x23, #0x894       | X23 = (44642304 + 2196) = 44644500 (0x02A93894);
            // 0x00C7B840: MOV x24, x20               | X24 = val_4;//m1                        
            val_60 = val_51;
            // 0x00C7B844: B #0xc7b850                |  goto label_61;                         
            goto label_61;
            label_57:
            // 0x00C7B848: MOV x27, x25               | X27 = 57977376 (0x374AA20);//ML01       
            val_54 = val_54;
            label_60:
            // 0x00C7B84C: MOV w25, w20               | W25 = val_8;//m1                        
            val_57 = val_57;
            label_61:
            // 0x00C7B850: LDR w8, [sp, #0x24]        | W8 = (val_5 < 0 ? 1 : 0 | val_13 != 0x0 ? 1 : 0);
            // 0x00C7B854: ADRP x22, #0x2a93000       | X22 = 44642304 (0x2A93000);             
            // 0x00C7B858: ADD x22, x22, #0x9e0       | X22 = (44642304 + 2528) = 44644832 (0x02A939E0);
            // 0x00C7B85C: TBNZ w8, #0, #0xc7b87c     | if (((val_5 < 0 ? 1 : 0 | val_13 != 0x0 ? 1 : 0) & 0x1) != 0) goto label_62;
            if((val_14 & 1) != 0)
            {
                goto label_62;
            }
            // 0x00C7B860: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B864: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B868: MOV x1, x24                | X1 = val_37;//m1                        
            // 0x00C7B86C: MOV x2, x26                | X2 = val_34;//m1                        
            // 0x00C7B870: BL #0x1708e5c              | X0 = System.Object.ReferenceEquals(objA:  0, objB:  val_60);
            bool val_40 = System.Object.ReferenceEquals(objA:  0, objB:  val_60);
            // 0x00C7B874: AND w8, w0, #1             | W8 = (val_40 & 1);                      
            bool val_41 = val_40;
            // 0x00C7B878: TBZ w8, #0, #0xc7b9e8      | if ((val_40 & 1) == false) goto label_63;
            if(val_41 == false)
            {
                goto label_63;
            }
            label_62:
            // 0x00C7B87C: LDR w8, [sp, #0x2c]        | W8 = val_7;                             
            // 0x00C7B880: MOV x24, x26               | X24 = val_34;//m1                       
            // 0x00C7B884: TBNZ w8, #0x1f, #0xc7b350  | if ((val_7 & 0x80000000) != 0) goto label_68;
            if((val_7 & 2147483648) != 0)
            {
                goto label_68;
            }
            // 0x00C7B888: MOV x24, x26               | X24 = val_34;//m1                       
            // 0x00C7B88C: TBZ w28, #0x1f, #0xc7b350  | if ((val_5 & 0x80000000) == 0) goto label_68;
            if((val_59 & 2147483648) == 0)
            {
                goto label_68;
            }
            // 0x00C7B890: MOV w20, w25               | W20 = val_8;//m1                        
            // 0x00C7B894: MOV x25, x27               | X25 = 57977376 (0x374AA20);//ML01       
            // 0x00C7B898: CBNZ x19, #0xc7b8a0        | if (key != 0) goto label_66;            
            if(key != 0)
            {
                goto label_66;
            }
            // 0x00C7B89C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_40, ????);     
            label_66:
            // 0x00C7B8A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7B8A4: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7B8A8: BL #0x2987a38              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_42 = key.NetCache;
            // 0x00C7B8AC: LDR x24, [sp, #0x30]       | X24 = val_28;                           
            // 0x00C7B8B0: MOV x27, x0                | X27 = val_42;//m1                       
            // 0x00C7B8B4: CBNZ x27, #0xc7b8bc        | if (val_42 != null) goto label_67;      
            if(val_42 != null)
            {
                goto label_67;
            }
            // 0x00C7B8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_67:
            // 0x00C7B8BC: LDR w1, [sp, #0x2c]        | W1 = val_7;                             
            // 0x00C7B8C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B8C4: MOV x0, x27                | X0 = val_42;//m1                        
            // 0x00C7B8C8: MOV x2, x24                | X2 = val_28;//m1                        
            // 0x00C7B8CC: BL #0x2984044              | val_42.SetKeyedObject(key:  val_7, value:  val_30);
            val_42.SetKeyedObject(key:  val_7, value:  val_30);
            // 0x00C7B8D0: MOV x24, x26               | X24 = val_34;//m1                       
            // 0x00C7B8D4: MOV x27, x25               | X27 = 57977376 (0x374AA20);//ML01       
            // 0x00C7B8D8: MOV w25, w20               | W25 = val_8;//m1                        
            // 0x00C7B8DC: B #0xc7b350                |  goto label_68;                         
            goto label_68;
            label_5:
            // 0x00C7B8E0: LDR w8, [sp, #0x1c]        | W8 = W5;                                
            var val_51 = W5;
            // 0x00C7B8E4: AND w8, w8, #1             | W8 = (W5 & 1);                          
            val_51 = val_51 & 1;
            // 0x00C7B8E8: TBNZ w8, #0, #0xc7b8f0     | if (((W5 & 1) & 0x1) != 0) goto label_69;
            if((val_51 & 1) != 0)
            {
                goto label_69;
            }
            // 0x00C7B8EC: TBZ w28, #0x1f, #0xc7b9cc  | if ((0x0 & 0x80000000) == 0) goto label_70;
            if((0 & 2147483648) == 0)
            {
                goto label_70;
            }
            label_69:
            // 0x00C7B8F0: LDR x0, [x21]              | X0 = typeof(ProtoBuf.ProtoReader);      
            // 0x00C7B8F4: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_10A;
            // 0x00C7B8F8: TBZ w8, #0, #0xc7b908      | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_has_cctor == 0) goto label_72;
            // 0x00C7B8FC: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B900: CBNZ w8, #0xc7b908         | if (ProtoBuf.ProtoReader.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x00C7B904: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoReader), ????);
            label_72:
            // 0x00C7B908: LDR x8, [sp, #0x10]        | X8 = val_1.value;                       
            // 0x00C7B90C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B910: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7B914: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7B918: AND x1, x8, #0xffffffff    | X1 = (val_1.value & 4294967295);        
            int val_43 = val_1.value & 4294967295;
            // 0x00C7B91C: BL #0x297e2fc              | ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  int val_43 = val_1.value & 4294967295);
            ProtoBuf.ProtoReader.EndSubItem(token:  new ProtoBuf.SubItemToken(), reader:  val_43);
            label_7:
            // 0x00C7B920: MOV x0, x24                | X0 = source;//m1                        
            // 0x00C7B924: SUB sp, x29, #0x50         | SP = (1152921514333964096 - 80) = 1152921514333964016 (0x1000000243C806F0);
            // 0x00C7B928: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7B92C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7B930: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7B934: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7B938: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00C7B93C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00C7B940: RET                        |  return (System.Object)source;          
            return (object)source;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            // 0x00C7B944: MOV x19, x0                | X19 = source;//m1                       
            // 0x00C7B948: ADD x0, sp, #0x38          | X0 = (1152921514333964112 + 56) = 1152921514333964168 (0x1000000243C80788);
            // 0x00C7B94C: BL #0x299a140              | 
            // 0x00C7B950: MOV x0, x19                | X0 = source;//m1                        
            // 0x00C7B954: BL #0x980800               | X0 = sub_980800( ?? source, ????);      
            label_35:
            // 0x00C7B958: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C7B95C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00C7B960: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00C7B964: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00C7B968: TBZ w8, #0, #0xc7b978      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_74;
            // 0x00C7B96C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C7B970: CBNZ w8, #0xc7b978         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_74;
            // 0x00C7B974: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_74:
            // 0x00C7B978: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00C7B97C: ADRP x9, #0x35c3000        | X9 = 56373248 (0x35C3000);              
            // 0x00C7B980: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921514333868240)("Unable to resolve type: ");
            // 0x00C7B984: LDR x9, [x9, #0x910]       | X9 = (string**)(1152921514333868368)(" (you can use the TypeModel.DynamicTypeFormatting event to provide a custom mapping)");
            // 0x00C7B988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7B98C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7B990: LDR x1, [x8]               | X1 = "Unable to resolve type: ";        
            // 0x00C7B994: LDR x3, [x9]               | X3 = " (you can use the TypeModel.DynamicTypeFormatting event to provide a custom mapping)";
            // 0x00C7B998: MOV x2, x25                | X2 = X25;//m1                           
            // 0x00C7B99C: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "Unable to resolve type: ", str2:  ???);
            string val_44 = System.String.Concat(str0:  0, str1:  "Unable to resolve type: ", str2:  ???);
            // 0x00C7B9A0: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00C7B9A4: LDR x8, [x8, #0x720]       | X8 = 1152921504884002816;               
            // 0x00C7B9A8: MOV x19, x0                | X19 = val_44;//m1                       
            // 0x00C7B9AC: LDR x8, [x8]               | X8 = typeof(ProtoBuf.ProtoException);   
            // 0x00C7B9B0: MOV x0, x8                 | X0 = 1152921504884002816 (0x1000000010851000);//ML01
            ProtoBuf.ProtoException val_45 = null;
            // 0x00C7B9B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C7B9B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7B9BC: MOV x1, x19                | X1 = val_44;//m1                        
            // 0x00C7B9C0: MOV x20, x0                | X20 = 1152921504884002816 (0x1000000010851000);//ML01
            val_61 = val_45;
            // 0x00C7B9C4: BL #0x2980224              | .ctor(message:  val_44);                
            val_45 = new ProtoBuf.ProtoException(message:  val_44);
            // 0x00C7B9C8: B #0xc7bab0                |  goto label_75;                         
            goto label_75;
            label_70:
            // 0x00C7B9CC: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00C7B9D0: LDR x8, [x8, #0x720]       | X8 = 1152921504884002816;               
            // 0x00C7B9D4: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoException);   
            val_62 = null;
            // 0x00C7B9D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C7B9DC: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00C7B9E0: LDR x8, [x8, #0xb38]       | X8 = (string**)(1152921514333872704)("Object key in input stream, but reference-tracking was not expected");
            val_63 = "Object key in input stream, but reference-tracking was not expected";
            // 0x00C7B9E4: B #0xc7ba00                |  goto label_76;                         
            goto label_76;
            label_63:
            // 0x00C7B9E8: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00C7B9EC: LDR x8, [x8, #0x720]       | X8 = 1152921504884002816;               
            // 0x00C7B9F0: LDR x0, [x8]               | X0 = typeof(ProtoBuf.ProtoException);   
            val_62 = null;
            // 0x00C7B9F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C7B9F8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00C7B9FC: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921514333872912)("A reference-tracked object changed reference during deserialization");
            val_63 = "A reference-tracked object changed reference during deserialization";
            label_76:
            // 0x00C7BA00: LDR x1, [x8]               | X1 = "A reference-tracked object changed reference during deserialization";
            // 0x00C7BA04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7BA08: MOV x19, x0                | X19 = 1152921504884002816 (0x1000000010851000);//ML01
            // 0x00C7BA0C: BL #0x2980224              | .ctor(message:  val_63 = "A reference-tracked object changed reference during deserialization");
            val_62 = new ProtoBuf.ProtoException(message:  val_63);
            // 0x00C7BA10: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00C7BA14: LDR x8, [x8, #0xaf8]       | X8 = 1152921514333873120;               
            // 0x00C7BA18: MOV x0, x19                | X0 = 1152921504884002816 (0x1000000010851000);//ML01
            // 0x00C7BA1C: LDR x1, [x8]               | X1 = public static System.Object ProtoBuf.BclHelpers::ReadNetObject(object value, ProtoBuf.ProtoReader source, int key, System.Type type, ProtoBuf.BclHelpers.NetObjectOptions options);
            val_56 = public static System.Object ProtoBuf.BclHelpers::ReadNetObject(object value, ProtoBuf.ProtoReader source, int key, System.Type type, ProtoBuf.BclHelpers.NetObjectOptions options);
            // 0x00C7BA20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ProtoBuf.ProtoException), ????);
            // 0x00C7BA24: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  277155840);
            System.Byte[] val_46 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  277155840);
            label_41:
            // 0x00C7BA28: LDR x19, [sp, #0x30]       | X19 = val_28;                           
            // 0x00C7BA2C: CBNZ x19, #0xc7ba34        | if (val_28 != 0) goto label_77;         
            if(val_30 != 0)
            {
                goto label_77;
            }
            // 0x00C7BA30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_46, ????);     
            label_77:
            // 0x00C7BA34: LDR x8, [x19]              | X8 = val_28;                            
            // 0x00C7BA38: MOV x0, x19                | X0 = val_28;//m1                        
            // 0x00C7BA3C: LDP x9, x1, [x8, #0x190]   | X9 = val_28 + 400; X1 = val_28 + 400 + 8; //  | 
            // 0x00C7BA40: BLR x9                     | X0 = val_28 + 400();                    
            // 0x00C7BA44: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C7BA48: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00C7BA4C: MOV x19, x0                | X19 = val_28;//m1                       
            // 0x00C7BA50: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00C7BA54: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00C7BA58: TBZ w9, #0, #0xc7ba6c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_79;
            // 0x00C7BA5C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BA60: CBNZ w9, #0xc7ba6c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_79;
            // 0x00C7BA64: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00C7BA68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_79:
            // 0x00C7BA6C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00C7BA70: LDR x8, [x8, #0x768]       | X8 = (string**)(1152921514333911008)("Dynamic type is not a contract-type: ");
            // 0x00C7BA74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BA78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BA7C: MOV x2, x19                | X2 = val_28;//m1                        
            // 0x00C7BA80: LDR x1, [x8]               | X1 = "Dynamic type is not a contract-type: ";
            // 0x00C7BA84: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Dynamic type is not a contract-type: ");
            string val_47 = System.String.Concat(str0:  0, str1:  "Dynamic type is not a contract-type: ");
            // 0x00C7BA88: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00C7BA8C: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x00C7BA90: MOV x19, x0                | X19 = val_47;//m1                       
            // 0x00C7BA94: LDR x8, [x8]               | X8 = typeof(System.InvalidOperationException);
            // 0x00C7BA98: MOV x0, x8                 | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            System.InvalidOperationException val_48 = null;
            // 0x00C7BA9C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x00C7BAA0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7BAA4: MOV x1, x19                | X1 = val_47;//m1                        
            // 0x00C7BAA8: MOV x20, x0                | X20 = 1152921504654397440 (0x1000000002D59000);//ML01
            val_61 = val_48;
            // 0x00C7BAAC: BL #0x1e6648c              | .ctor(message:  val_47);                
            val_48 = new System.InvalidOperationException(message:  val_47);
            label_75:
            // 0x00C7BAB0: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00C7BAB4: LDR x8, [x8, #0xaf8]       | X8 = 1152921514333873120;               
            // 0x00C7BAB8: MOV x0, x20                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00C7BABC: LDR x1, [x8]               | X1 = public static System.Object ProtoBuf.BclHelpers::ReadNetObject(object value, ProtoBuf.ProtoReader source, int key, System.Type type, ProtoBuf.BclHelpers.NetObjectOptions options);
            // 0x00C7BAC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x00C7BAC4: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  47550464);
            System.Byte[] val_49 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  47550464);
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7BAC8 (13089480), len: 1200  VirtAddr: 0x00C7BAC8 RVA: 0x00C7BAC8 token: 100689126 methodIndex: 53357 delegateWrapperIndex: 0 methodInvoker: 0
        public static void WriteNetObject(object value, ProtoBuf.ProtoWriter dest, int key, ProtoBuf.BclHelpers.NetObjectOptions options)
        {
            //
            // Disasemble & Code
            //  | 
            var val_17;
            //  | 
            ProtoBuf.ProtoWriter val_25;
            //  | 
            object val_26;
            //  | 
            ProtoBuf.ProtoWriter val_27;
            //  | 
            ProtoBuf.ProtoWriter val_28;
            //  | 
            var val_29;
            // 0x00C7BAC8: STP x28, x27, [sp, #-0x60]! | stack[1152921514334363760] = ???;  stack[1152921514334363768] = ???;  //  dest_result_addr=1152921514334363760 |  dest_result_addr=1152921514334363768
            // 0x00C7BACC: STP x26, x25, [sp, #0x10]  | stack[1152921514334363776] = ???;  stack[1152921514334363784] = ???;  //  dest_result_addr=1152921514334363776 |  dest_result_addr=1152921514334363784
            // 0x00C7BAD0: STP x24, x23, [sp, #0x20]  | stack[1152921514334363792] = ???;  stack[1152921514334363800] = ???;  //  dest_result_addr=1152921514334363792 |  dest_result_addr=1152921514334363800
            // 0x00C7BAD4: STP x22, x21, [sp, #0x30]  | stack[1152921514334363808] = ???;  stack[1152921514334363816] = ???;  //  dest_result_addr=1152921514334363808 |  dest_result_addr=1152921514334363816
            // 0x00C7BAD8: STP x20, x19, [sp, #0x40]  | stack[1152921514334363824] = ???;  stack[1152921514334363832] = ???;  //  dest_result_addr=1152921514334363824 |  dest_result_addr=1152921514334363832
            // 0x00C7BADC: STP x29, x30, [sp, #0x50]  | stack[1152921514334363840] = ???;  stack[1152921514334363848] = ???;  //  dest_result_addr=1152921514334363840 |  dest_result_addr=1152921514334363848
            // 0x00C7BAE0: ADD x29, sp, #0x50         | X29 = (1152921514334363760 + 80) = 1152921514334363840 (0x1000000243CE20C0);
            // 0x00C7BAE4: SUB sp, sp, #0x20          | SP = (1152921514334363760 - 32) = 1152921514334363728 (0x1000000243CE2050);
            // 0x00C7BAE8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00C7BAEC: LDRB w8, [x20, #0xf81]     | W8 = (bool)static_value_03733F81;       
            // 0x00C7BAF0: MOV w24, w4                | W24 = W4;//m1                           
            // 0x00C7BAF4: MOV w22, w3                | W22 = options;//m1                      
            val_25 = options;
            // 0x00C7BAF8: MOV x19, x2                | X19 = key;//m1                          
            // 0x00C7BAFC: MOV x21, x1                | X21 = dest;//m1                         
            val_26 = dest;
            // 0x00C7BB00: TBNZ w8, #0, #0xc7bb1c     | if (static_value_03733F81 == true) goto label_0;
            // 0x00C7BB04: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00C7BB08: LDR x8, [x8, #0x378]       | X8 = 0x2B8F168;                         
            // 0x00C7BB0C: LDR w0, [x8]               | W0 = 0x131C;                            
            // 0x00C7BB10: BL #0x2782188              | X0 = sub_2782188( ?? 0x131C, ????);     
            // 0x00C7BB14: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7BB18: STRB w8, [x20, #0xf81]     | static_value_03733F81 = true;            //  dest_result_addr=57884545
            label_0:
            // 0x00C7BB1C: STRB wzr, [sp, #0x17]      | stack[1152921514334363751] = 0x0;        //  dest_result_addr=1152921514334363751
            bool val_4 = false;
            // 0x00C7BB20: STRB wzr, [sp, #0x16]      | stack[1152921514334363750] = 0x0;        //  dest_result_addr=1152921514334363750
            bool val_13 = false;
            // 0x00C7BB24: STR xzr, [sp, #8]          | stack[1152921514334363736] = 0x0;        //  dest_result_addr=1152921514334363736
            // 0x00C7BB28: CBZ x19, #0xc7be84         | if (key == 0) goto label_1;             
            if(key == 0)
            {
                goto label_1;
            }
            // 0x00C7BB2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BB30: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7BB34: AND w25, w24, #1           | W25 = (W4 & 1);                         
            val_27 = W4 & 1;
            // 0x00C7BB38: BL #0x2988c04              | X0 = key.get_WireType();                
            ProtoBuf.WireType val_1 = key.WireType;
            // 0x00C7BB3C: ADRP x27, #0x35fb000       | X27 = 56602624 (0x35FB000);             
            // 0x00C7BB40: LDR x27, [x27, #0x778]     | X27 = 1152921504884428800;              
            // 0x00C7BB44: MOV w23, w0                | W23 = val_1;//m1                        
            val_28 = val_1;
            // 0x00C7BB48: LDR x8, [x27]              | X8 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BB4C: LDRB w9, [x8, #0x10a]      | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BB50: TBZ w9, #0, #0xc7bb64      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00C7BB54: LDR w9, [x8, #0xbc]        | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BB58: CBNZ w9, #0xc7bb64         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00C7BB5C: MOV x0, x8                 | X0 = 1152921504884428800 (0x10000000108B9000);//ML01
            // 0x00C7BB60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_3:
            // 0x00C7BB64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BB68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BB6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BB70: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7BB74: BL #0x2977f50              | X0 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            ProtoBuf.SubItemToken val_2 = ProtoBuf.ProtoWriter.StartSubItem(instance:  0, writer:  0);
            // 0x00C7BB78: MOV x20, x0                | X20 = val_2.value;//m1                  
            // 0x00C7BB7C: CBZ w25, #0xc7bc0c         | if ((W4 & 1) == 0) goto label_4;        
            if(val_27 == 0)
            {
                goto label_4;
            }
            // 0x00C7BB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BB84: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7BB88: BL #0x2988bfc              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_3 = key.NetCache;
            // 0x00C7BB8C: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x00C7BB90: CBNZ x25, #0xc7bb98        | if (val_3 != null) goto label_5;        
            if(val_3 != null)
            {
                goto label_5;
            }
            // 0x00C7BB94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x00C7BB98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BB9C: ADD x2, sp, #0x17          | X2 = (1152921514334363728 + 23) = 1152921514334363751 (0x1000000243CE2067);
            // 0x00C7BBA0: MOV x0, x25                | X0 = val_3;//m1                         
            // 0x00C7BBA4: MOV x1, x21                | X1 = dest;//m1                          
            // 0x00C7BBA8: BL #0x2984234              | X0 = val_3.AddObjectKey(value:  val_26, existing: out  bool val_4 = false);
            int val_5 = val_3.AddObjectKey(value:  val_26, existing: out  val_4);
            // 0x00C7BBAC: MOV w25, w0                | W25 = val_5;//m1                        
            val_27 = val_5;
            // 0x00C7BBB0: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BBB4: LDRB w8, [sp, #0x17]       | W8 = 0x0;                               
            // 0x00C7BBB8: LDRB w9, [x0, #0x10a]      | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BBBC: CMP w8, #0                 | STATE = COMPARE(0x0, 0x0)               
            // 0x00C7BBC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7BBC4: CINC w26, w8, eq           | W26 = val_4 == 0x0 ? (1 + 1) : 1;       
            ProtoBuf.WireType val_6 = (val_4 == 0) ? (1 + 1) : (1);
            // 0x00C7BBC8: TBZ w9, #0, #0xc7bbd8      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00C7BBCC: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BBD0: CBNZ w8, #0xc7bbd8         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00C7BBD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_7:
            // 0x00C7BBD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BBDC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7BBE0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7BBE4: MOV w1, w26                | W1 = val_4 == 0x0 ? (1 + 1) : 1;//m1    
            // 0x00C7BBE8: MOV x3, x19                | X3 = key;//m1                           
            // 0x00C7BBEC: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  val_6, writer:  0);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  val_6, writer:  0);
            // 0x00C7BBF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BBF4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BBF8: MOV w1, w25                | W1 = val_5;//m1                         
            // 0x00C7BBFC: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7BC00: BL #0x29780bc              | ProtoBuf.ProtoWriter.WriteInt32(value:  0, writer:  val_27);
            ProtoBuf.ProtoWriter.WriteInt32(value:  0, writer:  val_27);
            // 0x00C7BC04: LDRB w8, [sp, #0x17]       | W8 = 0x0;                               
            // 0x00C7BC08: CBNZ w8, #0xc7be38         | if (0x0 != 0) goto label_26;            
            if(val_4 != 0)
            {
                goto label_26;
            }
            label_4:
            // 0x00C7BC0C: AND w8, w24, #2            | W8 = (W4 & 2);                          
            var val_7 = W4 & 2;
            // 0x00C7BC10: CBZ w8, #0xc7bd54          | if ((W4 & 2) == 0) goto label_17;       
            if(val_7 == 0)
            {
                goto label_17;
            }
            // 0x00C7BC14: CBZ x21, #0xc7bc44         | if (dest == null) goto label_10;        
            if(val_26 == null)
            {
                goto label_10;
            }
            // 0x00C7BC18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BC1C: MOV x0, x21                | X0 = dest;//m1                          
            // 0x00C7BC20: BL #0x16fb28c              | X0 = dest.GetType();                    
            System.Type val_8 = val_26.GetType();
            // 0x00C7BC24: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C7BC28: STR x0, [sp, #8]           | stack[1152921514334363736] = val_8;      //  dest_result_addr=1152921514334363736
            // 0x00C7BC2C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00C7BC30: LDR x9, [x21]              | X9 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BC34: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00C7BC38: CMP x9, x8                 | STATE = COMPARE(typeof(ProtoBuf.ProtoWriter), typeof(System.String))
            // 0x00C7BC3C: B.NE #0xc7bc58             | if (typeof(ProtoBuf.ProtoWriter) != null) goto label_11;
            if(null != null)
            {
                goto label_11;
            }
            // 0x00C7BC40: B #0xc7bc70                |  goto label_12;                         
            goto label_12;
            label_10:
            // 0x00C7BC44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x00C7BC48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BC4C: MOV x0, x21                | X0 = dest;//m1                          
            // 0x00C7BC50: BL #0x16fb28c              | X0 = dest.GetType();                    
            System.Type val_9 = val_26.GetType();
            // 0x00C7BC54: STR x0, [sp, #8]           | stack[1152921514334363736] = val_9;      //  dest_result_addr=1152921514334363736
            System.Type val_10 = val_9;
            label_11:
            // 0x00C7BC58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7BC5C: ADD x1, sp, #8             | X1 = (1152921514334363728 + 8) = 1152921514334363736 (0x1000000243CE2058);
            // 0x00C7BC60: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7BC64: BL #0x2988bcc              | X0 = key.GetTypeKey(type: ref  System.Type val_10 = val_9);
            int val_11 = key.GetTypeKey(type: ref  val_10);
            // 0x00C7BC68: MOV w22, w0                | W22 = val_11;//m1                       
            val_25 = val_11;
            // 0x00C7BC6C: TBNZ w22, #0x1f, #0xc7bec4 | if ((val_11 & 0x80000000) != 0) goto label_13;
            if((val_25 & 2147483648) != 0)
            {
                goto label_13;
            }
            label_12:
            // 0x00C7BC70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BC74: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7BC78: BL #0x2988bfc              | X0 = key.get_NetCache();                
            ProtoBuf.NetObjectCache val_12 = key.NetCache;
            // 0x00C7BC7C: LDR x24, [sp, #8]          | X24 = val_9;                            
            // 0x00C7BC80: MOV x25, x0                | X25 = val_12;//m1                       
            // 0x00C7BC84: CBNZ x25, #0xc7bc8c        | if (val_12 != null) goto label_14;      
            if(val_12 != null)
            {
                goto label_14;
            }
            // 0x00C7BC88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_14:
            // 0x00C7BC8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BC90: ADD x2, sp, #0x16          | X2 = (1152921514334363728 + 22) = 1152921514334363750 (0x1000000243CE2066);
            // 0x00C7BC94: MOV x0, x25                | X0 = val_12;//m1                        
            // 0x00C7BC98: MOV x1, x24                | X1 = val_9;//m1                         
            // 0x00C7BC9C: BL #0x2984234              | X0 = val_12.AddObjectKey(value:  val_10, existing: out  bool val_13 = false);
            int val_14 = val_12.AddObjectKey(value:  val_10, existing: out  val_13);
            // 0x00C7BCA0: MOV w24, w0                | W24 = val_14;//m1                       
            // 0x00C7BCA4: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BCA8: LDRB w8, [sp, #0x16]       | W8 = 0x0;                               
            // 0x00C7BCAC: LDRB w9, [x0, #0x10a]      | W9 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BCB0: CMP w8, #0                 | STATE = COMPARE(0x0, 0x0)               
            // 0x00C7BCB4: ORR w8, wzr, #3            | W8 = 3(0x3);                            
            // 0x00C7BCB8: CINC w25, w8, eq           | W25 = val_13 == 0x0 ? (3 + 1) : 3;      
            ProtoBuf.WireType val_15 = (val_13 == 0) ? (3 + 1) : (3);
            // 0x00C7BCBC: TBZ w9, #0, #0xc7bccc      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00C7BCC0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BCC4: CBNZ w8, #0xc7bccc         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00C7BCC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_16:
            // 0x00C7BCCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BCD0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00C7BCD4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7BCD8: MOV w1, w25                | W1 = val_13 == 0x0 ? (3 + 1) : 3;//m1   
            // 0x00C7BCDC: MOV x3, x19                | X3 = key;//m1                           
            // 0x00C7BCE0: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  val_15, writer:  0);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  val_15, writer:  0);
            // 0x00C7BCE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BCE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BCEC: MOV w1, w24                | W1 = val_14;//m1                        
            // 0x00C7BCF0: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7BCF4: BL #0x29780bc              | ProtoBuf.ProtoWriter.WriteInt32(value:  0, writer:  val_14);
            ProtoBuf.ProtoWriter.WriteInt32(value:  0, writer:  val_14);
            // 0x00C7BCF8: LDRB w8, [sp, #0x16]       | W8 = 0x0;                               
            // 0x00C7BCFC: CBNZ w8, #0xc7bd54         | if (0x0 != 0) goto label_17;            
            if(val_13 != 0)
            {
                goto label_17;
            }
            // 0x00C7BD00: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BD04: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BD08: TBZ w8, #0, #0xc7bd18      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00C7BD0C: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BD10: CBNZ w8, #0xc7bd18         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00C7BD14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_19:
            // 0x00C7BD18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BD1C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7BD20: ORR w1, wzr, #8            | W1 = 8(0x8);                            
            // 0x00C7BD24: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x00C7BD28: MOV x3, x19                | X3 = key;//m1                           
            // 0x00C7BD2C: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  8, writer:  2);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  8, writer:  2);
            // 0x00C7BD30: LDR x1, [sp, #8]           | X1 = val_9;                             
            // 0x00C7BD34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7BD38: MOV x0, x19                | X0 = key;//m1                           
            // 0x00C7BD3C: BL #0x2989e64              | X0 = key.SerializeType(type:  val_10);  
            string val_16 = key.SerializeType(type:  val_10);
            // 0x00C7BD40: MOV x1, x0                 | X1 = val_16;//m1                        
            // 0x00C7BD44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BD48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BD4C: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7BD50: BL #0x2979404              | ProtoBuf.ProtoWriter.WriteString(value:  0, writer:  val_16);
            ProtoBuf.ProtoWriter.WriteString(value:  0, writer:  val_16);
            label_17:
            // 0x00C7BD54: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BD58: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BD5C: TBZ w8, #0, #0xc7bd6c      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00C7BD60: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BD64: CBNZ w8, #0xc7bd6c         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00C7BD68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_21:
            // 0x00C7BD6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BD70: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7BD74: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x00C7BD78: MOV w2, w23                | W2 = val_1;//m1                         
            // 0x00C7BD7C: MOV x3, x19                | X3 = key;//m1                           
            // 0x00C7BD80: BL #0x29778e4              | ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  10, writer:  val_28);
            ProtoBuf.ProtoWriter.WriteFieldHeader(fieldNumber:  0, wireType:  10, writer:  val_28);
            // 0x00C7BD84: CBZ x21, #0xc7bda0         | if (dest == null) goto label_22;        
            if(val_26 == null)
            {
                goto label_22;
            }
            // 0x00C7BD88: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
            // 0x00C7BD8C: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
            val_28 = 1152921504608284672;
            // 0x00C7BD90: LDR x9, [x21]              | X9 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BD94: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x00C7BD98: CMP x9, x8                 | STATE = COMPARE(typeof(ProtoBuf.ProtoWriter), typeof(System.String))
            // 0x00C7BD9C: B.EQ #0xc7bdd4             | if (typeof(ProtoBuf.ProtoWriter) == null) goto label_23;
            if(null == null)
            {
                goto label_23;
            }
            label_22:
            // 0x00C7BDA0: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BDA4: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BDA8: TBZ w8, #0, #0xc7bdb8      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x00C7BDAC: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BDB0: CBNZ w8, #0xc7bdb8         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x00C7BDB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_25:
            // 0x00C7BDB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BDBC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00C7BDC0: MOV x1, x21                | X1 = dest;//m1                          
            // 0x00C7BDC4: MOV w2, w22                | W2 = val_11;//m1                        
            // 0x00C7BDC8: MOV x3, x19                | X3 = key;//m1                           
            // 0x00C7BDCC: BL #0x2987f2c              | ProtoBuf.ProtoWriter.WriteObject(value:  0, key:  val_26, writer:  val_25);
            ProtoBuf.ProtoWriter.WriteObject(value:  0, key:  val_26, writer:  val_25);
            // 0x00C7BDD0: B #0xc7be38                |  goto label_26;                         
            goto label_26;
            label_23:
            // 0x00C7BDD4: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BDD8: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BDDC: TBZ w8, #0, #0xc7be24      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_29;
            // 0x00C7BDE0: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BDE4: CBNZ w8, #0xc7be24         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
            // 0x00C7BDE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            // 0x00C7BDEC: LDR x1, [x23]              | X1 = typeof(System.String);             
            // 0x00C7BDF0: LDR x8, [x21]              | X8 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BDF4: CMP x8, x1                 | STATE = COMPARE(typeof(ProtoBuf.ProtoWriter), typeof(System.String))
            // 0x00C7BDF8: B.EQ #0xc7be24             | if (typeof(ProtoBuf.ProtoWriter) == null) goto label_29;
            if(null == null)
            {
                goto label_29;
            }
            // 0x00C7BDFC: LDR x0, [x8, #0x30]        | X0 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_element_class;
            // 0x00C7BE00: ADD x8, sp, #0x18          | X8 = (1152921514334363728 + 24) = 1152921514334363752 (0x1000000243CE2068);
            // 0x00C7BE04: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ProtoBuf.ProtoWriter.__il2cppRuntimeField_element_class, ????);
            // 0x00C7BE08: LDR x0, [sp, #0x18]        | X0 = val_17;                             //  find_add[1152921514334351856]
            // 0x00C7BE0C: BL #0x27af090              | X0 = sub_27AF090( ?? val_17, ????);     
            // 0x00C7BE10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BE14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            // 0x00C7BE18: ADD x0, sp, #0x18          | X0 = (1152921514334363728 + 24) = 1152921514334363752 (0x1000000243CE2068);
            // 0x00C7BE1C: BL #0x299a140              | 
            // 0x00C7BE20: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_26 = 0;
            label_29:
            // 0x00C7BE24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BE28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BE2C: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x00C7BE30: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7BE34: BL #0x2979404              | ProtoBuf.ProtoWriter.WriteString(value:  0, writer:  val_26);
            ProtoBuf.ProtoWriter.WriteString(value:  0, writer:  val_26);
            label_26:
            // 0x00C7BE38: LDR x0, [x27]              | X0 = typeof(ProtoBuf.ProtoWriter);      
            // 0x00C7BE3C: LDRB w8, [x0, #0x10a]      | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_10A;
            // 0x00C7BE40: TBZ w8, #0, #0xc7be50      | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x00C7BE44: LDR w8, [x0, #0xbc]        | W8 = ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BE48: CBNZ w8, #0xc7be50         | if (ProtoBuf.ProtoWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x00C7BE4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ProtoBuf.ProtoWriter), ????);
            label_31:
            // 0x00C7BE50: AND x1, x20, #0xffffffff   | X1 = (val_2.value & 4294967295);        
            int val_18 = val_2.value & 4294967295;
            // 0x00C7BE54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BE58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BE5C: MOV x2, x19                | X2 = key;//m1                           
            // 0x00C7BE60: BL #0x2977fd0              | ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  int val_18 = val_2.value & 4294967295);
            ProtoBuf.ProtoWriter.EndSubItem(token:  new ProtoBuf.SubItemToken(), writer:  val_18);
            // 0x00C7BE64: SUB sp, x29, #0x50         | SP = (1152921514334363840 - 80) = 1152921514334363760 (0x1000000243CE2070);
            // 0x00C7BE68: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7BE6C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00C7BE70: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00C7BE74: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00C7BE78: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00C7BE7C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00C7BE80: RET                        |  return;                                
            return;
            label_1:
            // 0x00C7BE84: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00C7BE88: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00C7BE8C: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_19 = null;
            // 0x00C7BE90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7BE94: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00C7BE98: LDR x8, [x8, #0x5d8]       | X8 = (string**)(1152921514332272144)("dest");
            // 0x00C7BE9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7BEA0: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C7BEA4: LDR x1, [x8]               | X1 = "dest";                            
            // 0x00C7BEA8: BL #0x18b3df0              | .ctor(paramName:  "dest");              
            val_19 = new System.ArgumentNullException(paramName:  "dest");
            // 0x00C7BEAC: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00C7BEB0: LDR x8, [x8, #0x8b8]       | X8 = 1152921514334273008;               
            // 0x00C7BEB4: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00C7BEB8: LDR x1, [x8]               | X1 = public static System.Void ProtoBuf.BclHelpers::WriteNetObject(object value, ProtoBuf.ProtoWriter dest, int key, ProtoBuf.BclHelpers.NetObjectOptions options);
            val_29 = public static System.Void ProtoBuf.BclHelpers::WriteNetObject(object value, ProtoBuf.ProtoWriter dest, int key, ProtoBuf.BclHelpers.NetObjectOptions options);
            // 0x00C7BEBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00C7BEC0: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
            System.Byte[] val_20 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  45047808);
            label_13:
            // 0x00C7BEC4: LDR x19, [sp, #8]          | X19 = val_9;                            
            // 0x00C7BEC8: CBNZ x19, #0xc7bed0        | if (val_9 != 0) goto label_32;          
            if(val_10 != 0)
            {
                goto label_32;
            }
            // 0x00C7BECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_32:
            // 0x00C7BED0: LDR x8, [x19]              | X8 = val_9;                             
            // 0x00C7BED4: MOV x0, x19                | X0 = val_9;//m1                         
            // 0x00C7BED8: LDP x9, x1, [x8, #0x190]   | X9 = val_9 + 400; X1 = val_9 + 400 + 8;  //  | 
            // 0x00C7BEDC: BLR x9                     | X0 = val_9 + 400();                     
            // 0x00C7BEE0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00C7BEE4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00C7BEE8: MOV x19, x0                | X19 = val_9;//m1                        
            // 0x00C7BEEC: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00C7BEF0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00C7BEF4: TBZ w9, #0, #0xc7bf08      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x00C7BEF8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00C7BEFC: CBNZ w9, #0xc7bf08         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x00C7BF00: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00C7BF04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_34:
            // 0x00C7BF08: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x00C7BF0C: LDR x8, [x8, #0x768]       | X8 = (string**)(1152921514333911008)("Dynamic type is not a contract-type: ");
            // 0x00C7BF10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00C7BF14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00C7BF18: MOV x2, x19                | X2 = val_9;//m1                         
            // 0x00C7BF1C: LDR x1, [x8]               | X1 = "Dynamic type is not a contract-type: ";
            // 0x00C7BF20: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Dynamic type is not a contract-type: ");
            string val_21 = System.String.Concat(str0:  0, str1:  "Dynamic type is not a contract-type: ");
            // 0x00C7BF24: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00C7BF28: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x00C7BF2C: MOV x19, x0                | X19 = val_21;//m1                       
            // 0x00C7BF30: LDR x8, [x8]               | X8 = typeof(System.InvalidOperationException);
            // 0x00C7BF34: MOV x0, x8                 | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            System.InvalidOperationException val_22 = null;
            // 0x00C7BF38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x00C7BF3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00C7BF40: MOV x1, x19                | X1 = val_21;//m1                        
            // 0x00C7BF44: MOV x20, x0                | X20 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00C7BF48: BL #0x1e6648c              | .ctor(message:  val_21);                
            val_22 = new System.InvalidOperationException(message:  val_21);
            // 0x00C7BF4C: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00C7BF50: LDR x8, [x8, #0x8b8]       | X8 = 1152921514334273008;               
            // 0x00C7BF54: MOV x0, x20                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00C7BF58: LDR x1, [x8]               | X1 = public static System.Void ProtoBuf.BclHelpers::WriteNetObject(object value, ProtoBuf.ProtoWriter dest, int key, ProtoBuf.BclHelpers.NetObjectOptions options);
            // 0x00C7BF5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x00C7BF60: BL #0xc66e30               | X0 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  47550464);
            System.Byte[] val_23 = Pomelo.Protobuf.Encoder.encodeUInt32(n:  47550464);
            // 0x00C7BF64: MOV x19, x0                | X19 = val_23;//m1                       
            // 0x00C7BF68: ADD x0, sp, #0x18          | X0 = (1152921514334363728 + 24) = 1152921514334363752 (0x1000000243CE2068);
            // 0x00C7BF6C: BL #0x299a140              | 
            // 0x00C7BF70: MOV x0, x19                | X0 = val_23;//m1                        
            // 0x00C7BF74: BL #0x980800               | X0 = sub_980800( ?? val_23, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x00C7BF78 (13090680), len: 136  VirtAddr: 0x00C7BF78 RVA: 0x00C7BF78 token: 100689127 methodIndex: 53358 delegateWrapperIndex: 0 methodInvoker: 0
        private static BclHelpers()
        {
            //
            // Disasemble & Code
            // 0x00C7BF78: STP x20, x19, [sp, #-0x20]! | stack[1152921514334590512] = ???;  stack[1152921514334590520] = ???;  //  dest_result_addr=1152921514334590512 |  dest_result_addr=1152921514334590520
            // 0x00C7BF7C: STP x29, x30, [sp, #0x10]  | stack[1152921514334590528] = ???;  stack[1152921514334590536] = ???;  //  dest_result_addr=1152921514334590528 |  dest_result_addr=1152921514334590536
            // 0x00C7BF80: ADD x29, sp, #0x10         | X29 = (1152921514334590512 + 16) = 1152921514334590528 (0x1000000243D19640);
            // 0x00C7BF84: SUB sp, sp, #0x20          | SP = (1152921514334590512 - 32) = 1152921514334590480 (0x1000000243D19610);
            // 0x00C7BF88: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00C7BF8C: LDRB w8, [x19, #0xf82]     | W8 = (bool)static_value_03733F82;       
            // 0x00C7BF90: TBNZ w8, #0, #0xc7bfac     | if (static_value_03733F82 == true) goto label_0;
            // 0x00C7BF94: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x00C7BF98: LDR x8, [x8, #0xb40]       | X8 = 0x2B8F13C;                         
            // 0x00C7BF9C: LDR w0, [x8]               | W0 = 0x1311;                            
            // 0x00C7BFA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1311, ????);     
            // 0x00C7BFA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00C7BFA8: STRB w8, [x19, #0xf82]     | static_value_03733F82 = true;            //  dest_result_addr=57884546
            label_0:
            // 0x00C7BFAC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00C7BFB0: ADD x0, sp, #0x10          | X0 = (1152921514334590480 + 16) = 1152921514334590496 (0x1000000243D19620);
            // 0x00C7BFB4: MOVZ w1, #0x7b2            | W1 = 1970 (0x7B2);//ML01                
            // 0x00C7BFB8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00C7BFBC: ORR w3, wzr, #1            | W3 = 1(0x1);                            
            // 0x00C7BFC0: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00C7BFC4: MOV w6, wzr                | W6 = 0 (0x0);//ML01                     
            // 0x00C7BFC8: MOV w7, wzr                | W7 = 0 (0x0);//ML01                     
            // 0x00C7BFCC: STP xzr, xzr, [sp, #0x10]  | stack[1152921514334590496] = 0x0;  stack[1152921514334590504] = 0x0;  //  dest_result_addr=1152921514334590496 |  dest_result_addr=1152921514334590504
            // 0x00C7BFD0: STR xzr, [sp]              | stack[1152921514334590480] = 0x0;        //  dest_result_addr=1152921514334590480
            // 0x00C7BFD4: BL #0x1bacf6c              | X0 = label_System_DateTime__ctor_GL01BACF6C();
            // 0x00C7BFD8: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00C7BFDC: LDR x8, [x8, #0xd90]       | X8 = 1152921504881287168;               
            // 0x00C7BFE0: LDR x8, [x8]               | X8 = typeof(ProtoBuf.BclHelpers);       
            // 0x00C7BFE4: LDP x9, x10, [sp, #0x10]   | X9 = 0x0; X10 = 0x0;                     //  | 
            // 0x00C7BFE8: LDR x8, [x8, #0xa0]        | X8 = ProtoBuf.BclHelpers.__il2cppRuntimeField_static_fields;
            // 0x00C7BFEC: STP x9, x10, [x8]          | ProtoBuf.BclHelpers.FieldObject = 0; ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_3 = 0x0;  ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_8 = 0x0;  //  dest_result_addr=1152921504881291264 dest_result_addr=1152921504881291268 |  dest_result_addr=1152921504881291272
            ProtoBuf.BclHelpers.FieldObject = 0;
            ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_3 = 0;
            ProtoBuf.BclHelpers.FieldObject.__il2cppRuntimeField_8 = 0;
            // 0x00C7BFF0: SUB sp, x29, #0x10         | SP = (1152921514334590528 - 16) = 1152921514334590512 (0x1000000243D19630);
            // 0x00C7BFF4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00C7BFF8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00C7BFFC: RET                        |  return;                                
            return;
        
        }
    
    }

}
