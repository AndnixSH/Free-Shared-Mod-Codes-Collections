using UnityEngine;

namespace Iteedee.ApkReader
{
    public class ApkReader
    {
        // Fields
        private static int VER_ID; // static_offset: 0x00000000
        private static int ICN_ID; // static_offset: 0x00000004
        private static int LABEL_ID; // static_offset: 0x00000008
        private string[] VER_ICN; //  0x00000010
        private string[] TAGS; //  0x00000018
        private string[] ATTRS; //  0x00000020
        private System.Collections.Generic.Dictionary<string, object> entryList; //  0x00000028
        private System.Collections.Generic.List<string> tmpFiles; //  0x00000030
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x017B94E4 (24876260), len: 800  VirtAddr: 0x017B94E4 RVA: 0x017B94E4 token: 100684416 methodIndex: 45986 delegateWrapperIndex: 0 methodInvoker: 0
        public ApkReader()
        {
            //
            // Disasemble & Code
            // 0x017B94E4: STP x22, x21, [sp, #-0x30]! | stack[1152921513632026000] = ???;  stack[1152921513632026008] = ???;  //  dest_result_addr=1152921513632026000 |  dest_result_addr=1152921513632026008
            // 0x017B94E8: STP x20, x19, [sp, #0x10]  | stack[1152921513632026016] = ???;  stack[1152921513632026024] = ???;  //  dest_result_addr=1152921513632026016 |  dest_result_addr=1152921513632026024
            // 0x017B94EC: STP x29, x30, [sp, #0x20]  | stack[1152921513632026032] = ???;  stack[1152921513632026040] = ???;  //  dest_result_addr=1152921513632026032 |  dest_result_addr=1152921513632026040
            // 0x017B94F0: ADD x29, sp, #0x20         | X29 = (1152921513632026000 + 32) = 1152921513632026032 (0x1000000219F14DB0);
            // 0x017B94F4: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017B94F8: LDRB w8, [x20, #0x954]     | W8 = (bool)static_value_03738954;       
            // 0x017B94FC: MOV x19, x0                | X19 = 1152921513632038048 (0x1000000219F17CA0);//ML01
            // 0x017B9500: TBNZ w8, #0, #0x17b951c    | if (static_value_03738954 == true) goto label_0;
            // 0x017B9504: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x017B9508: LDR x8, [x8, #0x4c8]       | X8 = 0x2B8B018;                         
            // 0x017B950C: LDR w0, [x8]               | W0 = 0x2C4;                             
            // 0x017B9510: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C4, ????);      
            // 0x017B9514: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9518: STRB w8, [x20, #0x954]     | static_value_03738954 = true;            //  dest_result_addr=57903444
            label_0:
            // 0x017B951C: ADRP x21, #0x3680000       | X21 = 57147392 (0x3680000);             
            // 0x017B9520: LDR x21, [x21, #0x2d0]     | X21 = 1152921504948897168;              
            // 0x017B9524: LDR x20, [x21]             | X20 = typeof(System.String[]);          
            // 0x017B9528: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B952C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x017B9530: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x017B9534: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B9538: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x017B953C: STR x0, [x19, #0x10]       | this.VER_ICN = typeof(System.String[]);  //  dest_result_addr=1152921513632038064
            this.VER_ICN = null;
            // 0x017B9540: LDR x20, [x21]             | X20 = typeof(System.String[]);          
            // 0x017B9544: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B9548: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x017B954C: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x017B9550: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B9554: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x017B9558: MOV x20, x0                | X20 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B955C: CBNZ x20, #0x17b9564       | if ( != null) goto label_1;             
            if(null != null)
            {
                goto label_1;
            }
            // 0x017B9560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_1:
            // 0x017B9564: ADRP x22, #0x35bd000       | X22 = 56348672 (0x35BD000);             
            // 0x017B9568: LDR x22, [x22, #0xff8]     | X22 = (string**)(1152921513632013408)("manifest");
            // 0x017B956C: LDR x0, [x22]              | X0 = "manifest";                        
            // 0x017B9570: CBZ x0, #0x17b9590         | if ("manifest" == null) goto label_3;   
            // 0x017B9574: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B9578: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B957C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "manifest", ????); 
            // 0x017B9580: CBNZ x0, #0x17b9590        | if ("manifest" != null) goto label_3;   
            if("manifest" != null)
            {
                goto label_3;
            }
            // 0x017B9584: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "manifest", ????); 
            // 0x017B9588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B958C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "manifest", ????); 
            label_3:
            // 0x017B9590: LDR x22, [x22]             | X22 = "manifest";                       
            // 0x017B9594: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B9598: CBNZ w8, #0x17b95a8        | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_4;
            // 0x017B959C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "manifest", ????); 
            // 0x017B95A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B95A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "manifest", ????); 
            label_4:
            // 0x017B95A8: STR x22, [x20, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "manifest";  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = "manifest";
            // 0x017B95AC: ADRP x22, #0x35d7000       | X22 = 56455168 (0x35D7000);             
            // 0x017B95B0: LDR x22, [x22, #0x9b0]     | X22 = (string**)(1152921513632013504)("application");
            // 0x017B95B4: LDR x0, [x22]              | X0 = "application";                     
            // 0x017B95B8: CBZ x0, #0x17b95d8         | if ("application" == null) goto label_6;
            // 0x017B95BC: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B95C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B95C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "application", ????);
            // 0x017B95C8: CBNZ x0, #0x17b95d8        | if ("application" != null) goto label_6;
            if("application" != null)
            {
                goto label_6;
            }
            // 0x017B95CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "application", ????);
            // 0x017B95D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B95D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "application", ????);
            label_6:
            // 0x017B95D8: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B95DC: LDR x22, [x22]             | X22 = "application";                    
            // 0x017B95E0: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x017B95E4: B.HI #0x17b95f4            | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
            // 0x017B95E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "application", ????);
            // 0x017B95EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B95F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "application", ????);
            label_7:
            // 0x017B95F4: STR x22, [x20, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = "application";  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = "application";
            // 0x017B95F8: ADRP x22, #0x35d9000       | X22 = 56463360 (0x35D9000);             
            // 0x017B95FC: LDR x22, [x22, #0xa98]     | X22 = (string**)(1152921513632013600)("activity");
            // 0x017B9600: LDR x0, [x22]              | X0 = "activity";                        
            // 0x017B9604: CBZ x0, #0x17b9624         | if ("activity" == null) goto label_9;   
            // 0x017B9608: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B960C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B9610: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "activity", ????); 
            // 0x017B9614: CBNZ x0, #0x17b9624        | if ("activity" != null) goto label_9;   
            if("activity" != null)
            {
                goto label_9;
            }
            // 0x017B9618: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "activity", ????); 
            // 0x017B961C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9620: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "activity", ????); 
            label_9:
            // 0x017B9624: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B9628: LDR x22, [x22]             | X22 = "activity";                       
            // 0x017B962C: CMP w8, #2                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x017B9630: B.HI #0x17b9640            | if (System.String[].__il2cppRuntimeField_namespaze > 0x2) goto label_10;
            // 0x017B9634: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "activity", ????); 
            // 0x017B9638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B963C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "activity", ????); 
            label_10:
            // 0x017B9640: STR x22, [x20, #0x30]      | typeof(System.String[]).__il2cppRuntimeField_30 = "activity";  //  dest_result_addr=1152921504948897216
            typeof(System.String[]).__il2cppRuntimeField_30 = "activity";
            // 0x017B9644: STR x20, [x19, #0x18]      | this.TAGS = typeof(System.String[]);     //  dest_result_addr=1152921513632038072
            this.TAGS = null;
            // 0x017B9648: LDR x20, [x21]             | X20 = typeof(System.String[]);          
            // 0x017B964C: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B9650: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x017B9654: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x017B9658: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B965C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x017B9660: MOV x20, x0                | X20 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x017B9664: CBNZ x20, #0x17b966c       | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x017B9668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_11:
            // 0x017B966C: ADRP x21, #0x35bf000       | X21 = 56356864 (0x35BF000);             
            // 0x017B9670: LDR x21, [x21, #0x670]     | X21 = (string**)(1152921513632013696)("android:");
            // 0x017B9674: LDR x0, [x21]              | X0 = "android:";                        
            // 0x017B9678: CBZ x0, #0x17b9698         | if ("android:" == null) goto label_13;  
            // 0x017B967C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B9680: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B9684: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "android:", ????); 
            // 0x017B9688: CBNZ x0, #0x17b9698        | if ("android:" != null) goto label_13;  
            if(("android:") != null)
            {
                goto label_13;
            }
            // 0x017B968C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "android:", ????); 
            // 0x017B9690: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9694: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "android:", ????); 
            label_13:
            // 0x017B9698: LDR x21, [x21]             | X21 = "android:";                       
            // 0x017B969C: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B96A0: CBNZ w8, #0x17b96b0        | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_14;
            // 0x017B96A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "android:", ????); 
            // 0x017B96A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B96AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "android:", ????); 
            label_14:
            // 0x017B96B0: STR x21, [x20, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "android:";  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = "android:";
            // 0x017B96B4: ADRP x21, #0x35f2000       | X21 = 56565760 (0x35F2000);             
            // 0x017B96B8: LDR x21, [x21, #0xef0]     | X21 = (string**)(1152921513632013792)("a:");
            // 0x017B96BC: LDR x0, [x21]              | X0 = "a:";                              
            // 0x017B96C0: CBZ x0, #0x17b96e0         | if ("a:" == null) goto label_16;        
            // 0x017B96C4: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B96C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B96CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "a:", ????);       
            // 0x017B96D0: CBNZ x0, #0x17b96e0        | if ("a:" != null) goto label_16;        
            if(("a:") != null)
            {
                goto label_16;
            }
            // 0x017B96D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "a:", ????);       
            // 0x017B96D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B96DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "a:", ????);       
            label_16:
            // 0x017B96E0: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B96E4: LDR x21, [x21]             | X21 = "a:";                             
            // 0x017B96E8: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x017B96EC: B.HI #0x17b96fc            | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_17;
            // 0x017B96F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "a:", ????);       
            // 0x017B96F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B96F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "a:", ????);       
            label_17:
            // 0x017B96FC: STR x21, [x20, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = "a:";  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = "a:";
            // 0x017B9700: ADRP x21, #0x35d7000       | X21 = 56455168 (0x35D7000);             
            // 0x017B9704: LDR x21, [x21, #0x200]     | X21 = (string**)(1152921513632013872)("activity:");
            // 0x017B9708: LDR x0, [x21]              | X0 = "activity:";                       
            // 0x017B970C: CBZ x0, #0x17b972c         | if ("activity:" == null) goto label_19; 
            // 0x017B9710: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B9714: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B9718: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "activity:", ????);
            // 0x017B971C: CBNZ x0, #0x17b972c        | if ("activity:" != null) goto label_19; 
            if(("activity:") != null)
            {
                goto label_19;
            }
            // 0x017B9720: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "activity:", ????);
            // 0x017B9724: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9728: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "activity:", ????);
            label_19:
            // 0x017B972C: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B9730: LDR x21, [x21]             | X21 = "activity:";                      
            // 0x017B9734: CMP w8, #2                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x017B9738: B.HI #0x17b9748            | if (System.String[].__il2cppRuntimeField_namespaze > 0x2) goto label_20;
            // 0x017B973C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "activity:", ????);
            // 0x017B9740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9744: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "activity:", ????);
            label_20:
            // 0x017B9748: STR x21, [x20, #0x30]      | typeof(System.String[]).__il2cppRuntimeField_30 = "activity:";  //  dest_result_addr=1152921504948897216
            typeof(System.String[]).__il2cppRuntimeField_30 = "activity:";
            // 0x017B974C: ADRP x21, #0x35eb000       | X21 = 56537088 (0x35EB000);             
            // 0x017B9750: LDR x21, [x21, #0x8c0]     | X21 = (string**)(1152921513632013968)("_:");
            // 0x017B9754: LDR x0, [x21]              | X0 = "_:";                              
            // 0x017B9758: CBZ x0, #0x17b9778         | if ("_:" == null) goto label_22;        
            // 0x017B975C: LDR x8, [x20]              | X8 = ;                                  
            // 0x017B9760: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x017B9764: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "_:", ????);       
            // 0x017B9768: CBNZ x0, #0x17b9778        | if ("_:" != null) goto label_22;        
            if(("_:") != null)
            {
                goto label_22;
            }
            // 0x017B976C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "_:", ????);       
            // 0x017B9770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9774: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "_:", ????);       
            label_22:
            // 0x017B9778: LDR w8, [x20, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x017B977C: LDR x21, [x21]             | X21 = "_:";                             
            // 0x017B9780: CMP w8, #3                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x017B9784: B.HI #0x17b9794            | if (System.String[].__il2cppRuntimeField_namespaze > 0x3) goto label_23;
            // 0x017B9788: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "_:", ????);       
            // 0x017B978C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9790: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "_:", ????);       
            label_23:
            // 0x017B9794: STR x21, [x20, #0x38]      | typeof(System.String[]).__il2cppRuntimeField_38 = "_:";  //  dest_result_addr=1152921504948897224
            typeof(System.String[]).__il2cppRuntimeField_38 = "_:";
            // 0x017B9798: STR x20, [x19, #0x20]      | this.ATTRS = typeof(System.String[]);    //  dest_result_addr=1152921513632038080
            this.ATTRS = null;
            // 0x017B979C: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x017B97A0: LDR x8, [x8, #0xa10]       | X8 = 1152921504615792640;               
            // 0x017B97A4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, System.Object> val_1 = null;
            // 0x017B97A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x017B97AC: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x017B97B0: LDR x8, [x8, #0xf70]       | X8 = 1152921509667012816;               
            // 0x017B97B4: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x017B97B8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, System.Object>::.ctor();
            // 0x017B97BC: BL #0x23fb0c4              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, System.Object>();
            // 0x017B97C0: STR x20, [x19, #0x28]      | this.entryList = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921513632038088
            this.entryList = val_1;
            // 0x017B97C4: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017B97C8: LDR x8, [x8, #0xe00]       | X8 = 1152921504616644608;               
            // 0x017B97CC: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_2 = null;
            // 0x017B97D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017B97D4: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x017B97D8: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x017B97DC: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017B97E0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017B97E4: BL #0x25e9474              | .ctor();                                
            val_2 = new System.Collections.Generic.List<System.String>();
            // 0x017B97E8: STR x20, [x19, #0x30]      | this.tmpFiles = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513632038096
            this.tmpFiles = val_2;
            // 0x017B97EC: MOV x0, x19                | X0 = 1152921513632038048 (0x1000000219F17CA0);//ML01
            // 0x017B97F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B97F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B97F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B97FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B9800: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9804 (24877060), len: 472  VirtAddr: 0x017B9804 RVA: 0x017B9804 token: 100684417 methodIndex: 45987 delegateWrapperIndex: 0 methodInvoker: 0
        public string fuzzFindInDocument(System.Xml.XmlDocument doc, string tag, string attr)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            System.String[] val_14;
            //  | 
            string val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x017B9804: STP x28, x27, [sp, #-0x60]! | stack[1152921513632191200] = ???;  stack[1152921513632191208] = ???;  //  dest_result_addr=1152921513632191200 |  dest_result_addr=1152921513632191208
            // 0x017B9808: STP x26, x25, [sp, #0x10]  | stack[1152921513632191216] = ???;  stack[1152921513632191224] = ???;  //  dest_result_addr=1152921513632191216 |  dest_result_addr=1152921513632191224
            // 0x017B980C: STP x24, x23, [sp, #0x20]  | stack[1152921513632191232] = ???;  stack[1152921513632191240] = ???;  //  dest_result_addr=1152921513632191232 |  dest_result_addr=1152921513632191240
            // 0x017B9810: STP x22, x21, [sp, #0x30]  | stack[1152921513632191248] = ???;  stack[1152921513632191256] = ???;  //  dest_result_addr=1152921513632191248 |  dest_result_addr=1152921513632191256
            // 0x017B9814: STP x20, x19, [sp, #0x40]  | stack[1152921513632191264] = ???;  stack[1152921513632191272] = ???;  //  dest_result_addr=1152921513632191264 |  dest_result_addr=1152921513632191272
            // 0x017B9818: STP x29, x30, [sp, #0x50]  | stack[1152921513632191280] = ???;  stack[1152921513632191288] = ???;  //  dest_result_addr=1152921513632191280 |  dest_result_addr=1152921513632191288
            // 0x017B981C: ADD x29, sp, #0x50         | X29 = (1152921513632191200 + 80) = 1152921513632191280 (0x1000000219F3D330);
            // 0x017B9820: LDR x27, [x0, #0x18]       | X27 = this.TAGS; //P2                   
            val_14 = this.TAGS;
            // 0x017B9824: MOV x19, x3                | X19 = attr;//m1                         
            val_15 = attr;
            // 0x017B9828: MOV x20, x1                | X20 = doc;//m1                          
            // 0x017B982C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x017B9830: B #0x17b9838               |  goto label_0;                          
            goto label_0;
            label_7:
            // 0x017B9834: ADD w28, w28, #1           | W28 = (val_16 + 1) = val_16 (0x00000001);
            val_16 = 1;
            label_0:
            // 0x017B9838: CBNZ x27, #0x17b9840       | if (this.TAGS != null) goto label_1;    
            if(val_14 != null)
            {
                goto label_1;
            }
            // 0x017B983C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x017B9840: LDR w8, [x27, #0x18]       | W8 = this.TAGS.Length; //P2             
            // 0x017B9844: CMP w28, w8                | STATE = COMPARE(0x1, this.TAGS.Length)  
            // 0x017B9848: B.GE #0x17b99bc            | if (val_16 >= this.TAGS.Length) goto label_2;
            if(val_16 >= this.TAGS.Length)
            {
                goto label_2;
            }
            // 0x017B984C: SXTW x21, w28              | X21 = 1 (0x00000001);                   
            // 0x017B9850: CMP w28, w8                | STATE = COMPARE(0x1, this.TAGS.Length)  
            // 0x017B9854: B.LO #0x17b9864            | if (val_16 < this.TAGS.Length) goto label_3;
            if(val_16 < this.TAGS.Length)
            {
                goto label_3;
            }
            // 0x017B9858: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x017B985C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9860: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_3:
            // 0x017B9864: ADD x8, x27, x21, lsl #3   | X8 = this.TAGS[0x1]; //PARR1            
            // 0x017B9868: LDR x21, [x8, #0x20]       | X21 = this.TAGS[0x1][0]                 
            string val_14 = val_14[1];
            // 0x017B986C: CBNZ x20, #0x17b9874       | if (doc != null) goto label_4;          
            if(doc != null)
            {
                goto label_4;
            }
            // 0x017B9870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x017B9874: LDR x8, [x20]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9878: MOV x0, x20                | X0 = doc;//m1                           
            // 0x017B987C: MOV x1, x21                | X1 = this.TAGS[0x1][0];//m1             
            // 0x017B9880: LDR x9, [x8, #0x460]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_460;
            // 0x017B9884: LDR x2, [x8, #0x468]       | X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_468;
            // 0x017B9888: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_460();
            // 0x017B988C: MOV x21, x0                | X21 = doc;//m1                          
            // 0x017B9890: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x017B9894: B #0x17b989c               |  goto label_5;                          
            goto label_5;
            label_11:
            // 0x017B9898: ADD w22, w22, #1           | W22 = (val_17 + 1) = val_17 (0x00000001);
            val_17 = 1;
            label_5:
            // 0x017B989C: CBNZ x21, #0x17b98a4       | if (doc != null) goto label_6;          
            if(doc != null)
            {
                goto label_6;
            }
            // 0x017B98A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_6:
            // 0x017B98A4: LDR x8, [x21]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B98A8: MOV x0, x21                | X0 = doc;//m1                           
            // 0x017B98AC: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_168; //  | 
            // 0x017B98B0: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160();
            // 0x017B98B4: CMP w22, w0                | STATE = COMPARE(0x1, doc)               
            // 0x017B98B8: B.GE #0x17b9834            | if (val_17 >= doc) goto label_7;        
            if(val_17 >= doc)
            {
                goto label_7;
            }
            // 0x017B98BC: LDR x8, [x21]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B98C0: MOV x0, x21                | X0 = doc;//m1                           
            // 0x017B98C4: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
            // 0x017B98C8: LDP x9, x2, [x8, #0x190]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190; X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_198; //  | 
            // 0x017B98CC: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190();
            // 0x017B98D0: MOV x23, x0                | X23 = doc;//m1                          
            // 0x017B98D4: CBNZ x23, #0x17b98dc       | if (doc != null) goto label_8;          
            if(doc != null)
            {
                goto label_8;
            }
            // 0x017B98D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_8:
            // 0x017B98DC: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B98E0: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B98E4: LDR x9, [x8, #0x240]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_240;
            // 0x017B98E8: LDR x1, [x8, #0x248]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_248;
            // 0x017B98EC: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_240();
            // 0x017B98F0: CMP w0, #1                 | STATE = COMPARE(doc, 0x1)               
            // 0x017B98F4: B.NE #0x17b9898            | if (doc != 0x1) goto label_11;          
            if(doc != 1)
            {
                goto label_11;
            }
            // 0x017B98F8: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B98FC: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B9900: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_170; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_178; //  | 
            // 0x017B9904: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_170();
            // 0x017B9908: MOV x23, x0                | X23 = doc;//m1                          
            // 0x017B990C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            var val_15 = 0;
            label_14:
            // 0x017B9910: CBNZ x23, #0x17b9918       | if (doc != null) goto label_10;         
            if(doc != null)
            {
                goto label_10;
            }
            // 0x017B9914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_10:
            // 0x017B9918: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B991C: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B9920: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_168; //  | 
            // 0x017B9924: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160();
            // 0x017B9928: CMP w24, w0                | STATE = COMPARE(0x0, doc)               
            // 0x017B992C: B.GE #0x17b9898            | if (0 >= doc) goto label_11;            
            if(val_15 >= doc)
            {
                goto label_11;
            }
            // 0x017B9930: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9934: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B9938: MOV w1, w24                | W1 = 0 (0x0);//ML01                     
            // 0x017B993C: LDP x9, x2, [x8, #0x190]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190; X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_198; //  | 
            // 0x017B9940: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190();
            // 0x017B9944: MOV x25, x0                | X25 = doc;//m1                          
            // 0x017B9948: CBNZ x25, #0x17b9950       | if (doc != null) goto label_12;         
            if(doc != null)
            {
                goto label_12;
            }
            // 0x017B994C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_12:
            // 0x017B9950: LDR x8, [x25]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9954: MOV x0, x25                | X0 = doc;//m1                           
            // 0x017B9958: LDR x9, [x8, #0x210]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_210;
            // 0x017B995C: LDR x1, [x8, #0x218]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_218;
            // 0x017B9960: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_210();
            // 0x017B9964: MOV x26, x0                | X26 = doc;//m1                          
            // 0x017B9968: CBNZ x26, #0x17b9970       | if (doc != null) goto label_13;         
            if(doc != null)
            {
                goto label_13;
            }
            // 0x017B996C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_13:
            // 0x017B9970: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B9974: MOV x0, x26                | X0 = doc;//m1                           
            // 0x017B9978: MOV x1, x19                | X1 = attr;//m1                          
            // 0x017B997C: BL #0x18ab0a0              | X0 = doc.EndsWith(value:  val_15);      
            bool val_1 = doc.EndsWith(value:  val_15);
            // 0x017B9980: ADD w24, w24, #1           | W24 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x017B9984: TBZ w0, #0, #0x17b9910     | if (val_1 == false) goto label_14;      
            if(val_1 == false)
            {
                goto label_14;
            }
            // 0x017B9988: CBNZ x25, #0x17b9990       | if (doc != null) goto label_15;         
            if(doc != null)
            {
                goto label_15;
            }
            // 0x017B998C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_15:
            // 0x017B9990: LDR x8, [x25]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9994: MOV x0, x25                | X0 = doc;//m1                           
            // 0x017B9998: LDR x2, [x8, #0x290]       | X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
            // 0x017B999C: LDR x1, [x8, #0x298]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_298;
            // 0x017B99A0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x017B99A4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            val_15 = ???;
            // 0x017B99A8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x017B99AC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x017B99B0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x017B99B4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            val_14 = ???;
            // 0x017B99B8: BR x2                      | goto typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
            goto typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
            label_2:
            // 0x017B99BC: LDP x29, x30, [sp, #0x50]  | X29 = val_2; X30 = val_3;                //  find_add[1152921513632179296] |  find_add[1152921513632179296]
            // 0x017B99C0: LDP x20, x19, [sp, #0x40]  | X20 = val_4; X19 = val_5;                //  find_add[1152921513632179296] |  find_add[1152921513632179296]
            // 0x017B99C4: LDP x22, x21, [sp, #0x30]  | X22 = val_6; X21 = val_7;                //  find_add[1152921513632179296] |  find_add[1152921513632179296]
            // 0x017B99C8: LDP x24, x23, [sp, #0x20]  | X24 = val_8; X23 = val_9;                //  find_add[1152921513632179296] |  find_add[1152921513632179296]
            // 0x017B99CC: LDP x26, x25, [sp, #0x10]  | X26 = val_10; X25 = val_11;              //  find_add[1152921513632179296] |  find_add[1152921513632179296]
            // 0x017B99D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B99D4: LDP x28, x27, [sp], #0x60  | X28 = val_12; X27 = val_13;              //  find_add[1152921513632179296] |  find_add[1152921513632179296]
            // 0x017B99D8: RET                        |  return (System.String)null;            
            return (string)0;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B99DC (24877532), len: 176  VirtAddr: 0x017B99DC RVA: 0x017B99DC token: 100684418 methodIndex: 45988 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Xml.XmlDocument initDoc(string xml)
        {
            //
            // Disasemble & Code
            // 0x017B99DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513632364704] = ???;  stack[1152921513632364712] = ???;  //  dest_result_addr=1152921513632364704 |  dest_result_addr=1152921513632364712
            // 0x017B99E0: STP x29, x30, [sp, #0x10]  | stack[1152921513632364720] = ???;  stack[1152921513632364728] = ???;  //  dest_result_addr=1152921513632364720 |  dest_result_addr=1152921513632364728
            // 0x017B99E4: ADD x29, sp, #0x10         | X29 = (1152921513632364704 + 16) = 1152921513632364720 (0x1000000219F678B0);
            // 0x017B99E8: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017B99EC: LDRB w8, [x19, #0x955]     | W8 = (bool)static_value_03738955;       
            // 0x017B99F0: MOV x20, x1                | X20 = xml;//m1                          
            // 0x017B99F4: TBNZ w8, #0, #0x17b9a10    | if (static_value_03738955 == true) goto label_0;
            // 0x017B99F8: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
            // 0x017B99FC: LDR x8, [x8, #0x698]       | X8 = 0x2B8B030;                         
            // 0x017B9A00: LDR w0, [x8]               | W0 = 0x2CA;                             
            // 0x017B9A04: BL #0x2782188              | X0 = sub_2782188( ?? 0x2CA, ????);      
            // 0x017B9A08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9A0C: STRB w8, [x19, #0x955]     | static_value_03738955 = true;            //  dest_result_addr=57903445
            label_0:
            // 0x017B9A10: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x017B9A14: LDR x8, [x8, #0x2b0]       | X8 = 1152921504763875328;               
            // 0x017B9A18: LDR x0, [x8]               | X0 = typeof(System.Xml.XmlDocument);    
            System.Xml.XmlDocument val_1 = null;
            // 0x017B9A1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Xml.XmlDocument), ????);
            // 0x017B9A20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9A24: MOV x19, x0                | X19 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017B9A28: BL #0x1653434              | .ctor();                                
            val_1 = new System.Xml.XmlDocument();
            // 0x017B9A2C: CBZ x19, #0x17b9a84        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x017B9A30: LDR x8, [x19]              | X8 = ;                                  
            // 0x017B9A34: MOV x0, x19                | X0 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017B9A38: MOV x1, x20                | X1 = xml;//m1                           
            // 0x017B9A3C: LDR x9, [x8, #0x490]       |  //  not_find_field!1:1168
            // 0x017B9A40: LDR x2, [x8, #0x498]       |  //  not_find_field!1:1176
            // 0x017B9A44: BLR x9                     | X0 = mem[null + 1168]();                
            // 0x017B9A48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B9A4C: MOV x0, x19                | X0 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017B9A50: BL #0x1653b24              | X0 = get_DocumentElement();             
            System.Xml.XmlElement val_2 = DocumentElement;
            // 0x017B9A54: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x017B9A58: CBNZ x20, #0x17b9a60       | if (val_2 != null) goto label_2;        
            if(val_2 != null)
            {
                goto label_2;
            }
            // 0x017B9A5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_2:
            // 0x017B9A60: LDR x8, [x20]              | X8 = typeof(System.Xml.XmlElement);     
            // 0x017B9A64: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x017B9A68: LDR x9, [x8, #0x340]       | X9 = typeof(System.Xml.XmlElement).__il2cppRuntimeField_340;
            // 0x017B9A6C: LDR x1, [x8, #0x348]       | X1 = typeof(System.Xml.XmlElement).__il2cppRuntimeField_348;
            // 0x017B9A70: BLR x9                     | X0 = typeof(System.Xml.XmlElement).__il2cppRuntimeField_340();
            // 0x017B9A74: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9A78: MOV x0, x19                | X0 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017B9A7C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B9A80: RET                        |  return (System.Xml.XmlDocument)typeof(System.Xml.XmlDocument);
            return (System.Xml.XmlDocument)val_1;
            //  |  // // {name=val_0, type=System.Xml.XmlDocument, size=8, nGRN=0 }
            label_1:
            // 0x017B9A84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x017B9A88: BRK #0x1                   | 
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9A8C (24877708), len: 228  VirtAddr: 0x017B9A8C RVA: 0x017B9A8C token: 100684419 methodIndex: 45989 delegateWrapperIndex: 0 methodInvoker: 0
        private void extractPermissions(Iteedee.ApkReader.ApkInfo info, System.Xml.XmlDocument doc)
        {
            //
            // Disasemble & Code
            // 0x017B9A8C: STP x22, x21, [sp, #-0x30]! | stack[1152921513632493584] = ???;  stack[1152921513632493592] = ???;  //  dest_result_addr=1152921513632493584 |  dest_result_addr=1152921513632493592
            // 0x017B9A90: STP x20, x19, [sp, #0x10]  | stack[1152921513632493600] = ???;  stack[1152921513632493608] = ???;  //  dest_result_addr=1152921513632493600 |  dest_result_addr=1152921513632493608
            // 0x017B9A94: STP x29, x30, [sp, #0x20]  | stack[1152921513632493616] = ???;  stack[1152921513632493624] = ???;  //  dest_result_addr=1152921513632493616 |  dest_result_addr=1152921513632493624
            // 0x017B9A98: ADD x29, sp, #0x20         | X29 = (1152921513632493584 + 32) = 1152921513632493616 (0x1000000219F87030);
            // 0x017B9A9C: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x017B9AA0: LDRB w8, [x21, #0x956]     | W8 = (bool)static_value_03738956;       
            // 0x017B9AA4: MOV x19, x2                | X19 = doc;//m1                          
            // 0x017B9AA8: MOV x20, x1                | X20 = info;//m1                         
            // 0x017B9AAC: TBNZ w8, #0, #0x17b9ac8    | if (static_value_03738956 == true) goto label_0;
            // 0x017B9AB0: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x017B9AB4: LDR x8, [x8, #0x840]       | X8 = 0x2B8B028;                         
            // 0x017B9AB8: LDR w0, [x8]               | W0 = 0x2C8;                             
            // 0x017B9ABC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C8, ????);      
            // 0x017B9AC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9AC4: STRB w8, [x21, #0x956]     | static_value_03738956 = true;            //  dest_result_addr=57903446
            label_0:
            // 0x017B9AC8: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x017B9ACC: ADRP x21, #0x35c6000       | X21 = 56385536 (0x35C6000);             
            // 0x017B9AD0: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921513632481120)("uses-permission");
            // 0x017B9AD4: LDR x21, [x21, #0x5f0]     | X21 = (string**)(1152921509593945888)("name");
            // 0x017B9AD8: MOV x1, x20                | X1 = info;//m1                          
            // 0x017B9ADC: MOV x2, x19                | X2 = doc;//m1                           
            // 0x017B9AE0: LDR x3, [x8]               | X3 = "uses-permission";                 
            // 0x017B9AE4: LDR x4, [x21]              | X4 = "name";                            
            // 0x017B9AE8: BL #0x17b9b70              | this.ExtractPermission(info:  info, doc:  doc, keyName:  "uses-permission", attribName:  "name");
            this.ExtractPermission(info:  info, doc:  doc, keyName:  "uses-permission", attribName:  "name");
            // 0x017B9AEC: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x017B9AF0: LDR x8, [x8, #0x270]       | X8 = (string**)(1152921513632481232)("permission-group");
            // 0x017B9AF4: LDR x4, [x21]              | X4 = "name";                            
            // 0x017B9AF8: MOV x1, x20                | X1 = info;//m1                          
            // 0x017B9AFC: MOV x2, x19                | X2 = doc;//m1                           
            // 0x017B9B00: LDR x3, [x8]               | X3 = "permission-group";                
            // 0x017B9B04: BL #0x17b9b70              | this.ExtractPermission(info:  info, doc:  doc, keyName:  "permission-group", attribName:  "name");
            this.ExtractPermission(info:  info, doc:  doc, keyName:  "permission-group", attribName:  "name");
            // 0x017B9B08: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x017B9B0C: ADRP x21, #0x35c8000       | X21 = 56393728 (0x35C8000);             
            // 0x017B9B10: LDR x8, [x8, #0x340]       | X8 = (string**)(1152921513632481344)("service");
            // 0x017B9B14: LDR x21, [x21, #0xd78]     | X21 = (string**)(1152921513632481440)("permission");
            // 0x017B9B18: MOV x1, x20                | X1 = info;//m1                          
            // 0x017B9B1C: MOV x2, x19                | X2 = doc;//m1                           
            // 0x017B9B20: LDR x3, [x8]               | X3 = "service";                         
            // 0x017B9B24: LDR x4, [x21]              | X4 = "permission";                      
            // 0x017B9B28: BL #0x17b9b70              | this.ExtractPermission(info:  info, doc:  doc, keyName:  "service", attribName:  "permission");
            this.ExtractPermission(info:  info, doc:  doc, keyName:  "service", attribName:  "permission");
            // 0x017B9B2C: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x017B9B30: LDR x8, [x8, #0x4e8]       | X8 = (string**)(1152921513632481536)("provider");
            // 0x017B9B34: LDR x4, [x21]              | X4 = "permission";                      
            // 0x017B9B38: MOV x1, x20                | X1 = info;//m1                          
            // 0x017B9B3C: MOV x2, x19                | X2 = doc;//m1                           
            // 0x017B9B40: LDR x3, [x8]               | X3 = "provider";                        
            // 0x017B9B44: BL #0x17b9b70              | this.ExtractPermission(info:  info, doc:  doc, keyName:  "provider", attribName:  "permission");
            this.ExtractPermission(info:  info, doc:  doc, keyName:  "provider", attribName:  "permission");
            // 0x017B9B48: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x017B9B4C: LDR x8, [x8, #0xa98]       | X8 = (string**)(1152921513632013600)("activity");
            // 0x017B9B50: LDR x4, [x21]              | X4 = "permission";                      
            // 0x017B9B54: MOV x1, x20                | X1 = info;//m1                          
            // 0x017B9B58: MOV x2, x19                | X2 = doc;//m1                           
            // 0x017B9B5C: LDR x3, [x8]               | X3 = "activity";                        
            // 0x017B9B60: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9B64: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9B68: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B9B6C: B #0x17b9b70               | this.ExtractPermission(info:  info, doc:  doc, keyName:  "activity", attribName:  "permission"); return;
            this.ExtractPermission(info:  info, doc:  doc, keyName:  "activity", attribName:  "permission");
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9CEC (24878316), len: 272  VirtAddr: 0x017B9CEC RVA: 0x017B9CEC token: 100684420 methodIndex: 45990 delegateWrapperIndex: 0 methodInvoker: 0
        private bool readBoolean(System.Xml.XmlDocument doc, string tag, string attribute)
        {
            //
            // Disasemble & Code
            // 0x017B9CEC: STP x22, x21, [sp, #-0x30]! | stack[1152921513632630160] = ???;  stack[1152921513632630168] = ???;  //  dest_result_addr=1152921513632630160 |  dest_result_addr=1152921513632630168
            // 0x017B9CF0: STP x20, x19, [sp, #0x10]  | stack[1152921513632630176] = ???;  stack[1152921513632630184] = ???;  //  dest_result_addr=1152921513632630176 |  dest_result_addr=1152921513632630184
            // 0x017B9CF4: STP x29, x30, [sp, #0x20]  | stack[1152921513632630192] = ???;  stack[1152921513632630200] = ???;  //  dest_result_addr=1152921513632630192 |  dest_result_addr=1152921513632630200
            // 0x017B9CF8: ADD x29, sp, #0x20         | X29 = (1152921513632630160 + 32) = 1152921513632630192 (0x1000000219FA85B0);
            // 0x017B9CFC: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x017B9D00: LDRB w8, [x22, #0x957]     | W8 = (bool)static_value_03738957;       
            // 0x017B9D04: MOV x19, x3                | X19 = attribute;//m1                    
            // 0x017B9D08: MOV x20, x2                | X20 = tag;//m1                          
            // 0x017B9D0C: MOV x21, x1                | X21 = doc;//m1                          
            // 0x017B9D10: TBNZ w8, #0, #0x17b9d2c    | if (static_value_03738957 == true) goto label_0;
            // 0x017B9D14: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x017B9D18: LDR x8, [x8, #0xef0]       | X8 = 0x2B8B034;                         
            // 0x017B9D1C: LDR w0, [x8]               | W0 = 0x2CB;                             
            // 0x017B9D20: BL #0x2782188              | X0 = sub_2782188( ?? 0x2CB, ????);      
            // 0x017B9D24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9D28: STRB w8, [x22, #0x957]     | static_value_03738957 = true;            //  dest_result_addr=57903447
            label_0:
            // 0x017B9D2C: MOV x1, x21                | X1 = doc;//m1                           
            // 0x017B9D30: MOV x2, x20                | X2 = tag;//m1                           
            // 0x017B9D34: MOV x3, x19                | X3 = attribute;//m1                     
            // 0x017B9D38: BL #0x17b9dfc              | X0 = this.FindInDocument(doc:  doc, keyName:  tag, attribName:  attribute);
            string val_1 = this.FindInDocument(doc:  doc, keyName:  tag, attribName:  attribute);
            // 0x017B9D3C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x017B9D40: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x017B9D44: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x017B9D48: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x017B9D4C: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x017B9D50: TBZ w9, #0, #0x17b9d64     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x017B9D54: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x017B9D58: CBNZ w9, #0x17b9d64        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x017B9D5C: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x017B9D60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_2:
            // 0x017B9D64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B9D68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B9D6C: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x017B9D70: BL #0x1ba252c              | X0 = System.Convert.ToBoolean(value:  0);
            bool val_2 = System.Convert.ToBoolean(value:  0);
            // 0x017B9D74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9D78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9D7C: AND w0, w0, #1             | W0 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x017B9D80: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B9D84: RET                        |  return (System.Boolean)(val_2 & 1);    
            return val_3;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9F18 (24878872), len: 292  VirtAddr: 0x017B9F18 RVA: 0x017B9F18 token: 100684421 methodIndex: 45991 delegateWrapperIndex: 0 methodInvoker: 0
        private void extractSupportScreens(Iteedee.ApkReader.ApkInfo info, System.Xml.XmlDocument doc)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            // 0x017B9F18: STP x24, x23, [sp, #-0x40]! | stack[1152921513632767168] = ???;  stack[1152921513632767176] = ???;  //  dest_result_addr=1152921513632767168 |  dest_result_addr=1152921513632767176
            // 0x017B9F1C: STP x22, x21, [sp, #0x10]  | stack[1152921513632767184] = ???;  stack[1152921513632767192] = ???;  //  dest_result_addr=1152921513632767184 |  dest_result_addr=1152921513632767192
            // 0x017B9F20: STP x20, x19, [sp, #0x20]  | stack[1152921513632767200] = ???;  stack[1152921513632767208] = ???;  //  dest_result_addr=1152921513632767200 |  dest_result_addr=1152921513632767208
            // 0x017B9F24: STP x29, x30, [sp, #0x30]  | stack[1152921513632767216] = ???;  stack[1152921513632767224] = ???;  //  dest_result_addr=1152921513632767216 |  dest_result_addr=1152921513632767224
            // 0x017B9F28: ADD x29, sp, #0x30         | X29 = (1152921513632767168 + 48) = 1152921513632767216 (0x1000000219FC9CF0);
            // 0x017B9F2C: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x017B9F30: LDRB w8, [x22, #0x958]     | W8 = (bool)static_value_03738958;       
            // 0x017B9F34: MOV x20, x2                | X20 = doc;//m1                          
            // 0x017B9F38: MOV x19, x1                | X19 = info;//m1                         
            // 0x017B9F3C: MOV x21, x0                | X21 = 1152921513632779232 (0x1000000219FCCBE0);//ML01
            // 0x017B9F40: TBNZ w8, #0, #0x17b9f5c    | if (static_value_03738958 == true) goto label_0;
            // 0x017B9F44: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x017B9F48: LDR x8, [x8, #0x80]        | X8 = 0x2B8B02C;                         
            // 0x017B9F4C: LDR w0, [x8]               | W0 = 0x2C9;                             
            // 0x017B9F50: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C9, ????);      
            // 0x017B9F54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9F58: STRB w8, [x22, #0x958]     | static_value_03738958 = true;            //  dest_result_addr=57903448
            label_0:
            // 0x017B9F5C: ADRP x23, #0x3654000       | X23 = 56967168 (0x3654000);             
            // 0x017B9F60: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x017B9F64: LDR x23, [x23, #0xe8]      | X23 = (string**)(1152921513632754784)("supports-screens");
            // 0x017B9F68: LDR x8, [x8, #0x710]       | X8 = (string**)(1152921513632754896)("android:smallScreens");
            // 0x017B9F6C: MOV x0, x21                | X0 = 1152921513632779232 (0x1000000219FCCBE0);//ML01
            // 0x017B9F70: MOV x1, x20                | X1 = doc;//m1                           
            // 0x017B9F74: LDR x2, [x23]              | X2 = "supports-screens";                
            // 0x017B9F78: LDR x3, [x8]               | X3 = "android:smallScreens";            
            // 0x017B9F7C: BL #0x17b9cec              | X0 = this.readBoolean(doc:  doc, tag:  "supports-screens", attribute:  "android:smallScreens");
            bool val_1 = this.readBoolean(doc:  doc, tag:  "supports-screens", attribute:  "android:smallScreens");
            // 0x017B9F80: MOV w22, w0                | W22 = val_1;//m1                        
            // 0x017B9F84: CBNZ x19, #0x17b9f8c       | if (info != null) goto label_1;         
            if(info != null)
            {
                goto label_1;
            }
            // 0x017B9F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_1:
            // 0x017B9F8C: ADRP x9, #0x367e000        | X9 = 57139200 (0x367E000);              
            // 0x017B9F90: LDR x9, [x9, #0xca0]       | X9 = (string**)(1152921513632755008)("android:normalScreens");
            // 0x017B9F94: AND w8, w22, #1            | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x017B9F98: STRB w8, [x19, #0x79]      | info.supportSmallScreens = (val_1 & 1);  //  dest_result_addr=0
            info.supportSmallScreens = val_2;
            // 0x017B9F9C: LDR x2, [x23]              | X2 = "supports-screens";                
            // 0x017B9FA0: LDR x3, [x9]               | X3 = "android:normalScreens";           
            // 0x017B9FA4: MOV x0, x21                | X0 = 1152921513632779232 (0x1000000219FCCBE0);//ML01
            // 0x017B9FA8: MOV x1, x20                | X1 = doc;//m1                           
            // 0x017B9FAC: BL #0x17b9cec              | X0 = this.readBoolean(doc:  doc, tag:  "supports-screens", attribute:  "android:normalScreens");
            bool val_3 = this.readBoolean(doc:  doc, tag:  "supports-screens", attribute:  "android:normalScreens");
            // 0x017B9FB0: MOV w22, w0                | W22 = val_3;//m1                        
            // 0x017B9FB4: CBNZ x19, #0x17b9fbc       | if (info != null) goto label_2;         
            if(info != null)
            {
                goto label_2;
            }
            // 0x017B9FB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_2:
            // 0x017B9FBC: ADRP x9, #0x366a000        | X9 = 57057280 (0x366A000);              
            // 0x017B9FC0: LDR x9, [x9, #0x718]       | X9 = (string**)(1152921513632755120)("android:largeScreens");
            // 0x017B9FC4: AND w8, w22, #1            | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x017B9FC8: STRB w8, [x19, #0x7a]      | info.supportNormalScreens = (val_3 & 1);  //  dest_result_addr=0
            info.supportNormalScreens = val_4;
            // 0x017B9FCC: LDR x2, [x23]              | X2 = "supports-screens";                
            // 0x017B9FD0: LDR x3, [x9]               | X3 = "android:largeScreens";            
            // 0x017B9FD4: MOV x0, x21                | X0 = 1152921513632779232 (0x1000000219FCCBE0);//ML01
            // 0x017B9FD8: MOV x1, x20                | X1 = doc;//m1                           
            // 0x017B9FDC: BL #0x17b9cec              | X0 = this.readBoolean(doc:  doc, tag:  "supports-screens", attribute:  "android:largeScreens");
            bool val_5 = this.readBoolean(doc:  doc, tag:  "supports-screens", attribute:  "android:largeScreens");
            // 0x017B9FE0: MOV w20, w0                | W20 = val_5;//m1                        
            // 0x017B9FE4: CBZ x19, #0x17b9ff8        | if (info == null) goto label_3;         
            if(info == null)
            {
                goto label_3;
            }
            // 0x017B9FE8: AND w8, w20, #1            | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x017B9FEC: MOV x20, x19               | X20 = info;//m1                         
            val_8 = info;
            // 0x017B9FF0: STRB w8, [x20, #0x7b]!     | info.supportLargeScreens = (val_5 & 1);  //  dest_result_addr=0
            info.supportLargeScreens = val_6;
            // 0x017B9FF4: B #0x17ba00c               |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x017B9FF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x017B9FFC: AND w8, w20, #1            | W8 = (val_5 & 1);                       
            bool val_7 = val_5;
            // 0x017BA000: MOVZ w20, #0x7b            | W20 = 123 (0x7B);//ML01                 
            val_8 = 123;
            // 0x017BA004: STRB w8, [x20]             | mem[123] = (val_5 & 1);                  //  dest_result_addr=123
            mem[123] = val_7;
            // 0x017BA008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_4:
            // 0x017BA00C: LDRB w8, [x19, #0x79]      | W8 = info.supportSmallScreens; //P2     
            // 0x017BA010: CBNZ w8, #0x17ba024        | if (info.supportSmallScreens == true) goto label_6;
            if(info.supportSmallScreens == true)
            {
                goto label_6;
            }
            // 0x017BA014: LDRB w8, [x19, #0x7a]      | W8 = info.supportNormalScreens; //P2    
            // 0x017BA018: CBNZ w8, #0x17ba024        | if (info.supportNormalScreens == true) goto label_6;
            if(info.supportNormalScreens == true)
            {
                goto label_6;
            }
            // 0x017BA01C: LDRB w8, [x20]             | W8 = (val_5 & 1);                       
            // 0x017BA020: CBZ w8, #0x17ba028         | if ((val_5 & 1) == false) goto label_7; 
            if(mem[123] == false)
            {
                goto label_7;
            }
            label_6:
            // 0x017BA024: STRB wzr, [x19, #0x7c]     | info.supportAnyDensity = false;          //  dest_result_addr=0
            info.supportAnyDensity = false;
            label_7:
            // 0x017BA028: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x017BA02C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x017BA030: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x017BA034: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x017BA038: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BA03C (24879164), len: 364  VirtAddr: 0x017BA03C RVA: 0x017BA03C token: 100684422 methodIndex: 45992 delegateWrapperIndex: 0 methodInvoker: 0
        public Iteedee.ApkReader.ApkInfo extractInfo(byte[] manifest_xml, byte[] resources_arsx)
        {
            //
            // Disasemble & Code
            // 0x017BA03C: STP x22, x21, [sp, #-0x30]! | stack[1152921513632965200] = ???;  stack[1152921513632965208] = ???;  //  dest_result_addr=1152921513632965200 |  dest_result_addr=1152921513632965208
            // 0x017BA040: STP x20, x19, [sp, #0x10]  | stack[1152921513632965216] = ???;  stack[1152921513632965224] = ???;  //  dest_result_addr=1152921513632965216 |  dest_result_addr=1152921513632965224
            // 0x017BA044: STP x29, x30, [sp, #0x20]  | stack[1152921513632965232] = ???;  stack[1152921513632965240] = ???;  //  dest_result_addr=1152921513632965232 |  dest_result_addr=1152921513632965240
            // 0x017BA048: ADD x29, sp, #0x20         | X29 = (1152921513632965200 + 32) = 1152921513632965232 (0x1000000219FFA270);
            // 0x017BA04C: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x017BA050: LDRB w8, [x22, #0x959]     | W8 = (bool)static_value_03738959;       
            // 0x017BA054: MOV x19, x2                | X19 = resources_arsx;//m1               
            // 0x017BA058: MOV x21, x1                | X21 = manifest_xml;//m1                 
            // 0x017BA05C: MOV x20, x0                | X20 = 1152921513632977248 (0x1000000219FFD160);//ML01
            // 0x017BA060: TBNZ w8, #0, #0x17ba07c    | if (static_value_03738959 == true) goto label_0;
            // 0x017BA064: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x017BA068: LDR x8, [x8, #0x948]       | X8 = 0x2B8B020;                         
            // 0x017BA06C: LDR w0, [x8]               | W0 = 0x2C6;                             
            // 0x017BA070: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C6, ????);      
            // 0x017BA074: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BA078: STRB w8, [x22, #0x959]     | static_value_03738959 = true;            //  dest_result_addr=57903449
            label_0:
            // 0x017BA07C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BA080: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BA084: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BA088: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BA08C: TBZ w8, #0, #0x17ba09c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x017BA090: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BA094: CBNZ w8, #0x17ba09c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x017BA098: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x017BA09C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x017BA0A0: LDR x8, [x8, #0x7e8]       | X8 = 1152921504856580096;               
            // 0x017BA0A4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.APKManifest);
            Iteedee.ApkReader.APKManifest val_1 = null;
            // 0x017BA0A8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Iteedee.ApkReader.APKManifest), ????);
            // 0x017BA0AC: MOV x22, x0                | X22 = 1152921504856580096 (0x100000000EE2A000);//ML01
            // 0x017BA0B0: BL #0x17b8588              | .ctor();                                
            val_1 = new Iteedee.ApkReader.APKManifest();
            // 0x017BA0B4: CBNZ x22, #0x17ba0bc       | if ( != 0) goto label_3;                
            if(null != 0)
            {
                goto label_3;
            }
            // 0x017BA0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_3:
            // 0x017BA0BC: MOV x0, x22                | X0 = 1152921504856580096 (0x100000000EE2A000);//ML01
            // 0x017BA0C0: MOV x1, x21                | X1 = manifest_xml;//m1                  
            // 0x017BA0C4: BL #0x17b8600              | X0 = ReadManifestFileIntoXml(manifestFileData:  manifest_xml);
            string val_2 = ReadManifestFileIntoXml(manifestFileData:  manifest_xml);
            // 0x017BA0C8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x017BA0CC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x017BA0D0: LDR x8, [x8, #0x2b0]       | X8 = 1152921504763875328;               
            // 0x017BA0D4: LDR x0, [x8]               | X0 = typeof(System.Xml.XmlDocument);    
            System.Xml.XmlDocument val_3 = null;
            // 0x017BA0D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Xml.XmlDocument), ????);
            // 0x017BA0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA0E0: MOV x22, x0                | X22 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017BA0E4: BL #0x1653434              | .ctor();                                
            val_3 = new System.Xml.XmlDocument();
            // 0x017BA0E8: CBNZ x22, #0x17ba0f0       | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x017BA0EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_4:
            // 0x017BA0F0: LDR x8, [x22]              | X8 = ;                                  
            // 0x017BA0F4: MOV x0, x22                | X0 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017BA0F8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x017BA0FC: LDR x9, [x8, #0x490]       |  //  not_find_field!1:1168
            // 0x017BA100: LDR x2, [x8, #0x498]       |  //  not_find_field!1:1176
            // 0x017BA104: BLR x9                     | X0 = mem[null + 1168]();                
            // 0x017BA108: MOV x0, x20                | X0 = 1152921513632977248 (0x1000000219FFD160);//ML01
            // 0x017BA10C: MOV x2, x19                | X2 = resources_arsx;//m1                
            // 0x017BA110: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017BA114: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017BA118: MOV x1, x22                | X1 = 1152921504763875328 (0x10000000095C1000);//ML01
            // 0x017BA11C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017BA120: B #0x17ba1a8               | return this.extractInfo(manifestXml:  val_3, resources_arsx:  resources_arsx);
            return this.extractInfo(manifestXml:  val_3, resources_arsx:  resources_arsx);
        
        }
        //
        // Offset in libil2cpp.so: 0x017BA1A8 (24879528), len: 5004  VirtAddr: 0x017BA1A8 RVA: 0x017BA1A8 token: 100684423 methodIndex: 45993 delegateWrapperIndex: 0 methodInvoker: 0
        public Iteedee.ApkReader.ApkInfo extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx)
        {
            //
            // Disasemble & Code
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_82;
            //  | 
            System.Exception val_83;
            //  | 
            Iteedee.ApkReader.ApkInfo val_84;
            //  | 
            var val_85;
            //  | 
            var val_86;
            //  | 
            int val_87;
            //  | 
            Iteedee.ApkReader.ApkInfo val_88;
            //  | 
            var val_89;
            //  | 
            System.Byte[] val_90;
            //  | 
            var val_91;
            //  | 
            string val_92;
            //  | 
            var val_93;
            //  | 
            var val_94;
            //  | 
            var val_95;
            //  | 
            var val_96;
            //  | 
            var val_97;
            //  | 
            var val_98;
            //  | 
            var val_99;
            //  | 
            int val_100;
            //  | 
            string val_101;
            //  | 
            var val_102;
            //  | 
            var val_103;
            //  | 
            var val_104;
            //  | 
            var val_105;
            //  | 
            var val_106;
            //  | 
            var val_107;
            //  | 
            var val_108;
            //  | 
            var val_109;
            //  | 
            System.Collections.Generic.List<T> val_110;
            //  | 
            var val_111;
            //  | 
            var val_112;
            //  | 
            var val_113;
            //  | 
            var val_114;
            //  | 
            var val_115;
            //  | 
            var val_116;
            //  | 
            var val_117;
            //  | 
            var val_118;
            //  | 
            var val_119;
            // 0x017BA1A8: STP x28, x27, [sp, #-0x60]! | stack[1152921513633450256] = ???;  stack[1152921513633450264] = ???;  //  dest_result_addr=1152921513633450256 |  dest_result_addr=1152921513633450264
            // 0x017BA1AC: STP x26, x25, [sp, #0x10]  | stack[1152921513633450272] = ???;  stack[1152921513633450280] = ???;  //  dest_result_addr=1152921513633450272 |  dest_result_addr=1152921513633450280
            // 0x017BA1B0: STP x24, x23, [sp, #0x20]  | stack[1152921513633450288] = ???;  stack[1152921513633450296] = ???;  //  dest_result_addr=1152921513633450288 |  dest_result_addr=1152921513633450296
            // 0x017BA1B4: STP x22, x21, [sp, #0x30]  | stack[1152921513633450304] = ???;  stack[1152921513633450312] = ???;  //  dest_result_addr=1152921513633450304 |  dest_result_addr=1152921513633450312
            // 0x017BA1B8: STP x20, x19, [sp, #0x40]  | stack[1152921513633450320] = ???;  stack[1152921513633450328] = ???;  //  dest_result_addr=1152921513633450320 |  dest_result_addr=1152921513633450328
            // 0x017BA1BC: STP x29, x30, [sp, #0x50]  | stack[1152921513633450336] = ???;  stack[1152921513633450344] = ???;  //  dest_result_addr=1152921513633450336 |  dest_result_addr=1152921513633450344
            // 0x017BA1C0: ADD x29, sp, #0x50         | X29 = (1152921513633450256 + 80) = 1152921513633450336 (0x100000021A070960);
            // 0x017BA1C4: SUB sp, sp, #0x40          | SP = (1152921513633450256 - 64) = 1152921513633450192 (0x100000021A0708D0);
            // 0x017BA1C8: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BA1CC: LDRB w8, [x19, #0x95a]     | W8 = (bool)static_value_0373895A;       
            // 0x017BA1D0: MOV x22, x2                | X22 = resources_arsx;//m1               
            // 0x017BA1D4: MOV x21, x1                | X21 = manifestXml;//m1                  
            val_82 = manifestXml;
            // 0x017BA1D8: MOV x20, x0                | X20 = 1152921513633462352 (0x100000021A073850);//ML01
            val_83 = this;
            // 0x017BA1DC: TBNZ w8, #0, #0x17ba1f8    | if (static_value_0373895A == true) goto label_0;
            // 0x017BA1E0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BA1E4: LDR x8, [x8, #0x690]       | X8 = 0x2B8B01C;                         
            // 0x017BA1E8: LDR w0, [x8]               | W0 = 0x2C5;                             
            // 0x017BA1EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C5, ????);      
            // 0x017BA1F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BA1F4: STRB w8, [x19, #0x95a]     | static_value_0373895A = true;            //  dest_result_addr=57903450
            label_0:
            // 0x017BA1F8: STP wzr, wzr, [sp, #0x38]  | stack[1152921513633450248] = 0x0;  stack[1152921513633450252] = 0x0;  //  dest_result_addr=1152921513633450248 |  dest_result_addr=1152921513633450252
            // 0x017BA1FC: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x017BA200: LDR x8, [x8, #0xfc0]       | X8 = 1152921504856526848;               
            // 0x017BA204: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkInfo); 
            Iteedee.ApkReader.ApkInfo val_1 = null;
            // 0x017BA208: STP xzr, xzr, [sp, #0x28]  | stack[1152921513633450232] = 0x0;  stack[1152921513633450240] = 0x0;  //  dest_result_addr=1152921513633450232 |  dest_result_addr=1152921513633450240
            // 0x017BA20C: STR xzr, [sp, #0x20]       | stack[1152921513633450224] = 0x0;        //  dest_result_addr=1152921513633450224
            // 0x017BA210: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Iteedee.ApkReader.ApkInfo), ????);
            // 0x017BA214: MOV x19, x0                | X19 = 1152921504856526848 (0x100000000EE1D000);//ML01
            val_84 = val_1;
            // 0x017BA218: BL #0x17b7fa8              | .ctor();                                
            val_1 = new Iteedee.ApkReader.ApkInfo();
            // 0x017BA21C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA220: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA224: LDR x24, [x20, #0x10]      | X24 = this.VER_ICN; //P2                
            // 0x017BA228: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_85 = null;
            // 0x017BA22C: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BA230: TBZ w8, #0, #0x17ba24c     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x017BA234: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BA238: CBNZ w8, #0x17ba24c        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x017BA23C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BA240: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA244: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA248: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_85 = null;
            label_2:
            // 0x017BA24C: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
            // 0x017BA250: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA254: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
            // 0x017BA258: LDRSW x25, [x8]            | X25 = Iteedee.ApkReader.ApkReader.VER_ID;
            // 0x017BA25C: LDR x0, [x26]              | X0 = typeof(System.String);             
            val_86 = null;
            // 0x017BA260: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BA264: TBZ w8, #0, #0x17ba278     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x017BA268: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BA26C: CBNZ w8, #0x17ba278        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x017BA270: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017BA274: LDR x0, [x26]              | X0 = typeof(System.String);             
            val_86 = null;
            label_4:
            // 0x017BA278: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BA27C: LDR x23, [x8]              | X23 = System.String.Empty;              
            // 0x017BA280: CBNZ x24, #0x17ba288       | if (this.VER_ICN != null) goto label_5; 
            if(this.VER_ICN != null)
            {
                goto label_5;
            }
            // 0x017BA284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_5:
            // 0x017BA288: CBZ x23, #0x17ba2ac        | if (System.String.Empty == null) goto label_7;
            if(System.String.Empty == null)
            {
                goto label_7;
            }
            // 0x017BA28C: LDR x8, [x24]              | X8 = typeof(System.String[]);           
            // 0x017BA290: MOV x0, x23                | X0 = System.String.Empty;//m1           
            // 0x017BA294: LDR x1, [x8, #0x30]        | X1 = System.String[].__il2cppRuntimeField_element_class;
            // 0x017BA298: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x017BA29C: CBNZ x0, #0x17ba2ac        | if (System.String.Empty != null) goto label_7;
            if(System.String.Empty != null)
            {
                goto label_7;
            }
            // 0x017BA2A0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x017BA2A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA2A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_7:
            // 0x017BA2AC: LDR w8, [x24, #0x18]       | W8 = this.VER_ICN.Length; //P2          
            // 0x017BA2B0: CMP w25, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.VER_ID, this.VER_ICN.Length)
            // 0x017BA2B4: B.LO #0x17ba2c4            | if (Iteedee.ApkReader.ApkReader.VER_ID < this.VER_ICN.Length) goto label_8;
            if(Iteedee.ApkReader.ApkReader.VER_ID < this.VER_ICN.Length)
            {
                goto label_8;
            }
            // 0x017BA2B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x017BA2BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA2C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_8:
            // 0x017BA2C4: ADD x8, x24, x25, lsl #3   | X8 = this.VER_ICN[Iteedee.ApkReader.ApkReader.VER_ID]; //PARR1 
            // 0x017BA2C8: STR x23, [x8, #0x20]       | this.VER_ICN[Iteedee.ApkReader.ApkReader.VER_ID][0] = System.String.Empty;  //  dest_result_addr=0
            this.VER_ICN[Iteedee.ApkReader.ApkReader.VER_ID] = System.String.Empty;
            // 0x017BA2CC: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA2D0: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA2D4: LDR x9, [x26]              | X9 = typeof(System.String);             
            // 0x017BA2D8: LDR x24, [x20, #0x10]      | X24 = this.VER_ICN; //P2                
            // 0x017BA2DC: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.ApkReader);
            // 0x017BA2E0: LDR x9, [x9, #0xa0]        | X9 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BA2E4: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA2E8: LDR x23, [x9]              | X23 = System.String.Empty;              
            // 0x017BA2EC: LDRSW x25, [x8, #4]        | X25 = Iteedee.ApkReader.ApkReader.ICN_ID;
            // 0x017BA2F0: CBNZ x24, #0x17ba2f8       | if (this.VER_ICN != null) goto label_9; 
            if(this.VER_ICN != null)
            {
                goto label_9;
            }
            // 0x017BA2F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.String.Empty, ????);
            label_9:
            // 0x017BA2F8: CBZ x23, #0x17ba31c        | if (System.String.Empty == null) goto label_11;
            if(System.String.Empty == null)
            {
                goto label_11;
            }
            // 0x017BA2FC: LDR x8, [x24]              | X8 = typeof(System.String[]);           
            // 0x017BA300: MOV x0, x23                | X0 = System.String.Empty;//m1           
            // 0x017BA304: LDR x1, [x8, #0x30]        | X1 = System.String[].__il2cppRuntimeField_element_class;
            // 0x017BA308: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x017BA30C: CBNZ x0, #0x17ba31c        | if (System.String.Empty != null) goto label_11;
            if(System.String.Empty != null)
            {
                goto label_11;
            }
            // 0x017BA310: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x017BA314: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA318: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_11:
            // 0x017BA31C: LDR w8, [x24, #0x18]       | W8 = this.VER_ICN.Length; //P2          
            // 0x017BA320: CMP w25, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.ICN_ID, this.VER_ICN.Length)
            // 0x017BA324: B.LO #0x17ba334            | if (Iteedee.ApkReader.ApkReader.ICN_ID < this.VER_ICN.Length) goto label_12;
            if(Iteedee.ApkReader.ApkReader.ICN_ID < this.VER_ICN.Length)
            {
                goto label_12;
            }
            // 0x017BA328: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x017BA32C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA330: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_12:
            // 0x017BA334: ADD x8, x24, x25, lsl #3   | X8 = this.VER_ICN[Iteedee.ApkReader.ApkReader.ICN_ID]; //PARR1 
            // 0x017BA338: STR x23, [x8, #0x20]       | this.VER_ICN[Iteedee.ApkReader.ApkReader.ICN_ID][0] = System.String.Empty;  //  dest_result_addr=0
            this.VER_ICN[Iteedee.ApkReader.ApkReader.ICN_ID] = System.String.Empty;
            // 0x017BA33C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA340: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA344: LDR x9, [x26]              | X9 = typeof(System.String);             
            // 0x017BA348: LDR x24, [x20, #0x10]      | X24 = this.VER_ICN; //P2                
            // 0x017BA34C: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.ApkReader);
            // 0x017BA350: LDR x9, [x9, #0xa0]        | X9 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BA354: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA358: LDR x23, [x9]              | X23 = System.String.Empty;              
            // 0x017BA35C: LDRSW x25, [x8, #8]        | X25 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            val_87 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            // 0x017BA360: CBNZ x24, #0x17ba368       | if (this.VER_ICN != null) goto label_13;
            if(this.VER_ICN != null)
            {
                goto label_13;
            }
            // 0x017BA364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.String.Empty, ????);
            label_13:
            // 0x017BA368: CBZ x23, #0x17ba38c        | if (System.String.Empty == null) goto label_15;
            if(System.String.Empty == null)
            {
                goto label_15;
            }
            // 0x017BA36C: LDR x8, [x24]              | X8 = typeof(System.String[]);           
            // 0x017BA370: MOV x0, x23                | X0 = System.String.Empty;//m1           
            // 0x017BA374: LDR x1, [x8, #0x30]        | X1 = System.String[].__il2cppRuntimeField_element_class;
            // 0x017BA378: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x017BA37C: CBNZ x0, #0x17ba38c        | if (System.String.Empty != null) goto label_15;
            if(System.String.Empty != null)
            {
                goto label_15;
            }
            // 0x017BA380: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x017BA384: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA388: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_15:
            // 0x017BA38C: LDR w8, [x24, #0x18]       | W8 = this.VER_ICN.Length; //P2          
            // 0x017BA390: CMP w25, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.LABEL_ID, this.VER_ICN.Length)
            // 0x017BA394: B.LO #0x17ba3a4            | if (val_87 < this.VER_ICN.Length) goto label_16;
            if(val_87 < this.VER_ICN.Length)
            {
                goto label_16;
            }
            // 0x017BA398: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x017BA39C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA3A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_16:
            // 0x017BA3A4: ADD x8, x24, x25, lsl #3   | X8 = this.VER_ICN[Iteedee.ApkReader.ApkReader.LABEL_ID]; //PARR1 
            // 0x017BA3A8: STR x23, [x8, #0x20]       | this.VER_ICN[Iteedee.ApkReader.ApkReader.LABEL_ID][0] = System.String.Empty;  //  dest_result_addr=0
            this.VER_ICN[val_87] = System.String.Empty;
            // 0x017BA3AC: CBZ x21, #0x17ba3d4        | if (manifestXml == null) goto label_17; 
            if(val_82 == null)
            {
                goto label_17;
            }
            // 0x017BA3B0: CBNZ x19, #0x17ba490       | if ( != 0) goto label_18;               
            if(null != 0)
            {
                goto label_18;
            }
            // 0x017BA3B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.String.Empty, ????);
            // 0x017BA3B8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x017BA3BC: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921513633294624)("resources.arsx");
            // 0x017BA3C0: MOVZ w9, #0x68             | W9 = 104 (0x68);//ML01                  
            // 0x017BA3C4: LDR x8, [x8]               | X8 = "resources.arsx";                  
            // 0x017BA3C8: STR x8, [x9]               | mem[104] = "resources.arsx";             //  dest_result_addr=104
            mem[104] = "resources.arsx";
            // 0x017BA3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? System.String.Empty, ????);
            // 0x017BA3D0: B #0x17ba4a0               |  goto label_19;                         
            goto label_19;
            label_17:
            // 0x017BA3D4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BA3D8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BA3DC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BA3E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BA3E4: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BA3E8: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x017BA3EC: LDR x8, [x8, #0xed0]       | X8 = (string**)(1152921513633294720)("Document initialize failed");
            // 0x017BA3F0: LDR x1, [x8]               | X1 = "Document initialize failed";      
            // 0x017BA3F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA3F8: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_2 = null;
            // 0x017BA3FC: BL #0x1c32b48              | .ctor(message:  "Document initialize failed");
            val_2 = new System.Exception(message:  "Document initialize failed");
            // 0x017BA400: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x017BA404: LDR x8, [x8, #0x9e8]       | X8 = 1152921513633294848;               
            // 0x017BA408: LDR x1, [x8]               | X1 = public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx);
            // 0x017BA40C: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BA410: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BA414: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_3 = System.Collections.IEnumerable.GetEnumerator();
            // 0x017BA418: B #0x17ba41c               |  goto label_20;                         
            goto label_20;
            label_20:
            // 0x017BA41C: MOV x21, x0                | X21 = val_3;//m1                        
            val_88 = val_3;
            label_149:
            // 0x017BA420: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BA424: CMP w1, w8                 | STATE = COMPARE(public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx), 0x1)
            // 0x017BA428: B.NE #0x17bb44c            | if (public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx) != 1) goto label_21;
            if((public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx)) != 1)
            {
                goto label_21;
            }
            // 0x017BA42C: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x017BA430: BL #0x981060               | X0 = sub_981060( ?? val_3, ????);       
            // 0x017BA434: MOV x19, x0                | X19 = val_3;//m1                        
            val_84 = val_88;
            // 0x017BA438: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BA43C: LDR x20, [x19]             | X20 = typeof(System.Collections.IEnumerator);
            // 0x017BA440: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BA444: LDR x1, [x20]              | X1 = ;                                  
            // 0x017BA448: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BA44C: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
            // 0x017BA450: TBZ w0, #0, #0x17ba470     | if ((typeof(System.Exception) & 0x1) == 0) goto label_22;
            if((null & 1) == 0)
            {
                goto label_22;
            }
            // 0x017BA454: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
            // 0x017BA458: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x017BA45C: LDR x8, [x8, #0x9e8]       | X8 = 1152921513633294848;               
            // 0x017BA460: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x017BA464: LDR x1, [x8]               | X1 = public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx);
            // 0x017BA468: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.IEnumerator), ????);
            // 0x017BA46C: BL #0x17b754c              | X0 = 1152921504608018432.System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_4 = 1152921504608018432.System.Collections.IEnumerable.GetEnumerator();
            label_22:
            // 0x017BA470: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x017BA474: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x017BA478: LDR x8, [x19]              | X8 = typeof(System.Collections.IEnumerator);
            // 0x017BA47C: STR x8, [x0]               | mem[8] = typeof(System.Collections.IEnumerator);  //  dest_result_addr=8
            mem[8] = null;
            // 0x017BA480: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x017BA484: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA488: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x017BA48C: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            label_18:
            // 0x017BA490: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x017BA494: LDR x8, [x8, #0xdf0]       | X8 = (string**)(1152921513633294624)("resources.arsx");
            // 0x017BA498: LDR x8, [x8]               | X8 = "resources.arsx";                  
            // 0x017BA49C: STR x8, [x19, #0x68]       | mem2[0] = "resources.arsx";              //  dest_result_addr=0
            mem2[0] = "resources.arsx";
            label_19:
            // 0x017BA4A0: STR x22, [x19, #0x70]      | mem2[0] = resources_arsx;                //  dest_result_addr=0
            mem2[0] = resources_arsx;
            // 0x017BA4A4: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x017BA4A8: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x017BA4AC: MOV x2, x21                | X2 = val_3;//m1                         
            // 0x017BA4B0: BL #0x17b9a8c              | this.extractPermissions(info:  val_84, doc:  val_88);
            this.extractPermissions(info:  val_84, doc:  val_88);
            // 0x017BA4B4: ADRP x22, #0x3630000       | X22 = 56819712 (0x3630000);             
            // 0x017BA4B8: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x017BA4BC: LDR x22, [x22, #0x3f8]     | X22 = (string**)(1152921513633304064)("uses-sdk");
            // 0x017BA4C0: LDR x8, [x8, #0x928]       | X8 = (string**)(1152921513633304160)("minSdkVersion");
            // 0x017BA4C4: LDR x2, [x22]              | X2 = "uses-sdk";                        
            // 0x017BA4C8: LDR x3, [x8]               | X3 = "minSdkVersion";                   
            // 0x017BA4CC: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA4D0: BL #0x17b9dfc              | X0 = this.FindInDocument(doc:  val_88, keyName:  "uses-sdk", attribName:  "minSdkVersion");
            string val_5 = this.FindInDocument(doc:  val_88, keyName:  "uses-sdk", attribName:  "minSdkVersion");
            // 0x017BA4D4: STR x0, [x19, #0x28]       | mem2[0] = val_5;                         //  dest_result_addr=0
            mem2[0] = val_5;
            // 0x017BA4D8: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017BA4DC: LDR x8, [x8, #0xaa0]       | X8 = (string**)(1152921513633308352)("targetSdkVersion");
            // 0x017BA4E0: LDR x2, [x22]              | X2 = "uses-sdk";                        
            // 0x017BA4E4: LDR x3, [x8]               | X3 = "targetSdkVersion";                
            // 0x017BA4E8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA4EC: BL #0x17b9dfc              | X0 = val_5.FindInDocument(doc:  val_88, keyName:  "uses-sdk", attribName:  "targetSdkVersion");
            string val_6 = val_5.FindInDocument(doc:  val_88, keyName:  "uses-sdk", attribName:  "targetSdkVersion");
            // 0x017BA4F0: STR x0, [x19, #0x30]       | mem2[0] = val_6;                         //  dest_result_addr=0
            mem2[0] = val_6;
            // 0x017BA4F4: ADRP x22, #0x35bd000       | X22 = 56348672 (0x35BD000);             
            // 0x017BA4F8: ADRP x28, #0x366f000       | X28 = 57077760 (0x366F000);             
            // 0x017BA4FC: LDR x22, [x22, #0xff8]     | X22 = (string**)(1152921513632013408)("manifest");
            // 0x017BA500: LDR x28, [x28, #0x2a0]     | X28 = (string**)(1152921513633312560)("versionCode");
            // 0x017BA504: LDR x2, [x22]              | X2 = "manifest";                        
            // 0x017BA508: LDR x3, [x28]              | X3 = "versionCode";                     
            // 0x017BA50C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA510: BL #0x17b9dfc              | X0 = val_6.FindInDocument(doc:  val_88, keyName:  "manifest", attribName:  "versionCode");
            string val_7 = val_6.FindInDocument(doc:  val_88, keyName:  "manifest", attribName:  "versionCode");
            // 0x017BA514: STR x0, [x19, #0x20]       | mem2[0] = val_7;                         //  dest_result_addr=0
            mem2[0] = val_7;
            // 0x017BA518: ADRP x27, #0x3661000       | X27 = 57020416 (0x3661000);             
            // 0x017BA51C: LDR x27, [x27, #0x9a8]     | X27 = (string**)(1152921513633316752)("versionName");
            val_89 = "versionName";
            // 0x017BA520: LDR x2, [x22]              | X2 = "manifest";                        
            // 0x017BA524: LDR x3, [x27]              | X3 = "versionName";                     
            // 0x017BA528: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA52C: BL #0x17b9dfc              | X0 = val_7.FindInDocument(doc:  val_88, keyName:  "manifest", attribName:  "versionName");
            string val_8 = val_7.FindInDocument(doc:  val_88, keyName:  "manifest", attribName:  "versionName");
            // 0x017BA530: STR x0, [x19, #0x18]       | mem2[0] = val_8;                         //  dest_result_addr=0
            mem2[0] = val_8;
            // 0x017BA534: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x017BA538: LDR x8, [x8, #0xf10]       | X8 = (string**)(1152921509743370080)("package");
            // 0x017BA53C: LDR x2, [x22]              | X2 = "manifest";                        
            // 0x017BA540: LDR x3, [x8]               | X3 = "package";                         
            // 0x017BA544: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA548: BL #0x17b9dfc              | X0 = val_8.FindInDocument(doc:  val_88, keyName:  "manifest", attribName:  "package");
            string val_9 = val_8.FindInDocument(doc:  val_88, keyName:  "manifest", attribName:  "package");
            // 0x017BA54C: STR x0, [x19, #0x38]       | mem2[0] = val_9;                         //  dest_result_addr=0
            mem2[0] = val_9;
            // 0x017BA550: ADRP x26, #0x35d7000       | X26 = 56455168 (0x35D7000);             
            // 0x017BA554: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x017BA558: LDR x26, [x26, #0x9b0]     | X26 = (string**)(1152921513632013504)("application");
            // 0x017BA55C: LDR x8, [x8, #0x4d0]       | X8 = (string**)(1152921511251182064)("label");
            // 0x017BA560: LDR x2, [x26]              | X2 = "application";                     
            // 0x017BA564: LDR x3, [x8]               | X3 = "label";                           
            // 0x017BA568: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA56C: BL #0x17b9dfc              | X0 = val_9.FindInDocument(doc:  val_88, keyName:  "application", attribName:  "label");
            string val_10 = val_9.FindInDocument(doc:  val_88, keyName:  "application", attribName:  "label");
            // 0x017BA570: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x017BA574: STR x22, [x19, #0x10]      | mem2[0] = val_10;                        //  dest_result_addr=0
            mem2[0] = val_10;
            // 0x017BA578: CBNZ x22, #0x17ba580       | if (val_10 != null) goto label_23;      
            if(val_10 != null)
            {
                goto label_23;
            }
            // 0x017BA57C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_23:
            // 0x017BA580: ADRP x23, #0x35e7000       | X23 = 56520704 (0x35E7000);             
            // 0x017BA584: LDR x23, [x23, #0xf68]     | X23 = (string**)(1152921512830278272)("@");
            val_90 = "@";
            // 0x017BA588: LDR x1, [x23]              | X1 = "@";                               
            string val_12 = "@";
            // 0x017BA58C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA590: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x017BA594: BL #0x18add38              | X0 = val_10.StartsWith(value:  "@");    
            bool val_11 = val_10.StartsWith(value:  val_12);
            // 0x017BA598: TBZ w0, #0, #0x17ba62c     | if (val_11 == false) goto label_24;     
            if(val_11 == false)
            {
                goto label_24;
            }
            // 0x017BA59C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA5A0: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA5A4: LDR x24, [x20, #0x10]      | X24 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BA5A8: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_91 = null;
            // 0x017BA5AC: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BA5B0: TBZ w8, #0, #0x17ba5cc     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x017BA5B4: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BA5B8: CBNZ w8, #0x17ba5cc        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x017BA5BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BA5C0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA5C4: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA5C8: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_91 = null;
            label_26:
            // 0x017BA5CC: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA5D0: LDRSW x25, [x8, #8]        | X25 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            val_87 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            // 0x017BA5D4: CBNZ x19, #0x17ba5dc       | if (val_3 != null) goto label_27;       
            if(val_84 != null)
            {
                goto label_27;
            }
            // 0x017BA5D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_27:
            // 0x017BA5DC: LDR x22, [x19, #0x10]      | 
            // 0x017BA5E0: CBNZ x24, #0x17ba5e8       | if (IEnumerator != null) goto label_28; 
            if(IEnumerator != null)
            {
                goto label_28;
            }
            // 0x017BA5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_28:
            // 0x017BA5E8: CBZ x22, #0x17ba60c        | if (val_10 == null) goto label_30;      
            if(val_10 == null)
            {
                goto label_30;
            }
            // 0x017BA5EC: LDR x8, [x24]              | X8 = IEnumerator;                       
            // 0x017BA5F0: LDR x1, [x8, #0x30]        | 
            // 0x017BA5F4: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x017BA5F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x017BA5FC: CBNZ x0, #0x17ba60c        | if (val_10 != null) goto label_30;      
            if(val_10 != null)
            {
                goto label_30;
            }
            // 0x017BA600: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x017BA604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA608: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_30:
            // 0x017BA60C: LDR w8, [x24, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BA610: CMP w25, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.LABEL_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BA614: B.LO #0x17ba624            | if (val_87 < IEnumerator.__il2cppRuntimeField_18) goto label_31;
            // 0x017BA618: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x017BA61C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA620: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_31:
            // 0x017BA624: ADD x8, x24, x25, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_
            // 0x017BA628: B #0x17ba728               |  goto label_32;                         
            goto label_32;
            label_24:
            // 0x017BA62C: CBNZ x19, #0x17ba634       | if (val_3 != null) goto label_33;       
            if(val_84 != null)
            {
                goto label_33;
            }
            // 0x017BA630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_33:
            // 0x017BA634: LDR x1, [x19, #0x10]       | 
            // 0x017BA638: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BA63C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BA640: ADD x2, sp, #0x3c          | X2 = (1152921513633450192 + 60) = 1152921513633450252 (0x100000021A07090C);
            // 0x017BA644: BL #0x1e63c5c              | X0 = System.Int32.TryParse(s:  0, result: out  val_12);
            bool val_13 = System.Int32.TryParse(s:  0, result: out  val_12);
            // 0x017BA648: TBZ w0, #0, #0x17ba72c     | if (val_13 == false) goto label_34;     
            if(val_13 == false)
            {
                goto label_34;
            }
            // 0x017BA64C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA650: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA654: LDR x25, [x20, #0x10]      | X25 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BA658: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_94 = null;
            // 0x017BA65C: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BA660: TBZ w8, #0, #0x17ba67c     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_36;
            // 0x017BA664: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BA668: CBNZ w8, #0x17ba67c        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_36;
            // 0x017BA66C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BA670: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA674: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA678: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_94 = null;
            label_36:
            // 0x017BA67C: ADRP x9, #0x364c000        | X9 = 56934400 (0x364C000);              
            // 0x017BA680: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA684: LDR x9, [x9, #0x658]       | X9 = (string**)(1152921509750944816)("X4");
            // 0x017BA688: LDRSW x24, [x8, #8]        | X24 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            // 0x017BA68C: LDR x1, [x9]               | X1 = "X4";                              
            // 0x017BA690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA694: ADD x0, sp, #0x3c          | X0 = (1152921513633450192 + 60) = 1152921513633450252 (0x100000021A07090C);
            // 0x017BA698: BL #0x1e63df8              | X0 = 0.ToString(format:  "X4");         
            string val_14 = 0.ToString(format:  "X4");
            // 0x017BA69C: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x017BA6A0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BA6A4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BA6A8: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BA6AC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BA6B0: TBZ w8, #0, #0x17ba6c0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_38;
            // 0x017BA6B4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BA6B8: CBNZ w8, #0x17ba6c0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x017BA6BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_38:
            // 0x017BA6C0: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x017BA6C4: LDR x8, [x8, #0x4f0]       | X8 = (string**)(1152921513633333232)("@{0}");
            // 0x017BA6C8: LDR x1, [x8]               | X1 = "@{0}";                            
            // 0x017BA6CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BA6D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BA6D4: MOV x2, x22                | X2 = val_14;//m1                        
            // 0x017BA6D8: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "@{0}");
            string val_15 = System.String.Format(format:  0, arg0:  "@{0}");
            // 0x017BA6DC: MOV x22, x0                | X22 = val_15;//m1                       
            val_92 = val_15;
            // 0x017BA6E0: CBNZ x25, #0x17ba6e8       | if (IEnumerator != null) goto label_39; 
            if(IEnumerator != null)
            {
                goto label_39;
            }
            // 0x017BA6E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_39:
            // 0x017BA6E8: CBZ x22, #0x17ba70c        | if (val_15 == null) goto label_41;      
            if(val_92 == null)
            {
                goto label_41;
            }
            // 0x017BA6EC: LDR x8, [x25]              | X8 = IEnumerator;                       
            // 0x017BA6F0: LDR x1, [x8, #0x30]        | 
            // 0x017BA6F4: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x017BA6F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x017BA6FC: CBNZ x0, #0x17ba70c        | if (val_15 != null) goto label_41;      
            if(val_92 != null)
            {
                goto label_41;
            }
            // 0x017BA700: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x017BA704: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA708: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_41:
            // 0x017BA70C: LDR w8, [x25, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BA710: CMP w24, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.LABEL_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BA714: B.LO #0x17ba724            | if (Iteedee.ApkReader.ApkReader.LABEL_ID < IEnumerator.__il2cppRuntimeField_18) goto label_42;
            // 0x017BA718: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x017BA71C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA720: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_42:
            // 0x017BA724: ADD x8, x25, x24, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_
            label_32:
            // 0x017BA728: STR x22, [x8, #0x20]       | (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3).__unknownFiledOffset_20 = val_15;  //  dest_result_addr=0
            (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3).__unknownFiledOffset_20 = val_92;
            label_34:
            // 0x017BA72C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x017BA730: LDR x2, [x26]              | X2 = "application";                     
            // 0x017BA734: LDR x8, [x8, #0x6f0]       | X8 = (string**)(1152921513633337408)("debuggable");
            // 0x017BA738: LDR x3, [x8]               | X3 = "debuggable";                      
            // 0x017BA73C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA740: BL #0x17b9dfc              | X0 = val_15.FindInDocument(doc:  val_88, keyName:  "application", attribName:  "debuggable");
            string val_16 = val_92.FindInDocument(doc:  val_88, keyName:  "application", attribName:  "debuggable");
            // 0x017BA744: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x017BA748: CBNZ x19, #0x17ba750       | if (val_3 != null) goto label_43;       
            if(val_84 != null)
            {
                goto label_43;
            }
            // 0x017BA74C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_43:
            // 0x017BA750: STR x22, [x19, #0x40]      | mem2[0] = val_16;                        //  dest_result_addr=0
            mem2[0] = val_16;
            // 0x017BA754: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x017BA758: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x017BA75C: MOV x2, x21                | X2 = val_3;//m1                         
            // 0x017BA760: BL #0x17b9f18              | this.extractSupportScreens(info:  val_84, doc:  val_88);
            this.extractSupportScreens(info:  val_84, doc:  val_88);
            // 0x017BA764: LDR x8, [x19, #0x20]       | 
            // 0x017BA768: CBNZ x8, #0x17ba780        | if ("debuggable" != 0) goto label_44;   
            if("debuggable" != 0)
            {
                goto label_44;
            }
            // 0x017BA76C: LDR x3, [x28]              | X3 = "versionCode";                     
            // 0x017BA770: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x017BA774: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA778: BL #0x17b9804              | X0 = this.fuzzFindInDocument(doc:  val_88, tag:  val_88, attr:  "versionCode");
            string val_17 = this.fuzzFindInDocument(doc:  val_88, tag:  val_88, attr:  "versionCode");
            // 0x017BA77C: STR x0, [x19, #0x20]       | mem2[0] = val_17;                        //  dest_result_addr=0
            mem2[0] = val_17;
            label_44:
            // 0x017BA780: LDR x0, [x19, #0x18]       | 
            // 0x017BA784: CBZ x0, #0x17ba824         | if (val_17 == null) goto label_45;      
            if(val_17 == null)
            {
                goto label_45;
            }
            // 0x017BA788: LDR x1, [x23]              | X1 = "@";                               
            // 0x017BA78C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA790: BL #0x18add38              | X0 = val_17.StartsWith(value:  "@");    
            bool val_18 = val_17.StartsWith(value:  "@");
            // 0x017BA794: TBZ w0, #0, #0x17ba838     | if (val_18 == false) goto label_53;     
            if(val_18 == false)
            {
                goto label_53;
            }
            // 0x017BA798: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA79C: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA7A0: LDR x24, [x20, #0x10]      | X24 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BA7A4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_95 = null;
            // 0x017BA7A8: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BA7AC: TBZ w8, #0, #0x17ba7c8     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_48;
            // 0x017BA7B0: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BA7B4: CBNZ w8, #0x17ba7c8        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_48;
            // 0x017BA7B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BA7BC: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA7C0: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA7C4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_95 = null;
            label_48:
            // 0x017BA7C8: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA7CC: LDR x22, [x19, #0x18]      | 
            // 0x017BA7D0: LDRSW x25, [x8]            | X25 = Iteedee.ApkReader.ApkReader.VER_ID;
            val_87 = Iteedee.ApkReader.ApkReader.VER_ID;
            // 0x017BA7D4: CBNZ x24, #0x17ba7dc       | if (IEnumerator != null) goto label_49; 
            if(IEnumerator != null)
            {
                goto label_49;
            }
            // 0x017BA7D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_49:
            // 0x017BA7DC: CBZ x22, #0x17ba800        | if (val_16 == null) goto label_51;      
            if(val_16 == null)
            {
                goto label_51;
            }
            // 0x017BA7E0: LDR x8, [x24]              | X8 = IEnumerator;                       
            // 0x017BA7E4: LDR x1, [x8, #0x30]        | 
            // 0x017BA7E8: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x017BA7EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x017BA7F0: CBNZ x0, #0x17ba800        | if (val_16 != null) goto label_51;      
            if(val_16 != null)
            {
                goto label_51;
            }
            // 0x017BA7F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x017BA7F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA7FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_51:
            // 0x017BA800: LDR w8, [x24, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BA804: CMP w25, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.VER_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BA808: B.LO #0x17ba818            | if (val_87 < IEnumerator.__il2cppRuntimeField_18) goto label_52;
            // 0x017BA80C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x017BA810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA814: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_52:
            // 0x017BA818: ADD x8, x24, x25, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID
            // 0x017BA81C: STR x22, [x8, #0x20]       | (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3).__unknownFiledOffset_20 = val_16;  //  dest_result_addr=0
            (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3).__unknownFiledOffset_20 = val_16;
            // 0x017BA820: B #0x17ba838               |  goto label_53;                         
            goto label_53;
            label_45:
            // 0x017BA824: LDR x3, [x27]              | X3 = "versionName";                     
            // 0x017BA828: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x017BA82C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA830: BL #0x17b9804              | X0 = this.fuzzFindInDocument(doc:  val_88, tag:  val_88, attr:  "versionName");
            string val_20 = this.fuzzFindInDocument(doc:  val_88, tag:  val_88, attr:  "versionName");
            // 0x017BA834: STR x0, [x19, #0x18]       | mem2[0] = val_20;                        //  dest_result_addr=0
            mem2[0] = val_20;
            label_53:
            // 0x017BA838: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x017BA83C: LDR x2, [x26]              | X2 = "application";                     
            // 0x017BA840: LDR x8, [x8, #0xa70]       | X8 = (string**)(1152921513633349792)("android:icon");
            // 0x017BA844: LDR x3, [x8]               | X3 = "android:icon";                    
            // 0x017BA848: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA84C: BL #0x17b9dfc              | X0 = val_20.FindInDocument(doc:  val_88, keyName:  "application", attribName:  "android:icon");
            string val_21 = val_20.FindInDocument(doc:  val_88, keyName:  "application", attribName:  "android:icon");
            // 0x017BA850: MOV x22, x0                | X22 = val_21;//m1                       
            val_96 = val_21;
            // 0x017BA854: CBNZ x22, #0x17ba878       | if (val_21 != null) goto label_54;      
            if(val_96 != null)
            {
                goto label_54;
            }
            // 0x017BA858: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x017BA85C: LDR x8, [x8, #0xe50]       | X8 = (string**)(1152921510257790800)("icon");
            // 0x017BA860: LDR x3, [x8]               | X3 = "icon";                            
            // 0x017BA864: MOV x0, x20                | X0 = 1152921504608018432 (0x100000000011E000);//ML01
            // 0x017BA868: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x017BA86C: BL #0x17b9804              | X0 = this.fuzzFindInDocument(doc:  val_88, tag:  "application", attr:  "icon");
            string val_22 = this.fuzzFindInDocument(doc:  val_88, tag:  "application", attr:  "icon");
            // 0x017BA870: MOV x22, x0                | X22 = val_22;//m1                       
            val_96 = val_22;
            // 0x017BA874: CBZ x22, #0x17bb344        | if (val_22 == null) goto label_176;     
            if(val_96 == null)
            {
                goto label_176;
            }
            label_54:
            // 0x017BA878: CBNZ x19, #0x17ba880       | if (val_3 != null) goto label_56;       
            if(val_84 != null)
            {
                goto label_56;
            }
            // 0x017BA87C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_56:
            // 0x017BA880: LDRB w8, [x19, #0x78]      | 
            // 0x017BA884: CBNZ w8, #0x17bb344        | if ("icon" != 0) goto label_176;        
            if("icon" != 0)
            {
                goto label_176;
            }
            // 0x017BA888: CBNZ x22, #0x17ba890       | if (val_22 != null) goto label_58;      
            if(val_96 != null)
            {
                goto label_58;
            }
            // 0x017BA88C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_58:
            // 0x017BA890: ADRP x21, #0x363a000       | X21 = 56860672 (0x363A000);             
            // 0x017BA894: LDR x21, [x21, #0x400]     | X21 = (string**)(1152921513633358080)("@android:");
            // 0x017BA898: LDR x1, [x21]              | X1 = "@android:";                       
            // 0x017BA89C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA8A0: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x017BA8A4: BL #0x18add38              | X0 = val_22.StartsWith(value:  "@android:");
            bool val_23 = val_96.StartsWith(value:  "@android:");
            // 0x017BA8A8: MOV w8, w0                 | W8 = val_23;//m1                        
            // 0x017BA8AC: ADRP x9, #0x3625000        | X9 = 56774656 (0x3625000);              
            // 0x017BA8B0: LDR x9, [x9, #0x400]       | X9 = 1152921504856633344;               
            // 0x017BA8B4: LDR x26, [x20, #0x10]      | X26 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BA8B8: LDR x0, [x9]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_97 = null;
            // 0x017BA8BC: ADD x9, x0, #0x109         | X9 = (val_97 + 265) = 1152921504856633609 (0x100000000EE37109);
            // 0x017BA8C0: LDRH w9, [x9]              | W9 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_109;
            // 0x017BA8C4: AND w9, w9, #0x100         | W9 = (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_109 & 256);
            // 0x017BA8C8: TBZ w8, #0, #0x17ba9ac     | if (val_23 == false) goto label_59;     
            if(val_23 == false)
            {
                goto label_59;
            }
            // 0x017BA8CC: AND w8, w9, #0xffff        | W8 = ((Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x017BA8D0: CBZ w8, #0x17ba8ec         | if (((Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_61;
            // 0x017BA8D4: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BA8D8: CBNZ w8, #0x17ba8ec        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x017BA8DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BA8E0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA8E4: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA8E8: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_98 = null;
            label_61:
            // 0x017BA8EC: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA8F0: LDR x0, [x21]              | X0 = "@android:";                       
            val_99 = "@android:";
            // 0x017BA8F4: LDRSW x27, [x8, #4]        | X27 = Iteedee.ApkReader.ApkReader.ICN_ID;
            val_100 = Iteedee.ApkReader.ApkReader.ICN_ID;
            // 0x017BA8F8: CBNZ x0, #0x17ba904        | if ("@android:" != null) goto label_62; 
            if(("@android:") != null)
            {
                goto label_62;
            }
            // 0x017BA8FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "@android:", ????);
            // 0x017BA900: LDR x0, [x21]              | X0 = "@android:";                       
            val_99 = "@android:";
            label_62:
            // 0x017BA904: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA908: BL #0x18a4460              | X0 = get_Length();                      
            int val_26 = Length;
            // 0x017BA90C: MOV w21, w0                | W21 = val_26;//m1                       
            // 0x017BA910: CBNZ x22, #0x17ba918       | if (val_22 != null) goto label_63;      
            if(val_96 != null)
            {
                goto label_63;
            }
            // 0x017BA914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_63:
            // 0x017BA918: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA91C: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x017BA920: MOV w1, w21                | W1 = val_26;//m1                        
            // 0x017BA924: BL #0x18a5a40              | X0 = val_22.Substring(startIndex:  val_26);
            string val_27 = val_96.Substring(startIndex:  val_26);
            // 0x017BA928: MOV x21, x0                | X21 = val_27;//m1                       
            // 0x017BA92C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BA930: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BA934: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BA938: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BA93C: TBZ w8, #0, #0x17ba94c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_65;
            // 0x017BA940: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BA944: CBNZ w8, #0x17ba94c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_65;
            // 0x017BA948: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_65:
            // 0x017BA94C: LDR x1, [x23]              | X1 = "@";                               
            // 0x017BA950: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BA954: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BA958: MOV x2, x21                | X2 = val_27;//m1                        
            // 0x017BA95C: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "@");
            string val_28 = System.String.Concat(str0:  0, str1:  "@");
            // 0x017BA960: MOV x21, x0                | X21 = val_28;//m1                       
            val_101 = val_28;
            // 0x017BA964: CBNZ x26, #0x17ba96c       | if (IEnumerator != null) goto label_66; 
            if(IEnumerator != null)
            {
                goto label_66;
            }
            // 0x017BA968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_66:
            // 0x017BA96C: CBZ x21, #0x17ba990        | if (val_28 == null) goto label_68;      
            if(val_101 == null)
            {
                goto label_68;
            }
            // 0x017BA970: LDR x8, [x26]              | X8 = IEnumerator;                       
            // 0x017BA974: LDR x1, [x8, #0x30]        | 
            // 0x017BA978: MOV x0, x21                | X0 = val_28;//m1                        
            // 0x017BA97C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x017BA980: CBNZ x0, #0x17ba990        | if (val_28 != null) goto label_68;      
            if(val_101 != null)
            {
                goto label_68;
            }
            // 0x017BA984: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x017BA988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA98C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_68:
            // 0x017BA990: LDR w8, [x26, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BA994: CMP w27, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.ICN_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BA998: B.LO #0x17baaa8            | if (val_100 < IEnumerator.__il2cppRuntimeField_18) goto label_80;
            // 0x017BA99C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x017BA9A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BA9A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            // 0x017BA9A8: B #0x17baaa8               |  goto label_80;                         
            goto label_80;
            label_59:
            // 0x017BA9AC: AND w8, w9, #0xffff        | W8 = ((Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x017BA9B0: CBZ w8, #0x17ba9cc         | if (((Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_72;
            // 0x017BA9B4: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BA9B8: CBNZ w8, #0x17ba9cc        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x017BA9BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BA9C0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BA9C4: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BA9C8: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_102 = null;
            label_72:
            // 0x017BA9CC: ADRP x9, #0x3663000        | X9 = 57028608 (0x3663000);              
            // 0x017BA9D0: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BA9D4: LDR x9, [x9, #0xb48]       | X9 = 1152921504652587008;               
            // 0x017BA9D8: LDRSW x27, [x8, #4]        | X27 = Iteedee.ApkReader.ApkReader.ICN_ID;
            val_100 = Iteedee.ApkReader.ApkReader.ICN_ID;
            // 0x017BA9DC: LDR x0, [x9]               | X0 = typeof(System.Convert);            
            // 0x017BA9E0: LDRB w8, [x0, #0x10a]      | W8 = System.Convert.__il2cppRuntimeField_10A;
            // 0x017BA9E4: TBZ w8, #0, #0x17ba9f4     | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_74;
            // 0x017BA9E8: LDR w8, [x0, #0xbc]        | W8 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x017BA9EC: CBNZ w8, #0x17ba9f4        | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_74;
            // 0x017BA9F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_74:
            // 0x017BA9F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BA9F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BA9FC: MOV x1, x22                | X1 = val_22;//m1                        
            // 0x017BAA00: BL #0x1ba6004              | X0 = System.Convert.ToInt32(value:  0); 
            int val_30 = System.Convert.ToInt32(value:  0);
            // 0x017BAA04: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x017BAA08: LDR x8, [x8, #0x658]       | X8 = (string**)(1152921509750944816)("X4");
            // 0x017BAA0C: STR w0, [sp, #0x38]        | stack[1152921513633450248] = val_30;     //  dest_result_addr=1152921513633450248
            // 0x017BAA10: LDR x1, [x8]               | X1 = "X4";                              
            // 0x017BAA14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BAA18: ADD x0, sp, #0x38          | X0 = (1152921513633450192 + 56) = 1152921513633450248 (0x100000021A070908);
            // 0x017BAA1C: BL #0x1e63df8              | X0 = val_30.ToString(format:  "X4");    
            string val_31 = val_30.ToString(format:  "X4");
            // 0x017BAA20: MOV x21, x0                | X21 = val_31;//m1                       
            // 0x017BAA24: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BAA28: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BAA2C: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BAA30: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BAA34: TBZ w8, #0, #0x17baa44     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_76;
            // 0x017BAA38: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BAA3C: CBNZ w8, #0x17baa44        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_76;
            // 0x017BAA40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_76:
            // 0x017BAA44: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x017BAA48: LDR x8, [x8, #0x4f0]       | X8 = (string**)(1152921513633333232)("@{0}");
            // 0x017BAA4C: LDR x1, [x8]               | X1 = "@{0}";                            
            // 0x017BAA50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BAA54: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BAA58: MOV x2, x21                | X2 = val_31;//m1                        
            // 0x017BAA5C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "@{0}");
            string val_32 = System.String.Format(format:  0, arg0:  "@{0}");
            // 0x017BAA60: MOV x21, x0                | X21 = val_32;//m1                       
            val_101 = val_32;
            // 0x017BAA64: CBNZ x26, #0x17baa6c       | if (IEnumerator != null) goto label_77; 
            if(IEnumerator != null)
            {
                goto label_77;
            }
            // 0x017BAA68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_77:
            // 0x017BAA6C: CBZ x21, #0x17baa90        | if (val_32 == null) goto label_79;      
            if(val_101 == null)
            {
                goto label_79;
            }
            // 0x017BAA70: LDR x8, [x26]              | X8 = IEnumerator;                       
            // 0x017BAA74: LDR x1, [x8, #0x30]        | 
            // 0x017BAA78: MOV x0, x21                | X0 = val_32;//m1                        
            // 0x017BAA7C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_32, ????);     
            // 0x017BAA80: CBNZ x0, #0x17baa90        | if (val_32 != null) goto label_79;      
            if(val_101 != null)
            {
                goto label_79;
            }
            // 0x017BAA84: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_32, ????);     
            // 0x017BAA88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAA8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_79:
            // 0x017BAA90: LDR w8, [x26, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAA94: CMP w27, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.ICN_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAA98: B.LO #0x17baaa8            | if (val_100 < IEnumerator.__il2cppRuntimeField_18) goto label_80;
            // 0x017BAA9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_32, ????);     
            // 0x017BAAA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAAA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
            label_80:
            // 0x017BAAA8: ADD x8, x26, x27, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID
            // 0x017BAAAC: STR x21, [x8, #0x20]       | (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3).__unknownFiledOffset_20 = val_32;  //  dest_result_addr=0
            (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3).__unknownFiledOffset_20 = val_101;
            // 0x017BAAB0: ADRP x27, #0x367b000       | X27 = 57126912 (0x367B000);             
            // 0x017BAAB4: LDR x27, [x27, #0xe00]     | X27 = 1152921504616644608;              
            // 0x017BAAB8: LDR x0, [x27]              | X0 = typeof(System.Collections.Generic.List<T>);
            // 0x017BAABC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BAAC0: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BAAC4: ADRP x28, #0x35e9000       | X28 = 56528896 (0x35E9000);             
            // 0x017BAAC8: LDR x28, [x28, #0xe88]     | X28 = 1152921510893072720;              
            // 0x017BAACC: LDR x1, [x28]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017BAAD0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_34 = null;
            // 0x017BAAD4: BL #0x25e9474              | .ctor();                                
            val_34 = new System.Collections.Generic.List<System.String>();
            // 0x017BAAD8: ADRP x26, #0x35e6000       | X26 = 56516608 (0x35E6000);             
            // 0x017BAADC: LDR x26, [x26, #0x500]     | X26 = 1152921510890816336;              
            // 0x017BAAE0: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_103 = 0;
            // 0x017BAAE4: B #0x17baaec               |  goto label_81;                         
            goto label_81;
            label_91:
            // 0x017BAAE8: ADD w25, w25, #1           | W25 = (val_103 + 1) = val_103 (0x00000001);
            val_103 = 1;
            label_81:
            // 0x017BAAEC: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BAAF0: CBNZ x22, #0x17baaf8       | if (IEnumerator != null) goto label_82; 
            if(IEnumerator != null)
            {
                goto label_82;
            }
            // 0x017BAAF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_82:
            // 0x017BAAF8: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAAFC: CMP w25, w8                | STATE = COMPARE(0x1, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAB00: B.GE #0x17bab98            | if (val_103 >= IEnumerator.__il2cppRuntimeField_18) goto label_83;
            // 0x017BAB04: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BAB08: CBNZ x22, #0x17bab10       | if (IEnumerator != null) goto label_84; 
            if(IEnumerator != null)
            {
                goto label_84;
            }
            // 0x017BAB0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_84:
            // 0x017BAB10: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAB14: CMP w25, w8                | STATE = COMPARE(0x1, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAB18: B.LO #0x17bab28            | if (val_103 < IEnumerator.__il2cppRuntimeField_18) goto label_85;
            // 0x017BAB1C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x017BAB20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAB24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_85:
            // 0x017BAB28: SXTW x24, w25              | X24 = 1 (0x00000001);                   
            // 0x017BAB2C: ADD x8, x22, x24, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + 8) = 1152921504944270392 (0x10000000141CAC38);
            // 0x017BAB30: LDR x22, [x8, #0x20]       |  //  find_add[1152921504944270384]
            // 0x017BAB34: CBNZ x22, #0x17bab3c       | if (IEnumerator != null) goto label_86; 
            if(IEnumerator != null)
            {
                goto label_86;
            }
            // 0x017BAB38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_86:
            // 0x017BAB3C: LDR x1, [x23]              | X1 = "@";                               
            // 0x017BAB40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BAB44: MOV x0, x22                | X0 = 1152921504944270384 (0x10000000141CAC30);//ML01
            // 0x017BAB48: BL #0x18add38              | X0 = StartsWith(value:  "@");           
            bool val_35 = StartsWith(value:  "@");
            // 0x017BAB4C: TBZ w0, #0, #0x17baae8     | if (val_35 == false) goto label_91;     
            if(val_35 == false)
            {
                goto label_91;
            }
            // 0x017BAB50: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BAB54: CBNZ x22, #0x17bab5c       | if (IEnumerator != null) goto label_88; 
            if(IEnumerator != null)
            {
                goto label_88;
            }
            // 0x017BAB58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_88:
            // 0x017BAB5C: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAB60: CMP w25, w8                | STATE = COMPARE(0x1, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAB64: B.LO #0x17bab74            | if (val_103 < IEnumerator.__il2cppRuntimeField_18) goto label_89;
            // 0x017BAB68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_35, ????);     
            // 0x017BAB6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAB70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
            label_89:
            // 0x017BAB74: ADD x8, x22, x24, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + 8) = 1152921504944270392 (0x10000000141CAC38);
            // 0x017BAB78: LDR x22, [x8, #0x20]       |  //  find_add[1152921504944270384]
            // 0x017BAB7C: CBNZ x21, #0x17bab84       | if ( != 0) goto label_90;               
            if(null != 0)
            {
                goto label_90;
            }
            // 0x017BAB80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_90:
            // 0x017BAB84: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x017BAB88: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BAB8C: MOV x1, x22                | X1 = 1152921504944270384 (0x10000000141CAC30);//ML01
            // 0x017BAB90: BL #0x25ea480              | Add(item:  System.Collections.IEnumerator.__il2cppRuntimeField_name);
            Add(item:  System.Collections.IEnumerator.__il2cppRuntimeField_name);
            // 0x017BAB94: B #0x17baae8               |  goto label_91;                         
            goto label_91;
            label_83:
            // 0x017BAB98: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x017BAB9C: LDR x8, [x8, #0x670]       | X8 = 1152921504856686592;               
            // 0x017BABA0: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkResourceFinder);
            // 0x017BABA4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Iteedee.ApkReader.ApkResourceFinder), ????);
            // 0x017BABA8: MOV x22, x0                | X22 = 1152921504856686592 (0x100000000EE44000);//ML01
            // 0x017BABAC: MOV x0, x22                | X0 = 1152921504856686592 (0x100000000EE44000);//ML01
            Iteedee.ApkReader.ApkResourceFinder val_36 = null;
            // 0x017BABB0: BL #0x17bb534              | .ctor();                                
            val_36 = new Iteedee.ApkReader.ApkResourceFinder();
            // 0x017BABB4: CBNZ x19, #0x17babbc       | if (val_3 != null) goto label_92;       
            if(val_84 != null)
            {
                goto label_92;
            }
            // 0x017BABB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_92:
            // 0x017BABBC: LDR x23, [x19, #0x70]      | 
            // 0x017BABC0: CBNZ x22, #0x17babc8       | if ( != 0) goto label_93;               
            if(null != 0)
            {
                goto label_93;
            }
            // 0x017BABC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_93:
            // 0x017BABC8: MOV x0, x22                | X0 = 1152921504856686592 (0x100000000EE44000);//ML01
            // 0x017BABCC: MOV x1, x23                | X1 = 58294504 (0x37980E8);//ML01        
            // 0x017BABD0: MOV x2, x21                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BABD4: BL #0x17bb5a4              | X0 = processResourceTable(data:  val_90, resIdList:  null);
            System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>> val_37 = processResourceTable(data:  val_90, resIdList:  null);
            // 0x017BABD8: MOV x21, x0                | X21 = val_37;//m1                       
            // 0x017BABDC: CBNZ x19, #0x17babe4       | if (val_3 != null) goto label_94;       
            if(val_84 != null)
            {
                goto label_94;
            }
            // 0x017BABE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_37, ????);     
            label_94:
            // 0x017BABE4: STR x21, [x19, #0x80]      | mem2[0] = val_37;                        //  dest_result_addr=0
            mem2[0] = val_37;
            // 0x017BABE8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BABEC: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BABF0: LDR x21, [x20, #0x10]      | X21 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BABF4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_104 = null;
            // 0x017BABF8: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BABFC: TBZ w8, #0, #0x17bac18     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_96;
            // 0x017BAC00: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BAC04: CBNZ w8, #0x17bac18        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_96;
            // 0x017BAC08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAC0C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAC10: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAC14: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_104 = null;
            label_96:
            // 0x017BAC18: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BAC1C: LDRSW x22, [x8]            | X22 = Iteedee.ApkReader.ApkReader.VER_ID;
            // 0x017BAC20: CBNZ x21, #0x17bac28       | if (IEnumerator != null) goto label_97; 
            if(IEnumerator != null)
            {
                goto label_97;
            }
            // 0x017BAC24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_97:
            // 0x017BAC28: LDR w8, [x21, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAC2C: CMP w22, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.VER_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAC30: B.LO #0x17bac40            | if (Iteedee.ApkReader.ApkReader.VER_ID < IEnumerator.__il2cppRuntimeField_18) goto label_98;
            // 0x017BAC34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAC38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAC3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_98:
            // 0x017BAC40: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BAC44: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BAC48: LDR x0, [x8]               | X0 = typeof(System.String);             
            val_105 = null;
            // 0x017BAC4C: ADD x8, x21, x22, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID
            // 0x017BAC50: LDR x21, [x8, #0x20]       | X21 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BAC54: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BAC58: TBZ w8, #0, #0x17bac74     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_100;
            // 0x017BAC5C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BAC60: CBNZ w8, #0x17bac74        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_100;
            // 0x017BAC64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017BAC68: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BAC6C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BAC70: LDR x0, [x8]               | X0 = typeof(System.String);             
            val_105 = null;
            label_100:
            // 0x017BAC74: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BAC78: LDR x22, [x8]              | X22 = System.String.Empty;              
            // 0x017BAC7C: CBNZ x21, #0x17bac84       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32 != 0) goto label_101;
            // 0x017BAC80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_101:
            // 0x017BAC84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BAC88: MOV x0, x21                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32;//m1
            // 0x017BAC8C: MOV x1, x22                | X1 = System.String.Empty;//m1           
            // 0x017BAC90: BL #0x18a8334              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.Equals(value:  System.String.Empty);
            bool val_39 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.Equals(value:  System.String.Empty);
            // 0x017BAC94: AND w8, w0, #1             | W8 = (val_39 & 1);                      
            bool val_40 = val_39;
            // 0x017BAC98: TBNZ w8, #0, #0x17bae34    | if ((val_39 & 1) == true) goto label_119;
            if(val_40 == true)
            {
                goto label_119;
            }
            // 0x017BAC9C: CBNZ x19, #0x17baca4       | if (val_3 != null) goto label_103;      
            if(val_84 != null)
            {
                goto label_103;
            }
            // 0x017BACA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_103:
            // 0x017BACA4: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BACA8: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BACAC: LDR x21, [x19, #0x80]      | 
            // 0x017BACB0: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BACB4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_106 = null;
            // 0x017BACB8: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BACBC: TBZ w8, #0, #0x17bacd8     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_105;
            // 0x017BACC0: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BACC4: CBNZ w8, #0x17bacd8        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_105;
            // 0x017BACC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BACCC: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BACD0: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BACD4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_106 = null;
            label_105:
            // 0x017BACD8: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BACDC: LDRSW x23, [x8]            | X23 = Iteedee.ApkReader.ApkReader.VER_ID;
            // 0x017BACE0: CBNZ x22, #0x17bace8       | if (IEnumerator != null) goto label_106;
            if(IEnumerator != null)
            {
                goto label_106;
            }
            // 0x017BACE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_106:
            // 0x017BACE8: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BACEC: CMP w23, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.VER_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BACF0: B.LO #0x17bad00            | if (Iteedee.ApkReader.ApkReader.VER_ID < IEnumerator.__il2cppRuntimeField_18) goto label_107;
            // 0x017BACF4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BACF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BACFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_107:
            // 0x017BAD00: ADD x8, x22, x23, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID
            // 0x017BAD04: LDR x22, [x8, #0x20]       | X22 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BAD08: CBNZ x22, #0x17bad10       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32 != 0) goto label_108;
            // 0x017BAD0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_108:
            // 0x017BAD10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAD14: MOV x0, x22                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32;//m1
            // 0x017BAD18: BL #0x18af030              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.ToUpper();
            string val_42 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.ToUpper();
            // 0x017BAD1C: MOV x22, x0                | X22 = val_42;//m1                       
            // 0x017BAD20: CBNZ x21, #0x17bad28       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32 != 0) goto label_109;
            // 0x017BAD24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_109:
            // 0x017BAD28: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x017BAD2C: LDR x8, [x8, #0xf50]       | X8 = 1152921513633382752;               
            // 0x017BAD30: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::ContainsKey(System.String key);
            // 0x017BAD34: MOV x0, x21                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32;//m1
            // 0x017BAD38: MOV x1, x22                | X1 = val_42;//m1                        
            // 0x017BAD3C: BL #0x23fd9f0              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.ContainsKey(key:  val_42);
            bool val_43 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.ContainsKey(key:  val_42);
            // 0x017BAD40: TBZ w0, #0, #0x17bb454     | if (val_43 == false) goto label_118;    
            if(val_43 == false)
            {
                goto label_118;
            }
            // 0x017BAD44: CBNZ x19, #0x17bad4c       | if (val_3 != null) goto label_111;      
            if(val_84 != null)
            {
                goto label_111;
            }
            // 0x017BAD48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
            label_111:
            // 0x017BAD4C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAD50: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAD54: LDR x21, [x19, #0x80]      | 
            // 0x017BAD58: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BAD5C: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_107 = null;
            // 0x017BAD60: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BAD64: TBZ w8, #0, #0x17bad80     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_113;
            // 0x017BAD68: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BAD6C: CBNZ w8, #0x17bad80        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_113;
            // 0x017BAD70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAD74: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAD78: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAD7C: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_107 = null;
            label_113:
            // 0x017BAD80: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BAD84: LDRSW x23, [x8]            | X23 = Iteedee.ApkReader.ApkReader.VER_ID;
            // 0x017BAD88: CBNZ x22, #0x17bad90       | if (IEnumerator != null) goto label_114;
            if(IEnumerator != null)
            {
                goto label_114;
            }
            // 0x017BAD8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_114:
            // 0x017BAD90: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAD94: CMP w23, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.VER_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAD98: B.LO #0x17bada8            | if (Iteedee.ApkReader.ApkReader.VER_ID < IEnumerator.__il2cppRuntimeField_18) goto label_115;
            // 0x017BAD9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BADA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BADA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_115:
            // 0x017BADA8: ADD x8, x22, x23, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID
            // 0x017BADAC: LDR x22, [x8, #0x20]       | X22 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BADB0: CBNZ x22, #0x17badb8       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32 != 0) goto label_116;
            // 0x017BADB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_116:
            // 0x017BADB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BADBC: MOV x0, x22                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32;//m1
            // 0x017BADC0: BL #0x18af030              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.ToUpper();
            string val_45 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.ToUpper();
            // 0x017BADC4: MOV x22, x0                | X22 = val_45;//m1                       
            // 0x017BADC8: CBNZ x21, #0x17badd0       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32 != 0) goto label_117;
            // 0x017BADCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
            label_117:
            // 0x017BADD0: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x017BADD4: LDR x8, [x8, #0x800]       | X8 = 1152921513633387872;               
            // 0x017BADD8: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<System.String> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::get_Item(System.String key);
            // 0x017BADDC: MOV x0, x21                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32;//m1
            // 0x017BADE0: MOV x1, x22                | X1 = val_45;//m1                        
            // 0x017BADE4: BL #0x23fc26c              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.get_Item(key:  val_45);
            System.Collections.Generic.List<System.String> val_46 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32.Item[val_45];
            // 0x017BADE8: MOV x21, x0                | X21 = val_46;//m1                       
            // 0x017BADEC: CBZ x21, #0x17bb454        | if (val_46 == null) goto label_118;     
            if(val_46 == null)
            {
                goto label_118;
            }
            // 0x017BADF0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x017BADF4: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
            // 0x017BADF8: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x017BADFC: MOV x0, x21                | X0 = val_46;//m1                        
            // 0x017BAE00: BL #0x25ed72c              | X0 = val_46.get_Count();                
            int val_47 = val_46.Count;
            // 0x017BAE04: CMP w0, #1                 | STATE = COMPARE(val_47, 0x1)            
            // 0x017BAE08: B.LT #0x17bae34            | if (val_47 < 1) goto label_119;         
            if(val_47 < 1)
            {
                goto label_119;
            }
            // 0x017BAE0C: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x017BAE10: LDR x8, [x8, #0xb50]       | X8 = 1152921510890998992;               
            // 0x017BAE14: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x017BAE18: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x017BAE1C: MOV x0, x21                | X0 = val_46;//m1                        
            // 0x017BAE20: BL #0x25ed734              | X0 = val_46.get_Item(index:  0);        
            string val_48 = val_46.Item[0];
            // 0x017BAE24: MOV x21, x0                | X21 = val_48;//m1                       
            // 0x017BAE28: CBNZ x19, #0x17bae30       | if (val_3 != null) goto label_120;      
            if(val_84 != null)
            {
                goto label_120;
            }
            // 0x017BAE2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
            label_120:
            // 0x017BAE30: STR x21, [x19, #0x18]      | mem2[0] = val_48;                        //  dest_result_addr=0
            mem2[0] = val_48;
            label_119:
            // 0x017BAE34: CBNZ x19, #0x17bae3c       | if (val_3 != null) goto label_121;      
            if(val_84 != null)
            {
                goto label_121;
            }
            // 0x017BAE38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
            label_121:
            // 0x017BAE3C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAE40: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAE44: LDR x21, [x19, #0x80]      | 
            // 0x017BAE48: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BAE4C: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_108 = null;
            // 0x017BAE50: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BAE54: TBZ w8, #0, #0x17bae70     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_123;
            // 0x017BAE58: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BAE5C: CBNZ w8, #0x17bae70        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_123;
            // 0x017BAE60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAE64: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAE68: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAE6C: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_108 = null;
            label_123:
            // 0x017BAE70: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BAE74: LDRSW x23, [x8, #4]        | X23 = Iteedee.ApkReader.ApkReader.ICN_ID;
            // 0x017BAE78: CBNZ x22, #0x17bae80       | if (IEnumerator != null) goto label_124;
            if(IEnumerator != null)
            {
                goto label_124;
            }
            // 0x017BAE7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_124:
            // 0x017BAE80: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAE84: CMP w23, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.ICN_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAE88: B.LO #0x17bae98            | if (Iteedee.ApkReader.ApkReader.ICN_ID < IEnumerator.__il2cppRuntimeField_18) goto label_125;
            // 0x017BAE8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAE90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAE94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_125:
            // 0x017BAE98: ADD x8, x22, x23, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID
            // 0x017BAE9C: LDR x22, [x8, #0x20]       | X22 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BAEA0: CBNZ x22, #0x17baea8       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32 != 0) goto label_126;
            // 0x017BAEA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_126:
            // 0x017BAEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAEAC: MOV x0, x22                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32;//m1
            // 0x017BAEB0: BL #0x18af030              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32.ToUpper();
            string val_50 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32.ToUpper();
            // 0x017BAEB4: MOV x22, x0                | X22 = val_50;//m1                       
            // 0x017BAEB8: CBNZ x21, #0x17baec0       | if (val_48 != null) goto label_127;     
            if(val_48 != null)
            {
                goto label_127;
            }
            // 0x017BAEBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
            label_127:
            // 0x017BAEC0: ADRP x24, #0x3605000       | X24 = 56643584 (0x3605000);             
            // 0x017BAEC4: LDR x24, [x24, #0xf50]     | X24 = 1152921513633382752;              
            // 0x017BAEC8: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::ContainsKey(System.String key);
            // 0x017BAECC: MOV x0, x21                | X0 = val_48;//m1                        
            // 0x017BAED0: MOV x1, x22                | X1 = val_50;//m1                        
            // 0x017BAED4: BL #0x23fd9f0              | X0 = val_48.ContainsKey(key:  val_50);  
            bool val_51 = val_48.ContainsKey(key:  val_50);
            // 0x017BAED8: TBZ w0, #0, #0x17bb368     | if (val_51 == false) goto label_137;    
            if(val_51 == false)
            {
                goto label_137;
            }
            // 0x017BAEDC: CBNZ x19, #0x17baee4       | if (val_3 != null) goto label_129;      
            if(val_84 != null)
            {
                goto label_129;
            }
            // 0x017BAEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_51, ????);     
            label_129:
            // 0x017BAEE4: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAEE8: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAEEC: LDR x21, [x19, #0x80]      | 
            // 0x017BAEF0: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BAEF4: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_109 = null;
            // 0x017BAEF8: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BAEFC: TBZ w8, #0, #0x17baf18     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_131;
            // 0x017BAF00: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BAF04: CBNZ w8, #0x17baf18        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_131;
            // 0x017BAF08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAF0C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BAF10: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BAF14: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_109 = null;
            label_131:
            // 0x017BAF18: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BAF1C: LDRSW x23, [x8, #4]        | X23 = Iteedee.ApkReader.ApkReader.ICN_ID;
            // 0x017BAF20: CBNZ x22, #0x17baf28       | if (IEnumerator != null) goto label_132;
            if(IEnumerator != null)
            {
                goto label_132;
            }
            // 0x017BAF24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_132:
            // 0x017BAF28: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BAF2C: CMP w23, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.ICN_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BAF30: B.LO #0x17baf40            | if (Iteedee.ApkReader.ApkReader.ICN_ID < IEnumerator.__il2cppRuntimeField_18) goto label_133;
            // 0x017BAF34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BAF38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAF3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_133:
            // 0x017BAF40: ADD x8, x22, x23, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID
            // 0x017BAF44: LDR x22, [x8, #0x20]       | X22 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BAF48: CBNZ x22, #0x17baf50       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32 != 0) goto label_134;
            // 0x017BAF4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_134:
            // 0x017BAF50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BAF54: MOV x0, x22                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32;//m1
            // 0x017BAF58: BL #0x18af030              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32.ToUpper();
            string val_53 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32.ToUpper();
            // 0x017BAF5C: MOV x22, x0                | X22 = val_53;//m1                       
            // 0x017BAF60: CBNZ x21, #0x17baf68       | if (val_48 != null) goto label_135;     
            if(val_48 != null)
            {
                goto label_135;
            }
            // 0x017BAF64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_53, ????);     
            label_135:
            // 0x017BAF68: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x017BAF6C: LDR x8, [x8, #0x800]       | X8 = 1152921513633387872;               
            // 0x017BAF70: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<System.String> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::get_Item(System.String key);
            // 0x017BAF74: MOV x0, x21                | X0 = val_48;//m1                        
            // 0x017BAF78: MOV x1, x22                | X1 = val_53;//m1                        
            // 0x017BAF7C: BL #0x23fc26c              | X0 = val_48.get_Item(key:  val_53);     
            System.Collections.Generic.List<System.String> val_54 = val_48.Item[val_53];
            // 0x017BAF80: MOV x21, x0                | X21 = val_54;//m1                       
            // 0x017BAF84: CBZ x21, #0x17bb368        | if (val_54 == null) goto label_137;     
            if(val_54 == null)
            {
                goto label_137;
            }
            // 0x017BAF88: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x017BAF8C: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
            // 0x017BAF90: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x017BAF94: MOV x0, x21                | X0 = val_54;//m1                        
            // 0x017BAF98: BL #0x25ed72c              | X0 = val_54.get_Count();                
            int val_55 = val_54.Count;
            // 0x017BAF9C: CMP w0, #1                 | STATE = COMPARE(val_55, 0x1)            
            // 0x017BAFA0: B.LT #0x17bb368            | if (val_55 < 1) goto label_137;         
            if(val_55 < 1)
            {
                goto label_137;
            }
            // 0x017BAFA4: LDR x0, [x27]              | X0 = typeof(System.Collections.Generic.List<T>);
            // 0x017BAFA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BAFAC: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BAFB0: LDR x1, [x28]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017BAFB4: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_56 = null;
            // 0x017BAFB8: BL #0x25e9474              | .ctor();                                
            val_56 = new System.Collections.Generic.List<System.String>();
            // 0x017BAFBC: CBNZ x19, #0x17bafc4       | if (val_3 != null) goto label_138;      
            if(val_84 != null)
            {
                goto label_138;
            }
            // 0x017BAFC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_138:
            // 0x017BAFC4: STR x22, [x19, #0x58]      | mem2[0] = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=0
            mem2[0] = null;
            // 0x017BAFC8: LDR x0, [x27]              | X0 = typeof(System.Collections.Generic.List<T>);
            // 0x017BAFCC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BAFD0: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BAFD4: LDR x1, [x28]              | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017BAFD8: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.String> val_57 = null;
            // 0x017BAFDC: BL #0x25e9474              | .ctor();                                
            val_57 = new System.Collections.Generic.List<System.String>();
            // 0x017BAFE0: STR x22, [x19, #0x50]      | mem2[0] = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=0
            mem2[0] = null;
            // 0x017BAFE4: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x017BAFE8: LDR x8, [x8, #0xb00]       | X8 = 1152921510022785904;               
            // 0x017BAFEC: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.String>::GetEnumerator();
            // 0x017BAFF0: ADD x8, sp, #8             | X8 = (1152921513633450192 + 8) = 1152921513633450200 (0x100000021A0708D8);
            // 0x017BAFF4: MOV x0, x21                | X0 = val_54;//m1                        
            // 0x017BAFF8: BL #0x25ebf2c              | X0 = val_54.GetEnumerator();            
            List.Enumerator<T> val_58 = val_54.GetEnumerator();
            // 0x017BAFFC: ADRP x25, #0x3637000       | X25 = 56848384 (0x3637000);             
            // 0x017BB000: ADRP x27, #0x3640000       | X27 = 56885248 (0x3640000);             
            // 0x017BB004: ADRP x28, #0x35bb000       | X28 = 56340480 (0x35BB000);             
            // 0x017BB008: LDR x8, [sp, #0x18]        | X8 = val_59;                             //  find_add[1152921513633438352]
            // 0x017BB00C: LDUR q0, [sp, #8]          | Q0 = val_60;                             //  find_add[1152921513633438352]
            // 0x017BB010: LDR x25, [x25, #0x1a8]     | X25 = 1152921510022786928;              
            val_87 = 1152921510022786928;
            // 0x017BB014: LDR x27, [x27, #0x8d0]     | X27 = 1152921510022787952;              
            val_89 = 1152921510022787952;
            // 0x017BB018: LDR x28, [x28, #0x458]     | X28 = (string**)(1152921509471652944)("/");
            // 0x017BB01C: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            val_90 = 1;
            // 0x017BB020: STR x8, [sp, #0x30]        | stack[1152921513633450240] = val_59;     //  dest_result_addr=1152921513633450240
            // 0x017BB024: STR q0, [sp, #0x20]        | stack[1152921513633450224] = val_60;     //  dest_result_addr=1152921513633450224
            // 0x017BB028: B #0x17bb030               |  goto label_142;                        
            goto label_142;
            label_148:
            // 0x017BB02C: STRB w23, [x19, #0x78]     | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = val_90;
            label_142:
            // 0x017BB030: LDR x1, [x25]              | X1 = public System.Boolean List.Enumerator<System.String>::MoveNext();
            // 0x017BB034: ADD x0, sp, #0x20          | X0 = (1152921513633450192 + 32) = 1152921513633450224 (0x100000021A0708F0);
            // 0x017BB038: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x017BB03C: AND w8, w0, #1             | W8 = (1152921513633450224 & 1) = 0 (0x00000000);
            // 0x017BB040: TBZ w8, #0, #0x17bb0e4     | if ((0x0 & 0x1) == 0) goto label_140;   
            if((0 & 1) == 0)
            {
                goto label_140;
            }
            // 0x017BB044: LDR x1, [x27]              | X1 = public System.String List.Enumerator<System.String>::get_Current();
            // 0x017BB048: ADD x0, sp, #0x20          | X0 = (1152921513633450192 + 32) = 1152921513633450224 (0x100000021A0708F0);
            // 0x017BB04C: BL #0x13372d8              | X0 = val_60.get_InitialType();          
            System.Type val_61 = val_60.InitialType;
            // 0x017BB050: MOV x21, x0                | X21 = val_61;//m1                       
            // 0x017BB054: CBZ x21, #0x17bb030        | if (val_61 == null) goto label_142;     
            if(val_61 == null)
            {
                goto label_142;
            }
            // 0x017BB058: LDR x1, [x28]              | X1 = "/";                               
            // 0x017BB05C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BB060: MOV x0, x21                | X0 = val_61;//m1                        
            // 0x017BB064: BL #0x18ad42c              | X0 = val_61.Contains(value:  "/");      
            bool val_62 = val_61.Contains(value:  "/");
            // 0x017BB068: TBZ w0, #0, #0x17bb030     | if (val_62 == false) goto label_142;    
            if(val_62 == false)
            {
                goto label_142;
            }
            // 0x017BB06C: CBNZ x19, #0x17bb074       | if (val_3 != null) goto label_143;      
            if(val_84 != null)
            {
                goto label_143;
            }
            // 0x017BB070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
            label_143:
            // 0x017BB074: LDR x22, [x19, #0x58]      | 
            // 0x017BB078: CBNZ x22, #0x17bb080       | if ( != 0) goto label_144;              
            if(null != 0)
            {
                goto label_144;
            }
            // 0x017BB07C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_62, ????);     
            label_144:
            // 0x017BB080: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x017BB084: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BB088: MOV x1, x21                | X1 = val_61;//m1                        
            // 0x017BB08C: BL #0x25ea480              | Add(item:  val_61);                     
            Add(item:  val_61);
            // 0x017BB090: CBNZ x19, #0x17bb098       | if (val_3 != null) goto label_145;      
            if(val_84 != null)
            {
                goto label_145;
            }
            // 0x017BB094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_145:
            // 0x017BB098: LDR x22, [x19, #0x50]      | 
            // 0x017BB09C: CBNZ x22, #0x17bb0a4       | if ( != 0) goto label_146;              
            if(null != 0)
            {
                goto label_146;
            }
            // 0x017BB0A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_146:
            // 0x017BB0A4: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x017BB0A8: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BB0AC: MOV x1, x21                | X1 = val_61;//m1                        
            // 0x017BB0B0: BL #0x25ea480              | Add(item:  val_61);                     
            Add(item:  val_61);
            // 0x017BB0B4: CBNZ x19, #0x17bb02c       | if (val_3 != null) goto label_148;      
            if(val_84 != null)
            {
                goto label_148;
            }
            // 0x017BB0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BB0BC: B #0x17bb02c               |  goto label_148;                        
            goto label_148;
            // 0x017BB0C0: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BB0C4: CMP w1, #1                 | STATE = COMPARE(val_61, 0x1)            
            // 0x017BB0C8: B.NE #0x17ba420            | if (val_61 != 0x1) goto label_149;      
            if(val_61 != 1)
            {
                goto label_149;
            }
            // 0x017BB0CC: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017BB0D0: BL #0x981060               | X0 = sub_981060( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BB0D4: LDR x21, [x0]              | X21 = ;                                 
            val_110 = null;
            // 0x017BB0D8: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017BB0DC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_111 = 0;
            // 0x017BB0E0: B #0x17bb0ec               |  goto label_150;                        
            goto label_150;
            label_140:
            // 0x017BB0E4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_110 = 0;
            // 0x017BB0E8: MOVZ w22, #0x470           | W22 = 1136 (0x470);//ML01               
            val_111 = 1136;
            label_150:
            // 0x017BB0EC: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x017BB0F0: LDR x8, [x8, #0xd70]       | X8 = 1152921510022801264;               
            // 0x017BB0F4: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.String>::Dispose();
            // 0x017BB0F8: ADD x0, sp, #0x20          | X0 = (1152921513633450192 + 32) = 1152921513633450224 (0x100000021A0708F0);
            // 0x017BB0FC: BL #0x13371f4              | val_60.Dispose();                       
            val_60.Dispose();
            // 0x017BB100: CMP w22, #0x470            | STATE = COMPARE(0x470, 0x470)           
            // 0x017BB104: B.EQ #0x17bb118            | if (0x470 == 0x470) goto label_152;     
            if(1136 == 1136)
            {
                goto label_152;
            }
            // 0x017BB108: CBZ x21, #0x17bb118        | if (0x0 == 0) goto label_152;           
            if(val_110 == 0)
            {
                goto label_152;
            }
            // 0x017BB10C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB110: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x017BB114: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_152:
            // 0x017BB118: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB11C: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB120: LDR x21, [x20, #0x10]      | X21 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BB124: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_112 = null;
            // 0x017BB128: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BB12C: TBZ w8, #0, #0x17bb148     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_154;
            // 0x017BB130: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BB134: CBNZ w8, #0x17bb148        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_154;
            // 0x017BB138: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB13C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB140: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB144: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_112 = null;
            label_154:
            // 0x017BB148: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BB14C: LDRSW x22, [x8, #8]        | X22 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            // 0x017BB150: CBNZ x21, #0x17bb158       | if (IEnumerator != null) goto label_155;
            if(IEnumerator != null)
            {
                goto label_155;
            }
            // 0x017BB154: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_155:
            // 0x017BB158: LDR w8, [x21, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BB15C: CMP w22, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.LABEL_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BB160: B.LO #0x17bb170            | if (Iteedee.ApkReader.ApkReader.LABEL_ID < IEnumerator.__il2cppRuntimeField_18) goto label_156;
            // 0x017BB164: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB16C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_156:
            // 0x017BB170: ADRP x9, #0x35d6000        | X9 = 56451072 (0x35D6000);              
            // 0x017BB174: LDR x9, [x9, #0xe38]       | X9 = 1152921504608284672;               
            // 0x017BB178: ADD x8, x21, x22, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_
            // 0x017BB17C: LDR x21, [x8, #0x20]       | X21 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32; //  not_find_field!2:32
            val_82 = mem[(System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32];
            val_82 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32;
            // 0x017BB180: LDR x0, [x9]               | X0 = typeof(System.String);             
            val_113 = null;
            // 0x017BB184: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BB188: TBZ w8, #0, #0x17bb1a0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_158;
            // 0x017BB18C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BB190: CBNZ w8, #0x17bb1a0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_158;
            // 0x017BB194: MOV x22, x9                | X22 = 57977240 (0x374A998);//ML01       
            // 0x017BB198: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x017BB19C: LDR x0, [x22]              | X0 = typeof(System.String);             
            val_113 = null;
            label_158:
            // 0x017BB1A0: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x017BB1A4: LDR x22, [x8]              | X22 = System.String.Empty;              
            // 0x017BB1A8: CBNZ x21, #0x17bb1b0       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32 != 0) goto label_159;
            // 0x017BB1AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_159:
            // 0x017BB1B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BB1B4: MOV x0, x21                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32;//m1
            // 0x017BB1B8: MOV x1, x22                | X1 = System.String.Empty;//m1           
            // 0x017BB1BC: BL #0x18a8334              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32.Equals(value:  System.String.Empty);
            bool val_64 = val_82.Equals(value:  System.String.Empty);
            // 0x017BB1C0: AND w8, w0, #1             | W8 = (val_64 & 1);                      
            bool val_65 = val_64;
            // 0x017BB1C4: TBNZ w8, #0, #0x17bb344    | if ((val_64 & 1) == true) goto label_176;
            if(val_65 == true)
            {
                goto label_176;
            }
            // 0x017BB1C8: CBNZ x19, #0x17bb1d0       | if (val_3 != null) goto label_161;      
            if(val_84 != null)
            {
                goto label_161;
            }
            // 0x017BB1CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
            label_161:
            // 0x017BB1D0: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB1D4: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB1D8: LDR x21, [x19, #0x80]      | 
            // 0x017BB1DC: LDR x22, [x20, #0x10]      | X22 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BB1E0: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_114 = null;
            // 0x017BB1E4: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BB1E8: TBZ w8, #0, #0x17bb204     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_163;
            // 0x017BB1EC: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BB1F0: CBNZ w8, #0x17bb204        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_163;
            // 0x017BB1F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB1F8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB1FC: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB200: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_114 = null;
            label_163:
            // 0x017BB204: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BB208: LDRSW x23, [x8, #8]        | X23 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            val_90 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            // 0x017BB20C: CBNZ x22, #0x17bb214       | if (IEnumerator != null) goto label_164;
            if(IEnumerator != null)
            {
                goto label_164;
            }
            // 0x017BB210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_164:
            // 0x017BB214: LDR w8, [x22, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BB218: CMP w23, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.LABEL_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BB21C: B.LO #0x17bb22c            | if (val_90 < IEnumerator.__il2cppRuntimeField_18) goto label_165;
            // 0x017BB220: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB228: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_165:
            // 0x017BB22C: ADD x8, x22, x23, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_
            // 0x017BB230: LDR x22, [x8, #0x20]       | X22 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BB234: CBNZ x21, #0x17bb23c       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32 != 0) goto label_166;
            // 0x017BB238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_166:
            // 0x017BB23C: LDR x2, [x24]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::ContainsKey(System.String key);
            // 0x017BB240: MOV x0, x21                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32;//m1
            // 0x017BB244: MOV x1, x22                | X1 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32;//m1
            // 0x017BB248: BL #0x23fd9f0              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32.ContainsKey(key:  (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32);
            bool val_67 = val_82.ContainsKey(key:  (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32);
            // 0x017BB24C: TBZ w0, #0, #0x17bb2ec     | if (val_67 == false) goto label_174;    
            if(val_67 == false)
            {
                goto label_174;
            }
            // 0x017BB250: CBNZ x19, #0x17bb258       | if (val_3 != null) goto label_168;      
            if(val_84 != null)
            {
                goto label_168;
            }
            // 0x017BB254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_67, ????);     
            label_168:
            // 0x017BB258: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB25C: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB260: LDR x21, [x19, #0x80]      | 
            // 0x017BB264: LDR x20, [x20, #0x10]      | X20 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BB268: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_115 = null;
            // 0x017BB26C: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BB270: TBZ w8, #0, #0x17bb28c     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_170;
            // 0x017BB274: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BB278: CBNZ w8, #0x17bb28c        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_170;
            // 0x017BB27C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB280: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB284: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB288: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_115 = null;
            label_170:
            // 0x017BB28C: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BB290: LDRSW x22, [x8, #8]        | X22 = Iteedee.ApkReader.ApkReader.LABEL_ID;
            // 0x017BB294: CBNZ x20, #0x17bb29c       | if (IEnumerator != null) goto label_171;
            if(IEnumerator != null)
            {
                goto label_171;
            }
            // 0x017BB298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_171:
            // 0x017BB29C: LDR w8, [x20, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BB2A0: CMP w22, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.LABEL_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BB2A4: B.LO #0x17bb2b4            | if (Iteedee.ApkReader.ApkReader.LABEL_ID < IEnumerator.__il2cppRuntimeField_18) goto label_172;
            // 0x017BB2A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB2AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB2B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_172:
            // 0x017BB2B4: ADD x8, x20, x22, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_
            // 0x017BB2B8: LDR x20, [x8, #0x20]       | X20 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BB2BC: CBNZ x21, #0x17bb2c4       | if ((System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32 != 0) goto label_173;
            // 0x017BB2C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_173:
            // 0x017BB2C4: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x017BB2C8: LDR x8, [x8, #0x800]       | X8 = 1152921513633387872;               
            // 0x017BB2CC: LDR x2, [x8]               | X2 = public System.Collections.Generic.List<System.String> System.Collections.Generic.Dictionary<System.String, System.Collections.Generic.List<System.String>>::get_Item(System.String key);
            // 0x017BB2D0: MOV x0, x21                | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32;//m1
            // 0x017BB2D4: MOV x1, x20                | X1 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32;//m1
            // 0x017BB2D8: BL #0x23fc26c              | X0 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32.get_Item(key:  (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32);
            System.Collections.Generic.List<System.String> val_69 = val_82.Item[(System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.LABEL_ID) << 3) + 32];
            // 0x017BB2DC: MOV x20, x0                | X20 = val_69;//m1                       
            val_116 = val_69;
            // 0x017BB2E0: CBZ x20, #0x17bb2ec        | if (val_69 == null) goto label_174;     
            if(val_116 == null)
            {
                goto label_174;
            }
            // 0x017BB2E4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_82 = 0;
            // 0x017BB2E8: B #0x17bb2f8               |  goto label_175;                        
            goto label_175;
            label_174:
            // 0x017BB2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_67, ????);     
            // 0x017BB2F0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_116 = 0;
            // 0x017BB2F4: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            val_82 = 1;
            label_175:
            // 0x017BB2F8: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x017BB2FC: LDR x8, [x8, #0xb58]       | X8 = 1152921510022759280;               
            // 0x017BB300: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<System.String>::get_Count();
            // 0x017BB304: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x017BB308: BL #0x25ed72c              | X0 = val_116.get_Count();               
            int val_70 = val_116.Count;
            // 0x017BB30C: CMP w0, #1                 | STATE = COMPARE(val_70, 0x1)            
            // 0x017BB310: B.LT #0x17bb344            | if (val_70 < 1) goto label_176;         
            if(val_70 < 1)
            {
                goto label_176;
            }
            // 0x017BB314: CBZ w21, #0x17bb31c        | if (0x1 == 0) goto label_177;           
            if(val_82 == 0)
            {
                goto label_177;
            }
            // 0x017BB318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
            label_177:
            // 0x017BB31C: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x017BB320: LDR x8, [x8, #0xb50]       | X8 = 1152921510890998992;               
            // 0x017BB324: LDR x2, [x8]               | X2 = public System.String System.Collections.Generic.List<System.String>::get_Item(int index);
            // 0x017BB328: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x017BB32C: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x017BB330: BL #0x25ed734              | X0 = val_116.get_Item(index:  0);       
            string val_71 = val_116.Item[0];
            // 0x017BB334: MOV x20, x0                | X20 = val_71;//m1                       
            // 0x017BB338: CBNZ x19, #0x17bb340       | if (val_3 != null) goto label_178;      
            if(val_84 != null)
            {
                goto label_178;
            }
            // 0x017BB33C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_71, ????);     
            label_178:
            // 0x017BB340: STR x20, [x19, #0x10]      | mem2[0] = val_71;                        //  dest_result_addr=0
            mem2[0] = val_71;
            label_176:
            // 0x017BB344: MOV x0, x19                | X0 = val_3;//m1                         
            // 0x017BB348: SUB sp, x29, #0x50         | SP = (1152921513633450336 - 80) = 1152921513633450256 (0x100000021A070910);
            // 0x017BB34C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x017BB350: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x017BB354: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x017BB358: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x017BB35C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x017BB360: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x017BB364: RET                        |  return (Iteedee.ApkReader.ApkInfo)val_3;
            return (Iteedee.ApkReader.ApkInfo)val_84;
            //  |  // // {name=val_0, type=Iteedee.ApkReader.ApkInfo, size=8, nGRN=0 }
            label_137:
            // 0x017BB368: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB36C: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB370: LDR x19, [x20, #0x10]      | X19 = System.Collections.IEnumerator.__il2cppRuntimeField_name;
            // 0x017BB374: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_117 = null;
            // 0x017BB378: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BB37C: TBZ w8, #0, #0x17bb398     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_180;
            // 0x017BB380: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BB384: CBNZ w8, #0x17bb398        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_180;
            // 0x017BB388: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB38C: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB390: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB394: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_117 = null;
            label_180:
            // 0x017BB398: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BB39C: LDRSW x20, [x8, #4]        | X20 = Iteedee.ApkReader.ApkReader.ICN_ID;
            // 0x017BB3A0: CBNZ x19, #0x17bb3a8       | if (IEnumerator != null) goto label_181;
            if(IEnumerator != null)
            {
                goto label_181;
            }
            // 0x017BB3A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_181:
            // 0x017BB3A8: LDR w8, [x19, #0x18]       | W8 = IEnumerator.__il2cppRuntimeField_18;
            // 0x017BB3AC: CMP w20, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.ICN_ID, IEnumerator.__il2cppRuntimeField_18)
            // 0x017BB3B0: B.LO #0x17bb3c0            | if (Iteedee.ApkReader.ApkReader.ICN_ID < IEnumerator.__il2cppRuntimeField_18) goto label_182;
            // 0x017BB3B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB3B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB3BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_182:
            // 0x017BB3C0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BB3C4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BB3C8: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BB3CC: ADD x8, x19, x20, lsl #3   | X8 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID
            // 0x017BB3D0: LDR x19, [x8, #0x20]       | X19 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BB3D4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BB3D8: TBZ w8, #0, #0x17bb3e8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_184;
            // 0x017BB3DC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BB3E0: CBNZ w8, #0x17bb3e8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_184;
            // 0x017BB3E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_184:
            // 0x017BB3E8: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x017BB3EC: LDR x8, [x8, #0x778]       | X8 = (string**)(1152921513633421664)("Icon Cant Find in resource with id ");
            // 0x017BB3F0: LDR x1, [x8]               | X1 = "Icon Cant Find in resource with id ";
            // 0x017BB3F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BB3F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BB3FC: MOV x2, x19                | X2 = (System.Collections.IEnumerator.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.ICN_ID) << 3) + 32;//m1
            // 0x017BB400: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "Icon Cant Find in resource with id ");
            string val_73 = System.String.Concat(str0:  0, str1:  "Icon Cant Find in resource with id ");
            // 0x017BB404: MOV x19, x0                | X19 = val_73;//m1                       
            // 0x017BB408: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BB40C: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BB410: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BB414: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BB418: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_83 = null;
            // 0x017BB41C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BB420: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_74 = val_83;
            // 0x017BB424: MOV x1, x19                | X1 = val_73;//m1                        
            // 0x017BB428: BL #0x1c32b48              | .ctor(message:  val_73);                
            val_74 = new System.Exception(message:  val_73);
            // 0x017BB42C: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x017BB430: LDR x8, [x8, #0x9e8]       | X8 = 1152921513633294848;               
            // 0x017BB434: LDR x1, [x8]               | X1 = public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx);
            // 0x017BB438: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BB43C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BB440: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_75 = System.Collections.IEnumerable.GetEnumerator();
            // 0x017BB444: MOV x21, x0                | X21 = val_75;//m1                       
            val_118 = val_75;
            // 0x017BB448: BL #0x980920               | X0 = sub_980920( ?? val_75, ????);      
            label_21:
            // 0x017BB44C: MOV x0, x21                | X0 = val_75;//m1                        
            // 0x017BB450: BL #0x980800               | X0 = sub_980800( ?? val_75, ????);      
            label_118:
            // 0x017BB454: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB458: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB45C: LDR x19, [x20, #0x10]      | X19 = System.Exception.__il2cppRuntimeField_name;
            // 0x017BB460: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_119 = null;
            // 0x017BB464: LDRB w8, [x0, #0x10a]      | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_10A;
            // 0x017BB468: TBZ w8, #0, #0x17bb484     | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_has_cctor == 0) goto label_186;
            // 0x017BB46C: LDR w8, [x0, #0xbc]        | W8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished;
            // 0x017BB470: CBNZ w8, #0x17bb484        | if (Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_cctor_finished != 0) goto label_186;
            // 0x017BB474: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB478: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BB47C: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BB480: LDR x0, [x8]               | X0 = typeof(Iteedee.ApkReader.ApkReader);
            val_119 = null;
            label_186:
            // 0x017BB484: LDR x8, [x0, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BB488: LDRSW x20, [x8]            | X20 = Iteedee.ApkReader.ApkReader.VER_ID;
            // 0x017BB48C: CBNZ x19, #0x17bb494       | if (Exception != null) goto label_187;  
            if(Exception != null)
            {
                goto label_187;
            }
            // 0x017BB490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_187:
            // 0x017BB494: LDR w8, [x19, #0x18]       | W8 = Exception.__il2cppRuntimeField_18; 
            // 0x017BB498: CMP w20, w8                | STATE = COMPARE(Iteedee.ApkReader.ApkReader.VER_ID, Exception.__il2cppRuntimeField_18)
            // 0x017BB49C: B.LO #0x17bb4ac            | if (Iteedee.ApkReader.ApkReader.VER_ID < Exception.__il2cppRuntimeField_18) goto label_188;
            // 0x017BB4A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            // 0x017BB4A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017BB4A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Iteedee.ApkReader.ApkReader), ????);
            label_188:
            // 0x017BB4AC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x017BB4B0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x017BB4B4: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x017BB4B8: ADD x8, x19, x20, lsl #3   | X8 = (System.Exception.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3);
            // 0x017BB4BC: LDR x19, [x8, #0x20]       | X19 = (System.Exception.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32; //  not_find_field!2:32
            // 0x017BB4C0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x017BB4C4: TBZ w8, #0, #0x17bb4d4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_190;
            // 0x017BB4C8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x017BB4CC: CBNZ w8, #0x17bb4d4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_190;
            // 0x017BB4D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_190:
            // 0x017BB4D4: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x017BB4D8: LDR x8, [x8, #0x258]       | X8 = (string**)(1152921513633430000)("VersionName Cant Find in resource with id ");
            // 0x017BB4DC: LDR x1, [x8]               | X1 = "VersionName Cant Find in resource with id ";
            // 0x017BB4E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017BB4E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017BB4E8: MOV x2, x19                | X2 = (System.Exception.__il2cppRuntimeField_name + (Iteedee.ApkReader.ApkReader.VER_ID) << 3) + 32;//m1
            // 0x017BB4EC: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "VersionName Cant Find in resource with id ");
            string val_77 = System.String.Concat(str0:  0, str1:  "VersionName Cant Find in resource with id ");
            // 0x017BB4F0: MOV x19, x0                | X19 = val_77;//m1                       
            // 0x017BB4F4: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017BB4F8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017BB4FC: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017BB500: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x017BB504: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BB508: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017BB50C: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_78 = null;
            // 0x017BB510: MOV x1, x19                | X1 = val_77;//m1                        
            // 0x017BB514: BL #0x1c32b48              | .ctor(message:  val_77);                
            val_78 = new System.Exception(message:  val_77);
            // 0x017BB518: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x017BB51C: LDR x8, [x8, #0x9e8]       | X8 = 1152921513633294848;               
            // 0x017BB520: LDR x1, [x8]               | X1 = public Iteedee.ApkReader.ApkInfo Iteedee.ApkReader.ApkReader::extractInfo(System.Xml.XmlDocument manifestXml, byte[] resources_arsx);
            // 0x017BB524: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x017BB528: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x017BB52C: BL #0x17b754c              | X0 = System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_79 = System.Collections.IEnumerable.GetEnumerator();
            // 0x017BB530: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9B70 (24877936), len: 380  VirtAddr: 0x017B9B70 RVA: 0x017B9B70 token: 100684424 methodIndex: 45994 delegateWrapperIndex: 0 methodInvoker: 0
        private void ExtractPermission(Iteedee.ApkReader.ApkInfo info, System.Xml.XmlDocument doc, string keyName, string attribName)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.List<System.String> val_1;
            //  | 
            string val_2;
            // 0x017B9B70: STP x26, x25, [sp, #-0x50]! | stack[1152921513633873568] = ???;  stack[1152921513633873576] = ???;  //  dest_result_addr=1152921513633873568 |  dest_result_addr=1152921513633873576
            // 0x017B9B74: STP x24, x23, [sp, #0x10]  | stack[1152921513633873584] = ???;  stack[1152921513633873592] = ???;  //  dest_result_addr=1152921513633873584 |  dest_result_addr=1152921513633873592
            // 0x017B9B78: STP x22, x21, [sp, #0x20]  | stack[1152921513633873600] = ???;  stack[1152921513633873608] = ???;  //  dest_result_addr=1152921513633873600 |  dest_result_addr=1152921513633873608
            // 0x017B9B7C: STP x20, x19, [sp, #0x30]  | stack[1152921513633873616] = ???;  stack[1152921513633873624] = ???;  //  dest_result_addr=1152921513633873616 |  dest_result_addr=1152921513633873624
            // 0x017B9B80: STP x29, x30, [sp, #0x40]  | stack[1152921513633873632] = ???;  stack[1152921513633873640] = ???;  //  dest_result_addr=1152921513633873632 |  dest_result_addr=1152921513633873640
            // 0x017B9B84: ADD x29, sp, #0x40         | X29 = (1152921513633873568 + 64) = 1152921513633873632 (0x100000021A0D7EE0);
            // 0x017B9B88: ADRP x23, #0x3738000       | X23 = 57901056 (0x3738000);             
            // 0x017B9B8C: LDRB w8, [x23, #0x95b]     | W8 = (bool)static_value_0373895B;       
            // 0x017B9B90: MOV x19, x4                | X19 = attribName;//m1                   
            // 0x017B9B94: MOV x21, x3                | X21 = keyName;//m1                      
            // 0x017B9B98: MOV x22, x2                | X22 = doc;//m1                          
            // 0x017B9B9C: MOV x20, x1                | X20 = info;//m1                         
            // 0x017B9BA0: TBNZ w8, #0, #0x17b9bbc    | if (static_value_0373895B == true) goto label_0;
            // 0x017B9BA4: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x017B9BA8: LDR x8, [x8, #0xbe8]       | X8 = 0x2B8B024;                         
            // 0x017B9BAC: LDR w0, [x8]               | W0 = 0x2C7;                             
            // 0x017B9BB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C7, ????);      
            // 0x017B9BB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B9BB8: STRB w8, [x23, #0x95b]     | static_value_0373895B = true;            //  dest_result_addr=57903451
            label_0:
            // 0x017B9BBC: CBNZ x22, #0x17b9bc4       | if (doc != null) goto label_1;          
            if(doc != null)
            {
                goto label_1;
            }
            // 0x017B9BC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2C7, ????);      
            label_1:
            // 0x017B9BC4: LDR x8, [x22]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9BC8: MOV x0, x22                | X0 = doc;//m1                           
            // 0x017B9BCC: MOV x1, x21                | X1 = keyName;//m1                       
            // 0x017B9BD0: LDR x9, [x8, #0x460]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_460;
            // 0x017B9BD4: LDR x2, [x8, #0x468]       | X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_468;
            // 0x017B9BD8: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_460();
            // 0x017B9BDC: MOV x21, x0                | X21 = doc;//m1                          
            // 0x017B9BE0: CBZ x21, #0x17b9cd4        | if (doc == null) goto label_3;          
            if(doc == null)
            {
                goto label_3;
            }
            // 0x017B9BE4: LDR x8, [x21]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9BE8: MOV x0, x21                | X0 = doc;//m1                           
            // 0x017B9BEC: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_168; //  | 
            // 0x017B9BF0: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160();
            // 0x017B9BF4: CMP w0, #1                 | STATE = COMPARE(doc, 0x1)               
            // 0x017B9BF8: B.LT #0x17b9cd4            | if (doc < 0x1) goto label_3;            
            if(doc < 1)
            {
                goto label_3;
            }
            // 0x017B9BFC: ADRP x25, #0x35e6000       | X25 = 56516608 (0x35E6000);             
            // 0x017B9C00: LDR x25, [x25, #0x500]     | X25 = 1152921510890816336;              
            // 0x017B9C04: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_1 = 0;
            label_10:
            // 0x017B9C08: LDR x8, [x21]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9C0C: MOV x0, x21                | X0 = doc;//m1                           
            // 0x017B9C10: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
            // 0x017B9C14: LDP x9, x2, [x8, #0x190]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190; X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_198; //  | 
            // 0x017B9C18: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190();
            // 0x017B9C1C: MOV x23, x0                | X23 = doc;//m1                          
            val_1 = doc;
            // 0x017B9C20: CBNZ x23, #0x17b9c28       | if (doc != null) goto label_4;          
            if(val_1 != null)
            {
                goto label_4;
            }
            // 0x017B9C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_4:
            // 0x017B9C28: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9C2C: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B9C30: LDR x9, [x8, #0x240]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_240;
            // 0x017B9C34: LDR x1, [x8, #0x248]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_248;
            // 0x017B9C38: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_240();
            // 0x017B9C3C: CMP w0, #1                 | STATE = COMPARE(doc, 0x1)               
            // 0x017B9C40: B.NE #0x17b9cb8            | if (val_1 != 0x1) goto label_7;         
            if(val_1 != 1)
            {
                goto label_7;
            }
            // 0x017B9C44: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9C48: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B9C4C: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_170; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_178; //  | 
            // 0x017B9C50: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_170();
            // 0x017B9C54: MOV x23, x0                | X23 = doc;//m1                          
            val_1 = val_1;
            // 0x017B9C58: CBNZ x23, #0x17b9c60       | if (doc != null) goto label_6;          
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x017B9C5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_6:
            // 0x017B9C60: LDR x8, [x23]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9C64: MOV x0, x23                | X0 = doc;//m1                           
            // 0x017B9C68: MOV x1, x19                | X1 = attribName;//m1                    
            val_2 = attribName;
            // 0x017B9C6C: LDP x9, x2, [x8, #0x180]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_180; X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_188; //  | 
            // 0x017B9C70: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_180();
            // 0x017B9C74: MOV x24, x0                | X24 = doc;//m1                          
            // 0x017B9C78: CBZ x24, #0x17b9cb8        | if (doc == null) goto label_7;          
            if(val_1 == null)
            {
                goto label_7;
            }
            // 0x017B9C7C: CBNZ x20, #0x17b9c84       | if (info != null) goto label_8;         
            if(info != null)
            {
                goto label_8;
            }
            // 0x017B9C80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_8:
            // 0x017B9C84: LDR x8, [x24]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9C88: LDR x23, [x20, #0x48]      | X23 = info.Permissions; //P2            
            val_1 = info.Permissions;
            // 0x017B9C8C: MOV x0, x24                | X0 = doc;//m1                           
            // 0x017B9C90: LDR x9, [x8, #0x290]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
            // 0x017B9C94: LDR x1, [x8, #0x298]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_298;
            // 0x017B9C98: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290();
            // 0x017B9C9C: MOV x24, x0                | X24 = doc;//m1                          
            // 0x017B9CA0: CBNZ x23, #0x17b9ca8       | if (info.Permissions != null) goto label_9;
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x017B9CA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_9:
            // 0x017B9CA8: LDR x2, [x25]              | X2 = public System.Void System.Collections.Generic.List<System.String>::Add(System.String item);
            // 0x017B9CAC: MOV x0, x23                | X0 = info.Permissions;//m1              
            // 0x017B9CB0: MOV x1, x24                | X1 = doc;//m1                           
            val_2 = val_1;
            // 0x017B9CB4: BL #0x25ea480              | info.Permissions.Add(item:  val_2 = val_1);
            val_1.Add(item:  val_2);
            label_7:
            // 0x017B9CB8: LDR x8, [x21]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9CBC: MOV x0, x21                | X0 = doc;//m1                           
            // 0x017B9CC0: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_1 = val_1 + 1;
            // 0x017B9CC4: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_168; //  | 
            // 0x017B9CC8: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160();
            // 0x017B9CCC: CMP w22, w0                | STATE = COMPARE((0 + 1), doc)           
            // 0x017B9CD0: B.LT #0x17b9c08            | if (0 < doc) goto label_10;             
            if(val_1 < doc)
            {
                goto label_10;
            }
            label_3:
            // 0x017B9CD4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9CD8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9CDC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x017B9CE0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x017B9CE4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x017B9CE8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B9DFC (24878588), len: 284  VirtAddr: 0x017B9DFC RVA: 0x017B9DFC token: 100684425 methodIndex: 45995 delegateWrapperIndex: 0 methodInvoker: 0
        private string FindInDocument(System.Xml.XmlDocument doc, string keyName, string attribName)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            // 0x017B9DFC: STP x22, x21, [sp, #-0x30]! | stack[1152921513634018368] = ???;  stack[1152921513634018376] = ???;  //  dest_result_addr=1152921513634018368 |  dest_result_addr=1152921513634018376
            // 0x017B9E00: STP x20, x19, [sp, #0x10]  | stack[1152921513634018384] = ???;  stack[1152921513634018392] = ???;  //  dest_result_addr=1152921513634018384 |  dest_result_addr=1152921513634018392
            // 0x017B9E04: STP x29, x30, [sp, #0x20]  | stack[1152921513634018400] = ???;  stack[1152921513634018408] = ???;  //  dest_result_addr=1152921513634018400 |  dest_result_addr=1152921513634018408
            // 0x017B9E08: ADD x29, sp, #0x20         | X29 = (1152921513634018368 + 32) = 1152921513634018400 (0x100000021A0FB460);
            // 0x017B9E0C: MOV x19, x3                | X19 = attribName;//m1                   
            // 0x017B9E10: MOV x20, x2                | X20 = keyName;//m1                      
            // 0x017B9E14: MOV x21, x1                | X21 = doc;//m1                          
            val_1 = doc;
            // 0x017B9E18: CBNZ x21, #0x17b9e20       | if (doc != null) goto label_0;          
            if(val_1 != null)
            {
                goto label_0;
            }
            // 0x017B9E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x017B9E20: LDR x8, [x21]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9E24: MOV x0, x21                | X0 = doc;//m1                           
            // 0x017B9E28: MOV x1, x20                | X1 = keyName;//m1                       
            // 0x017B9E2C: LDR x9, [x8, #0x460]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_460;
            // 0x017B9E30: LDR x2, [x8, #0x468]       | X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_468;
            // 0x017B9E34: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_460();
            // 0x017B9E38: MOV x20, x0                | X20 = doc;//m1                          
            // 0x017B9E3C: CBZ x20, #0x17b9ee8        | if (doc == null) goto label_2;          
            if(val_1 == null)
            {
                goto label_2;
            }
            // 0x017B9E40: LDR x8, [x20]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9E44: MOV x0, x20                | X0 = doc;//m1                           
            // 0x017B9E48: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_168; //  | 
            // 0x017B9E4C: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160();
            // 0x017B9E50: CMP w0, #1                 | STATE = COMPARE(doc, 0x1)               
            // 0x017B9E54: B.LT #0x17b9ee8            | if (val_1 < 0x1) goto label_2;          
            if(val_1 < 1)
            {
                goto label_2;
            }
            // 0x017B9E58: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_7:
            // 0x017B9E5C: LDR x8, [x20]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9E60: MOV x0, x20                | X0 = doc;//m1                           
            // 0x017B9E64: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
            // 0x017B9E68: LDP x9, x2, [x8, #0x190]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190; X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_198; //  | 
            // 0x017B9E6C: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_190();
            // 0x017B9E70: MOV x22, x0                | X22 = doc;//m1                          
            // 0x017B9E74: CBNZ x22, #0x17b9e7c       | if (doc != null) goto label_3;          
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x017B9E78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_3:
            // 0x017B9E7C: LDR x8, [x22]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9E80: MOV x0, x22                | X0 = doc;//m1                           
            // 0x017B9E84: LDR x9, [x8, #0x240]       | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_240;
            // 0x017B9E88: LDR x1, [x8, #0x248]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_248;
            // 0x017B9E8C: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_240();
            // 0x017B9E90: CMP w0, #1                 | STATE = COMPARE(doc, 0x1)               
            // 0x017B9E94: B.NE #0x17b9ecc            | if (val_1 != 0x1) goto label_4;         
            if(val_1 != 1)
            {
                goto label_4;
            }
            // 0x017B9E98: LDR x8, [x22]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9E9C: MOV x0, x22                | X0 = doc;//m1                           
            // 0x017B9EA0: LDP x9, x1, [x8, #0x170]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_170; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_178; //  | 
            // 0x017B9EA4: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_170();
            // 0x017B9EA8: MOV x22, x0                | X22 = doc;//m1                          
            // 0x017B9EAC: CBNZ x22, #0x17b9eb4       | if (doc != null) goto label_5;          
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x017B9EB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? doc, ????);        
            label_5:
            // 0x017B9EB4: LDR x8, [x22]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9EB8: MOV x0, x22                | X0 = doc;//m1                           
            // 0x017B9EBC: MOV x1, x19                | X1 = attribName;//m1                    
            val_2 = attribName;
            // 0x017B9EC0: LDP x9, x2, [x8, #0x180]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_180; X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_188; //  | 
            // 0x017B9EC4: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_180();
            // 0x017B9EC8: CBNZ x0, #0x17b9efc        | if (doc != null) goto label_6;          
            if(val_1 != null)
            {
                goto label_6;
            }
            label_4:
            // 0x017B9ECC: LDR x8, [x20]              | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9ED0: MOV x0, x20                | X0 = doc;//m1                           
            // 0x017B9ED4: ADD w21, w21, #1           | W21 = (0 + 1);                          
            val_1 = 0 + 1;
            // 0x017B9ED8: LDP x9, x1, [x8, #0x160]   | X9 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160; X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_168; //  | 
            // 0x017B9EDC: BLR x9                     | X0 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_160();
            // 0x017B9EE0: CMP w21, w0                | STATE = COMPARE((0 + 1), doc)           
            // 0x017B9EE4: B.LT #0x17b9e5c            | if (val_1 < val_1) goto label_7;        
            if(val_1 < val_1)
            {
                goto label_7;
            }
            label_2:
            // 0x017B9EE8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9EEC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9EF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B9EF4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B9EF8: RET                        |  return (System.String)null;            
            return (string)0;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_6:
            // 0x017B9EFC: LDR x8, [x0]               | X8 = typeof(System.Xml.XmlDocument);    
            // 0x017B9F00: LDR x2, [x8, #0x290]       | X2 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
            // 0x017B9F04: LDR x1, [x8, #0x298]       | X1 = typeof(System.Xml.XmlDocument).__il2cppRuntimeField_298;
            // 0x017B9F08: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B9F0C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B9F10: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B9F14: BR x2                      | goto typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
            goto typeof(System.Xml.XmlDocument).__il2cppRuntimeField_290;
        
        }
        //
        // Offset in libil2cpp.so: 0x017BBD34 (24886580), len: 100  VirtAddr: 0x017BBD34 RVA: 0x017BBD34 token: 100684426 methodIndex: 45996 delegateWrapperIndex: 0 methodInvoker: 0
        private static ApkReader()
        {
            //
            // Disasemble & Code
            // 0x017BBD34: STP x20, x19, [sp, #-0x20]! | stack[1152921513634142672] = ???;  stack[1152921513634142680] = ???;  //  dest_result_addr=1152921513634142672 |  dest_result_addr=1152921513634142680
            // 0x017BBD38: STP x29, x30, [sp, #0x10]  | stack[1152921513634142688] = ???;  stack[1152921513634142696] = ???;  //  dest_result_addr=1152921513634142688 |  dest_result_addr=1152921513634142696
            // 0x017BBD3C: ADD x29, sp, #0x10         | X29 = (1152921513634142672 + 16) = 1152921513634142688 (0x100000021A1199E0);
            // 0x017BBD40: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017BBD44: LDRB w8, [x19, #0x95c]     | W8 = (bool)static_value_0373895C;       
            // 0x017BBD48: TBNZ w8, #0, #0x17bbd64    | if (static_value_0373895C == true) goto label_0;
            // 0x017BBD4C: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x017BBD50: LDR x8, [x8, #0x8a0]       | X8 = 0x2B8B014;                         
            // 0x017BBD54: LDR w0, [x8]               | W0 = 0x2C3;                             
            // 0x017BBD58: BL #0x2782188              | X0 = sub_2782188( ?? 0x2C3, ????);      
            // 0x017BBD5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017BBD60: STRB w8, [x19, #0x95c]     | static_value_0373895C = true;            //  dest_result_addr=57903452
            label_0:
            // 0x017BBD64: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x017BBD68: LDR x8, [x8, #0x400]       | X8 = 1152921504856633344;               
            // 0x017BBD6C: ORR w10, wzr, #1           | W10 = 1(0x1);                           
            // 0x017BBD70: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkReader);
            // 0x017BBD74: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BBD78: STR w10, [x9, #4]          | Iteedee.ApkReader.ApkReader.ICN_ID = 1;  //  dest_result_addr=1152921504856637444
            Iteedee.ApkReader.ApkReader.ICN_ID = 1;
            // 0x017BBD7C: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.ApkReader);
            // 0x017BBD80: ORR w9, wzr, #2            | W9 = 2(0x2);                            
            // 0x017BBD84: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkReader.__il2cppRuntimeField_static_fields;
            // 0x017BBD88: STR w9, [x8, #8]           | Iteedee.ApkReader.ApkReader.LABEL_ID = 2;  //  dest_result_addr=1152921504856637448
            Iteedee.ApkReader.ApkReader.LABEL_ID = 2;
            // 0x017BBD8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017BBD90: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017BBD94: RET                        |  return;                                
            return;
        
        }
    
    }

}
