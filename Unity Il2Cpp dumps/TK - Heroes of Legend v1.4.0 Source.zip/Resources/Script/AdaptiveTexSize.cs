using UnityEngine;
[Serializable]
public enum Tonemapping.AdaptiveTexSize
{
    // Fields
    Square16 = 16
    ,Square32 = 32
    ,Square64 = 64
    ,Square128 = 128
    ,Square256 = 256
    ,Square512 = 512
    ,Square1024 = 1024
    

}
