using UnityEngine;
public sealed class BetterList.CompareFunc<T> : MulticastDelegate
{
    // Methods
    // Generic instance method:
    //
    // file offset: 0x019BE8B0 VirtAddr: 0x019BE8B0 -RVA: 0x019BE8B0 
    // -BetterList.CompareFunc<object>..ctor
    // -BetterList.CompareFunc<UICamera>..ctor
    //
    // file offset: 0x019BF4F0 VirtAddr: 0x019BF4F0 -RVA: 0x019BF4F0 
    // -BetterList.CompareFunc<UICamera.DepthEntry>..ctor
    //
    // file offset: 0x019BE588 VirtAddr: 0x019BE588 -RVA: 0x019BE588 
    // -BetterList.CompareFunc<int>..ctor
    //
    // file offset: 0x019BECFC VirtAddr: 0x019BECFC -RVA: 0x019BECFC 
    // -BetterList.CompareFunc<float>..ctor
    //
    // file offset: 0x019BF024 VirtAddr: 0x019BF024 -RVA: 0x019BF024 
    // -BetterList.CompareFunc<TypewriterEffect.FadeEntry>..ctor
    //
    // file offset: 0x019BF9C4 VirtAddr: 0x019BF9C4 -RVA: 0x019BF9C4 
    // -BetterList.CompareFunc<UnityEngine.Color>..ctor
    //
    // file offset: 0x019BFDB0 VirtAddr: 0x019BFDB0 -RVA: 0x019BFDB0 
    // -BetterList.CompareFunc<UnityEngine.Color32>..ctor
    //
    // file offset: 0x019C0100 VirtAddr: 0x019C0100 -RVA: 0x019C0100 
    // -BetterList.CompareFunc<UnityEngine.Vector2>..ctor
    //
    // file offset: 0x019C046C VirtAddr: 0x019C046C -RVA: 0x019C046C 
    // -BetterList.CompareFunc<UnityEngine.Vector3>..ctor
    //
    // file offset: 0x019C0818 VirtAddr: 0x019C0818 -RVA: 0x019C0818 
    // -BetterList.CompareFunc<UnityEngine.Vector4>..ctor
    //
    //
    // Offset in libil2cpp.so: 0x019BE8B0 (26994864), len: 16  VirtAddr: 0x019BE8B0 RVA: 0x019BE8B0 token: 100687864 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public BetterList.CompareFunc<T>(object object, IntPtr method)
    {
        //
        // Disasemble & Code
        // 0x019BE8B0: LDR x8, [x2]               | X8 = method;                            
        // 0x019BE8B4: STP x1, x2, [x0, #0x20]    | mem[1152921514154357072] = object;  mem[1152921514154357080] = method;  //  dest_result_addr=1152921514154357072 |  dest_result_addr=1152921514154357080
        mem[1152921514154357072] = object;
        mem[1152921514154357080] = method;
        // 0x019BE8B8: STR x8, [x0, #0x10]        | mem[1152921514154357056] = method;       //  dest_result_addr=1152921514154357056
        mem[1152921514154357056] = method;
        // 0x019BE8BC: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019BE8C0 VirtAddr: 0x019BE8C0 -RVA: 0x019BE8C0 
    // -BetterList.CompareFunc<object>.Invoke
    //
    // file offset: 0x019BE598 VirtAddr: 0x019BE598 -RVA: 0x019BE598 
    // -BetterList.CompareFunc<int>.Invoke
    //
    // file offset: 0x019BED0C VirtAddr: 0x019BED0C -RVA: 0x019BED0C 
    // -BetterList.CompareFunc<float>.Invoke
    //
    // file offset: 0x019BF034 VirtAddr: 0x019BF034 -RVA: 0x019BF034 
    // -BetterList.CompareFunc<TypewriterEffect.FadeEntry>.Invoke
    //
    // file offset: 0x019BF500 VirtAddr: 0x019BF500 -RVA: 0x019BF500 
    // -BetterList.CompareFunc<UICamera.DepthEntry>.Invoke
    //
    // file offset: 0x019BF9D4 VirtAddr: 0x019BF9D4 -RVA: 0x019BF9D4 
    // -BetterList.CompareFunc<UnityEngine.Color>.Invoke
    //
    // file offset: 0x019BFDC0 VirtAddr: 0x019BFDC0 -RVA: 0x019BFDC0 
    // -BetterList.CompareFunc<UnityEngine.Color32>.Invoke
    //
    // file offset: 0x019C0110 VirtAddr: 0x019C0110 -RVA: 0x019C0110 
    // -BetterList.CompareFunc<UnityEngine.Vector2>.Invoke
    //
    // file offset: 0x019C047C VirtAddr: 0x019C047C -RVA: 0x019C047C 
    // -BetterList.CompareFunc<UnityEngine.Vector3>.Invoke
    //
    // file offset: 0x019C0828 VirtAddr: 0x019C0828 -RVA: 0x019C0828 
    // -BetterList.CompareFunc<UnityEngine.Vector4>.Invoke
    //
    //
    // Offset in libil2cpp.so: 0x019BE8C0 (26994880), len: 968  VirtAddr: 0x019BE8C0 RVA: 0x019BE8C0 token: 100687865 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual int Invoke(T left, T right)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        label_1:
        // 0x019BE8C0: STP x24, x23, [sp, #-0x40]! | stack[1152921514154485648] = ???;  stack[1152921514154485656] = ???;  //  dest_result_addr=1152921514154485648 |  dest_result_addr=1152921514154485656
        // 0x019BE8C4: STP x22, x21, [sp, #0x10]  | stack[1152921514154485664] = ???;  stack[1152921514154485672] = ???;  //  dest_result_addr=1152921514154485664 |  dest_result_addr=1152921514154485672
        // 0x019BE8C8: STP x20, x19, [sp, #0x20]  | stack[1152921514154485680] = ???;  stack[1152921514154485688] = ???;  //  dest_result_addr=1152921514154485680 |  dest_result_addr=1152921514154485688
        // 0x019BE8CC: STP x29, x30, [sp, #0x30]  | stack[1152921514154485696] = ???;  stack[1152921514154485704] = ???;  //  dest_result_addr=1152921514154485696 |  dest_result_addr=1152921514154485704
        // 0x019BE8D0: ADD x29, sp, #0x30         | X29 = (1152921514154485648 + 48) = 1152921514154485696 (0x10000002391567C0);
        // 0x019BE8D4: SUB sp, sp, #0x10          | SP = (1152921514154485648 - 16) = 1152921514154485632 (0x1000000239156780);
        // 0x019BE8D8: MOV x23, x0                | X23 = 1152921514154497712 (0x10000002391596B0);//ML01
        // 0x019BE8DC: LDR x0, [x23, #0x58]       | 
        // 0x019BE8E0: MOV x19, x2                | X19 = right;//m1                        
        // 0x019BE8E4: MOV x20, x1                | X20 = left;//m1                         
        // 0x019BE8E8: CBZ x0, #0x19be8f8         | if (this == null) goto label_0;         
        if(this == null)
        {
            goto label_0;
        }
        // 0x019BE8EC: MOV x1, x20                | X1 = left;//m1                          
        // 0x019BE8F0: MOV x2, x19                | X2 = right;//m1                         
        val_13 = right;
        // 0x019BE8F4: BL #0x19be8c0              |  R0 = label_1();                        
        label_0:
        // 0x019BE8F8: LDR x0, [x23, #0x10]       | 
        // 0x019BE8FC: STR x0, [sp, #8]           | stack[1152921514154485640] = this;       //  dest_result_addr=1152921514154485640
        // 0x019BE900: LDP x22, x21, [x23, #0x20] |                                          //  | 
        // 0x019BE904: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BE908: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
        // 0x019BE90C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BE910: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
        // 0x019BE914: LDRB w9, [x21, #0x4e]      | W9 = X21 + 78;                          
        // 0x019BE918: AND w8, w0, #1             | W8 = (X21 & 1);                         
        var val_1 = X21 & 1;
        // 0x019BE91C: TBZ w8, #0, #0x19be9b8     | if (((X21 & 1) & 0x1) == 0) goto label_2;
        if((val_1 & 1) == 0)
        {
            goto label_2;
        }
        // 0x019BE920: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x019BE924: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
        // 0x019BE928: B.NE #0x19be9c8            | if (X21 + 78 != 0x2) goto label_3;      
        if((X21 + 78) != 2)
        {
            goto label_3;
        }
        // 0x019BE92C: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
        // 0x019BE930: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
        // 0x019BE934: B.EQ #0x19bea84            | if (X21 + 76 == 65535) goto label_7;    
        if((X21 + 76) == 65535)
        {
            goto label_7;
        }
        // 0x019BE938: CBZ x22, #0x19be948        | if (X22 == 0) goto label_5;             
        if(X22 == 0)
        {
            goto label_5;
        }
        // 0x019BE93C: LDR x8, [x22]              | X8 = X22;                               
        // 0x019BE940: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
        // 0x019BE944: TBNZ w8, #0, #0x19bea84    | if ((X22 + 237 & 0x1) != 0) goto label_7;
        if(((X22 + 237) & 1) != 0)
        {
            goto label_7;
        }
        label_5:
        // 0x019BE948: LDR x8, [x23, #0x18]       | 
        // 0x019BE94C: CBZ x8, #0x19bea84         | if (X22 + 237 == 0) goto label_7;       
        if((X22 + 237) == 0)
        {
            goto label_7;
        }
        // 0x019BE950: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BE954: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
        // 0x019BE958: MOV w23, w0                | W23 = X21;//m1                          
        // 0x019BE95C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BE960: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_2 = X21.pressedSprite;
        // 0x019BE964: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
        // 0x019BE968: TBZ w23, #0, #0x19bead8    | if ((X21 & 0x1) == 0) goto label_8;     
        if((X21 & 1) == 0)
        {
            goto label_8;
        }
        // 0x019BE96C: TBZ w0, #0, #0x19beb90     | if ((val_2 & 0x1) == 0) goto label_9;   
        if((val_2 & 1) == 0)
        {
            goto label_9;
        }
        // 0x019BE970: LDR x8, [x22]              | X8 = X22;                               
        var val_19 = X22;
        // 0x019BE974: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
        // 0x019BE978: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
        // 0x019BE97C: LDRH w9, [x8, #0x102]      | W9 = X22 + 258;                         
        // 0x019BE980: CBZ x9, #0x19be9ac         | if (X22 + 258 == 0) goto label_10;      
        if((X22 + 258) == 0)
        {
            goto label_10;
        }
        // 0x019BE984: LDR x10, [x8, #0x98]       | X10 = X22 + 152;                        
        var val_11 = X22 + 152;
        // 0x019BE988: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_12 = 0;
        // 0x019BE98C: ADD x10, x10, #8           | X10 = (X22 + 152 + 8);                  
        val_11 = val_11 + 8;
        label_12:
        // 0x019BE990: LDUR x12, [x10, #-8]       | X12 = (X22 + 152 + 8) + -8;             
        // 0x019BE994: CMP x12, x1                | STATE = COMPARE((X22 + 152 + 8) + -8, X21 + 24)
        // 0x019BE998: B.EQ #0x19bebd8            | if ((X22 + 152 + 8) + -8 == X21 + 24) goto label_11;
        if(((X22 + 152 + 8) + -8) == (X21 + 24))
        {
            goto label_11;
        }
        // 0x019BE99C: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_12 = val_12 + 1;
        // 0x019BE9A0: ADD x10, x10, #0x10        | X10 = ((X22 + 152 + 8) + 16);           
        val_11 = val_11 + 16;
        // 0x019BE9A4: CMP x11, x9                | STATE = COMPARE((0 + 1), X22 + 258)     
        // 0x019BE9A8: B.LO #0x19be990            | if (0 < X22 + 258) goto label_12;       
        if(val_12 < (X22 + 258))
        {
            goto label_12;
        }
        label_10:
        // 0x019BE9AC: MOV x0, x22                | X0 = X22;//m1                           
        val_14 = X22;
        // 0x019BE9B0: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
        // 0x019BE9B4: B #0x19bebe8               |  goto label_13;                         
        goto label_13;
        label_2:
        // 0x019BE9B8: CMP w9, #2                 | STATE = COMPARE(X21 + 78, 0x2)          
        // 0x019BE9BC: B.NE #0x19bea54            | if (X21 + 78 != 0x2) goto label_14;     
        if((X21 + 78) != 2)
        {
            goto label_14;
        }
        // 0x019BE9C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x019BE9C4: B #0x19bea88               |  goto label_15;                         
        goto label_15;
        label_3:
        // 0x019BE9C8: ORR w9, wzr, #0xffff       | W9 = 65535(0xFFFF);                     
        // 0x019BE9CC: CMP w8, w9                 | STATE = COMPARE(X21 + 76, 0xFFFF)       
        // 0x019BE9D0: B.EQ #0x19beab0            | if (X21 + 76 == 65535) goto label_19;   
        if((X21 + 76) == 65535)
        {
            goto label_19;
        }
        // 0x019BE9D4: CBZ x22, #0x19be9e4        | if (X22 == 0) goto label_17;            
        if(X22 == 0)
        {
            goto label_17;
        }
        // 0x019BE9D8: LDR x8, [x22]              | X8 = X22;                               
        // 0x019BE9DC: LDRB w8, [x8, #0xed]       | W8 = X22 + 237;                         
        // 0x019BE9E0: TBNZ w8, #0, #0x19beab0    | if ((X22 + 237 & 0x1) != 0) goto label_19;
        if(((X22 + 237) & 1) != 0)
        {
            goto label_19;
        }
        label_17:
        // 0x019BE9E4: LDR x8, [x23, #0x18]       | 
        // 0x019BE9E8: CBZ x8, #0x19beab0         | if (X22 + 237 == 0) goto label_19;      
        if((X22 + 237) == 0)
        {
            goto label_19;
        }
        // 0x019BE9EC: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BE9F0: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
        // 0x019BE9F4: MOV w22, w0                | W22 = X21;//m1                          
        // 0x019BE9F8: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BE9FC: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_3 = X21.pressedSprite;
        // 0x019BEA00: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_3, ????);      
        // 0x019BEA04: TBZ w22, #0, #0x19beb34    | if ((X21 & 0x1) == 0) goto label_20;    
        if((X21 & 1) == 0)
        {
            goto label_20;
        }
        // 0x019BEA08: TBZ w0, #0, #0x19beba4     | if ((val_3 & 0x1) == 0) goto label_21;  
        if((val_3 & 1) == 0)
        {
            goto label_21;
        }
        // 0x019BEA0C: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x019BEA10: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
        // 0x019BEA14: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
        // 0x019BEA18: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
        // 0x019BEA1C: CBZ x9, #0x19bea48         | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_22;
        // 0x019BEA20: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
        // 0x019BEA24: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x019BEA28: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
        label_24:
        // 0x019BEA2C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x019BEA30: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, X21 + 24)
        // 0x019BEA34: B.EQ #0x19bec10            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == X21 + 24) goto label_23;
        // 0x019BEA38: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x019BEA3C: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
        // 0x019BEA40: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
        // 0x019BEA44: B.LO #0x19bea2c            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_24;
        label_22:
        // 0x019BEA48: MOV x0, x20                | X0 = left;//m1                          
        val_15 = left;
        // 0x019BEA4C: BL #0x2776c24              | X0 = sub_2776C24( ?? left, ????);       
        // 0x019BEA50: B #0x19bec20               |  goto label_25;                         
        goto label_25;
        label_14:
        // 0x019BEA54: LDR x5, [sp, #8]           | X5 = this;                              
        // 0x019BEA58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x019BEA5C: MOV x1, x22                | X1 = X22;//m1                           
        // 0x019BEA60: MOV x2, x20                | X2 = left;//m1                          
        // 0x019BEA64: MOV x3, x19                | X3 = right;//m1                         
        // 0x019BEA68: MOV x4, x21                | X4 = X21;//m1                           
        // 0x019BEA6C: SUB sp, x29, #0x30         | SP = (1152921514154485696 - 48) = 1152921514154485648 (0x1000000239156790);
        // 0x019BEA70: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019BEA74: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019BEA78: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019BEA7C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019BEA80: BR x5                      | X0 = this( ?? 0x0, ????);               
        label_7:
        // 0x019BEA84: MOV x0, x22                | X0 = X22;//m1                           
        label_15:
        // 0x019BEA88: LDR x4, [sp, #8]           | X4 = this;                              
        // 0x019BEA8C: MOV x1, x20                | X1 = left;//m1                          
        // 0x019BEA90: MOV x2, x19                | X2 = right;//m1                         
        // 0x019BEA94: MOV x3, x21                | X3 = X21;//m1                           
        label_42:
        // 0x019BEA98: SUB sp, x29, #0x30         | SP = (1152921514154485696 - 48) = 1152921514154485648 (0x1000000239156790);
        // 0x019BEA9C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019BEAA0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019BEAA4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019BEAA8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019BEAAC: BR x4                      | X0 = this( ?? X22, ????);               
        label_19:
        // 0x019BEAB0: LDR x3, [sp, #8]           | X3 = this;                              
        // 0x019BEAB4: MOV x0, x20                | X0 = left;//m1                          
        // 0x019BEAB8: MOV x1, x19                | X1 = right;//m1                         
        // 0x019BEABC: MOV x2, x21                | X2 = X21;//m1                           
        label_43:
        // 0x019BEAC0: SUB sp, x29, #0x30         | SP = (1152921514154485696 - 48) = 1152921514154485648 (0x1000000239156790);
        // 0x019BEAC4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019BEAC8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019BEACC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019BEAD0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019BEAD4: BR x3                      | X0 = this( ?? left, ????);              
        label_8:
        // 0x019BEAD8: LDRH w23, [x21, #0x4c]     | W23 = X21 + 76;                         
        // 0x019BEADC: TBZ w0, #0, #0x19bebb8     | if ((val_2 & 0x1) == 0) goto label_26;  
        if((val_2 & 1) == 0)
        {
            goto label_26;
        }
        // 0x019BEAE0: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BEAE4: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_4 = X21.pressedSprite;
        // 0x019BEAE8: LDR x9, [x22]              | X9 = X22;                               
        // 0x019BEAEC: MOV x8, x0                 | X8 = val_4;//m1                         
        // 0x019BEAF0: LDRH w10, [x9, #0x102]     | W10 = X22 + 258;                        
        // 0x019BEAF4: CBZ x10, #0x19beb20        | if (X22 + 258 == 0) goto label_27;      
        if((X22 + 258) == 0)
        {
            goto label_27;
        }
        // 0x019BEAF8: LDR x11, [x9, #0x98]       | X11 = X22 + 152;                        
        var val_14 = X22 + 152;
        // 0x019BEAFC: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_15 = 0;
        // 0x019BEB00: ADD x11, x11, #8           | X11 = (X22 + 152 + 8);                  
        val_14 = val_14 + 8;
        label_29:
        // 0x019BEB04: LDUR x13, [x11, #-8]       | X13 = (X22 + 152 + 8) + -8;             
        // 0x019BEB08: CMP x13, x8                | STATE = COMPARE((X22 + 152 + 8) + -8, val_4)
        // 0x019BEB0C: B.EQ #0x19bec44            | if ((X22 + 152 + 8) + -8 == val_4) goto label_28;
        if(((X22 + 152 + 8) + -8) == val_4)
        {
            goto label_28;
        }
        // 0x019BEB10: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_15 = val_15 + 1;
        // 0x019BEB14: ADD x11, x11, #0x10        | X11 = ((X22 + 152 + 8) + 16);           
        val_14 = val_14 + 16;
        // 0x019BEB18: CMP x12, x10               | STATE = COMPARE((0 + 1), X22 + 258)     
        // 0x019BEB1C: B.LO #0x19beb04            | if (0 < X22 + 258) goto label_29;       
        if(val_15 < (X22 + 258))
        {
            goto label_29;
        }
        label_27:
        // 0x019BEB20: MOV x0, x22                | X0 = X22;//m1                           
        val_16 = X22;
        // 0x019BEB24: MOV x1, x8                 | X1 = val_4;//m1                         
        // 0x019BEB28: MOV w2, w23                | W2 = X21 + 76;//m1                      
        // 0x019BEB2C: BL #0x2776c24              | X0 = sub_2776C24( ?? X22, ????);        
        // 0x019BEB30: B #0x19bec54               |  goto label_30;                         
        goto label_30;
        label_20:
        // 0x019BEB34: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
        // 0x019BEB38: TBZ w0, #0, #0x19bebc8     | if ((val_3 & 0x1) == 0) goto label_31;  
        if((val_3 & 1) == 0)
        {
            goto label_31;
        }
        // 0x019BEB3C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x019BEB40: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_5 = X21.pressedSprite;
        // 0x019BEB44: LDR x9, [x20]              | X9 = typeof(System.Object);             
        // 0x019BEB48: MOV x8, x0                 | X8 = val_5;//m1                         
        // 0x019BEB4C: LDRH w10, [x9, #0x102]     | W10 = System.Object.__il2cppRuntimeField_interface_offsets_count;
        // 0x019BEB50: CBZ x10, #0x19beb7c        | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_32;
        // 0x019BEB54: LDR x11, [x9, #0x98]       | X11 = System.Object.__il2cppRuntimeField_interfaceOffsets;
        // 0x019BEB58: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_16 = 0;
        // 0x019BEB5C: ADD x11, x11, #8           | X11 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
        label_34:
        // 0x019BEB60: LDUR x13, [x11, #-8]       | X13 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
        // 0x019BEB64: CMP x13, x8                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, val_5)
        // 0x019BEB68: B.EQ #0x19bec68            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == val_5) goto label_33;
        // 0x019BEB6C: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_16 = val_16 + 1;
        // 0x019BEB70: ADD x11, x11, #0x10        | X11 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
        // 0x019BEB74: CMP x12, x10               | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
        // 0x019BEB78: B.LO #0x19beb60            | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_34;
        label_32:
        // 0x019BEB7C: MOV x0, x20                | X0 = left;//m1                          
        val_17 = left;
        // 0x019BEB80: MOV x1, x8                 | X1 = val_5;//m1                         
        // 0x019BEB84: MOV w2, w22                | W2 = X21 + 76;//m1                      
        val_13 = X21 + 76;
        // 0x019BEB88: BL #0x2776c24              | X0 = sub_2776C24( ?? left, ????);       
        // 0x019BEB8C: B #0x19bec78               |  goto label_35;                         
        goto label_35;
        label_9:
        // 0x019BEB90: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x019BEB94: LDR x9, [x22]              | X9 = X22;                               
        // 0x019BEB98: ADD x8, x9, x8, lsl #4     | X8 = (X22 + (X21 + 76) << 4);           
        var val_6 = X22 + ((X21 + 76) << 4);
        // 0x019BEB9C: LDR x0, [x8, #0x118]       | X0 = (X22 + (X21 + 76) << 4) + 280;     
        val_18 = mem[(X22 + (X21 + 76) << 4) + 280];
        val_18 = (X22 + (X21 + 76) << 4) + 280;
        // 0x019BEBA0: B #0x19bebec               |  goto label_36;                         
        goto label_36;
        label_21:
        // 0x019BEBA4: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x019BEBA8: LDR x9, [x20]              | X9 = typeof(System.Object);             
        // 0x019BEBAC: ADD x8, x9, x8, lsl #4     | X8 = (1152921504606900224 + (X21 + 76) << 4);
        object val_7 = 1152921504606900224 + ((X21 + 76) << 4);
        // 0x019BEBB0: LDR x0, [x8, #0x118]       |  //  not_find_field!1:280
        val_19 = mem[(1152921504606900224 + (X21 + 76) << 4) + 280];
        // 0x019BEBB4: B #0x19bec24               |  goto label_37;                         
        goto label_37;
        label_26:
        // 0x019BEBB8: LDR x8, [x22]              | X8 = X22;                               
        var val_17 = X22;
        // 0x019BEBBC: ADD x8, x8, w23, uxtw #4   | X8 = (X22 + X21 + 76);                  
        val_17 = val_17 + (X21 + 76);
        // 0x019BEBC0: LDP x4, x3, [x8, #0x110]   | X4 = (X22 + X21 + 76) + 272; X3 = (X22 + X21 + 76) + 272 + 8; //  | 
        // 0x019BEBC4: B #0x19bec58               |  goto label_38;                         
        goto label_38;
        label_31:
        // 0x019BEBC8: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x019BEBCC: ADD x8, x8, w22, uxtw #4   | X8 = (1152921504606900224 + X21 + 76);  
        object val_8 = 1152921504606900224 + (X21 + 76);
        // 0x019BEBD0: LDP x3, x2, [x8, #0x110]   |                                          //  not_find_field!1:272 |  not_find_field!1:280
        // 0x019BEBD4: B #0x19bec7c               |  goto label_39;                         
        goto label_39;
        label_11:
        // 0x019BEBD8: LDR w9, [x10]              | W9 = (X22 + 152 + 8);                   
        var val_18 = val_11;
        // 0x019BEBDC: ADD w9, w9, w2             | W9 = ((X22 + 152 + 8) + X21 + 76);      
        val_18 = val_18 + (X21 + 76);
        // 0x019BEBE0: ADD x8, x8, w9, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
        val_19 = val_19 + val_18;
        // 0x019BEBE4: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
        val_14 = val_19 + 272;
        label_13:
        // 0x019BEBE8: LDR x0, [x0, #8]           | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
        val_18 = mem[((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8];
        val_18 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
        label_36:
        // 0x019BEBEC: MOV x1, x21                | X1 = X21;//m1                           
        // 0x019BEBF0: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
        // 0x019BEBF4: MOV x8, x0                 | X8 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
        // 0x019BEBF8: LDR x4, [x8]               | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;
        // 0x019BEBFC: MOV x0, x22                | X0 = X22;//m1                           
        // 0x019BEC00: MOV x1, x20                | X1 = left;//m1                          
        // 0x019BEC04: MOV x2, x19                | X2 = right;//m1                         
        // 0x019BEC08: MOV x3, x8                 | X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
        // 0x019BEC0C: B #0x19bea98               |  goto label_42;                         
        goto label_42;
        label_23:
        // 0x019BEC10: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x019BEC14: ADD w9, w9, w2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
        // 0x019BEC18: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
        // 0x019BEC1C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
        label_25:
        // 0x019BEC20: LDR x0, [x0, #8]           | 
        label_37:
        // 0x019BEC24: MOV x1, x21                | X1 = X21;//m1                           
        // 0x019BEC28: BL #0x2796ec8              | X0 = sub_2796EC8( ?? val_3, ????);      
        // 0x019BEC2C: MOV x8, x0                 | X8 = val_3;//m1                         
        // 0x019BEC30: LDR x3, [x8]               | X3 = typeof(UnityEngine.Sprite);        
        // 0x019BEC34: MOV x0, x20                | X0 = left;//m1                          
        // 0x019BEC38: MOV x1, x19                | X1 = right;//m1                         
        // 0x019BEC3C: MOV x2, x8                 | X2 = val_3;//m1                         
        // 0x019BEC40: B #0x19beac0               |  goto label_43;                         
        goto label_43;
        label_28:
        // 0x019BEC44: LDR w8, [x11]              | W8 = (X22 + 152 + 8);                   
        var val_20 = val_14;
        // 0x019BEC48: ADD w8, w8, w23            | W8 = ((X22 + 152 + 8) + X21 + 76);      
        val_20 = val_20 + (X21 + 76);
        // 0x019BEC4C: ADD x8, x9, w8, uxtw #4    | X8 = (X22 + ((X22 + 152 + 8) + X21 + 76));
        val_20 = X22 + val_20;
        // 0x019BEC50: ADD x0, x8, #0x110         | X0 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272);
        val_16 = val_20 + 272;
        label_30:
        // 0x019BEC54: LDP x4, x3, [x0]           | X4 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272); X3 = ((X22 + ((X22 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
        label_38:
        // 0x019BEC58: MOV x0, x22                | X0 = X22;//m1                           
        // 0x019BEC5C: MOV x1, x20                | X1 = left;//m1                          
        // 0x019BEC60: MOV x2, x19                | X2 = right;//m1                         
        // 0x019BEC64: B #0x19bea98               |  goto label_42;                         
        goto label_42;
        label_33:
        // 0x019BEC68: LDR w8, [x11]              | W8 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
        // 0x019BEC6C: ADD w8, w8, w22            | W8 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76);
        // 0x019BEC70: ADD x8, x9, w8, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76));
        // 0x019BEC74: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + X21 + 76)).272
        label_35:
        // 0x019BEC78: LDP x3, x2, [x0]           | X3 = typeof(UnityEngine.Sprite);         //  | 
        label_39:
        // 0x019BEC7C: MOV x0, x20                | X0 = left;//m1                          
        // 0x019BEC80: MOV x1, x19                | X1 = right;//m1                         
        // 0x019BEC84: B #0x19beac0               |  goto label_43;                         
        goto label_43;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019BEC88 VirtAddr: 0x019BEC88 -RVA: 0x019BEC88 
    // -BetterList.CompareFunc<object>.BeginInvoke
    //
    // file offset: 0x019BE7CC VirtAddr: 0x019BE7CC -RVA: 0x019BE7CC 
    // -BetterList.CompareFunc<int>.BeginInvoke
    //
    // file offset: 0x019BEF40 VirtAddr: 0x019BEF40 -RVA: 0x019BEF40 
    // -BetterList.CompareFunc<float>.BeginInvoke
    //
    // file offset: 0x019BF400 VirtAddr: 0x019BF400 -RVA: 0x019BF400 
    // -BetterList.CompareFunc<TypewriterEffect.FadeEntry>.BeginInvoke
    //
    // file offset: 0x019BF8D4 VirtAddr: 0x019BF8D4 -RVA: 0x019BF8D4 
    // -BetterList.CompareFunc<UICamera.DepthEntry>.BeginInvoke
    //
    // file offset: 0x019BFCBC VirtAddr: 0x019BFCBC -RVA: 0x019BFCBC 
    // -BetterList.CompareFunc<UnityEngine.Color>.BeginInvoke
    //
    // file offset: 0x019C0018 VirtAddr: 0x019C0018 -RVA: 0x019C0018 
    // -BetterList.CompareFunc<UnityEngine.Color32>.BeginInvoke
    //
    // file offset: 0x019C0380 VirtAddr: 0x019C0380 -RVA: 0x019C0380 
    // -BetterList.CompareFunc<UnityEngine.Vector2>.BeginInvoke
    //
    // file offset: 0x019C0728 VirtAddr: 0x019C0728 -RVA: 0x019C0728 
    // -BetterList.CompareFunc<UnityEngine.Vector3>.BeginInvoke
    //
    // file offset: 0x019C0B10 VirtAddr: 0x019C0B10 -RVA: 0x019C0B10 
    // -BetterList.CompareFunc<UnityEngine.Vector4>.BeginInvoke
    //
    //
    // Offset in libil2cpp.so: 0x019BEC88 (26995848), len: 52  VirtAddr: 0x019BEC88 RVA: 0x019BEC88 token: 100687866 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual System.IAsyncResult BeginInvoke(T left, T right, System.AsyncCallback callback, object object)
    {
        //
        // Disasemble & Code
        // 0x019BEC88: STP x29, x30, [sp, #-0x10]! | stack[1152921514154638656] = ???;  stack[1152921514154638664] = ???;  //  dest_result_addr=1152921514154638656 |  dest_result_addr=1152921514154638664
        // 0x019BEC8C: MOV x29, sp                | X29 = 1152921514154638656 (0x100000023917BD40);//ML01
        // 0x019BEC90: SUB sp, sp, #0x20          | SP = (1152921514154638656 - 32) = 1152921514154638624 (0x100000023917BD20);
        // 0x019BEC94: STP xzr, xzr, [sp, #0x10]  | stack[1152921514154638640] = 0x0;  stack[1152921514154638648] = 0x0;  //  dest_result_addr=1152921514154638640 |  dest_result_addr=1152921514154638648
        // 0x019BEC98: STP xzr, x2, [sp, #8]      | stack[1152921514154638632] = 0x0;  stack[1152921514154638640] = right;  //  dest_result_addr=1152921514154638632 |  dest_result_addr=1152921514154638640
        // 0x019BEC9C: STR x1, [sp, #8]           | stack[1152921514154638632] = left;       //  dest_result_addr=1152921514154638632
        // 0x019BECA0: ADD x1, sp, #8             | X1 = (1152921514154638624 + 8) = 1152921514154638632 (0x100000023917BD28);
        // 0x019BECA4: MOV x2, x3                 | X2 = callback;//m1                      
        // 0x019BECA8: MOV x3, x4                 | X3 = object;//m1                        
        // 0x019BECAC: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
        // 0x019BECB0: MOV sp, x29                | SP = 1152921514154638656 (0x100000023917BD40);//ML01
        // 0x019BECB4: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x019BECB8: RET                        |  return (System.IAsyncResult)this;      
        return (System.IAsyncResult)this;
        //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019BECBC VirtAddr: 0x019BECBC -RVA: 0x019BECBC 
    // -BetterList.CompareFunc<object>.EndInvoke
    //
    // file offset: 0x019BE870 VirtAddr: 0x019BE870 -RVA: 0x019BE870 
    // -BetterList.CompareFunc<int>.EndInvoke
    //
    // file offset: 0x019BEFE4 VirtAddr: 0x019BEFE4 -RVA: 0x019BEFE4 
    // -BetterList.CompareFunc<float>.EndInvoke
    //
    // file offset: 0x019BF4B0 VirtAddr: 0x019BF4B0 -RVA: 0x019BF4B0 
    // -BetterList.CompareFunc<TypewriterEffect.FadeEntry>.EndInvoke
    //
    // file offset: 0x019BF984 VirtAddr: 0x019BF984 -RVA: 0x019BF984 
    // -BetterList.CompareFunc<UICamera.DepthEntry>.EndInvoke
    //
    // file offset: 0x019BFD70 VirtAddr: 0x019BFD70 -RVA: 0x019BFD70 
    // -BetterList.CompareFunc<UnityEngine.Color>.EndInvoke
    //
    // file offset: 0x019C00C0 VirtAddr: 0x019C00C0 -RVA: 0x019C00C0 
    // -BetterList.CompareFunc<UnityEngine.Color32>.EndInvoke
    //
    // file offset: 0x019C042C VirtAddr: 0x019C042C -RVA: 0x019C042C 
    // -BetterList.CompareFunc<UnityEngine.Vector2>.EndInvoke
    //
    // file offset: 0x019C07D8 VirtAddr: 0x019C07D8 -RVA: 0x019C07D8 
    // -BetterList.CompareFunc<UnityEngine.Vector3>.EndInvoke
    //
    // file offset: 0x019C0BC4 VirtAddr: 0x019C0BC4 -RVA: 0x019C0BC4 
    // -BetterList.CompareFunc<UnityEngine.Vector4>.EndInvoke
    //
    //
    // Offset in libil2cpp.so: 0x019BECBC (26995900), len: 64  VirtAddr: 0x019BECBC RVA: 0x019BECBC token: 100687867 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual int EndInvoke(System.IAsyncResult result)
    {
        //
        // Disasemble & Code
        // 0x019BECBC: STP x20, x19, [sp, #-0x20]! | stack[1152921514154771120] = ???;  stack[1152921514154771128] = ???;  //  dest_result_addr=1152921514154771120 |  dest_result_addr=1152921514154771128
        // 0x019BECC0: STP x29, x30, [sp, #0x10]  | stack[1152921514154771136] = ???;  stack[1152921514154771144] = ???;  //  dest_result_addr=1152921514154771136 |  dest_result_addr=1152921514154771144
        // 0x019BECC4: ADD x29, sp, #0x10         | X29 = (1152921514154771120 + 16) = 1152921514154771136 (0x100000023919C2C0);
        // 0x019BECC8: MOV x8, x1                 | X8 = result;//m1                        
        // 0x019BECCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019BECD0: MOV x0, x8                 | X0 = result;//m1                        
        // 0x019BECD4: BL #0x278fde8              | X0 = sub_278FDE8( ?? result, ????);     
        // 0x019BECD8: MOV x19, x0                | X19 = result;//m1                       
        // 0x019BECDC: CBNZ x19, #0x19bece4       | if (result != null) goto label_0;       
        if(result != null)
        {
            goto label_0;
        }
        // 0x019BECE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? result, ????);     
        label_0:
        // 0x019BECE4: MOV x0, x19                | X0 = result;//m1                        
        // 0x019BECE8: BL #0x27bc4e8              | result.System.IDisposable.Dispose();    
        result.System.IDisposable.Dispose();
        // 0x019BECEC: LDR w0, [x0]               | W0 = typeof(System.IAsyncResult);       
        // 0x019BECF0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x019BECF4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x019BECF8: RET                        |  return (System.Int32)typeof(System.IAsyncResult);
        return (int)null;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }

}
