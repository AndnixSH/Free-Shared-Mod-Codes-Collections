using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CLRBindingsBase
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00A207A8 (10618792), len: 8  VirtAddr: 0x00A207A8 RVA: 0x00A207A8 token: 100679927 methodIndex: 30531 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRBindingsBase()
        {
            //
            // Disasemble & Code
            // 0x00A207A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00A207AC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00A45C34 (10771508), len: 112  VirtAddr: 0x00A45C34 RVA: 0x00A45C34 token: 100679928 methodIndex: 30532 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Initialize(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            // 0x00A45C34: STP x20, x19, [sp, #-0x20]! | stack[1152921512832033584] = ???;  stack[1152921512832033592] = ???;  //  dest_result_addr=1152921512832033584 |  dest_result_addr=1152921512832033592
            // 0x00A45C38: STP x29, x30, [sp, #0x10]  | stack[1152921512832033600] = ???;  stack[1152921512832033608] = ???;  //  dest_result_addr=1152921512832033600 |  dest_result_addr=1152921512832033608
            // 0x00A45C3C: ADD x29, sp, #0x10         | X29 = (1152921512832033584 + 16) = 1152921512832033600 (0x10000001EA426340);
            // 0x00A45C40: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00A45C44: LDRB w8, [x19, #0x14e]     | W8 = (bool)static_value_0373314E;       
            // 0x00A45C48: TBNZ w8, #0, #0xa45c64     | if (static_value_0373314E == true) goto label_0;
            // 0x00A45C4C: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
            // 0x00A45C50: LDR x8, [x8, #0xda0]       | X8 = 0x2B90C84;                         
            // 0x00A45C54: LDR w0, [x8]               | W0 = 0x19E5;                            
            // 0x00A45C58: BL #0x2782188              | X0 = sub_2782188( ?? 0x19E5, ????);     
            // 0x00A45C5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00A45C60: STRB w8, [x19, #0x14e]     | static_value_0373314E = true;            //  dest_result_addr=57880910
            label_0:
            // 0x00A45C64: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00A45C68: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x00A45C6C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x00A45C70: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x00A45C74: TBZ w8, #0, #0xa45c84      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00A45C78: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x00A45C7C: CBNZ w8, #0xa45c84         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00A45C80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_2:
            // 0x00A45C84: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x00A45C88: LDR x8, [x8, #0xcf0]       | X8 = (string**)(1152921512832021520)("未生成代码绑定");
            // 0x00A45C8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00A45C90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00A45C94: LDR x1, [x8]               | X1 = "未生成代码绑定";                         
            // 0x00A45C98: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00A45C9C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00A45CA0: B #0x1a5d504               | UnityEngine.Debug.LogError(message:  0); return;
            UnityEngine.Debug.LogError(message:  0);
            return;
        
        }
    
    }

}
