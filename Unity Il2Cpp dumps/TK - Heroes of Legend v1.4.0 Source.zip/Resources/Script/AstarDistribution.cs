using UnityEngine;
public enum AstarPath.AstarDistribution
{
    // Fields
    WebsiteDownload = 0
    ,AssetStore = 1
    

}
