using UnityEngine;
[UnityEngine.AddComponentMenu] // 0x281A7CC
[UnityEngine.ExecuteInEditMode] // 0x281A7CC
[Serializable]
public class ColorCorrectionLut : PostEffectsBase
{
    // Fields
    public UnityEngine.Shader shader; //  0x00000020
    private UnityEngine.Material material; //  0x00000028
    public UnityEngine.Texture3D converted3DLut; //  0x00000030
    public string basedOnTempTex; //  0x00000038
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02678C7C (40340604), len: 136  VirtAddr: 0x02678C7C RVA: 0x02678C7C token: 100663350 methodIndex: 24434 delegateWrapperIndex: 0 methodInvoker: 0
    public ColorCorrectionLut()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x02678C7C: STP x20, x19, [sp, #-0x20]! | stack[1152921509952527728] = ???;  stack[1152921509952527736] = ???;  //  dest_result_addr=1152921509952527728 |  dest_result_addr=1152921509952527736
        // 0x02678C80: STP x29, x30, [sp, #0x10]  | stack[1152921509952527744] = ???;  stack[1152921509952527752] = ???;  //  dest_result_addr=1152921509952527744 |  dest_result_addr=1152921509952527752
        // 0x02678C84: ADD x29, sp, #0x10         | X29 = (1152921509952527728 + 16) = 1152921509952527744 (0x100000013EA09D80);
        // 0x02678C88: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02678C8C: LDRB w8, [x20, #0xe5e]     | W8 = (bool)static_value_03740E5E;       
        // 0x02678C90: MOV x19, x0                | X19 = 1152921509952539760 (0x100000013EA0CC70);//ML01
        // 0x02678C94: TBNZ w8, #0, #0x2678cb0    | if (static_value_03740E5E == true) goto label_0;
        // 0x02678C98: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x02678C9C: LDR x8, [x8, #0x9b8]       | X8 = 0x2B9172C;                         
        // 0x02678CA0: LDR w0, [x8]               | W0 = 0x1C90;                            
        // 0x02678CA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C90, ????);     
        // 0x02678CA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678CAC: STRB w8, [x20, #0xe5e]     | static_value_03740E5E = true;            //  dest_result_addr=57937502
        label_0:
        // 0x02678CB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678CB4: MOV x0, x19                | X0 = 1152921509952539760 (0x100000013EA0CC70);//ML01
        UnityEngine.MonoBehaviour val_1 = this;
        // 0x02678CB8: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02678CBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678CC0: STRB w8, [x19, #0x1a]      | mem[1152921509952539786] = 0x1;          //  dest_result_addr=1152921509952539786
        mem[1152921509952539786] = 1;
        // 0x02678CC4: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x02678CC8: STRB w8, [x19, #0x18]      | mem[1152921509952539784] = 0x1;          //  dest_result_addr=1152921509952539784
        mem[1152921509952539784] = 1;
        // 0x02678CCC: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x02678CD0: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_2 = null;
        // 0x02678CD4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02678CD8: TBZ w8, #0, #0x2678cec     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02678CDC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x02678CE0: CBNZ w8, #0x2678cec        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02678CE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x02678CE8: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_2 = null;
        label_2:
        // 0x02678CEC: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x02678CF0: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x02678CF4: STR x8, [x19, #0x38]       | this.basedOnTempTex = System.String.Empty;  //  dest_result_addr=1152921509952539816
        this.basedOnTempTex = System.String.Empty;
        // 0x02678CF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02678CFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02678D00: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678D04 (40340740), len: 116  VirtAddr: 0x02678D04 RVA: 0x02678D04 token: 100663351 methodIndex: 24435 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Shader val_3;
        // 0x02678D04: STP x20, x19, [sp, #-0x20]! | stack[1152921509952647920] = ???;  stack[1152921509952647928] = ???;  //  dest_result_addr=1152921509952647920 |  dest_result_addr=1152921509952647928
        // 0x02678D08: STP x29, x30, [sp, #0x10]  | stack[1152921509952647936] = ???;  stack[1152921509952647944] = ???;  //  dest_result_addr=1152921509952647936 |  dest_result_addr=1152921509952647944
        // 0x02678D0C: ADD x29, sp, #0x10         | X29 = (1152921509952647920 + 16) = 1152921509952647936 (0x100000013EA27300);
        // 0x02678D10: MOV x19, x0                | X19 = 1152921509952659952 (0x100000013EA2A1F0);//ML01
        // 0x02678D14: LDR x8, [x19]              | X8 = typeof(ColorCorrectionLut);        
        // 0x02678D18: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02678D1C: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(ColorCorrectionLut).__il2cppRuntimeField_1B0; X2 = typeof(ColorCorrectionLut).__il2cppRuntimeField_1B8; //  | 
        // 0x02678D20: BLR x9                     | X0 = typeof(ColorCorrectionLut).__il2cppRuntimeField_1B0();
        // 0x02678D24: LDR x8, [x19]              | X8 = typeof(ColorCorrectionLut);        
        // 0x02678D28: LDP x1, x2, [x19, #0x20]   | X1 = this.shader; //P2  X2 = this.material; //P2  //  | 
        val_3 = this.shader;
        // 0x02678D2C: MOV x0, x19                | X0 = 1152921509952659952 (0x100000013EA2A1F0);//ML01
        // 0x02678D30: LDP x9, x3, [x8, #0x150]   | X9 = typeof(ColorCorrectionLut).__il2cppRuntimeField_150; X3 = typeof(ColorCorrectionLut).__il2cppRuntimeField_158; //  | 
        // 0x02678D34: BLR x9                     | X0 = typeof(ColorCorrectionLut).__il2cppRuntimeField_150();
        // 0x02678D38: LDRB w8, [x19, #0x1a]      | 
        // 0x02678D3C: STR x0, [x19, #0x28]       | this.material = this;                    //  dest_result_addr=1152921509952659992
        this.material = this;
        // 0x02678D40: CBZ w8, #0x2678d58         | if (typeof(ColorCorrectionLut) == null) goto label_0;
        if(null == null)
        {
            goto label_0;
        }
        // 0x02678D44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678D48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_3 = 0;
        // 0x02678D4C: BL #0x268de44              | X0 = UnityEngine.SystemInfo.get_supports3DTextures();
        bool val_1 = UnityEngine.SystemInfo.supports3DTextures;
        // 0x02678D50: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x02678D54: TBNZ w8, #0, #0x2678d68    | if ((val_1 & 1) == true) goto label_1;  
        if(val_2 == true)
        {
            goto label_1;
        }
        label_0:
        // 0x02678D58: LDR x8, [x19]              | X8 = typeof(ColorCorrectionLut);        
        // 0x02678D5C: MOV x0, x19                | X0 = 1152921509952659952 (0x100000013EA2A1F0);//ML01
        // 0x02678D60: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(ColorCorrectionLut).__il2cppRuntimeField_1E0; X1 = typeof(ColorCorrectionLut).__il2cppRuntimeField_1E8; //  | 
        // 0x02678D64: BLR x9                     | X0 = typeof(ColorCorrectionLut).__il2cppRuntimeField_1E0();
        label_1:
        // 0x02678D68: LDRB w0, [x19, #0x1a]      | 
        // 0x02678D6C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02678D70: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02678D74: RET                        |  return (System.Boolean)this;           
        return (bool)this;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02678D78 (40340856), len: 176  VirtAddr: 0x02678D78 RVA: 0x02678D78 token: 100663352 methodIndex: 24436 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnDisable()
    {
        //
        // Disasemble & Code
        // 0x02678D78: STP x22, x21, [sp, #-0x30]! | stack[1152921509952776288] = ???;  stack[1152921509952776296] = ???;  //  dest_result_addr=1152921509952776288 |  dest_result_addr=1152921509952776296
        // 0x02678D7C: STP x20, x19, [sp, #0x10]  | stack[1152921509952776304] = ???;  stack[1152921509952776312] = ???;  //  dest_result_addr=1152921509952776304 |  dest_result_addr=1152921509952776312
        // 0x02678D80: STP x29, x30, [sp, #0x20]  | stack[1152921509952776320] = ???;  stack[1152921509952776328] = ???;  //  dest_result_addr=1152921509952776320 |  dest_result_addr=1152921509952776328
        // 0x02678D84: ADD x29, sp, #0x20         | X29 = (1152921509952776288 + 32) = 1152921509952776320 (0x100000013EA46880);
        // 0x02678D88: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02678D8C: LDRB w8, [x20, #0xe5f]     | W8 = (bool)static_value_03740E5F;       
        // 0x02678D90: MOV x19, x0                | X19 = 1152921509952788336 (0x100000013EA49770);//ML01
        // 0x02678D94: TBNZ w8, #0, #0x2678db0    | if (static_value_03740E5F == true) goto label_0;
        // 0x02678D98: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x02678D9C: LDR x8, [x8, #0x840]       | X8 = 0x2B91738;                         
        // 0x02678DA0: LDR w0, [x8]               | W0 = 0x1C93;                            
        // 0x02678DA4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C93, ????);     
        // 0x02678DA8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678DAC: STRB w8, [x20, #0xe5f]     | static_value_03740E5F = true;            //  dest_result_addr=57937503
        label_0:
        // 0x02678DB0: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x02678DB4: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02678DB8: LDR x20, [x19, #0x28]      | X20 = this.material; //P2               
        // 0x02678DBC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02678DC0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02678DC4: TBZ w8, #0, #0x2678dd4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02678DC8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02678DCC: CBNZ w8, #0x2678dd4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02678DD0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02678DD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678DD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678DDC: MOV x1, x20                | X1 = this.material;//m1                 
        // 0x02678DE0: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02678DE4: TBZ w0, #0, #0x2678e18     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02678DE8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02678DEC: LDR x20, [x19, #0x28]      | X20 = this.material; //P2               
        // 0x02678DF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02678DF4: TBZ w8, #0, #0x2678e04     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02678DF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02678DFC: CBNZ w8, #0x2678e04        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02678E00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x02678E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678E08: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678E0C: MOV x1, x20                | X1 = this.material;//m1                 
        // 0x02678E10: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        // 0x02678E14: STR xzr, [x19, #0x28]      | this.material = null;                    //  dest_result_addr=1152921509952788376
        this.material = 0;
        label_3:
        // 0x02678E18: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02678E1C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02678E20: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02678E24: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678E28 (40341032), len: 176  VirtAddr: 0x02678E28 RVA: 0x02678E28 token: 100663353 methodIndex: 24437 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnDestroy()
    {
        //
        // Disasemble & Code
        // 0x02678E28: STP x22, x21, [sp, #-0x30]! | stack[1152921509952904672] = ???;  stack[1152921509952904680] = ???;  //  dest_result_addr=1152921509952904672 |  dest_result_addr=1152921509952904680
        // 0x02678E2C: STP x20, x19, [sp, #0x10]  | stack[1152921509952904688] = ???;  stack[1152921509952904696] = ???;  //  dest_result_addr=1152921509952904688 |  dest_result_addr=1152921509952904696
        // 0x02678E30: STP x29, x30, [sp, #0x20]  | stack[1152921509952904704] = ???;  stack[1152921509952904712] = ???;  //  dest_result_addr=1152921509952904704 |  dest_result_addr=1152921509952904712
        // 0x02678E34: ADD x29, sp, #0x20         | X29 = (1152921509952904672 + 32) = 1152921509952904704 (0x100000013EA65E00);
        // 0x02678E38: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02678E3C: LDRB w8, [x20, #0xe60]     | W8 = (bool)static_value_03740E60;       
        // 0x02678E40: MOV x19, x0                | X19 = 1152921509952916720 (0x100000013EA68CF0);//ML01
        // 0x02678E44: TBNZ w8, #0, #0x2678e60    | if (static_value_03740E60 == true) goto label_0;
        // 0x02678E48: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x02678E4C: LDR x8, [x8, #0x1f8]       | X8 = 0x2B91734;                         
        // 0x02678E50: LDR w0, [x8]               | W0 = 0x1C92;                            
        // 0x02678E54: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C92, ????);     
        // 0x02678E58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678E5C: STRB w8, [x20, #0xe60]     | static_value_03740E60 = true;            //  dest_result_addr=57937504
        label_0:
        // 0x02678E60: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x02678E64: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x02678E68: LDR x20, [x19, #0x30]      | X20 = this.converted3DLut; //P2         
        // 0x02678E6C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02678E70: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02678E74: TBZ w8, #0, #0x2678e84     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02678E78: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02678E7C: CBNZ w8, #0x2678e84        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02678E80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02678E84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678E88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678E8C: MOV x1, x20                | X1 = this.converted3DLut;//m1           
        // 0x02678E90: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02678E94: TBZ w0, #0, #0x2678ec4     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02678E98: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x02678E9C: LDR x20, [x19, #0x30]      | X20 = this.converted3DLut; //P2         
        // 0x02678EA0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02678EA4: TBZ w8, #0, #0x2678eb4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02678EA8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02678EAC: CBNZ w8, #0x2678eb4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02678EB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x02678EB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02678EB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02678EBC: MOV x1, x20                | X1 = this.converted3DLut;//m1           
        // 0x02678EC0: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_3:
        // 0x02678EC4: STR xzr, [x19, #0x30]      | this.converted3DLut = null;              //  dest_result_addr=1152921509952916768
        this.converted3DLut = 0;
        // 0x02678EC8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02678ECC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02678ED0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02678ED4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02678ED8 (40341208), len: 596  VirtAddr: 0x02678ED8 RVA: 0x02678ED8 token: 100663354 methodIndex: 24438 delegateWrapperIndex: 0 methodInvoker: 0
    public override void SetIdentityLut()
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        // 0x02678ED8: STP d11, d10, [sp, #-0x80]! | stack[1152921509953037072] = ???;  stack[1152921509953037080] = ???;  //  dest_result_addr=1152921509953037072 |  dest_result_addr=1152921509953037080
        // 0x02678EDC: STP d9, d8, [sp, #0x10]    | stack[1152921509953037088] = ???;  stack[1152921509953037096] = ???;  //  dest_result_addr=1152921509953037088 |  dest_result_addr=1152921509953037096
        // 0x02678EE0: STP x28, x27, [sp, #0x20]  | stack[1152921509953037104] = ???;  stack[1152921509953037112] = ???;  //  dest_result_addr=1152921509953037104 |  dest_result_addr=1152921509953037112
        // 0x02678EE4: STP x26, x25, [sp, #0x30]  | stack[1152921509953037120] = ???;  stack[1152921509953037128] = ???;  //  dest_result_addr=1152921509953037120 |  dest_result_addr=1152921509953037128
        // 0x02678EE8: STP x24, x23, [sp, #0x40]  | stack[1152921509953037136] = ???;  stack[1152921509953037144] = ???;  //  dest_result_addr=1152921509953037136 |  dest_result_addr=1152921509953037144
        // 0x02678EEC: STP x22, x21, [sp, #0x50]  | stack[1152921509953037152] = ???;  stack[1152921509953037160] = ???;  //  dest_result_addr=1152921509953037152 |  dest_result_addr=1152921509953037160
        // 0x02678EF0: STP x20, x19, [sp, #0x60]  | stack[1152921509953037168] = ???;  stack[1152921509953037176] = ???;  //  dest_result_addr=1152921509953037168 |  dest_result_addr=1152921509953037176
        // 0x02678EF4: STP x29, x30, [sp, #0x70]  | stack[1152921509953037184] = ???;  stack[1152921509953037192] = ???;  //  dest_result_addr=1152921509953037184 |  dest_result_addr=1152921509953037192
        // 0x02678EF8: ADD x29, sp, #0x70         | X29 = (1152921509953037072 + 112) = 1152921509953037184 (0x100000013EA86380);
        // 0x02678EFC: SUB sp, sp, #0x10          | SP = (1152921509953037072 - 16) = 1152921509953037056 (0x100000013EA86300);
        // 0x02678F00: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x02678F04: LDRB w8, [x20, #0xe61]     | W8 = (bool)static_value_03740E61;       
        // 0x02678F08: MOV x19, x0                | X19 = 1152921509953049200 (0x100000013EA89270);//ML01
        // 0x02678F0C: TBNZ w8, #0, #0x2678f28    | if (static_value_03740E61 == true) goto label_0;
        // 0x02678F10: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x02678F14: LDR x8, [x8, #0x10]        | X8 = 0x2B91740;                         
        // 0x02678F18: LDR w0, [x8]               | W0 = 0x1C95;                            
        // 0x02678F1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C95, ????);     
        // 0x02678F20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02678F24: STRB w8, [x20, #0xe61]     | static_value_03740E61 = true;            //  dest_result_addr=57937505
        label_0:
        // 0x02678F28: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x02678F2C: LDR x8, [x8, #0x190]       | X8 = 1152921505690746144;               
        // 0x02678F30: LDR x20, [x8]              | X20 = typeof(UnityEngine.Color[]);      
        // 0x02678F34: MOV x0, x20                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x02678F38: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Color[]), ????);
        // 0x02678F3C: ORR w1, wzr, #0x1000       | W1 = 4096(0x1000);                      
        // 0x02678F40: MOV x0, x20                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x02678F44: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Color[]), ????);
        // 0x02678F48: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02678F4C: LDR s11, [x8, #0xd2c]      | S11 = 0.06666667;                       
        // 0x02678F50: MOV x20, x0                | X20 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x02678F54: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        var val_10 = 0;
        // 0x02678F58: ADD x22, x20, #0x20        | X22 = (null + 32) = 1152921505690746176 (0x10000000409AFD40);
        // 0x02678F5C: FMOV s8, #1.00000000       | S8 = 1;                                 
        label_5:
        // 0x02678F60: SCVTF s0, w21              | S0 = 0;                                 
        // 0x02678F64: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        var val_8 = 0;
        // 0x02678F68: FMUL s9, s0, s11           | S9 = (0f * 0.06666667f);                
        float val_1 = 0f * 0.06666667f;
        // 0x02678F6C: MOV x24, x22               | X24 = 1152921505690746176 (0x10000000409AFD40);//ML01
        // 0x02678F70: MOV x25, x21               | X25 = 0 (0x0);//ML01                    
        var val_9 = val_10;
        label_4:
        // 0x02678F74: SCVTF s0, w23              | S0 = 0;                                 
        // 0x02678F78: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
        var val_6 = 0;
        // 0x02678F7C: FMUL s10, s0, s11          | S10 = (0f * 0.06666667f);               
        float val_2 = 0f * 0.06666667f;
        // 0x02678F80: MOV x27, x24               | X27 = 1152921505690746176 (0x10000000409AFD40);//ML01
        // 0x02678F84: MOV x28, x25               | X28 = 0 (0x0);//ML01                    
        var val_7 = val_9;
        label_3:
        // 0x02678F88: CBNZ x20, #0x2678f90       | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x02678F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Color[]), ????);
        label_1:
        // 0x02678F90: SCVTF s0, w26              | S0 = 0;                                 
        // 0x02678F94: FMUL s2, s0, s11           | S2 = (0f * 0.06666667f);                
        float val_3 = 0f * 0.06666667f;
        // 0x02678F98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678F9C: MOV x0, sp                 | X0 = 1152921509953037056 (0x100000013EA86300);//ML01
        // 0x02678FA0: MOV v0.16b, v9.16b         | V0 = (0f * 0.06666667f);//m1            
        // 0x02678FA4: MOV v1.16b, v10.16b        | V1 = (0f * 0.06666667f);//m1            
        // 0x02678FA8: MOV v3.16b, v8.16b         | V3 = 1;//m1                             
        // 0x02678FAC: STP xzr, xzr, [sp]         | stack[1152921509953037056] = 0x0;  stack[1152921509953037064] = 0x0;  //  dest_result_addr=1152921509953037056 |  dest_result_addr=1152921509953037064
        // 0x02678FB0: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02678FB4: LDR w8, [x20, #0x18]       | W8 = UnityEngine.Color[].__il2cppRuntimeField_namespaze;
        // 0x02678FB8: CMP x28, x8                | STATE = COMPARE(0x0, UnityEngine.Color[].__il2cppRuntimeField_namespaze)
        // 0x02678FBC: B.LO #0x2678fcc            | if (0 < UnityEngine.Color[].__il2cppRuntimeField_namespaze) goto label_2;
        // 0x02678FC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x100000013EA86300, ????);
        // 0x02678FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02678FC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x100000013EA86300, ????);
        label_2:
        // 0x02678FCC: LDR q0, [sp]               | Q0 = 0x0;                               
        // 0x02678FD0: ADD x26, x26, #1           | X26 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x02678FD4: ADD x28, x28, #0x100       | X28 = (0 + 256);                        
        val_7 = val_7 + 256;
        // 0x02678FD8: CMP x26, #0x10             | STATE = COMPARE((0 + 1), 0x10)          
        // 0x02678FDC: STR q0, [x27]              | UnityEngine.Color[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_FFFFFFFFFFFFFFFF = 0x0;  //  dest_result_addr=1152921505690746176
        UnityEngine.Color[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_FFFFFFFFFFFFFFFF = 0;
        // 0x02678FE0: ADD x27, x27, #1, lsl #12  | X27 = (1152921505690746176 + 4096) = 1152921505690750272 (0x10000000409B0D40);
        // 0x02678FE4: B.NE #0x2678f88            | if (0 != 0x10) goto label_3;            
        if(val_6 != 16)
        {
            goto label_3;
        }
        // 0x02678FE8: ADD x23, x23, #1           | X23 = (0 + 1);                          
        val_8 = val_8 + 1;
        // 0x02678FEC: ADD x25, x25, #0x10        | X25 = (0 + 16);                         
        val_9 = val_9 + 16;
        // 0x02678FF0: ADD x24, x24, #0x100       | X24 = (1152921505690746176 + 256) = 1152921505690746432 (0x10000000409AFE40);
        // 0x02678FF4: CMP x23, #0x10             | STATE = COMPARE((0 + 1), 0x10)          
        // 0x02678FF8: B.NE #0x2678f74            | if (0 != 0x10) goto label_4;            
        if(val_8 != 16)
        {
            goto label_4;
        }
        // 0x02678FFC: ADD x21, x21, #1           | X21 = (0 + 1);                          
        val_10 = val_10 + 1;
        // 0x02679000: ADD x22, x22, #0x10        | X22 = (1152921505690746176 + 16) = 1152921505690746192 (0x10000000409AFD50);
        // 0x02679004: CMP x21, #0x10             | STATE = COMPARE((0 + 1), 0x10)          
        // 0x02679008: B.NE #0x2678f60            | if (0 != 0x10) goto label_5;            
        if(val_10 != 16)
        {
            goto label_5;
        }
        // 0x0267900C: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x02679010: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        // 0x02679014: LDR x21, [x19, #0x30]      | X21 = this.converted3DLut; //P2         
        // 0x02679018: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x0267901C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02679020: TBZ w8, #0, #0x2679030     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x02679024: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02679028: CBNZ w8, #0x2679030        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0267902C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_7:
        // 0x02679030: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679034: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679038: MOV x1, x21                | X1 = this.converted3DLut;//m1           
        // 0x0267903C: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_4 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02679040: TBZ w0, #0, #0x2679070     | if (val_4 == false) goto label_8;       
        if(val_4 == false)
        {
            goto label_8;
        }
        // 0x02679044: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x02679048: LDR x21, [x19, #0x30]      | X21 = this.converted3DLut; //P2         
        // 0x0267904C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02679050: TBZ w8, #0, #0x2679060     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x02679054: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02679058: CBNZ w8, #0x2679060        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0267905C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_10:
        // 0x02679060: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679064: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679068: MOV x1, x21                | X1 = this.converted3DLut;//m1           
        // 0x0267906C: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_8:
        // 0x02679070: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x02679074: LDR x8, [x8, #0x658]       | X8 = 1152921504697208832;               
        // 0x02679078: LDR x0, [x8]               | X0 = typeof(UnityEngine.Texture3D);     
        UnityEngine.Texture3D val_5 = null;
        // 0x0267907C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Texture3D), ????);
        // 0x02679080: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
        // 0x02679084: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x02679088: ORR w1, wzr, #0x10         | W1 = 16(0x10);                          
        // 0x0267908C: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
        // 0x02679090: ORR w3, wzr, #0x10         | W3 = 16(0x10);                          
        // 0x02679094: MOVZ w4, #0x5              | W4 = 5 (0x5);//ML01                     
        // 0x02679098: MOV x21, x0                | X21 = 1152921504697208832 (0x100000000562D000);//ML01
        // 0x0267909C: BL #0x2690684              | .ctor(width:  16, height:  16, depth:  16, format:  5, mipmap:  false);
        val_5 = new UnityEngine.Texture3D(width:  16, height:  16, depth:  16, format:  5, mipmap:  false);
        // 0x026790A0: STR x21, [x19, #0x30]      | this.converted3DLut = typeof(UnityEngine.Texture3D);  //  dest_result_addr=1152921509953049248
        this.converted3DLut = val_5;
        // 0x026790A4: CBNZ x21, #0x26790ac       | if ( != 0) goto label_11;               
        if(null != 0)
        {
            goto label_11;
        }
        // 0x026790A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(width:  16, height:  16, depth:  16, format:  5, mipmap:  false), ????);
        label_11:
        // 0x026790AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026790B0: MOV x0, x21                | X0 = 1152921504697208832 (0x100000000562D000);//ML01
        // 0x026790B4: MOV x1, x20                | X1 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x026790B8: BL #0x2690970              | SetPixels(colors:  null);               
        SetPixels(colors:  null);
        // 0x026790BC: LDR x20, [x19, #0x30]      | X20 = this.converted3DLut; //P2         
        // 0x026790C0: CBNZ x20, #0x26790c8       | if (this.converted3DLut != null) goto label_12;
        if(this.converted3DLut != null)
        {
            goto label_12;
        }
        // 0x026790C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Texture3D), ????);
        label_12:
        // 0x026790C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026790CC: MOV x0, x20                | X0 = this.converted3DLut;//m1           
        // 0x026790D0: BL #0x2690a8c              | this.converted3DLut.Apply();            
        this.converted3DLut.Apply();
        // 0x026790D4: ADRP x20, #0x35d6000       | X20 = 56451072 (0x35D6000);             
        // 0x026790D8: LDR x20, [x20, #0xe38]     | X20 = 1152921504608284672;              
        // 0x026790DC: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_6 = null;
        // 0x026790E0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x026790E4: TBZ w8, #0, #0x26790f8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x026790E8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x026790EC: CBNZ w8, #0x26790f8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x026790F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x026790F4: LDR x0, [x20]              | X0 = typeof(System.String);             
        val_6 = null;
        label_14:
        // 0x026790F8: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x026790FC: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x02679100: STR x8, [x19, #0x38]       | this.basedOnTempTex = System.String.Empty;  //  dest_result_addr=1152921509953049256
        this.basedOnTempTex = System.String.Empty;
        // 0x02679104: SUB sp, x29, #0x70         | SP = (1152921509953037184 - 112) = 1152921509953037072 (0x100000013EA86310);
        // 0x02679108: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x0267910C: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x02679110: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x02679114: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x02679118: LDP x26, x25, [sp, #0x30]  | X26 = ; X25 = ;                          //  | 
        // 0x0267911C: LDP x28, x27, [sp, #0x20]  | X28 = ; X27 = ;                          //  | 
        // 0x02679120: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02679124: LDP d11, d10, [sp], #0x80  | D11 = ; D10 = ;                          //  | 
        // 0x02679128: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0267912C (40341804), len: 260  VirtAddr: 0x0267912C RVA: 0x0267912C token: 100663355 methodIndex: 24439 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool ValidDimensions(UnityEngine.Texture2D tex2d)
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x0267912C: STP x20, x19, [sp, #-0x20]! | stack[1152921509953165552] = ???;  stack[1152921509953165560] = ???;  //  dest_result_addr=1152921509953165552 |  dest_result_addr=1152921509953165560
        // 0x02679130: STP x29, x30, [sp, #0x10]  | stack[1152921509953165568] = ???;  stack[1152921509953165576] = ???;  //  dest_result_addr=1152921509953165568 |  dest_result_addr=1152921509953165576
        // 0x02679134: ADD x29, sp, #0x10         | X29 = (1152921509953165552 + 16) = 1152921509953165568 (0x100000013EAA5900);
        // 0x02679138: ADRP x20, #0x3740000       | X20 = 57933824 (0x3740000);             
        // 0x0267913C: LDRB w8, [x20, #0xe62]     | W8 = (bool)static_value_03740E62;       
        // 0x02679140: MOV x19, x1                | X19 = tex2d;//m1                        
        val_6 = tex2d;
        // 0x02679144: TBNZ w8, #0, #0x2679160    | if (static_value_03740E62 == true) goto label_0;
        // 0x02679148: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x0267914C: LDR x8, [x8, #0xc40]       | X8 = 0x2B91744;                         
        // 0x02679150: LDR w0, [x8]               | W0 = 0x1C96;                            
        // 0x02679154: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C96, ????);     
        // 0x02679158: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0267915C: STRB w8, [x20, #0xe62]     | static_value_03740E62 = true;            //  dest_result_addr=57937506
        label_0:
        // 0x02679160: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02679164: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02679168: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x0267916C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02679170: TBZ w8, #0, #0x2679180     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02679174: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02679178: CBNZ w8, #0x2679180        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0267917C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02679180: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679184: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679188: MOV x1, x19                | X1 = tex2d;//m1                         
        // 0x0267918C: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02679190: TBZ w0, #0, #0x2679220     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02679194: CBNZ x19, #0x267919c       | if (tex2d != null) goto label_4;        
        if(val_6 != null)
        {
            goto label_4;
        }
        // 0x02679198: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x0267919C: LDR x8, [x19]              | X8 = typeof(UnityEngine.Texture2D);     
        // 0x026791A0: MOV x0, x19                | X0 = tex2d;//m1                         
        // 0x026791A4: LDP x9, x1, [x8, #0x170]   | X9 = public System.Int32 UnityEngine.Texture::get_height(); X1 = public System.Int32 UnityEngine.Texture::get_height(); //  | 
        // 0x026791A8: BLR x9                     | X0 = tex2d.get_height();                
        int val_2 = val_6.height;
        // 0x026791AC: MOV w20, w0                | W20 = val_2;//m1                        
        // 0x026791B0: CBNZ x19, #0x26791b8       | if (tex2d != null) goto label_5;        
        if(val_6 != null)
        {
            goto label_5;
        }
        // 0x026791B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x026791B8: LDR x8, [x19]              | X8 = typeof(UnityEngine.Texture2D);     
        // 0x026791BC: MOV x0, x19                | X0 = tex2d;//m1                         
        // 0x026791C0: LDP x9, x1, [x8, #0x150]   | X9 = public System.Int32 UnityEngine.Texture::get_width(); X1 = public System.Int32 UnityEngine.Texture::get_width(); //  | 
        // 0x026791C4: BLR x9                     | X0 = tex2d.get_width();                 
        int val_3 = val_6.width;
        // 0x026791C8: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x026791CC: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x026791D0: MOV w19, w0                | W19 = val_3;//m1                        
        val_6 = val_3;
        // 0x026791D4: LDR x8, [x8]               | X8 = typeof(UnityEngine.Mathf);         
        // 0x026791D8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x026791DC: TBZ w9, #0, #0x26791f0     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x026791E0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x026791E4: CBNZ w9, #0x26791f0        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x026791E8: MOV x0, x8                 | X0 = 1152921504695345152 (0x1000000005466000);//ML01
        // 0x026791EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_7:
        // 0x026791F0: SCVTF s1, w19              | S1 = (float)(val_3);                    
        // 0x026791F4: FSQRT s0, s1               | 
        // 0x026791F8: FCMP s0, s0                | STATE = COMPARE(S0, S0)                 
        // 0x026791FC: B.VC #0x2679208            | if (S0 < _TYPE_MAX_) goto label_8;      
        if(S0 < _TYPE_MAX_)
        {
            goto label_8;
        }
        // 0x02679200: MOV v0.16b, v1.16b         | V0 = val_3;//m1                         
        // 0x02679204: BL #0x9813c0               | X0 = sub_9813C0( ?? typeof(UnityEngine.Mathf), ????);
        label_8:
        // 0x02679208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267920C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679210: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  (float)val_6);
        int val_4 = UnityEngine.Mathf.FloorToInt(f:  (float)val_6);
        // 0x02679214: CMP w20, w0                | STATE = COMPARE(val_2, val_4)           
        // 0x02679218: CSET w0, eq                | W0 = val_2 == val_4 ? 1 : 0;            
        var val_5 = (val_2 == val_4) ? 1 : 0;
        // 0x0267921C: B #0x2679224               |  goto label_9;                          
        goto label_9;
        label_3:
        // 0x02679220: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_7 = 0;
        label_9:
        // 0x02679224: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02679228: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0267922C: RET                        |  return (System.Boolean)false;          
        return (bool)val_7;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02679230 (40342064), len: 1092  VirtAddr: 0x02679230 RVA: 0x02679230 token: 100663356 methodIndex: 24440 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Convert(UnityEngine.Texture2D temp2DTex, string path)
    {
        //
        // Disasemble & Code
        //  | 
        ColorCorrectionLut val_16;
        //  | 
        var val_17;
        //  | 
        int val_18;
        //  | 
        var val_19;
        //  | 
        var val_20;
        // 0x02679230: STP x28, x27, [sp, #-0x60]! | stack[1152921509953339392] = ???;  stack[1152921509953339400] = ???;  //  dest_result_addr=1152921509953339392 |  dest_result_addr=1152921509953339400
        // 0x02679234: STP x26, x25, [sp, #0x10]  | stack[1152921509953339408] = ???;  stack[1152921509953339416] = ???;  //  dest_result_addr=1152921509953339408 |  dest_result_addr=1152921509953339416
        // 0x02679238: STP x24, x23, [sp, #0x20]  | stack[1152921509953339424] = ???;  stack[1152921509953339432] = ???;  //  dest_result_addr=1152921509953339424 |  dest_result_addr=1152921509953339432
        // 0x0267923C: STP x22, x21, [sp, #0x30]  | stack[1152921509953339440] = ???;  stack[1152921509953339448] = ???;  //  dest_result_addr=1152921509953339440 |  dest_result_addr=1152921509953339448
        // 0x02679240: STP x20, x19, [sp, #0x40]  | stack[1152921509953339456] = ???;  stack[1152921509953339464] = ???;  //  dest_result_addr=1152921509953339456 |  dest_result_addr=1152921509953339464
        // 0x02679244: STP x29, x30, [sp, #0x50]  | stack[1152921509953339472] = ???;  stack[1152921509953339480] = ???;  //  dest_result_addr=1152921509953339472 |  dest_result_addr=1152921509953339480
        // 0x02679248: ADD x29, sp, #0x50         | X29 = (1152921509953339392 + 80) = 1152921509953339472 (0x100000013EAD0050);
        // 0x0267924C: SUB sp, sp, #0x20          | SP = (1152921509953339392 - 32) = 1152921509953339360 (0x100000013EACFFE0);
        // 0x02679250: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02679254: LDRB w8, [x19, #0xe63]     | W8 = (bool)static_value_03740E63;       
        // 0x02679258: MOV x20, x2                | X20 = path;//m1                         
        // 0x0267925C: MOV x22, x1                | X22 = temp2DTex;//m1                    
        // 0x02679260: MOV x21, x0                | X21 = 1152921509953351488 (0x100000013EAD2F40);//ML01
        val_16 = this;
        // 0x02679264: TBNZ w8, #0, #0x2679280    | if (static_value_03740E63 == true) goto label_0;
        // 0x02679268: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
        // 0x0267926C: LDR x8, [x8, #0x2c0]       | X8 = 0x2B91730;                         
        // 0x02679270: LDR w0, [x8]               | W0 = 0x1C91;                            
        // 0x02679274: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C91, ????);     
        // 0x02679278: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0267927C: STRB w8, [x19, #0xe63]     | static_value_03740E63 = true;            //  dest_result_addr=57937507
        label_0:
        // 0x02679280: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02679284: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02679288: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x0267928C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02679290: TBZ w8, #0, #0x26792a0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02679294: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02679298: CBNZ w8, #0x26792a0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0267929C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x026792A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026792A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026792A8: MOV x1, x22                | X1 = temp2DTex;//m1                     
        // 0x026792AC: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x026792B0: TBZ w0, #0, #0x26792e4     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x026792B4: CBNZ x22, #0x26792bc       | if (temp2DTex != null) goto label_4;    
        if(temp2DTex != null)
        {
            goto label_4;
        }
        // 0x026792B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x026792BC: LDR x8, [x22]              | X8 = typeof(UnityEngine.Texture2D);     
        // 0x026792C0: MOV x0, x22                | X0 = temp2DTex;//m1                     
        // 0x026792C4: LDP x9, x1, [x8, #0x150]   | X9 = public System.Int32 UnityEngine.Texture::get_width(); X1 = public System.Int32 UnityEngine.Texture::get_width(); //  | 
        // 0x026792C8: BLR x9                     | X0 = temp2DTex.get_width();             
        int val_2 = temp2DTex.width;
        // 0x026792CC: CBZ x22, #0x2679338        | if (temp2DTex == null) goto label_5;    
        if(temp2DTex == null)
        {
            goto label_5;
        }
        // 0x026792D0: LDR x8, [x22]              | X8 = typeof(UnityEngine.Texture2D);     
        // 0x026792D4: MOV x0, x22                | X0 = temp2DTex;//m1                     
        // 0x026792D8: LDP x9, x1, [x8, #0x170]   | X9 = public System.Int32 UnityEngine.Texture::get_height(); X1 = public System.Int32 UnityEngine.Texture::get_height(); //  | 
        val_17 = public System.Int32 UnityEngine.Texture::get_height();
        // 0x026792DC: BLR x9                     | X0 = temp2DTex.get_height();            
        int val_3 = temp2DTex.height;
        // 0x026792E0: B #0x2679350               |  goto label_6;                          
        goto label_6;
        label_3:
        // 0x026792E4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x026792E8: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x026792EC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x026792F0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x026792F4: TBZ w8, #0, #0x2679304     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x026792F8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x026792FC: CBNZ w8, #0x2679304        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02679300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_8:
        // 0x02679304: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x02679308: LDR x8, [x8, #0xa0]        | X8 = (string**)(1152921509953277872)("Couldn\'t color correct with 3D LUT texture. Image Effect will be disabled.");
        // 0x0267930C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679310: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679314: LDR x1, [x8]               | X1 = "Couldn\'t color correct with 3D LUT texture. Image Effect will be disabled.";
        // 0x02679318: SUB sp, x29, #0x50         | SP = (1152921509953339472 - 80) = 1152921509953339392 (0x100000013EAD0000);
        // 0x0267931C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x02679320: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02679324: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02679328: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x0267932C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x02679330: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x02679334: B #0x1a5d504               | UnityEngine.Debug.LogError(message:  0); return;
        UnityEngine.Debug.LogError(message:  0);
        return;
        label_5:
        // 0x02679338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x0267933C: LDR x8, [x22]              | X8 = typeof(UnityEngine.Texture2D);     
        // 0x02679340: MOV x0, x22                | X0 = temp2DTex;//m1                     
        // 0x02679344: LDP x9, x1, [x8, #0x170]   | X9 = public System.Int32 UnityEngine.Texture::get_height(); X1 = public System.Int32 UnityEngine.Texture::get_height(); //  | 
        val_17 = public System.Int32 UnityEngine.Texture::get_height();
        // 0x02679348: BLR x9                     | X0 = temp2DTex.get_height();            
        int val_4 = temp2DTex.height;
        // 0x0267934C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_6:
        // 0x02679350: LDR x8, [x22]              | X8 = typeof(UnityEngine.Texture2D);     
        // 0x02679354: MOV x0, x22                | X0 = temp2DTex;//m1                     
        // 0x02679358: LDP x9, x1, [x8, #0x170]   | X9 = public System.Int32 UnityEngine.Texture::get_height(); X1 = public System.Int32 UnityEngine.Texture::get_height(); //  | 
        // 0x0267935C: BLR x9                     | X0 = temp2DTex.get_height();            
        int val_5 = temp2DTex.height;
        // 0x02679360: LDR x8, [x21]              | X8 = typeof(ColorCorrectionLut);        
        // 0x02679364: MOV w19, w0                | W19 = val_5;//m1                        
        val_18 = val_5;
        // 0x02679368: MOV x0, x21                | X0 = 1152921509953351488 (0x100000013EAD2F40);//ML01
        // 0x0267936C: MOV x1, x22                | X1 = temp2DTex;//m1                     
        // 0x02679370: LDR x9, [x8, #0x260]       | X9 = typeof(ColorCorrectionLut).__il2cppRuntimeField_260;
        // 0x02679374: LDR x2, [x8, #0x268]       | X2 = typeof(ColorCorrectionLut).__il2cppRuntimeField_268;
        // 0x02679378: BLR x9                     | X0 = typeof(ColorCorrectionLut).__il2cppRuntimeField_260();
        // 0x0267937C: MOV w23, w0                | W23 = 1152921509953351488 (0x100000013EAD2F40);//ML01
        val_19 = val_16;
        // 0x02679380: CBNZ x22, #0x2679388       | if (temp2DTex != null) goto label_9;    
        if(temp2DTex != null)
        {
            goto label_9;
        }
        // 0x02679384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_9:
        // 0x02679388: AND w8, w23, #1            | W8 = (this & 1) = 0 (0x00000000);       
        // 0x0267938C: TBZ w8, #0, #0x2679580     | if (((ColorCorrectionLut)[1152921509953351488] & 0x1) == 0) goto label_10;
        if((0 & 1) == 0)
        {
            goto label_10;
        }
        // 0x02679390: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679394: MOV x0, x22                | X0 = temp2DTex;//m1                     
        // 0x02679398: STR x21, [sp, #8]          | stack[1152921509953339368] = this;       //  dest_result_addr=1152921509953339368
        // 0x0267939C: BL #0x268feec              | X0 = temp2DTex.GetPixels();             
        UnityEngine.Color[] val_6 = temp2DTex.GetPixels();
        // 0x026793A0: MOV x23, x0                | X23 = val_6;//m1                        
        // 0x026793A4: CBNZ x23, #0x26793ac       | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x026793A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x026793AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026793B0: MOV x0, x23                | X0 = val_6;//m1                         
        // 0x026793B4: STR x20, [sp]              | stack[1152921509953339360] = path;       //  dest_result_addr=1152921509953339360
        // 0x026793B8: BL #0x18cbcf0              | X0 = val_6.get_Length();                
        int val_7 = val_6.Length;
        // 0x026793BC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x026793C0: LDR x8, [x8, #0x190]       | X8 = 1152921505690746144;               
        // 0x026793C4: MOV w24, w0                | W24 = val_7;//m1                        
        // 0x026793C8: LDR x22, [x8]              | X22 = typeof(UnityEngine.Color[]);      
        // 0x026793CC: MOV x0, x22                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x026793D0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Color[]), ????);
        // 0x026793D4: MOV w1, w24                | W1 = val_7;//m1                         
        // 0x026793D8: MOV x0, x22                | X0 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x026793DC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Color[]), ????);
        // 0x026793E0: MOV x22, x0                | X22 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x026793E4: SUBS w8, w19, #1           | W8 = (val_5 - 1);                       
        int val_8 = val_18 - 1;
        // 0x026793E8: B.LT #0x26794a8            | if ( < ) goto label_12;                 
        if()
        {
            goto label_12;
        }
        // 0x026793EC: MUL w26, w19, w19          | W26 = (val_5 * val_5);                  
        int val_9 = val_18 * val_18;
        // 0x026793F0: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
        // 0x026793F4: MUL w27, w26, w8           | W27 = ((val_5 * val_5) * (val_5 - 1));  
        int val_10 = val_9 * val_8;
        label_19:
        // 0x026793F8: STP w27, w9, [sp, #0x10]   | stack[1152921509953339376] = ((val_5 * val_5) * (val_5 - 1));  stack[1152921509953339380] = 0x0;  //  dest_result_addr=1152921509953339376 |  dest_result_addr=1152921509953339380
        // 0x026793FC: MOV w11, wzr               | W11 = 0 (0x0);//ML01                    
        label_18:
        // 0x02679400: STP w9, w11, [sp, #0x18]   | stack[1152921509953339384] = 0x0;  stack[1152921509953339388] = 0x0;  //  dest_result_addr=1152921509953339384 |  dest_result_addr=1152921509953339388
        // 0x02679404: MOV w21, w19               | W21 = val_5;//m1                        
        var val_19 = val_18;
        // 0x02679408: MOV w25, w9                | W25 = 0 (0x0);//ML01                    
        var val_18 = 0;
        // 0x0267940C: MOV w20, w27               | W20 = ((val_5 * val_5) * (val_5 - 1));//m1
        var val_17 = val_10;
        label_17:
        // 0x02679410: CBNZ x22, #0x2679418       | if ( != null) goto label_13;            
        if(null != null)
        {
            goto label_13;
        }
        // 0x02679414: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Color[]), ????);
        label_13:
        // 0x02679418: CBNZ x23, #0x2679420       | if (val_6 != null) goto label_14;       
        if(val_6 != null)
        {
            goto label_14;
        }
        // 0x0267941C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Color[]), ????);
        label_14:
        // 0x02679420: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Color[].__il2cppRuntimeField_namespaze;
        // 0x02679424: SXTW x28, w25              | X28 = 0 (0x00000000);                   
        // 0x02679428: CMP w25, w8                | STATE = COMPARE(0x0, UnityEngine.Color[].__il2cppRuntimeField_namespaze)
        // 0x0267942C: B.LO #0x267943c            | if (0 < UnityEngine.Color[].__il2cppRuntimeField_namespaze) goto label_15;
        // 0x02679430: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Color[]), ????);
        // 0x02679434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679438: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Color[]), ????);
        label_15:
        // 0x0267943C: LDR w8, [x23, #0x18]       | W8 = val_6.Length; //P2                 
        // 0x02679440: ADD x9, x22, x28, lsl #4   | X9 = (null + 0) = 1152921505690746144 (0x10000000409AFD20);
        // 0x02679444: ADD x28, x9, #0x20         | X28 = (1152921505690746144 + 32) = 1152921505690746176 (0x10000000409AFD40);
        // 0x02679448: SXTW x24, w20              | X24 = (long)(int)(((val_5 * val_5) * (val_5 - 1)));
        // 0x0267944C: CMP w20, w8                | STATE = COMPARE(((val_5 * val_5) * (val_5 - 1)), val_6.Length)
        // 0x02679450: B.LO #0x2679460            | if (val_10 < val_6.Length) goto label_16;
        if(val_17 < val_6.Length)
        {
            goto label_16;
        }
        // 0x02679454: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(UnityEngine.Color[]), ????);
        // 0x02679458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267945C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(UnityEngine.Color[]), ????);
        label_16:
        // 0x02679460: ADD x8, x23, x24, lsl #4   | X8 = val_6[((long)(int)(((val_5 * val_5) * (val_5 - 1)))) << 4]; //PARR1 
        // 0x02679464: LDR q0, [x8, #0x20]        | Q0 = val_6[((long)(int)(((val_5 * val_5) * (val_5 - 1)))) << 4][0]
        UnityEngine.Color val_16 = val_6[((long)(int)(((val_5 * val_5) * (val_5 - 1)))) << 4];
        // 0x02679468: ADD w20, w20, w19          | W20 = (((val_5 * val_5) * (val_5 - 1)) + val_5);
        val_17 = val_17 + val_18;
        // 0x0267946C: ADD w25, w25, w26          | W25 = (0 + (val_5 * val_5));            
        val_18 = val_18 + val_9;
        // 0x02679470: SUB w21, w21, #1           | W21 = (val_5 - 1);                      
        val_19 = val_19 - 1;
        // 0x02679474: STR q0, [x28]              | UnityEngine.Color[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_FFFFFFFFFFFFFFFF = val_6[((long)(int)(((val_5 * val_5) * (val_5 - 1)))) << 4][0];  //  dest_result_addr=1152921505690746176
        UnityEngine.Color[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_FFFFFFFFFFFFFFFF = val_16;
        // 0x02679478: CBNZ w21, #0x2679410       | if ((val_5 - 1) != 0) goto label_17;    
        if(val_19 != 0)
        {
            goto label_17;
        }
        // 0x0267947C: LDP w9, w11, [sp, #0x18]   | W9 = 0x0; W11 = 0x0;                     //  | 
        var val_20 = 0;
        // 0x02679480: SUB w27, w27, w26          | W27 = (((val_5 * val_5) * (val_5 - 1)) - (val_5 * val_5));
        val_10 = val_10 - val_9;
        // 0x02679484: ADD w11, w11, #1           | W11 = (0 + 1) = 1 (0x00000001);         
        // 0x02679488: ADD w9, w9, w19            | W9 = (0 + val_5);                       
        val_20 = val_20 + val_18;
        // 0x0267948C: CMP w11, w19               | STATE = COMPARE(0x1, val_5)             
        // 0x02679490: B.NE #0x2679400            | if (1 != val_18) goto label_18;         
        if(1 != val_18)
        {
            goto label_18;
        }
        // 0x02679494: LDP w27, w9, [sp, #0x10]   | W27 = ((val_5 * val_5) * (val_5 - 1)); W9 = 0x0; //  | 
        int val_21 = val_10;
        // 0x02679498: ADD w9, w9, #1             | W9 = (0 + 1) = 1 (0x00000001);          
        // 0x0267949C: ADD w27, w27, #1           | W27 = (((val_5 * val_5) * (val_5 - 1)) + 1);
        val_21 = val_21 + 1;
        // 0x026794A0: CMP w9, w19                | STATE = COMPARE(0x1, val_5)             
        // 0x026794A4: B.NE #0x26793f8            | if (1 != val_18) goto label_19;         
        if(1 != val_18)
        {
            goto label_19;
        }
        label_12:
        // 0x026794A8: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x026794AC: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x026794B0: LDR x20, [sp, #8]          | X20 = this;                             
        // 0x026794B4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x026794B8: LDR x23, [x20, #0x30]      | X23 = mem[1152921509953351536];         
        // 0x026794BC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026794C0: TBZ w8, #0, #0x26794d0     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_21;
        // 0x026794C4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026794C8: CBNZ w8, #0x26794d0        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
        // 0x026794CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_21:
        // 0x026794D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026794D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026794D8: MOV x1, x23                | X1 = mem[1152921509953351536];//m1      
        // 0x026794DC: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_11 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x026794E0: TBZ w0, #0, #0x2679510     | if (val_11 == false) goto label_22;     
        if(val_11 == false)
        {
            goto label_22;
        }
        // 0x026794E4: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x026794E8: LDR x23, [x20, #0x30]      | X23 = mem[1152921509953351536];         
        // 0x026794EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026794F0: TBZ w8, #0, #0x2679500     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x026794F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x026794F8: CBNZ w8, #0x2679500        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x026794FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_24:
        // 0x02679500: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679504: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679508: MOV x1, x23                | X1 = mem[1152921509953351536];//m1      
        // 0x0267950C: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_22:
        // 0x02679510: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x02679514: LDR x8, [x8, #0x658]       | X8 = 1152921504697208832;               
        // 0x02679518: LDR x0, [x8]               | X0 = typeof(UnityEngine.Texture3D);     
        UnityEngine.Texture3D val_12 = null;
        // 0x0267951C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Texture3D), ????);
        // 0x02679520: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
        // 0x02679524: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x02679528: MOVZ w4, #0x5              | W4 = 5 (0x5);//ML01                     
        // 0x0267952C: MOV w1, w19                | W1 = val_5;//m1                         
        // 0x02679530: MOV w2, w19                | W2 = val_5;//m1                         
        // 0x02679534: MOV w3, w19                | W3 = val_5;//m1                         
        // 0x02679538: MOV x23, x0                | X23 = 1152921504697208832 (0x100000000562D000);//ML01
        val_19 = val_12;
        // 0x0267953C: BL #0x2690684              | .ctor(width:  val_18, height:  val_18, depth:  val_18, format:  5, mipmap:  false);
        val_12 = new UnityEngine.Texture3D(width:  val_18, height:  val_18, depth:  val_18, format:  5, mipmap:  false);
        // 0x02679540: STR x23, [x20, #0x30]      | mem[1152921509953351536] = typeof(UnityEngine.Texture3D);  //  dest_result_addr=1152921509953351536
        mem[1152921509953351536] = val_19;
        // 0x02679544: CBNZ x23, #0x267954c       | if ( != 0) goto label_25;               
        if(null != 0)
        {
            goto label_25;
        }
        // 0x02679548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(width:  val_18, height:  val_18, depth:  val_18, format:  5, mipmap:  false), ????);
        label_25:
        // 0x0267954C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679550: MOV x0, x23                | X0 = 1152921504697208832 (0x100000000562D000);//ML01
        // 0x02679554: MOV x1, x22                | X1 = 1152921505690746144 (0x10000000409AFD20);//ML01
        // 0x02679558: BL #0x2690970              | SetPixels(colors:  null);               
        SetPixels(colors:  null);
        // 0x0267955C: LDR x21, [x20, #0x30]      | X21 = typeof(UnityEngine.Texture3D);    
        val_16 = mem[1152921509953351536];
        // 0x02679560: CBNZ x21, #0x2679568       | if ( != 0) goto label_26;               
        if(null != 0)
        {
            goto label_26;
        }
        // 0x02679564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Texture3D), ????);
        label_26:
        // 0x02679568: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267956C: MOV x0, x21                | X0 = 1152921504697208832 (0x100000000562D000);//ML01
        // 0x02679570: BL #0x2690a8c              | Apply();                                
        Apply();
        // 0x02679574: LDR x8, [sp]               | X8 = path;                              
        // 0x02679578: STR x8, [x20, #0x38]       | mem[1152921509953351544] = path;         //  dest_result_addr=1152921509953351544
        mem[1152921509953351544] = path;
        // 0x0267957C: B #0x2679654               |  goto label_27;                         
        goto label_27;
        label_10:
        // 0x02679580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679584: MOV x0, x22                | X0 = temp2DTex;//m1                     
        // 0x02679588: BL #0x1b759fc              | X0 = temp2DTex.get_name();              
        string val_13 = temp2DTex.name;
        // 0x0267958C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x02679590: LDR x8, [x8, #0x300]       | X8 = 1152921504721223680;               
        // 0x02679594: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x02679598: LDR x8, [x8]               | X8 = typeof(Boo.Lang.Runtime.RuntimeServices);
        // 0x0267959C: LDRB w9, [x8, #0x10a]      | W9 = Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_10A;
        // 0x026795A0: TBZ w9, #0, #0x26795b4     | if (Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_has_cctor == 0) goto label_29;
        // 0x026795A4: LDR w9, [x8, #0xbc]        | W9 = Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_cctor_finished;
        // 0x026795A8: CBNZ w9, #0x26795b4        | if (Boo.Lang.Runtime.RuntimeServices.__il2cppRuntimeField_cctor_finished != 0) goto label_29;
        // 0x026795AC: MOV x0, x8                 | X0 = 1152921504721223680 (0x1000000006D14000);//ML01
        // 0x026795B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Boo.Lang.Runtime.RuntimeServices), ????);
        label_29:
        // 0x026795B4: ADRP x8, #0x3639000        | X8 = 56856576 (0x3639000);              
        // 0x026795B8: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921509953319056)("The given 2D texture ");
        // 0x026795BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026795C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026795C4: MOV x2, x20                | X2 = val_13;//m1                        
        // 0x026795C8: LDR x1, [x8]               | X1 = "The given 2D texture ";           
        // 0x026795CC: BL #0x275d858              | X0 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  "The given 2D texture ");
        string val_14 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  "The given 2D texture ");
        // 0x026795D0: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
        // 0x026795D4: LDR x8, [x8, #0xc90]       | X8 = (string**)(1152921509953323264)(" cannot be used as a 3D LUT.");
        // 0x026795D8: MOV x1, x0                 | X1 = val_14;//m1                        
        // 0x026795DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026795E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026795E4: LDR x2, [x8]               | X2 = " cannot be used as a 3D LUT.";    
        // 0x026795E8: BL #0x275d858              | X0 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  val_14);
        string val_15 = Boo.Lang.Runtime.RuntimeServices.op_Addition(lhs:  0, rhs:  val_14);
        // 0x026795EC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x026795F0: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x026795F4: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x026795F8: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
        // 0x026795FC: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x02679600: TBZ w9, #0, #0x2679614     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_31;
        // 0x02679604: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x02679608: CBNZ w9, #0x2679614        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
        // 0x0267960C: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x02679610: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_31:
        // 0x02679614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267961C: MOV x1, x20                | X1 = val_15;//m1                        
        // 0x02679620: BL #0x1a5dba0              | UnityEngine.Debug.LogWarning(message:  0);
        UnityEngine.Debug.LogWarning(message:  0);
        // 0x02679624: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
        // 0x02679628: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
        val_18 = 1152921504608284672;
        // 0x0267962C: LDR x0, [x19]              | X0 = typeof(System.String);             
        val_20 = null;
        // 0x02679630: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x02679634: TBZ w8, #0, #0x2679648     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_33;
        // 0x02679638: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x0267963C: CBNZ w8, #0x2679648        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
        // 0x02679640: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x02679644: LDR x0, [x19]              | X0 = typeof(System.String);             
        val_20 = null;
        label_33:
        // 0x02679648: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x0267964C: LDR x8, [x8]               | X8 = System.String.Empty;               
        // 0x02679650: STR x8, [x21, #0x38]       | this.basedOnTempTex = System.String.Empty;  //  dest_result_addr=1152921509953351544
        this.basedOnTempTex = System.String.Empty;
        label_27:
        // 0x02679654: SUB sp, x29, #0x50         | SP = (1152921509953339472 - 80) = 1152921509953339392 (0x100000013EAD0000);
        // 0x02679658: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x0267965C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x02679660: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x02679664: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x02679668: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x0267966C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x02679670: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02679674 (40343156), len: 572  VirtAddr: 0x02679674 RVA: 0x02679674 token: 100663357 methodIndex: 24441 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Object val_9;
        // 0x02679674: STP d9, d8, [sp, #-0x50]!  | stack[1152921509953554080] = ???;  stack[1152921509953554088] = ???;  //  dest_result_addr=1152921509953554080 |  dest_result_addr=1152921509953554088
        // 0x02679678: STP x24, x23, [sp, #0x10]  | stack[1152921509953554096] = ???;  stack[1152921509953554104] = ???;  //  dest_result_addr=1152921509953554096 |  dest_result_addr=1152921509953554104
        // 0x0267967C: STP x22, x21, [sp, #0x20]  | stack[1152921509953554112] = ???;  stack[1152921509953554120] = ???;  //  dest_result_addr=1152921509953554112 |  dest_result_addr=1152921509953554120
        // 0x02679680: STP x20, x19, [sp, #0x30]  | stack[1152921509953554128] = ???;  stack[1152921509953554136] = ???;  //  dest_result_addr=1152921509953554128 |  dest_result_addr=1152921509953554136
        // 0x02679684: STP x29, x30, [sp, #0x40]  | stack[1152921509953554144] = ???;  stack[1152921509953554152] = ???;  //  dest_result_addr=1152921509953554144 |  dest_result_addr=1152921509953554152
        // 0x02679688: ADD x29, sp, #0x40         | X29 = (1152921509953554080 + 64) = 1152921509953554144 (0x100000013EB046E0);
        // 0x0267968C: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02679690: LDRB w8, [x22, #0xe64]     | W8 = (bool)static_value_03740E64;       
        // 0x02679694: MOV x19, x2                | X19 = destination;//m1                  
        // 0x02679698: MOV x20, x1                | X20 = source;//m1                       
        // 0x0267969C: MOV x21, x0                | X21 = 1152921509953566160 (0x100000013EB075D0);//ML01
        // 0x026796A0: TBNZ w8, #0, #0x26796bc    | if (static_value_03740E64 == true) goto label_0;
        // 0x026796A4: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
        // 0x026796A8: LDR x8, [x8, #0x618]       | X8 = 0x2B9173C;                         
        // 0x026796AC: LDR w0, [x8]               | W0 = 0x1C94;                            
        // 0x026796B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C94, ????);     
        // 0x026796B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026796B8: STRB w8, [x22, #0xe64]     | static_value_03740E64 = true;            //  dest_result_addr=57937508
        label_0:
        // 0x026796BC: LDR x8, [x21]              | X8 = typeof(ColorCorrectionLut);        
        // 0x026796C0: MOV x0, x21                | X0 = 1152921509953566160 (0x100000013EB075D0);//ML01
        // 0x026796C4: LDP x9, x1, [x8, #0x190]   | X9 = typeof(ColorCorrectionLut).__il2cppRuntimeField_190; X1 = typeof(ColorCorrectionLut).__il2cppRuntimeField_198; //  | 
        // 0x026796C8: BLR x9                     | X0 = typeof(ColorCorrectionLut).__il2cppRuntimeField_190();
        // 0x026796CC: TBZ w0, #0, #0x2679868     | if ((this & 0x1) == 0) goto label_2;    
        if((this & 1) == 0)
        {
            goto label_2;
        }
        // 0x026796D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026796D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026796D8: BL #0x268de44              | X0 = UnityEngine.SystemInfo.get_supports3DTextures();
        bool val_1 = UnityEngine.SystemInfo.supports3DTextures;
        // 0x026796DC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x026796E0: TBZ w8, #0, #0x2679868     | if ((val_1 & 1) == false) goto label_2; 
        if(val_2 == false)
        {
            goto label_2;
        }
        // 0x026796E4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x026796E8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x026796EC: LDR x22, [x21, #0x30]      | X22 = this.converted3DLut; //P2         
        // 0x026796F0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x026796F4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x026796F8: TBZ w8, #0, #0x2679708     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x026796FC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02679700: CBNZ w8, #0x2679708        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x02679704: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x02679708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267970C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679710: MOV x1, x22                | X1 = this.converted3DLut;//m1           
        val_9 = this.converted3DLut;
        // 0x02679714: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02679718: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_9 = this.converted3DLut);
        bool val_3 = UnityEngine.Object.op_Equality(x:  0, y:  val_9);
        // 0x0267971C: TBZ w0, #0, #0x2679734     | if (val_3 == false) goto label_5;       
        if(val_3 == false)
        {
            goto label_5;
        }
        // 0x02679720: LDR x8, [x21]              | X8 = typeof(ColorCorrectionLut);        
        // 0x02679724: MOV x0, x21                | X0 = 1152921509953566160 (0x100000013EB075D0);//ML01
        // 0x02679728: LDR x9, [x8, #0x250]       | X9 = typeof(ColorCorrectionLut).__il2cppRuntimeField_250;
        // 0x0267972C: LDR x1, [x8, #0x258]       | X1 = typeof(ColorCorrectionLut).__il2cppRuntimeField_258;
        // 0x02679730: BLR x9                     | X0 = typeof(ColorCorrectionLut).__il2cppRuntimeField_250();
        label_5:
        // 0x02679734: LDR x22, [x21, #0x30]      | X22 = this.converted3DLut; //P2         
        // 0x02679738: CBNZ x22, #0x2679740       | if (this.converted3DLut != null) goto label_6;
        if(this.converted3DLut != null)
        {
            goto label_6;
        }
        // 0x0267973C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_6:
        // 0x02679740: LDR x8, [x22]              | X8 = typeof(UnityEngine.Texture3D);     
        // 0x02679744: MOV x0, x22                | X0 = this.converted3DLut;//m1           
        // 0x02679748: LDP x9, x1, [x8, #0x150]   | X9 = public System.Int32 UnityEngine.Texture::get_width(); X1 = public System.Int32 UnityEngine.Texture::get_width(); //  | 
        // 0x0267974C: BLR x9                     | X0 = this.converted3DLut.get_width();   
        int val_4 = this.converted3DLut.width;
        // 0x02679750: LDR x23, [x21, #0x30]      | X23 = this.converted3DLut; //P2         
        // 0x02679754: MOV w22, w0                | W22 = val_4;//m1                        
        // 0x02679758: CBNZ x23, #0x2679760       | if (this.converted3DLut != null) goto label_7;
        if(this.converted3DLut != null)
        {
            goto label_7;
        }
        // 0x0267975C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x02679760: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02679764: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x02679768: MOV x0, x23                | X0 = this.converted3DLut;//m1           
        // 0x0267976C: BL #0x268f0a8              | this.converted3DLut.set_wrapMode(value:  1);
        this.converted3DLut.wrapMode = 1;
        // 0x02679770: LDR x23, [x21, #0x28]      | X23 = this.material; //P2               
        // 0x02679774: CBNZ x23, #0x267977c       | if (this.material != null) goto label_8;
        if(this.material != null)
        {
            goto label_8;
        }
        // 0x02679778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.converted3DLut, ????);
        label_8:
        // 0x0267977C: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x02679780: LDR x8, [x8, #0x9c0]       | X8 = (string**)(1152921509953521408)("_Scale");
        // 0x02679784: SCVTF s8, w22              | S8 = (float)(val_4);                    
        // 0x02679788: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267978C: MOV x0, x23                | X0 = this.material;//m1                 
        // 0x02679790: LDR x1, [x8]               | X1 = "_Scale";                          
        // 0x02679794: SUB w8, w22, #1            | W8 = (val_4 - 1);                       
        int val_5 = val_4 - 1;
        // 0x02679798: SCVTF s0, w8               | S0 = (float)((val_4 - 1));              
        float val_9 = (float)val_5;
        // 0x0267979C: FDIV s0, s0, s8            | S0 = ((val_4 - 1) / val_4);             
        val_9 = val_9 / (float)val_4;
        // 0x026797A0: BL #0x1a79ef8              | this.material.SetFloat(name:  "_Scale", value:  (float)val_5 = (float)val_5 / (float)val_4);
        this.material.SetFloat(name:  "_Scale", value:  val_9);
        // 0x026797A4: LDR x22, [x21, #0x28]      | X22 = this.material; //P2               
        // 0x026797A8: CBNZ x22, #0x26797b0       | if (this.material != null) goto label_9;
        if(this.material != null)
        {
            goto label_9;
        }
        // 0x026797AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.material, ????);
        label_9:
        // 0x026797B0: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x026797B4: LDR x8, [x8, #0xe20]       | X8 = (string**)(1152921509953525584)("_Offset");
        // 0x026797B8: FADD s0, s8, s8            | S0 = (val_4 + val_4);                   
        float val_6 = (float)val_4 + (float)val_4;
        // 0x026797BC: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x026797C0: FDIV s0, s1, s0            | S0 = (1f / (val_4 + val_4));            
        val_6 = 1f / val_6;
        // 0x026797C4: LDR x1, [x8]               | X1 = "_Offset";                         
        // 0x026797C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026797CC: MOV x0, x22                | X0 = this.material;//m1                 
        // 0x026797D0: BL #0x1a79ef8              | this.material.SetFloat(name:  "_Offset", value:  val_6 = 1f / val_6);
        this.material.SetFloat(name:  "_Offset", value:  val_6);
        // 0x026797D4: LDP x22, x23, [x21, #0x28] | X22 = this.material; //P2  X23 = this.converted3DLut; //P2  //  | 
        // 0x026797D8: CBNZ x22, #0x26797e0       | if (this.material != null) goto label_10;
        if(this.material != null)
        {
            goto label_10;
        }
        // 0x026797DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.material, ????);
        label_10:
        // 0x026797E0: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
        // 0x026797E4: LDR x8, [x8, #0xbc0]       | X8 = (string**)(1152921509953533872)("_ClutTex");
        // 0x026797E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026797EC: MOV x0, x22                | X0 = this.material;//m1                 
        // 0x026797F0: MOV x2, x23                | X2 = this.converted3DLut;//m1           
        // 0x026797F4: LDR x1, [x8]               | X1 = "_ClutTex";                        
        // 0x026797F8: BL #0x1a780c4              | this.material.SetTexture(name:  "_ClutTex", value:  this.converted3DLut);
        this.material.SetTexture(name:  "_ClutTex", value:  this.converted3DLut);
        // 0x026797FC: LDR x21, [x21, #0x28]      | X21 = this.material; //P2               
        // 0x02679800: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02679804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02679808: BL #0x1b7e32c              | X0 = UnityEngine.QualitySettings.get_activeColorSpace();
        UnityEngine.ColorSpace val_7 = UnityEngine.QualitySettings.activeColorSpace;
        // 0x0267980C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02679810: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02679814: CMP w0, #1                 | STATE = COMPARE(val_7, 0x1)             
        // 0x02679818: CSET w22, eq               | W22 = val_7 == 0x1 ? 1 : 0;             
        var val_8 = (val_7 == 1) ? 1 : 0;
        // 0x0267981C: LDR x8, [x8]               | X8 = typeof(UnityEngine.Graphics);      
        // 0x02679820: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02679824: TBZ w9, #0, #0x2679838     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x02679828: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267982C: CBNZ w9, #0x2679838        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x02679830: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02679834: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_12:
        // 0x02679838: MOV x1, x20                | X1 = source;//m1                        
        // 0x0267983C: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02679840: MOV x3, x21                | X3 = this.material;//m1                 
        // 0x02679844: MOV w4, w22                | W4 = val_7 == 0x1 ? 1 : 0;//m1          
        // 0x02679848: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0267984C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02679850: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02679854: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x02679858: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267985C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02679860: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x02679864: B #0x1a6bc84               | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination, pass:  this.material); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  destination, pass:  this.material);
        return;
        label_2:
        // 0x02679868: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267986C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02679870: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02679874: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02679878: TBZ w8, #0, #0x2679888     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x0267987C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02679880: CBNZ w8, #0x2679888        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x02679884: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_14:
        // 0x02679888: MOV x1, x20                | X1 = source;//m1                        
        // 0x0267988C: MOV x2, x19                | X2 = destination;//m1                   
        // 0x02679890: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02679894: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02679898: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x0267989C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x026798A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026798A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x026798A8: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x026798AC: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026798B0 (40343728), len: 4  VirtAddr: 0x026798B0 RVA: 0x026798B0 token: 100663358 methodIndex: 24442 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x026798B0: RET                        |  return;                                
        return;
    
    }

}
