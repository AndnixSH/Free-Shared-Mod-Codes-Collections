using UnityEngine;

namespace wxb
{
    internal class ArrayObjectType : ITypeSerialize
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2BDF8 (14859768), len: 8  VirtAddr: 0x00E2BDF8 RVA: 0x00E2BDF8 token: 100681225 methodIndex: 57217 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayObjectType()
        {
            //
            // Disasemble & Code
            // 0x00E2BDF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BDFC: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BE00 (14859776), len: 156  VirtAddr: 0x00E2BE00 RVA: 0x00E2BE00 token: 100681226 methodIndex: 57218 delegateWrapperIndex: 0 methodInvoker: 0
        private int wxb.ITypeSerialize.CalculateSize(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x00E2BE00: STP x20, x19, [sp, #-0x20]! | stack[1152921513028827264] = ???;  stack[1152921513028827272] = ???;  //  dest_result_addr=1152921513028827264 |  dest_result_addr=1152921513028827272
            // 0x00E2BE04: STP x29, x30, [sp, #0x10]  | stack[1152921513028827280] = ???;  stack[1152921513028827288] = ???;  //  dest_result_addr=1152921513028827280 |  dest_result_addr=1152921513028827288
            // 0x00E2BE08: ADD x29, sp, #0x10         | X29 = (1152921513028827264 + 16) = 1152921513028827280 (0x10000001F5FD3890);
            // 0x00E2BE0C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BE10: LDRB w8, [x20, #0x8f0]     | W8 = (bool)static_value_037348F0;       
            // 0x00E2BE14: MOV x19, x1                | X19 = value;//m1                        
            // 0x00E2BE18: TBNZ w8, #0, #0xe2be34     | if (static_value_037348F0 == true) goto label_0;
            // 0x00E2BE1C: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x00E2BE20: LDR x8, [x8, #0x490]       | X8 = 0x2B8E7AC;                         
            // 0x00E2BE24: LDR w0, [x8]               | W0 = 0x10A9;                            
            // 0x00E2BE28: BL #0x2782188              | X0 = sub_2782188( ?? 0x10A9, ????);     
            // 0x00E2BE2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BE30: STRB w8, [x20, #0x8f0]     | static_value_037348F0 = true;            //  dest_result_addr=57886960
            label_0:
            // 0x00E2BE34: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00E2BE38: LDR x8, [x8, #0xa88]       | X8 = 1152921505572583728;               
            // 0x00E2BE3C: MOV x0, x19                | X0 = value;//m1                         
            // 0x00E2BE40: LDR x1, [x8]               | X1 = typeof(UnityEngine.Object[]);      
            // 0x00E2BE44: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x00E2BE48: MOV x19, x0                | X19 = value;//m1                        
            // 0x00E2BE4C: CBZ x19, #0xe2be8c         | if (value == null) goto label_1;        
            if(value == null)
            {
                goto label_1;
            }
            // 0x00E2BE50: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00E2BE54: LDR x8, [x8, #0xfd8]       | X8 = 1152921504831766528;               
            // 0x00E2BE58: LDR x0, [x8]               | X0 = typeof(wxb.WRStream);              
            // 0x00E2BE5C: LDRB w8, [x0, #0x10a]      | W8 = wxb.WRStream.__il2cppRuntimeField_10A;
            // 0x00E2BE60: TBZ w8, #0, #0xe2be70      | if (wxb.WRStream.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E2BE64: LDR w8, [x0, #0xbc]        | W8 = wxb.WRStream.__il2cppRuntimeField_cctor_finished;
            // 0x00E2BE68: CBNZ w8, #0xe2be70         | if (wxb.WRStream.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E2BE6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.WRStream), ????);
            label_3:
            // 0x00E2BE70: LDR w1, [x19, #0x18]       | 
            // 0x00E2BE74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2BE78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BE7C: BL #0x26a48fc              | X0 = wxb.WRStream.ComputeLengthSize(length:  0);
            int val_1 = wxb.WRStream.ComputeLengthSize(length:  0);
            // 0x00E2BE80: LDR w8, [x19, #0x18]       | 
            // 0x00E2BE84: ADD w0, w0, w8, lsl #1     | W0 = (val_1 + (wxb.WRStream.__il2cppRuntimeField_cctor_finished) << 1);
            // 0x00E2BE88: B #0xe2be90                |  goto label_4;                          
            goto label_4;
            label_1:
            // 0x00E2BE8C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_2 = 0;
            label_4:
            // 0x00E2BE90: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BE94: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BE98: RET                        |  return (System.Int32)0;                
            return (int)val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BE9C (14859932), len: 352  VirtAddr: 0x00E2BE9C RVA: 0x00E2BE9C token: 100681227 methodIndex: 57219 delegateWrapperIndex: 0 methodInvoker: 0
        private void wxb.ITypeSerialize.WriteTo(object value, wxb.MonoStream ms)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            wxb.WRStream val_3;
            // 0x00E2BE9C: STP x24, x23, [sp, #-0x40]! | stack[1152921513028959712] = ???;  stack[1152921513028959720] = ???;  //  dest_result_addr=1152921513028959712 |  dest_result_addr=1152921513028959720
            // 0x00E2BEA0: STP x22, x21, [sp, #0x10]  | stack[1152921513028959728] = ???;  stack[1152921513028959736] = ???;  //  dest_result_addr=1152921513028959728 |  dest_result_addr=1152921513028959736
            // 0x00E2BEA4: STP x20, x19, [sp, #0x20]  | stack[1152921513028959744] = ???;  stack[1152921513028959752] = ???;  //  dest_result_addr=1152921513028959744 |  dest_result_addr=1152921513028959752
            // 0x00E2BEA8: STP x29, x30, [sp, #0x30]  | stack[1152921513028959760] = ???;  stack[1152921513028959768] = ???;  //  dest_result_addr=1152921513028959760 |  dest_result_addr=1152921513028959768
            // 0x00E2BEAC: ADD x29, sp, #0x30         | X29 = (1152921513028959712 + 48) = 1152921513028959760 (0x10000001F5FF3E10);
            // 0x00E2BEB0: SUB sp, sp, #0x10          | SP = (1152921513028959712 - 16) = 1152921513028959696 (0x10000001F5FF3DD0);
            // 0x00E2BEB4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BEB8: LDRB w8, [x20, #0x8f1]     | W8 = (bool)static_value_037348F1;       
            // 0x00E2BEBC: MOV x19, x2                | X19 = ms;//m1                           
            // 0x00E2BEC0: MOV x21, x1                | X21 = value;//m1                        
            val_3 = value;
            // 0x00E2BEC4: TBNZ w8, #0, #0xe2bee0     | if (static_value_037348F1 == true) goto label_0;
            // 0x00E2BEC8: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x00E2BECC: LDR x8, [x8, #0xd0]        | X8 = 0x2B8E7B4;                         
            // 0x00E2BED0: LDR w0, [x8]               | W0 = 0x10AB;                            
            // 0x00E2BED4: BL #0x2782188              | X0 = sub_2782188( ?? 0x10AB, ????);     
            // 0x00E2BED8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BEDC: STRB w8, [x20, #0x8f1]     | static_value_037348F1 = true;            //  dest_result_addr=57886961
            label_0:
            // 0x00E2BEE0: CBZ x21, #0xe2bfd0         | if (value == null) goto label_10;       
            if(val_3 == null)
            {
                goto label_10;
            }
            // 0x00E2BEE4: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x00E2BEE8: LDR x8, [x8, #0xa88]       | X8 = 1152921505572583728;               
            // 0x00E2BEEC: MOV x0, x21                | X0 = value;//m1                         
            // 0x00E2BEF0: LDR x22, [x8]              | X22 = typeof(UnityEngine.Object[]);     
            // 0x00E2BEF4: MOV x1, x22                | X1 = 1152921505572583728 (0x10000000398FF930);//ML01
            // 0x00E2BEF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x00E2BEFC: MOV x20, x0                | X20 = value;//m1                        
            // 0x00E2BF00: CBZ x20, #0xe2bfa4         | if (value == null) goto label_2;        
            if(val_3 == null)
            {
                goto label_2;
            }
            // 0x00E2BF04: CBNZ x19, #0xe2bf0c        | if (ms != null) goto label_3;           
            if(ms != null)
            {
                goto label_3;
            }
            // 0x00E2BF08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_3:
            // 0x00E2BF0C: LDR x21, [x19, #0x10]      | X21 = ms.Stream; //P2                   
            val_3 = ms.Stream;
            // 0x00E2BF10: CBNZ x21, #0xe2bf18        | if (ms.Stream != null) goto label_4;    
            if(val_3 != null)
            {
                goto label_4;
            }
            // 0x00E2BF14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_4:
            // 0x00E2BF18: LDR w1, [x20, #0x18]       | 
            // 0x00E2BF1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BF20: MOV x0, x21                | X0 = ms.Stream;//m1                     
            // 0x00E2BF24: BL #0x26a4da0              | ms.Stream.WriteLength(length:  965736752);
            val_3.WriteLength(length:  965736752);
            // 0x00E2BF28: LDR w8, [x20, #0x18]       | 
            // 0x00E2BF2C: CMP w8, #1                 | STATE = COMPARE(1152921505572583728, 0x1)
            // 0x00E2BF30: B.LT #0xe2bfd0             | if (1152921505572583728 < 0x1) goto label_10;
            if(1152921505572583728 < 1)
            {
                goto label_10;
            }
            // 0x00E2BF34: LDR x21, [x19, #0x10]      | X21 = ms.Stream; //P2                   
            val_3 = ms.Stream;
            // 0x00E2BF38: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            label_9:
            // 0x00E2BF3C: SXTW x23, w9               | X23 = 0 (0x00000000);                   
            // 0x00E2BF40: CMP w9, w8                 | STATE = COMPARE(0x0, 1152921505572583728)
            // 0x00E2BF44: B.LO #0xe2bf54             | if (0 < 1152921505572583728) goto label_6;
            if(0 < 1152921505572583728)
            {
                goto label_6;
            }
            // 0x00E2BF48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ms.Stream, ????);  
            // 0x00E2BF4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BF50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ms.Stream, ????);  
            label_6:
            // 0x00E2BF54: ADD x8, x20, x23, lsl #3   | X8 = typeof(System.Object);//AP1        
            // 0x00E2BF58: LDR x22, [x8, #0x20]       | X22 = System.Object.__il2cppRuntimeField_byval_arg;
            // 0x00E2BF5C: CBNZ x19, #0xe2bf64        | if (ms != null) goto label_7;           
            if(ms != null)
            {
                goto label_7;
            }
            // 0x00E2BF60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ms.Stream, ????);  
            label_7:
            // 0x00E2BF64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BF68: MOV x0, x19                | X0 = ms;//m1                            
            // 0x00E2BF6C: MOV x1, x22                | X1 = System.Object.__il2cppRuntimeField_byval_arg;//m1
            // 0x00E2BF70: BL #0x269fc50              | X0 = ms.Add(o:  System.Object.__il2cppRuntimeField_byval_arg);
            int val_1 = ms.Add(o:  System.Object.__il2cppRuntimeField_byval_arg);
            // 0x00E2BF74: MOV w22, w0                | W22 = val_1;//m1                        
            // 0x00E2BF78: CBNZ x21, #0xe2bf80        | if (ms.Stream != null) goto label_8;    
            if(val_3 != null)
            {
                goto label_8;
            }
            // 0x00E2BF7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_8:
            // 0x00E2BF80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BF84: MOV x0, x21                | X0 = ms.Stream;//m1                     
            // 0x00E2BF88: MOV w1, w22                | W1 = val_1;//m1                         
            // 0x00E2BF8C: BL #0x269fe28              | ms.Stream.WriteInt16(value:  val_1);    
            val_3.WriteInt16(value:  val_1);
            // 0x00E2BF90: LDR w8, [x20, #0x18]       | 
            // 0x00E2BF94: ADD w9, w23, #1            | W9 = (0 + 1);                           
            var val_2 = 0 + 1;
            // 0x00E2BF98: CMP w9, w8                 | STATE = COMPARE((0 + 1), typeof(System.Object))
            // 0x00E2BF9C: B.LT #0xe2bf3c             | if (val_2 < typeof(System.Object)) goto label_9;
            if(val_2 < null)
            {
                goto label_9;
            }
            // 0x00E2BFA0: B #0xe2bfd0                |  goto label_10;                         
            goto label_10;
            label_2:
            // 0x00E2BFA4: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x00E2BFA8: MOV x1, x22                | X1 = 1152921505572583728 (0x10000000398FF930);//ML01
            // 0x00E2BFAC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00E2BFB0: ADD x8, sp, #8             | X8 = (1152921513028959696 + 8) = 1152921513028959704 (0x10000001F5FF3DD8);
            // 0x00E2BFB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00E2BFB8: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921513028947776]
            // 0x00E2BFBC: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x00E2BFC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BFC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x00E2BFC8: ADD x0, sp, #8             | X0 = (1152921513028959696 + 8) = 1152921513028959704 (0x10000001F5FF3DD8);
            // 0x00E2BFCC: BL #0x299a140              | 
            label_10:
            // 0x00E2BFD0: SUB sp, x29, #0x30         | SP = (1152921513028959760 - 48) = 1152921513028959712 (0x10000001F5FF3DE0);
            // 0x00E2BFD4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BFD8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BFDC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2BFE0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E2BFE4: RET                        |  return;                                
            return;
            // 0x00E2BFE8: MOV x19, x0                | 
            // 0x00E2BFEC: ADD x0, sp, #8             | 
            // 0x00E2BFF0: BL #0x299a140              | 
            // 0x00E2BFF4: MOV x0, x19                | 
            // 0x00E2BFF8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BFFC (14860284), len: 456  VirtAddr: 0x00E2BFFC RVA: 0x00E2BFFC token: 100681228 methodIndex: 57220 delegateWrapperIndex: 0 methodInvoker: 0
        private void wxb.ITypeSerialize.MergeFrom(ref object value, wxb.MonoStream ms)
        {
            //
            // Disasemble & Code
            //  | 
            wxb.WRStream val_5;
            //  | 
            System.Collections.Generic.List<UnityEngine.Object> val_6;
            //  | 
            object val_7;
            // 0x00E2BFFC: STP x28, x27, [sp, #-0x60]! | stack[1152921513029112560] = ???;  stack[1152921513029112568] = ???;  //  dest_result_addr=1152921513029112560 |  dest_result_addr=1152921513029112568
            // 0x00E2C000: STP x26, x25, [sp, #0x10]  | stack[1152921513029112576] = ???;  stack[1152921513029112584] = ???;  //  dest_result_addr=1152921513029112576 |  dest_result_addr=1152921513029112584
            // 0x00E2C004: STP x24, x23, [sp, #0x20]  | stack[1152921513029112592] = ???;  stack[1152921513029112600] = ???;  //  dest_result_addr=1152921513029112592 |  dest_result_addr=1152921513029112600
            // 0x00E2C008: STP x22, x21, [sp, #0x30]  | stack[1152921513029112608] = ???;  stack[1152921513029112616] = ???;  //  dest_result_addr=1152921513029112608 |  dest_result_addr=1152921513029112616
            // 0x00E2C00C: STP x20, x19, [sp, #0x40]  | stack[1152921513029112624] = ???;  stack[1152921513029112632] = ???;  //  dest_result_addr=1152921513029112624 |  dest_result_addr=1152921513029112632
            // 0x00E2C010: STP x29, x30, [sp, #0x50]  | stack[1152921513029112640] = ???;  stack[1152921513029112648] = ???;  //  dest_result_addr=1152921513029112640 |  dest_result_addr=1152921513029112648
            // 0x00E2C014: ADD x29, sp, #0x50         | X29 = (1152921513029112560 + 80) = 1152921513029112640 (0x10000001F6019340);
            // 0x00E2C018: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C01C: LDRB w8, [x20, #0x8f2]     | W8 = (bool)static_value_037348F2;       
            // 0x00E2C020: MOV x19, x2                | X19 = ms;//m1                           
            // 0x00E2C024: MOV x21, x1                | X21 = 1152921513029156656 (0x10000001F6023F30);//ML01
            val_5 = 1152921513029156656;
            // 0x00E2C028: TBNZ w8, #0, #0xe2c044     | if (static_value_037348F2 == true) goto label_0;
            // 0x00E2C02C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00E2C030: LDR x8, [x8, #0x5e8]       | X8 = 0x2B8E7B0;                         
            // 0x00E2C034: LDR w0, [x8]               | W0 = 0x10AA;                            
            // 0x00E2C038: BL #0x2782188              | X0 = sub_2782188( ?? 0x10AA, ????);     
            // 0x00E2C03C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C040: STRB w8, [x20, #0x8f2]     | static_value_037348F2 = true;            //  dest_result_addr=57886962
            label_0:
            // 0x00E2C044: CBNZ x19, #0xe2c04c        | if (ms != null) goto label_1;           
            if(ms != null)
            {
                goto label_1;
            }
            // 0x00E2C048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10AA, ????);     
            label_1:
            // 0x00E2C04C: LDR x20, [x19, #0x10]      | X20 = ms.Stream; //P2                   
            // 0x00E2C050: CBNZ x20, #0xe2c058        | if (ms.Stream != null) goto label_2;    
            if(ms.Stream != null)
            {
                goto label_2;
            }
            // 0x00E2C054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10AA, ????);     
            label_2:
            // 0x00E2C058: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C05C: MOV x0, x20                | X0 = ms.Stream;//m1                     
            // 0x00E2C060: BL #0x26a4e7c              | X0 = ms.Stream.ReadLength();            
            int val_1 = ms.Stream.ReadLength();
            // 0x00E2C064: ADRP x23, #0x3645000       | X23 = 56905728 (0x3645000);             
            // 0x00E2C068: LDR x8, [x21]              | X8 = value;                             
            // 0x00E2C06C: LDR x23, [x23, #0xa88]     | X23 = 1152921505572583728;              
            val_6 = 1152921505572583728;
            // 0x00E2C070: MOV w22, w0                | W22 = val_1;//m1                        
            // 0x00E2C074: MOV x0, x8                 | X0 = value;//m1                         
            // 0x00E2C078: LDR x1, [x23]              | X1 = typeof(UnityEngine.Object[]);      
            // 0x00E2C07C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x00E2C080: MOV x20, x0                | X20 = value;//m1                        
            val_7 = value;
            // 0x00E2C084: CBZ x20, #0xe2c094         | if (value == null) goto label_3;        
            if(val_7 == null)
            {
                goto label_3;
            }
            // 0x00E2C088: LDR w8, [x20, #0x18]       |  //  not_find_field!1:24
            // 0x00E2C08C: CMP w8, w22                | STATE = COMPARE(mem[value + 24], val_1) 
            // 0x00E2C090: B.EQ #0xe2c0b4             | if (mem[value + 24] == val_1) goto label_4;
            if((mem[value + 24]) == val_1)
            {
                goto label_4;
            }
            label_3:
            // 0x00E2C094: LDR x20, [x23]             | X20 = typeof(UnityEngine.Object[]);     
            // 0x00E2C098: MOV x0, x20                | X0 = 1152921505572583728 (0x10000000398FF930);//ML01
            // 0x00E2C09C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Object[]), ????);
            // 0x00E2C0A0: MOV w1, w22                | W1 = val_1;//m1                         
            // 0x00E2C0A4: MOV x0, x20                | X0 = 1152921505572583728 (0x10000000398FF930);//ML01
            // 0x00E2C0A8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Object[]), ????);
            // 0x00E2C0AC: MOV x20, x0                | X20 = 1152921505572583728 (0x10000000398FF930);//ML01
            val_7 = null;
            // 0x00E2C0B0: STR x20, [x21]             | value = typeof(UnityEngine.Object[]);    //  dest_result_addr=1152921513029156656
            value = val_7;
            label_4:
            // 0x00E2C0B4: CBNZ x19, #0xe2c0bc        | if (ms != null) goto label_5;           
            if(ms != null)
            {
                goto label_5;
            }
            // 0x00E2C0B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Object[]), ????);
            label_5:
            // 0x00E2C0BC: CMP w22, #1                | STATE = COMPARE(val_1, 0x1)             
            // 0x00E2C0C0: B.LT #0xe2c1a8             | if (val_1 < 1) goto label_6;            
            if(val_1 < 1)
            {
                goto label_6;
            }
            // 0x00E2C0C4: ADRP x28, #0x3627000       | X28 = 56782848 (0x3627000);             
            // 0x00E2C0C8: LDR x21, [x19, #0x10]      | X21 = ms.Stream; //P2                   
            val_5 = ms.Stream;
            // 0x00E2C0CC: LDR x28, [x28, #0x648]     | X28 = 1152921513022166832;              
            // 0x00E2C0D0: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x00E2C0D4: ADD x25, x20, #0x20        | X25 = (val_7 + 32) = 1152921505572583760 (0x10000000398FF950);
            // 0x00E2C0D8: MOV w26, w22               | W26 = val_1;//m1                        
            // 0x00E2C0DC: ORR w27, wzr, #0xffff      | W27 = 65535(0xFFFF);                    
            label_18:
            // 0x00E2C0E0: CBNZ x21, #0xe2c0e8        | if (ms.Stream != null) goto label_7;    
            if(val_5 != null)
            {
                goto label_7;
            }
            // 0x00E2C0E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Object[]), ????);
            label_7:
            // 0x00E2C0E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C0EC: MOV x0, x21                | X0 = ms.Stream;//m1                     
            // 0x00E2C0F0: BL #0x269ff60              | X0 = ms.Stream.ReadInt16();             
            short val_2 = val_5.ReadInt16();
            // 0x00E2C0F4: AND w8, w0, #0xffff        | W8 = (val_2 & 65535);                   
            short val_3 = val_2 & 65535;
            // 0x00E2C0F8: CMP w8, w27                | STATE = COMPARE((val_2 & 65535), 0xFFFF)
            // 0x00E2C0FC: B.EQ #0xe2c178             | if (val_3 == 65535) goto label_8;       
            if(val_3 == 65535)
            {
                goto label_8;
            }
            // 0x00E2C100: SXTH w22, w0               | W22 = (int)(short)((val_2) & 0xFFFF);   
            // 0x00E2C104: CBNZ x19, #0xe2c10c        | if (ms != null) goto label_9;           
            if(ms != null)
            {
                goto label_9;
            }
            // 0x00E2C108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_9:
            // 0x00E2C10C: LDR x23, [x19, #0x18]      | X23 = ms.objs; //P2                     
            val_6 = ms.objs;
            // 0x00E2C110: CBNZ x23, #0xe2c118        | if (ms.objs != null) goto label_10;     
            if(val_6 != null)
            {
                goto label_10;
            }
            // 0x00E2C114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_10:
            // 0x00E2C118: LDR x2, [x28]              | X2 = public UnityEngine.Object System.Collections.Generic.List<UnityEngine.Object>::get_Item(int index);
            // 0x00E2C11C: MOV x0, x23                | X0 = ms.objs;//m1                       
            // 0x00E2C120: MOV w1, w22                | W1 = (int)(short)((val_2) & 0xFFFF);//m1
            // 0x00E2C124: BL #0x25ed734              | X0 = ms.objs.get_Item(index:  (int)val_2 & 65535);
            UnityEngine.Object val_4 = val_6.Item[(int)val_2 & 65535];
            // 0x00E2C128: MOV x22, x0                | X22 = val_4;//m1                        
            // 0x00E2C12C: CBNZ x20, #0xe2c134        | if ( != null) goto label_11;            
            if(null != null)
            {
                goto label_11;
            }
            // 0x00E2C130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x00E2C134: CBZ x22, #0xe2c158         | if (val_4 == null) goto label_13;       
            if(val_4 == null)
            {
                goto label_13;
            }
            // 0x00E2C138: LDR x8, [x20]              | X8 = ;                                  
            // 0x00E2C13C: MOV x0, x22                | X0 = val_4;//m1                         
            // 0x00E2C140: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E2C144: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00E2C148: CBNZ x0, #0xe2c158         | if (val_4 != null) goto label_13;       
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x00E2C14C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00E2C150: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C154: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_13:
            // 0x00E2C158: LDR w8, [x20, #0x18]       | W8 = UnityEngine.Object[].__il2cppRuntimeField_namespaze;
            // 0x00E2C15C: CMP x24, x8                | STATE = COMPARE(0x0, UnityEngine.Object[].__il2cppRuntimeField_namespaze)
            // 0x00E2C160: B.LO #0xe2c170             | if (0 < UnityEngine.Object[].__il2cppRuntimeField_namespaze) goto label_14;
            // 0x00E2C164: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00E2C168: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C16C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_14:
            // 0x00E2C170: STR x22, [x25, x24, lsl #3] | UnityEngine.Object[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_4;  //  dest_result_addr=1152921505572583760
            UnityEngine.Object[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_4;
            // 0x00E2C174: B #0xe2c19c                |  goto label_15;                         
            goto label_15;
            label_8:
            // 0x00E2C178: CBNZ x20, #0xe2c180        | if ( != null) goto label_16;            
            if(null != null)
            {
                goto label_16;
            }
            // 0x00E2C17C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_16:
            // 0x00E2C180: LDR w8, [x20, #0x18]       | W8 = UnityEngine.Object[].__il2cppRuntimeField_namespaze;
            // 0x00E2C184: CMP x24, x8                | STATE = COMPARE(0x0, UnityEngine.Object[].__il2cppRuntimeField_namespaze)
            // 0x00E2C188: B.LO #0xe2c198             | if (0 < UnityEngine.Object[].__il2cppRuntimeField_namespaze) goto label_17;
            // 0x00E2C18C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00E2C190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C194: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_17:
            // 0x00E2C198: STR xzr, [x25, x24, lsl #3] | UnityEngine.Object[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = 0x0;  //  dest_result_addr=1152921505572583760
            UnityEngine.Object[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = 0;
            label_15:
            // 0x00E2C19C: ADD x24, x24, #1           | X24 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x00E2C1A0: CMP w26, w24               | STATE = COMPARE(val_1, (0 + 1))         
            // 0x00E2C1A4: B.NE #0xe2c0e0             | if (val_1 != 0) goto label_18;          
            if(val_1 != val_5)
            {
                goto label_18;
            }
            label_6:
            // 0x00E2C1A8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C1AC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C1B0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2C1B4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E2C1B8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E2C1BC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E2C1C0: RET                        |  return;                                
            return;
        
        }
    
    }

}
