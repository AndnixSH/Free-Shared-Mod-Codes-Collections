using UnityEngine;
[Serializable]
public enum Vignetting.AberrationMode
{
    // Fields
    Simple = 0
    ,Advanced = 1
    

}
