using UnityEngine;

namespace wxb
{
    internal class ArrayStrType : ITypeSerialize
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2C334 (14861108), len: 8  VirtAddr: 0x00E2C334 RVA: 0x00E2C334 token: 100681221 methodIndex: 57229 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayStrType()
        {
            //
            // Disasemble & Code
            // 0x00E2C334: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C338: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C33C (14861116), len: 664  VirtAddr: 0x00E2C33C RVA: 0x00E2C33C token: 100681222 methodIndex: 57230 delegateWrapperIndex: 0 methodInvoker: 0
        private int wxb.ITypeSerialize.CalculateSize(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x00E2C33C: STP x26, x25, [sp, #-0x50]! | stack[1152921513028297456] = ???;  stack[1152921513028297464] = ???;  //  dest_result_addr=1152921513028297456 |  dest_result_addr=1152921513028297464
            // 0x00E2C340: STP x24, x23, [sp, #0x10]  | stack[1152921513028297472] = ???;  stack[1152921513028297480] = ???;  //  dest_result_addr=1152921513028297472 |  dest_result_addr=1152921513028297480
            // 0x00E2C344: STP x22, x21, [sp, #0x20]  | stack[1152921513028297488] = ???;  stack[1152921513028297496] = ???;  //  dest_result_addr=1152921513028297488 |  dest_result_addr=1152921513028297496
            // 0x00E2C348: STP x20, x19, [sp, #0x30]  | stack[1152921513028297504] = ???;  stack[1152921513028297512] = ???;  //  dest_result_addr=1152921513028297504 |  dest_result_addr=1152921513028297512
            // 0x00E2C34C: STP x29, x30, [sp, #0x40]  | stack[1152921513028297520] = ???;  stack[1152921513028297528] = ???;  //  dest_result_addr=1152921513028297520 |  dest_result_addr=1152921513028297528
            // 0x00E2C350: ADD x29, sp, #0x40         | X29 = (1152921513028297456 + 64) = 1152921513028297520 (0x10000001F5F52330);
            // 0x00E2C354: SUB sp, sp, #0x10          | SP = (1152921513028297456 - 16) = 1152921513028297440 (0x10000001F5F522E0);
            // 0x00E2C358: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C35C: LDRB w8, [x20, #0x8f5]     | W8 = (bool)static_value_037348F5;       
            // 0x00E2C360: MOV x19, x1                | X19 = value;//m1                        
            // 0x00E2C364: TBNZ w8, #0, #0xe2c380     | if (static_value_037348F5 == true) goto label_0;
            // 0x00E2C368: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00E2C36C: LDR x8, [x8, #0xff8]       | X8 = 0x2B8E82C;                         
            // 0x00E2C370: LDR w0, [x8]               | W0 = 0x10C9;                            
            // 0x00E2C374: BL #0x2782188              | X0 = sub_2782188( ?? 0x10C9, ????);     
            // 0x00E2C378: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C37C: STRB w8, [x20, #0x8f5]     | static_value_037348F5 = true;            //  dest_result_addr=57886965
            label_0:
            // 0x00E2C380: ADRP x23, #0x3605000       | X23 = 56643584 (0x3605000);             
            // 0x00E2C384: LDR x23, [x23, #0x308]     | X23 = 1152921504609349632;              
            // 0x00E2C388: MOV x0, x19                | X0 = value;//m1                         
            // 0x00E2C38C: LDR x1, [x23]              | X1 = typeof(System.Collections.IList);  
            // 0x00E2C390: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x00E2C394: MOV x19, x0                | X19 = value;//m1                        
            // 0x00E2C398: CBZ x19, #0xe2c3ec         | if (value == null) goto label_1;        
            if(value == null)
            {
                goto label_1;
            }
            // 0x00E2C39C: ADRP x24, #0x35db000       | X24 = 56471552 (0x35DB000);             
            // 0x00E2C3A0: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00E2C3A4: LDR x24, [x24, #0xd0]      | X24 = 1152921504609296384;              
            // 0x00E2C3A8: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2C3AC: LDR x1, [x24]              | X1 = typeof(System.Collections.ICollection);
            // 0x00E2C3B0: CBZ x9, #0xe2c3dc          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x00E2C3B4: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2C3B8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_7 = 0;
            // 0x00E2C3BC: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_4:
            // 0x00E2C3C0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2C3C4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.ICollection))
            // 0x00E2C3C8: B.EQ #0xe2c3f4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x00E2C3CC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_7 = val_7 + 1;
            // 0x00E2C3D0: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00E2C3D4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2C3D8: B.LO #0xe2c3c0             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x00E2C3DC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E2C3E0: MOV x0, x19                | X0 = value;//m1                         
            val_7 = value;
            // 0x00E2C3E4: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00E2C3E8: B #0xe2c400                |  goto label_5;                          
            goto label_5;
            label_1:
            // 0x00E2C3EC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x00E2C3F0: B #0xe2c5a0                |  goto label_14;                         
            goto label_14;
            label_3:
            // 0x00E2C3F4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2C3F8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E2C3FC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x00E2C400: LDP x8, x1, [x0]           | X8 = typeof(System.Object);              //  | 
            // 0x00E2C404: MOV x0, x19                | X0 = value;//m1                         
            // 0x00E2C408: BLR x8                     | X0 = sub_100000000000D000( ?? value, ????);
            // 0x00E2C40C: ADRP x25, #0x35df000       | X25 = 56487936 (0x35DF000);             
            // 0x00E2C410: LDR x25, [x25, #0xfd8]     | X25 = 1152921504831766528;              
            // 0x00E2C414: MOV w20, w0                | W20 = value;//m1                        
            // 0x00E2C418: LDR x8, [x25]              | X8 = typeof(wxb.WRStream);              
            // 0x00E2C41C: LDRB w9, [x8, #0x10a]      | W9 = wxb.WRStream.__il2cppRuntimeField_10A;
            // 0x00E2C420: TBZ w9, #0, #0xe2c434      | if (wxb.WRStream.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E2C424: LDR w9, [x8, #0xbc]        | W9 = wxb.WRStream.__il2cppRuntimeField_cctor_finished;
            // 0x00E2C428: CBNZ w9, #0xe2c434         | if (wxb.WRStream.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E2C42C: MOV x0, x8                 | X0 = 1152921504831766528 (0x100000000D680000);//ML01
            // 0x00E2C430: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.WRStream), ????);
            label_8:
            // 0x00E2C434: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2C438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x00E2C43C: MOV w1, w20                | W1 = value;//m1                         
            // 0x00E2C440: BL #0x26a48fc              | X0 = wxb.WRStream.ComputeLengthSize(length:  0);
            int val_2 = wxb.WRStream.ComputeLengthSize(length:  0);
            // 0x00E2C444: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
            // 0x00E2C448: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
            // 0x00E2C44C: MOV w20, w0                | W20 = val_2;//m1                        
            val_8 = val_2;
            // 0x00E2C450: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x00E2C454: B #0xe2c470                |  goto label_9;                          
            goto label_9;
            label_23:
            // 0x00E2C458: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E2C45C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x00E2C460: MOV x1, x22                | X1 = X22;//m1                           
            // 0x00E2C464: BL #0x26a3c24              | X0 = wxb.WRStream.ComputeStringSize(value:  0);
            int val_3 = wxb.WRStream.ComputeStringSize(value:  0);
            // 0x00E2C468: ADD w20, w0, w20           | W20 = (val_3 + val_2);                  
            val_8 = val_3 + val_8;
            // 0x00E2C46C: ADD w21, w21, #1           | W21 = (val_10 + 1) = val_10 (0x00000001);
            val_10 = 1;
            label_9:
            // 0x00E2C470: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00E2C474: LDR x1, [x24]              | X1 = typeof(System.Collections.ICollection);
            // 0x00E2C478: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2C47C: CBZ x9, #0xe2c4a8          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_10;
            // 0x00E2C480: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2C484: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x00E2C488: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_12:
            // 0x00E2C48C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2C490: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.ICollection))
            // 0x00E2C494: B.EQ #0xe2c4b8             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_11;
            // 0x00E2C498: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x00E2C49C: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00E2C4A0: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2C4A4: B.LO #0xe2c48c             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_12;
            label_10:
            // 0x00E2C4A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_9 = 0;
            // 0x00E2C4AC: MOV x0, x19                | X0 = value;//m1                         
            val_11 = value;
            // 0x00E2C4B0: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00E2C4B4: B #0xe2c4c4                |  goto label_13;                         
            goto label_13;
            label_11:
            // 0x00E2C4B8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2C4BC: ADD x8, x8, x9, lsl #4     | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E2C4C0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_13:
            // 0x00E2C4C4: LDP x8, x1, [x0]           | X8 = val_3; X1 = val_3 + 8;              //  | 
            // 0x00E2C4C8: MOV x0, x19                | X0 = value;//m1                         
            // 0x00E2C4CC: BLR x8                     | X0 = val_3();                           
            // 0x00E2C4D0: CMP w21, w0                | STATE = COMPARE(0x1, value)             
            // 0x00E2C4D4: B.GE #0xe2c5a0             | if (val_10 >= value) goto label_14;     
            if(val_10 >= value)
            {
                goto label_14;
            }
            // 0x00E2C4D8: LDR x8, [x19]              | X8 = typeof(System.Object);             
            // 0x00E2C4DC: LDR x1, [x23]              | X1 = typeof(System.Collections.IList);  
            // 0x00E2C4E0: LDRH w9, [x8, #0x102]      | W9 = System.Object.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E2C4E4: CBZ x9, #0xe2c510          | if (System.Object.__il2cppRuntimeField_interface_offsets_count == 0) goto label_15;
            // 0x00E2C4E8: LDR x10, [x8, #0x98]       | X10 = System.Object.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E2C4EC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x00E2C4F0: ADD x10, x10, #8           | X10 = (System.Object.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504606937096 (0x1000000000016008);
            label_17:
            // 0x00E2C4F4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E2C4F8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x00E2C4FC: B.EQ #0xe2c520             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_16;
            // 0x00E2C500: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x00E2C504: ADD x10, x10, #0x10        | X10 = (1152921504606937096 + 16) = 1152921504606937112 (0x1000000000016018);
            // 0x00E2C508: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Object.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E2C50C: B.LO #0xe2c4f4             | if (0 < System.Object.__il2cppRuntimeField_interface_offsets_count) goto label_17;
            label_15:
            // 0x00E2C510: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            val_9 = 2;
            // 0x00E2C514: MOV x0, x19                | X0 = value;//m1                         
            val_12 = value;
            // 0x00E2C518: BL #0x2776c24              | X0 = sub_2776C24( ?? value, ????);      
            // 0x00E2C51C: B #0xe2c530                |  goto label_18;                         
            goto label_18;
            label_16:
            // 0x00E2C520: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E2C524: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x00E2C528: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x00E2C52C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504606900224 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_18:
            // 0x00E2C530: LDP x8, x2, [x0]           | X8 = typeof(System.Object);              //  | 
            // 0x00E2C534: MOV x0, x19                | X0 = value;//m1                         
            // 0x00E2C538: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
            // 0x00E2C53C: BLR x8                     | X0 = sub_100000000000D000( ?? value, ????);
            // 0x00E2C540: LDR x8, [x25]              | X8 = typeof(wxb.WRStream);              
            // 0x00E2C544: MOV x22, x0                | X22 = value;//m1                        
            // 0x00E2C548: LDRB w9, [x8, #0x10a]      | W9 = wxb.WRStream.__il2cppRuntimeField_10A;
            // 0x00E2C54C: TBZ w9, #0, #0xe2c560      | if (wxb.WRStream.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x00E2C550: LDR w9, [x8, #0xbc]        | W9 = wxb.WRStream.__il2cppRuntimeField_cctor_finished;
            // 0x00E2C554: CBNZ w9, #0xe2c560         | if (wxb.WRStream.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x00E2C558: MOV x0, x8                 | X0 = 1152921504831766528 (0x100000000D680000);//ML01
            // 0x00E2C55C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(wxb.WRStream), ????);
            label_20:
            // 0x00E2C560: CBZ x22, #0xe2c598         | if (value == null) goto label_21;       
            if(value == null)
            {
                goto label_21;
            }
            // 0x00E2C564: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00E2C568: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x00E2C56C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x00E2C570: B.EQ #0xe2c458             | if (typeof(System.Object) == null) goto label_23;
            if(null == null)
            {
                goto label_23;
            }
            // 0x00E2C574: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x00E2C578: ADD x8, sp, #8             | X8 = (1152921513028297440 + 8) = 1152921513028297448 (0x10000001F5F522E8);
            // 0x00E2C57C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x00E2C580: LDR x0, [sp, #8]           | X0 = val_6;                              //  find_add[1152921513028285536]
            // 0x00E2C584: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00E2C588: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C58C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00E2C590: ADD x0, sp, #8             | X0 = (1152921513028297440 + 8) = 1152921513028297448 (0x10000001F5F522E8);
            // 0x00E2C594: BL #0x299a140              | 
            label_21:
            // 0x00E2C598: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            // 0x00E2C59C: B #0xe2c458                |  goto label_23;                         
            goto label_23;
            label_14:
            // 0x00E2C5A0: MOV w0, w20                | W0 = 0 (0x0);//ML01                     
            // 0x00E2C5A4: SUB sp, x29, #0x40         | SP = (1152921513028297520 - 64) = 1152921513028297456 (0x10000001F5F522F0);
            // 0x00E2C5A8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C5AC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C5B0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2C5B4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E2C5B8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E2C5BC: RET                        |  return (System.Int32)0;                
            return (int)val_8;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            // 0x00E2C5C0: MOV x19, x0                | 
            // 0x00E2C5C4: ADD x0, sp, #8             | 
            // 0x00E2C5C8: BL #0x299a140              | 
            // 0x00E2C5CC: MOV x0, x19                | 
            // 0x00E2C5D0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C5D4 (14861780), len: 232  VirtAddr: 0x00E2C5D4 RVA: 0x00E2C5D4 token: 100681223 methodIndex: 57231 delegateWrapperIndex: 0 methodInvoker: 0
        private void wxb.ITypeSerialize.WriteTo(object value, wxb.MonoStream ms)
        {
            //
            // Disasemble & Code
            //  | 
            wxb.WRStream val_1;
            // 0x00E2C5D4: STP x22, x21, [sp, #-0x30]! | stack[1152921513028429968] = ???;  stack[1152921513028429976] = ???;  //  dest_result_addr=1152921513028429968 |  dest_result_addr=1152921513028429976
            // 0x00E2C5D8: STP x20, x19, [sp, #0x10]  | stack[1152921513028429984] = ???;  stack[1152921513028429992] = ???;  //  dest_result_addr=1152921513028429984 |  dest_result_addr=1152921513028429992
            // 0x00E2C5DC: STP x29, x30, [sp, #0x20]  | stack[1152921513028430000] = ???;  stack[1152921513028430008] = ???;  //  dest_result_addr=1152921513028430000 |  dest_result_addr=1152921513028430008
            // 0x00E2C5E0: ADD x29, sp, #0x20         | X29 = (1152921513028429968 + 32) = 1152921513028430000 (0x10000001F5F728B0);
            // 0x00E2C5E4: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E2C5E8: LDRB w8, [x21, #0x8f6]     | W8 = (bool)static_value_037348F6;       
            // 0x00E2C5EC: MOV x20, x2                | X20 = ms;//m1                           
            // 0x00E2C5F0: MOV x19, x1                | X19 = value;//m1                        
            // 0x00E2C5F4: TBNZ w8, #0, #0xe2c610     | if (static_value_037348F6 == true) goto label_0;
            // 0x00E2C5F8: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x00E2C5FC: LDR x8, [x8, #0xf20]       | X8 = 0x2B8E834;                         
            // 0x00E2C600: LDR w0, [x8]               | W0 = 0x10CB;                            
            // 0x00E2C604: BL #0x2782188              | X0 = sub_2782188( ?? 0x10CB, ????);     
            // 0x00E2C608: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C60C: STRB w8, [x21, #0x8f6]     | static_value_037348F6 = true;            //  dest_result_addr=57886966
            label_0:
            // 0x00E2C610: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E2C614: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
            // 0x00E2C618: MOV x0, x19                | X0 = value;//m1                         
            // 0x00E2C61C: LDR x1, [x8]               | X1 = typeof(System.String[]);           
            // 0x00E2C620: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x00E2C624: MOV x19, x0                | X19 = value;//m1                        
            // 0x00E2C628: CBZ x19, #0xe2c6ac         | if (value == null) goto label_4;        
            if(value == null)
            {
                goto label_4;
            }
            // 0x00E2C62C: CBNZ x20, #0xe2c634        | if (ms != null) goto label_2;           
            if(ms != null)
            {
                goto label_2;
            }
            // 0x00E2C630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_2:
            // 0x00E2C634: LDR x21, [x20, #0x10]      | X21 = ms.Stream; //P2                   
            val_1 = ms.Stream;
            // 0x00E2C638: CBNZ x21, #0xe2c640        | if (ms.Stream != null) goto label_3;    
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00E2C63C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? value, ????);      
            label_3:
            // 0x00E2C640: LDR w1, [x19, #0x18]       | 
            // 0x00E2C644: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C648: MOV x0, x21                | X0 = ms.Stream;//m1                     
            // 0x00E2C64C: BL #0x26a4da0              | ms.Stream.WriteLength(length:  342050192);
            val_1.WriteLength(length:  342050192);
            // 0x00E2C650: LDR w8, [x19, #0x18]       | 
            // 0x00E2C654: CMP w8, #1                 | STATE = COMPARE(1152921504948897168, 0x1)
            // 0x00E2C658: B.LT #0xe2c6ac             | if (1152921504948897168 < 0x1) goto label_4;
            if(1152921504948897168 < 1)
            {
                goto label_4;
            }
            // 0x00E2C65C: LDR x20, [x20, #0x10]      | X20 = ms.Stream; //P2                   
            // 0x00E2C660: MOV w9, wzr                | W9 = 0 (0x0);//ML01                     
            label_7:
            // 0x00E2C664: SXTW x22, w9               | X22 = 0 (0x00000000);                   
            // 0x00E2C668: CMP w9, w8                 | STATE = COMPARE(0x0, 1152921504948897168)
            // 0x00E2C66C: B.LO #0xe2c67c             | if (0 < 1152921504948897168) goto label_5;
            if(0 < 1152921504948897168)
            {
                goto label_5;
            }
            // 0x00E2C670: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ms.Stream, ????);  
            // 0x00E2C674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ms.Stream, ????);  
            label_5:
            // 0x00E2C67C: ADD x8, x19, x22, lsl #3   | X8 = typeof(System.Object);//AP1        
            // 0x00E2C680: LDR x21, [x8, #0x20]       | X21 = System.Object.__il2cppRuntimeField_byval_arg;
            // 0x00E2C684: CBNZ x20, #0xe2c68c        | if (ms.Stream != null) goto label_6;    
            if(ms.Stream != null)
            {
                goto label_6;
            }
            // 0x00E2C688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ms.Stream, ????);  
            label_6:
            // 0x00E2C68C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C690: MOV x0, x20                | X0 = ms.Stream;//m1                     
            // 0x00E2C694: MOV x1, x21                | X1 = System.Object.__il2cppRuntimeField_byval_arg;//m1
            // 0x00E2C698: BL #0x26a3d18              | ms.Stream.WriteString(value:  System.Object.__il2cppRuntimeField_byval_arg);
            ms.Stream.WriteString(value:  System.Object.__il2cppRuntimeField_byval_arg);
            // 0x00E2C69C: LDR w8, [x19, #0x18]       | 
            // 0x00E2C6A0: ADD w9, w22, #1            | W9 = (0 + 1);                           
            var val_1 = 0 + 1;
            // 0x00E2C6A4: CMP w9, w8                 | STATE = COMPARE((0 + 1), typeof(System.Object))
            // 0x00E2C6A8: B.LT #0xe2c664             | if (val_1 < typeof(System.Object)) goto label_7;
            if(val_1 < null)
            {
                goto label_7;
            }
            label_4:
            // 0x00E2C6AC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C6B0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C6B4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E2C6B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C6BC (14862012), len: 336  VirtAddr: 0x00E2C6BC RVA: 0x00E2C6BC token: 100681224 methodIndex: 57232 delegateWrapperIndex: 0 methodInvoker: 0
        private void wxb.ITypeSerialize.MergeFrom(ref object value, wxb.MonoStream ms)
        {
            //
            // Disasemble & Code
            //  | 
            string val_3;
            //  | 
            var val_4;
            //  | 
            object val_5;
            // 0x00E2C6BC: STP x24, x23, [sp, #-0x40]! | stack[1152921513028578736] = ???;  stack[1152921513028578744] = ???;  //  dest_result_addr=1152921513028578736 |  dest_result_addr=1152921513028578744
            // 0x00E2C6C0: STP x22, x21, [sp, #0x10]  | stack[1152921513028578752] = ???;  stack[1152921513028578760] = ???;  //  dest_result_addr=1152921513028578752 |  dest_result_addr=1152921513028578760
            // 0x00E2C6C4: STP x20, x19, [sp, #0x20]  | stack[1152921513028578768] = ???;  stack[1152921513028578776] = ???;  //  dest_result_addr=1152921513028578768 |  dest_result_addr=1152921513028578776
            // 0x00E2C6C8: STP x29, x30, [sp, #0x30]  | stack[1152921513028578784] = ???;  stack[1152921513028578792] = ???;  //  dest_result_addr=1152921513028578784 |  dest_result_addr=1152921513028578792
            // 0x00E2C6CC: ADD x29, sp, #0x30         | X29 = (1152921513028578736 + 48) = 1152921513028578784 (0x10000001F5F96DE0);
            // 0x00E2C6D0: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E2C6D4: LDRB w8, [x19, #0x8f7]     | W8 = (bool)static_value_037348F7;       
            // 0x00E2C6D8: MOV x20, x2                | X20 = ms;//m1                           
            // 0x00E2C6DC: MOV x21, x1                | X21 = 1152921513028622800 (0x10000001F5FA19D0);//ML01
            val_3 = 1152921513028622800;
            // 0x00E2C6E0: TBNZ w8, #0, #0xe2c6fc     | if (static_value_037348F7 == true) goto label_0;
            // 0x00E2C6E4: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00E2C6E8: LDR x8, [x8, #0x410]       | X8 = 0x2B8E830;                         
            // 0x00E2C6EC: LDR w0, [x8]               | W0 = 0x10CA;                            
            // 0x00E2C6F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x10CA, ????);     
            // 0x00E2C6F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C6F8: STRB w8, [x19, #0x8f7]     | static_value_037348F7 = true;            //  dest_result_addr=57886967
            label_0:
            // 0x00E2C6FC: CBNZ x20, #0xe2c704        | if (ms != null) goto label_1;           
            if(ms != null)
            {
                goto label_1;
            }
            // 0x00E2C700: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10CA, ????);     
            label_1:
            // 0x00E2C704: LDR x19, [x20, #0x10]      | X19 = ms.Stream; //P2                   
            // 0x00E2C708: CBNZ x19, #0xe2c710        | if (ms.Stream != null) goto label_2;    
            if(ms.Stream != null)
            {
                goto label_2;
            }
            // 0x00E2C70C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10CA, ????);     
            label_2:
            // 0x00E2C710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C714: MOV x0, x19                | X0 = ms.Stream;//m1                     
            // 0x00E2C718: BL #0x26a4e7c              | X0 = ms.Stream.ReadLength();            
            int val_1 = ms.Stream.ReadLength();
            // 0x00E2C71C: ADRP x23, #0x3680000       | X23 = 57147392 (0x3680000);             
            // 0x00E2C720: LDR x8, [x21]              | X8 = value;                             
            // 0x00E2C724: LDR x23, [x23, #0x2d0]     | X23 = 1152921504948897168;              
            val_4 = 1152921504948897168;
            // 0x00E2C728: MOV w22, w0                | W22 = val_1;//m1                        
            // 0x00E2C72C: MOV x0, x8                 | X0 = value;//m1                         
            // 0x00E2C730: LDR x1, [x23]              | X1 = typeof(System.String[]);           
            // 0x00E2C734: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x00E2C738: MOV x19, x0                | X19 = value;//m1                        
            val_5 = value;
            // 0x00E2C73C: CBZ x19, #0xe2c74c         | if (value == null) goto label_3;        
            if(val_5 == null)
            {
                goto label_3;
            }
            // 0x00E2C740: LDR w8, [x19, #0x18]       |  //  not_find_field!1:24
            // 0x00E2C744: CMP w8, w22                | STATE = COMPARE(mem[value + 24], val_1) 
            // 0x00E2C748: B.EQ #0xe2c76c             | if (mem[value + 24] == val_1) goto label_4;
            if((mem[value + 24]) == val_1)
            {
                goto label_4;
            }
            label_3:
            // 0x00E2C74C: LDR x19, [x23]             | X19 = typeof(System.String[]);          
            // 0x00E2C750: MOV x0, x19                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E2C754: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00E2C758: MOV w1, w22                | W1 = val_1;//m1                         
            // 0x00E2C75C: MOV x0, x19                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E2C760: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00E2C764: MOV x19, x0                | X19 = 1152921504948897168 (0x1000000014634590);//ML01
            val_5 = null;
            // 0x00E2C768: STR x19, [x21]             | value = typeof(System.String[]);         //  dest_result_addr=1152921513028622800
            value = val_5;
            label_4:
            // 0x00E2C76C: CBNZ x20, #0xe2c774        | if (ms != null) goto label_5;           
            if(ms != null)
            {
                goto label_5;
            }
            // 0x00E2C770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_5:
            // 0x00E2C774: CMP w22, #1                | STATE = COMPARE(val_1, 0x1)             
            // 0x00E2C778: B.LT #0xe2c7f8             | if (val_1 < 1) goto label_6;            
            if(val_1 < 1)
            {
                goto label_6;
            }
            // 0x00E2C77C: LDR x20, [x20, #0x10]      | X20 = ms.Stream; //P2                   
            // 0x00E2C780: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            // 0x00E2C784: ADD x24, x19, #0x20        | X24 = (val_5 + 32) = 1152921504948897200 (0x10000000146345B0);
            // 0x00E2C788: MOV w22, w22               | W22 = val_1;//m1                        
            label_12:
            // 0x00E2C78C: CBNZ x20, #0xe2c794        | if (ms.Stream != null) goto label_7;    
            if(ms.Stream != null)
            {
                goto label_7;
            }
            // 0x00E2C790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_7:
            // 0x00E2C794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C798: MOV x0, x20                | X0 = ms.Stream;//m1                     
            // 0x00E2C79C: BL #0x26a3f24              | X0 = ms.Stream.ReadString();            
            string val_2 = ms.Stream.ReadString();
            // 0x00E2C7A0: MOV x21, x0                | X21 = val_2;//m1                        
            val_3 = val_2;
            // 0x00E2C7A4: CBNZ x19, #0xe2c7ac        | if ( != null) goto label_8;             
            if(null != null)
            {
                goto label_8;
            }
            // 0x00E2C7A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x00E2C7AC: CBZ x21, #0xe2c7d0         | if (val_2 == null) goto label_10;       
            if(val_3 == null)
            {
                goto label_10;
            }
            // 0x00E2C7B0: LDR x8, [x19]              | X8 = ;                                  
            // 0x00E2C7B4: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00E2C7B8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E2C7BC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_2, ????);      
            // 0x00E2C7C0: CBNZ x0, #0xe2c7d0         | if (val_2 != null) goto label_10;       
            if(val_3 != null)
            {
                goto label_10;
            }
            // 0x00E2C7C4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_2, ????);      
            // 0x00E2C7C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C7CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_10:
            // 0x00E2C7D0: LDR w8, [x19, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E2C7D4: CMP x23, x8                | STATE = COMPARE(0x0, System.String[].__il2cppRuntimeField_namespaze)
            // 0x00E2C7D8: B.LO #0xe2c7e8             | if (0 < System.String[].__il2cppRuntimeField_namespaze) goto label_11;
            // 0x00E2C7DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00E2C7E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C7E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_11:
            // 0x00E2C7E8: STR x21, [x24, x23, lsl #3] | System.String[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_2;  //  dest_result_addr=1152921504948897200
            System.String[].__il2cppRuntimeField_byval_arg.__il2cppRuntimeField_0 = val_3;
            // 0x00E2C7EC: ADD x23, x23, #1           | X23 = (0 + 1);                          
            val_4 = 0 + 1;
            // 0x00E2C7F0: CMP w22, w23               | STATE = COMPARE(val_1, (0 + 1))         
            // 0x00E2C7F4: B.NE #0xe2c78c             | if (val_1 != val_4) goto label_12;      
            if(val_1 != val_4)
            {
                goto label_12;
            }
            label_6:
            // 0x00E2C7F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C7FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C800: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E2C804: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E2C808: RET                        |  return;                                
            return;
        
        }
    
    }

}
