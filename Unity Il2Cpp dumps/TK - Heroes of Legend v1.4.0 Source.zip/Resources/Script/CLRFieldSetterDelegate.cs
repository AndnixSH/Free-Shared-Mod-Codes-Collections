using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public sealed class CLRFieldSetterDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E9240 (42897984), len: 16  VirtAddr: 0x028E9240 RVA: 0x028E9240 token: 100680192 methodIndex: 29543 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRFieldSetterDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x028E9240: LDR x8, [x2]               | X8 = method;                            
            // 0x028E9244: STP x1, x2, [x0, #0x20]    | mem[1152921512876116192] = object;  mem[1152921512876116200] = method;  //  dest_result_addr=1152921512876116192 |  dest_result_addr=1152921512876116200
            mem[1152921512876116192] = object;
            mem[1152921512876116200] = method;
            // 0x028E9248: STR x8, [x0, #0x10]        | mem[1152921512876116176] = method;       //  dest_result_addr=1152921512876116176
            mem[1152921512876116176] = method;
            // 0x028E924C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9250 (42898000), len: 564  VirtAddr: 0x028E9250 RVA: 0x028E9250 token: 100680193 methodIndex: 29544 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void Invoke(ref object target, object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            label_1:
            // 0x028E9250: STP x24, x23, [sp, #-0x40]! | stack[1152921512876236496] = ???;  stack[1152921512876236504] = ???;  //  dest_result_addr=1152921512876236496 |  dest_result_addr=1152921512876236504
            // 0x028E9254: STP x22, x21, [sp, #0x10]  | stack[1152921512876236512] = ???;  stack[1152921512876236520] = ???;  //  dest_result_addr=1152921512876236512 |  dest_result_addr=1152921512876236520
            // 0x028E9258: STP x20, x19, [sp, #0x20]  | stack[1152921512876236528] = ???;  stack[1152921512876236536] = ???;  //  dest_result_addr=1152921512876236528 |  dest_result_addr=1152921512876236536
            // 0x028E925C: STP x29, x30, [sp, #0x30]  | stack[1152921512876236544] = ???;  stack[1152921512876236552] = ???;  //  dest_result_addr=1152921512876236544 |  dest_result_addr=1152921512876236552
            // 0x028E9260: ADD x29, sp, #0x30         | X29 = (1152921512876236496 + 48) = 1152921512876236544 (0x10000001ECE4DF00);
            // 0x028E9264: SUB sp, sp, #0x10          | SP = (1152921512876236496 - 16) = 1152921512876236480 (0x10000001ECE4DEC0);
            // 0x028E9268: MOV x23, x0                | X23 = 1152921512876248560 (0x10000001ECE50DF0);//ML01
            // 0x028E926C: LDR x0, [x23, #0x58]       | 
            // 0x028E9270: MOV x19, x2                | X19 = value;//m1                        
            // 0x028E9274: MOV x20, x1                | X20 = 1152921512876280560 (0x10000001ECE58AF0);//ML01
            // 0x028E9278: CBZ x0, #0x28e9288         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x028E927C: MOV x1, x20                | X1 = 1152921512876280560 (0x10000001ECE58AF0);//ML01
            // 0x028E9280: MOV x2, x19                | X2 = value;//m1                         
            // 0x028E9284: BL #0x28e9250              |  R0 = label_1();                        
            label_0:
            // 0x028E9288: LDR x0, [x23, #0x10]       | 
            // 0x028E928C: STR x0, [sp, #8]           | stack[1152921512876236488] = this;       //  dest_result_addr=1152921512876236488
            // 0x028E9290: LDP x21, x22, [x23, #0x20] |                                          //  | 
            // 0x028E9294: MOV x0, x22                | X0 = X22;//m1                           
            // 0x028E9298: BL #0x2796f94              | X0 = sub_2796F94( ?? X22, ????);        
            // 0x028E929C: MOV x0, x22                | X0 = X22;//m1                           
            // 0x028E92A0: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X22, ????);        
            // 0x028E92A4: AND w8, w0, #1             | W8 = (X22 & 1);                         
            var val_1 = X22 & 1;
            // 0x028E92A8: TBZ w8, #0, #0x28e9338     | if (((X22 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x028E92AC: LDRSH w8, [x22, #0x4c]     | W8 = X22 + 76;                          
            // 0x028E92B0: CMN w8, #1                 | STATE = COMPARE(X22 + 76, 0x1)          
            // 0x028E92B4: B.EQ #0x28e934c            | if (X22 + 76 == 0x1) goto label_6;      
            if((X22 + 76) == 1)
            {
                goto label_6;
            }
            // 0x028E92B8: CBZ x21, #0x28e92c8        | if (X21 == 0) goto label_4;             
            if(X21 == 0)
            {
                goto label_4;
            }
            // 0x028E92BC: LDR x8, [x21]              | X8 = X21;                               
            // 0x028E92C0: LDRB w8, [x8, #0xed]       | W8 = X21 + 237;                         
            // 0x028E92C4: TBNZ w8, #0, #0x28e934c    | if ((X21 + 237 & 0x1) != 0) goto label_6;
            if(((X21 + 237) & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x028E92C8: LDR x8, [x23, #0x18]       | 
            // 0x028E92CC: CBZ x8, #0x28e934c         | if (X21 + 237 == 0) goto label_6;       
            if((X21 + 237) == 0)
            {
                goto label_6;
            }
            // 0x028E92D0: MOV x0, x22                | X0 = X22;//m1                           
            // 0x028E92D4: BL #0x27c0990              | X0 = sub_27C0990( ?? X22, ????);        
            // 0x028E92D8: MOV w23, w0                | W23 = X22;//m1                          
            // 0x028E92DC: MOV x0, x22                | X0 = X22;//m1                           
            // 0x028E92E0: BL #0x27c0a0c              | X0 = X22.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X22.pressedSprite;
            // 0x028E92E4: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x028E92E8: TBZ w23, #0, #0x28e93a8    | if ((X22 & 0x1) == 0) goto label_7;     
            if((X22 & 1) == 0)
            {
                goto label_7;
            }
            // 0x028E92EC: TBZ w0, #0, #0x28e9404     | if ((val_2 & 0x1) == 0) goto label_8;   
            if((val_2 & 1) == 0)
            {
                goto label_8;
            }
            // 0x028E92F0: LDR x8, [x21]              | X8 = X21;                               
            var val_11 = X21;
            // 0x028E92F4: LDR x1, [x22, #0x18]       | X1 = X22 + 24;                          
            // 0x028E92F8: LDRH w2, [x22, #0x4c]      | W2 = X22 + 76;                          
            // 0x028E92FC: LDRH w9, [x8, #0x102]      | W9 = X21 + 258;                         
            // 0x028E9300: CBZ x9, #0x28e932c         | if (X21 + 258 == 0) goto label_9;       
            if((X21 + 258) == 0)
            {
                goto label_9;
            }
            // 0x028E9304: LDR x10, [x8, #0x98]       | X10 = X21 + 152;                        
            var val_5 = X21 + 152;
            // 0x028E9308: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x028E930C: ADD x10, x10, #8           | X10 = (X21 + 152 + 8);                  
            val_5 = val_5 + 8;
            label_11:
            // 0x028E9310: LDUR x12, [x10, #-8]       | X12 = (X21 + 152 + 8) + -8;             
            // 0x028E9314: CMP x12, x1                | STATE = COMPARE((X21 + 152 + 8) + -8, X22 + 24)
            // 0x028E9318: B.EQ #0x28e9428            | if ((X21 + 152 + 8) + -8 == X22 + 24) goto label_10;
            if(((X21 + 152 + 8) + -8) == (X22 + 24))
            {
                goto label_10;
            }
            // 0x028E931C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x028E9320: ADD x10, x10, #0x10        | X10 = ((X21 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x028E9324: CMP x11, x9                | STATE = COMPARE((0 + 1), X21 + 258)     
            // 0x028E9328: B.LO #0x28e9310            | if (0 < X21 + 258) goto label_11;       
            if(val_6 < (X21 + 258))
            {
                goto label_11;
            }
            label_9:
            // 0x028E932C: MOV x0, x21                | X0 = X21;//m1                           
            val_7 = X21;
            // 0x028E9330: BL #0x2776c24              | X0 = sub_2776C24( ?? X21, ????);        
            // 0x028E9334: B #0x28e9438               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x028E9338: LDRB w8, [x22, #0x4e]      | W8 = X22 + 78;                          
            // 0x028E933C: CMP w8, #2                 | STATE = COMPARE(X22 + 78, 0x2)          
            // 0x028E9340: B.NE #0x28e9378            | if (X22 + 78 != 0x2) goto label_13;     
            if((X22 + 78) != 2)
            {
                goto label_13;
            }
            // 0x028E9344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9348: B #0x28e9350               |  goto label_14;                         
            goto label_14;
            label_6:
            // 0x028E934C: MOV x0, x21                | X0 = X21;//m1                           
            label_14:
            // 0x028E9350: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x028E9354: MOV x1, x20                | X1 = 1152921512876280560 (0x10000001ECE58AF0);//ML01
            // 0x028E9358: MOV x2, x19                | X2 = value;//m1                         
            // 0x028E935C: MOV x3, x22                | X3 = X22;//m1                           
            label_23:
            // 0x028E9360: SUB sp, x29, #0x30         | SP = (1152921512876236544 - 48) = 1152921512876236496 (0x10000001ECE4DED0);
            // 0x028E9364: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9368: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028E936C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028E9370: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028E9374: BR x4                      | X0 = this( ?? X21, ????);               
            label_13:
            // 0x028E9378: LDR x5, [sp, #8]           | X5 = this;                              
            // 0x028E937C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9380: MOV x1, x21                | X1 = X21;//m1                           
            // 0x028E9384: MOV x2, x20                | X2 = 1152921512876280560 (0x10000001ECE58AF0);//ML01
            // 0x028E9388: MOV x3, x19                | X3 = value;//m1                         
            // 0x028E938C: MOV x4, x22                | X4 = X22;//m1                           
            // 0x028E9390: SUB sp, x29, #0x30         | SP = (1152921512876236544 - 48) = 1152921512876236496 (0x10000001ECE4DED0);
            // 0x028E9394: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9398: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028E939C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028E93A0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028E93A4: BR x5                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x028E93A8: LDRH w23, [x22, #0x4c]     | W23 = X22 + 76;                         
            // 0x028E93AC: TBZ w0, #0, #0x28e9418     | if ((val_2 & 0x1) == 0) goto label_15;  
            if((val_2 & 1) == 0)
            {
                goto label_15;
            }
            // 0x028E93B0: MOV x0, x22                | X0 = X22;//m1                           
            // 0x028E93B4: BL #0x27c0a0c              | X0 = X22.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X22.pressedSprite;
            // 0x028E93B8: LDR x9, [x21]              | X9 = X21;                               
            // 0x028E93BC: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x028E93C0: LDRH w10, [x9, #0x102]     | W10 = X21 + 258;                        
            // 0x028E93C4: CBZ x10, #0x28e93f0        | if (X21 + 258 == 0) goto label_16;      
            if((X21 + 258) == 0)
            {
                goto label_16;
            }
            // 0x028E93C8: LDR x11, [x9, #0x98]       | X11 = X21 + 152;                        
            var val_7 = X21 + 152;
            // 0x028E93CC: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028E93D0: ADD x11, x11, #8           | X11 = (X21 + 152 + 8);                  
            val_7 = val_7 + 8;
            label_18:
            // 0x028E93D4: LDUR x13, [x11, #-8]       | X13 = (X21 + 152 + 8) + -8;             
            // 0x028E93D8: CMP x13, x8                | STATE = COMPARE((X21 + 152 + 8) + -8, val_3)
            // 0x028E93DC: B.EQ #0x28e9460            | if ((X21 + 152 + 8) + -8 == val_3) goto label_17;
            if(((X21 + 152 + 8) + -8) == val_3)
            {
                goto label_17;
            }
            // 0x028E93E0: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028E93E4: ADD x11, x11, #0x10        | X11 = ((X21 + 152 + 8) + 16);           
            val_7 = val_7 + 16;
            // 0x028E93E8: CMP x12, x10               | STATE = COMPARE((0 + 1), X21 + 258)     
            // 0x028E93EC: B.LO #0x28e93d4            | if (0 < X21 + 258) goto label_18;       
            if(val_8 < (X21 + 258))
            {
                goto label_18;
            }
            label_16:
            // 0x028E93F0: MOV x0, x21                | X0 = X21;//m1                           
            val_8 = X21;
            // 0x028E93F4: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x028E93F8: MOV w2, w23                | W2 = X22 + 76;//m1                      
            // 0x028E93FC: BL #0x2776c24              | X0 = sub_2776C24( ?? X21, ????);        
            // 0x028E9400: B #0x28e9470               |  goto label_19;                         
            goto label_19;
            label_8:
            // 0x028E9404: LDRH w8, [x22, #0x4c]      | W8 = X22 + 76;                          
            // 0x028E9408: LDR x9, [x21]              | X9 = X21;                               
            // 0x028E940C: ADD x8, x9, x8, lsl #4     | X8 = (X21 + (X22 + 76) << 4);           
            var val_4 = X21 + ((X22 + 76) << 4);
            // 0x028E9410: LDR x0, [x8, #0x118]       | X0 = (X21 + (X22 + 76) << 4) + 280;     
            val_9 = mem[(X21 + (X22 + 76) << 4) + 280];
            val_9 = (X21 + (X22 + 76) << 4) + 280;
            // 0x028E9414: B #0x28e943c               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x028E9418: LDR x8, [x21]              | X8 = X21;                               
            var val_9 = X21;
            // 0x028E941C: ADD x8, x8, w23, uxtw #4   | X8 = (X21 + X22 + 76);                  
            val_9 = val_9 + (X22 + 76);
            // 0x028E9420: LDP x4, x3, [x8, #0x110]   | X4 = (X21 + X22 + 76) + 272; X3 = (X21 + X22 + 76) + 272 + 8; //  | 
            // 0x028E9424: B #0x28e9474               |  goto label_21;                         
            goto label_21;
            label_10:
            // 0x028E9428: LDR w9, [x10]              | W9 = (X21 + 152 + 8);                   
            var val_10 = val_5;
            // 0x028E942C: ADD w9, w9, w2             | W9 = ((X21 + 152 + 8) + X22 + 76);      
            val_10 = val_10 + (X22 + 76);
            // 0x028E9430: ADD x8, x8, w9, uxtw #4    | X8 = (X21 + ((X21 + 152 + 8) + X22 + 76));
            val_11 = val_11 + val_10;
            // 0x028E9434: ADD x0, x8, #0x110         | X0 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272);
            val_7 = val_11 + 272;
            label_12:
            // 0x028E9438: LDR x0, [x0, #8]           | X0 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8;
            val_9 = mem[((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8];
            val_9 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8;
            label_20:
            // 0x028E943C: MOV x1, x22                | X1 = X22;//m1                           
            // 0x028E9440: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8, ????);
            // 0x028E9444: MOV x8, x0                 | X8 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8;//m1
            // 0x028E9448: LDR x4, [x8]               | X4 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8;
            // 0x028E944C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9450: MOV x1, x20                | X1 = 1152921512876280560 (0x10000001ECE58AF0);//ML01
            // 0x028E9454: MOV x2, x19                | X2 = value;//m1                         
            // 0x028E9458: MOV x3, x8                 | X3 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8;//m1
            // 0x028E945C: B #0x28e9360               |  goto label_23;                         
            goto label_23;
            label_17:
            // 0x028E9460: LDR w8, [x11]              | W8 = (X21 + 152 + 8);                   
            var val_12 = val_7;
            // 0x028E9464: ADD w8, w8, w23            | W8 = ((X21 + 152 + 8) + X22 + 76);      
            val_12 = val_12 + (X22 + 76);
            // 0x028E9468: ADD x8, x9, w8, uxtw #4    | X8 = (X21 + ((X21 + 152 + 8) + X22 + 76));
            val_12 = X21 + val_12;
            // 0x028E946C: ADD x0, x8, #0x110         | X0 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272);
            val_8 = val_12 + 272;
            label_19:
            // 0x028E9470: LDP x4, x3, [x0]           | X4 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272); X3 = ((X21 + ((X21 + 152 + 8) + X22 + 76)) + 272) + 8; //  | 
            label_21:
            // 0x028E9474: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9478: MOV x1, x20                | X1 = 1152921512876280560 (0x10000001ECE58AF0);//ML01
            // 0x028E947C: MOV x2, x19                | X2 = value;//m1                         
            // 0x028E9480: B #0x28e9360               |  goto label_23;                         
            goto label_23;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9484 (42898564), len: 56  VirtAddr: 0x028E9484 RVA: 0x028E9484 token: 100680194 methodIndex: 29545 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(ref object target, object value, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x028E9484: STP x29, x30, [sp, #-0x10]! | stack[1152921512876381168] = ???;  stack[1152921512876381176] = ???;  //  dest_result_addr=1152921512876381168 |  dest_result_addr=1152921512876381176
            // 0x028E9488: MOV x29, sp                | X29 = 1152921512876381168 (0x10000001ECE713F0);//ML01
            // 0x028E948C: SUB sp, sp, #0x20          | SP = (1152921512876381168 - 32) = 1152921512876381136 (0x10000001ECE713D0);
            // 0x028E9490: STP xzr, xzr, [sp, #0x10]  | stack[1152921512876381152] = 0x0;  stack[1152921512876381160] = 0x0;  //  dest_result_addr=1152921512876381152 |  dest_result_addr=1152921512876381160
            // 0x028E9494: STR xzr, [sp, #8]          | stack[1152921512876381144] = 0x0;        //  dest_result_addr=1152921512876381144
            // 0x028E9498: LDR x8, [x1]               | X8 = target;                            
            // 0x028E949C: ADD x1, sp, #8             | X1 = (1152921512876381136 + 8) = 1152921512876381144 (0x10000001ECE713D8);
            // 0x028E94A0: STP x8, x2, [sp, #8]       | stack[1152921512876381144] = target;  stack[1152921512876381152] = value;  //  dest_result_addr=1152921512876381144 |  dest_result_addr=1152921512876381152
            // 0x028E94A4: MOV x2, x3                 | X2 = callback;//m1                      
            // 0x028E94A8: MOV x3, x4                 | X3 = object;//m1                        
            // 0x028E94AC: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x028E94B0: MOV sp, x29                | SP = 1152921512876381168 (0x10000001ECE713F0);//ML01
            // 0x028E94B4: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E94B8: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E94BC (42898620), len: 40  VirtAddr: 0x028E94BC RVA: 0x028E94BC token: 100680195 methodIndex: 29546 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual void EndInvoke(ref object target, System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x028E94BC: STP x29, x30, [sp, #-0x10]! | stack[1152921512876517600] = ???;  stack[1152921512876517608] = ???;  //  dest_result_addr=1152921512876517600 |  dest_result_addr=1152921512876517608
            // 0x028E94C0: MOV x29, sp                | X29 = 1152921512876517600 (0x10000001ECE928E0);//ML01
            // 0x028E94C4: SUB sp, sp, #0x10          | SP = (1152921512876517600 - 16) = 1152921512876517584 (0x10000001ECE928D0);
            // 0x028E94C8: STR x1, [sp, #8]           | stack[1152921512876517592] = target;     //  dest_result_addr=1152921512876517592
            // 0x028E94CC: ADD x1, sp, #8             | X1 = (1152921512876517584 + 8) = 1152921512876517592 (0x10000001ECE928D8);
            // 0x028E94D0: MOV x0, x2                 | X0 = result;//m1                        
            // 0x028E94D4: BL #0x278fde8              | X0 = sub_278FDE8( ?? result, ????);     
            // 0x028E94D8: MOV sp, x29                | SP = 1152921512876517600 (0x10000001ECE928E0);//ML01
            // 0x028E94DC: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E94E0: RET                        |  return;                                
            return;
        
        }
    
    }

}
