using UnityEngine;

namespace Mihua.Asset.ABLoadOperation
{
    public class AssetOperationLoaded : AssetOperation
    {
        // Fields
        private string m_AssetName; //  0x00000018
        
        // Properties
        public override float progress { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AB04D4 (11207892), len: 52  VirtAddr: 0x00AB04D4 RVA: 0x00AB04D4 token: 100693164 methodIndex: 46911 delegateWrapperIndex: 0 methodInvoker: 0
        public AssetOperationLoaded(string assetName)
        {
            //
            // Disasemble & Code
            // 0x00AB04D4: STP x20, x19, [sp, #-0x20]! | stack[1152921514947218544] = ???;  stack[1152921514947218552] = ???;  //  dest_result_addr=1152921514947218544 |  dest_result_addr=1152921514947218552
            // 0x00AB04D8: STP x29, x30, [sp, #0x10]  | stack[1152921514947218560] = ???;  stack[1152921514947218568] = ???;  //  dest_result_addr=1152921514947218560 |  dest_result_addr=1152921514947218568
            // 0x00AB04DC: ADD x29, sp, #0x10         | X29 = (1152921514947218544 + 16) = 1152921514947218560 (0x1000000268558C80);
            // 0x00AB04E0: MOV x19, x1                | X19 = assetName;//m1                    
            // 0x00AB04E4: MOV x20, x0                | X20 = 1152921514947230576 (0x100000026855BB70);//ML01
            // 0x00AB04E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB04EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB04F0: STRB w8, [x20, #0x11]      | mem[1152921514947230593] = 0x1;          //  dest_result_addr=1152921514947230593
            mem[1152921514947230593] = 1;
            // 0x00AB04F4: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00AB04F8: STR x19, [x20, #0x18]      | this.m_AssetName = assetName;            //  dest_result_addr=1152921514947230600
            this.m_AssetName = assetName;
            // 0x00AB04FC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB0500: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB0504: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0508 (11207944), len: 120  VirtAddr: 0x00AB0508 RVA: 0x00AB0508 token: 100693165 methodIndex: 46912 delegateWrapperIndex: 0 methodInvoker: 0
        public override UnityEngine.Object GetAsset()
        {
            //
            // Disasemble & Code
            // 0x00AB0508: STP x20, x19, [sp, #-0x20]! | stack[1152921514947339760] = ???;  stack[1152921514947339768] = ???;  //  dest_result_addr=1152921514947339760 |  dest_result_addr=1152921514947339768
            // 0x00AB050C: STP x29, x30, [sp, #0x10]  | stack[1152921514947339776] = ???;  stack[1152921514947339784] = ???;  //  dest_result_addr=1152921514947339776 |  dest_result_addr=1152921514947339784
            // 0x00AB0510: ADD x29, sp, #0x10         | X29 = (1152921514947339760 + 16) = 1152921514947339776 (0x1000000268576600);
            // 0x00AB0514: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB0518: LDRB w8, [x20, #0x3da]     | W8 = (bool)static_value_037333DA;       
            // 0x00AB051C: MOV x19, x0                | X19 = 1152921514947351792 (0x10000002685794F0);//ML01
            // 0x00AB0520: TBNZ w8, #0, #0xab053c     | if (static_value_037333DA == true) goto label_0;
            // 0x00AB0524: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x00AB0528: LDR x8, [x8, #0x2a0]       | X8 = 0x2B8EBB4;                         
            // 0x00AB052C: LDR w0, [x8]               | W0 = 0x11AD;                            
            // 0x00AB0530: BL #0x2782188              | X0 = sub_2782188( ?? 0x11AD, ????);     
            // 0x00AB0534: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB0538: STRB w8, [x20, #0x3da]     | static_value_037333DA = true;            //  dest_result_addr=57881562
            label_0:
            // 0x00AB053C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB0540: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AB0544: LDR x19, [x19, #0x18]      | X19 = this.m_AssetName; //P2            
            // 0x00AB0548: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB054C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB0550: TBZ w8, #0, #0xab0560      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AB0554: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0558: CBNZ w8, #0xab0560         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AB055C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_2:
            // 0x00AB0560: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00AB0564: LDR x8, [x8, #0xef8]       | X8 = 1152921514947326768;               
            // 0x00AB0568: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AB056C: MOV x1, x19                | X1 = this.m_AssetName;//m1              
            // 0x00AB0570: LDR x2, [x8]               | X2 = public static UnityEngine.Object Mihua.Asset.AssetMgr::GetLoadedAsset<UnityEngine.Object>(string assetName);
            // 0x00AB0574: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB0578: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AB057C: B #0xfd8bec                | return Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
            return Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0580 (11208064), len: 8  VirtAddr: 0x00AB0580 RVA: 0x00AB0580 token: 100693166 methodIndex: 46913 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool Update()
        {
            //
            // Disasemble & Code
            // 0x00AB0580: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00AB0584: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0588 (11208072), len: 8  VirtAddr: 0x00AB0588 RVA: 0x00AB0588 token: 100693167 methodIndex: 46914 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool IsDone()
        {
            //
            // Disasemble & Code
            // 0x00AB0588: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00AB058C: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0590 (11208080), len: 8  VirtAddr: 0x00AB0590 RVA: 0x00AB0590 token: 100693168 methodIndex: 46915 delegateWrapperIndex: 0 methodInvoker: 0
        public override float get_progress()
        {
            //
            // Disasemble & Code
            // 0x00AB0590: FMOV s0, #1.00000000       | S0 = 1;                                 
            // 0x00AB0594: RET                        |  return (System.Single)1;               
            return 1f;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB0598 (11208088), len: 4  VirtAddr: 0x00AB0598 RVA: 0x00AB0598 token: 100693169 methodIndex: 46916 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Clear()
        {
            //
            // Disasemble & Code
            // 0x00AB0598: RET                        |  return;                                
            return;
        
        }
    
    }

}
