using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AnimatedWidget_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000030
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BB89BC (12290492), len: 8  VirtAddr: 0x00BB89BC RVA: 0x00BB89BC token: 100663749 methodIndex: 29794 delegateWrapperIndex: 0 methodInvoker: 0
        public AnimatedWidget_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BB89BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB89C0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB89C4 (12290500), len: 1132  VirtAddr: 0x00BB89C4 RVA: 0x00BB89C4 token: 100663750 methodIndex: 29795 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_10;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_11;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_12;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_13;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_14;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_15;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_16;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_17;
            // 0x00BB89C4: STP x24, x23, [sp, #-0x40]! | stack[1152921510042184784] = ???;  stack[1152921510042184792] = ???;  //  dest_result_addr=1152921510042184784 |  dest_result_addr=1152921510042184792
            // 0x00BB89C8: STP x22, x21, [sp, #0x10]  | stack[1152921510042184800] = ???;  stack[1152921510042184808] = ???;  //  dest_result_addr=1152921510042184800 |  dest_result_addr=1152921510042184808
            // 0x00BB89CC: STP x20, x19, [sp, #0x20]  | stack[1152921510042184816] = ???;  stack[1152921510042184824] = ???;  //  dest_result_addr=1152921510042184816 |  dest_result_addr=1152921510042184824
            // 0x00BB89D0: STP x29, x30, [sp, #0x30]  | stack[1152921510042184832] = ???;  stack[1152921510042184840] = ???;  //  dest_result_addr=1152921510042184832 |  dest_result_addr=1152921510042184840
            // 0x00BB89D4: ADD x29, sp, #0x30         | X29 = (1152921510042184784 + 48) = 1152921510042184832 (0x1000000143F8AC80);
            // 0x00BB89D8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB89DC: LDRB w8, [x20, #0xb53]     | W8 = (bool)static_value_03733B53;       
            // 0x00BB89E0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB89E4: TBNZ w8, #0, #0xbb8a00     | if (static_value_03733B53 == true) goto label_0;
            // 0x00BB89E8: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x00BB89EC: LDR x8, [x8, #0x300]       | X8 = 0x2B8ADA4;                         
            // 0x00BB89F0: LDR w0, [x8]               | W0 = 0x227;                             
            // 0x00BB89F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x227, ????);      
            // 0x00BB89F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB89FC: STRB w8, [x20, #0xb53]     | static_value_03733B53 = true;            //  dest_result_addr=57883475
            label_0:
            // 0x00BB8A00: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB8A04: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB8A08: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BB8A0C: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x00BB8A10: LDR x8, [x8, #0xde8]       | X8 = 1152921504878039040;               
            // 0x00BB8A14: LDR x20, [x8]              | X20 = typeof(AnimatedWidget);           
            // 0x00BB8A18: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB8A1C: TBZ w8, #0, #0xbb8a2c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BB8A20: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB8A24: CBNZ w8, #0xbb8a2c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BB8A28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BB8A2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB8A30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB8A34: MOV x1, x20                | X1 = 1152921504878039040 (0x10000000102A1000);//ML01
            // 0x00BB8A38: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB8A3C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB8A40: CBNZ x20, #0xbb8a48        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BB8A44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00BB8A48: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00BB8A4C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB8A50: LDR x9, [x9, #0x600]       | X9 = (string**)(1152921510042161424)("width");
            // 0x00BB8A54: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB8A58: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB8A5C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB8A60: LDR x1, [x9]               | X1 = "width";                           
            // 0x00BB8A64: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB8A68: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB8A6C: ADRP x24, #0x35b9000       | X24 = 56332288 (0x35B9000);             
            // 0x00BB8A70: LDR x24, [x24, #0x398]     | X24 = 1152921504782778368;              
            // 0x00BB8A74: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB8A78: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8A7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8A80: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache0;
            val_10 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache0;
            // 0x00BB8A84: CBNZ x22, #0xbb8ad0        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_10 != null)
            {
                goto label_4;
            }
            // 0x00BB8A88: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00BB8A8C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB8A90: LDR x8, [x8, #0xdd0]       | X8 = 1152921510042161504;               
            // 0x00BB8A94: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB8A98: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_width_0(ref object o);
            // 0x00BB8A9C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x00BB8AA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB8AA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8AA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8AAC: MOV x2, x22                | X2 = 1152921510042161504 (0x1000000143F85160);//ML01
            // 0x00BB8AB0: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_11 = val_2;
            // 0x00BB8AB4: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_width_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_width_0(ref object o));
            // 0x00BB8AB8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8ABC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8AC0: STR x23, [x8]              | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782782464
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache0 = val_11;
            // 0x00BB8AC4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8AC8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8ACC: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_10 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BB8AD0: CBNZ x19, #0xbb8ad8        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BB8AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_width_0(ref object o)), ????);
            label_5:
            // 0x00BB8AD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8ADC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8AE0: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB8AE4: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB8AE8: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_10);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_10);
            // 0x00BB8AEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8AF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8AF4: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache1;
            val_12 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache1;
            // 0x00BB8AF8: CBNZ x22, #0xbb8b44        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_12 != null)
            {
                goto label_6;
            }
            // 0x00BB8AFC: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x00BB8B00: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB8B04: LDR x8, [x8, #0x3a0]       | X8 = 1152921510042162528;               
            // 0x00BB8B08: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB8B0C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_width_0(ref object o, object v);
            // 0x00BB8B10: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x00BB8B14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB8B18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8B1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8B20: MOV x2, x22                | X2 = 1152921510042162528 (0x1000000143F85560);//ML01
            // 0x00BB8B24: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_11 = val_3;
            // 0x00BB8B28: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_width_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_width_0(ref object o, object v));
            // 0x00BB8B2C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8B30: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8B34: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782782472
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache1 = val_11;
            // 0x00BB8B38: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8B3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8B40: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_12 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache1;
            label_6:
            // 0x00BB8B44: CBNZ x19, #0xbb8b4c        | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x00BB8B48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_width_0(ref object o, object v)), ????);
            label_7:
            // 0x00BB8B4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8B50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8B54: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB8B58: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB8B5C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_12);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_12);
            // 0x00BB8B60: CBNZ x20, #0xbb8b68        | if (val_1 != null) goto label_8;        
            if(val_1 != null)
            {
                goto label_8;
            }
            // 0x00BB8B64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_8:
            // 0x00BB8B68: ADRP x9, #0x35d0000        | X9 = 56426496 (0x35D0000);              
            // 0x00BB8B6C: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB8B70: LDR x9, [x9, #0x3f0]       | X9 = (string**)(1152921510042163552)("height");
            // 0x00BB8B74: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB8B78: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB8B7C: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB8B80: LDR x1, [x9]               | X1 = "height";                          
            // 0x00BB8B84: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB8B88: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB8B8C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8B90: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB8B94: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8B98: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache2;
            val_13 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache2;
            // 0x00BB8B9C: CBNZ x22, #0xbb8be8        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache2 != null) goto label_9;
            if(val_13 != null)
            {
                goto label_9;
            }
            // 0x00BB8BA0: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00BB8BA4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB8BA8: LDR x8, [x8, #0xc0]        | X8 = 1152921510042163632;               
            // 0x00BB8BAC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB8BB0: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_height_1(ref object o);
            // 0x00BB8BB4: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4 = null;
            // 0x00BB8BB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB8BBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8BC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8BC4: MOV x2, x22                | X2 = 1152921510042163632 (0x1000000143F859B0);//ML01
            // 0x00BB8BC8: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_11 = val_4;
            // 0x00BB8BCC: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_height_1(ref object o));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_height_1(ref object o));
            // 0x00BB8BD0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8BD4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8BD8: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782782480
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache2 = val_11;
            // 0x00BB8BDC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8BE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8BE4: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_13 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache2;
            label_9:
            // 0x00BB8BE8: CBNZ x19, #0xbb8bf0        | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x00BB8BEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::get_height_1(ref object o)), ????);
            label_10:
            // 0x00BB8BF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8BF4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8BF8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB8BFC: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB8C00: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_13);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_13);
            // 0x00BB8C04: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8C08: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8C0C: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache3;
            val_14 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache3;
            // 0x00BB8C10: CBNZ x22, #0xbb8c5c        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache3 != null) goto label_11;
            if(val_14 != null)
            {
                goto label_11;
            }
            // 0x00BB8C14: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00BB8C18: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB8C1C: LDR x8, [x8, #0x7c0]       | X8 = 1152921510042164656;               
            // 0x00BB8C20: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB8C24: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_height_1(ref object o, object v);
            // 0x00BB8C28: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_5 = null;
            // 0x00BB8C2C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB8C30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8C34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8C38: MOV x2, x22                | X2 = 1152921510042164656 (0x1000000143F85DB0);//ML01
            // 0x00BB8C3C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_11 = val_5;
            // 0x00BB8C40: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_height_1(ref object o, object v));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_height_1(ref object o, object v));
            // 0x00BB8C44: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8C48: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8C4C: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782782488
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache3 = val_11;
            // 0x00BB8C50: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8C54: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8C58: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_14 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache3;
            label_11:
            // 0x00BB8C5C: CBNZ x19, #0xbb8c64        | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x00BB8C60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedWidget_Binding::set_height_1(ref object o, object v)), ????);
            label_12:
            // 0x00BB8C64: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8C68: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8C6C: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB8C70: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB8C74: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_14);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_14);
            // 0x00BB8C78: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8C7C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8C80: LDR x21, [x8, #0x28]       | X21 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache0;
            val_15 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache0;
            // 0x00BB8C84: CBNZ x21, #0xbb8cd0        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache0 != null) goto label_13;
            if(val_15 != null)
            {
                goto label_13;
            }
            // 0x00BB8C88: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x00BB8C8C: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BB8C90: LDR x8, [x8, #0x190]       | X8 = 1152921510042165680;               
            // 0x00BB8C94: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BB8C98: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__0();
            // 0x00BB8C9C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_6 = null;
            // 0x00BB8CA0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BB8CA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8CA8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8CAC: MOV x2, x21                | X2 = 1152921510042165680 (0x1000000143F861B0);//ML01
            // 0x00BB8CB0: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB8CB4: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__0());
            val_6 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__0());
            // 0x00BB8CB8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8CBC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8CC0: STR x22, [x8, #0x28]       | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504782782504
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache0 = val_6;
            // 0x00BB8CC4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8CC8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8CCC: LDR x21, [x8, #0x28]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_15 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache0;
            label_13:
            // 0x00BB8CD0: CBNZ x19, #0xbb8cd8        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BB8CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__0()), ????);
            label_14:
            // 0x00BB8CD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8CDC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8CE0: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB8CE4: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB8CE8: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_15);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_15);
            // 0x00BB8CEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8CF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8CF4: LDR x21, [x8, #0x30]       | X21 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache1;
            val_16 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache1;
            // 0x00BB8CF8: CBNZ x21, #0xbb8d44        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache1 != null) goto label_15;
            if(val_16 != null)
            {
                goto label_15;
            }
            // 0x00BB8CFC: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x00BB8D00: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BB8D04: LDR x8, [x8, #0xc68]       | X8 = 1152921510042166704;               
            // 0x00BB8D08: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BB8D0C: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__1(int s);
            // 0x00BB8D10: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_7 = null;
            // 0x00BB8D14: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BB8D18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8D1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8D20: MOV x2, x21                | X2 = 1152921510042166704 (0x1000000143F865B0);//ML01
            // 0x00BB8D24: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB8D28: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__1(int s));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__1(int s));
            // 0x00BB8D2C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8D30: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8D34: STR x22, [x8, #0x30]       | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504782782512
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache1 = val_7;
            // 0x00BB8D38: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8D3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8D40: LDR x21, [x8, #0x30]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_16 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__am$cache1;
            label_15:
            // 0x00BB8D44: CBNZ x19, #0xbb8d4c        | if (X1 != 0) goto label_16;             
            if(X1 != 0)
            {
                goto label_16;
            }
            // 0x00BB8D48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedWidget_Binding::<Register>m__1(int s)), ????);
            label_16:
            // 0x00BB8D4C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8D50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8D54: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB8D58: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB8D5C: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_16);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_16);
            // 0x00BB8D60: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BB8D64: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00BB8D68: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x00BB8D6C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB8D70: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB8D74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8D78: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB8D7C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB8D80: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB8D84: CBNZ x20, #0xbb8d8c        | if (val_1 != null) goto label_17;       
            if(val_1 != null)
            {
                goto label_17;
            }
            // 0x00BB8D88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_17:
            // 0x00BB8D8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB8D90: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB8D94: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BB8D98: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB8D9C: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB8DA0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB8DA4: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_8 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB8DA8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8DAC: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00BB8DB0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8DB4: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache4;
            val_17 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache4;
            // 0x00BB8DB8: CBNZ x21, #0xbb8e04        | if (ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache4 != null) goto label_18;
            if(val_17 != null)
            {
                goto label_18;
            }
            // 0x00BB8DBC: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x00BB8DC0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB8DC4: LDR x8, [x8, #0x920]       | X8 = 1152921510042171824;               
            // 0x00BB8DC8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB8DCC: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedWidget_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB8DD0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_9 = null;
            // 0x00BB8DD4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB8DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8DDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8DE0: MOV x2, x21                | X2 = 1152921510042171824 (0x1000000143F879B0);//ML01
            // 0x00BB8DE4: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB8DE8: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedWidget_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedWidget_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB8DEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8DF0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8DF4: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782782496
            ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache4 = val_9;
            // 0x00BB8DF8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedWidget_Binding);
            // 0x00BB8DFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8E00: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_17 = ILRuntime.Runtime.Generated.AnimatedWidget_Binding.<>f__mg$cache4;
            label_18:
            // 0x00BB8E04: CBNZ x19, #0xbb8e0c        | if (X1 != 0) goto label_19;             
            if(X1 != 0)
            {
                goto label_19;
            }
            // 0x00BB8E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedWidget_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_19:
            // 0x00BB8E0C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8E10: MOV x1, x20                | X1 = val_8;//m1                         
            // 0x00BB8E14: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB8E18: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8E1C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB8E20: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB8E24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8E28: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB8E2C: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_8, func:  val_17); return;
            X1.RegisterCLRMethodRedirection(mi:  val_8, func:  val_17);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8E30 (12291632), len: 312  VirtAddr: 0x00BB8E30 RVA: 0x00BB8E30 token: 100663751 methodIndex: 29796 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_width_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB8E30: STP x20, x19, [sp, #-0x20]! | stack[1152921510042317216] = ???;  stack[1152921510042317224] = ???;  //  dest_result_addr=1152921510042317216 |  dest_result_addr=1152921510042317224
            // 0x00BB8E34: STP x29, x30, [sp, #0x10]  | stack[1152921510042317232] = ???;  stack[1152921510042317240] = ???;  //  dest_result_addr=1152921510042317232 |  dest_result_addr=1152921510042317240
            // 0x00BB8E38: ADD x29, sp, #0x10         | X29 = (1152921510042317216 + 16) = 1152921510042317232 (0x1000000143FAB1B0);
            // 0x00BB8E3C: SUB sp, sp, #0x20          | SP = (1152921510042317216 - 32) = 1152921510042317184 (0x1000000143FAB180);
            // 0x00BB8E40: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB8E44: LDRB w8, [x20, #0xb54]     | W8 = (bool)static_value_03733B54;       
            // 0x00BB8E48: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB8E4C: TBNZ w8, #0, #0xbb8e68     | if (static_value_03733B54 == true) goto label_0;
            // 0x00BB8E50: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00BB8E54: LDR x8, [x8, #0x4e8]       | X8 = 0x2B8ADA0;                         
            // 0x00BB8E58: LDR w0, [x8]               | W0 = 0x226;                             
            // 0x00BB8E5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x226, ????);      
            // 0x00BB8E60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB8E64: STRB w8, [x20, #0xb54]     | static_value_03733B54 = true;            //  dest_result_addr=57883476
            label_0:
            // 0x00BB8E68: ADRP x20, #0x3614000       | X20 = 56705024 (0x3614000);             
            // 0x00BB8E6C: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB8E70: LDR x20, [x20, #0xbd0]     | X20 = 1152921504878039040;              
            // 0x00BB8E74: CBZ x19, #0xbb8ec8         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB8E78: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB8E7C: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB8E80: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB8E84: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB8E88: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB8E8C: B.LO #0xbb8ea4             | if (X1 + 260 < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB8E90: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB8E94: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB8E98: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB8E9C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB8EA0: B.EQ #0xbb8ecc             | if ((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB8EA4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB8EA8: ADD x8, sp, #0x10          | X8 = (1152921510042317184 + 16) = 1152921510042317200 (0x1000000143FAB190);
            // 0x00BB8EAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB8EB0: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510042305248]
            // 0x00BB8EB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB8EB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8EBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB8EC0: ADD x0, sp, #0x10          | X0 = (1152921510042317184 + 16) = 1152921510042317200 (0x1000000143FAB190);
            // 0x00BB8EC4: BL #0x299a140              | 
            label_1:
            // 0x00BB8EC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143FAB190, ????);
            label_3:
            // 0x00BB8ECC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB8ED0: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB8ED4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB8ED8: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB8EDC: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB8EE0: B.LO #0xbb8f24             | if (X1 + 260 < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB8EE4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB8EE8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB8EEC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB8EF0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB8EF4: B.NE #0xbb8f24             | if ((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB8EF8: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB8EFC: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x00BB8F00: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB8F04: ADD x1, sp, #0xc           | X1 = (1152921510042317184 + 12) = 1152921510042317196 (0x1000000143FAB18C);
            // 0x00BB8F08: STR w8, [sp, #0xc]         | stack[1152921510042317196] = X1 + 24;    //  dest_result_addr=1152921510042317196
            // 0x00BB8F0C: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB8F10: BL #0x27bc028              | X0 = 1152921510042365264 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 24);
            // 0x00BB8F14: SUB sp, x29, #0x10         | SP = (1152921510042317232 - 16) = 1152921510042317216 (0x1000000143FAB1A0);
            // 0x00BB8F18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8F1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB8F20: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB8F24: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB8F28: ADD x8, sp, #0x18          | X8 = (1152921510042317184 + 24) = 1152921510042317208 (0x1000000143FAB198);
            // 0x00BB8F2C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB8F30: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510042305248]
            // 0x00BB8F34: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB8F38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8F3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB8F40: ADD x0, sp, #0x18          | X0 = (1152921510042317184 + 24) = 1152921510042317208 (0x1000000143FAB198);
            // 0x00BB8F44: BL #0x299a140              | 
            // 0x00BB8F48: MOV x19, x0                | X19 = 1152921510042317208 (0x1000000143FAB198);//ML01
            // 0x00BB8F4C: ADD x0, sp, #0x10          | X0 = (1152921510042317184 + 16) = 1152921510042317200 (0x1000000143FAB190);
            label_6:
            // 0x00BB8F50: BL #0x299a140              | 
            // 0x00BB8F54: MOV x0, x19                | X0 = 1152921510042317208 (0x1000000143FAB198);//ML01
            // 0x00BB8F58: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143FAB198, ????);
            // 0x00BB8F5C: MOV x19, x0                | X19 = 1152921510042317208 (0x1000000143FAB198);//ML01
            // 0x00BB8F60: ADD x0, sp, #0x18          | X0 = (1152921510042317184 + 24) = 1152921510042317208 (0x1000000143FAB198);
            // 0x00BB8F64: B #0xbb8f50                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8F68 (12291944), len: 412  VirtAddr: 0x00BB8F68 RVA: 0x00BB8F68 token: 100663752 methodIndex: 29797 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_width_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB8F68: STP x22, x21, [sp, #-0x30]! | stack[1152921510042445424] = ???;  stack[1152921510042445432] = ???;  //  dest_result_addr=1152921510042445424 |  dest_result_addr=1152921510042445432
            // 0x00BB8F6C: STP x20, x19, [sp, #0x10]  | stack[1152921510042445440] = ???;  stack[1152921510042445448] = ???;  //  dest_result_addr=1152921510042445440 |  dest_result_addr=1152921510042445448
            // 0x00BB8F70: STP x29, x30, [sp, #0x20]  | stack[1152921510042445456] = ???;  stack[1152921510042445464] = ???;  //  dest_result_addr=1152921510042445456 |  dest_result_addr=1152921510042445464
            // 0x00BB8F74: ADD x29, sp, #0x20         | X29 = (1152921510042445424 + 32) = 1152921510042445456 (0x1000000143FCA690);
            // 0x00BB8F78: SUB sp, sp, #0x20          | SP = (1152921510042445424 - 32) = 1152921510042445392 (0x1000000143FCA650);
            // 0x00BB8F7C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB8F80: LDRB w8, [x21, #0xb55]     | W8 = (bool)static_value_03733B55;       
            // 0x00BB8F84: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB8F88: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB8F8C: TBNZ w8, #0, #0xbb8fa8     | if (static_value_03733B55 == true) goto label_0;
            // 0x00BB8F90: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x00BB8F94: LDR x8, [x8, #0xa50]       | X8 = 0x2B8ADAC;                         
            // 0x00BB8F98: LDR w0, [x8]               | W0 = 0x229;                             
            // 0x00BB8F9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x229, ????);      
            // 0x00BB8FA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB8FA4: STRB w8, [x21, #0xb55]     | static_value_03733B55 = true;            //  dest_result_addr=57883477
            label_0:
            // 0x00BB8FA8: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB8FAC: CBZ x21, #0xbb9060         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB8FB0: ADRP x20, #0x3614000       | X20 = 56705024 (0x3614000);             
            // 0x00BB8FB4: LDR x20, [x20, #0xbd0]     | X20 = 1152921504878039040;              
            // 0x00BB8FB8: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB8FBC: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB8FC0: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB8FC4: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB8FC8: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB8FCC: B.LO #0xbb8fe4             | if (mem[null + 260] < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB8FD0: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB8FD4: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB8FD8: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB8FDC: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB8FE0: B.EQ #0xbb900c             | if ((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB8FE4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB8FE8: ADD x8, sp, #8             | X8 = (1152921510042445392 + 8) = 1152921510042445400 (0x1000000143FCA658);
            // 0x00BB8FEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB8FF0: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510042433472]
            // 0x00BB8FF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB8FF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8FFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB9000: ADD x0, sp, #8             | X0 = (1152921510042445392 + 8) = 1152921510042445400 (0x1000000143FCA658);
            // 0x00BB9004: BL #0x299a140              | 
            // 0x00BB9008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143FCA658, ????);
            label_3:
            // 0x00BB900C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9010: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB9014: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB9018: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB901C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB9020: B.LO #0xbb9038             | if (mem[null + 260] < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB9024: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB9028: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB902C: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB9030: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB9034: B.EQ #0xbb9068             | if ((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB9038: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB903C: ADD x8, sp, #0x10          | X8 = (1152921510042445392 + 16) = 1152921510042445408 (0x1000000143FCA660);
            // 0x00BB9040: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB9044: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510042433472]
            // 0x00BB9048: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB904C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9050: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB9054: ADD x0, sp, #0x10          | X0 = (1152921510042445392 + 16) = 1152921510042445408 (0x1000000143FCA660);
            // 0x00BB9058: BL #0x299a140              | 
            // 0x00BB905C: B #0xbb9064                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB9060: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229, ????);      
            label_6:
            // 0x00BB9064: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB9068: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB906C: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB9070: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB9074: CBNZ x19, #0xbb907c        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB9078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x229, ????);      
            label_7:
            // 0x00BB907C: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB9080: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB9084: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB9088: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB908C: B.NE #0xbb90d4             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB9090: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB9094: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB9098: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB909C: STR w8, [x21, #0x18]       | mem[24] = X2;                            //  dest_result_addr=24
            mem[24] = X2;
            // 0x00BB90A0: SUB sp, x29, #0x20         | SP = (1152921510042445456 - 32) = 1152921510042445424 (0x1000000143FCA670);
            // 0x00BB90A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB90A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB90AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB90B0: RET                        |  return;                                
            return;
            // 0x00BB90B4: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB90B8: ADD x0, sp, #8             | X0 = (1152921510042445472 + 8) = 1152921510042445480 (0x1000000143FCA6A8);
            // 0x00BB90BC: B #0xbb90c8                |  goto label_10;                         
            goto label_10;
            // 0x00BB90C0: MOV x19, x0                | X19 = 1152921510042445480 (0x1000000143FCA6A8);//ML01
            val_7;
            // 0x00BB90C4: ADD x0, sp, #0x10          | X0 = (1152921510042445472 + 16) = 1152921510042445488 (0x1000000143FCA6B0);
            label_10:
            // 0x00BB90C8: BL #0x299a140              | 
            // 0x00BB90CC: MOV x0, x19                | X0 = 1152921510042445480 (0x1000000143FCA6A8);//ML01
            // 0x00BB90D0: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143FCA6A8, ????);
            label_8:
            // 0x00BB90D4: ADD x8, sp, #0x18          | X8 = (1152921510042445472 + 24) = 1152921510042445496 (0x1000000143FCA6B8);
            // 0x00BB90D8: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB90DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143FCA6A8, ????);
            // 0x00BB90E0: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510042433472]
            // 0x00BB90E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB90E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB90EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB90F0: ADD x0, sp, #0x18          | X0 = (1152921510042445472 + 24) = 1152921510042445496 (0x1000000143FCA6B8);
            // 0x00BB90F4: BL #0x299a140              | 
            // 0x00BB90F8: MOV x19, x0                | X19 = 1152921510042445496 (0x1000000143FCA6B8);//ML01
            // 0x00BB90FC: ADD x0, sp, #0x18          | X0 = (1152921510042445472 + 24) = 1152921510042445496 (0x1000000143FCA6B8);
            // 0x00BB9100: B #0xbb90c8                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB9104 (12292356), len: 312  VirtAddr: 0x00BB9104 RVA: 0x00BB9104 token: 100663753 methodIndex: 29798 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_height_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB9104: STP x20, x19, [sp, #-0x20]! | stack[1152921510042573664] = ???;  stack[1152921510042573672] = ???;  //  dest_result_addr=1152921510042573664 |  dest_result_addr=1152921510042573672
            // 0x00BB9108: STP x29, x30, [sp, #0x10]  | stack[1152921510042573680] = ???;  stack[1152921510042573688] = ???;  //  dest_result_addr=1152921510042573680 |  dest_result_addr=1152921510042573688
            // 0x00BB910C: ADD x29, sp, #0x10         | X29 = (1152921510042573664 + 16) = 1152921510042573680 (0x1000000143FE9B70);
            // 0x00BB9110: SUB sp, sp, #0x20          | SP = (1152921510042573664 - 32) = 1152921510042573632 (0x1000000143FE9B40);
            // 0x00BB9114: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB9118: LDRB w8, [x20, #0xb56]     | W8 = (bool)static_value_03733B56;       
            // 0x00BB911C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB9120: TBNZ w8, #0, #0xbb913c     | if (static_value_03733B56 == true) goto label_0;
            // 0x00BB9124: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00BB9128: LDR x8, [x8, #0x7a8]       | X8 = 0x2B8AD9C;                         
            // 0x00BB912C: LDR w0, [x8]               | W0 = 0x225;                             
            // 0x00BB9130: BL #0x2782188              | X0 = sub_2782188( ?? 0x225, ????);      
            // 0x00BB9134: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB9138: STRB w8, [x20, #0xb56]     | static_value_03733B56 = true;            //  dest_result_addr=57883478
            label_0:
            // 0x00BB913C: ADRP x20, #0x3614000       | X20 = 56705024 (0x3614000);             
            // 0x00BB9140: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB9144: LDR x20, [x20, #0xbd0]     | X20 = 1152921504878039040;              
            // 0x00BB9148: CBZ x19, #0xbb919c         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB914C: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB9150: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB9154: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB9158: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB915C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB9160: B.LO #0xbb9178             | if (X1 + 260 < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB9164: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB9168: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB916C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB9170: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB9174: B.EQ #0xbb91a0             | if ((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB9178: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB917C: ADD x8, sp, #0x10          | X8 = (1152921510042573632 + 16) = 1152921510042573648 (0x1000000143FE9B50);
            // 0x00BB9180: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB9184: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510042561696]
            // 0x00BB9188: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB918C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9190: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB9194: ADD x0, sp, #0x10          | X0 = (1152921510042573632 + 16) = 1152921510042573648 (0x1000000143FE9B50);
            // 0x00BB9198: BL #0x299a140              | 
            label_1:
            // 0x00BB919C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143FE9B50, ????);
            label_3:
            // 0x00BB91A0: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB91A4: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB91A8: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB91AC: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB91B0: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB91B4: B.LO #0xbb91f8             | if (X1 + 260 < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB91B8: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB91BC: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB91C0: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB91C4: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB91C8: B.NE #0xbb91f8             | if ((X1 + 176 + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB91CC: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
            // 0x00BB91D0: LDR w8, [x19, #0x1c]       | W8 = X1 + 28;                           
            // 0x00BB91D4: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
            // 0x00BB91D8: ADD x1, sp, #0xc           | X1 = (1152921510042573632 + 12) = 1152921510042573644 (0x1000000143FE9B4C);
            // 0x00BB91DC: STR w8, [sp, #0xc]         | stack[1152921510042573644] = X1 + 28;    //  dest_result_addr=1152921510042573644
            // 0x00BB91E0: LDR x0, [x9]               | X0 = typeof(System.Single);             
            // 0x00BB91E4: BL #0x27bc028              | X0 = 1152921510042621712 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), X1 + 28);
            // 0x00BB91E8: SUB sp, x29, #0x10         | SP = (1152921510042573680 - 16) = 1152921510042573664 (0x1000000143FE9B60);
            // 0x00BB91EC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB91F0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB91F4: RET                        |  return (System.Object)X1 + 28;         
            return (object)X1 + 28;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB91F8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB91FC: ADD x8, sp, #0x18          | X8 = (1152921510042573632 + 24) = 1152921510042573656 (0x1000000143FE9B58);
            // 0x00BB9200: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB9204: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510042561696]
            // 0x00BB9208: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB920C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9210: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB9214: ADD x0, sp, #0x18          | X0 = (1152921510042573632 + 24) = 1152921510042573656 (0x1000000143FE9B58);
            // 0x00BB9218: BL #0x299a140              | 
            // 0x00BB921C: MOV x19, x0                | X19 = 1152921510042573656 (0x1000000143FE9B58);//ML01
            // 0x00BB9220: ADD x0, sp, #0x10          | X0 = (1152921510042573632 + 16) = 1152921510042573648 (0x1000000143FE9B50);
            label_6:
            // 0x00BB9224: BL #0x299a140              | 
            // 0x00BB9228: MOV x0, x19                | X0 = 1152921510042573656 (0x1000000143FE9B58);//ML01
            // 0x00BB922C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143FE9B58, ????);
            // 0x00BB9230: MOV x19, x0                | X19 = 1152921510042573656 (0x1000000143FE9B58);//ML01
            // 0x00BB9234: ADD x0, sp, #0x18          | X0 = (1152921510042573632 + 24) = 1152921510042573656 (0x1000000143FE9B58);
            // 0x00BB9238: B #0xbb9224                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB923C (12292668), len: 412  VirtAddr: 0x00BB923C RVA: 0x00BB923C token: 100663754 methodIndex: 29799 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_height_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB923C: STP x22, x21, [sp, #-0x30]! | stack[1152921510042701872] = ???;  stack[1152921510042701880] = ???;  //  dest_result_addr=1152921510042701872 |  dest_result_addr=1152921510042701880
            // 0x00BB9240: STP x20, x19, [sp, #0x10]  | stack[1152921510042701888] = ???;  stack[1152921510042701896] = ???;  //  dest_result_addr=1152921510042701888 |  dest_result_addr=1152921510042701896
            // 0x00BB9244: STP x29, x30, [sp, #0x20]  | stack[1152921510042701904] = ???;  stack[1152921510042701912] = ???;  //  dest_result_addr=1152921510042701904 |  dest_result_addr=1152921510042701912
            // 0x00BB9248: ADD x29, sp, #0x20         | X29 = (1152921510042701872 + 32) = 1152921510042701904 (0x1000000144009050);
            // 0x00BB924C: SUB sp, sp, #0x20          | SP = (1152921510042701872 - 32) = 1152921510042701840 (0x1000000144009010);
            // 0x00BB9250: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB9254: LDRB w8, [x21, #0xb57]     | W8 = (bool)static_value_03733B57;       
            // 0x00BB9258: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB925C: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB9260: TBNZ w8, #0, #0xbb927c     | if (static_value_03733B57 == true) goto label_0;
            // 0x00BB9264: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00BB9268: LDR x8, [x8, #0x170]       | X8 = 0x2B8ADA8;                         
            // 0x00BB926C: LDR w0, [x8]               | W0 = 0x228;                             
            // 0x00BB9270: BL #0x2782188              | X0 = sub_2782188( ?? 0x228, ????);      
            // 0x00BB9274: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB9278: STRB w8, [x21, #0xb57]     | static_value_03733B57 = true;            //  dest_result_addr=57883479
            label_0:
            // 0x00BB927C: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB9280: CBZ x21, #0xbb9334         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB9284: ADRP x20, #0x3614000       | X20 = 56705024 (0x3614000);             
            // 0x00BB9288: LDR x20, [x20, #0xbd0]     | X20 = 1152921504878039040;              
            // 0x00BB928C: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB9290: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB9294: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB9298: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB929C: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB92A0: B.LO #0xbb92b8             | if (mem[null + 260] < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB92A4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB92A8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB92AC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB92B0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB92B4: B.EQ #0xbb92e0             | if ((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB92B8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB92BC: ADD x8, sp, #8             | X8 = (1152921510042701840 + 8) = 1152921510042701848 (0x1000000144009018);
            // 0x00BB92C0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB92C4: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510042689920]
            // 0x00BB92C8: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB92CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB92D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB92D4: ADD x0, sp, #8             | X0 = (1152921510042701840 + 8) = 1152921510042701848 (0x1000000144009018);
            // 0x00BB92D8: BL #0x299a140              | 
            // 0x00BB92DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144009018, ????);
            label_3:
            // 0x00BB92E0: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB92E4: LDR x1, [x20]              | X1 = typeof(AnimatedWidget);            
            // 0x00BB92E8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB92EC: LDRB w9, [x1, #0x104]      | W9 = AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB92F0: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB92F4: B.LO #0xbb930c             | if (mem[null + 260] < AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB92F8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB92FC: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB9300: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB9304: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedWidget))
            // 0x00BB9308: B.EQ #0xbb933c             | if ((mem[null + 176] + (AnimatedWidget.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB930C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB9310: ADD x8, sp, #0x10          | X8 = (1152921510042701840 + 16) = 1152921510042701856 (0x1000000144009020);
            // 0x00BB9314: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB9318: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510042689920]
            // 0x00BB931C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB9320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9324: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB9328: ADD x0, sp, #0x10          | X0 = (1152921510042701840 + 16) = 1152921510042701856 (0x1000000144009020);
            // 0x00BB932C: BL #0x299a140              | 
            // 0x00BB9330: B #0xbb9338                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB9334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x228, ????);      
            label_6:
            // 0x00BB9338: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB933C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00BB9340: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
            // 0x00BB9344: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x00BB9348: CBNZ x19, #0xbb9350        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB934C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x228, ????);      
            label_7:
            // 0x00BB9350: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB9354: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB9358: LDR x8, [x20, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
            // 0x00BB935C: CMP x0, x8                 | STATE = COMPARE(X2 + 48, System.Single.__il2cppRuntimeField_element_class)
            // 0x00BB9360: B.NE #0xbb93a8             | if (X2 + 48 != System.Single.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB9364: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB9368: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB936C: LDR w8, [x0]               | W8 = X2;                                
            // 0x00BB9370: STR w8, [x21, #0x1c]       | mem[28] = X2;                            //  dest_result_addr=28
            mem[28] = X2;
            // 0x00BB9374: SUB sp, x29, #0x20         | SP = (1152921510042701904 - 32) = 1152921510042701872 (0x1000000144009030);
            // 0x00BB9378: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB937C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB9380: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB9384: RET                        |  return;                                
            return;
            // 0x00BB9388: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB938C: ADD x0, sp, #8             | X0 = (1152921510042701920 + 8) = 1152921510042701928 (0x1000000144009068);
            // 0x00BB9390: B #0xbb939c                |  goto label_10;                         
            goto label_10;
            // 0x00BB9394: MOV x19, x0                | X19 = 1152921510042701928 (0x1000000144009068);//ML01
            val_7;
            // 0x00BB9398: ADD x0, sp, #0x10          | X0 = (1152921510042701920 + 16) = 1152921510042701936 (0x1000000144009070);
            label_10:
            // 0x00BB939C: BL #0x299a140              | 
            // 0x00BB93A0: MOV x0, x19                | X0 = 1152921510042701928 (0x1000000144009068);//ML01
            // 0x00BB93A4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144009068, ????);
            label_8:
            // 0x00BB93A8: ADD x8, sp, #0x18          | X8 = (1152921510042701920 + 24) = 1152921510042701944 (0x1000000144009078);
            // 0x00BB93AC: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB93B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000144009068, ????);
            // 0x00BB93B4: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510042689920]
            // 0x00BB93B8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB93BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB93C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB93C4: ADD x0, sp, #0x18          | X0 = (1152921510042701920 + 24) = 1152921510042701944 (0x1000000144009078);
            // 0x00BB93C8: BL #0x299a140              | 
            // 0x00BB93CC: MOV x19, x0                | X19 = 1152921510042701944 (0x1000000144009078);//ML01
            // 0x00BB93D0: ADD x0, sp, #0x18          | X0 = (1152921510042701920 + 24) = 1152921510042701944 (0x1000000144009078);
            // 0x00BB93D4: B #0xbb939c                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB93D8 (12293080), len: 180  VirtAddr: 0x00BB93D8 RVA: 0x00BB93D8 token: 100663755 methodIndex: 29800 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BB93D8: STP x22, x21, [sp, #-0x30]! | stack[1152921510042838368] = ???;  stack[1152921510042838376] = ???;  //  dest_result_addr=1152921510042838368 |  dest_result_addr=1152921510042838376
            // 0x00BB93DC: STP x20, x19, [sp, #0x10]  | stack[1152921510042838384] = ???;  stack[1152921510042838392] = ???;  //  dest_result_addr=1152921510042838384 |  dest_result_addr=1152921510042838392
            // 0x00BB93E0: STP x29, x30, [sp, #0x20]  | stack[1152921510042838400] = ???;  stack[1152921510042838408] = ???;  //  dest_result_addr=1152921510042838400 |  dest_result_addr=1152921510042838408
            // 0x00BB93E4: ADD x29, sp, #0x20         | X29 = (1152921510042838368 + 32) = 1152921510042838400 (0x100000014402A580);
            // 0x00BB93E8: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BB93EC: LDRB w8, [x22, #0xb58]     | W8 = (bool)static_value_03733B58;       
            // 0x00BB93F0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BB93F4: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BB93F8: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BB93FC: TBNZ w8, #0, #0xbb9418     | if (static_value_03733B58 == true) goto label_0;
            // 0x00BB9400: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00BB9404: LDR x8, [x8, #0x890]       | X8 = 0x2B8AD98;                         
            // 0x00BB9408: LDR w0, [x8]               | W0 = 0x224;                             
            // 0x00BB940C: BL #0x2782188              | X0 = sub_2782188( ?? 0x224, ????);      
            // 0x00BB9410: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB9414: STRB w8, [x22, #0xb58]     | static_value_03733B58 = true;            //  dest_result_addr=57883480
            label_0:
            // 0x00BB9418: CBNZ x21, #0xbb9420        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB941C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224, ????);      
            label_1:
            // 0x00BB9420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB9424: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BB9428: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB942C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9430: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BB9434: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BB9438: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB943C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BB9440: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00BB9444: LDR x8, [x8, #0xbd0]       | X8 = 1152921504878039040;               
            // 0x00BB9448: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB944C: LDR x8, [x8]               | X8 = typeof(AnimatedWidget);            
            // 0x00BB9450: MOV x0, x8                 | X0 = 1152921504878039040 (0x10000000102A1000);//ML01
            AnimatedWidget val_3 = null;
            // 0x00BB9454: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnimatedWidget), ????);
            // 0x00BB9458: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB945C: MOV x21, x0                | X21 = 1152921504878039040 (0x10000000102A1000);//ML01
            // 0x00BB9460: BL #0xb27548               | .ctor();                                
            val_3 = new AnimatedWidget();
            // 0x00BB9464: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BB9468: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BB946C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB9470: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB9474: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB9478: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BB947C: MOV x3, x21                | X3 = 1152921504878039040 (0x10000000102A1000);//ML01
            // 0x00BB9480: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB9484: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB9488: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB948C (12293260), len: 92  VirtAddr: 0x00BB948C RVA: 0x00BB948C token: 100663756 methodIndex: 29801 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BB948C: STP x20, x19, [sp, #-0x20]! | stack[1152921510042966768] = ???;  stack[1152921510042966776] = ???;  //  dest_result_addr=1152921510042966768 |  dest_result_addr=1152921510042966776
            // 0x00BB9490: STP x29, x30, [sp, #0x10]  | stack[1152921510042966784] = ???;  stack[1152921510042966792] = ???;  //  dest_result_addr=1152921510042966784 |  dest_result_addr=1152921510042966792
            // 0x00BB9494: ADD x29, sp, #0x10         | X29 = (1152921510042966768 + 16) = 1152921510042966784 (0x1000000144049B00);
            // 0x00BB9498: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB949C: LDRB w8, [x19, #0xb59]     | W8 = (bool)static_value_03733B59;       
            // 0x00BB94A0: TBNZ w8, #0, #0xbb94bc     | if (static_value_03733B59 == true) goto label_0;
            // 0x00BB94A4: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00BB94A8: LDR x8, [x8, #0x58]        | X8 = 0x2B8ADB0;                         
            // 0x00BB94AC: LDR w0, [x8]               | W0 = 0x22A;                             
            // 0x00BB94B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x22A, ????);      
            // 0x00BB94B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB94B8: STRB w8, [x19, #0xb59]     | static_value_03733B59 = true;            //  dest_result_addr=57883481
            label_0:
            // 0x00BB94BC: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x00BB94C0: LDR x8, [x8, #0xbd0]       | X8 = 1152921504878039040;               
            // 0x00BB94C4: LDR x0, [x8]               | X0 = typeof(AnimatedWidget);            
            AnimatedWidget val_1 = null;
            // 0x00BB94C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnimatedWidget), ????);
            // 0x00BB94CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB94D0: MOV x19, x0                | X19 = 1152921504878039040 (0x10000000102A1000);//ML01
            // 0x00BB94D4: BL #0xb27548               | .ctor();                                
            val_1 = new AnimatedWidget();
            // 0x00BB94D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB94DC: MOV x0, x19                | X0 = 1152921504878039040 (0x10000000102A1000);//ML01
            // 0x00BB94E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB94E4: RET                        |  return (System.Object)typeof(AnimatedWidget);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB94E8 (12293352), len: 92  VirtAddr: 0x00BB94E8 RVA: 0x00BB94E8 token: 100663757 methodIndex: 29802 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BB94E8: STP x20, x19, [sp, #-0x20]! | stack[1152921510043082864] = ???;  stack[1152921510043082872] = ???;  //  dest_result_addr=1152921510043082864 |  dest_result_addr=1152921510043082872
            // 0x00BB94EC: STP x29, x30, [sp, #0x10]  | stack[1152921510043082880] = ???;  stack[1152921510043082888] = ???;  //  dest_result_addr=1152921510043082880 |  dest_result_addr=1152921510043082888
            // 0x00BB94F0: ADD x29, sp, #0x10         | X29 = (1152921510043082864 + 16) = 1152921510043082880 (0x1000000144066080);
            // 0x00BB94F4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB94F8: LDRB w8, [x20, #0xb5a]     | W8 = (bool)static_value_03733B5A;       
            // 0x00BB94FC: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BB9500: TBNZ w8, #0, #0xbb951c     | if (static_value_03733B5A == true) goto label_0;
            // 0x00BB9504: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x00BB9508: LDR x8, [x8, #0x7a0]       | X8 = 0x2B8ADB4;                         
            // 0x00BB950C: LDR w0, [x8]               | W0 = 0x22B;                             
            // 0x00BB9510: BL #0x2782188              | X0 = sub_2782188( ?? 0x22B, ????);      
            // 0x00BB9514: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB9518: STRB w8, [x20, #0xb5a]     | static_value_03733B5A = true;            //  dest_result_addr=57883482
            label_0:
            // 0x00BB951C: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00BB9520: LDR x8, [x8, #0x250]       | X8 = 1152921510043066800;               
            // 0x00BB9524: LDR x20, [x8]              | X20 = typeof(AnimatedWidget[]);         
            // 0x00BB9528: MOV x0, x20                | X0 = 1152921510043066800 (0x10000001440621B0);//ML01
            // 0x00BB952C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(AnimatedWidget[]), ????);
            // 0x00BB9530: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB9534: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BB9538: MOV x0, x20                | X0 = 1152921510043066800 (0x10000001440621B0);//ML01
            // 0x00BB953C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB9540: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(AnimatedWidget[]), ????);
        
        }
    
    }

}
