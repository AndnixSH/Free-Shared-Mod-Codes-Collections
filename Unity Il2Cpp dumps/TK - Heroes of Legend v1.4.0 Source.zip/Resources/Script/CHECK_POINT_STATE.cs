using UnityEngine;
public enum CHECK_POINT_STATE
{
    // Fields
    CPS_UNLOCK = 0
    ,CPS_LOCK = 1
    ,CPS_FINISH = 2
    

}
