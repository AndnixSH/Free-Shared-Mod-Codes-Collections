using UnityEngine;
public class Blood : MonoBehaviour
{
    // Fields
    public bool isHide; //  0x00000018
    public UnityEngine.Transform targetTf; //  0x00000020
    private UnityEngine.Transform mTf; //  0x00000028
    private static UnityEngine.Vector3 offset; // static_offset: 0x00000000
    private bool isvisible; //  0x00000030
    private UISprite hp_sp; //  0x00000038
    private UISprite dutytype_sp; //  0x00000040
    private float fiveSecond; //  0x00000048
    private UnityEngine.Transform Obj_HP; //  0x00000050
    private UnityEngine.Transform focusTr; //  0x00000058
    
    // Properties
    public bool visible { set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B909B0 (12126640), len: 16  VirtAddr: 0x00B909B0 RVA: 0x00B909B0 token: 100696383 methodIndex: 25147 delegateWrapperIndex: 0 methodInvoker: 0
    public Blood()
    {
        //
        // Disasemble & Code
        // 0x00B909B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B909B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B909B8: STRB w8, [x0, #0x30]       | this.isvisible = true;                   //  dest_result_addr=1152921515523198144
        this.isvisible = true;
        // 0x00B909BC: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B909C0 (12126656), len: 320  VirtAddr: 0x00B909C0 RVA: 0x00B909C0 token: 100696384 methodIndex: 25148 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        // 0x00B909C0: STP x22, x21, [sp, #-0x30]! | stack[1152921515523339312] = ???;  stack[1152921515523339320] = ???;  //  dest_result_addr=1152921515523339312 |  dest_result_addr=1152921515523339320
        // 0x00B909C4: STP x20, x19, [sp, #0x10]  | stack[1152921515523339328] = ???;  stack[1152921515523339336] = ???;  //  dest_result_addr=1152921515523339328 |  dest_result_addr=1152921515523339336
        // 0x00B909C8: STP x29, x30, [sp, #0x20]  | stack[1152921515523339344] = ???;  stack[1152921515523339352] = ???;  //  dest_result_addr=1152921515523339344 |  dest_result_addr=1152921515523339352
        // 0x00B909CC: ADD x29, sp, #0x20         | X29 = (1152921515523339312 + 32) = 1152921515523339344 (0x100000028AAC7450);
        // 0x00B909D0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B909D4: LDRB w8, [x20, #0xa37]     | W8 = (bool)static_value_03733A37;       
        // 0x00B909D8: MOV x19, x0                | X19 = 1152921515523351360 (0x100000028AACA340);//ML01
        // 0x00B909DC: TBNZ w8, #0, #0xb909f8     | if (static_value_03733A37 == true) goto label_0;
        // 0x00B909E0: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00B909E4: LDR x8, [x8, #0x220]       | X8 = 0x2B8F660;                         
        // 0x00B909E8: LDR w0, [x8]               | W0 = 0x145C;                            
        // 0x00B909EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x145C, ????);     
        // 0x00B909F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B909F4: STRB w8, [x20, #0xa37]     | static_value_03733A37 = true;            //  dest_result_addr=57883191
        label_0:
        // 0x00B909F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B909FC: MOV x0, x19                | X0 = 1152921515523351360 (0x100000028AACA340);//ML01
        // 0x00B90A00: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_1 = this.transform;
        // 0x00B90A04: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B90A08: STR x20, [x19, #0x28]      | this.mTf = val_1;                        //  dest_result_addr=1152921515523351400
        this.mTf = val_1;
        // 0x00B90A0C: CBNZ x20, #0xb90a14        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00B90A10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00B90A14: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00B90A18: LDR x8, [x8, #0x2c0]       | X8 = (string**)(1152921515523290192)("Obj_HP_go");
        // 0x00B90A1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90A20: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B90A24: LDR x1, [x8]               | X1 = "Obj_HP_go";                       
        // 0x00B90A28: BL #0x2695ac0              | X0 = val_1.Find(name:  "Obj_HP_go");    
        UnityEngine.Transform val_2 = val_1.Find(name:  "Obj_HP_go");
        // 0x00B90A2C: LDR x20, [x19, #0x28]      | X20 = this.mTf; //P2                    
        // 0x00B90A30: STR x0, [x19, #0x50]       | this.Obj_HP = val_2;                     //  dest_result_addr=1152921515523351440
        this.Obj_HP = val_2;
        // 0x00B90A34: CBNZ x20, #0xb90a3c        | if (this.mTf != null) goto label_2;     
        if(this.mTf != null)
        {
            goto label_2;
        }
        // 0x00B90A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00B90A3C: ADRP x8, #0x3601000        | X8 = 56627200 (0x3601000);              
        // 0x00B90A40: LDR x8, [x8, #0xa08]       | X8 = (string**)(1152921515523298480)("Obj_HP_go/HPFG");
        // 0x00B90A44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90A48: MOV x0, x20                | X0 = this.mTf;//m1                      
        // 0x00B90A4C: LDR x1, [x8]               | X1 = "Obj_HP_go/HPFG";                  
        // 0x00B90A50: BL #0x2695ac0              | X0 = this.mTf.Find(name:  "Obj_HP_go/HPFG");
        UnityEngine.Transform val_3 = this.mTf.Find(name:  "Obj_HP_go/HPFG");
        // 0x00B90A54: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B90A58: CBNZ x20, #0xb90a60        | if (val_3 != null) goto label_3;        
        if(val_3 != null)
        {
            goto label_3;
        }
        // 0x00B90A5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00B90A60: ADRP x21, #0x35b8000       | X21 = 56328192 (0x35B8000);             
        // 0x00B90A64: LDR x21, [x21, #0x570]     | X21 = 1152921511724753616;              
        // 0x00B90A68: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B90A6C: LDR x1, [x21]              | X1 = public UISprite UnityEngine.Component::GetComponent<UISprite>();
        // 0x00B90A70: BL #0x23d5410              | X0 = val_3.GetComponent<UISprite>();    
        UISprite val_4 = val_3.GetComponent<UISprite>();
        // 0x00B90A74: LDR x20, [x19, #0x28]      | X20 = this.mTf; //P2                    
        // 0x00B90A78: STR x0, [x19, #0x38]       | this.hp_sp = val_4;                      //  dest_result_addr=1152921515523351416
        this.hp_sp = val_4;
        // 0x00B90A7C: CBNZ x20, #0xb90a84        | if (this.mTf != null) goto label_4;     
        if(this.mTf != null)
        {
            goto label_4;
        }
        // 0x00B90A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00B90A84: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00B90A88: LDR x8, [x8, #0x30]        | X8 = (string**)(1152921515523310864)("Obj_HP_go/dutytype");
        // 0x00B90A8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90A90: MOV x0, x20                | X0 = this.mTf;//m1                      
        // 0x00B90A94: LDR x1, [x8]               | X1 = "Obj_HP_go/dutytype";              
        // 0x00B90A98: BL #0x2695ac0              | X0 = this.mTf.Find(name:  "Obj_HP_go/dutytype");
        UnityEngine.Transform val_5 = this.mTf.Find(name:  "Obj_HP_go/dutytype");
        // 0x00B90A9C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00B90AA0: CBNZ x20, #0xb90aa8        | if (val_5 != null) goto label_5;        
        if(val_5 != null)
        {
            goto label_5;
        }
        // 0x00B90AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_5:
        // 0x00B90AA8: LDR x1, [x21]              | X1 = public UISprite UnityEngine.Component::GetComponent<UISprite>();
        // 0x00B90AAC: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00B90AB0: BL #0x23d5410              | X0 = val_5.GetComponent<UISprite>();    
        UISprite val_6 = val_5.GetComponent<UISprite>();
        // 0x00B90AB4: LDR x20, [x19, #0x50]      | X20 = this.Obj_HP; //P2                 
        // 0x00B90AB8: STR x0, [x19, #0x40]       | this.dutytype_sp = val_6;                //  dest_result_addr=1152921515523351424
        this.dutytype_sp = val_6;
        // 0x00B90ABC: CBNZ x20, #0xb90ac4        | if (this.Obj_HP != null) goto label_6;  
        if(this.Obj_HP != null)
        {
            goto label_6;
        }
        // 0x00B90AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_6:
        // 0x00B90AC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90AC8: MOV x0, x20                | X0 = this.Obj_HP;//m1                   
        // 0x00B90ACC: BL #0x20d50fc              | X0 = this.Obj_HP.get_gameObject();      
        UnityEngine.GameObject val_7 = this.Obj_HP.gameObject;
        // 0x00B90AD0: MOV x20, x0                | X20 = val_7;//m1                        
        // 0x00B90AD4: CBNZ x20, #0xb90adc        | if (val_7 != null) goto label_7;        
        if(val_7 != null)
        {
            goto label_7;
        }
        // 0x00B90AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_7:
        // 0x00B90ADC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B90AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90AE4: MOV x0, x20                | X0 = val_7;//m1                         
        // 0x00B90AE8: BL #0x1a62d64              | val_7.SetActive(value:  false);         
        val_7.SetActive(value:  false);
        // 0x00B90AEC: STRB wzr, [x19, #0x18]     | this.isHide = false;                     //  dest_result_addr=1152921515523351384
        this.isHide = false;
        // 0x00B90AF0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90AF4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B90AF8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B90AFC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90B00 (12126976), len: 504  VirtAddr: 0x00B90B00 RVA: 0x00B90B00 token: 100696385 methodIndex: 25149 delegateWrapperIndex: 0 methodInvoker: 0
    public void setDutyType(CombatEntity unit)
    {
        //
        // Disasemble & Code
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        //  | 
        string val_18;
        // 0x00B90B00: STP x22, x21, [sp, #-0x30]! | stack[1152921515523525328] = ???;  stack[1152921515523525336] = ???;  //  dest_result_addr=1152921515523525328 |  dest_result_addr=1152921515523525336
        // 0x00B90B04: STP x20, x19, [sp, #0x10]  | stack[1152921515523525344] = ???;  stack[1152921515523525352] = ???;  //  dest_result_addr=1152921515523525344 |  dest_result_addr=1152921515523525352
        // 0x00B90B08: STP x29, x30, [sp, #0x20]  | stack[1152921515523525360] = ???;  stack[1152921515523525368] = ???;  //  dest_result_addr=1152921515523525360 |  dest_result_addr=1152921515523525368
        // 0x00B90B0C: ADD x29, sp, #0x20         | X29 = (1152921515523525328 + 32) = 1152921515523525360 (0x100000028AAF4AF0);
        // 0x00B90B10: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B90B14: LDRB w8, [x21, #0xa38]     | W8 = (bool)static_value_03733A38;       
        // 0x00B90B18: MOV x20, x1                | X20 = unit;//m1                         
        // 0x00B90B1C: MOV x19, x0                | X19 = 1152921515523537376 (0x100000028AAF79E0);//ML01
        // 0x00B90B20: TBNZ w8, #0, #0xb90b3c     | if (static_value_03733A38 == true) goto label_0;
        // 0x00B90B24: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x00B90B28: LDR x8, [x8, #0x918]       | X8 = 0x2B8F66C;                         
        // 0x00B90B2C: LDR w0, [x8]               | W0 = 0x145F;                            
        // 0x00B90B30: BL #0x2782188              | X0 = sub_2782188( ?? 0x145F, ????);     
        // 0x00B90B34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B90B38: STRB w8, [x21, #0xa38]     | static_value_03733A38 = true;            //  dest_result_addr=57883192
        label_0:
        // 0x00B90B3C: CBNZ x20, #0xb90b44        | if (unit != null) goto label_1;         
        if(unit != null)
        {
            goto label_1;
        }
        // 0x00B90B40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x145F, ????);     
        label_1:
        // 0x00B90B44: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
        // 0x00B90B48: MOV x0, x20                | X0 = unit;//m1                          
        // 0x00B90B4C: LDR x9, [x8, #0x220]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_220;
        // 0x00B90B50: LDR x1, [x8, #0x228]       | X1 = typeof(CombatEntity).__il2cppRuntimeField_228;
        // 0x00B90B54: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_220();
        // 0x00B90B58: CMP w0, #5                 | STATE = COMPARE(unit, 0x5)              
        // 0x00B90B5C: B.NE #0xb90b94             | if (unit != 0x5) goto label_2;          
        if(unit != 5)
        {
            goto label_2;
        }
        // 0x00B90B60: LDR x20, [x19, #0x28]      | X20 = this.mTf; //P2                    
        // 0x00B90B64: STRB wzr, [x19, #0x30]     | this.isvisible = false;                  //  dest_result_addr=1152921515523537424
        this.isvisible = false;
        // 0x00B90B68: CBNZ x20, #0xb90b70        | if (this.mTf != null) goto label_3;     
        if(this.mTf != null)
        {
            goto label_3;
        }
        // 0x00B90B6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? unit, ????);       
        label_3:
        // 0x00B90B70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90B74: MOV x0, x20                | X0 = this.mTf;//m1                      
        // 0x00B90B78: BL #0x20d50fc              | X0 = this.mTf.get_gameObject();         
        UnityEngine.GameObject val_1 = this.mTf.gameObject;
        // 0x00B90B7C: MOV x19, x0                | X19 = val_1;//m1                        
        val_15 = val_1;
        // 0x00B90B80: CBNZ x19, #0xb90b88        | if (val_1 != null) goto label_4;        
        if(val_15 != null)
        {
            goto label_4;
        }
        // 0x00B90B84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B90B88: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        val_16 = 0;
        // 0x00B90B8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90B90: B #0xb90ce4                |  goto label_5;                          
        goto label_5;
        label_2:
        // 0x00B90B94: LDR x8, [x20]              | X8 = typeof(CombatEntity);              
        // 0x00B90B98: MOV x0, x20                | X0 = unit;//m1                          
        // 0x00B90B9C: LDR x9, [x8, #0x220]       | X9 = typeof(CombatEntity).__il2cppRuntimeField_220;
        // 0x00B90BA0: LDR x1, [x8, #0x228]       | X1 = typeof(CombatEntity).__il2cppRuntimeField_228;
        // 0x00B90BA4: BLR x9                     | X0 = typeof(CombatEntity).__il2cppRuntimeField_220();
        // 0x00B90BA8: CMP w0, #2                 | STATE = COMPARE(unit, 0x2)              
        // 0x00B90BAC: B.NE #0xb90c54             | if (unit != 0x2) goto label_9;          
        if(unit != 2)
        {
            goto label_9;
        }
        // 0x00B90BB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90BB4: MOV x0, x20                | X0 = unit;//m1                          
        // 0x00B90BB8: BL #0xd89bb8               | X0 = unit.get_dutytype();               
        int val_2 = unit.dutytype;
        // 0x00B90BBC: LDR x21, [x19, #0x40]      | X21 = this.dutytype_sp; //P2            
        // 0x00B90BC0: MOV w20, w0                | W20 = val_2;//m1                        
        // 0x00B90BC4: CBNZ x21, #0xb90bcc        | if (this.dutytype_sp != null) goto label_7;
        if(this.dutytype_sp != null)
        {
            goto label_7;
        }
        // 0x00B90BC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B90BCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90BD0: MOV x0, x21                | X0 = this.dutytype_sp;//m1              
        // 0x00B90BD4: BL #0x20d50fc              | X0 = this.dutytype_sp.get_gameObject(); 
        UnityEngine.GameObject val_3 = this.dutytype_sp.gameObject;
        // 0x00B90BD8: MOV x21, x0                | X21 = val_3;//m1                        
        val_14 = val_3;
        // 0x00B90BDC: CBNZ x21, #0xb90be4        | if (val_3 != null) goto label_8;        
        if(val_14 != null)
        {
            goto label_8;
        }
        // 0x00B90BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B90BE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90BE8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B90BEC: MOV x0, x21                | X0 = val_3;//m1                         
        // 0x00B90BF0: BL #0x1a62d64              | val_3.SetActive(value:  true);          
        val_14.SetActive(value:  true);
        // 0x00B90BF4: ADD w8, w20, #5            | W8 = (val_2 + 5);                       
        int val_4 = val_2 + 5;
        // 0x00B90BF8: CMP w20, #4                | STATE = COMPARE(val_2, 0x4)             
        // 0x00B90BFC: CSEL w8, w8, wzr, lo       | W8 = val_2 < 4 ? (val_2 + 5) : 0;       
        var val_5 = (val_2 < 4) ? (val_4) : 0;
        // 0x00B90C00: CMP w8, #8                 | STATE = COMPARE(val_2 < 4 ? (val_2 + 5) : 0, 0x8)
        // 0x00B90C04: B.HI #0xb90c54             | if (val_5 > 0x8) goto label_9;          
        if(val_5 > 8)
        {
            goto label_9;
        }
        // 0x00B90C08: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B90C0C: ADD x9, x9, #0xd84         | X9 = (44638208 + 3460) = 44641668 (0x02A92D84);
        // 0x00B90C10: LDRSW x8, [x9, x8, lsl #2] | X8 = 44641668 + (val_2 < 4 ? (val_2 + 5) : 0) << 2;
        var val_14 = 44641668 + (val_2 < 4 ? (val_2 + 5) : 0) << 2;
        // 0x00B90C14: ADD x8, x8, x9             | X8 = (44641668 + (val_2 < 4 ? (val_2 + 5) : 0) << 2 + 44641668);
        val_14 = val_14 + 44641668;
        // 0x00B90C18: BR x8                      | goto (44641668 + (val_2 < 4 ? (val_2 + 5) : 0) << 2 + 44641668);
        goto (44641668 + (val_2 < 4 ? (val_2 + 5) : 0) << 2 + 44641668);
        // 0x00B90C1C: LDR x20, [x19, #0x40]      | X20 = this.dutytype_sp; //P2            
        // 0x00B90C20: CBNZ x20, #0xb90c28        | if (this.dutytype_sp != null) goto label_10;
        if(this.dutytype_sp != null)
        {
            goto label_10;
        }
        // 0x00B90C24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x00B90C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90C2C: MOV x0, x20                | X0 = this.dutytype_sp;//m1              
        // 0x00B90C30: BL #0x20d50fc              | X0 = this.dutytype_sp.get_gameObject(); 
        UnityEngine.GameObject val_6 = this.dutytype_sp.gameObject;
        // 0x00B90C34: MOV x20, x0                | X20 = val_6;//m1                        
        // 0x00B90C38: CBNZ x20, #0xb90c40        | if (val_6 != null) goto label_11;       
        if(val_6 != null)
        {
            goto label_11;
        }
        // 0x00B90C3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_11:
        // 0x00B90C40: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B90C44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90C48: MOV x0, x20                | X0 = val_6;//m1                         
        // 0x00B90C4C: BL #0x1a62d64              | val_6.SetActive(value:  false);         
        val_6.SetActive(value:  false);
        // 0x00B90C50: B #0xb90cb8                |  goto label_12;                         
        goto label_12;
        label_9:
        // 0x00B90C54: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90C58: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B90C5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B90C60: RET                        |  return;                                
        return;
        // 0x00B90C64: LDR x20, [x19, #0x40]      | X20 = ??? + 64;                         
        val_17 = mem[??? + 64];
        val_17 = ??? + 64;
        // 0x00B90C68: CBNZ x20, #0xb90c70        | if (??? + 64 != 0) goto label_13;       
        if(val_17 != 0)
        {
            goto label_13;
        }
        // 0x00B90C6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? unit, ????);       
        label_13:
        // 0x00B90C70: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00B90C74: LDR x8, [x8, #0xfb0]       | X8 = (string**)(1152921515523508992)("gongjibiaoshi");
        val_18 = "gongjibiaoshi";
        // 0x00B90C78: B #0xb90ca8                |  goto label_16;                         
        goto label_16;
        // 0x00B90C7C: LDR x20, [x19, #0x40]      | X20 = ??? + 64;                         
        val_17 = mem[??? + 64];
        val_17 = ??? + 64;
        // 0x00B90C80: CBNZ x20, #0xb90c88        | if (??? + 64 != 0) goto label_15;       
        if(val_17 != 0)
        {
            goto label_15;
        }
        // 0x00B90C84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? unit, ????);       
        label_15:
        // 0x00B90C88: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
        // 0x00B90C8C: LDR x8, [x8, #0x30]        | X8 = (string**)(1152921515523509088)("fangyubiaoshi");
        val_18 = "fangyubiaoshi";
        // 0x00B90C90: B #0xb90ca8                |  goto label_16;                         
        goto label_16;
        // 0x00B90C94: LDR x20, [x19, #0x40]      | X20 = ??? + 64;                         
        val_17 = mem[??? + 64];
        val_17 = ??? + 64;
        // 0x00B90C98: CBNZ x20, #0xb90ca0        | if (??? + 64 != 0) goto label_17;       
        if(val_17 != 0)
        {
            goto label_17;
        }
        // 0x00B90C9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? unit, ????);       
        label_17:
        // 0x00B90CA0: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
        // 0x00B90CA4: LDR x8, [x8, #0x998]       | X8 = (string**)(1152921515523509184)("zhiliaobiaoshi");
        val_18 = "zhiliaobiaoshi";
        label_16:
        // 0x00B90CA8: LDR x1, [x8]               | X1 = "zhiliaobiaoshi";                  
        // 0x00B90CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90CB0: MOV x0, x20                | X0 = ??? + 64;//m1                      
        // 0x00B90CB4: BL #0x1538560              | ??? + 64.set_spriteName(value:  val_18 = "zhiliaobiaoshi");
        val_17.spriteName = val_18;
        label_12:
        // 0x00B90CB8: LDR x19, [x19, #0x28]      | X19 = ??? + 40;                         
        // 0x00B90CBC: CBNZ x19, #0xb90cc4        | if (??? + 40 != 0) goto label_18;       
        if((??? + 40) != 0)
        {
            goto label_18;
        }
        // 0x00B90CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ??? + 64, ????);   
        label_18:
        // 0x00B90CC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90CC8: MOV x0, x19                | X0 = ??? + 40;//m1                      
        // 0x00B90CCC: BL #0x20d50fc              | X0 = ??? + 40.get_gameObject();         
        UnityEngine.GameObject val_7 = ??? + 40.gameObject;
        // 0x00B90CD0: MOV x19, x0                | X19 = val_7;//m1                        
        val_15 = val_7;
        // 0x00B90CD4: CBNZ x19, #0xb90cdc        | if (val_7 != null) goto label_19;       
        if(val_15 != null)
        {
            goto label_19;
        }
        // 0x00B90CD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_19:
        // 0x00B90CDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90CE0: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_16 = 1;
        label_5:
        // 0x00B90CE4: MOV x0, x19                | X0 = val_7;//m1                         
        // 0x00B90CE8: LDP x29, x30, [sp, #0x20]  | X29 = val_8; X30 = val_9;                //  find_add[1152921515523513376] |  find_add[1152921515523513376]
        // 0x00B90CEC: LDP x20, x19, [sp, #0x10]  | X20 = val_10; X19 = val_11;              //  find_add[1152921515523513376] |  find_add[1152921515523513376]
        // 0x00B90CF0: LDP x22, x21, [sp], #0x30  | X22 = val_12; X21 = val_13;              //  find_add[1152921515523513376] |  find_add[1152921515523513376]
        // 0x00B90CF4: B #0x1a62d64               | val_7.SetActive(value:  true); return;  
        val_15.SetActive(value:  true);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90CF8 (12127480), len: 472  VirtAddr: 0x00B90CF8 RVA: 0x00B90CF8 token: 100696386 methodIndex: 25150 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        // 0x00B90CF8: STP d13, d12, [sp, #-0x60]! | stack[1152921515523690528] = ???;  stack[1152921515523690536] = ???;  //  dest_result_addr=1152921515523690528 |  dest_result_addr=1152921515523690536
        // 0x00B90CFC: STP d11, d10, [sp, #0x10]  | stack[1152921515523690544] = ???;  stack[1152921515523690552] = ???;  //  dest_result_addr=1152921515523690544 |  dest_result_addr=1152921515523690552
        // 0x00B90D00: STP d9, d8, [sp, #0x20]    | stack[1152921515523690560] = ???;  stack[1152921515523690568] = ???;  //  dest_result_addr=1152921515523690560 |  dest_result_addr=1152921515523690568
        // 0x00B90D04: STP x22, x21, [sp, #0x30]  | stack[1152921515523690576] = ???;  stack[1152921515523690584] = ???;  //  dest_result_addr=1152921515523690576 |  dest_result_addr=1152921515523690584
        // 0x00B90D08: STP x20, x19, [sp, #0x40]  | stack[1152921515523690592] = ???;  stack[1152921515523690600] = ???;  //  dest_result_addr=1152921515523690592 |  dest_result_addr=1152921515523690600
        // 0x00B90D0C: STP x29, x30, [sp, #0x50]  | stack[1152921515523690608] = ???;  stack[1152921515523690616] = ???;  //  dest_result_addr=1152921515523690608 |  dest_result_addr=1152921515523690616
        // 0x00B90D10: ADD x29, sp, #0x50         | X29 = (1152921515523690528 + 80) = 1152921515523690608 (0x100000028AB1D070);
        // 0x00B90D14: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B90D18: LDRB w8, [x20, #0xa39]     | W8 = (bool)static_value_03733A39;       
        // 0x00B90D1C: MOV x19, x0                | X19 = 1152921515523702624 (0x100000028AB1FF60);//ML01
        // 0x00B90D20: TBNZ w8, #0, #0xb90d3c     | if (static_value_03733A39 == true) goto label_0;
        // 0x00B90D24: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x00B90D28: LDR x8, [x8, #0x78]        | X8 = 0x2B8F678;                         
        // 0x00B90D2C: LDR w0, [x8]               | W0 = 0x1462;                            
        // 0x00B90D30: BL #0x2782188              | X0 = sub_2782188( ?? 0x1462, ????);     
        // 0x00B90D34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B90D38: STRB w8, [x20, #0xa39]     | static_value_03733A39 = true;            //  dest_result_addr=57883193
        label_0:
        // 0x00B90D3C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B90D40: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B90D44: LDR x20, [x19, #0x20]      | X20 = this.targetTf; //P2               
        // 0x00B90D48: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B90D4C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B90D50: TBZ w8, #0, #0xb90d60      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B90D54: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B90D58: CBNZ w8, #0xb90d60         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B90D5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B90D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90D68: MOV x1, x20                | X1 = this.targetTf;//m1                 
        // 0x00B90D6C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B90D70: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.targetTf);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.targetTf);
        // 0x00B90D74: TBZ w0, #0, #0xb90e48      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B90D78: LDP x21, x20, [x19, #0x20] | X21 = this.targetTf; //P2  X20 = this.mTf; //P2  //  | 
        // 0x00B90D7C: CBNZ x21, #0xb90d84        | if (this.targetTf != null) goto label_4;
        if(this.targetTf != null)
        {
            goto label_4;
        }
        // 0x00B90D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B90D84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90D88: MOV x0, x21                | X0 = this.targetTf;//m1                 
        // 0x00B90D8C: BL #0x2693510              | X0 = this.targetTf.get_position();      
        UnityEngine.Vector3 val_2 = this.targetTf.position;
        // 0x00B90D90: ADRP x21, #0x3650000       | X21 = 56950784 (0x3650000);             
        // 0x00B90D94: LDR x21, [x21, #0x2d0]     | X21 = 1152921504921223168;              
        // 0x00B90D98: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
        // 0x00B90D9C: MOV v9.16b, v1.16b         | V9 = val_2.y;//m1                       
        // 0x00B90DA0: MOV v10.16b, v2.16b        | V10 = val_2.z;//m1                      
        // 0x00B90DA4: LDR x0, [x21]              | X0 = typeof(Blood);                     
        val_7 = null;
        // 0x00B90DA8: LDRB w8, [x0, #0x10a]      | W8 = Blood.__il2cppRuntimeField_10A;    
        // 0x00B90DAC: TBZ w8, #0, #0xb90dc0      | if (Blood.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B90DB0: LDR w8, [x0, #0xbc]        | W8 = Blood.__il2cppRuntimeField_cctor_finished;
        // 0x00B90DB4: CBNZ w8, #0xb90dc0         | if (Blood.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B90DB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Blood), ????);
        // 0x00B90DBC: LDR x0, [x21]              | X0 = typeof(Blood);                     
        val_7 = null;
        label_6:
        // 0x00B90DC0: ADRP x9, #0x3673000        | X9 = 57094144 (0x3673000);              
        // 0x00B90DC4: LDR x8, [x0, #0xa0]        | X8 = Blood.__il2cppRuntimeField_static_fields;
        // 0x00B90DC8: LDR x9, [x9, #0x488]       | X9 = 1152921504695078912;               
        // 0x00B90DCC: LDR x0, [x9]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B90DD0: LDP s13, s12, [x8]         | S13 = Blood.offset; S12 = Blood.offset.__il2cppRuntimeField_4; //  | 
        // 0x00B90DD4: LDR s11, [x8, #8]          | S11 = Blood.offset.__il2cppRuntimeField_8;
        // 0x00B90DD8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B90DDC: TBZ w8, #0, #0xb90dec      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00B90DE0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B90DE4: CBNZ w8, #0xb90dec         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00B90DE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_8:
        // 0x00B90DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90DF4: MOV v0.16b, v8.16b         | V0 = val_2.x;//m1                       
        // 0x00B90DF8: MOV v1.16b, v9.16b         | V1 = val_2.y;//m1                       
        // 0x00B90DFC: MOV v2.16b, v10.16b        | V2 = val_2.z;//m1                       
        // 0x00B90E00: MOV v3.16b, v13.16b        | V3 = Blood.offset;//m1                  
        // 0x00B90E04: MOV v4.16b, v12.16b        | V4 = Blood.offset.__il2cppRuntimeField_4;//m1
        // 0x00B90E08: MOV v5.16b, v11.16b        | V5 = Blood.offset.__il2cppRuntimeField_8;//m1
        // 0x00B90E0C: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = Blood.offset, y = Blood.offset.__il2cppRuntimeField_4, z = Blood.offset.__il2cppRuntimeField_8});
        UnityEngine.Vector3 val_3 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = Blood.offset, y = Blood.offset.__il2cppRuntimeField_4, z = Blood.offset.__il2cppRuntimeField_8});
        // 0x00B90E10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90E18: BL #0xdf9c64               | X0 = UI3DWidgetMgr.WorldToNgui(_pos:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        UnityEngine.Vector3 val_4 = UI3DWidgetMgr.WorldToNgui(_pos:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        // 0x00B90E1C: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        // 0x00B90E20: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        // 0x00B90E24: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x00B90E28: CBNZ x20, #0xb90e30        | if (this.mTf != null) goto label_9;     
        if(this.mTf != null)
        {
            goto label_9;
        }
        // 0x00B90E2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x00B90E30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90E34: MOV x0, x20                | X0 = this.mTf;//m1                      
        // 0x00B90E38: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x00B90E3C: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x00B90E40: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x00B90E44: BL #0x26935b8              | this.mTf.set_position(value:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        this.mTf.position = new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z};
        label_3:
        // 0x00B90E48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B90E4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90E50: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_5 = UnityEngine.Time.time;
        // 0x00B90E54: LDR s1, [x19, #0x48]       | S1 = this.fiveSecond; //P2              
        // 0x00B90E58: FSUB s0, s0, s1            | S0 = (val_5 - this.fiveSecond);         
        val_5 = val_5 - this.fiveSecond;
        // 0x00B90E5C: FMOV s1, #5.00000000       | S1 = 5;                                 
        // 0x00B90E60: FCMP s0, s1                | STATE = COMPARE((val_5 - this.fiveSecond), 5)
        // 0x00B90E64: B.LE #0xb90eb4             | if (val_5 <= 5f) goto label_10;         
        if(val_5 <= 5f)
        {
            goto label_10;
        }
        // 0x00B90E68: LDR x19, [x19, #0x50]      | X19 = this.Obj_HP; //P2                 
        // 0x00B90E6C: CBNZ x19, #0xb90e74        | if (this.Obj_HP != null) goto label_11; 
        if(this.Obj_HP != null)
        {
            goto label_11;
        }
        // 0x00B90E70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_11:
        // 0x00B90E74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90E78: MOV x0, x19                | X0 = this.Obj_HP;//m1                   
        // 0x00B90E7C: BL #0x20d50fc              | X0 = this.Obj_HP.get_gameObject();      
        UnityEngine.GameObject val_6 = this.Obj_HP.gameObject;
        // 0x00B90E80: MOV x19, x0                | X19 = val_6;//m1                        
        // 0x00B90E84: CBNZ x19, #0xb90e8c        | if (val_6 != null) goto label_12;       
        if(val_6 != null)
        {
            goto label_12;
        }
        // 0x00B90E88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00B90E8C: MOV x0, x19                | X0 = val_6;//m1                         
        // 0x00B90E90: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90E94: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B90E98: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B90E9C: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B90EA0: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B90EA4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B90EA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90EAC: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B90EB0: B #0x1a62d64               | val_6.SetActive(value:  false); return; 
        val_6.SetActive(value:  false);
        return;
        label_10:
        // 0x00B90EB4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90EB8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B90EBC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B90EC0: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B90EC4: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B90EC8: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B90ECC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90ED0 (12127952), len: 120  VirtAddr: 0x00B90ED0 RVA: 0x00B90ED0 token: 100696387 methodIndex: 25151 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_visible(bool value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00B90ED0: STP x22, x21, [sp, #-0x30]! | stack[1152921515523831248] = ???;  stack[1152921515523831256] = ???;  //  dest_result_addr=1152921515523831248 |  dest_result_addr=1152921515523831256
        // 0x00B90ED4: STP x20, x19, [sp, #0x10]  | stack[1152921515523831264] = ???;  stack[1152921515523831272] = ???;  //  dest_result_addr=1152921515523831264 |  dest_result_addr=1152921515523831272
        // 0x00B90ED8: STP x29, x30, [sp, #0x20]  | stack[1152921515523831280] = ???;  stack[1152921515523831288] = ???;  //  dest_result_addr=1152921515523831280 |  dest_result_addr=1152921515523831288
        // 0x00B90EDC: ADD x29, sp, #0x20         | X29 = (1152921515523831248 + 32) = 1152921515523831280 (0x100000028AB3F5F0);
        // 0x00B90EE0: MOV x20, x0                | X20 = 1152921515523843296 (0x100000028AB424E0);//ML01
        // 0x00B90EE4: LDR x19, [x20, #0x50]      | X19 = this.Obj_HP; //P2                 
        // 0x00B90EE8: MOV w21, w1                | W21 = value;//m1                        
        // 0x00B90EEC: AND w8, w21, #1            | W8 = (value & 1);                       
        bool val_1 = value;
        // 0x00B90EF0: STRB w8, [x20, #0x30]      | this.isvisible = (value & 1);            //  dest_result_addr=1152921515523843344
        this.isvisible = val_1;
        // 0x00B90EF4: CBNZ x19, #0xb90efc        | if (this.Obj_HP != null) goto label_0;  
        if(this.Obj_HP != null)
        {
            goto label_0;
        }
        // 0x00B90EF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B90EFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90F00: MOV x0, x19                | X0 = this.Obj_HP;//m1                   
        // 0x00B90F04: BL #0x20d50fc              | X0 = this.Obj_HP.get_gameObject();      
        UnityEngine.GameObject val_2 = this.Obj_HP.gameObject;
        // 0x00B90F08: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B90F0C: TBZ w21, #0, #0xb90f1c     | if (value == false) goto label_1;       
        if(value == false)
        {
            goto label_1;
        }
        // 0x00B90F10: LDRB w8, [x20, #0x18]      | W8 = this.isHide; //P2                  
        // 0x00B90F14: EOR w20, w8, #1            | W20 = (this.isHide ^ 1);                
        val_5 = this.isHide ^ 1;
        // 0x00B90F18: B #0xb90f20                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B90F1C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_5 = 0;
        label_2:
        // 0x00B90F20: CBNZ x19, #0xb90f28        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00B90F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00B90F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90F2C: CMP w20, #0                | STATE = COMPARE(0x0, 0x0)               
        // 0x00B90F30: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B90F34: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90F38: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B90F3C: CSET w1, ne                | W1 = val_5 != 0x0 ? 1 : 0;              
        bool val_3 = (val_5 != 0) ? 1 : 0;
        // 0x00B90F40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B90F44: B #0x1a62d64               | val_2.SetActive(value:  bool val_3 = (val_5 != 0) ? 1 : 0); return;
        val_2.SetActive(value:  val_3);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90F48 (12128072), len: 112  VirtAddr: 0x00B90F48 RVA: 0x00B90F48 token: 100696388 methodIndex: 25152 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetHpShow(bool isShow)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00B90F48: STP x22, x21, [sp, #-0x30]! | stack[1152921515523959632] = ???;  stack[1152921515523959640] = ???;  //  dest_result_addr=1152921515523959632 |  dest_result_addr=1152921515523959640
        // 0x00B90F4C: STP x20, x19, [sp, #0x10]  | stack[1152921515523959648] = ???;  stack[1152921515523959656] = ???;  //  dest_result_addr=1152921515523959648 |  dest_result_addr=1152921515523959656
        // 0x00B90F50: STP x29, x30, [sp, #0x20]  | stack[1152921515523959664] = ???;  stack[1152921515523959672] = ???;  //  dest_result_addr=1152921515523959664 |  dest_result_addr=1152921515523959672
        // 0x00B90F54: ADD x29, sp, #0x20         | X29 = (1152921515523959632 + 32) = 1152921515523959664 (0x100000028AB5EB70);
        // 0x00B90F58: MOV x20, x0                | X20 = 1152921515523971680 (0x100000028AB61A60);//ML01
        // 0x00B90F5C: LDR x19, [x20, #0x50]      | X19 = this.Obj_HP; //P2                 
        // 0x00B90F60: MOV w21, w1                | W21 = isShow;//m1                       
        // 0x00B90F64: CBNZ x19, #0xb90f6c        | if (this.Obj_HP != null) goto label_0;  
        if(this.Obj_HP != null)
        {
            goto label_0;
        }
        // 0x00B90F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B90F6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B90F70: MOV x0, x19                | X0 = this.Obj_HP;//m1                   
        // 0x00B90F74: BL #0x20d50fc              | X0 = this.Obj_HP.get_gameObject();      
        UnityEngine.GameObject val_1 = this.Obj_HP.gameObject;
        // 0x00B90F78: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B90F7C: TBZ w21, #0, #0xb90f8c     | if (isShow == false) goto label_1;      
        if(isShow == false)
        {
            goto label_1;
        }
        // 0x00B90F80: LDRB w8, [x20, #0x18]      | W8 = this.isHide; //P2                  
        // 0x00B90F84: EOR w20, w8, #1            | W20 = (this.isHide ^ 1);                
        val_4 = this.isHide ^ 1;
        // 0x00B90F88: B #0xb90f90                |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x00B90F8C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
        val_4 = 0;
        label_2:
        // 0x00B90F90: CBNZ x19, #0xb90f98        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B90F94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B90F98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B90F9C: CMP w20, #0                | STATE = COMPARE(0x0, 0x0)               
        // 0x00B90FA0: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00B90FA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B90FA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B90FAC: CSET w1, ne                | W1 = val_4 != 0x0 ? 1 : 0;              
        bool val_2 = (val_4 != 0) ? 1 : 0;
        // 0x00B90FB0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B90FB4: B #0x1a62d64               | val_1.SetActive(value:  bool val_2 = (val_4 != 0) ? 1 : 0); return;
        val_1.SetActive(value:  val_2);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B90FB8 (12128184), len: 316  VirtAddr: 0x00B90FB8 RVA: 0x00B90FB8 token: 100696389 methodIndex: 25153 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetHp(float ratio)
    {
        //
        // Disasemble & Code
        // 0x00B90FB8: STP d9, d8, [sp, #-0x30]!  | stack[1152921515524104400] = ???;  stack[1152921515524104408] = ???;  //  dest_result_addr=1152921515524104400 |  dest_result_addr=1152921515524104408
        // 0x00B90FBC: STP x20, x19, [sp, #0x10]  | stack[1152921515524104416] = ???;  stack[1152921515524104424] = ???;  //  dest_result_addr=1152921515524104416 |  dest_result_addr=1152921515524104424
        // 0x00B90FC0: STP x29, x30, [sp, #0x20]  | stack[1152921515524104432] = ???;  stack[1152921515524104440] = ???;  //  dest_result_addr=1152921515524104432 |  dest_result_addr=1152921515524104440
        // 0x00B90FC4: ADD x29, sp, #0x20         | X29 = (1152921515524104400 + 32) = 1152921515524104432 (0x100000028AB820F0);
        // 0x00B90FC8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B90FCC: LDRB w8, [x20, #0xa3a]     | W8 = (bool)static_value_03733A3A;       
        // 0x00B90FD0: MOV v8.16b, v0.16b         | V8 = ratio;//m1                         
        // 0x00B90FD4: MOV x19, x0                | X19 = 1152921515524116448 (0x100000028AB84FE0);//ML01
        // 0x00B90FD8: TBNZ w8, #0, #0xb90ff4     | if (static_value_03733A3A == true) goto label_0;
        // 0x00B90FDC: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00B90FE0: LDR x8, [x8, #0x928]       | X8 = 0x2B8F670;                         
        // 0x00B90FE4: LDR w0, [x8]               | W0 = 0x1460;                            
        // 0x00B90FE8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1460, ????);     
        // 0x00B90FEC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B90FF0: STRB w8, [x20, #0xa3a]     | static_value_03733A3A = true;            //  dest_result_addr=57883194
        label_0:
        // 0x00B90FF4: LDR x20, [x19, #0x38]      | X20 = this.hp_sp; //P2                  
        // 0x00B90FF8: CBNZ x20, #0xb91000        | if (this.hp_sp != null) goto label_1;   
        if(this.hp_sp != null)
        {
            goto label_1;
        }
        // 0x00B90FFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1460, ????);     
        label_1:
        // 0x00B91000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91004: MOV x0, x20                | X0 = this.hp_sp;//m1                    
        // 0x00B91008: MOV v0.16b, v8.16b         | V0 = ratio;//m1                         
        // 0x00B9100C: BL #0xdfd8a8               | this.hp_sp.set_fillAmount(value:  ratio);
        this.hp_sp.fillAmount = ratio;
        // 0x00B91010: LDRB w8, [x19, #0x30]      | W8 = this.isvisible; //P2               
        // 0x00B91014: CBZ w8, #0xb91060          | if (this.isvisible == false) goto label_3;
        if(this.isvisible == false)
        {
            goto label_3;
        }
        // 0x00B91018: LDRB w8, [x19, #0x18]      | W8 = this.isHide; //P2                  
        // 0x00B9101C: CBNZ w8, #0xb91060         | if (this.isHide == true) goto label_3;  
        if(this.isHide == true)
        {
            goto label_3;
        }
        // 0x00B91020: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B91024: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B91028: LDR x20, [x19, #0x28]      | X20 = this.mTf; //P2                    
        // 0x00B9102C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B91030: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B91034: TBZ w8, #0, #0xb91044      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B91038: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B9103C: CBNZ w8, #0xb91044         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B91040: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00B91044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91048: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9104C: MOV x1, x20                | X1 = this.mTf;//m1                      
        // 0x00B91050: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B91054: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.mTf);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.mTf);
        // 0x00B91058: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B9105C: TBZ w8, #0, #0xb91070      | if ((val_1 & 1) == false) goto label_6; 
        if(val_2 == false)
        {
            goto label_6;
        }
        label_3:
        // 0x00B91060: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91064: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B91068: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B9106C: RET                        |  return;                                
        return;
        label_6:
        // 0x00B91070: LDR x20, [x19, #0x50]      | X20 = this.Obj_HP; //P2                 
        // 0x00B91074: CBNZ x20, #0xb9107c        | if (this.Obj_HP != null) goto label_7;  
        if(this.Obj_HP != null)
        {
            goto label_7;
        }
        // 0x00B91078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x00B9107C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91080: MOV x0, x20                | X0 = this.Obj_HP;//m1                   
        // 0x00B91084: BL #0x20d50fc              | X0 = this.Obj_HP.get_gameObject();      
        UnityEngine.GameObject val_3 = this.Obj_HP.gameObject;
        // 0x00B91088: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B9108C: CBNZ x20, #0xb91094        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00B91090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B91094: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91098: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B9109C: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B910A0: BL #0x1a62d64              | val_3.SetActive(value:  true);          
        val_3.SetActive(value:  true);
        // 0x00B910A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B910A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B910AC: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_4 = UnityEngine.Time.time;
        // 0x00B910B0: LDR x20, [x19, #0x28]      | X20 = this.mTf; //P2                    
        // 0x00B910B4: STR s0, [x19, #0x48]       | this.fiveSecond = val_4;                 //  dest_result_addr=1152921515524116520
        this.fiveSecond = val_4;
        // 0x00B910B8: CBNZ x20, #0xb910c0        | if (this.mTf != null) goto label_9;     
        if(this.mTf != null)
        {
            goto label_9;
        }
        // 0x00B910BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x00B910C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B910C4: MOV x0, x20                | X0 = this.mTf;//m1                      
        // 0x00B910C8: BL #0x20d50fc              | X0 = this.mTf.get_gameObject();         
        UnityEngine.GameObject val_5 = this.mTf.gameObject;
        // 0x00B910CC: MOV x19, x0                | X19 = val_5;//m1                        
        // 0x00B910D0: CBNZ x19, #0xb910d8        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00B910D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00B910D8: MOV x0, x19                | X0 = val_5;//m1                         
        // 0x00B910DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B910E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B910E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B910E8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B910EC: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B910F0: B #0x1a62d64               | val_5.SetActive(value:  true); return;  
        val_5.SetActive(value:  true);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B910F4 (12128500), len: 8  VirtAddr: 0x00B910F4 RVA: 0x00B910F4 token: 100696390 methodIndex: 25154 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetFocus(UnityEngine.Transform tr)
    {
        //
        // Disasemble & Code
        // 0x00B910F4: STR x1, [x0, #0x58]        | this.focusTr = tr;                       //  dest_result_addr=1152921515524257208
        this.focusTr = tr;
        // 0x00B910F8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B910FC (12128508), len: 184  VirtAddr: 0x00B910FC RVA: 0x00B910FC token: 100696391 methodIndex: 25155 delegateWrapperIndex: 0 methodInvoker: 0
    public void ShowFocus()
    {
        //
        // Disasemble & Code
        // 0x00B910FC: STP x20, x19, [sp, #-0x20]! | stack[1152921515524373472] = ???;  stack[1152921515524373480] = ???;  //  dest_result_addr=1152921515524373472 |  dest_result_addr=1152921515524373480
        // 0x00B91100: STP x29, x30, [sp, #0x10]  | stack[1152921515524373488] = ???;  stack[1152921515524373496] = ???;  //  dest_result_addr=1152921515524373488 |  dest_result_addr=1152921515524373496
        // 0x00B91104: ADD x29, sp, #0x10         | X29 = (1152921515524373472 + 16) = 1152921515524373488 (0x100000028ABC3BF0);
        // 0x00B91108: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B9110C: LDRB w8, [x20, #0xa3b]     | W8 = (bool)static_value_03733A3B;       
        // 0x00B91110: MOV x19, x0                | X19 = 1152921515524385504 (0x100000028ABC6AE0);//ML01
        // 0x00B91114: TBNZ w8, #0, #0xb91130     | if (static_value_03733A3B == true) goto label_0;
        // 0x00B91118: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00B9111C: LDR x8, [x8, #0xf98]       | X8 = 0x2B8F674;                         
        // 0x00B91120: LDR w0, [x8]               | W0 = 0x1461;                            
        // 0x00B91124: BL #0x2782188              | X0 = sub_2782188( ?? 0x1461, ????);     
        // 0x00B91128: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B9112C: STRB w8, [x20, #0xa3b]     | static_value_03733A3B = true;            //  dest_result_addr=57883195
        label_0:
        // 0x00B91130: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B91134: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B91138: LDR x20, [x19, #0x58]      | X20 = this.focusTr; //P2                
        // 0x00B9113C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B91140: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B91144: TBZ w8, #0, #0xb91154      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B91148: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B9114C: CBNZ w8, #0xb91154         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B91150: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B91154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91158: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9115C: MOV x1, x20                | X1 = this.focusTr;//m1                  
        // 0x00B91160: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B91164: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.focusTr);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.focusTr);
        // 0x00B91168: TBZ w0, #0, #0xb911a8      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B9116C: LDR x19, [x19, #0x58]      | X19 = this.focusTr; //P2                
        // 0x00B91170: CBNZ x19, #0xb91178        | if (this.focusTr != null) goto label_4; 
        if(this.focusTr != null)
        {
            goto label_4;
        }
        // 0x00B91174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B91178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B9117C: MOV x0, x19                | X0 = this.focusTr;//m1                  
        // 0x00B91180: BL #0x20d50fc              | X0 = this.focusTr.get_gameObject();     
        UnityEngine.GameObject val_2 = this.focusTr.gameObject;
        // 0x00B91184: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B91188: CBNZ x19, #0xb91190        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00B9118C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B91190: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91194: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91198: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B9119C: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B911A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B911A4: B #0x1a62d64               | val_2.SetActive(value:  true); return;  
        val_2.SetActive(value:  true);
        return;
        label_3:
        // 0x00B911A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B911AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B911B0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B911B4 (12128692), len: 184  VirtAddr: 0x00B911B4 RVA: 0x00B911B4 token: 100696392 methodIndex: 25156 delegateWrapperIndex: 0 methodInvoker: 0
    public void HideFocus()
    {
        //
        // Disasemble & Code
        // 0x00B911B4: STP x20, x19, [sp, #-0x20]! | stack[1152921515524510048] = ???;  stack[1152921515524510056] = ???;  //  dest_result_addr=1152921515524510048 |  dest_result_addr=1152921515524510056
        // 0x00B911B8: STP x29, x30, [sp, #0x10]  | stack[1152921515524510064] = ???;  stack[1152921515524510072] = ???;  //  dest_result_addr=1152921515524510064 |  dest_result_addr=1152921515524510072
        // 0x00B911BC: ADD x29, sp, #0x10         | X29 = (1152921515524510048 + 16) = 1152921515524510064 (0x100000028ABE5170);
        // 0x00B911C0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B911C4: LDRB w8, [x20, #0xa3c]     | W8 = (bool)static_value_03733A3C;       
        // 0x00B911C8: MOV x19, x0                | X19 = 1152921515524522080 (0x100000028ABE8060);//ML01
        // 0x00B911CC: TBNZ w8, #0, #0xb911e8     | if (static_value_03733A3C == true) goto label_0;
        // 0x00B911D0: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00B911D4: LDR x8, [x8, #0x248]       | X8 = 0x2B8F668;                         
        // 0x00B911D8: LDR w0, [x8]               | W0 = 0x145E;                            
        // 0x00B911DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x145E, ????);     
        // 0x00B911E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B911E4: STRB w8, [x20, #0xa3c]     | static_value_03733A3C = true;            //  dest_result_addr=57883196
        label_0:
        // 0x00B911E8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B911EC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B911F0: LDR x20, [x19, #0x58]      | X20 = this.focusTr; //P2                
        // 0x00B911F4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B911F8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B911FC: TBZ w8, #0, #0xb9120c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B91200: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B91204: CBNZ w8, #0xb9120c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B91208: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B9120C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91210: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91214: MOV x1, x20                | X1 = this.focusTr;//m1                  
        // 0x00B91218: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B9121C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.focusTr);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.focusTr);
        // 0x00B91220: TBZ w0, #0, #0xb91260      | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x00B91224: LDR x19, [x19, #0x58]      | X19 = this.focusTr; //P2                
        // 0x00B91228: CBNZ x19, #0xb91230        | if (this.focusTr != null) goto label_4; 
        if(this.focusTr != null)
        {
            goto label_4;
        }
        // 0x00B9122C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B91230: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91234: MOV x0, x19                | X0 = this.focusTr;//m1                  
        // 0x00B91238: BL #0x20d50fc              | X0 = this.focusTr.get_gameObject();     
        UnityEngine.GameObject val_2 = this.focusTr.gameObject;
        // 0x00B9123C: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00B91240: CBNZ x19, #0xb91248        | if (val_2 != null) goto label_5;        
        if(val_2 != null)
        {
            goto label_5;
        }
        // 0x00B91244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B91248: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B9124C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B91250: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91254: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00B91258: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B9125C: B #0x1a62d64               | val_2.SetActive(value:  false); return; 
        val_2.SetActive(value:  false);
        return;
        label_3:
        // 0x00B91260: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91264: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B91268: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B9126C (12128876), len: 232  VirtAddr: 0x00B9126C RVA: 0x00B9126C token: 100696393 methodIndex: 25157 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x00B9126C: STP x22, x21, [sp, #-0x30]! | stack[1152921515524642512] = ???;  stack[1152921515524642520] = ???;  //  dest_result_addr=1152921515524642512 |  dest_result_addr=1152921515524642520
        // 0x00B91270: STP x20, x19, [sp, #0x10]  | stack[1152921515524642528] = ???;  stack[1152921515524642536] = ???;  //  dest_result_addr=1152921515524642528 |  dest_result_addr=1152921515524642536
        // 0x00B91274: STP x29, x30, [sp, #0x20]  | stack[1152921515524642544] = ???;  stack[1152921515524642552] = ???;  //  dest_result_addr=1152921515524642544 |  dest_result_addr=1152921515524642552
        // 0x00B91278: ADD x29, sp, #0x20         | X29 = (1152921515524642512 + 32) = 1152921515524642544 (0x100000028AC056F0);
        // 0x00B9127C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B91280: LDRB w8, [x20, #0xa3d]     | W8 = (bool)static_value_03733A3D;       
        // 0x00B91284: MOV x19, x0                | X19 = 1152921515524654560 (0x100000028AC085E0);//ML01
        // 0x00B91288: TBNZ w8, #0, #0xb912a4     | if (static_value_03733A3D == true) goto label_0;
        // 0x00B9128C: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
        // 0x00B91290: LDR x8, [x8, #0xf68]       | X8 = 0x2B8F664;                         
        // 0x00B91294: LDR w0, [x8]               | W0 = 0x145D;                            
        // 0x00B91298: BL #0x2782188              | X0 = sub_2782188( ?? 0x145D, ????);     
        // 0x00B9129C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B912A0: STRB w8, [x20, #0xa3d]     | static_value_03733A3D = true;            //  dest_result_addr=57883197
        label_0:
        // 0x00B912A4: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B912A8: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00B912AC: LDR x20, [x19, #0x28]      | X20 = this.mTf; //P2                    
        // 0x00B912B0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B912B4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B912B8: TBZ w8, #0, #0xb912c8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B912BC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B912C0: CBNZ w8, #0xb912c8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B912C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B912C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B912CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B912D0: MOV x1, x20                | X1 = this.mTf;//m1                      
        // 0x00B912D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B912D8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.mTf);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  this.mTf);
        // 0x00B912DC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B912E0: TBZ w8, #0, #0xb912f4      | if ((val_1 & 1) == false) goto label_3; 
        if(val_2 == false)
        {
            goto label_3;
        }
        // 0x00B912E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B912E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B912EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B912F0: RET                        |  return;                                
        return;
        label_3:
        // 0x00B912F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B912F8: MOV x0, x19                | X0 = 1152921515524654560 (0x100000028AC085E0);//ML01
        // 0x00B912FC: STR xzr, [x19, #0x58]      | this.focusTr = null;                     //  dest_result_addr=1152921515524654648
        this.focusTr = 0;
        // 0x00B91300: STP xzr, xzr, [x19, #0x38] | this.hp_sp = null;  this.dutytype_sp = null;  //  dest_result_addr=1152921515524654616 |  dest_result_addr=1152921515524654624
        this.hp_sp = 0;
        this.dutytype_sp = 0;
        // 0x00B91304: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_3 = this.gameObject;
        // 0x00B91308: LDR x8, [x21]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B9130C: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B91310: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B91314: TBZ w9, #0, #0xb91328      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B91318: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B9131C: CBNZ w9, #0xb91328         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B91320: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B91324: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00B91328: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B9132C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B91330: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00B91334: BL #0x1b78acc              | UnityEngine.Object.Destroy(obj:  0);    
        UnityEngine.Object.Destroy(obj:  0);
        // 0x00B91338: MOV x1, x19                | X1 = 1152921515524654560 (0x100000028AC085E0);//ML01
        // 0x00B9133C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B91340: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B91344: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B91348: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B9134C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B91350: B #0x1b78acc               | UnityEngine.Object.Destroy(obj:  0); return;
        UnityEngine.Object.Destroy(obj:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B91354 (12129108), len: 132  VirtAddr: 0x00B91354 RVA: 0x00B91354 token: 100696394 methodIndex: 25158 delegateWrapperIndex: 0 methodInvoker: 0
    private static Blood()
    {
        //
        // Disasemble & Code
        // 0x00B91354: STP x20, x19, [sp, #-0x20]! | stack[1152921515524762720] = ???;  stack[1152921515524762728] = ???;  //  dest_result_addr=1152921515524762720 |  dest_result_addr=1152921515524762728
        // 0x00B91358: STP x29, x30, [sp, #0x10]  | stack[1152921515524762736] = ???;  stack[1152921515524762744] = ???;  //  dest_result_addr=1152921515524762736 |  dest_result_addr=1152921515524762744
        // 0x00B9135C: ADD x29, sp, #0x10         | X29 = (1152921515524762720 + 16) = 1152921515524762736 (0x100000028AC22C70);
        // 0x00B91360: SUB sp, sp, #0x10          | SP = (1152921515524762720 - 16) = 1152921515524762704 (0x100000028AC22C50);
        // 0x00B91364: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B91368: LDRB w8, [x19, #0xa3e]     | W8 = (bool)static_value_03733A3E;       
        // 0x00B9136C: TBNZ w8, #0, #0xb91388     | if (static_value_03733A3E == true) goto label_0;
        // 0x00B91370: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B91374: LDR x8, [x8, #0x558]       | X8 = 0x2B8F65C;                         
        // 0x00B91378: LDR w0, [x8]               | W0 = 0x145B;                            
        // 0x00B9137C: BL #0x2782188              | X0 = sub_2782188( ?? 0x145B, ????);     
        // 0x00B91380: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B91384: STRB w8, [x19, #0xa3e]     | static_value_03733A3E = true;            //  dest_result_addr=57883198
        label_0:
        // 0x00B91388: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B9138C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B91390: FMOV s1, #0.50000000       | S1 = 0.5;                               
        // 0x00B91394: MOV x0, sp                 | X0 = 1152921515524762704 (0x100000028AC22C50);//ML01
        // 0x00B91398: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x00B9139C: STR wzr, [sp, #8]          | stack[1152921515524762712] = 0x0;        //  dest_result_addr=1152921515524762712
        // 0x00B913A0: STR xzr, [sp]              | stack[1152921515524762704] = 0x0;        //  dest_result_addr=1152921515524762704
        // 0x00B913A4: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B913A8: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00B913AC: LDR x8, [x8, #0x2d0]       | X8 = 1152921504921223168;               
        // 0x00B913B0: LDR x9, [sp]               | X9 = 0x0;                               
        // 0x00B913B4: LDR w10, [sp, #8]          | W10 = 0x0;                              
        // 0x00B913B8: LDR x8, [x8]               | X8 = typeof(Blood);                     
        // 0x00B913BC: LDR x8, [x8, #0xa0]        | X8 = Blood.__il2cppRuntimeField_static_fields;
        // 0x00B913C0: STR x9, [x8]               | Blood.offset = new UnityEngine.Vector3();  //  dest_result_addr=1152921504921227264
        Blood.offset = 0;
        // 0x00B913C4: STR w10, [x8, #8]          | Blood.offset.__il2cppRuntimeField_8 = 0x0;  //  dest_result_addr=1152921504921227272
        Blood.offset.__il2cppRuntimeField_8 = 0;
        // 0x00B913C8: SUB sp, x29, #0x10         | SP = (1152921515524762736 - 16) = 1152921515524762720 (0x100000028AC22C60);
        // 0x00B913CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B913D0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B913D4: RET                        |  return;                                
        return;
    
    }

}
