using UnityEngine;
public class CameraShotMgr
{
    // Fields
    private CameraAniMap curMapCameraAni; //  0x00000010
    public const string WAITTIME_COMPLETE = "WAITTIME_COMPLETE";
    public const string ACTION_DONE = "ACTION_DONE";
    public const string SKILL_DONE = "SKILL_DONE";
    public const string START_ANI_COMPLETE = "START_ANI_COMPLETE";
    private UnityEngine.Vector3 circleLastPos; //  0x00000018
    private UnityEngine.Quaternion circleLastQua; //  0x00000024
    public bool isEditorRun; //  0x00000034
    private CombatEntity curSkillEntity; //  0x00000038
    private int curEffectid; //  0x00000040
    public bool isCameraShotRunning; //  0x00000044
    private bool isWith; //  0x00000045
    private int temp_Id; //  0x00000048
    private float temp_float; //  0x0000004C
    private int tempSkill_int; //  0x00000050
    private cameraShotCfg cameraShot_temp; //  0x00000058
    private CameraShotMgr.CameraShotVO curCameraShot; //  0x00000060
    private System.Collections.Generic.List<CameraShotMgr.CameraShotVO> cameraShotQueue; //  0x00000068
    private System.Collections.Generic.List<CameraShotMgr.CameraShotVO> withQueue; //  0x00000070
    public System.Collections.Generic.Dictionary<int, UnityEngine.GameObject> effectDic; //  0x00000078
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D773F8 (14119928), len: 120  VirtAddr: 0x00D773F8 RVA: 0x00D773F8 token: 100694122 methodIndex: 25806 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotMgr()
    {
        //
        // Disasemble & Code
        // 0x00D773F8: STP x20, x19, [sp, #-0x20]! | stack[1152921515109848096] = ???;  stack[1152921515109848104] = ???;  //  dest_result_addr=1152921515109848096 |  dest_result_addr=1152921515109848104
        // 0x00D773FC: STP x29, x30, [sp, #0x10]  | stack[1152921515109848112] = ???;  stack[1152921515109848120] = ???;  //  dest_result_addr=1152921515109848112 |  dest_result_addr=1152921515109848120
        // 0x00D77400: ADD x29, sp, #0x10         | X29 = (1152921515109848096 + 16) = 1152921515109848112 (0x1000000272071430);
        // 0x00D77404: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D77408: LDRB w8, [x20, #0x3e7]     | W8 = (bool)static_value_037343E7;       
        // 0x00D7740C: MOV x19, x0                | X19 = 1152921515109860128 (0x1000000272074320);//ML01
        // 0x00D77410: TBNZ w8, #0, #0xd7742c     | if (static_value_037343E7 == true) goto label_0;
        // 0x00D77414: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00D77418: LDR x8, [x8, #0x860]       | X8 = 0x2B9029C;                         
        // 0x00D7741C: LDR w0, [x8]               | W0 = 0x176B;                            
        // 0x00D77420: BL #0x2782188              | X0 = sub_2782188( ?? 0x176B, ????);     
        // 0x00D77424: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D77428: STRB w8, [x20, #0x3e7]     | static_value_037343E7 = true;            //  dest_result_addr=57885671
        label_0:
        // 0x00D7742C: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D77430: LDR x8, [x8, #0x148]       | X8 = 1152921504615792640;               
        // 0x00D77434: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject> val_1 = null;
        // 0x00D77438: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00D7743C: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D77440: LDR x8, [x8, #0x308]       | X8 = 1152921510773667152;               
        // 0x00D77444: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00D77448: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::.ctor();
        // 0x00D7744C: BL #0x2413320              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>();
        // 0x00D77450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77454: MOV x0, x19                | X0 = 1152921515109860128 (0x1000000272074320);//ML01
        // 0x00D77458: STR x20, [x19, #0x78]      | this.effectDic = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921515109860248
        this.effectDic = val_1;
        // 0x00D7745C: BL #0x16f59f0              | this..ctor();                           
        // 0x00D77460: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77464: MOV x0, x19                | X0 = 1152921515109860128 (0x1000000272074320);//ML01
        // 0x00D77468: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D7746C: B #0xd77470                | this.InitTrigger(); return;             
        this.InitTrigger();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77470 (14120048), len: 364  VirtAddr: 0x00D77470 RVA: 0x00D77470 token: 100694123 methodIndex: 25807 delegateWrapperIndex: 0 methodInvoker: 0
    private void InitTrigger()
    {
        //
        // Disasemble & Code
        // 0x00D77470: STP x24, x23, [sp, #-0x40]! | stack[1152921515109964160] = ???;  stack[1152921515109964168] = ???;  //  dest_result_addr=1152921515109964160 |  dest_result_addr=1152921515109964168
        // 0x00D77474: STP x22, x21, [sp, #0x10]  | stack[1152921515109964176] = ???;  stack[1152921515109964184] = ???;  //  dest_result_addr=1152921515109964176 |  dest_result_addr=1152921515109964184
        // 0x00D77478: STP x20, x19, [sp, #0x20]  | stack[1152921515109964192] = ???;  stack[1152921515109964200] = ???;  //  dest_result_addr=1152921515109964192 |  dest_result_addr=1152921515109964200
        // 0x00D7747C: STP x29, x30, [sp, #0x30]  | stack[1152921515109964208] = ???;  stack[1152921515109964216] = ???;  //  dest_result_addr=1152921515109964208 |  dest_result_addr=1152921515109964216
        // 0x00D77480: ADD x29, sp, #0x30         | X29 = (1152921515109964160 + 48) = 1152921515109964208 (0x100000027208D9B0);
        // 0x00D77484: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D77488: LDRB w8, [x20, #0x3e8]     | W8 = (bool)static_value_037343E8;       
        // 0x00D7748C: MOV x19, x0                | X19 = 1152921515109976224 (0x10000002720908A0);//ML01
        // 0x00D77490: TBNZ w8, #0, #0xd774ac     | if (static_value_037343E8 == true) goto label_0;
        // 0x00D77494: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00D77498: LDR x8, [x8, #0x5c8]       | X8 = 0x2B90304;                         
        // 0x00D7749C: LDR w0, [x8]               | W0 = 0x1785;                            
        // 0x00D774A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1785, ????);     
        // 0x00D774A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D774A8: STRB w8, [x20, #0x3e8]     | static_value_037343E8 = true;            //  dest_result_addr=57885672
        label_0:
        // 0x00D774AC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D774B0: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00D774B4: LDR x8, [x8, #0x928]       | X8 = 1152921515109948128;               
        // 0x00D774B8: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00D774BC: LDR x21, [x8]              | X21 = System.Void CameraShotMgr::OnOtherDead(CEvent.ZEvent ev);
        // 0x00D774C0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00D774C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D774C8: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00D774CC: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00D774D0: MOV x1, x19                | X1 = 1152921515109976224 (0x10000002720908A0);//ML01
        // 0x00D774D4: MOV x2, x21                | X2 = 1152921515109948128 (0x1000000272089AE0);//ML01
        // 0x00D774D8: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D774DC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D774E0: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnOtherDead(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnOtherDead(CEvent.ZEvent ev));
        // 0x00D774E4: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D774E8: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D774EC: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D774F0: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D774F4: TBZ w8, #0, #0xd77504      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D774F8: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D774FC: CBNZ w8, #0xd77504         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D77500: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00D77504: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00D77508: LDR x8, [x8, #0x320]       | X8 = (string**)(1152921510362022720)("OTHERDEAD");
        // 0x00D7750C: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77510: LDR x1, [x8]               | X1 = "OTHERDEAD";                       
        // 0x00D77514: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "OTHERDEAD");
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "OTHERDEAD");
        // 0x00D77518: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00D7751C: LDR x8, [x8, #0x268]       | X8 = 1152921515109949152;               
        // 0x00D77520: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00D77524: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnBattleEnded(CEvent.ZEvent ev);
        // 0x00D77528: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7752C: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D77530: MOV x1, x19                | X1 = 1152921515109976224 (0x10000002720908A0);//ML01
        // 0x00D77534: MOV x2, x20                | X2 = 1152921515109949152 (0x1000000272089EE0);//ML01
        // 0x00D77538: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7753C: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnBattleEnded(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnBattleEnded(CEvent.ZEvent ev));
        // 0x00D77540: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D77544: LDR x8, [x8, #0x550]       | X8 = (string**)(1152921510361990080)("BATTLE_ENDED");
        // 0x00D77548: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7754C: LDR x1, [x8]               | X1 = "BATTLE_ENDED";                    
        // 0x00D77550: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnBattleEnded(CEvent.ZEvent ev)), fun:  "BATTLE_ENDED");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_2, fun:  "BATTLE_ENDED");
        // 0x00D77554: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00D77558: LDR x8, [x8, #0x3e8]       | X8 = 1152921515109950176;               
        // 0x00D7755C: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_3 = null;
        // 0x00D77560: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnCombatWin(CEvent.ZEvent ev);
        // 0x00D77564: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D77568: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7756C: MOV x1, x19                | X1 = 1152921515109976224 (0x10000002720908A0);//ML01
        // 0x00D77570: MOV x2, x20                | X2 = 1152921515109950176 (0x100000027208A2E0);//ML01
        // 0x00D77574: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77578: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnCombatWin(CEvent.ZEvent ev));
        val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnCombatWin(CEvent.ZEvent ev));
        // 0x00D7757C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D77580: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921510361991200)("COMBAT_WIN");
        // 0x00D77584: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77588: LDR x1, [x8]               | X1 = "COMBAT_WIN";                      
        // 0x00D7758C: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnCombatWin(CEvent.ZEvent ev)), fun:  "COMBAT_WIN");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_3, fun:  "COMBAT_WIN");
        // 0x00D77590: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00D77594: LDR x8, [x8, #0xb28]       | X8 = 1152921515109951200;               
        // 0x00D77598: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00D7759C: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnEnterFuben(CEvent.ZEvent ev);
        // 0x00D775A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D775A4: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D775A8: MOV x1, x19                | X1 = 1152921515109976224 (0x10000002720908A0);//ML01
        // 0x00D775AC: MOV x2, x20                | X2 = 1152921515109951200 (0x100000027208A6E0);//ML01
        // 0x00D775B0: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D775B4: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnEnterFuben(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnEnterFuben(CEvent.ZEvent ev));
        // 0x00D775B8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00D775BC: LDR x8, [x8, #0xe08]       | X8 = (string**)(1152921510322305344)("ENTER_FUBEN");
        // 0x00D775C0: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D775C4: LDR x1, [x8]               | X1 = "ENTER_FUBEN";                     
        // 0x00D775C8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D775CC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D775D0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D775D4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D775D8: B #0xd775dc                | CEvent.ZEventCenter.AddEventListener(eventType:  val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnEnterFuben(CEvent.ZEvent ev)), fun:  "ENTER_FUBEN"); return;
        CEvent.ZEventCenter.AddEventListener(eventType:  val_4, fun:  "ENTER_FUBEN");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D776BC (14120636), len: 220  VirtAddr: 0x00D776BC RVA: 0x00D776BC token: 100694124 methodIndex: 25808 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnQuitGame(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00D776BC: STP x22, x21, [sp, #-0x30]! | stack[1152921515110081296] = ???;  stack[1152921515110081304] = ???;  //  dest_result_addr=1152921515110081296 |  dest_result_addr=1152921515110081304
        // 0x00D776C0: STP x20, x19, [sp, #0x10]  | stack[1152921515110081312] = ???;  stack[1152921515110081320] = ???;  //  dest_result_addr=1152921515110081312 |  dest_result_addr=1152921515110081320
        // 0x00D776C4: STP x29, x30, [sp, #0x20]  | stack[1152921515110081328] = ???;  stack[1152921515110081336] = ???;  //  dest_result_addr=1152921515110081328 |  dest_result_addr=1152921515110081336
        // 0x00D776C8: ADD x29, sp, #0x20         | X29 = (1152921515110081296 + 32) = 1152921515110081328 (0x10000002720AA330);
        // 0x00D776CC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D776D0: LDRB w8, [x20, #0x3e9]     | W8 = (bool)static_value_037343E9;       
        // 0x00D776D4: MOV x19, x0                | X19 = 1152921515110093344 (0x10000002720AD220);//ML01
        // 0x00D776D8: TBNZ w8, #0, #0xd776f4     | if (static_value_037343E9 == true) goto label_0;
        // 0x00D776DC: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00D776E0: LDR x8, [x8, #0xea0]       | X8 = 0x2B90344;                         
        // 0x00D776E4: LDR w0, [x8]               | W0 = 0x1795;                            
        // 0x00D776E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1795, ????);     
        // 0x00D776EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D776F0: STRB w8, [x20, #0x3e9]     | static_value_037343E9 = true;            //  dest_result_addr=57885673
        label_0:
        // 0x00D776F4: ADRP x20, #0x35f6000       | X20 = 56582144 (0x35F6000);             
        // 0x00D776F8: LDR x20, [x20, #0x7e8]     | X20 = 1152921504909295616;              
        // 0x00D776FC: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_2 = null;
        // 0x00D77700: LDRB w8, [x0, #0x10a]      | W8 = SceneMgr.__il2cppRuntimeField_10A; 
        // 0x00D77704: TBZ w8, #0, #0xd77718      | if (SceneMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D77708: LDR w8, [x0, #0xbc]        | W8 = SceneMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00D7770C: CBNZ w8, #0xd77718         | if (SceneMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D77710: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SceneMgr), ????);
        // 0x00D77714: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_2 = null;
        label_2:
        // 0x00D77718: ADRP x9, #0x367e000        | X9 = 57139200 (0x367E000);              
        // 0x00D7771C: ADRP x10, #0x3658000       | X10 = 56983552 (0x3658000);             
        // 0x00D77720: LDR x8, [x0, #0xa0]        | X8 = SceneMgr.__il2cppRuntimeField_static_fields;
        // 0x00D77724: LDR x9, [x9, #0x8c0]       | X9 = 1152921515110068320;               
        // 0x00D77728: LDR x10, [x10, #0x980]     | X10 = 1152921504898113536;              
        // 0x00D7772C: LDR x20, [x8, #0x10]       | X20 = SceneMgr.SCENE_START_LOAD;        
        // 0x00D77730: LDR x22, [x9]              | X22 = System.Void CameraShotMgr::OnQuitGame(CEvent.ZEvent ev);
        // 0x00D77734: LDR x0, [x10]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00D77738: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7773C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D77740: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00D77744: MOV x1, x19                | X1 = 1152921515110093344 (0x10000002720AD220);//ML01
        // 0x00D77748: MOV x2, x22                | X2 = 1152921515110068320 (0x10000002720A7060);//ML01
        // 0x00D7774C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77750: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D77754: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnQuitGame(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnQuitGame(CEvent.ZEvent ev));
        // 0x00D77758: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D7775C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D77760: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D77764: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D77768: TBZ w8, #0, #0xd77778      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D7776C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D77770: CBNZ w8, #0xd77778         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D77774: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_4:
        // 0x00D77778: MOV x1, x20                | X1 = SceneMgr.SCENE_START_LOAD;//m1     
        // 0x00D7777C: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77780: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  null, func:  SceneMgr.SCENE_START_LOAD);
        CEvent.ZEventCenter.RemoveEventListener(eventType:  null, func:  SceneMgr.SCENE_START_LOAD);
        // 0x00D77784: STR xzr, [x19, #0x10]      | this.curMapCameraAni = null;             //  dest_result_addr=1152921515110093360
        this.curMapCameraAni = 0;
        // 0x00D77788: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7778C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77790: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D77794: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77830 (14121008), len: 336  VirtAddr: 0x00D77830 RVA: 0x00D77830 token: 100694125 methodIndex: 25809 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnOtherDead(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_2;
        //  | 
        object val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x00D77830: STP x22, x21, [sp, #-0x30]! | stack[1152921515110209680] = ???;  stack[1152921515110209688] = ???;  //  dest_result_addr=1152921515110209680 |  dest_result_addr=1152921515110209688
        // 0x00D77834: STP x20, x19, [sp, #0x10]  | stack[1152921515110209696] = ???;  stack[1152921515110209704] = ???;  //  dest_result_addr=1152921515110209696 |  dest_result_addr=1152921515110209704
        // 0x00D77838: STP x29, x30, [sp, #0x20]  | stack[1152921515110209712] = ???;  stack[1152921515110209720] = ???;  //  dest_result_addr=1152921515110209712 |  dest_result_addr=1152921515110209720
        // 0x00D7783C: ADD x29, sp, #0x20         | X29 = (1152921515110209680 + 32) = 1152921515110209712 (0x10000002720C98B0);
        // 0x00D77840: SUB sp, sp, #0x10          | SP = (1152921515110209680 - 16) = 1152921515110209664 (0x10000002720C9880);
        // 0x00D77844: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D77848: LDRB w8, [x21, #0x3ea]     | W8 = (bool)static_value_037343EA;       
        // 0x00D7784C: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D77850: MOV x19, x0                | X19 = 1152921515110221728 (0x10000002720CC7A0);//ML01
        // 0x00D77854: TBNZ w8, #0, #0xd77870     | if (static_value_037343EA == true) goto label_0;
        // 0x00D77858: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00D7785C: LDR x8, [x8, #0x510]       | X8 = 0x2B9033C;                         
        // 0x00D77860: LDR w0, [x8]               | W0 = 0x1793;                            
        // 0x00D77864: BL #0x2782188              | X0 = sub_2782188( ?? 0x1793, ????);     
        // 0x00D77868: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7786C: STRB w8, [x21, #0x3ea]     | static_value_037343EA = true;            //  dest_result_addr=57885674
        label_0:
        // 0x00D77870: CBNZ x20, #0xd77878        | if (ev != null) goto label_1;           
        if(ev != null)
        {
            goto label_1;
        }
        // 0x00D77874: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1793, ????);     
        label_1:
        // 0x00D77878: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00D7787C: LDR x22, [x20, #0x28]      | X22 = ev.arg; //P2                      
        val_3 = ev.arg;
        // 0x00D77880: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00D77884: LDR x21, [x8]              | X21 = typeof(System.Int32);             
        // 0x00D77888: CBNZ x22, #0xd77890        | if (ev.arg != null) goto label_2;       
        if(val_3 != null)
        {
            goto label_2;
        }
        // 0x00D7788C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1793, ????);     
        label_2:
        // 0x00D77890: LDR x8, [x22]              | X8 = typeof(System.Object);             
        // 0x00D77894: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D77898: LDR x8, [x21, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7789C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D778A0: B.NE #0xd77918             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_3;
        // 0x00D778A4: MOV x0, x22                | X0 = ev.arg;//m1                        
        // 0x00D778A8: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_3.System.IDisposable.Dispose();
        // 0x00D778AC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00D778B0: LDR w21, [x0]              | W21 = typeof(System.Object);            
        // 0x00D778B4: LDR x20, [x20, #0x38]      | X20 = ev.arg2; //P2                     
        // 0x00D778B8: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
        // 0x00D778BC: LDR x22, [x8]              | X22 = typeof(System.Boolean);           
        val_3 = null;
        // 0x00D778C0: CBNZ x20, #0xd778c8        | if (ev.arg2 != null) goto label_4;      
        if(ev.arg2 != null)
        {
            goto label_4;
        }
        // 0x00D778C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ev.arg, ????);     
        label_4:
        // 0x00D778C8: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D778CC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D778D0: LDR x8, [x22, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
        // 0x00D778D4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Boolean.__il2cppRuntimeField_element_class)
        // 0x00D778D8: B.NE #0xd7793c             | if (System.Object.__il2cppRuntimeField_element_class != System.Boolean.__il2cppRuntimeField_element_class) goto label_5;
        // 0x00D778DC: MOV x0, x20                | X0 = ev.arg2;//m1                       
        // 0x00D778E0: BL #0x27bc4e8              | ev.arg2.System.IDisposable.Dispose();   
        ev.arg2.System.IDisposable.Dispose();
        // 0x00D778E4: LDRB w8, [x0]              | W8 = typeof(System.Object);             
        // 0x00D778E8: EOR w8, w8, #1             | W8 = (1152921504606900224 ^ 1) = 1152921504606900225 (0x100000000000D001);
        // 0x00D778EC: AND w20, w8, #0xff         | W20 = (1152921504606900225 & 255) = 1 (0x00000001);
        // 0x00D778F0: CBNZ x19, #0xd778f8        | if (this != null) goto label_6;         
        if(this != null)
        {
            goto label_6;
        }
        // 0x00D778F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ev.arg2, ????);    
        label_6:
        // 0x00D778F8: MOV x0, x19                | X0 = 1152921515110221728 (0x10000002720CC7A0);//ML01
        // 0x00D778FC: MOV w1, w20                | W1 = 1 (0x1);//ML01                     
        // 0x00D77900: MOV w2, w21                | W2 = 1152921504606900224 (0x100000000000D000);//ML01
        // 0x00D77904: SUB sp, x29, #0x20         | SP = (1152921515110209712 - 32) = 1152921515110209680 (0x10000002720C9890);
        // 0x00D77908: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7790C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77910: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D77914: B #0xd77980                | this.Trigger(_eventType:  1, arg:  53248); return;
        this.Trigger(_eventType:  1, arg:  53248);
        return;
        label_3:
        // 0x00D77918: MOV x8, sp                 | X8 = 1152921515110209664 (0x10000002720C9880);//ML01
        // 0x00D7791C: MOV x1, x21                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D77920: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D77924: LDR x0, [sp]               | X0 = val_1;                              //  find_add[1152921515110197728]
        // 0x00D77928: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
        // 0x00D7792C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77930: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00D77934: MOV x0, sp                 | X0 = 1152921515110209664 (0x10000002720C9880);//ML01
        // 0x00D77938: BL #0x299a140              | 
        label_5:
        // 0x00D7793C: ADD x8, sp, #8             | X8 = (1152921515110209664 + 8) = 1152921515110209672 (0x10000002720C9888);
        // 0x00D77940: MOV x1, x22                | X1 = ev.arg;//m1                        
        // 0x00D77944: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002720C9880, ????);
        // 0x00D77948: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921515110197728]
        // 0x00D7794C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
        // 0x00D77950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77954: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
        // 0x00D77958: ADD x0, sp, #8             | X0 = (1152921515110209664 + 8) = 1152921515110209672 (0x10000002720C9888);
        // 0x00D7795C: BL #0x299a140              | 
        // 0x00D77960: MOV x19, x0                | X19 = 1152921515110209672 (0x10000002720C9888);//ML01
        val_4;
        // 0x00D77964: MOV x0, sp                 | X0 = 1152921515110209664 (0x10000002720C9880);//ML01
        val_5;
        // 0x00D77968: B #0xd77974                |  goto label_7;                          
        goto label_7;
        // 0x00D7796C: MOV x19, x0                | X19 = 1152921515110209664 (0x10000002720C9880);//ML01
        val_4 = val_5;
        // 0x00D77970: ADD x0, sp, #8             | X0 = (1152921515110209664 + 8) = 1152921515110209672 (0x10000002720C9888);
        label_7:
        // 0x00D77974: BL #0x299a140              | 
        // 0x00D77978: MOV x0, x19                | X0 = 1152921515110209664 (0x10000002720C9880);//ML01
        // 0x00D7797C: BL #0x980800               | X0 = sub_980800( ?? 0x10000002720C9880, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77B80 (14121856), len: 212  VirtAddr: 0x00D77B80 RVA: 0x00D77B80 token: 100694126 methodIndex: 25810 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnBattleEnded(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00D77B80: STP x22, x21, [sp, #-0x30]! | stack[1152921515110342160] = ???;  stack[1152921515110342168] = ???;  //  dest_result_addr=1152921515110342160 |  dest_result_addr=1152921515110342168
        // 0x00D77B84: STP x20, x19, [sp, #0x10]  | stack[1152921515110342176] = ???;  stack[1152921515110342184] = ???;  //  dest_result_addr=1152921515110342176 |  dest_result_addr=1152921515110342184
        // 0x00D77B88: STP x29, x30, [sp, #0x20]  | stack[1152921515110342192] = ???;  stack[1152921515110342200] = ???;  //  dest_result_addr=1152921515110342192 |  dest_result_addr=1152921515110342200
        // 0x00D77B8C: ADD x29, sp, #0x20         | X29 = (1152921515110342160 + 32) = 1152921515110342192 (0x10000002720E9E30);
        // 0x00D77B90: SUB sp, sp, #0x10          | SP = (1152921515110342160 - 16) = 1152921515110342144 (0x10000002720E9E00);
        // 0x00D77B94: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D77B98: LDRB w8, [x21, #0x3eb]     | W8 = (bool)static_value_037343EB;       
        // 0x00D77B9C: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D77BA0: MOV x19, x0                | X19 = 1152921515110354208 (0x10000002720ECD20);//ML01
        // 0x00D77BA4: TBNZ w8, #0, #0xd77bc0     | if (static_value_037343EB == true) goto label_0;
        // 0x00D77BA8: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x00D77BAC: LDR x8, [x8, #0xb0]        | X8 = 0x2B90314;                         
        // 0x00D77BB0: LDR w0, [x8]               | W0 = 0x1789;                            
        // 0x00D77BB4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1789, ????);     
        // 0x00D77BB8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D77BBC: STRB w8, [x21, #0x3eb]     | static_value_037343EB = true;            //  dest_result_addr=57885675
        label_0:
        // 0x00D77BC0: CBNZ x20, #0xd77bc8        | if (ev != null) goto label_1;           
        if(ev != null)
        {
            goto label_1;
        }
        // 0x00D77BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1789, ????);     
        label_1:
        // 0x00D77BC8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00D77BCC: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        // 0x00D77BD0: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00D77BD4: LDR x20, [x8]              | X20 = typeof(System.Int32);             
        // 0x00D77BD8: CBNZ x21, #0xd77be0        | if (ev.arg != null) goto label_2;       
        if(ev.arg != null)
        {
            goto label_2;
        }
        // 0x00D77BDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1789, ????);     
        label_2:
        // 0x00D77BE0: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D77BE4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D77BE8: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D77BEC: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D77BF0: B.NE #0xd77c1c             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_3;
        // 0x00D77BF4: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D77BF8: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        ev.arg.System.IDisposable.Dispose();
        // 0x00D77BFC: LDR w2, [x0]               | W2 = typeof(System.Object);             
        // 0x00D77C00: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D77C04: MOV x0, x19                | X0 = 1152921515110354208 (0x10000002720ECD20);//ML01
        // 0x00D77C08: SUB sp, x29, #0x20         | SP = (1152921515110342192 - 32) = 1152921515110342160 (0x10000002720E9E10);
        // 0x00D77C0C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77C10: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77C14: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D77C18: B #0xd77980                | this.Trigger(_eventType:  2, arg:  53248); return;
        this.Trigger(_eventType:  2, arg:  53248);
        return;
        label_3:
        // 0x00D77C1C: ADD x8, sp, #8             | X8 = (1152921515110342144 + 8) = 1152921515110342152 (0x10000002720E9E08);
        // 0x00D77C20: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D77C24: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D77C28: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921515110330208]
        // 0x00D77C2C: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
        // 0x00D77C30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77C34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        // 0x00D77C38: ADD x0, sp, #8             | X0 = (1152921515110342144 + 8) = 1152921515110342152 (0x10000002720E9E08);
        // 0x00D77C3C: BL #0x299a140              | 
        // 0x00D77C40: MOV x19, x0                | X19 = 1152921515110342152 (0x10000002720E9E08);//ML01
        // 0x00D77C44: ADD x0, sp, #8             | X0 = (1152921515110342144 + 8) = 1152921515110342152 (0x10000002720E9E08);
        // 0x00D77C48: BL #0x299a140              | 
        // 0x00D77C4C: MOV x0, x19                | X0 = 1152921515110342152 (0x10000002720E9E08);//ML01
        // 0x00D77C50: BL #0x980800               | X0 = sub_980800( ?? 0x10000002720E9E08, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77C54 (14122068), len: 12  VirtAddr: 0x00D77C54 RVA: 0x00D77C54 token: 100694127 methodIndex: 25811 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnCombatWin(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        // 0x00D77C54: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00D77C58: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00D77C5C: B #0xd77980                | this.Trigger(_eventType:  4, arg:  0); return;
        this.Trigger(_eventType:  4, arg:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77C60 (14122080), len: 464  VirtAddr: 0x00D77C60 RVA: 0x00D77C60 token: 100694128 methodIndex: 25812 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEnterFuben(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_8;
        // 0x00D77C60: STP x24, x23, [sp, #-0x40]! | stack[1152921515110611200] = ???;  stack[1152921515110611208] = ???;  //  dest_result_addr=1152921515110611200 |  dest_result_addr=1152921515110611208
        // 0x00D77C64: STP x22, x21, [sp, #0x10]  | stack[1152921515110611216] = ???;  stack[1152921515110611224] = ???;  //  dest_result_addr=1152921515110611216 |  dest_result_addr=1152921515110611224
        // 0x00D77C68: STP x20, x19, [sp, #0x20]  | stack[1152921515110611232] = ???;  stack[1152921515110611240] = ???;  //  dest_result_addr=1152921515110611232 |  dest_result_addr=1152921515110611240
        // 0x00D77C6C: STP x29, x30, [sp, #0x30]  | stack[1152921515110611248] = ???;  stack[1152921515110611256] = ???;  //  dest_result_addr=1152921515110611248 |  dest_result_addr=1152921515110611256
        // 0x00D77C70: ADD x29, sp, #0x30         | X29 = (1152921515110611200 + 48) = 1152921515110611248 (0x100000027212B930);
        // 0x00D77C74: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D77C78: LDRB w8, [x20, #0x3ec]     | W8 = (bool)static_value_037343EC;       
        // 0x00D77C7C: MOV x19, x0                | X19 = 1152921515110623264 (0x100000027212E820);//ML01
        // 0x00D77C80: TBNZ w8, #0, #0xd77c9c     | if (static_value_037343EC == true) goto label_0;
        // 0x00D77C84: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
        // 0x00D77C88: LDR x8, [x8, #0xf10]       | X8 = 0x2B90328;                         
        // 0x00D77C8C: LDR w0, [x8]               | W0 = 0x178E;                            
        // 0x00D77C90: BL #0x2782188              | X0 = sub_2782188( ?? 0x178E, ????);     
        // 0x00D77C94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D77C98: STRB w8, [x20, #0x3ec]     | static_value_037343EC = true;            //  dest_result_addr=57885676
        label_0:
        // 0x00D77C9C: ADRP x23, #0x3668000       | X23 = 57049088 (0x3668000);             
        // 0x00D77CA0: LDR x23, [x23, #0x960]     | X23 = 1152921504911851520;              
        // 0x00D77CA4: LDR x0, [x23]              | X0 = typeof(ZMG);                       
        // 0x00D77CA8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D77CAC: TBZ w8, #0, #0xd77cbc      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D77CB0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D77CB4: CBNZ w8, #0xd77cbc         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D77CB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D77CBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D77CC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77CC4: BL #0x26a8140              | X0 = ZMG.get_SceneMgr();                
        SceneMgr val_1 = ZMG.SceneMgr;
        // 0x00D77CC8: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D77CCC: CBNZ x20, #0xd77cd4        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D77CD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D77CD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77CD8: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D77CDC: BL #0xca2b6c               | X0 = val_1.get_checkPoint();            
        checkpointCfg val_2 = val_1.checkPoint;
        // 0x00D77CE0: CBZ x0, #0xd77e10          | if (val_2 == null) goto label_4;        
        if(val_2 == null)
        {
            goto label_4;
        }
        // 0x00D77CE4: ADRP x20, #0x35f6000       | X20 = 56582144 (0x35F6000);             
        // 0x00D77CE8: LDR x20, [x20, #0x7e8]     | X20 = 1152921504909295616;              
        // 0x00D77CEC: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_8 = null;
        // 0x00D77CF0: LDRB w8, [x0, #0x10a]      | W8 = SceneMgr.__il2cppRuntimeField_10A; 
        // 0x00D77CF4: TBZ w8, #0, #0xd77d08      | if (SceneMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D77CF8: LDR w8, [x0, #0xbc]        | W8 = SceneMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00D77CFC: CBNZ w8, #0xd77d08         | if (SceneMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D77D00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SceneMgr), ????);
        // 0x00D77D04: LDR x0, [x20]              | X0 = typeof(SceneMgr);                  
        val_8 = null;
        label_6:
        // 0x00D77D08: ADRP x9, #0x367e000        | X9 = 57139200 (0x367E000);              
        // 0x00D77D0C: ADRP x10, #0x3658000       | X10 = 56983552 (0x3658000);             
        // 0x00D77D10: LDR x8, [x0, #0xa0]        | X8 = SceneMgr.__il2cppRuntimeField_static_fields;
        // 0x00D77D14: LDR x9, [x9, #0x8c0]       | X9 = 1152921515110068320;               
        // 0x00D77D18: LDR x10, [x10, #0x980]     | X10 = 1152921504898113536;              
        // 0x00D77D1C: LDR x20, [x8, #0x10]       | X20 = SceneMgr.SCENE_START_LOAD;        
        // 0x00D77D20: LDR x22, [x9]              | X22 = System.Void CameraShotMgr::OnQuitGame(CEvent.ZEvent ev);
        // 0x00D77D24: LDR x0, [x10]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_3 = null;
        // 0x00D77D28: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D77D2C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D77D30: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00D77D34: MOV x1, x19                | X1 = 1152921515110623264 (0x100000027212E820);//ML01
        // 0x00D77D38: MOV x2, x22                | X2 = 1152921515110068320 (0x10000002720A7060);//ML01
        // 0x00D77D3C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77D40: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D77D44: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnQuitGame(CEvent.ZEvent ev));
        val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnQuitGame(CEvent.ZEvent ev));
        // 0x00D77D48: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D77D4C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D77D50: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D77D54: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D77D58: TBZ w8, #0, #0xd77d68      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00D77D5C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D77D60: CBNZ w8, #0xd77d68         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00D77D64: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_8:
        // 0x00D77D68: MOV x1, x20                | X1 = SceneMgr.SCENE_START_LOAD;//m1     
        // 0x00D77D6C: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D77D70: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  SceneMgr.SCENE_START_LOAD);
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  SceneMgr.SCENE_START_LOAD);
        // 0x00D77D74: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00D77D78: LDR x8, [x8, #0xb88]       | X8 = 1152921504888635392;               
        // 0x00D77D7C: LDR x0, [x8]               | X0 = typeof(CameraAniCfgMgr);           
        // 0x00D77D80: LDRB w8, [x0, #0x10a]      | W8 = CameraAniCfgMgr.__il2cppRuntimeField_10A;
        // 0x00D77D84: TBZ w8, #0, #0xd77d94      | if (CameraAniCfgMgr.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00D77D88: LDR w8, [x0, #0xbc]        | W8 = CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00D77D8C: CBNZ w8, #0xd77d94         | if (CameraAniCfgMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00D77D90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraAniCfgMgr), ????);
        label_10:
        // 0x00D77D94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D77D98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77D9C: BL #0xba6c38               | X0 = CameraAniCfgMgr.get_instance();    
        CameraAniCfgMgr val_4 = CameraAniCfgMgr.instance;
        // 0x00D77DA0: LDR x8, [x23]              | X8 = typeof(ZMG);                       
        // 0x00D77DA4: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00D77DA8: LDRB w9, [x8, #0x10a]      | W9 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D77DAC: TBZ w9, #0, #0xd77dc0      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00D77DB0: LDR w9, [x8, #0xbc]        | W9 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D77DB4: CBNZ w9, #0xd77dc0         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00D77DB8: MOV x0, x8                 | X0 = 1152921504911851520 (0x10000000122E0000);//ML01
        // 0x00D77DBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_12:
        // 0x00D77DC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D77DC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77DC8: BL #0x26a8140              | X0 = ZMG.get_SceneMgr();                
        SceneMgr val_5 = ZMG.SceneMgr;
        // 0x00D77DCC: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00D77DD0: CBNZ x21, #0xd77dd8        | if (val_5 != null) goto label_13;       
        if(val_5 != null)
        {
            goto label_13;
        }
        // 0x00D77DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_13:
        // 0x00D77DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77DDC: MOV x0, x21                | X0 = val_5;//m1                         
        // 0x00D77DE0: BL #0xca2b6c               | X0 = val_5.get_checkPoint();            
        checkpointCfg val_6 = val_5.checkPoint;
        // 0x00D77DE4: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00D77DE8: CBNZ x21, #0xd77df0        | if (val_6 != null) goto label_14;       
        if(val_6 != null)
        {
            goto label_14;
        }
        // 0x00D77DEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_14:
        // 0x00D77DF0: LDR w21, [x21, #0x10]      | W21 = val_6.id; //P2                    
        // 0x00D77DF4: CBNZ x20, #0xd77dfc        | if (val_4 != null) goto label_15;       
        if(val_4 != null)
        {
            goto label_15;
        }
        // 0x00D77DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_15:
        // 0x00D77DFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D77E00: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00D77E04: MOV w1, w21                | W1 = val_6.id;//m1                      
        // 0x00D77E08: BL #0xba6ff4               | X0 = val_4.GetCameraAniMapByMapid(mapid:  val_6.id);
        CameraAniMap val_7 = val_4.GetCameraAniMapByMapid(mapid:  val_6.id);
        // 0x00D77E0C: STR x0, [x19, #0x10]       | this.curMapCameraAni = val_7;            //  dest_result_addr=1152921515110623280
        this.curMapCameraAni = val_7;
        label_4:
        // 0x00D77E10: MOV x0, x19                | X0 = 1152921515110623264 (0x100000027212E820);//ML01
        // 0x00D77E14: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77E18: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77E1C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D77E20: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00D77E24: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00D77E28: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D77E2C: B #0xd77980                | this.Trigger(_eventType:  3, arg:  0); return;
        this.Trigger(_eventType:  3, arg:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77980 (14121344), len: 512  VirtAddr: 0x00D77980 RVA: 0x00D77980 token: 100694129 methodIndex: 25813 delegateWrapperIndex: 0 methodInvoker: 0
    private void Trigger(triggerType _eventType, int arg)
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        //  | 
        var val_14;
        // 0x00D77980: STP x28, x27, [sp, #-0x60]! | stack[1152921515110782560] = ???;  stack[1152921515110782568] = ???;  //  dest_result_addr=1152921515110782560 |  dest_result_addr=1152921515110782568
        // 0x00D77984: STP x26, x25, [sp, #0x10]  | stack[1152921515110782576] = ???;  stack[1152921515110782584] = ???;  //  dest_result_addr=1152921515110782576 |  dest_result_addr=1152921515110782584
        // 0x00D77988: STP x24, x23, [sp, #0x20]  | stack[1152921515110782592] = ???;  stack[1152921515110782600] = ???;  //  dest_result_addr=1152921515110782592 |  dest_result_addr=1152921515110782600
        // 0x00D7798C: STP x22, x21, [sp, #0x30]  | stack[1152921515110782608] = ???;  stack[1152921515110782616] = ???;  //  dest_result_addr=1152921515110782608 |  dest_result_addr=1152921515110782616
        // 0x00D77990: STP x20, x19, [sp, #0x40]  | stack[1152921515110782624] = ???;  stack[1152921515110782632] = ???;  //  dest_result_addr=1152921515110782624 |  dest_result_addr=1152921515110782632
        // 0x00D77994: STP x29, x30, [sp, #0x50]  | stack[1152921515110782640] = ???;  stack[1152921515110782648] = ???;  //  dest_result_addr=1152921515110782640 |  dest_result_addr=1152921515110782648
        // 0x00D77998: ADD x29, sp, #0x50         | X29 = (1152921515110782560 + 80) = 1152921515110782640 (0x10000002721556B0);
        // 0x00D7799C: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D779A0: LDRB w8, [x22, #0x3ed]     | W8 = (bool)static_value_037343ED;       
        // 0x00D779A4: MOV w20, w2                | W20 = arg;//m1                          
        // 0x00D779A8: MOV w21, w1                | W21 = _eventType;//m1                   
        // 0x00D779AC: MOV x19, x0                | X19 = 1152921515110794656 (0x10000002721585A0);//ML01
        // 0x00D779B0: TBNZ w8, #0, #0xd779cc     | if (static_value_037343ED == true) goto label_0;
        // 0x00D779B4: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00D779B8: LDR x8, [x8, #0x698]       | X8 = 0x2B9036C;                         
        // 0x00D779BC: LDR w0, [x8]               | W0 = 0x179F;                            
        // 0x00D779C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x179F, ????);     
        // 0x00D779C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D779C8: STRB w8, [x22, #0x3ed]     | static_value_037343ED = true;            //  dest_result_addr=57885677
        label_0:
        // 0x00D779CC: LDR x0, [x19, #0x10]       | X0 = this.curMapCameraAni; //P2         
        // 0x00D779D0: CBZ x0, #0xd77b10          | if (this.curMapCameraAni == null) goto label_8;
        if(this.curMapCameraAni == null)
        {
            goto label_8;
        }
        // 0x00D779D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D779D8: BL #0xba716c               | X0 = this.curMapCameraAni.get_cameraAniGroups();
        System.Collections.Generic.List<CameraAniGroup> val_1 = this.curMapCameraAni.cameraAniGroups;
        // 0x00D779DC: ADRP x26, #0x3624000       | X26 = 56770560 (0x3624000);             
        // 0x00D779E0: ADRP x25, #0x3684000       | X25 = 57163776 (0x3684000);             
        // 0x00D779E4: LDR x26, [x26, #0x408]     | X26 = 1152921515110752224;              
        // 0x00D779E8: LDR x25, [x25, #0x240]     | X25 = 1152921515110753248;              
        // 0x00D779EC: MOV x23, x0                | X23 = val_1;//m1                        
        // 0x00D779F0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_13 = 0;
        // 0x00D779F4: ADD w8, w21, #7            | W8 = (_eventType + 7);                  
        triggerType val_2 = _eventType + 7;
        // 0x00D779F8: CMP w21, #5                | STATE = COMPARE(_eventType, 0x5)        
        // 0x00D779FC: ADRP x28, #0x2a97000       | X28 = 44658688 (0x2A97000);             
        // 0x00D77A00: CSEL w27, w8, wzr, lo      | W27 = _eventType < 0x5 ? (_eventType + 7) : 0;
        var val_3 = (_eventType < 5) ? (val_2) : 0;
        // 0x00D77A04: ADD x28, x28, #0xe4        | X28 = (44658688 + 228) = 44658916 (0x02A970E4);
        // 0x00D77A08: B #0xd77a10                |  goto label_2;                          
        goto label_2;
        label_14:
        // 0x00D77A0C: ADD w22, w22, #1           | W22 = (val_13 + 1) = val_13 (0x00000001);
        val_13 = 1;
        label_2:
        // 0x00D77A10: CBNZ x23, #0xd77a18        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D77A14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D77A18: LDR x1, [x26]              | X1 = public System.Int32 System.Collections.Generic.List<CameraAniGroup>::get_Count();
        // 0x00D77A1C: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x00D77A20: BL #0x25ed72c              | X0 = val_1.get_Count();                 
        int val_4 = val_1.Count;
        // 0x00D77A24: CMP w22, w0                | STATE = COMPARE(0x1, val_4)             
        // 0x00D77A28: B.GE #0xd77b10             | if (val_13 >= val_4) goto label_8;      
        if(val_13 >= val_4)
        {
            goto label_8;
        }
        // 0x00D77A2C: CBNZ x23, #0xd77a34        | if (val_1 != null) goto label_5;        
        if(val_1 != null)
        {
            goto label_5;
        }
        // 0x00D77A30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x00D77A34: LDR x2, [x25]              | X2 = public CameraAniGroup System.Collections.Generic.List<CameraAniGroup>::get_Item(int index);
        // 0x00D77A38: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x00D77A3C: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00D77A40: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        CameraAniGroup val_5 = val_1.Item[1];
        // 0x00D77A44: MOV x24, x0                | X24 = val_5;//m1                        
        // 0x00D77A48: CBNZ x24, #0xd77a50        | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x00D77A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x00D77A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77A54: MOV x0, x24                | X0 = val_5;//m1                         
        // 0x00D77A58: BL #0xba70ac               | X0 = val_5.get_eventType();             
        int val_6 = val_5.eventType;
        // 0x00D77A5C: CMP w0, w21                | STATE = COMPARE(val_6, _eventType)      
        // 0x00D77A60: B.NE #0xd77a0c             | if (val_6 != _eventType) goto label_14; 
        if(val_6 != _eventType)
        {
            goto label_14;
        }
        // 0x00D77A64: MOV w8, w27                | W8 = _eventType < 0x5 ? (_eventType + 7) : 0;//m1
        // 0x00D77A68: CMP w27, #0xb              | STATE = COMPARE(_eventType < 0x5 ? (_eventType + 7) : 0, 0xB)
        // 0x00D77A6C: B.HI #0xd77b10             | if (val_3 > 0xB) goto label_8;          
        if(val_3 > 11)
        {
            goto label_8;
        }
        // 0x00D77A70: LDRSW x8, [x28, x8, lsl #2] | X8 = 44658916 + (_eventType < 0x5 ? (_eventType + 7) : 0) << 2;
        var val_13 = 44658916 + (_eventType < 0x5 ? (_eventType + 7) : 0) << 2;
        // 0x00D77A74: ADD x8, x8, x28            | X8 = (44658916 + (_eventType < 0x5 ? (_eventType + 7) : 0) << 2 + 44658916);
        val_13 = val_13 + 44658916;
        // 0x00D77A78: BR x8                      | goto (44658916 + (_eventType < 0x5 ? (_eventType + 7) : 0) << 2 + 44658916);
        goto (44658916 + (_eventType < 0x5 ? (_eventType + 7) : 0) << 2 + 44658916);
        // 0x00D77A7C: CBNZ x23, #0xd77a84        | if (val_1 != null) goto label_9;        
        if(val_1 != null)
        {
            goto label_9;
        }
        // 0x00D77A80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_9:
        // 0x00D77A84: LDR x2, [x25]              | X2 = public CameraAniGroup System.Collections.Generic.List<CameraAniGroup>::get_Item(int index);
        // 0x00D77A88: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x00D77A8C: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00D77A90: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        CameraAniGroup val_7 = val_1.Item[1];
        // 0x00D77A94: MOV x24, x0                | X24 = val_7;//m1                        
        // 0x00D77A98: CBNZ x24, #0xd77aa0        | if (val_7 != null) goto label_10;       
        if(val_7 != null)
        {
            goto label_10;
        }
        // 0x00D77A9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_10:
        // 0x00D77AA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77AA4: MOV x0, x24                | X0 = val_7;//m1                         
        val_14 = val_7;
        // 0x00D77AA8: BL #0xba70cc               | X0 = val_7.get_id();                    
        int val_8 = val_14.id;
        // 0x00D77AAC: B #0xd77ae0                |  goto label_11;                         
        goto label_11;
        // 0x00D77AB0: CBNZ x23, #0xd77ab8        | if (val_1 != null) goto label_12;       
        if(val_1 != null)
        {
            goto label_12;
        }
        // 0x00D77AB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_12:
        // 0x00D77AB8: LDR x2, [x25]              | X2 = public CameraAniGroup System.Collections.Generic.List<CameraAniGroup>::get_Item(int index);
        // 0x00D77ABC: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x00D77AC0: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00D77AC4: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        CameraAniGroup val_9 = val_1.Item[1];
        // 0x00D77AC8: MOV x24, x0                | X24 = val_9;//m1                        
        // 0x00D77ACC: CBNZ x24, #0xd77ad4        | if (val_9 != null) goto label_13;       
        if(val_9 != null)
        {
            goto label_13;
        }
        // 0x00D77AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_13:
        // 0x00D77AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77AD8: MOV x0, x24                | X0 = val_9;//m1                         
        val_14 = val_9;
        // 0x00D77ADC: BL #0xba70bc               | X0 = val_9.get_round();                 
        int val_10 = val_14.round;
        label_11:
        // 0x00D77AE0: CMP w0, w20                | STATE = COMPARE(val_10, arg)            
        // 0x00D77AE4: B.NE #0xd77a0c             | if (val_10 != arg) goto label_14;       
        if(val_10 != arg)
        {
            goto label_14;
        }
        // 0x00D77AE8: LDRB w8, [x19, #0x34]      | W8 = this.isEditorRun; //P2             
        // 0x00D77AEC: CBZ w8, #0xd77b2c          | if (this.isEditorRun == false) goto label_15;
        if(this.isEditorRun == false)
        {
            goto label_15;
        }
        // 0x00D77AF0: MOV x0, x19                | X0 = 1152921515110794656 (0x10000002721585A0);//ML01
        // 0x00D77AF4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77AF8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77AFC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D77B00: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D77B04: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D77B08: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00D77B0C: B #0xd77e30                | this.PreviewCameraShot(); return;       
        this.PreviewCameraShot();
        return;
        label_8:
        // 0x00D77B10: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77B14: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77B18: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D77B1C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D77B20: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D77B24: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00D77B28: RET                        |  return;                                
        return;
        label_15:
        // 0x00D77B2C: CBNZ x23, #0xd77b34        | if (val_1 != null) goto label_16;       
        if(val_1 != null)
        {
            goto label_16;
        }
        // 0x00D77B30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_16:
        // 0x00D77B34: LDR x2, [x25]              | X2 = public CameraAniGroup System.Collections.Generic.List<CameraAniGroup>::get_Item(int index);
        // 0x00D77B38: MOV x0, x23                | X0 = val_1;//m1                         
        // 0x00D77B3C: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
        // 0x00D77B40: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        CameraAniGroup val_11 = val_1.Item[1];
        // 0x00D77B44: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00D77B48: CBNZ x20, #0xd77b50        | if (val_11 != null) goto label_17;      
        if(val_11 != null)
        {
            goto label_17;
        }
        // 0x00D77B4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_17:
        // 0x00D77B50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77B54: MOV x0, x20                | X0 = val_11;//m1                        
        // 0x00D77B58: BL #0xba709c               | X0 = val_11.get_startID();              
        int val_12 = val_11.startID;
        // 0x00D77B5C: MOV w1, w0                 | W1 = val_12;//m1                        
        // 0x00D77B60: MOV x0, x19                | X0 = 1152921515110794656 (0x10000002721585A0);//ML01
        // 0x00D77B64: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77B68: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D77B6C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D77B70: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D77B74: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D77B78: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00D77B7C: B #0xd77ec4                | this.PreviewCameraShot(cameraShotId:  val_12); return;
        this.PreviewCameraShot(cameraShotId:  val_12);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D780B8 (14123192), len: 28  VirtAddr: 0x00D780B8 RVA: 0x00D780B8 token: 100694130 methodIndex: 25814 delegateWrapperIndex: 0 methodInvoker: 0
    private int GetCameraShotId(int mapId, int cameraShotId)
    {
        //
        // Disasemble & Code
        // 0x00D780B8: MOVZ w8, #0x1, lsl #16     | W8 = 65536 (0x10000);//ML01             
        // 0x00D780BC: MOVK w8, #0x86a0           | W8 = 100000 (0x186A0);                  
        // 0x00D780C0: MUL w8, w1, w8             | W8 = (mapId * 100000);                  
        int val_1 = mapId * 100000;
        // 0x00D780C4: MOVZ w9, #0x3e8            | W9 = 1000 (0x3E8);//ML01                
        // 0x00D780C8: MADD w8, w2, w9, w8        | W8 = (cameraShotId * 1000) + (mapId * 100000);
        val_1 = val_1 + (cameraShotId * 1000);
        // 0x00D780CC: ORR w0, w8, #1             | W0 = ((cameraShotId * 1000) + (mapId * 100000) | 1);
        int val_2 = val_1 | 1;
        // 0x00D780D0: RET                        |  return (System.Int32)((cameraShotId * 1000) + (mapId * 100000) | 1);
        return val_2;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D780D4 (14123220), len: 28  VirtAddr: 0x00D780D4 RVA: 0x00D780D4 token: 100694131 methodIndex: 25815 delegateWrapperIndex: 0 methodInvoker: 0
    public void PreviewCameraShot(int mapId, int cameraShotId)
    {
        //
        // Disasemble & Code
        // 0x00D780D4: MOVZ w8, #0x1, lsl #16     | W8 = 65536 (0x10000);//ML01             
        // 0x00D780D8: MOVK w8, #0x86a0           | W8 = 100000 (0x186A0);                  
        // 0x00D780DC: MUL w8, w1, w8             | W8 = (mapId * 100000);                  
        int val_1 = mapId * 100000;
        // 0x00D780E0: MOVZ w9, #0x3e8            | W9 = 1000 (0x3E8);//ML01                
        // 0x00D780E4: MADD w8, w2, w9, w8        | W8 = (cameraShotId * 1000) + (mapId * 100000);
        val_1 = val_1 + (cameraShotId * 1000);
        // 0x00D780E8: ORR w1, w8, #1             | W1 = ((cameraShotId * 1000) + (mapId * 100000) | 1);
        mapId = val_1 | 1;
        // 0x00D780EC: B #0xd77ec4                | this.PreviewCameraShot(cameraShotId:  mapId = val_1 | 1); return;
        this.PreviewCameraShot(cameraShotId:  mapId);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D780F0 (14123248), len: 208  VirtAddr: 0x00D780F0 RVA: 0x00D780F0 token: 100694132 methodIndex: 25816 delegateWrapperIndex: 0 methodInvoker: 0
    public bool isCameraShotSkillFit(int effid, int scrid)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00D780F0: STP x22, x21, [sp, #-0x30]! | stack[1152921515111155472] = ???;  stack[1152921515111155480] = ???;  //  dest_result_addr=1152921515111155472 |  dest_result_addr=1152921515111155480
        // 0x00D780F4: STP x20, x19, [sp, #0x10]  | stack[1152921515111155488] = ???;  stack[1152921515111155496] = ???;  //  dest_result_addr=1152921515111155488 |  dest_result_addr=1152921515111155496
        // 0x00D780F8: STP x29, x30, [sp, #0x20]  | stack[1152921515111155504] = ???;  stack[1152921515111155512] = ???;  //  dest_result_addr=1152921515111155504 |  dest_result_addr=1152921515111155512
        // 0x00D780FC: ADD x29, sp, #0x20         | X29 = (1152921515111155472 + 32) = 1152921515111155504 (0x10000002721B0730);
        // 0x00D78100: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D78104: LDRB w8, [x22, #0x3ee]     | W8 = (bool)static_value_037343EE;       
        // 0x00D78108: MOV w19, w2                | W19 = scrid;//m1                        
        // 0x00D7810C: MOV w21, w1                | W21 = effid;//m1                        
        // 0x00D78110: MOV x20, x0                | X20 = 1152921515111167520 (0x10000002721B3620);//ML01
        // 0x00D78114: TBNZ w8, #0, #0xd78130     | if (static_value_037343EE == true) goto label_0;
        // 0x00D78118: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
        // 0x00D7811C: LDR x8, [x8, #0xa58]       | X8 = 0x2B90308;                         
        // 0x00D78120: LDR w0, [x8]               | W0 = 0x1786;                            
        // 0x00D78124: BL #0x2782188              | X0 = sub_2782188( ?? 0x1786, ????);     
        // 0x00D78128: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7812C: STRB w8, [x22, #0x3ee]     | static_value_037343EE = true;            //  dest_result_addr=57885678
        label_0:
        // 0x00D78130: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D78134: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D78138: LDR x22, [x20, #0x38]      | X22 = this.curSkillEntity; //P2         
        // 0x00D7813C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D78140: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D78144: TBZ w8, #0, #0xd78154      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D78148: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7814C: CBNZ w8, #0xd78154         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D78150: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00D78154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7815C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D78160: MOV x2, x22                | X2 = this.curSkillEntity;//m1           
        // 0x00D78164: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00D78168: TBZ w0, #0, #0xd781ac      | if (val_1 == false) goto label_7;       
        if(val_1 == false)
        {
            goto label_7;
        }
        // 0x00D7816C: LDR w8, [x20, #0x40]       | W8 = this.curEffectid; //P2             
        // 0x00D78170: CMP w8, w21                | STATE = COMPARE(this.curEffectid, effid)
        // 0x00D78174: B.NE #0xd781ac             | if (this.curEffectid != effid) goto label_7;
        if(this.curEffectid != effid)
        {
            goto label_7;
        }
        // 0x00D78178: LDR x20, [x20, #0x38]      | X20 = this.curSkillEntity; //P2         
        // 0x00D7817C: CBNZ x20, #0xd78184        | if (this.curSkillEntity != null) goto label_5;
        if(this.curSkillEntity != null)
        {
            goto label_5;
        }
        // 0x00D78180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D78184: LDR x20, [x20, #0x58]      | 
        // 0x00D78188: CBNZ x20, #0xd78190        | if (this.curSkillEntity != null) goto label_6;
        if(this.curSkillEntity != null)
        {
            goto label_6;
        }
        // 0x00D7818C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D78190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78194: MOV x0, x20                | X0 = this.curSkillEntity;//m1           
        // 0x00D78198: BL #0x1b78f0c              | X0 = this.curSkillEntity.GetInstanceID();
        int val_2 = this.curSkillEntity.GetInstanceID();
        // 0x00D7819C: CMP w0, w19                | STATE = COMPARE(val_2, scrid)           
        // 0x00D781A0: B.NE #0xd781ac             | if (val_2 != scrid) goto label_7;       
        if(val_2 != scrid)
        {
            goto label_7;
        }
        // 0x00D781A4: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_3 = 1;
        // 0x00D781A8: B #0xd781b0                |  goto label_8;                          
        goto label_8;
        label_7:
        // 0x00D781AC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_3 = 0;
        label_8:
        // 0x00D781B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D781B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D781B8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D781BC: RET                        |  return (System.Boolean)false;          
        return (bool)val_3;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77EC4 (14122692), len: 500  VirtAddr: 0x00D77EC4 RVA: 0x00D77EC4 token: 100694133 methodIndex: 25817 delegateWrapperIndex: 0 methodInvoker: 0
    public void PreviewCameraShot(int cameraShotId)
    {
        //
        // Disasemble & Code
        //  | 
        int val_10;
        // 0x00D77EC4: STP x28, x27, [sp, #-0x60]! | stack[1152921515111306336] = ???;  stack[1152921515111306344] = ???;  //  dest_result_addr=1152921515111306336 |  dest_result_addr=1152921515111306344
        // 0x00D77EC8: STP x26, x25, [sp, #0x10]  | stack[1152921515111306352] = ???;  stack[1152921515111306360] = ???;  //  dest_result_addr=1152921515111306352 |  dest_result_addr=1152921515111306360
        // 0x00D77ECC: STP x24, x23, [sp, #0x20]  | stack[1152921515111306368] = ???;  stack[1152921515111306376] = ???;  //  dest_result_addr=1152921515111306368 |  dest_result_addr=1152921515111306376
        // 0x00D77ED0: STP x22, x21, [sp, #0x30]  | stack[1152921515111306384] = ???;  stack[1152921515111306392] = ???;  //  dest_result_addr=1152921515111306384 |  dest_result_addr=1152921515111306392
        // 0x00D77ED4: STP x20, x19, [sp, #0x40]  | stack[1152921515111306400] = ???;  stack[1152921515111306408] = ???;  //  dest_result_addr=1152921515111306400 |  dest_result_addr=1152921515111306408
        // 0x00D77ED8: STP x29, x30, [sp, #0x50]  | stack[1152921515111306416] = ???;  stack[1152921515111306424] = ???;  //  dest_result_addr=1152921515111306416 |  dest_result_addr=1152921515111306424
        // 0x00D77EDC: ADD x29, sp, #0x50         | X29 = (1152921515111306336 + 80) = 1152921515111306416 (0x10000002721D54B0);
        // 0x00D77EE0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D77EE4: LDRB w8, [x21, #0x3ef]     | W8 = (bool)static_value_037343EF;       
        // 0x00D77EE8: MOV w19, w1                | W19 = cameraShotId;//m1                 
        // 0x00D77EEC: MOV x20, x0                | X20 = 1152921515111318432 (0x10000002721D83A0);//ML01
        // 0x00D77EF0: TBNZ w8, #0, #0xd77f0c     | if (static_value_037343EF == true) goto label_0;
        // 0x00D77EF4: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D77EF8: LDR x8, [x8, #0x880]       | X8 = 0x2B90360;                         
        // 0x00D77EFC: LDR w0, [x8]               | W0 = 0x179C;                            
        // 0x00D77F00: BL #0x2782188              | X0 = sub_2782188( ?? 0x179C, ????);     
        // 0x00D77F04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D77F08: STRB w8, [x21, #0x3ef]     | static_value_037343EF = true;            //  dest_result_addr=57885679
        label_0:
        // 0x00D77F0C: ADRP x24, #0x3668000       | X24 = 57049088 (0x3668000);             
        // 0x00D77F10: LDR x24, [x24, #0x960]     | X24 = 1152921504911851520;              
        // 0x00D77F14: LDR x0, [x24]              | X0 = typeof(ZMG);                       
        // 0x00D77F18: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D77F1C: TBZ w8, #0, #0xd77f2c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D77F20: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D77F24: CBNZ w8, #0xd77f2c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D77F28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D77F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D77F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77F34: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_1 = ZMG.CameraShotMgr;
        // 0x00D77F38: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00D77F3C: CBNZ x21, #0xd77f44        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D77F40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D77F44: LDRB w8, [x21, #0x44]      | W8 = val_1.isCameraShotRunning; //P2    
        // 0x00D77F48: CBZ w8, #0xd77f54          | if (val_1.isCameraShotRunning == false) goto label_4;
        if(val_1.isCameraShotRunning == false)
        {
            goto label_4;
        }
        // 0x00D77F4C: MOV x0, x20                | X0 = 1152921515111318432 (0x10000002721D83A0);//ML01
        // 0x00D77F50: BL #0xd781c0               | this.OnEnd();                           
        this.OnEnd();
        label_4:
        // 0x00D77F54: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
        // 0x00D77F58: LDR x22, [x22, #0x608]     | X22 = 1152921504616644608;              
        // 0x00D77F5C: LDR x0, [x22]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraShotVO> val_2 = null;
        // 0x00D77F60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00D77F64: ADRP x23, #0x3626000       | X23 = 56778752 (0x3626000);             
        // 0x00D77F68: LDR x23, [x23, #0xc8]      | X23 = 1152921515111267808;              
        // 0x00D77F6C: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00D77F70: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<CameraShotVO>::.ctor();
        // 0x00D77F74: BL #0x25e9474              | .ctor();                                
        val_2 = new System.Collections.Generic.List<CameraShotVO>();
        // 0x00D77F78: STR x21, [x20, #0x68]      | this.cameraShotQueue = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515111318536
        this.cameraShotQueue = val_2;
        // 0x00D77F7C: LDR x0, [x22]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraShotVO> val_3 = null;
        // 0x00D77F80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00D77F84: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<CameraShotVO>::.ctor();
        // 0x00D77F88: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00D77F8C: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<CameraShotVO>();
        // 0x00D77F90: MOV x0, x20                | X0 = 1152921515111318432 (0x10000002721D83A0);//ML01
        // 0x00D77F94: STR x21, [x20, #0x70]      | this.withQueue = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515111318544
        this.withQueue = val_3;
        // 0x00D77F98: BL #0xd786ec               | this.OnStart();                         
        this.OnStart();
        // 0x00D77F9C: ADRP x26, #0x3660000       | X26 = 57016320 (0x3660000);             
        // 0x00D77FA0: ADRP x27, #0x3676000       | X27 = 57106432 (0x3676000);             
        // 0x00D77FA4: LDR x26, [x26, #0xe28]     | X26 = 1152921504909881344;              
        // 0x00D77FA8: LDR x27, [x27, #0xc20]     | X27 = 1152921515111268832;              
        // 0x00D77FAC: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        var val_10 = 0;
        label_16:
        // 0x00D77FB0: LDR x0, [x24]              | X0 = typeof(ZMG);                       
        // 0x00D77FB4: ADD x8, x0, #0x109         | X8 = (null + 265) = 1152921504911851785 (0x10000000122E0109);
        // 0x00D77FB8: LDRH w8, [x8]              | W8 = ZMG.__il2cppRuntimeField_109;      
        // 0x00D77FBC: AND w8, w8, #0x100         | W8 = (ZMG.__il2cppRuntimeField_109 & 256);
        // 0x00D77FC0: AND w8, w8, #0xffff        | W8 = ((ZMG.__il2cppRuntimeField_109 & 256) & 65535);
        // 0x00D77FC4: CBZ w25, #0xd78010         | if (0x0 == 0) goto label_5;             
        if(val_10 == 0)
        {
            goto label_5;
        }
        // 0x00D77FC8: CBZ w8, #0xd77fd8          | if (((ZMG.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_7;
        // 0x00D77FCC: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D77FD0: CBNZ w8, #0xd77fd8         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00D77FD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_7:
        // 0x00D77FD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D77FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77FE0: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_6 = ZMG.CfgDataMgr;
        // 0x00D77FE4: LDR x22, [x20, #0x58]      | X22 = this.cameraShot_temp; //P2        
        // 0x00D77FE8: MOV x21, x0                | X21 = val_6;//m1                        
        // 0x00D77FEC: CBNZ x22, #0xd77ff4        | if (this.cameraShot_temp != null) goto label_8;
        if(this.cameraShot_temp != null)
        {
            goto label_8;
        }
        // 0x00D77FF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_8:
        // 0x00D77FF4: LDR w22, [x22, #0x14]      | W22 = this.cameraShot_temp.nextId; //P2 
        // 0x00D77FF8: CBNZ x21, #0xd78000        | if (val_6 != null) goto label_9;        
        if(val_6 != null)
        {
            goto label_9;
        }
        // 0x00D77FFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_9:
        // 0x00D78000: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D78004: MOV x0, x21                | X0 = val_6;//m1                         
        // 0x00D78008: MOV w1, w22                | W1 = this.cameraShot_temp.nextId;//m1   
        val_10 = this.cameraShot_temp.nextId;
        // 0x00D7800C: B #0xd78044                |  goto label_10;                         
        goto label_10;
        label_5:
        // 0x00D78010: CBZ w8, #0xd78020          | if (((ZMG.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_12;
        // 0x00D78014: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D78018: CBNZ w8, #0xd78020         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00D7801C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_12:
        // 0x00D78020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78024: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78028: BL #0x26a85a0              | X0 = ZMG.get_CfgDataMgr();              
        CSDatacfgManager val_7 = ZMG.CfgDataMgr;
        // 0x00D7802C: MOV x21, x0                | X21 = val_7;//m1                        
        // 0x00D78030: CBNZ x21, #0xd78038        | if (val_7 != null) goto label_13;       
        if(val_7 != null)
        {
            goto label_13;
        }
        // 0x00D78034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00D78038: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7803C: MOV x0, x21                | X0 = val_7;//m1                         
        // 0x00D78040: MOV w1, w19                | W1 = cameraShotId;//m1                  
        val_10 = cameraShotId;
        label_10:
        // 0x00D78044: BL #0xb47348               | X0 = val_7.GetcameraShotCfg(id:  val_10 = cameraShotId);
        cameraShotCfg val_8 = val_7.GetcameraShotCfg(id:  val_10);
        // 0x00D78048: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00D7804C: STR x22, [x20, #0x58]      | this.cameraShot_temp = val_8;            //  dest_result_addr=1152921515111318520
        this.cameraShot_temp = val_8;
        // 0x00D78050: LDR x0, [x26]              | X0 = typeof(CameraShotMgr.CameraShotVO);
        CameraShotMgr.CameraShotVO val_9 = null;
        // 0x00D78054: LDR x21, [x20, #0x68]      | X21 = this.cameraShotQueue; //P2        
        // 0x00D78058: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraShotMgr.CameraShotVO), ????);
        // 0x00D7805C: MOV x1, x22                | X1 = val_8;//m1                         
        // 0x00D78060: MOV x23, x0                | X23 = 1152921504909881344 (0x10000000120FF000);//ML01
        // 0x00D78064: BL #0xd78bd0               | .ctor(cfg:  val_8);                     
        val_9 = new CameraShotMgr.CameraShotVO(cfg:  val_8);
        // 0x00D78068: CBNZ x21, #0xd78070        | if (this.cameraShotQueue != null) goto label_14;
        if(this.cameraShotQueue != null)
        {
            goto label_14;
        }
        // 0x00D7806C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(cfg:  val_8), ????);
        label_14:
        // 0x00D78070: LDR x2, [x27]              | X2 = public System.Void System.Collections.Generic.List<CameraShotVO>::Add(CameraShotVO item);
        // 0x00D78074: MOV x0, x21                | X0 = this.cameraShotQueue;//m1          
        // 0x00D78078: MOV x1, x23                | X1 = 1152921504909881344 (0x10000000120FF000);//ML01
        // 0x00D7807C: BL #0x25ea480              | this.cameraShotQueue.Add(item:  val_9); 
        this.cameraShotQueue.Add(item:  val_9);
        // 0x00D78080: LDR x21, [x20, #0x58]      | X21 = this.cameraShot_temp; //P2        
        // 0x00D78084: CBNZ x21, #0xd7808c        | if (this.cameraShot_temp != null) goto label_15;
        if(this.cameraShot_temp != null)
        {
            goto label_15;
        }
        // 0x00D78088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.cameraShotQueue, ????);
        label_15:
        // 0x00D7808C: LDR w8, [x21, #0x14]       | W8 = this.cameraShot_temp.nextId; //P2  
        // 0x00D78090: SUB w25, w25, #1           | W25 = (0 - 1);                          
        val_10 = val_10 - 1;
        // 0x00D78094: CBNZ w8, #0xd77fb0         | if (this.cameraShot_temp.nextId != 0) goto label_16;
        if(this.cameraShot_temp.nextId != 0)
        {
            goto label_16;
        }
        // 0x00D78098: MOV x0, x20                | X0 = 1152921515111318432 (0x10000002721D83A0);//ML01
        // 0x00D7809C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00D780A0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00D780A4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00D780A8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00D780AC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00D780B0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00D780B4: B #0xd79714                | this.Execute(); return;                 
        this.Execute();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D77E30 (14122544), len: 148  VirtAddr: 0x00D77E30 RVA: 0x00D77E30 token: 100694134 methodIndex: 25818 delegateWrapperIndex: 0 methodInvoker: 0
    public void PreviewCameraShot()
    {
        //
        // Disasemble & Code
        // 0x00D77E30: STP x20, x19, [sp, #-0x20]! | stack[1152921515111451168] = ???;  stack[1152921515111451176] = ???;  //  dest_result_addr=1152921515111451168 |  dest_result_addr=1152921515111451176
        // 0x00D77E34: STP x29, x30, [sp, #0x10]  | stack[1152921515111451184] = ???;  stack[1152921515111451192] = ???;  //  dest_result_addr=1152921515111451184 |  dest_result_addr=1152921515111451192
        // 0x00D77E38: ADD x29, sp, #0x10         | X29 = (1152921515111451168 + 16) = 1152921515111451184 (0x10000002721F8A30);
        // 0x00D77E3C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D77E40: LDRB w8, [x20, #0x3f0]     | W8 = (bool)static_value_037343F0;       
        // 0x00D77E44: MOV x19, x0                | X19 = 1152921515111463200 (0x10000002721FB920);//ML01
        // 0x00D77E48: TBNZ w8, #0, #0xd77e64     | if (static_value_037343F0 == true) goto label_0;
        // 0x00D77E4C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D77E50: LDR x8, [x8, #0xe78]       | X8 = 0x2B9035C;                         
        // 0x00D77E54: LDR w0, [x8]               | W0 = 0x179B;                            
        // 0x00D77E58: BL #0x2782188              | X0 = sub_2782188( ?? 0x179B, ????);     
        // 0x00D77E5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D77E60: STRB w8, [x20, #0x3f0]     | static_value_037343F0 = true;            //  dest_result_addr=57885680
        label_0:
        // 0x00D77E64: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D77E68: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D77E6C: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D77E70: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D77E74: TBZ w8, #0, #0xd77e84      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D77E78: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D77E7C: CBNZ w8, #0xd77e84         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D77E80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D77E84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D77E88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D77E8C: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_1 = ZMG.CameraShotMgr;
        // 0x00D77E90: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D77E94: CBNZ x20, #0xd77e9c        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D77E98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D77E9C: LDRB w8, [x20, #0x44]      | W8 = val_1.isCameraShotRunning; //P2    
        // 0x00D77EA0: CBZ w8, #0xd77eac          | if (val_1.isCameraShotRunning == false) goto label_4;
        if(val_1.isCameraShotRunning == false)
        {
            goto label_4;
        }
        // 0x00D77EA4: MOV x0, x19                | X0 = 1152921515111463200 (0x10000002721FB920);//ML01
        // 0x00D77EA8: BL #0xd781c0               | this.OnEnd();                           
        this.OnEnd();
        label_4:
        // 0x00D77EAC: MOV x0, x19                | X0 = 1152921515111463200 (0x10000002721FB920);//ML01
        // 0x00D77EB0: BL #0xd786ec               | this.OnStart();                         
        this.OnStart();
        // 0x00D77EB4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D77EB8: MOV x0, x19                | X0 = 1152921515111463200 (0x10000002721FB920);//ML01
        // 0x00D77EBC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D77EC0: B #0xd79714                | this.Execute(); return;                 
        this.Execute();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7B8A8 (14137512), len: 372  VirtAddr: 0x00D7B8A8 RVA: 0x00D7B8A8 token: 100694135 methodIndex: 25819 delegateWrapperIndex: 0 methodInvoker: 0
    public void previewInEditor(cameraShotCfg[] cameraShotCfgList, CameraAniMap curAniMap)
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00D7B8A8: STP x26, x25, [sp, #-0x50]! | stack[1152921515111620464] = ???;  stack[1152921515111620472] = ???;  //  dest_result_addr=1152921515111620464 |  dest_result_addr=1152921515111620472
        // 0x00D7B8AC: STP x24, x23, [sp, #0x10]  | stack[1152921515111620480] = ???;  stack[1152921515111620488] = ???;  //  dest_result_addr=1152921515111620480 |  dest_result_addr=1152921515111620488
        // 0x00D7B8B0: STP x22, x21, [sp, #0x20]  | stack[1152921515111620496] = ???;  stack[1152921515111620504] = ???;  //  dest_result_addr=1152921515111620496 |  dest_result_addr=1152921515111620504
        // 0x00D7B8B4: STP x20, x19, [sp, #0x30]  | stack[1152921515111620512] = ???;  stack[1152921515111620520] = ???;  //  dest_result_addr=1152921515111620512 |  dest_result_addr=1152921515111620520
        // 0x00D7B8B8: STP x29, x30, [sp, #0x40]  | stack[1152921515111620528] = ???;  stack[1152921515111620536] = ???;  //  dest_result_addr=1152921515111620528 |  dest_result_addr=1152921515111620536
        // 0x00D7B8BC: ADD x29, sp, #0x40         | X29 = (1152921515111620464 + 64) = 1152921515111620528 (0x1000000272221FB0);
        // 0x00D7B8C0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7B8C4: LDRB w8, [x21, #0x3f1]     | W8 = (bool)static_value_037343F1;       
        // 0x00D7B8C8: MOV x19, x1                | X19 = cameraShotCfgList;//m1            
        // 0x00D7B8CC: MOV x20, x0                | X20 = 1152921515111632544 (0x1000000272224EA0);//ML01
        // 0x00D7B8D0: TBNZ w8, #0, #0xd7b8ec     | if (static_value_037343F1 == true) goto label_0;
        // 0x00D7B8D4: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
        // 0x00D7B8D8: LDR x8, [x8, #0xe20]       | X8 = 0x2B90364;                         
        // 0x00D7B8DC: LDR w0, [x8]               | W0 = 0x179D;                            
        // 0x00D7B8E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x179D, ????);     
        // 0x00D7B8E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7B8E8: STRB w8, [x21, #0x3f1]     | static_value_037343F1 = true;            //  dest_result_addr=57885681
        label_0:
        // 0x00D7B8EC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7B8F0: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7B8F4: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D7B8F8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7B8FC: TBZ w8, #0, #0xd7b90c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7B900: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7B904: CBNZ w8, #0xd7b90c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7B908: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D7B90C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7B910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7B914: BL #0x26a87d0              | X0 = ZMG.get_CameraShotMgr();           
        CameraShotMgr val_1 = ZMG.CameraShotMgr;
        // 0x00D7B918: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x00D7B91C: CBNZ x21, #0xd7b924        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D7B920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D7B924: LDRB w8, [x21, #0x44]      | W8 = val_1.isCameraShotRunning; //P2    
        // 0x00D7B928: CBZ w8, #0xd7b934          | if (val_1.isCameraShotRunning == false) goto label_4;
        if(val_1.isCameraShotRunning == false)
        {
            goto label_4;
        }
        // 0x00D7B92C: MOV x0, x20                | X0 = 1152921515111632544 (0x1000000272224EA0);//ML01
        // 0x00D7B930: BL #0xd781c0               | this.OnEnd();                           
        this.OnEnd();
        label_4:
        // 0x00D7B934: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
        // 0x00D7B938: LDR x22, [x22, #0x608]     | X22 = 1152921504616644608;              
        // 0x00D7B93C: LDR x0, [x22]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraShotVO> val_2 = null;
        // 0x00D7B940: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00D7B944: ADRP x23, #0x3626000       | X23 = 56778752 (0x3626000);             
        // 0x00D7B948: LDR x23, [x23, #0xc8]      | X23 = 1152921515111267808;              
        // 0x00D7B94C: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00D7B950: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<CameraShotVO>::.ctor();
        // 0x00D7B954: BL #0x25e9474              | .ctor();                                
        val_2 = new System.Collections.Generic.List<CameraShotVO>();
        // 0x00D7B958: STR x21, [x20, #0x68]      | this.cameraShotQueue = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515111632648
        this.cameraShotQueue = val_2;
        // 0x00D7B95C: LDR x0, [x22]              | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraShotVO> val_3 = null;
        // 0x00D7B960: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00D7B964: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<CameraShotVO>::.ctor();
        // 0x00D7B968: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00D7B96C: BL #0x25e9474              | .ctor();                                
        val_3 = new System.Collections.Generic.List<CameraShotVO>();
        // 0x00D7B970: MOV x0, x20                | X0 = 1152921515111632544 (0x1000000272224EA0);//ML01
        // 0x00D7B974: STR x21, [x20, #0x70]      | this.withQueue = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921515111632656
        this.withQueue = val_3;
        // 0x00D7B978: BL #0xd786ec               | this.OnStart();                         
        this.OnStart();
        // 0x00D7B97C: ADRP x25, #0x3660000       | X25 = 57016320 (0x3660000);             
        // 0x00D7B980: ADRP x26, #0x3676000       | X26 = 57106432 (0x3676000);             
        // 0x00D7B984: LDR x25, [x25, #0xe28]     | X25 = 1152921504909881344;              
        // 0x00D7B988: LDR x26, [x26, #0xc20]     | X26 = 1152921515111268832;              
        // 0x00D7B98C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00D7B990: B #0xd7b9a8                |  goto label_5;                          
        goto label_5;
        label_10:
        // 0x00D7B994: LDR x2, [x26]              | X2 = public System.Void System.Collections.Generic.List<CameraShotVO>::Add(CameraShotVO item);
        // 0x00D7B998: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00D7B99C: MOV x1, x22                | X1 = 57995264 (0x374F000);//ML01        
        // 0x00D7B9A0: BL #0x25ea480              | Add(item:  1152921504616644608);        
        Add(item:  1152921504616644608);
        // 0x00D7B9A4: ADD w24, w24, #1           | W24 = (val_5 + 1) = val_5 (0x00000001); 
        val_5 = 1;
        label_5:
        // 0x00D7B9A8: CBNZ x19, #0xd7b9b0        | if (cameraShotCfgList != null) goto label_6;
        if(cameraShotCfgList != null)
        {
            goto label_6;
        }
        // 0x00D7B9AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
        label_6:
        // 0x00D7B9B0: LDR w8, [x19, #0x18]       | W8 = cameraShotCfgList.Length; //P2     
        // 0x00D7B9B4: CMP w24, w8                | STATE = COMPARE(0x1, cameraShotCfgList.Length)
        // 0x00D7B9B8: B.GE #0xd7ba00             | if (val_5 >= cameraShotCfgList.Length) goto label_7;
        if(val_5 >= cameraShotCfgList.Length)
        {
            goto label_7;
        }
        // 0x00D7B9BC: LDR x21, [x20, #0x68]      | X21 = this.cameraShotQueue; //P2        
        // 0x00D7B9C0: SXTW x22, w24              | X22 = 1 (0x00000001);                   
        // 0x00D7B9C4: CMP w24, w8                | STATE = COMPARE(0x1, cameraShotCfgList.Length)
        // 0x00D7B9C8: B.LO #0xd7b9d8             | if (val_5 < cameraShotCfgList.Length) goto label_8;
        if(val_5 < cameraShotCfgList.Length)
        {
            goto label_8;
        }
        // 0x00D7B9CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00D7B9D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7B9D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Collections.Generic.List<T>), ????);
        label_8:
        // 0x00D7B9D8: ADD x8, x19, x22, lsl #3   | X8 = cameraShotCfgList[0x1]; //PARR1    
        // 0x00D7B9DC: LDR x0, [x25]              | X0 = typeof(CameraShotMgr.CameraShotVO);
        CameraShotMgr.CameraShotVO val_4 = null;
        // 0x00D7B9E0: LDR x23, [x8, #0x20]       | X23 = cameraShotCfgList[0x1][0]         
        cameraShotCfg val_5 = cameraShotCfgList[1];
        // 0x00D7B9E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CameraShotMgr.CameraShotVO), ????);
        // 0x00D7B9E8: MOV x1, x23                | X1 = cameraShotCfgList[0x1][0];//m1     
        // 0x00D7B9EC: MOV x22, x0                | X22 = 1152921504909881344 (0x10000000120FF000);//ML01
        // 0x00D7B9F0: BL #0xd78bd0               | .ctor(cfg:  cameraShotCfgList[1]);      
        val_4 = new CameraShotMgr.CameraShotVO(cfg:  val_5);
        // 0x00D7B9F4: CBNZ x21, #0xd7b994        | if (this.cameraShotQueue != null) goto label_10;
        if(this.cameraShotQueue != null)
        {
            goto label_10;
        }
        // 0x00D7B9F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(cfg:  cameraShotCfgList[1]), ????);
        // 0x00D7B9FC: B #0xd7b994                |  goto label_10;                         
        goto label_10;
        label_7:
        // 0x00D7BA00: MOV x0, x20                | X0 = 1152921515111632544 (0x1000000272224EA0);//ML01
        // 0x00D7BA04: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7BA08: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7BA0C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7BA10: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00D7BA14: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00D7BA18: B #0xd79714                | this.Execute(); return;                 
        this.Execute();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7BA1C (14137884), len: 2732  VirtAddr: 0x00D7BA1C RVA: 0x00D7BA1C token: 100694136 methodIndex: 25820 delegateWrapperIndex: 0 methodInvoker: 0
    private int returnCameraShotId(FunType funtype, object arg)
    {
        //
        // Disasemble & Code
        //  | 
        var val_25;
        //  | 
        var val_26;
        //  | 
        var val_27;
        //  | 
        var val_28;
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_32;
        //  | 
        var val_33;
        //  | 
        var val_34;
        //  | 
        var val_35;
        //  | 
        var val_36;
        //  | 
        object val_37;
        //  | 
        var val_38;
        //  | 
        string val_39;
        //  | 
        var val_40;
        //  | 
        var val_41;
        //  | 
        var val_42;
        //  | 
        var val_43;
        //  | 
        var val_44;
        // 0x00D7BA1C: STP d9, d8, [sp, #-0x70]!  | stack[1152921515111945520] = ???;  stack[1152921515111945528] = ???;  //  dest_result_addr=1152921515111945520 |  dest_result_addr=1152921515111945528
        // 0x00D7BA20: STP x28, x27, [sp, #0x10]  | stack[1152921515111945536] = ???;  stack[1152921515111945544] = ???;  //  dest_result_addr=1152921515111945536 |  dest_result_addr=1152921515111945544
        // 0x00D7BA24: STP x26, x25, [sp, #0x20]  | stack[1152921515111945552] = ???;  stack[1152921515111945560] = ???;  //  dest_result_addr=1152921515111945552 |  dest_result_addr=1152921515111945560
        // 0x00D7BA28: STP x24, x23, [sp, #0x30]  | stack[1152921515111945568] = ???;  stack[1152921515111945576] = ???;  //  dest_result_addr=1152921515111945568 |  dest_result_addr=1152921515111945576
        // 0x00D7BA2C: STP x22, x21, [sp, #0x40]  | stack[1152921515111945584] = ???;  stack[1152921515111945592] = ???;  //  dest_result_addr=1152921515111945584 |  dest_result_addr=1152921515111945592
        // 0x00D7BA30: STP x20, x19, [sp, #0x50]  | stack[1152921515111945600] = ???;  stack[1152921515111945608] = ???;  //  dest_result_addr=1152921515111945600 |  dest_result_addr=1152921515111945608
        // 0x00D7BA34: STP x29, x30, [sp, #0x60]  | stack[1152921515111945616] = ???;  stack[1152921515111945624] = ???;  //  dest_result_addr=1152921515111945616 |  dest_result_addr=1152921515111945624
        // 0x00D7BA38: ADD x29, sp, #0x60         | X29 = (1152921515111945520 + 96) = 1152921515111945616 (0x1000000272271590);
        // 0x00D7BA3C: SUB sp, sp, #0x60          | SP = (1152921515111945520 - 96) = 1152921515111945424 (0x10000002722714D0);
        // 0x00D7BA40: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
        // 0x00D7BA44: LDRB w8, [x22, #0x3f2]     | W8 = (bool)static_value_037343F2;       
        // 0x00D7BA48: MOV x20, x2                | X20 = arg;//m1                          
        // 0x00D7BA4C: MOV w21, w1                | W21 = funtype;//m1                      
        val_36 = funtype;
        // 0x00D7BA50: MOV x19, x0                | X19 = 1152921515111957632 (0x1000000272274480);//ML01
        val_37 = this;
        // 0x00D7BA54: TBNZ w8, #0, #0xd7ba70     | if (static_value_037343F2 == true) goto label_0;
        // 0x00D7BA58: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D7BA5C: LDR x8, [x8, #0xf28]       | X8 = 0x2B90368;                         
        // 0x00D7BA60: LDR w0, [x8]               | W0 = 0x179E;                            
        // 0x00D7BA64: BL #0x2782188              | X0 = sub_2782188( ?? 0x179E, ????);     
        // 0x00D7BA68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7BA6C: STRB w8, [x22, #0x3f2]     | static_value_037343F2 = true;            //  dest_result_addr=57885682
        label_0:
        // 0x00D7BA70: ADRP x24, #0x35c4000       | X24 = 56377344 (0x35C4000);             
        // 0x00D7BA74: LDR x24, [x24, #0x5d0]     | X24 = 1152921515111781984;              
        // 0x00D7BA78: MOVN w23, #0               | W23 = 0 (0x0);//ML01                    
        label_2:
        // 0x00D7BA7C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BA80: CBNZ x22, #0xd7ba88        | if (this.withQueue != null) goto label_1;
        if(this.withQueue != null)
        {
            goto label_1;
        }
        // 0x00D7BA84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x179E, ????);     
        label_1:
        // 0x00D7BA88: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BA8C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BA90: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = this.withQueue.Count;
        // 0x00D7BA94: ADD w23, w23, #1           | W23 = (0 + 1);                          
        val_38 = 0 + 1;
        // 0x00D7BA98: CMP w23, w0                | STATE = COMPARE((0 + 1), val_1)         
        // 0x00D7BA9C: B.LT #0xd7ba7c             | if (val_38 < val_1) goto label_2;       
        if(val_38 < val_1)
        {
            goto label_2;
        }
        // 0x00D7BAA0: CMP w21, #0x11             | STATE = COMPARE(funtype, 0x11)          
        // 0x00D7BAA4: B.HI #0xd7c26c             | if (val_36 > 0x11) goto label_96;       
        if(val_36 > 17)
        {
            goto label_96;
        }
        // 0x00D7BAA8: ADRP x8, #0x2a97000        | X8 = 44658688 (0x2A97000);              
        // 0x00D7BAAC: ADD x8, x8, #0x2e0         | X8 = (44658688 + 736) = 44659424 (0x02A972E0);
        // 0x00D7BAB0: LDR w8, [x8, w21, sxtw #2] | W8 = 44659424 + (funtype) << 2;         
        var val_36 = 44659424 + (funtype) << 2;
        // 0x00D7BAB4: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
        val_39 = 0;
        // 0x00D7BAB8: SUB w8, w8, #5             | W8 = (44659424 + (funtype) << 2 - 5);   
        val_36 = val_36 - 5;
        // 0x00D7BABC: CMP w8, #0xa               | STATE = COMPARE((44659424 + (funtype) << 2 - 5), 0xA)
        // 0x00D7BAC0: B.HI #0xd7c270             | if (44659424 + (funtype) << 2 > 0xA) goto label_104;
        if(val_36 > 10)
        {
            goto label_104;
        }
        // 0x00D7BAC4: ADRP x9, #0x2a97000        | X9 = 44658688 (0x2A97000);              
        // 0x00D7BAC8: ADD x9, x9, #0x1e0         | X9 = (44658688 + 480) = 44659168 (0x02A971E0);
        // 0x00D7BACC: LDRSW x8, [x9, x8, lsl #2] | X8 = 44659168 + ((44659424 + (funtype) << 2 - 5)) << 2;
        var val_37 = 44659168 + ((44659424 + (funtype) << 2 - 5)) << 2;
        // 0x00D7BAD0: ADD x8, x8, x9             | X8 = (44659168 + ((44659424 + (funtype) << 2 - 5)) << 2 + 44659168);
        val_37 = val_37 + 44659168;
        // 0x00D7BAD4: BR x8                      | goto (44659168 + ((44659424 + (funtype) << 2 - 5)) << 2 + 44659168);
        goto (44659168 + ((44659424 + (funtype) << 2 - 5)) << 2 + 44659168);
        // 0x00D7BAD8: ADRP x26, #0x3652000       | X26 = 56958976 (0x3652000);             
        // 0x00D7BADC: ADRP x25, #0x367a000       | X25 = 57122816 (0x367A000);             
        // 0x00D7BAE0: ADRP x27, #0x35cc000       | X27 = 56410112 (0x35CC000);             
        // 0x00D7BAE4: ADRP x28, #0x3662000       | X28 = 57024512 (0x3662000);             
        // 0x00D7BAE8: LDR x26, [x26, #0x140]     | X26 = 1152921504607113216;              
        // 0x00D7BAEC: LDR x25, [x25, #0xc38]     | X25 = 1152921512949758048;              
        val_40 = 1152921512949758048;
        // 0x00D7BAF0: LDR x27, [x27, #0xde0]     | X27 = 1152921504898379776;              
        val_41 = 1152921504898379776;
        // 0x00D7BAF4: LDR x28, [x28, #0x560]     | X28 = (string**)(1152921513302392240)("CAMERASHOT_MOVE_COMPLETE");
        // 0x00D7BAF8: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BAFC: B #0xd7bb10                |  goto label_5;                          
        goto label_5;
        label_15:
        // 0x00D7BB00: LDR x1, [x28]              | X1 = "CAMERASHOT_MOVE_COMPLETE";        
        // 0x00D7BB04: MOV x2, x22                | X2 = this.withQueue;//m1                
        // 0x00D7BB08: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_39 = 0, func:  "CAMERASHOT_MOVE_COMPLETE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_39, func:  "CAMERASHOT_MOVE_COMPLETE");
        // 0x00D7BB0C: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_5:
        // 0x00D7BB10: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BB14: CBNZ x22, #0xd7bb1c        | if (this.withQueue != null) goto label_6;
        if(this.withQueue != null)
        {
            goto label_6;
        }
        // 0x00D7BB18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x00D7BB1C: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BB20: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BB24: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_2 = this.withQueue.Count;
        // 0x00D7BB28: CMP w21, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00D7BB2C: B.GE #0xd7c26c             | if (val_36 >= val_2) goto label_96;     
        if(val_36 >= val_2)
        {
            goto label_96;
        }
        // 0x00D7BB30: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BB34: CBNZ x22, #0xd7bb3c        | if (this.withQueue != null) goto label_8;
        if(this.withQueue != null)
        {
            goto label_8;
        }
        // 0x00D7BB38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_8:
        // 0x00D7BB3C: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00D7BB40: LDR x8, [x8, #0x6e0]       | X8 = 1152921515111795296;               
        // 0x00D7BB44: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BB48: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7BB4C: LDR x2, [x8]               | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7BB50: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_3 = this.withQueue.Item[1];
        // 0x00D7BB54: MOV x22, x0                | X22 = val_3;//m1                        
        // 0x00D7BB58: CBNZ x22, #0xd7bb60        | if (val_3 != null) goto label_9;        
        if(val_3 != null)
        {
            goto label_9;
        }
        // 0x00D7BB5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_9:
        // 0x00D7BB60: LDR w23, [x22, #0x10]      | W23 = val_3.id; //P2                    
        // 0x00D7BB64: LDR x22, [x26]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7BB68: CBNZ x20, #0xd7bb70        | if (arg != null) goto label_10;         
        if(arg != null)
        {
            goto label_10;
        }
        // 0x00D7BB6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_10:
        // 0x00D7BB70: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BB74: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BB78: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7BB7C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7BB80: B.NE #0xd7c2b0             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_11;
        // 0x00D7BB84: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BB88: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BB8C: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7BB90: CMP w23, w8                | STATE = COMPARE(val_3.id, typeof(System.Object))
        // 0x00D7BB94: B.EQ #0xd7c294             | if (val_3.id == typeof(System.Object)) goto label_12;
        if(val_3.id == null)
        {
            goto label_12;
        }
        // 0x00D7BB98: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00D7BB9C: LDR x8, [x8, #0xde0]       | X8 = 1152921515111800416;               
        // 0x00D7BBA0: LDR x23, [x8]              | X23 = System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev);
        // 0x00D7BBA4: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00D7BBA8: LDR x8, [x8, #0x980]       | X8 = 1152921504898113536;               
        // 0x00D7BBAC: LDR x0, [x8]               | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00D7BBB0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7BBB4: LDR x3, [x25]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7BBB8: MOV x1, x19                | X1 = 1152921515111957632 (0x1000000272274480);//ML01
        // 0x00D7BBBC: MOV x2, x23                | X2 = 1152921515111800416 (0x100000027224DE60);//ML01
        // 0x00D7BBC0: MOV x22, x0                | X22 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7BBC4: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        // 0x00D7BBC8: LDR x0, [x27]              | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D7BBCC: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D7BBD0: TBZ w8, #0, #0xd7bb00      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00D7BBD4: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D7BBD8: CBNZ w8, #0xd7bb00         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00D7BBDC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        // 0x00D7BBE0: B #0xd7bb00                |  goto label_15;                         
        goto label_15;
        // 0x00D7BBE4: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7BBE8: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7BBEC: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7BBF0: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7BBF4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BBF8: B #0xd7bc00                |  goto label_16;                         
        goto label_16;
        label_23:
        // 0x00D7BBFC: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_16:
        // 0x00D7BC00: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BC04: CBNZ x22, #0xd7bc0c        | if (this.withQueue != null) goto label_17;
        if(this.withQueue != null)
        {
            goto label_17;
        }
        // 0x00D7BC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CEvent.ZEventCenter), ????);
        label_17:
        // 0x00D7BC0C: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BC10: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BC14: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_5 = this.withQueue.Count;
        // 0x00D7BC18: CMP w21, w0                | STATE = COMPARE(0x1, val_5)             
        // 0x00D7BC1C: B.GE #0xd7c26c             | if (val_36 >= val_5) goto label_96;     
        if(val_36 >= val_5)
        {
            goto label_96;
        }
        // 0x00D7BC20: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BC24: CBNZ x22, #0xd7bc2c        | if (this.withQueue != null) goto label_19;
        if(this.withQueue != null)
        {
            goto label_19;
        }
        // 0x00D7BC28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_19:
        // 0x00D7BC2C: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7BC30: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BC34: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7BC38: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_6 = this.withQueue.Item[1];
        // 0x00D7BC3C: MOV x22, x0                | X22 = val_6;//m1                        
        // 0x00D7BC40: CBNZ x22, #0xd7bc48        | if (val_6 != null) goto label_20;       
        if(val_6 != null)
        {
            goto label_20;
        }
        // 0x00D7BC44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_20:
        // 0x00D7BC48: LDR w26, [x22, #0x10]      | W26 = val_6.id; //P2                    
        // 0x00D7BC4C: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7BC50: CBNZ x20, #0xd7bc58        | if (arg != null) goto label_21;         
        if(arg != null)
        {
            goto label_21;
        }
        // 0x00D7BC54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_21:
        // 0x00D7BC58: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BC5C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BC60: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7BC64: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7BC68: B.NE #0xd7c2d4             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_22;
        // 0x00D7BC6C: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BC70: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BC74: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7BC78: CMP w26, w8                | STATE = COMPARE(val_6.id, typeof(System.Object))
        // 0x00D7BC7C: B.NE #0xd7bbfc             | if (val_6.id != typeof(System.Object)) goto label_23;
        if(val_6.id != null)
        {
            goto label_23;
        }
        // 0x00D7BC80: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7BC84: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7BC88: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7BC8C: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7BC90: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7BC94: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BC98: B #0xd7bca0                |  goto label_25;                         
        goto label_25;
        label_32:
        // 0x00D7BC9C: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_25:
        // 0x00D7BCA0: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BCA4: CBNZ x22, #0xd7bcac        | if (this.withQueue != null) goto label_26;
        if(this.withQueue != null)
        {
            goto label_26;
        }
        // 0x00D7BCA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_26:
        // 0x00D7BCAC: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BCB0: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BCB4: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_7 = this.withQueue.Count;
        // 0x00D7BCB8: CMP w21, w0                | STATE = COMPARE(0x1, val_7)             
        // 0x00D7BCBC: B.GE #0xd7c26c             | if (val_36 >= val_7) goto label_96;     
        if(val_36 >= val_7)
        {
            goto label_96;
        }
        // 0x00D7BCC0: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BCC4: CBNZ x22, #0xd7bccc        | if (this.withQueue != null) goto label_28;
        if(this.withQueue != null)
        {
            goto label_28;
        }
        // 0x00D7BCC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_28:
        // 0x00D7BCCC: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7BCD0: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BCD4: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7BCD8: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_8 = this.withQueue.Item[1];
        // 0x00D7BCDC: MOV x22, x0                | X22 = val_8;//m1                        
        // 0x00D7BCE0: CBNZ x22, #0xd7bce8        | if (val_8 != null) goto label_29;       
        if(val_8 != null)
        {
            goto label_29;
        }
        // 0x00D7BCE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_29:
        // 0x00D7BCE8: LDR w26, [x22, #0x90]      | W26 = val_8.heroOrNpcId; //P2           
        // 0x00D7BCEC: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7BCF0: CBNZ x20, #0xd7bcf8        | if (arg != null) goto label_30;         
        if(arg != null)
        {
            goto label_30;
        }
        // 0x00D7BCF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_30:
        // 0x00D7BCF8: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BCFC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BD00: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7BD04: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7BD08: B.NE #0xd7c2f8             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_31;
        // 0x00D7BD0C: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BD10: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BD14: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7BD18: CMP w26, w8                | STATE = COMPARE(val_8.heroOrNpcId, typeof(System.Object))
        // 0x00D7BD1C: B.NE #0xd7bc9c             | if (val_8.heroOrNpcId != typeof(System.Object)) goto label_32;
        if(val_8.heroOrNpcId != null)
        {
            goto label_32;
        }
        // 0x00D7BD20: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7BD24: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7BD28: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7BD2C: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7BD30: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7BD34: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BD38: B #0xd7bd40                |  goto label_34;                         
        goto label_34;
        label_41:
        // 0x00D7BD3C: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_34:
        // 0x00D7BD40: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BD44: CBNZ x22, #0xd7bd4c        | if (this.withQueue != null) goto label_35;
        if(this.withQueue != null)
        {
            goto label_35;
        }
        // 0x00D7BD48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_35:
        // 0x00D7BD4C: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BD50: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BD54: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_9 = this.withQueue.Count;
        // 0x00D7BD58: CMP w21, w0                | STATE = COMPARE(0x1, val_9)             
        // 0x00D7BD5C: B.GE #0xd7c26c             | if (val_36 >= val_9) goto label_96;     
        if(val_36 >= val_9)
        {
            goto label_96;
        }
        // 0x00D7BD60: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BD64: CBNZ x22, #0xd7bd6c        | if (this.withQueue != null) goto label_37;
        if(this.withQueue != null)
        {
            goto label_37;
        }
        // 0x00D7BD68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_37:
        // 0x00D7BD6C: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7BD70: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BD74: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7BD78: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_10 = this.withQueue.Item[1];
        // 0x00D7BD7C: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00D7BD80: CBNZ x22, #0xd7bd88        | if (val_10 != null) goto label_38;      
        if(val_10 != null)
        {
            goto label_38;
        }
        // 0x00D7BD84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_38:
        // 0x00D7BD88: LDR w26, [x22, #0x80]      | W26 = val_10.storyId; //P2              
        // 0x00D7BD8C: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7BD90: CBNZ x20, #0xd7bd98        | if (arg != null) goto label_39;         
        if(arg != null)
        {
            goto label_39;
        }
        // 0x00D7BD94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_39:
        // 0x00D7BD98: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BD9C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BDA0: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7BDA4: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7BDA8: B.NE #0xd7c31c             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_40;
        // 0x00D7BDAC: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BDB0: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BDB4: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7BDB8: CMP w26, w8                | STATE = COMPARE(val_10.storyId, typeof(System.Object))
        // 0x00D7BDBC: B.NE #0xd7bd3c             | if (val_10.storyId != typeof(System.Object)) goto label_41;
        if(val_10.storyId != null)
        {
            goto label_41;
        }
        // 0x00D7BDC0: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7BDC4: ADRP x25, #0x35e6000       | X25 = 56516608 (0x35E6000);             
        // 0x00D7BDC8: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
        // 0x00D7BDCC: ADRP x27, #0x35f6000       | X27 = 56582144 (0x35F6000);             
        // 0x00D7BDD0: ADRP x28, #0x3618000       | X28 = 56721408 (0x3618000);             
        // 0x00D7BDD4: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7BDD8: LDR x25, [x25, #0xce8]     | X25 = 1152921504608444416;              
        val_40 = 1152921504608444416;
        // 0x00D7BDDC: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
        // 0x00D7BDE0: LDR x27, [x27, #0xf48]     | X27 = (string**)(1152921515111838304)("(float)arg ");
        val_41 = "(float)arg ";
        // 0x00D7BDE4: LDR x28, [x28, #0x530]     | X28 = 1152921504924098560;              
        // 0x00D7BDE8: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7BDEC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BDF0: B #0xd7bdf8                |  goto label_43;                         
        goto label_43;
        label_56:
        // 0x00D7BDF4: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_43:
        // 0x00D7BDF8: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BDFC: CBNZ x22, #0xd7be04        | if (this.withQueue != null) goto label_44;
        if(this.withQueue != null)
        {
            goto label_44;
        }
        // 0x00D7BE00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_44:
        // 0x00D7BE04: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BE08: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BE0C: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_11 = this.withQueue.Count;
        // 0x00D7BE10: CMP w21, w0                | STATE = COMPARE(0x1, val_11)            
        // 0x00D7BE14: B.GE #0xd7c26c             | if (val_36 >= val_11) goto label_96;    
        if(val_36 >= val_11)
        {
            goto label_96;
        }
        // 0x00D7BE18: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_42 = null;
        // 0x00D7BE1C: CBNZ x20, #0xd7be24        | if (arg != null) goto label_46;         
        if(arg != null)
        {
            goto label_46;
        }
        // 0x00D7BE20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_46:
        // 0x00D7BE24: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BE28: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BE2C: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00D7BE30: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00D7BE34: B.NE #0xd7c340             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_47;
        // 0x00D7BE38: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BE3C: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BE40: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7BE44: LDR x0, [x25]              | X0 = typeof(System.Single);             
        // 0x00D7BE48: ADD x1, sp, #4             | X1 = (1152921515111945424 + 4) = 1152921515111945428 (0x10000002722714D4);
        // 0x00D7BE4C: STR w8, [sp, #4]           | stack[1152921515111945428] = typeof(System.Object);  //  dest_result_addr=1152921515111945428
        // 0x00D7BE50: BL #0x27bc028              | X0 = 1152921515112056192 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), typeof(System.Object));
        // 0x00D7BE54: LDR x8, [x26]              | X8 = typeof(System.String);             
        // 0x00D7BE58: MOV x22, x0                | X22 = 1152921515112056192 (0x100000027228C580);//ML01
        // 0x00D7BE5C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00D7BE60: TBZ w9, #0, #0xd7be74      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_49;
        // 0x00D7BE64: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D7BE68: CBNZ w9, #0xd7be74         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
        // 0x00D7BE6C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00D7BE70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_49:
        // 0x00D7BE74: LDR x1, [x27]              | X1 = "(float)arg ";                     
        // 0x00D7BE78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7BE7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7BE80: MOV x2, x22                | X2 = 1152921515112056192 (0x100000027228C580);//ML01
        // 0x00D7BE84: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "(float)arg ");
        string val_12 = System.String.Concat(arg0:  0, arg1:  "(float)arg ");
        // 0x00D7BE88: LDR x8, [x28]              | X8 = typeof(EDebug);                    
        // 0x00D7BE8C: MOV x22, x0                | X22 = val_12;//m1                       
        // 0x00D7BE90: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7BE94: TBZ w9, #0, #0xd7bea8      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_51;
        // 0x00D7BE98: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7BE9C: CBNZ w9, #0xd7bea8         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
        // 0x00D7BEA0: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00D7BEA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_51:
        // 0x00D7BEA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7BEAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7BEB0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7BEB4: MOV x1, x22                | X1 = val_12;//m1                        
        // 0x00D7BEB8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_12);
        EDebug.Log(message:  0, isShowStack:  val_12);
        // 0x00D7BEBC: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BEC0: CBNZ x22, #0xd7bec8        | if (this.withQueue != null) goto label_52;
        if(this.withQueue != null)
        {
            goto label_52;
        }
        // 0x00D7BEC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_52:
        // 0x00D7BEC8: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7BECC: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BED0: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7BED4: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_13 = this.withQueue.Item[1];
        // 0x00D7BED8: MOV x22, x0                | X22 = val_13;//m1                       
        // 0x00D7BEDC: CBNZ x22, #0xd7bee4        | if (val_13 != null) goto label_53;      
        if(val_13 != null)
        {
            goto label_53;
        }
        // 0x00D7BEE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_53:
        // 0x00D7BEE4: LDR s8, [x22, #0xd0]       | S8 = val_13.waitTime; //P2              
        // 0x00D7BEE8: LDR x22, [x25]             | X22 = typeof(System.Single);            
        val_42 = null;
        // 0x00D7BEEC: CBNZ x20, #0xd7bef4        | if (arg != null) goto label_54;         
        if(arg != null)
        {
            goto label_54;
        }
        // 0x00D7BEF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_54:
        // 0x00D7BEF4: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BEF8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BEFC: LDR x8, [x22, #0x30]       | X8 = System.Single.__il2cppRuntimeField_element_class;
        // 0x00D7BF00: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Single.__il2cppRuntimeField_element_class)
        // 0x00D7BF04: B.NE #0xd7c418             | if (System.Object.__il2cppRuntimeField_element_class != System.Single.__il2cppRuntimeField_element_class) goto label_55;
        // 0x00D7BF08: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BF0C: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BF10: LDR s0, [x0]               | S0 = typeof(System.Object);             
        // 0x00D7BF14: FCMP s8, s0                | STATE = COMPARE(val_13.waitTime, typeof(System.Object))
        // 0x00D7BF18: B.NE #0xd7bdf4             | if (val_13.waitTime != typeof(System.Object)) goto label_56;
        if(val_13.waitTime != null)
        {
            goto label_56;
        }
        // 0x00D7BF1C: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7BF20: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7BF24: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7BF28: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7BF2C: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7BF30: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BF34: B #0xd7bf3c                |  goto label_58;                         
        goto label_58;
        label_65:
        // 0x00D7BF38: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_58:
        // 0x00D7BF3C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BF40: CBNZ x22, #0xd7bf48        | if (this.withQueue != null) goto label_59;
        if(this.withQueue != null)
        {
            goto label_59;
        }
        // 0x00D7BF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_59:
        // 0x00D7BF48: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BF4C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BF50: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_14 = this.withQueue.Count;
        // 0x00D7BF54: CMP w21, w0                | STATE = COMPARE(0x1, val_14)            
        // 0x00D7BF58: B.GE #0xd7c26c             | if (val_36 >= val_14) goto label_96;    
        if(val_36 >= val_14)
        {
            goto label_96;
        }
        // 0x00D7BF5C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BF60: CBNZ x22, #0xd7bf68        | if (this.withQueue != null) goto label_61;
        if(this.withQueue != null)
        {
            goto label_61;
        }
        // 0x00D7BF64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_61:
        // 0x00D7BF68: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7BF6C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BF70: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7BF74: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_15 = this.withQueue.Item[1];
        // 0x00D7BF78: MOV x22, x0                | X22 = val_15;//m1                       
        // 0x00D7BF7C: CBNZ x22, #0xd7bf84        | if (val_15 != null) goto label_62;      
        if(val_15 != null)
        {
            goto label_62;
        }
        // 0x00D7BF80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_62:
        // 0x00D7BF84: LDR w26, [x22, #0xe8]      | W26 = val_15.circle_TargetId; //P2      
        // 0x00D7BF88: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7BF8C: CBNZ x20, #0xd7bf94        | if (arg != null) goto label_63;         
        if(arg != null)
        {
            goto label_63;
        }
        // 0x00D7BF90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_63:
        // 0x00D7BF94: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7BF98: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7BF9C: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7BFA0: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7BFA4: B.NE #0xd7c364             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_64;
        // 0x00D7BFA8: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7BFAC: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7BFB0: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7BFB4: CMP w26, w8                | STATE = COMPARE(val_15.circle_TargetId, typeof(System.Object))
        // 0x00D7BFB8: B.NE #0xd7bf38             | if (val_15.circle_TargetId != typeof(System.Object)) goto label_65;
        if(val_15.circle_TargetId != null)
        {
            goto label_65;
        }
        // 0x00D7BFBC: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7BFC0: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7BFC4: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7BFC8: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7BFCC: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7BFD0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7BFD4: B #0xd7bfdc                |  goto label_67;                         
        goto label_67;
        label_74:
        // 0x00D7BFD8: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_67:
        // 0x00D7BFDC: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7BFE0: CBNZ x22, #0xd7bfe8        | if (this.withQueue != null) goto label_68;
        if(this.withQueue != null)
        {
            goto label_68;
        }
        // 0x00D7BFE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_68:
        // 0x00D7BFE8: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7BFEC: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7BFF0: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_16 = this.withQueue.Count;
        // 0x00D7BFF4: CMP w21, w0                | STATE = COMPARE(0x1, val_16)            
        // 0x00D7BFF8: B.GE #0xd7c26c             | if (val_36 >= val_16) goto label_96;    
        if(val_36 >= val_16)
        {
            goto label_96;
        }
        // 0x00D7BFFC: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C000: CBNZ x22, #0xd7c008        | if (this.withQueue != null) goto label_70;
        if(this.withQueue != null)
        {
            goto label_70;
        }
        // 0x00D7C004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_70:
        // 0x00D7C008: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C00C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C010: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7C014: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_17 = this.withQueue.Item[1];
        // 0x00D7C018: MOV x22, x0                | X22 = val_17;//m1                       
        // 0x00D7C01C: CBNZ x22, #0xd7c024        | if (val_17 != null) goto label_71;      
        if(val_17 != null)
        {
            goto label_71;
        }
        // 0x00D7C020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_71:
        // 0x00D7C024: LDR w26, [x22, #0x90]      | W26 = val_17.heroOrNpcId; //P2          
        // 0x00D7C028: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7C02C: CBNZ x20, #0xd7c034        | if (arg != null) goto label_72;         
        if(arg != null)
        {
            goto label_72;
        }
        // 0x00D7C030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_72:
        // 0x00D7C034: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7C038: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C03C: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7C040: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7C044: B.NE #0xd7c388             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_73;
        // 0x00D7C048: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7C04C: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7C050: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7C054: CMP w26, w8                | STATE = COMPARE(val_17.heroOrNpcId, typeof(System.Object))
        // 0x00D7C058: B.NE #0xd7bfd8             | if (val_17.heroOrNpcId != typeof(System.Object)) goto label_74;
        if(val_17.heroOrNpcId != null)
        {
            goto label_74;
        }
        // 0x00D7C05C: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7C060: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7C064: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7C068: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7C06C: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7C070: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7C074: B #0xd7c07c                |  goto label_76;                         
        goto label_76;
        label_83:
        // 0x00D7C078: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_76:
        // 0x00D7C07C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C080: CBNZ x22, #0xd7c088        | if (this.withQueue != null) goto label_77;
        if(this.withQueue != null)
        {
            goto label_77;
        }
        // 0x00D7C084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_77:
        // 0x00D7C088: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7C08C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C090: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_18 = this.withQueue.Count;
        // 0x00D7C094: CMP w21, w0                | STATE = COMPARE(0x1, val_18)            
        // 0x00D7C098: B.GE #0xd7c26c             | if (val_36 >= val_18) goto label_96;    
        if(val_36 >= val_18)
        {
            goto label_96;
        }
        // 0x00D7C09C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C0A0: CBNZ x22, #0xd7c0a8        | if (this.withQueue != null) goto label_79;
        if(this.withQueue != null)
        {
            goto label_79;
        }
        // 0x00D7C0A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_79:
        // 0x00D7C0A8: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C0AC: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C0B0: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7C0B4: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_19 = this.withQueue.Item[1];
        // 0x00D7C0B8: MOV x22, x0                | X22 = val_19;//m1                       
        // 0x00D7C0BC: CBNZ x22, #0xd7c0c4        | if (val_19 != null) goto label_80;      
        if(val_19 != null)
        {
            goto label_80;
        }
        // 0x00D7C0C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_80:
        // 0x00D7C0C4: LDR w26, [x22, #0xa8]      | W26 = val_19.skillId; //P2              
        // 0x00D7C0C8: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7C0CC: CBNZ x20, #0xd7c0d4        | if (arg != null) goto label_81;         
        if(arg != null)
        {
            goto label_81;
        }
        // 0x00D7C0D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_81:
        // 0x00D7C0D4: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7C0D8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C0DC: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7C0E0: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7C0E4: B.NE #0xd7c3ac             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_82;
        // 0x00D7C0E8: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7C0EC: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7C0F0: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7C0F4: CMP w26, w8                | STATE = COMPARE(val_19.skillId, typeof(System.Object))
        // 0x00D7C0F8: B.NE #0xd7c078             | if (val_19.skillId != typeof(System.Object)) goto label_83;
        if(val_19.skillId != null)
        {
            goto label_83;
        }
        // 0x00D7C0FC: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7C100: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7C104: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7C108: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7C10C: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7C110: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7C114: B #0xd7c11c                |  goto label_85;                         
        goto label_85;
        label_92:
        // 0x00D7C118: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_85:
        // 0x00D7C11C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C120: CBNZ x22, #0xd7c128        | if (this.withQueue != null) goto label_86;
        if(this.withQueue != null)
        {
            goto label_86;
        }
        // 0x00D7C124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_86:
        // 0x00D7C128: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7C12C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C130: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_20 = this.withQueue.Count;
        // 0x00D7C134: CMP w21, w0                | STATE = COMPARE(0x1, val_20)            
        // 0x00D7C138: B.GE #0xd7c26c             | if (val_36 >= val_20) goto label_96;    
        if(val_36 >= val_20)
        {
            goto label_96;
        }
        // 0x00D7C13C: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C140: CBNZ x22, #0xd7c148        | if (this.withQueue != null) goto label_88;
        if(this.withQueue != null)
        {
            goto label_88;
        }
        // 0x00D7C144: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_88:
        // 0x00D7C148: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C14C: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C150: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7C154: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_21 = this.withQueue.Item[1];
        // 0x00D7C158: MOV x22, x0                | X22 = val_21;//m1                       
        // 0x00D7C15C: CBNZ x22, #0xd7c164        | if (val_21 != null) goto label_89;      
        if(val_21 != null)
        {
            goto label_89;
        }
        // 0x00D7C160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_89:
        // 0x00D7C164: LDR w26, [x22, #0x10]      | W26 = val_21.id; //P2                   
        // 0x00D7C168: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7C16C: CBNZ x20, #0xd7c174        | if (arg != null) goto label_90;         
        if(arg != null)
        {
            goto label_90;
        }
        // 0x00D7C170: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_90:
        // 0x00D7C174: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7C178: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C17C: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7C180: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7C184: B.NE #0xd7c3d0             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_91;
        // 0x00D7C188: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7C18C: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7C190: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7C194: CMP w26, w8                | STATE = COMPARE(val_21.id, typeof(System.Object))
        // 0x00D7C198: B.NE #0xd7c118             | if (val_21.id != typeof(System.Object)) goto label_92;
        if(val_21.id != null)
        {
            goto label_92;
        }
        // 0x00D7C19C: B #0xd7c23c                |  goto label_93;                         
        goto label_93;
        // 0x00D7C1A0: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7C1A4: ADRP x25, #0x3652000       | X25 = 56958976 (0x3652000);             
        // 0x00D7C1A8: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        val_38 = 1152921515111795296;
        // 0x00D7C1AC: LDR x25, [x25, #0x140]     | X25 = 1152921504607113216;              
        val_40 = 1152921504607113216;
        // 0x00D7C1B0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_36 = 0;
        // 0x00D7C1B4: B #0xd7c1bc                |  goto label_94;                         
        goto label_94;
        label_101:
        // 0x00D7C1B8: ADD w21, w21, #1           | W21 = (val_36 + 1) = val_36 (0x00000001);
        val_36 = 1;
        label_94:
        // 0x00D7C1BC: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C1C0: CBNZ x22, #0xd7c1c8        | if (this.withQueue != null) goto label_95;
        if(this.withQueue != null)
        {
            goto label_95;
        }
        // 0x00D7C1C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_95:
        // 0x00D7C1C8: LDR x1, [x24]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7C1CC: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C1D0: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_22 = this.withQueue.Count;
        // 0x00D7C1D4: CMP w21, w0                | STATE = COMPARE(0x1, val_22)            
        // 0x00D7C1D8: B.GE #0xd7c26c             | if (val_36 >= val_22) goto label_96;    
        if(val_36 >= val_22)
        {
            goto label_96;
        }
        // 0x00D7C1DC: LDR x22, [x19, #0x70]      | X22 = this.withQueue; //P2              
        // 0x00D7C1E0: CBNZ x22, #0xd7c1e8        | if (this.withQueue != null) goto label_97;
        if(this.withQueue != null)
        {
            goto label_97;
        }
        // 0x00D7C1E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_97:
        // 0x00D7C1E8: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C1EC: MOV x0, x22                | X0 = this.withQueue;//m1                
        // 0x00D7C1F0: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7C1F4: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_23 = this.withQueue.Item[1];
        // 0x00D7C1F8: MOV x22, x0                | X22 = val_23;//m1                       
        // 0x00D7C1FC: CBNZ x22, #0xd7c204        | if (val_23 != null) goto label_98;      
        if(val_23 != null)
        {
            goto label_98;
        }
        // 0x00D7C200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_98:
        // 0x00D7C204: LDR w26, [x22, #0x10]      | W26 = val_23.id; //P2                   
        // 0x00D7C208: LDR x22, [x25]             | X22 = typeof(System.Int32);             
        val_42 = null;
        // 0x00D7C20C: CBNZ x20, #0xd7c214        | if (arg != null) goto label_99;         
        if(arg != null)
        {
            goto label_99;
        }
        // 0x00D7C210: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
        label_99:
        // 0x00D7C214: LDR x8, [x20]              | X8 = typeof(System.Object);             
        // 0x00D7C218: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C21C: LDR x8, [x22, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7C220: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7C224: B.NE #0xd7c3f4             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_100;
        // 0x00D7C228: MOV x0, x20                | X0 = arg;//m1                           
        // 0x00D7C22C: BL #0x27bc4e8              | arg.System.IDisposable.Dispose();       
        arg.System.IDisposable.Dispose();
        // 0x00D7C230: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7C234: CMP w26, w8                | STATE = COMPARE(val_23.id, typeof(System.Object))
        // 0x00D7C238: B.NE #0xd7c1b8             | if (val_23.id != typeof(System.Object)) goto label_101;
        if(val_23.id != null)
        {
            goto label_101;
        }
        label_93:
        // 0x00D7C23C: LDR x19, [x19, #0x70]      | X19 = this.withQueue; //P2              
        // 0x00D7C240: CBNZ x19, #0xd7c248        | if (this.withQueue != null) goto label_102;
        if(this.withQueue != null)
        {
            goto label_102;
        }
        // 0x00D7C244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_102:
        // 0x00D7C248: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        label_106:
        // 0x00D7C24C: MOV x0, x19                | X0 = this.withQueue;//m1                
        // 0x00D7C250: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00D7C254: BL #0x25ed734              | X0 = this.withQueue.get_Item(index:  1);
        CameraShotVO val_24 = this.withQueue.Item[1];
        // 0x00D7C258: MOV x19, x0                | X19 = val_24;//m1                       
        val_37 = val_24;
        // 0x00D7C25C: CBNZ x19, #0xd7c264        | if (val_24 != null) goto label_103;     
        if(val_37 != null)
        {
            goto label_103;
        }
        // 0x00D7C260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_103:
        // 0x00D7C264: LDR w0, [x19, #0x10]       | W0 = val_24.id; //P2                    
        val_39 = val_24.id;
        // 0x00D7C268: B #0xd7c270                |  goto label_104;                        
        goto label_104;
        label_96:
        // 0x00D7C26C: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
        val_39 = 0;
        label_104:
        // 0x00D7C270: SUB sp, x29, #0x60         | SP = (1152921515111945616 - 96) = 1152921515111945520 (0x1000000272271530);
        // 0x00D7C274: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C278: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C27C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7C280: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
        // 0x00D7C284: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
        // 0x00D7C288: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
        // 0x00D7C28C: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
        // 0x00D7C290: RET                        |  return (System.Int32)0;                
        return (int)val_39;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        label_12:
        // 0x00D7C294: LDR x19, [x19, #0x70]      | X19 = this.withQueue; //P2              
        // 0x00D7C298: CBNZ x19, #0xd7c2a0        | if (this.withQueue != null) goto label_105;
        if(this.withQueue != null)
        {
            goto label_105;
        }
        // 0x00D7C29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? arg, ????);        
        label_105:
        // 0x00D7C2A0: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00D7C2A4: LDR x8, [x8, #0x6e0]       | X8 = 1152921515111795296;               
        // 0x00D7C2A8: LDR x2, [x8]               | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C2AC: B #0xd7c24c                |  goto label_106;                        
        goto label_106;
        label_11:
        // 0x00D7C2B0: ADD x8, sp, #0x30          | X8 = (1152921515111945424 + 48) = 1152921515111945472 (0x1000000272271500);
        // 0x00D7C2B4: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C2B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7C2BC: LDR x0, [sp, #0x30]        | X0 = val_25;                             //  find_add[1152921515111933632]
        // 0x00D7C2C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_25, ????);     
        // 0x00D7C2C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C2C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_25, ????);     
        // 0x00D7C2CC: ADD x0, sp, #0x30          | X0 = (1152921515111945424 + 48) = 1152921515111945472 (0x1000000272271500);
        // 0x00D7C2D0: BL #0x299a140              | 
        label_22:
        // 0x00D7C2D4: ADD x8, sp, #0x50          | X8 = (1152921515111945424 + 80) = 1152921515111945504 (0x1000000272271520);
        // 0x00D7C2D8: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C2DC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000272271500, ????);
        // 0x00D7C2E0: LDR x0, [sp, #0x50]        | X0 = val_26;                             //  find_add[1152921515111933632]
        // 0x00D7C2E4: BL #0x27af090              | X0 = sub_27AF090( ?? val_26, ????);     
        // 0x00D7C2E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C2EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
        // 0x00D7C2F0: ADD x0, sp, #0x50          | X0 = (1152921515111945424 + 80) = 1152921515111945504 (0x1000000272271520);
        // 0x00D7C2F4: BL #0x299a140              | 
        label_31:
        // 0x00D7C2F8: ADD x8, sp, #0x18          | X8 = (1152921515111945424 + 24) = 1152921515111945448 (0x10000002722714E8);
        // 0x00D7C2FC: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C300: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000272271520, ????);
        // 0x00D7C304: LDR x0, [sp, #0x18]        | X0 = val_27;                             //  find_add[1152921515111933632]
        // 0x00D7C308: BL #0x27af090              | X0 = sub_27AF090( ?? val_27, ????);     
        // 0x00D7C30C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C310: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
        // 0x00D7C314: ADD x0, sp, #0x18          | X0 = (1152921515111945424 + 24) = 1152921515111945448 (0x10000002722714E8);
        // 0x00D7C318: BL #0x299a140              | 
        label_40:
        // 0x00D7C31C: ADD x8, sp, #0x10          | X8 = (1152921515111945424 + 16) = 1152921515111945440 (0x10000002722714E0);
        // 0x00D7C320: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C324: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002722714E8, ????);
        // 0x00D7C328: LDR x0, [sp, #0x10]        | X0 = val_28;                             //  find_add[1152921515111933632]
        // 0x00D7C32C: BL #0x27af090              | X0 = sub_27AF090( ?? val_28, ????);     
        // 0x00D7C330: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C334: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
        // 0x00D7C338: ADD x0, sp, #0x10          | X0 = (1152921515111945424 + 16) = 1152921515111945440 (0x10000002722714E0);
        // 0x00D7C33C: BL #0x299a140              | 
        label_47:
        // 0x00D7C340: ADD x8, sp, #0x20          | X8 = (1152921515111945424 + 32) = 1152921515111945456 (0x10000002722714F0);
        // 0x00D7C344: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C348: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002722714E0, ????);
        // 0x00D7C34C: LDR x0, [sp, #0x20]        | X0 = val_29;                             //  find_add[1152921515111933632]
        // 0x00D7C350: BL #0x27af090              | X0 = sub_27AF090( ?? val_29, ????);     
        // 0x00D7C354: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C358: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
        // 0x00D7C35C: ADD x0, sp, #0x20          | X0 = (1152921515111945424 + 32) = 1152921515111945456 (0x10000002722714F0);
        // 0x00D7C360: BL #0x299a140              | 
        label_64:
        // 0x00D7C364: ADD x8, sp, #0x58          | X8 = (1152921515111945424 + 88) = 1152921515111945512 (0x1000000272271528);
        // 0x00D7C368: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C36C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002722714F0, ????);
        // 0x00D7C370: LDR x0, [sp, #0x58]        | X0 = val_30;                             //  find_add[1152921515111933632]
        // 0x00D7C374: BL #0x27af090              | X0 = sub_27AF090( ?? val_30, ????);     
        // 0x00D7C378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C37C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_30, ????);     
        // 0x00D7C380: ADD x0, sp, #0x58          | X0 = (1152921515111945424 + 88) = 1152921515111945512 (0x1000000272271528);
        // 0x00D7C384: BL #0x299a140              | 
        label_73:
        // 0x00D7C388: ADD x8, sp, #0x48          | X8 = (1152921515111945424 + 72) = 1152921515111945496 (0x1000000272271518);
        // 0x00D7C38C: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C390: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000272271528, ????);
        // 0x00D7C394: LDR x0, [sp, #0x48]        | X0 = val_31;                             //  find_add[1152921515111933632]
        // 0x00D7C398: BL #0x27af090              | X0 = sub_27AF090( ?? val_31, ????);     
        // 0x00D7C39C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C3A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
        // 0x00D7C3A4: ADD x0, sp, #0x48          | X0 = (1152921515111945424 + 72) = 1152921515111945496 (0x1000000272271518);
        // 0x00D7C3A8: BL #0x299a140              | 
        label_82:
        // 0x00D7C3AC: ADD x8, sp, #0x40          | X8 = (1152921515111945424 + 64) = 1152921515111945488 (0x1000000272271510);
        // 0x00D7C3B0: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C3B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000272271518, ????);
        // 0x00D7C3B8: LDR x0, [sp, #0x40]        | X0 = val_32;                             //  find_add[1152921515111933632]
        // 0x00D7C3BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_32, ????);     
        // 0x00D7C3C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C3C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_32, ????);     
        // 0x00D7C3C8: ADD x0, sp, #0x40          | X0 = (1152921515111945424 + 64) = 1152921515111945488 (0x1000000272271510);
        // 0x00D7C3CC: BL #0x299a140              | 
        label_91:
        // 0x00D7C3D0: ADD x8, sp, #8             | X8 = (1152921515111945424 + 8) = 1152921515111945432 (0x10000002722714D8);
        // 0x00D7C3D4: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C3D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000272271510, ????);
        // 0x00D7C3DC: LDR x0, [sp, #8]           | X0 = val_33;                             //  find_add[1152921515111933632]
        // 0x00D7C3E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_33, ????);     
        // 0x00D7C3E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C3E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_33, ????);     
        // 0x00D7C3EC: ADD x0, sp, #8             | X0 = (1152921515111945424 + 8) = 1152921515111945432 (0x10000002722714D8);
        // 0x00D7C3F0: BL #0x299a140              | 
        label_100:
        // 0x00D7C3F4: ADD x8, sp, #0x38          | X8 = (1152921515111945424 + 56) = 1152921515111945480 (0x1000000272271508);
        // 0x00D7C3F8: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C3FC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000002722714D8, ????);
        // 0x00D7C400: LDR x0, [sp, #0x38]        | X0 = val_34;                             //  find_add[1152921515111933632]
        // 0x00D7C404: BL #0x27af090              | X0 = sub_27AF090( ?? val_34, ????);     
        // 0x00D7C408: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C40C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_34, ????);     
        // 0x00D7C410: ADD x0, sp, #0x38          | X0 = (1152921515111945424 + 56) = 1152921515111945480 (0x1000000272271508);
        // 0x00D7C414: BL #0x299a140              | 
        label_55:
        // 0x00D7C418: ADD x8, sp, #0x28          | X8 = (1152921515111945424 + 40) = 1152921515111945464 (0x10000002722714F8);
        // 0x00D7C41C: MOV x1, x22                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7C420: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000272271508, ????);
        // 0x00D7C424: LDR x0, [sp, #0x28]        | X0 = val_35;                             //  find_add[1152921515111933632]
        // 0x00D7C428: BL #0x27af090              | X0 = sub_27AF090( ?? val_35, ????);     
        // 0x00D7C42C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C430: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_35, ????);     
        // 0x00D7C434: ADD x0, sp, #0x28          | X0 = (1152921515111945424 + 40) = 1152921515111945464 (0x10000002722714F8);
        // 0x00D7C438: BL #0x299a140              | 
        // 0x00D7C43C: MOV x19, x0                | X19 = 1152921515111945464 (0x10000002722714F8);//ML01
        val_43;
        // 0x00D7C440: ADD x0, sp, #0x30          | X0 = (1152921515111945424 + 48) = 1152921515111945472 (0x1000000272271500);
        // 0x00D7C444: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C448: MOV x19, x0                | X19 = 1152921515111945472 (0x1000000272271500);//ML01
        val_43;
        // 0x00D7C44C: ADD x0, sp, #0x50          | X0 = (1152921515111945424 + 80) = 1152921515111945504 (0x1000000272271520);
        // 0x00D7C450: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C454: MOV x19, x0                | X19 = 1152921515111945504 (0x1000000272271520);//ML01
        val_43;
        // 0x00D7C458: ADD x0, sp, #0x18          | X0 = (1152921515111945424 + 24) = 1152921515111945448 (0x10000002722714E8);
        // 0x00D7C45C: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C460: MOV x19, x0                | X19 = 1152921515111945448 (0x10000002722714E8);//ML01
        val_43;
        // 0x00D7C464: ADD x0, sp, #0x10          | X0 = (1152921515111945424 + 16) = 1152921515111945440 (0x10000002722714E0);
        // 0x00D7C468: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C46C: MOV x19, x0                | X19 = 1152921515111945440 (0x10000002722714E0);//ML01
        val_43;
        // 0x00D7C470: ADD x0, sp, #0x20          | X0 = (1152921515111945424 + 32) = 1152921515111945456 (0x10000002722714F0);
        // 0x00D7C474: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C478: MOV x19, x0                | X19 = 1152921515111945456 (0x10000002722714F0);//ML01
        val_43;
        // 0x00D7C47C: ADD x0, sp, #0x58          | X0 = (1152921515111945424 + 88) = 1152921515111945512 (0x1000000272271528);
        // 0x00D7C480: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C484: MOV x19, x0                | X19 = 1152921515111945512 (0x1000000272271528);//ML01
        val_43;
        // 0x00D7C488: ADD x0, sp, #0x48          | X0 = (1152921515111945424 + 72) = 1152921515111945496 (0x1000000272271518);
        // 0x00D7C48C: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C490: MOV x19, x0                | X19 = 1152921515111945496 (0x1000000272271518);//ML01
        val_43;
        // 0x00D7C494: ADD x0, sp, #0x40          | X0 = (1152921515111945424 + 64) = 1152921515111945488 (0x1000000272271510);
        // 0x00D7C498: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C49C: MOV x19, x0                | X19 = 1152921515111945488 (0x1000000272271510);//ML01
        val_43;
        // 0x00D7C4A0: ADD x0, sp, #8             | X0 = (1152921515111945424 + 8) = 1152921515111945432 (0x10000002722714D8);
        // 0x00D7C4A4: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C4A8: MOV x19, x0                | X19 = 1152921515111945432 (0x10000002722714D8);//ML01
        val_43;
        // 0x00D7C4AC: ADD x0, sp, #0x38          | X0 = (1152921515111945424 + 56) = 1152921515111945480 (0x1000000272271508);
        // 0x00D7C4B0: B #0xd7c4bc                |  goto label_116;                        
        goto label_116;
        // 0x00D7C4B4: MOV x19, x0                | X19 = 1152921515111945480 (0x1000000272271508);//ML01
        val_43;
        // 0x00D7C4B8: ADD x0, sp, #0x28          | X0 = (1152921515111945424 + 40) = 1152921515111945464 (0x10000002722714F8);
        label_116:
        // 0x00D7C4BC: BL #0x299a140              | 
        // 0x00D7C4C0: MOV x0, x19                | X0 = 1152921515111945480 (0x1000000272271508);//ML01
        // 0x00D7C4C4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000272271508, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7C4C8 (14140616), len: 52  VirtAddr: 0x00D7C4C8 RVA: 0x00D7C4C8 token: 100694137 methodIndex: 25821 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnStartAniComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        // 0x00D7C4C8: STP x20, x19, [sp, #-0x20]! | stack[1152921515112222464] = ???;  stack[1152921515112222472] = ???;  //  dest_result_addr=1152921515112222464 |  dest_result_addr=1152921515112222472
        // 0x00D7C4CC: STP x29, x30, [sp, #0x10]  | stack[1152921515112222480] = ???;  stack[1152921515112222488] = ???;  //  dest_result_addr=1152921515112222480 |  dest_result_addr=1152921515112222488
        // 0x00D7C4D0: ADD x29, sp, #0x10         | X29 = (1152921515112222464 + 16) = 1152921515112222480 (0x10000002722B4F10);
        // 0x00D7C4D4: MOV x19, x0                | X19 = 1152921515112234496 (0x10000002722B7E00);//ML01
        // 0x00D7C4D8: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7C4DC: CBNZ x20, #0xd7c4e4        | if (this.curCameraShot != null) goto label_0;
        if(this.curCameraShot != null)
        {
            goto label_0;
        }
        // 0x00D7C4E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00D7C4E4: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        // 0x00D7C4E8: MOV x0, x19                | X0 = 1152921515112234496 (0x10000002722B7E00);//ML01
        // 0x00D7C4EC: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515112234568
        this.temp_Id = this.curCameraShot.id;
        // 0x00D7C4F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C4F4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C4F8: B #0xd7c4fc                | this.OnComplete(a:  this.curCameraShot.id); return;
        this.OnComplete(a:  this.curCameraShot.id);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7C740 (14141248), len: 168  VirtAddr: 0x00D7C740 RVA: 0x00D7C740 token: 100694138 methodIndex: 25822 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnLineComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        int val_3;
        // 0x00D7C740: STP x22, x21, [sp, #-0x30]! | stack[1152921515112359024] = ???;  stack[1152921515112359032] = ???;  //  dest_result_addr=1152921515112359024 |  dest_result_addr=1152921515112359032
        // 0x00D7C744: STP x20, x19, [sp, #0x10]  | stack[1152921515112359040] = ???;  stack[1152921515112359048] = ???;  //  dest_result_addr=1152921515112359040 |  dest_result_addr=1152921515112359048
        // 0x00D7C748: STP x29, x30, [sp, #0x20]  | stack[1152921515112359056] = ???;  stack[1152921515112359064] = ???;  //  dest_result_addr=1152921515112359056 |  dest_result_addr=1152921515112359064
        // 0x00D7C74C: ADD x29, sp, #0x20         | X29 = (1152921515112359024 + 32) = 1152921515112359056 (0x10000002722D6490);
        // 0x00D7C750: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7C754: LDRB w8, [x21, #0x3f3]     | W8 = (bool)static_value_037343F3;       
        // 0x00D7C758: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7C75C: MOV x19, x0                | X19 = 1152921515112371072 (0x10000002722D9380);//ML01
        // 0x00D7C760: TBNZ w8, #0, #0xd7c77c     | if (static_value_037343F3 == true) goto label_0;
        // 0x00D7C764: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00D7C768: LDR x8, [x8, #0x48]        | X8 = 0x2B90330;                         
        // 0x00D7C76C: LDR w0, [x8]               | W0 = 0x1790;                            
        // 0x00D7C770: BL #0x2782188              | X0 = sub_2782188( ?? 0x1790, ????);     
        // 0x00D7C774: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7C778: STRB w8, [x21, #0x3f3]     | static_value_037343F3 = true;            //  dest_result_addr=57885683
        label_0:
        // 0x00D7C77C: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        // 0x00D7C780: CBNZ x21, #0xd7c788        | if (this.withQueue != null) goto label_1;
        if(this.withQueue != null)
        {
            goto label_1;
        }
        // 0x00D7C784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1790, ????);     
        label_1:
        // 0x00D7C788: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7C78C: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7C790: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7C794: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7C798: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = this.withQueue.Count;
        // 0x00D7C79C: CBZ w0, #0xd7c7c0          | if (val_1 == 0) goto label_2;           
        if(val_1 == 0)
        {
            goto label_2;
        }
        // 0x00D7C7A0: CBNZ x20, #0xd7c7a8        | if (ev != null) goto label_3;           
        if(ev != null)
        {
            goto label_3;
        }
        // 0x00D7C7A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D7C7A8: LDR x2, [x20, #0x28]       | X2 = ev.arg; //P2                       
        // 0x00D7C7AC: MOVZ w1, #0x11             | W1 = 17 (0x11);//ML01                   
        // 0x00D7C7B0: MOV x0, x19                | X0 = 1152921515112371072 (0x10000002722D9380);//ML01
        // 0x00D7C7B4: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  17, arg:  ev.arg);
        int val_2 = this.returnCameraShotId(funtype:  17, arg:  ev.arg);
        // 0x00D7C7B8: MOV w1, w0                 | W1 = val_2;//m1                         
        val_3 = val_2;
        // 0x00D7C7BC: B #0xd7c7d0                |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x00D7C7C0: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7C7C4: CBNZ x20, #0xd7c7cc        | if (this.curCameraShot != null) goto label_5;
        if(this.curCameraShot != null)
        {
            goto label_5;
        }
        // 0x00D7C7C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7C7CC: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_3 = this.curCameraShot.id;
        label_4:
        // 0x00D7C7D0: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515112371144
        this.temp_Id = val_3;
        // 0x00D7C7D4: MOV x0, x19                | X0 = 1152921515112371072 (0x10000002722D9380);//ML01
        // 0x00D7C7D8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C7DC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C7E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7C7E4: B #0xd7c4fc                | this.OnComplete(a:  val_3 = this.curCameraShot.id); return;
        this.OnComplete(a:  val_3);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7C7E8 (14141416), len: 168  VirtAddr: 0x00D7C7E8 RVA: 0x00D7C7E8 token: 100694139 methodIndex: 25823 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnShootEffectComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        int val_3;
        // 0x00D7C7E8: STP x22, x21, [sp, #-0x30]! | stack[1152921515112503792] = ???;  stack[1152921515112503800] = ???;  //  dest_result_addr=1152921515112503792 |  dest_result_addr=1152921515112503800
        // 0x00D7C7EC: STP x20, x19, [sp, #0x10]  | stack[1152921515112503808] = ???;  stack[1152921515112503816] = ???;  //  dest_result_addr=1152921515112503808 |  dest_result_addr=1152921515112503816
        // 0x00D7C7F0: STP x29, x30, [sp, #0x20]  | stack[1152921515112503824] = ???;  stack[1152921515112503832] = ???;  //  dest_result_addr=1152921515112503824 |  dest_result_addr=1152921515112503832
        // 0x00D7C7F4: ADD x29, sp, #0x20         | X29 = (1152921515112503792 + 32) = 1152921515112503824 (0x10000002722F9A10);
        // 0x00D7C7F8: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7C7FC: LDRB w8, [x21, #0x3f4]     | W8 = (bool)static_value_037343F4;       
        // 0x00D7C800: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7C804: MOV x19, x0                | X19 = 1152921515112515840 (0x10000002722FC900);//ML01
        // 0x00D7C808: TBNZ w8, #0, #0xd7c824     | if (static_value_037343F4 == true) goto label_0;
        // 0x00D7C80C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00D7C810: LDR x8, [x8, #0xd00]       | X8 = 0x2B90348;                         
        // 0x00D7C814: LDR w0, [x8]               | W0 = 0x1796;                            
        // 0x00D7C818: BL #0x2782188              | X0 = sub_2782188( ?? 0x1796, ????);     
        // 0x00D7C81C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7C820: STRB w8, [x21, #0x3f4]     | static_value_037343F4 = true;            //  dest_result_addr=57885684
        label_0:
        // 0x00D7C824: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        // 0x00D7C828: CBNZ x21, #0xd7c830        | if (this.withQueue != null) goto label_1;
        if(this.withQueue != null)
        {
            goto label_1;
        }
        // 0x00D7C82C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1796, ????);     
        label_1:
        // 0x00D7C830: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7C834: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7C838: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7C83C: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7C840: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = this.withQueue.Count;
        // 0x00D7C844: CBZ w0, #0xd7c868          | if (val_1 == 0) goto label_2;           
        if(val_1 == 0)
        {
            goto label_2;
        }
        // 0x00D7C848: CBNZ x20, #0xd7c850        | if (ev != null) goto label_3;           
        if(ev != null)
        {
            goto label_3;
        }
        // 0x00D7C84C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D7C850: LDR x2, [x20, #0x28]       | X2 = ev.arg; //P2                       
        // 0x00D7C854: ORR w1, wzr, #0xc          | W1 = 12(0xC);                           
        // 0x00D7C858: MOV x0, x19                | X0 = 1152921515112515840 (0x10000002722FC900);//ML01
        // 0x00D7C85C: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  12, arg:  ev.arg);
        int val_2 = this.returnCameraShotId(funtype:  12, arg:  ev.arg);
        // 0x00D7C860: MOV w1, w0                 | W1 = val_2;//m1                         
        val_3 = val_2;
        // 0x00D7C864: B #0xd7c878                |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x00D7C868: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7C86C: CBNZ x20, #0xd7c874        | if (this.curCameraShot != null) goto label_5;
        if(this.curCameraShot != null)
        {
            goto label_5;
        }
        // 0x00D7C870: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7C874: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_3 = this.curCameraShot.id;
        label_4:
        // 0x00D7C878: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515112515912
        this.temp_Id = val_3;
        // 0x00D7C87C: MOV x0, x19                | X0 = 1152921515112515840 (0x10000002722FC900);//ML01
        // 0x00D7C880: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C884: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C888: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7C88C: B #0xd7c4fc                | this.OnComplete(a:  val_3 = this.curCameraShot.id); return;
        this.OnComplete(a:  val_3);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7C890 (14141584), len: 492  VirtAddr: 0x00D7C890 RVA: 0x00D7C890 token: 100694140 methodIndex: 25824 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnEffectDone(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject> val_7;
        //  | 
        System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject> val_8;
        //  | 
        object val_9;
        // 0x00D7C890: STP x24, x23, [sp, #-0x40]! | stack[1152921515112660832] = ???;  stack[1152921515112660840] = ???;  //  dest_result_addr=1152921515112660832 |  dest_result_addr=1152921515112660840
        // 0x00D7C894: STP x22, x21, [sp, #0x10]  | stack[1152921515112660848] = ???;  stack[1152921515112660856] = ???;  //  dest_result_addr=1152921515112660848 |  dest_result_addr=1152921515112660856
        // 0x00D7C898: STP x20, x19, [sp, #0x20]  | stack[1152921515112660864] = ???;  stack[1152921515112660872] = ???;  //  dest_result_addr=1152921515112660864 |  dest_result_addr=1152921515112660872
        // 0x00D7C89C: STP x29, x30, [sp, #0x30]  | stack[1152921515112660880] = ???;  stack[1152921515112660888] = ???;  //  dest_result_addr=1152921515112660880 |  dest_result_addr=1152921515112660888
        // 0x00D7C8A0: ADD x29, sp, #0x30         | X29 = (1152921515112660832 + 48) = 1152921515112660880 (0x100000027231FF90);
        // 0x00D7C8A4: SUB sp, sp, #0x20          | SP = (1152921515112660832 - 32) = 1152921515112660800 (0x100000027231FF40);
        // 0x00D7C8A8: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7C8AC: LDRB w8, [x21, #0x3f5]     | W8 = (bool)static_value_037343F5;       
        // 0x00D7C8B0: MOV x20, x1                | X20 = ev;//m1                           
        val_6 = ev;
        // 0x00D7C8B4: MOV x19, x0                | X19 = 1152921515112672896 (0x1000000272322E80);//ML01
        val_7 = this;
        // 0x00D7C8B8: TBNZ w8, #0, #0xd7c8d4     | if (static_value_037343F5 == true) goto label_0;
        // 0x00D7C8BC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D7C8C0: LDR x8, [x8, #0x340]       | X8 = 0x2B90320;                         
        // 0x00D7C8C4: LDR w0, [x8]               | W0 = 0x178C;                            
        // 0x00D7C8C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x178C, ????);     
        // 0x00D7C8CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7C8D0: STRB w8, [x21, #0x3f5]     | static_value_037343F5 = true;            //  dest_result_addr=57885685
        label_0:
        // 0x00D7C8D4: LDR x21, [x19, #0x78]      | X21 = this.effectDic; //P2              
        val_8 = this.effectDic;
        // 0x00D7C8D8: CBNZ x20, #0xd7c8e0        | if (ev != null) goto label_1;           
        if(val_6 != null)
        {
            goto label_1;
        }
        // 0x00D7C8DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x178C, ????);     
        label_1:
        // 0x00D7C8E0: LDR x22, [x20, #0x28]      | X22 = ev.arg; //P2                      
        // 0x00D7C8E4: CBNZ x21, #0xd7c8ec        | if (this.effectDic != null) goto label_2;
        if(val_8 != null)
        {
            goto label_2;
        }
        // 0x00D7C8E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x178C, ????);     
        label_2:
        // 0x00D7C8EC: ADRP x24, #0x3652000       | X24 = 56958976 (0x3652000);             
        // 0x00D7C8F0: LDR x24, [x24, #0x140]     | X24 = 1152921504607113216;              
        // 0x00D7C8F4: LDR x23, [x24]             | X23 = typeof(System.Int32);             
        // 0x00D7C8F8: CBNZ x22, #0xd7c900        | if (ev.arg != null) goto label_3;       
        if(ev.arg != null)
        {
            goto label_3;
        }
        // 0x00D7C8FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x178C, ????);     
        label_3:
        // 0x00D7C900: LDR x8, [x22]              | X8 = typeof(System.Object);             
        // 0x00D7C904: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C908: LDR x8, [x23, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7C90C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7C910: B.NE #0xd7ca08             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_4;
        // 0x00D7C914: MOV x0, x22                | X0 = ev.arg;//m1                        
        // 0x00D7C918: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        ev.arg.System.IDisposable.Dispose();
        // 0x00D7C91C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7C920: LDR w1, [x0]               | W1 = typeof(System.Object);             
        // 0x00D7C924: LDR x8, [x8, #0x898]       | X8 = 1152921510772421328;               
        // 0x00D7C928: MOV x0, x21                | X0 = this.effectDic;//m1                
        // 0x00D7C92C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::ContainsKey(System.Int32 key);
        // 0x00D7C930: BL #0x2415bdc              | X0 = this.effectDic.ContainsKey(key:  53248);
        bool val_1 = val_8.ContainsKey(key:  53248);
        // 0x00D7C934: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00D7C938: TBNZ w8, #0, #0xd7c9f0     | if ((val_1 & 1) == true) goto label_5;  
        if(val_2 == true)
        {
            goto label_5;
        }
        // 0x00D7C93C: LDR x19, [x19, #0x78]      | X19 = this.effectDic; //P2              
        val_7 = this.effectDic;
        // 0x00D7C940: CBZ x20, #0xd7c94c         | if (ev == null) goto label_6;           
        if(val_6 == null)
        {
            goto label_6;
        }
        // 0x00D7C944: LDR x22, [x20, #0x28]      | X22 = ev.arg; //P2                      
        val_9 = ev.arg;
        // 0x00D7C948: B #0xd7c958                |  goto label_7;                          
        goto label_7;
        label_6:
        // 0x00D7C94C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        // 0x00D7C950: LDR x22, [x20, #0x28]      | X22 = ev.arg; //P2                      
        val_9 = ev.arg;
        // 0x00D7C954: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x00D7C958: LDR x21, [x20, #0x30]      | X21 = ev.arg1; //P2                     
        val_8 = ev.arg1;
        // 0x00D7C95C: CBNZ x19, #0xd7c964        | if (this.effectDic != null) goto label_8;
        if(val_7 != null)
        {
            goto label_8;
        }
        // 0x00D7C960: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_8:
        // 0x00D7C964: LDR x20, [x24]             | X20 = typeof(System.Int32);             
        val_6 = null;
        // 0x00D7C968: CBNZ x22, #0xd7c970        | if (ev.arg != null) goto label_9;       
        if(val_9 != null)
        {
            goto label_9;
        }
        // 0x00D7C96C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7C970: LDR x8, [x22]              | X8 = typeof(System.Object);             
        // 0x00D7C974: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C978: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7C97C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7C980: B.NE #0xd7ca2c             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_10;
        // 0x00D7C984: MOV x0, x22                | X0 = ev.arg;//m1                        
        // 0x00D7C988: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_9.System.IDisposable.Dispose();
        // 0x00D7C98C: LDR w20, [x0]              | W20 = typeof(System.Object);            
        // 0x00D7C990: CBZ x21, #0xd7c9d0         | if (ev.arg1 == null) goto label_11;     
        if(val_8 == null)
        {
            goto label_11;
        }
        // 0x00D7C994: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7C998: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
        // 0x00D7C99C: LDR x1, [x8]               | X1 = typeof(UnityEngine.GameObject);    
        // 0x00D7C9A0: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7C9A4: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(UnityEngine.GameObject))
        // 0x00D7C9A8: B.EQ #0xd7c9d4             | if (typeof(System.Object) == null) goto label_12;
        if(null == null)
        {
            goto label_12;
        }
        // 0x00D7C9AC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7C9B0: ADD x8, sp, #8             | X8 = (1152921515112660800 + 8) = 1152921515112660808 (0x100000027231FF48);
        // 0x00D7C9B4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7C9B8: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515112648896]
        // 0x00D7C9BC: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7C9C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7C9C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7C9C8: ADD x0, sp, #8             | X0 = (1152921515112660800 + 8) = 1152921515112660808 (0x100000027231FF48);
        // 0x00D7C9CC: BL #0x299a140              | 
        label_11:
        // 0x00D7C9D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_8 = 0;
        label_12:
        // 0x00D7C9D4: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D7C9D8: LDR x8, [x8, #0x710]       | X8 = 1152921510773326416;               
        // 0x00D7C9DC: MOV x0, x19                | X0 = this.effectDic;//m1                
        // 0x00D7C9E0: MOV w1, w20                | W1 = 1152921504606900224 (0x100000000000D000);//ML01
        // 0x00D7C9E4: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
        // 0x00D7C9E8: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::set_Item(System.Int32 key, UnityEngine.GameObject value);
        // 0x00D7C9EC: BL #0x24147b0              | this.effectDic.set_Item(key:  53248, value:  val_8);
        val_7.set_Item(key:  53248, value:  val_8);
        label_5:
        // 0x00D7C9F0: SUB sp, x29, #0x30         | SP = (1152921515112660880 - 48) = 1152921515112660832 (0x100000027231FF60);
        // 0x00D7C9F4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C9F8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C9FC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7CA00: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D7CA04: RET                        |  return;                                
        return;
        label_4:
        // 0x00D7CA08: ADD x8, sp, #0x10          | X8 = (1152921515112660800 + 16) = 1152921515112660816 (0x100000027231FF50);
        // 0x00D7CA0C: MOV x1, x23                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7CA10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7CA14: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921515112648896]
        // 0x00D7CA18: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
        // 0x00D7CA1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7CA20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
        // 0x00D7CA24: ADD x0, sp, #0x10          | X0 = (1152921515112660800 + 16) = 1152921515112660816 (0x100000027231FF50);
        // 0x00D7CA28: BL #0x299a140              | 
        label_10:
        // 0x00D7CA2C: ADD x8, sp, #0x18          | X8 = (1152921515112660800 + 24) = 1152921515112660824 (0x100000027231FF58);
        // 0x00D7CA30: MOV x1, x20                | X1 = ev;//m1                            
        // 0x00D7CA34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x100000027231FF50, ????);
        // 0x00D7CA38: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921515112648896]
        // 0x00D7CA3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
        // 0x00D7CA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7CA44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
        // 0x00D7CA48: ADD x0, sp, #0x18          | X0 = (1152921515112660800 + 24) = 1152921515112660824 (0x100000027231FF58);
        // 0x00D7CA4C: BL #0x299a140              | 
        // 0x00D7CA50: MOV x19, x0                | X19 = 1152921515112660824 (0x100000027231FF58);//ML01
        // 0x00D7CA54: ADD x0, sp, #8             | X0 = (1152921515112660800 + 8) = 1152921515112660808 (0x100000027231FF48);
        label_14:
        // 0x00D7CA58: BL #0x299a140              | 
        // 0x00D7CA5C: MOV x0, x19                | X0 = 1152921515112660824 (0x100000027231FF58);//ML01
        // 0x00D7CA60: BL #0x980800               | X0 = sub_980800( ?? 0x100000027231FF58, ????);
        // 0x00D7CA64: MOV x19, x0                | X19 = 1152921515112660824 (0x100000027231FF58);//ML01
        // 0x00D7CA68: ADD x0, sp, #0x10          | X0 = (1152921515112660800 + 16) = 1152921515112660816 (0x100000027231FF50);
        // 0x00D7CA6C: B #0xd7ca58                |  goto label_14;                         
        goto label_14;
        // 0x00D7CA70: MOV x19, x0                | X19 = 1152921515112660816 (0x100000027231FF50);//ML01
        // 0x00D7CA74: ADD x0, sp, #0x18          | X0 = (1152921515112660800 + 24) = 1152921515112660824 (0x100000027231FF58);
        // 0x00D7CA78: B #0xd7ca58                |  goto label_14;                         
        goto label_14;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7CA7C (14142076), len: 368  VirtAddr: 0x00D7CA7C RVA: 0x00D7CA7C token: 100694141 methodIndex: 25825 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnGameSpeedComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7CA7C: STP x22, x21, [sp, #-0x30]! | stack[1152921515112822000] = ???;  stack[1152921515112822008] = ???;  //  dest_result_addr=1152921515112822000 |  dest_result_addr=1152921515112822008
        // 0x00D7CA80: STP x20, x19, [sp, #0x10]  | stack[1152921515112822016] = ???;  stack[1152921515112822024] = ???;  //  dest_result_addr=1152921515112822016 |  dest_result_addr=1152921515112822024
        // 0x00D7CA84: STP x29, x30, [sp, #0x20]  | stack[1152921515112822032] = ???;  stack[1152921515112822040] = ???;  //  dest_result_addr=1152921515112822032 |  dest_result_addr=1152921515112822040
        // 0x00D7CA88: ADD x29, sp, #0x20         | X29 = (1152921515112822000 + 32) = 1152921515112822032 (0x1000000272347510);
        // 0x00D7CA8C: SUB sp, sp, #0x10          | SP = (1152921515112822000 - 16) = 1152921515112821984 (0x10000002723474E0);
        // 0x00D7CA90: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7CA94: LDRB w8, [x21, #0x3f6]     | W8 = (bool)static_value_037343F6;       
        // 0x00D7CA98: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7CA9C: MOV x19, x0                | X19 = 1152921515112834048 (0x100000027234A400);//ML01
        // 0x00D7CAA0: TBNZ w8, #0, #0xd7cabc     | if (static_value_037343F6 == true) goto label_0;
        // 0x00D7CAA4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
        // 0x00D7CAA8: LDR x8, [x8, #0xc58]       | X8 = 0x2B9032C;                         
        // 0x00D7CAAC: LDR w0, [x8]               | W0 = 0x178F;                            
        // 0x00D7CAB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x178F, ????);     
        // 0x00D7CAB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7CAB8: STRB w8, [x21, #0x3f6]     | static_value_037343F6 = true;            //  dest_result_addr=57885686
        label_0:
        // 0x00D7CABC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7CAC0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7CAC4: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7CAC8: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7CACC: TBZ w8, #0, #0xd7cadc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7CAD0: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7CAD4: CBNZ w8, #0xd7cadc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7CAD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7CADC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00D7CAE0: LDR x8, [x8, #0xd88]       | X8 = (string**)(1152921513285951552)("2");
        // 0x00D7CAE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7CAE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7CAEC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7CAF0: LDR x1, [x8]               | X1 = "2";                               
        // 0x00D7CAF4: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7CAF8: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7CAFC: CBNZ x21, #0xd7cb04        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7CB00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7CB04: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7CB08: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7CB0C: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7CB10: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7CB14: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7CB18: CBZ w0, #0xd7cb84          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7CB1C: CBNZ x20, #0xd7cb24        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7CB20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7CB24: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7CB28: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7CB2C: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7CB30: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7CB34: CBNZ x21, #0xd7cb3c        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7CB38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7CB3C: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7CB40: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7CB44: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7CB48: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7CB4C: B.NE #0xd7cbb4             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7CB50: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7CB54: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7CB58: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7CB5C: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7CB60: ADD x1, sp, #4             | X1 = (1152921515112821984 + 4) = 1152921515112821988 (0x10000002723474E4);
        // 0x00D7CB64: STR w8, [sp, #4]           | stack[1152921515112821988] = typeof(System.Object);  //  dest_result_addr=1152921515112821988
        // 0x00D7CB68: BL #0x27bc028              | X0 = 1152921515112878336 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7CB6C: MOV x2, x0                 | X2 = 1152921515112878336 (0x1000000272355100);//ML01
        // 0x00D7CB70: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D7CB74: MOV x0, x19                | X0 = 1152921515112834048 (0x100000027234A400);//ML01
        // 0x00D7CB78: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  2, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  2, arg:  null);
        // 0x00D7CB7C: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7CB80: B #0xd7cb94                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7CB84: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7CB88: CBNZ x20, #0xd7cb90        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7CB8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7CB90: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7CB94: MOV x0, x19                | X0 = 1152921515112834048 (0x100000027234A400);//ML01
        // 0x00D7CB98: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515112834120
        this.temp_Id = val_5;
        // 0x00D7CB9C: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7CBA0: SUB sp, x29, #0x20         | SP = (1152921515112822032 - 32) = 1152921515112822000 (0x10000002723474F0);
        // 0x00D7CBA4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7CBA8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7CBAC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7CBB0: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7CBB4: ADD x8, sp, #8             | X8 = (1152921515112821984 + 8) = 1152921515112821992 (0x10000002723474E8);
        // 0x00D7CBB8: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7CBBC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7CBC0: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515112810048]
        // 0x00D7CBC4: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7CBC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7CBCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7CBD0: ADD x0, sp, #8             | X0 = (1152921515112821984 + 8) = 1152921515112821992 (0x10000002723474E8);
        // 0x00D7CBD4: BL #0x299a140              | 
        // 0x00D7CBD8: MOV x19, x0                | X19 = 1152921515112821992 (0x10000002723474E8);//ML01
        // 0x00D7CBDC: ADD x0, sp, #8             | X0 = (1152921515112821984 + 8) = 1152921515112821992 (0x10000002723474E8);
        // 0x00D7CBE0: BL #0x299a140              | 
        // 0x00D7CBE4: MOV x0, x19                | X0 = 1152921515112821992 (0x10000002723474E8);//ML01
        // 0x00D7CBE8: BL #0x980800               | X0 = sub_980800( ?? 0x10000002723474E8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7CBEC (14142444), len: 368  VirtAddr: 0x00D7CBEC RVA: 0x00D7CBEC token: 100694142 methodIndex: 25826 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnActionComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7CBEC: STP x22, x21, [sp, #-0x30]! | stack[1152921515112974960] = ???;  stack[1152921515112974968] = ???;  //  dest_result_addr=1152921515112974960 |  dest_result_addr=1152921515112974968
        // 0x00D7CBF0: STP x20, x19, [sp, #0x10]  | stack[1152921515112974976] = ???;  stack[1152921515112974984] = ???;  //  dest_result_addr=1152921515112974976 |  dest_result_addr=1152921515112974984
        // 0x00D7CBF4: STP x29, x30, [sp, #0x20]  | stack[1152921515112974992] = ???;  stack[1152921515112975000] = ???;  //  dest_result_addr=1152921515112974992 |  dest_result_addr=1152921515112975000
        // 0x00D7CBF8: ADD x29, sp, #0x20         | X29 = (1152921515112974960 + 32) = 1152921515112974992 (0x100000027236CA90);
        // 0x00D7CBFC: SUB sp, sp, #0x10          | SP = (1152921515112974960 - 16) = 1152921515112974944 (0x100000027236CA60);
        // 0x00D7CC00: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7CC04: LDRB w8, [x21, #0x3f7]     | W8 = (bool)static_value_037343F7;       
        // 0x00D7CC08: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7CC0C: MOV x19, x0                | X19 = 1152921515112987008 (0x100000027236F980);//ML01
        // 0x00D7CC10: TBNZ w8, #0, #0xd7cc2c     | if (static_value_037343F7 == true) goto label_0;
        // 0x00D7CC14: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00D7CC18: LDR x8, [x8, #0xc80]       | X8 = 0x2B90310;                         
        // 0x00D7CC1C: LDR w0, [x8]               | W0 = 0x1788;                            
        // 0x00D7CC20: BL #0x2782188              | X0 = sub_2782188( ?? 0x1788, ????);     
        // 0x00D7CC24: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7CC28: STRB w8, [x21, #0x3f7]     | static_value_037343F7 = true;            //  dest_result_addr=57885687
        label_0:
        // 0x00D7CC2C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7CC30: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7CC34: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7CC38: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7CC3C: TBZ w8, #0, #0xd7cc4c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7CC40: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7CC44: CBNZ w8, #0xd7cc4c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7CC48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7CC4C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00D7CC50: LDR x8, [x8, #0xa50]       | X8 = (string**)(1152921514899915392)("3");
        // 0x00D7CC54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7CC58: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7CC5C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7CC60: LDR x1, [x8]               | X1 = "3";                               
        // 0x00D7CC64: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7CC68: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7CC6C: CBNZ x21, #0xd7cc74        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7CC70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7CC74: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7CC78: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7CC7C: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7CC80: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7CC84: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7CC88: CBZ w0, #0xd7ccf4          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7CC8C: CBNZ x20, #0xd7cc94        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7CC90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7CC94: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7CC98: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7CC9C: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7CCA0: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7CCA4: CBNZ x21, #0xd7ccac        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7CCA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7CCAC: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7CCB0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7CCB4: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7CCB8: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7CCBC: B.NE #0xd7cd24             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7CCC0: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7CCC4: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7CCC8: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7CCCC: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7CCD0: ADD x1, sp, #4             | X1 = (1152921515112974944 + 4) = 1152921515112974948 (0x100000027236CA64);
        // 0x00D7CCD4: STR w8, [sp, #4]           | stack[1152921515112974948] = typeof(System.Object);  //  dest_result_addr=1152921515112974948
        // 0x00D7CCD8: BL #0x27bc028              | X0 = 1152921515113031296 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7CCDC: MOV x2, x0                 | X2 = 1152921515113031296 (0x100000027237A680);//ML01
        // 0x00D7CCE0: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00D7CCE4: MOV x0, x19                | X0 = 1152921515112987008 (0x100000027236F980);//ML01
        // 0x00D7CCE8: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  3, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  3, arg:  null);
        // 0x00D7CCEC: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7CCF0: B #0xd7cd04                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7CCF4: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7CCF8: CBNZ x20, #0xd7cd00        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7CCFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7CD00: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7CD04: MOV x0, x19                | X0 = 1152921515112987008 (0x100000027236F980);//ML01
        // 0x00D7CD08: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515112987080
        this.temp_Id = val_5;
        // 0x00D7CD0C: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7CD10: SUB sp, x29, #0x20         | SP = (1152921515112974992 - 32) = 1152921515112974960 (0x100000027236CA70);
        // 0x00D7CD14: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7CD18: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7CD1C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7CD20: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7CD24: ADD x8, sp, #8             | X8 = (1152921515112974944 + 8) = 1152921515112974952 (0x100000027236CA68);
        // 0x00D7CD28: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7CD2C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7CD30: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515112963008]
        // 0x00D7CD34: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7CD38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7CD3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7CD40: ADD x0, sp, #8             | X0 = (1152921515112974944 + 8) = 1152921515112974952 (0x100000027236CA68);
        // 0x00D7CD44: BL #0x299a140              | 
        // 0x00D7CD48: MOV x19, x0                | X19 = 1152921515112974952 (0x100000027236CA68);//ML01
        // 0x00D7CD4C: ADD x0, sp, #8             | X0 = (1152921515112974944 + 8) = 1152921515112974952 (0x100000027236CA68);
        // 0x00D7CD50: BL #0x299a140              | 
        // 0x00D7CD54: MOV x0, x19                | X0 = 1152921515112974952 (0x100000027236CA68);//ML01
        // 0x00D7CD58: BL #0x980800               | X0 = sub_980800( ?? 0x100000027236CA68, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7CD5C (14142812), len: 368  VirtAddr: 0x00D7CD5C RVA: 0x00D7CD5C token: 100694143 methodIndex: 25827 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnSkillComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7CD5C: STP x22, x21, [sp, #-0x30]! | stack[1152921515113127920] = ???;  stack[1152921515113127928] = ???;  //  dest_result_addr=1152921515113127920 |  dest_result_addr=1152921515113127928
        // 0x00D7CD60: STP x20, x19, [sp, #0x10]  | stack[1152921515113127936] = ???;  stack[1152921515113127944] = ???;  //  dest_result_addr=1152921515113127936 |  dest_result_addr=1152921515113127944
        // 0x00D7CD64: STP x29, x30, [sp, #0x20]  | stack[1152921515113127952] = ???;  stack[1152921515113127960] = ???;  //  dest_result_addr=1152921515113127952 |  dest_result_addr=1152921515113127960
        // 0x00D7CD68: ADD x29, sp, #0x20         | X29 = (1152921515113127920 + 32) = 1152921515113127952 (0x1000000272392010);
        // 0x00D7CD6C: SUB sp, sp, #0x10          | SP = (1152921515113127920 - 16) = 1152921515113127904 (0x1000000272391FE0);
        // 0x00D7CD70: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7CD74: LDRB w8, [x21, #0x3f8]     | W8 = (bool)static_value_037343F8;       
        // 0x00D7CD78: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7CD7C: MOV x19, x0                | X19 = 1152921515113139968 (0x1000000272394F00);//ML01
        // 0x00D7CD80: TBNZ w8, #0, #0xd7cd9c     | if (static_value_037343F8 == true) goto label_0;
        // 0x00D7CD84: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
        // 0x00D7CD88: LDR x8, [x8, #0x48]        | X8 = 0x2B9034C;                         
        // 0x00D7CD8C: LDR w0, [x8]               | W0 = 0x1797;                            
        // 0x00D7CD90: BL #0x2782188              | X0 = sub_2782188( ?? 0x1797, ????);     
        // 0x00D7CD94: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7CD98: STRB w8, [x21, #0x3f8]     | static_value_037343F8 = true;            //  dest_result_addr=57885688
        label_0:
        // 0x00D7CD9C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7CDA0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7CDA4: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7CDA8: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7CDAC: TBZ w8, #0, #0xd7cdbc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7CDB0: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7CDB4: CBNZ w8, #0xd7cdbc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7CDB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7CDBC: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
        // 0x00D7CDC0: LDR x8, [x8, #0xe00]       | X8 = (string**)(1152921514899915472)("4");
        // 0x00D7CDC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7CDC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7CDCC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7CDD0: LDR x1, [x8]               | X1 = "4";                               
        // 0x00D7CDD4: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7CDD8: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7CDDC: CBNZ x21, #0xd7cde4        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7CDE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7CDE4: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7CDE8: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7CDEC: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7CDF0: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7CDF4: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7CDF8: CBZ w0, #0xd7ce64          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7CDFC: CBNZ x20, #0xd7ce04        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7CE00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7CE04: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7CE08: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7CE0C: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7CE10: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7CE14: CBNZ x21, #0xd7ce1c        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7CE18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7CE1C: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7CE20: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7CE24: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7CE28: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7CE2C: B.NE #0xd7ce94             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7CE30: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7CE34: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7CE38: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7CE3C: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7CE40: ADD x1, sp, #4             | X1 = (1152921515113127904 + 4) = 1152921515113127908 (0x1000000272391FE4);
        // 0x00D7CE44: STR w8, [sp, #4]           | stack[1152921515113127908] = typeof(System.Object);  //  dest_result_addr=1152921515113127908
        // 0x00D7CE48: BL #0x27bc028              | X0 = 1152921515113184256 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7CE4C: MOV x2, x0                 | X2 = 1152921515113184256 (0x100000027239FC00);//ML01
        // 0x00D7CE50: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00D7CE54: MOV x0, x19                | X0 = 1152921515113139968 (0x1000000272394F00);//ML01
        // 0x00D7CE58: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  4, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  4, arg:  null);
        // 0x00D7CE5C: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7CE60: B #0xd7ce74                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7CE64: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7CE68: CBNZ x20, #0xd7ce70        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7CE6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7CE70: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7CE74: MOV x0, x19                | X0 = 1152921515113139968 (0x1000000272394F00);//ML01
        // 0x00D7CE78: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515113140040
        this.temp_Id = val_5;
        // 0x00D7CE7C: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7CE80: SUB sp, x29, #0x20         | SP = (1152921515113127952 - 32) = 1152921515113127920 (0x1000000272391FF0);
        // 0x00D7CE84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7CE88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7CE8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7CE90: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7CE94: ADD x8, sp, #8             | X8 = (1152921515113127904 + 8) = 1152921515113127912 (0x1000000272391FE8);
        // 0x00D7CE98: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7CE9C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7CEA0: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515113115968]
        // 0x00D7CEA4: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7CEA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7CEAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7CEB0: ADD x0, sp, #8             | X0 = (1152921515113127904 + 8) = 1152921515113127912 (0x1000000272391FE8);
        // 0x00D7CEB4: BL #0x299a140              | 
        // 0x00D7CEB8: MOV x19, x0                | X19 = 1152921515113127912 (0x1000000272391FE8);//ML01
        // 0x00D7CEBC: ADD x0, sp, #8             | X0 = (1152921515113127904 + 8) = 1152921515113127912 (0x1000000272391FE8);
        // 0x00D7CEC0: BL #0x299a140              | 
        // 0x00D7CEC4: MOV x0, x19                | X0 = 1152921515113127912 (0x1000000272391FE8);//ML01
        // 0x00D7CEC8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000272391FE8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7CECC (14143180), len: 368  VirtAddr: 0x00D7CECC RVA: 0x00D7CECC token: 100694144 methodIndex: 25828 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnBrightComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7CECC: STP x22, x21, [sp, #-0x30]! | stack[1152921515113280960] = ???;  stack[1152921515113280968] = ???;  //  dest_result_addr=1152921515113280960 |  dest_result_addr=1152921515113280968
        // 0x00D7CED0: STP x20, x19, [sp, #0x10]  | stack[1152921515113280976] = ???;  stack[1152921515113280984] = ???;  //  dest_result_addr=1152921515113280976 |  dest_result_addr=1152921515113280984
        // 0x00D7CED4: STP x29, x30, [sp, #0x20]  | stack[1152921515113280992] = ???;  stack[1152921515113281000] = ???;  //  dest_result_addr=1152921515113280992 |  dest_result_addr=1152921515113281000
        // 0x00D7CED8: ADD x29, sp, #0x20         | X29 = (1152921515113280960 + 32) = 1152921515113280992 (0x10000002723B75E0);
        // 0x00D7CEDC: SUB sp, sp, #0x10          | SP = (1152921515113280960 - 16) = 1152921515113280944 (0x10000002723B75B0);
        // 0x00D7CEE0: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7CEE4: LDRB w8, [x21, #0x3f9]     | W8 = (bool)static_value_037343F9;       
        // 0x00D7CEE8: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7CEEC: MOV x19, x0                | X19 = 1152921515113293008 (0x10000002723BA4D0);//ML01
        // 0x00D7CEF0: TBNZ w8, #0, #0xd7cf0c     | if (static_value_037343F9 == true) goto label_0;
        // 0x00D7CEF4: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
        // 0x00D7CEF8: LDR x8, [x8, #0x1e8]       | X8 = 0x2B90318;                         
        // 0x00D7CEFC: LDR w0, [x8]               | W0 = 0x178A;                            
        // 0x00D7CF00: BL #0x2782188              | X0 = sub_2782188( ?? 0x178A, ????);     
        // 0x00D7CF04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7CF08: STRB w8, [x21, #0x3f9]     | static_value_037343F9 = true;            //  dest_result_addr=57885689
        label_0:
        // 0x00D7CF0C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7CF10: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7CF14: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7CF18: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7CF1C: TBZ w8, #0, #0xd7cf2c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7CF20: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7CF24: CBNZ w8, #0xd7cf2c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7CF28: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7CF2C: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x00D7CF30: LDR x8, [x8, #0x270]       | X8 = (string**)(1152921515113252544)("14");
        // 0x00D7CF34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7CF38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7CF3C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7CF40: LDR x1, [x8]               | X1 = "14";                              
        // 0x00D7CF44: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7CF48: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7CF4C: CBNZ x21, #0xd7cf54        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7CF50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7CF54: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7CF58: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7CF5C: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7CF60: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7CF64: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7CF68: CBZ w0, #0xd7cfd4          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7CF6C: CBNZ x20, #0xd7cf74        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7CF70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7CF74: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7CF78: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7CF7C: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7CF80: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7CF84: CBNZ x21, #0xd7cf8c        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7CF88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7CF8C: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7CF90: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7CF94: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7CF98: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7CF9C: B.NE #0xd7d004             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7CFA0: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7CFA4: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7CFA8: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7CFAC: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7CFB0: ADD x1, sp, #4             | X1 = (1152921515113280944 + 4) = 1152921515113280948 (0x10000002723B75B4);
        // 0x00D7CFB4: STR w8, [sp, #4]           | stack[1152921515113280948] = typeof(System.Object);  //  dest_result_addr=1152921515113280948
        // 0x00D7CFB8: BL #0x27bc028              | X0 = 1152921515113337296 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7CFBC: MOV x2, x0                 | X2 = 1152921515113337296 (0x10000002723C51D0);//ML01
        // 0x00D7CFC0: ORR w1, wzr, #0xe          | W1 = 14(0xE);                           
        // 0x00D7CFC4: MOV x0, x19                | X0 = 1152921515113293008 (0x10000002723BA4D0);//ML01
        // 0x00D7CFC8: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  14, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  14, arg:  null);
        // 0x00D7CFCC: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7CFD0: B #0xd7cfe4                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7CFD4: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7CFD8: CBNZ x20, #0xd7cfe0        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7CFDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7CFE0: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7CFE4: MOV x0, x19                | X0 = 1152921515113293008 (0x10000002723BA4D0);//ML01
        // 0x00D7CFE8: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515113293080
        this.temp_Id = val_5;
        // 0x00D7CFEC: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7CFF0: SUB sp, x29, #0x20         | SP = (1152921515113280992 - 32) = 1152921515113280960 (0x10000002723B75C0);
        // 0x00D7CFF4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7CFF8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7CFFC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7D000: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7D004: ADD x8, sp, #8             | X8 = (1152921515113280944 + 8) = 1152921515113280952 (0x10000002723B75B8);
        // 0x00D7D008: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7D00C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7D010: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515113269008]
        // 0x00D7D014: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7D018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D01C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7D020: ADD x0, sp, #8             | X0 = (1152921515113280944 + 8) = 1152921515113280952 (0x10000002723B75B8);
        // 0x00D7D024: BL #0x299a140              | 
        // 0x00D7D028: MOV x19, x0                | X19 = 1152921515113280952 (0x10000002723B75B8);//ML01
        // 0x00D7D02C: ADD x0, sp, #8             | X0 = (1152921515113280944 + 8) = 1152921515113280952 (0x10000002723B75B8);
        // 0x00D7D030: BL #0x299a140              | 
        // 0x00D7D034: MOV x0, x19                | X0 = 1152921515113280952 (0x10000002723B75B8);//ML01
        // 0x00D7D038: BL #0x980800               | X0 = sub_980800( ?? 0x10000002723B75B8, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D03C (14143548), len: 228  VirtAddr: 0x00D7D03C RVA: 0x00D7D03C token: 100694145 methodIndex: 25829 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnWaitComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        int val_3;
        // 0x00D7D03C: STP x22, x21, [sp, #-0x30]! | stack[1152921515113429904] = ???;  stack[1152921515113429912] = ???;  //  dest_result_addr=1152921515113429904 |  dest_result_addr=1152921515113429912
        // 0x00D7D040: STP x20, x19, [sp, #0x10]  | stack[1152921515113429920] = ???;  stack[1152921515113429928] = ???;  //  dest_result_addr=1152921515113429920 |  dest_result_addr=1152921515113429928
        // 0x00D7D044: STP x29, x30, [sp, #0x20]  | stack[1152921515113429936] = ???;  stack[1152921515113429944] = ???;  //  dest_result_addr=1152921515113429936 |  dest_result_addr=1152921515113429944
        // 0x00D7D048: ADD x29, sp, #0x20         | X29 = (1152921515113429904 + 32) = 1152921515113429936 (0x10000002723DBBB0);
        // 0x00D7D04C: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7D050: LDRB w8, [x21, #0x3fa]     | W8 = (bool)static_value_037343FA;       
        // 0x00D7D054: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7D058: MOV x19, x0                | X19 = 1152921515113441952 (0x10000002723DEAA0);//ML01
        // 0x00D7D05C: TBNZ w8, #0, #0xd7d078     | if (static_value_037343FA == true) goto label_0;
        // 0x00D7D060: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
        // 0x00D7D064: LDR x8, [x8, #0xda8]       | X8 = 0x2B90354;                         
        // 0x00D7D068: LDR w0, [x8]               | W0 = 0x1799;                            
        // 0x00D7D06C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1799, ????);     
        // 0x00D7D070: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D074: STRB w8, [x21, #0x3fa]     | static_value_037343FA = true;            //  dest_result_addr=57885690
        label_0:
        // 0x00D7D078: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7D07C: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7D080: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7D084: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7D088: TBZ w8, #0, #0xd7d098      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7D08C: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D090: CBNZ w8, #0xd7d098         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7D094: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7D098: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
        // 0x00D7D09C: LDR x8, [x8, #0x670]       | X8 = (string**)(1152921515113405584)("6");
        // 0x00D7D0A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D0A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D0A8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7D0AC: LDR x1, [x8]               | X1 = "6";                               
        // 0x00D7D0B0: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7D0B4: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        // 0x00D7D0B8: CBNZ x21, #0xd7d0c0        | if (this.withQueue != null) goto label_3;
        if(this.withQueue != null)
        {
            goto label_3;
        }
        // 0x00D7D0BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7D0C0: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7D0C4: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7D0C8: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7D0CC: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7D0D0: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = this.withQueue.Count;
        // 0x00D7D0D4: CBZ w0, #0xd7d0f8          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7D0D8: CBNZ x20, #0xd7d0e0        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7D0DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7D0E0: LDR x2, [x20, #0x28]       | X2 = ev.arg; //P2                       
        // 0x00D7D0E4: ORR w1, wzr, #6            | W1 = 6(0x6);                            
        // 0x00D7D0E8: MOV x0, x19                | X0 = 1152921515113441952 (0x10000002723DEAA0);//ML01
        // 0x00D7D0EC: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  6, arg:  ev.arg);
        int val_2 = this.returnCameraShotId(funtype:  6, arg:  ev.arg);
        // 0x00D7D0F0: MOV w1, w0                 | W1 = val_2;//m1                         
        val_3 = val_2;
        // 0x00D7D0F4: B #0xd7d108                |  goto label_6;                          
        goto label_6;
        label_4:
        // 0x00D7D0F8: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7D0FC: CBNZ x20, #0xd7d104        | if (this.curCameraShot != null) goto label_7;
        if(this.curCameraShot != null)
        {
            goto label_7;
        }
        // 0x00D7D100: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x00D7D104: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_3 = this.curCameraShot.id;
        label_6:
        // 0x00D7D108: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515113442024
        this.temp_Id = val_3;
        // 0x00D7D10C: MOV x0, x19                | X0 = 1152921515113441952 (0x10000002723DEAA0);//ML01
        // 0x00D7D110: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7D114: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7D118: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7D11C: B #0xd7c4fc                | this.OnComplete(a:  val_3 = this.curCameraShot.id); return;
        this.OnComplete(a:  val_3);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D120 (14143776), len: 368  VirtAddr: 0x00D7D120 RVA: 0x00D7D120 token: 100694146 methodIndex: 25830 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnPlotComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7D120: STP x22, x21, [sp, #-0x30]! | stack[1152921515113578768] = ???;  stack[1152921515113578776] = ???;  //  dest_result_addr=1152921515113578768 |  dest_result_addr=1152921515113578776
        // 0x00D7D124: STP x20, x19, [sp, #0x10]  | stack[1152921515113578784] = ???;  stack[1152921515113578792] = ???;  //  dest_result_addr=1152921515113578784 |  dest_result_addr=1152921515113578792
        // 0x00D7D128: STP x29, x30, [sp, #0x20]  | stack[1152921515113578800] = ???;  stack[1152921515113578808] = ???;  //  dest_result_addr=1152921515113578800 |  dest_result_addr=1152921515113578808
        // 0x00D7D12C: ADD x29, sp, #0x20         | X29 = (1152921515113578768 + 32) = 1152921515113578800 (0x1000000272400130);
        // 0x00D7D130: SUB sp, sp, #0x10          | SP = (1152921515113578768 - 16) = 1152921515113578752 (0x1000000272400100);
        // 0x00D7D134: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7D138: LDRB w8, [x21, #0x3fb]     | W8 = (bool)static_value_037343FB;       
        // 0x00D7D13C: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7D140: MOV x19, x0                | X19 = 1152921515113590816 (0x1000000272403020);//ML01
        // 0x00D7D144: TBNZ w8, #0, #0xd7d160     | if (static_value_037343FB == true) goto label_0;
        // 0x00D7D148: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00D7D14C: LDR x8, [x8, #0x5e0]       | X8 = 0x2B90340;                         
        // 0x00D7D150: LDR w0, [x8]               | W0 = 0x1794;                            
        // 0x00D7D154: BL #0x2782188              | X0 = sub_2782188( ?? 0x1794, ????);     
        // 0x00D7D158: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D15C: STRB w8, [x21, #0x3fb]     | static_value_037343FB = true;            //  dest_result_addr=57885691
        label_0:
        // 0x00D7D160: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7D164: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7D168: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7D16C: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7D170: TBZ w8, #0, #0xd7d180      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7D174: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D178: CBNZ w8, #0xd7d180         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7D17C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7D180: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00D7D184: LDR x8, [x8, #0xa48]       | X8 = (string**)(1152921514286305440)("1");
        // 0x00D7D188: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D18C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D190: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7D194: LDR x1, [x8]               | X1 = "1";                               
        // 0x00D7D198: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7D19C: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7D1A0: CBNZ x21, #0xd7d1a8        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7D1A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7D1A8: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7D1AC: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7D1B0: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7D1B4: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7D1B8: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7D1BC: CBZ w0, #0xd7d228          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7D1C0: CBNZ x20, #0xd7d1c8        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7D1C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7D1C8: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7D1CC: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7D1D0: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7D1D4: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7D1D8: CBNZ x21, #0xd7d1e0        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7D1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7D1E0: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7D1E4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7D1E8: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7D1EC: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7D1F0: B.NE #0xd7d258             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7D1F4: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7D1F8: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7D1FC: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7D200: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7D204: ADD x1, sp, #4             | X1 = (1152921515113578752 + 4) = 1152921515113578756 (0x1000000272400104);
        // 0x00D7D208: STR w8, [sp, #4]           | stack[1152921515113578756] = typeof(System.Object);  //  dest_result_addr=1152921515113578756
        // 0x00D7D20C: BL #0x27bc028              | X0 = 1152921515113635104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7D210: MOV x2, x0                 | X2 = 1152921515113635104 (0x100000027240DD20);//ML01
        // 0x00D7D214: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D7D218: MOV x0, x19                | X0 = 1152921515113590816 (0x1000000272403020);//ML01
        // 0x00D7D21C: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  1, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  1, arg:  null);
        // 0x00D7D220: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7D224: B #0xd7d238                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7D228: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7D22C: CBNZ x20, #0xd7d234        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7D230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7D234: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7D238: MOV x0, x19                | X0 = 1152921515113590816 (0x1000000272403020);//ML01
        // 0x00D7D23C: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515113590888
        this.temp_Id = val_5;
        // 0x00D7D240: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7D244: SUB sp, x29, #0x20         | SP = (1152921515113578800 - 32) = 1152921515113578768 (0x1000000272400110);
        // 0x00D7D248: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7D24C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7D250: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7D254: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7D258: ADD x8, sp, #8             | X8 = (1152921515113578752 + 8) = 1152921515113578760 (0x1000000272400108);
        // 0x00D7D25C: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7D260: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7D264: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515113566816]
        // 0x00D7D268: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7D26C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D270: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7D274: ADD x0, sp, #8             | X0 = (1152921515113578752 + 8) = 1152921515113578760 (0x1000000272400108);
        // 0x00D7D278: BL #0x299a140              | 
        // 0x00D7D27C: MOV x19, x0                | X19 = 1152921515113578760 (0x1000000272400108);//ML01
        // 0x00D7D280: ADD x0, sp, #8             | X0 = (1152921515113578752 + 8) = 1152921515113578760 (0x1000000272400108);
        // 0x00D7D284: BL #0x299a140              | 
        // 0x00D7D288: MOV x0, x19                | X0 = 1152921515113578760 (0x1000000272400108);//ML01
        // 0x00D7D28C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000272400108, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D290 (14144144), len: 368  VirtAddr: 0x00D7D290 RVA: 0x00D7D290 token: 100694147 methodIndex: 25831 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnMoveCameraComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7D290: STP x22, x21, [sp, #-0x30]! | stack[1152921515113731728] = ???;  stack[1152921515113731736] = ???;  //  dest_result_addr=1152921515113731728 |  dest_result_addr=1152921515113731736
        // 0x00D7D294: STP x20, x19, [sp, #0x10]  | stack[1152921515113731744] = ???;  stack[1152921515113731752] = ???;  //  dest_result_addr=1152921515113731744 |  dest_result_addr=1152921515113731752
        // 0x00D7D298: STP x29, x30, [sp, #0x20]  | stack[1152921515113731760] = ???;  stack[1152921515113731768] = ???;  //  dest_result_addr=1152921515113731760 |  dest_result_addr=1152921515113731768
        // 0x00D7D29C: ADD x29, sp, #0x20         | X29 = (1152921515113731728 + 32) = 1152921515113731760 (0x10000002724256B0);
        // 0x00D7D2A0: SUB sp, sp, #0x10          | SP = (1152921515113731728 - 16) = 1152921515113731712 (0x1000000272425680);
        // 0x00D7D2A4: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7D2A8: LDRB w8, [x21, #0x3fc]     | W8 = (bool)static_value_037343FC;       
        // 0x00D7D2AC: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7D2B0: MOV x19, x0                | X19 = 1152921515113743776 (0x10000002724285A0);//ML01
        // 0x00D7D2B4: TBNZ w8, #0, #0xd7d2d0     | if (static_value_037343FC == true) goto label_0;
        // 0x00D7D2B8: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x00D7D2BC: LDR x8, [x8, #0x298]       | X8 = 0x2B90334;                         
        // 0x00D7D2C0: LDR w0, [x8]               | W0 = 0x1791;                            
        // 0x00D7D2C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1791, ????);     
        // 0x00D7D2C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D2CC: STRB w8, [x21, #0x3fc]     | static_value_037343FC = true;            //  dest_result_addr=57885692
        label_0:
        // 0x00D7D2D0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7D2D4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7D2D8: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7D2DC: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7D2E0: TBZ w8, #0, #0xd7d2f0      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7D2E4: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D2E8: CBNZ w8, #0xd7d2f0         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7D2EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7D2F0: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00D7D2F4: LDR x8, [x8, #0x5a8]       | X8 = (string**)(1152921513178512912)("0");
        // 0x00D7D2F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D2FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D300: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7D304: LDR x1, [x8]               | X1 = "0";                               
        // 0x00D7D308: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7D30C: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7D310: CBNZ x21, #0xd7d318        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7D314: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7D318: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7D31C: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7D320: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7D324: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7D328: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7D32C: CBZ w0, #0xd7d398          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7D330: CBNZ x20, #0xd7d338        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7D334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7D338: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7D33C: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7D340: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7D344: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7D348: CBNZ x21, #0xd7d350        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7D34C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7D350: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7D354: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7D358: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7D35C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7D360: B.NE #0xd7d3c8             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7D364: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7D368: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7D36C: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7D370: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7D374: ADD x1, sp, #4             | X1 = (1152921515113731712 + 4) = 1152921515113731716 (0x1000000272425684);
        // 0x00D7D378: STR w8, [sp, #4]           | stack[1152921515113731716] = typeof(System.Object);  //  dest_result_addr=1152921515113731716
        // 0x00D7D37C: BL #0x27bc028              | X0 = 1152921515113788064 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7D380: MOV x2, x0                 | X2 = 1152921515113788064 (0x10000002724332A0);//ML01
        // 0x00D7D384: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7D388: MOV x0, x19                | X0 = 1152921515113743776 (0x10000002724285A0);//ML01
        // 0x00D7D38C: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  0, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  0, arg:  null);
        // 0x00D7D390: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7D394: B #0xd7d3a8                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7D398: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7D39C: CBNZ x20, #0xd7d3a4        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7D3A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7D3A4: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7D3A8: MOV x0, x19                | X0 = 1152921515113743776 (0x10000002724285A0);//ML01
        // 0x00D7D3AC: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515113743848
        this.temp_Id = val_5;
        // 0x00D7D3B0: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7D3B4: SUB sp, x29, #0x20         | SP = (1152921515113731760 - 32) = 1152921515113731728 (0x1000000272425690);
        // 0x00D7D3B8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7D3BC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7D3C0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7D3C4: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7D3C8: ADD x8, sp, #8             | X8 = (1152921515113731712 + 8) = 1152921515113731720 (0x1000000272425688);
        // 0x00D7D3CC: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7D3D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7D3D4: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515113719776]
        // 0x00D7D3D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7D3DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D3E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7D3E4: ADD x0, sp, #8             | X0 = (1152921515113731712 + 8) = 1152921515113731720 (0x1000000272425688);
        // 0x00D7D3E8: BL #0x299a140              | 
        // 0x00D7D3EC: MOV x19, x0                | X19 = 1152921515113731720 (0x1000000272425688);//ML01
        // 0x00D7D3F0: ADD x0, sp, #8             | X0 = (1152921515113731712 + 8) = 1152921515113731720 (0x1000000272425688);
        // 0x00D7D3F4: BL #0x299a140              | 
        // 0x00D7D3F8: MOV x0, x19                | X0 = 1152921515113731720 (0x1000000272425688);//ML01
        // 0x00D7D3FC: BL #0x980800               | X0 = sub_980800( ?? 0x1000000272425688, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D400 (14144512), len: 368  VirtAddr: 0x00D7D400 RVA: 0x00D7D400 token: 100694148 methodIndex: 25832 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnMoveComplete(CEvent.ZEvent ev)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Collections.Generic.List<CameraShotVO> val_4;
        //  | 
        int val_5;
        // 0x00D7D400: STP x22, x21, [sp, #-0x30]! | stack[1152921515113884688] = ???;  stack[1152921515113884696] = ???;  //  dest_result_addr=1152921515113884688 |  dest_result_addr=1152921515113884696
        // 0x00D7D404: STP x20, x19, [sp, #0x10]  | stack[1152921515113884704] = ???;  stack[1152921515113884712] = ???;  //  dest_result_addr=1152921515113884704 |  dest_result_addr=1152921515113884712
        // 0x00D7D408: STP x29, x30, [sp, #0x20]  | stack[1152921515113884720] = ???;  stack[1152921515113884728] = ???;  //  dest_result_addr=1152921515113884720 |  dest_result_addr=1152921515113884728
        // 0x00D7D40C: ADD x29, sp, #0x20         | X29 = (1152921515113884688 + 32) = 1152921515113884720 (0x100000027244AC30);
        // 0x00D7D410: SUB sp, sp, #0x10          | SP = (1152921515113884688 - 16) = 1152921515113884672 (0x100000027244AC00);
        // 0x00D7D414: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7D418: LDRB w8, [x21, #0x3fd]     | W8 = (bool)static_value_037343FD;       
        // 0x00D7D41C: MOV x20, x1                | X20 = ev;//m1                           
        // 0x00D7D420: MOV x19, x0                | X19 = 1152921515113896736 (0x100000027244DB20);//ML01
        // 0x00D7D424: TBNZ w8, #0, #0xd7d440     | if (static_value_037343FD == true) goto label_0;
        // 0x00D7D428: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
        // 0x00D7D42C: LDR x8, [x8, #0x880]       | X8 = 0x2B90338;                         
        // 0x00D7D430: LDR w0, [x8]               | W0 = 0x1792;                            
        // 0x00D7D434: BL #0x2782188              | X0 = sub_2782188( ?? 0x1792, ????);     
        // 0x00D7D438: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D43C: STRB w8, [x21, #0x3fd]     | static_value_037343FD = true;            //  dest_result_addr=57885693
        label_0:
        // 0x00D7D440: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7D444: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7D448: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7D44C: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7D450: TBZ w8, #0, #0xd7d460      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7D454: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D458: CBNZ w8, #0xd7d460         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7D45C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7D460: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D7D464: LDR x8, [x8, #0xa30]       | X8 = (string**)(1152921514899915552)("5");
        // 0x00D7D468: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D46C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D470: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7D474: LDR x1, [x8]               | X1 = "5";                               
        // 0x00D7D478: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7D47C: LDR x21, [x19, #0x70]      | X21 = this.withQueue; //P2              
        val_4 = this.withQueue;
        // 0x00D7D480: CBNZ x21, #0xd7d488        | if (this.withQueue != null) goto label_3;
        if(val_4 != null)
        {
            goto label_3;
        }
        // 0x00D7D484: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x00D7D488: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7D48C: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7D490: MOV x0, x21                | X0 = this.withQueue;//m1                
        // 0x00D7D494: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7D498: BL #0x25ed72c              | X0 = this.withQueue.get_Count();        
        int val_1 = val_4.Count;
        // 0x00D7D49C: CBZ w0, #0xd7d508          | if (val_1 == 0) goto label_4;           
        if(val_1 == 0)
        {
            goto label_4;
        }
        // 0x00D7D4A0: CBNZ x20, #0xd7d4a8        | if (ev != null) goto label_5;           
        if(ev != null)
        {
            goto label_5;
        }
        // 0x00D7D4A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00D7D4A8: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7D4AC: LDR x21, [x20, #0x28]      | X21 = ev.arg; //P2                      
        val_4 = ev.arg;
        // 0x00D7D4B0: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7D4B4: LDR x20, [x22]             | X20 = typeof(System.Int32);             
        // 0x00D7D4B8: CBNZ x21, #0xd7d4c0        | if (ev.arg != null) goto label_6;       
        if(val_4 != null)
        {
            goto label_6;
        }
        // 0x00D7D4BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00D7D4C0: LDR x8, [x21]              | X8 = typeof(System.Object);             
        // 0x00D7D4C4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
        // 0x00D7D4C8: LDR x8, [x20, #0x30]       | X8 = System.Int32.__il2cppRuntimeField_element_class;
        // 0x00D7D4CC: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, System.Int32.__il2cppRuntimeField_element_class)
        // 0x00D7D4D0: B.NE #0xd7d538             | if (System.Object.__il2cppRuntimeField_element_class != System.Int32.__il2cppRuntimeField_element_class) goto label_7;
        // 0x00D7D4D4: MOV x0, x21                | X0 = ev.arg;//m1                        
        // 0x00D7D4D8: BL #0x27bc4e8              | ev.arg.System.IDisposable.Dispose();    
        val_4.System.IDisposable.Dispose();
        // 0x00D7D4DC: LDR w8, [x0]               | W8 = typeof(System.Object);             
        // 0x00D7D4E0: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7D4E4: ADD x1, sp, #4             | X1 = (1152921515113884672 + 4) = 1152921515113884676 (0x100000027244AC04);
        // 0x00D7D4E8: STR w8, [sp, #4]           | stack[1152921515113884676] = typeof(System.Object);  //  dest_result_addr=1152921515113884676
        // 0x00D7D4EC: BL #0x27bc028              | X0 = 1152921515113941024 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), typeof(System.Object));
        // 0x00D7D4F0: MOV x2, x0                 | X2 = 1152921515113941024 (0x1000000272458820);//ML01
        // 0x00D7D4F4: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
        // 0x00D7D4F8: MOV x0, x19                | X0 = 1152921515113896736 (0x100000027244DB20);//ML01
        // 0x00D7D4FC: BL #0xd7ba1c               | X0 = this.returnCameraShotId(funtype:  5, arg:  null);
        int val_2 = this.returnCameraShotId(funtype:  5, arg:  null);
        // 0x00D7D500: MOV w1, w0                 | W1 = val_2;//m1                         
        val_5 = val_2;
        // 0x00D7D504: B #0xd7d518                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00D7D508: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D7D50C: CBNZ x20, #0xd7d514        | if (this.curCameraShot != null) goto label_9;
        if(this.curCameraShot != null)
        {
            goto label_9;
        }
        // 0x00D7D510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00D7D514: LDR w1, [x20, #0x10]       | W1 = this.curCameraShot.id; //P2        
        val_5 = this.curCameraShot.id;
        label_8:
        // 0x00D7D518: MOV x0, x19                | X0 = 1152921515113896736 (0x100000027244DB20);//ML01
        // 0x00D7D51C: STR w1, [x19, #0x48]       | this.temp_Id = this.curCameraShot.id;    //  dest_result_addr=1152921515113896808
        this.temp_Id = val_5;
        // 0x00D7D520: BL #0xd7c4fc               | this.OnComplete(a:  val_5 = this.curCameraShot.id);
        this.OnComplete(a:  val_5);
        // 0x00D7D524: SUB sp, x29, #0x20         | SP = (1152921515113884720 - 32) = 1152921515113884688 (0x100000027244AC10);
        // 0x00D7D528: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7D52C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7D530: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7D534: RET                        |  return;                                
        return;
        label_7:
        // 0x00D7D538: ADD x8, sp, #8             | X8 = (1152921515113884672 + 8) = 1152921515113884680 (0x100000027244AC08);
        // 0x00D7D53C: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7D540: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
        // 0x00D7D544: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921515113872736]
        // 0x00D7D548: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
        // 0x00D7D54C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D550: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        // 0x00D7D554: ADD x0, sp, #8             | X0 = (1152921515113884672 + 8) = 1152921515113884680 (0x100000027244AC08);
        // 0x00D7D558: BL #0x299a140              | 
        // 0x00D7D55C: MOV x19, x0                | X19 = 1152921515113884680 (0x100000027244AC08);//ML01
        // 0x00D7D560: ADD x0, sp, #8             | X0 = (1152921515113884672 + 8) = 1152921515113884680 (0x100000027244AC08);
        // 0x00D7D564: BL #0x299a140              | 
        // 0x00D7D568: MOV x0, x19                | X0 = 1152921515113884680 (0x100000027244AC08);//ML01
        // 0x00D7D56C: BL #0x980800               | X0 = sub_980800( ?? 0x100000027244AC08, ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D570 (14144880), len: 244  VirtAddr: 0x00D7D570 RVA: 0x00D7D570 token: 100694149 methodIndex: 25833 delegateWrapperIndex: 0 methodInvoker: 0
    public void Open()
    {
        //
        // Disasemble & Code
        // 0x00D7D570: STP x20, x19, [sp, #-0x20]! | stack[1152921515114025488] = ???;  stack[1152921515114025496] = ???;  //  dest_result_addr=1152921515114025488 |  dest_result_addr=1152921515114025496
        // 0x00D7D574: STP x29, x30, [sp, #0x10]  | stack[1152921515114025504] = ???;  stack[1152921515114025512] = ???;  //  dest_result_addr=1152921515114025504 |  dest_result_addr=1152921515114025512
        // 0x00D7D578: ADD x29, sp, #0x10         | X29 = (1152921515114025488 + 16) = 1152921515114025504 (0x100000027246D220);
        // 0x00D7D57C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7D580: LDRB w8, [x20, #0x3fe]     | W8 = (bool)static_value_037343FE;       
        // 0x00D7D584: MOV x19, x0                | X19 = 1152921515114037520 (0x1000000272470110);//ML01
        // 0x00D7D588: TBNZ w8, #0, #0xd7d5a4     | if (static_value_037343FE == true) goto label_0;
        // 0x00D7D58C: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
        // 0x00D7D590: LDR x8, [x8, #0x5a0]       | X8 = 0x2B90358;                         
        // 0x00D7D594: LDR w0, [x8]               | W0 = 0x179A;                            
        // 0x00D7D598: BL #0x2782188              | X0 = sub_2782188( ?? 0x179A, ????);     
        // 0x00D7D59C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D5A0: STRB w8, [x20, #0x3fe]     | static_value_037343FE = true;            //  dest_result_addr=57885694
        label_0:
        // 0x00D7D5A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D5A8: STRB w8, [x19, #0x44]      | this.isCameraShotRunning = true;         //  dest_result_addr=1152921515114037588
        this.isCameraShotRunning = true;
        // 0x00D7D5AC: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7D5B0: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
        // 0x00D7D5B4: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
        // 0x00D7D5B8: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00D7D5BC: TBZ w8, #0, #0xd7d5cc      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7D5C0: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D5C4: CBNZ w8, #0xd7d5cc         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7D5C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        label_2:
        // 0x00D7D5CC: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00D7D5D0: ADRP x9, #0x3630000        | X9 = 56819712 (0x3630000);              
        // 0x00D7D5D4: LDR x8, [x8, #0x878]       | X8 = (string**)(1152921515114005216)("OpenCameraShotFace");
        // 0x00D7D5D8: LDR x9, [x9, #0x3d0]       | X9 = 1152921504954501264;               
        // 0x00D7D5DC: LDR x19, [x8]              | X19 = "OpenCameraShotFace";             
        // 0x00D7D5E0: LDR x20, [x9]              | X20 = typeof(System.Object[]);          
        // 0x00D7D5E4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7D5E8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D7D5EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D5F0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7D5F4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D7D5F8: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7D5FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D604: MOV x1, x19                | X1 = 1152921515114005216 (0x10000002724682E0);//ML01
        // 0x00D7D608: BL #0xba5838               | CallJSApi.CallJsFun(funName:  0, args:  "OpenCameraShotFace");
        CallJSApi.CallJsFun(funName:  0, args:  "OpenCameraShotFace");
        // 0x00D7D60C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D610: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D614: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_1 = HeroMgr.instance;
        // 0x00D7D618: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00D7D61C: CBNZ x19, #0xd7d624        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D7D620: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D7D624: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7D628: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7D62C: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00D7D630: BL #0x289bcc0              | val_1.SetHeroModelView(isShow:  false); 
        val_1.SetHeroModelView(isShow:  false);
        // 0x00D7D634: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D63C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_2 = NpcMgr.instance;
        // 0x00D7D640: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00D7D644: CBNZ x19, #0xd7d64c        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00D7D648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00D7D64C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7D650: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7D654: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D7D658: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00D7D65C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D7D660: B #0xd18db0                | val_2.SetMonsterNotSelected(isShow:  true); return;
        val_2.SetMonsterNotSelected(isShow:  true);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D664 (14145124), len: 400  VirtAddr: 0x00D7D664 RVA: 0x00D7D664 token: 100694150 methodIndex: 25834 delegateWrapperIndex: 0 methodInvoker: 0
    public void JumpAllStory(CEvent.ZEvent e)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x00D7D664: STP x22, x21, [sp, #-0x30]! | stack[1152921515114159072] = ???;  stack[1152921515114159080] = ???;  //  dest_result_addr=1152921515114159072 |  dest_result_addr=1152921515114159080
        // 0x00D7D668: STP x20, x19, [sp, #0x10]  | stack[1152921515114159088] = ???;  stack[1152921515114159096] = ???;  //  dest_result_addr=1152921515114159088 |  dest_result_addr=1152921515114159096
        // 0x00D7D66C: STP x29, x30, [sp, #0x20]  | stack[1152921515114159104] = ???;  stack[1152921515114159112] = ???;  //  dest_result_addr=1152921515114159104 |  dest_result_addr=1152921515114159112
        // 0x00D7D670: ADD x29, sp, #0x20         | X29 = (1152921515114159072 + 32) = 1152921515114159104 (0x100000027248DC00);
        // 0x00D7D674: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7D678: LDRB w8, [x20, #0x3ff]     | W8 = (bool)static_value_037343FF;       
        // 0x00D7D67C: MOV x19, x0                | X19 = 1152921515114171120 (0x1000000272490AF0);//ML01
        // 0x00D7D680: TBNZ w8, #0, #0xd7d69c     | if (static_value_037343FF == true) goto label_0;
        // 0x00D7D684: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x00D7D688: LDR x8, [x8, #0x458]       | X8 = 0x2B9030C;                         
        // 0x00D7D68C: LDR w0, [x8]               | W0 = 0x1787;                            
        // 0x00D7D690: BL #0x2782188              | X0 = sub_2782188( ?? 0x1787, ????);     
        // 0x00D7D694: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D698: STRB w8, [x20, #0x3ff]     | static_value_037343FF = true;            //  dest_result_addr=57885695
        label_0:
        // 0x00D7D69C: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7D6A0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7D6A4: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7D6A8: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7D6AC: TBZ w8, #0, #0xd7d6bc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7D6B0: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D6B4: CBNZ w8, #0xd7d6bc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7D6B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_2:
        // 0x00D7D6BC: ADRP x8, #0x35be000        | X8 = 56352768 (0x35BE000);              
        // 0x00D7D6C0: LDR x8, [x8, #0xd98]       | X8 = (string**)(1152921515114137808)("event Jump");
        // 0x00D7D6C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D6C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D6CC: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7D6D0: LDR x1, [x8]               | X1 = "event Jump";                      
        // 0x00D7D6D4: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7D6D8: ADRP x21, #0x35c4000       | X21 = 56377344 (0x35C4000);             
        // 0x00D7D6DC: ADRP x22, #0x35fa000       | X22 = 56598528 (0x35FA000);             
        // 0x00D7D6E0: LDR x21, [x21, #0x5d0]     | X21 = 1152921515111781984;              
        // 0x00D7D6E4: LDR x22, [x22, #0x898]     | X22 = 1152921515114137904;              
        // 0x00D7D6E8: B #0xd7d6fc                |  goto label_3;                          
        goto label_3;
        label_7:
        // 0x00D7D6EC: LDR x2, [x22]              | X2 = public System.Void System.Collections.Generic.List<CameraShotVO>::RemoveAt(int index);
        // 0x00D7D6F0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7D6F4: MOV x0, x20                | X0 = 57884672 (0x3734000);//ML01        
        // 0x00D7D6F8: BL #0x25ed00c              | RemoveAt(index:  0);                    
        RemoveAt(index:  0);
        label_3:
        // 0x00D7D6FC: LDR x20, [x19, #0x68]      | X20 = this.cameraShotQueue; //P2        
        // 0x00D7D700: CBNZ x20, #0xd7d708        | if (this.cameraShotQueue != null) goto label_4;
        if(this.cameraShotQueue != null)
        {
            goto label_4;
        }
        // 0x00D7D704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3734000, ????);  
        label_4:
        // 0x00D7D708: LDR x1, [x21]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7D70C: MOV x0, x20                | X0 = this.cameraShotQueue;//m1          
        // 0x00D7D710: BL #0x25ed72c              | X0 = this.cameraShotQueue.get_Count();  
        int val_1 = this.cameraShotQueue.Count;
        // 0x00D7D714: SUB w8, w0, #1             | W8 = (val_1 - 1);                       
        int val_2 = val_1 - 1;
        // 0x00D7D718: CMP w8, #0                 | STATE = COMPARE((val_1 - 1), 0x0)       
        // 0x00D7D71C: B.LE #0xd7d730             | if (val_2 <= 0) goto label_5;           
        if(val_2 <= 0)
        {
            goto label_5;
        }
        // 0x00D7D720: LDR x20, [x19, #0x68]      | X20 = this.cameraShotQueue; //P2        
        // 0x00D7D724: CBNZ x20, #0xd7d6ec        | if (this.cameraShotQueue != null) goto label_7;
        if(this.cameraShotQueue != null)
        {
            goto label_7;
        }
        // 0x00D7D728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        // 0x00D7D72C: B #0xd7d6ec                |  goto label_7;                          
        goto label_7;
        label_5:
        // 0x00D7D730: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
        // 0x00D7D734: LDR x21, [x21, #0x8b0]     | X21 = 1152921504887996416;              
        // 0x00D7D738: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_4 = null;
        // 0x00D7D73C: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7D740: TBZ w8, #0, #0xd7d754      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00D7D744: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D748: CBNZ w8, #0xd7d754         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00D7D74C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7D750: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_4 = null;
        label_9:
        // 0x00D7D754: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7D758: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7D75C: CBNZ x20, #0xd7d764        | if (CameraShotHelper.instance != null) goto label_10;
        if(CameraShotHelper.instance != null)
        {
            goto label_10;
        }
        // 0x00D7D760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_10:
        // 0x00D7D764: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7D768: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7D76C: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7D770: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7D774: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7D778: TBZ w8, #0, #0xd7d788      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00D7D77C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D780: CBNZ w8, #0xd7d788         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00D7D784: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x00D7D788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D78C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D790: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D794: MOV x2, x20                | X2 = 1152921504843214848 (0x100000000E16B000);//ML01
        // 0x00D7D798: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_3 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00D7D79C: TBZ w0, #0, #0xd7d7e0      | if (val_3 == false) goto label_13;      
        if(val_3 == false)
        {
            goto label_13;
        }
        // 0x00D7D7A0: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_5 = null;
        // 0x00D7D7A4: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7D7A8: TBZ w8, #0, #0xd7d7bc      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00D7D7AC: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D7B0: CBNZ w8, #0xd7d7bc         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00D7D7B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7D7B8: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_5 = null;
        label_15:
        // 0x00D7D7BC: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7D7C0: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7D7C4: CBNZ x20, #0xd7d7cc        | if (CameraShotHelper.instance != null) goto label_16;
        if(CameraShotHelper.instance != null)
        {
            goto label_16;
        }
        // 0x00D7D7C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_16:
        // 0x00D7D7CC: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7D7D0: CBNZ x20, #0xd7d7d8        | if ( != 0) goto label_17;               
        if(null != 0)
        {
            goto label_17;
        }
        // 0x00D7D7D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_17:
        // 0x00D7D7D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D7DC: STRB w8, [x20, #0x88]      | typeof(CameraBezier).__il2cppRuntimeField_88 = 0x1;  //  dest_result_addr=1152921504843214984
        typeof(CameraBezier).__il2cppRuntimeField_88 = 1;
        label_13:
        // 0x00D7D7E0: MOV x0, x19                | X0 = 1152921515114171120 (0x1000000272490AF0);//ML01
        // 0x00D7D7E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7D7E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7D7EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7D7F0: B #0xd79714                | this.Execute(); return;                 
        this.Execute();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7D7F4 (14145524), len: 1020  VirtAddr: 0x00D7D7F4 RVA: 0x00D7D7F4 token: 100694151 methodIndex: 25835 delegateWrapperIndex: 0 methodInvoker: 0
    public void Close()
    {
        //
        // Disasemble & Code
        //  | 
        var val_16;
        // 0x00D7D7F4: STP d11, d10, [sp, #-0x50]! | stack[1152921515114349072] = ???;  stack[1152921515114349080] = ???;  //  dest_result_addr=1152921515114349072 |  dest_result_addr=1152921515114349080
        // 0x00D7D7F8: STP d9, d8, [sp, #0x10]    | stack[1152921515114349088] = ???;  stack[1152921515114349096] = ???;  //  dest_result_addr=1152921515114349088 |  dest_result_addr=1152921515114349096
        // 0x00D7D7FC: STP x22, x21, [sp, #0x20]  | stack[1152921515114349104] = ???;  stack[1152921515114349112] = ???;  //  dest_result_addr=1152921515114349104 |  dest_result_addr=1152921515114349112
        // 0x00D7D800: STP x20, x19, [sp, #0x30]  | stack[1152921515114349120] = ???;  stack[1152921515114349128] = ???;  //  dest_result_addr=1152921515114349120 |  dest_result_addr=1152921515114349128
        // 0x00D7D804: STP x29, x30, [sp, #0x40]  | stack[1152921515114349136] = ???;  stack[1152921515114349144] = ???;  //  dest_result_addr=1152921515114349136 |  dest_result_addr=1152921515114349144
        // 0x00D7D808: ADD x29, sp, #0x40         | X29 = (1152921515114349072 + 64) = 1152921515114349136 (0x10000002724BC250);
        // 0x00D7D80C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7D810: LDRB w8, [x20, #0x400]     | W8 = (bool)static_value_03734400;       
        // 0x00D7D814: MOV x19, x0                | X19 = 1152921515114361152 (0x10000002724BF140);//ML01
        // 0x00D7D818: TBNZ w8, #0, #0xd7d834     | if (static_value_03734400 == true) goto label_0;
        // 0x00D7D81C: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
        // 0x00D7D820: LDR x8, [x8, #0x3d0]       | X8 = 0x2B902F8;                         
        // 0x00D7D824: LDR w0, [x8]               | W0 = 0x1782;                            
        // 0x00D7D828: BL #0x2782188              | X0 = sub_2782188( ?? 0x1782, ????);     
        // 0x00D7D82C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7D830: STRB w8, [x20, #0x400]     | static_value_03734400 = true;            //  dest_result_addr=57885696
        label_0:
        // 0x00D7D834: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D838: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D83C: STRB wzr, [x19, #0x44]     | this.isCameraShotRunning = false;        //  dest_result_addr=1152921515114361220
        this.isCameraShotRunning = false;
        // 0x00D7D840: STRB wzr, [x19, #0x34]     | this.isEditorRun = false;                //  dest_result_addr=1152921515114361204
        this.isEditorRun = false;
        // 0x00D7D844: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_1 = HeroMgr.instance;
        // 0x00D7D848: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D7D84C: CBNZ x20, #0xd7d854        | if (val_1 != null) goto label_1;        
        if(val_1 != null)
        {
            goto label_1;
        }
        // 0x00D7D850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00D7D854: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7D858: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D7D85C: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D7D860: BL #0x289bcc0              | val_1.SetHeroModelView(isShow:  true);  
        val_1.SetHeroModelView(isShow:  true);
        // 0x00D7D864: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D86C: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_2 = NpcMgr.instance;
        // 0x00D7D870: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00D7D874: CBNZ x20, #0xd7d87c        | if (val_2 != null) goto label_2;        
        if(val_2 != null)
        {
            goto label_2;
        }
        // 0x00D7D878: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_2:
        // 0x00D7D87C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7D880: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7D884: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00D7D888: BL #0xd18db0               | val_2.SetMonsterNotSelected(isShow:  false);
        val_2.SetMonsterNotSelected(isShow:  false);
        // 0x00D7D88C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D890: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D894: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_3 = NpcMgr.instance;
        // 0x00D7D898: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00D7D89C: CBNZ x20, #0xd7d8a4        | if (val_3 != null) goto label_3;        
        if(val_3 != null)
        {
            goto label_3;
        }
        // 0x00D7D8A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00D7D8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D8A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7D8AC: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00D7D8B0: BL #0xd17f7c               | val_3.ClearAniShowList(special:  0);    
        val_3.ClearAniShowList(special:  0);
        // 0x00D7D8B4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D7D8B8: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00D7D8BC: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00D7D8C0: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7D8C4: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D7D8C8: CBNZ x20, #0xd7d8d0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_4;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_4;
        }
        // 0x00D7D8CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00D7D8D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D8D4: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7D8D8: BL #0xc19860               | GameMgr.UPDATEOnOffEffect.UnLockNpcBehaviour();
        GameMgr.UPDATEOnOffEffect.UnLockNpcBehaviour();
        // 0x00D7D8DC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7D8E0: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7D8E4: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D7D8E8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7D8EC: TBZ w8, #0, #0xd7d8fc      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D7D8F0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D8F4: CBNZ w8, #0xd7d8fc         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D7D8F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_6:
        // 0x00D7D8FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D904: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_4 = ZMG.EffectMgr;
        // 0x00D7D908: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00D7D90C: CBNZ x20, #0xd7d914        | if (val_4 != null) goto label_7;        
        if(val_4 != null)
        {
            goto label_7;
        }
        // 0x00D7D910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_7:
        // 0x00D7D914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D918: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x00D7D91C: BL #0xb60764               | val_4.Clear();                          
        val_4.Clear();
        // 0x00D7D920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D924: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D928: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_5 = ZMG.EffectMgr;
        // 0x00D7D92C: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x00D7D930: CBNZ x20, #0xd7d938        | if (val_5 != null) goto label_8;        
        if(val_5 != null)
        {
            goto label_8;
        }
        // 0x00D7D934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_8:
        // 0x00D7D938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D93C: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x00D7D940: BL #0xb5fdc8               | val_5.ClearSceneEffect();               
        val_5.ClearSceneEffect();
        // 0x00D7D944: LDR x19, [x19, #0x78]      | X19 = this.effectDic; //P2              
        // 0x00D7D948: CBNZ x19, #0xd7d950        | if (this.effectDic != null) goto label_9;
        if(this.effectDic != null)
        {
            goto label_9;
        }
        // 0x00D7D94C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00D7D950: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00D7D954: LDR x8, [x8, #0xa00]       | X8 = 1152921510773143760;               
        // 0x00D7D958: MOV x0, x19                | X0 = this.effectDic;//m1                
        // 0x00D7D95C: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::Clear();
        // 0x00D7D960: BL #0x2415b18              | this.effectDic.Clear();                 
        this.effectDic.Clear();
        // 0x00D7D964: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D968: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D96C: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_6 = ZMG.EffectMgr;
        // 0x00D7D970: MOV x19, x0                | X19 = val_6;//m1                        
        // 0x00D7D974: CBNZ x19, #0xd7d97c        | if (val_6 != null) goto label_10;       
        if(val_6 != null)
        {
            goto label_10;
        }
        // 0x00D7D978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_10:
        // 0x00D7D97C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D980: MOV x0, x19                | X0 = val_6;//m1                         
        // 0x00D7D984: BL #0xb5fdc8               | val_6.ClearSceneEffect();               
        val_6.ClearSceneEffect();
        // 0x00D7D988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7D98C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D990: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_7 = NpcMgr.instance;
        // 0x00D7D994: MOV x19, x0                | X19 = val_7;//m1                        
        // 0x00D7D998: CBNZ x19, #0xd7d9a0        | if (val_7 != null) goto label_11;       
        if(val_7 != null)
        {
            goto label_11;
        }
        // 0x00D7D99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_11:
        // 0x00D7D9A0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7D9A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7D9A8: MOV x0, x19                | X0 = val_7;//m1                         
        // 0x00D7D9AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7D9B0: BL #0xd18380               | val_7.CameraShotBattle(isTruth:  0, specialInTruth:  0);
        val_7.CameraShotBattle(isTruth:  0, specialInTruth:  0);
        // 0x00D7D9B4: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D7D9B8: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D7D9BC: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_16 = null;
        // 0x00D7D9C0: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7D9C4: TBZ w8, #0, #0xd7d9d8      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00D7D9C8: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7D9CC: CBNZ w8, #0xd7d9d8         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00D7D9D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7D9D4: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_16 = null;
        label_13:
        // 0x00D7D9D8: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7D9DC: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7D9E0: CBNZ x19, #0xd7d9e8        | if (CameraShotHelper.instance != null) goto label_14;
        if(CameraShotHelper.instance != null)
        {
            goto label_14;
        }
        // 0x00D7D9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_14:
        // 0x00D7D9E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7D9EC: MOV x0, x19                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7D9F0: BL #0xbadea4               | CameraShotHelper.instance.Clear();      
        CameraShotHelper.instance.Clear();
        // 0x00D7D9F4: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7D9F8: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7D9FC: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DA00: CBNZ x19, #0xd7da08        | if (CameraShotHelper.instance != null) goto label_15;
        if(CameraShotHelper.instance != null)
        {
            goto label_15;
        }
        // 0x00D7DA04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraShotHelper.instance, ????);
        label_15:
        // 0x00D7DA08: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7DA0C: STRB w8, [x19, #0x20]      | CameraShotHelper.instance.IsOpeningMoveUpdate = true;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = true;
        // 0x00D7DA10: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7DA14: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7DA18: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DA1C: CBNZ x19, #0xd7da24        | if (CameraShotHelper.instance != null) goto label_16;
        if(CameraShotHelper.instance != null)
        {
            goto label_16;
        }
        // 0x00D7DA20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraShotHelper.instance, ????);
        label_16:
        // 0x00D7DA24: STRB wzr, [x19, #0x22]     | CameraShotHelper.instance.isCircleCameraMoving = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isCircleCameraMoving = false;
        // 0x00D7DA28: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7DA2C: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7DA30: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DA34: CBNZ x19, #0xd7da3c        | if (CameraShotHelper.instance != null) goto label_17;
        if(CameraShotHelper.instance != null)
        {
            goto label_17;
        }
        // 0x00D7DA38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraShotHelper.instance, ????);
        label_17:
        // 0x00D7DA3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DA44: STRB wzr, [x19, #0xbc]     | CameraShotHelper.instance.isLineRunning = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isLineRunning = false;
        // 0x00D7DA48: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_8 = UnityEngine.Camera.main;
        // 0x00D7DA4C: MOV x19, x0                | X19 = val_8;//m1                        
        // 0x00D7DA50: CBNZ x19, #0xd7da58        | if (val_8 != null) goto label_18;       
        if(val_8 != null)
        {
            goto label_18;
        }
        // 0x00D7DA54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_18:
        // 0x00D7DA58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DA5C: MOV x0, x19                | X0 = val_8;//m1                         
        // 0x00D7DA60: BL #0x20d5094              | X0 = val_8.get_transform();             
        UnityEngine.Transform val_9 = val_8.transform;
        // 0x00D7DA64: MOV x19, x0                | X19 = val_9;//m1                        
        // 0x00D7DA68: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DA6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DA70: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_10 = HeroMgr.instance;
        // 0x00D7DA74: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00D7DA78: CBNZ x20, #0xd7da80        | if (val_10 != null) goto label_19;      
        if(val_10 != null)
        {
            goto label_19;
        }
        // 0x00D7DA7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_19:
        // 0x00D7DA80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DA84: MOV x0, x20                | X0 = val_10;//m1                        
        // 0x00D7DA88: BL #0x28964e8              | X0 = val_10.get_CameraSmoothFollow();   
        CameraSmoothFollow val_11 = val_10.CameraSmoothFollow;
        // 0x00D7DA8C: MOV x20, x0                | X20 = val_11;//m1                       
        // 0x00D7DA90: CBNZ x20, #0xd7da98        | if (val_11 != null) goto label_20;      
        if(val_11 != null)
        {
            goto label_20;
        }
        // 0x00D7DA94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_20:
        // 0x00D7DA98: LDP s8, s9, [x20, #0xa0]   | S8 = val_11.lastPos; //P2                //  | 
        // 0x00D7DA9C: LDR s10, [x20, #0xa8]      | 
        // 0x00D7DAA0: CBNZ x19, #0xd7daa8        | if (val_9 != null) goto label_21;       
        if(val_9 != null)
        {
            goto label_21;
        }
        // 0x00D7DAA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_21:
        // 0x00D7DAA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DAAC: MOV x0, x19                | X0 = val_9;//m1                         
        // 0x00D7DAB0: MOV v0.16b, v8.16b         | V0 = val_11.lastPos;//m1                
        // 0x00D7DAB4: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00D7DAB8: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00D7DABC: BL #0x26935b8              | val_9.set_position(value:  new UnityEngine.Vector3() {x = val_11.lastPos, y = V9.16B, z = V10.16B});
        val_9.position = new UnityEngine.Vector3() {x = val_11.lastPos, y = V9.16B, z = V10.16B};
        // 0x00D7DAC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DAC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DAC8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_12 = UnityEngine.Camera.main;
        // 0x00D7DACC: MOV x19, x0                | X19 = val_12;//m1                       
        // 0x00D7DAD0: CBNZ x19, #0xd7dad8        | if (val_12 != null) goto label_22;      
        if(val_12 != null)
        {
            goto label_22;
        }
        // 0x00D7DAD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_22:
        // 0x00D7DAD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DADC: MOV x0, x19                | X0 = val_12;//m1                        
        // 0x00D7DAE0: BL #0x20d5094              | X0 = val_12.get_transform();            
        UnityEngine.Transform val_13 = val_12.transform;
        // 0x00D7DAE4: MOV x19, x0                | X19 = val_13;//m1                       
        // 0x00D7DAE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DAEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DAF0: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_14 = HeroMgr.instance;
        // 0x00D7DAF4: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x00D7DAF8: CBNZ x20, #0xd7db00        | if (val_14 != null) goto label_23;      
        if(val_14 != null)
        {
            goto label_23;
        }
        // 0x00D7DAFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_23:
        // 0x00D7DB00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DB04: MOV x0, x20                | X0 = val_14;//m1                        
        // 0x00D7DB08: BL #0x28964e8              | X0 = val_14.get_CameraSmoothFollow();   
        CameraSmoothFollow val_15 = val_14.CameraSmoothFollow;
        // 0x00D7DB0C: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00D7DB10: CBNZ x20, #0xd7db18        | if (val_15 != null) goto label_24;      
        if(val_15 != null)
        {
            goto label_24;
        }
        // 0x00D7DB14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_24:
        // 0x00D7DB18: LDP s8, s9, [x20, #0x90]   | S8 = val_15.lastRotation; //P2           //  | 
        // 0x00D7DB1C: LDP s10, s11, [x20, #0x98] |                                          //  | 
        // 0x00D7DB20: CBNZ x19, #0xd7db28        | if (val_13 != null) goto label_25;      
        if(val_13 != null)
        {
            goto label_25;
        }
        // 0x00D7DB24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_25:
        // 0x00D7DB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DB2C: MOV x0, x19                | X0 = val_13;//m1                        
        // 0x00D7DB30: MOV v0.16b, v8.16b         | V0 = val_15.lastRotation;//m1           
        // 0x00D7DB34: MOV v1.16b, v9.16b         | V1 = V9.16B;//m1                        
        // 0x00D7DB38: MOV v2.16b, v10.16b        | V2 = V10.16B;//m1                       
        // 0x00D7DB3C: MOV v3.16b, v11.16b        | V3 = V11.16B;//m1                       
        // 0x00D7DB40: BL #0x26938b0              | val_13.set_rotation(value:  new UnityEngine.Quaternion() {x = val_15.lastRotation, y = V9.16B, z = V10.16B, w = V11.16B});
        val_13.rotation = new UnityEngine.Quaternion() {x = val_15.lastRotation, y = V9.16B, z = V10.16B, w = V11.16B};
        // 0x00D7DB44: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7DB48: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
        // 0x00D7DB4C: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
        // 0x00D7DB50: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00D7DB54: TBZ w8, #0, #0xd7db64      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_27;
        // 0x00D7DB58: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00D7DB5C: CBNZ w8, #0xd7db64         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
        // 0x00D7DB60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        label_27:
        // 0x00D7DB64: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
        // 0x00D7DB68: ADRP x21, #0x3630000       | X21 = 56819712 (0x3630000);             
        // 0x00D7DB6C: LDR x8, [x8, #0xe30]       | X8 = (string**)(1152921515114336944)("OpenCombatFace");
        // 0x00D7DB70: LDR x21, [x21, #0x3d0]     | X21 = 1152921504954501264;              
        // 0x00D7DB74: LDR x19, [x8]              | X19 = "OpenCombatFace";                 
        // 0x00D7DB78: LDR x20, [x21]             | X20 = typeof(System.Object[]);          
        // 0x00D7DB7C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7DB80: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D7DB84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DB88: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7DB8C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D7DB90: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7DB94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DB98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7DB9C: MOV x1, x19                | X1 = 1152921515114336944 (0x10000002724B92B0);//ML01
        // 0x00D7DBA0: BL #0xba5838               | CallJSApi.CallJsFun(funName:  0, args:  "OpenCombatFace");
        CallJSApi.CallJsFun(funName:  0, args:  "OpenCombatFace");
        // 0x00D7DBA4: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00D7DBA8: LDR x8, [x8, #0xec8]       | X8 = (string**)(1152921515114337040)("CloseCameraShotFace");
        // 0x00D7DBAC: LDR x20, [x21]             | X20 = typeof(System.Object[]);          
        // 0x00D7DBB0: LDR x19, [x8]              | X19 = "CloseCameraShotFace";            
        // 0x00D7DBB4: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7DBB8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D7DBBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DBC0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7DBC4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D7DBC8: MOV x1, x19                | X1 = 1152921515114337040 (0x10000002724B9310);//ML01
        // 0x00D7DBCC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7DBD0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7DBD4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7DBD8: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00D7DBDC: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7DBE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DBE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7DBE8: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x00D7DBEC: B #0xba5838                | CallJSApi.CallJsFun(funName:  0, args:  "CloseCameraShotFace"); return;
        CallJSApi.CallJsFun(funName:  0, args:  "CloseCameraShotFace");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7DBF0 (14146544), len: 384  VirtAddr: 0x00D7DBF0 RVA: 0x00D7DBF0 token: 100694152 methodIndex: 25836 delegateWrapperIndex: 0 methodInvoker: 0
    public void ClosePeak()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00D7DBF0: STP x20, x19, [sp, #-0x20]! | stack[1152921515114543040] = ???;  stack[1152921515114543048] = ???;  //  dest_result_addr=1152921515114543040 |  dest_result_addr=1152921515114543048
        // 0x00D7DBF4: STP x29, x30, [sp, #0x10]  | stack[1152921515114543056] = ???;  stack[1152921515114543064] = ???;  //  dest_result_addr=1152921515114543056 |  dest_result_addr=1152921515114543064
        // 0x00D7DBF8: ADD x29, sp, #0x10         | X29 = (1152921515114543040 + 16) = 1152921515114543056 (0x10000002724EB7D0);
        // 0x00D7DBFC: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7DC00: LDRB w8, [x20, #0x401]     | W8 = (bool)static_value_03734401;       
        // 0x00D7DC04: MOV x19, x0                | X19 = 1152921515114555072 (0x10000002724EE6C0);//ML01
        // 0x00D7DC08: TBNZ w8, #0, #0xd7dc24     | if (static_value_03734401 == true) goto label_0;
        // 0x00D7DC0C: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00D7DC10: LDR x8, [x8, #0x438]       | X8 = 0x2B902FC;                         
        // 0x00D7DC14: LDR w0, [x8]               | W0 = 0x1783;                            
        // 0x00D7DC18: BL #0x2782188              | X0 = sub_2782188( ?? 0x1783, ????);     
        // 0x00D7DC1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7DC20: STRB w8, [x20, #0x401]     | static_value_03734401 = true;            //  dest_result_addr=57885697
        label_0:
        // 0x00D7DC24: STRB wzr, [x19, #0x34]     | this.isEditorRun = false;                //  dest_result_addr=1152921515114555124
        this.isEditorRun = false;
        // 0x00D7DC28: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7DC2C: STRB wzr, [x19, #0x44]     | this.isCameraShotRunning = false;        //  dest_result_addr=1152921515114555140
        this.isCameraShotRunning = false;
        // 0x00D7DC30: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7DC34: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D7DC38: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7DC3C: TBZ w8, #0, #0xd7dc4c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7DC40: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7DC44: CBNZ w8, #0xd7dc4c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7DC48: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_2:
        // 0x00D7DC4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DC54: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_1 = ZMG.EffectMgr;
        // 0x00D7DC58: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D7DC5C: CBNZ x20, #0xd7dc64        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00D7DC60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D7DC64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DC68: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00D7DC6C: BL #0xb60764               | val_1.Clear();                          
        val_1.Clear();
        // 0x00D7DC70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DC74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DC78: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_2 = ZMG.EffectMgr;
        // 0x00D7DC7C: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00D7DC80: CBNZ x20, #0xd7dc88        | if (val_2 != null) goto label_4;        
        if(val_2 != null)
        {
            goto label_4;
        }
        // 0x00D7DC84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00D7DC88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DC8C: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00D7DC90: BL #0xb5fdc8               | val_2.ClearSceneEffect();               
        val_2.ClearSceneEffect();
        // 0x00D7DC94: LDR x19, [x19, #0x78]      | X19 = this.effectDic; //P2              
        // 0x00D7DC98: CBNZ x19, #0xd7dca0        | if (this.effectDic != null) goto label_5;
        if(this.effectDic != null)
        {
            goto label_5;
        }
        // 0x00D7DC9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00D7DCA0: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
        // 0x00D7DCA4: LDR x8, [x8, #0xa00]       | X8 = 1152921510773143760;               
        // 0x00D7DCA8: MOV x0, x19                | X0 = this.effectDic;//m1                
        // 0x00D7DCAC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::Clear();
        // 0x00D7DCB0: BL #0x2415b18              | this.effectDic.Clear();                 
        this.effectDic.Clear();
        // 0x00D7DCB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7DCB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DCBC: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_3 = ZMG.EffectMgr;
        // 0x00D7DCC0: MOV x19, x0                | X19 = val_3;//m1                        
        // 0x00D7DCC4: CBNZ x19, #0xd7dccc        | if (val_3 != null) goto label_6;        
        if(val_3 != null)
        {
            goto label_6;
        }
        // 0x00D7DCC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_6:
        // 0x00D7DCCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DCD0: MOV x0, x19                | X0 = val_3;//m1                         
        // 0x00D7DCD4: BL #0xb5fdc8               | val_3.ClearSceneEffect();               
        val_3.ClearSceneEffect();
        // 0x00D7DCD8: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D7DCDC: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D7DCE0: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_4 = null;
        // 0x00D7DCE4: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7DCE8: TBZ w8, #0, #0xd7dcfc      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00D7DCEC: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7DCF0: CBNZ w8, #0xd7dcfc         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00D7DCF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7DCF8: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_4 = null;
        label_8:
        // 0x00D7DCFC: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7DD00: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DD04: CBNZ x19, #0xd7dd0c        | if (CameraShotHelper.instance != null) goto label_9;
        if(CameraShotHelper.instance != null)
        {
            goto label_9;
        }
        // 0x00D7DD08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_9:
        // 0x00D7DD0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DD10: MOV x0, x19                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7DD14: BL #0xbadea4               | CameraShotHelper.instance.Clear();      
        CameraShotHelper.instance.Clear();
        // 0x00D7DD18: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7DD1C: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7DD20: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DD24: CBNZ x19, #0xd7dd2c        | if (CameraShotHelper.instance != null) goto label_10;
        if(CameraShotHelper.instance != null)
        {
            goto label_10;
        }
        // 0x00D7DD28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraShotHelper.instance, ????);
        label_10:
        // 0x00D7DD2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7DD30: STRB w8, [x19, #0x20]      | CameraShotHelper.instance.IsOpeningMoveUpdate = true;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = true;
        // 0x00D7DD34: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7DD38: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7DD3C: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DD40: CBNZ x19, #0xd7dd48        | if (CameraShotHelper.instance != null) goto label_11;
        if(CameraShotHelper.instance != null)
        {
            goto label_11;
        }
        // 0x00D7DD44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraShotHelper.instance, ????);
        label_11:
        // 0x00D7DD48: STRB wzr, [x19, #0x22]     | CameraShotHelper.instance.isCircleCameraMoving = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isCircleCameraMoving = false;
        // 0x00D7DD4C: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7DD50: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7DD54: LDR x19, [x8]              | X19 = CameraShotHelper.instance;        
        // 0x00D7DD58: CBNZ x19, #0xd7dd60        | if (CameraShotHelper.instance != null) goto label_12;
        if(CameraShotHelper.instance != null)
        {
            goto label_12;
        }
        // 0x00D7DD5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? CameraShotHelper.instance, ????);
        label_12:
        // 0x00D7DD60: STRB wzr, [x19, #0xbc]     | CameraShotHelper.instance.isLineRunning = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isLineRunning = false;
        // 0x00D7DD64: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7DD68: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D7DD6C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7C4FC (14140668), len: 580  VirtAddr: 0x00D7C4FC RVA: 0x00D7C4FC token: 100694153 methodIndex: 25837 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnComplete(int a)
    {
        //
        // Disasemble & Code
        // 0x00D7C4FC: STP x24, x23, [sp, #-0x40]! | stack[1152921515114713664] = ???;  stack[1152921515114713672] = ???;  //  dest_result_addr=1152921515114713664 |  dest_result_addr=1152921515114713672
        // 0x00D7C500: STP x22, x21, [sp, #0x10]  | stack[1152921515114713680] = ???;  stack[1152921515114713688] = ???;  //  dest_result_addr=1152921515114713680 |  dest_result_addr=1152921515114713688
        // 0x00D7C504: STP x20, x19, [sp, #0x20]  | stack[1152921515114713696] = ???;  stack[1152921515114713704] = ???;  //  dest_result_addr=1152921515114713696 |  dest_result_addr=1152921515114713704
        // 0x00D7C508: STP x29, x30, [sp, #0x30]  | stack[1152921515114713712] = ???;  stack[1152921515114713720] = ???;  //  dest_result_addr=1152921515114713712 |  dest_result_addr=1152921515114713720
        // 0x00D7C50C: ADD x29, sp, #0x30         | X29 = (1152921515114713664 + 48) = 1152921515114713712 (0x1000000272515270);
        // 0x00D7C510: SUB sp, sp, #0x10          | SP = (1152921515114713664 - 16) = 1152921515114713648 (0x1000000272515230);
        // 0x00D7C514: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
        // 0x00D7C518: LDRB w8, [x21, #0x402]     | W8 = (bool)static_value_03734402;       
        // 0x00D7C51C: MOV w20, w1                | W20 = a;//m1                            
        // 0x00D7C520: MOV x19, x0                | X19 = 1152921515114725728 (0x1000000272518160);//ML01
        // 0x00D7C524: TBNZ w8, #0, #0xd7c540     | if (static_value_03734402 == true) goto label_0;
        // 0x00D7C528: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D7C52C: LDR x8, [x8, #0xc90]       | X8 = 0x2B9031C;                         
        // 0x00D7C530: LDR w0, [x8]               | W0 = 0x178B;                            
        // 0x00D7C534: BL #0x2782188              | X0 = sub_2782188( ?? 0x178B, ????);     
        // 0x00D7C538: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7C53C: STRB w8, [x21, #0x402]     | static_value_03734402 = true;            //  dest_result_addr=57885698
        label_0:
        // 0x00D7C540: LDR x21, [x19, #0x68]      | X21 = this.cameraShotQueue; //P2        
        // 0x00D7C544: CBNZ x21, #0xd7c54c        | if (this.cameraShotQueue != null) goto label_1;
        if(this.cameraShotQueue != null)
        {
            goto label_1;
        }
        // 0x00D7C548: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x178B, ????);     
        label_1:
        // 0x00D7C54C: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00D7C550: LDR x8, [x8, #0x5d0]       | X8 = 1152921515111781984;               
        // 0x00D7C554: MOV x0, x21                | X0 = this.cameraShotQueue;//m1          
        // 0x00D7C558: LDR x1, [x8]               | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D7C55C: BL #0x25ed72c              | X0 = this.cameraShotQueue.get_Count();  
        int val_1 = this.cameraShotQueue.Count;
        // 0x00D7C560: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x00D7C564: B.LT #0xd7c6e8             | if (val_1 < 1) goto label_2;            
        if(val_1 < 1)
        {
            goto label_2;
        }
        // 0x00D7C568: ADRP x22, #0x3652000       | X22 = 56958976 (0x3652000);             
        // 0x00D7C56C: LDR x22, [x22, #0x140]     | X22 = 1152921504607113216;              
        // 0x00D7C570: ADD x1, sp, #0xc           | X1 = (1152921515114713648 + 12) = 1152921515114713660 (0x100000027251523C);
        // 0x00D7C574: STR w20, [sp, #0xc]        | stack[1152921515114713660] = a;          //  dest_result_addr=1152921515114713660
        // 0x00D7C578: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7C57C: BL #0x27bc028              | X0 = 1152921515114761824 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), a);
        // 0x00D7C580: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00D7C584: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00D7C588: MOV x21, x0                | X21 = 1152921515114761824 (0x1000000272520E60);//ML01
        // 0x00D7C58C: LDR x8, [x8]               | X8 = typeof(System.String);             
        // 0x00D7C590: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00D7C594: TBZ w9, #0, #0xd7c5a8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D7C598: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D7C59C: CBNZ w9, #0xd7c5a8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D7C5A0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00D7C5A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_4:
        // 0x00D7C5A8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00D7C5AC: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921515114667648)("a ");
        // 0x00D7C5B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7C5B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7C5B8: MOV x2, x21                | X2 = 1152921515114761824 (0x1000000272520E60);//ML01
        // 0x00D7C5BC: LDR x1, [x8]               | X1 = "a ";                              
        // 0x00D7C5C0: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "a ");
        string val_2 = System.String.Concat(arg0:  0, arg1:  "a ");
        // 0x00D7C5C4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7C5C8: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7C5CC: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x00D7C5D0: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00D7C5D4: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7C5D8: TBZ w9, #0, #0xd7c5ec      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00D7C5DC: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7C5E0: CBNZ w9, #0xd7c5ec         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00D7C5E4: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00D7C5E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_6:
        // 0x00D7C5EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7C5F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7C5F4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7C5F8: MOV x1, x21                | X1 = val_2;//m1                         
        // 0x00D7C5FC: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_2);
        EDebug.Log(message:  0, isShowStack:  val_2);
        // 0x00D7C600: LDR x21, [x19, #0x68]      | X21 = this.cameraShotQueue; //P2        
        // 0x00D7C604: CBNZ x21, #0xd7c60c        | if (this.cameraShotQueue != null) goto label_7;
        if(this.cameraShotQueue != null)
        {
            goto label_7;
        }
        // 0x00D7C608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_7:
        // 0x00D7C60C: ADRP x23, #0x3657000       | X23 = 56979456 (0x3657000);             
        // 0x00D7C610: LDR x23, [x23, #0x6e0]     | X23 = 1152921515111795296;              
        // 0x00D7C614: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7C618: MOV x0, x21                | X0 = this.cameraShotQueue;//m1          
        // 0x00D7C61C: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C620: BL #0x25ed734              | X0 = this.cameraShotQueue.get_Item(index:  0);
        CameraShotVO val_3 = this.cameraShotQueue.Item[0];
        // 0x00D7C624: MOV x21, x0                | X21 = val_3;//m1                        
        // 0x00D7C628: CBNZ x21, #0xd7c630        | if (val_3 != null) goto label_8;        
        if(val_3 != null)
        {
            goto label_8;
        }
        // 0x00D7C62C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00D7C630: LDR w8, [x21, #0x1c]       | W8 = val_3.preId; //P2                  
        // 0x00D7C634: LDR x0, [x22]              | X0 = typeof(System.Int32);              
        // 0x00D7C638: ADD x1, sp, #8             | X1 = (1152921515114713648 + 8) = 1152921515114713656 (0x1000000272515238);
        // 0x00D7C63C: STR w8, [sp, #8]           | stack[1152921515114713656] = val_3.preId;  //  dest_result_addr=1152921515114713656
        // 0x00D7C640: BL #0x27bc028              | X0 = 1152921515114778208 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_3.preId);
        // 0x00D7C644: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x00D7C648: LDR x8, [x8, #0x2d8]       | X8 = (string**)(1152921515114684112)("cameraShotQueue[0].preId ");
        // 0x00D7C64C: MOV x2, x0                 | X2 = 1152921515114778208 (0x1000000272524E60);//ML01
        // 0x00D7C650: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7C654: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7C658: LDR x1, [x8]               | X1 = "cameraShotQueue[0].preId ";       
        // 0x00D7C65C: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "cameraShotQueue[0].preId ");
        string val_4 = System.String.Concat(arg0:  0, arg1:  "cameraShotQueue[0].preId ");
        // 0x00D7C660: MOV x1, x0                 | X1 = val_4;//m1                         
        // 0x00D7C664: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7C668: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7C66C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7C670: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_4);
        EDebug.Log(message:  0, isShowStack:  val_4);
        // 0x00D7C674: LDR x21, [x19, #0x68]      | X21 = this.cameraShotQueue; //P2        
        // 0x00D7C678: CBNZ x21, #0xd7c680        | if (this.cameraShotQueue != null) goto label_9;
        if(this.cameraShotQueue != null)
        {
            goto label_9;
        }
        // 0x00D7C67C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_9:
        // 0x00D7C680: LDR x2, [x23]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D7C684: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7C688: MOV x0, x21                | X0 = this.cameraShotQueue;//m1          
        // 0x00D7C68C: BL #0x25ed734              | X0 = this.cameraShotQueue.get_Item(index:  0);
        CameraShotVO val_5 = this.cameraShotQueue.Item[0];
        // 0x00D7C690: MOV x21, x0                | X21 = val_5;//m1                        
        // 0x00D7C694: CBNZ x21, #0xd7c69c        | if (val_5 != null) goto label_10;       
        if(val_5 != null)
        {
            goto label_10;
        }
        // 0x00D7C698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_10:
        // 0x00D7C69C: LDR w8, [x21, #0x1c]       | W8 = val_5.preId; //P2                  
        // 0x00D7C6A0: CMP w8, w20                | STATE = COMPARE(val_5.preId, a)         
        // 0x00D7C6A4: B.NE #0xd7c6d0             | if (val_5.preId != a) goto label_11;    
        if(val_5.preId != a)
        {
            goto label_11;
        }
        // 0x00D7C6A8: LDR x20, [x19, #0x70]      | X20 = this.withQueue; //P2              
        // 0x00D7C6AC: CBNZ x20, #0xd7c6b4        | if (this.withQueue != null) goto label_12;
        if(this.withQueue != null)
        {
            goto label_12;
        }
        // 0x00D7C6B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_12:
        // 0x00D7C6B4: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00D7C6B8: LDR x8, [x8, #0x7f8]       | X8 = 1152921515114700624;               
        // 0x00D7C6BC: MOV x0, x20                | X0 = this.withQueue;//m1                
        // 0x00D7C6C0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CameraShotVO>::Clear();
        // 0x00D7C6C4: BL #0x25ead28              | this.withQueue.Clear();                 
        this.withQueue.Clear();
        // 0x00D7C6C8: MOV x0, x19                | X0 = 1152921515114725728 (0x1000000272518160);//ML01
        // 0x00D7C6CC: BL #0xd79714               | this.Execute();                         
        this.Execute();
        label_11:
        // 0x00D7C6D0: SUB sp, x29, #0x30         | SP = (1152921515114713712 - 48) = 1152921515114713664 (0x1000000272515240);
        // 0x00D7C6D4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C6D8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C6DC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7C6E0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D7C6E4: RET                        |  return;                                
        return;
        label_2:
        // 0x00D7C6E8: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D7C6EC: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D7C6F0: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D7C6F4: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D7C6F8: TBZ w8, #0, #0xd7c708      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00D7C6FC: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D7C700: CBNZ w8, #0xd7c708         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00D7C704: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_14:
        // 0x00D7C708: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00D7C70C: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921515114701648)("end");
        // 0x00D7C710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7C714: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7C718: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7C71C: LDR x1, [x8]               | X1 = "end";                             
        // 0x00D7C720: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D7C724: MOV x0, x19                | X0 = 1152921515114725728 (0x1000000272518160);//ML01
        // 0x00D7C728: SUB sp, x29, #0x30         | SP = (1152921515114713712 - 48) = 1152921515114713664 (0x1000000272515240);
        // 0x00D7C72C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7C730: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7C734: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D7C738: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D7C73C: B #0xd781c0                | this.OnEnd(); return;                   
        this.OnEnd();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D79714 (14128916), len: 8596  VirtAddr: 0x00D79714 RVA: 0x00D79714 token: 100694154 methodIndex: 25838 delegateWrapperIndex: 0 methodInvoker: 0
    public void Execute()
    {
        //
        // Disasemble & Code
        //  | 
        var val_70;
        //  | 
        var val_71;
        //  | 
        System.Int32[] val_72;
        //  | 
        int val_73;
        //  | 
        int val_74;
        //  | 
        var val_75;
        //  | 
        CameraShotVO val_76;
        //  | 
        CameraShotHelper val_77;
        //  | 
        UnityEngine.Vector3[] val_78;
        //  | 
        var val_79;
        //  | 
        System.Object[] val_80;
        //  | 
        var val_81;
        //  | 
        var val_82;
        //  | 
        float val_83;
        //  | 
        var val_84;
        //  | 
        var val_85;
        //  | 
        var val_86;
        //  | 
        var val_87;
        //  | 
        int val_88;
        //  | 
        var val_89;
        //  | 
        var val_90;
        //  | 
        var val_91;
        //  | 
        var val_92;
        //  | 
        var val_93;
        //  | 
        var val_94;
        //  | 
        var val_95;
        //  | 
        var val_96;
        //  | 
        var val_97;
        //  | 
        var val_98;
        //  | 
        int val_99;
        //  | 
        var val_100;
        //  | 
        var val_101;
        //  | 
        var val_102;
        //  | 
        int val_103;
        //  | 
        var val_104;
        //  | 
        var val_105;
        //  | 
        var val_106;
        //  | 
        int val_107;
        //  | 
        var val_108;
        //  | 
        var val_109;
        //  | 
        var val_110;
        //  | 
        int val_111;
        //  | 
        var val_112;
        //  | 
        var val_113;
        //  | 
        var val_114;
        //  | 
        var val_115;
        //  | 
        var val_116;
        //  | 
        int val_117;
        //  | 
        var val_118;
        //  | 
        var val_119;
        //  | 
        var val_120;
        //  | 
        var val_121;
        //  | 
        var val_122;
        //  | 
        int val_123;
        //  | 
        float val_124;
        //  | 
        UnityEngine.Vector3[] val_125;
        //  | 
        System.Single[] val_126;
        //  | 
        System.Int32[] val_127;
        //  | 
        System.Int32[] val_128;
        //  | 
        System.Single[] val_129;
        //  | 
        System.Single[] val_130;
        //  | 
        System.Single[] val_131;
        //  | 
        System.Int32[] val_132;
        //  | 
        System.Single[] val_133;
        //  | 
        var val_134;
        //  | 
        var val_135;
        //  | 
        var val_136;
        //  | 
        float val_137;
        //  | 
        var val_138;
        //  | 
        var val_139;
        //  | 
        var val_140;
        //  | 
        var val_141;
        //  | 
        int val_142;
        //  | 
        var val_143;
        //  | 
        float val_144;
        //  | 
        var val_145;
        //  | 
        int val_146;
        //  | 
        var val_147;
        label_299:
        // 0x00D79714: STP d15, d14, [sp, #-0xa0]! | stack[1152921515115947744] = ???;  stack[1152921515115947752] = ???;  //  dest_result_addr=1152921515115947744 |  dest_result_addr=1152921515115947752
        // 0x00D79718: STP d13, d12, [sp, #0x10]  | stack[1152921515115947760] = ???;  stack[1152921515115947768] = ???;  //  dest_result_addr=1152921515115947760 |  dest_result_addr=1152921515115947768
        // 0x00D7971C: STP d11, d10, [sp, #0x20]  | stack[1152921515115947776] = ???;  stack[1152921515115947784] = ???;  //  dest_result_addr=1152921515115947776 |  dest_result_addr=1152921515115947784
        // 0x00D79720: STP d9, d8, [sp, #0x30]    | stack[1152921515115947792] = ???;  stack[1152921515115947800] = ???;  //  dest_result_addr=1152921515115947792 |  dest_result_addr=1152921515115947800
        // 0x00D79724: STP x28, x27, [sp, #0x40]  | stack[1152921515115947808] = ???;  stack[1152921515115947816] = ???;  //  dest_result_addr=1152921515115947808 |  dest_result_addr=1152921515115947816
        // 0x00D79728: STP x26, x25, [sp, #0x50]  | stack[1152921515115947824] = ???;  stack[1152921515115947832] = ???;  //  dest_result_addr=1152921515115947824 |  dest_result_addr=1152921515115947832
        // 0x00D7972C: STP x24, x23, [sp, #0x60]  | stack[1152921515115947840] = ???;  stack[1152921515115947848] = ???;  //  dest_result_addr=1152921515115947840 |  dest_result_addr=1152921515115947848
        // 0x00D79730: STP x22, x21, [sp, #0x70]  | stack[1152921515115947856] = ???;  stack[1152921515115947864] = ???;  //  dest_result_addr=1152921515115947856 |  dest_result_addr=1152921515115947864
        // 0x00D79734: STP x20, x19, [sp, #0x80]  | stack[1152921515115947872] = ???;  stack[1152921515115947880] = ???;  //  dest_result_addr=1152921515115947872 |  dest_result_addr=1152921515115947880
        // 0x00D79738: STP x29, x30, [sp, #0x90]  | stack[1152921515115947888] = ???;  stack[1152921515115947896] = ???;  //  dest_result_addr=1152921515115947888 |  dest_result_addr=1152921515115947896
        // 0x00D7973C: ADD x29, sp, #0x90         | X29 = (1152921515115947744 + 144) = 1152921515115947888 (0x1000000272642770);
        // 0x00D79740: SUB sp, sp, #0x80          | SP = (1152921515115947744 - 128) = 1152921515115947616 (0x1000000272642660);
        // 0x00D79744: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D79748: LDRB w8, [x20, #0x403]     | W8 = (bool)static_value_03734403;       
        // 0x00D7974C: MOV x19, x0                | X19 = 1152921515115959904 (0x1000000272645660);//ML01
        // 0x00D79750: TBNZ w8, #0, #0xd7976c     | if (static_value_03734403 == true) goto label_0;
        // 0x00D79754: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x00D79758: LDR x8, [x8, #0xcf0]       | X8 = 0x2B90300;                         
        // 0x00D7975C: LDR w0, [x8]               | W0 = 0x1784;                            
        // 0x00D79760: BL #0x2782188              | X0 = sub_2782188( ?? 0x1784, ????);     
        // 0x00D79764: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D79768: STRB w8, [x20, #0x403]     | static_value_03734403 = true;            //  dest_result_addr=57885699
        label_0:
        // 0x00D7976C: LDR x20, [x19, #0x68]      | X20 = this.cameraShotQueue; //P2        
        // 0x00D79770: CBNZ x20, #0xd79778        | if (this.cameraShotQueue != null) goto label_1;
        if(this.cameraShotQueue != null)
        {
            goto label_1;
        }
        // 0x00D79774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1784, ????);     
        label_1:
        // 0x00D79778: ADRP x28, #0x35c4000       | X28 = 56377344 (0x35C4000);             
        // 0x00D7977C: LDR x28, [x28, #0x5d0]     | X28 = 1152921515111781984;              
        val_70 = 1152921515111781984;
        // 0x00D79780: MOV x0, x20                | X0 = this.cameraShotQueue;//m1          
        // 0x00D79784: LDR x1, [x28]              | X1 = public System.Int32 System.Collections.Generic.List<CameraShotVO>::get_Count();
        // 0x00D79788: BL #0x25ed72c              | X0 = this.cameraShotQueue.get_Count();  
        int val_1 = this.cameraShotQueue.Count;
        // 0x00D7978C: CMP w0, #1                 | STATE = COMPARE(val_1, 0x1)             
        // 0x00D79790: B.LT #0xd79afc             | if (val_1 < 1) goto label_2;            
        if(val_1 < 1)
        {
            goto label_2;
        }
        // 0x00D79794: LDR x20, [x19, #0x68]      | X20 = this.cameraShotQueue; //P2        
        // 0x00D79798: CBNZ x20, #0xd797a0        | if (this.cameraShotQueue != null) goto label_3;
        if(this.cameraShotQueue != null)
        {
            goto label_3;
        }
        // 0x00D7979C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00D797A0: ADRP x27, #0x3657000       | X27 = 56979456 (0x3657000);             
        // 0x00D797A4: LDR x27, [x27, #0x6e0]     | X27 = 1152921515111795296;              
        val_71 = 1152921515111795296;
        // 0x00D797A8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D797AC: MOV x0, x20                | X0 = this.cameraShotQueue;//m1          
        // 0x00D797B0: LDR x2, [x27]              | X2 = public CameraShotVO System.Collections.Generic.List<CameraShotVO>::get_Item(int index);
        // 0x00D797B4: BL #0x25ed734              | X0 = this.cameraShotQueue.get_Item(index:  0);
        CameraShotVO val_2 = this.cameraShotQueue.Item[0];
        // 0x00D797B8: LDR x20, [x19, #0x68]      | X20 = this.cameraShotQueue; //P2        
        // 0x00D797BC: STR x0, [x19, #0x60]       | this.curCameraShot = val_2;              //  dest_result_addr=1152921515115960000
        this.curCameraShot = val_2;
        // 0x00D797C0: CBNZ x20, #0xd797c8        | if (this.cameraShotQueue != null) goto label_4;
        if(this.cameraShotQueue != null)
        {
            goto label_4;
        }
        // 0x00D797C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_4:
        // 0x00D797C8: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00D797CC: LDR x8, [x8, #0x898]       | X8 = 1152921515114137904;               
        // 0x00D797D0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D797D4: MOV x0, x20                | X0 = this.cameraShotQueue;//m1          
        // 0x00D797D8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<CameraShotVO>::RemoveAt(int index);
        // 0x00D797DC: BL #0x25ed00c              | this.cameraShotQueue.RemoveAt(index:  0);
        this.cameraShotQueue.RemoveAt(index:  0);
        // 0x00D797E0: ADRP x22, #0x3630000       | X22 = 56819712 (0x3630000);             
        // 0x00D797E4: LDR x22, [x22, #0x3d0]     | X22 = 1152921504954501264;              
        // 0x00D797E8: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x00D797EC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D797F0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D797F4: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D797F8: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D797FC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D79800: LDR x21, [x19, #0x60]      | X21 = this.curCameraShot; //P2          
        // 0x00D79804: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D79808: CBNZ x21, #0xd79810        | if (this.curCameraShot != null) goto label_5;
        if(this.curCameraShot != null)
        {
            goto label_5;
        }
        // 0x00D7980C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_5:
        // 0x00D79810: ADRP x23, #0x3652000       | X23 = 56958976 (0x3652000);             
        // 0x00D79814: LDR w8, [x21, #0x10]       | W8 = this.curCameraShot.id; //P2        
        // 0x00D79818: LDR x23, [x23, #0x140]     | X23 = 1152921504607113216;              
        val_72 = 1152921504607113216;
        // 0x00D7981C: ADD x1, sp, #0x68          | X1 = (1152921515115947616 + 104) = 1152921515115947720 (0x10000002726426C8);
        // 0x00D79820: STR w8, [sp, #0x68]        | stack[1152921515115947720] = this.curCameraShot.id;  //  dest_result_addr=1152921515115947720
        // 0x00D79824: LDR x0, [x23]              | X0 = typeof(System.Int32);              
        // 0x00D79828: BL #0x27bc028              | X0 = 1152921515116012384 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.curCameraShot.id);
        // 0x00D7982C: MOV x21, x0                | X21 = 1152921515116012384 (0x1000000272652360);//ML01
        // 0x00D79830: CBNZ x20, #0xd79838        | if ( != null) goto label_6;             
        if(null != null)
        {
            goto label_6;
        }
        // 0x00D79834: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.curCameraShot.id, ????);
        label_6:
        // 0x00D79838: CBZ x21, #0xd7985c         | if (this.curCameraShot.id == 0) goto label_8;
        if(this.curCameraShot.id == 0)
        {
            goto label_8;
        }
        // 0x00D7983C: LDR x8, [x20]              | X8 = ;                                  
        // 0x00D79840: MOV x0, x21                | X0 = 1152921515116012384 (0x1000000272652360);//ML01
        // 0x00D79844: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D79848: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.curCameraShot.id, ????);
        // 0x00D7984C: CBNZ x0, #0xd7985c         | if (this.curCameraShot.id != 0) goto label_8;
        if(this.curCameraShot.id != 0)
        {
            goto label_8;
        }
        // 0x00D79850: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.curCameraShot.id, ????);
        // 0x00D79854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79858: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.curCameraShot.id, ????);
        label_8:
        // 0x00D7985C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D79860: CBNZ w8, #0xd79870         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_9;
        // 0x00D79864: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.curCameraShot.id, ????);
        // 0x00D79868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7986C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.curCameraShot.id, ????);
        label_9:
        // 0x00D79870: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D79874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79878: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = this.curCameraShot.id; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = this.curCameraShot.id;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00D7987C: BL #0x269115c              | X0 = UnityEngine.Time.get_frameCount(); 
        int val_3 = UnityEngine.Time.frameCount;
        // 0x00D79880: LDR x8, [x23]              | X8 = typeof(System.Int32);              
        // 0x00D79884: STR w0, [sp, #0x7c]        | stack[1152921515115947740] = val_3;      //  dest_result_addr=1152921515115947740
        // 0x00D79888: ADD x1, sp, #0x7c          | X1 = (1152921515115947616 + 124) = 1152921515115947740 (0x10000002726426DC);
        // 0x00D7988C: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D79890: BL #0x27bc028              | X0 = 1152921515116016480 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), val_3);
        // 0x00D79894: MOV x21, x0                | X21 = 1152921515116016480 (0x1000000272653360);//ML01
        val_73 = val_3;
        // 0x00D79898: CBZ x21, #0xd798bc         | if (val_3 == 0) goto label_11;          
        if(val_3 == 0)
        {
            goto label_11;
        }
        // 0x00D7989C: LDR x8, [x20]              | X8 = ;                                  
        // 0x00D798A0: MOV x0, x21                | X0 = 1152921515116016480 (0x1000000272653360);//ML01
        // 0x00D798A4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D798A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_3, ????);      
        // 0x00D798AC: CBNZ x0, #0xd798bc         | if (val_3 != 0) goto label_11;          
        if(val_3 != 0)
        {
            goto label_11;
        }
        // 0x00D798B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_3, ????);      
        // 0x00D798B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D798B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_11:
        // 0x00D798BC: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D798C0: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x00D798C4: B.HI #0xd798d4             | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_12;
        // 0x00D798C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00D798CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D798D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_12:
        // 0x00D798D4: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = val_3; typeof(System.Object[]).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504954501304 dest_result_addr=1152921504954501308
        typeof(System.Object[]).__il2cppRuntimeField_28 = val_73;
        typeof(System.Object[]).__il2cppRuntimeField_2C = 268435458;
        // 0x00D798D8: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00D798DC: LDR x8, [x8, #0x548]       | X8 = (string**)(1152921515114883360)("开始执行剧情 id ：{0} {1}");
        // 0x00D798E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D798E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D798E8: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D798EC: LDR x1, [x8]               | X1 = "开始执行剧情 id ：{0} {1}";              
        // 0x00D798F0: BL #0x27952d8              | X0 = EString.EFormat(format:  0, args:  "开始执行剧情 id ：{0} {1}");
        string val_4 = EString.EFormat(format:  0, args:  "开始执行剧情 id ：{0} {1}");
        // 0x00D798F4: ADRP x24, #0x3618000       | X24 = 56721408 (0x3618000);             
        // 0x00D798F8: LDR x24, [x24, #0x530]     | X24 = 1152921504924098560;              
        // 0x00D798FC: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x00D79900: LDR x8, [x24]              | X8 = typeof(EDebug);                    
        // 0x00D79904: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D79908: TBZ w9, #0, #0xd7991c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_14;
        // 0x00D7990C: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D79910: CBNZ w9, #0xd7991c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_14;
        // 0x00D79914: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00D79918: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_14:
        // 0x00D7991C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D79920: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79924: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D79928: MOV x1, x20                | X1 = val_4;//m1                         
        // 0x00D7992C: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_4);
        EDebug.Log(message:  0, isShowStack:  val_4);
        // 0x00D79930: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D79934: CBNZ x20, #0xd7993c        | if (this.curCameraShot != null) goto label_15;
        if(this.curCameraShot != null)
        {
            goto label_15;
        }
        // 0x00D79938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_15:
        // 0x00D7993C: ADRP x9, #0x365a000        | X9 = 56991744 (0x365A000);              
        // 0x00D79940: LDR w8, [x20, #0x14]       | W8 = this.curCameraShot.funType; //P2   
        // 0x00D79944: LDR x9, [x9, #0xe90]       | X9 = 1152921504909987840;               
        // 0x00D79948: ADD x1, sp, #0x78          | X1 = (1152921515115947616 + 120) = 1152921515115947736 (0x10000002726426D8);
        // 0x00D7994C: STR w8, [sp, #0x78]        | stack[1152921515115947736] = this.curCameraShot.funType;  //  dest_result_addr=1152921515115947736
        // 0x00D79950: LDR x0, [x9]               | X0 = typeof(FunType);                   
        // 0x00D79954: BL #0x27bc028              | X0 = 1152921515116032864 = (Il2CppObject*)Box((RuntimeClass*)typeof(FunType), this.curCameraShot.funType);
        // 0x00D79958: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
        // 0x00D7995C: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
        val_74 = 1152921504608284672;
        // 0x00D79960: MOV x20, x0                | X20 = 1152921515116032864 (0x1000000272657360);//ML01
        // 0x00D79964: LDR x8, [x25]              | X8 = typeof(System.String);             
        // 0x00D79968: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
        // 0x00D7996C: TBZ w9, #0, #0xd79980      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00D79970: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00D79974: CBNZ w9, #0xd79980         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00D79978: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00D7997C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_17:
        // 0x00D79980: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
        // 0x00D79984: LDR x8, [x8, #0xfb8]       | X8 = (string**)(1152921515114899856)("功能: ");
        // 0x00D79988: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7998C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79990: MOV x2, x20                | X2 = 1152921515116032864 (0x1000000272657360);//ML01
        // 0x00D79994: LDR x1, [x8]               | X1 = "功能: ";                            
        // 0x00D79998: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "功能: ");
        string val_5 = System.String.Concat(arg0:  0, arg1:  "功能: ");
        // 0x00D7999C: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00D799A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D799A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D799A8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D799AC: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_5);
        EDebug.Log(message:  0, isShowStack:  val_5);
        // 0x00D799B0: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D799B4: CBNZ x20, #0xd799bc        | if (this.curCameraShot != null) goto label_18;
        if(this.curCameraShot != null)
        {
            goto label_18;
        }
        // 0x00D799B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_18:
        // 0x00D799BC: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
        // 0x00D799C0: LDR x2, [x20, #0x150]      | X2 = this.curCameraShot.remark; //P2    
        // 0x00D799C4: LDR x8, [x8, #0xb18]       | X8 = (string**)(1152921515114912224)("备注: ");
        // 0x00D799C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D799CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D799D0: LDR x1, [x8]               | X1 = "备注: ";                            
        // 0x00D799D4: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "备注: ");
        string val_6 = System.String.Concat(str0:  0, str1:  "备注: ");
        // 0x00D799D8: MOV x1, x0                 | X1 = val_6;//m1                         
        // 0x00D799DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D799E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D799E4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D799E8: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_6);
        EDebug.Log(message:  0, isShowStack:  val_6);
        // 0x00D799EC: LDR x20, [x19, #0x60]      | X20 = this.curCameraShot; //P2          
        // 0x00D799F0: CBNZ x20, #0xd799f8        | if (this.curCameraShot != null) goto label_19;
        if(this.curCameraShot != null)
        {
            goto label_19;
        }
        // 0x00D799F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_19:
        // 0x00D799F8: LDR w8, [x20, #0x14]       | W8 = this.curCameraShot.funType; //P2   
        FunType val_70 = this.curCameraShot.funType;
        // 0x00D799FC: ADD w9, w8, #8             | W9 = (this.curCameraShot.funType + 8);  
        FunType val_7 = val_70 + 8;
        // 0x00D79A00: CMP w8, #0x13              | STATE = COMPARE(this.curCameraShot.funType, 0x13)
        // 0x00D79A04: CSEL w8, w9, wzr, lo       | W8 = this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0;
        val_70 = (val_70 < 19) ? (val_7) : 0;
        // 0x00D79A08: CMP w8, #0x1a              | STATE = COMPARE(this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0, 0x1A)
        // 0x00D79A0C: B.HI #0xd7b214             | if (this.curCameraShot.funType > 0x1A) goto label_293;
        if(val_70 > 26)
        {
            goto label_293;
        }
        // 0x00D79A10: ADRP x9, #0x2a97000        | X9 = 44658688 (0x2A97000);              
        // 0x00D79A14: ADD x9, x9, #0x174         | X9 = (44658688 + 372) = 44659060 (0x02A97174);
        // 0x00D79A18: LDRSW x8, [x9, x8, lsl #2] | X8 = 44659060 + (this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0) << 2;
        var val_71 = 44659060 + (this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0) << 2;
        // 0x00D79A1C: ADD x8, x8, x9             | X8 = (44659060 + (this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0) << 2 + 4
        val_71 = val_71 + 44659060;
        // 0x00D79A20: BR x8                      | goto (44659060 + (this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0) << 2 + 44659060);
        goto (44659060 + (this.curCameraShot.funType < 0x13 ? (this.curCameraShot.funType + 8) : 0) << 2 + 44659060);
        // 0x00D79A24: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00D79A28: ADRP x9, #0x3658000        | X9 = 56983552 (0x3658000);              
        // 0x00D79A2C: LDR x8, [x8, #0xde0]       | X8 = 1152921515111800416;               
        // 0x00D79A30: LDR x9, [x9, #0x980]       | X9 = 1152921504898113536;               
        // 0x00D79A34: LDR x21, [x8]              | X21 = System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev);
        // 0x00D79A38: LDR x0, [x9]               | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_8 = null;
        // 0x00D79A3C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D79A40: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D79A44: LDR x8, [x8, #0xc38]       | X8 = 1152921512949758048;               
        // 0x00D79A48: MOV x1, x19                | X1 = 1152921515115959904 (0x1000000272645660);//ML01
        // 0x00D79A4C: MOV x2, x21                | X2 = 1152921515111800416 (0x100000027224DE60);//ML01
        // 0x00D79A50: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D79A54: LDR x3, [x8]               | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D79A58: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        val_8 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        // 0x00D79A5C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D79A60: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D79A64: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D79A68: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D79A6C: TBZ w8, #0, #0xd79a7c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x00D79A70: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D79A74: CBNZ w8, #0xd79a7c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x00D79A78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_22:
        // 0x00D79A7C: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00D79A80: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513302392240)("CAMERASHOT_MOVE_COMPLETE");
        // 0x00D79A84: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D79A88: LDR x1, [x8]               | X1 = "CAMERASHOT_MOVE_COMPLETE";        
        // 0x00D79A8C: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "CAMERASHOT_MOVE_COMPLETE");
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "CAMERASHOT_MOVE_COMPLETE");
        // 0x00D79A90: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D79A94: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D79A98: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_75 = null;
        // 0x00D79A9C: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D79AA0: TBZ w8, #0, #0xd79ab4      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_24;
        // 0x00D79AA4: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D79AA8: CBNZ w8, #0xd79ab4         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
        // 0x00D79AAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D79AB0: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_75 = null;
        label_24:
        // 0x00D79AB4: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D79AB8: LDR x21, [x8]              | X21 = CameraShotHelper.instance;        
        // 0x00D79ABC: CBNZ x21, #0xd79ac4        | if (CameraShotHelper.instance != null) goto label_25;
        if(CameraShotHelper.instance != null)
        {
            goto label_25;
        }
        // 0x00D79AC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_25:
        // 0x00D79AC4: STRB wzr, [x21, #0x20]     | CameraShotHelper.instance.IsOpeningMoveUpdate = false;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = false;
        // 0x00D79AC8: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D79ACC: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D79AD0: LDR x21, [x8]              | X21 = CameraShotHelper.instance;        
        // 0x00D79AD4: CBNZ x21, #0xd79adc        | if (CameraShotHelper.instance != null) goto label_26;
        if(CameraShotHelper.instance != null)
        {
            goto label_26;
        }
        // 0x00D79AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_26:
        // 0x00D79ADC: STRB wzr, [x21, #0x22]     | CameraShotHelper.instance.isCircleCameraMoving = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isCircleCameraMoving = false;
        // 0x00D79AE0: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D79AE4: LDR x21, [x19, #0x60]      | X21 = this.curCameraShot; //P2          
        val_76 = this.curCameraShot;
        // 0x00D79AE8: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D79AEC: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        val_77 = CameraShotHelper.instance;
        // 0x00D79AF0: CBZ x21, #0xd7ab94         | if (this.curCameraShot == null) goto label_27;
        if(val_76 == null)
        {
            goto label_27;
        }
        // 0x00D79AF4: LDR x1, [x21, #0x20]       | X1 = this.curCameraShot.paths; //P2     
        val_78 = this.curCameraShot.paths;
        // 0x00D79AF8: B #0xd7aba8                |  goto label_28;                         
        goto label_28;
        label_2:
        // 0x00D79AFC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00D79B00: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00D79B04: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00D79B08: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00D79B0C: TBZ w8, #0, #0xd79b1c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_30;
        // 0x00D79B10: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00D79B14: CBNZ w8, #0xd79b1c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
        // 0x00D79B18: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_30:
        // 0x00D79B1C: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00D79B20: LDR x8, [x8, #0x6e8]       | X8 = (string**)(1152921515114965552)("enddddddddddddddddddddddddddddddd");
        // 0x00D79B24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D79B28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79B2C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D79B30: LDR x1, [x8]               | X1 = "enddddddddddddddddddddddddddddddd";
        // 0x00D79B34: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00D79B38: MOV x0, x19                | X0 = 1152921515115959904 (0x1000000272645660);//ML01
        // 0x00D79B3C: SUB sp, x29, #0x90         | SP = (1152921515115947888 - 144) = 1152921515115947744 (0x10000002726426E0);
        // 0x00D79B40: LDP x29, x30, [sp, #0x90]  | X29 = ; X30 = ;                          //  | 
        // 0x00D79B44: LDP x20, x19, [sp, #0x80]  | X20 = ; X19 = ;                          //  | 
        // 0x00D79B48: LDP x22, x21, [sp, #0x70]  | X22 = ; X21 = ;                          //  | 
        // 0x00D79B4C: LDP x24, x23, [sp, #0x60]  | X24 = ; X23 = ;                          //  | 
        // 0x00D79B50: LDP x26, x25, [sp, #0x50]  | X26 = ; X25 = ;                          //  | 
        // 0x00D79B54: LDP x28, x27, [sp, #0x40]  | X28 = ; X27 = ;                          //  | 
        // 0x00D79B58: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00D79B5C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00D79B60: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00D79B64: LDP d15, d14, [sp], #0xa0  | D15 = ; D14 = ;                          //  | 
        // 0x00D79B68: B #0xd781c0                | this.OnEnd(); return;                   
        this.OnEnd();
        return;
        // 0x00D79B6C: LDR x20, [x22]             | X20 = ;                                 
        // 0x00D79B70: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D79B74: BL #0x277461c              | X0 = sub_277461C( ?? , ????);           
        // 0x00D79B78: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D79B7C: MOV x0, x20                | X0 = X20;//m1                           
        // 0x00D79B80: BL #0x27c1608              | X0 = sub_27C1608( ?? , ????);           
        // 0x00D79B84: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D79B88: MOV x20, x0                | X20 = X0;//m1                           
        val_79 = ???;
        // 0x00D79B8C: CBNZ x21, #0xd79b94        | if (??? + 96 != 0) goto label_31;       
        if((??? + 96) != 0)
        {
            goto label_31;
        }
        // 0x00D79B90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_31:
        // 0x00D79B94: LDR w8, [x21, #0x80]       | W8 = ??? + 96 + 128;                    
        // 0x00D79B98: LDR x0, [x23]              | X0 = ;                                  
        // 0x00D79B9C: ADD x1, sp, #0x68          | X1 = (1152921515115947904 + 104) = 1152921515115948008 (0x10000002726427E8);
        // 0x00D79BA0: STR w8, [sp, #0x68]        | stack[1152921515115948008] = ??? + 96 + 128;  //  dest_result_addr=1152921515115948008
        // 0x00D79BA4: BL #0x27bc028              | X0 = 0 = (Il2CppObject*)Box((RuntimeClass*)typeof(), ??? + 96 + 128);
        // 0x00D79BA8: MOV x21, x0                | X21 = 1152921515115948008 (0x10000002726427E8);//ML01
        // 0x00D79BAC: CBNZ x20, #0xd79bb4        | if ( != 0) goto label_32;               
        if(val_79 != 0)
        {
            goto label_32;
        }
        // 0x00D79BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002726427E8, ????);
        label_32:
        // 0x00D79BB4: CBZ x21, #0xd79bd8         | if (??? + 96 + 128 == 0) goto label_34; 
        if((??? + 96 + 128) == 0)
        {
            goto label_34;
        }
        // 0x00D79BB8: LDR x8, [x20]              | X8 = ;                                  
        // 0x00D79BBC: MOV x0, x21                | X0 = 1152921515115948008 (0x10000002726427E8);//ML01
        // 0x00D79BC0: LDR x1, [x8, #0x30]        | X1 = val_79 + 48;                       
        // 0x00D79BC4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x10000002726427E8, ????);
        // 0x00D79BC8: CBNZ x0, #0xd79bd8         | if (??? + 96 + 128 != 0) goto label_34; 
        if((??? + 96 + 128) != 0)
        {
            goto label_34;
        }
        // 0x00D79BCC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x10000002726427E8, ????);
        // 0x00D79BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79BD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002726427E8, ????);
        label_34:
        // 0x00D79BD8: LDR w8, [x20, #0x18]       | W8 = val_79 + 24;                       
        // 0x00D79BDC: CBNZ w8, #0xd79bec         | if (val_79 + 24 != 0) goto label_35;    
        if((val_79 + 24) != 0)
        {
            goto label_35;
        }
        // 0x00D79BE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000002726427E8, ????);
        // 0x00D79BE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79BE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002726427E8, ????);
        label_35:
        // 0x00D79BEC: STR x21, [x20, #0x20]      | mem2[0] = 0x10000002726427E8;            //  dest_result_addr=0
        mem2[0] = ;
        // 0x00D79BF0: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
        // 0x00D79BF4: LDR x8, [x8, #0xce8]       | X8 = 1152921504608444416;               
        // 0x00D79BF8: ADD x1, sp, #0x7c          | X1 = (1152921515115947904 + 124) = 1152921515115948028 (0x10000002726427FC);
        // 0x00D79BFC: STR wzr, [sp, #0x7c]       | stack[1152921515115948028] = 0x0;        //  dest_result_addr=1152921515115948028
        // 0x00D79C00: LDR x0, [x8]               | X0 = typeof(System.Single);             
        // 0x00D79C04: BL #0x27bc028              | X0 = 1152921515116103520 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), 0);
        // 0x00D79C08: MOV x21, x0                | X21 = 1152921515116103520 (0x1000000272668760);//ML01
        val_73 = 0f;
        // 0x00D79C0C: CBZ x21, #0xd79c30         | if (0 == 0) goto label_37;              
        if(0f == 0)
        {
            goto label_37;
        }
        // 0x00D79C10: LDR x8, [x20]              | X8 = ;                                  
        // 0x00D79C14: MOV x0, x21                | X0 = 1152921515116103520 (0x1000000272668760);//ML01
        // 0x00D79C18: LDR x1, [x8, #0x30]        | X1 = val_79 + 48;                       
        // 0x00D79C1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0, ????);          
        // 0x00D79C20: CBNZ x0, #0xd79c30         | if (0 != 0) goto label_37;              
        if(0f != 0)
        {
            goto label_37;
        }
        // 0x00D79C24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0, ????);          
        // 0x00D79C28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79C2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0, ????);          
        label_37:
        // 0x00D79C30: LDR w8, [x20, #0x18]       | W8 = val_79 + 24;                       
        // 0x00D79C34: CMP w8, #1                 | STATE = COMPARE(val_79 + 24, 0x1)       
        // 0x00D79C38: B.HI #0xd79c48             | if (val_79 + 24 > 0x1) goto label_38;   
        if((val_79 + 24) > 1)
        {
            goto label_38;
        }
        // 0x00D79C3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0, ????);          
        // 0x00D79C40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79C44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0, ????);          
        label_38:
        // 0x00D79C48: STR x21, [x20, #0x28]      | mem2[0] = 0; mem[4] = 0x10000002;        //  dest_result_addr=0 dest_result_addr=4
        mem2[0] = val_73;
        mem[4] = 268435458;
        // 0x00D79C4C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D79C50: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
        // 0x00D79C54: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
        // 0x00D79C58: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00D79C5C: TBZ w8, #0, #0xd79c6c      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00D79C60: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00D79C64: CBNZ w8, #0xd79c6c         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00D79C68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        label_40:
        // 0x00D79C6C: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00D79C70: LDR x8, [x8, #0xbb8]       | X8 = (string**)(1152921515114970816)("OpenPlot");
        val_80 = "OpenPlot";
        // 0x00D79C74: B #0xd7a8c4                |  goto label_41;                         
        goto label_41;
        // 0x00D79C78: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D79C7C: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D79C80: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_81 = null;
        // 0x00D79C84: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D79C88: TBZ w8, #0, #0xd79c9c      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00D79C8C: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D79C90: CBNZ w8, #0xd79c9c         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00D79C94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D79C98: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_81 = null;
        label_43:
        // 0x00D79C9C: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D79CA0: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        val_82 = mem[??? + 96];
        val_82 = ??? + 96;
        // 0x00D79CA4: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D79CA8: CBZ x21, #0xd7ac78         | if (??? + 96 == 0) goto label_44;       
        if(val_82 == 0)
        {
            goto label_44;
        }
        // 0x00D79CAC: LDR s8, [x21, #0x84]       | S8 = ??? + 96 + 132;                    
        val_83 = mem[??? + 96 + 132];
        val_83 = ??? + 96 + 132;
        // 0x00D79CB0: B #0xd7ac8c                |  goto label_45;                         
        goto label_45;
        // 0x00D79CB4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D79CB8: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00D79CBC: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D79CC0: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00D79CC4: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D79CC8: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D79CCC: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_84 = ??? + 96;
        // 0x00D79CD0: CBNZ x21, #0xd79ce0        | if (??? + 96 != 0) goto label_46;       
        if((??? + 96) != 0)
        {
            goto label_46;
        }
        // 0x00D79CD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D79CD8: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_84 = mem[??? + 96];
        val_84 = ??? + 96;
        // 0x00D79CDC: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_84 == 0)
        {
            goto label_382;
        }
        label_46:
        // 0x00D79CE0: LDR w22, [x21, #0x94]      | W22 = ??? + 96 + 148;                   
        // 0x00D79CE4: LDR w21, [x8, #0x90]       | W21 = ??? + 96 + 144;                   
        // 0x00D79CE8: CBNZ x20, #0xd79cf0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_48;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_48;
        }
        // 0x00D79CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_48:
        // 0x00D79CF0: CMP w22, #1                | STATE = COMPARE(??? + 96 + 148, 0x1)    
        // 0x00D79CF4: CSET w1, eq                | W1 = ??? + 96 + 148 == 0x1 ? 1 : 0;     
        bool val_9 = ((??? + 96 + 148) == 1) ? 1 : 0;
        // 0x00D79CF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79CFC: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D79D00: MOV w2, w21                | W2 = ??? + 96 + 144;//m1                
        // 0x00D79D04: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_9 = ((??? + 96 + 148) == 1) ? 1 : 0, id:  ??? + 96 + 144);
        CombatEntity val_10 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_9, id:  ??? + 96 + 144);
        // 0x00D79D08: MOV x20, x0                | X20 = val_10;//m1                       
        // 0x00D79D0C: CBNZ x20, #0xd79d14        | if (val_10 != null) goto label_49;      
        if(val_10 != null)
        {
            goto label_49;
        }
        // 0x00D79D10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_49:
        // 0x00D79D14: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D79D18: LDR x20, [x20, #0x258]     | X20 = val_10.<characterAnim>k__BackingField; //P2 
        // 0x00D79D1C: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_85 = ??? + 96;
        // 0x00D79D20: CBNZ x21, #0xd79d30        | if (??? + 96 != 0) goto label_50;       
        if((??? + 96) != 0)
        {
            goto label_50;
        }
        // 0x00D79D24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        // 0x00D79D28: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_85 = mem[??? + 96];
        val_85 = ??? + 96;
        // 0x00D79D2C: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_85 == 0)
        {
            goto label_382;
        }
        label_50:
        // 0x00D79D30: LDR w22, [x21, #0xa4]      | W22 = ??? + 96 + 164;                   
        // 0x00D79D34: LDR x21, [x8, #0x98]       | X21 = ??? + 96 + 152;                   
        val_73 = mem[??? + 96 + 152];
        val_73 = ??? + 96 + 152;
        // 0x00D79D38: CBNZ x20, #0xd79d40        | if (val_10.<characterAnim>k__BackingField != null) goto label_52;
        if((val_10.<characterAnim>k__BackingField) != null)
        {
            goto label_52;
        }
        // 0x00D79D3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_52:
        // 0x00D79D40: CMP w22, #1                | STATE = COMPARE(??? + 96 + 164, 0x1)    
        // 0x00D79D44: CSET w1, eq                | W1 = ??? + 96 + 164 == 0x1 ? 1 : 0;     
        bool val_11 = ((??? + 96 + 164) == 1) ? 1 : 0;
        // 0x00D79D48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79D4C: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00D79D50: MOV x0, x20                | X0 = val_10.<characterAnim>k__BackingField;//m1
        // 0x00D79D54: MOV x2, x21                | X2 = ??? + 96 + 152;//m1                
        // 0x00D79D58: BL #0xb28c84               | val_10.<characterAnim>k__BackingField.Play(isLoop:  bool val_11 = ((??? + 96 + 164) == 1) ? 1 : 0, aniName:  val_73, playTime:  0f);
        val_10.<characterAnim>k__BackingField.Play(isLoop:  val_11, aniName:  val_73, playTime:  0f);
        // 0x00D79D5C: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        // 0x00D79D60: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D79D64: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00D79D68: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D79D6C: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00D79D70: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D79D74: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D79D78: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_86 = ??? + 96;
        // 0x00D79D7C: CBNZ x21, #0xd79d8c        | if (??? + 96 != 0) goto label_54;       
        if((??? + 96) != 0)
        {
            goto label_54;
        }
        // 0x00D79D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10.<characterAnim>k__BackingField, ????);
        // 0x00D79D84: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_86 = mem[??? + 96];
        val_86 = ??? + 96;
        // 0x00D79D88: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_86 == 0)
        {
            goto label_382;
        }
        label_54:
        // 0x00D79D8C: LDR w22, [x21, #0x94]      | W22 = ??? + 96 + 148;                   
        // 0x00D79D90: LDR w21, [x8, #0x90]       | W21 = ??? + 96 + 144;                   
        // 0x00D79D94: CBNZ x20, #0xd79d9c        | if (GameMgr.UPDATEOnOffEffect != null) goto label_56;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_56;
        }
        // 0x00D79D98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10.<characterAnim>k__BackingField, ????);
        label_56:
        // 0x00D79D9C: CMP w22, #1                | STATE = COMPARE(??? + 96 + 148, 0x1)    
        // 0x00D79DA0: CSET w1, eq                | W1 = ??? + 96 + 148 == 0x1 ? 1 : 0;     
        bool val_12 = ((??? + 96 + 148) == 1) ? 1 : 0;
        // 0x00D79DA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79DA8: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D79DAC: MOV w2, w21                | W2 = ??? + 96 + 144;//m1                
        // 0x00D79DB0: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_12 = ((??? + 96 + 148) == 1) ? 1 : 0, id:  ??? + 96 + 144);
        CombatEntity val_13 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_12, id:  ??? + 96 + 144);
        // 0x00D79DB4: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00D79DB8: CBNZ x20, #0xd79dc0        | if (val_13 != null) goto label_57;      
        if(val_13 != null)
        {
            goto label_57;
        }
        // 0x00D79DBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_57:
        // 0x00D79DC0: LDR x21, [x20, #0x278]     | X21 = val_13.<fightCtrl>k__BackingField; //P2 
        // 0x00D79DC4: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        val_87 = mem[??? + 96];
        val_87 = ??? + 96;
        // 0x00D79DC8: CBZ x24, #0xd7accc         | if (??? + 96 == 0) goto label_58;       
        if(val_87 == 0)
        {
            goto label_58;
        }
        // 0x00D79DCC: LDR w22, [x24, #0xa8]      | W22 = ??? + 96 + 168;                   
        val_88 = mem[??? + 96 + 168];
        val_88 = ??? + 96 + 168;
        // 0x00D79DD0: MOV x23, x24               | X23 = ??? + 96;//m1                     
        val_89 = val_87;
        // 0x00D79DD4: B #0xd7b0a8                |  goto label_238;                        
        goto label_238;
        // 0x00D79DD8: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D79DDC: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00D79DE0: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D79DE4: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00D79DE8: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D79DEC: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D79DF0: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_90 = ??? + 96;
        // 0x00D79DF4: CBNZ x21, #0xd79e04        | if (??? + 96 != 0) goto label_60;       
        if((??? + 96) != 0)
        {
            goto label_60;
        }
        // 0x00D79DF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        // 0x00D79DFC: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_90 = mem[??? + 96];
        val_90 = ??? + 96;
        // 0x00D79E00: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_90 == 0)
        {
            goto label_382;
        }
        label_60:
        // 0x00D79E04: LDR w23, [x21, #0x94]      | W23 = ??? + 96 + 148;                   
        val_72 = mem[??? + 96 + 148];
        val_72 = ??? + 96 + 148;
        // 0x00D79E08: LDR w21, [x8, #0x90]       | W21 = ??? + 96 + 144;                   
        // 0x00D79E0C: CBNZ x20, #0xd79e14        | if (GameMgr.UPDATEOnOffEffect != null) goto label_62;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_62;
        }
        // 0x00D79E10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_62:
        // 0x00D79E14: CMP w23, #1                | STATE = COMPARE(??? + 96 + 148, 0x1)    
        // 0x00D79E18: CSET w1, eq                | W1 = val_72 == 0x1 ? 1 : 0;             
        bool val_14 = (val_72 == 1) ? 1 : 0;
        // 0x00D79E1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79E20: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D79E24: MOV w2, w21                | W2 = ??? + 96 + 144;//m1                
        // 0x00D79E28: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_14 = (val_72 == 1) ? 1 : 0, id:  ??? + 96 + 144);
        CombatEntity val_15 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_14, id:  ??? + 96 + 144);
        // 0x00D79E2C: MOV x20, x0                | X20 = val_15;//m1                       
        // 0x00D79E30: CBNZ x20, #0xd79e38        | if (val_15 != null) goto label_63;      
        if(val_15 != null)
        {
            goto label_63;
        }
        // 0x00D79E34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_63:
        // 0x00D79E38: LDR x21, [x22]             | X21 = ??? + 96 + 168;                   
        // 0x00D79E3C: LDR x20, [x20, #0x288]     | X20 = val_15.<bvrCtrl>k__BackingField; //P2 
        // 0x00D79E40: MOV x0, x21                | X0 = ??? + 96 + 168;//m1                
        // 0x00D79E44: BL #0x277461c              | X0 = sub_277461C( ?? ??? + 96 + 168, ????);
        // 0x00D79E48: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D79E4C: MOV x0, x21                | X0 = ??? + 96 + 168;//m1                
        // 0x00D79E50: BL #0x27c1608              | X0 = sub_27C1608( ?? ??? + 96 + 168, ????);
        // 0x00D79E54: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D79E58: MOV x21, x0                | X21 = ??? + 96 + 168;//m1               
        val_73 = val_88;
        // 0x00D79E5C: CBNZ x22, #0xd79e64        | if (??? + 96 != 0) goto label_64;       
        if((??? + 96) != 0)
        {
            goto label_64;
        }
        // 0x00D79E60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ??? + 96 + 168, ????);
        label_64:
        // 0x00D79E64: ADRP x11, #0x3673000       | X11 = 57094144 (0x3673000);             
        // 0x00D79E68: LDP w8, w9, [x22, #0xac]   | W8 = ??? + 96 + 172; W9 = ??? + 96 + 172 + 4; //  | 
        // 0x00D79E6C: LDR w10, [x22, #0xb4]      | W10 = ??? + 96 + 180;                   
        // 0x00D79E70: LDR x11, [x11, #0x488]     | X11 = 1152921504695078912;              
        // 0x00D79E74: ADD x1, sp, #0x68          | X1 = (1152921515115947904 + 104) = 1152921515115948008 (0x10000002726427E8);
        // 0x00D79E78: LDR x0, [x11]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D79E7C: STP w8, w9, [sp, #0x68]    | stack[1152921515115948008] = ??? + 96 + 172;  stack[1152921515115948012] = ??? + 96 + 172 + 4;  //  dest_result_addr=1152921515115948008 |  dest_result_addr=1152921515115948012
        // 0x00D79E80: STR w10, [sp, #0x70]       | stack[1152921515115948016] = ??? + 96 + 180;  //  dest_result_addr=1152921515115948016
        // 0x00D79E84: BL #0x27bc028              | X0 = 1152921515116132192 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), ??? + 96 + 172);
        // 0x00D79E88: MOV x22, x0                | X22 = 1152921515116132192 (0x100000027266F760);//ML01
        // 0x00D79E8C: CBNZ x21, #0xd79e94        | if (??? + 96 + 168 != 0) goto label_65; 
        if(val_73 != 0)
        {
            goto label_65;
        }
        // 0x00D79E90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ??? + 96 + 172, ????);
        label_65:
        // 0x00D79E94: CBZ x22, #0xd79eb8         | if (??? + 96 + 172 == 0) goto label_67; 
        if((??? + 96 + 172) == 0)
        {
            goto label_67;
        }
        // 0x00D79E98: LDR x8, [x21]              | X8 = ??? + 96 + 168;                    
        // 0x00D79E9C: MOV x0, x22                | X0 = 1152921515116132192 (0x100000027266F760);//ML01
        // 0x00D79EA0: LDR x1, [x8, #0x30]        | X1 = ??? + 96 + 168 + 48;               
        // 0x00D79EA4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ??? + 96 + 172, ????);
        // 0x00D79EA8: CBNZ x0, #0xd79eb8         | if (??? + 96 + 172 != 0) goto label_67; 
        if((??? + 96 + 172) != 0)
        {
            goto label_67;
        }
        // 0x00D79EAC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ??? + 96 + 172, ????);
        // 0x00D79EB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79EB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ??? + 96 + 172, ????);
        label_67:
        // 0x00D79EB8: LDR w8, [x21, #0x18]       | W8 = ??? + 96 + 168 + 24;               
        // 0x00D79EBC: CBNZ w8, #0xd79ecc         | if (??? + 96 + 168 + 24 != 0) goto label_68;
        if((??? + 96 + 168 + 24) != 0)
        {
            goto label_68;
        }
        // 0x00D79EC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ??? + 96 + 172, ????);
        // 0x00D79EC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79EC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ??? + 96 + 172, ????);
        label_68:
        // 0x00D79ECC: STR x22, [x21, #0x20]      | mem2[0] = ??? + 96 + 172;                //  dest_result_addr=0
        mem2[0] = ??? + 96 + 172;
        // 0x00D79ED0: CBNZ x20, #0xd79ed8        | if (val_15.<bvrCtrl>k__BackingField != null) goto label_69;
        if((val_15.<bvrCtrl>k__BackingField) != null)
        {
            goto label_69;
        }
        // 0x00D79ED4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ??? + 96 + 172, ????);
        label_69:
        // 0x00D79ED8: LDR x8, [x20]              | X8 = typeof(Entity.Behavior.IBehaviorCtrl);
        // 0x00D79EDC: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00D79EE0: MOV x0, x20                | X0 = val_15.<bvrCtrl>k__BackingField;//m1
        // 0x00D79EE4: MOV x2, x21                | X2 = ??? + 96 + 168;//m1                
        // 0x00D79EE8: LDP x9, x3, [x8, #0x180]   | X9 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180; X3 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_188; //  | 
        // 0x00D79EEC: BLR x9                     | X0 = typeof(Entity.Behavior.IBehaviorCtrl).__il2cppRuntimeField_180();
        // 0x00D79EF0: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        // 0x00D79EF4: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D79EF8: CBNZ x20, #0xd79f00        | if (??? + 96 != 0) goto label_71;       
        if((??? + 96) != 0)
        {
            goto label_71;
        }
        // 0x00D79EFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15.<bvrCtrl>k__BackingField, ????);
        label_71:
        // 0x00D79F00: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
        // 0x00D79F04: LDR w8, [x20, #0xd0]       | W8 = ??? + 96 + 208;                    
        // 0x00D79F08: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
        // 0x00D79F0C: ADD x1, sp, #0x68          | X1 = (1152921515115947904 + 104) = 1152921515115948008 (0x10000002726427E8);
        // 0x00D79F10: STR w8, [sp, #0x68]        | stack[1152921515115948008] = ??? + 96 + 208;  //  dest_result_addr=1152921515115948008
        // 0x00D79F14: LDR x0, [x9]               | X0 = typeof(System.Single);             
        // 0x00D79F18: BL #0x27bc028              | X0 = 1152921515116136288 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), ??? + 96 + 208);
        // 0x00D79F1C: LDR x8, [x25]              | X8 = ;                                  
        // 0x00D79F20: MOV x20, x0                | X20 = 1152921515116136288 (0x1000000272670760);//ML01
        // 0x00D79F24: LDRB w9, [x8, #0x10a]      | W9 = ??? + 266;                         
        // 0x00D79F28: TBZ w9, #0, #0xd79f3c      | if ((??? + 266 & 0x1) == 0) goto label_73;
        if(((??? + 266) & 1) == 0)
        {
            goto label_73;
        }
        // 0x00D79F2C: LDR w9, [x8, #0xbc]        | W9 = ??? + 188;                         
        // 0x00D79F30: CBNZ w9, #0xd79f3c         | if (??? + 188 != 0) goto label_73;      
        if((??? + 188) != 0)
        {
            goto label_73;
        }
        // 0x00D79F34: MOV x0, x8                 | X0 = X8;//m1                            
        // 0x00D79F38: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
        label_73:
        // 0x00D79F3C: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00D79F40: LDR x8, [x8, #0x780]       | X8 = (string**)(1152921515115003680)("waitTime ");
        // 0x00D79F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D79F48: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79F4C: MOV x2, x20                | X2 = 1152921515116136288 (0x1000000272670760);//ML01
        // 0x00D79F50: LDR x1, [x8]               | X1 = "waitTime ";                       
        // 0x00D79F54: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "waitTime ");
        string val_16 = System.String.Concat(arg0:  0, arg1:  "waitTime ");
        // 0x00D79F58: LDR x8, [x24]              | X8 = ??? + 96;                          
        // 0x00D79F5C: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x00D79F60: LDRB w9, [x8, #0x10a]      | W9 = ??? + 96 + 266;                    
        // 0x00D79F64: TBZ w9, #0, #0xd79f78      | if ((??? + 96 + 266 & 0x1) == 0) goto label_75;
        if(((??? + 96 + 266) & 1) == 0)
        {
            goto label_75;
        }
        // 0x00D79F68: LDR w9, [x8, #0xbc]        | W9 = ??? + 96 + 188;                    
        // 0x00D79F6C: CBNZ w9, #0xd79f78         | if (??? + 96 + 188 != 0) goto label_75; 
        if((??? + 96 + 188) != 0)
        {
            goto label_75;
        }
        // 0x00D79F70: MOV x0, x8                 | X0 = ??? + 96;//m1                      
        // 0x00D79F74: BL #0x27977a4              | X0 = sub_27977A4( ?? ??? + 96, ????);   
        label_75:
        // 0x00D79F78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D79F7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D79F80: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D79F84: MOV x1, x20                | X1 = val_16;//m1                        
        // 0x00D79F88: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_16);
        EDebug.Log(message:  0, isShowStack:  val_16);
        // 0x00D79F8C: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        val_91 = mem[??? + 96];
        val_91 = ??? + 96;
        // 0x00D79F90: CBZ x20, #0xd7ace4         | if (??? + 96 == 0) goto label_76;       
        if(val_91 == 0)
        {
            goto label_76;
        }
        // 0x00D79F94: LDR w8, [x20, #0xd0]       | W8 = ??? + 96 + 208;                    
        // 0x00D79F98: STR w8, [x19, #0x4c]       | mem2[0] = ??? + 96 + 208;                //  dest_result_addr=0
        mem2[0] = ??? + 96 + 208;
        // 0x00D79F9C: B #0xd7acfc                |  goto label_77;                         
        goto label_77;
        // 0x00D79FA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D79FA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79FA8: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_17 = NpcMgr.instance;
        // 0x00D79FAC: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_92 = mem[??? + 96];
        val_92 = ??? + 96;
        // 0x00D79FB0: MOV x20, x0                | X20 = val_17;//m1                       
        // 0x00D79FB4: CBZ x23, #0xd7ad68         | if (??? + 96 == 0) goto label_78;       
        if(val_92 == 0)
        {
            goto label_78;
        }
        // 0x00D79FB8: LDR w21, [x23, #0xb8]      | W21 = ??? + 96 + 184;                   
        val_73 = mem[??? + 96 + 184];
        val_73 = ??? + 96 + 184;
        // 0x00D79FBC: MOV x22, x23               | X22 = ??? + 96;//m1                     
        val_93 = val_92;
        // 0x00D79FC0: B #0xd7b130                |  goto label_244;                        
        goto label_244;
        // 0x00D79FC4: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D79FC8: CBNZ x20, #0xd79fd0        | if (??? + 96 != 0) goto label_80;       
        if((??? + 96) != 0)
        {
            goto label_80;
        }
        // 0x00D79FCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_80:
        // 0x00D79FD0: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D79FD4: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00D79FD8: LDR w21, [x20, #0xd4]      | W21 = ??? + 96 + 212;                   
        val_73 = mem[??? + 96 + 212];
        val_73 = ??? + 96 + 212;
        // 0x00D79FDC: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00D79FE0: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D79FE4: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D79FE8: CBNZ x20, #0xd79ff0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_81;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_81;
        }
        // 0x00D79FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_81:
        // 0x00D79FF0: CMP w21, #1                | STATE = COMPARE(??? + 96 + 212, 0x1)    
        // 0x00D79FF4: B.NE #0xd7a924             | if (val_73 != 0x1) goto label_82;       
        if(val_73 != 1)
        {
            goto label_82;
        }
        // 0x00D79FF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D79FFC: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A000: BL #0xc1933c               | GameMgr.UPDATEOnOffEffect.LockNpcBehaviour();
        GameMgr.UPDATEOnOffEffect.LockNpcBehaviour();
        // 0x00D7A004: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        // 0x00D7A008: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D7A00C: LDR x8, [x8, #0xb20]       | X8 = 1152921504901574656;               
        // 0x00D7A010: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7A014: LDR x8, [x8]               | X8 = typeof(GameMgr);                   
        // 0x00D7A018: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7A01C: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D7A020: CBNZ x21, #0xd7a028        | if (??? + 96 != 0) goto label_84;       
        if((??? + 96) != 0)
        {
            goto label_84;
        }
        // 0x00D7A024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? GameMgr.UPDATEOnOffEffect, ????);
        label_84:
        // 0x00D7A028: LDR w21, [x21, #0xd8]      | W21 = ??? + 96 + 216;                   
        val_73 = mem[??? + 96 + 216];
        val_73 = ??? + 96 + 216;
        // 0x00D7A02C: CBNZ x20, #0xd7a034        | if (GameMgr.UPDATEOnOffEffect != null) goto label_85;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_85;
        }
        // 0x00D7A030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? GameMgr.UPDATEOnOffEffect, ????);
        label_85:
        // 0x00D7A034: CMP w21, #1                | STATE = COMPARE(??? + 96 + 216, 0x1)    
        // 0x00D7A038: CSET w1, eq                | W1 = val_73 == 0x1 ? 1 : 0;             
        bool val_18 = (val_73 == 1) ? 1 : 0;
        // 0x00D7A03C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7A040: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A044: BL #0xc1908c               | GameMgr.UPDATEOnOffEffect.SetFightCtrlUpdateState(isState:  bool val_18 = (val_73 == 1) ? 1 : 0);
        GameMgr.UPDATEOnOffEffect.SetFightCtrlUpdateState(isState:  val_18);
        // 0x00D7A048: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        // 0x00D7A04C: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A050: CBNZ x20, #0xd7a058        | if (??? + 96 != 0) goto label_87;       
        if((??? + 96) != 0)
        {
            goto label_87;
        }
        // 0x00D7A054: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? GameMgr.UPDATEOnOffEffect, ????);
        label_87:
        // 0x00D7A058: LDR w8, [x20, #0xdc]       | W8 = ??? + 96 + 220;                    
        // 0x00D7A05C: CMP w8, #1                 | STATE = COMPARE(??? + 96 + 220, 0x1)    
        // 0x00D7A060: B.NE #0xd7b158             | if (??? + 96 + 220 != 0x1) goto label_346;
        if((??? + 96 + 220) != 1)
        {
            goto label_346;
        }
        // 0x00D7A064: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D7A068: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D7A06C: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_94 = null;
        // 0x00D7A070: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A074: TBZ w8, #0, #0xd7a088      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_90;
        // 0x00D7A078: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A07C: CBNZ w8, #0xd7a088         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_90;
        // 0x00D7A080: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A084: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_94 = null;
        label_90:
        // 0x00D7A088: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A08C: LDR x21, [x8]              | X21 = CameraShotHelper.instance;        
        // 0x00D7A090: CBNZ x21, #0xd7a098        | if (CameraShotHelper.instance != null) goto label_91;
        if(CameraShotHelper.instance != null)
        {
            goto label_91;
        }
        // 0x00D7A094: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_91:
        // 0x00D7A098: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7A09C: STRB w8, [x21, #0x20]      | CameraShotHelper.instance.IsOpeningMoveUpdate = true;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = true;
        // 0x00D7A0A0: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7A0A4: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A0A8: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A0AC: CBNZ x20, #0xd7a0b4        | if (CameraShotHelper.instance != null) goto label_92;
        if(CameraShotHelper.instance != null)
        {
            goto label_92;
        }
        // 0x00D7A0B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_92:
        // 0x00D7A0B4: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7A0B8: CBNZ x20, #0xd7a0c0        | if ( != 0) goto label_93;               
        if(null != 0)
        {
            goto label_93;
        }
        // 0x00D7A0BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_93:
        // 0x00D7A0C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7A0C4: STRB w8, [x20, #0x88]      | typeof(CameraBezier).__il2cppRuntimeField_88 = 0x1;  //  dest_result_addr=1152921504843214984
        typeof(CameraBezier).__il2cppRuntimeField_88 = 1;
        // 0x00D7A0C8: B #0xd7ae1c                |  goto label_94;                         
        goto label_94;
        // 0x00D7A0CC: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A0D0: CBNZ x20, #0xd7a0d8        | if (??? + 96 != 0) goto label_95;       
        if((??? + 96) != 0)
        {
            goto label_95;
        }
        // 0x00D7A0D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_95:
        // 0x00D7A0D8: LDR w8, [x20, #0xe0]       | W8 = ??? + 96 + 224;                    
        // 0x00D7A0DC: CMP w8, #1                 | STATE = COMPARE(??? + 96 + 224, 0x1)    
        // 0x00D7A0E0: B.NE #0xd7b158             | if (??? + 96 + 224 != 0x1) goto label_346;
        if((??? + 96 + 224) != 1)
        {
            goto label_346;
        }
        // 0x00D7A0E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A0E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A0EC: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_19 = NpcMgr.instance;
        // 0x00D7A0F0: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7A0F4: MOV x20, x0                | X20 = val_19;//m1                       
        // 0x00D7A0F8: CBNZ x21, #0xd7a100        | if (??? + 96 != 0) goto label_97;       
        if((??? + 96) != 0)
        {
            goto label_97;
        }
        // 0x00D7A0FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_97:
        // 0x00D7A100: LDR x21, [x21, #0xc8]      | X21 = ??? + 96 + 200;                   
        val_73 = mem[??? + 96 + 200];
        val_73 = ??? + 96 + 200;
        // 0x00D7A104: CBNZ x20, #0xd7a10c        | if (val_19 != null) goto label_98;      
        if(val_19 != null)
        {
            goto label_98;
        }
        // 0x00D7A108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_98:
        // 0x00D7A10C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7A110: MOV x0, x20                | X0 = val_19;//m1                        
        // 0x00D7A114: MOV x1, x21                | X1 = ??? + 96 + 200;//m1                
        // 0x00D7A118: BL #0xd17f7c               | val_19.ClearAniShowList(special:  val_73);
        val_19.ClearAniShowList(special:  val_73);
        // 0x00D7A11C: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        // 0x00D7A120: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A124: CBNZ x20, #0xd7a12c        | if (??? + 96 != 0) goto label_100;      
        if((??? + 96) != 0)
        {
            goto label_100;
        }
        // 0x00D7A128: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_100:
        // 0x00D7A12C: LDR w8, [x20, #0xe4]       | W8 = ??? + 96 + 228;                    
        // 0x00D7A130: CMP w8, #1                 | STATE = COMPARE(??? + 96 + 228, 0x1)    
        // 0x00D7A134: B.NE #0xd7a934             | if (??? + 96 + 228 != 0x1) goto label_101;
        if((??? + 96 + 228) != 1)
        {
            goto label_101;
        }
        // 0x00D7A138: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
        // 0x00D7A13C: LDR x21, [x21, #0x8b0]     | X21 = 1152921504887996416;              
        // 0x00D7A140: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_95 = null;
        // 0x00D7A144: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A148: TBZ w8, #0, #0xd7a15c      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_103;
        // 0x00D7A14C: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A150: CBNZ w8, #0xd7a15c         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_103;
        // 0x00D7A154: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A158: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_95 = null;
        label_103:
        // 0x00D7A15C: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A160: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A164: CBNZ x20, #0xd7a16c        | if (CameraShotHelper.instance != null) goto label_104;
        if(CameraShotHelper.instance != null)
        {
            goto label_104;
        }
        // 0x00D7A168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_104:
        // 0x00D7A16C: STRB wzr, [x20, #0x20]     | CameraShotHelper.instance.IsOpeningMoveUpdate = false;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = false;
        // 0x00D7A170: LDR x8, [x21]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7A174: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A178: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A17C: CBNZ x20, #0xd7a184        | if (CameraShotHelper.instance != null) goto label_105;
        if(CameraShotHelper.instance != null)
        {
            goto label_105;
        }
        // 0x00D7A180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_105:
        // 0x00D7A184: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7A188: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7A18C: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7A190: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7A194: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7A198: TBZ w8, #0, #0xd7a1a8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_107;
        // 0x00D7A19C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A1A0: CBNZ w8, #0xd7a1a8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_107;
        // 0x00D7A1A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_107:
        // 0x00D7A1A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A1AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A1B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A1B4: MOV x2, x20                | X2 = 1152921504843214848 (0x100000000E16B000);//ML01
        // 0x00D7A1B8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_20 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00D7A1BC: TBZ w0, #0, #0xd7a200      | if (val_20 == false) goto label_108;    
        if(val_20 == false)
        {
            goto label_108;
        }
        // 0x00D7A1C0: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_96 = null;
        // 0x00D7A1C4: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A1C8: TBZ w8, #0, #0xd7a1dc      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_110;
        // 0x00D7A1CC: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A1D0: CBNZ w8, #0xd7a1dc         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_110;
        // 0x00D7A1D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A1D8: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_96 = null;
        label_110:
        // 0x00D7A1DC: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A1E0: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A1E4: CBNZ x20, #0xd7a1ec        | if (CameraShotHelper.instance != null) goto label_111;
        if(CameraShotHelper.instance != null)
        {
            goto label_111;
        }
        // 0x00D7A1E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_111:
        // 0x00D7A1EC: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7A1F0: CBNZ x20, #0xd7a1f8        | if ( != 0) goto label_112;              
        if(null != 0)
        {
            goto label_112;
        }
        // 0x00D7A1F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_112:
        // 0x00D7A1F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7A1FC: STRB w8, [x20, #0x88]      | typeof(CameraBezier).__il2cppRuntimeField_88 = 0x1;  //  dest_result_addr=1152921504843214984
        typeof(CameraBezier).__il2cppRuntimeField_88 = 1;
        label_108:
        // 0x00D7A200: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_97 = null;
        // 0x00D7A204: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A208: TBZ w8, #0, #0xd7a21c      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_114;
        // 0x00D7A20C: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A210: CBNZ w8, #0xd7a21c         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_114;
        // 0x00D7A214: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A218: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_97 = null;
        label_114:
        // 0x00D7A21C: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A220: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_98 = mem[??? + 96];
        val_98 = ??? + 96;
        // 0x00D7A224: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A228: CBZ x23, #0xd7adb0         | if (??? + 96 == 0) goto label_115;      
        if(val_98 == 0)
        {
            goto label_115;
        }
        // 0x00D7A22C: LDR w21, [x23, #0xe8]      | W21 = ??? + 96 + 232;                   
        val_99 = mem[??? + 96 + 232];
        val_99 = ??? + 96 + 232;
        // 0x00D7A230: MOV x22, x23               | X22 = ??? + 96;//m1                     
        val_100 = val_98;
        // 0x00D7A234: B #0xd7b42c                |  goto label_250;                        
        goto label_250;
        // 0x00D7A238: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A23C: CBNZ x20, #0xd7a244        | if (??? + 96 != 0) goto label_117;      
        if((??? + 96) != 0)
        {
            goto label_117;
        }
        // 0x00D7A240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_117:
        // 0x00D7A244: LDR w8, [x20, #0x118]      | W8 = ??? + 96 + 280;                    
        // 0x00D7A248: CBZ w8, #0xd7a8dc          | if (??? + 96 + 280 == 0) goto label_137;
        if((??? + 96 + 280) == 0)
        {
            goto label_137;
        }
        // 0x00D7A24C: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A250: CBNZ x20, #0xd7a258        | if (??? + 96 != 0) goto label_119;      
        if((??? + 96) != 0)
        {
            goto label_119;
        }
        // 0x00D7A254: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_119:
        // 0x00D7A258: LDR w8, [x20, #0x90]       | W8 = ??? + 96 + 144;                    
        // 0x00D7A25C: CMN w8, #1                 | STATE = COMPARE(??? + 96 + 144, 0x1)    
        // 0x00D7A260: B.EQ #0xd7aa74             | if (??? + 96 + 144 == 0x1) goto label_139;
        if((??? + 96 + 144) == 1)
        {
            goto label_139;
        }
        // 0x00D7A264: ADRP x22, #0x35f7000       | X22 = 56586240 (0x35F7000);             
        // 0x00D7A268: LDR x22, [x22, #0xb20]     | X22 = 1152921504901574656;              
        // 0x00D7A26C: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7A270: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00D7A274: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7A278: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D7A27C: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_101 = ??? + 96;
        // 0x00D7A280: CBNZ x21, #0xd7a290        | if (??? + 96 != 0) goto label_121;      
        if((??? + 96) != 0)
        {
            goto label_121;
        }
        // 0x00D7A284: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A288: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_101 = mem[??? + 96];
        val_101 = ??? + 96;
        // 0x00D7A28C: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_101 == 0)
        {
            goto label_382;
        }
        label_121:
        // 0x00D7A290: LDR w23, [x21, #0x94]      | W23 = ??? + 96 + 148;                   
        // 0x00D7A294: LDR w21, [x8, #0x90]       | W21 = ??? + 96 + 144;                   
        // 0x00D7A298: CBNZ x20, #0xd7a2a0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_123;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_123;
        }
        // 0x00D7A29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_123:
        // 0x00D7A2A0: CMP w23, #1                | STATE = COMPARE(??? + 96 + 148, 0x1)    
        // 0x00D7A2A4: CSET w1, eq                | W1 = ??? + 96 + 148 == 0x1 ? 1 : 0;     
        bool val_21 = ((??? + 96 + 148) == 1) ? 1 : 0;
        // 0x00D7A2A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A2AC: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A2B0: MOV w2, w21                | W2 = ??? + 96 + 144;//m1                
        // 0x00D7A2B4: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_21 = ((??? + 96 + 148) == 1) ? 1 : 0, id:  ??? + 96 + 144);
        CombatEntity val_22 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_21, id:  ??? + 96 + 144);
        // 0x00D7A2B8: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00D7A2BC: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7A2C0: MOV x20, x0                | X20 = val_22;//m1                       
        // 0x00D7A2C4: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7A2C8: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D7A2CC: CBNZ x22, #0xd7a2d4        | if (??? + 96 != 0) goto label_124;      
        if((??? + 96) != 0)
        {
            goto label_124;
        }
        // 0x00D7A2D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_124:
        // 0x00D7A2D4: LDR w22, [x22, #0x12c]     | W22 = ??? + 96 + 300;                   
        // 0x00D7A2D8: CBNZ x21, #0xd7a2e0        | if (GameMgr.UPDATEOnOffEffect != null) goto label_125;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_125;
        }
        // 0x00D7A2DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
        label_125:
        // 0x00D7A2E0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7A2E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A2E8: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A2EC: MOV w2, w22                | W2 = ??? + 96 + 300;//m1                
        // 0x00D7A2F0: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  false, id:  ??? + 96 + 300);
        CombatEntity val_23 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  false, id:  ??? + 96 + 300);
        // 0x00D7A2F4: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7A2F8: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7A2FC: MOV x22, x0                | X22 = val_23;//m1                       
        // 0x00D7A300: LDR x8, [x8]               | X8 = typeof(ZMG);                       
        // 0x00D7A304: LDRB w9, [x8, #0x10a]      | W9 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7A308: TBZ w9, #0, #0xd7a31c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_127;
        // 0x00D7A30C: LDR w9, [x8, #0xbc]        | W9 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A310: CBNZ w9, #0xd7a31c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_127;
        // 0x00D7A314: MOV x0, x8                 | X0 = 1152921504911851520 (0x10000000122E0000);//ML01
        // 0x00D7A318: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_127:
        // 0x00D7A31C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A324: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_24 = ZMG.EffectMgr;
        // 0x00D7A328: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7A32C: MOV x21, x0                | X21 = val_24;//m1                       
        // 0x00D7A330: CBNZ x23, #0xd7a338        | if (??? + 96 != 0) goto label_128;      
        if((??? + 96) != 0)
        {
            goto label_128;
        }
        // 0x00D7A334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_128:
        // 0x00D7A338: LDR w23, [x23, #0x118]     | W23 = ??? + 96 + 280;                   
        // 0x00D7A33C: CBNZ x21, #0xd7a344        | if (val_24 != null) goto label_129;     
        if(val_24 != null)
        {
            goto label_129;
        }
        // 0x00D7A340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
        label_129:
        // 0x00D7A344: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7A348: MOV x0, x21                | X0 = val_24;//m1                        
        // 0x00D7A34C: MOV w1, w23                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7A350: BL #0xb5fbc8               | X0 = val_24.GetEffectObj(id:  ??? + 96 + 280);
        UnityEngine.GameObject val_25 = val_24.GetEffectObj(id:  ??? + 96 + 280);
        // 0x00D7A354: MOV x21, x0                | X21 = val_25;//m1                       
        // 0x00D7A358: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A35C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A360: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_26 = ZMG.EffectMgr;
        // 0x00D7A364: LDR x25, [x19, #0x60]      | X25 = ??? + 96;                         
        val_102 = mem[??? + 96];
        val_102 = ??? + 96;
        // 0x00D7A368: MOV x23, x0                | X23 = val_26;//m1                       
        // 0x00D7A36C: CBZ x25, #0xd7af30         | if (??? + 96 == 0) goto label_130;      
        if(val_102 == 0)
        {
            goto label_130;
        }
        // 0x00D7A370: LDR w24, [x25, #0x118]     | W24 = ??? + 96 + 280;                   
        val_103 = mem[??? + 96 + 280];
        val_103 = ??? + 96 + 280;
        // 0x00D7A374: MOV x26, x25               | X26 = ??? + 96;//m1                     
        val_104 = val_102;
        // 0x00D7A378: B #0xd7b4fc                |  goto label_265;                        
        goto label_265;
        // 0x00D7A37C: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D7A380: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D7A384: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_105 = null;
        // 0x00D7A388: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A38C: TBZ w8, #0, #0xd7a3a0      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_133;
        // 0x00D7A390: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A394: CBNZ w8, #0xd7a3a0         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_133;
        // 0x00D7A398: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A39C: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_105 = null;
        label_133:
        // 0x00D7A3A0: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A3A4: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        val_106 = mem[??? + 96];
        val_106 = ??? + 96;
        // 0x00D7A3A8: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A3AC: CBZ x22, #0xd7ad80         | if (??? + 96 == 0) goto label_134;      
        if(val_106 == 0)
        {
            goto label_134;
        }
        // 0x00D7A3B0: LDR w21, [x22, #0x138]     | W21 = ??? + 96 + 312;                   
        val_107 = mem[??? + 96 + 312];
        val_107 = ??? + 96 + 312;
        // 0x00D7A3B4: MOV x23, x22               | X23 = ??? + 96;//m1                     
        val_108 = val_106;
        // 0x00D7A3B8: B #0xd7b250                |  goto label_246;                        
        goto label_246;
        // 0x00D7A3BC: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A3C0: CBNZ x20, #0xd7a3c8        | if (??? + 96 != 0) goto label_136;      
        if((??? + 96) != 0)
        {
            goto label_136;
        }
        // 0x00D7A3C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_136:
        // 0x00D7A3C8: LDR w8, [x20, #0x118]      | W8 = ??? + 96 + 280;                    
        // 0x00D7A3CC: CBZ w8, #0xd7a8dc          | if (??? + 96 + 280 == 0) goto label_137;
        if((??? + 96 + 280) == 0)
        {
            goto label_137;
        }
        // 0x00D7A3D0: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A3D4: CBNZ x20, #0xd7a3dc        | if (??? + 96 != 0) goto label_138;      
        if((??? + 96) != 0)
        {
            goto label_138;
        }
        // 0x00D7A3D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_138:
        // 0x00D7A3DC: LDR w8, [x20, #0x90]       | W8 = ??? + 96 + 144;                    
        // 0x00D7A3E0: CMN w8, #1                 | STATE = COMPARE(??? + 96 + 144, 0x1)    
        // 0x00D7A3E4: B.EQ #0xd7aa74             | if (??? + 96 + 144 == 0x1) goto label_139;
        if((??? + 96 + 144) == 1)
        {
            goto label_139;
        }
        // 0x00D7A3E8: ADRP x22, #0x35f7000       | X22 = 56586240 (0x35F7000);             
        // 0x00D7A3EC: LDR x22, [x22, #0xb20]     | X22 = 1152921504901574656;              
        // 0x00D7A3F0: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7A3F4: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00D7A3F8: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7A3FC: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D7A400: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_109 = ??? + 96;
        // 0x00D7A404: CBNZ x21, #0xd7a414        | if (??? + 96 != 0) goto label_140;      
        if((??? + 96) != 0)
        {
            goto label_140;
        }
        // 0x00D7A408: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A40C: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_109 = mem[??? + 96];
        val_109 = ??? + 96;
        // 0x00D7A410: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_109 == 0)
        {
            goto label_382;
        }
        label_140:
        // 0x00D7A414: LDR w23, [x21, #0x94]      | W23 = ??? + 96 + 148;                   
        // 0x00D7A418: LDR w21, [x8, #0x90]       | W21 = ??? + 96 + 144;                   
        // 0x00D7A41C: CBNZ x20, #0xd7a424        | if (GameMgr.UPDATEOnOffEffect != null) goto label_142;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_142;
        }
        // 0x00D7A420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_142:
        // 0x00D7A424: CMP w23, #1                | STATE = COMPARE(??? + 96 + 148, 0x1)    
        // 0x00D7A428: CSET w1, eq                | W1 = ??? + 96 + 148 == 0x1 ? 1 : 0;     
        bool val_27 = ((??? + 96 + 148) == 1) ? 1 : 0;
        // 0x00D7A42C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A430: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A434: MOV w2, w21                | W2 = ??? + 96 + 144;//m1                
        // 0x00D7A438: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  bool val_27 = ((??? + 96 + 148) == 1) ? 1 : 0, id:  ??? + 96 + 144);
        CombatEntity val_28 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  val_27, id:  ??? + 96 + 144);
        // 0x00D7A43C: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00D7A440: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7A444: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D7A448: LDR x21, [x8]              | X21 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D7A44C: STR x0, [sp, #0x60]        | stack[1152921515115948000] = val_28;     //  dest_result_addr=1152921515115948000
        // 0x00D7A450: CBNZ x22, #0xd7a458        | if (??? + 96 != 0) goto label_143;      
        if((??? + 96) != 0)
        {
            goto label_143;
        }
        // 0x00D7A454: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_143:
        // 0x00D7A458: LDR w22, [x22, #0x12c]     | W22 = ??? + 96 + 300;                   
        // 0x00D7A45C: CBNZ x21, #0xd7a464        | if (GameMgr.UPDATEOnOffEffect != null) goto label_144;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_144;
        }
        // 0x00D7A460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_144:
        // 0x00D7A464: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7A468: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A46C: MOV x0, x21                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A470: MOV w2, w22                | W2 = ??? + 96 + 300;//m1                
        // 0x00D7A474: BL #0xc18cd8               | X0 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  false, id:  ??? + 96 + 300);
        CombatEntity val_29 = GameMgr.UPDATEOnOffEffect.GetEntityByID(isHero:  false, id:  ??? + 96 + 300);
        // 0x00D7A478: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7A47C: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7A480: MOV x22, x0                | X22 = val_29;//m1                       
        // 0x00D7A484: LDR x8, [x8]               | X8 = typeof(ZMG);                       
        // 0x00D7A488: LDRB w9, [x8, #0x10a]      | W9 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7A48C: TBZ w9, #0, #0xd7a4a0      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_146;
        // 0x00D7A490: LDR w9, [x8, #0xbc]        | W9 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A494: CBNZ w9, #0xd7a4a0         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_146;
        // 0x00D7A498: MOV x0, x8                 | X0 = 1152921504911851520 (0x10000000122E0000);//ML01
        // 0x00D7A49C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_146:
        // 0x00D7A4A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A4A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A4A8: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_30 = ZMG.EffectMgr;
        // 0x00D7A4AC: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7A4B0: MOV x21, x0                | X21 = val_30;//m1                       
        // 0x00D7A4B4: CBNZ x23, #0xd7a4bc        | if (??? + 96 != 0) goto label_147;      
        if((??? + 96) != 0)
        {
            goto label_147;
        }
        // 0x00D7A4B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_147:
        // 0x00D7A4BC: LDR w23, [x23, #0x118]     | W23 = ??? + 96 + 280;                   
        // 0x00D7A4C0: CBNZ x21, #0xd7a4c8        | if (val_30 != null) goto label_148;     
        if(val_30 != null)
        {
            goto label_148;
        }
        // 0x00D7A4C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_30, ????);     
        label_148:
        // 0x00D7A4C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7A4CC: MOV x0, x21                | X0 = val_30;//m1                        
        // 0x00D7A4D0: MOV w1, w23                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7A4D4: BL #0xb5fbc8               | X0 = val_30.GetEffectObj(id:  ??? + 96 + 280);
        UnityEngine.GameObject val_31 = val_30.GetEffectObj(id:  ??? + 96 + 280);
        // 0x00D7A4D8: MOV x20, x0                | X20 = val_31;//m1                       
        // 0x00D7A4DC: CBNZ x22, #0xd7a4e4        | if (val_29 != null) goto label_149;     
        if(val_29 != null)
        {
            goto label_149;
        }
        // 0x00D7A4E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
        label_149:
        // 0x00D7A4E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A4E8: MOV x0, x22                | X0 = val_29;//m1                        
        // 0x00D7A4EC: BL #0x20d50fc              | X0 = val_29.get_gameObject();           
        UnityEngine.GameObject val_32 = val_29.gameObject;
        // 0x00D7A4F0: MOV x23, x0                | X23 = val_32;//m1                       
        // 0x00D7A4F4: CBNZ x23, #0xd7a4fc        | if (val_32 != null) goto label_150;     
        if(val_32 != null)
        {
            goto label_150;
        }
        // 0x00D7A4F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_150:
        // 0x00D7A4FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A500: MOV x0, x23                | X0 = val_32;//m1                        
        // 0x00D7A504: BL #0x1b759fc              | X0 = val_32.get_name();                 
        string val_33 = val_32.name;
        // 0x00D7A508: LDR x8, [x25]              | X8 = ??? + 96;                          
        // 0x00D7A50C: MOV x23, x0                | X23 = val_33;//m1                       
        // 0x00D7A510: LDRB w9, [x8, #0x10a]      | W9 = ??? + 96 + 266;                    
        // 0x00D7A514: TBZ w9, #0, #0xd7a528      | if ((??? + 96 + 266 & 0x1) == 0) goto label_152;
        if(((??? + 96 + 266) & 1) == 0)
        {
            goto label_152;
        }
        // 0x00D7A518: LDR w9, [x8, #0xbc]        | W9 = ??? + 96 + 188;                    
        // 0x00D7A51C: CBNZ w9, #0xd7a528         | if (??? + 96 + 188 != 0) goto label_152;
        if((??? + 96 + 188) != 0)
        {
            goto label_152;
        }
        // 0x00D7A520: MOV x0, x8                 | X0 = ??? + 96;//m1                      
        // 0x00D7A524: BL #0x27977a4              | X0 = sub_27977A4( ?? ??? + 96, ????);   
        label_152:
        // 0x00D7A528: ADRP x25, #0x3663000       | X25 = 57028608 (0x3663000);             
        // 0x00D7A52C: LDR x25, [x25, #0xad0]     | X25 = (string**)(1152921515115061120)("target Name ");
        // 0x00D7A530: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A534: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A538: MOV x2, x23                | X2 = val_33;//m1                        
        // 0x00D7A53C: LDR x1, [x25]              | X1 = "target Name ";                    
        // 0x00D7A540: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  "target Name ");
        string val_34 = System.String.Concat(str0:  0, str1:  "target Name ");
        // 0x00D7A544: LDR x8, [x24]              | X8 = ??? + 96 + 280;                    
        // 0x00D7A548: MOV x23, x0                | X23 = val_34;//m1                       
        // 0x00D7A54C: LDRB w9, [x8, #0x10a]      | W9 = ??? + 96 + 280 + 266;              
        // 0x00D7A550: TBZ w9, #0, #0xd7a564      | if ((??? + 96 + 280 + 266 & 0x1) == 0) goto label_154;
        if(((??? + 96 + 280 + 266) & 1) == 0)
        {
            goto label_154;
        }
        // 0x00D7A554: LDR w9, [x8, #0xbc]        | W9 = ??? + 96 + 280 + 188;              
        // 0x00D7A558: CBNZ w9, #0xd7a564         | if (??? + 96 + 280 + 188 != 0) goto label_154;
        if((??? + 96 + 280 + 188) != 0)
        {
            goto label_154;
        }
        // 0x00D7A55C: MOV x0, x8                 | X0 = ??? + 96 + 280;//m1                
        // 0x00D7A560: BL #0x27977a4              | X0 = sub_27977A4( ?? ??? + 96 + 280, ????);
        label_154:
        // 0x00D7A564: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A568: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A56C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7A570: MOV x1, x23                | X1 = val_34;//m1                        
        // 0x00D7A574: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_34);
        EDebug.Log(message:  0, isShowStack:  val_34);
        // 0x00D7A578: CBNZ x22, #0xd7a580        | if (val_29 != null) goto label_155;     
        if(val_29 != null)
        {
            goto label_155;
        }
        // 0x00D7A57C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_155:
        // 0x00D7A580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A584: MOV x0, x22                | X0 = val_29;//m1                        
        // 0x00D7A588: BL #0x20d50fc              | X0 = val_29.get_gameObject();           
        UnityEngine.GameObject val_35 = val_29.gameObject;
        // 0x00D7A58C: MOV x23, x0                | X23 = val_35;//m1                       
        // 0x00D7A590: CBNZ x23, #0xd7a598        | if (val_35 != null) goto label_156;     
        if(val_35 != null)
        {
            goto label_156;
        }
        // 0x00D7A594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_156:
        // 0x00D7A598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A59C: MOV x0, x23                | X0 = val_35;//m1                        
        // 0x00D7A5A0: BL #0x1a62c1c              | X0 = val_35.get_transform();            
        UnityEngine.Transform val_36 = val_35.transform;
        // 0x00D7A5A4: MOV x23, x0                | X23 = val_36;//m1                       
        // 0x00D7A5A8: CBNZ x23, #0xd7a5b0        | if (val_36 != null) goto label_157;     
        if(val_36 != null)
        {
            goto label_157;
        }
        // 0x00D7A5AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
        label_157:
        // 0x00D7A5B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A5B4: MOV x0, x23                | X0 = val_36;//m1                        
        // 0x00D7A5B8: BL #0x2693510              | X0 = val_36.get_position();             
        UnityEngine.Vector3 val_37 = val_36.position;
        // 0x00D7A5BC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00D7A5C0: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00D7A5C4: ADD x1, sp, #0x68          | X1 = (1152921515115947904 + 104) = 1152921515115948008 (0x10000002726427E8);
        // 0x00D7A5C8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00D7A5CC: STP s0, s1, [sp, #0x68]    | stack[1152921515115948008] = val_37.x;  stack[1152921515115948012] = val_37.y;  //  dest_result_addr=1152921515115948008 |  dest_result_addr=1152921515115948012
        // 0x00D7A5D0: STR s2, [sp, #0x70]        | stack[1152921515115948016] = val_37.z;   //  dest_result_addr=1152921515115948016
        // 0x00D7A5D4: BL #0x27bc028              | X0 = 1152921515116211040 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Vector3), val_37);
        // 0x00D7A5D8: LDR x1, [x25]              | X1 = "target Name ";                    
        // 0x00D7A5DC: MOV x2, x0                 | X2 = 1152921515116211040 (0x1000000272682B60);//ML01
        // 0x00D7A5E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A5E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A5E8: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "target Name ");
        string val_38 = System.String.Concat(arg0:  0, arg1:  "target Name ");
        // 0x00D7A5EC: MOV x1, x0                 | X1 = val_38;//m1                        
        // 0x00D7A5F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A5F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A5F8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7A5FC: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_38);
        EDebug.Log(message:  0, isShowStack:  val_38);
        // 0x00D7A600: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A608: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_39 = ZMG.EffectMgr;
        // 0x00D7A60C: LDR x25, [x19, #0x60]      | X25 = ??? + 96;                         
        val_110 = mem[??? + 96];
        val_110 = ??? + 96;
        // 0x00D7A610: MOV x23, x0                | X23 = val_39;//m1                       
        // 0x00D7A614: CBZ x25, #0xd7af48         | if (??? + 96 == 0) goto label_158;      
        if(val_110 == 0)
        {
            goto label_158;
        }
        // 0x00D7A618: LDR w24, [x25, #0x118]     | W24 = ??? + 96 + 280;                   
        val_111 = mem[??? + 96 + 280];
        val_111 = ??? + 96 + 280;
        // 0x00D7A61C: B #0xd7af5c                |  goto label_159;                        
        goto label_159;
        // 0x00D7A620: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A624: CBNZ x20, #0xd7a62c        | if (??? + 96 != 0) goto label_160;      
        if((??? + 96) != 0)
        {
            goto label_160;
        }
        // 0x00D7A628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_160:
        // 0x00D7A62C: LDR w8, [x20, #0x144]      | W8 = ??? + 96 + 324;                    
        // 0x00D7A630: LDR x0, [x23]              | X0 = typeof(EffectMgr);                 
        // 0x00D7A634: ADD x1, sp, #0x68          | X1 = (1152921515115947904 + 104) = 1152921515115948008 (0x10000002726427E8);
        // 0x00D7A638: STR w8, [sp, #0x68]        | stack[1152921515115948008] = ??? + 96 + 324;  //  dest_result_addr=1152921515115948008
        // 0x00D7A63C: BL #0x27bc028              | X0 = 1152921515116223328 = (Il2CppObject*)Box((RuntimeClass*)typeof(EffectMgr), ??? + 96 + 324);
        // 0x00D7A640: LDR x8, [x25]              | X8 = ??? + 96;                          
        // 0x00D7A644: MOV x20, x0                | X20 = 1152921515116223328 (0x1000000272685B60);//ML01
        // 0x00D7A648: LDRB w9, [x8, #0x10a]      | W9 = ??? + 96 + 266;                    
        // 0x00D7A64C: TBZ w9, #0, #0xd7a660      | if ((??? + 96 + 266 & 0x1) == 0) goto label_162;
        if(((??? + 96 + 266) & 1) == 0)
        {
            goto label_162;
        }
        // 0x00D7A650: LDR w9, [x8, #0xbc]        | W9 = ??? + 96 + 188;                    
        // 0x00D7A654: CBNZ w9, #0xd7a660         | if (??? + 96 + 188 != 0) goto label_162;
        if((??? + 96 + 188) != 0)
        {
            goto label_162;
        }
        // 0x00D7A658: MOV x0, x8                 | X0 = ??? + 96;//m1                      
        // 0x00D7A65C: BL #0x27977a4              | X0 = sub_27977A4( ?? ??? + 96, ????);   
        label_162:
        // 0x00D7A660: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00D7A664: LDR x8, [x8, #0xde8]       | X8 = (string**)(1152921515115090912)("真实战斗 isTruth ");
        // 0x00D7A668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A66C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A670: MOV x2, x20                | X2 = 1152921515116223328 (0x1000000272685B60);//ML01
        // 0x00D7A674: LDR x1, [x8]               | X1 = "真实战斗 isTruth ";                   
        // 0x00D7A678: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "真实战斗 isTruth ");
        string val_40 = System.String.Concat(arg0:  0, arg1:  "真实战斗 isTruth ");
        // 0x00D7A67C: LDR x8, [x24]              | X8 = ??? + 96 + 280;                    
        // 0x00D7A680: MOV x20, x0                | X20 = val_40;//m1                       
        // 0x00D7A684: LDRB w9, [x8, #0x10a]      | W9 = ??? + 96 + 280 + 266;              
        // 0x00D7A688: TBZ w9, #0, #0xd7a69c      | if ((??? + 96 + 280 + 266 & 0x1) == 0) goto label_164;
        if(((??? + 96 + 280 + 266) & 1) == 0)
        {
            goto label_164;
        }
        // 0x00D7A68C: LDR w9, [x8, #0xbc]        | W9 = ??? + 96 + 280 + 188;              
        // 0x00D7A690: CBNZ w9, #0xd7a69c         | if (??? + 96 + 280 + 188 != 0) goto label_164;
        if((??? + 96 + 280 + 188) != 0)
        {
            goto label_164;
        }
        // 0x00D7A694: MOV x0, x8                 | X0 = ??? + 96 + 280;//m1                
        // 0x00D7A698: BL #0x27977a4              | X0 = sub_27977A4( ?? ??? + 96 + 280, ????);
        label_164:
        // 0x00D7A69C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A6A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A6A4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00D7A6A8: MOV x1, x20                | X1 = val_40;//m1                        
        // 0x00D7A6AC: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_40);
        EDebug.Log(message:  0, isShowStack:  val_40);
        // 0x00D7A6B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A6B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A6B8: BL #0xd0f5f8               | X0 = NpcMgr.get_instance();             
        NpcMgr val_41 = NpcMgr.instance;
        // 0x00D7A6BC: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7A6C0: MOV x20, x0                | X20 = val_41;//m1                       
        // 0x00D7A6C4: MOV x8, x21                | X8 = ??? + 96;//m1                      
        val_112 = ??? + 96;
        // 0x00D7A6C8: CBNZ x21, #0xd7a6d8        | if (??? + 96 != 0) goto label_165;      
        if((??? + 96) != 0)
        {
            goto label_165;
        }
        // 0x00D7A6CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        // 0x00D7A6D0: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_112 = mem[??? + 96];
        val_112 = ??? + 96;
        // 0x00D7A6D4: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_112 == 0)
        {
            goto label_382;
        }
        label_165:
        // 0x00D7A6D8: LDR w21, [x21, #0x144]     | W21 = ??? + 96 + 324;                   
        val_73 = mem[??? + 96 + 324];
        val_73 = ??? + 96 + 324;
        // 0x00D7A6DC: LDR x22, [x8, #0x148]      | X22 = ??? + 96 + 328;                   
        // 0x00D7A6E0: CBNZ x20, #0xd7a6e8        | if (val_41 != null) goto label_167;     
        if(val_41 != null)
        {
            goto label_167;
        }
        // 0x00D7A6E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
        label_167:
        // 0x00D7A6E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A6EC: MOV x0, x20                | X0 = val_41;//m1                        
        // 0x00D7A6F0: MOV w1, w21                | W1 = ??? + 96 + 324;//m1                
        // 0x00D7A6F4: MOV x2, x22                | X2 = ??? + 96 + 328;//m1                
        // 0x00D7A6F8: BL #0xd18380               | val_41.CameraShotBattle(isTruth:  val_73, specialInTruth:  ??? + 96 + 328);
        val_41.CameraShotBattle(isTruth:  val_73, specialInTruth:  ??? + 96 + 328);
        // 0x00D7A6FC: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        // 0x00D7A700: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
        // 0x00D7A704: LDR x21, [x21, #0x8b0]     | X21 = 1152921504887996416;              
        // 0x00D7A708: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_113 = null;
        // 0x00D7A70C: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A710: TBZ w8, #0, #0xd7a724      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_170;
        // 0x00D7A714: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A718: CBNZ w8, #0xd7a724         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_170;
        // 0x00D7A71C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A720: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_113 = null;
        label_170:
        // 0x00D7A724: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A728: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A72C: CBNZ x20, #0xd7a734        | if (CameraShotHelper.instance != null) goto label_171;
        if(CameraShotHelper.instance != null)
        {
            goto label_171;
        }
        // 0x00D7A730: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_171:
        // 0x00D7A734: STRB wzr, [x20, #0x20]     | CameraShotHelper.instance.IsOpeningMoveUpdate = false;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = false;
        // 0x00D7A738: LDR x8, [x21]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7A73C: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A740: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A744: CBNZ x20, #0xd7a74c        | if (CameraShotHelper.instance != null) goto label_172;
        if(CameraShotHelper.instance != null)
        {
            goto label_172;
        }
        // 0x00D7A748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_172:
        // 0x00D7A74C: STRB wzr, [x20, #0x22]     | CameraShotHelper.instance.isCircleCameraMoving = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isCircleCameraMoving = false;
        // 0x00D7A750: LDR x8, [x21]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7A754: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A758: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A75C: CBNZ x20, #0xd7a764        | if (CameraShotHelper.instance != null) goto label_173;
        if(CameraShotHelper.instance != null)
        {
            goto label_173;
        }
        // 0x00D7A760: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_173:
        // 0x00D7A764: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7A768: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7A76C: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7A770: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7A774: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7A778: TBZ w8, #0, #0xd7a788      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_175;
        // 0x00D7A77C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A780: CBNZ w8, #0xd7a788         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_175;
        // 0x00D7A784: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_175:
        // 0x00D7A788: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A78C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A790: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A794: MOV x2, x20                | X2 = 1152921504843214848 (0x100000000E16B000);//ML01
        // 0x00D7A798: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_42 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00D7A79C: TBZ w0, #0, #0xd7a7e0      | if (val_42 == false) goto label_176;    
        if(val_42 == false)
        {
            goto label_176;
        }
        // 0x00D7A7A0: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_114 = null;
        // 0x00D7A7A4: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A7A8: TBZ w8, #0, #0xd7a7bc      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_178;
        // 0x00D7A7AC: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A7B0: CBNZ w8, #0xd7a7bc         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_178;
        // 0x00D7A7B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A7B8: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_114 = null;
        label_178:
        // 0x00D7A7BC: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A7C0: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A7C4: CBNZ x20, #0xd7a7cc        | if (CameraShotHelper.instance != null) goto label_179;
        if(CameraShotHelper.instance != null)
        {
            goto label_179;
        }
        // 0x00D7A7C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_179:
        // 0x00D7A7CC: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7A7D0: CBNZ x20, #0xd7a7d8        | if ( != 0) goto label_180;              
        if(null != 0)
        {
            goto label_180;
        }
        // 0x00D7A7D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_180:
        // 0x00D7A7D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7A7DC: STRB w8, [x20, #0x88]      | typeof(CameraBezier).__il2cppRuntimeField_88 = 0x1;  //  dest_result_addr=1152921504843214984
        typeof(CameraBezier).__il2cppRuntimeField_88 = 1;
        label_176:
        // 0x00D7A7E0: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_115 = null;
        // 0x00D7A7E4: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A7E8: TBZ w8, #0, #0xd7a7fc      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_182;
        // 0x00D7A7EC: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A7F0: CBNZ w8, #0xd7a7fc         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_182;
        // 0x00D7A7F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A7F8: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_115 = null;
        label_182:
        // 0x00D7A7FC: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A800: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_116 = mem[??? + 96];
        val_116 = ??? + 96;
        // 0x00D7A804: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A808: CBZ x23, #0xd7ad98         | if (??? + 96 == 0) goto label_183;      
        if(val_116 == 0)
        {
            goto label_183;
        }
        // 0x00D7A80C: LDR w21, [x23, #0x90]      | W21 = ??? + 96 + 144;                   
        val_117 = mem[??? + 96 + 144];
        val_117 = ??? + 96 + 144;
        // 0x00D7A810: MOV x22, x23               | X22 = ??? + 96;//m1                     
        val_118 = val_116;
        // 0x00D7A814: B #0xd7b288                |  goto label_248;                        
        goto label_248;
        // 0x00D7A818: LDR x20, [x22]             | X20 = ??? + 96;                         
        // 0x00D7A81C: MOV x0, x20                | X0 = ??? + 96;//m1                      
        // 0x00D7A820: BL #0x277461c              | X0 = sub_277461C( ?? ??? + 96, ????);   
        // 0x00D7A824: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D7A828: MOV x0, x20                | X0 = ??? + 96;//m1                      
        // 0x00D7A82C: BL #0x27c1608              | X0 = sub_27C1608( ?? ??? + 96, ????);   
        // 0x00D7A830: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7A834: MOV x20, x0                | X20 = ??? + 96;//m1                     
        val_79 = val_118;
        // 0x00D7A838: CBNZ x21, #0xd7a840        | if (??? + 96 != 0) goto label_185;      
        if((??? + 96) != 0)
        {
            goto label_185;
        }
        // 0x00D7A83C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ??? + 96, ????);   
        label_185:
        // 0x00D7A840: LDR w8, [x21, #0x164]      | W8 = ??? + 96 + 356;                    
        // 0x00D7A844: LDR x0, [x23]              | X0 = ??? + 96;                          
        // 0x00D7A848: ADD x1, sp, #0x68          | X1 = (1152921515115947904 + 104) = 1152921515115948008 (0x10000002726427E8);
        // 0x00D7A84C: STR w8, [sp, #0x68]        | stack[1152921515115948008] = ??? + 96 + 356;  //  dest_result_addr=1152921515115948008
        // 0x00D7A850: BL #0x27bc028              | X0 = 0 = (Il2CppObject*)Box((RuntimeClass*)typeof(??? + 96), ??? + 96 + 356);
        // 0x00D7A854: MOV x21, x0                | X21 = 1152921515115948008 (0x10000002726427E8);//ML01
        val_73;
        // 0x00D7A858: CBNZ x20, #0xd7a860        | if (??? + 96 != 0) goto label_186;      
        if(val_79 != 0)
        {
            goto label_186;
        }
        // 0x00D7A85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002726427E8, ????);
        label_186:
        // 0x00D7A860: CBZ x21, #0xd7a884         | if (??? + 96 + 356 == 0) goto label_188;
        if((??? + 96 + 356) == 0)
        {
            goto label_188;
        }
        // 0x00D7A864: LDR x8, [x20]              | X8 = ??? + 96;                          
        // 0x00D7A868: MOV x0, x21                | X0 = 1152921515115948008 (0x10000002726427E8);//ML01
        // 0x00D7A86C: LDR x1, [x8, #0x30]        | X1 = ??? + 96 + 48;                     
        // 0x00D7A870: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x10000002726427E8, ????);
        // 0x00D7A874: CBNZ x0, #0xd7a884         | if (??? + 96 + 356 != 0) goto label_188;
        if((??? + 96 + 356) != 0)
        {
            goto label_188;
        }
        // 0x00D7A878: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 0x10000002726427E8, ????);
        // 0x00D7A87C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A880: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002726427E8, ????);
        label_188:
        // 0x00D7A884: LDR w8, [x20, #0x18]       | W8 = ??? + 96 + 24;                     
        // 0x00D7A888: CBNZ w8, #0xd7a898         | if (??? + 96 + 24 != 0) goto label_189; 
        if((??? + 96 + 24) != 0)
        {
            goto label_189;
        }
        // 0x00D7A88C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000002726427E8, ????);
        // 0x00D7A890: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A894: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002726427E8, ????);
        label_189:
        // 0x00D7A898: STR x21, [x20, #0x20]      | mem2[0] = 0x10000002726427E8;            //  dest_result_addr=0
        mem2[0] = val_73;
        // 0x00D7A89C: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7A8A0: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
        // 0x00D7A8A4: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
        // 0x00D7A8A8: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00D7A8AC: TBZ w8, #0, #0xd7a8bc      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_191;
        // 0x00D7A8B0: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A8B4: CBNZ w8, #0xd7a8bc         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_191;
        // 0x00D7A8B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        label_191:
        // 0x00D7A8BC: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00D7A8C0: LDR x8, [x8, #0x638]       | X8 = (string**)(1152921515115099200)("OpenStartAni");
        val_80 = "OpenStartAni";
        label_41:
        // 0x00D7A8C4: LDR x1, [x8]               | X1 = "OpenStartAni";                    
        // 0x00D7A8C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A8CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A8D0: MOV x2, x20                | X2 = ??? + 96;//m1                      
        // 0x00D7A8D4: BL #0xba5838               | CallJSApi.CallJsFun(funName:  0, args:  val_80 = "OpenStartAni");
        CallJSApi.CallJsFun(funName:  0, args:  val_80);
        // 0x00D7A8D8: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_137:
        // 0x00D7A8DC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7A8E0: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7A8E4: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D7A8E8: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7A8EC: TBZ w8, #0, #0xd7a8fc      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_194;
        // 0x00D7A8F0: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A8F4: CBNZ w8, #0xd7a8fc         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_194;
        // 0x00D7A8F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_194:
        // 0x00D7A8FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A900: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A904: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_43 = ZMG.EffectMgr;
        // 0x00D7A908: MOV x20, x0                | X20 = val_43;//m1                       
        // 0x00D7A90C: CBNZ x20, #0xd7a914        | if (val_43 != null) goto label_195;     
        if(val_43 != null)
        {
            goto label_195;
        }
        // 0x00D7A910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_43, ????);     
        label_195:
        // 0x00D7A914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A918: MOV x0, x20                | X0 = val_43;//m1                        
        // 0x00D7A91C: BL #0xb5fdc8               | val_43.ClearSceneEffect();              
        val_43.ClearSceneEffect();
        // 0x00D7A920: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_82:
        // 0x00D7A924: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A928: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D7A92C: BL #0xc19860               | GameMgr.UPDATEOnOffEffect.UnLockNpcBehaviour();
        GameMgr.UPDATEOnOffEffect.UnLockNpcBehaviour();
        // 0x00D7A930: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_101:
        // 0x00D7A934: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A938: CBNZ x20, #0xd7a940        | if (??? + 96 != 0) goto label_198;      
        if((??? + 96) != 0)
        {
            goto label_198;
        }
        // 0x00D7A93C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_198:
        // 0x00D7A940: LDR w8, [x20, #0xe4]       | W8 = ??? + 96 + 228;                    
        // 0x00D7A944: CBZ w8, #0xd7adc8          | if (??? + 96 + 228 == 0) goto label_199;
        if((??? + 96 + 228) == 0)
        {
            goto label_199;
        }
        // 0x00D7A948: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A94C: CBNZ x20, #0xd7a954        | if (??? + 96 != 0) goto label_200;      
        if((??? + 96) != 0)
        {
            goto label_200;
        }
        // 0x00D7A950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_200:
        // 0x00D7A954: LDR w8, [x20, #0xe4]       | W8 = ??? + 96 + 228;                    
        // 0x00D7A958: CMN w8, #1                 | STATE = COMPARE(??? + 96 + 228, 0x1)    
        // 0x00D7A95C: B.EQ #0xd7b320             | if (??? + 96 + 228 == 0x1) goto label_201;
        if((??? + 96 + 228) == 1)
        {
            goto label_201;
        }
        // 0x00D7A960: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7A964: CBNZ x20, #0xd7a96c        | if (??? + 96 != 0) goto label_202;      
        if((??? + 96) != 0)
        {
            goto label_202;
        }
        // 0x00D7A968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
        label_202:
        // 0x00D7A96C: LDR w8, [x20, #0xe4]       | W8 = ??? + 96 + 228;                    
        // 0x00D7A970: CMN w8, #2                 | STATE = COMPARE(??? + 96 + 228, 0x2)    
        // 0x00D7A974: B.NE #0xd7b170             | if (??? + 96 + 228 != 0x2) goto label_368;
        if((??? + 96 + 228) != 2)
        {
            goto label_368;
        }
        // 0x00D7A978: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
        // 0x00D7A97C: LDR x21, [x21, #0x8b0]     | X21 = 1152921504887996416;              
        // 0x00D7A980: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_119 = null;
        // 0x00D7A984: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7A988: TBZ w8, #0, #0xd7a99c      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_205;
        // 0x00D7A98C: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A990: CBNZ w8, #0xd7a99c         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_205;
        // 0x00D7A994: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7A998: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_119 = null;
        label_205:
        // 0x00D7A99C: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A9A0: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A9A4: CBNZ x20, #0xd7a9ac        | if (CameraShotHelper.instance != null) goto label_206;
        if(CameraShotHelper.instance != null)
        {
            goto label_206;
        }
        // 0x00D7A9A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_206:
        // 0x00D7A9AC: STRB wzr, [x20, #0x20]     | CameraShotHelper.instance.IsOpeningMoveUpdate = false;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = false;
        // 0x00D7A9B0: LDR x8, [x21]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7A9B4: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7A9B8: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7A9BC: CBNZ x20, #0xd7a9c4        | if (CameraShotHelper.instance != null) goto label_207;
        if(CameraShotHelper.instance != null)
        {
            goto label_207;
        }
        // 0x00D7A9C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_207:
        // 0x00D7A9C4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7A9C8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7A9CC: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7A9D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7A9D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7A9D8: TBZ w8, #0, #0xd7a9e8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_209;
        // 0x00D7A9DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7A9E0: CBNZ w8, #0xd7a9e8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_209;
        // 0x00D7A9E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_209:
        // 0x00D7A9E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7A9EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7A9F0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7A9F4: MOV x2, x20                | X2 = 1152921504843214848 (0x100000000E16B000);//ML01
        // 0x00D7A9F8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_44 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00D7A9FC: TBZ w0, #0, #0xd7aa40      | if (val_44 == false) goto label_210;    
        if(val_44 == false)
        {
            goto label_210;
        }
        // 0x00D7AA00: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_120 = null;
        // 0x00D7AA04: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7AA08: TBZ w8, #0, #0xd7aa1c      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_212;
        // 0x00D7AA0C: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7AA10: CBNZ w8, #0xd7aa1c         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_212;
        // 0x00D7AA14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AA18: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_120 = null;
        label_212:
        // 0x00D7AA1C: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7AA20: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7AA24: CBNZ x20, #0xd7aa2c        | if (CameraShotHelper.instance != null) goto label_213;
        if(CameraShotHelper.instance != null)
        {
            goto label_213;
        }
        // 0x00D7AA28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_213:
        // 0x00D7AA2C: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7AA30: CBNZ x20, #0xd7aa38        | if ( != 0) goto label_214;              
        if(null != 0)
        {
            goto label_214;
        }
        // 0x00D7AA34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_214:
        // 0x00D7AA38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7AA3C: STRB w8, [x20, #0x88]      | typeof(CameraBezier).__il2cppRuntimeField_88 = 0x1;  //  dest_result_addr=1152921504843214984
        typeof(CameraBezier).__il2cppRuntimeField_88 = 1;
        label_210:
        // 0x00D7AA40: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_121 = null;
        // 0x00D7AA44: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7AA48: TBZ w8, #0, #0xd7aa5c      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_216;
        // 0x00D7AA4C: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7AA50: CBNZ w8, #0xd7aa5c         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_216;
        // 0x00D7AA54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AA58: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_121 = null;
        label_216:
        // 0x00D7AA5C: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7AA60: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_122 = mem[??? + 96];
        val_122 = ??? + 96;
        // 0x00D7AA64: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7AA68: CBZ x23, #0xd7b634         | if (??? + 96 == 0) goto label_217;      
        if(val_122 == 0)
        {
            goto label_217;
        }
        // 0x00D7AA6C: LDR w21, [x23, #0xe8]      | W21 = ??? + 96 + 232;                   
        val_123 = mem[??? + 96 + 232];
        val_123 = ??? + 96 + 232;
        // 0x00D7AA70: B #0xd7b648                |  goto label_218;                        
        goto label_218;
        label_139:
        // 0x00D7AA74: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D7AA78: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7AA7C: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D7AA80: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D7AA84: TBZ w8, #0, #0xd7aa94      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_220;
        // 0x00D7AA88: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7AA8C: CBNZ w8, #0xd7aa94         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_220;
        // 0x00D7AA90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_220:
        // 0x00D7AA94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AA98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AA9C: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_45 = ZMG.EffectMgr;
        // 0x00D7AAA0: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7AAA4: MOV x20, x0                | X20 = val_45;//m1                       
        // 0x00D7AAA8: CBNZ x21, #0xd7aab0        | if (??? + 96 != 0) goto label_221;      
        if((??? + 96) != 0)
        {
            goto label_221;
        }
        // 0x00D7AAAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_221:
        // 0x00D7AAB0: LDR w21, [x21, #0x118]     | W21 = ??? + 96 + 280;                   
        // 0x00D7AAB4: CBNZ x20, #0xd7aabc        | if (val_45 != null) goto label_222;     
        if(val_45 != null)
        {
            goto label_222;
        }
        // 0x00D7AAB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
        label_222:
        // 0x00D7AABC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7AAC0: MOV x0, x20                | X0 = val_45;//m1                        
        // 0x00D7AAC4: MOV w1, w21                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7AAC8: BL #0xb5fbc8               | X0 = val_45.GetEffectObj(id:  ??? + 96 + 280);
        UnityEngine.GameObject val_46 = val_45.GetEffectObj(id:  ??? + 96 + 280);
        // 0x00D7AACC: MOV x20, x0                | X20 = val_46;//m1                       
        // 0x00D7AAD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AAD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AAD8: BL #0x26a8290              | X0 = ZMG.get_EffectMgr();               
        EffectMgr val_47 = ZMG.EffectMgr;
        // 0x00D7AADC: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7AAE0: MOV x21, x0                | X21 = val_47;//m1                       
        // 0x00D7AAE4: CBNZ x22, #0xd7aaec        | if (??? + 96 != 0) goto label_223;      
        if((??? + 96) != 0)
        {
            goto label_223;
        }
        // 0x00D7AAE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_223:
        // 0x00D7AAEC: LDR s8, [x22, #0x11c]      | S8 = ??? + 96 + 284;                    
        val_83 = mem[??? + 96 + 284];
        val_83 = ??? + 96 + 284;
        // 0x00D7AAF0: LDR s9, [x22, #0x120]      | S9 = ??? + 96 + 288;                    
        // 0x00D7AAF4: LDR s10, [x22, #0x124]     | S10 = ??? + 96 + 292;                   
        val_124 = mem[??? + 96 + 292];
        val_124 = ??? + 96 + 292;
        // 0x00D7AAF8: CBNZ x21, #0xd7ab00        | if (val_47 != null) goto label_224;     
        if(val_47 != null)
        {
            goto label_224;
        }
        // 0x00D7AAFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_224:
        // 0x00D7AB00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7AB04: MOV x0, x21                | X0 = val_47;//m1                        
        // 0x00D7AB08: MOV x1, x20                | X1 = val_46;//m1                        
        // 0x00D7AB0C: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 284;//m1                
        // 0x00D7AB10: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 288;//m1                
        // 0x00D7AB14: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 292;//m1                
        // 0x00D7AB18: BL #0xb5fb08               | val_47.PlaySceneEffect(obj:  val_46, pos:  new UnityEngine.Vector3() {x = val_83, y = ??? + 96 + 288, z = val_124});
        val_47.PlaySceneEffect(obj:  val_46, pos:  new UnityEngine.Vector3() {x = val_83, y = ??? + 96 + 288, z = val_124});
        // 0x00D7AB1C: LDR x21, [x19, #0x78]      | X21 = ??? + 120;                        
        val_73 = mem[??? + 120];
        val_73 = ??? + 120;
        // 0x00D7AB20: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7AB24: CBNZ x22, #0xd7ab2c        | if (??? + 96 != 0) goto label_225;      
        if((??? + 96) != 0)
        {
            goto label_225;
        }
        // 0x00D7AB28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_225:
        // 0x00D7AB2C: LDR w22, [x22, #0x118]     | W22 = ??? + 96 + 280;                   
        // 0x00D7AB30: CBNZ x21, #0xd7ab38        | if (??? + 120 != 0) goto label_226;     
        if(val_73 != 0)
        {
            goto label_226;
        }
        // 0x00D7AB34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_47, ????);     
        label_226:
        // 0x00D7AB38: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7AB3C: LDR x8, [x8, #0x898]       | X8 = 1152921510772421328;               
        // 0x00D7AB40: MOV x0, x21                | X0 = ??? + 120;//m1                     
        // 0x00D7AB44: MOV w1, w22                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7AB48: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::ContainsKey(System.Int32 key);
        // 0x00D7AB4C: BL #0x2415bdc              | X0 = ??? + 120.ContainsKey(key:  ??? + 96 + 280);
        bool val_48 = val_73.ContainsKey(key:  ??? + 96 + 280);
        // 0x00D7AB50: AND w8, w0, #1             | W8 = (val_48 & 1);                      
        bool val_49 = val_48;
        // 0x00D7AB54: TBNZ w8, #0, #0xd7b158     | if ((val_48 & 1) == true) goto label_346;
        if(val_49 == true)
        {
            goto label_346;
        }
        // 0x00D7AB58: LDR x21, [x19, #0x78]      | X21 = ??? + 120;                        
        val_73 = mem[??? + 120];
        val_73 = ??? + 120;
        // 0x00D7AB5C: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7AB60: CBNZ x22, #0xd7ab68        | if (??? + 96 != 0) goto label_228;      
        if((??? + 96) != 0)
        {
            goto label_228;
        }
        // 0x00D7AB64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_228:
        // 0x00D7AB68: LDR w22, [x22, #0x118]     | W22 = ??? + 96 + 280;                   
        // 0x00D7AB6C: CBNZ x21, #0xd7ab74        | if (??? + 120 != 0) goto label_229;     
        if(val_73 != 0)
        {
            goto label_229;
        }
        // 0x00D7AB70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
        label_229:
        // 0x00D7AB74: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D7AB78: LDR x8, [x8, #0x710]       | X8 = 1152921510773326416;               
        // 0x00D7AB7C: MOV x0, x21                | X0 = ??? + 120;//m1                     
        // 0x00D7AB80: MOV w1, w22                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7AB84: MOV x2, x20                | X2 = val_46;//m1                        
        // 0x00D7AB88: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::set_Item(System.Int32 key, UnityEngine.GameObject value);
        // 0x00D7AB8C: BL #0x24147b0              | ??? + 120.set_Item(key:  ??? + 96 + 280, value:  val_46);
        val_73.set_Item(key:  ??? + 96 + 280, value:  val_46);
        // 0x00D7AB90: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_27:
        // 0x00D7AB94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AB98: LDR x22, [x19, #0x60]      | X22 = this.curCameraShot; //P2          
        // 0x00D7AB9C: LDR x1, [x21, #0x20]       | X1 = this.curCameraShot.paths; //P2     
        val_78 = this.curCameraShot.paths;
        // 0x00D7ABA0: CBZ x22, #0xd7b058         | if (this.curCameraShot == null) goto label_231;
        if(this.curCameraShot == null)
        {
            goto label_231;
        }
        // 0x00D7ABA4: MOV x21, x22               | X21 = this.curCameraShot;//m1           
        val_76 = this.curCameraShot;
        label_28:
        // 0x00D7ABA8: LDR x26, [x21, #0x28]      | X26 = this.curCameraShot.rotations; //P2 
        val_125 = this.curCameraShot.rotations;
        label_277:
        // 0x00D7ABAC: LDR x27, [x21, #0x30]      | X27 = this.curCameraShot.speeds; //P2   
        val_126 = this.curCameraShot.speeds;
        // 0x00D7ABB0: MOV x22, x21               | X22 = this.curCameraShot;//m1           
        label_351:
        // 0x00D7ABB4: LDR x4, [x22, #0x38]       | X4 = this.curCameraShot.focusIds; //P2  
        val_127 = this.curCameraShot.focusIds;
        // 0x00D7ABB8: MOV x21, x22               | X21 = this.curCameraShot;//m1           
        label_360:
        // 0x00D7ABBC: LDR x5, [x21, #0x40]       | X5 = this.curCameraShot.isHeros; //P2   
        val_128 = this.curCameraShot.isHeros;
        // 0x00D7ABC0: MOV x22, x21               | X22 = this.curCameraShot;//m1           
        label_374:
        // 0x00D7ABC4: LDR x6, [x22, #0x48]       | X6 = this.curCameraShot.smooths; //P2   
        val_129 = this.curCameraShot.smooths;
        // 0x00D7ABC8: MOV x21, x22               | X21 = this.curCameraShot;//m1           
        val_73 = val_76;
        label_378:
        // 0x00D7ABCC: LDR x7, [x21, #0x50]       | X7 = this.curCameraShot.views; //P2     
        val_130 = this.curCameraShot.views;
        // 0x00D7ABD0: MOV x22, x21               | X22 = this.curCameraShot;//m1           
        label_380:
        // 0x00D7ABD4: LDR x8, [x22, #0x60]       | X8 = this.curCameraShot.rotSpeed; //P2  
        val_131 = this.curCameraShot.rotSpeed;
        // 0x00D7ABD8: MOV x24, x22               | X24 = this.curCameraShot;//m1           
        label_384:
        // 0x00D7ABDC: LDR x9, [x24, #0x68]       | X9 = this.curCameraShot.isClockWise; //P2 
        val_132 = this.curCameraShot.isClockWise;
        // 0x00D7ABE0: MOV x23, x24               | X23 = this.curCameraShot;//m1           
        label_386:
        // 0x00D7ABE4: LDR x10, [x23, #0x78]      | X10 = this.curCameraShot.orthograhics; //P2 
        val_133 = this.curCameraShot.orthograhics;
        // 0x00D7ABE8: MOV x25, x23               | X25 = this.curCameraShot;//m1           
        label_389:
        // 0x00D7ABEC: LDR w25, [x25, #0x10]      | W25 = this.curCameraShot.id; //P2       
        val_74 = this.curCameraShot.id;
        // 0x00D7ABF0: LDR x23, [x23, #0x70]      | X23 = this.curCameraShot.isConstant; //P2 
        val_72 = this.curCameraShot.isConstant;
        // 0x00D7ABF4: CBNZ x20, #0xd7ac4c        | if (CameraShotHelper.instance != null) goto label_232;
        if(val_77 != null)
        {
            goto label_232;
        }
        // 0x00D7ABF8: STP x26, x27, [sp, #0x58]  | stack[1152921515115947704] = this.curCameraShot.rotations;  stack[1152921515115947712] = this.curCameraShot.speeds;  //  dest_result_addr=1152921515115947704 |  dest_result_addr=1152921515115947712
        // 0x00D7ABFC: STP x9, x20, [sp, #0x48]   | stack[1152921515115947688] = this.curCameraShot.isClockWise;  stack[1152921515115947696] = CameraShotHelper.instance;  //  dest_result_addr=1152921515115947688 |  dest_result_addr=1152921515115947696
        // 0x00D7AC00: MOV x28, x1                | X28 = this.curCameraShot.paths;//m1     
        // 0x00D7AC04: MOV x22, x4                | X22 = this.curCameraShot.focusIds;//m1  
        // 0x00D7AC08: MOV x24, x5                | X24 = this.curCameraShot.isHeros;//m1   
        // 0x00D7AC0C: MOV x21, x6                | X21 = this.curCameraShot.smooths;//m1   
        val_73 = val_129;
        // 0x00D7AC10: MOV x27, x7                | X27 = this.curCameraShot.views;//m1     
        // 0x00D7AC14: MOV x26, x8                | X26 = this.curCameraShot.rotSpeed;//m1  
        // 0x00D7AC18: MOV x20, x10               | X20 = this.curCameraShot.orthograhics;//m1
        // 0x00D7AC1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AC20: MOV x1, x28                | X1 = this.curCameraShot.paths;//m1      
        val_78 = val_78;
        // 0x00D7AC24: ADRP x28, #0x35c4000       | X28 = 56377344 (0x35C4000);             
        // 0x00D7AC28: MOV x10, x20               | X10 = this.curCameraShot.orthograhics;//m1
        val_133 = val_133;
        // 0x00D7AC2C: LDP x9, x20, [sp, #0x48]   | X9 = this.curCameraShot.isClockWise; X20 = CameraShotHelper.instance; //  | 
        val_132 = val_132;
        val_77 = val_77;
        // 0x00D7AC30: MOV x8, x26                | X8 = this.curCameraShot.rotSpeed;//m1   
        val_131 = val_131;
        // 0x00D7AC34: MOV x7, x27                | X7 = this.curCameraShot.views;//m1      
        val_130 = val_130;
        // 0x00D7AC38: LDR x28, [x28, #0x5d0]     | X28 = 1152921515111781984;              
        val_70 = 1152921515111781984;
        // 0x00D7AC3C: LDP x26, x27, [sp, #0x58]  | X26 = this.curCameraShot.rotations; X27 = this.curCameraShot.speeds; //  | 
        val_125 = val_125;
        val_126 = val_126;
        // 0x00D7AC40: MOV x6, x21                | X6 = this.curCameraShot.smooths;//m1    
        val_129 = val_73;
        // 0x00D7AC44: MOV x5, x24                | X5 = this.curCameraShot.isHeros;//m1    
        val_128 = val_128;
        // 0x00D7AC48: MOV x4, x22                | X4 = this.curCameraShot.focusIds;//m1   
        val_127 = val_127;
        label_232:
        // 0x00D7AC4C: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7AC50: MOV x2, x26                | X2 = this.curCameraShot.rotations;//m1  
        // 0x00D7AC54: MOV x3, x27                | X3 = this.curCameraShot.speeds;//m1     
        // 0x00D7AC58: STP x23, xzr, [sp, #0x20]  | stack[1152921515115947648] = this.curCameraShot.isConstant;  stack[1152921515115947656] = 0x0;  //  dest_result_addr=1152921515115947648 |  dest_result_addr=1152921515115947656
        // 0x00D7AC5C: STR w25, [sp, #0x18]       | stack[1152921515115947640] = this.curCameraShot.id;  //  dest_result_addr=1152921515115947640
        // 0x00D7AC60: STP x9, x10, [sp, #8]      | stack[1152921515115947624] = this.curCameraShot.isClockWise;  stack[1152921515115947632] = this.curCameraShot.orthograhics;  //  dest_result_addr=1152921515115947624 |  dest_result_addr=1152921515115947632
        // 0x00D7AC64: STR x8, [sp]               | stack[1152921515115947616] = this.curCameraShot.rotSpeed;  //  dest_result_addr=1152921515115947616
        // 0x00D7AC68: BL #0xbb0b84               | CameraShotHelper.instance.Preview(points:  val_78 = val_78, rots:  val_125, speeds:  val_126, focusIds:  val_127 = val_127, isHeros:  val_128 = val_128, smooths:  val_129 = val_73, views:  val_130 = val_130, rotSpeed:  val_131, isClockWise:  val_132, orthographics:  val_133, id:  val_74, isConstants:  val_72);
        val_77.Preview(points:  val_78, rots:  val_125, speeds:  val_126, focusIds:  val_127, isHeros:  val_128, smooths:  val_129, views:  val_130, rotSpeed:  val_131, isClockWise:  val_132, orthographics:  val_133, id:  val_74, isConstants:  val_72);
        // 0x00D7AC6C: ADRP x27, #0x3657000       | X27 = 56979456 (0x3657000);             
        // 0x00D7AC70: LDR x27, [x27, #0x6e0]     | X27 = 1152921515111795296;              
        val_71 = 1152921515111795296;
        // 0x00D7AC74: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_44:
        // 0x00D7AC78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AC7C: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7AC80: LDR s8, [x21, #0x84]       | S8 = ??? + 96 + 132;                    
        val_83 = mem[??? + 96 + 132];
        val_83 = ??? + 96 + 132;
        // 0x00D7AC84: CBZ x22, #0xd7b074         | if (??? + 96 == 0) goto label_234;      
        if((??? + 96) == 0)
        {
            goto label_234;
        }
        // 0x00D7AC88: MOV x21, x22               | X21 = ??? + 96;//m1                     
        val_82 = ??? + 96;
        label_45:
        // 0x00D7AC8C: LDR s9, [x21, #0x88]       | S9 = ??? + 96 + 136;                    
        label_278:
        // 0x00D7AC90: LDR s10, [x21, #0xd0]      | S10 = ??? + 96 + 208;                   
        val_124 = mem[??? + 96 + 208];
        val_124 = ??? + 96 + 208;
        // 0x00D7AC94: MOV x22, x21               | X22 = ??? + 96;//m1                     
        label_357:
        // 0x00D7AC98: LDR s11, [x22, #0x8c]      | S11 = ??? + 96 + 140;                   
        // 0x00D7AC9C: LDR w21, [x21, #0x10]      | W21 = ??? + 96 + 16;                    
        val_73 = mem[??? + 96 + 16];
        val_73 = ??? + 96 + 16;
        // 0x00D7ACA0: CBNZ x20, #0xd7aca8        | if (CameraShotHelper.instance != null) goto label_235;
        if(CameraShotHelper.instance != null)
        {
            goto label_235;
        }
        // 0x00D7ACA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_235:
        // 0x00D7ACA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7ACAC: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7ACB0: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 132;//m1                
        // 0x00D7ACB4: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 136;//m1                
        // 0x00D7ACB8: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 208;//m1                
        // 0x00D7ACBC: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 140;//m1                
        // 0x00D7ACC0: MOV w1, w21                | W1 = ??? + 96 + 16;//m1                 
        // 0x00D7ACC4: BL #0xbafc80               | CameraShotHelper.instance.gameSpeedCtrl(speed:  val_83, from:  ??? + 96 + 136, wait:  val_124, to:  ??? + 96 + 140, id:  val_73);
        CameraShotHelper.instance.gameSpeedCtrl(speed:  val_83, from:  ??? + 96 + 136, wait:  val_124, to:  ??? + 96 + 140, id:  val_73);
        // 0x00D7ACC8: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_58:
        // 0x00D7ACCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        // 0x00D7ACD0: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_89 = mem[??? + 96];
        val_89 = ??? + 96;
        // 0x00D7ACD4: LDR w22, [x24, #0xa8]      | W22 = ??? + 96 + 168;                   
        val_88 = mem[??? + 96 + 168];
        val_88 = ??? + 96 + 168;
        // 0x00D7ACD8: CBZ x23, #0xd7b09c         | if (??? + 96 == 0) goto label_237;      
        if(val_89 == 0)
        {
            goto label_237;
        }
        // 0x00D7ACDC: MOV x24, x23               | X24 = ??? + 96;//m1                     
        val_87 = val_89;
        // 0x00D7ACE0: B #0xd7b0a8                |  goto label_238;                        
        goto label_238;
        label_76:
        // 0x00D7ACE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00D7ACE8: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        // 0x00D7ACEC: LDR w9, [x20, #0xd0]       | W9 = ??? + 96 + 208;                    
        // 0x00D7ACF0: MOV x20, x8                | X20 = ??? + 96;//m1                     
        val_91 = ??? + 96;
        // 0x00D7ACF4: STR w9, [x19, #0x4c]       | mem2[0] = ??? + 96 + 208;                //  dest_result_addr=0
        mem2[0] = ??? + 96 + 208;
        // 0x00D7ACF8: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if((??? + 96) == 0)
        {
            goto label_382;
        }
        label_77:
        // 0x00D7ACFC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
        // 0x00D7AD00: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
        // 0x00D7AD04: LDR s8, [x20, #0xd0]       | S8 = ??? + 96 + 208;                    
        val_83 = mem[??? + 96 + 208];
        val_83 = ??? + 96 + 208;
        // 0x00D7AD08: LDR x8, [x8, #0x1e0]       | X8 = 1152921515115525280;               
        // 0x00D7AD0C: LDR x9, [x9, #0xbe0]       | X9 = 1152921504687837184;               
        // 0x00D7AD10: LDR x21, [x8]              | X21 = System.Void CameraShotMgr::<Execute>m__0();
        val_73 = System.Void CameraShotMgr::<Execute>m__0();
        // 0x00D7AD14: LDR x0, [x9]               | X0 = typeof(System.Action);             
        System.Action val_50 = null;
        // 0x00D7AD18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Action), ????);
        // 0x00D7AD1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7AD20: MOV x1, x19                | X1 = X19;//m1                           
        // 0x00D7AD24: MOV x2, x21                | X2 = 1152921515115525280 (0x10000002725DB4A0);//ML01
        // 0x00D7AD28: MOV x20, x0                | X20 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D7AD2C: BL #0x26e30f0              | .ctor(object:  ???, method:  val_73);   
        val_50 = new System.Action(object:  ???, method:  val_73);
        // 0x00D7AD30: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D7AD34: LDR x8, [x8, #0x4b8]       | X8 = 1152921504922660864;               
        // 0x00D7AD38: LDR x0, [x8]               | X0 = typeof(BehaviourUtil);             
        // 0x00D7AD3C: LDRB w8, [x0, #0x10a]      | W8 = BehaviourUtil.__il2cppRuntimeField_10A;
        // 0x00D7AD40: TBZ w8, #0, #0xd7ad50      | if (BehaviourUtil.__il2cppRuntimeField_has_cctor == 0) goto label_241;
        // 0x00D7AD44: LDR w8, [x0, #0xbc]        | W8 = BehaviourUtil.__il2cppRuntimeField_cctor_finished;
        // 0x00D7AD48: CBNZ w8, #0xd7ad50         | if (BehaviourUtil.__il2cppRuntimeField_cctor_finished != 0) goto label_241;
        // 0x00D7AD4C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BehaviourUtil), ????);
        label_241:
        // 0x00D7AD50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AD54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D7AD58: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 208;//m1                
        // 0x00D7AD5C: MOV x1, x20                | X1 = 1152921504687837184 (0x1000000004D3D000);//ML01
        // 0x00D7AD60: BL #0xb8e194               | X0 = BehaviourUtil.DelayCall(delaytime:  val_83, act:  0);
        uint val_51 = BehaviourUtil.DelayCall(delaytime:  val_83, act:  0);
        // 0x00D7AD64: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_78:
        // 0x00D7AD68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00D7AD6C: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        val_93 = mem[??? + 96];
        val_93 = ??? + 96;
        // 0x00D7AD70: LDR w21, [x23, #0xb8]      | W21 = ??? + 96 + 184;                   
        val_73 = mem[??? + 96 + 184];
        val_73 = ??? + 96 + 184;
        // 0x00D7AD74: CBZ x22, #0xd7b124         | if (??? + 96 == 0) goto label_243;      
        if(val_93 == 0)
        {
            goto label_243;
        }
        // 0x00D7AD78: MOV x23, x22               | X23 = ??? + 96;//m1                     
        val_92 = val_93;
        // 0x00D7AD7C: B #0xd7b130                |  goto label_244;                        
        goto label_244;
        label_134:
        // 0x00D7AD80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AD84: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_108 = mem[??? + 96];
        val_108 = ??? + 96;
        // 0x00D7AD88: LDR w21, [x22, #0x138]     | W21 = ??? + 96 + 312;                   
        val_107 = mem[??? + 96 + 312];
        val_107 = ??? + 96 + 312;
        // 0x00D7AD8C: CBZ x23, #0xd7b244         | if (??? + 96 == 0) goto label_245;      
        if(val_108 == 0)
        {
            goto label_245;
        }
        // 0x00D7AD90: MOV x22, x23               | X22 = ??? + 96;//m1                     
        val_106 = val_108;
        // 0x00D7AD94: B #0xd7b250                |  goto label_246;                        
        goto label_246;
        label_183:
        // 0x00D7AD98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7AD9C: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        val_118 = mem[??? + 96];
        val_118 = ??? + 96;
        // 0x00D7ADA0: LDR w21, [x23, #0x90]      | W21 = ??? + 96 + 144;                   
        val_117 = mem[??? + 96 + 144];
        val_117 = ??? + 96 + 144;
        // 0x00D7ADA4: CBZ x22, #0xd7b27c         | if (??? + 96 == 0) goto label_247;      
        if(val_118 == 0)
        {
            goto label_247;
        }
        // 0x00D7ADA8: MOV x23, x22               | X23 = ??? + 96;//m1                     
        val_116 = val_118;
        // 0x00D7ADAC: B #0xd7b288                |  goto label_248;                        
        goto label_248;
        label_115:
        // 0x00D7ADB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7ADB4: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        val_100 = mem[??? + 96];
        val_100 = ??? + 96;
        // 0x00D7ADB8: LDR w21, [x23, #0xe8]      | W21 = ??? + 96 + 232;                   
        val_99 = mem[??? + 96 + 232];
        val_99 = ??? + 96 + 232;
        // 0x00D7ADBC: CBZ x22, #0xd7b420         | if (??? + 96 == 0) goto label_249;      
        if(val_100 == 0)
        {
            goto label_249;
        }
        // 0x00D7ADC0: MOV x23, x22               | X23 = ??? + 96;//m1                     
        val_98 = val_100;
        // 0x00D7ADC4: B #0xd7b42c                |  goto label_250;                        
        goto label_250;
        label_199:
        // 0x00D7ADC8: ADRP x20, #0x3642000       | X20 = 56893440 (0x3642000);             
        // 0x00D7ADCC: LDR x20, [x20, #0x8b0]     | X20 = 1152921504887996416;              
        // 0x00D7ADD0: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_134 = null;
        // 0x00D7ADD4: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7ADD8: TBZ w8, #0, #0xd7adec      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_252;
        // 0x00D7ADDC: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7ADE0: CBNZ w8, #0xd7adec         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_252;
        // 0x00D7ADE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7ADE8: LDR x0, [x20]              | X0 = typeof(CameraShotHelper);          
        val_134 = null;
        label_252:
        // 0x00D7ADEC: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7ADF0: LDR x21, [x8]              | X21 = CameraShotHelper.instance;        
        // 0x00D7ADF4: CBNZ x21, #0xd7adfc        | if (CameraShotHelper.instance != null) goto label_253;
        if(CameraShotHelper.instance != null)
        {
            goto label_253;
        }
        // 0x00D7ADF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_253:
        // 0x00D7ADFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7AE00: STRB w8, [x21, #0x20]      | CameraShotHelper.instance.IsOpeningMoveUpdate = true;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = true;
        // 0x00D7AE04: LDR x8, [x20]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7AE08: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7AE0C: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7AE10: CBNZ x20, #0xd7ae18        | if (CameraShotHelper.instance != null) goto label_254;
        if(CameraShotHelper.instance != null)
        {
            goto label_254;
        }
        // 0x00D7AE14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_254:
        // 0x00D7AE18: STRB wzr, [x20, #0x22]     | CameraShotHelper.instance.isCircleCameraMoving = false;  //  dest_result_addr=0
        CameraShotHelper.instance.isCircleCameraMoving = false;
        label_94:
        // 0x00D7AE1C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AE20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AE24: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_52 = UnityEngine.Camera.main;
        // 0x00D7AE28: MOV x20, x0                | X20 = val_52;//m1                       
        // 0x00D7AE2C: CBNZ x20, #0xd7ae34        | if (val_52 != null) goto label_255;     
        if(val_52 != null)
        {
            goto label_255;
        }
        // 0x00D7AE30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
        label_255:
        // 0x00D7AE34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AE38: MOV x0, x20                | X0 = val_52;//m1                        
        // 0x00D7AE3C: BL #0x20d5094              | X0 = val_52.get_transform();            
        UnityEngine.Transform val_53 = val_52.transform;
        // 0x00D7AE40: MOV x20, x0                | X20 = val_53;//m1                       
        // 0x00D7AE44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AE48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AE4C: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_54 = HeroMgr.instance;
        // 0x00D7AE50: MOV x21, x0                | X21 = val_54;//m1                       
        // 0x00D7AE54: CBNZ x21, #0xd7ae5c        | if (val_54 != null) goto label_256;     
        if(val_54 != null)
        {
            goto label_256;
        }
        // 0x00D7AE58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_54, ????);     
        label_256:
        // 0x00D7AE5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AE60: MOV x0, x21                | X0 = val_54;//m1                        
        // 0x00D7AE64: BL #0x28964e8              | X0 = val_54.get_CameraSmoothFollow();   
        CameraSmoothFollow val_55 = val_54.CameraSmoothFollow;
        // 0x00D7AE68: MOV x21, x0                | X21 = val_55;//m1                       
        // 0x00D7AE6C: CBNZ x21, #0xd7ae74        | if (val_55 != null) goto label_257;     
        if(val_55 != null)
        {
            goto label_257;
        }
        // 0x00D7AE70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_257:
        // 0x00D7AE74: LDR s8, [x21, #0xa0]       | S8 = val_55.lastPos; //P2               
        // 0x00D7AE78: LDR s9, [x21, #0xa4]       | 
        // 0x00D7AE7C: LDR s10, [x21, #0xa8]      | 
        // 0x00D7AE80: CBNZ x20, #0xd7ae88        | if (val_53 != null) goto label_258;     
        if(val_53 != null)
        {
            goto label_258;
        }
        // 0x00D7AE84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_55, ????);     
        label_258:
        // 0x00D7AE88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AE8C: MOV x0, x20                | X0 = val_53;//m1                        
        // 0x00D7AE90: MOV v0.16b, v8.16b         | V0 = val_55.lastPos;//m1                
        // 0x00D7AE94: MOV v1.16b, v9.16b         | V1 = V9;//m1                            
        // 0x00D7AE98: MOV v2.16b, v10.16b        | V2 = V10;//m1                           
        // 0x00D7AE9C: BL #0x26935b8              | val_53.set_position(value:  new UnityEngine.Vector3() {x = val_55.lastPos, y = ???, z = ???});
        val_53.position = new UnityEngine.Vector3() {x = val_55.lastPos, y = ???, z = ???};
        // 0x00D7AEA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AEA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AEA8: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_56 = UnityEngine.Camera.main;
        // 0x00D7AEAC: MOV x20, x0                | X20 = val_56;//m1                       
        // 0x00D7AEB0: CBNZ x20, #0xd7aeb8        | if (val_56 != null) goto label_259;     
        if(val_56 != null)
        {
            goto label_259;
        }
        // 0x00D7AEB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
        label_259:
        // 0x00D7AEB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AEBC: MOV x0, x20                | X0 = val_56;//m1                        
        // 0x00D7AEC0: BL #0x20d5094              | X0 = val_56.get_transform();            
        UnityEngine.Transform val_57 = val_56.transform;
        // 0x00D7AEC4: MOV x20, x0                | X20 = val_57;//m1                       
        // 0x00D7AEC8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7AECC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AED0: BL #0x287ee80              | X0 = HeroMgr.get_instance();            
        HeroMgr val_58 = HeroMgr.instance;
        // 0x00D7AED4: MOV x21, x0                | X21 = val_58;//m1                       
        // 0x00D7AED8: CBNZ x21, #0xd7aee0        | if (val_58 != null) goto label_260;     
        if(val_58 != null)
        {
            goto label_260;
        }
        // 0x00D7AEDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_58, ????);     
        label_260:
        // 0x00D7AEE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AEE4: MOV x0, x21                | X0 = val_58;//m1                        
        // 0x00D7AEE8: BL #0x28964e8              | X0 = val_58.get_CameraSmoothFollow();   
        CameraSmoothFollow val_59 = val_58.CameraSmoothFollow;
        // 0x00D7AEEC: MOV x21, x0                | X21 = val_59;//m1                       
        val_73 = val_59;
        // 0x00D7AEF0: CBNZ x21, #0xd7aef8        | if (val_59 != null) goto label_261;     
        if(val_73 != null)
        {
            goto label_261;
        }
        // 0x00D7AEF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
        label_261:
        // 0x00D7AEF8: LDR s8, [x21, #0x90]       | S8 = val_59.lastRotation; //P2          
        val_83 = val_59.lastRotation;
        // 0x00D7AEFC: LDR s9, [x21, #0x94]       | 
        // 0x00D7AF00: LDR s10, [x21, #0x98]      | 
        // 0x00D7AF04: LDR s11, [x21, #0x9c]      | 
        // 0x00D7AF08: CBNZ x20, #0xd7af10        | if (val_57 != null) goto label_262;     
        if(val_57 != null)
        {
            goto label_262;
        }
        // 0x00D7AF0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
        label_262:
        // 0x00D7AF10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7AF14: MOV x0, x20                | X0 = val_57;//m1                        
        // 0x00D7AF18: MOV v0.16b, v8.16b         | V0 = val_59.lastRotation;//m1           
        // 0x00D7AF1C: MOV v1.16b, v9.16b         | V1 = V9;//m1                            
        // 0x00D7AF20: MOV v2.16b, v10.16b        | V2 = V10;//m1                           
        // 0x00D7AF24: MOV v3.16b, v11.16b        | V3 = V11;//m1                           
        // 0x00D7AF28: BL #0x26938b0              | val_57.set_rotation(value:  new UnityEngine.Quaternion() {x = val_83, y = ???, z = ???, w = ???});
        val_57.rotation = new UnityEngine.Quaternion() {x = val_83, y = ???, z = ???, w = ???};
        // 0x00D7AF2C: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_130:
        // 0x00D7AF30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        // 0x00D7AF34: LDR x26, [x19, #0x60]      | X26 = ??? + 96;                         
        val_104 = mem[??? + 96];
        val_104 = ??? + 96;
        // 0x00D7AF38: LDR w24, [x25, #0x118]     | W24 = ??? + 96 + 280;                   
        val_103 = mem[??? + 96 + 280];
        val_103 = ??? + 96 + 280;
        // 0x00D7AF3C: CBZ x26, #0xd7b4f0         | if (??? + 96 == 0) goto label_264;      
        if(val_104 == 0)
        {
            goto label_264;
        }
        // 0x00D7AF40: MOV x25, x26               | X25 = ??? + 96;//m1                     
        val_102 = val_104;
        // 0x00D7AF44: B #0xd7b4fc                |  goto label_265;                        
        goto label_265;
        label_158:
        // 0x00D7AF48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        // 0x00D7AF4C: LDR x26, [x19, #0x60]      | X26 = ??? + 96;                         
        // 0x00D7AF50: LDR w24, [x25, #0x118]     | W24 = ??? + 96 + 280;                   
        val_111 = mem[??? + 96 + 280];
        val_111 = ??? + 96 + 280;
        // 0x00D7AF54: CBZ x26, #0xd7b5e0         | if (??? + 96 == 0) goto label_266;      
        if((??? + 96) == 0)
        {
            goto label_266;
        }
        // 0x00D7AF58: MOV x25, x26               | X25 = ??? + 96;//m1                     
        val_110 = ??? + 96;
        label_159:
        // 0x00D7AF5C: LDR s8, [x25, #0x134]      | S8 = ??? + 96 + 308;                    
        val_83 = mem[??? + 96 + 308];
        val_83 = ??? + 96 + 308;
        // 0x00D7AF60: MOV x21, x27               | X21 = X27;//m1                          
        val_73 = ???;
        label_347:
        // 0x00D7AF64: MOV x26, x25               | X26 = ??? + 96;//m1                     
        label_348:
        // 0x00D7AF68: LDR w27, [x25, #0x13c]     | W27 = ??? + 96 + 316;                   
        // 0x00D7AF6C: LDR s9, [x26, #0x11c]      | S9 = ??? + 96 + 284;                    
        // 0x00D7AF70: LDR s10, [x26, #0x120]     | S10 = ??? + 96 + 288;                   
        val_124 = mem[??? + 96 + 288];
        val_124 = ??? + 96 + 288;
        // 0x00D7AF74: LDR s11, [x26, #0x124]     | S11 = ??? + 96 + 292;                   
        // 0x00D7AF78: MOV x8, x26                | X8 = ??? + 96;//m1                      
        val_135 = val_110;
        // 0x00D7AF7C: CBNZ x26, #0xd7af8c        | if (??? + 96 != 0) goto label_267;      
        if(val_110 != 0)
        {
            goto label_267;
        }
        // 0x00D7AF80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        // 0x00D7AF84: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_135 = mem[??? + 96];
        val_135 = ??? + 96;
        // 0x00D7AF88: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_135 == 0)
        {
            goto label_382;
        }
        label_267:
        // 0x00D7AF8C: LDR w25, [x26, #0x140]     | W25 = ??? + 96 + 320;                   
        val_74 = mem[??? + 96 + 320];
        val_74 = ??? + 96 + 320;
        // 0x00D7AF90: LDR w26, [x8, #0xa8]       | W26 = ??? + 96 + 168;                   
        // 0x00D7AF94: CBNZ x23, #0xd7af9c        | if (val_39 != null) goto label_269;     
        if(val_39 != null)
        {
            goto label_269;
        }
        // 0x00D7AF98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_269:
        // 0x00D7AF9C: LDR x3, [sp, #0x60]        | X3 = val_28;                            
        // 0x00D7AFA0: CMP w27, #1                | STATE = COMPARE(??? + 96 + 316, 0x1)    
        // 0x00D7AFA4: MOV x0, x23                | X0 = val_39;//m1                        
        // 0x00D7AFA8: MOV x23, x20               | X23 = val_31;//m1                       
        val_72 = val_31;
        // 0x00D7AFAC: CSET w5, eq                | W5 = ??? + 96 + 316 == 0x1 ? 1 : 0;     
        bool val_60 = ((??? + 96 + 316) == 1) ? 1 : 0;
        // 0x00D7AFB0: MOV w1, w24                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7AFB4: MOV x2, x23                | X2 = val_31;//m1                        
        // 0x00D7AFB8: MOV x4, x22                | X4 = val_29;//m1                        
        // 0x00D7AFBC: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 308;//m1                
        // 0x00D7AFC0: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 284;//m1                
        // 0x00D7AFC4: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 288;//m1                
        // 0x00D7AFC8: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 292;//m1                
        // 0x00D7AFCC: MOV w6, w25                | W6 = ??? + 96 + 320;//m1                
        // 0x00D7AFD0: MOV w7, w26                | W7 = ??? + 96 + 168;//m1                
        // 0x00D7AFD4: STR xzr, [sp]              | stack[1152921515115947904] = 0x0;        //  dest_result_addr=1152921515115947904
        // 0x00D7AFD8: BL #0xb630a8               | val_39.PlayCameraShotShoot(id:  val_111, obj:  val_72, srcEntity:  val_28, targetTf:  val_29, speed:  val_83, isatk:  bool val_60 = ((??? + 96 + 316) == 1) ? 1 : 0, targetPosition:  new UnityEngine.Vector3() {x = ??? + 96 + 284, y = val_124, z = ??? + 96 + 292}, tag:  val_74, skillID:  ??? + 96 + 168);
        val_39.PlayCameraShotShoot(id:  val_111, obj:  val_72, srcEntity:  val_28, targetTf:  val_29, speed:  val_83, isatk:  val_60, targetPosition:  new UnityEngine.Vector3() {x = ??? + 96 + 284, y = val_124, z = ??? + 96 + 292}, tag:  val_74, skillID:  ??? + 96 + 168);
        // 0x00D7AFDC: LDR x20, [x19, #0x78]      | X20 = ??? + 120;                        
        // 0x00D7AFE0: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7AFE4: CBNZ x22, #0xd7afec        | if (??? + 96 != 0) goto label_270;      
        if((??? + 96) != 0)
        {
            goto label_270;
        }
        // 0x00D7AFE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_270:
        // 0x00D7AFEC: LDR w22, [x22, #0x118]     | W22 = ??? + 96 + 280;                   
        // 0x00D7AFF0: MOV x27, x21               | X27 = X21;//m1                          
        val_71 = val_73;
        // 0x00D7AFF4: CBNZ x20, #0xd7affc        | if (??? + 120 != 0) goto label_271;     
        if((??? + 120) != 0)
        {
            goto label_271;
        }
        // 0x00D7AFF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        label_271:
        // 0x00D7AFFC: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7B000: LDR x8, [x8, #0x898]       | X8 = 1152921510772421328;               
        // 0x00D7B004: MOV x0, x20                | X0 = ??? + 120;//m1                     
        // 0x00D7B008: MOV w1, w22                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7B00C: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::ContainsKey(System.Int32 key);
        // 0x00D7B010: BL #0x2415bdc              | X0 = ??? + 120.ContainsKey(key:  ??? + 96 + 280);
        bool val_61 = ??? + 120.ContainsKey(key:  ??? + 96 + 280);
        // 0x00D7B014: AND w8, w0, #1             | W8 = (val_61 & 1);                      
        bool val_62 = val_61;
        // 0x00D7B018: TBNZ w8, #0, #0xd7b158     | if ((val_61 & 1) == true) goto label_346;
        if(val_62 == true)
        {
            goto label_346;
        }
        // 0x00D7B01C: LDR x20, [x19, #0x78]      | X20 = ??? + 120;                        
        // 0x00D7B020: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B024: CBNZ x22, #0xd7b02c        | if (??? + 96 != 0) goto label_273;      
        if((??? + 96) != 0)
        {
            goto label_273;
        }
        // 0x00D7B028: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        label_273:
        // 0x00D7B02C: LDR w22, [x22, #0x118]     | W22 = ??? + 96 + 280;                   
        // 0x00D7B030: CBNZ x20, #0xd7b038        | if (??? + 120 != 0) goto label_274;     
        if((??? + 120) != 0)
        {
            goto label_274;
        }
        // 0x00D7B034: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
        label_274:
        // 0x00D7B038: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D7B03C: LDR x8, [x8, #0x710]       | X8 = 1152921510773326416;               
        // 0x00D7B040: MOV x0, x20                | X0 = ??? + 120;//m1                     
        // 0x00D7B044: MOV w1, w22                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7B048: MOV x2, x23                | X2 = val_31;//m1                        
        // 0x00D7B04C: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::set_Item(System.Int32 key, UnityEngine.GameObject value);
        // 0x00D7B050: BL #0x24147b0              | ??? + 120.set_Item(key:  ??? + 96 + 280, value:  val_72);
        ??? + 120.set_Item(key:  ??? + 96 + 280, value:  val_72);
        // 0x00D7B054: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_231:
        // 0x00D7B058: STR x1, [sp, #0x60]        | stack[1152921515115947712] = this.curCameraShot.paths;  //  dest_result_addr=1152921515115947712
        // 0x00D7B05C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B060: LDR x21, [x19, #0x60]      | X21 = this.curCameraShot; //P2          
        // 0x00D7B064: LDR x26, [x22, #0x28]      | X26 = this.curCameraShot.rotations; //P2 
        // 0x00D7B068: CBZ x21, #0xd7b604         | if (this.curCameraShot == null) goto label_276;
        if(this.curCameraShot == null)
        {
            goto label_276;
        }
        // 0x00D7B06C: LDR x1, [sp, #0x60]        | X1 = this.curCameraShot.paths;          
        // 0x00D7B070: B #0xd7abac                |  goto label_277;                        
        goto label_277;
        label_234:
        // 0x00D7B074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B078: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7B07C: LDR s9, [x22, #0x88]       | S9 = ??? + 96 + 136;                    
        // 0x00D7B080: CBNZ x21, #0xd7ac90        | if (??? + 96 != 0) goto label_278;      
        if((??? + 96) != 0)
        {
            goto label_278;
        }
        // 0x00D7B084: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B088: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B08C: LDR s10, [x21, #0xd0]      | S10 = ??? + 96 + 208;                   
        // 0x00D7B090: CBZ x22, #0xd7b694         | if (??? + 96 == 0) goto label_279;      
        if((??? + 96) == 0)
        {
            goto label_279;
        }
        // 0x00D7B094: MOV x21, x22               | X21 = ??? + 96;//m1                     
        // 0x00D7B098: B #0xd7ac98                |  goto label_357;                        
        goto label_357;
        label_237:
        // 0x00D7B09C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        // 0x00D7B0A0: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        val_87 = mem[??? + 96];
        val_87 = ??? + 96;
        // 0x00D7B0A4: CBZ x24, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_87 == 0)
        {
            goto label_382;
        }
        label_238:
        // 0x00D7B0A8: LDR w23, [x23, #0x12c]     | W23 = ??? + 96 + 300;                   
        val_72 = mem[??? + 96 + 300];
        val_72 = ??? + 96 + 300;
        // 0x00D7B0AC: LDR w24, [x24, #0x118]     | W24 = ??? + 96 + 280;                   
        // 0x00D7B0B0: CBNZ x21, #0xd7b0b8        | if (val_13.<fightCtrl>k__BackingField != null) goto label_282;
        if((val_13.<fightCtrl>k__BackingField) != null)
        {
            goto label_282;
        }
        // 0x00D7B0B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_282:
        // 0x00D7B0B8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00D7B0BC: MOV x0, x21                | X0 = val_13.<fightCtrl>k__BackingField;//m1
        // 0x00D7B0C0: MOV w1, w22                | W1 = ??? + 96 + 168;//m1                
        // 0x00D7B0C4: MOV w2, w23                | W2 = ??? + 96 + 300;//m1                
        // 0x00D7B0C8: MOV w3, w24                | W3 = ??? + 96 + 280;//m1                
        // 0x00D7B0CC: BL #0xed0608               | val_13.<fightCtrl>k__BackingField.ForceUsingSkill(skillId:  val_88, hostId:  val_72, effectId:  ??? + 96 + 280);
        val_13.<fightCtrl>k__BackingField.ForceUsingSkill(skillId:  val_88, hostId:  val_72, effectId:  ??? + 96 + 280);
        // 0x00D7B0D0: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        val_73 = mem[??? + 96];
        val_73 = ??? + 96;
        // 0x00D7B0D4: CBZ x21, #0xd7b0e4         | if (??? + 96 == 0) goto label_283;      
        if(val_73 == 0)
        {
            goto label_283;
        }
        // 0x00D7B0D8: LDR w8, [x21, #0xa8]       | W8 = ??? + 96 + 168;                    
        // 0x00D7B0DC: STR w8, [x19, #0x50]       | mem2[0] = ??? + 96 + 168;                //  dest_result_addr=0
        mem2[0] = ??? + 96 + 168;
        // 0x00D7B0E0: B #0xd7b0fc                |  goto label_284;                        
        goto label_284;
        label_283:
        // 0x00D7B0E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13.<fightCtrl>k__BackingField, ????);
        // 0x00D7B0E8: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        // 0x00D7B0EC: LDR w9, [x21, #0xa8]       | W9 = ??? + 96 + 168;                    
        // 0x00D7B0F0: MOV x21, x8                | X21 = ??? + 96;//m1                     
        val_73 = ??? + 96;
        // 0x00D7B0F4: STR w9, [x19, #0x50]       | mem2[0] = ??? + 96 + 168;                //  dest_result_addr=0
        mem2[0] = ??? + 96 + 168;
        // 0x00D7B0F8: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if((??? + 96) == 0)
        {
            goto label_382;
        }
        label_284:
        // 0x00D7B0FC: LDR w8, [x21, #0x118]      | W8 = ??? + 96 + 280;                    
        // 0x00D7B100: CMN w8, #1                 | STATE = COMPARE(??? + 96 + 280, 0x1)    
        // 0x00D7B104: B.EQ #0xd7b158             | if (??? + 96 + 280 == 0x1) goto label_346;
        if((??? + 96 + 280) == 1)
        {
            goto label_346;
        }
        // 0x00D7B108: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        val_73 = mem[??? + 96];
        val_73 = ??? + 96;
        // 0x00D7B10C: STR x20, [x19, #0x38]      | mem2[0] = val_13;                        //  dest_result_addr=0
        mem2[0] = val_13;
        // 0x00D7B110: CBNZ x21, #0xd7b118        | if (??? + 96 != 0) goto label_287;      
        if(val_73 != 0)
        {
            goto label_287;
        }
        // 0x00D7B114: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13.<fightCtrl>k__BackingField, ????);
        label_287:
        // 0x00D7B118: LDR w8, [x21, #0x118]      | W8 = ??? + 96 + 280;                    
        // 0x00D7B11C: STR w8, [x19, #0x40]       | mem2[0] = ??? + 96 + 280;                //  dest_result_addr=0
        mem2[0] = ??? + 96 + 280;
        // 0x00D7B120: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_243:
        // 0x00D7B124: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        // 0x00D7B128: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_92 = mem[??? + 96];
        val_92 = ??? + 96;
        // 0x00D7B12C: CBZ x23, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_92 == 0)
        {
            goto label_382;
        }
        label_244:
        // 0x00D7B130: LDR w22, [x22, #0xbc]      | W22 = ??? + 96 + 188;                   
        // 0x00D7B134: LDR w23, [x23, #0xc0]      | W23 = ??? + 96 + 192;                   
        val_72 = mem[??? + 96 + 192];
        val_72 = ??? + 96 + 192;
        // 0x00D7B138: CBNZ x20, #0xd7b140        | if (val_17 != null) goto label_290;     
        if(val_17 != null)
        {
            goto label_290;
        }
        // 0x00D7B13C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_290:
        // 0x00D7B140: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00D7B144: MOV x0, x20                | X0 = val_17;//m1                        
        // 0x00D7B148: MOV w1, w21                | W1 = ??? + 96 + 184;//m1                
        // 0x00D7B14C: MOV w2, w22                | W2 = ??? + 96 + 188;//m1                
        // 0x00D7B150: MOV w3, w23                | W3 = ??? + 96 + 192;//m1                
        // 0x00D7B154: BL #0xd13c70               | val_17.CreateAniShowNpcList(type:  val_73, roundIndex:  ??? + 96 + 188, npcId:  val_72);
        val_17.CreateAniShowNpcList(type:  val_73, roundIndex:  ??? + 96 + 188, npcId:  val_72);
        label_346:
        // 0x00D7B158: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7B15C: CBNZ x20, #0xd7b164        | if (??? + 96 != 0) goto label_291;      
        if((??? + 96) != 0)
        {
            goto label_291;
        }
        // 0x00D7B160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_291:
        // 0x00D7B164: LDR w1, [x20, #0x10]       | W1 = ??? + 96 + 16;                     
        // 0x00D7B168: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00D7B16C: BL #0xd7c4fc               | OnComplete(a:  ??? + 96 + 16);          
        ???.OnComplete(a:  ??? + 96 + 16);
        label_368:
        // 0x00D7B170: LDR x20, [x19, #0x60]      | X20 = ??? + 96;                         
        // 0x00D7B174: CBNZ x20, #0xd7b17c        | if (??? + 96 != 0) goto label_292;      
        if((??? + 96) != 0)
        {
            goto label_292;
        }
        // 0x00D7B178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_292:
        // 0x00D7B17C: LDR w8, [x20, #0x18]       | W8 = ??? + 96 + 24;                     
        // 0x00D7B180: CMP w8, #1                 | STATE = COMPARE(??? + 96 + 24, 0x1)     
        // 0x00D7B184: B.NE #0xd7b214             | if (??? + 96 + 24 != 0x1) goto label_293;
        if((??? + 96 + 24) != 1)
        {
            goto label_293;
        }
        // 0x00D7B188: LDR x20, [x19, #0x70]      | X20 = ??? + 112;                        
        val_136 = mem[??? + 112];
        val_136 = ??? + 112;
        // 0x00D7B18C: CBNZ x20, #0xd7b194        | if (??? + 112 != 0) goto label_294;     
        if(val_136 != 0)
        {
            goto label_294;
        }
        // 0x00D7B190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? , ????);           
        label_294:
        // 0x00D7B194: LDR x1, [x28]              | X1 = ;                                  
        // 0x00D7B198: MOV x0, x20                | X0 = ??? + 112;//m1                     
        // 0x00D7B19C: BL #0x25ed72c              | X0 = ??? + 112.get_Count();             
        int val_63 = val_136.Count;
        // 0x00D7B1A0: CBNZ w0, #0xd7b1cc         | if (val_63 != 0) goto label_295;        
        if(val_63 != 0)
        {
            goto label_295;
        }
        // 0x00D7B1A4: LDR x20, [x19, #0x70]      | X20 = ??? + 112;                        
        val_136 = mem[??? + 112];
        val_136 = ??? + 112;
        // 0x00D7B1A8: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7B1AC: CBNZ x20, #0xd7b1b4        | if (??? + 112 != 0) goto label_296;     
        if(val_136 != 0)
        {
            goto label_296;
        }
        // 0x00D7B1B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
        label_296:
        // 0x00D7B1B4: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D7B1B8: LDR x8, [x8, #0xc20]       | X8 = 1152921515111268832;               
        // 0x00D7B1BC: MOV x0, x20                | X0 = ??? + 112;//m1                     
        // 0x00D7B1C0: MOV x1, x21                | X1 = ??? + 96;//m1                      
        // 0x00D7B1C4: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<CameraShotVO>::Add(CameraShotVO item);
        // 0x00D7B1C8: BL #0x25ea480              | ??? + 112.Add(item:  ??? + 96);         
        val_136.Add(item:  ??? + 96);
        label_295:
        // 0x00D7B1CC: LDP x21, x20, [x19, #0x68] | X21 = ??? + 104; X20 = ??? + 104 + 8;    //  | 
        // 0x00D7B1D0: CBNZ x21, #0xd7b1d8        | if (??? + 104 != 0) goto label_297;     
        if((??? + 104) != 0)
        {
            goto label_297;
        }
        // 0x00D7B1D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ??? + 112, ????);  
        label_297:
        // 0x00D7B1D8: LDR x2, [x27]              | X2 = ;                                  
        // 0x00D7B1DC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00D7B1E0: MOV x0, x21                | X0 = ??? + 104;//m1                     
        // 0x00D7B1E4: BL #0x25ed734              | X0 = ??? + 104.get_Item(index:  0);     
        UnityEngine.EventSystems.IEventSystemHandler val_64 = ??? + 104.Item[0];
        // 0x00D7B1E8: MOV x21, x0                | X21 = val_64;//m1                       
        val_73 = val_64;
        // 0x00D7B1EC: CBNZ x20, #0xd7b1f4        | if (??? + 104 + 8 != 0) goto label_298; 
        if((??? + 104 + 8) != 0)
        {
            goto label_298;
        }
        // 0x00D7B1F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_64, ????);     
        label_298:
        // 0x00D7B1F4: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D7B1F8: LDR x8, [x8, #0xc20]       | X8 = 1152921515111268832;               
        // 0x00D7B1FC: MOV x0, x20                | X0 = ??? + 104 + 8;//m1                 
        // 0x00D7B200: MOV x1, x21                | X1 = val_64;//m1                        
        // 0x00D7B204: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<CameraShotVO>::Add(CameraShotVO item);
        // 0x00D7B208: BL #0x25ea480              | ??? + 104 + 8.Add(item:  val_73);       
        ??? + 104 + 8.Add(item:  val_73);
        // 0x00D7B20C: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00D7B210: BL #0xd79714               |  R0 = label_299();                      
        label_293:
        // 0x00D7B214: SUB sp, x29, #0x90         | SP = (??? - 144);                       
        var val_65 = (???) - 144;
        // 0x00D7B218: LDP x29, x30, [sp, #0x90]  | X29 = (??? - 144) + 144; X30 = (??? - 144) + 144 + 8; //  | 
        // 0x00D7B21C: LDP x20, x19, [sp, #0x80]  | X20 = (??? - 144) + 128; X19 = (??? - 144) + 128 + 8; //  | 
        // 0x00D7B220: LDP x22, x21, [sp, #0x70]  | X22 = (??? - 144) + 112; X21 = (??? - 144) + 112 + 8; //  | 
        // 0x00D7B224: LDP x24, x23, [sp, #0x60]  | X24 = (??? - 144) + 96; X23 = (??? - 144) + 96 + 8; //  | 
        // 0x00D7B228: LDP x26, x25, [sp, #0x50]  | X26 = (??? - 144) + 80; X25 = (??? - 144) + 80 + 8; //  | 
        // 0x00D7B22C: LDP x28, x27, [sp, #0x40]  | X28 = (??? - 144) + 64; X27 = (??? - 144) + 64 + 8; //  | 
        // 0x00D7B230: LDP d9, d8, [sp, #0x30]    | D9 = (??? - 144) + 48; D8 = (??? - 144) + 48 + 8; //  | 
        // 0x00D7B234: LDP d11, d10, [sp, #0x20]  | D11 = (??? - 144) + 32; D10 = (??? - 144) + 32 + 8; //  | 
        // 0x00D7B238: LDP d13, d12, [sp, #0x10]  | D13 = (??? - 144) + 16; D12 = (??? - 144) + 16 + 8; //  | 
        // 0x00D7B23C: LDP d15, d14, [sp], #0xa0  | D15 = (??? - 144); D14 = (??? - 144) + 8; //  | 
        // 0x00D7B240: RET                        |  return;                                
        return;
        label_245:
        // 0x00D7B244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B248: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        val_106 = mem[??? + 96];
        val_106 = ??? + 96;
        // 0x00D7B24C: CBZ x22, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_106 == 0)
        {
            goto label_382;
        }
        label_246:
        // 0x00D7B250: LDR s8, [x23, #0xd0]       | S8 = ??? + 96 + 208;                    
        // 0x00D7B254: LDR w22, [x22, #0x10]      | W22 = ??? + 96 + 16;                    
        // 0x00D7B258: CBNZ x20, #0xd7b260        | if (CameraShotHelper.instance != null) goto label_301;
        if(CameraShotHelper.instance != null)
        {
            goto label_301;
        }
        // 0x00D7B25C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_301:
        // 0x00D7B260: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7B264: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7B268: MOV w1, w21                | W1 = ??? + 96 + 312;//m1                
        // 0x00D7B26C: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 208;//m1                
        // 0x00D7B270: MOV w2, w22                | W2 = ??? + 96 + 16;//m1                 
        // 0x00D7B274: BL #0xbafc98               | CameraShotHelper.instance.brightChange(brightId:  val_107, time:  ??? + 96 + 208, curCameraShotId:  ??? + 96 + 16);
        CameraShotHelper.instance.brightChange(brightId:  val_107, time:  ??? + 96 + 208, curCameraShotId:  ??? + 96 + 16);
        // 0x00D7B278: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_247:
        // 0x00D7B27C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B280: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_116 = mem[??? + 96];
        val_116 = ??? + 96;
        // 0x00D7B284: CBZ x23, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_116 == 0)
        {
            goto label_382;
        }
        label_248:
        // 0x00D7B288: LDR w22, [x22, #0x94]      | W22 = ??? + 96 + 148;                   
        // 0x00D7B28C: LDP s8, s9, [x23, #0xac]   | S8 = ??? + 96 + 172; S9 = ??? + 96 + 172 + 4; //  | 
        // 0x00D7B290: LDR s10, [x23, #0xb4]      | S10 = ??? + 96 + 180;                   
        // 0x00D7B294: CBZ x23, #0xd7b2a0         | if (??? + 96 == 0) goto label_304;      
        if(val_116 == 0)
        {
            goto label_304;
        }
        // 0x00D7B298: LDR s11, [x23, #0x158]     | S11 = ??? + 96 + 344;                   
        val_137 = mem[??? + 96 + 344];
        val_137 = ??? + 96 + 344;
        // 0x00D7B29C: B #0xd7b2b4                |  goto label_305;                        
        goto label_305;
        label_304:
        // 0x00D7B2A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B2A4: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        // 0x00D7B2A8: LDR s11, [x23, #0x158]     | S11 = ??? + 96 + 344;                   
        val_137 = mem[??? + 96 + 344];
        val_137 = ??? + 96 + 344;
        // 0x00D7B2AC: CBZ x24, #0xd7b300         | if (??? + 96 == 0) goto label_306;      
        if((??? + 96) == 0)
        {
            goto label_306;
        }
        // 0x00D7B2B0: MOV x23, x24               | X23 = ??? + 96;//m1                     
        val_116 = ??? + 96;
        label_305:
        // 0x00D7B2B4: LDR s12, [x23, #0x15c]     | S12 = ??? + 96 + 348;                   
        label_309:
        // 0x00D7B2B8: MOV x8, x23                | X8 = ??? + 96;//m1                      
        label_310:
        // 0x00D7B2BC: LDR w23, [x23, #0x160]     | W23 = ??? + 96 + 352;                   
        // 0x00D7B2C0: LDR w24, [x8, #0x10]       | W24 = ??? + 96 + 16;                    
        // 0x00D7B2C4: CBNZ x20, #0xd7b2cc        | if (CameraShotHelper.instance != null) goto label_307;
        if(CameraShotHelper.instance != null)
        {
            goto label_307;
        }
        // 0x00D7B2C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_307:
        // 0x00D7B2CC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00D7B2D0: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7B2D4: MOV w1, w21                | W1 = ??? + 96 + 144;//m1                
        // 0x00D7B2D8: MOV w2, w22                | W2 = ??? + 96 + 148;//m1                
        // 0x00D7B2DC: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 172;//m1                
        // 0x00D7B2E0: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 172 + 4;//m1            
        // 0x00D7B2E4: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 180;//m1                
        // 0x00D7B2E8: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 344;//m1                
        // 0x00D7B2EC: MOV v4.16b, v12.16b        | V4 = ??? + 96 + 348;//m1                
        // 0x00D7B2F0: MOV w3, w23                | W3 = ??? + 96 + 352;//m1                
        // 0x00D7B2F4: MOV w4, w24                | W4 = ??? + 96 + 16;//m1                 
        // 0x00D7B2F8: BL #0xbaf7c0               | CameraShotHelper.instance.lineMoveCtrl(targetId:  val_117, isHero:  ??? + 96 + 148, targetPos:  new UnityEngine.Vector3() {x = ??? + 96 + 172, y = ??? + 96 + 172 + 4, z = ??? + 96 + 180}, stopDis:  val_137, time:  ??? + 96 + 348, isDamp:  ??? + 96 + 352, curCameraShotId:  ??? + 96 + 16);
        CameraShotHelper.instance.lineMoveCtrl(targetId:  val_117, isHero:  ??? + 96 + 148, targetPos:  new UnityEngine.Vector3() {x = ??? + 96 + 172, y = ??? + 96 + 172 + 4, z = ??? + 96 + 180}, stopDis:  val_137, time:  ??? + 96 + 348, isDamp:  ??? + 96 + 352, curCameraShotId:  ??? + 96 + 16);
        // 0x00D7B2FC: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_306:
        // 0x00D7B300: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B304: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7B308: LDR s12, [x24, #0x15c]     | S12 = ??? + 96 + 348;                   
        // 0x00D7B30C: CBNZ x23, #0xd7b2b8        | if (??? + 96 != 0) goto label_309;      
        if((??? + 96) != 0)
        {
            goto label_309;
        }
        // 0x00D7B310: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B314: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        // 0x00D7B318: CBNZ x8, #0xd7b2bc         | if (??? + 96 != 0) goto label_310;      
        if((??? + 96) != 0)
        {
            goto label_310;
        }
        // 0x00D7B31C: B #0xd7b8a4                |  goto label_382;                        
        goto label_382;
        label_201:
        // 0x00D7B320: ADRP x21, #0x3642000       | X21 = 56893440 (0x3642000);             
        // 0x00D7B324: LDR x21, [x21, #0x8b0]     | X21 = 1152921504887996416;              
        // 0x00D7B328: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_138 = null;
        // 0x00D7B32C: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7B330: TBZ w8, #0, #0xd7b344      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_313;
        // 0x00D7B334: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7B338: CBNZ w8, #0xd7b344         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_313;
        // 0x00D7B33C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B340: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_138 = null;
        label_313:
        // 0x00D7B344: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7B348: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7B34C: CBNZ x20, #0xd7b354        | if (CameraShotHelper.instance != null) goto label_314;
        if(CameraShotHelper.instance != null)
        {
            goto label_314;
        }
        // 0x00D7B350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_314:
        // 0x00D7B354: STRB wzr, [x20, #0x20]     | CameraShotHelper.instance.IsOpeningMoveUpdate = false;  //  dest_result_addr=0
        CameraShotHelper.instance.IsOpeningMoveUpdate = false;
        // 0x00D7B358: LDR x8, [x21]              | X8 = typeof(CameraShotHelper);          
        // 0x00D7B35C: LDR x8, [x8, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7B360: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7B364: CBNZ x20, #0xd7b36c        | if (CameraShotHelper.instance != null) goto label_315;
        if(CameraShotHelper.instance != null)
        {
            goto label_315;
        }
        // 0x00D7B368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_315:
        // 0x00D7B36C: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00D7B370: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00D7B374: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7B378: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00D7B37C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D7B380: TBZ w8, #0, #0xd7b390      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_317;
        // 0x00D7B384: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D7B388: CBNZ w8, #0xd7b390         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_317;
        // 0x00D7B38C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_317:
        // 0x00D7B390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D7B394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7B398: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7B39C: MOV x2, x20                | X2 = 1152921504843214848 (0x100000000E16B000);//ML01
        // 0x00D7B3A0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        bool val_66 = UnityEngine.Object.op_Inequality(x:  0, y:  0);
        // 0x00D7B3A4: TBZ w0, #0, #0xd7b3e8      | if (val_66 == false) goto label_318;    
        if(val_66 == false)
        {
            goto label_318;
        }
        // 0x00D7B3A8: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_139 = null;
        // 0x00D7B3AC: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7B3B0: TBZ w8, #0, #0xd7b3c4      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_320;
        // 0x00D7B3B4: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7B3B8: CBNZ w8, #0xd7b3c4         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_320;
        // 0x00D7B3BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B3C0: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_139 = null;
        label_320:
        // 0x00D7B3C4: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7B3C8: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7B3CC: CBNZ x20, #0xd7b3d4        | if (CameraShotHelper.instance != null) goto label_321;
        if(CameraShotHelper.instance != null)
        {
            goto label_321;
        }
        // 0x00D7B3D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_321:
        // 0x00D7B3D4: LDR x20, [x20, #0x18]      | X20 = CameraShotHelper.instance.cameraBezier;
        // 0x00D7B3D8: CBNZ x20, #0xd7b3e0        | if ( != 0) goto label_322;              
        if(null != 0)
        {
            goto label_322;
        }
        // 0x00D7B3DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_322:
        // 0x00D7B3E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7B3E4: STRB w8, [x20, #0x88]      | typeof(CameraBezier).__il2cppRuntimeField_88 = 0x1;  //  dest_result_addr=1152921504843214984
        typeof(CameraBezier).__il2cppRuntimeField_88 = 1;
        label_318:
        // 0x00D7B3E8: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_140 = null;
        // 0x00D7B3EC: LDRB w8, [x0, #0x10a]      | W8 = CameraShotHelper.__il2cppRuntimeField_10A;
        // 0x00D7B3F0: TBZ w8, #0, #0xd7b404      | if (CameraShotHelper.__il2cppRuntimeField_has_cctor == 0) goto label_324;
        // 0x00D7B3F4: LDR w8, [x0, #0xbc]        | W8 = CameraShotHelper.__il2cppRuntimeField_cctor_finished;
        // 0x00D7B3F8: CBNZ w8, #0xd7b404         | if (CameraShotHelper.__il2cppRuntimeField_cctor_finished != 0) goto label_324;
        // 0x00D7B3FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B400: LDR x0, [x21]              | X0 = typeof(CameraShotHelper);          
        val_140 = null;
        label_324:
        // 0x00D7B404: LDR x8, [x0, #0xa0]        | X8 = CameraShotHelper.__il2cppRuntimeField_static_fields;
        // 0x00D7B408: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        val_141 = mem[??? + 96];
        val_141 = ??? + 96;
        // 0x00D7B40C: LDR x20, [x8]              | X20 = CameraShotHelper.instance;        
        // 0x00D7B410: CBZ x24, #0xd7b61c         | if (??? + 96 == 0) goto label_325;      
        if(val_141 == 0)
        {
            goto label_325;
        }
        // 0x00D7B414: LDR w21, [x24, #0xe8]      | W21 = ??? + 96 + 232;                   
        val_142 = mem[??? + 96 + 232];
        val_142 = ??? + 96 + 232;
        // 0x00D7B418: MOV x22, x24               | X22 = ??? + 96;//m1                     
        val_143 = val_141;
        // 0x00D7B41C: B #0xd7b6c8                |  goto label_353;                        
        goto label_353;
        label_249:
        // 0x00D7B420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B424: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        val_98 = mem[??? + 96];
        val_98 = ??? + 96;
        // 0x00D7B428: CBZ x23, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_98 == 0)
        {
            goto label_382;
        }
        label_250:
        // 0x00D7B42C: LDR x22, [x22, #0x110]     | X22 = ??? + 96 + 272;                   
        // 0x00D7B430: LDP s8, s9, [x23, #0xec]   | S8 = ??? + 96 + 236; S9 = ??? + 96 + 236 + 4; //  | 
        // 0x00D7B434: LDR s10, [x23, #0xf4]      | S10 = ??? + 96 + 244;                   
        // 0x00D7B438: CBZ x23, #0xd7b444         | if (??? + 96 == 0) goto label_328;      
        if(val_98 == 0)
        {
            goto label_328;
        }
        // 0x00D7B43C: LDR s11, [x23, #0xf8]      | S11 = ??? + 96 + 248;                   
        val_144 = mem[??? + 96 + 248];
        val_144 = ??? + 96 + 248;
        // 0x00D7B440: B #0xd7b458                |  goto label_329;                        
        goto label_329;
        label_328:
        // 0x00D7B444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B448: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        // 0x00D7B44C: LDR s11, [x23, #0xf8]      | S11 = ??? + 96 + 248;                   
        val_144 = mem[??? + 96 + 248];
        val_144 = ??? + 96 + 248;
        // 0x00D7B450: CBZ x24, #0xd7b4b8         | if (??? + 96 == 0) goto label_330;      
        if((??? + 96) == 0)
        {
            goto label_330;
        }
        // 0x00D7B454: MOV x23, x24               | X23 = ??? + 96;//m1                     
        val_98 = ??? + 96;
        label_329:
        // 0x00D7B458: LDR s12, [x23, #0xfc]      | S12 = ??? + 96 + 252;                   
        label_333:
        // 0x00D7B45C: LDR s13, [x23, #0x100]     | S13 = ??? + 96 + 256;                   
        // 0x00D7B460: MOV x24, x23               | X24 = ??? + 96;//m1                     
        label_334:
        // 0x00D7B464: LDR s14, [x24, #0x104]     | S14 = ??? + 96 + 260;                   
        // 0x00D7B468: MOV x23, x24               | X23 = ??? + 96;//m1                     
        label_375:
        // 0x00D7B46C: LDR w23, [x23, #0x94]      | W23 = ??? + 96 + 148;                   
        // 0x00D7B470: LDR w24, [x24, #0x108]     | W24 = ??? + 96 + 264;                   
        // 0x00D7B474: CBNZ x20, #0xd7b47c        | if (CameraShotHelper.instance != null) goto label_331;
        if(CameraShotHelper.instance != null)
        {
            goto label_331;
        }
        // 0x00D7B478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_331:
        // 0x00D7B47C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00D7B480: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7B484: MOV w1, w21                | W1 = ??? + 96 + 232;//m1                
        // 0x00D7B488: MOV x2, x22                | X2 = ??? + 96 + 272;//m1                
        // 0x00D7B48C: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 236;//m1                
        // 0x00D7B490: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 236 + 4;//m1            
        // 0x00D7B494: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 244;//m1                
        // 0x00D7B498: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 248;//m1                
        // 0x00D7B49C: MOV v4.16b, v12.16b        | V4 = ??? + 96 + 252;//m1                
        // 0x00D7B4A0: MOV v5.16b, v13.16b        | V5 = ??? + 96 + 256;//m1                
        // 0x00D7B4A4: MOV v6.16b, v14.16b        | V6 = ??? + 96 + 260;//m1                
        // 0x00D7B4A8: MOV w3, w23                | W3 = ??? + 96 + 148;//m1                
        // 0x00D7B4AC: MOV w4, w24                | W4 = ??? + 96 + 264;//m1                
        // 0x00D7B4B0: BL #0xbafed0               | CameraShotHelper.instance.circleAction(id:  val_99, boneName:  ??? + 96 + 272, tg:  new UnityEngine.Vector3() {x = ??? + 96 + 236, y = ??? + 96 + 236 + 4, z = ??? + 96 + 244}, sp:  val_144, dt:  ??? + 96 + 252, hg:  ??? + 96 + 256, sa:  ??? + 96 + 260, isHero:  ??? + 96 + 148, isRight:  ??? + 96 + 264);
        CameraShotHelper.instance.circleAction(id:  val_99, boneName:  ??? + 96 + 272, tg:  new UnityEngine.Vector3() {x = ??? + 96 + 236, y = ??? + 96 + 236 + 4, z = ??? + 96 + 244}, sp:  val_144, dt:  ??? + 96 + 252, hg:  ??? + 96 + 256, sa:  ??? + 96 + 260, isHero:  ??? + 96 + 148, isRight:  ??? + 96 + 264);
        // 0x00D7B4B4: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_330:
        // 0x00D7B4B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B4BC: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7B4C0: LDR s12, [x24, #0xfc]      | S12 = ??? + 96 + 252;                   
        // 0x00D7B4C4: CBNZ x23, #0xd7b45c        | if (??? + 96 != 0) goto label_333;      
        if((??? + 96) != 0)
        {
            goto label_333;
        }
        // 0x00D7B4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B4CC: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        // 0x00D7B4D0: LDR s13, [x23, #0x100]     | S13 = ??? + 96 + 256;                   
        // 0x00D7B4D4: CBNZ x24, #0xd7b464        | if (??? + 96 != 0) goto label_334;      
        if((??? + 96) != 0)
        {
            goto label_334;
        }
        // 0x00D7B4D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B4DC: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7B4E0: LDR s14, [x24, #0x104]     | S14 = ??? + 96 + 260;                   
        // 0x00D7B4E4: CBZ x23, #0xd7b79c         | if (??? + 96 == 0) goto label_335;      
        if((??? + 96) == 0)
        {
            goto label_335;
        }
        // 0x00D7B4E8: MOV x24, x23               | X24 = ??? + 96;//m1                     
        // 0x00D7B4EC: B #0xd7b46c                |  goto label_375;                        
        goto label_375;
        label_264:
        // 0x00D7B4F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        // 0x00D7B4F4: LDR x25, [x19, #0x60]      | X25 = ??? + 96;                         
        val_102 = mem[??? + 96];
        val_102 = ??? + 96;
        // 0x00D7B4F8: CBZ x25, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_102 == 0)
        {
            goto label_382;
        }
        label_265:
        // 0x00D7B4FC: LDR s8, [x26, #0x128]      | S8 = ??? + 96 + 296;                    
        // 0x00D7B500: LDR s9, [x25, #0x11c]      | S9 = ??? + 96 + 284;                    
        // 0x00D7B504: LDR s10, [x25, #0x120]     | S10 = ??? + 96 + 288;                   
        // 0x00D7B508: LDR s11, [x25, #0x124]     | S11 = ??? + 96 + 292;                   
        // 0x00D7B50C: MOV x8, x25                | X8 = ??? + 96;//m1                      
        val_145 = val_102;
        // 0x00D7B510: CBNZ x25, #0xd7b520        | if (??? + 96 != 0) goto label_338;      
        if(val_102 != 0)
        {
            goto label_338;
        }
        // 0x00D7B514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        // 0x00D7B518: LDR x8, [x19, #0x60]       | X8 = ??? + 96;                          
        val_145 = mem[??? + 96];
        val_145 = ??? + 96;
        // 0x00D7B51C: CBZ x8, #0xd7b8a4          | if (??? + 96 == 0) goto label_382;      
        if(val_145 == 0)
        {
            goto label_382;
        }
        label_338:
        // 0x00D7B520: LDR w25, [x25, #0x130]     | W25 = ??? + 96 + 304;                   
        // 0x00D7B524: LDR s12, [x8, #0x134]      | S12 = ??? + 96 + 308;                   
        // 0x00D7B528: CBNZ x23, #0xd7b530        | if (val_26 != null) goto label_340;     
        if(val_26 != null)
        {
            goto label_340;
        }
        // 0x00D7B52C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_340:
        // 0x00D7B530: CMP w25, #1                | STATE = COMPARE(??? + 96 + 304, 0x1)    
        // 0x00D7B534: CSET w5, eq                | W5 = ??? + 96 + 304 == 0x1 ? 1 : 0;     
        bool val_67 = ((??? + 96 + 304) == 1) ? 1 : 0;
        // 0x00D7B538: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
        // 0x00D7B53C: MOV x0, x23                | X0 = val_26;//m1                        
        // 0x00D7B540: MOV w1, w24                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7B544: MOV x2, x21                | X2 = val_25;//m1                        
        // 0x00D7B548: MOV x3, x20                | X3 = val_22;//m1                        
        // 0x00D7B54C: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 296;//m1                
        // 0x00D7B550: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 284;//m1                
        // 0x00D7B554: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 288;//m1                
        // 0x00D7B558: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 292;//m1                
        // 0x00D7B55C: MOV x4, x22                | X4 = val_23;//m1                        
        // 0x00D7B560: MOV v4.16b, v12.16b        | V4 = ??? + 96 + 308;//m1                
        // 0x00D7B564: BL #0xb61974               | val_26.PlayCameraShotEffect(id:  val_103, obj:  val_25, srcTf:  val_22, lifetime:  ??? + 96 + 296, pos:  new UnityEngine.Vector3() {x = ??? + 96 + 284, y = ??? + 96 + 288, z = ??? + 96 + 292}, host:  val_23, isShowInBlack:  bool val_67 = ((??? + 96 + 304) == 1) ? 1 : 0, playSpeed:  ??? + 96 + 308);
        val_26.PlayCameraShotEffect(id:  val_103, obj:  val_25, srcTf:  val_22, lifetime:  ??? + 96 + 296, pos:  new UnityEngine.Vector3() {x = ??? + 96 + 284, y = ??? + 96 + 288, z = ??? + 96 + 292}, host:  val_23, isShowInBlack:  val_67, playSpeed:  ??? + 96 + 308);
        // 0x00D7B568: LDR x20, [x19, #0x78]      | X20 = ??? + 120;                        
        // 0x00D7B56C: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B570: CBNZ x22, #0xd7b578        | if (??? + 96 != 0) goto label_341;      
        if((??? + 96) != 0)
        {
            goto label_341;
        }
        // 0x00D7B574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_341:
        // 0x00D7B578: LDR w22, [x22, #0x118]     | W22 = ??? + 96 + 280;                   
        // 0x00D7B57C: CBNZ x20, #0xd7b584        | if (??? + 120 != 0) goto label_342;     
        if((??? + 120) != 0)
        {
            goto label_342;
        }
        // 0x00D7B580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
        label_342:
        // 0x00D7B584: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7B588: LDR x8, [x8, #0x898]       | X8 = 1152921510772421328;               
        // 0x00D7B58C: MOV x0, x20                | X0 = ??? + 120;//m1                     
        // 0x00D7B590: MOV w1, w22                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7B594: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::ContainsKey(System.Int32 key);
        // 0x00D7B598: BL #0x2415bdc              | X0 = ??? + 120.ContainsKey(key:  ??? + 96 + 280);
        bool val_68 = ??? + 120.ContainsKey(key:  ??? + 96 + 280);
        // 0x00D7B59C: AND w8, w0, #1             | W8 = (val_68 & 1);                      
        bool val_69 = val_68;
        // 0x00D7B5A0: TBNZ w8, #0, #0xd7b158     | if ((val_68 & 1) == true) goto label_346;
        if(val_69 == true)
        {
            goto label_346;
        }
        // 0x00D7B5A4: LDR x20, [x19, #0x78]      | X20 = ??? + 120;                        
        // 0x00D7B5A8: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B5AC: CBNZ x22, #0xd7b5b4        | if (??? + 96 != 0) goto label_344;      
        if((??? + 96) != 0)
        {
            goto label_344;
        }
        // 0x00D7B5B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
        label_344:
        // 0x00D7B5B4: LDR w22, [x22, #0x118]     | W22 = ??? + 96 + 280;                   
        // 0x00D7B5B8: CBNZ x20, #0xd7b5c0        | if (??? + 120 != 0) goto label_345;     
        if((??? + 120) != 0)
        {
            goto label_345;
        }
        // 0x00D7B5BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
        label_345:
        // 0x00D7B5C0: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
        // 0x00D7B5C4: LDR x8, [x8, #0x710]       | X8 = 1152921510773326416;               
        // 0x00D7B5C8: MOV x0, x20                | X0 = ??? + 120;//m1                     
        // 0x00D7B5CC: MOV w1, w22                | W1 = ??? + 96 + 280;//m1                
        // 0x00D7B5D0: MOV x2, x21                | X2 = val_25;//m1                        
        // 0x00D7B5D4: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, UnityEngine.GameObject>::set_Item(System.Int32 key, UnityEngine.GameObject value);
        // 0x00D7B5D8: BL #0x24147b0              | ??? + 120.set_Item(key:  ??? + 96 + 280, value:  val_25);
        ??? + 120.set_Item(key:  ??? + 96 + 280, value:  val_25);
        // 0x00D7B5DC: B #0xd7b158                |  goto label_346;                        
        goto label_346;
        label_266:
        // 0x00D7B5E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        // 0x00D7B5E4: LDR x25, [x19, #0x60]      | X25 = ??? + 96;                         
        // 0x00D7B5E8: LDR s8, [x26, #0x134]      | S8 = ??? + 96 + 308;                    
        // 0x00D7B5EC: MOV x21, x27               | X21 = X27;//m1                          
        // 0x00D7B5F0: CBNZ x25, #0xd7af64        | if (??? + 96 != 0) goto label_347;      
        if((??? + 96) != 0)
        {
            goto label_347;
        }
        // 0x00D7B5F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
        // 0x00D7B5F8: LDR x26, [x19, #0x60]      | X26 = ??? + 96;                         
        // 0x00D7B5FC: CBNZ x26, #0xd7af68        | if (??? + 96 != 0) goto label_348;      
        if((??? + 96) != 0)
        {
            goto label_348;
        }
        // 0x00D7B600: B #0xd7b8a4                |  goto label_382;                        
        goto label_382;
        label_276:
        // 0x00D7B604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B608: LDR x22, [x19, #0x60]      | X22 = this.curCameraShot; //P2          
        // 0x00D7B60C: LDR x27, [x21, #0x30]      | X27 = this.curCameraShot.speeds; //P2   
        // 0x00D7B610: CBZ x22, #0xd7b6a4         | if (this.curCameraShot == null) goto label_350;
        if(this.curCameraShot == null)
        {
            goto label_350;
        }
        // 0x00D7B614: LDR x1, [sp, #0x60]        | X1 = this.curCameraShot.paths;          
        // 0x00D7B618: B #0xd7abb4                |  goto label_351;                        
        goto label_351;
        label_325:
        // 0x00D7B61C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B620: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        val_143 = mem[??? + 96];
        val_143 = ??? + 96;
        // 0x00D7B624: LDR w21, [x24, #0xe8]      | W21 = ??? + 96 + 232;                   
        val_142 = mem[??? + 96 + 232];
        val_142 = ??? + 96 + 232;
        // 0x00D7B628: CBZ x22, #0xd7b6bc         | if (??? + 96 == 0) goto label_352;      
        if(val_143 == 0)
        {
            goto label_352;
        }
        // 0x00D7B62C: MOV x24, x22               | X24 = ??? + 96;//m1                     
        val_141 = val_143;
        // 0x00D7B630: B #0xd7b6c8                |  goto label_353;                        
        goto label_353;
        label_217:
        // 0x00D7B634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B638: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B63C: LDR w21, [x23, #0xe8]      | W21 = ??? + 96 + 232;                   
        val_123 = mem[??? + 96 + 232];
        val_123 = ??? + 96 + 232;
        // 0x00D7B640: CBZ x22, #0xd7b748         | if (??? + 96 == 0) goto label_354;      
        if((??? + 96) == 0)
        {
            goto label_354;
        }
        // 0x00D7B644: MOV x23, x22               | X23 = ??? + 96;//m1                     
        val_122 = ??? + 96;
        label_218:
        // 0x00D7B648: LDR s8, [x23, #0xf8]       | S8 = ??? + 96 + 248;                    
        label_369:
        // 0x00D7B64C: LDR s9, [x23, #0xfc]       | S9 = ??? + 96 + 252;                    
        // 0x00D7B650: MOV x22, x23               | X22 = ??? + 96;//m1                     
        label_370:
        // 0x00D7B654: LDR s10, [x22, #0x100]     | S10 = ??? + 96 + 256;                   
        // 0x00D7B658: MOV x23, x22               | X23 = ??? + 96;//m1                     
        label_381:
        // 0x00D7B65C: LDR s11, [x23, #0x104]     | S11 = ??? + 96 + 260;                   
        // 0x00D7B660: LDR w22, [x22, #0x108]     | W22 = ??? + 96 + 264;                   
        // 0x00D7B664: CBNZ x20, #0xd7b66c        | if (CameraShotHelper.instance != null) goto label_355;
        if(CameraShotHelper.instance != null)
        {
            goto label_355;
        }
        // 0x00D7B668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_355:
        // 0x00D7B66C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7B670: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7B674: MOV w1, w21                | W1 = ??? + 96 + 232;//m1                
        // 0x00D7B678: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 248;//m1                
        // 0x00D7B67C: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 252;//m1                
        // 0x00D7B680: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 256;//m1                
        // 0x00D7B684: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 260;//m1                
        // 0x00D7B688: MOV w2, w22                | W2 = ??? + 96 + 264;//m1                
        // 0x00D7B68C: BL #0xbb0940               | CameraShotHelper.instance.circleAction_Effect(id:  val_123, sp:  ??? + 96 + 248, dt:  ??? + 96 + 252, hg:  ??? + 96 + 256, sa:  ??? + 96 + 260, isRight:  ??? + 96 + 264);
        CameraShotHelper.instance.circleAction_Effect(id:  val_123, sp:  ??? + 96 + 248, dt:  ??? + 96 + 252, hg:  ??? + 96 + 256, sa:  ??? + 96 + 260, isRight:  ??? + 96 + 264);
        // 0x00D7B690: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_279:
        // 0x00D7B694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B698: LDR x21, [x19, #0x60]      | X21 = ??? + 96;                         
        // 0x00D7B69C: CBNZ x21, #0xd7ac98        | if (??? + 96 != 0) goto label_357;      
        if((??? + 96) != 0)
        {
            goto label_357;
        }
        // 0x00D7B6A0: B #0xd7b8a4                |  goto label_382;                        
        goto label_382;
        label_350:
        // 0x00D7B6A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B6A8: LDR x21, [x19, #0x60]      | X21 = this.curCameraShot; //P2          
        // 0x00D7B6AC: LDR x4, [x22, #0x38]       | X4 = this.curCameraShot.focusIds; //P2  
        // 0x00D7B6B0: CBZ x21, #0xd7b780         | if (this.curCameraShot == null) goto label_359;
        if(this.curCameraShot == null)
        {
            goto label_359;
        }
        // 0x00D7B6B4: LDR x1, [sp, #0x60]        | X1 = this.curCameraShot.paths;          
        // 0x00D7B6B8: B #0xd7abbc                |  goto label_360;                        
        goto label_360;
        label_352:
        // 0x00D7B6BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B6C0: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        val_141 = mem[??? + 96];
        val_141 = ??? + 96;
        // 0x00D7B6C4: CBZ x24, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_141 == 0)
        {
            goto label_382;
        }
        label_353:
        // 0x00D7B6C8: LDR x22, [x22, #0x110]     | X22 = ??? + 96 + 272;                   
        // 0x00D7B6CC: LDP s8, s9, [x24, #0xec]   | S8 = ??? + 96 + 236; S9 = ??? + 96 + 236 + 4; //  | 
        // 0x00D7B6D0: LDR s10, [x24, #0xf4]      | S10 = ??? + 96 + 244;                   
        // 0x00D7B6D4: CBZ x24, #0xd7b6e4         | if (??? + 96 == 0) goto label_362;      
        if(val_141 == 0)
        {
            goto label_362;
        }
        // 0x00D7B6D8: LDR w23, [x24, #0x108]     | W23 = ??? + 96 + 264;                   
        val_146 = mem[??? + 96 + 264];
        val_146 = ??? + 96 + 264;
        // 0x00D7B6DC: MOV x25, x24               | X25 = ??? + 96;//m1                     
        val_147 = val_141;
        // 0x00D7B6E0: B #0xd7b708                |  goto label_365;                        
        goto label_365;
        label_362:
        // 0x00D7B6E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B6E8: LDR x25, [x19, #0x60]      | X25 = ??? + 96;                         
        val_147 = mem[??? + 96];
        val_147 = ??? + 96;
        // 0x00D7B6EC: LDR w23, [x24, #0x108]     | W23 = ??? + 96 + 264;                   
        val_146 = mem[??? + 96 + 264];
        val_146 = ??? + 96 + 264;
        // 0x00D7B6F0: CBZ x25, #0xd7b6fc         | if (??? + 96 == 0) goto label_364;      
        if(val_147 == 0)
        {
            goto label_364;
        }
        // 0x00D7B6F4: MOV x24, x25               | X24 = ??? + 96;//m1                     
        val_141 = val_147;
        // 0x00D7B6F8: B #0xd7b708                |  goto label_365;                        
        goto label_365;
        label_364:
        // 0x00D7B6FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B700: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        val_141 = mem[??? + 96];
        val_141 = ??? + 96;
        // 0x00D7B704: CBZ x24, #0xd7b8a4         | if (??? + 96 == 0) goto label_382;      
        if(val_141 == 0)
        {
            goto label_382;
        }
        label_365:
        // 0x00D7B708: LDR s11, [x25, #0xf8]      | S11 = ??? + 96 + 248;                   
        // 0x00D7B70C: LDR w24, [x24, #0x94]      | W24 = ??? + 96 + 148;                   
        // 0x00D7B710: CBNZ x20, #0xd7b718        | if (CameraShotHelper.instance != null) goto label_367;
        if(CameraShotHelper.instance != null)
        {
            goto label_367;
        }
        // 0x00D7B714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        label_367:
        // 0x00D7B718: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x00D7B71C: MOV x0, x20                | X0 = CameraShotHelper.instance;//m1     
        // 0x00D7B720: MOV w1, w21                | W1 = ??? + 96 + 232;//m1                
        // 0x00D7B724: MOV x2, x22                | X2 = ??? + 96 + 272;//m1                
        // 0x00D7B728: MOV v0.16b, v8.16b         | V0 = ??? + 96 + 236;//m1                
        // 0x00D7B72C: MOV v1.16b, v9.16b         | V1 = ??? + 96 + 236 + 4;//m1            
        // 0x00D7B730: MOV v2.16b, v10.16b        | V2 = ??? + 96 + 244;//m1                
        // 0x00D7B734: MOV w3, w23                | W3 = ??? + 96 + 264;//m1                
        // 0x00D7B738: MOV v3.16b, v11.16b        | V3 = ??? + 96 + 248;//m1                
        // 0x00D7B73C: MOV w4, w24                | W4 = ??? + 96 + 148;//m1                
        // 0x00D7B740: BL #0xbb00c4               | CameraShotHelper.instance.circleAction_default(id:  val_142, boneName:  ??? + 96 + 272, tg:  new UnityEngine.Vector3() {x = ??? + 96 + 236, y = ??? + 96 + 236 + 4, z = ??? + 96 + 244}, isRight:  val_146, sp:  ??? + 96 + 248, isHero:  ??? + 96 + 148);
        CameraShotHelper.instance.circleAction_default(id:  val_142, boneName:  ??? + 96 + 272, tg:  new UnityEngine.Vector3() {x = ??? + 96 + 236, y = ??? + 96 + 236 + 4, z = ??? + 96 + 244}, isRight:  val_146, sp:  ??? + 96 + 248, isHero:  ??? + 96 + 148);
        // 0x00D7B744: B #0xd7b170                |  goto label_368;                        
        goto label_368;
        label_354:
        // 0x00D7B748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B74C: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7B750: LDR s8, [x22, #0xf8]       | S8 = ??? + 96 + 248;                    
        // 0x00D7B754: CBNZ x23, #0xd7b64c        | if (??? + 96 != 0) goto label_369;      
        if((??? + 96) != 0)
        {
            goto label_369;
        }
        // 0x00D7B758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B75C: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B760: LDR s9, [x23, #0xfc]       | S9 = ??? + 96 + 252;                    
        // 0x00D7B764: CBNZ x22, #0xd7b654        | if (??? + 96 != 0) goto label_370;      
        if((??? + 96) != 0)
        {
            goto label_370;
        }
        // 0x00D7B768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B76C: LDR x23, [x19, #0x60]      | X23 = ??? + 96;                         
        // 0x00D7B770: LDR s10, [x22, #0x100]     | S10 = ??? + 96 + 256;                   
        // 0x00D7B774: CBZ x23, #0xd7b7f0         | if (??? + 96 == 0) goto label_371;      
        if((??? + 96) == 0)
        {
            goto label_371;
        }
        // 0x00D7B778: MOV x22, x23               | X22 = ??? + 96;//m1                     
        // 0x00D7B77C: B #0xd7b65c                |  goto label_381;                        
        goto label_381;
        label_359:
        // 0x00D7B780: STR x4, [sp, #0x58]        | stack[1152921515115947704] = this.curCameraShot.focusIds;  //  dest_result_addr=1152921515115947704
        // 0x00D7B784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B788: LDR x22, [x19, #0x60]      | X22 = this.curCameraShot; //P2          
        // 0x00D7B78C: LDR x5, [x21, #0x40]       | X5 = this.curCameraShot.isHeros; //P2   
        // 0x00D7B790: CBZ x22, #0xd7b7ac         | if (this.curCameraShot == null) goto label_373;
        if(this.curCameraShot == null)
        {
            goto label_373;
        }
        // 0x00D7B794: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B798: B #0xd7abc4                |  goto label_374;                        
        goto label_374;
        label_335:
        // 0x00D7B79C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B7A0: LDR x24, [x19, #0x60]      | X24 = ??? + 96;                         
        // 0x00D7B7A4: CBNZ x24, #0xd7b46c        | if (??? + 96 != 0) goto label_375;      
        if((??? + 96) != 0)
        {
            goto label_375;
        }
        // 0x00D7B7A8: B #0xd7b8a4                |  goto label_382;                        
        goto label_382;
        label_373:
        // 0x00D7B7AC: STR x5, [sp, #0x50]        | stack[1152921515115947696] = this.curCameraShot.isHeros;  //  dest_result_addr=1152921515115947696
        // 0x00D7B7B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B7B4: LDR x21, [x19, #0x60]      | X21 = this.curCameraShot; //P2          
        // 0x00D7B7B8: LDR x8, [x22, #0x48]       | X8 = this.curCameraShot.smooths; //P2   
        // 0x00D7B7BC: STR x8, [sp, #0x48]        | stack[1152921515115947688] = this.curCameraShot.smooths;  //  dest_result_addr=1152921515115947688
        // 0x00D7B7C0: CBZ x21, #0xd7b7d0         | if (this.curCameraShot == null) goto label_377;
        if(this.curCameraShot == null)
        {
            goto label_377;
        }
        // 0x00D7B7C4: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B7C8: LDP x6, x5, [sp, #0x48]    | X6 = this.curCameraShot.smooths; X5 = this.curCameraShot.isHeros; //  | 
        // 0x00D7B7CC: B #0xd7abcc                |  goto label_378;                        
        goto label_378;
        label_377:
        // 0x00D7B7D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B7D4: LDR x22, [x19, #0x60]      | X22 = this.curCameraShot; //P2          
        // 0x00D7B7D8: LDR x21, [x21, #0x50]      | X21 = this.curCameraShot.views; //P2    
        // 0x00D7B7DC: CBZ x22, #0xd7b800         | if (this.curCameraShot == null) goto label_379;
        if(this.curCameraShot == null)
        {
            goto label_379;
        }
        // 0x00D7B7E0: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B7E4: LDP x6, x5, [sp, #0x48]    | X6 = this.curCameraShot.smooths; X5 = this.curCameraShot.isHeros; //  | 
        // 0x00D7B7E8: MOV x7, x21                | X7 = this.curCameraShot.views;//m1      
        // 0x00D7B7EC: B #0xd7abd4                |  goto label_380;                        
        goto label_380;
        label_371:
        // 0x00D7B7F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B7F4: LDR x22, [x19, #0x60]      | X22 = ??? + 96;                         
        // 0x00D7B7F8: CBNZ x22, #0xd7b65c        | if (??? + 96 != 0) goto label_381;      
        if((??? + 96) != 0)
        {
            goto label_381;
        }
        // 0x00D7B7FC: B #0xd7b8a4                |  goto label_382;                        
        goto label_382;
        label_379:
        // 0x00D7B800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B804: LDR x24, [x19, #0x60]      | X24 = this.curCameraShot; //P2          
        // 0x00D7B808: LDR x22, [x22, #0x60]      | X22 = this.curCameraShot.rotSpeed; //P2 
        // 0x00D7B80C: CBZ x24, #0xd7b824         | if (this.curCameraShot == null) goto label_383;
        if(this.curCameraShot == null)
        {
            goto label_383;
        }
        // 0x00D7B810: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B814: LDP x6, x5, [sp, #0x48]    | X6 = this.curCameraShot.smooths; X5 = this.curCameraShot.isHeros; //  | 
        // 0x00D7B818: MOV x7, x21                | X7 = this.curCameraShot.views;//m1      
        // 0x00D7B81C: MOV x8, x22                | X8 = this.curCameraShot.rotSpeed;//m1   
        // 0x00D7B820: B #0xd7abdc                |  goto label_384;                        
        goto label_384;
        label_383:
        // 0x00D7B824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B828: LDR x23, [x19, #0x60]      | X23 = this.curCameraShot; //P2          
        // 0x00D7B82C: LDR x24, [x24, #0x68]      | X24 = this.curCameraShot.isClockWise; //P2 
        // 0x00D7B830: CBZ x23, #0xd7b84c         | if (this.curCameraShot == null) goto label_385;
        if(this.curCameraShot == null)
        {
            goto label_385;
        }
        // 0x00D7B834: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B838: LDP x6, x5, [sp, #0x48]    | X6 = this.curCameraShot.smooths; X5 = this.curCameraShot.isHeros; //  | 
        // 0x00D7B83C: MOV x7, x21                | X7 = this.curCameraShot.views;//m1      
        // 0x00D7B840: MOV x8, x22                | X8 = this.curCameraShot.rotSpeed;//m1   
        // 0x00D7B844: MOV x9, x24                | X9 = this.curCameraShot.isClockWise;//m1
        // 0x00D7B848: B #0xd7abe4                |  goto label_386;                        
        goto label_386;
        label_385:
        // 0x00D7B84C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B850: LDR x25, [x19, #0x60]      | X25 = this.curCameraShot; //P2          
        // 0x00D7B854: LDR x8, [x23, #0x78]       | X8 = this.curCameraShot.orthograhics; //P2 
        // 0x00D7B858: STR x8, [sp, #0x40]        | stack[1152921515115947680] = this.curCameraShot.orthograhics;  //  dest_result_addr=1152921515115947680
        // 0x00D7B85C: CBZ x25, #0xd7b880         | if (this.curCameraShot == null) goto label_387;
        if(this.curCameraShot == null)
        {
            goto label_387;
        }
        // 0x00D7B860: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B864: LDP x6, x5, [sp, #0x48]    | X6 = this.curCameraShot.smooths; X5 = this.curCameraShot.isHeros; //  | 
        // 0x00D7B868: LDR x10, [sp, #0x40]       | X10 = this.curCameraShot.orthograhics;  
        // 0x00D7B86C: MOV x23, x25               | X23 = this.curCameraShot;//m1           
        // 0x00D7B870: MOV x7, x21                | X7 = this.curCameraShot.views;//m1      
        // 0x00D7B874: MOV x8, x22                | X8 = this.curCameraShot.rotSpeed;//m1   
        // 0x00D7B878: MOV x9, x24                | X9 = this.curCameraShot.isClockWise;//m1
        // 0x00D7B87C: B #0xd7abec                |  goto label_389;                        
        goto label_389;
        label_387:
        // 0x00D7B880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
        // 0x00D7B884: LDR x23, [x19, #0x60]      | X23 = this.curCameraShot; //P2          
        // 0x00D7B888: LDP x4, x1, [sp, #0x58]    | X4 = this.curCameraShot.focusIds; X1 = this.curCameraShot.paths; //  | 
        // 0x00D7B88C: LDP x6, x5, [sp, #0x48]    | X6 = this.curCameraShot.smooths; X5 = this.curCameraShot.isHeros; //  | 
        // 0x00D7B890: LDR x10, [sp, #0x40]       | X10 = this.curCameraShot.orthograhics;  
        // 0x00D7B894: MOV x7, x21                | X7 = this.curCameraShot.views;//m1      
        // 0x00D7B898: MOV x8, x22                | X8 = this.curCameraShot.rotSpeed;//m1   
        // 0x00D7B89C: MOV x9, x24                | X9 = this.curCameraShot.isClockWise;//m1
        // 0x00D7B8A0: CBNZ x23, #0xd7abec        | if (this.curCameraShot != null) goto label_389;
        if(this.curCameraShot != null)
        {
            goto label_389;
        }
        label_382:
        // 0x00D7B8A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(CameraShotHelper), ????);
    
    }
    //
    // Offset in libil2cpp.so: 0x00D786EC (14124780), len: 1252  VirtAddr: 0x00D786EC RVA: 0x00D786EC token: 100694155 methodIndex: 25839 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnStart()
    {
        //
        // Disasemble & Code
        // 0x00D786EC: STP x24, x23, [sp, #-0x40]! | stack[1152921515117186240] = ???;  stack[1152921515117186248] = ???;  //  dest_result_addr=1152921515117186240 |  dest_result_addr=1152921515117186248
        // 0x00D786F0: STP x22, x21, [sp, #0x10]  | stack[1152921515117186256] = ???;  stack[1152921515117186264] = ???;  //  dest_result_addr=1152921515117186256 |  dest_result_addr=1152921515117186264
        // 0x00D786F4: STP x20, x19, [sp, #0x20]  | stack[1152921515117186272] = ???;  stack[1152921515117186280] = ???;  //  dest_result_addr=1152921515117186272 |  dest_result_addr=1152921515117186280
        // 0x00D786F8: STP x29, x30, [sp, #0x30]  | stack[1152921515117186288] = ???;  stack[1152921515117186296] = ???;  //  dest_result_addr=1152921515117186288 |  dest_result_addr=1152921515117186296
        // 0x00D786FC: ADD x29, sp, #0x30         | X29 = (1152921515117186240 + 48) = 1152921515117186288 (0x1000000272770CF0);
        // 0x00D78700: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D78704: LDRB w8, [x20, #0x404]     | W8 = (bool)static_value_03734404;       
        // 0x00D78708: MOV x19, x0                | X19 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D7870C: TBNZ w8, #0, #0xd78728     | if (static_value_03734404 == true) goto label_0;
        // 0x00D78710: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D78714: LDR x8, [x8, #8]           | X8 = 0x2B90350;                         
        // 0x00D78718: LDR w0, [x8]               | W0 = 0x1798;                            
        // 0x00D7871C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1798, ????);     
        // 0x00D78720: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D78724: STRB w8, [x20, #0x404]     | static_value_03734404 = true;            //  dest_result_addr=57885700
        label_0:
        // 0x00D78728: MOV x0, x19                | X0 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D7872C: BL #0xd7d570               | this.Open();                            
        this.Open();
        // 0x00D78730: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D78734: ADRP x22, #0x3658000       | X22 = 56983552 (0x3658000);             
        // 0x00D78738: LDR x8, [x8, #0x190]       | X8 = 1152921515117127200;               
        // 0x00D7873C: LDR x22, [x22, #0x980]     | X22 = 1152921504898113536;              
        // 0x00D78740: LDR x21, [x8]              | X21 = System.Void CameraShotMgr::OnLineComplete(CEvent.ZEvent ev);
        // 0x00D78744: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_1 = null;
        // 0x00D78748: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7874C: ADRP x23, #0x367a000       | X23 = 57122816 (0x367A000);             
        // 0x00D78750: LDR x23, [x23, #0xc38]     | X23 = 1152921512949758048;              
        // 0x00D78754: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D78758: MOV x2, x21                | X2 = 1152921515117127200 (0x1000000272762620);//ML01
        // 0x00D7875C: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78760: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78764: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnLineComplete(CEvent.ZEvent ev));
        val_1 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnLineComplete(CEvent.ZEvent ev));
        // 0x00D78768: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D7876C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D78770: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D78774: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D78778: TBZ w8, #0, #0xd78788      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7877C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D78780: CBNZ w8, #0xd78788         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D78784: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00D78788: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00D7878C: LDR x8, [x8, #0x510]       | X8 = (string**)(1152921514494688976)("LINE_MOVE");
        // 0x00D78790: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78794: LDR x1, [x8]               | X1 = "LINE_MOVE";                       
        // 0x00D78798: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "LINE_MOVE");
        CEvent.ZEventCenter.AddEventListener(eventType:  null, fun:  "LINE_MOVE");
        // 0x00D7879C: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00D787A0: LDR x8, [x8, #0x350]       | X8 = 1152921515117128224;               
        // 0x00D787A4: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00D787A8: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev);
        // 0x00D787AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D787B0: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D787B4: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D787B8: MOV x2, x20                | X2 = 1152921515117128224 (0x1000000272762A20);//ML01
        // 0x00D787BC: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D787C0: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev));
        // 0x00D787C4: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D787C8: LDR x8, [x8, #0xb0]        | X8 = (string**)(1152921510322335888)("SHOOTEFFECT_DONE");
        // 0x00D787CC: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D787D0: LDR x1, [x8]               | X1 = "SHOOTEFFECT_DONE";                
        // 0x00D787D4: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev)), fun:  "SHOOTEFFECT_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_2, fun:  "SHOOTEFFECT_DONE");
        // 0x00D787D8: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D787DC: LDR x8, [x8, #0xc00]       | X8 = 1152921515117129248;               
        // 0x00D787E0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_3 = null;
        // 0x00D787E4: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev);
        // 0x00D787E8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D787EC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D787F0: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D787F4: MOV x2, x20                | X2 = 1152921515117129248 (0x1000000272762E20);//ML01
        // 0x00D787F8: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D787FC: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev));
        val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev));
        // 0x00D78800: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00D78804: LDR x8, [x8, #0xcd8]       | X8 = (string**)(1152921510322334768)("EFFECT_DONE");
        // 0x00D78808: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7880C: LDR x1, [x8]               | X1 = "EFFECT_DONE";                     
        // 0x00D78810: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev)), fun:  "EFFECT_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_3, fun:  "EFFECT_DONE");
        // 0x00D78814: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00D78818: LDR x8, [x8, #0x6b8]       | X8 = 1152921515117130272;               
        // 0x00D7881C: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00D78820: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev);
        // 0x00D78824: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78828: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7882C: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D78830: MOV x2, x20                | X2 = 1152921515117130272 (0x1000000272763220);//ML01
        // 0x00D78834: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78838: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev));
        // 0x00D7883C: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00D78840: LDR x8, [x8, #0x7b8]       | X8 = (string**)(1152921514494331120)("GAMESPEED_DONE");
        // 0x00D78844: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78848: LDR x1, [x8]               | X1 = "GAMESPEED_DONE";                  
        // 0x00D7884C: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev)), fun:  "GAMESPEED_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_4, fun:  "GAMESPEED_DONE");
        // 0x00D78850: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x00D78854: LDR x8, [x8, #0x9d0]       | X8 = 1152921515117131296;               
        // 0x00D78858: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_5 = null;
        // 0x00D7885C: LDR x20, [x8]              | X20 = public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e);
        // 0x00D78860: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78864: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78868: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D7886C: MOV x2, x20                | X2 = 1152921515117131296 (0x1000000272763620);//ML01
        // 0x00D78870: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78874: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e));
        val_5 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e));
        // 0x00D78878: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D7887C: LDR x8, [x8, #0x610]       | X8 = (string**)(1152921510322337024)("CAMERASHOTJUMP_DONE");
        // 0x00D78880: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78884: LDR x1, [x8]               | X1 = "CAMERASHOTJUMP_DONE";             
        // 0x00D78888: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_5 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e)), fun:  "CAMERASHOTJUMP_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_5, fun:  "CAMERASHOTJUMP_DONE");
        // 0x00D7888C: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00D78890: LDR x8, [x8, #0x998]       | X8 = 1152921515117132320;               
        // 0x00D78894: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_6 = null;
        // 0x00D78898: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev);
        // 0x00D7889C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D788A0: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D788A4: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D788A8: MOV x2, x20                | X2 = 1152921515117132320 (0x1000000272763A20);//ML01
        // 0x00D788AC: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D788B0: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev));
        val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev));
        // 0x00D788B4: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00D788B8: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921510113315232)("ACTION_DONE");
        // 0x00D788BC: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D788C0: LDR x1, [x8]               | X1 = "ACTION_DONE";                     
        // 0x00D788C4: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev)), fun:  "ACTION_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_6, fun:  "ACTION_DONE");
        // 0x00D788C8: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D788CC: LDR x8, [x8, #0x448]       | X8 = 1152921515117133344;               
        // 0x00D788D0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_7 = null;
        // 0x00D788D4: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev);
        // 0x00D788D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D788DC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D788E0: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D788E4: MOV x2, x20                | X2 = 1152921515117133344 (0x1000000272763E20);//ML01
        // 0x00D788E8: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D788EC: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev));
        val_7 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev));
        // 0x00D788F0: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00D788F4: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510113316352)("SKILL_DONE");
        // 0x00D788F8: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D788FC: LDR x1, [x8]               | X1 = "SKILL_DONE";                      
        // 0x00D78900: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_7 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev)), fun:  "SKILL_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_7, fun:  "SKILL_DONE");
        // 0x00D78904: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00D78908: LDR x8, [x8, #0xe20]       | X8 = 1152921515117134368;               
        // 0x00D7890C: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_8 = null;
        // 0x00D78910: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev);
        // 0x00D78914: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78918: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7891C: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D78920: MOV x2, x20                | X2 = 1152921515117134368 (0x1000000272764220);//ML01
        // 0x00D78924: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78928: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev));
        val_8 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev));
        // 0x00D7892C: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D78930: LDR x8, [x8, #0x758]       | X8 = (string**)(1152921514495046832)("BRIGHT_DONE");
        // 0x00D78934: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78938: LDR x1, [x8]               | X1 = "BRIGHT_DONE";                     
        // 0x00D7893C: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_8 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev)), fun:  "BRIGHT_DONE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_8, fun:  "BRIGHT_DONE");
        // 0x00D78940: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D78944: LDR x8, [x8, #0x650]       | X8 = 1152921515117135392;               
        // 0x00D78948: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_9 = null;
        // 0x00D7894C: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev);
        // 0x00D78950: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78954: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78958: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D7895C: MOV x2, x20                | X2 = 1152921515117135392 (0x1000000272764620);//ML01
        // 0x00D78960: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78964: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev));
        val_9 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev));
        // 0x00D78968: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00D7896C: LDR x8, [x8, #0xde0]       | X8 = (string**)(1152921510113314096)("WAITTIME_COMPLETE");
        // 0x00D78970: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78974: LDR x1, [x8]               | X1 = "WAITTIME_COMPLETE";               
        // 0x00D78978: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_9 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev)), fun:  "WAITTIME_COMPLETE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_9, fun:  "WAITTIME_COMPLETE");
        // 0x00D7897C: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00D78980: LDR x8, [x8, #0x438]       | X8 = 1152921515117136416;               
        // 0x00D78984: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_10 = null;
        // 0x00D78988: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev);
        // 0x00D7898C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78990: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78994: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D78998: MOV x2, x20                | X2 = 1152921515117136416 (0x1000000272764A20);//ML01
        // 0x00D7899C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D789A0: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev));
        val_10 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev));
        // 0x00D789A4: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D789A8: LDR x8, [x8, #0x268]       | X8 = (string**)(1152921510322314320)("PLOT_END");
        // 0x00D789AC: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D789B0: LDR x1, [x8]               | X1 = "PLOT_END";                        
        // 0x00D789B4: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_10 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev)), fun:  "PLOT_END");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_10, fun:  "PLOT_END");
        // 0x00D789B8: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00D789BC: LDR x8, [x8, #0xde0]       | X8 = 1152921515111800416;               
        // 0x00D789C0: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_11 = null;
        // 0x00D789C4: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev);
        // 0x00D789C8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D789CC: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D789D0: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D789D4: MOV x2, x20                | X2 = 1152921515111800416 (0x100000027224DE60);//ML01
        // 0x00D789D8: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D789DC: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        val_11 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        // 0x00D789E0: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00D789E4: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513302392240)("CAMERASHOT_MOVE_COMPLETE");
        // 0x00D789E8: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D789EC: LDR x1, [x8]               | X1 = "CAMERASHOT_MOVE_COMPLETE";        
        // 0x00D789F0: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_11 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev)), fun:  "CAMERASHOT_MOVE_COMPLETE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_11, fun:  "CAMERASHOT_MOVE_COMPLETE");
        // 0x00D789F4: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00D789F8: LDR x8, [x8, #0xe88]       | X8 = 1152921515117137440;               
        // 0x00D789FC: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_12 = null;
        // 0x00D78A00: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev);
        // 0x00D78A04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78A08: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78A0C: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D78A10: MOV x2, x20                | X2 = 1152921515117137440 (0x1000000272764E20);//ML01
        // 0x00D78A14: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78A18: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev));
        val_12 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev));
        // 0x00D78A1C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00D78A20: LDR x8, [x8, #0xf20]       | X8 = (string**)(1152921514670686544)("MOVE_FINISH");
        // 0x00D78A24: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78A28: LDR x1, [x8]               | X1 = "MOVE_FINISH";                     
        // 0x00D78A2C: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_12 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev)), fun:  "MOVE_FINISH");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_12, fun:  "MOVE_FINISH");
        // 0x00D78A30: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00D78A34: LDR x8, [x8, #0xcb0]       | X8 = 1152921515117138464;               
        // 0x00D78A38: LDR x0, [x22]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_13 = null;
        // 0x00D78A3C: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev);
        // 0x00D78A40: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78A44: LDR x3, [x23]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78A48: MOV x1, x19                | X1 = 1152921515117198304 (0x1000000272773BE0);//ML01
        // 0x00D78A4C: MOV x2, x20                | X2 = 1152921515117138464 (0x1000000272765220);//ML01
        // 0x00D78A50: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78A54: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev));
        val_13 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev));
        // 0x00D78A58: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D78A5C: LDR x8, [x8, #0xa00]       | X8 = (string**)(1152921510113317472)("START_ANI_COMPLETE");
        // 0x00D78A60: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78A64: LDR x1, [x8]               | X1 = "START_ANI_COMPLETE";              
        // 0x00D78A68: BL #0xd775dc               | CEvent.ZEventCenter.AddEventListener(eventType:  val_13 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev)), fun:  "START_ANI_COMPLETE");
        CEvent.ZEventCenter.AddEventListener(eventType:  val_13, fun:  "START_ANI_COMPLETE");
        // 0x00D78A6C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D78A70: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D78A74: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D78A78: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D78A7C: TBZ w8, #0, #0xd78a8c      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00D78A80: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D78A84: CBNZ w8, #0xd78a8c         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00D78A88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_4:
        // 0x00D78A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78A90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78A94: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_14 = ZMG.GlobalGOMgr;
        // 0x00D78A98: MOV x19, x0                | X19 = val_14;//m1                       
        // 0x00D78A9C: CBNZ x19, #0xd78aa4        | if (val_14 != null) goto label_5;       
        if(val_14 != null)
        {
            goto label_5;
        }
        // 0x00D78AA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_5:
        // 0x00D78AA4: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D78AA8: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510322348304)("LS_STORY");
        // 0x00D78AAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D78AB0: MOV x0, x19                | X0 = val_14;//m1                        
        // 0x00D78AB4: LDR x1, [x8]               | X1 = "LS_STORY";                        
        // 0x00D78AB8: BL #0x2882014              | val_14.UnLock3DTouchEvent(key:  "LS_STORY");
        val_14.UnLock3DTouchEvent(key:  "LS_STORY");
        // 0x00D78ABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78AC4: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_15 = UnityEngine.Camera.main;
        // 0x00D78AC8: MOV x19, x0                | X19 = val_15;//m1                       
        // 0x00D78ACC: CBNZ x19, #0xd78ad4        | if (val_15 != null) goto label_6;       
        if(val_15 != null)
        {
            goto label_6;
        }
        // 0x00D78AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_6:
        // 0x00D78AD4: ADRP x20, #0x363c000       | X20 = 56868864 (0x363C000);             
        // 0x00D78AD8: LDR x20, [x20, #0xbe8]     | X20 = 1152921515117147680;              
        // 0x00D78ADC: MOV x0, x19                | X0 = val_15;//m1                        
        // 0x00D78AE0: LDR x1, [x20]              | X1 = public CameraShotHelper UnityEngine.Component::GetComponent<CameraShotHelper>();
        // 0x00D78AE4: BL #0x23d5410              | X0 = val_15.GetComponent<CameraShotHelper>();
        CameraShotHelper val_16 = val_15.GetComponent<CameraShotHelper>();
        // 0x00D78AE8: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00D78AEC: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00D78AF0: MOV x19, x0                | X19 = val_16;//m1                       
        // 0x00D78AF4: LDR x8, [x21]              | X8 = typeof(UnityEngine.Object);        
        // 0x00D78AF8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D78AFC: TBZ w9, #0, #0xd78b10      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x00D78B00: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D78B04: CBNZ w9, #0xd78b10         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x00D78B08: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00D78B0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_8:
        // 0x00D78B10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78B14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D78B18: MOV x1, x19                | X1 = val_16;//m1                        
        // 0x00D78B1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D78B20: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_16);
        bool val_17 = UnityEngine.Object.op_Inequality(x:  0, y:  val_16);
        // 0x00D78B24: TBZ w0, #0, #0xd78b7c      | if (val_17 == false) goto label_9;      
        if(val_17 == false)
        {
            goto label_9;
        }
        // 0x00D78B28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78B2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78B30: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_18 = UnityEngine.Camera.main;
        // 0x00D78B34: MOV x19, x0                | X19 = val_18;//m1                       
        // 0x00D78B38: CBNZ x19, #0xd78b40        | if (val_18 != null) goto label_10;      
        if(val_18 != null)
        {
            goto label_10;
        }
        // 0x00D78B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_10:
        // 0x00D78B40: LDR x1, [x20]              | X1 = public CameraShotHelper UnityEngine.Component::GetComponent<CameraShotHelper>();
        // 0x00D78B44: MOV x0, x19                | X0 = val_18;//m1                        
        // 0x00D78B48: BL #0x23d5410              | X0 = val_18.GetComponent<CameraShotHelper>();
        CameraShotHelper val_19 = val_18.GetComponent<CameraShotHelper>();
        // 0x00D78B4C: LDR x8, [x21]              | X8 = typeof(UnityEngine.Object);        
        // 0x00D78B50: MOV x19, x0                | X19 = val_19;//m1                       
        // 0x00D78B54: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00D78B58: TBZ w9, #0, #0xd78b6c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00D78B5C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00D78B60: CBNZ w9, #0xd78b6c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00D78B64: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00D78B68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x00D78B6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78B70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D78B74: MOV x1, x19                | X1 = val_19;//m1                        
        // 0x00D78B78: BL #0x1b78bac              | UnityEngine.Object.DestroyImmediate(obj:  0);
        UnityEngine.Object.DestroyImmediate(obj:  0);
        label_9:
        // 0x00D78B7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D78B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78B84: BL #0x20d1bd4              | X0 = UnityEngine.Camera.get_main();     
        UnityEngine.Camera val_20 = UnityEngine.Camera.main;
        // 0x00D78B88: MOV x19, x0                | X19 = val_20;//m1                       
        // 0x00D78B8C: CBNZ x19, #0xd78b94        | if (val_20 != null) goto label_13;      
        if(val_20 != null)
        {
            goto label_13;
        }
        // 0x00D78B90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
        label_13:
        // 0x00D78B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78B98: MOV x0, x19                | X0 = val_20;//m1                        
        // 0x00D78B9C: BL #0x20d50fc              | X0 = val_20.get_gameObject();           
        UnityEngine.GameObject val_21 = val_20.gameObject;
        // 0x00D78BA0: MOV x19, x0                | X19 = val_21;//m1                       
        // 0x00D78BA4: CBNZ x19, #0xd78bac        | if (val_21 != null) goto label_14;      
        if(val_21 != null)
        {
            goto label_14;
        }
        // 0x00D78BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_14:
        // 0x00D78BAC: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
        // 0x00D78BB0: LDR x8, [x8, #0xe88]       | X8 = 1152921515117169184;               
        // 0x00D78BB4: MOV x0, x19                | X0 = val_21;//m1                        
        // 0x00D78BB8: LDR x1, [x8]               | X1 = public CameraShotHelper UnityEngine.GameObject::AddComponent<CameraShotHelper>();
        // 0x00D78BBC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D78BC0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D78BC4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D78BC8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D78BCC: B #0x23d5984               | X0 = val_21.AddComponent<CameraShotHelper>(); return;
        CameraShotHelper val_22 = val_21.AddComponent<CameraShotHelper>();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D781C0 (14123456), len: 1324  VirtAddr: 0x00D781C0 RVA: 0x00D781C0 token: 100694156 methodIndex: 25840 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnEnd()
    {
        //
        // Disasemble & Code
        //  | 
        var val_17;
        // 0x00D781C0: STP x24, x23, [sp, #-0x40]! | stack[1152921515117347392] = ???;  stack[1152921515117347400] = ???;  //  dest_result_addr=1152921515117347392 |  dest_result_addr=1152921515117347400
        // 0x00D781C4: STP x22, x21, [sp, #0x10]  | stack[1152921515117347408] = ???;  stack[1152921515117347416] = ???;  //  dest_result_addr=1152921515117347408 |  dest_result_addr=1152921515117347416
        // 0x00D781C8: STP x20, x19, [sp, #0x20]  | stack[1152921515117347424] = ???;  stack[1152921515117347432] = ???;  //  dest_result_addr=1152921515117347424 |  dest_result_addr=1152921515117347432
        // 0x00D781CC: STP x29, x30, [sp, #0x30]  | stack[1152921515117347440] = ???;  stack[1152921515117347448] = ???;  //  dest_result_addr=1152921515117347440 |  dest_result_addr=1152921515117347448
        // 0x00D781D0: ADD x29, sp, #0x30         | X29 = (1152921515117347392 + 48) = 1152921515117347440 (0x1000000272798270);
        // 0x00D781D4: SUB sp, sp, #0x10          | SP = (1152921515117347392 - 16) = 1152921515117347376 (0x1000000272798230);
        // 0x00D781D8: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D781DC: LDRB w8, [x20, #0x405]     | W8 = (bool)static_value_03734405;       
        // 0x00D781E0: MOV x19, x0                | X19 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D781E4: TBNZ w8, #0, #0xd78200     | if (static_value_03734405 == true) goto label_0;
        // 0x00D781E8: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
        // 0x00D781EC: LDR x8, [x8, #0x2d8]       | X8 = 0x2B90324;                         
        // 0x00D781F0: LDR w0, [x8]               | W0 = 0x178D;                            
        // 0x00D781F4: BL #0x2782188              | X0 = sub_2782188( ?? 0x178D, ????);     
        // 0x00D781F8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D781FC: STRB w8, [x20, #0x405]     | static_value_03734405 = true;            //  dest_result_addr=57885701
        label_0:
        // 0x00D78200: ADRP x22, #0x35f7000       | X22 = 56586240 (0x35F7000);             
        // 0x00D78204: LDR x22, [x22, #0xb20]     | X22 = 1152921504901574656;              
        // 0x00D78208: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00D7820C: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D78210: LDR x20, [x8]              | X20 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D78214: CBNZ x20, #0xd7821c        | if (GameMgr.UPDATEOnOffEffect != null) goto label_1;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_1;
        }
        // 0x00D78218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x178D, ????);     
        label_1:
        // 0x00D7821C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78220: MOV x0, x20                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D78224: BL #0xc0c8b0               | X0 = GameMgr.UPDATEOnOffEffect.get_checkPoint();
        CSCheckPointUnit val_1 = GameMgr.UPDATEOnOffEffect.checkPoint;
        // 0x00D78228: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00D7822C: CBNZ x20, #0xd78234        | if (val_1 != null) goto label_2;        
        if(val_1 != null)
        {
            goto label_2;
        }
        // 0x00D78230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_2:
        // 0x00D78234: LDR w8, [x20, #0x18]       | W8 = val_1.id; //P2                     
        // 0x00D78238: CMP w8, #3                 | STATE = COMPARE(val_1.id, 0x3)          
        // 0x00D7823C: B.EQ #0xd78248             | if (val_1.id == 0x3) goto label_3;      
        if(val_1.id == 3)
        {
            goto label_3;
        }
        // 0x00D78240: MOV x0, x19                | X0 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78244: BL #0xd7d7f4               | this.Close();                           
        this.Close();
        label_3:
        // 0x00D78248: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
        // 0x00D7824C: ADRP x23, #0x3658000       | X23 = 56983552 (0x3658000);             
        // 0x00D78250: LDR x8, [x8, #0x190]       | X8 = 1152921515117127200;               
        // 0x00D78254: LDR x23, [x23, #0x980]     | X23 = 1152921504898113536;              
        // 0x00D78258: LDR x21, [x8]              | X21 = System.Void CameraShotMgr::OnLineComplete(CEvent.ZEvent ev);
        // 0x00D7825C: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_2 = null;
        // 0x00D78260: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78264: ADRP x24, #0x367a000       | X24 = 57122816 (0x367A000);             
        // 0x00D78268: LDR x24, [x24, #0xc38]     | X24 = 1152921512949758048;              
        // 0x00D7826C: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78270: MOV x2, x21                | X2 = 1152921515117127200 (0x1000000272762620);//ML01
        // 0x00D78274: MOV x20, x0                | X20 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78278: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D7827C: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnLineComplete(CEvent.ZEvent ev));
        val_2 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnLineComplete(CEvent.ZEvent ev));
        // 0x00D78280: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D78284: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D78288: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D7828C: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D78290: TBZ w8, #0, #0xd782a0      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00D78294: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D78298: CBNZ w8, #0xd782a0         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00D7829C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_5:
        // 0x00D782A0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00D782A4: LDR x8, [x8, #0x510]       | X8 = (string**)(1152921514494688976)("LINE_MOVE");
        // 0x00D782A8: MOV x2, x20                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D782AC: LDR x1, [x8]               | X1 = "LINE_MOVE";                       
        // 0x00D782B0: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  null, func:  "LINE_MOVE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  null, func:  "LINE_MOVE");
        // 0x00D782B4: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
        // 0x00D782B8: LDR x8, [x8, #0x350]       | X8 = 1152921515117128224;               
        // 0x00D782BC: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_3 = null;
        // 0x00D782C0: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev);
        // 0x00D782C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D782C8: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D782CC: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D782D0: MOV x2, x20                | X2 = 1152921515117128224 (0x1000000272762A20);//ML01
        // 0x00D782D4: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D782D8: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev));
        val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev));
        // 0x00D782DC: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x00D782E0: LDR x8, [x8, #0xb0]        | X8 = (string**)(1152921510322335888)("SHOOTEFFECT_DONE");
        // 0x00D782E4: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D782E8: LDR x1, [x8]               | X1 = "SHOOTEFFECT_DONE";                
        // 0x00D782EC: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_3 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnShootEffectComplete(CEvent.ZEvent ev)), func:  "SHOOTEFFECT_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_3, func:  "SHOOTEFFECT_DONE");
        // 0x00D782F0: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
        // 0x00D782F4: LDR x8, [x8, #0xc00]       | X8 = 1152921515117129248;               
        // 0x00D782F8: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_4 = null;
        // 0x00D782FC: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev);
        // 0x00D78300: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78304: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78308: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D7830C: MOV x2, x20                | X2 = 1152921515117129248 (0x1000000272762E20);//ML01
        // 0x00D78310: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78314: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev));
        val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev));
        // 0x00D78318: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
        // 0x00D7831C: LDR x8, [x8, #0xcd8]       | X8 = (string**)(1152921510322334768)("EFFECT_DONE");
        // 0x00D78320: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78324: LDR x1, [x8]               | X1 = "EFFECT_DONE";                     
        // 0x00D78328: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_4 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnEffectDone(CEvent.ZEvent ev)), func:  "EFFECT_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_4, func:  "EFFECT_DONE");
        // 0x00D7832C: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
        // 0x00D78330: LDR x8, [x8, #0x6b8]       | X8 = 1152921515117130272;               
        // 0x00D78334: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_5 = null;
        // 0x00D78338: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev);
        // 0x00D7833C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78340: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78344: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78348: MOV x2, x20                | X2 = 1152921515117130272 (0x1000000272763220);//ML01
        // 0x00D7834C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78350: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev));
        val_5 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev));
        // 0x00D78354: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00D78358: LDR x8, [x8, #0x7b8]       | X8 = (string**)(1152921514494331120)("GAMESPEED_DONE");
        // 0x00D7835C: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78360: LDR x1, [x8]               | X1 = "GAMESPEED_DONE";                  
        // 0x00D78364: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_5 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnGameSpeedComplete(CEvent.ZEvent ev)), func:  "GAMESPEED_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_5, func:  "GAMESPEED_DONE");
        // 0x00D78368: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
        // 0x00D7836C: LDR x8, [x8, #0x9d0]       | X8 = 1152921515117131296;               
        // 0x00D78370: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_6 = null;
        // 0x00D78374: LDR x20, [x8]              | X20 = public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e);
        // 0x00D78378: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7837C: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78380: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78384: MOV x2, x20                | X2 = 1152921515117131296 (0x1000000272763620);//ML01
        // 0x00D78388: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7838C: BL #0x19cc774              | .ctor(object:  this, method:  public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e));
        val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e));
        // 0x00D78390: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D78394: LDR x8, [x8, #0x610]       | X8 = (string**)(1152921510322337024)("CAMERASHOTJUMP_DONE");
        // 0x00D78398: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7839C: LDR x1, [x8]               | X1 = "CAMERASHOTJUMP_DONE";             
        // 0x00D783A0: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_6 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  public System.Void CameraShotMgr::JumpAllStory(CEvent.ZEvent e)), func:  "CAMERASHOTJUMP_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_6, func:  "CAMERASHOTJUMP_DONE");
        // 0x00D783A4: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
        // 0x00D783A8: LDR x8, [x8, #0x998]       | X8 = 1152921515117132320;               
        // 0x00D783AC: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_7 = null;
        // 0x00D783B0: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev);
        // 0x00D783B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D783B8: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D783BC: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D783C0: MOV x2, x20                | X2 = 1152921515117132320 (0x1000000272763A20);//ML01
        // 0x00D783C4: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D783C8: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev));
        val_7 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev));
        // 0x00D783CC: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00D783D0: LDR x8, [x8, #0xdf8]       | X8 = (string**)(1152921510113315232)("ACTION_DONE");
        // 0x00D783D4: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D783D8: LDR x1, [x8]               | X1 = "ACTION_DONE";                     
        // 0x00D783DC: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_7 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnActionComplete(CEvent.ZEvent ev)), func:  "ACTION_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_7, func:  "ACTION_DONE");
        // 0x00D783E0: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
        // 0x00D783E4: LDR x8, [x8, #0x448]       | X8 = 1152921515117133344;               
        // 0x00D783E8: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_8 = null;
        // 0x00D783EC: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev);
        // 0x00D783F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D783F4: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D783F8: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D783FC: MOV x2, x20                | X2 = 1152921515117133344 (0x1000000272763E20);//ML01
        // 0x00D78400: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78404: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev));
        val_8 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev));
        // 0x00D78408: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x00D7840C: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510113316352)("SKILL_DONE");
        // 0x00D78410: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78414: LDR x1, [x8]               | X1 = "SKILL_DONE";                      
        // 0x00D78418: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_8 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnSkillComplete(CEvent.ZEvent ev)), func:  "SKILL_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_8, func:  "SKILL_DONE");
        // 0x00D7841C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00D78420: LDR x8, [x8, #0xe20]       | X8 = 1152921515117134368;               
        // 0x00D78424: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_9 = null;
        // 0x00D78428: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev);
        // 0x00D7842C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78430: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78434: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78438: MOV x2, x20                | X2 = 1152921515117134368 (0x1000000272764220);//ML01
        // 0x00D7843C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78440: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev));
        val_9 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev));
        // 0x00D78444: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x00D78448: LDR x8, [x8, #0x758]       | X8 = (string**)(1152921514495046832)("BRIGHT_DONE");
        // 0x00D7844C: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78450: LDR x1, [x8]               | X1 = "BRIGHT_DONE";                     
        // 0x00D78454: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_9 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnBrightComplete(CEvent.ZEvent ev)), func:  "BRIGHT_DONE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_9, func:  "BRIGHT_DONE");
        // 0x00D78458: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x00D7845C: LDR x8, [x8, #0x650]       | X8 = 1152921515117135392;               
        // 0x00D78460: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_10 = null;
        // 0x00D78464: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev);
        // 0x00D78468: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7846C: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78470: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78474: MOV x2, x20                | X2 = 1152921515117135392 (0x1000000272764620);//ML01
        // 0x00D78478: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7847C: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev));
        val_10 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev));
        // 0x00D78480: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00D78484: LDR x8, [x8, #0xde0]       | X8 = (string**)(1152921510113314096)("WAITTIME_COMPLETE");
        // 0x00D78488: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7848C: LDR x1, [x8]               | X1 = "WAITTIME_COMPLETE";               
        // 0x00D78490: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_10 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnWaitComplete(CEvent.ZEvent ev)), func:  "WAITTIME_COMPLETE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_10, func:  "WAITTIME_COMPLETE");
        // 0x00D78494: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
        // 0x00D78498: LDR x8, [x8, #0x438]       | X8 = 1152921515117136416;               
        // 0x00D7849C: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_11 = null;
        // 0x00D784A0: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev);
        // 0x00D784A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D784A8: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D784AC: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D784B0: MOV x2, x20                | X2 = 1152921515117136416 (0x1000000272764A20);//ML01
        // 0x00D784B4: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D784B8: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev));
        val_11 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev));
        // 0x00D784BC: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
        // 0x00D784C0: LDR x8, [x8, #0x268]       | X8 = (string**)(1152921510322314320)("PLOT_END");
        // 0x00D784C4: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D784C8: LDR x1, [x8]               | X1 = "PLOT_END";                        
        // 0x00D784CC: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_11 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnPlotComplete(CEvent.ZEvent ev)), func:  "PLOT_END");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_11, func:  "PLOT_END");
        // 0x00D784D0: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
        // 0x00D784D4: LDR x8, [x8, #0xde0]       | X8 = 1152921515111800416;               
        // 0x00D784D8: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_12 = null;
        // 0x00D784DC: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev);
        // 0x00D784E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D784E4: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D784E8: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D784EC: MOV x2, x20                | X2 = 1152921515111800416 (0x100000027224DE60);//ML01
        // 0x00D784F0: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D784F4: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        val_12 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev));
        // 0x00D784F8: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00D784FC: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513302392240)("CAMERASHOT_MOVE_COMPLETE");
        // 0x00D78500: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78504: LDR x1, [x8]               | X1 = "CAMERASHOT_MOVE_COMPLETE";        
        // 0x00D78508: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_12 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveCameraComplete(CEvent.ZEvent ev)), func:  "CAMERASHOT_MOVE_COMPLETE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_12, func:  "CAMERASHOT_MOVE_COMPLETE");
        // 0x00D7850C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
        // 0x00D78510: LDR x8, [x8, #0xe88]       | X8 = 1152921515117137440;               
        // 0x00D78514: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_13 = null;
        // 0x00D78518: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev);
        // 0x00D7851C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D78520: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78524: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78528: MOV x2, x20                | X2 = 1152921515117137440 (0x1000000272764E20);//ML01
        // 0x00D7852C: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78530: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev));
        val_13 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev));
        // 0x00D78534: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00D78538: LDR x8, [x8, #0xf20]       | X8 = (string**)(1152921514670686544)("MOVE_FINISH");
        // 0x00D7853C: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D78540: LDR x1, [x8]               | X1 = "MOVE_FINISH";                     
        // 0x00D78544: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_13 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnMoveComplete(CEvent.ZEvent ev)), func:  "MOVE_FINISH");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_13, func:  "MOVE_FINISH");
        // 0x00D78548: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00D7854C: LDR x8, [x8, #0xcb0]       | X8 = 1152921515117138464;               
        // 0x00D78550: LDR x0, [x23]              | X0 = typeof(CEvent.EventFunc<T>);       
        CEvent.EventFunc<CEvent.ZEvent> val_14 = null;
        // 0x00D78554: LDR x20, [x8]              | X20 = System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev);
        // 0x00D78558: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.EventFunc<T>), ????);
        // 0x00D7855C: LDR x3, [x24]              | X3 = public System.Void CEvent.EventFunc<CEvent.ZEvent>::.ctor(object object, IntPtr method);
        // 0x00D78560: MOV x1, x19                | X1 = 1152921515117359456 (0x100000027279B160);//ML01
        // 0x00D78564: MOV x2, x20                | X2 = 1152921515117138464 (0x1000000272765220);//ML01
        // 0x00D78568: MOV x21, x0                | X21 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7856C: BL #0x19cc774              | .ctor(object:  this, method:  System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev));
        val_14 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev));
        // 0x00D78570: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x00D78574: LDR x8, [x8, #0xa00]       | X8 = (string**)(1152921510113317472)("START_ANI_COMPLETE");
        // 0x00D78578: MOV x2, x21                | X2 = 1152921504898113536 (0x10000000115C6000);//ML01
        // 0x00D7857C: LDR x1, [x8]               | X1 = "START_ANI_COMPLETE";              
        // 0x00D78580: BL #0xd77798               | CEvent.ZEventCenter.RemoveEventListener(eventType:  val_14 = new CEvent.EventFunc<CEvent.ZEvent>(object:  this, method:  System.Void CameraShotMgr::OnStartAniComplete(CEvent.ZEvent ev)), func:  "START_ANI_COMPLETE");
        CEvent.ZEventCenter.RemoveEventListener(eventType:  val_14, func:  "START_ANI_COMPLETE");
        // 0x00D78584: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x00D78588: LDR x8, [x8, #0x960]       | X8 = 1152921504911851520;               
        // 0x00D7858C: LDR x0, [x8]               | X0 = typeof(ZMG);                       
        // 0x00D78590: LDRB w8, [x0, #0x10a]      | W8 = ZMG.__il2cppRuntimeField_10A;      
        // 0x00D78594: TBZ w8, #0, #0xd785a4      | if (ZMG.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00D78598: LDR w8, [x0, #0xbc]        | W8 = ZMG.__il2cppRuntimeField_cctor_finished;
        // 0x00D7859C: CBNZ w8, #0xd785a4         | if (ZMG.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00D785A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ZMG), ????);
        label_7:
        // 0x00D785A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D785A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D785AC: BL #0x26a7bb8              | X0 = ZMG.get_GlobalGOMgr();             
        GlobalGOMgr val_15 = ZMG.GlobalGOMgr;
        // 0x00D785B0: MOV x19, x0                | X19 = val_15;//m1                       
        // 0x00D785B4: CBNZ x19, #0xd785bc        | if (val_15 != null) goto label_8;       
        if(val_15 != null)
        {
            goto label_8;
        }
        // 0x00D785B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_8:
        // 0x00D785BC: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00D785C0: LDR x8, [x8, #0x728]       | X8 = (string**)(1152921510322348304)("LS_STORY");
        // 0x00D785C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00D785C8: MOV x0, x19                | X0 = val_15;//m1                        
        // 0x00D785CC: LDR x1, [x8]               | X1 = "LS_STORY";                        
        // 0x00D785D0: BL #0x2882014              | val_15.UnLock3DTouchEvent(key:  "LS_STORY");
        val_15.UnLock3DTouchEvent(key:  "LS_STORY");
        // 0x00D785D4: LDR x8, [x22]              | X8 = typeof(GameMgr);                   
        // 0x00D785D8: LDR x8, [x8, #0xa0]        | X8 = GameMgr.__il2cppRuntimeField_static_fields;
        // 0x00D785DC: LDR x19, [x8]              | X19 = GameMgr.UPDATEOnOffEffect;        
        // 0x00D785E0: CBNZ x19, #0xd785e8        | if (GameMgr.UPDATEOnOffEffect != null) goto label_9;
        if(GameMgr.UPDATEOnOffEffect != null)
        {
            goto label_9;
        }
        // 0x00D785E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_9:
        // 0x00D785E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D785EC: MOV x0, x19                | X0 = GameMgr.UPDATEOnOffEffect;//m1     
        // 0x00D785F0: BL #0xc0c8b0               | X0 = GameMgr.UPDATEOnOffEffect.get_checkPoint();
        CSCheckPointUnit val_16 = GameMgr.UPDATEOnOffEffect.checkPoint;
        // 0x00D785F4: MOV x19, x0                | X19 = val_16;//m1                       
        val_17 = val_16;
        // 0x00D785F8: CBNZ x19, #0xd78600        | if (val_16 != null) goto label_10;      
        if(val_17 != null)
        {
            goto label_10;
        }
        // 0x00D785FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_10:
        // 0x00D78600: LDR w8, [x19, #0x18]       | W8 = val_16.id; //P2                    
        // 0x00D78604: CMP w8, #3                 | STATE = COMPARE(val_16.id, 0x3)         
        // 0x00D78608: B.NE #0xd786d4             | if (val_16.id != 0x3) goto label_11;    
        if(val_16.id != 3)
        {
            goto label_11;
        }
        // 0x00D7860C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00D78610: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00D78614: LDR x19, [x8]              | X19 = typeof(System.Object[]);          
        // 0x00D78618: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D7861C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00D78620: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00D78624: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D78628: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00D7862C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00D78630: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00D78634: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_17 = null;
        // 0x00D78638: ORR w9, wzr, #2            | W9 = 2(0x2);                            
        // 0x00D7863C: ADD x1, sp, #0xc           | X1 = (1152921515117347376 + 12) = 1152921515117347388 (0x100000027279823C);
        // 0x00D78640: LDR x8, [x8]               | X8 = typeof(System.Int32);              
        // 0x00D78644: STR w9, [sp, #0xc]         | stack[1152921515117347388] = 0x2;        //  dest_result_addr=1152921515117347388
        // 0x00D78648: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00D7864C: BL #0x27bc028              | X0 = 1152921515117403744 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 2);
        // 0x00D78650: MOV x20, x0                | X20 = 1152921515117403744 (0x10000002727A5E60);//ML01
        // 0x00D78654: CBNZ x19, #0xd7865c        | if ( != null) goto label_12;            
        if(null != null)
        {
            goto label_12;
        }
        // 0x00D78658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 2, ????);          
        label_12:
        // 0x00D7865C: CBZ x20, #0xd78680         | if (2 == 0) goto label_14;              
        if(2 == 0)
        {
            goto label_14;
        }
        // 0x00D78660: LDR x8, [x19]              | X8 = ;                                  
        // 0x00D78664: MOV x0, x20                | X0 = 1152921515117403744 (0x10000002727A5E60);//ML01
        // 0x00D78668: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00D7866C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 2, ????);          
        // 0x00D78670: CBNZ x0, #0xd78680         | if (2 != 0) goto label_14;              
        if(2 != 0)
        {
            goto label_14;
        }
        // 0x00D78674: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 2, ????);          
        // 0x00D78678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7867C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 2, ????);          
        label_14:
        // 0x00D78680: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00D78684: CBNZ w8, #0xd78694         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_15;
        // 0x00D78688: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 2, ????);          
        // 0x00D7868C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D78690: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 2, ????);          
        label_15:
        // 0x00D78694: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 2; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 2;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00D78698: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00D7869C: LDR x8, [x8, #0xb68]       | X8 = 1152921504901255168;               
        // 0x00D786A0: LDR x0, [x8]               | X0 = typeof(CallJSApi);                 
        // 0x00D786A4: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00D786A8: TBZ w8, #0, #0xd786b8      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00D786AC: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00D786B0: CBNZ w8, #0xd786b8         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00D786B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        label_17:
        // 0x00D786B8: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
        // 0x00D786BC: LDR x8, [x8, #0x638]       | X8 = (string**)(1152921515115099200)("OpenStartAni");
        // 0x00D786C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00D786C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D786C8: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00D786CC: LDR x1, [x8]               | X1 = "OpenStartAni";                    
        // 0x00D786D0: BL #0xba5838               | CallJSApi.CallJsFun(funName:  0, args:  "OpenStartAni");
        CallJSApi.CallJsFun(funName:  0, args:  "OpenStartAni");
        label_11:
        // 0x00D786D4: SUB sp, x29, #0x30         | SP = (1152921515117347440 - 48) = 1152921515117347392 (0x1000000272798240);
        // 0x00D786D8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00D786DC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00D786E0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00D786E4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00D786E8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7DD88 (14146952), len: 204  VirtAddr: 0x00D7DD88 RVA: 0x00D7DD88 token: 100694157 methodIndex: 25841 delegateWrapperIndex: 0 methodInvoker: 0
    private void <Execute>m__0()
    {
        //
        // Disasemble & Code
        // 0x00D7DD88: STP x22, x21, [sp, #-0x30]! | stack[1152921515117479888] = ???;  stack[1152921515117479896] = ???;  //  dest_result_addr=1152921515117479888 |  dest_result_addr=1152921515117479896
        // 0x00D7DD8C: STP x20, x19, [sp, #0x10]  | stack[1152921515117479904] = ???;  stack[1152921515117479912] = ???;  //  dest_result_addr=1152921515117479904 |  dest_result_addr=1152921515117479912
        // 0x00D7DD90: STP x29, x30, [sp, #0x20]  | stack[1152921515117479920] = ???;  stack[1152921515117479928] = ???;  //  dest_result_addr=1152921515117479920 |  dest_result_addr=1152921515117479928
        // 0x00D7DD94: ADD x29, sp, #0x20         | X29 = (1152921515117479888 + 32) = 1152921515117479920 (0x10000002727B87F0);
        // 0x00D7DD98: SUB sp, sp, #0x10          | SP = (1152921515117479888 - 16) = 1152921515117479872 (0x10000002727B87C0);
        // 0x00D7DD9C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7DDA0: LDRB w8, [x20, #0x406]     | W8 = (bool)static_value_03734406;       
        // 0x00D7DDA4: MOV x19, x0                | X19 = 1152921515117491936 (0x10000002727BB6E0);//ML01
        // 0x00D7DDA8: TBNZ w8, #0, #0xd7ddc4     | if (static_value_03734406 == true) goto label_0;
        // 0x00D7DDAC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
        // 0x00D7DDB0: LDR x8, [x8, #0x5a0]       | X8 = 0x2B90370;                         
        // 0x00D7DDB4: LDR w0, [x8]               | W0 = 0x17A0;                            
        // 0x00D7DDB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x17A0, ????);     
        // 0x00D7DDBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7DDC0: STRB w8, [x20, #0x406]     | static_value_03734406 = true;            //  dest_result_addr=57885702
        label_0:
        // 0x00D7DDC4: ADRP x9, #0x35e6000        | X9 = 56516608 (0x35E6000);              
        // 0x00D7DDC8: LDR w8, [x19, #0x4c]       | W8 = this.temp_float; //P2              
        // 0x00D7DDCC: LDR x9, [x9, #0xce8]       | X9 = 1152921504608444416;               
        // 0x00D7DDD0: ADD x1, sp, #0xc           | X1 = (1152921515117479872 + 12) = 1152921515117479884 (0x10000002727B87CC);
        // 0x00D7DDD4: STR w8, [sp, #0xc]         | stack[1152921515117479884] = this.temp_float;  //  dest_result_addr=1152921515117479884
        // 0x00D7DDD8: LDR x0, [x9]               | X0 = typeof(System.Single);             
        // 0x00D7DDDC: BL #0x27bc028              | X0 = 1152921515117523936 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Single), this.temp_float);
        // 0x00D7DDE0: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00D7DDE4: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00D7DDE8: MOV x20, x0                | X20 = 1152921515117523936 (0x10000002727C33E0);//ML01
        // 0x00D7DDEC: LDR x8, [x8]               | X8 = typeof(CEvent.ZEvent);             
        // 0x00D7DDF0: MOV x0, x8                 | X0 = 1152921504898326528 (0x10000000115FA000);//ML01
        object val_1 = null;
        // 0x00D7DDF4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00D7DDF8: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
        // 0x00D7DDFC: LDR x8, [x8, #0xde0]       | X8 = (string**)(1152921510113314096)("WAITTIME_COMPLETE");
        // 0x00D7DE00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7DE04: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00D7DE08: LDR x21, [x8]              | X21 = "WAITTIME_COMPLETE";              
        // 0x00D7DE0C: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00D7DE10: STR x20, [x19, #0x28]      | typeof(CEvent.ZEvent).__il2cppRuntimeField_28 = this.temp_float; typeof(CEvent.ZEvent).__il2cppRuntimeField_2C = 0x10000002;  //  dest_result_addr=1152921504898326568 dest_result_addr=1152921504898326572
        typeof(CEvent.ZEvent).__il2cppRuntimeField_28 = this.temp_float;
        typeof(CEvent.ZEvent).__il2cppRuntimeField_2C = 268435458;
        // 0x00D7DE14: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00D7DE18: STR x21, [x19, #0x10]      | typeof(CEvent.ZEvent).__il2cppRuntimeField_10 = "WAITTIME_COMPLETE";  //  dest_result_addr=1152921504898326544
        typeof(CEvent.ZEvent).__il2cppRuntimeField_10 = "WAITTIME_COMPLETE";
        // 0x00D7DE1C: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00D7DE20: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00D7DE24: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00D7DE28: TBZ w8, #0, #0xd7de38      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00D7DE2C: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00D7DE30: CBNZ w8, #0xd7de38         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00D7DE34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00D7DE38: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00D7DE3C: BL #0xd7de90               | CEvent.ZEventCenter.DispatchEvent(ev:  null);
        CEvent.ZEventCenter.DispatchEvent(ev:  null);
        // 0x00D7DE40: SUB sp, x29, #0x20         | SP = (1152921515117479920 - 32) = 1152921515117479888 (0x10000002727B87D0);
        // 0x00D7DE44: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7DE48: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00D7DE4C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00D7DE50: RET                        |  return;                                
        return;
    
    }

}
