using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonBinaryWriter
    {
        // Fields
        private static readonly System.Text.Encoding Encoding; // static_offset: 0x00000000
        private readonly System.IO.BinaryWriter _writer; //  0x00000010
        private byte[] _largeByteBuffer; //  0x00000018
        private int _maxChars; //  0x00000020
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285E7FC
        private System.DateTimeKind <DateTimeKindHandling>k__BackingField; //  0x00000024
        
        // Properties
        public System.DateTimeKind DateTimeKindHandling { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00ACF90C (11335948), len: 132  VirtAddr: 0x00ACF90C RVA: 0x00ACF90C token: 100684709 methodIndex: 47359 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonBinaryWriter(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            // 0x00ACF90C: STP x22, x21, [sp, #-0x30]! | stack[1152921513713248688] = ???;  stack[1152921513713248696] = ???;  //  dest_result_addr=1152921513713248688 |  dest_result_addr=1152921513713248696
            // 0x00ACF910: STP x20, x19, [sp, #0x10]  | stack[1152921513713248704] = ???;  stack[1152921513713248712] = ???;  //  dest_result_addr=1152921513713248704 |  dest_result_addr=1152921513713248712
            // 0x00ACF914: STP x29, x30, [sp, #0x20]  | stack[1152921513713248720] = ???;  stack[1152921513713248728] = ???;  //  dest_result_addr=1152921513713248720 |  dest_result_addr=1152921513713248728
            // 0x00ACF918: ADD x29, sp, #0x20         | X29 = (1152921513713248688 + 32) = 1152921513713248720 (0x100000021EC8A9D0);
            // 0x00ACF91C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00ACF920: LDRB w8, [x21, #0x4c6]     | W8 = (bool)static_value_037334C6;       
            // 0x00ACF924: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00ACF928: MOV x19, x0                | X19 = 1152921513713260736 (0x100000021EC8D8C0);//ML01
            // 0x00ACF92C: TBNZ w8, #0, #0xacf948     | if (static_value_037334C6 == true) goto label_0;
            // 0x00ACF930: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x00ACF934: LDR x8, [x8, #0xda0]       | X8 = 0x2B8F968;                         
            // 0x00ACF938: LDR w0, [x8]               | W0 = 0x151E;                            
            // 0x00ACF93C: BL #0x2782188              | X0 = sub_2782188( ?? 0x151E, ????);     
            // 0x00ACF940: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00ACF944: STRB w8, [x21, #0x4c6]     | static_value_037334C6 = true;            //  dest_result_addr=57881798
            label_0:
            // 0x00ACF948: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACF94C: MOV x0, x19                | X0 = 1152921513713260736 (0x100000021EC8D8C0);//ML01
            // 0x00ACF950: BL #0x16f59f0              | this..ctor();                           
            // 0x00ACF954: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00ACF958: STR w8, [x19, #0x24]       | this.<DateTimeKindHandling>k__BackingField = 0x1;  //  dest_result_addr=1152921513713260772
            this.<DateTimeKindHandling>k__BackingField = 1;
            // 0x00ACF95C: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00ACF960: LDR x8, [x8, #0xb0]        | X8 = 1152921504620744704;               
            // 0x00ACF964: LDR x0, [x8]               | X0 = typeof(System.IO.BinaryWriter);    
            System.IO.BinaryWriter val_1 = null;
            // 0x00ACF968: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.BinaryWriter), ????);
            // 0x00ACF96C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00ACF970: MOV x1, x20                | X1 = stream;//m1                        
            // 0x00ACF974: MOV x21, x0                | X21 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x00ACF978: BL #0x1e680b0              | .ctor(output:  stream);                 
            val_1 = new System.IO.BinaryWriter(output:  stream);
            // 0x00ACF97C: STR x21, [x19, #0x10]      | this._writer = typeof(System.IO.BinaryWriter);  //  dest_result_addr=1152921513713260752
            this._writer = val_1;
            // 0x00ACF980: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACF984: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00ACF988: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00ACF98C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF998 (11336088), len: 8  VirtAddr: 0x00ACF998 RVA: 0x00ACF998 token: 100684710 methodIndex: 47360 delegateWrapperIndex: 0 methodInvoker: 0
        public System.DateTimeKind get_DateTimeKindHandling()
        {
            //
            // Disasemble & Code
            // 0x00ACF998: LDR w0, [x0, #0x24]        | W0 = this.<DateTimeKindHandling>k__BackingField; //P2 
            // 0x00ACF99C: RET                        |  return (System.DateTimeKind)this.<DateTimeKindHandling>k__BackingField;
            return this.<DateTimeKindHandling>k__BackingField;
            //  |  // // {name=val_0, type=System.DateTimeKind, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF990 (11336080), len: 8  VirtAddr: 0x00ACF990 RVA: 0x00ACF990 token: 100684711 methodIndex: 47361 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_DateTimeKindHandling(System.DateTimeKind value)
        {
            //
            // Disasemble & Code
            // 0x00ACF990: STR w1, [x0, #0x24]        | this.<DateTimeKindHandling>k__BackingField = value;  //  dest_result_addr=1152921513713501156
            this.<DateTimeKindHandling>k__BackingField = value;
            // 0x00ACF994: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF9A0 (11336096), len: 48  VirtAddr: 0x00ACF9A0 RVA: 0x00ACF9A0 token: 100684712 methodIndex: 47362 delegateWrapperIndex: 0 methodInvoker: 0
        public void Flush()
        {
            //
            // Disasemble & Code
            // 0x00ACF9A0: STP x20, x19, [sp, #-0x20]! | stack[1152921513713609280] = ???;  stack[1152921513713609288] = ???;  //  dest_result_addr=1152921513713609280 |  dest_result_addr=1152921513713609288
            // 0x00ACF9A4: STP x29, x30, [sp, #0x10]  | stack[1152921513713609296] = ???;  stack[1152921513713609304] = ???;  //  dest_result_addr=1152921513713609296 |  dest_result_addr=1152921513713609304
            // 0x00ACF9A8: ADD x29, sp, #0x10         | X29 = (1152921513713609280 + 16) = 1152921513713609296 (0x100000021ECE2A50);
            // 0x00ACF9AC: LDR x19, [x0, #0x10]       | X19 = this._writer; //P2                
            // 0x00ACF9B0: CBNZ x19, #0xacf9b8        | if (this._writer != null) goto label_0; 
            if(this._writer != null)
            {
                goto label_0;
            }
            // 0x00ACF9B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00ACF9B8: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00ACF9BC: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00ACF9C0: LDP x2, x1, [x8, #0x190]   | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_190; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_198; //  | 
            // 0x00ACF9C4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACF9C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00ACF9CC: BR x2                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_190;
            goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_190;
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF9D0 (11336144), len: 48  VirtAddr: 0x00ACF9D0 RVA: 0x00ACF9D0 token: 100684713 methodIndex: 47363 delegateWrapperIndex: 0 methodInvoker: 0
        public void Close()
        {
            //
            // Disasemble & Code
            // 0x00ACF9D0: STP x20, x19, [sp, #-0x20]! | stack[1152921513713729472] = ???;  stack[1152921513713729480] = ???;  //  dest_result_addr=1152921513713729472 |  dest_result_addr=1152921513713729480
            // 0x00ACF9D4: STP x29, x30, [sp, #0x10]  | stack[1152921513713729488] = ???;  stack[1152921513713729496] = ???;  //  dest_result_addr=1152921513713729488 |  dest_result_addr=1152921513713729496
            // 0x00ACF9D8: ADD x29, sp, #0x10         | X29 = (1152921513713729472 + 16) = 1152921513713729488 (0x100000021ECFFFD0);
            // 0x00ACF9DC: LDR x19, [x0, #0x10]       | X19 = this._writer; //P2                
            // 0x00ACF9E0: CBNZ x19, #0xacf9e8        | if (this._writer != null) goto label_0; 
            if(this._writer != null)
            {
                goto label_0;
            }
            // 0x00ACF9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00ACF9E8: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00ACF9EC: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00ACF9F0: LDP x2, x1, [x8, #0x170]   | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_170; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_178; //  | 
            // 0x00ACF9F4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACF9F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00ACF9FC: BR x2                      | goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_170;
            goto typeof(System.IO.BinaryWriter).__il2cppRuntimeField_170;
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACFA00 (11336192), len: 44  VirtAddr: 0x00ACFA00 RVA: 0x00ACFA00 token: 100684714 methodIndex: 47364 delegateWrapperIndex: 0 methodInvoker: 0
        public void WriteToken(Newtonsoft.Json.Bson.BsonToken t)
        {
            //
            // Disasemble & Code
            // 0x00ACFA00: STP x20, x19, [sp, #-0x20]! | stack[1152921513713849664] = ???;  stack[1152921513713849672] = ???;  //  dest_result_addr=1152921513713849664 |  dest_result_addr=1152921513713849672
            // 0x00ACFA04: STP x29, x30, [sp, #0x10]  | stack[1152921513713849680] = ???;  stack[1152921513713849688] = ???;  //  dest_result_addr=1152921513713849680 |  dest_result_addr=1152921513713849688
            // 0x00ACFA08: ADD x29, sp, #0x10         | X29 = (1152921513713849664 + 16) = 1152921513713849680 (0x100000021ED1D550);
            // 0x00ACFA0C: MOV x19, x1                | X19 = t;//m1                            
            // 0x00ACFA10: MOV x20, x0                | X20 = 1152921513713861696 (0x100000021ED20440);//ML01
            // 0x00ACFA14: BL #0xacfa2c               | X0 = this.CalculateSize(t:  t);         
            int val_1 = this.CalculateSize(t:  t);
            // 0x00ACFA18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACFA1C: MOV x0, x20                | X0 = 1152921513713861696 (0x100000021ED20440);//ML01
            // 0x00ACFA20: MOV x1, x19                | X1 = t;//m1                             
            // 0x00ACFA24: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00ACFA28: B #0xad0484                | this.WriteTokenInternal(t:  t); return; 
            this.WriteTokenInternal(t:  t);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD0484 (11338884), len: 4876  VirtAddr: 0x00AD0484 RVA: 0x00AD0484 token: 100684715 methodIndex: 47365 delegateWrapperIndex: 0 methodInvoker: 0
        private void WriteTokenInternal(Newtonsoft.Json.Bson.BsonToken t)
        {
            //
            // Disasemble & Code
            //  | 
            var val_22;
            //  | 
            var val_24;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            var val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            long val_51;
            //  | 
            System.IO.BinaryWriter val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            var val_55;
            //  | 
            var val_56;
            //  | 
            var val_57;
            //  | 
            var val_58;
            //  | 
            var val_59;
            //  | 
            var val_60;
            //  | 
            var val_61;
            //  | 
            var val_62;
            //  | 
            System.IO.Stream val_63;
            //  | 
            var val_64;
            //  | 
            var val_65;
            //  | 
            var val_66;
            //  | 
            var val_67;
            //  | 
            var val_68;
            //  | 
            System.DateTimeOffset val_69;
            //  | 
            var val_70;
            //  | 
            var val_71;
            //  | 
            var val_72;
            //  | 
            var val_73;
            //  | 
            string val_74;
            //  | 
            var val_75;
            //  | 
            var val_76;
            //  | 
            var val_77;
            //  | 
            var val_78;
            //  | 
            string val_79;
            //  | 
            int val_80;
            //  | 
            var val_81;
            //  | 
            var val_82;
            //  | 
            var val_83;
            //  | 
            var val_84;
            //  | 
            var val_85;
            //  | 
            var val_86;
            //  | 
            var val_87;
            //  | 
            string val_88;
            //  | 
            var val_89;
            //  | 
            System.DateTimeKind val_90;
            //  | 
            var val_91;
            label_84:
            // 0x00AD0484: STP d9, d8, [sp, #-0x70]!  | stack[1152921513714037600] = ???;  stack[1152921513714037608] = ???;  //  dest_result_addr=1152921513714037600 |  dest_result_addr=1152921513714037608
            // 0x00AD0488: STP x28, x27, [sp, #0x10]  | stack[1152921513714037616] = ???;  stack[1152921513714037624] = ???;  //  dest_result_addr=1152921513714037616 |  dest_result_addr=1152921513714037624
            // 0x00AD048C: STP x26, x25, [sp, #0x20]  | stack[1152921513714037632] = ???;  stack[1152921513714037640] = ???;  //  dest_result_addr=1152921513714037632 |  dest_result_addr=1152921513714037640
            // 0x00AD0490: STP x24, x23, [sp, #0x30]  | stack[1152921513714037648] = ???;  stack[1152921513714037656] = ???;  //  dest_result_addr=1152921513714037648 |  dest_result_addr=1152921513714037656
            // 0x00AD0494: STP x22, x21, [sp, #0x40]  | stack[1152921513714037664] = ???;  stack[1152921513714037672] = ???;  //  dest_result_addr=1152921513714037664 |  dest_result_addr=1152921513714037672
            // 0x00AD0498: STP x20, x19, [sp, #0x50]  | stack[1152921513714037680] = ???;  stack[1152921513714037688] = ???;  //  dest_result_addr=1152921513714037680 |  dest_result_addr=1152921513714037688
            // 0x00AD049C: STP x29, x30, [sp, #0x60]  | stack[1152921513714037696] = ???;  stack[1152921513714037704] = ???;  //  dest_result_addr=1152921513714037696 |  dest_result_addr=1152921513714037704
            // 0x00AD04A0: ADD x29, sp, #0x60         | X29 = (1152921513714037600 + 96) = 1152921513714037696 (0x100000021ED4B3C0);
            // 0x00AD04A4: SUB sp, sp, #0xe0          | SP = (1152921513714037600 - 224) = 1152921513714037376 (0x100000021ED4B280);
            // 0x00AD04A8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00AD04AC: LDRB w8, [x21, #0x4c7]     | W8 = (bool)static_value_037334C7;       
            // 0x00AD04B0: MOV x20, x1                | X20 = t;//m1                            
            // 0x00AD04B4: MOV x19, x0                | X19 = 1152921513714049712 (0x100000021ED4E2B0);//ML01
            val_52 = this;
            // 0x00AD04B8: TBNZ w8, #0, #0xad04d4     | if (static_value_037334C7 == true) goto label_0;
            // 0x00AD04BC: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x00AD04C0: LDR x8, [x8, #0x680]       | X8 = 0x2B8F974;                         
            // 0x00AD04C4: LDR w0, [x8]               | W0 = 0x1521;                            
            // 0x00AD04C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1521, ????);     
            // 0x00AD04CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD04D0: STRB w8, [x21, #0x4c7]     | static_value_037334C7 = true;            //  dest_result_addr=57881799
            label_0:
            // 0x00AD04D4: STR wzr, [sp, #0x44]       | stack[1152921513714037444] = 0x0;        //  dest_result_addr=1152921513714037444
            // 0x00AD04D8: STP xzr, xzr, [sp, #0x30]  | stack[1152921513714037424] = 0x0;  stack[1152921513714037432] = 0x0;  //  dest_result_addr=1152921513714037424 |  dest_result_addr=1152921513714037432
            // 0x00AD04DC: STP xzr, xzr, [sp, #0x18]  | stack[1152921513714037400] = 0x0;  stack[1152921513714037408] = 0x0;  //  dest_result_addr=1152921513714037400 |  dest_result_addr=1152921513714037408
            // 0x00AD04E0: STR xzr, [sp, #0x10]       | stack[1152921513714037392] = 0x0;        //  dest_result_addr=1152921513714037392
            // 0x00AD04E4: CBNZ x20, #0xad04ec        | if (t != null) goto label_1;            
            if(t != null)
            {
                goto label_1;
            }
            // 0x00AD04E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1521, ????);     
            label_1:
            // 0x00AD04EC: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD04F0: MOV x0, x20                | X0 = t;//m1                             
            // 0x00AD04F4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150; X1 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_158; //  | 
            // 0x00AD04F8: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150();
            // 0x00AD04FC: SXTB w8, w0                | W8 = (int)(sbyte)((t) & 0xFF);          
            var val_51 = (int)t & 255;
            // 0x00AD0500: SUB w8, w8, #1             | W8 = ((int)(sbyte)((t) & 0xFF) - 1);    
            val_51 = val_51 - 1;
            // 0x00AD0504: CMP w8, #0x11              | STATE = COMPARE(((int)(sbyte)((t) & 0xFF) - 1), 0x11)
            // 0x00AD0508: B.HI #0xad13b8             | if ((int)t & 255 > 0x11) goto label_2;  
            if(val_51 > 17)
            {
                goto label_2;
            }
            // 0x00AD050C: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD0510: ADD x9, x9, #0x660         | X9 = (44638208 + 1632) = 44639840 (0x02A92660);
            // 0x00AD0514: LDR w8, [x9, w8, sxtw #2]  | W8 = 44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2;
            // 0x00AD0518: CMP w8, #0xf               | STATE = COMPARE(44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2, 0xF)
            // 0x00AD051C: B.HI #0xad1380             | if (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2 > 0xF) goto label_144;
            if((44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) > 15)
            {
                goto label_144;
            }
            // 0x00AD0520: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00AD0524: ADD x9, x9, #0x518         | X9 = (44638208 + 1304) = 44639512 (0x02A92518);
            // 0x00AD0528: LDRSW x8, [x9, x8, lsl #2] | X8 = 44639512 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2;
            var val_52 = 44639512 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2;
            // 0x00AD052C: ADD x23, sp, #0x88         | X23 = (1152921513714037376 + 136) = 1152921513714037512 (0x100000021ED4B308);
            // 0x00AD0530: ADD x8, x8, x9             | X8 = (44639512 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2 + 44639512);
            val_52 = val_52 + 44639512;
            // 0x00AD0534: BR x8                      | goto (44639512 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2 + 44639512);
            goto (44639512 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2 + 44639512);
            // 0x00AD0538: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD053C: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD0540: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD0544: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD0548: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD054C: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0550: CMP w10, w9                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0554: B.LO #0xad15b4             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00AD0558: LDR x10, [x8, #0xb0]       | X10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD055C: ADD x9, x10, x9, lsl #3    | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bson
            // 0x00AD0560: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0564: CMP x9, x1                 | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD0568: B.NE #0xad15b4             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00AD056C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD0570: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD0574: LDR x19, [x19, #0x10]      | X19 = this._writer; //P2                
            val_52 = this._writer;
            // 0x00AD0578: LDR x20, [x20, #0x20]      | 
            // 0x00AD057C: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD0580: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD0584: TBZ w8, #0, #0xad0594      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00AD0588: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD058C: CBNZ w8, #0xad0594         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00AD0590: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_7:
            // 0x00AD0594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0598: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD059C: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_2 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD05A0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AD05A4: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00AD05A8: MOV x21, x0                | X21 = val_2;//m1                        
            val_51 = val_2;
            // 0x00AD05AC: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x00AD05B0: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00AD05B4: TBZ w9, #0, #0xad05c8      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00AD05B8: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD05BC: CBNZ w9, #0xad05c8         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00AD05C0: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x00AD05C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_9:
            // 0x00AD05C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD05CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD05D0: MOV x1, x20                | X1 = t;//m1                             
            // 0x00AD05D4: MOV x2, x21                | X2 = val_2;//m1                         
            // 0x00AD05D8: BL #0x1ba4e50              | X0 = System.Convert.ToDouble(value:  0, provider:  t);
            double val_3 = System.Convert.ToDouble(value:  0, provider:  t);
            // 0x00AD05DC: MOV v8.16b, v0.16b         | V8 = val_3;//m1                         
            // 0x00AD05E0: CBNZ x19, #0xad05e8        | if (this._writer != null) goto label_10;
            if(val_52 != null)
            {
                goto label_10;
            }
            // 0x00AD05E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_10:
            // 0x00AD05E8: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD05EC: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00AD05F0: MOV v0.16b, v8.16b         | V0 = val_3;//m1                         
            // 0x00AD05F4: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1E0; X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1E8; //  | 
            // 0x00AD05F8: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1E0();
            // 0x00AD05FC: B #0xad1380                |  goto label_144;                        
            goto label_144;
            // 0x00AD0600: ADRP x9, #0x366a000        | X9 = 57057280 (0x366A000);              
            // 0x00AD0604: LDR x9, [x9, #0x6c8]       | X9 = 1152921504857804800;               
            // 0x00AD0608: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD060C: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonArray);
            // 0x00AD0610: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0614: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0618: CMP w10, w9                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD061C: B.LO #0xad14ec             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x00AD0620: LDR x10, [x8, #0xb0]       | X10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD0624: ADD x9, x10, x9, lsl #3    | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bson
            // 0x00AD0628: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD062C: CMP x9, x1                 | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonArray))
            // 0x00AD0630: B.NE #0xad14ec             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_13;
            // 0x00AD0634: LDR x21, [x19, #0x10]      | X21 = this._writer.OutStream; //P2      
            // 0x00AD0638: LDR w22, [x20, #0x18]      | W22 = t.<CalculatedSize>k__BackingField; //P2 
            // 0x00AD063C: CBNZ x21, #0xad0644        | if (this._writer.OutStream != null) goto label_14;
            if(this._writer.OutStream != null)
            {
                goto label_14;
            }
            // 0x00AD0640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer, ????);
            label_14:
            // 0x00AD0644: LDR x8, [x21]              | X8 = typeof(System.IO.Stream);          
            // 0x00AD0648: MOV x0, x21                | X0 = this._writer.OutStream;//m1        
            // 0x00AD064C: MOV w1, w22                | W1 = t.<CalculatedSize>k__BackingField;//m1
            // 0x00AD0650: LDR x9, [x8, #0x200]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_200;
            // 0x00AD0654: LDR x2, [x8, #0x208]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_208;
            // 0x00AD0658: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_200();
            // 0x00AD065C: MOV x0, x20                | X0 = t;//m1                             
            // 0x00AD0660: STR wzr, [sp, #0x44]       | stack[1152921513714037444] = 0x0;        //  dest_result_addr=1152921513714037444
            // 0x00AD0664: BL #0xacf878               | X0 = t.GetEnumerator();                 
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_5 = t.GetEnumerator();
            // 0x00AD0668: ADRP x24, #0x361c000       | X24 = 56737792 (0x361C000);             
            // 0x00AD066C: ADRP x25, #0x3634000       | X25 = 56836096 (0x3634000);             
            // 0x00AD0670: ADRP x26, #0x361d000       | X26 = 56741888 (0x361D000);             
            // 0x00AD0674: LDR x24, [x24, #0x358]     | X24 = 1152921504608018432;              
            // 0x00AD0678: LDR x25, [x25, #0x3b0]     | X25 = 1152921504608178176;              
            // 0x00AD067C: LDR x26, [x26, #0x518]     | X26 = 1152921504619892736;              
            // 0x00AD0680: MOV x20, x0                | X20 = val_5;//m1                        
            // 0x00AD0684: B #0xad0694                |  goto label_15;                         
            goto label_15;
            label_32:
            // 0x00AD0688: LDR w8, [sp, #0x44]        | W8 = 0x0;                               
            string val_53 = 0;
            // 0x00AD068C: ADD w8, w8, #1             | W8 = (0 + 1);                           
            val_53 = val_53 + 1;
            // 0x00AD0690: STR w8, [sp, #0x44]        | stack[1152921513714037444] = (0 + 1);    //  dest_result_addr=1152921513714037444
            label_15:
            // 0x00AD0694: CBNZ x20, #0xad069c        | if (val_5 != null) goto label_16;       
            if(val_5 != null)
            {
                goto label_16;
            }
            // 0x00AD0698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_16:
            // 0x00AD069C: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD06A0: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00AD06A4: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD06A8: CBZ x9, #0xad06d4          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_17;
            // 0x00AD06AC: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD06B0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_54 = 0;
            // 0x00AD06B4: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_19:
            // 0x00AD06B8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD06BC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00AD06C0: B.EQ #0xad06e4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_18;
            // 0x00AD06C4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_54 = val_54 + 1;
            // 0x00AD06C8: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD06CC: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD06D0: B.LO #0xad06b8             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_19;
            label_17:
            // 0x00AD06D4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AD06D8: MOV x0, x20                | X0 = val_5;//m1                         
            val_55 = val_5;
            // 0x00AD06DC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_5, ????);      
            // 0x00AD06E0: B #0xad06f4                |  goto label_20;                         
            goto label_20;
            label_18:
            // 0x00AD06E4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD06E8: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00AD06EC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00AD06F0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_20:
            // 0x00AD06F4: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);  //  | 
            // 0x00AD06F8: MOV x0, x20                | X0 = val_5;//m1                         
            // 0x00AD06FC: BLR x8                     | X0 = sub_1000000000145000( ?? val_5, ????);
            // 0x00AD0700: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_7 = val_5 & 1;
            // 0x00AD0704: TBZ w8, #0, #0xad12f0      | if (((val_5 & 1) & 0x1) == 0) goto label_21;
            if((val_7 & 1) == 0)
            {
                goto label_21;
            }
            // 0x00AD0708: CBNZ x20, #0xad0710        | if (val_5 != null) goto label_22;       
            if(val_5 != null)
            {
                goto label_22;
            }
            // 0x00AD070C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_22:
            // 0x00AD0710: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD0714: LDR x1, [x25]              | X1 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00AD0718: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD071C: CBZ x9, #0xad0748          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_23;
            // 0x00AD0720: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0724: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_55 = 0;
            // 0x00AD0728: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_25:
            // 0x00AD072C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0730: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IEnumerator<T>))
            // 0x00AD0734: B.EQ #0xad0758             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_24;
            // 0x00AD0738: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_55 = val_55 + 1;
            // 0x00AD073C: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0740: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0744: B.LO #0xad072c             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_25;
            label_23:
            // 0x00AD0748: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD074C: MOV x0, x20                | X0 = val_5;//m1                         
            val_56 = val_5;
            // 0x00AD0750: BL #0x2776c24              | X0 = sub_2776C24( ?? val_5, ????);      
            // 0x00AD0754: B #0xad0764                |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x00AD0758: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD075C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD0760: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_26:
            // 0x00AD0764: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);  //  | 
            // 0x00AD0768: MOV x0, x20                | X0 = val_5;//m1                         
            // 0x00AD076C: BLR x8                     | X0 = sub_1000000000145000( ?? val_5, ????);
            // 0x00AD0770: MOV x21, x0                | X21 = val_5;//m1                        
            // 0x00AD0774: LDR x22, [x19, #0x10]      | X22 = this._writer.OutStream; //P2      
            // 0x00AD0778: CBNZ x21, #0xad0780        | if (val_5 != null) goto label_27;       
            if(val_5 != null)
            {
                goto label_27;
            }
            // 0x00AD077C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_27:
            // 0x00AD0780: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD0784: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Collections.Generic.IEnumerator<T>).__il2cppRuntimeField_150; X1 = typeof(System.Collections.Generic.IEnumerator<T>).__il2cppRuntimeField_158; //  | 
            // 0x00AD0788: MOV x0, x21                | X0 = val_5;//m1                         
            // 0x00AD078C: BLR x9                     | X0 = typeof(System.Collections.Generic.IEnumerator<T>).__il2cppRuntimeField_150();
            // 0x00AD0790: MOV w23, w0                | W23 = val_5;//m1                        
            // 0x00AD0794: CBNZ x22, #0xad079c        | if (this._writer.OutStream != null) goto label_28;
            if(this._writer.OutStream != null)
            {
                goto label_28;
            }
            // 0x00AD0798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_28:
            // 0x00AD079C: LDR x8, [x22]              | X8 = typeof(System.IO.Stream);          
            // 0x00AD07A0: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x00AD07A4: LDR x2, [x8, #0x228]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x00AD07A8: MOV x0, x22                | X0 = this._writer.OutStream;//m1        
            // 0x00AD07AC: MOV w1, w23                | W1 = val_5;//m1                         
            // 0x00AD07B0: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x00AD07B4: LDR x0, [x26]              | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD07B8: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD07BC: TBZ w8, #0, #0xad07cc      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x00AD07C0: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD07C4: CBNZ w8, #0xad07cc         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x00AD07C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_30:
            // 0x00AD07CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD07D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD07D4: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_9 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD07D8: MOV x1, x0                 | X1 = val_9;//m1                         
            // 0x00AD07DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD07E0: ADD x0, sp, #0x44          | X0 = (1152921513714037376 + 68) = 1152921513714037444 (0x100000021ED4B2C4);
            // 0x00AD07E4: BL #0x1e63d74              | X0 = label_System_Int32_ToString_GL01E63D74();
            // 0x00AD07E8: MOV x22, x0                | X22 = 1152921513714037444 (0x100000021ED4B2C4);//ML01
            // 0x00AD07EC: LDR w1, [sp, #0x44]        | W1 = (0 + 1);                           
            // 0x00AD07F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD07F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD07F8: BL #0x291912c              | X0 = Newtonsoft.Json.Utilities.MathUtils.IntLength(i:  0);
            int val_10 = Newtonsoft.Json.Utilities.MathUtils.IntLength(i:  0);
            // 0x00AD07FC: MOV w2, w0                 | W2 = val_10;//m1                        
            // 0x00AD0800: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD0804: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00AD0808: MOV x1, x22                | X1 = 1152921513714037444 (0x100000021ED4B2C4);//ML01
            // 0x00AD080C: BL #0xad1848               | this._writer.WriteString(s:  0, byteCount:  val_10, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            val_52.WriteString(s:  val_53, byteCount:  val_10, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            // 0x00AD0810: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00AD0814: MOV x1, x21                | X1 = val_5;//m1                         
            // 0x00AD0818: BL #0xad0484               |  R0 = label_84();                       
            // 0x00AD081C: B #0xad0688                |  goto label_32;                         
            goto label_32;
            // 0x00AD0820: MOV x21, x0                | X21 = this._writer;//m1                 
            val_57 = val_52;
            // 0x00AD0824: CMP w1, #1                 | STATE = COMPARE(val_5, 0x1)             
            // 0x00AD0828: B.NE #0xad16fc             | if (val_5 != 0x1) goto label_86;        
            if(val_5 != 1)
            {
                goto label_86;
            }
            // 0x00AD082C: MOV x0, x21                | X0 = this._writer;//m1                  
            // 0x00AD0830: BL #0x981060               | X0 = sub_981060( ?? this._writer, ????);
            // 0x00AD0834: LDR x21, [x0]              | X21 = typeof(System.IO.BinaryWriter);   
            // 0x00AD0838: BL #0x980920               | X0 = sub_980920( ?? this._writer, ????);
            // 0x00AD083C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            label_146:
            // 0x00AD0840: CBZ x20, #0xad11ac         | if (val_5 == null) goto label_34;       
            if(val_5 == null)
            {
                goto label_34;
            }
            // 0x00AD0844: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00AD0848: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD084C: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00AD0850: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00AD0854: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD0858: CBZ x9, #0xad0884          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_35;
            // 0x00AD085C: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0860: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_56 = 0;
            // 0x00AD0864: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_37:
            // 0x00AD0868: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD086C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00AD0870: B.EQ #0xad1194             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_36;
            // 0x00AD0874: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_56 = val_56 + 1;
            // 0x00AD0878: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD087C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0880: B.LO #0xad0868             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_37;
            label_35:
            // 0x00AD0884: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD0888: MOV x0, x20                | X0 = val_5;//m1                         
            val_58 = val_5;
            // 0x00AD088C: BL #0x2776c24              | X0 = sub_2776C24( ?? val_5, ????);      
            // 0x00AD0890: B #0xad11a0                |  goto label_38;                         
            goto label_38;
            // 0x00AD0894: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x00AD0898: LDR x9, [x9, #0x98]        | X9 = 1152921504857964544;               
            // 0x00AD089C: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD08A0: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonRegex);
            // 0x00AD08A4: LDRB w10, [x8, #0x104]     | W10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD08A8: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD08AC: CMP w10, w9                | STATE = COMPARE(System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD08B0: B.LO #0xad08c8             | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) goto label_39;
            // 0x00AD08B4: LDR x10, [x8, #0xb0]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD08B8: ADD x9, x10, x9, lsl #3    | X9 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Jso
            // 0x00AD08BC: LDUR x9, [x9, #-8]         | X9 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD08C0: CMP x9, x1                 | STATE = COMPARE((System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonRegex))
            // 0x00AD08C4: B.EQ #0xad11ec             | if ((System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_40;
            label_39:
            // 0x00AD08C8: LDR x0, [x8, #0x30]        | X0 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_element_class;
            // 0x00AD08CC: SUB x8, x29, #0x78         | X8 = (1152921513714037696 - 120) = 1152921513714037576 (0x100000021ED4B348);
            // 0x00AD08D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_element_class, ????);
            // 0x00AD08D4: LDR x0, [x23, #0x40]       | 
            // 0x00AD08D8: BL #0x27af090              | X0 = sub_27AF090( ?? System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_element_class, ????);
            // 0x00AD08DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD08E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_element_class, ????);
            // 0x00AD08E4: SUB x0, x29, #0x78         | X0 = (1152921513714037696 - 120) = 1152921513714037576 (0x100000021ED4B348);
            // 0x00AD08E8: BL #0x299a140              | 
            // 0x00AD08EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B348, ????);
            // 0x00AD08F0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00AD08F4: ORR w24, wzr, #1           | W24 = 1(0x1);                           
            val_60 = 1;
            // 0x00AD08F8: B #0xad11f0                |  goto label_41;                         
            goto label_41;
            // 0x00AD08FC: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD0900: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD0904: LDR x8, [x20]              | X8 = 0x10102464C457F;                   
            val_61 = 1179403647;
            // 0x00AD0908: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD090C: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00AD0910: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0914: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0918: B.LO #0xad1514             | if (mem[282584257676931] < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_43;
            // 0x00AD091C: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00AD0920: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth
            // 0x00AD0924: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0928: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD092C: B.NE #0xad1514             | if ((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_43;
            // 0x00AD0930: LDR x21, [x20, #0x20]      | X21 = 0x40;                             
            // 0x00AD0934: CBZ x21, #0xad10d4         | if (0x40 == 0) goto label_44;           
            if(64 == 0)
            {
                goto label_44;
            }
            // 0x00AD0938: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00AD093C: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00AD0940: MOV x0, x21                | X0 = 64 (0x40);//ML01                   
            // 0x00AD0944: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
            // 0x00AD0948: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD094C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x40, ????);       
            // 0x00AD0950: MOV x20, x0                | X20 = 64 (0x40);//ML01                  
            val_62 = 64;
            // 0x00AD0954: CBZ x20, #0xad10a8         | if (0x40 == 0) goto label_45;           
            if(val_62 == 0)
            {
                goto label_45;
            }
            // 0x00AD0958: LDR x21, [x19, #0x10]!     | X21 = this._writer.OutStream; //P2      
            val_63 = this._writer.OutStream;
            // 0x00AD095C: MOV x22, x20               | X22 = 64 (0x40);//ML01                  
            val_64 = val_62;
            // 0x00AD0960: B #0xad10e4                |  goto label_46;                         
            goto label_46;
            // 0x00AD0964: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD0968: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD096C: LDR x8, [x20]              | X8 = 0x500000001;                       
            val_65 = 1;
            // 0x00AD0970: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD0974: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[21474836741];           
            // 0x00AD0978: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD097C: CMP w10, w9                | STATE = COMPARE(mem[21474836741], Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0980: B.LO #0xad153c             | if (mem[21474836741] < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_48;
            // 0x00AD0984: LDR x10, [x8, #0xb0]       | X10 = mem[21474836657];                 
            // 0x00AD0988: ADD x9, x10, x9, lsl #3    | X9 = (mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) <<
            // 0x00AD098C: LDUR x9, [x9, #-8]         | X9 = (mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0990: CMP x9, x1                 | STATE = COMPARE((mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD0994: B.NE #0xad153c             | if ((mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_48;
            // 0x00AD0998: LDR x0, [x20, #0x20]       | X0 = 0x33644C8;                         
            val_66 = 53888200;
            // 0x00AD099C: CBZ x0, #0xad0fdc          | if (0x33644C8 == 0) goto label_49;      
            if(val_66 == 0)
            {
                goto label_49;
            }
            // 0x00AD09A0: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00AD09A4: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x00AD09A8: LDR x9, [x8]               | X9 = typeof(System.DateTime);           
            // 0x00AD09AC: LDR x8, [x0]               | X8 = 0x98150C;                          
            val_67 = 9966860;
            // 0x00AD09B0: CMP x8, x9                 | STATE = COMPARE(0x98150C, typeof(System.DateTime))
            // 0x00AD09B4: B.EQ #0xad1140             | if (val_67 == null) goto label_50;      
            if(val_67 == null)
            {
                goto label_50;
            }
            // 0x00AD09B8: ADRP x9, #0x35cd000        | X9 = 56414208 (0x35CD000);              
            // 0x00AD09BC: LDR x9, [x9, #0x6a8]       | X9 = 1152921504652853248;               
            // 0x00AD09C0: LDR x20, [x9]              | X20 = typeof(System.DateTimeOffset);    
            val_68 = null;
            // 0x00AD09C4: B #0xad0ff0                |  goto label_51;                         
            goto label_51;
            // 0x00AD09C8: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD09CC: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD09D0: LDR x8, [x20]              | X8 = ;                                  
            val_69 = new System.DateTimeOffset();
            // 0x00AD09D4: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD09D8: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00AD09DC: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD09E0: CMP w10, w9                | STATE = COMPARE(mem[val_69 + 260], Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD09E4: B.LO #0xad1564             | if (mem[val_69 + 260] < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_53;
            // 0x00AD09E8: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00AD09EC: ADD x9, x10, x9, lsl #3    | X9 = (mem[val_69 + 176] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) <
            // 0x00AD09F0: LDUR x9, [x9, #-8]         | X9 = (mem[val_69 + 176] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD09F4: CMP x9, x1                 | STATE = COMPARE((mem[val_69 + 176] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD09F8: B.NE #0xad1564             | if ((mem[val_69 + 176] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_53;
            // 0x00AD09FC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD0A00: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD0A04: LDR x19, [x19, #0x10]      | X19 = this._writer + 16 + 16;           
            val_52 = mem[this._writer + 16 + 16];
            val_52 = this._writer + 16 + 16;
            // 0x00AD0A08: LDR x20, [x20, #0x20]      | X20 = System.DateTimeOffset.__il2cppRuntimeField_byval_arg;
            // 0x00AD0A0C: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD0A10: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD0A14: TBZ w8, #0, #0xad0a24      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_55;
            // 0x00AD0A18: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD0A1C: CBNZ w8, #0xad0a24         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
            // 0x00AD0A20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_55:
            // 0x00AD0A24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0A28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0A2C: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_15 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD0A30: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AD0A34: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00AD0A38: MOV x21, x0                | X21 = val_15;//m1                       
            val_51 = val_15;
            // 0x00AD0A3C: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x00AD0A40: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00AD0A44: TBZ w9, #0, #0xad0a58      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_57;
            // 0x00AD0A48: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD0A4C: CBNZ w9, #0xad0a58         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
            // 0x00AD0A50: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x00AD0A54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_57:
            // 0x00AD0A58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0A5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD0A60: MOV x1, x20                | X1 = System.DateTimeOffset.__il2cppRuntimeField_byval_arg;//m1
            // 0x00AD0A64: MOV x2, x21                | X2 = val_15;//m1                        
            // 0x00AD0A68: BL #0x1ba6ec0              | X0 = System.Convert.ToInt64(value:  0, provider:  System.DateTimeOffset.__il2cppRuntimeField_byval_arg);
            long val_16 = System.Convert.ToInt64(value:  0, provider:  System.DateTimeOffset.__il2cppRuntimeField_byval_arg);
            // 0x00AD0A6C: MOV x20, x0                | X20 = val_16;//m1                       
            val_62 = val_16;
            // 0x00AD0A70: CBNZ x19, #0xad1368        | if (this._writer + 16 + 16 != 0) goto label_150;
            if(val_52 != 0)
            {
                goto label_150;
            }
            // 0x00AD0A74: B #0xad1364                |  goto label_59;                         
            goto label_59;
            // 0x00AD0A78: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00AD0A7C: LDR x9, [x9, #0xcd8]       | X9 = 1152921504857751552;               
            // 0x00AD0A80: LDR x8, [x20]              | X8 = val_16;                            
            val_70 = mem[val_16];
            val_70 = val_62;
            // 0x00AD0A84: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonObject);
            // 0x00AD0A88: LDRB w10, [x8, #0x104]     | W10 = val_16 + 260;                     
            // 0x00AD0A8C: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0A90: CMP w10, w9                | STATE = COMPARE(val_16 + 260, Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0A94: B.LO #0xad158c             | if (val_16 + 260 < Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_61;
            // 0x00AD0A98: LDR x10, [x8, #0xb0]       | X10 = val_16 + 176;                     
            // 0x00AD0A9C: ADD x9, x10, x9, lsl #3    | X9 = (val_16 + 176 + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3)
            // 0x00AD0AA0: LDUR x9, [x9, #-8]         | X9 = (val_16 + 176 + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0AA4: CMP x9, x1                 | STATE = COMPARE((val_16 + 176 + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonObject))
            // 0x00AD0AA8: B.NE #0xad158c             | if ((val_16 + 176 + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_61;
            // 0x00AD0AAC: LDR x21, [x19, #0x10]      | X21 = this._writer + 16 + 16 + 16;      
            // 0x00AD0AB0: LDR w22, [x20, #0x18]      | W22 = val_16 + 24;                      
            // 0x00AD0AB4: CBNZ x21, #0xad0abc        | if (this._writer + 16 + 16 + 16 != 0) goto label_62;
            if((this._writer + 16 + 16 + 16) != 0)
            {
                goto label_62;
            }
            // 0x00AD0AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_62:
            // 0x00AD0ABC: LDR x8, [x21]              | X8 = this._writer + 16 + 16 + 16;       
            // 0x00AD0AC0: MOV x0, x21                | X0 = this._writer + 16 + 16 + 16;//m1   
            // 0x00AD0AC4: MOV w1, w22                | W1 = val_16 + 24;//m1                   
            // 0x00AD0AC8: LDR x9, [x8, #0x200]       | X9 = this._writer + 16 + 16 + 16 + 512; 
            // 0x00AD0ACC: LDR x2, [x8, #0x208]       | X2 = this._writer + 16 + 16 + 16 + 520; 
            // 0x00AD0AD0: BLR x9                     | X0 = this._writer + 16 + 16 + 16 + 512();
            // 0x00AD0AD4: MOV x0, x20                | X0 = val_16;//m1                        
            // 0x00AD0AD8: BL #0xad1798               | X0 = val_16.GetEnumerator();            
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty> val_18 = val_62.GetEnumerator();
            // 0x00AD0ADC: ADRP x24, #0x361c000       | X24 = 56737792 (0x361C000);             
            // 0x00AD0AE0: ADRP x25, #0x3661000       | X25 = 57020416 (0x3661000);             
            // 0x00AD0AE4: ADRP x26, #0x35d6000       | X26 = 56451072 (0x35D6000);             
            // 0x00AD0AE8: LDR x24, [x24, #0x358]     | X24 = 1152921504608018432;              
            // 0x00AD0AEC: LDR x25, [x25, #0x230]     | X25 = 1152921504608178176;              
            // 0x00AD0AF0: LDR x26, [x26, #0xe38]     | X26 = 1152921504608284672;              
            // 0x00AD0AF4: MOV x20, x0                | X20 = val_18;//m1                       
            label_85:
            // 0x00AD0AF8: CBNZ x20, #0xad0b00        | if (val_18 != null) goto label_63;      
            if(val_18 != null)
            {
                goto label_63;
            }
            // 0x00AD0AFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_63:
            // 0x00AD0B00: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00AD0B04: LDR x1, [x24]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00AD0B08: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD0B0C: CBZ x9, #0xad0b38          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_64;
            // 0x00AD0B10: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0B14: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_57 = 0;
            // 0x00AD0B18: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_66:
            // 0x00AD0B1C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0B20: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00AD0B24: B.EQ #0xad0b48             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_65;
            // 0x00AD0B28: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_57 = val_57 + 1;
            // 0x00AD0B2C: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0B30: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0B34: B.LO #0xad0b1c             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_66;
            label_64:
            // 0x00AD0B38: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AD0B3C: MOV x0, x20                | X0 = val_18;//m1                        
            val_71 = val_18;
            // 0x00AD0B40: BL #0x2776c24              | X0 = sub_2776C24( ?? val_18, ????);     
            // 0x00AD0B44: B #0xad0b58                |  goto label_67;                         
            goto label_67;
            label_65:
            // 0x00AD0B48: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD0B4C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00AD0B50: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00AD0B54: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_67:
            // 0x00AD0B58: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);  //  | 
            // 0x00AD0B5C: MOV x0, x20                | X0 = val_18;//m1                        
            // 0x00AD0B60: BLR x8                     | X0 = sub_1000000000145000( ?? val_18, ????);
            // 0x00AD0B64: AND w8, w0, #1             | W8 = (val_18 & 1);                      
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty> val_20 = val_18 & 1;
            // 0x00AD0B68: TBZ w8, #0, #0xad12e4      | if (((val_18 & 1) & 0x1) == 0) goto label_68;
            if((val_20 & 1) == 0)
            {
                goto label_68;
            }
            // 0x00AD0B6C: CBNZ x20, #0xad0b74        | if (val_18 != null) goto label_69;      
            if(val_18 != null)
            {
                goto label_69;
            }
            // 0x00AD0B70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_69:
            // 0x00AD0B74: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00AD0B78: LDR x1, [x25]              | X1 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00AD0B7C: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD0B80: CBZ x9, #0xad0bac          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_70;
            // 0x00AD0B84: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0B88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_58 = 0;
            // 0x00AD0B8C: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_72:
            // 0x00AD0B90: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0B94: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IEnumerator<T>))
            // 0x00AD0B98: B.EQ #0xad0bbc             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_71;
            // 0x00AD0B9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_58 = val_58 + 1;
            // 0x00AD0BA0: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0BA4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0BA8: B.LO #0xad0b90             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_72;
            label_70:
            // 0x00AD0BAC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD0BB0: MOV x0, x20                | X0 = val_18;//m1                        
            val_72 = val_18;
            // 0x00AD0BB4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_18, ????);     
            // 0x00AD0BB8: B #0xad0bc8                |  goto label_73;                         
            goto label_73;
            label_71:
            // 0x00AD0BBC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD0BC0: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD0BC4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_73:
            // 0x00AD0BC8: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);  //  | 
            // 0x00AD0BCC: MOV x0, x20                | X0 = val_18;//m1                        
            // 0x00AD0BD0: BLR x8                     | X0 = sub_1000000000145000( ?? val_18, ????);
            // 0x00AD0BD4: MOV x21, x0                | X21 = val_18;//m1                       
            // 0x00AD0BD8: LDR x22, [x19, #0x10]      | X22 = this._writer + 16 + 16 + 16;      
            // 0x00AD0BDC: CBNZ x21, #0xad0be4        | if (val_18 != null) goto label_74;      
            if(val_18 != null)
            {
                goto label_74;
            }
            // 0x00AD0BE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_74:
            // 0x00AD0BE4: LDR x23, [x21, #0x18]      | 
            // 0x00AD0BE8: CBNZ x23, #0xad0bf0        | if (val_5 != null) goto label_75;       
            if(val_5 != null)
            {
                goto label_75;
            }
            // 0x00AD0BEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_75:
            // 0x00AD0BF0: LDR x8, [x23]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD0BF4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(System.Collections.Generic.IEnumerator<T>).__il2cppRuntimeField_150; X1 = typeof(System.Collections.Generic.IEnumerator<T>).__il2cppRuntimeField_158; //  | 
            // 0x00AD0BF8: MOV x0, x23                | X0 = val_5;//m1                         
            // 0x00AD0BFC: BLR x9                     | X0 = typeof(System.Collections.Generic.IEnumerator<T>).__il2cppRuntimeField_150();
            // 0x00AD0C00: MOV w23, w0                | W23 = val_5;//m1                        
            // 0x00AD0C04: CBNZ x22, #0xad0c0c        | if (this._writer + 16 + 16 + 16 != 0) goto label_76;
            if((this._writer + 16 + 16 + 16) != 0)
            {
                goto label_76;
            }
            // 0x00AD0C08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_76:
            // 0x00AD0C0C: LDR x8, [x22]              | X8 = this._writer + 16 + 16 + 16;       
            // 0x00AD0C10: LDR x9, [x8, #0x220]       | X9 = this._writer + 16 + 16 + 16 + 544; 
            // 0x00AD0C14: LDR x2, [x8, #0x228]       | X2 = this._writer + 16 + 16 + 16 + 552; 
            // 0x00AD0C18: MOV x0, x22                | X0 = this._writer + 16 + 16 + 16;//m1   
            // 0x00AD0C1C: MOV w1, w23                | W1 = val_5;//m1                         
            // 0x00AD0C20: BLR x9                     | X0 = this._writer + 16 + 16 + 16 + 544();
            // 0x00AD0C24: CBNZ x21, #0xad0c2c        | if (val_18 != null) goto label_77;      
            if(val_18 != null)
            {
                goto label_77;
            }
            // 0x00AD0C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer + 16 + 16 + 16, ????);
            label_77:
            // 0x00AD0C2C: LDR x22, [x21, #0x10]      | 
            // 0x00AD0C30: CBZ x22, #0xad0c3c         | if (this._writer + 16 + 16 + 16 == 0) goto label_78;
            if((this._writer + 16 + 16 + 16) == 0)
            {
                goto label_78;
            }
            // 0x00AD0C34: LDR x23, [x22, #0x20]      | X23 = this._writer + 16 + 16 + 16 + 32; 
            val_74 = mem[this._writer + 16 + 16 + 16 + 32];
            val_74 = this._writer + 16 + 16 + 16 + 32;
            // 0x00AD0C38: B #0xad0c5c                |  goto label_81;                         
            goto label_81;
            label_78:
            // 0x00AD0C3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer + 16 + 16 + 16, ????);
            // 0x00AD0C40: LDR x8, [x21, #0x10]       | 
            // 0x00AD0C44: LDR x23, [x22, #0x20]      | X23 = this._writer + 16 + 16 + 16 + 32; 
            val_74 = mem[this._writer + 16 + 16 + 16 + 32];
            val_74 = this._writer + 16 + 16 + 16 + 32;
            // 0x00AD0C48: CBZ x8, #0xad0c54          | if (this._writer + 16 + 16 + 16 == 0) goto label_80;
            if((this._writer + 16 + 16 + 16) == 0)
            {
                goto label_80;
            }
            // 0x00AD0C4C: MOV x22, x8                | X22 = this._writer + 16 + 16 + 16;//m1  
            val_73 = this._writer + 16 + 16 + 16;
            // 0x00AD0C50: B #0xad0c5c                |  goto label_81;                         
            goto label_81;
            label_80:
            // 0x00AD0C54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer + 16 + 16 + 16, ????);
            // 0x00AD0C58: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_73 = 0;
            label_81:
            // 0x00AD0C5C: LDR w22, [x22, #0x2c]      | W22 = 0x0;                              
            // 0x00AD0C60: CBZ x23, #0xad0c98         | if (this._writer + 16 + 16 + 16 + 32 == 0) goto label_82;
            if(val_74 == 0)
            {
                goto label_82;
            }
            // 0x00AD0C64: LDR x1, [x26]              | X1 = typeof(System.String);             
            // 0x00AD0C68: LDR x8, [x23]              | X8 = this._writer + 16 + 16 + 16 + 32;  
            // 0x00AD0C6C: CMP x8, x1                 | STATE = COMPARE(this._writer + 16 + 16 + 16 + 32, typeof(System.String))
            // 0x00AD0C70: B.EQ #0xad0c9c             | if (val_74 == null) goto label_83;      
            if(val_74 == null)
            {
                goto label_83;
            }
            // 0x00AD0C74: LDR x0, [x8, #0x30]        | X0 = this._writer + 16 + 16 + 16 + 32 + 48;
            // 0x00AD0C78: ADD x8, sp, #0x50          | X8 = (1152921513714037376 + 80) = 1152921513714037456 (0x100000021ED4B2D0);
            // 0x00AD0C7C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? this._writer + 16 + 16 + 16 + 32 + 48, ????);
            // 0x00AD0C80: LDR x0, [sp, #0x50]        | X0 = val_22;                             //  find_add[1152921513714025712]
            // 0x00AD0C84: BL #0x27af090              | X0 = sub_27AF090( ?? val_22, ????);     
            // 0x00AD0C88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0C8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            // 0x00AD0C90: ADD x0, sp, #0x50          | X0 = (1152921513714037376 + 80) = 1152921513714037456 (0x100000021ED4B2D0);
            // 0x00AD0C94: BL #0x299a140              | 
            label_82:
            // 0x00AD0C98: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_74 = 0;
            label_83:
            // 0x00AD0C9C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD0CA0: MOV x0, x19                | X0 = this._writer + 16 + 16;//m1        
            // 0x00AD0CA4: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0CA8: MOV w2, w22                | W2 = 0 (0x0);//ML01                     
            // 0x00AD0CAC: BL #0xad1848               | this._writer + 16 + 16.WriteString(s:  val_74, byteCount:  0, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            val_52.WriteString(s:  val_74, byteCount:  0, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            // 0x00AD0CB0: LDR x1, [x21, #0x18]       | 
            // 0x00AD0CB4: MOV x0, x19                | X0 = this._writer + 16 + 16;//m1        
            // 0x00AD0CB8: BL #0xad0484               |  R0 = label_84();                       
            // 0x00AD0CBC: B #0xad0af8                |  goto label_85;                         
            goto label_85;
            // 0x00AD0CC0: MOV x22, x1                | X22 = 0 (0x0);//ML01                    
            // 0x00AD0CC4: MOV x21, x0                | X21 = this._writer + 16 + 16;//m1       
            val_57 = val_52;
            label_151:
            // 0x00AD0CC8: CMP w22, #1                | STATE = COMPARE(0x0, 0x1)               
            // 0x00AD0CCC: B.NE #0xad16fc             | if (val_74 != 0x1) goto label_86;       
            if(val_74 != 1)
            {
                goto label_86;
            }
            // 0x00AD0CD0: MOV x0, x21                | X0 = this._writer + 16 + 16;//m1        
            // 0x00AD0CD4: BL #0x981060               | X0 = sub_981060( ?? this._writer + 16 + 16, ????);
            // 0x00AD0CD8: LDR x21, [x0]              | X21 = this._writer + 16 + 16;           
            val_51 = mem[this._writer + 16 + 16];
            val_51 = val_57;
            // 0x00AD0CDC: BL #0x980920               | X0 = sub_980920( ?? this._writer + 16 + 16, ????);
            // 0x00AD0CE0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            label_145:
            // 0x00AD0CE4: CBZ x20, #0xad1188         | if (val_18 == null) goto label_87;      
            if(val_18 == null)
            {
                goto label_87;
            }
            // 0x00AD0CE8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00AD0CEC: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00AD0CF0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00AD0CF4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00AD0CF8: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD0CFC: CBZ x9, #0xad0d28          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_88;
            // 0x00AD0D00: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0D04: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_59 = 0;
            // 0x00AD0D08: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_90:
            // 0x00AD0D0C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0D10: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00AD0D14: B.EQ #0xad1170             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_89;
            // 0x00AD0D18: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_59 = val_59 + 1;
            // 0x00AD0D1C: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0D20: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0D24: B.LO #0xad0d0c             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_90;
            label_88:
            // 0x00AD0D28: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD0D2C: MOV x0, x20                | X0 = val_18;//m1                        
            val_75 = val_18;
            // 0x00AD0D30: BL #0x2776c24              | X0 = sub_2776C24( ?? val_18, ????);     
            // 0x00AD0D34: B #0xad117c                |  goto label_91;                         
            goto label_91;
            // 0x00AD0D38: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00AD0D3C: LDR x9, [x9, #0x188]       | X9 = 1152921504857911296;               
            // 0x00AD0D40: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00AD0D44: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00AD0D48: LDRB w10, [x8, #0x104]     | W10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0D4C: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0D50: CMP w10, w9                | STATE = COMPARE(System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0D54: B.LO #0xad15dc             | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) goto label_93;
            // 0x00AD0D58: LDR x10, [x8, #0xb0]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD0D5C: ADD x9, x10, x9, lsl #3    | X9 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Jso
            // 0x00AD0D60: LDUR x9, [x9, #-8]         | X9 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0D64: CMP x9, x1                 | STATE = COMPARE((System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonString))
            // 0x00AD0D68: B.NE #0xad15dc             | if ((System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_93;
            // 0x00AD0D6C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00AD0D70: LDR x22, [x20, #0x20]      | 
            // 0x00AD0D74: LDR w21, [x20, #0x2c]      | 
            // 0x00AD0D78: LDR w8, [x20, #0x18]       | 
            // 0x00AD0D7C: LDR x9, [x9, #0x4c0]       | X9 = 1152921509457528368;               
            // 0x00AD0D80: ADD x0, sp, #8             | X0 = (1152921513714037376 + 8) = 1152921513714037384 (0x100000021ED4B288);
            // 0x00AD0D84: STR xzr, [sp, #8]          | stack[1152921513714037384] = 0x0;        //  dest_result_addr=1152921513714037384
            // 0x00AD0D88: SUB w1, w8, #4             | W1 = (1152921504608178176 - 4) = 1152921504608178172 (0x1000000000144FFC);
            // 0x00AD0D8C: LDR x2, [x9]               | X2 = public System.Void System.Nullable<System.Int32>::.ctor(System.Int32 value);
            // 0x00AD0D90: BL #0x1d6c16c              | X0 = sub_1D6C16C( ?? 0x100000021ED4B288, ????);
            // 0x00AD0D94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_77 = 0;
            // 0x00AD0D98: CBZ x22, #0xad0de0         | if (0x0 == 0) goto label_95;            
            if(0 == 0)
            {
                goto label_95;
            }
            // 0x00AD0D9C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00AD0DA0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00AD0DA4: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00AD0DA8: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00AD0DAC: CMP x8, x1                 | STATE = COMPARE(0x10102464C457F, typeof(System.String))
            // 0x00AD0DB0: MOV x2, x22                | X2 = 0 (0x0);//ML01                     
            val_77 = 0;
            // 0x00AD0DB4: B.EQ #0xad0de0             | if (1179403647 == null) goto label_95;  
            if(1179403647 == null)
            {
                goto label_95;
            }
            // 0x00AD0DB8: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00AD0DBC: ADD x8, sp, #0x80          | X8 = (1152921513714037376 + 128) = 1152921513714037504 (0x100000021ED4B300);
            // 0x00AD0DC0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00AD0DC4: LDR x0, [sp, #0x80]        | X0 = val_24;                             //  find_add[1152921513714025712]
            // 0x00AD0DC8: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
            // 0x00AD0DCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0DD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x00AD0DD4: ADD x0, sp, #0x80          | X0 = (1152921513714037376 + 128) = 1152921513714037504 (0x100000021ED4B300);
            // 0x00AD0DD8: BL #0x299a140              | 
            // 0x00AD0DDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            val_77 = 0;
            label_95:
            // 0x00AD0DE0: LDR x3, [sp, #8]           | X3 = 0x0;                               
            val_78 = 0;
            // 0x00AD0DE4: MOV x0, x19                | X0 = this._writer + 16 + 16;//m1        
            // 0x00AD0DE8: MOV x1, x2                 | X1 = 0 (0x0);//ML01                     
            val_79 = val_77;
            // 0x00AD0DEC: MOV w2, w21                | W2 = this._writer + 16 + 16;//m1        
            val_80 = val_51;
            // 0x00AD0DF0: B #0xad12dc                |  goto label_96;                         
            goto label_96;
            // 0x00AD0DF4: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD0DF8: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD0DFC: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00AD0E00: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD0E04: LDRB w10, [x8, #0x104]     | W10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0E08: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0E0C: CMP w10, w9                | STATE = COMPARE(System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0E10: B.LO #0xad160c             | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_98;
            // 0x00AD0E14: LDR x10, [x8, #0xb0]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy;
            // 0x00AD0E18: ADD x9, x10, x9, lsl #3    | X9 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Jso
            // 0x00AD0E1C: LDUR x9, [x9, #-8]         | X9 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0E20: CMP x9, x1                 | STATE = COMPARE((System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD0E24: B.NE #0xad160c             | if ((System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_98;
            // 0x00AD0E28: LDR x22, [x20, #0x20]      | 
            // 0x00AD0E2C: CBZ x22, #0xad0e7c         | if (0x0 == 0) goto label_99;            
            if(0 == 0)
            {
                goto label_99;
            }
            // 0x00AD0E30: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00AD0E34: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00AD0E38: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0E3C: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
            val_51 = null;
            // 0x00AD0E40: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD0E44: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x0, ????);        
            // 0x00AD0E48: MOV x20, x0                | X20 = 0 (0x0);//ML01                    
            val_62 = 0;
            // 0x00AD0E4C: CBNZ x20, #0xad0e80        | if (0x0 != 0) goto label_100;           
            if(val_62 != 0)
            {
                goto label_100;
            }
            // 0x00AD0E50: LDR x8, [x22]              | X8 = 0x10102464C457F;                   
            // 0x00AD0E54: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD0E58: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00AD0E5C: SUB x8, x29, #0x80         | X8 = (1152921513714037696 - 128) = 1152921513714037568 (0x100000021ED4B340);
            // 0x00AD0E60: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00AD0E64: LDR x0, [x23, #0x38]       | X0 = 0x19001A00400006;                  
            // 0x00AD0E68: BL #0x27af090              | X0 = sub_27AF090( ?? 0x19001A00400006, ????);
            // 0x00AD0E6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0E70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x19001A00400006, ????);
            // 0x00AD0E74: SUB x0, x29, #0x80         | X0 = (1152921513714037696 - 128) = 1152921513714037568 (0x100000021ED4B340);
            // 0x00AD0E78: BL #0x299a140              | 
            label_99:
            // 0x00AD0E7C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_62 = 0;
            label_100:
            // 0x00AD0E80: LDR x19, [x19, #0x10]      | X19 = this._writer + 16 + 16 + 16;      
            val_52 = mem[this._writer + 16 + 16 + 16];
            val_52 = this._writer + 16 + 16 + 16;
            // 0x00AD0E84: CBNZ x19, #0xad1130        | if (this._writer + 16 + 16 + 16 != 0) goto label_124;
            if(val_52 != 0)
            {
                goto label_124;
            }
            // 0x00AD0E88: B #0xad112c                |  goto label_102;                        
            goto label_102;
            // 0x00AD0E8C: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD0E90: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD0E94: LDR x8, [x20]              | X8 = 0x10102464C457F;                   
            val_82 = 1179403647;
            // 0x00AD0E98: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD0E9C: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00AD0EA0: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0EA4: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0EA8: B.LO #0xad1634             | if (mem[282584257676931] < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_104;
            // 0x00AD0EAC: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00AD0EB0: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth
            // 0x00AD0EB4: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0EB8: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD0EBC: B.NE #0xad1634             | if ((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_104;
            // 0x00AD0EC0: LDR x19, [x19, #0x10]      | X19 = this._writer + 16 + 16 + 16 + 16; 
            val_52 = mem[this._writer + 16 + 16 + 16 + 16];
            val_52 = this._writer + 16 + 16 + 16 + 16;
            // 0x00AD0EC4: LDR x20, [x20, #0x20]      | X20 = 0x40;                             
            // 0x00AD0EC8: CBNZ x19, #0xad0ed0        | if (this._writer + 16 + 16 + 16 + 16 != 0) goto label_105;
            if(val_52 != 0)
            {
                goto label_105;
            }
            // 0x00AD0ECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B340, ????);
            label_105:
            // 0x00AD0ED0: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00AD0ED4: LDR x8, [x8, #0x7d8]       | X8 = 1152921504608604160;               
            // 0x00AD0ED8: LDR x21, [x8]              | X21 = typeof(System.Boolean);           
            val_51 = null;
            // 0x00AD0EDC: CBNZ x20, #0xad0ee4        | if (0x40 != 0) goto label_106;          
            if(64 != 0)
            {
                goto label_106;
            }
            // 0x00AD0EE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B340, ????);
            label_106:
            // 0x00AD0EE4: LDR x8, [x20]              | X8 = 0x500000001;                       
            // 0x00AD0EE8: LDR x0, [x8, #0x30]        | X0 = mem[21474836529];                  
            // 0x00AD0EEC: LDR x8, [x21, #0x30]       | X8 = System.Boolean.__il2cppRuntimeField_element_class;
            // 0x00AD0EF0: CMP x0, x8                 | STATE = COMPARE(mem[21474836529], System.Boolean.__il2cppRuntimeField_element_class)
            // 0x00AD0EF4: B.NE #0xad1690             | if (mem[21474836529] != System.Boolean.__il2cppRuntimeField_element_class) goto label_107;
            // 0x00AD0EF8: MOV x0, x20                | X0 = 64 (0x40);//ML01                   
            // 0x00AD0EFC: BL #0x27bc4e8              | 64.System.IDisposable.Dispose();        
            64.System.IDisposable.Dispose();
            // 0x00AD0F00: LDR x8, [x19]              | X8 = this._writer + 16 + 16 + 16 + 16;  
            // 0x00AD0F04: LDP x9, x2, [x8, #0x1a0]   | X9 = this._writer + 16 + 16 + 16 + 16 + 416; X2 = this._writer + 16 + 16 + 16 + 16 + 416 + 8; //  | 
            // 0x00AD0F08: LDRB w1, [x0]              | W1 = 0x1;                               
            // 0x00AD0F0C: B #0xad11e0                |  goto label_108;                        
            goto label_108;
            // 0x00AD0F10: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00AD0F14: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00AD0F18: LDR x8, [x20]              | X8 = 0x500000001;                       
            val_83 = 1;
            // 0x00AD0F1C: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00AD0F20: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[21474836741];           
            // 0x00AD0F24: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00AD0F28: CMP w10, w9                | STATE = COMPARE(mem[21474836741], Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00AD0F2C: B.LO #0xad165c             | if (mem[21474836741] < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_110;
            // 0x00AD0F30: LDR x10, [x8, #0xb0]       | X10 = mem[21474836657];                 
            // 0x00AD0F34: ADD x9, x10, x9, lsl #3    | X9 = (mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) <<
            // 0x00AD0F38: LDUR x9, [x9, #-8]         | X9 = (mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00AD0F3C: CMP x9, x1                 | STATE = COMPARE((mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00AD0F40: B.NE #0xad165c             | if ((mem[21474836657] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_110;
            // 0x00AD0F44: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD0F48: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD0F4C: LDR x19, [x19, #0x10]      | X19 = this._writer + 16 + 16 + 16 + 16 + 16;
            val_52 = mem[this._writer + 16 + 16 + 16 + 16 + 16];
            val_52 = this._writer + 16 + 16 + 16 + 16 + 16;
            // 0x00AD0F50: LDR x20, [x20, #0x20]      | X20 = 0x33644C8;                        
            // 0x00AD0F54: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD0F58: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD0F5C: TBZ w8, #0, #0xad0f6c      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_112;
            // 0x00AD0F60: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD0F64: CBNZ w8, #0xad0f6c         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_112;
            // 0x00AD0F68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_112:
            // 0x00AD0F6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0F70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0F74: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_28 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD0F78: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00AD0F7C: LDR x8, [x8, #0xb48]       | X8 = 1152921504652587008;               
            // 0x00AD0F80: MOV x21, x0                | X21 = val_28;//m1                       
            val_51 = val_28;
            // 0x00AD0F84: LDR x8, [x8]               | X8 = typeof(System.Convert);            
            // 0x00AD0F88: LDRB w9, [x8, #0x10a]      | W9 = System.Convert.__il2cppRuntimeField_10A;
            // 0x00AD0F8C: TBZ w9, #0, #0xad0fa0      | if (System.Convert.__il2cppRuntimeField_has_cctor == 0) goto label_114;
            // 0x00AD0F90: LDR w9, [x8, #0xbc]        | W9 = System.Convert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD0F94: CBNZ w9, #0xad0fa0         | if (System.Convert.__il2cppRuntimeField_cctor_finished != 0) goto label_114;
            // 0x00AD0F98: MOV x0, x8                 | X0 = 1152921504652587008 (0x1000000002B9F000);//ML01
            // 0x00AD0F9C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Convert), ????);
            label_114:
            // 0x00AD0FA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0FA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD0FA8: MOV x1, x20                | X1 = 53888200 (0x33644C8);//ML01        
            // 0x00AD0FAC: MOV x2, x21                | X2 = val_28;//m1                        
            // 0x00AD0FB0: BL #0x1ba6274              | X0 = System.Convert.ToInt32(value:  0, provider:  53888200);
            int val_29 = System.Convert.ToInt32(value:  0, provider:  53888200);
            // 0x00AD0FB4: MOV w20, w0                | W20 = val_29;//m1                       
            // 0x00AD0FB8: CBNZ x19, #0xad0fc0        | if (this._writer + 16 + 16 + 16 + 16 + 16 != 0) goto label_115;
            if(val_52 != 0)
            {
                goto label_115;
            }
            // 0x00AD0FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_115:
            // 0x00AD0FC0: LDR x8, [x19]              | X8 = this._writer + 16 + 16 + 16 + 16 + 16;
            // 0x00AD0FC4: MOV x0, x19                | X0 = this._writer + 16 + 16 + 16 + 16 + 16;//m1
            // 0x00AD0FC8: MOV w1, w20                | W1 = val_29;//m1                        
            // 0x00AD0FCC: LDR x9, [x8, #0x200]       | X9 = this._writer + 16 + 16 + 16 + 16 + 16 + 512;
            // 0x00AD0FD0: LDR x2, [x8, #0x208]       | X2 = this._writer + 16 + 16 + 16 + 16 + 16 + 520;
            // 0x00AD0FD4: BLR x9                     | X0 = this._writer + 16 + 16 + 16 + 16 + 16 + 512();
            // 0x00AD0FD8: B #0xad1380                |  goto label_144;                        
            goto label_144;
            label_49:
            // 0x00AD0FDC: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00AD0FE0: LDR x8, [x8, #0x6a8]       | X8 = 1152921504652853248;               
            val_67 = 1152921504652853248;
            // 0x00AD0FE4: LDR x20, [x8]              | X20 = typeof(System.DateTimeOffset);    
            val_68 = null;
            // 0x00AD0FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x33644C8, ????);  
            // 0x00AD0FEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_66 = 0;
            label_51:
            // 0x00AD0FF0: LDR x9, [x8, #0x30]        | X9 = typeof(System.Reflection.MethodInfo);
            // 0x00AD0FF4: LDR x8, [x20, #0x30]       | X8 = System.DateTimeOffset.__il2cppRuntimeField_element_class;
            // 0x00AD0FF8: CMP x9, x8                 | STATE = COMPARE(typeof(System.Reflection.MethodInfo), System.DateTimeOffset.__il2cppRuntimeField_element_class)
            // 0x00AD0FFC: B.EQ #0xad1030             | if (null == System.DateTimeOffset.__il2cppRuntimeField_element_class) goto label_117;
            // 0x00AD1000: ADD x8, sp, #0xa0          | X8 = (1152921513714037376 + 160) = 1152921513714037536 (0x100000021ED4B320);
            // 0x00AD1004: MOV x0, x9                 | X0 = 1152921504627560448 (0x10000000013C1000);//ML01
            // 0x00AD1008: MOV x1, x20                | X1 = 1152921504652853248 (0x1000000002BE0000);//ML01
            // 0x00AD100C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? typeof(System.Reflection.MethodInfo), ????);
            // 0x00AD1010: LDR x0, [x23, #0x18]       | 
            // 0x00AD1014: BL #0x27af090              | X0 = sub_27AF090( ?? typeof(System.Reflection.MethodInfo), ????);
            // 0x00AD1018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD101C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Reflection.MethodInfo), ????);
            // 0x00AD1020: ADD x0, sp, #0xa0          | X0 = (1152921513714037376 + 160) = 1152921513714037536 (0x100000021ED4B320);
            // 0x00AD1024: BL #0x299a140              | 
            // 0x00AD1028: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_66 = 0;
            // 0x00AD102C: B #0xad1034                |  goto label_118;                        
            goto label_118;
            label_117:
            // 0x00AD1030: BL #0x27bc4e8              | val_66.System.IDisposable.Dispose();    
            val_66.System.IDisposable.Dispose();
            label_118:
            // 0x00AD1034: LDR x8, [x0, #0x10]        | X8 = 0x100B70003;                       
            // 0x00AD1038: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD103C: STR x8, [sp, #0x20]        | stack[1152921513714037408] = 0x100B70003;  //  dest_result_addr=1152921513714037408
            // 0x00AD1040: LDR q0, [x0]               | Q0 = ;                                  
            // 0x00AD1044: ADD x0, sp, #0x10          | X0 = (1152921513714037376 + 16) = 1152921513714037392 (0x100000021ED4B290);
            // 0x00AD1048: STR q0, [sp, #0x10]        | stack[1152921513714037392] = ;           //  dest_result_addr=1152921513714037392
            // 0x00AD104C: BL #0x1c28dc8              | X0 = label_ILRuntime_Runtime_Generated_CSHeroUnit_Binding_set_movespeed_9_GL01C28DC8();
            // 0x00AD1050: MOV x20, x0                | X20 = 1152921513714037392 (0x100000021ED4B290);//ML01
            // 0x00AD1054: MOV x21, x1                | X21 = 0 (0x0);//ML01                    
            val_51 = 0;
            // 0x00AD1058: ADD x0, sp, #0x10          | X0 = (1152921513714037376 + 16) = 1152921513714037392 (0x100000021ED4B290);
            // 0x00AD105C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1060: BL #0x1c2d8b0              | X0 = get_InitialType();                 
            System.Type val_30 = InitialType;
            // 0x00AD1064: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AD1068: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
            // 0x00AD106C: MOV x22, x0                | X22 = val_30;//m1                       
            // 0x00AD1070: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.JsonConvert);
            // 0x00AD1074: LDRB w9, [x8, #0x10a]      | W9 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
            // 0x00AD1078: TBZ w9, #0, #0xad108c      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_120;
            // 0x00AD107C: LDR w9, [x8, #0xbc]        | W9 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD1080: CBNZ w9, #0xad108c         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_120;
            // 0x00AD1084: MOV x0, x8                 | X0 = 1152921504859615232 (0x100000000F10F000);//ML01
            // 0x00AD1088: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
            label_120:
            // 0x00AD108C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD1090: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD1094: MOV x1, x20                | X1 = 1152921513714037392 (0x100000021ED4B290);//ML01
            // 0x00AD1098: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x00AD109C: MOV x3, x22                | X3 = val_30;//m1                        
            // 0x00AD10A0: BL #0x130e91c              | X0 = Newtonsoft.Json.JsonConvert.ConvertDateTimeToJavaScriptTicks(dateTime:  new System.DateTime() {ticks = new System.TimeSpan()}, offset:  new System.TimeSpan() {_ticks = val_51});
            long val_31 = Newtonsoft.Json.JsonConvert.ConvertDateTimeToJavaScriptTicks(dateTime:  new System.DateTime() {ticks = new System.TimeSpan()}, offset:  new System.TimeSpan() {_ticks = val_51});
            // 0x00AD10A4: B #0xad1358                |  goto label_121;                        
            goto label_121;
            label_45:
            // 0x00AD10A8: LDR x8, [x21]              | X8 = 0x500000001;                       
            // 0x00AD10AC: MOV x1, x22                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD10B0: LDR x0, [x8, #0x30]        | X0 = mem[21474836529];                  
            // 0x00AD10B4: SUB x8, x29, #0x90         | X8 = (1152921513714037696 - 144) = 1152921513714037552 (0x100000021ED4B330);
            // 0x00AD10B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[21474836529], ????);
            // 0x00AD10BC: LDR x0, [x23, #0x28]       | 
            // 0x00AD10C0: BL #0x27af090              | X0 = sub_27AF090( ?? mem[21474836529], ????);
            // 0x00AD10C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD10C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? mem[21474836529], ????);
            // 0x00AD10CC: SUB x0, x29, #0x90         | X0 = (1152921513714037696 - 144) = 1152921513714037552 (0x100000021ED4B330);
            // 0x00AD10D0: BL #0x299a140              | 
            label_44:
            // 0x00AD10D4: LDR x21, [x19, #0x10]!     | X21 = this._writer.OutStream; //P2      
            val_63 = this._writer.OutStream;
            // 0x00AD10D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B330, ????);
            // 0x00AD10DC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_62 = 0;
            // 0x00AD10E0: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_64 = 0;
            label_46:
            // 0x00AD10E4: CBNZ x21, #0xad10ec        | if (this._writer.OutStream != null) goto label_122;
            if(val_63 != null)
            {
                goto label_122;
            }
            // 0x00AD10E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B330, ????);
            label_122:
            // 0x00AD10EC: LDR x8, [x21]              | X8 = typeof(System.IO.Stream);          
            // 0x00AD10F0: LDR w1, [x22, #0x18]       | W1 = 0x9814C0;                          
            // 0x00AD10F4: MOV x0, x21                | X0 = this._writer.OutStream;//m1        
            // 0x00AD10F8: LDR x9, [x8, #0x200]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_200;
            // 0x00AD10FC: LDR x2, [x8, #0x208]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_208;
            // 0x00AD1100: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_200();
            // 0x00AD1104: LDR x21, [x19]             | X21 = this._writer + 16;                
            val_51 = mem[this._writer + 16];
            val_51 = this._writer + 16;
            // 0x00AD1108: CBNZ x21, #0xad1110        | if (this._writer + 16 != 0) goto label_123;
            if(val_51 != 0)
            {
                goto label_123;
            }
            // 0x00AD110C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer.OutStream, ????);
            label_123:
            // 0x00AD1110: LDR x8, [x21]              | X8 = this._writer + 16;                 
            // 0x00AD1114: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AD1118: MOV x0, x21                | X0 = this._writer + 16;//m1             
            // 0x00AD111C: LDP x9, x2, [x8, #0x1b0]   | X9 = this._writer + 16 + 432; X2 = this._writer + 16 + 432 + 8; //  | 
            // 0x00AD1120: BLR x9                     | X0 = this._writer + 16 + 432();         
            // 0x00AD1124: LDR x19, [x19]             | X19 = this._writer + 16;                
            val_52 = mem[this._writer + 16];
            val_52 = this._writer + 16;
            // 0x00AD1128: CBNZ x19, #0xad1130        | if (this._writer + 16 != 0) goto label_124;
            if(val_52 != 0)
            {
                goto label_124;
            }
            label_102:
            // 0x00AD112C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer + 16, ????);
            label_124:
            // 0x00AD1130: LDR x8, [x19]              | X8 = this._writer + 16;                 
            // 0x00AD1134: LDR x9, [x8, #0x1c0]       | X9 = this._writer + 16 + 448;           
            // 0x00AD1138: LDR x2, [x8, #0x1c8]       | X2 = this._writer + 16 + 456;           
            // 0x00AD113C: B #0xad1374                |  goto label_125;                        
            goto label_125;
            label_50:
            // 0x00AD1140: BL #0x27bc4e8              | val_66.System.IDisposable.Dispose();    
            val_66.System.IDisposable.Dispose();
            // 0x00AD1144: LDR q0, [x0]               | Q0 = ;                                  
            // 0x00AD1148: STR q0, [sp, #0x30]        | stack[1152921513714037424] = ;           //  dest_result_addr=1152921513714037424
            // 0x00AD114C: LDR w8, [x19, #0x24]       | W8 = this._writer + 16 + 36;            
            // 0x00AD1150: CMP w8, #1                 | STATE = COMPARE(this._writer + 16 + 36, 0x1)
            // 0x00AD1154: B.EQ #0xad12fc             | if (this._writer + 16 + 36 == 0x1) goto label_126;
            if((this._writer + 16 + 36) == 1)
            {
                goto label_126;
            }
            // 0x00AD1158: CMP w8, #2                 | STATE = COMPARE(this._writer + 16 + 36, 0x2)
            // 0x00AD115C: B.NE #0xad131c             | if (this._writer + 16 + 36 != 0x2) goto label_127;
            if((this._writer + 16 + 36) != 2)
            {
                goto label_127;
            }
            // 0x00AD1160: ADD x0, sp, #0x30          | X0 = (1152921513714037376 + 48) = 1152921513714037424 (0x100000021ED4B2B0);
            // 0x00AD1164: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_86 = 0;
            // 0x00AD1168: BL #0x1bb09dc              | X0 = label_System_DateTime_FromBinary_GL01BB09DC();
            // 0x00AD116C: B #0xad1308                |  goto label_128;                        
            goto label_128;
            label_89:
            // 0x00AD1170: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD1174: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD1178: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_91:
            // 0x00AD117C: LDP x8, x1, [x0]           | X8 = this._writer + 16 + 16; X1 = this._writer + 16 + 16 + 8; //  | 
            // 0x00AD1180: MOV x0, x20                | X0 = val_18;//m1                        
            // 0x00AD1184: BLR x8                     | X0 = this._writer + 16 + 16();          
            label_87:
            // 0x00AD1188: CMP w22, #0xf1             | STATE = COMPARE(0x0, 0xF1)              
            // 0x00AD118C: B.NE #0xad11b4             | if (0 != 0xF1) goto label_129;          
            if(0 != 241)
            {
                goto label_129;
            }
            // 0x00AD1190: B #0xad11c4                |  goto label_132;                        
            goto label_132;
            label_36:
            // 0x00AD1194: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD1198: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD119C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_38:
            // 0x00AD11A0: LDP x8, x1, [x0]           | X8 = typeof(System.IO.BinaryWriter);     //  | 
            // 0x00AD11A4: MOV x0, x20                | X0 = val_5;//m1                         
            // 0x00AD11A8: BLR x8                     | X0 = sub_1000000000D41000( ?? val_5, ????);
            label_34:
            // 0x00AD11AC: CMP w22, #0x199            | STATE = COMPARE(0x0, 0x199)             
            // 0x00AD11B0: B.EQ #0xad11c4             | if (0 == 0x199) goto label_132;         
            if(0 == 409)
            {
                goto label_132;
            }
            label_129:
            // 0x00AD11B4: CBZ x21, #0xad11c4         | if (typeof(System.IO.BinaryWriter) == null) goto label_132;
            if(null == null)
            {
                goto label_132;
            }
            // 0x00AD11B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD11BC: MOV x0, x21                | X0 = 1152921504620744704 (0x1000000000D41000);//ML01
            // 0x00AD11C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryWriter), ????);
            label_132:
            // 0x00AD11C4: LDR x19, [x19, #0x10]      | X19 = this._writer.OutStream; //P2      
            val_52 = this._writer.OutStream;
            // 0x00AD11C8: CBNZ x19, #0xad11d0        | if (this._writer.OutStream != null) goto label_133;
            if(val_52 != null)
            {
                goto label_133;
            }
            // 0x00AD11CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.BinaryWriter), ????);
            label_133:
            // 0x00AD11D0: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
            // 0x00AD11D4: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AD11D8: LDR x9, [x8, #0x1b0]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_1B0;
            // 0x00AD11DC: LDR x2, [x8, #0x1b8]       | X2 = typeof(System.IO.Stream).__il2cppRuntimeField_1B8;
            label_108:
            // 0x00AD11E0: MOV x0, x19                | X0 = this._writer.OutStream;//m1        
            // 0x00AD11E4: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_1B0();
            // 0x00AD11E8: B #0xad1380                |  goto label_144;                        
            goto label_144;
            label_40:
            // 0x00AD11EC: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_60 = 0;
            label_41:
            // 0x00AD11F0: LDR x21, [x20, #0x20]      | 
            // 0x00AD11F4: MOV x8, x21                | X8 = 1152921504620744704 (0x1000000000D41000);//ML01
            val_87 = 1152921504620744704;
            // 0x00AD11F8: CBNZ x21, #0xad1208        | if (typeof(System.IO.BinaryWriter) != null) goto label_135;
            if(null != null)
            {
                goto label_135;
            }
            // 0x00AD11FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x00AD1200: LDR x8, [x20, #0x20]       | 
            // 0x00AD1204: CBZ x8, #0xad1704          | if (typeof(System.IO.BinaryWriter) == null) goto label_136;
            if(val_87 == null)
            {
                goto label_136;
            }
            label_135:
            // 0x00AD1208: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
            // 0x00AD120C: LDR x1, [x21, #0x20]       | X1 = System.IO.BinaryWriter.__il2cppRuntimeField_byval_arg;
            // 0x00AD1210: LDR w21, [x8, #0x2c]       | W21 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C;
            // 0x00AD1214: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
            // 0x00AD1218: CBZ x1, #0xad1254          | if (System.IO.BinaryWriter.__il2cppRuntimeField_byval_arg == 0) goto label_137;
            // 0x00AD121C: LDR x9, [x22]              | X9 = typeof(System.String);             
            // 0x00AD1220: LDR x8, [x1]               | X8 =  typeof(Il2CppType*);              
            // 0x00AD1224: CMP x8, x9                 | STATE = COMPARE(__il2cppRuntimeField_byval_arg, typeof(System.String))
            // 0x00AD1228: B.EQ #0xad1258             | if (__il2cppRuntimeField_byval_arg == null) goto label_138;
            // 0x00AD122C: LDR x0, [x8, #0x30]        | X0 = 0x38004000000000;                  
            // 0x00AD1230: SUB x8, x29, #0x70         | X8 = (1152921513714037696 - 112) = 1152921513714037584 (0x100000021ED4B350);
            // 0x00AD1234: MOV x1, x9                 | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AD1238: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x38004000000000, ????);
            // 0x00AD123C: LDR x0, [x23, #0x48]       | 
            // 0x00AD1240: BL #0x27af090              | X0 = sub_27AF090( ?? 0x38004000000000, ????);
            // 0x00AD1244: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1248: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x38004000000000, ????);
            // 0x00AD124C: SUB x0, x29, #0x70         | X0 = (1152921513714037696 - 112) = 1152921513714037584 (0x100000021ED4B350);
            // 0x00AD1250: BL #0x299a140              | 
            label_137:
            // 0x00AD1254: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_88 = 0;
            label_138:
            // 0x00AD1258: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD125C: MOV x0, x19                | X0 = this._writer;//m1                  
            val_59 = val_52;
            // 0x00AD1260: MOV w2, w21                | W2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C;//m1
            // 0x00AD1264: BL #0xad1848               | this._writer.WriteString(s:  val_88 = 0, byteCount:  typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            val_59.WriteString(s:  val_88, byteCount:  typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            // 0x00AD1268: CBZ w24, #0xad1270         | if (0x0 == 0) goto label_139;           
            if(val_60 == 0)
            {
                goto label_139;
            }
            // 0x00AD126C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer, ????);
            label_139:
            // 0x00AD1270: LDR x21, [x20, #0x28]      | 
            // 0x00AD1274: MOV x8, x21                | X8 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C;//m1
            val_89 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C;
            // 0x00AD1278: CBNZ x21, #0xad1288        | if (typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C != 0) goto label_140;
            // 0x00AD127C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer, ????);
            // 0x00AD1280: LDR x8, [x20, #0x28]       | 
            // 0x00AD1284: CBZ x8, #0xad1708          | if (typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C == 0) goto label_141;
            label_140:
            // 0x00AD1288: LDR x1, [x21, #0x20]       | X1 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32;
            val_79 = mem[typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32];
            val_79 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32;
            // 0x00AD128C: LDR w20, [x8, #0x2c]       | W20 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 44;
            // 0x00AD1290: CBZ x1, #0xad12cc          | if (typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32 == 0) goto label_142;
            // 0x00AD1294: LDR x9, [x22]              | X9 = typeof(System.String);             
            // 0x00AD1298: LDR x8, [x1]               | X8 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32;
            // 0x00AD129C: CMP x8, x9                 | STATE = COMPARE(typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32, typeof(System.String))
            // 0x00AD12A0: B.EQ #0xad12d0             | if (val_79 == null) goto label_143;     
            if(val_79 == null)
            {
                goto label_143;
            }
            // 0x00AD12A4: LDR x0, [x8, #0x30]        | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32 + 48;
            // 0x00AD12A8: SUB x8, x29, #0x68         | X8 = (1152921513714037696 - 104) = 1152921513714037592 (0x100000021ED4B358);
            // 0x00AD12AC: MOV x1, x9                 | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00AD12B0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32 + 48, ????);
            // 0x00AD12B4: LDR x0, [x23, #0x50]       | 
            // 0x00AD12B8: BL #0x27af090              | X0 = sub_27AF090( ?? typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32 + 48, ????);
            // 0x00AD12BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD12C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 32 + 48, ????);
            // 0x00AD12C4: SUB x0, x29, #0x68         | X0 = (1152921513714037696 - 104) = 1152921513714037592 (0x100000021ED4B358);
            // 0x00AD12C8: BL #0x299a140              | 
            label_142:
            // 0x00AD12CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_79 = 0;
            label_143:
            // 0x00AD12D0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            val_78 = 0;
            // 0x00AD12D4: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00AD12D8: MOV w2, w20                | W2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 44;//m1
            val_80 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 44;
            label_96:
            // 0x00AD12DC: BL #0xad1848               | this._writer.WriteString(s:  val_79 = 0, byteCount:  val_80 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_2C + 44, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            val_52.WriteString(s:  val_79, byteCount:  val_80, calculatedlengthPrefix:  new System.Nullable<System.Int32>() {HasValue = false});
            // 0x00AD12E0: B #0xad1380                |  goto label_144;                        
            goto label_144;
            label_68:
            // 0x00AD12E4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x00AD12E8: MOVZ w22, #0xf1            | W22 = 241 (0xF1);//ML01                 
            // 0x00AD12EC: B #0xad0ce4                |  goto label_145;                        
            goto label_145;
            label_21:
            // 0x00AD12F0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            // 0x00AD12F4: MOVZ w22, #0x199           | W22 = 409 (0x199);//ML01                
            // 0x00AD12F8: B #0xad0840                |  goto label_146;                        
            goto label_146;
            label_126:
            // 0x00AD12FC: ADD x0, sp, #0x30          | X0 = (1152921513714037376 + 48) = 1152921513714037424 (0x100000021ED4B2B0);
            // 0x00AD1300: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_86 = 0;
            // 0x00AD1304: BL #0x1bb0840              | X0 = label_System_DateTime_Equals_GL01BB0840();
            label_128:
            // 0x00AD1308: MOV x20, x0                | X20 = 1152921513714037424 (0x100000021ED4B2B0);//ML01
            val_90;
            // 0x00AD130C: MOV x21, x1                | X21 = 0 (0x0);//ML01                    
            val_51 = val_86;
            // 0x00AD1310: STR x20, [sp, #0x30]       | stack[1152921513714037424] = 0x100000021ED4B2B0;  //  dest_result_addr=1152921513714037424
            // 0x00AD1314: STR x21, [sp, #0x38]       | stack[1152921513714037432] = 0x0;        //  dest_result_addr=1152921513714037432
            // 0x00AD1318: B #0xad1320                |  goto label_147;                        
            goto label_147;
            label_127:
            // 0x00AD131C: LDP x20, x21, [sp, #0x30]  | X20 = 0x100000021ED4B2B0; X21 = 0x0;     //  | 
            val_90 = val_90;
            val_51 = val_51;
            label_147:
            // 0x00AD1320: ADRP x8, #0x365c000        | X8 = 56999936 (0x365C000);              
            // 0x00AD1324: LDR x8, [x8, #0x9c8]       | X8 = 1152921504859615232;               
            // 0x00AD1328: LDR x0, [x8]               | X0 = typeof(Newtonsoft.Json.JsonConvert);
            // 0x00AD132C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_10A;
            // 0x00AD1330: TBZ w8, #0, #0xad1340      | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_has_cctor == 0) goto label_149;
            // 0x00AD1334: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished;
            // 0x00AD1338: CBNZ w8, #0xad1340         | if (Newtonsoft.Json.JsonConvert.__il2cppRuntimeField_cctor_finished != 0) goto label_149;
            // 0x00AD133C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.JsonConvert), ????);
            label_149:
            // 0x00AD1340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD1344: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x00AD1348: MOV x1, x20                | X1 = 1152921513714037424 (0x100000021ED4B2B0);//ML01
            // 0x00AD134C: MOV x2, x21                | X2 = 0 (0x0);//ML01                     
            // 0x00AD1350: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD1354: BL #0x130eb64              | X0 = Newtonsoft.Json.JsonConvert.ConvertDateTimeToJavaScriptTicks(dateTime:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_90}, convertToUtc:  false);
            long val_34 = Newtonsoft.Json.JsonConvert.ConvertDateTimeToJavaScriptTicks(dateTime:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_90}, convertToUtc:  false);
            label_121:
            // 0x00AD1358: LDR x19, [x19, #0x10]      | X19 = this._writer + 16 + 16;           
            val_52 = mem[this._writer + 16 + 16];
            val_52 = this._writer + 16 + 16;
            // 0x00AD135C: MOV x20, x0                | X20 = val_34;//m1                       
            val_62 = val_34;
            // 0x00AD1360: CBNZ x19, #0xad1368        | if (this._writer + 16 + 16 != 0) goto label_150;
            if(val_52 != 0)
            {
                goto label_150;
            }
            label_59:
            // 0x00AD1364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            label_150:
            // 0x00AD1368: LDR x8, [x19]              | X8 = this._writer + 16 + 16;            
            // 0x00AD136C: LDR x9, [x8, #0x210]       | X9 = this._writer + 16 + 16 + 528;      
            // 0x00AD1370: LDR x2, [x8, #0x218]       | X2 = this._writer + 16 + 16 + 536;      
            label_125:
            // 0x00AD1374: MOV x0, x19                | X0 = this._writer + 16 + 16;//m1        
            // 0x00AD1378: MOV x1, x20                | X1 = val_34;//m1                        
            // 0x00AD137C: BLR x9                     | X0 = this._writer + 16 + 16 + 528();    
            label_144:
            // 0x00AD1380: SUB sp, x29, #0x60         | SP = (1152921513714037696 - 96) = 1152921513714037600 (0x100000021ED4B360);
            // 0x00AD1384: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1388: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD138C: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD1390: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD1394: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD1398: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x00AD139C: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x00AD13A0: RET                        |  return;                                
            return;
            // 0x00AD13A4: MOV x21, x0                | X21 = this._writer + 16 + 16;//m1       
            // 0x00AD13A8: ADD x0, sp, #0x50          | X0 = (1152921513714037712 + 80) = 1152921513714037792 (0x100000021ED4B420);
            // 0x00AD13AC: MOV x22, x1                | X22 = val_34;//m1                       
            // 0x00AD13B0: BL #0x299a140              | 
            // 0x00AD13B4: B #0xad0cc8                |  goto label_151;                        
            goto label_151;
            label_2:
            // 0x00AD13B8: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD13BC: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD13C0: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD13C4: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD13C8: TBZ w8, #0, #0xad13d8      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_153;
            // 0x00AD13CC: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD13D0: CBNZ w8, #0xad13d8         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_153;
            // 0x00AD13D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_153:
            // 0x00AD13D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD13DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD13E0: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_35 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD13E4: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD13E8: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD13EC: MOV x19, x0                | X19 = val_35;//m1                       
            // 0x00AD13F0: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AD13F4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD13F8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD13FC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD1400: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD1404: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD1408: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD140C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD1410: MOV x0, x20                | X0 = t;//m1                             
            // 0x00AD1414: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150; X1 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_158; //  | 
            // 0x00AD1418: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150();
            // 0x00AD141C: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00AD1420: LDR x8, [x8, #0xc00]       | X8 = 1152921504858071040;               
            // 0x00AD1424: STRB w0, [sp, #7]          | stack[1152921513714037383] = t;          //  dest_result_addr=1152921513714037383
            // 0x00AD1428: ADD x1, sp, #7             | X1 = (1152921513714037376 + 7) = 1152921513714037383 (0x100000021ED4B287);
            // 0x00AD142C: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonType);
            // 0x00AD1430: MOV x0, x8                 | X0 = 1152921504858071040 (0x100000000EF96000);//ML01
            // 0x00AD1434: BL #0x27bc028              | X0 = 1152921513714143152 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.Bson.BsonType), t);
            // 0x00AD1438: MOV x20, x0                | X20 = 1152921513714143152 (0x100000021ED64FB0);//ML01
            // 0x00AD143C: CBNZ x21, #0xad1444        | if ( != null) goto label_154;           
            if(null != null)
            {
                goto label_154;
            }
            // 0x00AD1440: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? t, ????);          
            label_154:
            // 0x00AD1444: CBZ x20, #0xad1468         | if (t == 0) goto label_156;             
            if(t == 0)
            {
                goto label_156;
            }
            // 0x00AD1448: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AD144C: MOV x0, x20                | X0 = 1152921513714143152 (0x100000021ED64FB0);//ML01
            // 0x00AD1450: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD1454: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? t, ????);          
            // 0x00AD1458: CBNZ x0, #0xad1468         | if (t != 0) goto label_156;             
            if(t != 0)
            {
                goto label_156;
            }
            // 0x00AD145C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? t, ????);          
            // 0x00AD1460: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1464: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t, ????);          
            label_156:
            // 0x00AD1468: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD146C: CBNZ w8, #0xad147c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_157;
            // 0x00AD1470: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? t, ????);          
            // 0x00AD1474: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1478: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t, ????);          
            label_157:
            // 0x00AD147C: STR x20, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = t;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = t;
            // 0x00AD1480: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00AD1484: LDR x8, [x8, #0x6a8]       | X8 = (string**)(1152921513714019328)("Unexpected token when writing BSON: {0}");
            // 0x00AD1488: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD148C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD1490: MOV x2, x19                | X2 = val_35;//m1                        
            // 0x00AD1494: LDR x1, [x8]               | X1 = "Unexpected token when writing BSON: {0}";
            // 0x00AD1498: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD149C: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Unexpected token when writing BSON: {0}", args:  val_35);
            string val_36 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Unexpected token when writing BSON: {0}", args:  val_35);
            // 0x00AD14A0: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD14A4: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x00AD14A8: MOV x19, x0                | X19 = val_36;//m1                       
            // 0x00AD14AC: LDR x8, [x8]               | X8 = typeof(System.ArgumentOutOfRangeException);
            // 0x00AD14B0: MOV x0, x8                 | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            System.ArgumentOutOfRangeException val_37 = null;
            // 0x00AD14B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD14B8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00AD14BC: LDR x8, [x8, #0xe48]       | X8 = (string**)(1152921513714023584)("t");
            // 0x00AD14C0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD14C4: MOV x2, x19                | X2 = val_36;//m1                        
            // 0x00AD14C8: MOV x20, x0                | X20 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD14CC: LDR x1, [x8]               | X1 = "t";                               
            // 0x00AD14D0: BL #0x18b3e8c              | .ctor(paramName:  "t", message:  val_36);
            val_37 = new System.ArgumentOutOfRangeException(paramName:  "t", message:  val_36);
            // 0x00AD14D4: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x00AD14D8: LDR x8, [x8, #0xbc0]       | X8 = 1152921513714023664;               
            val_54 = 1152921513714023664;
            // 0x00AD14DC: MOV x0, x20                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD14E0: LDR x1, [x8]               | X1 = System.Void Newtonsoft.Json.Bson.BsonBinaryWriter::WriteTokenInternal(Newtonsoft.Json.Bson.BsonToken t);
            // 0x00AD14E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD14E8: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            label_13:
            // 0x00AD14EC: LDR x0, [x8, #0x30]        | X0 = public System.Void System.Collections.Generic.List<ContainerContext>::.ctor();
            // 0x00AD14F0: ADD x8, sp, #0x58          | X8 = (1152921513714037376 + 88) = 1152921513714037464 (0x100000021ED4B2D8);
            // 0x00AD14F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? public System.Void System.Collections.Generic.List<ContainerContext>::.ctor(), ????);
            // 0x00AD14F8: LDR x0, [sp, #0x58]        | X0 = val_38;                             //  find_add[1152921513714025712]
            // 0x00AD14FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_38, ????);     
            // 0x00AD1500: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1504: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_38, ????);     
            // 0x00AD1508: ADD x0, sp, #0x58          | X0 = (1152921513714037376 + 88) = 1152921513714037464 (0x100000021ED4B2D8);
            // 0x00AD150C: BL #0x299a140              | 
            // 0x00AD1510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2D8, ????);
            label_43:
            // 0x00AD1514: LDR x0, [x8, #0x30]        | X0 = val_39;                             //  find_add[1152921513714025712]
            // 0x00AD1518: SUB x8, x29, #0x98         | X8 = (1152921513714037696 - 152) = 1152921513714037544 (0x100000021ED4B328);
            // 0x00AD151C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_39, ????);     
            // 0x00AD1520: LDR x0, [x23, #0x20]       | X0 = X23 + 32;                          
            // 0x00AD1524: BL #0x27af090              | X0 = sub_27AF090( ?? X23 + 32, ????);   
            // 0x00AD1528: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD152C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X23 + 32, ????);   
            // 0x00AD1530: SUB x0, x29, #0x98         | X0 = (1152921513714037696 - 152) = 1152921513714037544 (0x100000021ED4B328);
            // 0x00AD1534: BL #0x299a140              | 
            // 0x00AD1538: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B328, ????);
            label_48:
            // 0x00AD153C: LDR x0, [x8, #0x30]        | X0 = val_40;                             //  find_add[1152921513714025712]
            // 0x00AD1540: ADD x8, sp, #0x98          | X8 = (1152921513714037376 + 152) = 1152921513714037528 (0x100000021ED4B318);
            // 0x00AD1544: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_40, ????);     
            // 0x00AD1548: LDR x0, [x23, #0x10]       | X0 = X23 + 16;                          
            // 0x00AD154C: BL #0x27af090              | X0 = sub_27AF090( ?? X23 + 16, ????);   
            // 0x00AD1550: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1554: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X23 + 16, ????);   
            // 0x00AD1558: ADD x0, sp, #0x98          | X0 = (1152921513714037376 + 152) = 1152921513714037528 (0x100000021ED4B318);
            // 0x00AD155C: BL #0x299a140              | 
            // 0x00AD1560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B318, ????);
            label_53:
            // 0x00AD1564: LDR x0, [x8, #0x30]        | X0 = val_41;                             //  find_add[1152921513714025712]
            // 0x00AD1568: ADD x8, sp, #0x68          | X8 = (1152921513714037376 + 104) = 1152921513714037480 (0x100000021ED4B2E8);
            // 0x00AD156C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_41, ????);     
            // 0x00AD1570: LDR x0, [sp, #0x68]        | X0 = val_42;                             //  find_add[1152921513714025712]
            // 0x00AD1574: BL #0x27af090              | X0 = sub_27AF090( ?? val_42, ????);     
            // 0x00AD1578: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD157C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            // 0x00AD1580: ADD x0, sp, #0x68          | X0 = (1152921513714037376 + 104) = 1152921513714037480 (0x100000021ED4B2E8);
            // 0x00AD1584: BL #0x299a140              | 
            // 0x00AD1588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2E8, ????);
            label_61:
            // 0x00AD158C: LDR x0, [x8, #0x30]        | X0 = val_43;                             //  find_add[1152921513714025712]
            // 0x00AD1590: ADD x8, sp, #0x48          | X8 = (1152921513714037376 + 72) = 1152921513714037448 (0x100000021ED4B2C8);
            // 0x00AD1594: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_43, ????);     
            // 0x00AD1598: LDR x0, [sp, #0x48]        | X0 = val_44;                             //  find_add[1152921513714025712]
            // 0x00AD159C: BL #0x27af090              | X0 = sub_27AF090( ?? val_44, ????);     
            // 0x00AD15A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD15A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_44, ????);     
            // 0x00AD15A8: ADD x0, sp, #0x48          | X0 = (1152921513714037376 + 72) = 1152921513714037448 (0x100000021ED4B2C8);
            // 0x00AD15AC: BL #0x299a140              | 
            // 0x00AD15B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2C8, ????);
            label_5:
            // 0x00AD15B4: LDR x0, [x8, #0x30]        | X0 = val_45;                             //  find_add[1152921513714025712]
            // 0x00AD15B8: ADD x8, sp, #0x70          | X8 = (1152921513714037376 + 112) = 1152921513714037488 (0x100000021ED4B2F0);
            // 0x00AD15BC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_45, ????);     
            // 0x00AD15C0: LDR x0, [sp, #0x70]        | X0 = val_46;                             //  find_add[1152921513714025712]
            // 0x00AD15C4: BL #0x27af090              | X0 = sub_27AF090( ?? val_46, ????);     
            // 0x00AD15C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD15CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_46, ????);     
            // 0x00AD15D0: ADD x0, sp, #0x70          | X0 = (1152921513714037376 + 112) = 1152921513714037488 (0x100000021ED4B2F0);
            // 0x00AD15D4: BL #0x299a140              | 
            // 0x00AD15D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2F0, ????);
            label_93:
            // 0x00AD15DC: LDR x0, [x8, #0x30]        | X0 = val_47;                             //  find_add[1152921513714025712]
            // 0x00AD15E0: ADD x8, sp, #0x78          | X8 = (1152921513714037376 + 120) = 1152921513714037496 (0x100000021ED4B2F8);
            // 0x00AD15E4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_47, ????);     
            // 0x00AD15E8: LDR x0, [sp, #0x78]        | X0 = val_45;                             //  find_add[1152921513714025712]
            // 0x00AD15EC: BL #0x27af090              | X0 = sub_27AF090( ?? val_45, ????);     
            // 0x00AD15F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD15F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_45, ????);     
            // 0x00AD15F8: ADD x0, sp, #0x78          | X0 = (1152921513714037376 + 120) = 1152921513714037496 (0x100000021ED4B2F8);
            // 0x00AD15FC: BL #0x299a140              | 
            // 0x00AD1600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2F8, ????);
            // 0x00AD1604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2F8, ????);
            // 0x00AD1608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2F8, ????);
            label_98:
            // 0x00AD160C: LDR x0, [x8, #0x30]        | X0 = val_48;                             //  find_add[1152921513714025712]
            // 0x00AD1610: SUB x8, x29, #0x88         | X8 = (1152921513714037696 - 136) = 1152921513714037560 (0x100000021ED4B338);
            // 0x00AD1614: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_48, ????);     
            // 0x00AD1618: LDR x0, [x23, #0x30]       | X0 = X23 + 48;                          
            // 0x00AD161C: BL #0x27af090              | X0 = sub_27AF090( ?? X23 + 48, ????);   
            // 0x00AD1620: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1624: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X23 + 48, ????);   
            // 0x00AD1628: SUB x0, x29, #0x88         | X0 = (1152921513714037696 - 136) = 1152921513714037560 (0x100000021ED4B338);
            // 0x00AD162C: BL #0x299a140              | 
            // 0x00AD1630: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B338, ????);
            label_104:
            // 0x00AD1634: LDR x0, [x8, #0x30]        | X0 = ;                                  
            // 0x00AD1638: ADD x8, sp, #0x88          | X8 = (1152921513714037376 + 136) = 1152921513714037512 (0x100000021ED4B308);
            // 0x00AD163C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? , ????);           
            // 0x00AD1640: LDR x0, [x23]              | X0 = X23;                               
            // 0x00AD1644: BL #0x27af090              | X0 = sub_27AF090( ?? X23, ????);        
            // 0x00AD1648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD164C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? X23, ????);        
            // 0x00AD1650: ADD x0, sp, #0x88          | X0 = (1152921513714037376 + 136) = 1152921513714037512 (0x100000021ED4B308);
            // 0x00AD1654: BL #0x299a140              | 
            // 0x00AD1658: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B308, ????);
            label_110:
            // 0x00AD165C: LDR x0, [x8, #0x30]        | X0 = val_49;                             //  find_add[1152921513714025712]
            // 0x00AD1660: ADD x8, sp, #0x60          | X8 = (1152921513714037376 + 96) = 1152921513714037472 (0x100000021ED4B2E0);
            // 0x00AD1664: BL #0x27d96d4              | X0 = sub_27D96D4( ?? val_49, ????);     
            // 0x00AD1668: LDR x0, [sp, #0x60]        | X0 = val_50;                             //  find_add[1152921513714025712]
            // 0x00AD166C: BL #0x27af090              | X0 = sub_27AF090( ?? val_50, ????);     
            // 0x00AD1670: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1674: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_50, ????);     
            // 0x00AD1678: ADD x0, sp, #0x60          | X0 = (1152921513714037376 + 96) = 1152921513714037472 (0x100000021ED4B2E0);
            // 0x00AD167C: BL #0x299a140              | 
            // 0x00AD1680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B2E0, ????);
            // 0x00AD1684: MOV x21, x0                | X21 = 1152921513714037472 (0x100000021ED4B2E0);//ML01
            val_57;
            // 0x00AD1688: SUB x0, x29, #0x78         | X0 = (1152921513714037696 - 120) = 1152921513714037576 (0x100000021ED4B348);
            // 0x00AD168C: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            label_107:
            // 0x00AD1690: ADD x8, sp, #0x90          | X8 = (1152921513714037376 + 144) = 1152921513714037520 (0x100000021ED4B310);
            // 0x00AD1694: MOV x1, x21                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x00AD1698: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[21474836529], ????);
            // 0x00AD169C: LDR x0, [x23, #8]          | X0 = 0x0;                               
            // 0x00AD16A0: BL #0x27af090              | X0 = sub_27AF090( ?? 0x0, ????);        
            // 0x00AD16A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD16A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            // 0x00AD16AC: ADD x0, sp, #0x90          | X0 = (1152921513714037376 + 144) = 1152921513714037520 (0x100000021ED4B310);
            // 0x00AD16B0: BL #0x299a140              | 
            // 0x00AD16B4: MOV x21, x0                | X21 = 1152921513714037520 (0x100000021ED4B310);//ML01
            val_57;
            // 0x00AD16B8: ADD x0, sp, #0xa0          | X0 = (1152921513714037376 + 160) = 1152921513714037536 (0x100000021ED4B320);
            // 0x00AD16BC: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD16C0: MOV x21, x0                | X21 = 1152921513714037536 (0x100000021ED4B320);//ML01
            val_57;
            // 0x00AD16C4: ADD x0, sp, #0x80          | X0 = (1152921513714037376 + 128) = 1152921513714037504 (0x100000021ED4B300);
            // 0x00AD16C8: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD16CC: MOV x21, x0                | X21 = 1152921513714037504 (0x100000021ED4B300);//ML01
            val_57;
            // 0x00AD16D0: SUB x0, x29, #0x70         | X0 = (1152921513714037696 - 112) = 1152921513714037584 (0x100000021ED4B350);
            // 0x00AD16D4: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD16D8: MOV x21, x0                | X21 = 1152921513714037584 (0x100000021ED4B350);//ML01
            val_57;
            // 0x00AD16DC: SUB x0, x29, #0x68         | X0 = (1152921513714037696 - 104) = 1152921513714037592 (0x100000021ED4B358);
            // 0x00AD16E0: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD16E4: MOV x21, x0                | X21 = 1152921513714037592 (0x100000021ED4B358);//ML01
            val_57;
            // 0x00AD16E8: SUB x0, x29, #0x80         | X0 = (1152921513714037696 - 128) = 1152921513714037568 (0x100000021ED4B340);
            // 0x00AD16EC: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD16F0: MOV x21, x0                | X21 = 1152921513714037568 (0x100000021ED4B340);//ML01
            val_57;
            // 0x00AD16F4: SUB x0, x29, #0x90         | X0 = (1152921513714037696 - 144) = 1152921513714037552 (0x100000021ED4B330);
            label_174:
            // 0x00AD16F8: BL #0x299a140              | 
            label_86:
            // 0x00AD16FC: MOV x0, x21                | X0 = 1152921513714037568 (0x100000021ED4B340);//ML01
            val_59 = val_57;
            // 0x00AD1700: BL #0x980800               | X0 = sub_980800( ?? 0x100000021ED4B340, ????);
            label_136:
            // 0x00AD1704: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B340, ????);
            label_141:
            // 0x00AD1708: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021ED4B340, ????);
            // 0x00AD170C: MOV x21, x0                | X21 = 1152921513714037568 (0x100000021ED4B340);//ML01
            // 0x00AD1710: ADD x0, sp, #0x58          | X0 = (1152921513714037376 + 88) = 1152921513714037464 (0x100000021ED4B2D8);
            // 0x00AD1714: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1718: MOV x21, x0                | X21 = 1152921513714037464 (0x100000021ED4B2D8);//ML01
            // 0x00AD171C: SUB x0, x29, #0x98         | X0 = (1152921513714037696 - 152) = 1152921513714037544 (0x100000021ED4B328);
            // 0x00AD1720: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1724: MOV x21, x0                | X21 = 1152921513714037544 (0x100000021ED4B328);//ML01
            // 0x00AD1728: ADD x0, sp, #0x98          | X0 = (1152921513714037376 + 152) = 1152921513714037528 (0x100000021ED4B318);
            // 0x00AD172C: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1730: MOV x21, x0                | X21 = 1152921513714037528 (0x100000021ED4B318);//ML01
            // 0x00AD1734: ADD x0, sp, #0x68          | X0 = (1152921513714037376 + 104) = 1152921513714037480 (0x100000021ED4B2E8);
            // 0x00AD1738: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD173C: MOV x21, x0                | X21 = 1152921513714037480 (0x100000021ED4B2E8);//ML01
            // 0x00AD1740: ADD x0, sp, #0x48          | X0 = (1152921513714037376 + 72) = 1152921513714037448 (0x100000021ED4B2C8);
            // 0x00AD1744: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1748: MOV x21, x0                | X21 = 1152921513714037448 (0x100000021ED4B2C8);//ML01
            // 0x00AD174C: ADD x0, sp, #0x70          | X0 = (1152921513714037376 + 112) = 1152921513714037488 (0x100000021ED4B2F0);
            // 0x00AD1750: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1754: MOV x21, x0                | X21 = 1152921513714037488 (0x100000021ED4B2F0);//ML01
            // 0x00AD1758: ADD x0, sp, #0x78          | X0 = (1152921513714037376 + 120) = 1152921513714037496 (0x100000021ED4B2F8);
            // 0x00AD175C: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1760: MOV x21, x0                | X21 = 1152921513714037496 (0x100000021ED4B2F8);//ML01
            // 0x00AD1764: SUB x0, x29, #0x88         | X0 = (1152921513714037696 - 136) = 1152921513714037560 (0x100000021ED4B338);
            // 0x00AD1768: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD176C: MOV x21, x0                | X21 = 1152921513714037560 (0x100000021ED4B338);//ML01
            // 0x00AD1770: ADD x0, sp, #0x88          | X0 = (1152921513714037376 + 136) = 1152921513714037512 (0x100000021ED4B308);
            // 0x00AD1774: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1778: MOV x21, x0                | X21 = 1152921513714037512 (0x100000021ED4B308);//ML01
            // 0x00AD177C: ADD x0, sp, #0x60          | X0 = (1152921513714037376 + 96) = 1152921513714037472 (0x100000021ED4B2E0);
            // 0x00AD1780: B #0xad16f8                |  goto label_174;                        
            goto label_174;
            // 0x00AD1784: MOV x21, x0                | X21 = 1152921513714037472 (0x100000021ED4B2E0);//ML01
            // 0x00AD1788: ADD x0, sp, #0x90          | X0 = (1152921513714037376 + 144) = 1152921513714037520 (0x100000021ED4B310);
            // 0x00AD178C: B #0xad16f8                |  goto label_174;                        
            goto label_174;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1848 (11343944), len: 720  VirtAddr: 0x00AD1848 RVA: 0x00AD1848 token: 100684716 methodIndex: 47366 delegateWrapperIndex: 0 methodInvoker: 0
        private void WriteString(string s, int byteCount, System.Nullable<int> calculatedlengthPrefix)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            System.Byte[] val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x00AD1848: STP x28, x27, [sp, #-0x60]! | stack[1152921513714424048] = ???;  stack[1152921513714424056] = ???;  //  dest_result_addr=1152921513714424048 |  dest_result_addr=1152921513714424056
            // 0x00AD184C: STP x26, x25, [sp, #0x10]  | stack[1152921513714424064] = ???;  stack[1152921513714424072] = ???;  //  dest_result_addr=1152921513714424064 |  dest_result_addr=1152921513714424072
            // 0x00AD1850: STP x24, x23, [sp, #0x20]  | stack[1152921513714424080] = ???;  stack[1152921513714424088] = ???;  //  dest_result_addr=1152921513714424080 |  dest_result_addr=1152921513714424088
            // 0x00AD1854: STP x22, x21, [sp, #0x30]  | stack[1152921513714424096] = ???;  stack[1152921513714424104] = ???;  //  dest_result_addr=1152921513714424096 |  dest_result_addr=1152921513714424104
            // 0x00AD1858: STP x20, x19, [sp, #0x40]  | stack[1152921513714424112] = ???;  stack[1152921513714424120] = ???;  //  dest_result_addr=1152921513714424112 |  dest_result_addr=1152921513714424120
            // 0x00AD185C: STP x29, x30, [sp, #0x50]  | stack[1152921513714424128] = ???;  stack[1152921513714424136] = ???;  //  dest_result_addr=1152921513714424128 |  dest_result_addr=1152921513714424136
            // 0x00AD1860: ADD x29, sp, #0x50         | X29 = (1152921513714424048 + 80) = 1152921513714424128 (0x100000021EDA9940);
            // 0x00AD1864: SUB sp, sp, #0x10          | SP = (1152921513714424048 - 16) = 1152921513714424032 (0x100000021EDA98E0);
            // 0x00AD1868: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00AD186C: LDRB w8, [x22, #0x4c8]     | W8 = (bool)static_value_037334C8;       
            // 0x00AD1870: MOV w21, w2                | W21 = byteCount;//m1                    
            val_4 = byteCount;
            // 0x00AD1874: MOV x20, x1                | X20 = s;//m1                            
            // 0x00AD1878: MOV x19, x0                | X19 = 1152921513714436144 (0x100000021EDAC830);//ML01
            // 0x00AD187C: STR x3, [sp, #8]           | stack[1152921513714424040] = calculatedlengthPrefix.HasValue;  //  dest_result_addr=1152921513714424040
            // 0x00AD1880: TBNZ w8, #0, #0xad189c     | if (static_value_037334C8 == true) goto label_0;
            // 0x00AD1884: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x00AD1888: LDR x8, [x8, #0xbc0]       | X8 = 0x2B8F970;                         
            // 0x00AD188C: LDR w0, [x8]               | W0 = 0x1520;                            
            // 0x00AD1890: BL #0x2782188              | X0 = sub_2782188( ?? 0x1520, ????);     
            // 0x00AD1894: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1898: STRB w8, [x22, #0x4c8]     | static_value_037334C8 = true;            //  dest_result_addr=57881800
            label_0:
            // 0x00AD189C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00AD18A0: LDR x8, [x8, #0x908]       | X8 = 1152921509457529392;               
            // 0x00AD18A4: ADD x0, sp, #8             | X0 = (1152921513714424032 + 8) = 1152921513714424040 (0x100000021EDA98E8);
            // 0x00AD18A8: LDR x1, [x8]               | X1 = public System.Boolean System.Nullable<System.Int32>::get_HasValue();
            // 0x00AD18AC: BL #0x1d6c184              | X0 = sub_1D6C184( ?? 0x100000021EDA98E8, ????);
            // 0x00AD18B0: TBZ w0, #0, #0xad18f0      | if ((0x100000021EDA98E8 & 0x1) == 0) goto label_1;
            if((517642472 & 1) == 0)
            {
                goto label_1;
            }
            // 0x00AD18B4: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x00AD18B8: LDR x22, [x19, #0x10]      | X22 = this._writer; //P2                
            // 0x00AD18BC: LDR x8, [x8, #0x3b8]       | X8 = 1152921509577802208;               
            // 0x00AD18C0: ADD x0, sp, #8             | X0 = (1152921513714424032 + 8) = 1152921513714424040 (0x100000021EDA98E8);
            // 0x00AD18C4: LDR x1, [x8]               | X1 = public System.Int32 System.Nullable<System.Int32>::get_Value();
            // 0x00AD18C8: BL #0x1d6c1b0              | X0 = sub_1D6C1B0( ?? 0x100000021EDA98E8, ????);
            // 0x00AD18CC: MOV w23, w0                | W23 = 1152921513714424040 (0x100000021EDA98E8);//ML01
            val_5;
            // 0x00AD18D0: CBNZ x22, #0xad18d8        | if (this._writer != null) goto label_2; 
            if(this._writer != null)
            {
                goto label_2;
            }
            // 0x00AD18D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EDA98E8, ????);
            label_2:
            // 0x00AD18D8: LDR x8, [x22]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD18DC: MOV x0, x22                | X0 = this._writer;//m1                  
            // 0x00AD18E0: MOV w1, w23                | W1 = 1152921513714424040 (0x100000021EDA98E8);//ML01
            // 0x00AD18E4: LDR x9, [x8, #0x200]       | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200;
            // 0x00AD18E8: LDR x2, [x8, #0x208]       | X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_208;
            // 0x00AD18EC: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_200();
            label_1:
            // 0x00AD18F0: CBZ x20, #0xad1ad8         | if (s == null) goto label_15;           
            if(s == null)
            {
                goto label_15;
            }
            // 0x00AD18F4: LDR x8, [x19, #0x18]       | X8 = this._largeByteBuffer; //P2        
            // 0x00AD18F8: CBNZ x8, #0xad1978         | if (this._largeByteBuffer != null) goto label_4;
            if(this._largeByteBuffer != null)
            {
                goto label_4;
            }
            // 0x00AD18FC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00AD1900: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00AD1904: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
            // 0x00AD1908: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD190C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00AD1910: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
            // 0x00AD1914: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00AD1918: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00AD191C: STR x0, [x19, #0x18]       | this._largeByteBuffer = typeof(System.Byte[]);  //  dest_result_addr=1152921513714436168
            this._largeByteBuffer = null;
            // 0x00AD1920: ADRP x22, #0x3670000       | X22 = 57081856 (0x3670000);             
            // 0x00AD1924: LDR x22, [x22, #0x380]     | X22 = 1152921504857432064;              
            // 0x00AD1928: LDR x0, [x22]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_7 = null;
            // 0x00AD192C: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_10A;
            // 0x00AD1930: TBZ w8, #0, #0xad1944      | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AD1934: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00AD1938: CBNZ w8, #0xad1944         | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AD193C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            // 0x00AD1940: LDR x0, [x22]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_7 = null;
            label_6:
            // 0x00AD1944: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_static_fields;
            // 0x00AD1948: LDR x22, [x8]              | X22 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;
            // 0x00AD194C: CBNZ x22, #0xad1954        | if (Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null) goto label_7;
            if(Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null)
            {
                goto label_7;
            }
            // 0x00AD1950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            label_7:
            // 0x00AD1954: LDR x8, [x22]              | X8 =  typeof(System.Text.Encoding);     
            // 0x00AD1958: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD195C: MOV x0, x22                | X0 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            // 0x00AD1960: LDR x9, [x8, #0x280]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_280;
            // 0x00AD1964: LDR x2, [x8, #0x288]       | X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_288;
            // 0x00AD1968: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_280();
            // 0x00AD196C: ORR w8, wzr, #0x100        | W8 = 256(0x100);                        
            int val_4 = 256;
            // 0x00AD1970: SDIV w8, w8, w0            | W8 = (256 / Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding);
            val_4 = val_4 / Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;
            // 0x00AD1974: STR w8, [x19, #0x20]       | this._maxChars = (256 / Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding);  //  dest_result_addr=1152921513714436176
            this._maxChars = val_4;
            label_4:
            // 0x00AD1978: CMP w21, #0x100            | STATE = COMPARE(byteCount, 0x100)       
            // 0x00AD197C: B.LE #0xad1a44             | if (val_4 <= 256) goto label_8;         
            if(val_4 <= 256)
            {
                goto label_8;
            }
            // 0x00AD1980: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1984: MOV x0, x20                | X0 = s;//m1                             
            // 0x00AD1988: BL #0x18a4460              | X0 = s.get_Length();                    
            int val_1 = s.Length;
            // 0x00AD198C: MOV w21, w0                | W21 = val_1;//m1                        
            val_4 = val_1;
            // 0x00AD1990: CMP w21, #1                | STATE = COMPARE(val_1, 0x1)             
            // 0x00AD1994: B.LT #0xad1ad8             | if (val_4 < 1) goto label_15;           
            if(val_4 < 1)
            {
                goto label_15;
            }
            // 0x00AD1998: ADRP x27, #0x3670000       | X27 = 57081856 (0x3670000);             
            // 0x00AD199C: LDR x27, [x27, #0x380]     | X27 = 1152921504857432064;              
            // 0x00AD19A0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_5 = 0;
            label_14:
            // 0x00AD19A4: LDR x0, [x27]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_8 = null;
            // 0x00AD19A8: LDR w8, [x19, #0x20]       | W8 = this._maxChars; //P2               
            // 0x00AD19AC: LDRB w9, [x0, #0x10a]      | W9 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_10A;
            // 0x00AD19B0: CMP w21, w8                | STATE = COMPARE(val_1, this._maxChars)  
            // 0x00AD19B4: CSEL w23, w8, w21, gt      | W23 = val_4 > this._maxChars ? this._maxChars : val_1;
            var val_2 = (val_4 > this._maxChars) ? (this._maxChars) : (val_4);
            // 0x00AD19B8: TBZ w9, #0, #0xad19cc      | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00AD19BC: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00AD19C0: CBNZ w8, #0xad19cc         | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00AD19C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            // 0x00AD19C8: LDR x0, [x27]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_8 = null;
            label_11:
            // 0x00AD19CC: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_static_fields;
            // 0x00AD19D0: LDR x24, [x19, #0x18]      | X24 = this._largeByteBuffer; //P2       
            // 0x00AD19D4: LDR x25, [x8]              | X25 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;
            // 0x00AD19D8: CBNZ x25, #0xad19e0        | if (Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null) goto label_12;
            if(Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null)
            {
                goto label_12;
            }
            // 0x00AD19DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            label_12:
            // 0x00AD19E0: LDR x8, [x25]              | X8 =  typeof(System.Text.Encoding);     
            // 0x00AD19E4: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00AD19E8: MOV x0, x25                | X0 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            // 0x00AD19EC: MOV x1, x20                | X1 = s;//m1                             
            // 0x00AD19F0: LDP x9, x6, [x8, #0x1b0]   | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_1B0; X6 = typeof(System.Text.Encoding).__il2cppRuntimeField_1B8; //  | 
            // 0x00AD19F4: MOV w2, w22                | W2 = 0 (0x0);//ML01                     
            // 0x00AD19F8: MOV w3, w23                | W3 = val_4 > this._maxChars ? this._maxChars : val_1;//m1
            // 0x00AD19FC: MOV x4, x24                | X4 = this._largeByteBuffer;//m1         
            // 0x00AD1A00: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_1B0();
            // 0x00AD1A04: LDP x25, x26, [x19, #0x10] | X25 = this._writer; //P2  X26 = this._largeByteBuffer; //P2  //  | 
            // 0x00AD1A08: MOV w24, w0                | W24 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            // 0x00AD1A0C: CBNZ x25, #0xad1a14        | if (this._writer != null) goto label_13;
            if(this._writer != null)
            {
                goto label_13;
            }
            // 0x00AD1A10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            label_13:
            // 0x00AD1A14: LDR x8, [x25]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD1A18: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_6 = 0;
            // 0x00AD1A1C: MOV x0, x25                | X0 = this._writer;//m1                  
            // 0x00AD1A20: MOV x1, x26                | X1 = this._largeByteBuffer;//m1         
            // 0x00AD1A24: LDP x9, x4, [x8, #0x1d0]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1D0; X4 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1D8; //  | 
            // 0x00AD1A28: MOV w3, w24                | W3 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            // 0x00AD1A2C: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1D0();
            // 0x00AD1A30: ADD w22, w23, w22          | W22 = (val_4 > this._maxChars ? this._maxChars : val_1 + 0);
            val_5 = val_2 + val_5;
            // 0x00AD1A34: SUB w21, w21, w23          | W21 = (val_1 - val_4 > this._maxChars ? this._maxChars : val_1);
            val_4 = val_4 - val_2;
            // 0x00AD1A38: CMP w21, #0                | STATE = COMPARE((val_1 - val_4 > this._maxChars ? this._maxChars : val_1), 0x0)
            // 0x00AD1A3C: B.GT #0xad19a4             | if (val_4 > 0) goto label_14;           
            if(val_4 > 0)
            {
                goto label_14;
            }
            // 0x00AD1A40: B #0xad1ad8                |  goto label_15;                         
            goto label_15;
            label_8:
            // 0x00AD1A44: ADRP x22, #0x3670000       | X22 = 57081856 (0x3670000);             
            // 0x00AD1A48: LDR x22, [x22, #0x380]     | X22 = 1152921504857432064;              
            // 0x00AD1A4C: LDR x0, [x22]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_9 = null;
            // 0x00AD1A50: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_10A;
            // 0x00AD1A54: TBZ w8, #0, #0xad1a68      | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00AD1A58: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00AD1A5C: CBNZ w8, #0xad1a68         | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00AD1A60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            // 0x00AD1A64: LDR x0, [x22]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_9 = null;
            label_17:
            // 0x00AD1A68: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_static_fields;
            // 0x00AD1A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1A70: MOV x0, x20                | X0 = s;//m1                             
            // 0x00AD1A74: LDR x22, [x8]              | X22 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;
            // 0x00AD1A78: BL #0x18a4460              | X0 = s.get_Length();                    
            int val_3 = s.Length;
            // 0x00AD1A7C: LDR x23, [x19, #0x18]      | X23 = this._largeByteBuffer; //P2       
            val_5 = this._largeByteBuffer;
            // 0x00AD1A80: MOV w24, w0                | W24 = val_3;//m1                        
            // 0x00AD1A84: CBNZ x22, #0xad1a8c        | if (Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null) goto label_18;
            if(Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null)
            {
                goto label_18;
            }
            // 0x00AD1A88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_18:
            // 0x00AD1A8C: LDR x8, [x22]              | X8 =  typeof(System.Text.Encoding);     
            // 0x00AD1A90: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD1A94: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x00AD1A98: MOV x0, x22                | X0 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            // 0x00AD1A9C: LDP x9, x6, [x8, #0x1b0]   | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_1B0; X6 = typeof(System.Text.Encoding).__il2cppRuntimeField_1B8; //  | 
            // 0x00AD1AA0: MOV x1, x20                | X1 = s;//m1                             
            // 0x00AD1AA4: MOV w3, w24                | W3 = val_3;//m1                         
            // 0x00AD1AA8: MOV x4, x23                | X4 = this._largeByteBuffer;//m1         
            // 0x00AD1AAC: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_1B0();
            // 0x00AD1AB0: LDP x20, x22, [x19, #0x10] | X20 = this._writer; //P2  X22 = this._largeByteBuffer; //P2  //  | 
            // 0x00AD1AB4: CBNZ x20, #0xad1abc        | if (this._writer != null) goto label_19;
            if(this._writer != null)
            {
                goto label_19;
            }
            // 0x00AD1AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            label_19:
            // 0x00AD1ABC: LDR x8, [x20]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD1AC0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            val_6 = 0;
            // 0x00AD1AC4: MOV x0, x20                | X0 = this._writer;//m1                  
            // 0x00AD1AC8: MOV x1, x22                | X1 = this._largeByteBuffer;//m1         
            // 0x00AD1ACC: LDP x9, x4, [x8, #0x1d0]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1D0; X4 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1D8; //  | 
            // 0x00AD1AD0: MOV w3, w21                | W3 = byteCount;//m1                     
            // 0x00AD1AD4: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1D0();
            label_15:
            // 0x00AD1AD8: LDR x19, [x19, #0x10]      | X19 = this._writer; //P2                
            // 0x00AD1ADC: CBNZ x19, #0xad1ae4        | if (this._writer != null) goto label_20;
            if(this._writer != null)
            {
                goto label_20;
            }
            // 0x00AD1AE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._writer, ????);
            label_20:
            // 0x00AD1AE4: LDR x8, [x19]              | X8 = typeof(System.IO.BinaryWriter);    
            // 0x00AD1AE8: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00AD1AEC: MOV x0, x19                | X0 = this._writer;//m1                  
            // 0x00AD1AF0: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1B0; X2 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1B8; //  | 
            // 0x00AD1AF4: BLR x9                     | X0 = typeof(System.IO.BinaryWriter).__il2cppRuntimeField_1B0();
            // 0x00AD1AF8: SUB sp, x29, #0x50         | SP = (1152921513714424128 - 80) = 1152921513714424048 (0x100000021EDA98F0);
            // 0x00AD1AFC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1B00: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1B04: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD1B08: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD1B0C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD1B10: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AD1B14: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B28 (11344680), len: 8  VirtAddr: 0x00AD1B28 RVA: 0x00AD1B28 token: 100684717 methodIndex: 47367 delegateWrapperIndex: 0 methodInvoker: 0
        private int CalculateSize(int stringByteCount)
        {
            //
            // Disasemble & Code
            // 0x00AD1B28: ADD w0, w1, #1             | W0 = (stringByteCount + 1);             
            int val_1 = stringByteCount + 1;
            // 0x00AD1B2C: RET                        |  return (System.Int32)(stringByteCount + 1);
            return val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B30 (11344688), len: 24  VirtAddr: 0x00AD1B30 RVA: 0x00AD1B30 token: 100684718 methodIndex: 47368 delegateWrapperIndex: 0 methodInvoker: 0
        private int CalculateSizeWithLength(int stringByteCount, bool includeSize)
        {
            //
            // Disasemble & Code
            // 0x00AD1B30: TST w2, #1                 | STATE = COMPARE(includeSize, 0x1)       
            // 0x00AD1B34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1B38: MOVZ w9, #0x5              | W9 = 5 (0x5);//ML01                     
            // 0x00AD1B3C: CSEL w8, w9, w8, ne        | W8 = includeSize != true ? 5 : 1;       
            var val_1 = (includeSize != true) ? 5 : (1);
            // 0x00AD1B40: ADD w0, w8, w1             | W0 = (includeSize != true ? 5 : 1 + stringByteCount);
            int val_2 = val_1 + stringByteCount;
            // 0x00AD1B44: RET                        |  return (System.Int32)(includeSize != true ? 5 : 1 + stringByteCount);
            return val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACFA2C (11336236), len: 2648  VirtAddr: 0x00ACFA2C RVA: 0x00ACFA2C token: 100684719 methodIndex: 47369 delegateWrapperIndex: 0 methodInvoker: 0
        private int CalculateSize(Newtonsoft.Json.Bson.BsonToken t)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_8;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            Newtonsoft.Json.Bson.BsonToken val_36;
            //  | 
            Newtonsoft.Json.Bson.BsonToken val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            //  | 
            System.Text.Encoding val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            var val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            var val_49;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            label_87:
            // 0x00ACFA2C: STP x28, x27, [sp, #-0x60]! | stack[1152921513714990448] = ???;  stack[1152921513714990456] = ???;  //  dest_result_addr=1152921513714990448 |  dest_result_addr=1152921513714990456
            // 0x00ACFA30: STP x26, x25, [sp, #0x10]  | stack[1152921513714990464] = ???;  stack[1152921513714990472] = ???;  //  dest_result_addr=1152921513714990464 |  dest_result_addr=1152921513714990472
            // 0x00ACFA34: STP x24, x23, [sp, #0x20]  | stack[1152921513714990480] = ???;  stack[1152921513714990488] = ???;  //  dest_result_addr=1152921513714990480 |  dest_result_addr=1152921513714990488
            // 0x00ACFA38: STP x22, x21, [sp, #0x30]  | stack[1152921513714990496] = ???;  stack[1152921513714990504] = ???;  //  dest_result_addr=1152921513714990496 |  dest_result_addr=1152921513714990504
            // 0x00ACFA3C: STP x20, x19, [sp, #0x40]  | stack[1152921513714990512] = ???;  stack[1152921513714990520] = ???;  //  dest_result_addr=1152921513714990512 |  dest_result_addr=1152921513714990520
            // 0x00ACFA40: STP x29, x30, [sp, #0x50]  | stack[1152921513714990528] = ???;  stack[1152921513714990536] = ???;  //  dest_result_addr=1152921513714990528 |  dest_result_addr=1152921513714990536
            // 0x00ACFA44: ADD x29, sp, #0x50         | X29 = (1152921513714990448 + 80) = 1152921513714990528 (0x100000021EE33DC0);
            // 0x00ACFA48: SUB sp, sp, #0x40          | SP = (1152921513714990448 - 64) = 1152921513714990384 (0x100000021EE33D30);
            // 0x00ACFA4C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00ACFA50: LDRB w8, [x21, #0x4c9]     | W8 = (bool)static_value_037334C9;       
            // 0x00ACFA54: MOV x19, x1                | X19 = t;//m1                            
            val_36 = t;
            // 0x00ACFA58: MOV x20, x0                | X20 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00ACFA5C: TBNZ w8, #0, #0xacfa78     | if (static_value_037334C9 == true) goto label_0;
            // 0x00ACFA60: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00ACFA64: LDR x8, [x8, #0x918]       | X8 = 0x2B8F96C;                         
            // 0x00ACFA68: LDR w0, [x8]               | W0 = 0x151F;                            
            // 0x00ACFA6C: BL #0x2782188              | X0 = sub_2782188( ?? 0x151F, ????);     
            // 0x00ACFA70: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00ACFA74: STRB w8, [x21, #0x4c9]     | static_value_037334C9 = true;            //  dest_result_addr=57881801
            label_0:
            // 0x00ACFA78: CBNZ x19, #0xacfa80        | if (t != null) goto label_1;            
            if(val_36 != null)
            {
                goto label_1;
            }
            // 0x00ACFA7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x151F, ????);     
            label_1:
            // 0x00ACFA80: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00ACFA84: MOV x0, x19                | X0 = t;//m1                             
            // 0x00ACFA88: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150; X1 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_158; //  | 
            // 0x00ACFA8C: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150();
            // 0x00ACFA90: SXTB w8, w0                | W8 = (int)(sbyte)((t) & 0xFF);          
            var val_34 = (int)val_36 & 255;
            // 0x00ACFA94: SUB w8, w8, #1             | W8 = ((int)(sbyte)((t) & 0xFF) - 1);    
            val_34 = val_34 - 1;
            // 0x00ACFA98: CMP w8, #0x11              | STATE = COMPARE(((int)(sbyte)((t) & 0xFF) - 1), 0x11)
            // 0x00ACFA9C: B.HI #0xad02f4             | if ((int)val_36 & 255 > 0x11) goto label_2;
            if(val_34 > 17)
            {
                goto label_2;
            }
            // 0x00ACFAA0: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00ACFAA4: ADD x9, x9, #0x660         | X9 = (44638208 + 1632) = 44639840 (0x02A92660);
            // 0x00ACFAA8: LDR w8, [x9, w8, sxtw #2]  | W8 = 44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2;
            // 0x00ACFAAC: ORR w21, wzr, #4           | W21 = 4(0x4);                           
            val_37 = 4;
            // 0x00ACFAB0: CMP w8, #0xf               | STATE = COMPARE(44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2, 0xF)
            // 0x00ACFAB4: B.HI #0xad02b8             | if (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2 > 0xF) goto label_89;
            if((44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) > 15)
            {
                goto label_89;
            }
            // 0x00ACFAB8: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
            // 0x00ACFABC: ADD x9, x9, #0x4d8         | X9 = (44638208 + 1240) = 44639448 (0x02A924D8);
            // 0x00ACFAC0: LDRSW x8, [x9, x8, lsl #2] | X8 = 44639448 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2;
            var val_35 = 44639448 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2;
            // 0x00ACFAC4: ADD x8, x8, x9             | X8 = (44639448 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2 + 44639448);
            val_35 = val_35 + 44639448;
            // 0x00ACFAC8: BR x8                      | goto (44639448 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2 + 44639448);
            goto (44639448 + (44639840 + (((int)(sbyte)((t) & 0xFF) - 1)) << 2) << 2 + 44639448);
            // 0x00ACFACC: ORR w21, wzr, #8           | W21 = 8(0x8);                           
            val_37 = 8;
            // 0x00ACFAD0: B #0xad02b8                |  goto label_89;                         
            goto label_89;
            // 0x00ACFAD4: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00ACFAD8: LDR x9, [x9, #0x188]       | X9 = 1152921504857911296;               
            // 0x00ACFADC: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00ACFAE0: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonString);
            // 0x00ACFAE4: LDRB w10, [x8, #0x104]     | W10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00ACFAE8: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00ACFAEC: CMP w10, w9                | STATE = COMPARE(Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth, Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00ACFAF0: B.LO #0xacfb08             | if (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchyDepth < Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00ACFAF4: LDR x10, [x8, #0xb0]       | X10 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy;
            // 0x00ACFAF8: ADD x9, x10, x9, lsl #3    | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.Bson
            // 0x00ACFAFC: LDUR x9, [x9, #-8]         | X9 = (Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00ACFB00: CMP x9, x1                 | STATE = COMPARE((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonString))
            // 0x00ACFB04: B.EQ #0xacfd94             | if ((Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_typeHierarchy + (Newtonsoft.Json.Bson.BsonString.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_6;
            label_5:
            // 0x00ACFB08: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class;
            // 0x00ACFB0C: ADD x8, sp, #0x18          | X8 = (1152921513714990384 + 24) = 1152921513714990408 (0x100000021EE33D48);
            // 0x00ACFB10: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonToken.__il2cppRuntimeField_element_class, ????);
            // 0x00ACFB14: LDR x0, [sp, #0x18]        | X0 = val_2;                              //  find_add[1152921513714978544]
            // 0x00ACFB18: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00ACFB1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFB20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00ACFB24: ADD x0, sp, #0x18          | X0 = (1152921513714990384 + 24) = 1152921513714990408 (0x100000021EE33D48);
            // 0x00ACFB28: BL #0x299a140              | 
            // 0x00ACFB2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D48, ????);
            // 0x00ACFB30: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_36 = 0;
            // 0x00ACFB34: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_38 = 1;
            // 0x00ACFB38: B #0xacfd98                |  goto label_7;                          
            goto label_7;
            // 0x00ACFB3C: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x00ACFB40: LDR x9, [x9, #0xcd8]       | X9 = 1152921504857751552;               
            // 0x00ACFB44: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
            // 0x00ACFB48: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonObject);
            // 0x00ACFB4C: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00ACFB50: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00ACFB54: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00ACFB58: B.LO #0xacfb70             | if (mem[282584257676931] < Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x00ACFB5C: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00ACFB60: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDept
            // 0x00ACFB64: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00ACFB68: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonObject))
            // 0x00ACFB6C: B.EQ #0xacfe9c             | if ((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonObject.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x00ACFB70: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00ACFB74: ADD x8, sp, #8             | X8 = (1152921513714990384 + 8) = 1152921513714990392 (0x100000021EE33D38);
            // 0x00ACFB78: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00ACFB7C: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921513714978544]
            // 0x00ACFB80: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00ACFB84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFB88: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00ACFB8C: ADD x0, sp, #8             | X0 = (1152921513714990384 + 8) = 1152921513714990392 (0x100000021EE33D38);
            // 0x00ACFB90: BL #0x299a140              | 
            // 0x00ACFB94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D38, ????);
            // 0x00ACFB98: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x00ACFB9C: ORR w25, wzr, #1           | W25 = 1(0x1);                           
            // 0x00ACFBA0: B #0xacfea0                |  goto label_10;                         
            goto label_10;
            // 0x00ACFBA4: ADRP x9, #0x366a000        | X9 = 57057280 (0x366A000);              
            // 0x00ACFBA8: LDR x9, [x9, #0x6c8]       | X9 = 1152921504857804800;               
            // 0x00ACFBAC: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
            // 0x00ACFBB0: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonArray);
            // 0x00ACFBB4: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00ACFBB8: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00ACFBBC: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00ACFBC0: B.LO #0xacfbd8             | if (mem[282584257676931] < Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) goto label_11;
            // 0x00ACFBC4: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00ACFBC8: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth
            // 0x00ACFBCC: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00ACFBD0: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonArray))
            // 0x00ACFBD4: B.EQ #0xad0078             | if ((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonArray.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_12;
            label_11:
            // 0x00ACFBD8: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00ACFBDC: ADD x8, sp, #0x10          | X8 = (1152921513714990384 + 16) = 1152921513714990400 (0x100000021EE33D40);
            // 0x00ACFBE0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00ACFBE4: LDR x0, [sp, #0x10]        | X0 = val_6;                              //  find_add[1152921513714978544]
            // 0x00ACFBE8: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x00ACFBEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFBF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x00ACFBF4: ADD x0, sp, #0x10          | X0 = (1152921513714990384 + 16) = 1152921513714990400 (0x100000021EE33D40);
            // 0x00ACFBF8: BL #0x299a140              | 
            // 0x00ACFBFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D40, ????);
            // 0x00ACFC00: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x00ACFC04: ORR w24, wzr, #1           | W24 = 1(0x1);                           
            // 0x00ACFC08: B #0xad007c                |  goto label_13;                         
            goto label_13;
            // 0x00ACFC0C: ADRP x9, #0x35ef000        | X9 = 56553472 (0x35EF000);              
            // 0x00ACFC10: LDR x9, [x9, #0x818]       | X9 = 1152921504857858048;               
            // 0x00ACFC14: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
            // 0x00ACFC18: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonValue);
            // 0x00ACFC1C: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00ACFC20: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00ACFC24: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00ACFC28: B.LO #0xacfc40             | if (mem[282584257676931] < Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) goto label_14;
            // 0x00ACFC2C: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00ACFC30: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth
            // 0x00ACFC34: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00ACFC38: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonValue))
            // 0x00ACFC3C: B.EQ #0xacfd0c             | if ((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonValue.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_15;
            label_14:
            // 0x00ACFC40: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00ACFC44: ADD x8, sp, #0x28          | X8 = (1152921513714990384 + 40) = 1152921513714990424 (0x100000021EE33D58);
            // 0x00ACFC48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00ACFC4C: LDR x0, [sp, #0x28]        | X0 = val_8;                              //  find_add[1152921513714978544]
            // 0x00ACFC50: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x00ACFC54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFC58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x00ACFC5C: ADD x0, sp, #0x28          | X0 = (1152921513714990384 + 40) = 1152921513714990424 (0x100000021EE33D58);
            // 0x00ACFC60: BL #0x299a140              | 
            // 0x00ACFC64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D58, ????);
            // 0x00ACFC68: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_36 = 0;
            // 0x00ACFC6C: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            val_39 = 1;
            // 0x00ACFC70: B #0xacfd10                |  goto label_16;                         
            goto label_16;
            // 0x00ACFC74: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_37 = 0;
            // 0x00ACFC78: B #0xad02b8                |  goto label_89;                         
            goto label_89;
            // 0x00ACFC7C: ORR w21, wzr, #0xc         | W21 = 12(0xC);                          
            val_37 = 12;
            // 0x00ACFC80: B #0xad02b8                |  goto label_89;                         
            goto label_89;
            // 0x00ACFC84: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            val_37 = 1;
            // 0x00ACFC88: B #0xad02b8                |  goto label_89;                         
            goto label_89;
            // 0x00ACFC8C: ADRP x9, #0x3639000        | X9 = 56856576 (0x3639000);              
            // 0x00ACFC90: LDR x9, [x9, #0x98]        | X9 = 1152921504857964544;               
            // 0x00ACFC94: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
            // 0x00ACFC98: LDR x1, [x9]               | X1 = typeof(Newtonsoft.Json.Bson.BsonRegex);
            // 0x00ACFC9C: LDRB w10, [x8, #0x104]     | W10 = (bool)mem[282584257676931];       
            // 0x00ACFCA0: LDRB w9, [x1, #0x104]      | W9 = Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00ACFCA4: CMP w10, w9                | STATE = COMPARE(mem[282584257676931], Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00ACFCA8: B.LO #0xacfcc0             | if (mem[282584257676931] < Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) goto label_20;
            // 0x00ACFCAC: LDR x10, [x8, #0xb0]       | X10 = mem[282584257676847];             
            // 0x00ACFCB0: ADD x9, x10, x9, lsl #3    | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth
            // 0x00ACFCB4: LDUR x9, [x9, #-8]         | X9 = (mem[282584257676847] + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00ACFCB8: CMP x9, x1                 | STATE = COMPARE((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Newtonsoft.Json.Bson.BsonRegex))
            // 0x00ACFCBC: B.EQ #0xad0274             | if ((mem[282584257676847] + (Newtonsoft.Json.Bson.BsonRegex.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_21;
            label_20:
            // 0x00ACFCC0: LDR x0, [x8, #0x30]        | X0 = mem[282584257676719];              
            // 0x00ACFCC4: ADD x8, sp, #0x38          | X8 = (1152921513714990384 + 56) = 1152921513714990440 (0x100000021EE33D68);
            // 0x00ACFCC8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[282584257676719], ????);
            // 0x00ACFCCC: LDR x0, [sp, #0x38]        | X0 = val_10;                             //  find_add[1152921513714978544]
            // 0x00ACFCD0: BL #0x27af090              | X0 = sub_27AF090( ?? val_10, ????);     
            // 0x00ACFCD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFCD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            // 0x00ACFCDC: ADD x0, sp, #0x38          | X0 = (1152921513714990384 + 56) = 1152921513714990440 (0x100000021EE33D68);
            // 0x00ACFCE0: BL #0x299a140              | 
            // 0x00ACFCE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D68, ????);
            // 0x00ACFCE8: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
            // 0x00ACFCEC: LDR x1, [x8]               | X1 = 0x40;                              
            // 0x00ACFCF0: MOV x0, x20                | X0 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00ACFCF4: BL #0xacfa2c               |  R0 = label_87();                       
            // 0x00ACFCF8: MOV w21, w0                | W21 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            val_40 = this;
            // 0x00ACFCFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00ACFD00: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_36 = 0;
            // 0x00ACFD04: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_41 = 1;
            // 0x00ACFD08: B #0xad0288                |  goto label_23;                         
            goto label_23;
            label_15:
            // 0x00ACFD0C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_39 = 0;
            label_16:
            // 0x00ACFD10: LDR x20, [x19, #0x20]      | X20 = 0x40;                             
            // 0x00ACFD14: CBZ x20, #0xacfd64         | if (0x40 == 0) goto label_24;           
            if(64 == 0)
            {
                goto label_24;
            }
            // 0x00ACFD18: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00ACFD1C: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00ACFD20: MOV x0, x20                | X0 = 64 (0x40);//ML01                   
            // 0x00ACFD24: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
            // 0x00ACFD28: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00ACFD2C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 0x40, ????);       
            // 0x00ACFD30: MOV x22, x0                | X22 = 64 (0x40);//ML01                  
            val_42 = 64;
            // 0x00ACFD34: CBNZ x22, #0xacfd6c        | if (0x40 != 0) goto label_25;           
            if(val_42 != 0)
            {
                goto label_25;
            }
            // 0x00ACFD38: LDR x8, [x20]              | X8 = 0x500000001;                       
            // 0x00ACFD3C: MOV x1, x21                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00ACFD40: LDR x0, [x8, #0x30]        | X0 = mem[21474836529];                  
            // 0x00ACFD44: ADD x8, sp, #0x30          | X8 = (1152921513714990384 + 48) = 1152921513714990432 (0x100000021EE33D60);
            // 0x00ACFD48: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[21474836529], ????);
            // 0x00ACFD4C: LDR x0, [sp, #0x30]        | X0 = val_11;                             //  find_add[1152921513714978544]
            // 0x00ACFD50: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x00ACFD54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFD58: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x00ACFD5C: ADD x0, sp, #0x30          | X0 = (1152921513714990384 + 48) = 1152921513714990432 (0x100000021EE33D60);
            // 0x00ACFD60: BL #0x299a140              | 
            label_24:
            // 0x00ACFD64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D60, ????);
            // 0x00ACFD68: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_42 = 0;
            label_25:
            // 0x00ACFD6C: TBZ w23, #0, #0xacfd88     | if ((0x0 & 0x1) == 0) goto label_26;    
            if((val_39 & 1) == 0)
            {
                goto label_26;
            }
            // 0x00ACFD70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000021EE33D60, ????);
            // 0x00ACFD74: LDR w8, [x22, #0x18]       | W8 = 0x9814C0;                          
            // 0x00ACFD78: ORR w19, wzr, #0x18        | W19 = 24(0x18);                         
            val_36 = 24;
            // 0x00ACFD7C: ADD w8, w8, #5             | W8 = (9966784 + 5) = 9966789 (0x009814C5);
            // 0x00ACFD80: STR w8, [x19]              | mem[24] = 0x9814C5;                      //  dest_result_addr=24
            mem[24] = 9966789;
            // 0x00ACFD84: B #0xad02a8                |  goto label_27;                         
            goto label_27;
            label_26:
            // 0x00ACFD88: LDR w8, [x22, #0x18]       | W8 = 0x9814C5;                          
            // 0x00ACFD8C: ADD w21, w8, #5            | W21 = (mem[24] + 5);                    
            val_37 = mem[24] + 5;
            // 0x00ACFD90: B #0xad02b4                |  goto label_88;                         
            goto label_88;
            label_6:
            // 0x00ACFD94: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_38 = 0;
            label_7:
            // 0x00ACFD98: LDR x20, [x19, #0x20]      | 
            // 0x00ACFD9C: CBZ x20, #0xacfddc         | if (this == null) goto label_29;        
            if(this == null)
            {
                goto label_29;
            }
            // 0x00ACFDA0: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00ACFDA4: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00ACFDA8: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x00ACFDAC: LDR x8, [x20]              | X8 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            // 0x00ACFDB0: CMP x8, x1                 | STATE = COMPARE(typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), typeof(System.String))
            // 0x00ACFDB4: B.EQ #0xacfde4             | if (typeof(Newtonsoft.Json.Bson.BsonBinaryWriter) == null) goto label_30;
            if(null == null)
            {
                goto label_30;
            }
            // 0x00ACFDB8: LDR x0, [x8, #0x30]        | X0 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_element_class;
            // 0x00ACFDBC: ADD x8, sp, #0x20          | X8 = (1152921513714990384 + 32) = 1152921513714990416 (0x100000021EE33D50);
            // 0x00ACFDC0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_element_class, ????);
            // 0x00ACFDC4: LDR x0, [sp, #0x20]        | X0 = val_12;                             //  find_add[1152921513714978544]
            // 0x00ACFDC8: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x00ACFDCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACFDD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x00ACFDD4: ADD x0, sp, #0x20          | X0 = (1152921513714990384 + 32) = 1152921513714990416 (0x100000021EE33D50);
            // 0x00ACFDD8: BL #0x299a140              | 
            label_29:
            // 0x00ACFDDC: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_43 = 0;
            // 0x00ACFDE0: B #0xacfe30                |  goto label_31;                         
            goto label_31;
            label_30:
            // 0x00ACFDE4: ADRP x21, #0x3670000       | X21 = 57081856 (0x3670000);             
            // 0x00ACFDE8: LDR x21, [x21, #0x380]     | X21 = 1152921504857432064;              
            // 0x00ACFDEC: LDR x0, [x21]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_44 = null;
            // 0x00ACFDF0: LDRB w8, [x0, #0x10a]      | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_10A;
            // 0x00ACFDF4: TBZ w8, #0, #0xacfe08      | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x00ACFDF8: LDR w8, [x0, #0xbc]        | W8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished;
            // 0x00ACFDFC: CBNZ w8, #0xacfe08         | if (Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x00ACFE00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            // 0x00ACFE04: LDR x0, [x21]              | X0 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            val_44 = null;
            label_33:
            // 0x00ACFE08: LDR x8, [x0, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_static_fields;
            // 0x00ACFE0C: LDR x21, [x8]              | X21 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;
            // 0x00ACFE10: CBNZ x21, #0xacfe18        | if (Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null) goto label_34;
            if(Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding != null)
            {
                goto label_34;
            }
            // 0x00ACFE14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            label_34:
            // 0x00ACFE18: LDR x8, [x21]              | X8 =  typeof(System.Text.Encoding);     
            // 0x00ACFE1C: MOV x0, x21                | X0 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            // 0x00ACFE20: MOV x1, x20                | X1 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00ACFE24: LDP x9, x2, [x8, #0x180]   | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_180; X2 = typeof(System.Text.Encoding).__il2cppRuntimeField_188; //  | 
            // 0x00ACFE28: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_180();
            // 0x00ACFE2C: MOV w20, w0                | W20 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;//m1
            val_43 = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;
            label_31:
            // 0x00ACFE30: TBZ w22, #0, #0xacfe7c     | if ((0x0 & 0x1) == 0) goto label_35;    
            if((val_38 & 1) == 0)
            {
                goto label_35;
            }
            // 0x00ACFE34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            // 0x00ACFE38: STR w20, [x19, #0x2c]      | mem2[0] = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;  //  dest_result_addr=0
            mem2[0] = val_43;
            // 0x00ACFE3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            // 0x00ACFE40: LDR w19, [x19, #0x2c]      | 
            // 0x00ACFE44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            // 0x00ACFE48: ORR w8, wzr, #0x30         | W8 = 48(0x30);                          
            // 0x00ACFE4C: LDRB w8, [x8]              | W8 = 0x0;                               
            // 0x00ACFE50: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00ACFE54: CMP w8, #0                 | STATE = COMPARE(0x0, 0x0)               
            // 0x00ACFE58: MOVZ w8, #0x5              | W8 = 5 (0x5);//ML01                     
            // 0x00ACFE5C: CSEL w8, w8, w9, ne        | W8 = 0 != 0x0 ? 5 : 1;                  
            var val_13 = (0 != 0) ? 5 : (1);
            // 0x00ACFE60: ADD w19, w8, w19           | W19 = (0 != 0x0 ? 5 : 1 + t);           
            val_36 = val_13 + val_36;
            // 0x00ACFE64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            // 0x00ACFE68: ORR w20, wzr, #0x18        | W20 = 24(0x18);                         
            // 0x00ACFE6C: STR w19, [x20]             | mem[24] = (0 != 0x0 ? 5 : 1 + t);        //  dest_result_addr=24
            mem[24] = val_36;
            // 0x00ACFE70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding, ????);
            // 0x00ACFE74: LDR w21, [x20]             | W21 = (0 != 0x0 ? 5 : 1 + t);           
            val_37 = mem[24];
            // 0x00ACFE78: B #0xad02b8                |  goto label_89;                         
            goto label_89;
            label_35:
            // 0x00ACFE7C: LDRB w8, [x19, #0x30]      | 
            // 0x00ACFE80: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00ACFE84: STR w20, [x19, #0x2c]      | mem2[0] = Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding;  //  dest_result_addr=0
            mem2[0] = val_43;
            // 0x00ACFE88: CMP w8, #0                 | STATE = COMPARE(Encoding, 0x0)          
            // 0x00ACFE8C: MOVZ w8, #0x5              | W8 = 5 (0x5);//ML01                     
            // 0x00ACFE90: CSEL w8, w8, w9, ne        | W8 = Encoding != null ? 5 : 1;          
            var val_14 = (null != 0) ? 5 : (1);
            // 0x00ACFE94: ADD w21, w8, w20           | W21 = (Encoding != null ? 5 : 1 + Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding);
            val_37 = val_14 + val_43;
            // 0x00ACFE98: B #0xad02b4                |  goto label_88;                         
            goto label_88;
            label_9:
            // 0x00ACFE9C: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            label_10:
            // 0x00ACFEA0: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x00ACFEA4: BL #0xad1798               | X0 = val_36.GetEnumerator();            
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty> val_15 = val_36.GetEnumerator();
            // 0x00ACFEA8: ADRP x26, #0x361c000       | X26 = 56737792 (0x361C000);             
            // 0x00ACFEAC: ADRP x27, #0x3661000       | X27 = 57020416 (0x3661000);             
            // 0x00ACFEB0: LDR x26, [x26, #0x358]     | X26 = 1152921504608018432;              
            // 0x00ACFEB4: LDR x27, [x27, #0x230]     | X27 = 1152921504608178176;              
            // 0x00ACFEB8: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x00ACFEBC: MOVZ w21, #0x5             | W21 = 5 (0x5);//ML01                    
            // 0x00ACFEC0: B #0xacfed0                |  goto label_38;                         
            goto label_38;
            label_53:
            // 0x00ACFEC4: ADD w8, w21, w24           | W8 = (5 + W24);                         
            var val_16 = 5 + W24;
            // 0x00ACFEC8: ADD w8, w8, w0             | W8 = ((5 + W24) + val_15);              
            val_16 = val_16 + val_15;
            // 0x00ACFECC: ADD w21, w8, #1            | W21 = (((5 + W24) + val_15) + 1);       
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty> val_17 = val_16 + 1;
            label_38:
            // 0x00ACFED0: CBNZ x22, #0xacfed8        | if (val_15 != null) goto label_39;      
            if(val_15 != null)
            {
                goto label_39;
            }
            // 0x00ACFED4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_39:
            // 0x00ACFED8: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00ACFEDC: LDR x1, [x26]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00ACFEE0: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00ACFEE4: CBZ x9, #0xacff10          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_40;
            // 0x00ACFEE8: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00ACFEEC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_36 = 0;
            // 0x00ACFEF0: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_42:
            // 0x00ACFEF4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00ACFEF8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00ACFEFC: B.EQ #0xacff20             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_41;
            // 0x00ACFF00: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_36 = val_36 + 1;
            // 0x00ACFF04: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00ACFF08: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00ACFF0C: B.LO #0xacfef4             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_42;
            label_40:
            // 0x00ACFF10: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00ACFF14: MOV x0, x22                | X0 = val_15;//m1                        
            val_45 = val_15;
            // 0x00ACFF18: BL #0x2776c24              | X0 = sub_2776C24( ?? val_15, ????);     
            // 0x00ACFF1C: B #0xacff30                |  goto label_43;                         
            goto label_43;
            label_41:
            // 0x00ACFF20: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00ACFF24: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00ACFF28: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00ACFF2C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_43:
            // 0x00ACFF30: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);  //  | 
            // 0x00ACFF34: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x00ACFF38: BLR x8                     | X0 = sub_1000000000145000( ?? val_15, ????);
            // 0x00ACFF3C: AND w8, w0, #1             | W8 = (val_15 & 1);                      
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty> val_19 = val_15 & 1;
            // 0x00ACFF40: TBZ w8, #0, #0xad02e8      | if (((val_15 & 1) & 0x1) == 0) goto label_44;
            if((val_19 & 1) == 0)
            {
                goto label_44;
            }
            // 0x00ACFF44: CBNZ x22, #0xacff4c        | if (val_15 != null) goto label_45;      
            if(val_15 != null)
            {
                goto label_45;
            }
            // 0x00ACFF48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_45:
            // 0x00ACFF4C: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00ACFF50: LDR x1, [x27]              | X1 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00ACFF54: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00ACFF58: CBZ x9, #0xacff84          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_46;
            // 0x00ACFF5C: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00ACFF60: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_37 = 0;
            // 0x00ACFF64: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_48:
            // 0x00ACFF68: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00ACFF6C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IEnumerator<T>))
            // 0x00ACFF70: B.EQ #0xacff94             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_47;
            // 0x00ACFF74: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_37 = val_37 + 1;
            // 0x00ACFF78: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00ACFF7C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00ACFF80: B.LO #0xacff68             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_48;
            label_46:
            // 0x00ACFF84: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00ACFF88: MOV x0, x22                | X0 = val_15;//m1                        
            val_46 = val_15;
            // 0x00ACFF8C: BL #0x2776c24              | X0 = sub_2776C24( ?? val_15, ????);     
            // 0x00ACFF90: B #0xacffa0                |  goto label_49;                         
            goto label_49;
            label_47:
            // 0x00ACFF94: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00ACFF98: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00ACFF9C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_49:
            // 0x00ACFFA0: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);  //  | 
            // 0x00ACFFA4: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x00ACFFA8: BLR x8                     | X0 = sub_1000000000145000( ?? val_15, ????);
            // 0x00ACFFAC: MOV x23, x0                | X23 = val_15;//m1                       
            // 0x00ACFFB0: CBNZ x23, #0xacffb8        | if (val_15 != null) goto label_50;      
            if(val_15 != null)
            {
                goto label_50;
            }
            // 0x00ACFFB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_50:
            // 0x00ACFFB8: LDR x1, [x23, #0x10]       | 
            // 0x00ACFFBC: MOV x0, x20                | X0 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00ACFFC0: BL #0xacfa2c               |  R0 = label_87();                       
            // 0x00ACFFC4: MOV w24, w0                | W24 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00ACFFC8: LDR x1, [x23, #0x18]       | 
            // 0x00ACFFCC: MOV x0, x20                | X0 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00ACFFD0: BL #0xacfa2c               |  R0 = label_87();                       
            // 0x00ACFFD4: B #0xacfec4                |  goto label_53;                         
            goto label_53;
            // 0x00ACFFD8: BL #0x981060               | X0 = sub_981060( ?? this, ????);        
            // 0x00ACFFDC: LDR x20, [x0]              | X20 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            // 0x00ACFFE0: BL #0x980920               | X0 = sub_980920( ?? this, ????);        
            // 0x00ACFFE4: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_39 = 0;
            label_91:
            // 0x00ACFFE8: CBZ x22, #0xad0054         | if (val_15 == null) goto label_54;      
            if(val_15 == null)
            {
                goto label_54;
            }
            // 0x00ACFFEC: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00ACFFF0: LDR x8, [x22]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonProperty>);
            // 0x00ACFFF4: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00ACFFF8: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00ACFFFC: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD0000: CBZ x9, #0xad002c          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_55;
            // 0x00AD0004: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0008: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_38 = 0;
            // 0x00AD000C: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_57:
            // 0x00AD0010: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0014: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00AD0018: B.EQ #0xad003c             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_56;
            // 0x00AD001C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_38 = val_38 + 1;
            // 0x00AD0020: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0024: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0028: B.LO #0xad0010             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_57;
            label_55:
            // 0x00AD002C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD0030: MOV x0, x22                | X0 = val_15;//m1                        
            val_47 = val_15;
            // 0x00AD0034: BL #0x2776c24              | X0 = sub_2776C24( ?? val_15, ????);     
            // 0x00AD0038: B #0xad0048                |  goto label_58;                         
            goto label_58;
            label_56:
            // 0x00AD003C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD0040: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD0044: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_58:
            // 0x00AD0048: LDP x8, x1, [x0]           | X8 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);  //  | 
            // 0x00AD004C: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x00AD0050: BLR x8                     | X0 = sub_100000000EEFA000( ?? val_15, ????);
            label_54:
            // 0x00AD0054: CMP w23, #0xc4             | STATE = COMPARE(0x0, 0xC4)              
            // 0x00AD0058: B.EQ #0xad006c             | if (val_39 == 0xC4) goto label_60;      
            if(val_39 == 196)
            {
                goto label_60;
            }
            // 0x00AD005C: CBZ x20, #0xad006c         | if (typeof(Newtonsoft.Json.Bson.BsonBinaryWriter) == null) goto label_60;
            if(null == null)
            {
                goto label_60;
            }
            // 0x00AD0060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0064: MOV x0, x20                | X0 = 1152921504857432064 (0x100000000EEFA000);//ML01
            // 0x00AD0068: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            label_60:
            // 0x00AD006C: CBZ w25, #0xad02b4         | if (0x0 == 0) goto label_88;            
            if(0 == 0)
            {
                goto label_88;
            }
            // 0x00AD0070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            // 0x00AD0074: B #0xad02b4                |  goto label_88;                         
            goto label_88;
            label_12:
            // 0x00AD0078: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            label_13:
            // 0x00AD007C: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0080: BL #0xacf878               | X0 = 0.GetEnumerator();                 
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_22 = 0.GetEnumerator();
            // 0x00AD0084: ADRP x26, #0x361c000       | X26 = 56737792 (0x361C000);             
            // 0x00AD0088: ADRP x27, #0x3634000       | X27 = 56836096 (0x3634000);             
            // 0x00AD008C: LDR x26, [x26, #0x358]     | X26 = 1152921504608018432;              
            // 0x00AD0090: LDR x27, [x27, #0x3b0]     | X27 = 1152921504608178176;              
            // 0x00AD0094: MOV x21, x0                | X21 = val_22;//m1                       
            // 0x00AD0098: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_48 = 0;
            // 0x00AD009C: ORR w25, wzr, #4           | W25 = 4(0x4);                           
            val_49 = 4;
            // 0x00AD00A0: B #0xad00ac                |  goto label_63;                         
            goto label_63;
            label_76:
            // 0x00AD00A4: ADD w25, w0, w28           | W25 = (val_22 + W28);                   
            val_49 = val_22 + W28;
            // 0x00AD00A8: ADD w22, w22, #1           | W22 = (val_48 + 1) = val_48 (0x00000001);
            val_48 = 1;
            label_63:
            // 0x00AD00AC: CBNZ x21, #0xad00b8        | if (val_22 != null) goto label_64;      
            if(val_22 != null)
            {
                goto label_64;
            }
            // 0x00AD00B0: MOV w28, w25               | W28 = (val_22 + W28);//m1               
            // 0x00AD00B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_64:
            // 0x00AD00B8: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD00BC: LDR x1, [x26]              | X1 = typeof(System.Collections.IEnumerator);
            // 0x00AD00C0: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD00C4: CBZ x9, #0xad00f0          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_65;
            // 0x00AD00C8: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD00CC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_39 = 0;
            // 0x00AD00D0: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_67:
            // 0x00AD00D4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD00D8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00AD00DC: B.EQ #0xad0104             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_66;
            // 0x00AD00E0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_39 = val_39 + 1;
            // 0x00AD00E4: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD00E8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD00EC: B.LO #0xad00d4             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_67;
            label_65:
            // 0x00AD00F0: MOV w28, w25               | W28 = (val_22 + W28);//m1               
            // 0x00AD00F4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00AD00F8: MOV x0, x21                | X0 = val_22;//m1                        
            val_50 = val_22;
            // 0x00AD00FC: BL #0x2776c24              | X0 = sub_2776C24( ?? val_22, ????);     
            // 0x00AD0100: B #0xad0114                |  goto label_68;                         
            goto label_68;
            label_66:
            // 0x00AD0104: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD0108: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00AD010C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00AD0110: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_68:
            // 0x00AD0114: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);  //  | 
            // 0x00AD0118: MOV w28, w25               | W28 = (val_22 + W28);//m1               
            // 0x00AD011C: MOV x0, x21                | X0 = val_22;//m1                        
            // 0x00AD0120: BLR x8                     | X0 = sub_1000000000145000( ?? val_22, ????);
            // 0x00AD0124: AND w8, w0, #1             | W8 = (val_22 & 1);                      
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_24 = val_22 & 1;
            // 0x00AD0128: TBZ w8, #0, #0xad02dc      | if (((val_22 & 1) & 0x1) == 0) goto label_69;
            if((val_24 & 1) == 0)
            {
                goto label_69;
            }
            // 0x00AD012C: CBNZ x21, #0xad0138        | if (val_22 != null) goto label_70;      
            if(val_22 != null)
            {
                goto label_70;
            }
            // 0x00AD0130: MOV w28, w25               | W28 = (val_22 + W28);//m1               
            // 0x00AD0134: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_70:
            // 0x00AD0138: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD013C: LDR x1, [x27]              | X1 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00AD0140: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD0144: CBZ x9, #0xad0170          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_71;
            // 0x00AD0148: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD014C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_40 = 0;
            // 0x00AD0150: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_73:
            // 0x00AD0154: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0158: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IEnumerator<T>))
            // 0x00AD015C: B.EQ #0xad0184             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_72;
            // 0x00AD0160: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_40 = val_40 + 1;
            // 0x00AD0164: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0168: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD016C: B.LO #0xad0154             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_73;
            label_71:
            // 0x00AD0170: MOV w28, w25               | W28 = (val_22 + W28);//m1               
            // 0x00AD0174: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD0178: MOV x0, x21                | X0 = val_22;//m1                        
            val_51 = val_22;
            // 0x00AD017C: BL #0x2776c24              | X0 = sub_2776C24( ?? val_22, ????);     
            // 0x00AD0180: B #0xad0190                |  goto label_74;                         
            goto label_74;
            label_72:
            // 0x00AD0184: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD0188: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD018C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_74:
            // 0x00AD0190: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);  //  | 
            // 0x00AD0194: MOV w28, w25               | W28 = (val_22 + W28);//m1               
            // 0x00AD0198: MOV x0, x21                | X0 = val_22;//m1                        
            // 0x00AD019C: BLR x8                     | X0 = sub_1000000000145000( ?? val_22, ????);
            // 0x00AD01A0: MOV x23, x0                | X23 = val_22;//m1                       
            // 0x00AD01A4: ADD w28, w25, #1           | W28 = ((val_22 + W28) + 1);             
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_26 = val_49 + 1;
            // 0x00AD01A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD01AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AD01B0: MOV w1, w22                | W1 = 1 (0x1);//ML01                     
            // 0x00AD01B4: BL #0x291912c              | X0 = Newtonsoft.Json.Utilities.MathUtils.IntLength(i:  0);
            int val_27 = Newtonsoft.Json.Utilities.MathUtils.IntLength(i:  0);
            // 0x00AD01B8: ADD w8, w25, w0            | W8 = ((val_22 + W28) + val_27);         
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_28 = val_49 + val_27;
            // 0x00AD01BC: ADD w28, w8, #2            | W28 = (((val_22 + W28) + val_27) + 2);  
            System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> val_29 = val_28 + 2;
            // 0x00AD01C0: MOV x0, x20                | X0 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00AD01C4: MOV x1, x23                | X1 = val_22;//m1                        
            // 0x00AD01C8: BL #0xacfa2c               |  R0 = label_87();                       
            // 0x00AD01CC: B #0xad00a4                |  goto label_76;                         
            goto label_76;
            // 0x00AD01D0: BL #0x981060               | X0 = sub_981060( ?? this, ????);        
            // 0x00AD01D4: LDR x20, [x0]              | X20 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            // 0x00AD01D8: BL #0x980920               | X0 = sub_980920( ?? this, ????);        
            // 0x00AD01DC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x00AD01E0: MOV w25, w28               | W25 = (((val_22 + W28) + val_27) + 2);//m1
            label_90:
            // 0x00AD01E4: CBZ x21, #0xad0250         | if (val_22 == null) goto label_77;      
            if(val_22 == null)
            {
                goto label_77;
            }
            // 0x00AD01E8: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00AD01EC: LDR x8, [x21]              | X8 = typeof(System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>);
            // 0x00AD01F0: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00AD01F4: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00AD01F8: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00AD01FC: CBZ x9, #0xad0228          | if (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_78;
            // 0x00AD0200: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00AD0204: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_41 = 0;
            // 0x00AD0208: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608215048 (0x100000000014E008);
            label_80:
            // 0x00AD020C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00AD0210: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00AD0214: B.EQ #0xad0238             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_79;
            // 0x00AD0218: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_41 = val_41 + 1;
            // 0x00AD021C: ADD x10, x10, #0x10        | X10 = (1152921504608215048 + 16) = 1152921504608215064 (0x100000000014E018);
            // 0x00AD0220: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00AD0224: B.LO #0xad020c             | if (0 < System.Collections.Generic.IEnumerator<T>.__il2cppRuntimeField_interface_offsets_count) goto label_80;
            label_78:
            // 0x00AD0228: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00AD022C: MOV x0, x21                | X0 = val_22;//m1                        
            val_52 = val_22;
            // 0x00AD0230: BL #0x2776c24              | X0 = sub_2776C24( ?? val_22, ????);     
            // 0x00AD0234: B #0xad0244                |  goto label_81;                         
            goto label_81;
            label_79:
            // 0x00AD0238: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00AD023C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00AD0240: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608178176 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_81:
            // 0x00AD0244: LDP x8, x1, [x0]           | X8 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);  //  | 
            // 0x00AD0248: MOV x0, x21                | X0 = val_22;//m1                        
            // 0x00AD024C: BLR x8                     | X0 = sub_100000000EEFA000( ?? val_22, ????);
            label_77:
            // 0x00AD0250: CMP w22, #0x141            | STATE = COMPARE(0x0, 0x141)             
            // 0x00AD0254: B.EQ #0xad0268             | if (0 == 0x141) goto label_83;          
            if(0 == 321)
            {
                goto label_83;
            }
            // 0x00AD0258: CBZ x20, #0xad0268         | if (typeof(Newtonsoft.Json.Bson.BsonBinaryWriter) == null) goto label_83;
            if(null == null)
            {
                goto label_83;
            }
            // 0x00AD025C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD0260: MOV x0, x20                | X0 = 1152921504857432064 (0x100000000EEFA000);//ML01
            // 0x00AD0264: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Newtonsoft.Json.Bson.BsonBinaryWriter), ????);
            label_83:
            // 0x00AD0268: ADD w21, w25, #1           | W21 = ((((val_22 + W28) + val_27) + 2) + 1);
            val_37 = val_29 + 1;
            // 0x00AD026C: TBZ w24, #0, #0xad02b4     | if ((0x0 & 0x1) == 0) goto label_88;    
            if((0 & 1) == 0)
            {
                goto label_88;
            }
            // 0x00AD0270: B #0xad029c                |  goto label_85;                         
            goto label_85;
            label_21:
            // 0x00AD0274: LDR x1, [x19, #0x20]       | X1 = 0x40;                              
            // 0x00AD0278: MOV x0, x20                | X0 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00AD027C: BL #0xacfa2c               |  R0 = label_87();                       
            // 0x00AD0280: MOV w21, w0                | W21 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            val_40 = this;
            // 0x00AD0284: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_41 = 0;
            label_23:
            // 0x00AD0288: LDR x1, [x19, #0x28]       | X1 = 0x3723290;                         
            // 0x00AD028C: MOV x0, x20                | X0 = 1152921513715002544 (0x100000021EE36CB0);//ML01
            // 0x00AD0290: BL #0xacfa2c               |  R0 = label_87();                       
            // 0x00AD0294: ADD w21, w0, w21           | W21 = (this + this) = val_37 (0x200000043DC6D960);
            val_37 = 2305843027430005088;
            // 0x00AD0298: TBZ w22, #0, #0xad02b4     | if ((0x0 & 0x1) == 0) goto label_88;    
            if((val_41 & 1) == 0)
            {
                goto label_88;
            }
            label_85:
            // 0x00AD029C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00AD02A0: ORR w19, wzr, #0x18        | W19 = 24(0x18);                         
            val_36 = 24;
            // 0x00AD02A4: STR w21, [x19]             | mem[24] = 0x200000043DC6D960;            //  dest_result_addr=24
            mem[24] = val_37;
            label_27:
            // 0x00AD02A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00AD02AC: LDR w21, [x19]             | W21 = 0x200000043DC6D960;               
            // 0x00AD02B0: B #0xad02b8                |  goto label_89;                         
            goto label_89;
            label_88:
            // 0x00AD02B4: STR w21, [x19, #0x18]      | mem[24] = (mem[24] + 5);                 //  dest_result_addr=24
            mem[24] = val_37;
            label_89:
            // 0x00AD02B8: MOV w0, w21                | W0 = (mem[24] + 5);//m1                 
            // 0x00AD02BC: SUB sp, x29, #0x50         | SP = (1152921513714990528 - 80) = 1152921513714990448 (0x100000021EE33D70);
            // 0x00AD02C0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD02C4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD02C8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD02CC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD02D0: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AD02D4: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AD02D8: RET                        |  return (System.Int32)(mem[24] + 5);    
            return (int)val_37;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_69:
            // 0x00AD02DC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00AD02E0: MOVZ w22, #0x141           | W22 = 321 (0x141);//ML01                
            // 0x00AD02E4: B #0xad01e4                |  goto label_90;                         
            goto label_90;
            label_44:
            // 0x00AD02E8: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x00AD02EC: MOVZ w23, #0xc4            | W23 = 196 (0xC4);//ML01                 
            // 0x00AD02F0: B #0xacffe8                |  goto label_91;                         
            goto label_91;
            label_2:
            // 0x00AD02F4: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00AD02F8: LDR x8, [x8, #0x518]       | X8 = 1152921504619892736;               
            // 0x00AD02FC: LDR x0, [x8]               | X0 = typeof(System.Globalization.CultureInfo);
            // 0x00AD0300: LDRB w8, [x0, #0x10a]      | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_10A;
            // 0x00AD0304: TBZ w8, #0, #0xad0314      | if (System.Globalization.CultureInfo.__il2cppRuntimeField_has_cctor == 0) goto label_93;
            // 0x00AD0308: LDR w8, [x0, #0xbc]        | W8 = System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished;
            // 0x00AD030C: CBNZ w8, #0xad0314         | if (System.Globalization.CultureInfo.__il2cppRuntimeField_cctor_finished != 0) goto label_93;
            // 0x00AD0310: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Globalization.CultureInfo), ????);
            label_93:
            // 0x00AD0314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD0318: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD031C: BL #0x1c2f10c              | X0 = System.Globalization.CultureInfo.get_InvariantCulture();
            System.Globalization.CultureInfo val_31 = System.Globalization.CultureInfo.InvariantCulture;
            // 0x00AD0320: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00AD0324: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x00AD0328: MOV x20, x0                | X20 = val_31;//m1                       
            // 0x00AD032C: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
            // 0x00AD0330: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD0334: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x00AD0338: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00AD033C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD0340: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x00AD0344: LDR x8, [x19]              | X8 = typeof(Newtonsoft.Json.Bson.BsonToken);
            // 0x00AD0348: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD034C: MOV x0, x19                | X0 = t;//m1                             
            // 0x00AD0350: LDP x9, x1, [x8, #0x150]   | X9 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150; X1 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_158; //  | 
            // 0x00AD0354: BLR x9                     | X0 = typeof(Newtonsoft.Json.Bson.BsonToken).__il2cppRuntimeField_150();
            // 0x00AD0358: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00AD035C: LDR x8, [x8, #0xc00]       | X8 = 1152921504858071040;               
            // 0x00AD0360: STRB w0, [sp, #7]          | stack[1152921513714990391] = t;          //  dest_result_addr=1152921513714990391
            // 0x00AD0364: ADD x1, sp, #7             | X1 = (1152921513714990384 + 7) = 1152921513714990391 (0x100000021EE33D37);
            // 0x00AD0368: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonType);
            // 0x00AD036C: MOV x0, x8                 | X0 = 1152921504858071040 (0x100000000EF96000);//ML01
            // 0x00AD0370: BL #0x27bc028              | X0 = 1152921513715050928 = (Il2CppObject*)Box((RuntimeClass*)typeof(Newtonsoft.Json.Bson.BsonType), t);
            // 0x00AD0374: MOV x19, x0                | X19 = 1152921513715050928 (0x100000021EE429B0);//ML01
            // 0x00AD0378: CBNZ x21, #0xad0380        | if ( != null) goto label_94;            
            if(null != null)
            {
                goto label_94;
            }
            // 0x00AD037C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? t, ????);          
            label_94:
            // 0x00AD0380: CBZ x19, #0xad03a4         | if (t == 0) goto label_96;              
            if(val_36 == 0)
            {
                goto label_96;
            }
            // 0x00AD0384: LDR x8, [x21]              | X8 = ;                                  
            // 0x00AD0388: MOV x0, x19                | X0 = 1152921513715050928 (0x100000021EE429B0);//ML01
            // 0x00AD038C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00AD0390: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? t, ????);          
            // 0x00AD0394: CBNZ x0, #0xad03a4         | if (t != 0) goto label_96;              
            if(val_36 != 0)
            {
                goto label_96;
            }
            // 0x00AD0398: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? t, ????);          
            // 0x00AD039C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD03A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t, ????);          
            label_96:
            // 0x00AD03A4: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x00AD03A8: CBNZ w8, #0xad03b8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_97;
            // 0x00AD03AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? t, ????);          
            // 0x00AD03B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD03B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? t, ????);          
            label_97:
            // 0x00AD03B8: STR x19, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = t;  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = val_36;
            // 0x00AD03BC: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x00AD03C0: LDR x8, [x8, #0x6a8]       | X8 = (string**)(1152921513714019328)("Unexpected token when writing BSON: {0}");
            // 0x00AD03C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD03C8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00AD03CC: MOV x2, x20                | X2 = val_31;//m1                        
            // 0x00AD03D0: LDR x1, [x8]               | X1 = "Unexpected token when writing BSON: {0}";
            // 0x00AD03D4: MOV x3, x21                | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x00AD03D8: BL #0x2900ac4              | X0 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Unexpected token when writing BSON: {0}", args:  val_31);
            string val_32 = Newtonsoft.Json.Utilities.StringUtils.FormatWith(format:  0, provider:  "Unexpected token when writing BSON: {0}", args:  val_31);
            // 0x00AD03DC: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x00AD03E0: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x00AD03E4: MOV x19, x0                | X19 = val_32;//m1                       
            // 0x00AD03E8: LDR x8, [x8]               | X8 = typeof(System.ArgumentOutOfRangeException);
            // 0x00AD03EC: MOV x0, x8                 | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            System.ArgumentOutOfRangeException val_33 = null;
            // 0x00AD03F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD03F4: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00AD03F8: LDR x8, [x8, #0xe48]       | X8 = (string**)(1152921513714023584)("t");
            // 0x00AD03FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00AD0400: MOV x2, x19                | X2 = val_32;//m1                        
            // 0x00AD0404: MOV x20, x0                | X20 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD0408: LDR x1, [x8]               | X1 = "t";                               
            // 0x00AD040C: BL #0x18b3e8c              | .ctor(paramName:  "t", message:  val_32);
            val_33 = new System.ArgumentOutOfRangeException(paramName:  "t", message:  val_32);
            // 0x00AD0410: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x00AD0414: LDR x8, [x8, #0x580]       | X8 = 1152921513714977520;               
            // 0x00AD0418: MOV x0, x20                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x00AD041C: LDR x1, [x8]               | X1 = System.Int32 Newtonsoft.Json.Bson.BsonBinaryWriter::CalculateSize(Newtonsoft.Json.Bson.BsonToken t);
            // 0x00AD0420: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x00AD0424: BL #0xac27ac               | X0 = label_Sdkwww_<RequestExe>c__Iterator0_Reset_GL00AC27AC();
            // 0x00AD0428: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            val_53 = val_33;
            // 0x00AD042C: ADD x0, sp, #0x18          | X0 = (1152921513714990384 + 24) = 1152921513714990408 (0x100000021EE33D48);
            // 0x00AD0430: B #0xad0478                |  goto label_103;                        
            goto label_103;
            // 0x00AD0434: MOV x19, x0                | X19 = 1152921513714990408 (0x100000021EE33D48);//ML01
            val_53;
            // 0x00AD0438: ADD x0, sp, #8             | X0 = (1152921513714990384 + 8) = 1152921513714990392 (0x100000021EE33D38);
            // 0x00AD043C: B #0xad0478                |  goto label_103;                        
            goto label_103;
            // 0x00AD0440: MOV x19, x0                | X19 = 1152921513714990392 (0x100000021EE33D38);//ML01
            val_53;
            // 0x00AD0444: ADD x0, sp, #0x10          | X0 = (1152921513714990384 + 16) = 1152921513714990400 (0x100000021EE33D40);
            // 0x00AD0448: B #0xad0478                |  goto label_103;                        
            goto label_103;
            // 0x00AD044C: MOV x19, x0                | X19 = 1152921513714990400 (0x100000021EE33D40);//ML01
            val_53;
            // 0x00AD0450: ADD x0, sp, #0x28          | X0 = (1152921513714990384 + 40) = 1152921513714990424 (0x100000021EE33D58);
            // 0x00AD0454: B #0xad0478                |  goto label_103;                        
            goto label_103;
            // 0x00AD0458: MOV x19, x0                | X19 = 1152921513714990424 (0x100000021EE33D58);//ML01
            val_53;
            // 0x00AD045C: ADD x0, sp, #0x38          | X0 = (1152921513714990384 + 56) = 1152921513714990440 (0x100000021EE33D68);
            // 0x00AD0460: B #0xad0478                |  goto label_103;                        
            goto label_103;
            // 0x00AD0464: MOV x19, x0                | X19 = 1152921513714990440 (0x100000021EE33D68);//ML01
            val_53;
            // 0x00AD0468: ADD x0, sp, #0x20          | X0 = (1152921513714990384 + 32) = 1152921513714990416 (0x100000021EE33D50);
            // 0x00AD046C: B #0xad0478                |  goto label_103;                        
            goto label_103;
            // 0x00AD0470: MOV x19, x0                | X19 = 1152921513714990416 (0x100000021EE33D50);//ML01
            val_53;
            // 0x00AD0474: ADD x0, sp, #0x30          | X0 = (1152921513714990384 + 48) = 1152921513714990432 (0x100000021EE33D60);
            label_103:
            // 0x00AD0478: BL #0x299a140              | 
            // 0x00AD047C: MOV x0, x19                | X0 = 1152921513714990416 (0x100000021EE33D50);//ML01
            // 0x00AD0480: BL #0x980800               | X0 = sub_980800( ?? 0x100000021EE33D50, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD1B60 (11344736), len: 124  VirtAddr: 0x00AD1B60 RVA: 0x00AD1B60 token: 100684720 methodIndex: 47370 delegateWrapperIndex: 0 methodInvoker: 0
        private static BsonBinaryWriter()
        {
            //
            // Disasemble & Code
            // 0x00AD1B60: STP x20, x19, [sp, #-0x20]! | stack[1152921513715131184] = ???;  stack[1152921513715131192] = ???;  //  dest_result_addr=1152921513715131184 |  dest_result_addr=1152921513715131192
            // 0x00AD1B64: STP x29, x30, [sp, #0x10]  | stack[1152921513715131200] = ???;  stack[1152921513715131208] = ???;  //  dest_result_addr=1152921513715131200 |  dest_result_addr=1152921513715131208
            // 0x00AD1B68: ADD x29, sp, #0x10         | X29 = (1152921513715131184 + 16) = 1152921513715131200 (0x100000021EE56340);
            // 0x00AD1B6C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00AD1B70: LDRB w8, [x19, #0x4ca]     | W8 = (bool)static_value_037334CA;       
            // 0x00AD1B74: TBNZ w8, #0, #0xad1b90     | if (static_value_037334CA == true) goto label_0;
            // 0x00AD1B78: ADRP x8, #0x3621000        | X8 = 56758272 (0x3621000);              
            // 0x00AD1B7C: LDR x8, [x8, #0x770]       | X8 = 0x2B8F964;                         
            // 0x00AD1B80: LDR w0, [x8]               | W0 = 0x151D;                            
            // 0x00AD1B84: BL #0x2782188              | X0 = sub_2782188( ?? 0x151D, ????);     
            // 0x00AD1B88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AD1B8C: STRB w8, [x19, #0x4ca]     | static_value_037334CA = true;            //  dest_result_addr=57881802
            label_0:
            // 0x00AD1B90: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
            // 0x00AD1B94: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
            // 0x00AD1B98: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
            // 0x00AD1B9C: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
            // 0x00AD1BA0: TBZ w8, #0, #0xad1bb0      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00AD1BA4: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
            // 0x00AD1BA8: CBNZ w8, #0xad1bb0         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00AD1BAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
            label_2:
            // 0x00AD1BB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AD1BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD1BB8: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
            System.Text.Encoding val_1 = System.Text.Encoding.UTF8;
            // 0x00AD1BBC: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00AD1BC0: LDR x8, [x8, #0x380]       | X8 = 1152921504857432064;               
            // 0x00AD1BC4: LDR x8, [x8]               | X8 = typeof(Newtonsoft.Json.Bson.BsonBinaryWriter);
            // 0x00AD1BC8: LDR x8, [x8, #0xa0]        | X8 = Newtonsoft.Json.Bson.BsonBinaryWriter.__il2cppRuntimeField_static_fields;
            // 0x00AD1BCC: STR x0, [x8]               | Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding = val_1;  //  dest_result_addr=1152921504857436160
            Newtonsoft.Json.Bson.BsonBinaryWriter.Encoding = val_1;
            // 0x00AD1BD0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD1BD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AD1BD8: RET                        |  return;                                
            return;
        
        }
    
    }

}
