using UnityEngine;
[UnityEngine.ExecuteInEditMode] // 0x2819D18
[UnityEngine.AddComponentMenu] // 0x2819D18
public class BlurEffect : MonoBehaviour
{
    // Fields
    public int iterations; //  0x00000018
    public float blurSpread; //  0x0000001C
    public UnityEngine.Shader blurShader; //  0x00000020
    private static UnityEngine.Material m_Material; // static_offset: 0x00000000
    
    // Properties
    protected UnityEngine.Material material { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0272AE10 (41070096), len: 24  VirtAddr: 0x0272AE10 RVA: 0x0272AE10 token: 100663358 methodIndex: 24257 delegateWrapperIndex: 0 methodInvoker: 0
    public BlurEffect()
    {
        //
        // Disasemble & Code
        // 0x0272AE10: MOVZ x8, #0x3f19, lsl #48  | X8 = 4546665298807226368 (0x3F19000000000000);//ML01
        // 0x0272AE14: MOVK x8, #0x999a, lsl #32  | X8 = 4546834185511239680 (0x3F19999A00000000);
        // 0x0272AE18: MOVK x8, #0x3              | X8 = 4546834185511239683 (0x3F19999A00000003);
        // 0x0272AE1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272AE20: STR x8, [x0, #0x18]        | this.iterations = 3; this.blurSpread = 5.510186E-41;  //  dest_result_addr=1152921509932905848 dest_result_addr=1152921509932905852
        this.iterations = 3;
        this.blurSpread = 5.510186E-41f;
        // 0x0272AE24: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272AE28 (41070120), len: 316  VirtAddr: 0x0272AE28 RVA: 0x0272AE28 token: 100663359 methodIndex: 24258 delegateWrapperIndex: 0 methodInvoker: 0
    protected UnityEngine.Material get_material()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.Material val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        // 0x0272AE28: STP x22, x21, [sp, #-0x30]! | stack[1152921509933009872] = ???;  stack[1152921509933009880] = ???;  //  dest_result_addr=1152921509933009872 |  dest_result_addr=1152921509933009880
        // 0x0272AE2C: STP x20, x19, [sp, #0x10]  | stack[1152921509933009888] = ???;  stack[1152921509933009896] = ???;  //  dest_result_addr=1152921509933009888 |  dest_result_addr=1152921509933009896
        // 0x0272AE30: STP x29, x30, [sp, #0x20]  | stack[1152921509933009904] = ???;  stack[1152921509933009912] = ???;  //  dest_result_addr=1152921509933009904 |  dest_result_addr=1152921509933009912
        // 0x0272AE34: ADD x29, sp, #0x20         | X29 = (1152921509933009872 + 32) = 1152921509933009904 (0x100000013D76CBF0);
        // 0x0272AE38: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272AE3C: LDRB w8, [x20, #0xa94]     | W8 = (bool)static_value_03743A94;       
        // 0x0272AE40: MOV x19, x0                | X19 = 1152921509933021920 (0x100000013D76FAE0);//ML01
        val_3 = this;
        // 0x0272AE44: TBNZ w8, #0, #0x272ae60    | if (static_value_03743A94 == true) goto label_0;
        // 0x0272AE48: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
        // 0x0272AE4C: LDR x8, [x8, #0xb38]       | X8 = 0x2B8F6E0;                         
        // 0x0272AE50: LDR w0, [x8]               | W0 = 0x147C;                            
        // 0x0272AE54: BL #0x2782188              | X0 = sub_2782188( ?? 0x147C, ????);     
        // 0x0272AE58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272AE5C: STRB w8, [x20, #0xa94]     | static_value_03743A94 = true;            //  dest_result_addr=57948820
        label_0:
        // 0x0272AE60: ADRP x21, #0x3608000       | X21 = 56655872 (0x3608000);             
        // 0x0272AE64: LDR x21, [x21, #0xfd0]     | X21 = 1152921504777080832;              
        // 0x0272AE68: LDR x0, [x21]              | X0 = typeof(BlurEffect);                
        val_4 = null;
        // 0x0272AE6C: LDRB w8, [x0, #0x10a]      | W8 = BlurEffect.__il2cppRuntimeField_10A;
        // 0x0272AE70: TBZ w8, #0, #0x272ae84     | if (BlurEffect.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272AE74: LDR w8, [x0, #0xbc]        | W8 = BlurEffect.__il2cppRuntimeField_cctor_finished;
        // 0x0272AE78: CBNZ w8, #0x272ae84        | if (BlurEffect.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272AE7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BlurEffect), ????);
        // 0x0272AE80: LDR x0, [x21]              | X0 = typeof(BlurEffect);                
        val_4 = null;
        label_2:
        // 0x0272AE84: ADRP x9, #0x35fe000        | X9 = 56614912 (0x35FE000);              
        // 0x0272AE88: LDR x8, [x0, #0xa0]        | X8 = BlurEffect.__il2cppRuntimeField_static_fields;
        // 0x0272AE8C: LDR x9, [x9, #0x810]       | X9 = 1152921504697475072;               
        // 0x0272AE90: LDR x20, [x8]              | X20 = BlurEffect.m_Material;            
        // 0x0272AE94: LDR x0, [x9]               | X0 = typeof(UnityEngine.Object);        
        // 0x0272AE98: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0272AE9C: TBZ w8, #0, #0x272aeac     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272AEA0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0272AEA4: CBNZ w8, #0x272aeac        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272AEA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x0272AEAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272AEB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AEB4: MOV x1, x20                | X1 = BlurEffect.m_Material;//m1         
        // 0x0272AEB8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272AEBC: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  BlurEffect.m_Material);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  BlurEffect.m_Material);
        // 0x0272AEC0: TBZ w0, #0, #0x272af30     | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x0272AEC4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
        // 0x0272AEC8: LDR x20, [x19, #0x20]      | X20 = this.blurShader; //P2             
        // 0x0272AECC: LDR x8, [x8, #0x40]        | X8 = 1152921504696356864;               
        // 0x0272AED0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Material);      
        UnityEngine.Material val_2 = null;
        // 0x0272AED4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.Material), ????);
        // 0x0272AED8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AEDC: MOV x1, x20                | X1 = this.blurShader;//m1               
        // 0x0272AEE0: MOV x19, x0                | X19 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x0272AEE4: BL #0x1a77bd8              | .ctor(shader:  this.blurShader);        
        val_2 = new UnityEngine.Material(shader:  this.blurShader);
        // 0x0272AEE8: LDR x0, [x21]              | X0 = typeof(BlurEffect);                
        val_5 = null;
        // 0x0272AEEC: LDRB w8, [x0, #0x10a]      | W8 = BlurEffect.__il2cppRuntimeField_10A;
        // 0x0272AEF0: TBZ w8, #0, #0x272af04     | if (BlurEffect.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272AEF4: LDR w8, [x0, #0xbc]        | W8 = BlurEffect.__il2cppRuntimeField_cctor_finished;
        // 0x0272AEF8: CBNZ w8, #0x272af04        | if (BlurEffect.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272AEFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BlurEffect), ????);
        // 0x0272AF00: LDR x0, [x21]              | X0 = typeof(BlurEffect);                
        val_5 = null;
        label_7:
        // 0x0272AF04: LDR x8, [x0, #0xa0]        | X8 = BlurEffect.__il2cppRuntimeField_static_fields;
        // 0x0272AF08: STR x19, [x8]              | BlurEffect.m_Material = typeof(UnityEngine.Material);  //  dest_result_addr=1152921504777084928
        BlurEffect.m_Material = val_2;
        // 0x0272AF0C: LDR x8, [x21]              | X8 = typeof(BlurEffect);                
        // 0x0272AF10: LDR x8, [x8, #0xa0]        | X8 = BlurEffect.__il2cppRuntimeField_static_fields;
        // 0x0272AF14: LDR x19, [x8]              | X19 = typeof(UnityEngine.Material);     
        val_3 = BlurEffect.m_Material;
        // 0x0272AF18: CBNZ x19, #0x272af20       | if ( != 0) goto label_8;                
        if(null != 0)
        {
            goto label_8;
        }
        // 0x0272AF1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(BlurEffect), ????);
        label_8:
        // 0x0272AF20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AF24: MOVZ w1, #0x34             | W1 = 52 (0x34);//ML01                   
        // 0x0272AF28: MOV x0, x19                | X0 = 1152921504696356864 (0x100000000555D000);//ML01
        // 0x0272AF2C: BL #0x1b77b04              | set_hideFlags(value:  52);              
        hideFlags = 52;
        label_5:
        // 0x0272AF30: LDR x0, [x21]              | X0 = typeof(BlurEffect);                
        val_6 = null;
        // 0x0272AF34: LDRB w8, [x0, #0x10a]      | W8 = BlurEffect.__il2cppRuntimeField_10A;
        // 0x0272AF38: TBZ w8, #0, #0x272af4c     | if (BlurEffect.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x0272AF3C: LDR w8, [x0, #0xbc]        | W8 = BlurEffect.__il2cppRuntimeField_cctor_finished;
        // 0x0272AF40: CBNZ w8, #0x272af4c        | if (BlurEffect.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x0272AF44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BlurEffect), ????);
        // 0x0272AF48: LDR x0, [x21]              | X0 = typeof(BlurEffect);                
        val_6 = null;
        label_10:
        // 0x0272AF4C: LDR x8, [x0, #0xa0]        | X8 = BlurEffect.__il2cppRuntimeField_static_fields;
        // 0x0272AF50: LDR x0, [x8]               | X0 = typeof(UnityEngine.Material);      
        // 0x0272AF54: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272AF58: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272AF5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272AF60: RET                        |  return (UnityEngine.Material)typeof(UnityEngine.Material);
        return BlurEffect.m_Material;
        //  |  // // {name=val_0, type=UnityEngine.Material, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x0272AF64 (41070436), len: 252  VirtAddr: 0x0272AF64 RVA: 0x0272AF64 token: 100663360 methodIndex: 24259 delegateWrapperIndex: 0 methodInvoker: 0
    protected void OnDisable()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        //  | 
        var val_3;
        // 0x0272AF64: STP x22, x21, [sp, #-0x30]! | stack[1152921509933125968] = ???;  stack[1152921509933125976] = ???;  //  dest_result_addr=1152921509933125968 |  dest_result_addr=1152921509933125976
        // 0x0272AF68: STP x20, x19, [sp, #0x10]  | stack[1152921509933125984] = ???;  stack[1152921509933125992] = ???;  //  dest_result_addr=1152921509933125984 |  dest_result_addr=1152921509933125992
        // 0x0272AF6C: STP x29, x30, [sp, #0x20]  | stack[1152921509933126000] = ???;  stack[1152921509933126008] = ???;  //  dest_result_addr=1152921509933126000 |  dest_result_addr=1152921509933126008
        // 0x0272AF70: ADD x29, sp, #0x20         | X29 = (1152921509933125968 + 32) = 1152921509933126000 (0x100000013D789170);
        // 0x0272AF74: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272AF78: LDRB w8, [x19, #0xa95]     | W8 = (bool)static_value_03743A95;       
        // 0x0272AF7C: TBNZ w8, #0, #0x272af98    | if (static_value_03743A95 == true) goto label_0;
        // 0x0272AF80: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x0272AF84: LDR x8, [x8, #0xba8]       | X8 = 0x2B8F6E4;                         
        // 0x0272AF88: LDR w0, [x8]               | W0 = 0x147D;                            
        // 0x0272AF8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x147D, ????);     
        // 0x0272AF90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272AF94: STRB w8, [x19, #0xa95]     | static_value_03743A95 = true;            //  dest_result_addr=57948821
        label_0:
        // 0x0272AF98: ADRP x20, #0x3608000       | X20 = 56655872 (0x3608000);             
        // 0x0272AF9C: LDR x20, [x20, #0xfd0]     | X20 = 1152921504777080832;              
        // 0x0272AFA0: LDR x0, [x20]              | X0 = typeof(BlurEffect);                
        val_2 = null;
        // 0x0272AFA4: LDRB w8, [x0, #0x10a]      | W8 = BlurEffect.__il2cppRuntimeField_10A;
        // 0x0272AFA8: TBZ w8, #0, #0x272afbc     | if (BlurEffect.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x0272AFAC: LDR w8, [x0, #0xbc]        | W8 = BlurEffect.__il2cppRuntimeField_cctor_finished;
        // 0x0272AFB0: CBNZ w8, #0x272afbc        | if (BlurEffect.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x0272AFB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BlurEffect), ????);
        // 0x0272AFB8: LDR x0, [x20]              | X0 = typeof(BlurEffect);                
        val_2 = null;
        label_2:
        // 0x0272AFBC: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x0272AFC0: LDR x8, [x0, #0xa0]        | X8 = BlurEffect.__il2cppRuntimeField_static_fields;
        // 0x0272AFC4: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x0272AFC8: LDR x19, [x8]              | X19 = BlurEffect.m_Material;            
        // 0x0272AFCC: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x0272AFD0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0272AFD4: TBZ w8, #0, #0x272afe4     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272AFD8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0272AFDC: CBNZ w8, #0x272afe4        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272AFE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x0272AFE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272AFE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AFEC: MOV x1, x19                | X1 = BlurEffect.m_Material;//m1         
        // 0x0272AFF0: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x0272AFF4: TBZ w0, #0, #0x272b050     | if (val_1 == false) goto label_5;       
        if(val_1 == false)
        {
            goto label_5;
        }
        // 0x0272AFF8: LDR x0, [x20]              | X0 = typeof(BlurEffect);                
        val_3 = null;
        // 0x0272AFFC: LDRB w8, [x0, #0x10a]      | W8 = BlurEffect.__il2cppRuntimeField_10A;
        // 0x0272B000: TBZ w8, #0, #0x272b014     | if (BlurEffect.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272B004: LDR w8, [x0, #0xbc]        | W8 = BlurEffect.__il2cppRuntimeField_cctor_finished;
        // 0x0272B008: CBNZ w8, #0x272b014        | if (BlurEffect.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272B00C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(BlurEffect), ????);
        // 0x0272B010: LDR x0, [x20]              | X0 = typeof(BlurEffect);                
        val_3 = null;
        label_7:
        // 0x0272B014: LDR x8, [x0, #0xa0]        | X8 = BlurEffect.__il2cppRuntimeField_static_fields;
        // 0x0272B018: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x0272B01C: LDR x19, [x8]              | X19 = BlurEffect.m_Material;            
        // 0x0272B020: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0272B024: TBZ w8, #0, #0x272b034     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x0272B028: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0272B02C: CBNZ w8, #0x272b034        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x0272B030: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_9:
        // 0x0272B034: MOV x1, x19                | X1 = BlurEffect.m_Material;//m1         
        // 0x0272B038: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B03C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272B040: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B044: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272B048: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272B04C: B #0x1b78bac               | UnityEngine.Object.DestroyImmediate(obj:  0); return;
        UnityEngine.Object.DestroyImmediate(obj:  0);
        return;
        label_5:
        // 0x0272B050: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B054: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272B058: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272B05C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B060 (41070688), len: 228  VirtAddr: 0x0272B060 RVA: 0x0272B060 token: 100663361 methodIndex: 24260 delegateWrapperIndex: 0 methodInvoker: 0
    protected void Start()
    {
        //
        // Disasemble & Code
        // 0x0272B060: STP x20, x19, [sp, #-0x20]! | stack[1152921509933250272] = ???;  stack[1152921509933250280] = ???;  //  dest_result_addr=1152921509933250272 |  dest_result_addr=1152921509933250280
        // 0x0272B064: STP x29, x30, [sp, #0x10]  | stack[1152921509933250288] = ???;  stack[1152921509933250296] = ???;  //  dest_result_addr=1152921509933250288 |  dest_result_addr=1152921509933250296
        // 0x0272B068: ADD x29, sp, #0x10         | X29 = (1152921509933250272 + 16) = 1152921509933250288 (0x100000013D7A76F0);
        // 0x0272B06C: ADRP x20, #0x3743000       | X20 = 57946112 (0x3743000);             
        // 0x0272B070: LDRB w8, [x20, #0xa96]     | W8 = (bool)static_value_03743A96;       
        // 0x0272B074: MOV x19, x0                | X19 = 1152921509933262304 (0x100000013D7AA5E0);//ML01
        // 0x0272B078: TBNZ w8, #0, #0x272b094    | if (static_value_03743A96 == true) goto label_0;
        // 0x0272B07C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x0272B080: LDR x8, [x8, #0x848]       | X8 = 0x2B8F6EC;                         
        // 0x0272B084: LDR w0, [x8]               | W0 = 0x147F;                            
        // 0x0272B088: BL #0x2782188              | X0 = sub_2782188( ?? 0x147F, ????);     
        // 0x0272B08C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B090: STRB w8, [x20, #0xa96]     | static_value_03743A96 = true;            //  dest_result_addr=57948822
        label_0:
        // 0x0272B094: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B09C: BL #0x268dde8              | X0 = UnityEngine.SystemInfo.get_supportsImageEffects();
        bool val_1 = UnityEngine.SystemInfo.supportsImageEffects;
        // 0x0272B0A0: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x0272B0A4: TBZ w8, #0, #0x272b12c     | if ((val_1 & 1) == false) goto label_7; 
        if(val_2 == false)
        {
            goto label_7;
        }
        // 0x0272B0A8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x0272B0AC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x0272B0B0: LDR x20, [x19, #0x20]      | X20 = this.blurShader; //P2             
        // 0x0272B0B4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x0272B0B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0272B0BC: TBZ w8, #0, #0x272b0cc     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x0272B0C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0272B0C4: CBNZ w8, #0x272b0cc        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x0272B0C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x0272B0CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B0D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272B0D4: MOV x1, x20                | X1 = this.blurShader;//m1               
        // 0x0272B0D8: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_3 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x0272B0DC: TBZ w0, #0, #0x272b12c     | if (val_3 == false) goto label_7;       
        if(val_3 == false)
        {
            goto label_7;
        }
        // 0x0272B0E0: MOV x0, x19                | X0 = 1152921509933262304 (0x100000013D7AA5E0);//ML01
        // 0x0272B0E4: BL #0x272ae28              | X0 = this.get_material();               
        UnityEngine.Material val_4 = this.material;
        // 0x0272B0E8: MOV x20, x0                | X20 = val_4;//m1                        
        // 0x0272B0EC: CBNZ x20, #0x272b0f4       | if (val_4 != null) goto label_5;        
        if(val_4 != null)
        {
            goto label_5;
        }
        // 0x0272B0F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_5:
        // 0x0272B0F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B0F8: MOV x0, x20                | X0 = val_4;//m1                         
        // 0x0272B0FC: BL #0x1a72c4c              | X0 = val_4.get_shader();                
        UnityEngine.Shader val_5 = val_4.shader;
        // 0x0272B100: MOV x20, x0                | X20 = val_5;//m1                        
        // 0x0272B104: CBNZ x20, #0x272b10c       | if (val_5 != null) goto label_6;        
        if(val_5 != null)
        {
            goto label_6;
        }
        // 0x0272B108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_6:
        // 0x0272B10C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B110: MOV x0, x20                | X0 = val_5;//m1                         
        // 0x0272B114: BL #0x1b8e0d8              | X0 = val_5.get_isSupported();           
        bool val_6 = val_5.isSupported;
        // 0x0272B118: AND w8, w0, #1             | W8 = (val_6 & 1);                       
        bool val_7 = val_6;
        // 0x0272B11C: TBZ w8, #0, #0x272b12c     | if ((val_6 & 1) == false) goto label_7; 
        if(val_7 == false)
        {
            goto label_7;
        }
        // 0x0272B120: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B124: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B128: RET                        |  return;                                
        return;
        label_7:
        // 0x0272B12C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B130: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x0272B134: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272B138: MOV x0, x19                | X0 = 1152921509933262304 (0x100000013D7AA5E0);//ML01
        // 0x0272B13C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x0272B140: B #0x20cb458               | this.set_enabled(value:  false); return;
        this.enabled = false;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B144 (41070916), len: 468  VirtAddr: 0x0272B144 RVA: 0x0272B144 token: 100663362 methodIndex: 24261 delegateWrapperIndex: 0 methodInvoker: 0
    public void FourTapCone(UnityEngine.RenderTexture source, UnityEngine.RenderTexture dest, int iteration)
    {
        //
        // Disasemble & Code
        // 0x0272B144: STP d9, d8, [sp, #-0x50]!  | stack[1152921509933386800] = ???;  stack[1152921509933386808] = ???;  //  dest_result_addr=1152921509933386800 |  dest_result_addr=1152921509933386808
        // 0x0272B148: STP x24, x23, [sp, #0x10]  | stack[1152921509933386816] = ???;  stack[1152921509933386824] = ???;  //  dest_result_addr=1152921509933386816 |  dest_result_addr=1152921509933386824
        // 0x0272B14C: STP x22, x21, [sp, #0x20]  | stack[1152921509933386832] = ???;  stack[1152921509933386840] = ???;  //  dest_result_addr=1152921509933386832 |  dest_result_addr=1152921509933386840
        // 0x0272B150: STP x20, x19, [sp, #0x30]  | stack[1152921509933386848] = ???;  stack[1152921509933386856] = ???;  //  dest_result_addr=1152921509933386848 |  dest_result_addr=1152921509933386856
        // 0x0272B154: STP x29, x30, [sp, #0x40]  | stack[1152921509933386864] = ???;  stack[1152921509933386872] = ???;  //  dest_result_addr=1152921509933386864 |  dest_result_addr=1152921509933386872
        // 0x0272B158: ADD x29, sp, #0x40         | X29 = (1152921509933386800 + 64) = 1152921509933386864 (0x100000013D7C8C70);
        // 0x0272B15C: SUB sp, sp, #0x20          | SP = (1152921509933386800 - 32) = 1152921509933386768 (0x100000013D7C8C10);
        // 0x0272B160: ADRP x23, #0x3743000       | X23 = 57946112 (0x3743000);             
        // 0x0272B164: LDRB w8, [x23, #0xa97]     | W8 = (bool)static_value_03743A97;       
        // 0x0272B168: MOV w21, w3                | W21 = iteration;//m1                    
        // 0x0272B16C: MOV x19, x2                | X19 = dest;//m1                         
        // 0x0272B170: MOV x20, x1                | X20 = source;//m1                       
        // 0x0272B174: MOV x22, x0                | X22 = 1152921509933398880 (0x100000013D7CBB60);//ML01
        // 0x0272B178: TBNZ w8, #0, #0x272b194    | if (static_value_03743A97 == true) goto label_0;
        // 0x0272B17C: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x0272B180: LDR x8, [x8, #0xaa8]       | X8 = 0x2B8F6DC;                         
        // 0x0272B184: LDR w0, [x8]               | W0 = 0x147B;                            
        // 0x0272B188: BL #0x2782188              | X0 = sub_2782188( ?? 0x147B, ????);     
        // 0x0272B18C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B190: STRB w8, [x23, #0xa97]     | static_value_03743A97 = true;            //  dest_result_addr=57948823
        label_0:
        // 0x0272B194: LDR s0, [x22, #0x1c]       | S0 = this.blurSpread; //P2              
        float val_7 = this.blurSpread;
        // 0x0272B198: SCVTF s1, w21              | S1 = (float)(iteration);                
        // 0x0272B19C: MOV x0, x22                | X0 = 1152921509933398880 (0x100000013D7CBB60);//ML01
        // 0x0272B1A0: FMUL s0, s1, s0            | S0 = (iteration * this.blurSpread);     
        val_7 = (float)iteration * val_7;
        // 0x0272B1A4: FMOV s1, #0.50000000       | S1 = 0.5;                               
        // 0x0272B1A8: FADD s8, s0, s1            | S8 = ((iteration * this.blurSpread) + 0.5f);
        float val_1 = val_7 + 0.5f;
        // 0x0272B1AC: BL #0x272ae28              | X0 = this.get_material();               
        UnityEngine.Material val_2 = this.material;
        // 0x0272B1B0: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x0272B1B4: LDR x8, [x8, #0xd58]       | X8 = 1152921505638826144;               
        // 0x0272B1B8: MOV x21, x0                | X21 = val_2;//m1                        
        // 0x0272B1BC: LDR x22, [x8]              | X22 = typeof(UnityEngine.Vector2[]);    
        // 0x0272B1C0: MOV x0, x22                | X0 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B1C4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Vector2[]), ????);
        // 0x0272B1C8: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x0272B1CC: MOV x0, x22                | X0 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B1D0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Vector2[]), ????);
        // 0x0272B1D4: MOV x22, x0                | X22 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B1D8: CBNZ x22, #0x272b1e0       | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x0272B1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Vector2[]), ????);
        label_1:
        // 0x0272B1E0: FNEG s9, s8                | S9 = -(((iteration * this.blurSpread) + 0.5f));
        // 0x0272B1E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B1E8: ADD x0, sp, #0x18          | X0 = (1152921509933386768 + 24) = 1152921509933386792 (0x100000013D7C8C28);
        // 0x0272B1EC: MOV v0.16b, v9.16b         | V0 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B1F0: MOV v1.16b, v9.16b         | V1 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B1F4: STR xzr, [sp, #0x18]       | stack[1152921509933386792] = 0x0;        //  dest_result_addr=1152921509933386792
        // 0x0272B1F8: BL #0x2697148              | null..ctor(_x:  -val_1, _y:  -val_1);   
        Geometric.Point val_3 = new Geometric.Point(_x:  -val_1, _y:  -val_1);
        // 0x0272B1FC: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B200: CBNZ w8, #0x272b210        | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze != 0) goto label_2;
        // 0x0272B204: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  -val_1, _y:  -val_1), ????);
        // 0x0272B208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B20C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  -val_1, _y:  -val_1), ????);
        label_2:
        // 0x0272B210: LDR x8, [sp, #0x18]        | X8 = val_3.x;                           
        // 0x0272B214: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B218: ADD x0, sp, #0x10          | X0 = (1152921509933386768 + 16) = 1152921509933386784 (0x100000013D7C8C20);
        // 0x0272B21C: MOV v0.16b, v9.16b         | V0 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B220: MOV v1.16b, v8.16b         | V1 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B224: STR x8, [x22, #0x20]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_20 = val_3.x;  //  dest_result_addr=1152921505638826176
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_20 = val_3.x;
        // 0x0272B228: STR xzr, [sp, #0x10]       | stack[1152921509933386784] = 0x0;        //  dest_result_addr=1152921509933386784
        // 0x0272B22C: BL #0x2697148              | null..ctor(_x:  -val_1, _y:  val_1);    
        Geometric.Point val_4 = new Geometric.Point(_x:  -val_1, _y:  val_1);
        // 0x0272B230: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B234: CMP w8, #1                 | STATE = COMPARE(UnityEngine.Vector2[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272B238: B.HI #0x272b248            | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze > 0x1) goto label_3;
        // 0x0272B23C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  -val_1, _y:  val_1), ????);
        // 0x0272B240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B244: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  -val_1, _y:  val_1), ????);
        label_3:
        // 0x0272B248: LDR x8, [sp, #0x10]        | X8 = val_4.x;                           
        // 0x0272B24C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B250: ADD x0, sp, #8             | X0 = (1152921509933386768 + 8) = 1152921509933386776 (0x100000013D7C8C18);
        // 0x0272B254: MOV v0.16b, v8.16b         | V0 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B258: MOV v1.16b, v8.16b         | V1 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B25C: STR x8, [x22, #0x28]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_28 = val_4.x;  //  dest_result_addr=1152921505638826184
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_28 = val_4.x;
        // 0x0272B260: STR xzr, [sp, #8]          | stack[1152921509933386776] = 0x0;        //  dest_result_addr=1152921509933386776
        // 0x0272B264: BL #0x2697148              | null..ctor(_x:  val_1, _y:  val_1);     
        Geometric.Point val_5 = new Geometric.Point(_x:  val_1, _y:  val_1);
        // 0x0272B268: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B26C: CMP w8, #2                 | STATE = COMPARE(UnityEngine.Vector2[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x0272B270: B.HI #0x272b280            | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze > 0x2) goto label_4;
        // 0x0272B274: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  val_1, _y:  val_1), ????);
        // 0x0272B278: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B27C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  val_1, _y:  val_1), ????);
        label_4:
        // 0x0272B280: LDR x8, [sp, #8]           | X8 = val_5.x;                           
        // 0x0272B284: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B288: MOV x0, sp                 | X0 = 1152921509933386768 (0x100000013D7C8C10);//ML01
        Geometric.Point val_6;
        // 0x0272B28C: MOV v0.16b, v8.16b         | V0 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B290: MOV v1.16b, v9.16b         | V1 = ((iteration * this.blurSpread) + 0.5f);//m1
        // 0x0272B294: STR x8, [x22, #0x30]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_30 = val_5.x;  //  dest_result_addr=1152921505638826192
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_30 = val_5.x;
        // 0x0272B298: STR xzr, [sp]              | stack[1152921509933386768] = 0x0;        //  dest_result_addr=1152921509933386768
        // 0x0272B29C: BL #0x2697148              | null..ctor(_x:  val_1, _y:  -val_1);    
        val_6 = new Geometric.Point(_x:  val_1, _y:  -val_1);
        // 0x0272B2A0: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B2A4: CMP w8, #3                 | STATE = COMPARE(UnityEngine.Vector2[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x0272B2A8: B.HI #0x272b2b8            | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze > 0x3) goto label_5;
        // 0x0272B2AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  val_1, _y:  -val_1), ????);
        // 0x0272B2B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B2B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  val_1, _y:  -val_1), ????);
        label_5:
        // 0x0272B2B8: LDR x8, [sp]               | X8 = val_6.x;                           
        // 0x0272B2BC: STR x8, [x22, #0x38]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_38 = val_6.x;  //  dest_result_addr=1152921505638826200
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_38 = val_6.x;
        // 0x0272B2C0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0272B2C4: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0272B2C8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0272B2CC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0272B2D0: TBZ w8, #0, #0x272b2e0     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272B2D4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0272B2D8: CBNZ w8, #0x272b2e0        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272B2DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_7:
        // 0x0272B2E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B2E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0272B2E8: MOV x1, x20                | X1 = source;//m1                        
        // 0x0272B2EC: MOV x2, x19                | X2 = dest;//m1                          
        // 0x0272B2F0: MOV x3, x21                | X3 = val_2;//m1                         
        // 0x0272B2F4: MOV x4, x22                | X4 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B2F8: BL #0x1a6bffc              | UnityEngine.Graphics.BlitMultiTap(source:  0, dest:  source, mat:  dest, offsets:  val_2);
        UnityEngine.Graphics.BlitMultiTap(source:  0, dest:  source, mat:  dest, offsets:  val_2);
        // 0x0272B2FC: SUB sp, x29, #0x40         | SP = (1152921509933386864 - 64) = 1152921509933386800 (0x100000013D7C8C30);
        // 0x0272B300: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B304: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x0272B308: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x0272B30C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x0272B310: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x0272B314: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B318 (41071384), len: 424  VirtAddr: 0x0272B318 RVA: 0x0272B318 token: 100663363 methodIndex: 24262 delegateWrapperIndex: 0 methodInvoker: 0
    private void DownSample4x(UnityEngine.RenderTexture source, UnityEngine.RenderTexture dest)
    {
        //
        // Disasemble & Code
        // 0x0272B318: STP x22, x21, [sp, #-0x30]! | stack[1152921509933523408] = ???;  stack[1152921509933523416] = ???;  //  dest_result_addr=1152921509933523408 |  dest_result_addr=1152921509933523416
        // 0x0272B31C: STP x20, x19, [sp, #0x10]  | stack[1152921509933523424] = ???;  stack[1152921509933523432] = ???;  //  dest_result_addr=1152921509933523424 |  dest_result_addr=1152921509933523432
        // 0x0272B320: STP x29, x30, [sp, #0x20]  | stack[1152921509933523440] = ???;  stack[1152921509933523448] = ???;  //  dest_result_addr=1152921509933523440 |  dest_result_addr=1152921509933523448
        // 0x0272B324: ADD x29, sp, #0x20         | X29 = (1152921509933523408 + 32) = 1152921509933523440 (0x100000013D7EA1F0);
        // 0x0272B328: SUB sp, sp, #0x20          | SP = (1152921509933523408 - 32) = 1152921509933523376 (0x100000013D7EA1B0);
        // 0x0272B32C: ADRP x22, #0x3743000       | X22 = 57946112 (0x3743000);             
        // 0x0272B330: LDRB w8, [x22, #0xa98]     | W8 = (bool)static_value_03743A98;       
        // 0x0272B334: MOV x19, x2                | X19 = dest;//m1                         
        // 0x0272B338: MOV x20, x1                | X20 = source;//m1                       
        // 0x0272B33C: MOV x21, x0                | X21 = 1152921509933535456 (0x100000013D7ED0E0);//ML01
        // 0x0272B340: TBNZ w8, #0, #0x272b35c    | if (static_value_03743A98 == true) goto label_0;
        // 0x0272B344: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x0272B348: LDR x8, [x8, #0x320]       | X8 = 0x2B8F6D8;                         
        // 0x0272B34C: LDR w0, [x8]               | W0 = 0x147A;                            
        // 0x0272B350: BL #0x2782188              | X0 = sub_2782188( ?? 0x147A, ????);     
        // 0x0272B354: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B358: STRB w8, [x22, #0xa98]     | static_value_03743A98 = true;            //  dest_result_addr=57948824
        label_0:
        // 0x0272B35C: MOV x0, x21                | X0 = 1152921509933535456 (0x100000013D7ED0E0);//ML01
        // 0x0272B360: BL #0x272ae28              | X0 = this.get_material();               
        UnityEngine.Material val_1 = this.material;
        // 0x0272B364: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
        // 0x0272B368: LDR x8, [x8, #0xd58]       | X8 = 1152921505638826144;               
        // 0x0272B36C: MOV x21, x0                | X21 = val_1;//m1                        
        // 0x0272B370: LDR x22, [x8]              | X22 = typeof(UnityEngine.Vector2[]);    
        // 0x0272B374: MOV x0, x22                | X0 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B378: BL #0x277461c              | X0 = sub_277461C( ?? typeof(UnityEngine.Vector2[]), ????);
        // 0x0272B37C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x0272B380: MOV x0, x22                | X0 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B384: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(UnityEngine.Vector2[]), ????);
        // 0x0272B388: MOV x22, x0                | X22 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B38C: CBNZ x22, #0x272b394       | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x0272B390: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(UnityEngine.Vector2[]), ????);
        label_1:
        // 0x0272B394: FMOV s0, #-1.00000000      | S0 = -1;                                
        // 0x0272B398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B39C: ADD x0, sp, #0x18          | X0 = (1152921509933523376 + 24) = 1152921509933523400 (0x100000013D7EA1C8);
        // 0x0272B3A0: MOV v1.16b, v0.16b         | V1 = -1;//m1                            
        // 0x0272B3A4: STR xzr, [sp, #0x18]       | stack[1152921509933523400] = 0x0;        //  dest_result_addr=1152921509933523400
        // 0x0272B3A8: BL #0x2697148              | null..ctor(_x:  -1f, _y:  -1f);         
        Geometric.Point val_2 = new Geometric.Point(_x:  -1f, _y:  -1f);
        // 0x0272B3AC: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B3B0: CBNZ w8, #0x272b3c0        | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze != 0) goto label_2;
        // 0x0272B3B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  -1f, _y:  -1f), ????);
        // 0x0272B3B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B3BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  -1f, _y:  -1f), ????);
        label_2:
        // 0x0272B3C0: LDR x8, [sp, #0x18]        | X8 = val_2.x;                           
        // 0x0272B3C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B3C8: FMOV s0, #-1.00000000      | S0 = -1;                                
        // 0x0272B3CC: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x0272B3D0: ADD x0, sp, #0x10          | X0 = (1152921509933523376 + 16) = 1152921509933523392 (0x100000013D7EA1C0);
        // 0x0272B3D4: STR x8, [x22, #0x20]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_20 = val_2.x;  //  dest_result_addr=1152921505638826176
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_20 = val_2.x;
        // 0x0272B3D8: STR xzr, [sp, #0x10]       | stack[1152921509933523392] = 0x0;        //  dest_result_addr=1152921509933523392
        // 0x0272B3DC: BL #0x2697148              | null..ctor(_x:  -1f, _y:  1f);          
        Geometric.Point val_3 = new Geometric.Point(_x:  -1f, _y:  1f);
        // 0x0272B3E0: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B3E4: CMP w8, #1                 | STATE = COMPARE(UnityEngine.Vector2[].__il2cppRuntimeField_namespaze, 0x1)
        // 0x0272B3E8: B.HI #0x272b3f8            | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze > 0x1) goto label_3;
        // 0x0272B3EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  -1f, _y:  1f), ????);
        // 0x0272B3F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B3F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  -1f, _y:  1f), ????);
        label_3:
        // 0x0272B3F8: LDR x8, [sp, #0x10]        | X8 = val_3.x;                           
        // 0x0272B3FC: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x0272B400: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B404: ADD x0, sp, #8             | X0 = (1152921509933523376 + 8) = 1152921509933523384 (0x100000013D7EA1B8);
        // 0x0272B408: MOV v1.16b, v0.16b         | V1 = 1;//m1                             
        // 0x0272B40C: STR x8, [x22, #0x28]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_28 = val_3.x;  //  dest_result_addr=1152921505638826184
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_28 = val_3.x;
        // 0x0272B410: STR xzr, [sp, #8]          | stack[1152921509933523384] = 0x0;        //  dest_result_addr=1152921509933523384
        // 0x0272B414: BL #0x2697148              | null..ctor(_x:  1f, _y:  1f);           
        Geometric.Point val_4 = new Geometric.Point(_x:  1f, _y:  1f);
        // 0x0272B418: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B41C: CMP w8, #2                 | STATE = COMPARE(UnityEngine.Vector2[].__il2cppRuntimeField_namespaze, 0x2)
        // 0x0272B420: B.HI #0x272b430            | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze > 0x2) goto label_4;
        // 0x0272B424: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  1f, _y:  1f), ????);
        // 0x0272B428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B42C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  1f, _y:  1f), ????);
        label_4:
        // 0x0272B430: LDR x8, [sp, #8]           | X8 = val_4.x;                           
        // 0x0272B434: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B438: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x0272B43C: FMOV s1, #-1.00000000      | S1 = -1;                                
        // 0x0272B440: MOV x0, sp                 | X0 = 1152921509933523376 (0x100000013D7EA1B0);//ML01
        Geometric.Point val_5;
        // 0x0272B444: STR x8, [x22, #0x30]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_30 = val_4.x;  //  dest_result_addr=1152921505638826192
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_30 = val_4.x;
        // 0x0272B448: STR xzr, [sp]              | stack[1152921509933523376] = 0x0;        //  dest_result_addr=1152921509933523376
        // 0x0272B44C: BL #0x2697148              | null..ctor(_x:  1f, _y:  -1f);          
        val_5 = new Geometric.Point(_x:  1f, _y:  -1f);
        // 0x0272B450: LDR w8, [x22, #0x18]       | W8 = UnityEngine.Vector2[].__il2cppRuntimeField_namespaze;
        // 0x0272B454: CMP w8, #3                 | STATE = COMPARE(UnityEngine.Vector2[].__il2cppRuntimeField_namespaze, 0x3)
        // 0x0272B458: B.HI #0x272b468            | if (UnityEngine.Vector2[].__il2cppRuntimeField_namespaze > 0x3) goto label_5;
        // 0x0272B45C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? null..ctor(_x:  1f, _y:  -1f), ????);
        // 0x0272B460: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272B464: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? null..ctor(_x:  1f, _y:  -1f), ????);
        label_5:
        // 0x0272B468: LDR x8, [sp]               | X8 = val_5.x;                           
        // 0x0272B46C: STR x8, [x22, #0x38]       | typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_38 = val_5.x;  //  dest_result_addr=1152921505638826200
        typeof(UnityEngine.Vector2[]).__il2cppRuntimeField_38 = val_5.x;
        // 0x0272B470: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0272B474: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0272B478: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0272B47C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0272B480: TBZ w8, #0, #0x272b490     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272B484: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0272B488: CBNZ w8, #0x272b490        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272B48C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_7:
        // 0x0272B490: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B494: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x0272B498: MOV x1, x20                | X1 = source;//m1                        
        // 0x0272B49C: MOV x2, x19                | X2 = dest;//m1                          
        // 0x0272B4A0: MOV x3, x21                | X3 = val_1;//m1                         
        // 0x0272B4A4: MOV x4, x22                | X4 = 1152921505638826144 (0x100000003D82C0A0);//ML01
        // 0x0272B4A8: BL #0x1a6bffc              | UnityEngine.Graphics.BlitMultiTap(source:  0, dest:  source, mat:  dest, offsets:  val_1);
        UnityEngine.Graphics.BlitMultiTap(source:  0, dest:  source, mat:  dest, offsets:  val_1);
        // 0x0272B4AC: SUB sp, x29, #0x20         | SP = (1152921509933523440 - 32) = 1152921509933523408 (0x100000013D7EA1D0);
        // 0x0272B4B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B4B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x0272B4B8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x0272B4BC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B4C0 (41071808), len: 392  VirtAddr: 0x0272B4C0 RVA: 0x0272B4C0 token: 100663364 methodIndex: 24263 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.RenderTexture val_9;
        // 0x0272B4C0: STP x26, x25, [sp, #-0x50]! | stack[1152921509933664048] = ???;  stack[1152921509933664056] = ???;  //  dest_result_addr=1152921509933664048 |  dest_result_addr=1152921509933664056
        // 0x0272B4C4: STP x24, x23, [sp, #0x10]  | stack[1152921509933664064] = ???;  stack[1152921509933664072] = ???;  //  dest_result_addr=1152921509933664064 |  dest_result_addr=1152921509933664072
        // 0x0272B4C8: STP x22, x21, [sp, #0x20]  | stack[1152921509933664080] = ???;  stack[1152921509933664088] = ???;  //  dest_result_addr=1152921509933664080 |  dest_result_addr=1152921509933664088
        // 0x0272B4CC: STP x20, x19, [sp, #0x30]  | stack[1152921509933664096] = ???;  stack[1152921509933664104] = ???;  //  dest_result_addr=1152921509933664096 |  dest_result_addr=1152921509933664104
        // 0x0272B4D0: STP x29, x30, [sp, #0x40]  | stack[1152921509933664112] = ???;  stack[1152921509933664120] = ???;  //  dest_result_addr=1152921509933664112 |  dest_result_addr=1152921509933664120
        // 0x0272B4D4: ADD x29, sp, #0x40         | X29 = (1152921509933664048 + 64) = 1152921509933664112 (0x100000013D80C770);
        // 0x0272B4D8: ADRP x21, #0x3743000       | X21 = 57946112 (0x3743000);             
        // 0x0272B4DC: LDRB w8, [x21, #0xa99]     | W8 = (bool)static_value_03743A99;       
        // 0x0272B4E0: MOV x19, x2                | X19 = destination;//m1                  
        // 0x0272B4E4: MOV x22, x1                | X22 = source;//m1                       
        // 0x0272B4E8: MOV x20, x0                | X20 = 1152921509933676128 (0x100000013D80F660);//ML01
        // 0x0272B4EC: TBNZ w8, #0, #0x272b508    | if (static_value_03743A99 == true) goto label_0;
        // 0x0272B4F0: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
        // 0x0272B4F4: LDR x8, [x8, #0x30]        | X8 = 0x2B8F6E8;                         
        // 0x0272B4F8: LDR w0, [x8]               | W0 = 0x147E;                            
        // 0x0272B4FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x147E, ????);     
        // 0x0272B500: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272B504: STRB w8, [x21, #0xa99]     | static_value_03743A99 = true;            //  dest_result_addr=57948825
        label_0:
        // 0x0272B508: CBNZ x22, #0x272b510       | if (source != null) goto label_1;       
        if(source != null)
        {
            goto label_1;
        }
        // 0x0272B50C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x147E, ????);     
        label_1:
        // 0x0272B510: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0272B514: MOV x0, x22                | X0 = source;//m1                        
        // 0x0272B518: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x0272B51C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x0272B520: ADD w8, w0, #3             | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_1 = source + 3;
        // 0x0272B524: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x0272B528: CSEL w8, w8, w0, lt        | W8 = source < null ? (source + 3) : source;
        var val_2 = (source < 0) ? (val_1) : (source);
        // 0x0272B52C: ASR w21, w8, #2            | W21 = (source < null ? (source + 3) : source >> 2);
        int val_3 = val_2 >> 2;
        // 0x0272B530: CBNZ x22, #0x272b538       | if (source != null) goto label_2;       
        if(source != null)
        {
            goto label_2;
        }
        // 0x0272B534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_2:
        // 0x0272B538: LDR x8, [x22]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0272B53C: MOV x0, x22                | X0 = source;//m1                        
        // 0x0272B540: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x0272B544: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x0272B548: ADD w8, w0, #3             | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_4 = source + 3;
        // 0x0272B54C: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x0272B550: CSEL w8, w8, w0, lt        | W8 = source < null ? (source + 3) : source;
        var val_5 = (source < 0) ? (val_4) : (source);
        // 0x0272B554: ASR w23, w8, #2            | W23 = (source < null ? (source + 3) : source >> 2);
        int val_6 = val_5 >> 2;
        // 0x0272B558: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B55C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x0272B560: MOV w1, w21                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x0272B564: MOV w2, w23                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x0272B568: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272B56C: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_3, depthBuffer:  val_6);
        UnityEngine.RenderTexture val_7 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_3, depthBuffer:  val_6);
        // 0x0272B570: MOV x24, x0                | X24 = val_7;//m1                        
        // 0x0272B574: MOV x0, x20                | X0 = 1152921509933676128 (0x100000013D80F660);//ML01
        // 0x0272B578: MOV x1, x22                | X1 = source;//m1                        
        // 0x0272B57C: MOV x2, x24                | X2 = val_7;//m1                         
        // 0x0272B580: BL #0x272b318              | this.DownSample4x(source:  source, dest:  val_7);
        this.DownSample4x(source:  source, dest:  val_7);
        // 0x0272B584: LDR w8, [x20, #0x18]       | W8 = this.iterations; //P2              
        // 0x0272B588: CMP w8, #1                 | STATE = COMPARE(this.iterations, 0x1)   
        // 0x0272B58C: B.LT #0x272b5ec            | if (this.iterations < 1) goto label_3;  
        if(this.iterations < 1)
        {
            goto label_3;
        }
        // 0x0272B590: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
        var val_9 = 0;
        label_4:
        // 0x0272B594: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B598: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x0272B59C: MOV w1, w21                | W1 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x0272B5A0: MOV w2, w23                | W2 = (source < null ? (source + 3) : source >> 2);//m1
        // 0x0272B5A4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0272B5A8: BL #0x1b89164              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_3, depthBuffer:  val_6);
        UnityEngine.RenderTexture val_8 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_3, depthBuffer:  val_6);
        // 0x0272B5AC: MOV x22, x0                | X22 = val_8;//m1                        
        val_9 = val_8;
        // 0x0272B5B0: MOV x0, x20                | X0 = 1152921509933676128 (0x100000013D80F660);//ML01
        // 0x0272B5B4: MOV x1, x24                | X1 = val_7;//m1                         
        // 0x0272B5B8: MOV x2, x22                | X2 = val_8;//m1                         
        // 0x0272B5BC: MOV w3, w25                | W3 = 0 (0x0);//ML01                     
        // 0x0272B5C0: BL #0x272b144              | this.FourTapCone(source:  val_7, dest:  val_9, iteration:  0);
        this.FourTapCone(source:  val_7, dest:  val_9, iteration:  0);
        // 0x0272B5C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B5C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272B5CC: MOV x1, x24                | X1 = val_7;//m1                         
        // 0x0272B5D0: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x0272B5D4: LDR w8, [x20, #0x18]       | W8 = this.iterations; //P2              
        // 0x0272B5D8: ADD w25, w25, #1           | W25 = (0 + 1);                          
        val_9 = val_9 + 1;
        // 0x0272B5DC: CMP w25, w8                | STATE = COMPARE((0 + 1), this.iterations)
        // 0x0272B5E0: MOV x24, x22               | X24 = val_8;//m1                        
        // 0x0272B5E4: B.LT #0x272b594            | if (0 < this.iterations) goto label_4;  
        if(val_9 < this.iterations)
        {
            goto label_4;
        }
        // 0x0272B5E8: B #0x272b5f0               |  goto label_5;                          
        goto label_5;
        label_3:
        // 0x0272B5EC: MOV x22, x24               | X22 = val_7;//m1                        
        val_9 = val_7;
        label_5:
        // 0x0272B5F0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0272B5F4: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x0272B5F8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x0272B5FC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0272B600: TBZ w8, #0, #0x272b610     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x0272B604: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0272B608: CBNZ w8, #0x272b610        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x0272B60C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_7:
        // 0x0272B610: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B614: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272B618: MOV x1, x22                | X1 = val_7;//m1                         
        // 0x0272B61C: MOV x2, x19                | X2 = destination;//m1                   
        // 0x0272B620: BL #0x1a6ba68              | UnityEngine.Graphics.Blit(source:  0, dest:  val_9);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_9);
        // 0x0272B624: MOV x1, x22                | X1 = val_7;//m1                         
        // 0x0272B628: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x0272B62C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x0272B630: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x0272B634: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x0272B638: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272B63C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272B640: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x0272B644: B #0x1b892ac               | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0); return;
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272B648 (41072200), len: 4  VirtAddr: 0x0272B648 RVA: 0x0272B648 token: 100663365 methodIndex: 24264 delegateWrapperIndex: 0 methodInvoker: 0
    private static BlurEffect()
    {
        //
        // Disasemble & Code
        // 0x0272B648: RET                        |  return;                                
        return;
    
    }

}
