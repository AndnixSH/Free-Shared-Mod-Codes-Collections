using UnityEngine;
public class BossAnimationConfig
{
    // Fields
    private static BossAnimationConfig _inst; // static_offset: 0x00000000
    private System.Collections.Generic.Dictionary<int, BossAnimationInfo> _dicBossCfg; //  0x00000010
    
    // Properties
    public static BossAnimationConfig Instance { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B93A24 (12139044), len: 120  VirtAddr: 0x00B93A24 RVA: 0x00B93A24 token: 100690117 methodIndex: 25209 delegateWrapperIndex: 0 methodInvoker: 0
    public BossAnimationConfig()
    {
        //
        // Disasemble & Code
        // 0x00B93A24: STP x20, x19, [sp, #-0x20]! | stack[1152921514474984784] = ???;  stack[1152921514474984792] = ???;  //  dest_result_addr=1152921514474984784 |  dest_result_addr=1152921514474984792
        // 0x00B93A28: STP x29, x30, [sp, #0x10]  | stack[1152921514474984800] = ???;  stack[1152921514474984808] = ???;  //  dest_result_addr=1152921514474984800 |  dest_result_addr=1152921514474984808
        // 0x00B93A2C: ADD x29, sp, #0x10         | X29 = (1152921514474984784 + 16) = 1152921514474984800 (0x100000024C2FD560);
        // 0x00B93A30: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B93A34: LDRB w8, [x20, #0xa64]     | W8 = (bool)static_value_03733A64;       
        // 0x00B93A38: MOV x19, x0                | X19 = 1152921514474996816 (0x100000024C300450);//ML01
        // 0x00B93A3C: TBNZ w8, #0, #0xb93a58     | if (static_value_03733A64 == true) goto label_0;
        // 0x00B93A40: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B93A44: LDR x8, [x8, #0x808]       | X8 = 0x2B8F8B0;                         
        // 0x00B93A48: LDR w0, [x8]               | W0 = 0x14F0;                            
        // 0x00B93A4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F0, ????);     
        // 0x00B93A50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93A54: STRB w8, [x20, #0xa64]     | static_value_03733A64 = true;            //  dest_result_addr=57883236
        label_0:
        // 0x00B93A58: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x00B93A5C: LDR x8, [x8, #0x170]       | X8 = 1152921504615792640;               
        // 0x00B93A60: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
        System.Collections.Generic.Dictionary<System.Int32, BossAnimationInfo> val_1 = null;
        // 0x00B93A64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
        // 0x00B93A68: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
        // 0x00B93A6C: LDR x8, [x8, #0x5e0]       | X8 = 1152921514474971792;               
        // 0x00B93A70: MOV x20, x0                | X20 = 1152921504615792640 (0x1000000000888000);//ML01
        // 0x00B93A74: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.Int32, BossAnimationInfo>::.ctor();
        // 0x00B93A78: BL #0x2413320              | .ctor();                                
        val_1 = new System.Collections.Generic.Dictionary<System.Int32, BossAnimationInfo>();
        // 0x00B93A7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B93A80: MOV x0, x19                | X0 = 1152921514474996816 (0x100000024C300450);//ML01
        // 0x00B93A84: STR x20, [x19, #0x10]      | this._dicBossCfg = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921514474996832
        this._dicBossCfg = val_1;
        // 0x00B93A88: BL #0x16f59f0              | this..ctor();                           
        // 0x00B93A8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93A90: MOV x0, x19                | X0 = 1152921514474996816 (0x100000024C300450);//ML01
        // 0x00B93A94: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B93A98: B #0xb93a9c                | this.InitLevelConfig(); return;         
        this.InitLevelConfig();
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93BE8 (12139496), len: 124  VirtAddr: 0x00B93BE8 RVA: 0x00B93BE8 token: 100690118 methodIndex: 25210 delegateWrapperIndex: 0 methodInvoker: 0
    public static BossAnimationConfig get_Instance()
    {
        //
        // Disasemble & Code
        //  | 
        BossAnimationConfig val_2;
        //  | 
        BossAnimationConfig val_3;
        // 0x00B93BE8: STP x20, x19, [sp, #-0x20]! | stack[1152921514475096784] = ???;  stack[1152921514475096792] = ???;  //  dest_result_addr=1152921514475096784 |  dest_result_addr=1152921514475096792
        // 0x00B93BEC: STP x29, x30, [sp, #0x10]  | stack[1152921514475096800] = ???;  stack[1152921514475096808] = ???;  //  dest_result_addr=1152921514475096800 |  dest_result_addr=1152921514475096808
        // 0x00B93BF0: ADD x29, sp, #0x10         | X29 = (1152921514475096784 + 16) = 1152921514475096800 (0x100000024C318AE0);
        // 0x00B93BF4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00B93BF8: LDRB w8, [x19, #0xa65]     | W8 = (bool)static_value_03733A65;       
        // 0x00B93BFC: TBNZ w8, #0, #0xb93c18     | if (static_value_03733A65 == true) goto label_0;
        // 0x00B93C00: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
        // 0x00B93C04: LDR x8, [x8, #0x9b0]       | X8 = 0x2B8F8B4;                         
        // 0x00B93C08: LDR w0, [x8]               | W0 = 0x14F1;                            
        // 0x00B93C0C: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F1, ????);     
        // 0x00B93C10: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93C14: STRB w8, [x19, #0xa65]     | static_value_03733A65 = true;            //  dest_result_addr=57883237
        label_0:
        // 0x00B93C18: ADRP x20, #0x3636000       | X20 = 56844288 (0x3636000);             
        // 0x00B93C1C: LDR x20, [x20, #0xa30]     | X20 = 1152921504887357440;              
        // 0x00B93C20: LDR x0, [x20]              | X0 = typeof(BossAnimationConfig);       
        BossAnimationConfig val_1 = null;
        // 0x00B93C24: LDR x8, [x0, #0xa0]        | X8 = BossAnimationConfig.__il2cppRuntimeField_static_fields;
        // 0x00B93C28: LDR x8, [x8]               | X8 = BossAnimationConfig._inst;         
        val_3 = BossAnimationConfig._inst;
        // 0x00B93C2C: CBNZ x8, #0xb93c54         | if (BossAnimationConfig._inst != null) goto label_1;
        if(val_3 != null)
        {
            goto label_1;
        }
        // 0x00B93C30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(BossAnimationConfig), ????);
        // 0x00B93C34: MOV x19, x0                | X19 = 1152921504887357440 (0x1000000010B84000);//ML01
        val_2 = val_1;
        // 0x00B93C38: BL #0xb93a24               | .ctor();                                
        val_1 = new BossAnimationConfig();
        // 0x00B93C3C: LDR x8, [x20]              | X8 = typeof(BossAnimationConfig);       
        // 0x00B93C40: LDR x8, [x8, #0xa0]        | X8 = BossAnimationConfig.__il2cppRuntimeField_static_fields;
        // 0x00B93C44: STR x19, [x8]              | BossAnimationConfig._inst = typeof(BossAnimationConfig);  //  dest_result_addr=1152921504887361536
        BossAnimationConfig._inst = val_2;
        // 0x00B93C48: LDR x8, [x20]              | X8 = typeof(BossAnimationConfig);       
        // 0x00B93C4C: LDR x8, [x8, #0xa0]        | X8 = BossAnimationConfig.__il2cppRuntimeField_static_fields;
        // 0x00B93C50: LDR x8, [x8]               | X8 = typeof(BossAnimationConfig);       
        val_3 = BossAnimationConfig._inst;
        label_1:
        // 0x00B93C54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93C58: MOV x0, x8                 | X0 = 1152921504887357440 (0x1000000010B84000);//ML01
        // 0x00B93C5C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B93C60: RET                        |  return (BossAnimationConfig)typeof(BossAnimationConfig);
        return (BossAnimationConfig)val_3;
        //  |  // // {name=val_0, type=BossAnimationConfig, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93A9C (12139164), len: 332  VirtAddr: 0x00B93A9C RVA: 0x00B93A9C token: 100690119 methodIndex: 25211 delegateWrapperIndex: 0 methodInvoker: 0
    private void InitLevelConfig()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        // 0x00B93A9C: STP x28, x27, [sp, #-0x60]! | stack[1152921514475229328] = ???;  stack[1152921514475229336] = ???;  //  dest_result_addr=1152921514475229328 |  dest_result_addr=1152921514475229336
        // 0x00B93AA0: STP x26, x25, [sp, #0x10]  | stack[1152921514475229344] = ???;  stack[1152921514475229352] = ???;  //  dest_result_addr=1152921514475229344 |  dest_result_addr=1152921514475229352
        // 0x00B93AA4: STP x24, x23, [sp, #0x20]  | stack[1152921514475229360] = ???;  stack[1152921514475229368] = ???;  //  dest_result_addr=1152921514475229360 |  dest_result_addr=1152921514475229368
        // 0x00B93AA8: STP x22, x21, [sp, #0x30]  | stack[1152921514475229376] = ???;  stack[1152921514475229384] = ???;  //  dest_result_addr=1152921514475229376 |  dest_result_addr=1152921514475229384
        // 0x00B93AAC: STP x20, x19, [sp, #0x40]  | stack[1152921514475229392] = ???;  stack[1152921514475229400] = ???;  //  dest_result_addr=1152921514475229392 |  dest_result_addr=1152921514475229400
        // 0x00B93AB0: STP x29, x30, [sp, #0x50]  | stack[1152921514475229408] = ???;  stack[1152921514475229416] = ???;  //  dest_result_addr=1152921514475229408 |  dest_result_addr=1152921514475229416
        // 0x00B93AB4: ADD x29, sp, #0x50         | X29 = (1152921514475229328 + 80) = 1152921514475229408 (0x100000024C3390E0);
        // 0x00B93AB8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B93ABC: LDRB w8, [x20, #0xa66]     | W8 = (bool)static_value_03733A66;       
        // 0x00B93AC0: MOV x19, x0                | X19 = 1152921514475241424 (0x100000024C33BFD0);//ML01
        // 0x00B93AC4: TBNZ w8, #0, #0xb93ae0     | if (static_value_03733A66 == true) goto label_0;
        // 0x00B93AC8: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x00B93ACC: LDR x8, [x8, #0x870]       | X8 = 0x2B8F8BC;                         
        // 0x00B93AD0: LDR w0, [x8]               | W0 = 0x14F3;                            
        // 0x00B93AD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F3, ????);     
        // 0x00B93AD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93ADC: STRB w8, [x20, #0xa66]     | static_value_03733A66 = true;            //  dest_result_addr=57883238
        label_0:
        // 0x00B93AE0: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
        // 0x00B93AE4: LDR x8, [x8, #0x638]       | X8 = 1152921504924684288;               
        // 0x00B93AE8: LDR x0, [x8]               | X0 = typeof(ReadFileTool);              
        // 0x00B93AEC: LDRB w8, [x0, #0x10a]      | W8 = ReadFileTool.__il2cppRuntimeField_10A;
        // 0x00B93AF0: TBZ w8, #0, #0xb93b00      | if (ReadFileTool.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B93AF4: LDR w8, [x0, #0xbc]        | W8 = ReadFileTool.__il2cppRuntimeField_cctor_finished;
        // 0x00B93AF8: CBNZ w8, #0xb93b00         | if (ReadFileTool.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B93AFC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ReadFileTool), ????);
        label_2:
        // 0x00B93B00: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00B93B04: ADRP x9, #0x363e000        | X9 = 56877056 (0x363E000);              
        // 0x00B93B08: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921514475196816)("Data/Animation/bossAniInfo");
        // 0x00B93B0C: LDR x9, [x9, #0x940]       | X9 = 1152921514475196944;               
        // 0x00B93B10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B93B14: LDR x1, [x8]               | X1 = "Data/Animation/bossAniInfo";      
        // 0x00B93B18: LDR x2, [x9]               | X2 = public static System.Collections.Generic.List<BossAnimationInfo> ReadFileTool::AddressToClass<System.Collections.Generic.List<BossAnimationInfo>>(string txtAddress);
        // 0x00B93B1C: BL #0xfdecdc               | X0 = ReadFileTool.AddressToClass<JSCMapDataConfig>(txtAddress:  0);
        JSCMapDataConfig val_1 = ReadFileTool.AddressToClass<JSCMapDataConfig>(txtAddress:  0);
        // 0x00B93B20: ADRP x25, #0x35cf000       | X25 = 56422400 (0x35CF000);             
        // 0x00B93B24: ADRP x26, #0x3682000       | X26 = 57155584 (0x3682000);             
        // 0x00B93B28: ADRP x27, #0x360d000       | X27 = 56676352 (0x360D000);             
        // 0x00B93B2C: LDR x25, [x25, #0x298]     | X25 = 1152921514475202064;              
        // 0x00B93B30: LDR x26, [x26, #0xd08]     | X26 = 1152921514475203088;              
        // 0x00B93B34: LDR x27, [x27, #0x228]     | X27 = 1152921514475204112;              
        // 0x00B93B38: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B93B3C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x00B93B40: B #0xb93b5c                |  goto label_3;                          
        goto label_3;
        label_10:
        // 0x00B93B44: LDR x3, [x27]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.Int32, BossAnimationInfo>::Add(System.Int32 key, BossAnimationInfo value);
        // 0x00B93B48: MOV x0, x22                | X0 = X22;//m1                           
        // 0x00B93B4C: MOV w1, w23                | W1 = W23;//m1                           
        // 0x00B93B50: MOV x2, x24                | X2 = X24;//m1                           
        // 0x00B93B54: BL #0x2415668              | X22.Add(key:  W23, value:  X24);        
        X22.Add(key:  W23, value:  X24);
        // 0x00B93B58: ADD w21, w21, #1           | W21 = (val_5 + 1) = val_5 (0x00000001); 
        val_5 = 1;
        label_3:
        // 0x00B93B5C: CBNZ x20, #0xb93b64        | if (val_1 != null) goto label_4;        
        if(val_1 != null)
        {
            goto label_4;
        }
        // 0x00B93B60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X22, ????);        
        label_4:
        // 0x00B93B64: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<BossAnimationInfo>::get_Count();
        // 0x00B93B68: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B93B6C: BL #0x25ed72c              | X0 = val_1.get_Count();                 
        int val_2 = val_1.Count;
        // 0x00B93B70: CMP w21, w0                | STATE = COMPARE(0x1, val_2)             
        // 0x00B93B74: B.GE #0xb93bcc             | if (val_5 >= val_2) goto label_5;       
        if(val_5 >= val_2)
        {
            goto label_5;
        }
        // 0x00B93B78: LDR x22, [x19, #0x10]      | X22 = this._dicBossCfg; //P2            
        // 0x00B93B7C: CBNZ x20, #0xb93b84        | if (val_1 != null) goto label_6;        
        if(val_1 != null)
        {
            goto label_6;
        }
        // 0x00B93B80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_6:
        // 0x00B93B84: LDR x2, [x26]              | X2 = public BossAnimationInfo System.Collections.Generic.List<BossAnimationInfo>::get_Item(int index);
        // 0x00B93B88: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B93B8C: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B93B90: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        BossAnimationInfo val_3 = val_1.Item[1];
        // 0x00B93B94: MOV x23, x0                | X23 = val_3;//m1                        
        // 0x00B93B98: CBNZ x23, #0xb93ba0        | if (val_3 != null) goto label_7;        
        if(val_3 != null)
        {
            goto label_7;
        }
        // 0x00B93B9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00B93BA0: LDR w23, [x23, #0x10]      | W23 = val_3._id; //P2                   
        // 0x00B93BA4: CBNZ x20, #0xb93bac        | if (val_1 != null) goto label_8;        
        if(val_1 != null)
        {
            goto label_8;
        }
        // 0x00B93BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_8:
        // 0x00B93BAC: LDR x2, [x26]              | X2 = public BossAnimationInfo System.Collections.Generic.List<BossAnimationInfo>::get_Item(int index);
        // 0x00B93BB0: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B93BB4: MOV w1, w21                | W1 = 1 (0x1);//ML01                     
        // 0x00B93BB8: BL #0x25ed734              | X0 = val_1.get_Item(index:  1);         
        BossAnimationInfo val_4 = val_1.Item[1];
        // 0x00B93BBC: MOV x24, x0                | X24 = val_4;//m1                        
        // 0x00B93BC0: CBNZ x22, #0xb93b44        | if (this._dicBossCfg != null) goto label_10;
        if(this._dicBossCfg != null)
        {
            goto label_10;
        }
        // 0x00B93BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        // 0x00B93BC8: B #0xb93b44                |  goto label_10;                         
        goto label_10;
        label_5:
        // 0x00B93BCC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93BD0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B93BD4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B93BD8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B93BDC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00B93BE0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00B93BE4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B93C6C (12139628), len: 280  VirtAddr: 0x00B93C6C RVA: 0x00B93C6C token: 100690120 methodIndex: 25212 delegateWrapperIndex: 0 methodInvoker: 0
    public BossAnimationInfo GetBossCfg(int id)
    {
        //
        // Disasemble & Code
        //  | 
        int val_4;
        //  | 
        var val_5;
        // 0x00B93C6C: STP x22, x21, [sp, #-0x30]! | stack[1152921514475380400] = ???;  stack[1152921514475380408] = ???;  //  dest_result_addr=1152921514475380400 |  dest_result_addr=1152921514475380408
        // 0x00B93C70: STP x20, x19, [sp, #0x10]  | stack[1152921514475380416] = ???;  stack[1152921514475380424] = ???;  //  dest_result_addr=1152921514475380416 |  dest_result_addr=1152921514475380424
        // 0x00B93C74: STP x29, x30, [sp, #0x20]  | stack[1152921514475380432] = ???;  stack[1152921514475380440] = ???;  //  dest_result_addr=1152921514475380432 |  dest_result_addr=1152921514475380440
        // 0x00B93C78: ADD x29, sp, #0x20         | X29 = (1152921514475380400 + 32) = 1152921514475380432 (0x100000024C35DED0);
        // 0x00B93C7C: SUB sp, sp, #0x10          | SP = (1152921514475380400 - 16) = 1152921514475380384 (0x100000024C35DEA0);
        // 0x00B93C80: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B93C84: LDRB w8, [x21, #0xa67]     | W8 = (bool)static_value_03733A67;       
        // 0x00B93C88: MOV w19, w1                | W19 = id;//m1                           
        val_4 = id;
        // 0x00B93C8C: MOV x20, x0                | X20 = 1152921514475392448 (0x100000024C360DC0);//ML01
        // 0x00B93C90: TBNZ w8, #0, #0xb93cac     | if (static_value_03733A67 == true) goto label_0;
        // 0x00B93C94: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
        // 0x00B93C98: LDR x8, [x8, #0x990]       | X8 = 0x2B8F8B8;                         
        // 0x00B93C9C: LDR w0, [x8]               | W0 = 0x14F2;                            
        // 0x00B93CA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x14F2, ????);     
        // 0x00B93CA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B93CA8: STRB w8, [x21, #0xa67]     | static_value_03733A67 = true;            //  dest_result_addr=57883239
        label_0:
        // 0x00B93CAC: LDR x21, [x20, #0x10]      | X21 = this._dicBossCfg; //P2            
        // 0x00B93CB0: CBNZ x21, #0xb93cb8        | if (this._dicBossCfg != null) goto label_1;
        if(this._dicBossCfg != null)
        {
            goto label_1;
        }
        // 0x00B93CB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x14F2, ????);     
        label_1:
        // 0x00B93CB8: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
        // 0x00B93CBC: LDR x8, [x8, #0x4e0]       | X8 = 1152921514475349904;               
        // 0x00B93CC0: MOV x0, x21                | X0 = this._dicBossCfg;//m1              
        // 0x00B93CC4: MOV w1, w19                | W1 = id;//m1                            
        // 0x00B93CC8: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.Int32, BossAnimationInfo>::ContainsKey(System.Int32 key);
        // 0x00B93CCC: BL #0x2415bdc              | X0 = this._dicBossCfg.ContainsKey(key:  val_4);
        bool val_1 = this._dicBossCfg.ContainsKey(key:  val_4);
        // 0x00B93CD0: TBZ w0, #0, #0xb93cfc      | if (val_1 == false) goto label_2;       
        if(val_1 == false)
        {
            goto label_2;
        }
        // 0x00B93CD4: LDR x20, [x20, #0x10]      | X20 = this._dicBossCfg; //P2            
        // 0x00B93CD8: CBNZ x20, #0xb93ce0        | if (this._dicBossCfg != null) goto label_3;
        if(this._dicBossCfg != null)
        {
            goto label_3;
        }
        // 0x00B93CDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B93CE0: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
        // 0x00B93CE4: LDR x8, [x8, #0xbb8]       | X8 = 1152921514475355024;               
        // 0x00B93CE8: MOV x0, x20                | X0 = this._dicBossCfg;//m1              
        // 0x00B93CEC: MOV w1, w19                | W1 = id;//m1                            
        // 0x00B93CF0: LDR x2, [x8]               | X2 = public BossAnimationInfo System.Collections.Generic.Dictionary<System.Int32, BossAnimationInfo>::get_Item(System.Int32 key);
        // 0x00B93CF4: BL #0x24144f0              | X0 = this._dicBossCfg.get_Item(key:  val_4);
        BossAnimationInfo val_2 = this._dicBossCfg.Item[val_4];
        // 0x00B93CF8: B #0xb93d70                |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x00B93CFC: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
        // 0x00B93D00: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
        // 0x00B93D04: ADD x1, sp, #0xc           | X1 = (1152921514475380384 + 12) = 1152921514475380396 (0x100000024C35DEAC);
        // 0x00B93D08: STR w19, [sp, #0xc]        | stack[1152921514475380396] = id;         //  dest_result_addr=1152921514475380396
        // 0x00B93D0C: LDR x0, [x8]               | X0 = typeof(System.Int32);              
        // 0x00B93D10: BL #0x27bc028              | X0 = 1152921514475436736 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), id);
        // 0x00B93D14: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B93D18: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921514475364240)("找不到boss动画id为{0}的信息");
        // 0x00B93D1C: MOV x2, x0                 | X2 = 1152921514475436736 (0x100000024C36BAC0);//ML01
        // 0x00B93D20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B93D24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B93D28: LDR x1, [x8]               | X1 = "找不到boss动画id为{0}的信息";              
        // 0x00B93D2C: BL #0x279525c              | X0 = EString.EFormat(format:  0, arg0:  "找不到boss动画id为{0}的信息");
        string val_3 = EString.EFormat(format:  0, arg0:  "找不到boss动画id为{0}的信息");
        // 0x00B93D30: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00B93D34: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00B93D38: MOV x19, x0                | X19 = val_3;//m1                        
        val_4 = val_3;
        // 0x00B93D3C: LDR x8, [x8]               | X8 = typeof(EDebug);                    
        // 0x00B93D40: LDRB w9, [x8, #0x10a]      | W9 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00B93D44: TBZ w9, #0, #0xb93d58      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00B93D48: LDR w9, [x8, #0xbc]        | W9 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00B93D4C: CBNZ w9, #0xb93d58         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00B93D50: MOV x0, x8                 | X0 = 1152921504924098560 (0x1000000012E8E000);//ML01
        // 0x00B93D54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_6:
        // 0x00B93D58: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B93D5C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B93D60: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00B93D64: MOV x1, x19                | X1 = val_3;//m1                         
        // 0x00B93D68: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  val_4);
        EDebug.Log(message:  0, isShowStack:  val_4);
        // 0x00B93D6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        val_5 = 0;
        label_4:
        // 0x00B93D70: SUB sp, x29, #0x20         | SP = (1152921514475380432 - 32) = 1152921514475380400 (0x100000024C35DEB0);
        // 0x00B93D74: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B93D78: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B93D7C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B93D80: RET                        |  return (BossAnimationInfo)null;        
        return (BossAnimationInfo)val_5;
        //  |  // // {name=val_0, type=BossAnimationInfo, size=8, nGRN=0 }
    
    }

}
