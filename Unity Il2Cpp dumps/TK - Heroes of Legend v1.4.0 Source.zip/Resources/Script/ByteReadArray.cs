using UnityEngine;
public class ByteReadArray
{
    // Fields
    private const byte MaxBufferSize = 128;
    private static readonly byte[] buffer; // static_offset: 0x00000000
    private static readonly char[] charBuffer; // static_offset: 0x00000008
    private static readonly System.Text.StringBuilder sb; // static_offset: 0x00000010
    private static readonly System.Text.Decoder decoder; // static_offset: 0x00000018
    private System.IO.MemoryStream m_Stream; //  0x00000010
    private int start_offset; //  0x00000018
    
    // Properties
    public int Length { get; }
    internal System.IO.MemoryStream MemoryStream { get; }
    public int Postion { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA2E6C (12201580), len: 124  VirtAddr: 0x00BA2E6C RVA: 0x00BA2E6C token: 100690727 methodIndex: 25566 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteReadArray(byte[] buffer)
    {
        //
        // Disasemble & Code
        // 0x00BA2E6C: STP x22, x21, [sp, #-0x30]! | stack[1152921514566228288] = ???;  stack[1152921514566228296] = ???;  //  dest_result_addr=1152921514566228288 |  dest_result_addr=1152921514566228296
        // 0x00BA2E70: STP x20, x19, [sp, #0x10]  | stack[1152921514566228304] = ???;  stack[1152921514566228312] = ???;  //  dest_result_addr=1152921514566228304 |  dest_result_addr=1152921514566228312
        // 0x00BA2E74: STP x29, x30, [sp, #0x20]  | stack[1152921514566228320] = ???;  stack[1152921514566228328] = ???;  //  dest_result_addr=1152921514566228320 |  dest_result_addr=1152921514566228328
        // 0x00BA2E78: ADD x29, sp, #0x20         | X29 = (1152921514566228288 + 32) = 1152921514566228320 (0x1000000251A01960);
        // 0x00BA2E7C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA2E80: LDRB w8, [x21, #0xab9]     | W8 = (bool)static_value_03733AB9;       
        // 0x00BA2E84: MOV x20, x1                | X20 = buffer;//m1                       
        // 0x00BA2E88: MOV x19, x0                | X19 = 1152921514566240336 (0x1000000251A04850);//ML01
        // 0x00BA2E8C: TBNZ w8, #0, #0xba2ea8     | if (static_value_03733AB9 == true) goto label_0;
        // 0x00BA2E90: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
        // 0x00BA2E94: LDR x8, [x8, #0xb80]       | X8 = 0x2B8FF90;                         
        // 0x00BA2E98: LDR w0, [x8]               | W0 = 0x16A8;                            
        // 0x00BA2E9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A8, ????);     
        // 0x00BA2EA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA2EA4: STRB w8, [x21, #0xab9]     | static_value_03733AB9 = true;            //  dest_result_addr=57883321
        label_0:
        // 0x00BA2EA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2EAC: MOV x0, x19                | X0 = 1152921514566240336 (0x1000000251A04850);//ML01
        // 0x00BA2EB0: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA2EB4: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00BA2EB8: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
        // 0x00BA2EBC: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
        System.IO.MemoryStream val_1 = null;
        // 0x00BA2EC0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00BA2EC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA2EC8: MOV x1, x20                | X1 = buffer;//m1                        
        // 0x00BA2ECC: MOV x21, x0                | X21 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA2ED0: BL #0x1e78658              | .ctor(buffer:  buffer);                 
        val_1 = new System.IO.MemoryStream(buffer:  buffer);
        // 0x00BA2ED4: STR x21, [x19, #0x10]      | this.m_Stream = typeof(System.IO.MemoryStream);  //  dest_result_addr=1152921514566240352
        this.m_Stream = val_1;
        // 0x00BA2ED8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2EDC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2EE0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2EE4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2EE8 (12201704), len: 44  VirtAddr: 0x00BA2EE8 RVA: 0x00BA2EE8 token: 100690728 methodIndex: 25567 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteReadArray(System.IO.MemoryStream ms)
    {
        //
        // Disasemble & Code
        // 0x00BA2EE8: STP x20, x19, [sp, #-0x20]! | stack[1152921514566381264] = ???;  stack[1152921514566381272] = ???;  //  dest_result_addr=1152921514566381264 |  dest_result_addr=1152921514566381272
        // 0x00BA2EEC: STP x29, x30, [sp, #0x10]  | stack[1152921514566381280] = ???;  stack[1152921514566381288] = ???;  //  dest_result_addr=1152921514566381280 |  dest_result_addr=1152921514566381288
        // 0x00BA2EF0: ADD x29, sp, #0x10         | X29 = (1152921514566381264 + 16) = 1152921514566381280 (0x1000000251A26EE0);
        // 0x00BA2EF4: MOV x19, x1                | X19 = ms;//m1                           
        // 0x00BA2EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2EFC: MOV x20, x0                | X20 = 1152921514566393296 (0x1000000251A29DD0);//ML01
        // 0x00BA2F00: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA2F04: STR x19, [x20, #0x10]      | this.m_Stream = ms;                      //  dest_result_addr=1152921514566393312
        this.m_Stream = ms;
        // 0x00BA2F08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2F0C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2F10: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2F14 (12201748), len: 156  VirtAddr: 0x00BA2F14 RVA: 0x00BA2F14 token: 100690729 methodIndex: 25568 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteReadArray(byte[] buffer, int start_offset)
    {
        //
        // Disasemble & Code
        // 0x00BA2F14: STP x22, x21, [sp, #-0x30]! | stack[1152921514566534208] = ???;  stack[1152921514566534216] = ???;  //  dest_result_addr=1152921514566534208 |  dest_result_addr=1152921514566534216
        // 0x00BA2F18: STP x20, x19, [sp, #0x10]  | stack[1152921514566534224] = ???;  stack[1152921514566534232] = ???;  //  dest_result_addr=1152921514566534224 |  dest_result_addr=1152921514566534232
        // 0x00BA2F1C: STP x29, x30, [sp, #0x20]  | stack[1152921514566534240] = ???;  stack[1152921514566534248] = ???;  //  dest_result_addr=1152921514566534240 |  dest_result_addr=1152921514566534248
        // 0x00BA2F20: ADD x29, sp, #0x20         | X29 = (1152921514566534208 + 32) = 1152921514566534240 (0x1000000251A4C460);
        // 0x00BA2F24: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
        // 0x00BA2F28: LDRB w8, [x22, #0xaba]     | W8 = (bool)static_value_03733ABA;       
        // 0x00BA2F2C: MOV w19, w2                | W19 = start_offset;//m1                 
        // 0x00BA2F30: MOV x21, x1                | X21 = buffer;//m1                       
        // 0x00BA2F34: MOV x20, x0                | X20 = 1152921514566546256 (0x1000000251A4F350);//ML01
        // 0x00BA2F38: TBNZ w8, #0, #0xba2f54     | if (static_value_03733ABA == true) goto label_0;
        // 0x00BA2F3C: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00BA2F40: LDR x8, [x8, #0xa00]       | X8 = 0x2B8FF94;                         
        // 0x00BA2F44: LDR w0, [x8]               | W0 = 0x16A9;                            
        // 0x00BA2F48: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A9, ????);     
        // 0x00BA2F4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA2F50: STRB w8, [x22, #0xaba]     | static_value_03733ABA = true;            //  dest_result_addr=57883322
        label_0:
        // 0x00BA2F54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2F58: MOV x0, x20                | X0 = 1152921514566546256 (0x1000000251A4F350);//ML01
        // 0x00BA2F5C: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA2F60: STR w19, [x20, #0x18]      | this.start_offset = start_offset;        //  dest_result_addr=1152921514566546280
        this.start_offset = start_offset;
        // 0x00BA2F64: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00BA2F68: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
        // 0x00BA2F6C: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
        System.IO.MemoryStream val_1 = null;
        // 0x00BA2F70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00BA2F74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA2F78: MOV x1, x21                | X1 = buffer;//m1                        
        // 0x00BA2F7C: MOV x22, x0                | X22 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA2F80: BL #0x1e78658              | .ctor(buffer:  buffer);                 
        val_1 = new System.IO.MemoryStream(buffer:  buffer);
        // 0x00BA2F84: STR x22, [x20, #0x10]      | this.m_Stream = typeof(System.IO.MemoryStream);  //  dest_result_addr=1152921514566546272
        this.m_Stream = val_1;
        // 0x00BA2F88: CBNZ x22, #0xba2f90        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00BA2F8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(buffer:  buffer), ????);
        label_1:
        // 0x00BA2F90: LDR x8, [x22]              | X8 = ;                                  
        // 0x00BA2F94: SXTW x1, w19               | X1 = (long)(int)(start_offset);         
        // 0x00BA2F98: MOV x0, x22                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA2F9C: LDP x3, x2, [x8, #0x1b0]   |                                          //  not_find_field!1:432 |  not_find_field!1:440
        // 0x00BA2FA0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2FA4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2FA8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA2FAC: BR x3                      | goto mem[null + 432];                   
        goto mem[null + 432];
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA2FB0 (12201904), len: 84  VirtAddr: 0x00BA2FB0 RVA: 0x00BA2FB0 token: 100690730 methodIndex: 25569 delegateWrapperIndex: 0 methodInvoker: 0
    public ByteReadArray(System.IO.MemoryStream memStream, int start_offset)
    {
        //
        // Disasemble & Code
        // 0x00BA2FB0: STP x22, x21, [sp, #-0x30]! | stack[1152921514566687168] = ???;  stack[1152921514566687176] = ???;  //  dest_result_addr=1152921514566687168 |  dest_result_addr=1152921514566687176
        // 0x00BA2FB4: STP x20, x19, [sp, #0x10]  | stack[1152921514566687184] = ???;  stack[1152921514566687192] = ???;  //  dest_result_addr=1152921514566687184 |  dest_result_addr=1152921514566687192
        // 0x00BA2FB8: STP x29, x30, [sp, #0x20]  | stack[1152921514566687200] = ???;  stack[1152921514566687208] = ???;  //  dest_result_addr=1152921514566687200 |  dest_result_addr=1152921514566687208
        // 0x00BA2FBC: ADD x29, sp, #0x20         | X29 = (1152921514566687168 + 32) = 1152921514566687200 (0x1000000251A719E0);
        // 0x00BA2FC0: MOV x19, x1                | X19 = memStream;//m1                    
        // 0x00BA2FC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA2FC8: MOV w20, w2                | W20 = start_offset;//m1                 
        // 0x00BA2FCC: MOV x21, x0                | X21 = 1152921514566699216 (0x1000000251A748D0);//ML01
        // 0x00BA2FD0: BL #0x16f59f0              | this..ctor();                           
        // 0x00BA2FD4: STR w20, [x21, #0x18]      | this.start_offset = start_offset;        //  dest_result_addr=1152921514566699240
        this.start_offset = start_offset;
        // 0x00BA2FD8: STR x19, [x21, #0x10]      | this.m_Stream = memStream;               //  dest_result_addr=1152921514566699232
        this.m_Stream = memStream;
        // 0x00BA2FDC: CBNZ x19, #0xba2fe4        | if (memStream != null) goto label_0;    
        if(memStream != null)
        {
            goto label_0;
        }
        // 0x00BA2FE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA2FE4: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA2FE8: SXTW x1, w20               | X1 = (long)(int)(start_offset);         
        // 0x00BA2FEC: MOV x0, x19                | X0 = memStream;//m1                     
        // 0x00BA2FF0: LDP x3, x2, [x8, #0x1b0]   | X3 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0; X2 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B8; //  | 
        // 0x00BA2FF4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA2FF8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA2FFC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3000: BR x3                      | goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0;
        goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3004 (12201988), len: 28  VirtAddr: 0x00BA3004 RVA: 0x00BA3004 token: 100690731 methodIndex: 25570 delegateWrapperIndex: 0 methodInvoker: 0
    public bool ReadBoolean()
    {
        //
        // Disasemble & Code
        // 0x00BA3004: STP x29, x30, [sp, #-0x10]! | stack[1152921514566803296] = ???;  stack[1152921514566803304] = ???;  //  dest_result_addr=1152921514566803296 |  dest_result_addr=1152921514566803304
        // 0x00BA3008: MOV x29, sp                | X29 = 1152921514566803296 (0x1000000251A8DF60);//ML01
        // 0x00BA300C: BL #0xba3020               | X0 = this.ReadByte();                   
        byte val_1 = this.ReadByte();
        // 0x00BA3010: TST w0, #0xff              | STATE = COMPARE(val_1, 0xFF)            
        // 0x00BA3014: CSET w0, ne                | W0 = val_1 != 255 ? 1 : 0;              
        var val_2 = (val_1 != 255) ? 1 : 0;
        // 0x00BA3018: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
        // 0x00BA301C: RET                        |  return (System.Boolean)val_1 != 255 ? 1 : 0;
        return (bool)val_2;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3140 (12202304), len: 264  VirtAddr: 0x00BA3140 RVA: 0x00BA3140 token: 100690732 methodIndex: 25571 delegateWrapperIndex: 0 methodInvoker: 0
    public static byte[] inverse(byte[] source)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00BA3140: STP x24, x23, [sp, #-0x40]! | stack[1152921514566952112] = ???;  stack[1152921514566952120] = ???;  //  dest_result_addr=1152921514566952112 |  dest_result_addr=1152921514566952120
        // 0x00BA3144: STP x22, x21, [sp, #0x10]  | stack[1152921514566952128] = ???;  stack[1152921514566952136] = ???;  //  dest_result_addr=1152921514566952128 |  dest_result_addr=1152921514566952136
        // 0x00BA3148: STP x20, x19, [sp, #0x20]  | stack[1152921514566952144] = ???;  stack[1152921514566952152] = ???;  //  dest_result_addr=1152921514566952144 |  dest_result_addr=1152921514566952152
        // 0x00BA314C: STP x29, x30, [sp, #0x30]  | stack[1152921514566952160] = ???;  stack[1152921514566952168] = ???;  //  dest_result_addr=1152921514566952160 |  dest_result_addr=1152921514566952168
        // 0x00BA3150: ADD x29, sp, #0x30         | X29 = (1152921514566952112 + 48) = 1152921514566952160 (0x1000000251AB24E0);
        // 0x00BA3154: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA3158: LDRB w8, [x20, #0xabb]     | W8 = (bool)static_value_03733ABB;       
        // 0x00BA315C: MOV x19, x1                | X19 = X1;//m1                           
        // 0x00BA3160: TBNZ w8, #0, #0xba317c     | if (static_value_03733ABB == true) goto label_0;
        // 0x00BA3164: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
        // 0x00BA3168: LDR x8, [x8, #0xee0]       | X8 = 0x2B8FF98;                         
        // 0x00BA316C: LDR w0, [x8]               | W0 = 0x16AA;                            
        // 0x00BA3170: BL #0x2782188              | X0 = sub_2782188( ?? 0x16AA, ????);     
        // 0x00BA3174: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3178: STRB w8, [x20, #0xabb]     | static_value_03733ABB = true;            //  dest_result_addr=57883323
        label_0:
        // 0x00BA317C: CBNZ x19, #0xba3184        | if (X1 != 0) goto label_1;              
        if(X1 != 0)
        {
            goto label_1;
        }
        // 0x00BA3180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16AA, ????);     
        label_1:
        // 0x00BA3184: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00BA3188: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x00BA318C: LDR w21, [x19, #0x18]      | W21 = X1 + 24;                          
        val_4 = mem[X1 + 24];
        val_4 = X1 + 24;
        // 0x00BA3190: LDR x20, [x8]              | X20 = typeof(System.Byte[]);            
        // 0x00BA3194: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA3198: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00BA319C: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA31A0: MOV x1, x21                | X1 = X1 + 24;//m1                       
        // 0x00BA31A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00BA31A8: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA31AC: CBNZ x19, #0xba31b4        | if (X1 != 0) goto label_2;              
        if(X1 != 0)
        {
            goto label_2;
        }
        // 0x00BA31B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_2:
        // 0x00BA31B4: LDR x8, [x19, #0x18]       | X8 = X1 + 24;                           
        // 0x00BA31B8: SUB w9, w8, #1             | W9 = (X1 + 24 - 1);                     
        var val_1 = (X1 + 24) - 1;
        // 0x00BA31BC: TBNZ w9, #0x1f, #0xba3230  | if (((X1 + 24 - 1) & 0x80000000) != 0) goto label_3;
        if((val_1 & 2147483648) != 0)
        {
            goto label_3;
        }
        // 0x00BA31C0: SXTW x21, w9               | X21 = (long)(int)((X1 + 24 - 1));       
        // 0x00BA31C4: NEG w22, w8                | W22 = -(X1 + 24);                       
        var val_5 = -(X1 + 24);
        label_8:
        // 0x00BA31C8: CBNZ x19, #0xba31d4        | if (X1 != 0) goto label_4;              
        if(X1 != 0)
        {
            goto label_4;
        }
        // 0x00BA31CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        // 0x00BA31D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_4:
        // 0x00BA31D4: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
        var val_4 = X1 + 24;
        // 0x00BA31D8: ADD w9, w22, w8            | W9 = (X1 + 24 + X1 + 24);               
        var val_2 = val_5 + val_4;
        // 0x00BA31DC: SXTW x23, w9               | X23 = (long)(int)((X1 + 24 + X1 + 24)); 
        // 0x00BA31E0: CMP w9, w8                 | STATE = COMPARE((X1 + 24 + X1 + 24), X1 + 24)
        // 0x00BA31E4: B.LO #0xba31f4             | if (val_2 < X1 + 24) goto label_5;      
        if(val_2 < val_4)
        {
            goto label_5;
        }
        // 0x00BA31E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
        // 0x00BA31EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA31F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
        label_5:
        // 0x00BA31F4: ADD x8, x19, x23           | X8 = (X1 + (long)(int)((X1 + 24 + X1 + 24)));
        val_4 = X1 + (long)val_2;
        // 0x00BA31F8: LDRB w23, [x8, #0x20]      | W23 = (X1 + (long)(int)((X1 + 24 + X1 + 24))) + 32;
        // 0x00BA31FC: CBNZ x20, #0xba3204        | if ( != null) goto label_6;             
        if(null != null)
        {
            goto label_6;
        }
        // 0x00BA3200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_6:
        // 0x00BA3204: LDR w8, [x20, #0x18]       | W8 = System.Byte[].__il2cppRuntimeField_namespaze;
        // 0x00BA3208: CMP x21, x8                | STATE = COMPARE((long)(int)((X1 + 24 - 1)), System.Byte[].__il2cppRuntimeField_namespaze)
        // 0x00BA320C: B.LO #0xba321c             | if ((long)val_1 < System.Byte[].__il2cppRuntimeField_namespaze) goto label_7;
        // 0x00BA3210: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
        // 0x00BA3214: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3218: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
        label_7:
        // 0x00BA321C: ADD x8, x20, x21           | X8 = (null + (long)(int)((X1 + 24 - 1)));
        var val_3 = null + (long)val_1;
        // 0x00BA3220: SUB x21, x21, #1           | X21 = ((long)(int)((X1 + 24 - 1)) - 1); 
        val_4 = (long)val_1 - 1;
        // 0x00BA3224: ADD w22, w22, #1           | W22 = (X1 + 24 + 1);                    
        val_5 = val_5 + 1;
        // 0x00BA3228: STRB w23, [x8, #0x20]      | mem2[0] = (X1 + (long)(int)((X1 + 24 + X1 + 24))) + 32;  //  dest_result_addr=0
        mem2[0] = (X1 + (long)(int)((X1 + 24 + X1 + 24))) + 32;
        // 0x00BA322C: TBZ w21, #0x1f, #0xba31c8  | if ((((long)(int)((X1 + 24 - 1)) - 1) & 0x80000000) == 0) goto label_8;
        if((val_4 & 2147483648) == 0)
        {
            goto label_8;
        }
        label_3:
        // 0x00BA3230: MOV x0, x20                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA3234: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3238: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA323C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3240: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA3244: RET                        |  return (System.Byte[])typeof(System.Byte[]);
        return (System.Byte[])null;
        //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3020 (12202016), len: 288  VirtAddr: 0x00BA3020 RVA: 0x00BA3020 token: 100690733 methodIndex: 25572 delegateWrapperIndex: 0 methodInvoker: 0
    public byte ReadByte()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        // 0x00BA3020: STP x22, x21, [sp, #-0x30]! | stack[1152921514567110208] = ???;  stack[1152921514567110216] = ???;  //  dest_result_addr=1152921514567110208 |  dest_result_addr=1152921514567110216
        // 0x00BA3024: STP x20, x19, [sp, #0x10]  | stack[1152921514567110224] = ???;  stack[1152921514567110232] = ???;  //  dest_result_addr=1152921514567110224 |  dest_result_addr=1152921514567110232
        // 0x00BA3028: STP x29, x30, [sp, #0x20]  | stack[1152921514567110240] = ???;  stack[1152921514567110248] = ???;  //  dest_result_addr=1152921514567110240 |  dest_result_addr=1152921514567110248
        // 0x00BA302C: ADD x29, sp, #0x20         | X29 = (1152921514567110208 + 32) = 1152921514567110240 (0x1000000251AD8E60);
        // 0x00BA3030: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA3034: LDRB w8, [x20, #0xabc]     | W8 = (bool)static_value_03733ABC;       
        // 0x00BA3038: MOV x19, x0                | X19 = 1152921514567122256 (0x1000000251ADBD50);//ML01
        // 0x00BA303C: TBNZ w8, #0, #0xba3058     | if (static_value_03733ABC == true) goto label_0;
        // 0x00BA3040: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
        // 0x00BA3044: LDR x8, [x8, #0xab8]       | X8 = 0x2B8FF9C;                         
        // 0x00BA3048: LDR w0, [x8]               | W0 = 0x16AB;                            
        // 0x00BA304C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16AB, ????);     
        // 0x00BA3050: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3054: STRB w8, [x20, #0xabc]     | static_value_03733ABC = true;            //  dest_result_addr=57883324
        label_0:
        // 0x00BA3058: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA305C: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA3060: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA3064: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_3 = null;
        // 0x00BA3068: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA306C: TBZ w8, #0, #0xba3080      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA3070: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3074: CBNZ w8, #0xba3080         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA3078: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA307C: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_3 = null;
        label_2:
        // 0x00BA3080: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3084: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3088: CBNZ x19, #0xba3090        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA308C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA3090: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3094: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3098: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00BA309C: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA30A0: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA30A4: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA30A8: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA30AC: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA30B0: CMP w0, #1                 | STATE = COMPARE(this.m_Stream, 0x1)     
        // 0x00BA30B4: B.NE #0xba310c             | if (this.m_Stream != 0x1) goto label_4; 
        if(this.m_Stream != 1)
        {
            goto label_4;
        }
        // 0x00BA30B8: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_4 = null;
        // 0x00BA30BC: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA30C0: TBZ w8, #0, #0xba30d4      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00BA30C4: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA30C8: CBNZ w8, #0xba30d4         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BA30CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA30D0: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_4 = null;
        label_6:
        // 0x00BA30D4: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA30D8: LDR x19, [x8]              | X19 = ByteReadArray.buffer;             
        // 0x00BA30DC: CBNZ x19, #0xba30e4        | if (ByteReadArray.buffer != null) goto label_7;
        if(ByteReadArray.buffer != null)
        {
            goto label_7;
        }
        // 0x00BA30E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_7:
        // 0x00BA30E4: LDR w8, [x19, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA30E8: CBNZ w8, #0xba30f8         | if (ByteReadArray.buffer.Length != 0) goto label_8;
        if(ByteReadArray.buffer.Length != 0)
        {
            goto label_8;
        }
        // 0x00BA30EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ByteReadArray), ????);
        // 0x00BA30F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA30F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ByteReadArray), ????);
        label_8:
        // 0x00BA30F8: LDRB w0, [x19, #0x20]      | W0 = ByteReadArray.buffer + 32;          //  not_find_field!2:32
        // 0x00BA30FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3100: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3104: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3108: RET                        |  return (System.Byte)ByteReadArray.buffer + 32;
        return (byte)ByteReadArray.buffer + 32;
        //  |  // // {name=val_0, type=System.Byte, size=1, nGRN=0 }
        label_4:
        // 0x00BA310C: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
        // 0x00BA3110: LDR x8, [x8, #0x310]       | X8 = 1152921504620957696;               
        // 0x00BA3114: LDR x0, [x8]               | X0 = typeof(System.IO.EndOfStreamException);
        System.IO.EndOfStreamException val_1 = null;
        // 0x00BA3118: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.EndOfStreamException), ????);
        // 0x00BA311C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3120: MOV x19, x0                | X19 = 1152921504620957696 (0x1000000000D75000);//ML01
        // 0x00BA3124: BL #0x1e6697c              | .ctor();                                
        val_1 = new System.IO.EndOfStreamException();
        // 0x00BA3128: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00BA312C: LDR x8, [x8, #0x718]       | X8 = 1152921514567093136;               
        // 0x00BA3130: MOV x0, x19                | X0 = 1152921504620957696 (0x1000000000D75000);//ML01
        // 0x00BA3134: LDR x1, [x8]               | X1 = public System.Byte ByteReadArray::ReadByte();
        // 0x00BA3138: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.EndOfStreamException), ????);
        // 0x00BA313C: BL #0xb8bb04               | X0 = System.Collections.Generic.IEnumerator<object>.get_Current();
        object val_2 = System.Collections.Generic.IEnumerator<object>.get_Current();
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3248 (12202568), len: 84  VirtAddr: 0x00BA3248 RVA: 0x00BA3248 token: 100690734 methodIndex: 25573 delegateWrapperIndex: 0 methodInvoker: 0
    public void ReadBytes(byte[] bytes, int offset, int length)
    {
        //
        // Disasemble & Code
        // 0x00BA3248: STP x22, x21, [sp, #-0x30]! | stack[1152921514567271360] = ???;  stack[1152921514567271368] = ???;  //  dest_result_addr=1152921514567271360 |  dest_result_addr=1152921514567271368
        // 0x00BA324C: STP x20, x19, [sp, #0x10]  | stack[1152921514567271376] = ???;  stack[1152921514567271384] = ???;  //  dest_result_addr=1152921514567271376 |  dest_result_addr=1152921514567271384
        // 0x00BA3250: STP x29, x30, [sp, #0x20]  | stack[1152921514567271392] = ???;  stack[1152921514567271400] = ???;  //  dest_result_addr=1152921514567271392 |  dest_result_addr=1152921514567271400
        // 0x00BA3254: ADD x29, sp, #0x20         | X29 = (1152921514567271360 + 32) = 1152921514567271392 (0x1000000251B003E0);
        // 0x00BA3258: LDR x21, [x0, #0x10]       | X21 = this.m_Stream; //P2               
        // 0x00BA325C: MOV w19, w3                | W19 = length;//m1                       
        // 0x00BA3260: MOV w20, w2                | W20 = offset;//m1                       
        // 0x00BA3264: MOV x22, x1                | X22 = bytes;//m1                        
        // 0x00BA3268: CBNZ x21, #0xba3270        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA326C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA3270: LDR x8, [x21]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3274: MOV w2, w20                | W2 = offset;//m1                        
        // 0x00BA3278: MOV w3, w19                | W3 = length;//m1                        
        // 0x00BA327C: MOV x0, x21                | X0 = this.m_Stream;//m1                 
        // 0x00BA3280: LDR x5, [x8, #0x220]       | X5 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA3284: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA3288: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA328C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3290: MOV x1, x22                | X1 = bytes;//m1                         
        // 0x00BA3294: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3298: BR x5                      | goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA329C (12202652), len: 192  VirtAddr: 0x00BA329C RVA: 0x00BA329C token: 100690735 methodIndex: 25574 delegateWrapperIndex: 0 methodInvoker: 0
    public char ReadChar()
    {
        //
        // Disasemble & Code
        //  | 
        System.Byte[] val_4;
        // 0x00BA329C: STP x20, x19, [sp, #-0x20]! | stack[1152921514567498064] = ???;  stack[1152921514567498072] = ???;  //  dest_result_addr=1152921514567498064 |  dest_result_addr=1152921514567498072
        // 0x00BA32A0: STP x29, x30, [sp, #0x10]  | stack[1152921514567498080] = ???;  stack[1152921514567498088] = ???;  //  dest_result_addr=1152921514567498080 |  dest_result_addr=1152921514567498088
        // 0x00BA32A4: ADD x29, sp, #0x10         | X29 = (1152921514567498064 + 16) = 1152921514567498080 (0x1000000251B37960);
        // 0x00BA32A8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA32AC: LDRB w8, [x20, #0xabd]     | W8 = (bool)static_value_03733ABD;       
        // 0x00BA32B0: MOV x19, x0                | X19 = 1152921514567510096 (0x1000000251B3A850);//ML01
        // 0x00BA32B4: TBNZ w8, #0, #0xba32d0     | if (static_value_03733ABD == true) goto label_0;
        // 0x00BA32B8: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
        // 0x00BA32BC: LDR x8, [x8, #0xf58]       | X8 = 0x2B8FFA0;                         
        // 0x00BA32C0: LDR w0, [x8]               | W0 = 0x16AC;                            
        // 0x00BA32C4: BL #0x2782188              | X0 = sub_2782188( ?? 0x16AC, ????);     
        // 0x00BA32C8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA32CC: STRB w8, [x20, #0xabd]     | static_value_03733ABD = true;            //  dest_result_addr=57883325
        label_0:
        // 0x00BA32D0: MOV x0, x19                | X0 = 1152921514567510096 (0x1000000251B3A850);//ML01
        // 0x00BA32D4: BL #0xba335c               | X0 = this.ReadShort();                  
        short val_1 = this.ReadShort();
        // 0x00BA32D8: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00BA32DC: LDR x8, [x8, #0xe08]       | X8 = 1152921504652320768;               
        // 0x00BA32E0: MOV w19, w0                | W19 = val_1;//m1                        
        // 0x00BA32E4: LDR x8, [x8]               | X8 = typeof(System.BitConverter);       
        // 0x00BA32E8: LDRB w9, [x8, #0x10a]      | W9 = System.BitConverter.__il2cppRuntimeField_10A;
        // 0x00BA32EC: TBZ w9, #0, #0xba3300      | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA32F0: LDR w9, [x8, #0xbc]        | W9 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
        // 0x00BA32F4: CBNZ w9, #0xba3300         | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA32F8: MOV x0, x8                 | X0 = 1152921504652320768 (0x1000000002B5E000);//ML01
        // 0x00BA32FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
        label_2:
        // 0x00BA3300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA3304: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA3308: MOV w1, w19                | W1 = val_1;//m1                         
        // 0x00BA330C: BL #0x18d3548              | X0 = System.BitConverter.GetBytes(value:  0);
        System.Byte[] val_2 = System.BitConverter.GetBytes(value:  0);
        // 0x00BA3310: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00BA3314: LDR x8, [x8, #0x600]       | X8 = 1152921504891564032;               
        // 0x00BA3318: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00BA331C: LDR x8, [x8]               | X8 = typeof(ByteReadArray);             
        // 0x00BA3320: LDRB w9, [x8, #0x10a]      | W9 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3324: TBZ w9, #0, #0xba3338      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BA3328: LDR w9, [x8, #0xbc]        | W9 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA332C: CBNZ w9, #0xba3338         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BA3330: MOV x0, x8                 | X0 = 1152921504891564032 (0x1000000010F87000);//ML01
        val_4 = null;
        // 0x00BA3334: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        label_4:
        // 0x00BA3338: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00BA333C: BL #0xba3140               | X0 = ByteReadArray.inverse(source:  val_4 = null);
        System.Byte[] val_3 = ByteReadArray.inverse(source:  val_4);
        // 0x00BA3340: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3344: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00BA3348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA334C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA3354: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3358: B #0x18d3974               | return System.BitConverter.ToChar(value:  0, startIndex:  val_3);
        return System.BitConverter.ToChar(value:  0, startIndex:  val_3);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3460 (12203104), len: 192  VirtAddr: 0x00BA3460 RVA: 0x00BA3460 token: 100690736 methodIndex: 25575 delegateWrapperIndex: 0 methodInvoker: 0
    public double ReadDouble()
    {
        //
        // Disasemble & Code
        //  | 
        System.Byte[] val_4;
        // 0x00BA3460: STP x20, x19, [sp, #-0x20]! | stack[1152921514567757520] = ???;  stack[1152921514567757528] = ???;  //  dest_result_addr=1152921514567757520 |  dest_result_addr=1152921514567757528
        // 0x00BA3464: STP x29, x30, [sp, #0x10]  | stack[1152921514567757536] = ???;  stack[1152921514567757544] = ???;  //  dest_result_addr=1152921514567757536 |  dest_result_addr=1152921514567757544
        // 0x00BA3468: ADD x29, sp, #0x10         | X29 = (1152921514567757520 + 16) = 1152921514567757536 (0x1000000251B76EE0);
        // 0x00BA346C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA3470: LDRB w8, [x20, #0xabe]     | W8 = (bool)static_value_03733ABE;       
        // 0x00BA3474: MOV x19, x0                | X19 = 1152921514567769552 (0x1000000251B79DD0);//ML01
        // 0x00BA3478: TBNZ w8, #0, #0xba3494     | if (static_value_03733ABE == true) goto label_0;
        // 0x00BA347C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
        // 0x00BA3480: LDR x8, [x8, #0xf88]       | X8 = 0x2B8FFA4;                         
        // 0x00BA3484: LDR w0, [x8]               | W0 = 0x16AD;                            
        // 0x00BA3488: BL #0x2782188              | X0 = sub_2782188( ?? 0x16AD, ????);     
        // 0x00BA348C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3490: STRB w8, [x20, #0xabe]     | static_value_03733ABE = true;            //  dest_result_addr=57883326
        label_0:
        // 0x00BA3494: MOV x0, x19                | X0 = 1152921514567769552 (0x1000000251B79DD0);//ML01
        // 0x00BA3498: BL #0xba3520               | X0 = this.ReadLong();                   
        long val_1 = this.ReadLong();
        // 0x00BA349C: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
        // 0x00BA34A0: LDR x8, [x8, #0xe08]       | X8 = 1152921504652320768;               
        // 0x00BA34A4: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00BA34A8: LDR x8, [x8]               | X8 = typeof(System.BitConverter);       
        // 0x00BA34AC: LDRB w9, [x8, #0x10a]      | W9 = System.BitConverter.__il2cppRuntimeField_10A;
        // 0x00BA34B0: TBZ w9, #0, #0xba34c4      | if (System.BitConverter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA34B4: LDR w9, [x8, #0xbc]        | W9 = System.BitConverter.__il2cppRuntimeField_cctor_finished;
        // 0x00BA34B8: CBNZ w9, #0xba34c4         | if (System.BitConverter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA34BC: MOV x0, x8                 | X0 = 1152921504652320768 (0x1000000002B5E000);//ML01
        // 0x00BA34C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.BitConverter), ????);
        label_2:
        // 0x00BA34C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA34C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA34CC: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00BA34D0: BL #0x18d312c              | X0 = System.BitConverter.GetBytes(value:  0);
        System.Byte[] val_2 = System.BitConverter.GetBytes(value:  0);
        // 0x00BA34D4: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
        // 0x00BA34D8: LDR x8, [x8, #0x600]       | X8 = 1152921504891564032;               
        // 0x00BA34DC: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00BA34E0: LDR x8, [x8]               | X8 = typeof(ByteReadArray);             
        // 0x00BA34E4: LDRB w9, [x8, #0x10a]      | W9 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA34E8: TBZ w9, #0, #0xba34fc      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00BA34EC: LDR w9, [x8, #0xbc]        | W9 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA34F0: CBNZ w9, #0xba34fc         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00BA34F4: MOV x0, x8                 | X0 = 1152921504891564032 (0x1000000010F87000);//ML01
        val_4 = null;
        // 0x00BA34F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        label_4:
        // 0x00BA34FC: MOV x1, x19                | X1 = val_2;//m1                         
        // 0x00BA3500: BL #0xba3140               | X0 = ByteReadArray.inverse(source:  val_4 = null);
        System.Byte[] val_3 = ByteReadArray.inverse(source:  val_4);
        // 0x00BA3504: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3508: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00BA350C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA3510: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3514: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA3518: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA351C: B #0x18d31a0               | return System.BitConverter.ToDouble(value:  0, startIndex:  val_3);
        return System.BitConverter.ToDouble(value:  0, startIndex:  val_3);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3778 (12203896), len: 316  VirtAddr: 0x00BA3778 RVA: 0x00BA3778 token: 100690737 methodIndex: 25576 delegateWrapperIndex: 0 methodInvoker: 0
    public void ReadFloatBytes(byte[] value)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_2;
        // 0x00BA3778: STP x24, x23, [sp, #-0x40]! | stack[1152921514567984176] = ???;  stack[1152921514567984184] = ???;  //  dest_result_addr=1152921514567984176 |  dest_result_addr=1152921514567984184
        // 0x00BA377C: STP x22, x21, [sp, #0x10]  | stack[1152921514567984192] = ???;  stack[1152921514567984200] = ???;  //  dest_result_addr=1152921514567984192 |  dest_result_addr=1152921514567984200
        // 0x00BA3780: STP x20, x19, [sp, #0x20]  | stack[1152921514567984208] = ???;  stack[1152921514567984216] = ???;  //  dest_result_addr=1152921514567984208 |  dest_result_addr=1152921514567984216
        // 0x00BA3784: STP x29, x30, [sp, #0x30]  | stack[1152921514567984224] = ???;  stack[1152921514567984232] = ???;  //  dest_result_addr=1152921514567984224 |  dest_result_addr=1152921514567984232
        // 0x00BA3788: ADD x29, sp, #0x30         | X29 = (1152921514567984176 + 48) = 1152921514567984224 (0x1000000251BAE460);
        // 0x00BA378C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA3790: LDRB w8, [x21, #0xabf]     | W8 = (bool)static_value_03733ABF;       
        // 0x00BA3794: MOV x19, x1                | X19 = value;//m1                        
        // 0x00BA3798: MOV x20, x0                | X20 = 1152921514567996240 (0x1000000251BB1350);//ML01
        // 0x00BA379C: TBNZ w8, #0, #0xba37b8     | if (static_value_03733ABF == true) goto label_0;
        // 0x00BA37A0: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
        // 0x00BA37A4: LDR x8, [x8, #0x658]       | X8 = 0x2B8FFAC;                         
        // 0x00BA37A8: LDR w0, [x8]               | W0 = 0x16AF;                            
        // 0x00BA37AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x16AF, ????);     
        // 0x00BA37B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA37B4: STRB w8, [x21, #0xabf]     | static_value_03733ABF = true;            //  dest_result_addr=57883327
        label_0:
        // 0x00BA37B8: ADRP x22, #0x3669000       | X22 = 57053184 (0x3669000);             
        // 0x00BA37BC: LDR x22, [x22, #0x600]     | X22 = 1152921504891564032;              
        // 0x00BA37C0: LDR x20, [x20, #0x10]      | X20 = this.m_Stream; //P2               
        // 0x00BA37C4: LDR x0, [x22]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        // 0x00BA37C8: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA37CC: TBZ w8, #0, #0xba37e0      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA37D0: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA37D4: CBNZ w8, #0xba37e0         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA37D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA37DC: LDR x0, [x22]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        label_2:
        // 0x00BA37E0: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA37E4: LDR x21, [x8]              | X21 = ByteReadArray.buffer;             
        // 0x00BA37E8: CBNZ x20, #0xba37f0        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA37EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA37F0: LDR x8, [x20]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA37F4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA37F8: ORR w3, wzr, #4            | W3 = 4(0x4);                            
        // 0x00BA37FC: MOV x0, x20                | X0 = this.m_Stream;//m1                 
        // 0x00BA3800: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA3804: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA3808: MOV x1, x21                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA380C: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA3810: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        var val_3 = 0;
        // 0x00BA3814: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        var val_2 = 0;
        // 0x00BA3818: ADD x23, x19, #0x23        | X23 = value[0x23]; //PARR1              
        label_10:
        // 0x00BA381C: LDR x0, [x22]              | X0 = typeof(ByteReadArray);             
        val_2 = null;
        // 0x00BA3820: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3824: TBZ w8, #0, #0xba3838      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00BA3828: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA382C: CBNZ w8, #0xba3838         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00BA3830: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3834: LDR x0, [x22]              | X0 = typeof(ByteReadArray);             
        val_2 = null;
        label_5:
        // 0x00BA3838: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA383C: LDR x24, [x8]              | X24 = ByteReadArray.buffer;             
        // 0x00BA3840: CBNZ x24, #0xba3848        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA3844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_6:
        // 0x00BA3848: LDR w8, [x24, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA384C: CMP x21, x8                | STATE = COMPARE(0x0, ByteReadArray.buffer.Length)
        // 0x00BA3850: B.LO #0xba3860             | if (0 < ByteReadArray.buffer.Length) goto label_7;
        if(val_2 < ByteReadArray.buffer.Length)
        {
            goto label_7;
        }
        // 0x00BA3854: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA385C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ByteReadArray), ????);
        label_7:
        // 0x00BA3860: ADD x8, x24, x21           |  //  not_find_field:ByteReadArray.buffer.0
        // 0x00BA3864: LDRB w24, [x8, #0x20]      | W24 = ByteReadArray.buffer.Length + 32; 
        // 0x00BA3868: CBNZ x19, #0xba3870        | if (value != null) goto label_8;        
        if(value != null)
        {
            goto label_8;
        }
        // 0x00BA386C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_8:
        // 0x00BA3870: LDR w8, [x19, #0x18]       | W8 = value.Length; //P2                 
        // 0x00BA3874: ADD x9, x20, #3            | X9 = (0 + 3);                           
        var val_1 = val_3 + 3;
        // 0x00BA3878: CMP x9, x8                 | STATE = COMPARE((0 + 3), value.Length)  
        // 0x00BA387C: B.LO #0xba388c             | if (val_1 < value.Length) goto label_9; 
        if(val_1 < value.Length)
        {
            goto label_9;
        }
        // 0x00BA3880: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3888: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ByteReadArray), ????);
        label_9:
        // 0x00BA388C: STRB w24, [x23, x20]       | mem2[0] = ByteReadArray.buffer.Length + 32;  //  dest_result_addr=0
        mem2[0] = ByteReadArray.buffer.Length + 32;
        // 0x00BA3890: ADD x21, x21, #1           | X21 = (0 + 1);                          
        val_2 = val_2 + 1;
        // 0x00BA3894: SUB x20, x20, #1           | X20 = (0 - 1);                          
        val_3 = val_3 - 1;
        // 0x00BA3898: CMP x21, #4                | STATE = COMPARE((0 + 1), 0x4)           
        // 0x00BA389C: B.NE #0xba381c             | if (0 != 0x4) goto label_10;            
        if(val_2 != 4)
        {
            goto label_10;
        }
        // 0x00BA38A0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA38A4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA38A8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA38AC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x00BA38B0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA38B4 (12204212), len: 280  VirtAddr: 0x00BA38B4 RVA: 0x00BA38B4 token: 100690738 methodIndex: 25577 delegateWrapperIndex: 0 methodInvoker: 0
    public float ReadFloat()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_2;
        // 0x00BA38B4: STP x22, x21, [sp, #-0x30]! | stack[1152921514568141248] = ???;  stack[1152921514568141256] = ???;  //  dest_result_addr=1152921514568141248 |  dest_result_addr=1152921514568141256
        // 0x00BA38B8: STP x20, x19, [sp, #0x10]  | stack[1152921514568141264] = ???;  stack[1152921514568141272] = ???;  //  dest_result_addr=1152921514568141264 |  dest_result_addr=1152921514568141272
        // 0x00BA38BC: STP x29, x30, [sp, #0x20]  | stack[1152921514568141280] = ???;  stack[1152921514568141288] = ???;  //  dest_result_addr=1152921514568141280 |  dest_result_addr=1152921514568141288
        // 0x00BA38C0: ADD x29, sp, #0x20         | X29 = (1152921514568141248 + 32) = 1152921514568141280 (0x1000000251BD49E0);
        // 0x00BA38C4: SUB sp, sp, #0x10          | SP = (1152921514568141248 - 16) = 1152921514568141232 (0x1000000251BD49B0);
        // 0x00BA38C8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA38CC: LDRB w8, [x20, #0xac0]     | W8 = (bool)static_value_03733AC0;       
        // 0x00BA38D0: MOV x19, x0                | X19 = 1152921514568153296 (0x1000000251BD78D0);//ML01
        // 0x00BA38D4: TBNZ w8, #0, #0xba38f0     | if (static_value_03733AC0 == true) goto label_0;
        // 0x00BA38D8: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
        // 0x00BA38DC: LDR x8, [x8, #0x9d8]       | X8 = 0x2B8FFA8;                         
        // 0x00BA38E0: LDR w0, [x8]               | W0 = 0x16AE;                            
        // 0x00BA38E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x16AE, ????);     
        // 0x00BA38E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA38EC: STRB w8, [x20, #0xac0]     | static_value_03733AC0 = true;            //  dest_result_addr=57883328
        label_0:
        // 0x00BA38F0: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA38F4: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA38F8: STR wzr, [sp, #0xc]        | stack[1152921514568141244] = 0x0;        //  dest_result_addr=1152921514568141244
        // 0x00BA38FC: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA3900: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        // 0x00BA3904: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3908: TBZ w8, #0, #0xba391c      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA390C: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3910: CBNZ w8, #0xba391c         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA3914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3918: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        label_2:
        // 0x00BA391C: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3920: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3924: CBNZ x19, #0xba392c        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA3928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA392C: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3930: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3934: ORR w3, wzr, #4            | W3 = 4(0x4);                            
        // 0x00BA3938: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA393C: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA3940: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA3944: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA3948: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA394C: ADD x8, sp, #0xc           | X8 = (1152921514568141232 + 12) = 1152921514568141244 (0x1000000251BD49BC);
        // 0x00BA3950: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        var val_1 = 0;
        // 0x00BA3954: ORR x20, x8, #3            | X20 = (1152921514568141244 | 3) = 1152921514568141247 (0x1000000251BD49BF);
        label_8:
        // 0x00BA3958: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_2 = null;
        // 0x00BA395C: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3960: TBZ w8, #0, #0xba3974      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00BA3964: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3968: CBNZ w8, #0xba3974         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00BA396C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3970: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_2 = null;
        label_5:
        // 0x00BA3974: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3978: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA397C: CBNZ x22, #0xba3984        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA3980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_6:
        // 0x00BA3984: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3988: CMP x19, x8                | STATE = COMPARE(0x0, ByteReadArray.buffer.Length)
        // 0x00BA398C: B.LO #0xba399c             | if (0 < ByteReadArray.buffer.Length) goto label_7;
        if(val_1 < ByteReadArray.buffer.Length)
        {
            goto label_7;
        }
        // 0x00BA3990: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3994: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3998: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ByteReadArray), ????);
        label_7:
        // 0x00BA399C: ADD x8, x22, x19           |  //  not_find_field:ByteReadArray.buffer.0
        // 0x00BA39A0: LDRB w8, [x8, #0x20]       | W8 = ByteReadArray.buffer.Length + 32;  
        // 0x00BA39A4: ADD x19, x19, #1           | X19 = (0 + 1);                          
        val_1 = val_1 + 1;
        // 0x00BA39A8: CMP x19, #4                | STATE = COMPARE((0 + 1), 0x4)           
        // 0x00BA39AC: STRB w8, [x20], #0xffffffffffffffff | stack[1152921514568141247] = ByteReadArray.buffer.Length + 32;  //  dest_result_addr=1152921514568141247
        // 0x00BA39B0: B.NE #0xba3958             | if (0 != 0x4) goto label_8;             
        if(val_1 != 4)
        {
            goto label_8;
        }
        // 0x00BA39B4: LDR s0, [sp, #0xc]         | S0 = 0;                                 
        // 0x00BA39B8: SUB sp, x29, #0x20         | SP = (1152921514568141280 - 32) = 1152921514568141248 (0x1000000251BD49C0);
        // 0x00BA39BC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA39C0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA39C4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA39C8: RET                        |  return (System.Single)0;               
        return 0;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA39CC (12204492), len: 364  VirtAddr: 0x00BA39CC RVA: 0x00BA39CC token: 100690739 methodIndex: 25578 delegateWrapperIndex: 0 methodInvoker: 0
    public int ReadInt()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA39CC: STP x22, x21, [sp, #-0x30]! | stack[1152921514568261440] = ???;  stack[1152921514568261448] = ???;  //  dest_result_addr=1152921514568261440 |  dest_result_addr=1152921514568261448
        // 0x00BA39D0: STP x20, x19, [sp, #0x10]  | stack[1152921514568261456] = ???;  stack[1152921514568261464] = ???;  //  dest_result_addr=1152921514568261456 |  dest_result_addr=1152921514568261464
        // 0x00BA39D4: STP x29, x30, [sp, #0x20]  | stack[1152921514568261472] = ???;  stack[1152921514568261480] = ???;  //  dest_result_addr=1152921514568261472 |  dest_result_addr=1152921514568261480
        // 0x00BA39D8: ADD x29, sp, #0x20         | X29 = (1152921514568261440 + 32) = 1152921514568261472 (0x1000000251BF1F60);
        // 0x00BA39DC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA39E0: LDRB w8, [x20, #0xac1]     | W8 = (bool)static_value_03733AC1;       
        // 0x00BA39E4: MOV x19, x0                | X19 = 1152921514568273488 (0x1000000251BF4E50);//ML01
        // 0x00BA39E8: TBNZ w8, #0, #0xba3a04     | if (static_value_03733AC1 == true) goto label_0;
        // 0x00BA39EC: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
        // 0x00BA39F0: LDR x8, [x8, #0xcf0]       | X8 = 0x2B8FFB0;                         
        // 0x00BA39F4: LDR w0, [x8]               | W0 = 0x16B0;                            
        // 0x00BA39F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B0, ????);     
        // 0x00BA39FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3A00: STRB w8, [x20, #0xac1]     | static_value_03733AC1 = true;            //  dest_result_addr=57883329
        label_0:
        // 0x00BA3A04: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA3A08: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA3A0C: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA3A10: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        // 0x00BA3A14: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3A18: TBZ w8, #0, #0xba3a2c      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA3A1C: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3A20: CBNZ w8, #0xba3a2c         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA3A24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3A28: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        label_2:
        // 0x00BA3A2C: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3A30: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3A34: CBNZ x19, #0xba3a3c        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA3A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA3A3C: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3A40: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3A44: ORR w3, wzr, #4            | W3 = 4(0x4);                            
        // 0x00BA3A48: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA3A4C: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA3A50: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA3A54: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA3A58: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA3A5C: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3A60: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3A64: LDR x19, [x8]              | X19 = ByteReadArray.buffer;             
        // 0x00BA3A68: CBNZ x19, #0xba3a70        | if (ByteReadArray.buffer != null) goto label_4;
        if(ByteReadArray.buffer != null)
        {
            goto label_4;
        }
        // 0x00BA3A6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_4:
        // 0x00BA3A70: LDR w8, [x19, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3A74: CBNZ w8, #0xba3a84         | if (ByteReadArray.buffer.Length != 0) goto label_5;
        if(ByteReadArray.buffer.Length != 0)
        {
            goto label_5;
        }
        // 0x00BA3A78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3A7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3A80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_5:
        // 0x00BA3A84: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3A88: LDRB w19, [x19, #0x20]     | W19 = ByteReadArray.buffer + 32;         //  not_find_field!2:32
        // 0x00BA3A8C: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3A90: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3A94: CBNZ x20, #0xba3a9c        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA3A98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_6:
        // 0x00BA3A9C: LDR w8, [x20, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3AA0: CMP w8, #1                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x1)
        // 0x00BA3AA4: B.HI #0xba3ab4             | if (ByteReadArray.buffer.Length > 1) goto label_7;
        if(ByteReadArray.buffer.Length > 1)
        {
            goto label_7;
        }
        // 0x00BA3AA8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3AAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3AB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_7:
        // 0x00BA3AB4: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3AB8: LDRB w20, [x20, #0x21]     | W20 = ByteReadArray.buffer + 33;         //  not_find_field!2:33
        // 0x00BA3ABC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3AC0: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA3AC4: CBNZ x22, #0xba3acc        | if (ByteReadArray.buffer != null) goto label_8;
        if(ByteReadArray.buffer != null)
        {
            goto label_8;
        }
        // 0x00BA3AC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_8:
        // 0x00BA3ACC: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3AD0: CMP w8, #2                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x2)
        // 0x00BA3AD4: B.HI #0xba3ae4             | if (ByteReadArray.buffer.Length > 2) goto label_9;
        if(ByteReadArray.buffer.Length > 2)
        {
            goto label_9;
        }
        // 0x00BA3AD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3ADC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3AE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_9:
        // 0x00BA3AE4: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3AE8: LDRB w21, [x22, #0x22]     | W21 = ByteReadArray.buffer + 34;         //  not_find_field!2:34
        // 0x00BA3AEC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3AF0: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA3AF4: CBNZ x22, #0xba3afc        | if (ByteReadArray.buffer != null) goto label_10;
        if(ByteReadArray.buffer != null)
        {
            goto label_10;
        }
        // 0x00BA3AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_10:
        // 0x00BA3AFC: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3B00: CMP w8, #3                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x3)
        // 0x00BA3B04: B.HI #0xba3b14             | if (ByteReadArray.buffer.Length > 3) goto label_11;
        if(ByteReadArray.buffer.Length > 3)
        {
            goto label_11;
        }
        // 0x00BA3B08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3B0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3B10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_11:
        // 0x00BA3B14: LDRB w8, [x22, #0x23]      | W8 = ByteReadArray.buffer + 35;          //  not_find_field!2:35
        // 0x00BA3B18: BFI w19, w20, #8, #8       | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 33
        // 0x00BA3B1C: BFI w19, w21, #0x10, #8    | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 34
        // 0x00BA3B20: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3B24: BFI w19, w8, #0x18, #8     | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 35
        // 0x00BA3B28: MOV w0, w19                | W0 = ByteReadArray.buffer + 32;//m1     
        // 0x00BA3B2C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3B30: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3B34: RET                        |  return (System.Int32)ByteReadArray.buffer + 32;
        return (int)ByteReadArray.buffer + 32;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3B38 (12204856), len: 364  VirtAddr: 0x00BA3B38 RVA: 0x00BA3B38 token: 100690740 methodIndex: 25579 delegateWrapperIndex: 0 methodInvoker: 0
    public uint ReadUInt32()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA3B38: STP x22, x21, [sp, #-0x30]! | stack[1152921514568381632] = ???;  stack[1152921514568381640] = ???;  //  dest_result_addr=1152921514568381632 |  dest_result_addr=1152921514568381640
        // 0x00BA3B3C: STP x20, x19, [sp, #0x10]  | stack[1152921514568381648] = ???;  stack[1152921514568381656] = ???;  //  dest_result_addr=1152921514568381648 |  dest_result_addr=1152921514568381656
        // 0x00BA3B40: STP x29, x30, [sp, #0x20]  | stack[1152921514568381664] = ???;  stack[1152921514568381672] = ???;  //  dest_result_addr=1152921514568381664 |  dest_result_addr=1152921514568381672
        // 0x00BA3B44: ADD x29, sp, #0x20         | X29 = (1152921514568381632 + 32) = 1152921514568381664 (0x1000000251C0F4E0);
        // 0x00BA3B48: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA3B4C: LDRB w8, [x20, #0xac2]     | W8 = (bool)static_value_03733AC2;       
        // 0x00BA3B50: MOV x19, x0                | X19 = 1152921514568393680 (0x1000000251C123D0);//ML01
        // 0x00BA3B54: TBNZ w8, #0, #0xba3b70     | if (static_value_03733AC2 == true) goto label_0;
        // 0x00BA3B58: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
        // 0x00BA3B5C: LDR x8, [x8, #0x310]       | X8 = 0x2B8FFBC;                         
        // 0x00BA3B60: LDR w0, [x8]               | W0 = 0x16B3;                            
        // 0x00BA3B64: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B3, ????);     
        // 0x00BA3B68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3B6C: STRB w8, [x20, #0xac2]     | static_value_03733AC2 = true;            //  dest_result_addr=57883330
        label_0:
        // 0x00BA3B70: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA3B74: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA3B78: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA3B7C: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        // 0x00BA3B80: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3B84: TBZ w8, #0, #0xba3b98      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA3B88: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3B8C: CBNZ w8, #0xba3b98         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA3B90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3B94: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        label_2:
        // 0x00BA3B98: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3B9C: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3BA0: CBNZ x19, #0xba3ba8        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA3BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA3BA8: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3BAC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3BB0: ORR w3, wzr, #4            | W3 = 4(0x4);                            
        // 0x00BA3BB4: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA3BB8: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA3BBC: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA3BC0: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA3BC4: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA3BC8: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3BCC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3BD0: LDR x19, [x8]              | X19 = ByteReadArray.buffer;             
        // 0x00BA3BD4: CBNZ x19, #0xba3bdc        | if (ByteReadArray.buffer != null) goto label_4;
        if(ByteReadArray.buffer != null)
        {
            goto label_4;
        }
        // 0x00BA3BD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_4:
        // 0x00BA3BDC: LDR w8, [x19, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3BE0: CBNZ w8, #0xba3bf0         | if (ByteReadArray.buffer.Length != 0) goto label_5;
        if(ByteReadArray.buffer.Length != 0)
        {
            goto label_5;
        }
        // 0x00BA3BE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3BE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3BEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_5:
        // 0x00BA3BF0: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3BF4: LDRB w19, [x19, #0x20]     | W19 = ByteReadArray.buffer + 32;         //  not_find_field!2:32
        // 0x00BA3BF8: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3BFC: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3C00: CBNZ x20, #0xba3c08        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA3C04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_6:
        // 0x00BA3C08: LDR w8, [x20, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3C0C: CMP w8, #1                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x1)
        // 0x00BA3C10: B.HI #0xba3c20             | if (ByteReadArray.buffer.Length > 1) goto label_7;
        if(ByteReadArray.buffer.Length > 1)
        {
            goto label_7;
        }
        // 0x00BA3C14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3C1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_7:
        // 0x00BA3C20: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3C24: LDRB w20, [x20, #0x21]     | W20 = ByteReadArray.buffer + 33;         //  not_find_field!2:33
        // 0x00BA3C28: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3C2C: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA3C30: CBNZ x22, #0xba3c38        | if (ByteReadArray.buffer != null) goto label_8;
        if(ByteReadArray.buffer != null)
        {
            goto label_8;
        }
        // 0x00BA3C34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_8:
        // 0x00BA3C38: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3C3C: CMP w8, #2                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x2)
        // 0x00BA3C40: B.HI #0xba3c50             | if (ByteReadArray.buffer.Length > 2) goto label_9;
        if(ByteReadArray.buffer.Length > 2)
        {
            goto label_9;
        }
        // 0x00BA3C44: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3C48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3C4C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_9:
        // 0x00BA3C50: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3C54: LDRB w21, [x22, #0x22]     | W21 = ByteReadArray.buffer + 34;         //  not_find_field!2:34
        // 0x00BA3C58: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3C5C: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA3C60: CBNZ x22, #0xba3c68        | if (ByteReadArray.buffer != null) goto label_10;
        if(ByteReadArray.buffer != null)
        {
            goto label_10;
        }
        // 0x00BA3C64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_10:
        // 0x00BA3C68: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3C6C: CMP w8, #3                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x3)
        // 0x00BA3C70: B.HI #0xba3c80             | if (ByteReadArray.buffer.Length > 3) goto label_11;
        if(ByteReadArray.buffer.Length > 3)
        {
            goto label_11;
        }
        // 0x00BA3C74: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3C78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3C7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_11:
        // 0x00BA3C80: LDRB w8, [x22, #0x23]      | W8 = ByteReadArray.buffer + 35;          //  not_find_field!2:35
        // 0x00BA3C84: BFI w19, w20, #8, #8       | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 33
        // 0x00BA3C88: BFI w19, w21, #0x10, #8    | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 34
        // 0x00BA3C8C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3C90: BFI w19, w8, #0x18, #8     | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 35
        // 0x00BA3C94: MOV w0, w19                | W0 = ByteReadArray.buffer + 32;//m1     
        // 0x00BA3C98: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3C9C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3CA0: RET                        |  return (System.UInt32)ByteReadArray.buffer + 32;
        return (uint)ByteReadArray.buffer + 32;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3520 (12203296), len: 600  VirtAddr: 0x00BA3520 RVA: 0x00BA3520 token: 100690741 methodIndex: 25580 delegateWrapperIndex: 0 methodInvoker: 0
    public long ReadLong()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00BA3520: STP x26, x25, [sp, #-0x50]! | stack[1152921514568501792] = ???;  stack[1152921514568501800] = ???;  //  dest_result_addr=1152921514568501792 |  dest_result_addr=1152921514568501800
        // 0x00BA3524: STP x24, x23, [sp, #0x10]  | stack[1152921514568501808] = ???;  stack[1152921514568501816] = ???;  //  dest_result_addr=1152921514568501808 |  dest_result_addr=1152921514568501816
        // 0x00BA3528: STP x22, x21, [sp, #0x20]  | stack[1152921514568501824] = ???;  stack[1152921514568501832] = ???;  //  dest_result_addr=1152921514568501824 |  dest_result_addr=1152921514568501832
        // 0x00BA352C: STP x20, x19, [sp, #0x30]  | stack[1152921514568501840] = ???;  stack[1152921514568501848] = ???;  //  dest_result_addr=1152921514568501840 |  dest_result_addr=1152921514568501848
        // 0x00BA3530: STP x29, x30, [sp, #0x40]  | stack[1152921514568501856] = ???;  stack[1152921514568501864] = ???;  //  dest_result_addr=1152921514568501856 |  dest_result_addr=1152921514568501864
        // 0x00BA3534: ADD x29, sp, #0x40         | X29 = (1152921514568501792 + 64) = 1152921514568501856 (0x1000000251C2CA60);
        // 0x00BA3538: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA353C: LDRB w8, [x20, #0xac3]     | W8 = (bool)static_value_03733AC3;       
        // 0x00BA3540: MOV x19, x0                | X19 = 1152921514568513872 (0x1000000251C2F950);//ML01
        // 0x00BA3544: TBNZ w8, #0, #0xba3560     | if (static_value_03733AC3 == true) goto label_0;
        // 0x00BA3548: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
        // 0x00BA354C: LDR x8, [x8, #0xd90]       | X8 = 0x2B8FFB4;                         
        // 0x00BA3550: LDR w0, [x8]               | W0 = 0x16B1;                            
        // 0x00BA3554: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B1, ????);     
        // 0x00BA3558: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA355C: STRB w8, [x20, #0xac3]     | static_value_03733AC3 = true;            //  dest_result_addr=57883331
        label_0:
        // 0x00BA3560: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA3564: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA3568: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA356C: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_3 = null;
        // 0x00BA3570: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3574: TBZ w8, #0, #0xba3588      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA3578: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA357C: CBNZ w8, #0xba3588         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA3580: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3584: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_3 = null;
        label_2:
        // 0x00BA3588: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA358C: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3590: CBNZ x19, #0xba3598        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA3594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA3598: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA359C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA35A0: ORR w3, wzr, #8            | W3 = 8(0x8);                            
        // 0x00BA35A4: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA35A8: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA35AC: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA35B0: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA35B4: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA35B8: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA35BC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA35C0: LDR x19, [x8]              | X19 = ByteReadArray.buffer;             
        // 0x00BA35C4: CBNZ x19, #0xba35cc        | if (ByteReadArray.buffer != null) goto label_4;
        if(ByteReadArray.buffer != null)
        {
            goto label_4;
        }
        // 0x00BA35C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_4:
        // 0x00BA35CC: LDR w8, [x19, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA35D0: CBNZ w8, #0xba35e0         | if (ByteReadArray.buffer.Length != 0) goto label_5;
        if(ByteReadArray.buffer.Length != 0)
        {
            goto label_5;
        }
        // 0x00BA35D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA35D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA35DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_5:
        // 0x00BA35E0: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA35E4: LDRB w19, [x19, #0x20]     | W19 = ByteReadArray.buffer + 32;         //  not_find_field!2:32
        // 0x00BA35E8: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA35EC: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA35F0: CBNZ x20, #0xba35f8        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA35F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_6:
        // 0x00BA35F8: LDR w8, [x20, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA35FC: CMP w8, #1                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x1)
        // 0x00BA3600: B.HI #0xba3610             | if (ByteReadArray.buffer.Length > 1) goto label_7;
        if(ByteReadArray.buffer.Length > 1)
        {
            goto label_7;
        }
        // 0x00BA3604: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3608: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA360C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_7:
        // 0x00BA3610: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3614: LDRB w20, [x20, #0x21]     | W20 = ByteReadArray.buffer + 33;         //  not_find_field!2:33
        // 0x00BA3618: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA361C: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA3620: CBNZ x22, #0xba3628        | if (ByteReadArray.buffer != null) goto label_8;
        if(ByteReadArray.buffer != null)
        {
            goto label_8;
        }
        // 0x00BA3624: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_8:
        // 0x00BA3628: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA362C: CMP w8, #2                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x2)
        // 0x00BA3630: B.HI #0xba3640             | if (ByteReadArray.buffer.Length > 2) goto label_9;
        if(ByteReadArray.buffer.Length > 2)
        {
            goto label_9;
        }
        // 0x00BA3634: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA363C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_9:
        // 0x00BA3640: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3644: LDRB w22, [x22, #0x22]     | W22 = ByteReadArray.buffer + 34;         //  not_find_field!2:34
        // 0x00BA3648: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA364C: LDR x23, [x8]              | X23 = ByteReadArray.buffer;             
        // 0x00BA3650: CBNZ x23, #0xba3658        | if (ByteReadArray.buffer != null) goto label_10;
        if(ByteReadArray.buffer != null)
        {
            goto label_10;
        }
        // 0x00BA3654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_10:
        // 0x00BA3658: LDR w8, [x23, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA365C: CMP w8, #3                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x3)
        // 0x00BA3660: B.HI #0xba3670             | if (ByteReadArray.buffer.Length > 3) goto label_11;
        if(ByteReadArray.buffer.Length > 3)
        {
            goto label_11;
        }
        // 0x00BA3664: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA366C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_11:
        // 0x00BA3670: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3674: LDRB w23, [x23, #0x23]     | W23 = ByteReadArray.buffer + 35;         //  not_find_field!2:35
        // 0x00BA3678: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA367C: LDR x24, [x8]              | X24 = ByteReadArray.buffer;             
        // 0x00BA3680: CBNZ x24, #0xba3688        | if (ByteReadArray.buffer != null) goto label_12;
        if(ByteReadArray.buffer != null)
        {
            goto label_12;
        }
        // 0x00BA3684: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_12:
        // 0x00BA3688: LDR w8, [x24, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA368C: CMP w8, #4                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x4)
        // 0x00BA3690: B.HI #0xba36a0             | if (ByteReadArray.buffer.Length > 4) goto label_13;
        if(ByteReadArray.buffer.Length > 4)
        {
            goto label_13;
        }
        // 0x00BA3694: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA369C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_13:
        // 0x00BA36A0: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA36A4: LDRB w24, [x24, #0x24]     | W24 = ByteReadArray.buffer + 36;         //  not_find_field!2:36
        // 0x00BA36A8: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA36AC: LDR x25, [x8]              | X25 = ByteReadArray.buffer;             
        // 0x00BA36B0: CBNZ x25, #0xba36b8        | if (ByteReadArray.buffer != null) goto label_14;
        if(ByteReadArray.buffer != null)
        {
            goto label_14;
        }
        // 0x00BA36B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_14:
        // 0x00BA36B8: LDR w8, [x25, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA36BC: CMP w8, #5                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x5)
        // 0x00BA36C0: B.HI #0xba36d0             | if (ByteReadArray.buffer.Length > 5) goto label_15;
        if(ByteReadArray.buffer.Length > 5)
        {
            goto label_15;
        }
        // 0x00BA36C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA36C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA36CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_15:
        // 0x00BA36D0: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA36D4: LDRB w25, [x25, #0x25]     | W25 = ByteReadArray.buffer + 37;         //  not_find_field!2:37
        // 0x00BA36D8: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA36DC: LDR x26, [x8]              | X26 = ByteReadArray.buffer;             
        // 0x00BA36E0: CBNZ x26, #0xba36e8        | if (ByteReadArray.buffer != null) goto label_16;
        if(ByteReadArray.buffer != null)
        {
            goto label_16;
        }
        // 0x00BA36E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_16:
        // 0x00BA36E8: LDR w8, [x26, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA36EC: BFI x19, x20, #8, #8       | X19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 33
        // 0x00BA36F0: CMP w8, #6                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x6)
        // 0x00BA36F4: B.HI #0xba3704             | if (ByteReadArray.buffer.Length > 6) goto label_17;
        if(ByteReadArray.buffer.Length > 6)
        {
            goto label_17;
        }
        // 0x00BA36F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA36FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3700: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_17:
        // 0x00BA3704: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3708: LDRB w20, [x26, #0x26]     | W20 = ByteReadArray.buffer + 38;         //  not_find_field!2:38
        // 0x00BA370C: BFI x19, x22, #0x10, #8    | X19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 34
        // 0x00BA3710: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3714: LDR x21, [x8]              | X21 = ByteReadArray.buffer;             
        // 0x00BA3718: CBNZ x21, #0xba3720        | if (ByteReadArray.buffer != null) goto label_18;
        if(ByteReadArray.buffer != null)
        {
            goto label_18;
        }
        // 0x00BA371C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_18:
        // 0x00BA3720: LDR w8, [x21, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3724: BFI x19, x23, #0x18, #8    | X19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 35
        // 0x00BA3728: CMP w8, #7                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x7)
        // 0x00BA372C: B.HI #0xba373c             | if (ByteReadArray.buffer.Length > 7) goto label_19;
        if(ByteReadArray.buffer.Length > 7)
        {
            goto label_19;
        }
        // 0x00BA3730: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3738: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_19:
        // 0x00BA373C: LDRB w9, [x21, #0x27]      | W9 = ByteReadArray.buffer + 39;          //  not_find_field!2:39
        var val_3 = ByteReadArray.buffer + 39;
        // 0x00BA3740: LSL x8, x25, #8            | X8 = (ByteReadArray.buffer + 37 << 8);  
        var val_1 = (ByteReadArray.buffer + 37) << 8;
        // 0x00BA3744: ORR w8, w8, w24            | W8 = ((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36);
        val_1 = val_1 | (ByteReadArray.buffer + 36);
        // 0x00BA3748: LSL x10, x20, #0x10        | X10 = (ByteReadArray.buffer + 38 << 16);
        var val_2 = (ByteReadArray.buffer + 38) << 16;
        // 0x00BA374C: ORR w8, w8, w10            | W8 = (((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36) | (ByteReadArray.buffer + 38 <<
        val_1 = val_1 | val_2;
        // 0x00BA3750: LSL x9, x9, #0x18          | X9 = (ByteReadArray.buffer + 39 << 24); 
        val_3 = val_3 << 24;
        // 0x00BA3754: ORR w8, w8, w9             | W8 = ((((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36) | (ByteReadArray.buffer + 38 <
        val_1 = val_1 | val_3;
        // 0x00BA3758: BFI x19, x8, #0x20, #0x20  | X19 = ByteReadArray.buffer + 32 | ((((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36) | (ByteReadArray.buffer + 38 << 16)) | (ByteReadArray.buffer + 39 << 24))
        // 0x00BA375C: MOV x0, x19                | X0 = ByteReadArray.buffer + 32;//m1     
        // 0x00BA3760: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3764: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3768: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA376C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA3770: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA3774: RET                        |  return (System.Int64)ByteReadArray.buffer + 32;
        return (long)ByteReadArray.buffer + 32;
        //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3CA4 (12205220), len: 600  VirtAddr: 0x00BA3CA4 RVA: 0x00BA3CA4 token: 100690742 methodIndex: 25581 delegateWrapperIndex: 0 methodInvoker: 0
    public ulong ReadUlong()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x00BA3CA4: STP x26, x25, [sp, #-0x50]! | stack[1152921514568621984] = ???;  stack[1152921514568621992] = ???;  //  dest_result_addr=1152921514568621984 |  dest_result_addr=1152921514568621992
        // 0x00BA3CA8: STP x24, x23, [sp, #0x10]  | stack[1152921514568622000] = ???;  stack[1152921514568622008] = ???;  //  dest_result_addr=1152921514568622000 |  dest_result_addr=1152921514568622008
        // 0x00BA3CAC: STP x22, x21, [sp, #0x20]  | stack[1152921514568622016] = ???;  stack[1152921514568622024] = ???;  //  dest_result_addr=1152921514568622016 |  dest_result_addr=1152921514568622024
        // 0x00BA3CB0: STP x20, x19, [sp, #0x30]  | stack[1152921514568622032] = ???;  stack[1152921514568622040] = ???;  //  dest_result_addr=1152921514568622032 |  dest_result_addr=1152921514568622040
        // 0x00BA3CB4: STP x29, x30, [sp, #0x40]  | stack[1152921514568622048] = ???;  stack[1152921514568622056] = ???;  //  dest_result_addr=1152921514568622048 |  dest_result_addr=1152921514568622056
        // 0x00BA3CB8: ADD x29, sp, #0x40         | X29 = (1152921514568621984 + 64) = 1152921514568622048 (0x1000000251C49FE0);
        // 0x00BA3CBC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA3CC0: LDRB w8, [x20, #0xac4]     | W8 = (bool)static_value_03733AC4;       
        // 0x00BA3CC4: MOV x19, x0                | X19 = 1152921514568634064 (0x1000000251C4CED0);//ML01
        // 0x00BA3CC8: TBNZ w8, #0, #0xba3ce4     | if (static_value_03733AC4 == true) goto label_0;
        // 0x00BA3CCC: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00BA3CD0: LDR x8, [x8, #0x158]       | X8 = 0x2B8FFC0;                         
        // 0x00BA3CD4: LDR w0, [x8]               | W0 = 0x16B4;                            
        // 0x00BA3CD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B4, ????);     
        // 0x00BA3CDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3CE0: STRB w8, [x20, #0xac4]     | static_value_03733AC4 = true;            //  dest_result_addr=57883332
        label_0:
        // 0x00BA3CE4: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA3CE8: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA3CEC: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA3CF0: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_3 = null;
        // 0x00BA3CF4: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3CF8: TBZ w8, #0, #0xba3d0c      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA3CFC: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3D00: CBNZ w8, #0xba3d0c         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA3D04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3D08: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_3 = null;
        label_2:
        // 0x00BA3D0C: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3D10: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3D14: CBNZ x19, #0xba3d1c        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA3D18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA3D1C: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3D20: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3D24: ORR w3, wzr, #8            | W3 = 8(0x8);                            
        // 0x00BA3D28: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA3D2C: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA3D30: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA3D34: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA3D38: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA3D3C: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3D40: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3D44: LDR x19, [x8]              | X19 = ByteReadArray.buffer;             
        // 0x00BA3D48: CBNZ x19, #0xba3d50        | if (ByteReadArray.buffer != null) goto label_4;
        if(ByteReadArray.buffer != null)
        {
            goto label_4;
        }
        // 0x00BA3D4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_4:
        // 0x00BA3D50: LDR w8, [x19, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3D54: CBNZ w8, #0xba3d64         | if (ByteReadArray.buffer.Length != 0) goto label_5;
        if(ByteReadArray.buffer.Length != 0)
        {
            goto label_5;
        }
        // 0x00BA3D58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3D5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3D60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_5:
        // 0x00BA3D64: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3D68: LDRB w19, [x19, #0x20]     | W19 = ByteReadArray.buffer + 32;         //  not_find_field!2:32
        // 0x00BA3D6C: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3D70: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3D74: CBNZ x20, #0xba3d7c        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA3D78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_6:
        // 0x00BA3D7C: LDR w8, [x20, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3D80: CMP w8, #1                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x1)
        // 0x00BA3D84: B.HI #0xba3d94             | if (ByteReadArray.buffer.Length > 1) goto label_7;
        if(ByteReadArray.buffer.Length > 1)
        {
            goto label_7;
        }
        // 0x00BA3D88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3D90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_7:
        // 0x00BA3D94: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3D98: LDRB w20, [x20, #0x21]     | W20 = ByteReadArray.buffer + 33;         //  not_find_field!2:33
        // 0x00BA3D9C: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3DA0: LDR x22, [x8]              | X22 = ByteReadArray.buffer;             
        // 0x00BA3DA4: CBNZ x22, #0xba3dac        | if (ByteReadArray.buffer != null) goto label_8;
        if(ByteReadArray.buffer != null)
        {
            goto label_8;
        }
        // 0x00BA3DA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_8:
        // 0x00BA3DAC: LDR w8, [x22, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3DB0: CMP w8, #2                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x2)
        // 0x00BA3DB4: B.HI #0xba3dc4             | if (ByteReadArray.buffer.Length > 2) goto label_9;
        if(ByteReadArray.buffer.Length > 2)
        {
            goto label_9;
        }
        // 0x00BA3DB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3DBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3DC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_9:
        // 0x00BA3DC4: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3DC8: LDRB w22, [x22, #0x22]     | W22 = ByteReadArray.buffer + 34;         //  not_find_field!2:34
        // 0x00BA3DCC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3DD0: LDR x23, [x8]              | X23 = ByteReadArray.buffer;             
        // 0x00BA3DD4: CBNZ x23, #0xba3ddc        | if (ByteReadArray.buffer != null) goto label_10;
        if(ByteReadArray.buffer != null)
        {
            goto label_10;
        }
        // 0x00BA3DD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_10:
        // 0x00BA3DDC: LDR w8, [x23, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3DE0: CMP w8, #3                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x3)
        // 0x00BA3DE4: B.HI #0xba3df4             | if (ByteReadArray.buffer.Length > 3) goto label_11;
        if(ByteReadArray.buffer.Length > 3)
        {
            goto label_11;
        }
        // 0x00BA3DE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3DEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3DF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_11:
        // 0x00BA3DF4: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3DF8: LDRB w23, [x23, #0x23]     | W23 = ByteReadArray.buffer + 35;         //  not_find_field!2:35
        // 0x00BA3DFC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3E00: LDR x24, [x8]              | X24 = ByteReadArray.buffer;             
        // 0x00BA3E04: CBNZ x24, #0xba3e0c        | if (ByteReadArray.buffer != null) goto label_12;
        if(ByteReadArray.buffer != null)
        {
            goto label_12;
        }
        // 0x00BA3E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_12:
        // 0x00BA3E0C: LDR w8, [x24, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3E10: CMP w8, #4                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x4)
        // 0x00BA3E14: B.HI #0xba3e24             | if (ByteReadArray.buffer.Length > 4) goto label_13;
        if(ByteReadArray.buffer.Length > 4)
        {
            goto label_13;
        }
        // 0x00BA3E18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3E1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3E20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_13:
        // 0x00BA3E24: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3E28: LDRB w24, [x24, #0x24]     | W24 = ByteReadArray.buffer + 36;         //  not_find_field!2:36
        // 0x00BA3E2C: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3E30: LDR x25, [x8]              | X25 = ByteReadArray.buffer;             
        // 0x00BA3E34: CBNZ x25, #0xba3e3c        | if (ByteReadArray.buffer != null) goto label_14;
        if(ByteReadArray.buffer != null)
        {
            goto label_14;
        }
        // 0x00BA3E38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_14:
        // 0x00BA3E3C: LDR w8, [x25, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3E40: CMP w8, #5                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x5)
        // 0x00BA3E44: B.HI #0xba3e54             | if (ByteReadArray.buffer.Length > 5) goto label_15;
        if(ByteReadArray.buffer.Length > 5)
        {
            goto label_15;
        }
        // 0x00BA3E48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3E4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3E50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_15:
        // 0x00BA3E54: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3E58: LDRB w25, [x25, #0x25]     | W25 = ByteReadArray.buffer + 37;         //  not_find_field!2:37
        // 0x00BA3E5C: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3E60: LDR x26, [x8]              | X26 = ByteReadArray.buffer;             
        // 0x00BA3E64: CBNZ x26, #0xba3e6c        | if (ByteReadArray.buffer != null) goto label_16;
        if(ByteReadArray.buffer != null)
        {
            goto label_16;
        }
        // 0x00BA3E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_16:
        // 0x00BA3E6C: LDR w8, [x26, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3E70: BFI x19, x20, #8, #8       | X19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 33
        // 0x00BA3E74: CMP w8, #6                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x6)
        // 0x00BA3E78: B.HI #0xba3e88             | if (ByteReadArray.buffer.Length > 6) goto label_17;
        if(ByteReadArray.buffer.Length > 6)
        {
            goto label_17;
        }
        // 0x00BA3E7C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3E80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3E84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_17:
        // 0x00BA3E88: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3E8C: LDRB w20, [x26, #0x26]     | W20 = ByteReadArray.buffer + 38;         //  not_find_field!2:38
        // 0x00BA3E90: BFI x19, x22, #0x10, #8    | X19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 34
        // 0x00BA3E94: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3E98: LDR x21, [x8]              | X21 = ByteReadArray.buffer;             
        // 0x00BA3E9C: CBNZ x21, #0xba3ea4        | if (ByteReadArray.buffer != null) goto label_18;
        if(ByteReadArray.buffer != null)
        {
            goto label_18;
        }
        // 0x00BA3EA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_18:
        // 0x00BA3EA4: LDR w8, [x21, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3EA8: BFI x19, x23, #0x18, #8    | X19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 35
        // 0x00BA3EAC: CMP w8, #7                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x7)
        // 0x00BA3EB0: B.HI #0xba3ec0             | if (ByteReadArray.buffer.Length > 7) goto label_19;
        if(ByteReadArray.buffer.Length > 7)
        {
            goto label_19;
        }
        // 0x00BA3EB4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA3EB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3EBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_19:
        // 0x00BA3EC0: LDRB w9, [x21, #0x27]      | W9 = ByteReadArray.buffer + 39;          //  not_find_field!2:39
        var val_3 = ByteReadArray.buffer + 39;
        // 0x00BA3EC4: LSL x8, x25, #8            | X8 = (ByteReadArray.buffer + 37 << 8);  
        var val_1 = (ByteReadArray.buffer + 37) << 8;
        // 0x00BA3EC8: ORR w8, w8, w24            | W8 = ((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36);
        val_1 = val_1 | (ByteReadArray.buffer + 36);
        // 0x00BA3ECC: LSL x10, x20, #0x10        | X10 = (ByteReadArray.buffer + 38 << 16);
        var val_2 = (ByteReadArray.buffer + 38) << 16;
        // 0x00BA3ED0: ORR w8, w8, w10            | W8 = (((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36) | (ByteReadArray.buffer + 38 <<
        val_1 = val_1 | val_2;
        // 0x00BA3ED4: LSL x9, x9, #0x18          | X9 = (ByteReadArray.buffer + 39 << 24); 
        val_3 = val_3 << 24;
        // 0x00BA3ED8: ORR w8, w8, w9             | W8 = ((((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36) | (ByteReadArray.buffer + 38 <
        val_1 = val_1 | val_3;
        // 0x00BA3EDC: BFI x19, x8, #0x20, #0x20  | X19 = ByteReadArray.buffer + 32 | ((((ByteReadArray.buffer + 37 << 8) | ByteReadArray.buffer + 36) | (ByteReadArray.buffer + 38 << 16)) | (ByteReadArray.buffer + 39 << 24))
        // 0x00BA3EE0: MOV x0, x19                | X0 = ByteReadArray.buffer + 32;//m1     
        // 0x00BA3EE4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3EE8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3EEC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA3EF0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA3EF4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA3EF8: RET                        |  return (System.UInt64)ByteReadArray.buffer + 32;
        return (ulong)ByteReadArray.buffer + 32;
        //  |  // // {name=val_0, type=System.UInt64, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA335C (12202844), len: 260  VirtAddr: 0x00BA335C RVA: 0x00BA335C token: 100690743 methodIndex: 25582 delegateWrapperIndex: 0 methodInvoker: 0
    public short ReadShort()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA335C: STP x22, x21, [sp, #-0x30]! | stack[1152921514568742208] = ???;  stack[1152921514568742216] = ???;  //  dest_result_addr=1152921514568742208 |  dest_result_addr=1152921514568742216
        // 0x00BA3360: STP x20, x19, [sp, #0x10]  | stack[1152921514568742224] = ???;  stack[1152921514568742232] = ???;  //  dest_result_addr=1152921514568742224 |  dest_result_addr=1152921514568742232
        // 0x00BA3364: STP x29, x30, [sp, #0x20]  | stack[1152921514568742240] = ???;  stack[1152921514568742248] = ???;  //  dest_result_addr=1152921514568742240 |  dest_result_addr=1152921514568742248
        // 0x00BA3368: ADD x29, sp, #0x20         | X29 = (1152921514568742208 + 32) = 1152921514568742240 (0x1000000251C67560);
        // 0x00BA336C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA3370: LDRB w8, [x20, #0xac5]     | W8 = (bool)static_value_03733AC5;       
        // 0x00BA3374: MOV x19, x0                | X19 = 1152921514568754256 (0x1000000251C6A450);//ML01
        // 0x00BA3378: TBNZ w8, #0, #0xba3394     | if (static_value_03733AC5 == true) goto label_0;
        // 0x00BA337C: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
        // 0x00BA3380: LDR x8, [x8, #0xb60]       | X8 = 0x2B8FFB8;                         
        // 0x00BA3384: LDR w0, [x8]               | W0 = 0x16B2;                            
        // 0x00BA3388: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B2, ????);     
        // 0x00BA338C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3390: STRB w8, [x20, #0xac5]     | static_value_03733AC5 = true;            //  dest_result_addr=57883333
        label_0:
        // 0x00BA3394: ADRP x21, #0x3669000       | X21 = 57053184 (0x3669000);             
        // 0x00BA3398: LDR x21, [x21, #0x600]     | X21 = 1152921504891564032;              
        // 0x00BA339C: LDR x19, [x19, #0x10]      | X19 = this.m_Stream; //P2               
        // 0x00BA33A0: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        // 0x00BA33A4: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA33A8: TBZ w8, #0, #0xba33bc      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA33AC: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA33B0: CBNZ w8, #0xba33bc         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA33B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA33B8: LDR x0, [x21]              | X0 = typeof(ByteReadArray);             
        val_1 = null;
        label_2:
        // 0x00BA33BC: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA33C0: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA33C4: CBNZ x19, #0xba33cc        | if (this.m_Stream != null) goto label_3;
        if(this.m_Stream != null)
        {
            goto label_3;
        }
        // 0x00BA33C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_3:
        // 0x00BA33CC: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA33D0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA33D4: ORR w3, wzr, #2            | W3 = 2(0x2);                            
        // 0x00BA33D8: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA33DC: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA33E0: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA33E4: MOV x1, x20                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA33E8: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA33EC: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA33F0: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA33F4: LDR x19, [x8]              | X19 = ByteReadArray.buffer;             
        // 0x00BA33F8: CBNZ x19, #0xba3400        | if (ByteReadArray.buffer != null) goto label_4;
        if(ByteReadArray.buffer != null)
        {
            goto label_4;
        }
        // 0x00BA33FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_4:
        // 0x00BA3400: LDR w8, [x19, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3404: CBNZ w8, #0xba3414         | if (ByteReadArray.buffer.Length != 0) goto label_5;
        if(ByteReadArray.buffer.Length != 0)
        {
            goto label_5;
        }
        // 0x00BA3408: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA340C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3410: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_5:
        // 0x00BA3414: LDR x8, [x21]              | X8 = typeof(ByteReadArray);             
        // 0x00BA3418: LDRB w19, [x19, #0x20]     | W19 = ByteReadArray.buffer + 32;         //  not_find_field!2:32
        // 0x00BA341C: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3420: LDR x20, [x8]              | X20 = ByteReadArray.buffer;             
        // 0x00BA3424: CBNZ x20, #0xba342c        | if (ByteReadArray.buffer != null) goto label_6;
        if(ByteReadArray.buffer != null)
        {
            goto label_6;
        }
        // 0x00BA3428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_6:
        // 0x00BA342C: LDR w8, [x20, #0x18]       | W8 = ByteReadArray.buffer.Length;       
        // 0x00BA3430: CMP w8, #1                 | STATE = COMPARE(ByteReadArray.buffer.Length, 0x1)
        // 0x00BA3434: B.HI #0xba3444             | if (ByteReadArray.buffer.Length > 1) goto label_7;
        if(ByteReadArray.buffer.Length > 1)
        {
            goto label_7;
        }
        // 0x00BA3438: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.m_Stream, ????);
        // 0x00BA343C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA3440: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.m_Stream, ????);
        label_7:
        // 0x00BA3444: LDRB w8, [x20, #0x21]      | W8 = ByteReadArray.buffer + 33;          //  not_find_field!2:33
        // 0x00BA3448: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA344C: BFI w19, w8, #8, #8        | W19 = ByteReadArray.buffer + 32 | ByteReadArray.buffer + 33
        // 0x00BA3450: MOV w0, w19                | W0 = ByteReadArray.buffer + 32;//m1     
        // 0x00BA3454: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3458: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA345C: RET                        |  return (System.Int16)ByteReadArray.buffer + 32;
        return (short)ByteReadArray.buffer + 32;
        //  |  // // {name=val_0, type=System.Int16, size=2, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3EFC (12205820), len: 40  VirtAddr: 0x00BA3EFC RVA: 0x00BA3EFC token: 100690744 methodIndex: 25583 delegateWrapperIndex: 0 methodInvoker: 0
    public string ReadUTF()
    {
        //
        // Disasemble & Code
        // 0x00BA3EFC: STP x20, x19, [sp, #-0x20]! | stack[1152921514568858320] = ???;  stack[1152921514568858328] = ???;  //  dest_result_addr=1152921514568858320 |  dest_result_addr=1152921514568858328
        // 0x00BA3F00: STP x29, x30, [sp, #0x10]  | stack[1152921514568858336] = ???;  stack[1152921514568858344] = ???;  //  dest_result_addr=1152921514568858336 |  dest_result_addr=1152921514568858344
        // 0x00BA3F04: ADD x29, sp, #0x10         | X29 = (1152921514568858320 + 16) = 1152921514568858336 (0x1000000251C83AE0);
        // 0x00BA3F08: MOV x19, x0                | X19 = 1152921514568870352 (0x1000000251C869D0);//ML01
        // 0x00BA3F0C: BL #0xba335c               | X0 = this.ReadShort();                  
        short val_1 = this.ReadShort();
        // 0x00BA3F10: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA3F14: SXTH w1, w0                | W1 = (int)(short)((val_1) & 0xFFFF);    
        // 0x00BA3F18: MOV x0, x19                | X0 = 1152921514568870352 (0x1000000251C869D0);//ML01
        // 0x00BA3F1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA3F20: B #0xba3f24                | return this.ReadUTFBytes(length:  (int)val_1 & 65535);
        return this.ReadUTFBytes(length:  (int)val_1 & 65535);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA3F24 (12205860), len: 500  VirtAddr: 0x00BA3F24 RVA: 0x00BA3F24 token: 100690745 methodIndex: 25584 delegateWrapperIndex: 0 methodInvoker: 0
    public string ReadUTFBytes(int length)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        //  | 
        var val_14;
        //  | 
        var val_15;
        //  | 
        var val_16;
        //  | 
        var val_17;
        // 0x00BA3F24: STP x26, x25, [sp, #-0x50]! | stack[1152921514568978464] = ???;  stack[1152921514568978472] = ???;  //  dest_result_addr=1152921514568978464 |  dest_result_addr=1152921514568978472
        // 0x00BA3F28: STP x24, x23, [sp, #0x10]  | stack[1152921514568978480] = ???;  stack[1152921514568978488] = ???;  //  dest_result_addr=1152921514568978480 |  dest_result_addr=1152921514568978488
        // 0x00BA3F2C: STP x22, x21, [sp, #0x20]  | stack[1152921514568978496] = ???;  stack[1152921514568978504] = ???;  //  dest_result_addr=1152921514568978496 |  dest_result_addr=1152921514568978504
        // 0x00BA3F30: STP x20, x19, [sp, #0x30]  | stack[1152921514568978512] = ???;  stack[1152921514568978520] = ???;  //  dest_result_addr=1152921514568978512 |  dest_result_addr=1152921514568978520
        // 0x00BA3F34: STP x29, x30, [sp, #0x40]  | stack[1152921514568978528] = ???;  stack[1152921514568978536] = ???;  //  dest_result_addr=1152921514568978528 |  dest_result_addr=1152921514568978536
        // 0x00BA3F38: ADD x29, sp, #0x40         | X29 = (1152921514568978464 + 64) = 1152921514568978528 (0x1000000251CA1060);
        // 0x00BA3F3C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA3F40: LDRB w8, [x21, #0xac6]     | W8 = (bool)static_value_03733AC6;       
        // 0x00BA3F44: MOV w19, w1                | W19 = length;//m1                       
        int val_13 = length;
        // 0x00BA3F48: MOV x20, x0                | X20 = 1152921514568990544 (0x1000000251CA3F50);//ML01
        // 0x00BA3F4C: TBNZ w8, #0, #0xba3f68     | if (static_value_03733AC6 == true) goto label_0;
        // 0x00BA3F50: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00BA3F54: LDR x8, [x8, #0xe90]       | X8 = 0x2B8FFC4;                         
        // 0x00BA3F58: LDR w0, [x8]               | W0 = 0x16B5;                            
        // 0x00BA3F5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16B5, ????);     
        // 0x00BA3F60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA3F64: STRB w8, [x21, #0xac6]     | static_value_03733AC6 = true;            //  dest_result_addr=57883334
        label_0:
        // 0x00BA3F68: CBZ w19, #0xba40d4         | if (length == 0) goto label_1;          
        if(val_13 == 0)
        {
            goto label_1;
        }
        // 0x00BA3F6C: ADRP x25, #0x3669000       | X25 = 57053184 (0x3669000);             
        // 0x00BA3F70: LDR x25, [x25, #0x600]     | X25 = 1152921504891564032;              
        // 0x00BA3F74: LDR x0, [x25]              | X0 = typeof(ByteReadArray);             
        val_14 = null;
        // 0x00BA3F78: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3F7C: TBZ w8, #0, #0xba3f90      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00BA3F80: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3F84: CBNZ w8, #0xba3f90         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00BA3F88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3F8C: LDR x0, [x25]              | X0 = typeof(ByteReadArray);             
        val_14 = null;
        label_3:
        // 0x00BA3F90: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3F94: LDR x21, [x8, #0x10]       | X21 = ByteReadArray.sb;                 
        // 0x00BA3F98: CBNZ x21, #0xba3fa0        | if (ByteReadArray.sb != null) goto label_4;
        if(ByteReadArray.sb != null)
        {
            goto label_4;
        }
        // 0x00BA3F9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_4:
        // 0x00BA3FA0: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00BA3FA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA3FA8: MOV x0, x21                | X0 = ByteReadArray.sb;//m1              
        // 0x00BA3FAC: BL #0x1b5ac0c              | ByteReadArray.sb.set_Length(value:  0); 
        ByteReadArray.sb.Length = 0;
        // 0x00BA3FB0: ORR w26, wzr, #0x80        | W26 = 128(0x80);                        
        label_10:
        // 0x00BA3FB4: LDR x0, [x25]              | X0 = typeof(ByteReadArray);             
        val_15 = null;
        // 0x00BA3FB8: LDR x22, [x20, #0x10]      | X22 = this.m_Stream; //P2               
        // 0x00BA3FBC: CMP w19, #0x80             | STATE = COMPARE(length, 0x80)           
        // 0x00BA3FC0: CSEL w21, w26, w19, gt     | W21 = length > 128 ? 128 : length;      
        var val_1 = (val_13 > 128) ? (128) : (val_13);
        // 0x00BA3FC4: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA3FC8: TBZ w8, #0, #0xba3fdc      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00BA3FCC: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA3FD0: CBNZ w8, #0xba3fdc         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BA3FD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA3FD8: LDR x0, [x25]              | X0 = typeof(ByteReadArray);             
        val_15 = null;
        label_6:
        // 0x00BA3FDC: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA3FE0: LDR x23, [x8]              | X23 = ByteReadArray.buffer;             
        // 0x00BA3FE4: CBNZ x22, #0xba3fec        | if (this.m_Stream != null) goto label_7;
        if(this.m_Stream != null)
        {
            goto label_7;
        }
        // 0x00BA3FE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_7:
        // 0x00BA3FEC: LDR x8, [x22]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA3FF0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA3FF4: MOV x0, x22                | X0 = this.m_Stream;//m1                 
        // 0x00BA3FF8: MOV x1, x23                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA3FFC: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220;
        // 0x00BA4000: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_228;
        // 0x00BA4004: MOV w3, w21                | W3 = length > 128 ? 128 : length;//m1   
        // 0x00BA4008: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_220();
        // 0x00BA400C: LDR x8, [x25]              | X8 = typeof(ByteReadArray);             
        // 0x00BA4010: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA4014: LDR x22, [x8, #0x18]       | X22 = ByteReadArray.decoder;            
        // 0x00BA4018: LDP x24, x23, [x8]         | X24 = ByteReadArray.buffer; X23 = ByteReadArray.charBuffer; //  | 
        // 0x00BA401C: CBNZ x22, #0xba4024        | if (ByteReadArray.decoder != null) goto label_8;
        if(ByteReadArray.decoder != null)
        {
            goto label_8;
        }
        // 0x00BA4020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.m_Stream, ????);
        label_8:
        // 0x00BA4024: LDR x8, [x22]              | X8 =  typeof(System.Text.Decoder);      
        // 0x00BA4028: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA402C: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
        // 0x00BA4030: MOV x0, x22                | X0 = ByteReadArray.decoder;//m1         
        // 0x00BA4034: LDP x9, x6, [x8, #0x160]   | X9 = typeof(System.Text.Decoder).__il2cppRuntimeField_160; X6 = typeof(System.Text.Decoder).__il2cppRuntimeField_168; //  | 
        // 0x00BA4038: MOV x1, x24                | X1 = ByteReadArray.buffer;//m1          
        // 0x00BA403C: MOV w3, w21                | W3 = length > 128 ? 128 : length;//m1   
        // 0x00BA4040: MOV x4, x23                | X4 = ByteReadArray.charBuffer;//m1      
        // 0x00BA4044: BLR x9                     | X0 = typeof(System.Text.Decoder).__il2cppRuntimeField_160();
        // 0x00BA4048: LDR x8, [x25]              | X8 = typeof(ByteReadArray);             
        // 0x00BA404C: MOV w22, w0                | W22 = ByteReadArray.decoder;//m1        
        // 0x00BA4050: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA4054: LDP x23, x24, [x8, #8]     | X23 = ByteReadArray.charBuffer; X24 = ByteReadArray.sb; //  | 
        // 0x00BA4058: CBNZ x24, #0xba4060        | if (ByteReadArray.sb != null) goto label_9;
        if(ByteReadArray.sb != null)
        {
            goto label_9;
        }
        // 0x00BA405C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ByteReadArray.decoder, ????);
        label_9:
        // 0x00BA4060: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA4064: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA4068: MOV x0, x24                | X0 = ByteReadArray.sb;//m1              
        // 0x00BA406C: MOV x1, x23                | X1 = ByteReadArray.charBuffer;//m1      
        // 0x00BA4070: MOV w3, w22                | W3 = ByteReadArray.decoder;//m1         
        // 0x00BA4074: BL #0x1b5bd68              | X0 = ByteReadArray.sb.Append(value:  ByteReadArray.charBuffer, startIndex:  0, charCount:  ByteReadArray.decoder);
        System.Text.StringBuilder val_2 = ByteReadArray.sb.Append(value:  ByteReadArray.charBuffer, startIndex:  0, charCount:  ByteReadArray.decoder);
        // 0x00BA4078: SUB w19, w19, w21          | W19 = (length - length > 128 ? 128 : length);
        val_13 = val_13 - val_1;
        // 0x00BA407C: CMP w19, #0                | STATE = COMPARE((length - length > 128 ? 128 : length), 0x0)
        // 0x00BA4080: B.GT #0xba3fb4             | if (length > 0) goto label_10;          
        if(val_13 > 0)
        {
            goto label_10;
        }
        // 0x00BA4084: LDR x0, [x25]              | X0 = typeof(ByteReadArray);             
        val_16 = null;
        // 0x00BA4088: LDRB w8, [x0, #0x10a]      | W8 = ByteReadArray.__il2cppRuntimeField_10A;
        // 0x00BA408C: TBZ w8, #0, #0xba40a0      | if (ByteReadArray.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x00BA4090: LDR w8, [x0, #0xbc]        | W8 = ByteReadArray.__il2cppRuntimeField_cctor_finished;
        // 0x00BA4094: CBNZ w8, #0xba40a0         | if (ByteReadArray.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x00BA4098: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ByteReadArray), ????);
        // 0x00BA409C: LDR x0, [x25]              | X0 = typeof(ByteReadArray);             
        val_16 = null;
        label_12:
        // 0x00BA40A0: LDR x8, [x0, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA40A4: LDR x19, [x8, #0x10]       | X19 = ByteReadArray.sb;                 
        // 0x00BA40A8: CBNZ x19, #0xba40b0        | if (ByteReadArray.sb != null) goto label_13;
        if(ByteReadArray.sb != null)
        {
            goto label_13;
        }
        // 0x00BA40AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ByteReadArray), ????);
        label_13:
        // 0x00BA40B0: LDR x8, [x19]              | X8 =  typeof(System.Text.StringBuilder);
        // 0x00BA40B4: MOV x0, x19                | X0 = ByteReadArray.sb;//m1              
        // 0x00BA40B8: LDP x2, x1, [x8, #0x140]   | X2 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
        // 0x00BA40BC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA40C0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA40C4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        val_13 = ???;
        // 0x00BA40C8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA40CC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA40D0: BR x2                      | goto typeof(System.Text.StringBuilder).__il2cppRuntimeField_140;
        goto typeof(System.Text.StringBuilder).__il2cppRuntimeField_140;
        label_1:
        // 0x00BA40D4: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
        // 0x00BA40D8: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
        // 0x00BA40DC: LDR x0, [x19]              | X0 = typeof(System.String);             
        val_17 = null;
        // 0x00BA40E0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00BA40E4: TBZ w8, #0, #0xba40f8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00BA40E8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00BA40EC: CBNZ w8, #0xba40f8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00BA40F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        // 0x00BA40F4: LDR x0, [x19]              | X0 = typeof(System.String);             
        val_17 = null;
        label_15:
        // 0x00BA40F8: LDR x8, [x0, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
        // 0x00BA40FC: LDR x0, [x8]               | X0 = System.String.Empty;               
        // 0x00BA4100: LDP x29, x30, [sp, #0x40]  | X29 = val_3; X30 = val_4;                //  find_add[1152921514568966544] |  find_add[1152921514568966544]
        // 0x00BA4104: LDP x20, x19, [sp, #0x30]  | X20 = val_5; X19 = val_6;                //  find_add[1152921514568966544] |  find_add[1152921514568966544]
        // 0x00BA4108: LDP x22, x21, [sp, #0x20]  | X22 = val_7; X21 = val_8;                //  find_add[1152921514568966544] |  find_add[1152921514568966544]
        // 0x00BA410C: LDP x24, x23, [sp, #0x10]  | X24 = val_9; X23 = val_10;               //  find_add[1152921514568966544] |  find_add[1152921514568966544]
        // 0x00BA4110: LDP x26, x25, [sp], #0x50  | X26 = val_11; X25 = val_12;              //  find_add[1152921514568966544] |  find_add[1152921514568966544]
        // 0x00BA4114: RET                        |  return (System.String)System.String.Empty;
        return System.String.Empty;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4118 (12206360), len: 52  VirtAddr: 0x00BA4118 RVA: 0x00BA4118 token: 100690746 methodIndex: 25585 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_Length()
    {
        //
        // Disasemble & Code
        // 0x00BA4118: STP x20, x19, [sp, #-0x20]! | stack[1152921514569102800] = ???;  stack[1152921514569102808] = ???;  //  dest_result_addr=1152921514569102800 |  dest_result_addr=1152921514569102808
        // 0x00BA411C: STP x29, x30, [sp, #0x10]  | stack[1152921514569102816] = ???;  stack[1152921514569102824] = ???;  //  dest_result_addr=1152921514569102816 |  dest_result_addr=1152921514569102824
        // 0x00BA4120: ADD x29, sp, #0x10         | X29 = (1152921514569102800 + 16) = 1152921514569102816 (0x1000000251CBF5E0);
        // 0x00BA4124: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA4128: CBNZ x19, #0xba4130        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA412C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA4130: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA4134: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA4138: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_190; X1 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_198; //  | 
        // 0x00BA413C: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_190();
        // 0x00BA4140: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4144: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA4148: RET                        |  return (System.Int32)this.m_Stream;    
        return (int)this.m_Stream;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA414C (12206412), len: 8  VirtAddr: 0x00BA414C RVA: 0x00BA414C token: 100690747 methodIndex: 25586 delegateWrapperIndex: 0 methodInvoker: 0
    internal System.IO.MemoryStream get_MemoryStream()
    {
        //
        // Disasemble & Code
        // 0x00BA414C: LDR x0, [x0, #0x10]        | X0 = this.m_Stream; //P2                
        // 0x00BA4150: RET                        |  return (System.IO.MemoryStream)this.m_Stream;
        return this.m_Stream;
        //  |  // // {name=val_0, type=System.IO.MemoryStream, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4154 (12206420), len: 52  VirtAddr: 0x00BA4154 RVA: 0x00BA4154 token: 100690748 methodIndex: 25587 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_Postion()
    {
        //
        // Disasemble & Code
        // 0x00BA4154: STP x20, x19, [sp, #-0x20]! | stack[1152921514569343184] = ???;  stack[1152921514569343192] = ???;  //  dest_result_addr=1152921514569343184 |  dest_result_addr=1152921514569343192
        // 0x00BA4158: STP x29, x30, [sp, #0x10]  | stack[1152921514569343200] = ???;  stack[1152921514569343208] = ???;  //  dest_result_addr=1152921514569343200 |  dest_result_addr=1152921514569343208
        // 0x00BA415C: ADD x29, sp, #0x10         | X29 = (1152921514569343184 + 16) = 1152921514569343200 (0x1000000251CFA0E0);
        // 0x00BA4160: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA4164: CBNZ x19, #0xba416c        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA4168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA416C: LDR x8, [x19]              | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA4170: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA4174: LDP x9, x1, [x8, #0x1a0]   | X9 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1A0; X1 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1A8; //  | 
        // 0x00BA4178: BLR x9                     | X0 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1A0();
        // 0x00BA417C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA4180: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA4184: RET                        |  return (System.Int32)this.m_Stream;    
        return (int)this.m_Stream;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA4188 (12206472), len: 72  VirtAddr: 0x00BA4188 RVA: 0x00BA4188 token: 100690749 methodIndex: 25588 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_Postion(int value)
    {
        //
        // Disasemble & Code
        // 0x00BA4188: STP x22, x21, [sp, #-0x30]! | stack[1152921514569463360] = ???;  stack[1152921514569463368] = ???;  //  dest_result_addr=1152921514569463360 |  dest_result_addr=1152921514569463368
        // 0x00BA418C: STP x20, x19, [sp, #0x10]  | stack[1152921514569463376] = ???;  stack[1152921514569463384] = ???;  //  dest_result_addr=1152921514569463376 |  dest_result_addr=1152921514569463384
        // 0x00BA4190: STP x29, x30, [sp, #0x20]  | stack[1152921514569463392] = ???;  stack[1152921514569463400] = ???;  //  dest_result_addr=1152921514569463392 |  dest_result_addr=1152921514569463400
        // 0x00BA4194: ADD x29, sp, #0x20         | X29 = (1152921514569463360 + 32) = 1152921514569463392 (0x1000000251D17660);
        // 0x00BA4198: LDR x19, [x0, #0x10]       | X19 = this.m_Stream; //P2               
        // 0x00BA419C: LDR w21, [x0, #0x18]       | W21 = this.start_offset; //P2           
        // 0x00BA41A0: MOV w20, w1                | W20 = value;//m1                        
        // 0x00BA41A4: CBNZ x19, #0xba41ac        | if (this.m_Stream != null) goto label_0;
        if(this.m_Stream != null)
        {
            goto label_0;
        }
        // 0x00BA41A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00BA41AC: LDR x9, [x19]              | X9 = typeof(System.IO.MemoryStream);    
        // 0x00BA41B0: ADD w8, w21, w20           | W8 = (this.start_offset + value);       
        int val_1 = this.start_offset + value;
        // 0x00BA41B4: MOV x0, x19                | X0 = this.m_Stream;//m1                 
        // 0x00BA41B8: SXTW x1, w8                | X1 = (long)(int)((this.start_offset + value));
        // 0x00BA41BC: LDP x3, x2, [x9, #0x1b0]   | X3 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0; X2 = typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B8; //  | 
        // 0x00BA41C0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA41C4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA41C8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA41CC: BR x3                      | goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0;
        goto typeof(System.IO.MemoryStream).__il2cppRuntimeField_1B0;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA41D0 (12206544), len: 292  VirtAddr: 0x00BA41D0 RVA: 0x00BA41D0 token: 100690750 methodIndex: 25589 delegateWrapperIndex: 0 methodInvoker: 0
    private static ByteReadArray()
    {
        //
        // Disasemble & Code
        // 0x00BA41D0: STP x22, x21, [sp, #-0x30]! | stack[1152921514569583552] = ???;  stack[1152921514569583560] = ???;  //  dest_result_addr=1152921514569583552 |  dest_result_addr=1152921514569583560
        // 0x00BA41D4: STP x20, x19, [sp, #0x10]  | stack[1152921514569583568] = ???;  stack[1152921514569583576] = ???;  //  dest_result_addr=1152921514569583568 |  dest_result_addr=1152921514569583576
        // 0x00BA41D8: STP x29, x30, [sp, #0x20]  | stack[1152921514569583584] = ???;  stack[1152921514569583592] = ???;  //  dest_result_addr=1152921514569583584 |  dest_result_addr=1152921514569583592
        // 0x00BA41DC: ADD x29, sp, #0x20         | X29 = (1152921514569583552 + 32) = 1152921514569583584 (0x1000000251D34BE0);
        // 0x00BA41E0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA41E4: LDRB w8, [x19, #0xac7]     | W8 = (bool)static_value_03733AC7;       
        // 0x00BA41E8: TBNZ w8, #0, #0xba4204     | if (static_value_03733AC7 == true) goto label_0;
        // 0x00BA41EC: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00BA41F0: LDR x8, [x8, #0x718]       | X8 = 0x2B8FF8C;                         
        // 0x00BA41F4: LDR w0, [x8]               | W0 = 0x16A7;                            
        // 0x00BA41F8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16A7, ????);     
        // 0x00BA41FC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA4200: STRB w8, [x19, #0xac7]     | static_value_03733AC7 = true;            //  dest_result_addr=57883335
        label_0:
        // 0x00BA4204: ADRP x20, #0x3669000       | X20 = 57053184 (0x3669000);             
        // 0x00BA4208: LDR x20, [x20, #0x600]     | X20 = 1152921504891564032;              
        // 0x00BA420C: ADRP x9, #0x35db000        | X9 = 56471552 (0x35DB000);              
        // 0x00BA4210: LDR x8, [x20]              | X8 = typeof(ByteReadArray);             
        // 0x00BA4214: LDR x9, [x9, #0xf00]       | X9 = 1152921504996170800;               
        // 0x00BA4218: LDR x21, [x8, #0xa0]       | X21 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA421C: LDR x19, [x9]              | X19 = typeof(System.Byte[]);            
        // 0x00BA4220: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4224: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00BA4228: ORR w1, wzr, #0x80         | W1 = 128(0x80);                         
        // 0x00BA422C: MOV x0, x19                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA4230: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00BA4234: STR x0, [x21]              | ByteReadArray.buffer = typeof(System.Byte[]);  //  dest_result_addr=1152921504891568128
        ByteReadArray.buffer = null;
        // 0x00BA4238: ADRP x9, #0x3627000        | X9 = 56782848 (0x3627000);              
        // 0x00BA423C: LDR x8, [x20]              | X8 = typeof(ByteReadArray);             
        // 0x00BA4240: LDR x9, [x9, #0xd58]       | X9 = 1152921504947213072;               
        // 0x00BA4244: LDR x21, [x8, #0xa0]       | X21 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA4248: LDR x19, [x9]              | X19 = typeof(System.Char[]);            
        // 0x00BA424C: MOV x0, x19                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BA4250: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
        // 0x00BA4254: ORR w1, wzr, #0x80         | W1 = 128(0x80);                         
        // 0x00BA4258: MOV x0, x19                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
        // 0x00BA425C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
        // 0x00BA4260: STR x0, [x21, #8]          | ByteReadArray.charBuffer = typeof(System.Char[]);  //  dest_result_addr=1152921504891568136
        ByteReadArray.charBuffer = null;
        // 0x00BA4264: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00BA4268: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x00BA426C: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_1 = null;
        // 0x00BA4270: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00BA4274: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA4278: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA427C: BL #0x1b5a30c              | .ctor();                                
        val_1 = new System.Text.StringBuilder();
        // 0x00BA4280: LDR x8, [x20]              | X8 = typeof(ByteReadArray);             
        // 0x00BA4284: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA4288: STR x19, [x8, #0x10]       | ByteReadArray.sb = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921504891568144
        ByteReadArray.sb = val_1;
        // 0x00BA428C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00BA4290: LDR x8, [x8, #0xd48]       | X8 = 1152921504649285632;               
        // 0x00BA4294: LDR x0, [x8]               | X0 = typeof(System.Text.Encoding);      
        // 0x00BA4298: LDRB w8, [x0, #0x10a]      | W8 = System.Text.Encoding.__il2cppRuntimeField_10A;
        // 0x00BA429C: TBZ w8, #0, #0xba42ac      | if (System.Text.Encoding.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA42A0: LDR w8, [x0, #0xbc]        | W8 = System.Text.Encoding.__il2cppRuntimeField_cctor_finished;
        // 0x00BA42A4: CBNZ w8, #0xba42ac         | if (System.Text.Encoding.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA42A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Text.Encoding), ????);
        label_2:
        // 0x00BA42AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA42B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA42B4: BL #0x1b56504              | X0 = System.Text.Encoding.get_UTF8();   
        System.Text.Encoding val_2 = System.Text.Encoding.UTF8;
        // 0x00BA42B8: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00BA42BC: CBNZ x19, #0xba42c4        | if (val_2 != null) goto label_3;        
        if(val_2 != null)
        {
            goto label_3;
        }
        // 0x00BA42C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_3:
        // 0x00BA42C4: LDR x8, [x19]              | X8 = typeof(System.Text.Encoding);      
        // 0x00BA42C8: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00BA42CC: LDR x9, [x8, #0x240]       | X9 = typeof(System.Text.Encoding).__il2cppRuntimeField_240;
        // 0x00BA42D0: LDR x1, [x8, #0x248]       | X1 = typeof(System.Text.Encoding).__il2cppRuntimeField_248;
        // 0x00BA42D4: BLR x9                     | X0 = typeof(System.Text.Encoding).__il2cppRuntimeField_240();
        // 0x00BA42D8: LDR x8, [x20]              | X8 = typeof(ByteReadArray);             
        // 0x00BA42DC: LDR x8, [x8, #0xa0]        | X8 = ByteReadArray.__il2cppRuntimeField_static_fields;
        // 0x00BA42E0: STR x0, [x8, #0x18]        | ByteReadArray.decoder = val_2;           //  dest_result_addr=1152921504891568152
        ByteReadArray.decoder = val_2;
        // 0x00BA42E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA42E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA42EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA42F0: RET                        |  return;                                
        return;
    
    }

}
