using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class AssemblyLinkedResource : Resource
    {
        // Fields
        private ILRuntime.Mono.Cecil.AssemblyNameReference reference; //  0x00000020
        
        // Properties
        set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E55308 (15029000), len: 8  VirtAddr: 0x00E55308 RVA: 0x00E55308 token: 100663461 methodIndex: 19289 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Assembly(ILRuntime.Mono.Cecil.AssemblyNameReference value)
        {
            //
            // Disasemble & Code
            // 0x00E55308: STR x1, [x0, #0x20]        | this.reference = value;                  //  dest_result_addr=1152921509421789984
            this.reference = value;
            // 0x00E5530C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E55310 (15029008), len: 8  VirtAddr: 0x00E55310 RVA: 0x00E55310 token: 100663462 methodIndex: 19290 delegateWrapperIndex: 0 methodInvoker: 0
        public AssemblyLinkedResource(string name, ILRuntime.Mono.Cecil.ManifestResourceAttributes flags)
        {
            //
            // Disasemble & Code
            // 0x00E55310: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E55314: B #0x11e4d38               | this..ctor(name:  name, attributes:  flags); return;
            return;
        
        }
    
    }

}
