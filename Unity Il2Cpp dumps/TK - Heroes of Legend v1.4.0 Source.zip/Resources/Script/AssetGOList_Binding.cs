using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AssetGOList_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BC3F00 (12336896), len: 8  VirtAddr: 0x00BC3F00 RVA: 0x00BC3F00 token: 100663825 methodIndex: 29870 delegateWrapperIndex: 0 methodInvoker: 0
        public AssetGOList_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BC3F00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3F04: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC3F08 (12336904), len: 428  VirtAddr: 0x00BC3F08 RVA: 0x00BC3F08 token: 100663826 methodIndex: 29871 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_5;
            // 0x00BC3F08: STP x24, x23, [sp, #-0x40]! | stack[1152921510054284368] = ???;  stack[1152921510054284376] = ???;  //  dest_result_addr=1152921510054284368 |  dest_result_addr=1152921510054284376
            // 0x00BC3F0C: STP x22, x21, [sp, #0x10]  | stack[1152921510054284384] = ???;  stack[1152921510054284392] = ???;  //  dest_result_addr=1152921510054284384 |  dest_result_addr=1152921510054284392
            // 0x00BC3F10: STP x20, x19, [sp, #0x20]  | stack[1152921510054284400] = ???;  stack[1152921510054284408] = ???;  //  dest_result_addr=1152921510054284400 |  dest_result_addr=1152921510054284408
            // 0x00BC3F14: STP x29, x30, [sp, #0x30]  | stack[1152921510054284416] = ???;  stack[1152921510054284424] = ???;  //  dest_result_addr=1152921510054284416 |  dest_result_addr=1152921510054284424
            // 0x00BC3F18: ADD x29, sp, #0x30         | X29 = (1152921510054284368 + 48) = 1152921510054284416 (0x1000000144B14C80);
            // 0x00BC3F1C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC3F20: LDRB w8, [x20, #0xb9b]     | W8 = (bool)static_value_03733B9B;       
            // 0x00BC3F24: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC3F28: TBNZ w8, #0, #0xbc3f44     | if (static_value_03733B9B == true) goto label_0;
            // 0x00BC3F2C: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x00BC3F30: LDR x8, [x8, #0xff8]       | X8 = 0x2B8EAFC;                         
            // 0x00BC3F34: LDR w0, [x8]               | W0 = 0x117F;                            
            // 0x00BC3F38: BL #0x2782188              | X0 = sub_2782188( ?? 0x117F, ????);     
            // 0x00BC3F3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC3F40: STRB w8, [x20, #0xb9b]     | static_value_03733B9B = true;            //  dest_result_addr=57883547
            label_0:
            // 0x00BC3F44: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BC3F48: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BC3F4C: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BC3F50: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00BC3F54: LDR x8, [x8, #0x3b0]       | X8 = 1152921504922501120;               
            // 0x00BC3F58: LDR x20, [x8]              | X20 = typeof(AssetGOList);              
            // 0x00BC3F5C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BC3F60: TBZ w8, #0, #0xbc3f70      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BC3F64: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BC3F68: CBNZ w8, #0xbc3f70         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BC3F6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BC3F70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BC3F74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BC3F78: MOV x1, x20                | X1 = 1152921504922501120 (0x1000000012D08000);//ML01
            // 0x00BC3F7C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BC3F80: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BC3F84: CBNZ x20, #0xbc3f8c        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BC3F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00BC3F8C: ADRP x9, #0x35c8000        | X9 = 56393728 (0x35C8000);              
            // 0x00BC3F90: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BC3F94: LDR x9, [x9, #0x4f8]       | X9 = (string**)(1152921510054270304)("goList");
            // 0x00BC3F98: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BC3F9C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BC3FA0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BC3FA4: LDR x1, [x9]               | X1 = "goList";                          
            // 0x00BC3FA8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BC3FAC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BC3FB0: ADRP x23, #0x3603000       | X23 = 56635392 (0x3603000);             
            // 0x00BC3FB4: LDR x23, [x23, #0xec8]     | X23 = 1152921504782991360;              
            // 0x00BC3FB8: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BC3FBC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.AssetGOList_Binding);
            // 0x00BC3FC0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AssetGOList_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC3FC4: LDR x21, [x8]              | X21 = ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache0;
            val_4 = ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache0;
            // 0x00BC3FC8: CBNZ x21, #0xbc4014        | if (ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_4 != null)
            {
                goto label_4;
            }
            // 0x00BC3FCC: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x00BC3FD0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BC3FD4: LDR x8, [x8, #0xcd8]       | X8 = 1152921510054270384;               
            // 0x00BC3FD8: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BC3FDC: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AssetGOList_Binding::get_goList_0(ref object o);
            // 0x00BC3FE0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x00BC3FE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BC3FE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC3FEC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC3FF0: MOV x2, x21                | X2 = 1152921510054270384 (0x1000000144B115B0);//ML01
            // 0x00BC3FF4: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BC3FF8: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AssetGOList_Binding::get_goList_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AssetGOList_Binding::get_goList_0(ref object o));
            // 0x00BC3FFC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.AssetGOList_Binding);
            // 0x00BC4000: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AssetGOList_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4004: STR x22, [x8]              | ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782995456
            ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache0 = val_2;
            // 0x00BC4008: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.AssetGOList_Binding);
            // 0x00BC400C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AssetGOList_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4010: LDR x21, [x8]              | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_4 = ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BC4014: CBNZ x19, #0xbc401c        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BC4018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AssetGOList_Binding::get_goList_0(ref object o)), ????);
            label_5:
            // 0x00BC401C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4020: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC4024: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BC4028: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BC402C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_4);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_4);
            // 0x00BC4030: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.AssetGOList_Binding);
            // 0x00BC4034: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AssetGOList_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4038: LDR x21, [x8, #8]          | X21 = ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache1;
            val_5 = ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache1;
            // 0x00BC403C: CBNZ x21, #0xbc4088        | if (ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_5 != null)
            {
                goto label_6;
            }
            // 0x00BC4040: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x00BC4044: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BC4048: LDR x8, [x8, #0x798]       | X8 = 1152921510054271408;               
            // 0x00BC404C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BC4050: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.AssetGOList_Binding::set_goList_0(ref object o, object v);
            // 0x00BC4054: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x00BC4058: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BC405C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4060: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC4064: MOV x2, x21                | X2 = 1152921510054271408 (0x1000000144B119B0);//ML01
            // 0x00BC4068: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BC406C: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AssetGOList_Binding::set_goList_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AssetGOList_Binding::set_goList_0(ref object o, object v));
            // 0x00BC4070: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.AssetGOList_Binding);
            // 0x00BC4074: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AssetGOList_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4078: STR x22, [x8, #8]          | ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782995464
            ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache1 = val_3;
            // 0x00BC407C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.AssetGOList_Binding);
            // 0x00BC4080: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AssetGOList_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BC4084: LDR x21, [x8, #8]          | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_5 = ILRuntime.Runtime.Generated.AssetGOList_Binding.<>f__mg$cache1;
            label_6:
            // 0x00BC4088: CBNZ x19, #0xbc4090        | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x00BC408C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AssetGOList_Binding::set_goList_0(ref object o, object v)), ????);
            label_7:
            // 0x00BC4090: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BC4094: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BC4098: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BC409C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC40A0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC40A4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BC40A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BC40AC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BC40B0: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_5); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_5);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC40B4 (12337332), len: 288  VirtAddr: 0x00BC40B4 RVA: 0x00BC40B4 token: 100663827 methodIndex: 29872 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_goList_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BC40B4: STP x20, x19, [sp, #-0x20]! | stack[1152921510054408608] = ???;  stack[1152921510054408616] = ???;  //  dest_result_addr=1152921510054408608 |  dest_result_addr=1152921510054408616
            // 0x00BC40B8: STP x29, x30, [sp, #0x10]  | stack[1152921510054408624] = ???;  stack[1152921510054408632] = ???;  //  dest_result_addr=1152921510054408624 |  dest_result_addr=1152921510054408632
            // 0x00BC40BC: ADD x29, sp, #0x10         | X29 = (1152921510054408608 + 16) = 1152921510054408624 (0x1000000144B331B0);
            // 0x00BC40C0: SUB sp, sp, #0x10          | SP = (1152921510054408608 - 16) = 1152921510054408592 (0x1000000144B33190);
            // 0x00BC40C4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BC40C8: LDRB w8, [x20, #0xb9c]     | W8 = (bool)static_value_03733B9C;       
            // 0x00BC40CC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BC40D0: TBNZ w8, #0, #0xbc40ec     | if (static_value_03733B9C == true) goto label_0;
            // 0x00BC40D4: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x00BC40D8: LDR x8, [x8, #0x680]       | X8 = 0x2B8EAF8;                         
            // 0x00BC40DC: LDR w0, [x8]               | W0 = 0x117E;                            
            // 0x00BC40E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x117E, ????);     
            // 0x00BC40E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC40E8: STRB w8, [x20, #0xb9c]     | static_value_03733B9C = true;            //  dest_result_addr=57883548
            label_0:
            // 0x00BC40EC: ADRP x20, #0x3629000       | X20 = 56791040 (0x3629000);             
            // 0x00BC40F0: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BC40F4: LDR x20, [x20, #0x390]     | X20 = 1152921504922501120;              
            // 0x00BC40F8: CBZ x19, #0xbc414c         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BC40FC: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BC4100: LDR x1, [x20]              | X1 = typeof(AssetGOList);               
            // 0x00BC4104: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BC4108: LDRB w9, [x1, #0x104]      | W9 = AssetGOList.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC410C: CMP w10, w9                | STATE = COMPARE(X1 + 260, AssetGOList.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC4110: B.LO #0xbc4128             | if (X1 + 260 < AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BC4114: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BC4118: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC411C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC4120: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AssetGOList))
            // 0x00BC4124: B.EQ #0xbc4150             | if ((X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BC4128: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC412C: MOV x8, sp                 | X8 = 1152921510054408592 (0x1000000144B33190);//ML01
            // 0x00BC4130: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC4134: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510054396640]
            // 0x00BC4138: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BC413C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4140: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BC4144: MOV x0, sp                 | X0 = 1152921510054408592 (0x1000000144B33190);//ML01
            // 0x00BC4148: BL #0x299a140              | 
            label_1:
            // 0x00BC414C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144B33190, ????);
            label_3:
            // 0x00BC4150: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BC4154: LDR x1, [x20]              | X1 = typeof(AssetGOList);               
            // 0x00BC4158: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BC415C: LDRB w9, [x1, #0x104]      | W9 = AssetGOList.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC4160: CMP w10, w9                | STATE = COMPARE(X1 + 260, AssetGOList.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC4164: B.LO #0xbc4190             | if (X1 + 260 < AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BC4168: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BC416C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC4170: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC4174: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AssetGOList))
            // 0x00BC4178: B.NE #0xbc4190             | if ((X1 + 176 + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BC417C: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x00BC4180: SUB sp, x29, #0x10         | SP = (1152921510054408624 - 16) = 1152921510054408608 (0x1000000144B331A0);
            // 0x00BC4184: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC4188: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BC418C: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BC4190: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BC4194: ADD x8, sp, #8             | X8 = (1152921510054408592 + 8) = 1152921510054408600 (0x1000000144B33198);
            // 0x00BC4198: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BC419C: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510054396640]
            // 0x00BC41A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC41A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC41A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC41AC: ADD x0, sp, #8             | X0 = (1152921510054408592 + 8) = 1152921510054408600 (0x1000000144B33198);
            // 0x00BC41B0: BL #0x299a140              | 
            // 0x00BC41B4: MOV x19, x0                | X19 = 1152921510054408600 (0x1000000144B33198);//ML01
            // 0x00BC41B8: MOV x0, sp                 | X0 = 1152921510054408592 (0x1000000144B33190);//ML01
            label_6:
            // 0x00BC41BC: BL #0x299a140              | 
            // 0x00BC41C0: MOV x0, x19                | X0 = 1152921510054408600 (0x1000000144B33198);//ML01
            // 0x00BC41C4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000144B33198, ????);
            // 0x00BC41C8: MOV x19, x0                | X19 = 1152921510054408600 (0x1000000144B33198);//ML01
            // 0x00BC41CC: ADD x0, sp, #8             | X0 = (1152921510054408592 + 8) = 1152921510054408600 (0x1000000144B33198);
            // 0x00BC41D0: B #0xbc41bc                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BC41D4 (12337620), len: 404  VirtAddr: 0x00BC41D4 RVA: 0x00BC41D4 token: 100663828 methodIndex: 29873 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_goList_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00BC41D4: STP x22, x21, [sp, #-0x30]! | stack[1152921510054532720] = ???;  stack[1152921510054532728] = ???;  //  dest_result_addr=1152921510054532720 |  dest_result_addr=1152921510054532728
            // 0x00BC41D8: STP x20, x19, [sp, #0x10]  | stack[1152921510054532736] = ???;  stack[1152921510054532744] = ???;  //  dest_result_addr=1152921510054532736 |  dest_result_addr=1152921510054532744
            // 0x00BC41DC: STP x29, x30, [sp, #0x20]  | stack[1152921510054532752] = ???;  stack[1152921510054532760] = ???;  //  dest_result_addr=1152921510054532752 |  dest_result_addr=1152921510054532760
            // 0x00BC41E0: ADD x29, sp, #0x20         | X29 = (1152921510054532720 + 32) = 1152921510054532752 (0x1000000144B51690);
            // 0x00BC41E4: SUB sp, sp, #0x20          | SP = (1152921510054532720 - 32) = 1152921510054532688 (0x1000000144B51650);
            // 0x00BC41E8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BC41EC: LDRB w8, [x21, #0xb9d]     | W8 = (bool)static_value_03733B9D;       
            // 0x00BC41F0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BC41F4: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BC41F8: TBNZ w8, #0, #0xbc4214     | if (static_value_03733B9D == true) goto label_0;
            // 0x00BC41FC: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00BC4200: LDR x8, [x8, #0x9e8]       | X8 = 0x2B8EB00;                         
            // 0x00BC4204: LDR w0, [x8]               | W0 = 0x1180;                            
            // 0x00BC4208: BL #0x2782188              | X0 = sub_2782188( ?? 0x1180, ????);     
            // 0x00BC420C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BC4210: STRB w8, [x21, #0xb9d]     | static_value_03733B9D = true;            //  dest_result_addr=57883549
            label_0:
            // 0x00BC4214: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BC4218: CBZ x21, #0xbc42cc         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BC421C: ADRP x20, #0x3629000       | X20 = 56791040 (0x3629000);             
            // 0x00BC4220: LDR x20, [x20, #0x390]     | X20 = 1152921504922501120;              
            // 0x00BC4224: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC4228: LDR x1, [x20]              | X1 = typeof(AssetGOList);               
            // 0x00BC422C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BC4230: LDRB w9, [x1, #0x104]      | W9 = AssetGOList.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC4234: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AssetGOList.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC4238: B.LO #0xbc4250             | if (mem[null + 260] < AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BC423C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BC4240: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC4244: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC4248: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AssetGOList))
            // 0x00BC424C: B.EQ #0xbc4278             | if ((mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BC4250: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC4254: ADD x8, sp, #8             | X8 = (1152921510054532688 + 8) = 1152921510054532696 (0x1000000144B51658);
            // 0x00BC4258: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BC425C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510054520768]
            // 0x00BC4260: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BC4264: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4268: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BC426C: ADD x0, sp, #8             | X0 = (1152921510054532688 + 8) = 1152921510054532696 (0x1000000144B51658);
            // 0x00BC4270: BL #0x299a140              | 
            // 0x00BC4274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000144B51658, ????);
            label_3:
            // 0x00BC4278: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BC427C: LDR x1, [x20]              | X1 = typeof(AssetGOList);               
            // 0x00BC4280: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BC4284: LDRB w9, [x1, #0x104]      | W9 = AssetGOList.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BC4288: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AssetGOList.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BC428C: B.LO #0xbc42a4             | if (mem[null + 260] < AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BC4290: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BC4294: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BC4298: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BC429C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AssetGOList))
            // 0x00BC42A0: B.EQ #0xbc42d4             | if ((mem[null + 176] + (AssetGOList.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BC42A4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BC42A8: ADD x8, sp, #0x10          | X8 = (1152921510054532688 + 16) = 1152921510054532704 (0x1000000144B51660);
            // 0x00BC42AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BC42B0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510054520768]
            // 0x00BC42B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BC42B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC42BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BC42C0: ADD x0, sp, #0x10          | X0 = (1152921510054532688 + 16) = 1152921510054532704 (0x1000000144B51660);
            // 0x00BC42C4: BL #0x299a140              | 
            // 0x00BC42C8: B #0xbc42d0                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BC42CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1180, ????);     
            label_6:
            // 0x00BC42D0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BC42D4: CBZ x19, #0xbc4320         | if (X2 == 0) goto label_7;              
            if(X2 == 0)
            {
                goto label_7;
            }
            // 0x00BC42D8: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00BC42DC: LDR x8, [x8, #0xb30]       | X8 = 1152921505607026400;               
            // 0x00BC42E0: MOV x0, x19                | X0 = X2;//m1                            
            val_7 = X2;
            // 0x00BC42E4: LDR x20, [x8]              | X20 = typeof(UnityEngine.GameObject[]); 
            // 0x00BC42E8: MOV x1, x20                | X1 = 1152921505607026400 (0x100000003B9D86E0);//ML01
            // 0x00BC42EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
            // 0x00BC42F0: CBNZ x0, #0xbc4324         | if (X2 != 0) goto label_8;              
            if(val_7 != 0)
            {
                goto label_8;
            }
            // 0x00BC42F4: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BC42F8: MOV x1, x20                | X1 = 1152921505607026400 (0x100000003B9D86E0);//ML01
            // 0x00BC42FC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BC4300: ADD x8, sp, #0x18          | X8 = (1152921510054532688 + 24) = 1152921510054532712 (0x1000000144B51668);
            // 0x00BC4304: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x00BC4308: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510054520768]
            // 0x00BC430C: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BC4310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BC4314: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BC4318: ADD x0, sp, #0x18          | X0 = (1152921510054532688 + 24) = 1152921510054532712 (0x1000000144B51668);
            // 0x00BC431C: BL #0x299a140              | 
            label_7:
            // 0x00BC4320: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_7 = 0;
            label_8:
            // 0x00BC4324: STR x0, [x21, #0x18]       | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_7;
            // 0x00BC4328: SUB sp, x29, #0x20         | SP = (1152921510054532752 - 32) = 1152921510054532720 (0x1000000144B51670);
            // 0x00BC432C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BC4330: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BC4334: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BC4338: RET                        |  return;                                
            return;
            // 0x00BC433C: MOV x19, x0                | 
            // 0x00BC4340: ADD x0, sp, #8             | 
            // 0x00BC4344: B #0xbc435c                | 
            // 0x00BC4348: MOV x19, x0                | 
            // 0x00BC434C: ADD x0, sp, #0x10          | 
            // 0x00BC4350: B #0xbc435c                | 
            // 0x00BC4354: MOV x19, x0                | 
            // 0x00BC4358: ADD x0, sp, #0x18          | 
            label_10:
            // 0x00BC435C: BL #0x299a140              | 
            // 0x00BC4360: MOV x0, x19                | 
            // 0x00BC4364: BL #0x980800               | 
        
        }
    
    }

}
