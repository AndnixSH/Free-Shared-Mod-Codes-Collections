using UnityEngine;

namespace Pathfinding
{
    public class ABPathEndingCondition : PathEndingCondition
    {
        // Fields
        protected Pathfinding.ABPath abPath; //  0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00D1E200 (13754880), len: 160  VirtAddr: 0x00D1E200 RVA: 0x00D1E200 token: 100683672 methodIndex: 49700 delegateWrapperIndex: 0 methodInvoker: 0
        public ABPathEndingCondition(Pathfinding.ABPath p)
        {
            //
            // Disasemble & Code
            // 0x00D1E200: STP x22, x21, [sp, #-0x30]! | stack[1152921513525666576] = ???;  stack[1152921513525666584] = ???;  //  dest_result_addr=1152921513525666576 |  dest_result_addr=1152921513525666584
            // 0x00D1E204: STP x20, x19, [sp, #0x10]  | stack[1152921513525666592] = ???;  stack[1152921513525666600] = ???;  //  dest_result_addr=1152921513525666592 |  dest_result_addr=1152921513525666600
            // 0x00D1E208: STP x29, x30, [sp, #0x20]  | stack[1152921513525666608] = ???;  stack[1152921513525666616] = ???;  //  dest_result_addr=1152921513525666608 |  dest_result_addr=1152921513525666616
            // 0x00D1E20C: ADD x29, sp, #0x20         | X29 = (1152921513525666576 + 32) = 1152921513525666608 (0x10000002139A6330);
            // 0x00D1E210: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00D1E214: LDRB w8, [x21, #0x2dc]     | W8 = (bool)static_value_037342DC;       
            // 0x00D1E218: MOV x19, x1                | X19 = p;//m1                            
            // 0x00D1E21C: MOV x20, x0                | X20 = 1152921513525678624 (0x10000002139A9220);//ML01
            // 0x00D1E220: TBNZ w8, #0, #0xd1e23c     | if (static_value_037342DC == true) goto label_0;
            // 0x00D1E224: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00D1E228: LDR x8, [x8, #0xf90]       | X8 = 0x2B8A790;                         
            // 0x00D1E22C: LDR w0, [x8]               | W0 = 0xA2;                              
            // 0x00D1E230: BL #0x2782188              | X0 = sub_2782188( ?? 0xA2, ????);       
            // 0x00D1E234: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1E238: STRB w8, [x21, #0x2dc]     | static_value_037342DC = true;            //  dest_result_addr=57885404
            label_0:
            // 0x00D1E23C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E240: MOV x0, x20                | X0 = 1152921513525678624 (0x10000002139A9220);//ML01
            // 0x00D1E244: BL #0x1405070              | this..ctor();                           
            // 0x00D1E248: CBZ x19, #0xd1e260         | if (p == null) goto label_1;            
            if(p == null)
            {
                goto label_1;
            }
            // 0x00D1E24C: STR x19, [x20, #0x18]      | this.abPath = p;                         //  dest_result_addr=1152921513525678648
            this.abPath = p;
            // 0x00D1E250: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1E254: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1E258: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00D1E25C: RET                        |  return;                                
            return;
            label_1:
            // 0x00D1E260: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00D1E264: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x00D1E268: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_1 = null;
            // 0x00D1E26C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x00D1E270: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00D1E274: LDR x8, [x8, #0x920]       | X8 = (string**)(1152921513525403872)("Please supply a non-null path");
            // 0x00D1E278: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00D1E27C: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00D1E280: LDR x1, [x8]               | X1 = "Please supply a non-null path";   
            // 0x00D1E284: BL #0x18b3df0              | .ctor(paramName:  "Please supply a non-null path");
            val_1 = new System.ArgumentNullException(paramName:  "Please supply a non-null path");
            // 0x00D1E288: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00D1E28C: LDR x8, [x8, #0x650]       | X8 = 1152921513525653600;               
            // 0x00D1E290: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x00D1E294: LDR x1, [x8]               | X1 = public System.Void Pathfinding.ABPathEndingCondition::.ctor(Pathfinding.ABPath p);
            // 0x00D1E298: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x00D1E29C: BL #0xd1d708               | ResetCosts(p:  public System.Void Pathfinding.ABPathEndingCondition::.ctor(Pathfinding.ABPath p));
            ResetCosts(p:  public System.Void Pathfinding.ABPathEndingCondition::.ctor(Pathfinding.ABPath p));
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1E2A0 (13755040), len: 68  VirtAddr: 0x00D1E2A0 RVA: 0x00D1E2A0 token: 100683673 methodIndex: 49701 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool TargetFound(Pathfinding.PathNode node)
        {
            //
            // Disasemble & Code
            // 0x00D1E2A0: STP x20, x19, [sp, #-0x20]! | stack[1152921513525799072] = ???;  stack[1152921513525799080] = ???;  //  dest_result_addr=1152921513525799072 |  dest_result_addr=1152921513525799080
            // 0x00D1E2A4: STP x29, x30, [sp, #0x10]  | stack[1152921513525799088] = ???;  stack[1152921513525799096] = ???;  //  dest_result_addr=1152921513525799088 |  dest_result_addr=1152921513525799096
            // 0x00D1E2A8: ADD x29, sp, #0x10         | X29 = (1152921513525799072 + 16) = 1152921513525799088 (0x10000002139C68B0);
            // 0x00D1E2AC: MOV x20, x1                | X20 = node;//m1                         
            // 0x00D1E2B0: MOV x19, x0                | X19 = 1152921513525811104 (0x10000002139C97A0);//ML01
            // 0x00D1E2B4: CBNZ x20, #0xd1e2bc        | if (node != null) goto label_0;         
            if(node != null)
            {
                goto label_0;
            }
            // 0x00D1E2B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00D1E2BC: LDR x20, [x20, #0x10]      | X20 = node.node; //P2                   
            // 0x00D1E2C0: LDR x19, [x19, #0x18]      | X19 = this.abPath; //P2                 
            // 0x00D1E2C4: CBNZ x19, #0xd1e2cc        | if (this.abPath != null) goto label_1;  
            if(this.abPath != null)
            {
                goto label_1;
            }
            // 0x00D1E2C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00D1E2CC: LDR x8, [x19, #0x118]      | X8 = this.abPath.endNode; //P2          
            // 0x00D1E2D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1E2D4: CMP x20, x8                | STATE = COMPARE(node.node, this.abPath.endNode)
            // 0x00D1E2D8: CSET w0, eq                | W0 = node.node == this.abPath.endNode ? 1 : 0;
            var val_1 = (node.node == this.abPath.endNode) ? 1 : 0;
            // 0x00D1E2DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00D1E2E0: RET                        |  return (System.Boolean)node.node == this.abPath.endNode ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
