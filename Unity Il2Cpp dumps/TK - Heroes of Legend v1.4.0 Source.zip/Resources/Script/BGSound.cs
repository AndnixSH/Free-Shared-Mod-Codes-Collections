using UnityEngine;
public class BGSound : ISound
{
    // Fields
    private UnityEngine.AudioSource audioSource; //  0x00000018
    private int curID; //  0x00000020
    private bool isPlaying; //  0x00000024
    
    // Properties
    public override bool mute { get; set; }
    public override float volume { get; set; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8F3A4 (12120996), len: 232  VirtAddr: 0x00B8F3A4 RVA: 0x00B8F3A4 token: 100694056 methodIndex: 25118 delegateWrapperIndex: 0 methodInvoker: 0
    public BGSound()
    {
        //
        // Disasemble & Code
        // 0x00B8F3A4: STP x20, x19, [sp, #-0x20]! | stack[1152921515101550112] = ???;  stack[1152921515101550120] = ???;  //  dest_result_addr=1152921515101550112 |  dest_result_addr=1152921515101550120
        // 0x00B8F3A8: STP x29, x30, [sp, #0x10]  | stack[1152921515101550128] = ???;  stack[1152921515101550136] = ???;  //  dest_result_addr=1152921515101550128 |  dest_result_addr=1152921515101550136
        // 0x00B8F3AC: ADD x29, sp, #0x10         | X29 = (1152921515101550112 + 16) = 1152921515101550128 (0x1000000271887630);
        // 0x00B8F3B0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8F3B4: LDRB w8, [x20, #0xa2d]     | W8 = (bool)static_value_03733A2D;       
        // 0x00B8F3B8: MOV x19, x0                | X19 = 1152921515101562144 (0x100000027188A520);//ML01
        // 0x00B8F3BC: TBNZ w8, #0, #0xb8f3d8     | if (static_value_03733A2D == true) goto label_0;
        // 0x00B8F3C0: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
        // 0x00B8F3C4: LDR x8, [x8, #0xbd0]       | X8 = 0x2B8F370;                         
        // 0x00B8F3C8: LDR w0, [x8]               | W0 = 0x139E;                            
        // 0x00B8F3CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x139E, ????);     
        // 0x00B8F3D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F3D4: STRB w8, [x20, #0xa2d]     | static_value_03733A2D = true;            //  dest_result_addr=57883181
        label_0:
        // 0x00B8F3D8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00B8F3DC: LDR x8, [x8, #0xf58]       | X8 = 1152921504923992064;               
        // 0x00B8F3E0: LDR x0, [x8]               | X0 = typeof(GlobalObject);              
        // 0x00B8F3E4: LDRB w8, [x0, #0x10a]      | W8 = GlobalObject.__il2cppRuntimeField_10A;
        // 0x00B8F3E8: TBZ w8, #0, #0xb8f3f8      | if (GlobalObject.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8F3EC: LDR w8, [x0, #0xbc]        | W8 = GlobalObject.__il2cppRuntimeField_cctor_finished;
        // 0x00B8F3F0: CBNZ w8, #0xb8f3f8         | if (GlobalObject.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8F3F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(GlobalObject), ????);
        label_2:
        // 0x00B8F3F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F3FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F400: BL #0x2882314              | X0 = GlobalObject.get_GlobalObj();      
        UnityEngine.GameObject val_1 = GlobalObject.GlobalObj;
        // 0x00B8F404: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8F408: CBNZ x20, #0xb8f410        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00B8F40C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00B8F410: ADRP x8, #0x362a000        | X8 = 56795136 (0x362A000);              
        // 0x00B8F414: LDR x8, [x8, #0xa70]       | X8 = 1152921514186286784;               
        // 0x00B8F418: MOV x0, x20                | X0 = val_1;//m1                         
        // 0x00B8F41C: LDR x1, [x8]               | X1 = public UnityEngine.AudioSource UnityEngine.GameObject::AddComponent<UnityEngine.AudioSource>();
        // 0x00B8F420: BL #0x23d5984              | X0 = val_1.AddComponent<UnityEngine.AudioSource>();
        UnityEngine.AudioSource val_2 = val_1.AddComponent<UnityEngine.AudioSource>();
        // 0x00B8F424: STR x0, [x19, #0x18]       | this.audioSource = val_2;                //  dest_result_addr=1152921515101562168
        this.audioSource = val_2;
        // 0x00B8F428: MOVN w8, #0                | W8 = 0 (0x0);//ML01                     
        // 0x00B8F42C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F430: MOV x0, x19                | X0 = 1152921515101562144 (0x100000027188A520);//ML01
        // 0x00B8F434: STR w8, [x19, #0x20]       | this.curID = 0;                          //  dest_result_addr=1152921515101562176
        this.curID = 0;
        // 0x00B8F438: BL #0x17b7f78              | this..ctor();                           
        // 0x00B8F43C: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F440: CBNZ x20, #0xb8f448        | if (this.audioSource != null) goto label_4;
        if(this.audioSource != null)
        {
            goto label_4;
        }
        // 0x00B8F444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_4:
        // 0x00B8F448: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F44C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00B8F450: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F454: BL #0x27526b8              | this.audioSource.set_loop(value:  true);
        this.audioSource.loop = true;
        // 0x00B8F458: LDR x8, [x19]              | X8 = typeof(BGSound);                   
        // 0x00B8F45C: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B8F460: MOV x0, x19                | X0 = 1152921515101562144 (0x100000027188A520);//ML01
        // 0x00B8F464: LDP x9, x2, [x8, #0x1f0]   | X9 = typeof(BGSound).__il2cppRuntimeField_1F0; X2 = typeof(BGSound).__il2cppRuntimeField_1F8; //  | 
        // 0x00B8F468: BLR x9                     | X0 = typeof(BGSound).__il2cppRuntimeField_1F0();
        // 0x00B8F46C: LDR x8, [x19]              | X8 = typeof(BGSound);                   
        // 0x00B8F470: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x00B8F474: MOV x0, x19                | X0 = 1152921515101562144 (0x100000027188A520);//ML01
        // 0x00B8F478: LDR x2, [x8, #0x210]       | X2 = typeof(BGSound).__il2cppRuntimeField_210;
        // 0x00B8F47C: LDR x1, [x8, #0x218]       | X1 = typeof(BGSound).__il2cppRuntimeField_218;
        // 0x00B8F480: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F484: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F488: BR x2                      | goto typeof(BGSound).__il2cppRuntimeField_210;
        goto typeof(BGSound).__il2cppRuntimeField_210;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F48C (12121228), len: 184  VirtAddr: 0x00B8F48C RVA: 0x00B8F48C token: 100694057 methodIndex: 25119 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Pause()
    {
        //
        // Disasemble & Code
        // 0x00B8F48C: STP x20, x19, [sp, #-0x20]! | stack[1152921515101686688] = ???;  stack[1152921515101686696] = ???;  //  dest_result_addr=1152921515101686688 |  dest_result_addr=1152921515101686696
        // 0x00B8F490: STP x29, x30, [sp, #0x10]  | stack[1152921515101686704] = ???;  stack[1152921515101686712] = ???;  //  dest_result_addr=1152921515101686704 |  dest_result_addr=1152921515101686712
        // 0x00B8F494: ADD x29, sp, #0x10         | X29 = (1152921515101686688 + 16) = 1152921515101686704 (0x10000002718A8BB0);
        // 0x00B8F498: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8F49C: LDRB w8, [x20, #0xa2e]     | W8 = (bool)static_value_03733A2E;       
        // 0x00B8F4A0: MOV x19, x0                | X19 = 1152921515101698720 (0x10000002718ABAA0);//ML01
        // 0x00B8F4A4: TBNZ w8, #0, #0xb8f4c0     | if (static_value_03733A2E == true) goto label_0;
        // 0x00B8F4A8: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00B8F4AC: LDR x8, [x8, #0x98]        | X8 = 0x2B8F374;                         
        // 0x00B8F4B0: LDR w0, [x8]               | W0 = 0x139F;                            
        // 0x00B8F4B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x139F, ????);     
        // 0x00B8F4B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F4BC: STRB w8, [x20, #0xa2e]     | static_value_03733A2E = true;            //  dest_result_addr=57883182
        label_0:
        // 0x00B8F4C0: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F4C4: CBNZ x20, #0xb8f4cc        | if (this.audioSource != null) goto label_1;
        if(this.audioSource != null)
        {
            goto label_1;
        }
        // 0x00B8F4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x139F, ????);     
        label_1:
        // 0x00B8F4CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F4D0: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F4D4: BL #0x2751780              | X0 = this.audioSource.get_clip();       
        UnityEngine.AudioClip val_1 = this.audioSource.clip;
        // 0x00B8F4D8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B8F4DC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B8F4E0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8F4E4: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B8F4E8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B8F4EC: TBZ w9, #0, #0xb8f500      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B8F4F0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B8F4F4: CBNZ w9, #0xb8f500         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B8F4F8: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B8F4FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B8F500: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F504: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F508: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B8F50C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8F510: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        // 0x00B8F514: TBZ w0, #0, #0xb8f538      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B8F518: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F51C: CBNZ x20, #0xb8f524        | if (this.audioSource != null) goto label_5;
        if(this.audioSource != null)
        {
            goto label_5;
        }
        // 0x00B8F520: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B8F524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F528: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F52C: BL #0x2752054              | this.audioSource.Pause();               
        this.audioSource.Pause();
        // 0x00B8F530: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F534: STRB w8, [x19, #0x24]      | this.isPlaying = true;                   //  dest_result_addr=1152921515101698756
        this.isPlaying = true;
        label_4:
        // 0x00B8F538: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F53C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F540: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F544 (12121412), len: 360  VirtAddr: 0x00B8F544 RVA: 0x00B8F544 token: 100694058 methodIndex: 25120 delegateWrapperIndex: 0 methodInvoker: 0
    public override UnityEngine.AudioSource Play(SoundCfg soundCfg, UnityEngine.AudioClip clip)
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.AudioClip val_2;
        //  | 
        UnityEngine.AudioSource val_3;
        // 0x00B8F544: STP d9, d8, [sp, #-0x50]!  | stack[1152921515101831408] = ???;  stack[1152921515101831416] = ???;  //  dest_result_addr=1152921515101831408 |  dest_result_addr=1152921515101831416
        // 0x00B8F548: STP x24, x23, [sp, #0x10]  | stack[1152921515101831424] = ???;  stack[1152921515101831432] = ???;  //  dest_result_addr=1152921515101831424 |  dest_result_addr=1152921515101831432
        // 0x00B8F54C: STP x22, x21, [sp, #0x20]  | stack[1152921515101831440] = ???;  stack[1152921515101831448] = ???;  //  dest_result_addr=1152921515101831440 |  dest_result_addr=1152921515101831448
        // 0x00B8F550: STP x20, x19, [sp, #0x30]  | stack[1152921515101831456] = ???;  stack[1152921515101831464] = ???;  //  dest_result_addr=1152921515101831456 |  dest_result_addr=1152921515101831464
        // 0x00B8F554: STP x29, x30, [sp, #0x40]  | stack[1152921515101831472] = ???;  stack[1152921515101831480] = ???;  //  dest_result_addr=1152921515101831472 |  dest_result_addr=1152921515101831480
        // 0x00B8F558: ADD x29, sp, #0x40         | X29 = (1152921515101831408 + 64) = 1152921515101831472 (0x10000002718CC130);
        // 0x00B8F55C: MOV x21, x2                | X21 = clip;//m1                         
        val_2 = clip;
        // 0x00B8F560: MOV x20, x1                | X20 = soundCfg;//m1                     
        // 0x00B8F564: MOV x19, x0                | X19 = 1152921515101843488 (0x10000002718CF020);//ML01
        // 0x00B8F568: CBNZ x20, #0xb8f570        | if (soundCfg != null) goto label_0;     
        if(soundCfg != null)
        {
            goto label_0;
        }
        // 0x00B8F56C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B8F570: LDR w8, [x20, #0x10]       | W8 = soundCfg.id; //P2                  
        // 0x00B8F574: LDR x9, [x19, #0x20]       | X9 = this.curID; //P2                   
        // 0x00B8F578: CMP w9, w8                 | STATE = COMPARE(this.curID, soundCfg.id)
        // 0x00B8F57C: B.NE #0xb8f5bc             | if (this.curID != soundCfg.id) goto label_1;
        if(this.curID != soundCfg.id)
        {
            goto label_1;
        }
        // 0x00B8F580: ADD x23, x19, #0x18        | X23 = this.audioSource;//AP2 res_addr=1152921515101843512
        val_3 = this.audioSource;
        // 0x00B8F584: AND x8, x9, #0xff00000000  | X8 = (this.curID & 1095216660480);      
        int val_1 = this.curID & 1095216660480;
        // 0x00B8F588: CBNZ x8, #0xb8f690         | if ((this.curID & 1095216660480) != 0) goto label_4;
        if(val_1 != 0)
        {
            goto label_4;
        }
        // 0x00B8F58C: LDR x20, [x23]             |  //  not_find_field!1:0
        // 0x00B8F590: CBNZ x20, #0xb8f598        | if (mem[this.audioSource] != 0) goto label_3;
        if(mem[this.audioSource] != 0)
        {
            goto label_3;
        }
        // 0x00B8F594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_3:
        // 0x00B8F598: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F59C: MOV x0, x20                | X0 = mem[this.audioSource];//m1         
        // 0x00B8F5A0: MOV x1, x21                | X1 = clip;//m1                          
        // 0x00B8F5A4: BL #0x2751c34              | mem[this.audioSource].set_clip(value:  val_2);
        mem[this.audioSource].clip = val_2;
        // 0x00B8F5A8: LDR x8, [x19]              | X8 = typeof(BGSound);                   
        // 0x00B8F5AC: MOV x0, x19                | X0 = 1152921515101843488 (0x10000002718CF020);//ML01
        // 0x00B8F5B0: LDP x9, x1, [x8, #0x180]   | X9 = typeof(BGSound).__il2cppRuntimeField_180; X1 = typeof(BGSound).__il2cppRuntimeField_188; //  | 
        // 0x00B8F5B4: BLR x9                     | X0 = typeof(BGSound).__il2cppRuntimeField_180();
        // 0x00B8F5B8: B #0xb8f690                |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x00B8F5BC: STR w8, [x19, #0x20]       | this.curID = soundCfg.id;                //  dest_result_addr=1152921515101843520
        this.curID = soundCfg.id;
        // 0x00B8F5C0: MOV x23, x19               | X23 = 1152921515101843488 (0x10000002718CF020);//ML01
        val_3 = this;
        // 0x00B8F5C4: LDR x22, [x23, #0x18]!     | X22 = this.audioSource; //P2            
        // 0x00B8F5C8: CBNZ x22, #0xb8f5d0        | if (this.audioSource != null) goto label_5;
        if(this.audioSource != null)
        {
            goto label_5;
        }
        // 0x00B8F5CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x00B8F5D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F5D4: MOV x0, x22                | X0 = this.audioSource;//m1              
        // 0x00B8F5D8: BL #0x2751fec              | this.audioSource.Stop();                
        this.audioSource.Stop();
        // 0x00B8F5DC: LDR x22, [x23]             | X22 = this.audioSource;                 
        // 0x00B8F5E0: CBNZ x22, #0xb8f5e8        | if (this.audioSource != null) goto label_6;
        if(null != null)
        {
            goto label_6;
        }
        // 0x00B8F5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.audioSource, ????);
        label_6:
        // 0x00B8F5E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F5EC: MOV x0, x22                | X0 = this.audioSource;//m1              
        // 0x00B8F5F0: MOV x1, x21                | X1 = clip;//m1                          
        // 0x00B8F5F4: BL #0x2751c34              | this.audioSource.set_clip(value:  val_2);
        null.clip = val_2;
        // 0x00B8F5F8: LDR x21, [x23]             | X21 = this.audioSource;                 
        // 0x00B8F5FC: CBNZ x21, #0xb8f604        | if (this.audioSource != null) goto label_7;
        if(null != null)
        {
            goto label_7;
        }
        // 0x00B8F600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.audioSource, ????);
        label_7:
        // 0x00B8F604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F608: MOV x0, x21                | X0 = this.audioSource;//m1              
        // 0x00B8F60C: BL #0x2751e04              | this.audioSource.Play();                
        null.Play();
        // 0x00B8F610: LDR x21, [x23]             | X21 = this.audioSource;                 
        // 0x00B8F614: CBNZ x21, #0xb8f61c        | if (this.audioSource != null) goto label_8;
        if(null != null)
        {
            goto label_8;
        }
        // 0x00B8F618: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.audioSource, ????);
        label_8:
        // 0x00B8F61C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F620: FMOV s0, #1.00000000       | S0 = 1;                                 
        float val_2 = 1f;
        // 0x00B8F624: MOV x0, x21                | X0 = this.audioSource;//m1              
        // 0x00B8F628: BL #0x27519fc              | this.audioSource.set_pitch(value:  1f); 
        null.pitch = val_2;
        // 0x00B8F62C: LDR x21, [x19, #0x18]      | X21 = this.audioSource; //P2            
        // 0x00B8F630: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F634: STRB w8, [x19, #0x24]      | this.isPlaying = true;                   //  dest_result_addr=1152921515101843524
        this.isPlaying = true;
        // 0x00B8F638: CBNZ x21, #0xb8f640        | if (this.audioSource != null) goto label_9;
        if(this.audioSource != null)
        {
            goto label_9;
        }
        // 0x00B8F63C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.audioSource, ????);
        label_9:
        // 0x00B8F640: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F644: ORR w1, wzr, #0x100        | W1 = 256(0x100);                        
        // 0x00B8F648: MOV x0, x21                | X0 = this.audioSource;//m1              
        // 0x00B8F64C: BL #0x2753564              | this.audioSource.set_priority(value:  256);
        this.audioSource.priority = 256;
        // 0x00B8F650: LDR x8, [x19]              | X8 = typeof(BGSound);                   
        // 0x00B8F654: LDR x21, [x19, #0x18]      | X21 = this.audioSource; //P2            
        val_2 = this.audioSource;
        // 0x00B8F658: MOV x0, x19                | X0 = 1152921515101843488 (0x10000002718CF020);//ML01
        // 0x00B8F65C: LDR x9, [x8, #0x200]       | X9 = typeof(BGSound).__il2cppRuntimeField_200;
        // 0x00B8F660: LDR x1, [x8, #0x208]       | X1 = typeof(BGSound).__il2cppRuntimeField_208;
        // 0x00B8F664: BLR x9                     | X0 = typeof(BGSound).__il2cppRuntimeField_200();
        // 0x00B8F668: MOV v8.16b, v0.16b         | V8 = 1;//m1                             
        // 0x00B8F66C: CBNZ x20, #0xb8f674        | if (soundCfg != null) goto label_10;    
        if(soundCfg != null)
        {
            goto label_10;
        }
        // 0x00B8F670: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_10:
        // 0x00B8F674: LDR s9, [x20, #0x30]       | S9 = soundCfg.volume; //P2              
        // 0x00B8F678: CBNZ x21, #0xb8f680        | if (this.audioSource != null) goto label_11;
        if(val_2 != null)
        {
            goto label_11;
        }
        // 0x00B8F67C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_11:
        // 0x00B8F680: FMUL s0, s8, s9            | S0 = (1f * soundCfg.volume);            
        val_2 = val_2 * soundCfg.volume;
        // 0x00B8F684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F688: MOV x0, x21                | X0 = this.audioSource;//m1              
        // 0x00B8F68C: BL #0x275191c              | this.audioSource.set_volume(value:  1f = 1f * soundCfg.volume);
        val_2.volume = val_2;
        label_4:
        // 0x00B8F690: LDR x0, [x23]              | X0 = this.audioSource;                  
        // 0x00B8F694: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F698: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F69C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8F6A0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00B8F6A4: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x00B8F6A8: RET                        |  return (UnityEngine.AudioSource)this.audioSource;
        return null;
        //  |  // // {name=val_0, type=UnityEngine.AudioSource, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F6AC (12121772), len: 184  VirtAddr: 0x00B8F6AC RVA: 0x00B8F6AC token: 100694059 methodIndex: 25121 delegateWrapperIndex: 0 methodInvoker: 0
    public override void RePlay()
    {
        //
        // Disasemble & Code
        // 0x00B8F6AC: STP x20, x19, [sp, #-0x20]! | stack[1152921515101976224] = ???;  stack[1152921515101976232] = ???;  //  dest_result_addr=1152921515101976224 |  dest_result_addr=1152921515101976232
        // 0x00B8F6B0: STP x29, x30, [sp, #0x10]  | stack[1152921515101976240] = ???;  stack[1152921515101976248] = ???;  //  dest_result_addr=1152921515101976240 |  dest_result_addr=1152921515101976248
        // 0x00B8F6B4: ADD x29, sp, #0x10         | X29 = (1152921515101976224 + 16) = 1152921515101976240 (0x10000002718EF6B0);
        // 0x00B8F6B8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8F6BC: LDRB w8, [x20, #0xa2f]     | W8 = (bool)static_value_03733A2F;       
        // 0x00B8F6C0: MOV x19, x0                | X19 = 1152921515101988256 (0x10000002718F25A0);//ML01
        // 0x00B8F6C4: TBNZ w8, #0, #0xb8f6e0     | if (static_value_03733A2F == true) goto label_0;
        // 0x00B8F6C8: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
        // 0x00B8F6CC: LDR x8, [x8, #0xdd0]       | X8 = 0x2B8F378;                         
        // 0x00B8F6D0: LDR w0, [x8]               | W0 = 0x13A0;                            
        // 0x00B8F6D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A0, ????);     
        // 0x00B8F6D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F6DC: STRB w8, [x20, #0xa2f]     | static_value_03733A2F = true;            //  dest_result_addr=57883183
        label_0:
        // 0x00B8F6E0: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F6E4: CBNZ x20, #0xb8f6ec        | if (this.audioSource != null) goto label_1;
        if(this.audioSource != null)
        {
            goto label_1;
        }
        // 0x00B8F6E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A0, ????);     
        label_1:
        // 0x00B8F6EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F6F0: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F6F4: BL #0x2751780              | X0 = this.audioSource.get_clip();       
        UnityEngine.AudioClip val_1 = this.audioSource.clip;
        // 0x00B8F6F8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B8F6FC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B8F700: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8F704: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B8F708: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B8F70C: TBZ w9, #0, #0xb8f720      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B8F710: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B8F714: CBNZ w9, #0xb8f720         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B8F718: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B8F71C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B8F720: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F724: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F728: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B8F72C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8F730: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        // 0x00B8F734: TBZ w0, #0, #0xb8f758      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B8F738: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F73C: CBNZ x20, #0xb8f744        | if (this.audioSource != null) goto label_5;
        if(this.audioSource != null)
        {
            goto label_5;
        }
        // 0x00B8F740: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B8F744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F748: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F74C: BL #0x2751e04              | this.audioSource.Play();                
        this.audioSource.Play();
        // 0x00B8F750: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F754: STRB w8, [x19, #0x24]      | this.isPlaying = true;                   //  dest_result_addr=1152921515101988292
        this.isPlaying = true;
        label_4:
        // 0x00B8F758: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F75C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F760: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F764 (12121956), len: 204  VirtAddr: 0x00B8F764 RVA: 0x00B8F764 token: 100694060 methodIndex: 25122 delegateWrapperIndex: 0 methodInvoker: 0
    public override void SetPitch(float pitch, int id)
    {
        //
        // Disasemble & Code
        // 0x00B8F764: STP d9, d8, [sp, #-0x30]!  | stack[1152921515102112784] = ???;  stack[1152921515102112792] = ???;  //  dest_result_addr=1152921515102112784 |  dest_result_addr=1152921515102112792
        // 0x00B8F768: STP x20, x19, [sp, #0x10]  | stack[1152921515102112800] = ???;  stack[1152921515102112808] = ???;  //  dest_result_addr=1152921515102112800 |  dest_result_addr=1152921515102112808
        // 0x00B8F76C: STP x29, x30, [sp, #0x20]  | stack[1152921515102112816] = ???;  stack[1152921515102112824] = ???;  //  dest_result_addr=1152921515102112816 |  dest_result_addr=1152921515102112824
        // 0x00B8F770: ADD x29, sp, #0x20         | X29 = (1152921515102112784 + 32) = 1152921515102112816 (0x1000000271910C30);
        // 0x00B8F774: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8F778: LDRB w8, [x20, #0xa30]     | W8 = (bool)static_value_03733A30;       
        // 0x00B8F77C: MOV v8.16b, v0.16b         | V8 = pitch;//m1                         
        // 0x00B8F780: MOV x19, x0                | X19 = 1152921515102124832 (0x1000000271913B20);//ML01
        // 0x00B8F784: TBNZ w8, #0, #0xb8f7a0     | if (static_value_03733A30 == true) goto label_0;
        // 0x00B8F788: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00B8F78C: LDR x8, [x8, #0x6d0]       | X8 = 0x2B8F37C;                         
        // 0x00B8F790: LDR w0, [x8]               | W0 = 0x13A1;                            
        // 0x00B8F794: BL #0x2782188              | X0 = sub_2782188( ?? 0x13A1, ????);     
        // 0x00B8F798: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8F79C: STRB w8, [x20, #0xa30]     | static_value_03733A30 = true;            //  dest_result_addr=57883184
        label_0:
        // 0x00B8F7A0: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F7A4: CBNZ x20, #0xb8f7ac        | if (this.audioSource != null) goto label_1;
        if(this.audioSource != null)
        {
            goto label_1;
        }
        // 0x00B8F7A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x13A1, ????);     
        label_1:
        // 0x00B8F7AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F7B0: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F7B4: BL #0x2751780              | X0 = this.audioSource.get_clip();       
        UnityEngine.AudioClip val_1 = this.audioSource.clip;
        // 0x00B8F7B8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B8F7BC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B8F7C0: MOV x20, x0                | X20 = val_1;//m1                        
        // 0x00B8F7C4: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B8F7C8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B8F7CC: TBZ w9, #0, #0xb8f7e0      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B8F7D0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B8F7D4: CBNZ w9, #0xb8f7e0         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B8F7D8: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B8F7DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_3:
        // 0x00B8F7E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F7E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F7E8: MOV x1, x20                | X1 = val_1;//m1                         
        // 0x00B8F7EC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B8F7F0: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  val_1);
        // 0x00B8F7F4: TBZ w0, #0, #0xb8f820      | if (val_2 == false) goto label_4;       
        if(val_2 == false)
        {
            goto label_4;
        }
        // 0x00B8F7F8: LDR x19, [x19, #0x18]      | X19 = this.audioSource; //P2            
        // 0x00B8F7FC: CBNZ x19, #0xb8f804        | if (this.audioSource != null) goto label_5;
        if(this.audioSource != null)
        {
            goto label_5;
        }
        // 0x00B8F800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_5:
        // 0x00B8F804: MOV x0, x19                | X0 = this.audioSource;//m1              
        // 0x00B8F808: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F80C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F810: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F814: MOV v0.16b, v8.16b         | V0 = pitch;//m1                         
        // 0x00B8F818: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8F81C: B #0x27519fc               | this.audioSource.set_pitch(value:  pitch); return;
        this.audioSource.pitch = pitch;
        return;
        label_4:
        // 0x00B8F820: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F824: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F828: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8F82C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F830 (12122160), len: 56  VirtAddr: 0x00B8F830 RVA: 0x00B8F830 token: 100694061 methodIndex: 25123 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Stop()
    {
        //
        // Disasemble & Code
        // 0x00B8F830: STP x20, x19, [sp, #-0x20]! | stack[1152921515102241184] = ???;  stack[1152921515102241192] = ???;  //  dest_result_addr=1152921515102241184 |  dest_result_addr=1152921515102241192
        // 0x00B8F834: STP x29, x30, [sp, #0x10]  | stack[1152921515102241200] = ???;  stack[1152921515102241208] = ???;  //  dest_result_addr=1152921515102241200 |  dest_result_addr=1152921515102241208
        // 0x00B8F838: ADD x29, sp, #0x10         | X29 = (1152921515102241184 + 16) = 1152921515102241200 (0x10000002719301B0);
        // 0x00B8F83C: MOV x19, x0                | X19 = 1152921515102253216 (0x10000002719330A0);//ML01
        // 0x00B8F840: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F844: CBNZ x20, #0xb8f84c        | if (this.audioSource != null) goto label_0;
        if(this.audioSource != null)
        {
            goto label_0;
        }
        // 0x00B8F848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B8F84C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F850: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F854: BL #0x2751fec              | this.audioSource.Stop();                
        this.audioSource.Stop();
        // 0x00B8F858: STRB wzr, [x19, #0x24]     | this.isPlaying = false;                  //  dest_result_addr=1152921515102253252
        this.isPlaying = false;
        // 0x00B8F85C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F860: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F864: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F868 (12122216), len: 56  VirtAddr: 0x00B8F868 RVA: 0x00B8F868 token: 100694062 methodIndex: 25124 delegateWrapperIndex: 0 methodInvoker: 0
    public override void StopByID(int id)
    {
        //
        // Disasemble & Code
        // 0x00B8F868: STP x20, x19, [sp, #-0x20]! | stack[1152921515102361376] = ???;  stack[1152921515102361384] = ???;  //  dest_result_addr=1152921515102361376 |  dest_result_addr=1152921515102361384
        // 0x00B8F86C: STP x29, x30, [sp, #0x10]  | stack[1152921515102361392] = ???;  stack[1152921515102361400] = ???;  //  dest_result_addr=1152921515102361392 |  dest_result_addr=1152921515102361400
        // 0x00B8F870: ADD x29, sp, #0x10         | X29 = (1152921515102361376 + 16) = 1152921515102361392 (0x100000027194D730);
        // 0x00B8F874: MOV x19, x0                | X19 = 1152921515102373408 (0x1000000271950620);//ML01
        // 0x00B8F878: LDR x20, [x19, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F87C: CBNZ x20, #0xb8f884        | if (this.audioSource != null) goto label_0;
        if(this.audioSource != null)
        {
            goto label_0;
        }
        // 0x00B8F880: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B8F884: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F888: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F88C: BL #0x2751fec              | this.audioSource.Stop();                
        this.audioSource.Stop();
        // 0x00B8F890: STRB wzr, [x19, #0x24]     | this.isPlaying = false;                  //  dest_result_addr=1152921515102373444
        this.isPlaying = false;
        // 0x00B8F894: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F898: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F89C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F8A0 (12122272), len: 4  VirtAddr: 0x00B8F8A0 RVA: 0x00B8F8A0 token: 100694063 methodIndex: 25125 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Update()
    {
        //
        // Disasemble & Code
        // 0x00B8F8A0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F8A4 (12122276), len: 8  VirtAddr: 0x00B8F8A4 RVA: 0x00B8F8A4 token: 100694064 methodIndex: 25126 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool get_mute()
    {
        //
        // Disasemble & Code
        // 0x00B8F8A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F8A8: B #0x17b7f84               | return this.get_mute();                 
        return this.mute;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F8AC (12122284), len: 68  VirtAddr: 0x00B8F8AC RVA: 0x00B8F8AC token: 100694065 methodIndex: 25127 delegateWrapperIndex: 0 methodInvoker: 0
    public override void set_mute(bool value)
    {
        //
        // Disasemble & Code
        // 0x00B8F8AC: STP x20, x19, [sp, #-0x20]! | stack[1152921515102705568] = ???;  stack[1152921515102705576] = ???;  //  dest_result_addr=1152921515102705568 |  dest_result_addr=1152921515102705576
        // 0x00B8F8B0: STP x29, x30, [sp, #0x10]  | stack[1152921515102705584] = ???;  stack[1152921515102705592] = ???;  //  dest_result_addr=1152921515102705584 |  dest_result_addr=1152921515102705592
        // 0x00B8F8B4: ADD x29, sp, #0x10         | X29 = (1152921515102705568 + 16) = 1152921515102705584 (0x10000002719A17B0);
        // 0x00B8F8B8: AND w19, w1, #1            | W19 = (value & 1);                      
        bool val_1 = value;
        // 0x00B8F8BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F8C0: MOV w1, w19                | W1 = (value & 1);//m1                   
        // 0x00B8F8C4: MOV x20, x0                | X20 = 1152921515102717600 (0x10000002719A46A0);//ML01
        // 0x00B8F8C8: BL #0x17b7f8c              | this.set_mute(value:  val_1);           
        this.mute = val_1;
        // 0x00B8F8CC: LDR x20, [x20, #0x18]      | X20 = this.audioSource; //P2            
        // 0x00B8F8D0: CBNZ x20, #0xb8f8d8        | if (this.audioSource != null) goto label_0;
        if(this.audioSource != null)
        {
            goto label_0;
        }
        // 0x00B8F8D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B8F8D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F8DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8F8E0: MOV x0, x20                | X0 = this.audioSource;//m1              
        // 0x00B8F8E4: MOV w1, w19                | W1 = (value & 1);//m1                   
        // 0x00B8F8E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F8EC: B #0x2753644               | this.audioSource.set_mute(value:  val_1); return;
        this.audioSource.mute = val_1;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F8F0 (12122352), len: 8  VirtAddr: 0x00B8F8F0 RVA: 0x00B8F8F0 token: 100694066 methodIndex: 25128 delegateWrapperIndex: 0 methodInvoker: 0
    public override float get_volume()
    {
        //
        // Disasemble & Code
        // 0x00B8F8F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F8F4: B #0x17b7f98               | return this.get_volume();               
        return this.volume;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F8F8 (12122360), len: 72  VirtAddr: 0x00B8F8F8 RVA: 0x00B8F8F8 token: 100694067 methodIndex: 25129 delegateWrapperIndex: 0 methodInvoker: 0
    public override void set_volume(float value)
    {
        //
        // Disasemble & Code
        // 0x00B8F8F8: STP d9, d8, [sp, #-0x30]!  | stack[1152921515102937744] = ???;  stack[1152921515102937752] = ???;  //  dest_result_addr=1152921515102937744 |  dest_result_addr=1152921515102937752
        // 0x00B8F8FC: STP x20, x19, [sp, #0x10]  | stack[1152921515102937760] = ???;  stack[1152921515102937768] = ???;  //  dest_result_addr=1152921515102937760 |  dest_result_addr=1152921515102937768
        // 0x00B8F900: STP x29, x30, [sp, #0x20]  | stack[1152921515102937776] = ???;  stack[1152921515102937784] = ???;  //  dest_result_addr=1152921515102937776 |  dest_result_addr=1152921515102937784
        // 0x00B8F904: ADD x29, sp, #0x20         | X29 = (1152921515102937744 + 32) = 1152921515102937776 (0x10000002719DA2B0);
        // 0x00B8F908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F90C: MOV v8.16b, v0.16b         | V8 = value;//m1                         
        // 0x00B8F910: MOV x19, x0                | X19 = 1152921515102949792 (0x10000002719DD1A0);//ML01
        // 0x00B8F914: BL #0x17b7fa0              | this.set_volume(value:  value);         
        this.volume = value;
        // 0x00B8F918: LDR x19, [x19, #0x18]      | X19 = this.audioSource; //P2            
        // 0x00B8F91C: CBNZ x19, #0xb8f924        | if (this.audioSource != null) goto label_0;
        if(this.audioSource != null)
        {
            goto label_0;
        }
        // 0x00B8F920: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B8F924: MOV x0, x19                | X0 = this.audioSource;//m1              
        // 0x00B8F928: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F92C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F934: MOV v0.16b, v8.16b         | V0 = value;//m1                         
        // 0x00B8F938: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
        // 0x00B8F93C: B #0x275191c               | this.audioSource.set_volume(value:  value); return;
        this.audioSource.volume = value;
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8F940 (12122432), len: 4  VirtAddr: 0x00B8F940 RVA: 0x00B8F940 token: 100694068 methodIndex: 25130 delegateWrapperIndex: 0 methodInvoker: 0
    public override void StopLoopSound()
    {
        //
        // Disasemble & Code
        // 0x00B8F940: RET                        |  return;                                
        return;
    
    }

}
