using UnityEngine;
[Serializable]
public class BMSymbol
{
    // Fields
    public string sequence; //  0x00000010
    public string spriteName; //  0x00000018
    private UISpriteData mSprite; //  0x00000020
    private bool mIsValid; //  0x00000028
    private int mLength; //  0x0000002C
    private int mOffsetX; //  0x00000030
    private int mOffsetY; //  0x00000034
    private int mWidth; //  0x00000038
    private int mHeight; //  0x0000003C
    private int mAdvance; //  0x00000040
    private UnityEngine.Rect mUV; //  0x00000044
    
    // Properties
    public int length { get; }
    public int offsetX { get; }
    public int offsetY { get; }
    public int width { get; }
    public int height { get; }
    public int advance { get; }
    public UnityEngine.Rect uvRect { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B929E8 (12134888), len: 8  VirtAddr: 0x00B929E8 RVA: 0x00B929E8 token: 100687890 methodIndex: 25190 delegateWrapperIndex: 0 methodInvoker: 0
    public BMSymbol()
    {
        //
        // Disasemble & Code
        // 0x00B929E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B929EC: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B929F0 (12134896), len: 64  VirtAddr: 0x00B929F0 RVA: 0x00B929F0 token: 100687891 methodIndex: 25191 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_length()
    {
        //
        // Disasemble & Code
        //  | 
        int val_2;
        // 0x00B929F0: STP x20, x19, [sp, #-0x20]! | stack[1152921514158363568] = ???;  stack[1152921514158363576] = ???;  //  dest_result_addr=1152921514158363568 |  dest_result_addr=1152921514158363576
        // 0x00B929F4: STP x29, x30, [sp, #0x10]  | stack[1152921514158363584] = ???;  stack[1152921514158363592] = ???;  //  dest_result_addr=1152921514158363584 |  dest_result_addr=1152921514158363592
        // 0x00B929F8: ADD x29, sp, #0x10         | X29 = (1152921514158363568 + 16) = 1152921514158363584 (0x10000002395093C0);
        // 0x00B929FC: MOV x19, x0                | X19 = 1152921514158375600 (0x100000023950C2B0);//ML01
        // 0x00B92A00: LDR w0, [x19, #0x2c]       | W0 = this.mLength; //P2                 
        val_2 = this.mLength;
        // 0x00B92A04: CBNZ w0, #0xb92a24         | if (this.mLength != 0) goto label_0;    
        if(val_2 != 0)
        {
            goto label_0;
        }
        // 0x00B92A08: LDR x20, [x19, #0x10]      | X20 = this.sequence; //P2               
        // 0x00B92A0C: CBNZ x20, #0xb92a14        | if (this.sequence != null) goto label_1;
        if(this.sequence != null)
        {
            goto label_1;
        }
        // 0x00B92A10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.mLength, ????);
        label_1:
        // 0x00B92A14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92A18: MOV x0, x20                | X0 = this.sequence;//m1                 
        val_2 = this.sequence;
        // 0x00B92A1C: BL #0x18a4460              | X0 = this.sequence.get_Length();        
        int val_1 = val_2.Length;
        // 0x00B92A20: STR w0, [x19, #0x2c]       | this.mLength = val_1;                    //  dest_result_addr=1152921514158375644
        this.mLength = val_1;
        label_0:
        // 0x00B92A24: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92A28: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B92A2C: RET                        |  return (System.Int32)val_1;            
        return val_1;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A30 (12134960), len: 8  VirtAddr: 0x00B92A30 RVA: 0x00B92A30 token: 100687892 methodIndex: 25192 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_offsetX()
    {
        //
        // Disasemble & Code
        // 0x00B92A30: LDR w0, [x0, #0x30]        | W0 = this.mOffsetX; //P2                
        // 0x00B92A34: RET                        |  return (System.Int32)this.mOffsetX;    
        return this.mOffsetX;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A38 (12134968), len: 8  VirtAddr: 0x00B92A38 RVA: 0x00B92A38 token: 100687893 methodIndex: 25193 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_offsetY()
    {
        //
        // Disasemble & Code
        // 0x00B92A38: LDR w0, [x0, #0x34]        | W0 = this.mOffsetY; //P2                
        // 0x00B92A3C: RET                        |  return (System.Int32)this.mOffsetY;    
        return this.mOffsetY;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A40 (12134976), len: 8  VirtAddr: 0x00B92A40 RVA: 0x00B92A40 token: 100687894 methodIndex: 25194 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_width()
    {
        //
        // Disasemble & Code
        // 0x00B92A40: LDR w0, [x0, #0x38]        | W0 = this.mWidth; //P2                  
        // 0x00B92A44: RET                        |  return (System.Int32)this.mWidth;      
        return this.mWidth;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A48 (12134984), len: 8  VirtAddr: 0x00B92A48 RVA: 0x00B92A48 token: 100687895 methodIndex: 25195 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_height()
    {
        //
        // Disasemble & Code
        // 0x00B92A48: LDR w0, [x0, #0x3c]        | W0 = this.mHeight; //P2                 
        // 0x00B92A4C: RET                        |  return (System.Int32)this.mHeight;     
        return this.mHeight;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A50 (12134992), len: 8  VirtAddr: 0x00B92A50 RVA: 0x00B92A50 token: 100687896 methodIndex: 25196 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_advance()
    {
        //
        // Disasemble & Code
        // 0x00B92A50: LDR w0, [x0, #0x40]        | W0 = this.mAdvance; //P2                
        // 0x00B92A54: RET                        |  return (System.Int32)this.mAdvance;    
        return this.mAdvance;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A58 (12135000), len: 12  VirtAddr: 0x00B92A58 RVA: 0x00B92A58 token: 100687897 methodIndex: 25197 delegateWrapperIndex: 0 methodInvoker: 0
    public UnityEngine.Rect get_uvRect()
    {
        //
        // Disasemble & Code
        // 0x00B92A58: LDP s0, s1, [x0, #0x44]    | S0 = this.mUV; //P2                      //  | 
        // 0x00B92A5C: LDP s2, s3, [x0, #0x4c]    |                                          //  | 
        // 0x00B92A60: RET                        |  return new UnityEngine.Rect() {m_XMin = this.mUV};
        return new UnityEngine.Rect() {m_XMin = this.mUV};
        //  |  // // {name=val_0.m_XMin, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.m_YMin, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.m_Width, type=System.Single, size=4, nSRN=2 }
        //  |  // // {name=val_0.m_Height, type=System.Single, size=4, nSRN=3 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A64 (12135012), len: 8  VirtAddr: 0x00B92A64 RVA: 0x00B92A64 token: 100687898 methodIndex: 25198 delegateWrapperIndex: 0 methodInvoker: 0
    public void MarkAsChanged()
    {
        //
        // Disasemble & Code
        // 0x00B92A64: STRB wzr, [x0, #0x28]      | this.mIsValid = false;                   //  dest_result_addr=1152921514159163736
        this.mIsValid = false;
        // 0x00B92A68: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B92A6C (12135020), len: 904  VirtAddr: 0x00B92A6C RVA: 0x00B92A6C token: 100687899 methodIndex: 25199 delegateWrapperIndex: 0 methodInvoker: 0
    public bool Validate(UIAtlas atlas)
    {
        //
        // Disasemble & Code
        //  | 
        string val_11;
        //  | 
        var val_12;
        //  | 
        UISpriteData val_13;
        //  | 
        UnityEngine.Object val_14;
        //  | 
        var val_15;
        //  | 
        UISpriteData val_16;
        //  | 
        var val_17;
        //  | 
        UISpriteData val_18;
        //  | 
        UISpriteData val_19;
        // 0x00B92A6C: STP d11, d10, [sp, #-0x60]! | stack[1152921514159304560] = ???;  stack[1152921514159304568] = ???;  //  dest_result_addr=1152921514159304560 |  dest_result_addr=1152921514159304568
        // 0x00B92A70: STP d9, d8, [sp, #0x10]    | stack[1152921514159304576] = ???;  stack[1152921514159304584] = ???;  //  dest_result_addr=1152921514159304576 |  dest_result_addr=1152921514159304584
        // 0x00B92A74: STP x24, x23, [sp, #0x20]  | stack[1152921514159304592] = ???;  stack[1152921514159304600] = ???;  //  dest_result_addr=1152921514159304592 |  dest_result_addr=1152921514159304600
        // 0x00B92A78: STP x22, x21, [sp, #0x30]  | stack[1152921514159304608] = ???;  stack[1152921514159304616] = ???;  //  dest_result_addr=1152921514159304608 |  dest_result_addr=1152921514159304616
        // 0x00B92A7C: STP x20, x19, [sp, #0x40]  | stack[1152921514159304624] = ???;  stack[1152921514159304632] = ???;  //  dest_result_addr=1152921514159304624 |  dest_result_addr=1152921514159304632
        // 0x00B92A80: STP x29, x30, [sp, #0x50]  | stack[1152921514159304640] = ???;  stack[1152921514159304648] = ???;  //  dest_result_addr=1152921514159304640 |  dest_result_addr=1152921514159304648
        // 0x00B92A84: ADD x29, sp, #0x50         | X29 = (1152921514159304560 + 80) = 1152921514159304640 (0x10000002395EEFC0);
        // 0x00B92A88: SUB sp, sp, #0x10          | SP = (1152921514159304560 - 16) = 1152921514159304544 (0x10000002395EEF60);
        // 0x00B92A8C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B92A90: LDRB w8, [x21, #0xa4e]     | W8 = (bool)static_value_03733A4E;       
        // 0x00B92A94: MOV x20, x1                | X20 = atlas;//m1                        
        // 0x00B92A98: MOV x19, x0                | X19 = 1152921514159316656 (0x10000002395F1EB0);//ML01
        // 0x00B92A9C: TBNZ w8, #0, #0xb92ab8     | if (static_value_03733A4E == true) goto label_0;
        // 0x00B92AA0: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
        // 0x00B92AA4: LDR x8, [x8, #0xc38]       | X8 = 0x2B8F814;                         
        // 0x00B92AA8: LDR w0, [x8]               | W0 = 0x14C9;                            
        // 0x00B92AAC: BL #0x2782188              | X0 = sub_2782188( ?? 0x14C9, ????);     
        // 0x00B92AB0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B92AB4: STRB w8, [x21, #0xa4e]     | static_value_03733A4E = true;            //  dest_result_addr=57883214
        label_0:
        // 0x00B92AB8: ADRP x23, #0x35fe000       | X23 = 56614912 (0x35FE000);             
        // 0x00B92ABC: LDR x23, [x23, #0x810]     | X23 = 1152921504697475072;              
        // 0x00B92AC0: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B92AC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B92AC8: TBZ w8, #0, #0xb92ad8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B92ACC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B92AD0: CBNZ w8, #0xb92ad8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B92AD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B92AD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92ADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92AE0: MOV x1, x20                | X1 = atlas;//m1                         
        // 0x00B92AE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B92AE8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  atlas);
        bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  atlas);
        // 0x00B92AEC: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B92AF0: TBNZ w8, #0, #0xb92b4c     | if ((val_1 & 1) == true) goto label_3;  
        if(val_2 == true)
        {
            goto label_3;
        }
        // 0x00B92AF4: LDRB w8, [x19, #0x28]      | W8 = this.mIsValid; //P2                
        // 0x00B92AF8: CBZ w8, #0xb92b10          | if (this.mIsValid == false) goto label_4;
        if(this.mIsValid == false)
        {
            goto label_4;
        }
        // 0x00B92AFC: ADD x22, x19, #0x20        | X22 = this.mSprite;//AP2 res_addr=1152921514159316688
        label_28:
        // 0x00B92B00: LDR x8, [x22]              |  //  not_find_field!1:0
        // 0x00B92B04: CMP x8, #0                 | STATE = COMPARE(mem[this.mSprite], 0x0) 
        // 0x00B92B08: CSET w0, ne                | W0 = mem[this.mSprite] != 0x0 ? 1 : 0;  
        var val_3 = (mem[this.mSprite] != 0) ? 1 : 0;
        // 0x00B92B0C: B #0xb92b50                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00B92B10: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00B92B14: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
        // 0x00B92B18: LDR x21, [x19, #0x18]      | X21 = this.spriteName; //P2             
        val_11 = this.spriteName;
        // 0x00B92B1C: LDR x0, [x8]               | X0 = typeof(System.String);             
        // 0x00B92B20: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
        // 0x00B92B24: TBZ w8, #0, #0xb92b34      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_7;
        // 0x00B92B28: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
        // 0x00B92B2C: CBNZ w8, #0xb92b34         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
        // 0x00B92B30: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
        label_7:
        // 0x00B92B34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92B38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92B3C: MOV x1, x21                | X1 = this.spriteName;//m1               
        // 0x00B92B40: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
        bool val_4 = System.String.IsNullOrEmpty(value:  0);
        // 0x00B92B44: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x00B92B48: TBZ w8, #0, #0xb92b70      | if ((val_4 & 1) == false) goto label_8; 
        if(val_5 == false)
        {
            goto label_8;
        }
        label_3:
        // 0x00B92B4C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_12 = 0;
        label_5:
        // 0x00B92B50: SUB sp, x29, #0x50         | SP = (1152921514159304640 - 80) = 1152921514159304560 (0x10000002395EEF70);
        // 0x00B92B54: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B92B58: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B92B5C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B92B60: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B92B64: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B92B68: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00B92B6C: RET                        |  return (System.Boolean)false;          
        return (bool)val_12;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        label_8:
        // 0x00B92B70: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B92B74: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B92B78: TBZ w8, #0, #0xb92b88      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B92B7C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B92B80: CBNZ w8, #0xb92b88         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B92B84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_10:
        // 0x00B92B88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92B8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92B90: MOV x1, x20                | X1 = atlas;//m1                         
        // 0x00B92B94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B92B98: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  atlas);
        bool val_6 = UnityEngine.Object.op_Inequality(x:  0, y:  atlas);
        // 0x00B92B9C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_13 = 0;
        // 0x00B92BA0: TBZ w0, #0, #0xb92bc4      | if (val_6 == false) goto label_11;      
        if(val_6 == false)
        {
            goto label_11;
        }
        // 0x00B92BA4: LDR x21, [x19, #0x18]      | X21 = this.spriteName; //P2             
        // 0x00B92BA8: CBNZ x20, #0xb92bb0        | if (atlas != null) goto label_12;       
        if(atlas != null)
        {
            goto label_12;
        }
        // 0x00B92BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_12:
        // 0x00B92BB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92BB4: MOV x0, x20                | X0 = atlas;//m1                         
        // 0x00B92BB8: MOV x1, x21                | X1 = this.spriteName;//m1               
        // 0x00B92BBC: BL #0xdfc6ac               | X0 = atlas.GetSprite(name:  this.spriteName);
        UISpriteData val_7 = atlas.GetSprite(name:  this.spriteName);
        // 0x00B92BC0: MOV x21, x0                | X21 = val_7;//m1                        
        val_13 = val_7;
        label_11:
        // 0x00B92BC4: CBNZ x19, #0xb92bcc        | if (this != null) goto label_13;        
        if(this != null)
        {
            goto label_13;
        }
        // 0x00B92BC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_13:
        // 0x00B92BCC: MOV x22, x19               | X22 = 1152921514159316656 (0x10000002395F1EB0);//ML01
        // 0x00B92BD0: STR x21, [x22, #0x20]!     | this.mSprite = val_7;                    //  dest_result_addr=1152921514159316688
        this.mSprite = val_13;
        // 0x00B92BD4: CBZ x21, #0xb92b00         | if (val_7 == null) goto label_28;       
        if(val_13 == null)
        {
            goto label_28;
        }
        // 0x00B92BD8: CBNZ x20, #0xb92be0        | if (atlas != null) goto label_15;       
        if(atlas != null)
        {
            goto label_15;
        }
        // 0x00B92BDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_15:
        // 0x00B92BE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92BE4: MOV x0, x20                | X0 = atlas;//m1                         
        // 0x00B92BE8: BL #0xdfc210               | X0 = atlas.get_texture();               
        UnityEngine.Texture val_8 = atlas.texture;
        // 0x00B92BEC: LDR x8, [x23]              | X8 = typeof(UnityEngine.Object);        
        // 0x00B92BF0: MOV x20, x0                | X20 = val_8;//m1                        
        val_14 = val_8;
        // 0x00B92BF4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B92BF8: TBZ w9, #0, #0xb92c0c      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B92BFC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B92C00: CBNZ w9, #0xb92c0c         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B92C04: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B92C08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_17:
        // 0x00B92C0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92C10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B92C14: MOV x1, x20                | X1 = val_8;//m1                         
        // 0x00B92C18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B92C1C: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  val_14);
        bool val_9 = UnityEngine.Object.op_Equality(x:  0, y:  val_14);
        // 0x00B92C20: TBZ w0, #0, #0xb92c2c      | if (val_9 == false) goto label_18;      
        if(val_9 == false)
        {
            goto label_18;
        }
        // 0x00B92C24: STR xzr, [x22]             | this.mSprite = null;                     //  dest_result_addr=1152921514159316688
        this.mSprite = 0;
        // 0x00B92C28: B #0xb92b00                |  goto label_28;                         
        goto label_28;
        label_18:
        // 0x00B92C2C: LDR x23, [x22]             | X23 = null;                             
        val_16 = this.mSprite;
        // 0x00B92C30: CBZ x23, #0xb92c3c         | if (null == null) goto label_20;        
        if(val_16 == null)
        {
            goto label_20;
        }
        // 0x00B92C34: LDR w21, [x23, #0x18]      | W21 = 0x9814C0;                         
        val_17 = 9966784;
        // 0x00B92C38: B #0xb92c50                |  goto label_21;                         
        goto label_21;
        label_20:
        // 0x00B92C3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92C40: LDR x24, [x22]             | X24 = null;                             
        // 0x00B92C44: LDR w21, [x23, #0x18]      | W21 = 0x9814C0;                         
        val_17 = 9966784;
        // 0x00B92C48: CBZ x24, #0xb92d70         | if (null == null) goto label_22;        
        if(this.mSprite == null)
        {
            goto label_22;
        }
        // 0x00B92C4C: MOV x23, x24               | X23 = 0 (0x0);//ML01                    
        val_16 = this.mSprite;
        label_21:
        // 0x00B92C50: LDR w24, [x23, #0x1c]      | W24 = 0x0;                              
        label_29:
        // 0x00B92C54: MOV x8, x23                | X8 = 0 (0x0);//ML01                     
        label_30:
        // 0x00B92C58: LDR s2, [x23, #0x20]       | S2 = 8.96831E-44;                       
        // 0x00B92C5C: LDR s3, [x8, #0x24]        | S3 = 0;                                 
        // 0x00B92C60: SCVTF s0, w21              | S0 = 9966784;                           
        // 0x00B92C64: SCVTF s1, w24              | S1 = 0;                                 
        // 0x00B92C68: SCVTF s2, s2               | S2 = 64;                                
        // 0x00B92C6C: SCVTF s3, s3               | S3 = 0;                                 
        // 0x00B92C70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B92C74: MOV x0, sp                 | X0 = 1152921514159304544 (0x10000002395EEF60);//ML01
        // 0x00B92C78: STP xzr, xzr, [sp]         | stack[1152921514159304544] = 0x0;  stack[1152921514159304552] = 0x0;  //  dest_result_addr=1152921514159304544 |  dest_result_addr=1152921514159304552
        // 0x00B92C7C: BL #0x1b815e4              | X0 = label_UnityEngine_Ray2D_ToString_GL01B815E4();
        // 0x00B92C80: LDP w8, w9, [sp]           | W8 = 0x0; W9 = 0x0;                      //  | 
        // 0x00B92C84: LDR w10, [sp, #8]          | W10 = 0x0;                              
        // 0x00B92C88: LDR s8, [sp, #0xc]         | S8 = 0;                                 
        // 0x00B92C8C: FMOV s9, w8                | S9 = 0f;                                
        // 0x00B92C90: FMOV s10, w9               | S10 = 0f;                               
        // 0x00B92C94: FMOV s11, w10              | S11 = 0f;                               
        // 0x00B92C98: STP w8, w9, [x19, #0x44]   | this.mUV = new UnityEngine.Rect();  mem[1152921514159316728] = 0x0;  //  dest_result_addr=1152921514159316724 |  dest_result_addr=1152921514159316728
        this.mUV = 0;
        mem[1152921514159316728] = 0;
        // 0x00B92C9C: STR w10, [x19, #0x4c]      | mem[1152921514159316732] = 0x0;          //  dest_result_addr=1152921514159316732
        mem[1152921514159316732] = 0;
        // 0x00B92CA0: STR s8, [x19, #0x50]       | mem[1152921514159316736] = 0x0;          //  dest_result_addr=1152921514159316736
        mem[1152921514159316736] = 0f;
        // 0x00B92CA4: CBNZ x20, #0xb92cac        | if (val_8 != null) goto label_23;       
        if(val_14 != null)
        {
            goto label_23;
        }
        // 0x00B92CA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002395EEF60, ????);
        label_23:
        // 0x00B92CAC: LDR x8, [x20]              | X8 = typeof(UnityEngine.Texture);       
        // 0x00B92CB0: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B92CB4: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.Texture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.Texture).__il2cppRuntimeField_158; //  | 
        // 0x00B92CB8: BLR x9                     | X0 = typeof(UnityEngine.Texture).__il2cppRuntimeField_150();
        // 0x00B92CBC: MOV w21, w0                | W21 = val_8;//m1                        
        // 0x00B92CC0: CBNZ x20, #0xb92cc8        | if (val_8 != null) goto label_24;       
        if(val_14 != null)
        {
            goto label_24;
        }
        // 0x00B92CC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_24:
        // 0x00B92CC8: LDR x8, [x20]              | X8 = typeof(UnityEngine.Texture);       
        // 0x00B92CCC: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B92CD0: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.Texture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.Texture).__il2cppRuntimeField_178; //  | 
        // 0x00B92CD4: BLR x9                     | X0 = typeof(UnityEngine.Texture).__il2cppRuntimeField_170();
        // 0x00B92CD8: MOV w2, w0                 | W2 = val_8;//m1                         
        // 0x00B92CDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B92CE0: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x00B92CE4: MOV v0.16b, v9.16b         | V0 = 0;//m1                             
        // 0x00B92CE8: MOV v1.16b, v10.16b        | V1 = 0;//m1                             
        // 0x00B92CEC: MOV v2.16b, v11.16b        | V2 = 0;//m1                             
        // 0x00B92CF0: MOV v3.16b, v8.16b         | V3 = 0 (0x0);//ML01                     
        // 0x00B92CF4: MOV w1, w21                | W1 = val_8;//m1                         
        // 0x00B92CF8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B92CFC: BL #0x2920c08              | X0 = NGUIMath.ConvertToTexCoords(rect:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, width:  0, height:  val_14, isConvert:  val_14);
        UnityEngine.Rect val_10 = NGUIMath.ConvertToTexCoords(rect:  new UnityEngine.Rect() {m_XMin = 0f, m_YMin = 0f, m_Width = 0f, m_Height = 0f}, width:  0, height:  val_14, isConvert:  val_14);
        // 0x00B92D00: STP s0, s1, [x19, #0x44]   | this.mUV = val_10;  mem[1152921514159316728] = val_10.m_YMin;  //  dest_result_addr=1152921514159316724 |  dest_result_addr=1152921514159316728
        this.mUV = val_10;
        mem[1152921514159316728] = val_10.m_YMin;
        // 0x00B92D04: LDR x20, [x19, #0x20]      | X20 = this.mSprite; //P2                
        val_18 = this.mSprite;
        // 0x00B92D08: STP s2, s3, [x19, #0x4c]   | mem[1152921514159316732] = val_10.m_Width;  mem[1152921514159316736] = val_10.m_Height;  //  dest_result_addr=1152921514159316732 |  dest_result_addr=1152921514159316736
        mem[1152921514159316732] = val_10.m_Width;
        mem[1152921514159316736] = val_10.m_Height;
        // 0x00B92D0C: CBZ x20, #0xb92d1c         | if (this.mSprite == null) goto label_25;
        if(val_18 == null)
        {
            goto label_25;
        }
        // 0x00B92D10: LDR w8, [x20, #0x38]       | W8 = this.mSprite.paddingLeft; //P2     
        // 0x00B92D14: STR w8, [x19, #0x30]       | this.mOffsetX = this.mSprite.paddingLeft;  //  dest_result_addr=1152921514159316704
        this.mOffsetX = this.mSprite.paddingLeft;
        // 0x00B92D18: B #0xb92d30                |  goto label_26;                         
        goto label_26;
        label_25:
        // 0x00B92D1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B92D20: LDR w8, [x20, #0x38]       | W8 = this.mSprite.paddingLeft; //P2     
        // 0x00B92D24: LDR x20, [x19, #0x20]      | X20 = this.mSprite; //P2                
        val_19 = this.mSprite;
        // 0x00B92D28: STR w8, [x19, #0x30]       | this.mOffsetX = this.mSprite.paddingLeft;  //  dest_result_addr=1152921514159316704
        this.mOffsetX = this.mSprite.paddingLeft;
        // 0x00B92D2C: CBZ x20, #0xb92d90         | if (this.mSprite == null) goto label_27;
        if(val_19 == null)
        {
            goto label_27;
        }
        label_26:
        // 0x00B92D30: LDR w8, [x20, #0x40]       | W8 = this.mSprite.paddingTop; //P2      
        // 0x00B92D34: STR w8, [x19, #0x34]       | this.mOffsetY = this.mSprite.paddingTop;  //  dest_result_addr=1152921514159316708
        this.mOffsetY = this.mSprite.paddingTop;
        label_31:
        // 0x00B92D38: LDR w8, [x20, #0x20]       | W8 = this.mSprite.width; //P2           
        // 0x00B92D3C: STR w8, [x19, #0x38]       | this.mWidth = this.mSprite.width;        //  dest_result_addr=1152921514159316712
        this.mWidth = this.mSprite.width;
        label_32:
        // 0x00B92D40: LDR w8, [x20, #0x24]       | W8 = this.mSprite.height; //P2          
        // 0x00B92D44: STR w8, [x19, #0x3c]       | this.mHeight = this.mSprite.height;      //  dest_result_addr=1152921514159316716
        this.mHeight = this.mSprite.height;
        label_33:
        // 0x00B92D48: LDR w21, [x20, #0x20]      | W21 = this.mSprite.width; //P2          
        // 0x00B92D4C: MOV x23, x20               | X23 = this.mSprite;//m1                 
        label_37:
        // 0x00B92D50: LDR w8, [x23, #0x38]       | W8 = this.mSprite.paddingLeft; //P2     
        int val_11 = this.mSprite.paddingLeft;
        // 0x00B92D54: LDR w9, [x20, #0x3c]       | W9 = this.mSprite.paddingRight; //P2    
        // 0x00B92D58: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x00B92D5C: STRB w10, [x19, #0x28]     | this.mIsValid = true;                    //  dest_result_addr=1152921514159316696
        this.mIsValid = true;
        // 0x00B92D60: ADD w8, w8, w21            | W8 = (this.mSprite.paddingLeft + this.mSprite.width);
        val_11 = val_11 + this.mSprite.width;
        // 0x00B92D64: ADD w8, w8, w9             | W8 = ((this.mSprite.paddingLeft + this.mSprite.width) + this.mSprite.paddingRight);
        val_11 = val_11 + this.mSprite.paddingRight;
        // 0x00B92D68: STR w8, [x19, #0x40]       | this.mAdvance = ((this.mSprite.paddingLeft + this.mSprite.width) + this.mSprite.paddingRight);  //  dest_result_addr=1152921514159316720
        this.mAdvance = val_11;
        // 0x00B92D6C: B #0xb92b00                |  goto label_28;                         
        goto label_28;
        label_22:
        // 0x00B92D70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92D74: LDR x23, [x22]             | X23 = null;                             
        // 0x00B92D78: LDR w24, [x24, #0x1c]      | W24 = 0x0;                              
        // 0x00B92D7C: CBNZ x23, #0xb92c54        | if (null != null) goto label_29;        
        if(this.mSprite != null)
        {
            goto label_29;
        }
        // 0x00B92D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92D84: LDR x8, [x22]              | X8 = null;                              
        // 0x00B92D88: CBNZ x8, #0xb92c58         | if (null != null) goto label_30;        
        if(this.mSprite != null)
        {
            goto label_30;
        }
        label_36:
        // 0x00B92D8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_27:
        // 0x00B92D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92D94: LDR w8, [x20, #0x40]       | 
        // 0x00B92D98: LDR x20, [x19, #0x20]      | X20 = this.mSprite; //P2                
        // 0x00B92D9C: STR w8, [x19, #0x34]       | this.mOffsetY = 0;                       //  dest_result_addr=1152921514159316708
        this.mOffsetY = 0;
        // 0x00B92DA0: CBNZ x20, #0xb92d38        | if (this.mSprite != null) goto label_31;
        if(this.mSprite != null)
        {
            goto label_31;
        }
        // 0x00B92DA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92DA8: LDR w8, [x20, #0x20]       | W8 = this.mSprite.width; //P2           
        // 0x00B92DAC: LDR x20, [x19, #0x20]      | X20 = this.mSprite; //P2                
        // 0x00B92DB0: STR w8, [x19, #0x38]       | this.mWidth = this.mSprite.width;        //  dest_result_addr=1152921514159316712
        this.mWidth = this.mSprite.width;
        // 0x00B92DB4: CBNZ x20, #0xb92d40        | if (this.mSprite != null) goto label_32;
        if(this.mSprite != null)
        {
            goto label_32;
        }
        // 0x00B92DB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92DBC: LDR w8, [x20, #0x24]       | W8 = this.mSprite.height; //P2          
        // 0x00B92DC0: LDR x20, [x19, #0x20]      | X20 = this.mSprite; //P2                
        // 0x00B92DC4: STR w8, [x19, #0x3c]       | this.mHeight = this.mSprite.height;      //  dest_result_addr=1152921514159316716
        this.mHeight = this.mSprite.height;
        // 0x00B92DC8: CBNZ x20, #0xb92d48        | if (this.mSprite != null) goto label_33;
        if(this.mSprite != null)
        {
            goto label_33;
        }
        // 0x00B92DCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92DD0: LDR x23, [x22]             | X23 = null;                             
        // 0x00B92DD4: LDR w21, [x20, #0x20]      | W21 = this.mSprite.width; //P2          
        // 0x00B92DD8: CBZ x23, #0xb92de4         | if (null == null) goto label_34;        
        if(this.mSprite == null)
        {
            goto label_34;
        }
        // 0x00B92DDC: MOV x20, x23               | X20 = 0 (0x0);//ML01                    
        // 0x00B92DE0: B #0xb92d50                |  goto label_37;                         
        goto label_37;
        label_34:
        // 0x00B92DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        // 0x00B92DE8: LDR x20, [x22]             | X20 = null;                             
        // 0x00B92DEC: CBZ x20, #0xb92d8c         | if (null == null) goto label_36;        
        if(this.mSprite == null)
        {
            goto label_36;
        }
        // 0x00B92DF0: B #0xb92d50                |  goto label_37;                         
        goto label_37;
    
    }

}
