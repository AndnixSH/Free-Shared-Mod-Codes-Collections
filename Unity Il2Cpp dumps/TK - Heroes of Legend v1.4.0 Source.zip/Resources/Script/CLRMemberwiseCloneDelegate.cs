using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public sealed class CLRMemberwiseCloneDelegate : MulticastDelegate
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x028E94E4 (42898660), len: 16  VirtAddr: 0x028E94E4 RVA: 0x028E94E4 token: 100680196 methodIndex: 29547 delegateWrapperIndex: 0 methodInvoker: 0
        public CLRMemberwiseCloneDelegate(object object, IntPtr method)
        {
            //
            // Disasemble & Code
            // 0x028E94E4: LDR x8, [x2]               | X8 = method;                            
            // 0x028E94E8: STP x1, x2, [x0, #0x20]    | mem[1152921512876653856] = object;  mem[1152921512876653864] = method;  //  dest_result_addr=1152921512876653856 |  dest_result_addr=1152921512876653864
            mem[1152921512876653856] = object;
            mem[1152921512876653864] = method;
            // 0x028E94EC: STR x8, [x0, #0x10]        | mem[1152921512876653840] = method;       //  dest_result_addr=1152921512876653840
            mem[1152921512876653840] = method;
            // 0x028E94F0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E94F4 (42898676), len: 528  VirtAddr: 0x028E94F4 RVA: 0x028E94F4 token: 100680197 methodIndex: 29548 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object Invoke(ref object target)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            label_1:
            // 0x028E94F4: STP x22, x21, [sp, #-0x30]! | stack[1152921512876770080] = ???;  stack[1152921512876770088] = ???;  //  dest_result_addr=1152921512876770080 |  dest_result_addr=1152921512876770088
            // 0x028E94F8: STP x20, x19, [sp, #0x10]  | stack[1152921512876770096] = ???;  stack[1152921512876770104] = ???;  //  dest_result_addr=1152921512876770096 |  dest_result_addr=1152921512876770104
            // 0x028E94FC: STP x29, x30, [sp, #0x20]  | stack[1152921512876770112] = ???;  stack[1152921512876770120] = ???;  //  dest_result_addr=1152921512876770112 |  dest_result_addr=1152921512876770120
            // 0x028E9500: ADD x29, sp, #0x20         | X29 = (1152921512876770080 + 32) = 1152921512876770112 (0x10000001ECED0340);
            // 0x028E9504: SUB sp, sp, #0x10          | SP = (1152921512876770080 - 16) = 1152921512876770064 (0x10000001ECED0310);
            // 0x028E9508: MOV x22, x0                | X22 = 1152921512876782128 (0x10000001ECED3230);//ML01
            // 0x028E950C: LDR x0, [x22, #0x58]       | 
            // 0x028E9510: MOV x19, x1                | X19 = 1152921512876814128 (0x10000001ECEDAF30);//ML01
            // 0x028E9514: CBZ x0, #0x28e9520         | if (this == null) goto label_0;         
            if(this == null)
            {
                goto label_0;
            }
            // 0x028E9518: MOV x1, x19                | X1 = 1152921512876814128 (0x10000001ECEDAF30);//ML01
            // 0x028E951C: BL #0x28e94f4              |  R0 = label_1();                        
            label_0:
            // 0x028E9520: LDR x0, [x22, #0x10]       | 
            // 0x028E9524: STR x0, [sp, #8]           | stack[1152921512876770072] = this;       //  dest_result_addr=1152921512876770072
            // 0x028E9528: LDP x20, x21, [x22, #0x20] |                                          //  | 
            // 0x028E952C: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9530: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
            // 0x028E9534: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9538: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
            // 0x028E953C: AND w8, w0, #1             | W8 = (X21 & 1);                         
            var val_1 = X21 & 1;
            // 0x028E9540: TBZ w8, #0, #0x28e95d0     | if (((X21 & 1) & 0x1) == 0) goto label_2;
            if((val_1 & 1) == 0)
            {
                goto label_2;
            }
            // 0x028E9544: LDRSH w8, [x21, #0x4c]     | W8 = X21 + 76;                          
            // 0x028E9548: CMN w8, #1                 | STATE = COMPARE(X21 + 76, 0x1)          
            // 0x028E954C: B.EQ #0x28e95e4            | if (X21 + 76 == 0x1) goto label_6;      
            if((X21 + 76) == 1)
            {
                goto label_6;
            }
            // 0x028E9550: CBZ x20, #0x28e9560        | if (X20 == 0) goto label_4;             
            if(X20 == 0)
            {
                goto label_4;
            }
            // 0x028E9554: LDR x8, [x20]              | X8 = X20;                               
            // 0x028E9558: LDRB w8, [x8, #0xed]       | W8 = X20 + 237;                         
            // 0x028E955C: TBNZ w8, #0, #0x28e95e4    | if ((X20 + 237 & 0x1) != 0) goto label_6;
            if(((X20 + 237) & 1) != 0)
            {
                goto label_6;
            }
            label_4:
            // 0x028E9560: LDR x8, [x22, #0x18]       | 
            // 0x028E9564: CBZ x8, #0x28e95e4         | if (X20 + 237 == 0) goto label_6;       
            if((X20 + 237) == 0)
            {
                goto label_6;
            }
            // 0x028E9568: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E956C: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
            // 0x028E9570: MOV w22, w0                | W22 = X21;//m1                          
            // 0x028E9574: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E9578: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_2 = X21.pressedSprite;
            // 0x028E957C: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
            // 0x028E9580: TBZ w22, #0, #0x28e9630    | if ((X21 & 0x1) == 0) goto label_7;     
            if((X21 & 1) == 0)
            {
                goto label_7;
            }
            // 0x028E9584: TBZ w0, #0, #0x28e968c     | if ((val_2 & 0x1) == 0) goto label_8;   
            if((val_2 & 1) == 0)
            {
                goto label_8;
            }
            // 0x028E9588: LDR x8, [x20]              | X8 = X20;                               
            var val_11 = X20;
            // 0x028E958C: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
            // 0x028E9590: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
            // 0x028E9594: LDRH w9, [x8, #0x102]      | W9 = X20 + 258;                         
            // 0x028E9598: CBZ x9, #0x28e95c4         | if (X20 + 258 == 0) goto label_9;       
            if((X20 + 258) == 0)
            {
                goto label_9;
            }
            // 0x028E959C: LDR x10, [x8, #0x98]       | X10 = X20 + 152;                        
            var val_5 = X20 + 152;
            // 0x028E95A0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_6 = 0;
            // 0x028E95A4: ADD x10, x10, #8           | X10 = (X20 + 152 + 8);                  
            val_5 = val_5 + 8;
            label_11:
            // 0x028E95A8: LDUR x12, [x10, #-8]       | X12 = (X20 + 152 + 8) + -8;             
            // 0x028E95AC: CMP x12, x1                | STATE = COMPARE((X20 + 152 + 8) + -8, X21 + 24)
            // 0x028E95B0: B.EQ #0x28e96b0            | if ((X20 + 152 + 8) + -8 == X21 + 24) goto label_10;
            if(((X20 + 152 + 8) + -8) == (X21 + 24))
            {
                goto label_10;
            }
            // 0x028E95B4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_6 = val_6 + 1;
            // 0x028E95B8: ADD x10, x10, #0x10        | X10 = ((X20 + 152 + 8) + 16);           
            val_5 = val_5 + 16;
            // 0x028E95BC: CMP x11, x9                | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x028E95C0: B.LO #0x28e95a8            | if (0 < X20 + 258) goto label_11;       
            if(val_6 < (X20 + 258))
            {
                goto label_11;
            }
            label_9:
            // 0x028E95C4: MOV x0, x20                | X0 = X20;//m1                           
            val_7 = X20;
            // 0x028E95C8: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x028E95CC: B #0x28e96c0               |  goto label_12;                         
            goto label_12;
            label_2:
            // 0x028E95D0: LDRB w8, [x21, #0x4e]      | W8 = X21 + 78;                          
            // 0x028E95D4: CMP w8, #1                 | STATE = COMPARE(X21 + 78, 0x1)          
            // 0x028E95D8: B.NE #0x28e9608            | if (X21 + 78 != 0x1) goto label_13;     
            if((X21 + 78) != 1)
            {
                goto label_13;
            }
            // 0x028E95DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E95E0: B #0x28e95e8               |  goto label_14;                         
            goto label_14;
            label_6:
            // 0x028E95E4: MOV x0, x20                | X0 = X20;//m1                           
            label_14:
            // 0x028E95E8: LDR x3, [sp, #8]           | X3 = this;                              
            // 0x028E95EC: MOV x1, x19                | X1 = 1152921512876814128 (0x10000001ECEDAF30);//ML01
            // 0x028E95F0: MOV x2, x21                | X2 = X21;//m1                           
            label_23:
            // 0x028E95F4: SUB sp, x29, #0x20         | SP = (1152921512876770112 - 32) = 1152921512876770080 (0x10000001ECED0320);
            // 0x028E95F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E95FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9600: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E9604: BR x3                      | X0 = this( ?? X20, ????);               
            label_13:
            // 0x028E9608: LDR x4, [sp, #8]           | X4 = this;                              
            // 0x028E960C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028E9610: MOV x1, x20                | X1 = X20;//m1                           
            // 0x028E9614: MOV x2, x19                | X2 = 1152921512876814128 (0x10000001ECEDAF30);//ML01
            // 0x028E9618: MOV x3, x21                | X3 = X21;//m1                           
            // 0x028E961C: SUB sp, x29, #0x20         | SP = (1152921512876770112 - 32) = 1152921512876770080 (0x10000001ECED0320);
            // 0x028E9620: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028E9624: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028E9628: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028E962C: BR x4                      | X0 = this( ?? 0x0, ????);               
            label_7:
            // 0x028E9630: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
            // 0x028E9634: TBZ w0, #0, #0x28e96a0     | if ((val_2 & 0x1) == 0) goto label_15;  
            if((val_2 & 1) == 0)
            {
                goto label_15;
            }
            // 0x028E9638: MOV x0, x21                | X0 = X21;//m1                           
            // 0x028E963C: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
            UnityEngine.Sprite val_3 = X21.pressedSprite;
            // 0x028E9640: LDR x9, [x20]              | X9 = X20;                               
            // 0x028E9644: MOV x8, x0                 | X8 = val_3;//m1                         
            // 0x028E9648: LDRH w10, [x9, #0x102]     | W10 = X20 + 258;                        
            // 0x028E964C: CBZ x10, #0x28e9678        | if (X20 + 258 == 0) goto label_16;      
            if((X20 + 258) == 0)
            {
                goto label_16;
            }
            // 0x028E9650: LDR x11, [x9, #0x98]       | X11 = X20 + 152;                        
            var val_7 = X20 + 152;
            // 0x028E9654: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028E9658: ADD x11, x11, #8           | X11 = (X20 + 152 + 8);                  
            val_7 = val_7 + 8;
            label_18:
            // 0x028E965C: LDUR x13, [x11, #-8]       | X13 = (X20 + 152 + 8) + -8;             
            // 0x028E9660: CMP x13, x8                | STATE = COMPARE((X20 + 152 + 8) + -8, val_3)
            // 0x028E9664: B.EQ #0x28e96e4            | if ((X20 + 152 + 8) + -8 == val_3) goto label_17;
            if(((X20 + 152 + 8) + -8) == val_3)
            {
                goto label_17;
            }
            // 0x028E9668: ADD x12, x12, #1           | X12 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028E966C: ADD x11, x11, #0x10        | X11 = ((X20 + 152 + 8) + 16);           
            val_7 = val_7 + 16;
            // 0x028E9670: CMP x12, x10               | STATE = COMPARE((0 + 1), X20 + 258)     
            // 0x028E9674: B.LO #0x28e965c            | if (0 < X20 + 258) goto label_18;       
            if(val_8 < (X20 + 258))
            {
                goto label_18;
            }
            label_16:
            // 0x028E9678: MOV x0, x20                | X0 = X20;//m1                           
            val_8 = X20;
            // 0x028E967C: MOV x1, x8                 | X1 = val_3;//m1                         
            // 0x028E9680: MOV w2, w22                | W2 = X21 + 76;//m1                      
            // 0x028E9684: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
            // 0x028E9688: B #0x28e96f4               |  goto label_19;                         
            goto label_19;
            label_8:
            // 0x028E968C: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
            // 0x028E9690: LDR x9, [x20]              | X9 = X20;                               
            // 0x028E9694: ADD x8, x9, x8, lsl #4     | X8 = (X20 + (X21 + 76) << 4);           
            var val_4 = X20 + ((X21 + 76) << 4);
            // 0x028E9698: LDR x0, [x8, #0x118]       | X0 = (X20 + (X21 + 76) << 4) + 280;     
            val_9 = mem[(X20 + (X21 + 76) << 4) + 280];
            val_9 = (X20 + (X21 + 76) << 4) + 280;
            // 0x028E969C: B #0x28e96c4               |  goto label_20;                         
            goto label_20;
            label_15:
            // 0x028E96A0: LDR x8, [x20]              | X8 = X20;                               
            var val_9 = X20;
            // 0x028E96A4: ADD x8, x8, w22, uxtw #4   | X8 = (X20 + X21 + 76);                  
            val_9 = val_9 + (X21 + 76);
            // 0x028E96A8: LDP x3, x2, [x8, #0x110]   | X3 = (X20 + X21 + 76) + 272; X2 = (X20 + X21 + 76) + 272 + 8; //  | 
            // 0x028E96AC: B #0x28e96f8               |  goto label_21;                         
            goto label_21;
            label_10:
            // 0x028E96B0: LDR w9, [x10]              | W9 = (X20 + 152 + 8);                   
            var val_10 = val_5;
            // 0x028E96B4: ADD w9, w9, w2             | W9 = ((X20 + 152 + 8) + X21 + 76);      
            val_10 = val_10 + (X21 + 76);
            // 0x028E96B8: ADD x8, x8, w9, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
            val_11 = val_11 + val_10;
            // 0x028E96BC: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
            val_7 = val_11 + 272;
            label_12:
            // 0x028E96C0: LDR x0, [x0, #8]           | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            val_9 = mem[((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8];
            val_9 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            label_20:
            // 0x028E96C4: MOV x1, x21                | X1 = X21;//m1                           
            // 0x028E96C8: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
            // 0x028E96CC: MOV x8, x0                 | X8 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x028E96D0: LDR x3, [x8]               | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
            // 0x028E96D4: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E96D8: MOV x1, x19                | X1 = 1152921512876814128 (0x10000001ECEDAF30);//ML01
            // 0x028E96DC: MOV x2, x8                 | X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
            // 0x028E96E0: B #0x28e95f4               |  goto label_23;                         
            goto label_23;
            label_17:
            // 0x028E96E4: LDR w8, [x11]              | W8 = (X20 + 152 + 8);                   
            var val_12 = val_7;
            // 0x028E96E8: ADD w8, w8, w22            | W8 = ((X20 + 152 + 8) + X21 + 76);      
            val_12 = val_12 + (X21 + 76);
            // 0x028E96EC: ADD x8, x9, w8, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
            val_12 = X20 + val_12;
            // 0x028E96F0: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
            val_8 = val_12 + 272;
            label_19:
            // 0x028E96F4: LDP x3, x2, [x0]           | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272); X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
            label_21:
            // 0x028E96F8: MOV x0, x20                | X0 = X20;//m1                           
            // 0x028E96FC: MOV x1, x19                | X1 = 1152921512876814128 (0x10000001ECEDAF30);//ML01
            // 0x028E9700: B #0x28e95f4               |  goto label_23;                         
            goto label_23;
        
        }
        //
        // Offset in libil2cpp.so: 0x028E9704 (42899204), len: 40  VirtAddr: 0x028E9704 RVA: 0x028E9704 token: 100680198 methodIndex: 29549 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.IAsyncResult BeginInvoke(ref object target, System.AsyncCallback callback, object object)
        {
            //
            // Disasemble & Code
            // 0x028E9704: STP x29, x30, [sp, #-0x10]! | stack[1152921512876906544] = ???;  stack[1152921512876906552] = ???;  //  dest_result_addr=1152921512876906544 |  dest_result_addr=1152921512876906552
            // 0x028E9708: MOV x29, sp                | X29 = 1152921512876906544 (0x10000001ECEF1830);//ML01
            // 0x028E970C: STP xzr, xzr, [sp, #-0x10]! | stack[1152921512876906528] = 0x0;  stack[1152921512876906536] = 0x0;  //  dest_result_addr=1152921512876906528 |  dest_result_addr=1152921512876906536
            // 0x028E9710: LDR x8, [x1]               | X8 = target;                            
            // 0x028E9714: MOV x1, sp                 | X1 = 1152921512876906528 (0x10000001ECEF1820);//ML01
            // 0x028E9718: STR x8, [sp]               | stack[1152921512876906528] = target;     //  dest_result_addr=1152921512876906528
            // 0x028E971C: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
            // 0x028E9720: MOV sp, x29                | SP = 1152921512876906544 (0x10000001ECEF1830);//ML01
            // 0x028E9724: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E9728: RET                        |  return (System.IAsyncResult)this;      
            return (System.IAsyncResult)this;
            //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E972C (42899244), len: 40  VirtAddr: 0x028E972C RVA: 0x028E972C token: 100680199 methodIndex: 29550 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual object EndInvoke(ref object target, System.IAsyncResult result)
        {
            //
            // Disasemble & Code
            // 0x028E972C: STP x29, x30, [sp, #-0x10]! | stack[1152921512877038880] = ???;  stack[1152921512877038888] = ???;  //  dest_result_addr=1152921512877038880 |  dest_result_addr=1152921512877038888
            // 0x028E9730: MOV x29, sp                | X29 = 1152921512877038880 (0x10000001ECF11D20);//ML01
            // 0x028E9734: SUB sp, sp, #0x10          | SP = (1152921512877038880 - 16) = 1152921512877038864 (0x10000001ECF11D10);
            // 0x028E9738: STR x1, [sp, #8]           | stack[1152921512877038872] = target;     //  dest_result_addr=1152921512877038872
            // 0x028E973C: ADD x1, sp, #8             | X1 = (1152921512877038864 + 8) = 1152921512877038872 (0x10000001ECF11D18);
            // 0x028E9740: MOV x0, x2                 | X0 = result;//m1                        
            // 0x028E9744: BL #0x278fde8              | X0 = sub_278FDE8( ?? result, ????);     
            // 0x028E9748: MOV sp, x29                | SP = 1152921512877038880 (0x10000001ECF11D20);//ML01
            // 0x028E974C: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x028E9750: RET                        |  return (System.Object)result;          
            return (object)result;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
    
    }

}
