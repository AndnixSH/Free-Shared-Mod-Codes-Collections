using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286BF10
[Serializable]
public class CameraShotsCfg : IExtensible
{
    // Fields
    private int _id; //  0x00000010
    private float _waitTime; //  0x00000014
    private readonly System.Collections.Generic.List<CurCameraShotCfg> _curCameraShot; //  0x00000018
    private ProtoBuf.IExtension extensionObject; //  0x00000020
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286BF54
    [System.ComponentModel.DefaultValueAttribute] // 0x286BF54
    public int id { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286BFD4
    [System.ComponentModel.DefaultValueAttribute] // 0x286BFD4
    public float waitTime { get; set; }
    [ProtoBuf.ProtoMemberAttribute] // 0x286C054
    public System.Collections.Generic.List<CurCameraShotCfg> curCameraShot { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00D7F160 (14152032), len: 112  VirtAddr: 0x00D7F160 RVA: 0x00D7F160 token: 100690327 methodIndex: 25894 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraShotsCfg()
    {
        //
        // Disasemble & Code
        // 0x00D7F160: STP x20, x19, [sp, #-0x20]! | stack[1152921514508621600] = ???;  stack[1152921514508621608] = ???;  //  dest_result_addr=1152921514508621600 |  dest_result_addr=1152921514508621608
        // 0x00D7F164: STP x29, x30, [sp, #0x10]  | stack[1152921514508621616] = ???;  stack[1152921514508621624] = ???;  //  dest_result_addr=1152921514508621616 |  dest_result_addr=1152921514508621624
        // 0x00D7F168: ADD x29, sp, #0x10         | X29 = (1152921514508621600 + 16) = 1152921514508621616 (0x100000024E311730);
        // 0x00D7F16C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
        // 0x00D7F170: LDRB w8, [x20, #0x411]     | W8 = (bool)static_value_03734411;       
        // 0x00D7F174: MOV x19, x0                | X19 = 1152921514508633632 (0x100000024E314620);//ML01
        // 0x00D7F178: TBNZ w8, #0, #0xd7f194     | if (static_value_03734411 == true) goto label_0;
        // 0x00D7F17C: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00D7F180: LDR x8, [x8, #0x70]        | X8 = 0x2B90374;                         
        // 0x00D7F184: LDR w0, [x8]               | W0 = 0x17A1;                            
        // 0x00D7F188: BL #0x2782188              | X0 = sub_2782188( ?? 0x17A1, ????);     
        // 0x00D7F18C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00D7F190: STRB w8, [x20, #0x411]     | static_value_03734411 = true;            //  dest_result_addr=57885713
        label_0:
        // 0x00D7F194: ADRP x8, #0x3622000        | X8 = 56762368 (0x3622000);              
        // 0x00D7F198: LDR x8, [x8, #0x718]       | X8 = 1152921504616644608;               
        // 0x00D7F19C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CurCameraShotCfg> val_1 = null;
        // 0x00D7F1A0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00D7F1A4: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x00D7F1A8: LDR x8, [x8, #0xd50]       | X8 = 1152921514508608608;               
        // 0x00D7F1AC: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00D7F1B0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CurCameraShotCfg>::.ctor();
        // 0x00D7F1B4: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<CurCameraShotCfg>();
        // 0x00D7F1B8: STR x20, [x19, #0x18]      | this._curCameraShot = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514508633656
        this._curCameraShot = val_1;
        // 0x00D7F1BC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00D7F1C0: MOV x0, x19                | X0 = 1152921514508633632 (0x100000024E314620);//ML01
        // 0x00D7F1C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00D7F1C8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00D7F1CC: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F1D0 (14152144), len: 8  VirtAddr: 0x00D7F1D0 RVA: 0x00D7F1D0 token: 100690328 methodIndex: 25895 delegateWrapperIndex: 0 methodInvoker: 0
    public int get_id()
    {
        //
        // Disasemble & Code
        // 0x00D7F1D0: LDR w0, [x0, #0x10]        | W0 = this._id; //P2                     
        // 0x00D7F1D4: RET                        |  return (System.Int32)this._id;         
        return this._id;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F1D8 (14152152), len: 8  VirtAddr: 0x00D7F1D8 RVA: 0x00D7F1D8 token: 100690329 methodIndex: 25896 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_id(int value)
    {
        //
        // Disasemble & Code
        // 0x00D7F1D8: STR w1, [x0, #0x10]        | this._id = value;                        //  dest_result_addr=1152921514508857648
        this._id = value;
        // 0x00D7F1DC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F1E0 (14152160), len: 8  VirtAddr: 0x00D7F1E0 RVA: 0x00D7F1E0 token: 100690330 methodIndex: 25897 delegateWrapperIndex: 0 methodInvoker: 0
    public float get_waitTime()
    {
        //
        // Disasemble & Code
        // 0x00D7F1E0: LDR s0, [x0, #0x14]        | S0 = this._waitTime; //P2               
        // 0x00D7F1E4: RET                        |  return (System.Single)this._waitTime;  
        return this._waitTime;
        //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F1E8 (14152168), len: 8  VirtAddr: 0x00D7F1E8 RVA: 0x00D7F1E8 token: 100690331 methodIndex: 25898 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_waitTime(float value)
    {
        //
        // Disasemble & Code
        // 0x00D7F1E8: STR s0, [x0, #0x14]        | this._waitTime = value;                  //  dest_result_addr=1152921514509081652
        this._waitTime = value;
        // 0x00D7F1EC: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F1F0 (14152176), len: 8  VirtAddr: 0x00D7F1F0 RVA: 0x00D7F1F0 token: 100690332 methodIndex: 25899 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<CurCameraShotCfg> get_curCameraShot()
    {
        //
        // Disasemble & Code
        // 0x00D7F1F0: LDR x0, [x0, #0x18]        | X0 = this._curCameraShot; //P2          
        // 0x00D7F1F4: RET                        |  return (System.Collections.Generic.List<CurCameraShotCfg>)this._curCameraShot;
        return this._curCameraShot;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<CurCameraShotCfg>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00D7F1F8 (14152184), len: 24  VirtAddr: 0x00D7F1F8 RVA: 0x00D7F1F8 token: 100690333 methodIndex: 25900 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00D7F1F8: ADD x8, x0, #0x20          | X8 = this.extensionObject;//AP2 res_addr=1152921514509313856
        // 0x00D7F1FC: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00D7F200: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00D7F204: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00D7F208: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00D7F20C: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
