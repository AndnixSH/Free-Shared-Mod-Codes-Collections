using UnityEngine;

namespace ILRuntime.Runtime.Debugger
{
    internal class BreakpointInfo
    {
        // Fields
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x28574C4
        private int <BreakpointHashCode>k__BackingField; //  0x00000010
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x2857500
        private int <MethodHashCode>k__BackingField; //  0x00000014
        [System.Diagnostics.DebuggerBrowsableAttribute] // 0x285753C
        private int <StartLine>k__BackingField; //  0x00000018
        
        // Properties
        public int BreakpointHashCode { get; set; }
        public int MethodHashCode { get; set; }
        public int StartLine { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01113C00 (17906688), len: 8  VirtAddr: 0x01113C00 RVA: 0x01113C00 token: 100679951 methodIndex: 29240 delegateWrapperIndex: 0 methodInvoker: 0
        public BreakpointInfo()
        {
            //
            // Disasemble & Code
            // 0x01113C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01113C04: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01113C08 (17906696), len: 8  VirtAddr: 0x01113C08 RVA: 0x01113C08 token: 100679952 methodIndex: 29241 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_BreakpointHashCode()
        {
            //
            // Disasemble & Code
            // 0x01113C08: LDR w0, [x0, #0x10]        | W0 = this.<BreakpointHashCode>k__BackingField; //P2 
            // 0x01113C0C: RET                        |  return (System.Int32)this.<BreakpointHashCode>k__BackingField;
            return this.<BreakpointHashCode>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01113C10 (17906704), len: 8  VirtAddr: 0x01113C10 RVA: 0x01113C10 token: 100679953 methodIndex: 29242 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_BreakpointHashCode(int value)
        {
            //
            // Disasemble & Code
            // 0x01113C10: STR w1, [x0, #0x10]        | this.<BreakpointHashCode>k__BackingField = value;  //  dest_result_addr=1152921512840406048
            this.<BreakpointHashCode>k__BackingField = value;
            // 0x01113C14: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01113C18 (17906712), len: 8  VirtAddr: 0x01113C18 RVA: 0x01113C18 token: 100679954 methodIndex: 29243 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_MethodHashCode()
        {
            //
            // Disasemble & Code
            // 0x01113C18: LDR w0, [x0, #0x14]        | W0 = this.<MethodHashCode>k__BackingField; //P2 
            // 0x01113C1C: RET                        |  return (System.Int32)this.<MethodHashCode>k__BackingField;
            return this.<MethodHashCode>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01113C20 (17906720), len: 8  VirtAddr: 0x01113C20 RVA: 0x01113C20 token: 100679955 methodIndex: 29244 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_MethodHashCode(int value)
        {
            //
            // Disasemble & Code
            // 0x01113C20: STR w1, [x0, #0x14]        | this.<MethodHashCode>k__BackingField = value;  //  dest_result_addr=1152921512840630052
            this.<MethodHashCode>k__BackingField = value;
            // 0x01113C24: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01113C28 (17906728), len: 8  VirtAddr: 0x01113C28 RVA: 0x01113C28 token: 100679956 methodIndex: 29245 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_StartLine()
        {
            //
            // Disasemble & Code
            // 0x01113C28: LDR w0, [x0, #0x18]        | W0 = this.<StartLine>k__BackingField; //P2 
            // 0x01113C2C: RET                        |  return (System.Int32)this.<StartLine>k__BackingField;
            return this.<StartLine>k__BackingField;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01113C30 (17906736), len: 8  VirtAddr: 0x01113C30 RVA: 0x01113C30 token: 100679957 methodIndex: 29246 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_StartLine(int value)
        {
            //
            // Disasemble & Code
            // 0x01113C30: STR w1, [x0, #0x18]        | this.<StartLine>k__BackingField = value;  //  dest_result_addr=1152921512840854056
            this.<StartLine>k__BackingField = value;
            // 0x01113C34: RET                        |  return;                                
            return;
        
        }
    
    }

}
