using UnityEngine;
internal sealed class ValueMember.Comparer : IComparer, IComparer<ProtoBuf.Meta.ValueMember>
{
    // Fields
    public static readonly ProtoBuf.Meta.ValueMember.Comparer Default; // static_offset: 0x00000000
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02983D14 (43531540), len: 8  VirtAddr: 0x02983D14 RVA: 0x02983D14 token: 100689543 methodIndex: 53751 delegateWrapperIndex: 0 methodInvoker: 0
    public ValueMember.Comparer()
    {
        //
        // Disasemble & Code
        // 0x02983D14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02983D18: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02983D1C (43531548), len: 192  VirtAddr: 0x02983D1C RVA: 0x02983D1C token: 100689544 methodIndex: 53752 delegateWrapperIndex: 0 methodInvoker: 0
    public int Compare(object x, object y)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        //  | 
        var val_2;
        // 0x02983D1C: STP x22, x21, [sp, #-0x30]! | stack[1152921514398561168] = ???;  stack[1152921514398561176] = ???;  //  dest_result_addr=1152921514398561168 |  dest_result_addr=1152921514398561176
        // 0x02983D20: STP x20, x19, [sp, #0x10]  | stack[1152921514398561184] = ???;  stack[1152921514398561192] = ???;  //  dest_result_addr=1152921514398561184 |  dest_result_addr=1152921514398561192
        // 0x02983D24: STP x29, x30, [sp, #0x20]  | stack[1152921514398561200] = ???;  stack[1152921514398561208] = ???;  //  dest_result_addr=1152921514398561200 |  dest_result_addr=1152921514398561208
        // 0x02983D28: ADD x29, sp, #0x20         | X29 = (1152921514398561168 + 32) = 1152921514398561200 (0x1000000247A1B3B0);
        // 0x02983D2C: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
        // 0x02983D30: LDRB w8, [x21, #0xe8e]     | W8 = (bool)static_value_037B8E8E;       
        // 0x02983D34: MOV x19, x2                | X19 = y;//m1                            
        // 0x02983D38: MOV x20, x1                | X20 = x;//m1                            
        // 0x02983D3C: TBNZ w8, #0, #0x2983d58    | if (static_value_037B8E8E == true) goto label_0;
        // 0x02983D40: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x02983D44: LDR x8, [x8, #0xa50]       | X8 = 0x2B925D4;                         
        // 0x02983D48: LDR w0, [x8]               | W0 = 0x203A;                            
        // 0x02983D4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x203A, ????);     
        // 0x02983D50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02983D54: STRB w8, [x21, #0xe8e]     | static_value_037B8E8E = true;            //  dest_result_addr=58429070
        label_0:
        // 0x02983D58: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x02983D5C: LDR x8, [x8, #0x778]       | X8 = 1152921504883576832;               
        // 0x02983D60: LDR x8, [x8]               | X8 = typeof(ProtoBuf.Meta.ValueMember); 
        // 0x02983D64: CBZ x20, #0x2983d7c        | if (x == null) goto label_1;            
        if(x == null)
        {
            goto label_1;
        }
        // 0x02983D68: LDR x9, [x20]              | X9 = typeof(System.Object);             
        // 0x02983D6C: LDRB w10, [x8, #0x104]     | W10 = ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x02983D70: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x02983D74: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x02983D78: B.HS #0x2983d84            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth >= ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
        label_1:
        // 0x02983D7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_1 = 0;
        // 0x02983D80: B #0x2983d98               |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x02983D84: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
        // 0x02983D88: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeF
        // 0x02983D8C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x02983D90: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ProtoBuf.Meta.ValueMember))
        // 0x02983D94: CSEL x1, x20, xzr, eq      | X1 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? x : 0;
        x = (((System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (x) : 0;
        label_3:
        // 0x02983D98: CBZ x19, #0x2983db0        | if (y == null) goto label_4;            
        if(y == null)
        {
            goto label_4;
        }
        // 0x02983D9C: LDR x9, [x19]              | X9 = typeof(System.Object);             
        // 0x02983DA0: LDRB w10, [x8, #0x104]     | W10 = ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x02983DA4: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x02983DA8: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x02983DAC: B.HS #0x2983db8            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth >= ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
        label_4:
        // 0x02983DB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        val_2 = 0;
        // 0x02983DB4: B #0x2983dcc               |  goto label_6;                          
        goto label_6;
        label_5:
        // 0x02983DB8: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
        // 0x02983DBC: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeF
        // 0x02983DC0: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x02983DC4: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ProtoBuf.Meta.ValueMember))
        // 0x02983DC8: CSEL x2, x19, xzr, eq      | X2 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? y : 0;
        y = (((System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (y) : 0;
        label_6:
        // 0x02983DCC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x02983DD0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x02983DD4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x02983DD8: B #0x2983ddc               | return this.Compare(x:  x = (((System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (x) : 0, y:  y = (((System.Object.__il2cppRuntimeField_typeHierarchy + (ProtoBuf.Meta.ValueMember.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (y) : 0);
        return this.Compare(x:  x, y:  y);
    
    }
    //
    // Offset in libil2cpp.so: 0x02983DDC (43531740), len: 120  VirtAddr: 0x02983DDC RVA: 0x02983DDC token: 100689545 methodIndex: 53753 delegateWrapperIndex: 0 methodInvoker: 0
    public int Compare(ProtoBuf.Meta.ValueMember x, ProtoBuf.Meta.ValueMember y)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x02983DDC: STP x20, x19, [sp, #-0x20]! | stack[1152921514398689568] = ???;  stack[1152921514398689576] = ???;  //  dest_result_addr=1152921514398689568 |  dest_result_addr=1152921514398689576
        // 0x02983DE0: STP x29, x30, [sp, #0x10]  | stack[1152921514398689584] = ???;  stack[1152921514398689592] = ???;  //  dest_result_addr=1152921514398689584 |  dest_result_addr=1152921514398689592
        // 0x02983DE4: ADD x29, sp, #0x10         | X29 = (1152921514398689568 + 16) = 1152921514398689584 (0x1000000247A3A930);
        // 0x02983DE8: SUB sp, sp, #0x10          | SP = (1152921514398689568 - 16) = 1152921514398689552 (0x1000000247A3A910);
        // 0x02983DEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02983DF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02983DF4: MOV x19, x2                | X19 = y;//m1                            
        // 0x02983DF8: MOV x20, x1                | X20 = x;//m1                            
        // 0x02983DFC: STR wzr, [sp, #0xc]        | stack[1152921514398689564] = 0x0;        //  dest_result_addr=1152921514398689564
        // 0x02983E00: BL #0x1708e5c              | X0 = System.Object.ReferenceEquals(objA:  0, objB:  x);
        bool val_1 = System.Object.ReferenceEquals(objA:  0, objB:  x);
        // 0x02983E04: MOV w8, w0                 | W8 = val_1;//m1                         
        // 0x02983E08: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_3 = 0;
        // 0x02983E0C: AND w8, w8, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x02983E10: TBNZ w8, #0, #0x2983e44    | if ((val_1 & 1) == true) goto label_4;  
        if(val_2 == true)
        {
            goto label_4;
        }
        // 0x02983E14: CBZ x20, #0x2983e38        | if (x == null) goto label_1;            
        if(x == null)
        {
            goto label_1;
        }
        // 0x02983E18: CBZ x19, #0x2983e40        | if (y == null) goto label_2;            
        if(y == null)
        {
            goto label_2;
        }
        // 0x02983E1C: LDR w8, [x20, #0x10]       | W8 = x.fieldNumber; //P2                
        // 0x02983E20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02983E24: ADD x0, sp, #0xc           | X0 = (1152921514398689552 + 12) = 1152921514398689564 (0x1000000247A3A91C);
        // 0x02983E28: STR w8, [sp, #0xc]         | stack[1152921514398689564] = x.fieldNumber;  //  dest_result_addr=1152921514398689564
        // 0x02983E2C: LDR w1, [x19, #0x10]       | W1 = y.fieldNumber; //P2                
        // 0x02983E30: BL #0x1e62058              | X0 = label_System_Int32_GetHashCode_GL01E62058();
        // 0x02983E34: B #0x2983e44               |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x02983E38: MOVN w0, #0                | W0 = 0 (0x0);//ML01                     
        val_3 = 0;
        // 0x02983E3C: B #0x2983e44               |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x02983E40: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_3 = 1;
        label_4:
        // 0x02983E44: SUB sp, x29, #0x10         | SP = (1152921514398689584 - 16) = 1152921514398689568 (0x1000000247A3A920);
        // 0x02983E48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02983E4C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02983E50: RET                        |  return (System.Int32)1;                
        return (int)val_3;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x02983E54 (43531860), len: 100  VirtAddr: 0x02983E54 RVA: 0x02983E54 token: 100689546 methodIndex: 53754 delegateWrapperIndex: 0 methodInvoker: 0
    private static ValueMember.Comparer()
    {
        //
        // Disasemble & Code
        // 0x02983E54: STP x20, x19, [sp, #-0x20]! | stack[1152921514398809760] = ???;  stack[1152921514398809768] = ???;  //  dest_result_addr=1152921514398809760 |  dest_result_addr=1152921514398809768
        // 0x02983E58: STP x29, x30, [sp, #0x10]  | stack[1152921514398809776] = ???;  stack[1152921514398809784] = ???;  //  dest_result_addr=1152921514398809776 |  dest_result_addr=1152921514398809784
        // 0x02983E5C: ADD x29, sp, #0x10         | X29 = (1152921514398809760 + 16) = 1152921514398809776 (0x1000000247A57EB0);
        // 0x02983E60: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
        // 0x02983E64: LDRB w8, [x19, #0xe8f]     | W8 = (bool)static_value_037B8E8F;       
        // 0x02983E68: TBNZ w8, #0, #0x2983e84    | if (static_value_037B8E8F == true) goto label_0;
        // 0x02983E6C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
        // 0x02983E70: LDR x8, [x8, #0xd80]       | X8 = 0x2B923D8;                         
        // 0x02983E74: LDR w0, [x8]               | W0 = 0x1FBB;                            
        // 0x02983E78: BL #0x2782188              | X0 = sub_2782188( ?? 0x1FBB, ????);     
        // 0x02983E7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02983E80: STRB w8, [x19, #0xe8f]     | static_value_037B8E8F = true;            //  dest_result_addr=58429071
        label_0:
        // 0x02983E84: ADRP x20, #0x3681000       | X20 = 57151488 (0x3681000);             
        // 0x02983E88: LDR x20, [x20, #0xce0]     | X20 = 1152921504883630080;              
        // 0x02983E8C: LDR x0, [x20]              | X0 = typeof(ValueMember.Comparer);      
        object val_1 = null;
        // 0x02983E90: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ValueMember.Comparer), ????);
        // 0x02983E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02983E98: MOV x19, x0                | X19 = 1152921504883630080 (0x10000000107F6000);//ML01
        // 0x02983E9C: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x02983EA0: LDR x8, [x20]              | X8 = typeof(ValueMember.Comparer);      
        // 0x02983EA4: LDR x8, [x8, #0xa0]        | X8 = ValueMember.Comparer.__il2cppRuntimeField_static_fields;
        // 0x02983EA8: STR x19, [x8]              | ValueMember.Comparer.Default = typeof(ValueMember.Comparer);  //  dest_result_addr=1152921504883634176
        ValueMember.Comparer.Default = val_1;
        // 0x02983EAC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x02983EB0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x02983EB4: RET                        |  return;                                
        return;
    
    }

}
