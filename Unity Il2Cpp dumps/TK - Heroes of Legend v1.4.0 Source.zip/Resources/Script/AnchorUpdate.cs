using UnityEngine;
public enum UIRect.AnchorUpdate
{
    // Fields
    OnEnable = 0
    ,OnUpdate = 1
    ,OnStart = 2
    

}
