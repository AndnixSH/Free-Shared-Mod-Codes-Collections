using UnityEngine;
public class barrierGateCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public int initState; //  0x00000014
    public int openWay; //  0x00000018
    public int openParameter; //  0x0000001C
    public int closeWay; //  0x00000020
    public int closeParameter; //  0x00000024
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8D44C (12112972), len: 8  VirtAddr: 0x00B8D44C RVA: 0x00B8D44C token: 100690506 methodIndex: 25089 delegateWrapperIndex: 0 methodInvoker: 0
    public barrierGateCfg()
    {
        //
        // Disasemble & Code
        // 0x00B8D44C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8D450: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8D454 (12112980), len: 484  VirtAddr: 0x00B8D454 RVA: 0x00B8D454 token: 100690507 methodIndex: 25090 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00B8D454: STP x22, x21, [sp, #-0x30]! | stack[1152921514529066272] = ???;  stack[1152921514529066280] = ???;  //  dest_result_addr=1152921514529066272 |  dest_result_addr=1152921514529066280
        // 0x00B8D458: STP x20, x19, [sp, #0x10]  | stack[1152921514529066288] = ???;  stack[1152921514529066296] = ???;  //  dest_result_addr=1152921514529066288 |  dest_result_addr=1152921514529066296
        // 0x00B8D45C: STP x29, x30, [sp, #0x20]  | stack[1152921514529066304] = ???;  stack[1152921514529066312] = ???;  //  dest_result_addr=1152921514529066304 |  dest_result_addr=1152921514529066312
        // 0x00B8D460: ADD x29, sp, #0x20         | X29 = (1152921514529066272 + 32) = 1152921514529066304 (0x100000024F690D40);
        // 0x00B8D464: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B8D468: LDRB w8, [x21, #0xa19]     | W8 = (bool)static_value_03733A19;       
        // 0x00B8D46C: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00B8D470: MOV x19, x0                | X19 = 1152921514529078320 (0x100000024F693C30);//ML01
        // 0x00B8D474: TBNZ w8, #0, #0xb8d490     | if (static_value_03733A19 == true) goto label_0;
        // 0x00B8D478: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
        // 0x00B8D47C: LDR x8, [x8, #0x3b0]       | X8 = 0x2B8EFC4;                         
        // 0x00B8D480: LDR w0, [x8]               | W0 = 0x12B3;                            
        // 0x00B8D484: BL #0x2782188              | X0 = sub_2782188( ?? 0x12B3, ????);     
        // 0x00B8D488: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8D48C: STRB w8, [x21, #0xa19]     | static_value_03733A19 = true;            //  dest_result_addr=57883161
        label_0:
        // 0x00B8D490: CBNZ x20, #0xb8d498        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00B8D494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12B3, ????);     
        label_1:
        // 0x00B8D498: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00B8D49C: ADRP x21, #0x3667000       | X21 = 57044992 (0x3667000);             
        // 0x00B8D4A0: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00B8D4A4: LDR x21, [x21, #0x90]      | X21 = 1152921510817398768;              
        // 0x00B8D4A8: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D4AC: LDR x1, [x8]               | X1 = "id";                              
        // 0x00B8D4B0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D4B4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00B8D4B8: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00B8D4BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D4C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D4C4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00B8D4C8: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514529078336
        this.id = val_2;
        // 0x00B8D4CC: CBZ x20, #0xb8d500         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00B8D4D0: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00B8D4D4: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921514529025168)("initState");
        // 0x00B8D4D8: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D4DC: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D4E0: LDR x1, [x8]               | X1 = "initState";                       
        // 0x00B8D4E4: BL #0x23fc26c              | X0 = _info.get_Item(key:  "initState"); 
        string val_3 = _info.Item["initState"];
        // 0x00B8D4E8: MOV x1, x0                 | X1 = val_3;//m1                         
        // 0x00B8D4EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D4F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D4F4: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_4 = System.Int32.Parse(s:  0);
        // 0x00B8D4F8: STR w0, [x19, #0x14]       | this.initState = val_4;                  //  dest_result_addr=1152921514529078340
        this.initState = val_4;
        // 0x00B8D4FC: B #0xb8d534                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00B8D500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B8D504: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00B8D508: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921514529025168)("initState");
        // 0x00B8D50C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D510: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D514: LDR x1, [x8]               | X1 = "initState";                       
        // 0x00B8D518: BL #0x23fc26c              | X0 = _info.get_Item(key:  "initState"); 
        string val_5 = _info.Item["initState"];
        // 0x00B8D51C: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00B8D520: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D524: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D528: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_6 = System.Int32.Parse(s:  0);
        // 0x00B8D52C: STR w0, [x19, #0x14]       | this.initState = val_6;                  //  dest_result_addr=1152921514529078340
        this.initState = val_6;
        // 0x00B8D530: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        label_3:
        // 0x00B8D534: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
        // 0x00B8D538: LDR x8, [x8, #0x150]       | X8 = (string**)(1152921514529033456)("openWay");
        // 0x00B8D53C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D540: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D544: LDR x1, [x8]               | X1 = "openWay";                         
        // 0x00B8D548: BL #0x23fc26c              | X0 = _info.get_Item(key:  "openWay");   
        string val_7 = _info.Item["openWay"];
        // 0x00B8D54C: MOV x1, x0                 | X1 = val_7;//m1                         
        // 0x00B8D550: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D554: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D558: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_8 = System.Int32.Parse(s:  0);
        // 0x00B8D55C: STR w0, [x19, #0x18]       | this.openWay = val_8;                    //  dest_result_addr=1152921514529078344
        this.openWay = val_8;
        // 0x00B8D560: CBZ x20, #0xb8d594         | if (_info == null) goto label_4;        
        if(_info == null)
        {
            goto label_4;
        }
        // 0x00B8D564: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B8D568: LDR x8, [x8, #0xd90]       | X8 = (string**)(1152921514529037648)("openParameter");
        // 0x00B8D56C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D570: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D574: LDR x1, [x8]               | X1 = "openParameter";                   
        // 0x00B8D578: BL #0x23fc26c              | X0 = _info.get_Item(key:  "openParameter");
        string val_9 = _info.Item["openParameter"];
        // 0x00B8D57C: MOV x1, x0                 | X1 = val_9;//m1                         
        // 0x00B8D580: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D584: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D588: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_10 = System.Int32.Parse(s:  0);
        // 0x00B8D58C: STR w0, [x19, #0x1c]       | this.openParameter = val_10;             //  dest_result_addr=1152921514529078348
        this.openParameter = val_10;
        // 0x00B8D590: B #0xb8d5c8                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00B8D594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        // 0x00B8D598: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B8D59C: LDR x8, [x8, #0xd90]       | X8 = (string**)(1152921514529037648)("openParameter");
        // 0x00B8D5A0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D5A4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D5A8: LDR x1, [x8]               | X1 = "openParameter";                   
        // 0x00B8D5AC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "openParameter");
        string val_11 = _info.Item["openParameter"];
        // 0x00B8D5B0: MOV x1, x0                 | X1 = val_11;//m1                        
        // 0x00B8D5B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D5B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D5BC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_12 = System.Int32.Parse(s:  0);
        // 0x00B8D5C0: STR w0, [x19, #0x1c]       | this.openParameter = val_12;             //  dest_result_addr=1152921514529078348
        this.openParameter = val_12;
        // 0x00B8D5C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_5:
        // 0x00B8D5C8: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x00B8D5CC: LDR x8, [x8, #0x3b8]       | X8 = (string**)(1152921514529045936)("closeWay");
        // 0x00B8D5D0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D5D4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D5D8: LDR x1, [x8]               | X1 = "closeWay";                        
        // 0x00B8D5DC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "closeWay");  
        string val_13 = _info.Item["closeWay"];
        // 0x00B8D5E0: MOV x1, x0                 | X1 = val_13;//m1                        
        // 0x00B8D5E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D5E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D5EC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_14 = System.Int32.Parse(s:  0);
        // 0x00B8D5F0: STR w0, [x19, #0x20]       | this.closeWay = val_14;                  //  dest_result_addr=1152921514529078352
        this.closeWay = val_14;
        // 0x00B8D5F4: CBNZ x20, #0xb8d5fc        | if (_info != null) goto label_6;        
        if(_info != null)
        {
            goto label_6;
        }
        // 0x00B8D5F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_6:
        // 0x00B8D5FC: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B8D600: LDR x8, [x8, #0x650]       | X8 = (string**)(1152921514529050128)("closeParameter");
        // 0x00B8D604: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B8D608: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B8D60C: LDR x1, [x8]               | X1 = "closeParameter";                  
        // 0x00B8D610: BL #0x23fc26c              | X0 = _info.get_Item(key:  "closeParameter");
        string val_15 = _info.Item["closeParameter"];
        // 0x00B8D614: MOV x1, x0                 | X1 = val_15;//m1                        
        // 0x00B8D618: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8D61C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8D620: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_16 = System.Int32.Parse(s:  0);
        // 0x00B8D624: STR w0, [x19, #0x24]       | this.closeParameter = val_16;            //  dest_result_addr=1152921514529078356
        this.closeParameter = val_16;
        // 0x00B8D628: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8D62C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8D630: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B8D634: RET                        |  return;                                
        return;
    
    }

}
