using UnityEngine;
public class CallJSApi
{
    // Fields
    private static ILRuntime.Runtime.Intepreter.ILTypeInstance mhJSApi; // static_offset: 0x00000000
    public static string jsStr; // static_offset: 0x00000008
    private static bool isNeedNext; // static_offset: 0x00000010
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA5710 (12211984), len: 288  VirtAddr: 0x00BA5710 RVA: 0x00BA5710 token: 100692721 methodIndex: 25620 delegateWrapperIndex: 0 methodInvoker: 0
    private static CallJSApi()
    {
        //
        // Disasemble & Code
        // 0x00BA5710: STP x20, x19, [sp, #-0x20]! | stack[1152921514874069696] = ???;  stack[1152921514874069704] = ???;  //  dest_result_addr=1152921514874069696 |  dest_result_addr=1152921514874069704
        // 0x00BA5714: STP x29, x30, [sp, #0x10]  | stack[1152921514874069712] = ???;  stack[1152921514874069720] = ???;  //  dest_result_addr=1152921514874069712 |  dest_result_addr=1152921514874069720
        // 0x00BA5718: ADD x29, sp, #0x10         | X29 = (1152921514874069696 + 16) = 1152921514874069712 (0x1000000263F962D0);
        // 0x00BA571C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA5720: LDRB w8, [x19, #0xad3]     | W8 = (bool)static_value_03733AD3;       
        // 0x00BA5724: TBNZ w8, #0, #0xba5740     | if (static_value_03733AD3 == true) goto label_0;
        // 0x00BA5728: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x00BA572C: LDR x8, [x8, #0x370]       | X8 = 0x2B900A8;                         
        // 0x00BA5730: LDR w0, [x8]               | W0 = 0x16EE;                            
        // 0x00BA5734: BL #0x2782188              | X0 = sub_2782188( ?? 0x16EE, ????);     
        // 0x00BA5738: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA573C: STRB w8, [x19, #0xad3]     | static_value_03733AD3 = true;            //  dest_result_addr=57883347
        label_0:
        // 0x00BA5740: ADRP x20, #0x3604000       | X20 = 56639488 (0x3604000);             
        // 0x00BA5744: LDR x20, [x20, #0xb68]     | X20 = 1152921504901255168;              
        // 0x00BA5748: ADRP x9, #0x364c000        | X9 = 56934400 (0x364C000);              
        // 0x00BA574C: LDR x8, [x20]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5750: LDR x9, [x9, #0xda0]       | X9 = (string**)(1152921514874049200)("com.starjoys.msdk.JSSDK");
        // 0x00BA5754: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5758: LDR x9, [x9]               | X9 = "com.starjoys.msdk.JSSDK";         
        // 0x00BA575C: STR x9, [x8, #8]           | CallJSApi.jsStr = "com.starjoys.msdk.JSSDK";  //  dest_result_addr=1152921504901259272
        CallJSApi.jsStr = "com.starjoys.msdk.JSSDK";
        // 0x00BA5760: LDR x8, [x20]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5764: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x00BA5768: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA576C: STRB w9, [x8, #0x10]       | CallJSApi.isNeedNext = true;             //  dest_result_addr=1152921504901259280
        CallJSApi.isNeedNext = true;
        // 0x00BA5770: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
        // 0x00BA5774: LDR x8, [x8, #0x290]       | X8 = 1152921504826335232;               
        // 0x00BA5778: LDR x0, [x8]               | X0 = typeof(ILRuntimeMgr);              
        // 0x00BA577C: LDRB w8, [x0, #0x10a]      | W8 = ILRuntimeMgr.__il2cppRuntimeField_10A;
        // 0x00BA5780: TBZ w8, #0, #0xba5790      | if (ILRuntimeMgr.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA5784: LDR w8, [x0, #0xbc]        | W8 = ILRuntimeMgr.__il2cppRuntimeField_cctor_finished;
        // 0x00BA5788: CBNZ w8, #0xba5790         | if (ILRuntimeMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA578C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntimeMgr), ????);
        label_2:
        // 0x00BA5790: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA5794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5798: BL #0x17b4c54              | X0 = ILRuntimeMgr.get_appdomain();      
        ILRuntime.Runtime.Enviorment.AppDomain val_1 = ILRuntimeMgr.appdomain;
        // 0x00BA579C: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00BA57A0: CBNZ x19, #0xba57a8        | if (val_1 != null) goto label_3;        
        if(val_1 != null)
        {
            goto label_3;
        }
        // 0x00BA57A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_3:
        // 0x00BA57A8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00BA57AC: LDR x8, [x8, #0x768]       | X8 = (string**)(1152921514874053424)("MHJsApi");
        // 0x00BA57B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA57B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA57B8: MOV x0, x19                | X0 = val_1;//m1                         
        // 0x00BA57BC: LDR x1, [x8]               | X1 = "MHJsApi";                         
        // 0x00BA57C0: BL #0x28e65ec              | X0 = val_1.Instantiate(type:  "MHJsApi", args:  0);
        ILRuntime.Runtime.Intepreter.ILTypeInstance val_2 = val_1.Instantiate(type:  "MHJsApi", args:  0);
        // 0x00BA57C4: LDR x8, [x20]              | X8 = typeof(CallJSApi);                 
        // 0x00BA57C8: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA57CC: STR x0, [x8]               | CallJSApi.mhJSApi = val_2;               //  dest_result_addr=1152921504901259264
        CallJSApi.mhJSApi = val_2;
        // 0x00BA57D0: LDR x8, [x20]              | X8 = typeof(CallJSApi);                 
        // 0x00BA57D4: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA57D8: LDR x8, [x8]               | X8 = val_2;                             
        // 0x00BA57DC: CBZ x8, #0xba57ec          | if (val_2 == null) goto label_4;        
        if(CallJSApi.mhJSApi == null)
        {
            goto label_4;
        }
        // 0x00BA57E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA57E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA57E8: RET                        |  return;                                
        return;
        label_4:
        // 0x00BA57EC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00BA57F0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00BA57F4: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00BA57F8: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00BA57FC: TBZ w8, #0, #0xba580c      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00BA5800: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA5804: CBNZ w8, #0xba580c         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BA5808: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_6:
        // 0x00BA580C: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
        // 0x00BA5810: LDR x8, [x8, #0x348]       | X8 = (string**)(1152921514874057616)("MHJsApi is null");
        // 0x00BA5814: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA5818: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA581C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00BA5820: LDR x1, [x8]               | X1 = "MHJsApi is null";                 
        // 0x00BA5824: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5828: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA582C: B #0xb5b538                | EDebug.LogError(message:  0, isShowStack:  true); return;
        EDebug.LogError(message:  0, isShowStack:  true);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5830 (12212272), len: 8  VirtAddr: 0x00BA5830 RVA: 0x00BA5830 token: 100692722 methodIndex: 25621 delegateWrapperIndex: 0 methodInvoker: 0
    public CallJSApi()
    {
        //
        // Disasemble & Code
        // 0x00BA5830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5834: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5838 (12212280), len: 140  VirtAddr: 0x00BA5838 RVA: 0x00BA5838 token: 100692723 methodIndex: 25622 delegateWrapperIndex: 0 methodInvoker: 0
    public static void CallJsFun(string funName, object[] args)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA5838: STP x22, x21, [sp, #-0x30]! | stack[1152921514874342832] = ???;  stack[1152921514874342840] = ???;  //  dest_result_addr=1152921514874342832 |  dest_result_addr=1152921514874342840
        // 0x00BA583C: STP x20, x19, [sp, #0x10]  | stack[1152921514874342848] = ???;  stack[1152921514874342856] = ???;  //  dest_result_addr=1152921514874342848 |  dest_result_addr=1152921514874342856
        // 0x00BA5840: STP x29, x30, [sp, #0x20]  | stack[1152921514874342864] = ???;  stack[1152921514874342872] = ???;  //  dest_result_addr=1152921514874342864 |  dest_result_addr=1152921514874342872
        // 0x00BA5844: ADD x29, sp, #0x20         | X29 = (1152921514874342832 + 32) = 1152921514874342864 (0x1000000263FD8DD0);
        // 0x00BA5848: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA584C: LDRB w8, [x21, #0xad4]     | W8 = (bool)static_value_03733AD4;       
        // 0x00BA5850: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00BA5854: MOV x20, x1                | X20 = args;//m1                         
        // 0x00BA5858: TBNZ w8, #0, #0xba5874     | if (static_value_03733AD4 == true) goto label_0;
        // 0x00BA585C: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
        // 0x00BA5860: LDR x8, [x8, #0x8b0]       | X8 = 0x2B900E8;                         
        // 0x00BA5864: LDR w0, [x8]               | W0 = 0x16FE;                            
        // 0x00BA5868: BL #0x2782188              | X0 = sub_2782188( ?? 0x16FE, ????);     
        // 0x00BA586C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA5870: STRB w8, [x21, #0xad4]     | static_value_03733AD4 = true;            //  dest_result_addr=57883348
        label_0:
        // 0x00BA5874: ADRP x21, #0x3604000       | X21 = 56639488 (0x3604000);             
        // 0x00BA5878: LDR x21, [x21, #0xb68]     | X21 = 1152921504901255168;              
        // 0x00BA587C: LDR x8, [x21]              | X8 = typeof(CallJSApi);                 
        val_1 = null;
        // 0x00BA5880: LDRB w9, [x8, #0x10a]      | W9 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00BA5884: TBZ w9, #0, #0xba589c      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA5888: LDR w9, [x8, #0xbc]        | W9 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00BA588C: CBNZ w9, #0xba589c         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA5890: MOV x0, x8                 | X0 = 1152921504901255168 (0x10000000118C5000);//ML01
        // 0x00BA5894: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        // 0x00BA5898: LDR x8, [x21]              | X8 = typeof(CallJSApi);                 
        val_1 = null;
        label_2:
        // 0x00BA589C: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA58A0: MOV x2, x20                | X2 = args;//m1                          
        // 0x00BA58A4: MOV x3, x19                | X3 = X2;//m1                            
        // 0x00BA58A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA58AC: LDR x1, [x8]               | X1 = CallJSApi.mhJSApi;                 
        // 0x00BA58B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA58B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA58B8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA58BC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA58C0: B #0xb64f40                | EILTypeInstance.EInvoke(_this:  0, method:  CallJSApi.mhJSApi, p:  args); return;
        EILTypeInstance.EInvoke(_this:  0, method:  CallJSApi.mhJSApi, p:  args);
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x00FD70B4 VirtAddr: 0x00FD70B4 -RVA: 0x00FD70B4 
    // -CallJSApi.CallJsFun<object>
    //
    //
    // Offset in libil2cpp.so: 0x00FD70B4 (16609460), len: 152  VirtAddr: 0x00FD70B4 RVA: 0x00FD70B4 token: 100692724 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public static T CallJsFun<T>(string funName, object[] args)
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00FD70B4: STP x22, x21, [sp, #-0x30]! | stack[1152921514874536752] = ???;  stack[1152921514874536760] = ???;  //  dest_result_addr=1152921514874536752 |  dest_result_addr=1152921514874536760
        // 0x00FD70B8: STP x20, x19, [sp, #0x10]  | stack[1152921514874536768] = ???;  stack[1152921514874536776] = ???;  //  dest_result_addr=1152921514874536768 |  dest_result_addr=1152921514874536776
        // 0x00FD70BC: STP x29, x30, [sp, #0x20]  | stack[1152921514874536784] = ???;  stack[1152921514874536792] = ???;  //  dest_result_addr=1152921514874536784 |  dest_result_addr=1152921514874536792
        // 0x00FD70C0: ADD x29, sp, #0x20         | X29 = (1152921514874536752 + 32) = 1152921514874536784 (0x1000000264008350);
        // 0x00FD70C4: ADRP x22, #0x3735000       | X22 = 57888768 (0x3735000);             
        // 0x00FD70C8: LDRB w8, [x22, #0x3e6]     | W8 = (bool)static_value_037353E6;       
        // 0x00FD70CC: MOV x20, x3                | X20 = X3;//m1                           
        // 0x00FD70D0: MOV x19, x2                | X19 = __RuntimeMethodHiddenParam;//m1   
        // 0x00FD70D4: MOV x21, x1                | X21 = args;//m1                         
        // 0x00FD70D8: TBNZ w8, #0, #0xfd70f4     | if (static_value_037353E6 == true) goto label_0;
        // 0x00FD70DC: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
        // 0x00FD70E0: LDR x8, [x8, #0x2a0]       | X8 = 0x2B900EC;                         
        // 0x00FD70E4: LDR w0, [x8]               | W0 = 0x16FF;                            
        // 0x00FD70E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x16FF, ????);     
        // 0x00FD70EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00FD70F0: STRB w8, [x22, #0x3e6]     | static_value_037353E6 = true;            //  dest_result_addr=57889766
        label_0:
        // 0x00FD70F4: ADRP x22, #0x3604000       | X22 = 56639488 (0x3604000);             
        // 0x00FD70F8: LDR x22, [x22, #0xb68]     | X22 = 1152921504901255168;              
        // 0x00FD70FC: LDR x8, [x22]              | X8 = typeof(CallJSApi);                 
        val_1 = null;
        // 0x00FD7100: LDRB w9, [x8, #0x10a]      | W9 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00FD7104: TBZ w9, #0, #0xfd711c      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00FD7108: LDR w9, [x8, #0xbc]        | W9 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00FD710C: CBNZ w9, #0xfd711c         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00FD7110: MOV x0, x8                 | X0 = 1152921504901255168 (0x10000000118C5000);//ML01
        // 0x00FD7114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        // 0x00FD7118: LDR x8, [x22]              | X8 = typeof(CallJSApi);                 
        val_1 = null;
        label_2:
        // 0x00FD711C: LDR x9, [x20, #0x30]       | X9 = X3 + 48;                           
        // 0x00FD7120: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00FD7124: MOV x3, x19                | X3 = __RuntimeMethodHiddenParam;//m1    
        // 0x00FD7128: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00FD712C: LDR x4, [x9]               | X4 = X3 + 48;                           
        // 0x00FD7130: LDR x1, [x8]               | X1 = CallJSApi.mhJSApi;                 
        // 0x00FD7134: MOV x2, x21                | X2 = args;//m1                          
        // 0x00FD7138: LDR x5, [x4]               | X5 = X3 + 48;                           
        // 0x00FD713C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00FD7140: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00FD7144: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00FD7148: BR x5                      | goto X3 + 48;                           
        goto X3 + 48;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA58C4 (12212420), len: 176  VirtAddr: 0x00BA58C4 RVA: 0x00BA58C4 token: 100692725 methodIndex: 25623 delegateWrapperIndex: 0 methodInvoker: 0
    public static void CallLoadJsObjToCs()
    {
        //
        // Disasemble & Code
        //  | 
        var val_1;
        // 0x00BA58C4: STP x22, x21, [sp, #-0x30]! | stack[1152921514874689808] = ???;  stack[1152921514874689816] = ???;  //  dest_result_addr=1152921514874689808 |  dest_result_addr=1152921514874689816
        // 0x00BA58C8: STP x20, x19, [sp, #0x10]  | stack[1152921514874689824] = ???;  stack[1152921514874689832] = ???;  //  dest_result_addr=1152921514874689824 |  dest_result_addr=1152921514874689832
        // 0x00BA58CC: STP x29, x30, [sp, #0x20]  | stack[1152921514874689840] = ???;  stack[1152921514874689848] = ???;  //  dest_result_addr=1152921514874689840 |  dest_result_addr=1152921514874689848
        // 0x00BA58D0: ADD x29, sp, #0x20         | X29 = (1152921514874689808 + 32) = 1152921514874689840 (0x100000026402D930);
        // 0x00BA58D4: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA58D8: LDRB w8, [x19, #0xad5]     | W8 = (bool)static_value_03733AD5;       
        // 0x00BA58DC: TBNZ w8, #0, #0xba58f8     | if (static_value_03733AD5 == true) goto label_0;
        // 0x00BA58E0: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
        // 0x00BA58E4: LDR x8, [x8, #0x198]       | X8 = 0x2B900F0;                         
        // 0x00BA58E8: LDR w0, [x8]               | W0 = 0x1700;                            
        // 0x00BA58EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1700, ????);     
        // 0x00BA58F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA58F4: STRB w8, [x19, #0xad5]     | static_value_03733AD5 = true;            //  dest_result_addr=57883349
        label_0:
        // 0x00BA58F8: ADRP x19, #0x3604000       | X19 = 56639488 (0x3604000);             
        // 0x00BA58FC: LDR x19, [x19, #0xb68]     | X19 = 1152921504901255168;              
        // 0x00BA5900: LDR x0, [x19]              | X0 = typeof(CallJSApi);                 
        val_1 = null;
        // 0x00BA5904: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00BA5908: TBZ w8, #0, #0xba591c      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA590C: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00BA5910: CBNZ w8, #0xba591c         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA5914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        // 0x00BA5918: LDR x0, [x19]              | X0 = typeof(CallJSApi);                 
        val_1 = null;
        label_2:
        // 0x00BA591C: ADRP x9, #0x3667000        | X9 = 57044992 (0x3667000);              
        // 0x00BA5920: ADRP x10, #0x3630000       | X10 = 56819712 (0x3630000);             
        // 0x00BA5924: LDR x8, [x0, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5928: LDR x9, [x9]               | X9 = (string**)(1152921514874677760)("LoadJsObjToCs");
        // 0x00BA592C: LDR x10, [x10, #0x3d0]     | X10 = 1152921504954501264;              
        // 0x00BA5930: LDR x20, [x8]              | X20 = CallJSApi.mhJSApi;                
        // 0x00BA5934: LDR x19, [x9]              | X19 = "LoadJsObjToCs";                  
        // 0x00BA5938: LDR x21, [x10]             | X21 = typeof(System.Object[]);          
        // 0x00BA593C: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5940: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5948: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA594C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5950: MOV x1, x20                | X1 = CallJSApi.mhJSApi;//m1             
        // 0x00BA5954: MOV x2, x19                | X2 = 1152921514874677760 (0x100000026402AA00);//ML01
        // 0x00BA5958: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA595C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5960: MOV x3, x0                 | X3 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5964: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA5968: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA596C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA5970: B #0xb64f40                | EILTypeInstance.EInvoke(_this:  0, method:  CallJSApi.mhJSApi, p:  "LoadJsObjToCs"); return;
        EILTypeInstance.EInvoke(_this:  0, method:  CallJSApi.mhJSApi, p:  "LoadJsObjToCs");
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5974 (12212596), len: 112  VirtAddr: 0x00BA5974 RVA: 0x00BA5974 token: 100692726 methodIndex: 25624 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetNeedNext(bool isNext)
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x00BA5974: STP x20, x19, [sp, #-0x20]! | stack[1152921514874801824] = ???;  stack[1152921514874801832] = ???;  //  dest_result_addr=1152921514874801824 |  dest_result_addr=1152921514874801832
        // 0x00BA5978: STP x29, x30, [sp, #0x10]  | stack[1152921514874801840] = ???;  stack[1152921514874801848] = ???;  //  dest_result_addr=1152921514874801840 |  dest_result_addr=1152921514874801848
        // 0x00BA597C: ADD x29, sp, #0x10         | X29 = (1152921514874801824 + 16) = 1152921514874801840 (0x1000000264048EB0);
        // 0x00BA5980: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA5984: LDRB w8, [x20, #0xad6]     | W8 = (bool)static_value_03733AD6;       
        // 0x00BA5988: MOV w19, w1                | W19 = isNext;//m1                       
        // 0x00BA598C: TBNZ w8, #0, #0xba59a8     | if (static_value_03733AD6 == true) goto label_0;
        // 0x00BA5990: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00BA5994: LDR x8, [x8, #0x520]       | X8 = 0x2B90108;                         
        // 0x00BA5998: LDR w0, [x8]               | W0 = 0x1706;                            
        // 0x00BA599C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1706, ????);     
        // 0x00BA59A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA59A4: STRB w8, [x20, #0xad6]     | static_value_03733AD6 = true;            //  dest_result_addr=57883350
        label_0:
        // 0x00BA59A8: ADRP x20, #0x3604000       | X20 = 56639488 (0x3604000);             
        // 0x00BA59AC: LDR x20, [x20, #0xb68]     | X20 = 1152921504901255168;              
        // 0x00BA59B0: LDR x0, [x20]              | X0 = typeof(CallJSApi);                 
        val_2 = null;
        // 0x00BA59B4: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00BA59B8: TBZ w8, #0, #0xba59cc      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA59BC: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00BA59C0: CBNZ w8, #0xba59cc         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA59C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        // 0x00BA59C8: LDR x0, [x20]              | X0 = typeof(CallJSApi);                 
        val_2 = null;
        label_2:
        // 0x00BA59CC: LDR x8, [x0, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA59D0: AND w9, w19, #1            | W9 = (isNext & 1);                      
        bool val_1 = isNext;
        // 0x00BA59D4: STRB w9, [x8, #0x10]       | CallJSApi.isNeedNext = (isNext & 1);     //  dest_result_addr=1152921504901259280
        CallJSApi.isNeedNext = val_1;
        // 0x00BA59D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA59DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA59E0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA59E4 (12212708), len: 316  VirtAddr: 0x00BA59E4 RVA: 0x00BA59E4 token: 100692727 methodIndex: 25625 delegateWrapperIndex: 0 methodInvoker: 0
    public static string GetJSHash(byte[] bytes)
    {
        //
        // Disasemble & Code
        //  | 
        string val_5;
        //  | 
        System.Byte[] val_6;
        // 0x00BA59E4: STP x26, x25, [sp, #-0x50]! | stack[1152921514874991600] = ???;  stack[1152921514874991608] = ???;  //  dest_result_addr=1152921514874991600 |  dest_result_addr=1152921514874991608
        // 0x00BA59E8: STP x24, x23, [sp, #0x10]  | stack[1152921514874991616] = ???;  stack[1152921514874991624] = ???;  //  dest_result_addr=1152921514874991616 |  dest_result_addr=1152921514874991624
        // 0x00BA59EC: STP x22, x21, [sp, #0x20]  | stack[1152921514874991632] = ???;  stack[1152921514874991640] = ???;  //  dest_result_addr=1152921514874991632 |  dest_result_addr=1152921514874991640
        // 0x00BA59F0: STP x20, x19, [sp, #0x30]  | stack[1152921514874991648] = ???;  stack[1152921514874991656] = ???;  //  dest_result_addr=1152921514874991648 |  dest_result_addr=1152921514874991656
        // 0x00BA59F4: STP x29, x30, [sp, #0x40]  | stack[1152921514874991664] = ???;  stack[1152921514874991672] = ???;  //  dest_result_addr=1152921514874991664 |  dest_result_addr=1152921514874991672
        // 0x00BA59F8: ADD x29, sp, #0x40         | X29 = (1152921514874991600 + 64) = 1152921514874991664 (0x1000000264077430);
        // 0x00BA59FC: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA5A00: LDRB w8, [x19, #0xad7]     | W8 = (bool)static_value_03733AD7;       
        // 0x00BA5A04: MOV x20, x1                | X20 = X1;//m1                           
        // 0x00BA5A08: TBNZ w8, #0, #0xba5a24     | if (static_value_03733AD7 == true) goto label_0;
        // 0x00BA5A0C: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00BA5A10: LDR x8, [x8, #0x958]       | X8 = 0x2B900FC;                         
        // 0x00BA5A14: LDR w0, [x8]               | W0 = 0x1703;                            
        // 0x00BA5A18: BL #0x2782188              | X0 = sub_2782188( ?? 0x1703, ????);     
        // 0x00BA5A1C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA5A20: STRB w8, [x19, #0xad7]     | static_value_03733AD7 = true;            //  dest_result_addr=57883351
        label_0:
        // 0x00BA5A24: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00BA5A28: LDR x8, [x8, #0x378]       | X8 = 1152921504643747840;               
        // 0x00BA5A2C: LDR x0, [x8]               | X0 = typeof(System.Security.Cryptography.MD5CryptoServiceProvider);
        System.Security.Cryptography.MD5CryptoServiceProvider val_1 = null;
        // 0x00BA5A30: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Security.Cryptography.MD5CryptoServiceProvider), ????);
        // 0x00BA5A34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5A38: MOV x21, x0                | X21 = 1152921504643747840 (0x1000000002331000);//ML01
        val_5 = val_1;
        // 0x00BA5A3C: BL #0x1128568              | .ctor();                                
        val_1 = new System.Security.Cryptography.MD5CryptoServiceProvider();
        // 0x00BA5A40: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00BA5A44: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x00BA5A48: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_2 = null;
        // 0x00BA5A4C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00BA5A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5A54: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA5A58: BL #0x1b5a30c              | .ctor();                                
        val_2 = new System.Text.StringBuilder();
        // 0x00BA5A5C: CBNZ x21, #0xba5a64        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00BA5A60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00BA5A64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5A68: MOV x0, x21                | X0 = 1152921504643747840 (0x1000000002331000);//ML01
        // 0x00BA5A6C: MOV x1, x20                | X1 = X1;//m1                            
        val_6 = X1;
        // 0x00BA5A70: BL #0x1126134              | X0 = ComputeHash(buffer:  val_6 = X1);  
        System.Byte[] val_3 = ComputeHash(buffer:  val_6);
        // 0x00BA5A74: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00BA5A78: CBNZ x20, #0xba5a80        | if (val_3 != null) goto label_2;        
        if(val_3 != null)
        {
            goto label_2;
        }
        // 0x00BA5A7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_2:
        // 0x00BA5A80: LDR x22, [x20, #0x18]      | X22 = val_3.Length; //P2                
        // 0x00BA5A84: CMP w22, #1                | STATE = COMPARE(val_3.Length, 0x1)      
        // 0x00BA5A88: B.LT #0xba5af4             | if (val_3.Length < 1) goto label_3;     
        if(val_3.Length < 1)
        {
            goto label_3;
        }
        // 0x00BA5A8C: ADRP x25, #0x3655000       | X25 = 56971264 (0x3655000);             
        // 0x00BA5A90: LDR x25, [x25, #0xda0]     | X25 = (string**)(1152921509424900384)("x2");
        // 0x00BA5A94: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        var val_5 = 0;
        // 0x00BA5A98: ADD x24, x20, #0x20        | X24 = val_3[0x20]; //PARR1              
        label_7:
        // 0x00BA5A9C: CBNZ x20, #0xba5aa4        | if (val_3 != null) goto label_4;        
        if(val_3 != null)
        {
            goto label_4;
        }
        // 0x00BA5AA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00BA5AA4: LDR w8, [x20, #0x18]       | W8 = val_3.Length; //P2                 
        // 0x00BA5AA8: CMP x23, x8                | STATE = COMPARE(0x0, val_3.Length)      
        // 0x00BA5AAC: B.LO #0xba5abc             | if (0 < val_3.Length) goto label_5;     
        if(val_5 < val_3.Length)
        {
            goto label_5;
        }
        // 0x00BA5AB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
        // 0x00BA5AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5AB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
        label_5:
        // 0x00BA5ABC: LDR x1, [x25]              | X1 = "x2";                              
        // 0x00BA5AC0: ADD x0, x24, x23           | X0 = val_3[0x20][0x0]; //PARR1          
        // 0x00BA5AC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5AC8: BL #0x18d5968              | X0 = label_System_Byte_ToString_GL018D5968();
        // 0x00BA5ACC: MOV x21, x0                | X21 = val_3[0x20][0x0];//m1             
        val_5 = val_3[32][val_5];
        // 0x00BA5AD0: CBNZ x19, #0xba5ad8        | if ( != 0) goto label_6;                
        if(null != 0)
        {
            goto label_6;
        }
        // 0x00BA5AD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3[0x20][0x0], ????);
        label_6:
        // 0x00BA5AD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5ADC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA5AE0: MOV x1, x21                | X1 = val_3[0x20][0x0];//m1              
        val_6 = val_5;
        // 0x00BA5AE4: BL #0x1b5b818              | X0 = Append(value:  val_6 = val_5);     
        System.Text.StringBuilder val_4 = Append(value:  val_6);
        // 0x00BA5AE8: ADD x23, x23, #1           | X23 = (0 + 1);                          
        val_5 = val_5 + 1;
        // 0x00BA5AEC: CMP w22, w23               | STATE = COMPARE(val_3.Length, (0 + 1))  
        // 0x00BA5AF0: B.NE #0xba5a9c             | if (val_3.Length != 0) goto label_7;    
        if(val_3.Length != val_5)
        {
            goto label_7;
        }
        label_3:
        // 0x00BA5AF4: CBNZ x19, #0xba5afc        | if ( != 0) goto label_8;                
        if(null != 0)
        {
            goto label_8;
        }
        // 0x00BA5AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00BA5AFC: LDR x8, [x19]              | X8 = ;                                  
        // 0x00BA5B00: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA5B04: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
        // 0x00BA5B08: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA5B0C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA5B10: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA5B14: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA5B18: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA5B1C: BR x2                      | goto mem[null + 320];                   
        goto mem[null + 320];
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA5B20 (12213024), len: 1860  VirtAddr: 0x00BA5B20 RVA: 0x00BA5B20 token: 100692728 methodIndex: 25626 delegateWrapperIndex: 0 methodInvoker: 0
    public static string GetJsNum()
    {
        //
        // Disasemble & Code
        //  | 
        string val_19;
        //  | 
        string val_20;
        //  | 
        bool val_21;
        //  | 
        string val_22;
        //  | 
        var val_23;
        //  | 
        string val_24;
        //  | 
        var val_25;
        //  | 
        bool val_26;
        // 0x00BA5B20: STP x26, x25, [sp, #-0x50]! | stack[1152921514875238928] = ???;  stack[1152921514875238936] = ???;  //  dest_result_addr=1152921514875238928 |  dest_result_addr=1152921514875238936
        // 0x00BA5B24: STP x24, x23, [sp, #0x10]  | stack[1152921514875238944] = ???;  stack[1152921514875238952] = ???;  //  dest_result_addr=1152921514875238944 |  dest_result_addr=1152921514875238952
        // 0x00BA5B28: STP x22, x21, [sp, #0x20]  | stack[1152921514875238960] = ???;  stack[1152921514875238968] = ???;  //  dest_result_addr=1152921514875238960 |  dest_result_addr=1152921514875238968
        // 0x00BA5B2C: STP x20, x19, [sp, #0x30]  | stack[1152921514875238976] = ???;  stack[1152921514875238984] = ???;  //  dest_result_addr=1152921514875238976 |  dest_result_addr=1152921514875238984
        // 0x00BA5B30: STP x29, x30, [sp, #0x40]  | stack[1152921514875238992] = ???;  stack[1152921514875239000] = ???;  //  dest_result_addr=1152921514875238992 |  dest_result_addr=1152921514875239000
        // 0x00BA5B34: ADD x29, sp, #0x40         | X29 = (1152921514875238928 + 64) = 1152921514875238992 (0x10000002640B3A50);
        // 0x00BA5B38: SUB sp, sp, #0x20          | SP = (1152921514875238928 - 32) = 1152921514875238896 (0x10000002640B39F0);
        // 0x00BA5B3C: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA5B40: LDRB w8, [x19, #0xad8]     | W8 = (bool)static_value_03733AD8;       
        // 0x00BA5B44: TBNZ w8, #0, #0xba5b60     | if (static_value_03733AD8 == true) goto label_0;
        // 0x00BA5B48: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
        // 0x00BA5B4C: LDR x8, [x8, #0x908]       | X8 = 0x2B90100;                         
        // 0x00BA5B50: LDR w0, [x8]               | W0 = 0x1704;                            
        // 0x00BA5B54: BL #0x2782188              | X0 = sub_2782188( ?? 0x1704, ????);     
        // 0x00BA5B58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA5B5C: STRB w8, [x19, #0xad8]     | static_value_03733AD8 = true;            //  dest_result_addr=57883352
        label_0:
        // 0x00BA5B60: ADRP x22, #0x3630000       | X22 = 56819712 (0x3630000);             
        // 0x00BA5B64: LDR x22, [x22, #0x3d0]     | X22 = 1152921504954501264;              
        // 0x00BA5B68: LDR x19, [x22]             | X19 = typeof(System.Object[]);          
        // 0x00BA5B6C: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5B70: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5B74: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA5B78: MOV x0, x19                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5B7C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5B80: ADRP x24, #0x3652000       | X24 = 56958976 (0x3652000);             
        // 0x00BA5B84: LDR x24, [x24, #0x140]     | X24 = 1152921504607113216;              
        // 0x00BA5B88: MOV x19, x0                | X19 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5B8C: MOVZ w9, #0x61             | W9 = 97 (0x61);//ML01                   
        // 0x00BA5B90: ADD x1, sp, #0x1c          | X1 = (1152921514875238896 + 28) = 1152921514875238924 (0x10000002640B3A0C);
        // 0x00BA5B94: LDR x8, [x24]              | X8 = typeof(System.Int32);              
        // 0x00BA5B98: STR w9, [sp, #0x1c]        | stack[1152921514875238924] = 0x61;       //  dest_result_addr=1152921514875238924
        // 0x00BA5B9C: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00BA5BA0: BL #0x27bc028              | X0 = 1152921514875283008 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 97);
        // 0x00BA5BA4: MOV x20, x0                | X20 = 1152921514875283008 (0x10000002640BE640);//ML01
        // 0x00BA5BA8: CBNZ x19, #0xba5bb0        | if ( != null) goto label_1;             
        if(null != null)
        {
            goto label_1;
        }
        // 0x00BA5BAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 97, ????);         
        label_1:
        // 0x00BA5BB0: CBZ x20, #0xba5bd4         | if (97 == 0) goto label_3;              
        if(97 == 0)
        {
            goto label_3;
        }
        // 0x00BA5BB4: LDR x8, [x19]              | X8 = ;                                  
        // 0x00BA5BB8: MOV x0, x20                | X0 = 1152921514875283008 (0x10000002640BE640);//ML01
        // 0x00BA5BBC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA5BC0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 97, ????);         
        // 0x00BA5BC4: CBNZ x0, #0xba5bd4         | if (97 != 0) goto label_3;              
        if(97 != 0)
        {
            goto label_3;
        }
        // 0x00BA5BC8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 97, ????);         
        // 0x00BA5BCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5BD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 97, ????);         
        label_3:
        // 0x00BA5BD4: LDR w8, [x19, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA5BD8: CBNZ w8, #0xba5be8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_4;
        // 0x00BA5BDC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 97, ????);         
        // 0x00BA5BE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5BE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 97, ????);         
        label_4:
        // 0x00BA5BE8: STR x20, [x19, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 97; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 97;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00BA5BEC: ADRP x23, #0x3604000       | X23 = 56639488 (0x3604000);             
        // 0x00BA5BF0: LDR x23, [x23, #0xb68]     | X23 = 1152921504901255168;              
        // 0x00BA5BF4: LDR x0, [x23]              | X0 = typeof(CallJSApi);                 
        // 0x00BA5BF8: LDRB w8, [x0, #0x10a]      | W8 = CallJSApi.__il2cppRuntimeField_10A;
        // 0x00BA5BFC: TBZ w8, #0, #0xba5c0c      | if (CallJSApi.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x00BA5C00: LDR w8, [x0, #0xbc]        | W8 = CallJSApi.__il2cppRuntimeField_cctor_finished;
        // 0x00BA5C04: CBNZ w8, #0xba5c0c         | if (CallJSApi.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x00BA5C08: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CallJSApi), ????);
        label_6:
        // 0x00BA5C0C: ADRP x25, #0x361a000       | X25 = 56729600 (0x361A000);             
        // 0x00BA5C10: LDR x25, [x25, #0x768]     | X25 = (string**)(1152921510105338336)("SetNeedNext");
        // 0x00BA5C14: MOV x2, x19                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5C18: LDR x1, [x25]              | X1 = "SetNeedNext";                     
        // 0x00BA5C1C: BL #0xba5838               | CallJSApi.CallJsFun(funName:  null, args:  "SetNeedNext");
        CallJSApi.CallJsFun(funName:  null, args:  "SetNeedNext");
        // 0x00BA5C20: LDR x8, [x23]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5C24: ADRP x9, #0x3641000        | X9 = 56889344 (0x3641000);              
        // 0x00BA5C28: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5C2C: LDR x9, [x9, #0xa30]       | X9 = 1152921504690233344;               
        // 0x00BA5C30: LDR x20, [x8, #8]          | X20 = CallJSApi.jsStr;                  
        // 0x00BA5C34: LDR x0, [x9]               | X0 = typeof(UnityEngine.AndroidJavaClass);
        UnityEngine.AndroidJavaClass val_1 = null;
        // 0x00BA5C38: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaClass), ????);
        // 0x00BA5C3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5C40: MOV x1, x20                | X1 = CallJSApi.jsStr;//m1               
        // 0x00BA5C44: MOV x19, x0                | X19 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00BA5C48: BL #0x20b9834              | .ctor(className:  CallJSApi.jsStr);     
        val_1 = new UnityEngine.AndroidJavaClass(className:  CallJSApi.jsStr);
        // 0x00BA5C4C: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x00BA5C50: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5C54: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5C58: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA5C5C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5C60: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5C64: LDR x8, [x24]              | X8 = typeof(System.Int32);              
        // 0x00BA5C68: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5C6C: MOVZ w9, #0x62             | W9 = 98 (0x62);//ML01                   
        // 0x00BA5C70: ADD x1, sp, #0x18          | X1 = (1152921514875238896 + 24) = 1152921514875238920 (0x10000002640B3A08);
        // 0x00BA5C74: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00BA5C78: STR w9, [sp, #0x18]        | stack[1152921514875238920] = 0x62;       //  dest_result_addr=1152921514875238920
        // 0x00BA5C7C: BL #0x27bc028              | X0 = 1152921514875287104 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 98);
        // 0x00BA5C80: MOV x21, x0                | X21 = 1152921514875287104 (0x10000002640BF640);//ML01
        // 0x00BA5C84: CBNZ x20, #0xba5c8c        | if ( != null) goto label_7;             
        if(null != null)
        {
            goto label_7;
        }
        // 0x00BA5C88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 98, ????);         
        label_7:
        // 0x00BA5C8C: CBZ x21, #0xba5cb0         | if (98 == 0) goto label_9;              
        if(98 == 0)
        {
            goto label_9;
        }
        // 0x00BA5C90: LDR x8, [x20]              | X8 = ;                                  
        // 0x00BA5C94: MOV x0, x21                | X0 = 1152921514875287104 (0x10000002640BF640);//ML01
        val_19 = 98;
        // 0x00BA5C98: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA5C9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 98, ????);         
        // 0x00BA5CA0: CBNZ x0, #0xba5cb0         | if (98 != 0) goto label_9;              
        if(98 != 0)
        {
            goto label_9;
        }
        // 0x00BA5CA4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 98, ????);         
        // 0x00BA5CA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5CAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 98, ????);         
        label_9:
        // 0x00BA5CB0: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA5CB4: CBNZ w8, #0xba5cc4         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_10;
        // 0x00BA5CB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 98, ????);         
        // 0x00BA5CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5CC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 98, ????);         
        label_10:
        // 0x00BA5CC4: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 98; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 98;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00BA5CC8: LDR x1, [x25]              | X1 = "SetNeedNext";                     
        // 0x00BA5CCC: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5CD0: BL #0xba5838               | CallJSApi.CallJsFun(funName:  98, args:  "SetNeedNext");
        CallJSApi.CallJsFun(funName:  98, args:  "SetNeedNext");
        // 0x00BA5CD4: LDR x8, [x23]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5CD8: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5CDC: LDR x20, [x8, #8]          | X20 = CallJSApi.jsStr;                  
        // 0x00BA5CE0: CBNZ x19, #0xba5ce8        | if ( != 0) goto label_11;               
        if(null != 0)
        {
            goto label_11;
        }
        // 0x00BA5CE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 98, ????);         
        label_11:
        // 0x00BA5CE8: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x00BA5CEC: LDR x8, [x8, #0x458]       | X8 = 1152921514474312400;               
        // 0x00BA5CF0: MOV x0, x19                | X0 = 1152921504690233344 (0x1000000004F86000);//ML01
        // 0x00BA5CF4: MOV x1, x20                | X1 = CallJSApi.jsStr;//m1               
        // 0x00BA5CF8: LDR x2, [x8]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00BA5CFC: BL #0x12e3528              | X0 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  CallJSApi.jsStr);
        UnityEngine.AndroidJavaObject val_2 = GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  CallJSApi.jsStr);
        // 0x00BA5D00: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x00BA5D04: MOV x19, x0                | X19 = val_2;//m1                        
        // 0x00BA5D08: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5D0C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5D10: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA5D14: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5D18: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5D1C: LDR x8, [x24]              | X8 = typeof(System.Int32);              
        // 0x00BA5D20: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5D24: MOVZ w9, #0x63             | W9 = 99 (0x63);//ML01                   
        // 0x00BA5D28: ADD x1, sp, #0x14          | X1 = (1152921514875238896 + 20) = 1152921514875238916 (0x10000002640B3A04);
        // 0x00BA5D2C: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00BA5D30: STR w9, [sp, #0x14]        | stack[1152921514875238916] = 0x63;       //  dest_result_addr=1152921514875238916
        // 0x00BA5D34: BL #0x27bc028              | X0 = 1152921514875295296 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 99);
        // 0x00BA5D38: MOV x21, x0                | X21 = 1152921514875295296 (0x10000002640C1640);//ML01
        // 0x00BA5D3C: CBNZ x20, #0xba5d44        | if ( != null) goto label_12;            
        if(null != null)
        {
            goto label_12;
        }
        // 0x00BA5D40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 99, ????);         
        label_12:
        // 0x00BA5D44: CBZ x21, #0xba5d68         | if (99 == 0) goto label_14;             
        if(99 == 0)
        {
            goto label_14;
        }
        // 0x00BA5D48: LDR x8, [x20]              | X8 = ;                                  
        // 0x00BA5D4C: MOV x0, x21                | X0 = 1152921514875295296 (0x10000002640C1640);//ML01
        val_20 = 99;
        // 0x00BA5D50: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA5D54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 99, ????);         
        // 0x00BA5D58: CBNZ x0, #0xba5d68         | if (99 != 0) goto label_14;             
        if(99 != 0)
        {
            goto label_14;
        }
        // 0x00BA5D5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 99, ????);         
        // 0x00BA5D60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5D64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 99, ????);         
        label_14:
        // 0x00BA5D68: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA5D6C: CBNZ w8, #0xba5d7c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_15;
        // 0x00BA5D70: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 99, ????);         
        // 0x00BA5D74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5D78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 99, ????);         
        label_15:
        // 0x00BA5D7C: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 99; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 99;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00BA5D80: LDR x1, [x25]              | X1 = "SetNeedNext";                     
        // 0x00BA5D84: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5D88: BL #0xba5838               | CallJSApi.CallJsFun(funName:  99, args:  "SetNeedNext");
        CallJSApi.CallJsFun(funName:  99, args:  "SetNeedNext");
        // 0x00BA5D8C: LDR x8, [x23]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5D90: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5D94: LDR x20, [x8, #8]          | X20 = CallJSApi.jsStr;                  
        // 0x00BA5D98: CBNZ x19, #0xba5da0        | if (val_2 != null) goto label_16;       
        if(val_2 != null)
        {
            goto label_16;
        }
        // 0x00BA5D9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 99, ????);         
        label_16:
        // 0x00BA5DA0: LDR x21, [x22]             | X21 = typeof(System.Object[]);          
        // 0x00BA5DA4: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5DA8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5DAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5DB0: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5DB4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5DB8: ADRP x26, #0x367a000       | X26 = 57122816 (0x367A000);             
        // 0x00BA5DBC: LDR x26, [x26, #0x220]     | X26 = 1152921514870544176;              
        // 0x00BA5DC0: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5DC4: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00BA5DC8: MOV x1, x20                | X1 = CallJSApi.jsStr;//m1               
        // 0x00BA5DCC: LDR x3, [x26]              | X3 = public System.String UnityEngine.AndroidJavaObject::Call<System.String>(string methodName, object[] args);
        // 0x00BA5DD0: BL #0x12f5e74              | X0 = val_2.Call<System.String>(methodName:  CallJSApi.jsStr, args:  null);
        string val_3 = val_2.Call<System.String>(methodName:  CallJSApi.jsStr, args:  null);
        // 0x00BA5DD4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00BA5DD8: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00BA5DDC: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00BA5DE0: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
        // 0x00BA5DE4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00BA5DE8: TBZ w9, #0, #0xba5dfc      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_18;
        // 0x00BA5DEC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA5DF0: CBNZ w9, #0xba5dfc         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
        // 0x00BA5DF4: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00BA5DF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_18:
        // 0x00BA5DFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA5E00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5E04: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00BA5E08: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
        UnityEngine.Debug.Log(message:  0);
        // 0x00BA5E0C: LDR x8, [x23]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5E10: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5E14: LDR x20, [x8, #8]          | X20 = CallJSApi.jsStr;                  
        // 0x00BA5E18: CBNZ x19, #0xba5e20        | if (val_2 != null) goto label_19;       
        if(val_2 != null)
        {
            goto label_19;
        }
        // 0x00BA5E1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_19:
        // 0x00BA5E20: LDR x21, [x22]             | X21 = typeof(System.Object[]);          
        // 0x00BA5E24: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5E28: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5E2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5E30: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5E34: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5E38: LDR x3, [x26]              | X3 = public System.String UnityEngine.AndroidJavaObject::Call<System.String>(string methodName, object[] args);
        // 0x00BA5E3C: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5E40: MOV x0, x19                | X0 = val_2;//m1                         
        // 0x00BA5E44: MOV x1, x20                | X1 = CallJSApi.jsStr;//m1               
        // 0x00BA5E48: BL #0x12f5e74              | X0 = val_2.Call<System.String>(methodName:  CallJSApi.jsStr, args:  null);
        string val_4 = val_2.Call<System.String>(methodName:  CallJSApi.jsStr, args:  null);
        // 0x00BA5E4C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00BA5E50: LDR x8, [x8, #0x558]       | X8 = 1152921504621490176;               
        // 0x00BA5E54: MOV x19, x0                | X19 = val_4;//m1                        
        // 0x00BA5E58: LDR x8, [x8]               | X8 = typeof(System.IO.FileStream);      
        // 0x00BA5E5C: MOV x0, x8                 | X0 = 1152921504621490176 (0x1000000000DF7000);//ML01
        System.IO.FileStream val_5 = null;
        // 0x00BA5E60: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.FileStream), ????);
        // 0x00BA5E64: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA5E68: ORR w2, wzr, #3            | W2 = 3(0x3);                            
        // 0x00BA5E6C: ORR w3, wzr, #1            | W3 = 1(0x1);                            
        // 0x00BA5E70: MOV x1, x19                | X1 = val_4;//m1                         
        // 0x00BA5E74: MOV x20, x0                | X20 = 1152921504621490176 (0x1000000000DF7000);//ML01
        // 0x00BA5E78: BL #0x1e74170              | .ctor(path:  val_4, mode:  3, access:  1);
        val_5 = new System.IO.FileStream(path:  val_4, mode:  3, access:  1);
        // 0x00BA5E7C: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
        // 0x00BA5E80: LDR x8, [x8, #0x330]       | X8 = 1152921504735707136;               
        // 0x00BA5E84: LDR x0, [x8]               | X0 = typeof(ICSharpCode.SharpZipLib.Zip.ZipFile);
        ICSharpCode.SharpZipLib.Zip.ZipFile val_6 = null;
        // 0x00BA5E88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ICSharpCode.SharpZipLib.Zip.ZipFile), ????);
        // 0x00BA5E8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5E90: MOV x1, x20                | X1 = 1152921504621490176 (0x1000000000DF7000);//ML01
        // 0x00BA5E94: MOV x19, x0                | X19 = 1152921504735707136 (0x1000000007AE4000);//ML01
        val_21 = val_6;
        // 0x00BA5E98: BL #0x266d500              | .ctor(file:  val_5);                    
        val_6 = new ICSharpCode.SharpZipLib.Zip.ZipFile(file:  val_5);
        // 0x00BA5E9C: LDR x20, [x22]             | X20 = typeof(System.Object[]);          
        // 0x00BA5EA0: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5EA4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5EA8: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA5EAC: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5EB0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5EB4: LDR x8, [x24]              | X8 = typeof(System.Int32);              
        // 0x00BA5EB8: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5EBC: MOVZ w9, #0x64             | W9 = 100 (0x64);//ML01                  
        // 0x00BA5EC0: ADD x1, sp, #0x10          | X1 = (1152921514875238896 + 16) = 1152921514875238912 (0x10000002640B3A00);
        // 0x00BA5EC4: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00BA5EC8: STR w9, [sp, #0x10]        | stack[1152921514875238912] = 0x64;       //  dest_result_addr=1152921514875238912
        // 0x00BA5ECC: BL #0x27bc028              | X0 = 1152921514875307584 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 100);
        // 0x00BA5ED0: MOV x21, x0                | X21 = 1152921514875307584 (0x10000002640C4640);//ML01
        // 0x00BA5ED4: CBNZ x20, #0xba5edc        | if ( != null) goto label_20;            
        if(null != null)
        {
            goto label_20;
        }
        // 0x00BA5ED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 100, ????);        
        label_20:
        // 0x00BA5EDC: CBZ x21, #0xba5f00         | if (100 == 0) goto label_22;            
        if(100 == 0)
        {
            goto label_22;
        }
        // 0x00BA5EE0: LDR x8, [x20]              | X8 = ;                                  
        // 0x00BA5EE4: MOV x0, x21                | X0 = 1152921514875307584 (0x10000002640C4640);//ML01
        val_22 = 100;
        // 0x00BA5EE8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA5EEC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 100, ????);        
        // 0x00BA5EF0: CBNZ x0, #0xba5f00         | if (100 != 0) goto label_22;            
        if(100 != 0)
        {
            goto label_22;
        }
        // 0x00BA5EF4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 100, ????);        
        // 0x00BA5EF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5EFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 100, ????);        
        label_22:
        // 0x00BA5F00: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA5F04: CBNZ w8, #0xba5f14         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_23;
        // 0x00BA5F08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 100, ????);        
        // 0x00BA5F0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5F10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 100, ????);        
        label_23:
        // 0x00BA5F14: STR x21, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 100; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 100;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00BA5F18: LDR x1, [x25]              | X1 = "SetNeedNext";                     
        // 0x00BA5F1C: MOV x2, x20                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5F20: BL #0xba5838               | CallJSApi.CallJsFun(funName:  100, args:  "SetNeedNext");
        CallJSApi.CallJsFun(funName:  100, args:  "SetNeedNext");
        // 0x00BA5F24: LDR x8, [x23]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5F28: LDR x21, [x22]             | X21 = typeof(System.Object[]);          
        // 0x00BA5F2C: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5F30: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5F34: LDR x20, [x8, #8]          | X20 = CallJSApi.jsStr;                  
        // 0x00BA5F38: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA5F3C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA5F40: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5F44: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA5F48: LDR x8, [x24]              | X8 = typeof(System.Int32);              
        // 0x00BA5F4C: MOV x21, x0                | X21 = 1152921504954501264 (0x1000000014B8C890);//ML01
        val_23 = null;
        // 0x00BA5F50: MOVZ w9, #0x6e             | W9 = 110 (0x6E);//ML01                  
        // 0x00BA5F54: ADD x1, sp, #0xc           | X1 = (1152921514875238896 + 12) = 1152921514875238908 (0x10000002640B39FC);
        // 0x00BA5F58: MOV x0, x8                 | X0 = 1152921504607113216 (0x1000000000041000);//ML01
        // 0x00BA5F5C: STR w9, [sp, #0xc]         | stack[1152921514875238908] = 0x6E;       //  dest_result_addr=1152921514875238908
        // 0x00BA5F60: BL #0x27bc028              | X0 = 1152921514875311680 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 110);
        // 0x00BA5F64: MOV x22, x0                | X22 = 1152921514875311680 (0x10000002640C5640);//ML01
        // 0x00BA5F68: CBNZ x21, #0xba5f70        | if ( != null) goto label_24;            
        if(null != null)
        {
            goto label_24;
        }
        // 0x00BA5F6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 110, ????);        
        label_24:
        // 0x00BA5F70: CBZ x22, #0xba5f94         | if (110 == 0) goto label_26;            
        if(110 == 0)
        {
            goto label_26;
        }
        // 0x00BA5F74: LDR x8, [x21]              | X8 = ;                                  
        // 0x00BA5F78: MOV x0, x22                | X0 = 1152921514875311680 (0x10000002640C5640);//ML01
        val_24 = 110;
        // 0x00BA5F7C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA5F80: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? 110, ????);        
        // 0x00BA5F84: CBNZ x0, #0xba5f94         | if (110 != 0) goto label_26;            
        if(110 != 0)
        {
            goto label_26;
        }
        // 0x00BA5F88: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? 110, ????);        
        // 0x00BA5F8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5F90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 110, ????);        
        label_26:
        // 0x00BA5F94: LDR w8, [x21, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA5F98: CBNZ w8, #0xba5fa8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_27;
        // 0x00BA5F9C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 110, ????);        
        // 0x00BA5FA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5FA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 110, ????);        
        label_27:
        // 0x00BA5FA8: STR x22, [x21, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = 110; typeof(System.Object[]).__il2cppRuntimeField_24 = 0x10000002;  //  dest_result_addr=1152921504954501296 dest_result_addr=1152921504954501300
        typeof(System.Object[]).__il2cppRuntimeField_20 = 110;
        typeof(System.Object[]).__il2cppRuntimeField_24 = 268435458;
        // 0x00BA5FAC: LDR x1, [x25]              | X1 = "SetNeedNext";                     
        // 0x00BA5FB0: MOV x2, x21                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA5FB4: BL #0xba5838               | CallJSApi.CallJsFun(funName:  110, args:  "SetNeedNext");
        CallJSApi.CallJsFun(funName:  110, args:  "SetNeedNext");
        // 0x00BA5FB8: LDR x8, [x23]              | X8 = typeof(CallJSApi);                 
        // 0x00BA5FBC: LDR x8, [x8, #0xa0]        | X8 = CallJSApi.__il2cppRuntimeField_static_fields;
        // 0x00BA5FC0: LDR x22, [x8, #8]          | X22 = CallJSApi.jsStr;                  
        // 0x00BA5FC4: CBNZ x19, #0xba5fcc        | if ( != 0) goto label_28;               
        if(null != 0)
        {
            goto label_28;
        }
        // 0x00BA5FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 110, ????);        
        label_28:
        // 0x00BA5FCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA5FD0: MOV x0, x19                | X0 = 1152921504735707136 (0x1000000007AE4000);//ML01
        // 0x00BA5FD4: BL #0x266e1d0              | X0 = get_Count();                       
        long val_7 = Count;
        // 0x00BA5FD8: MOV x23, x0                | X23 = val_7;//m1                        
        // 0x00BA5FDC: CMP w23, #0                | STATE = COMPARE(val_7, 0x0)             
        // 0x00BA5FE0: B.LE #0xba607c             | if (val_7 <= 0) goto label_29;          
        if(val_7 <= 0)
        {
            goto label_29;
        }
        // 0x00BA5FE4: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        label_38:
        // 0x00BA5FE8: CBNZ x19, #0xba5ff0        | if ( != 0) goto label_30;               
        if(null != 0)
        {
            goto label_30;
        }
        // 0x00BA5FEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_30:
        // 0x00BA5FF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA5FF4: MOV x0, x19                | X0 = 1152921504735707136 (0x1000000007AE4000);//ML01
        // 0x00BA5FF8: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00BA5FFC: BL #0x266e1f8              | X0 = get_EntryByIndex(index:  0);       
        ICSharpCode.SharpZipLib.Zip.ZipEntry val_8 = EntryByIndex[0];
        // 0x00BA6000: MOV x24, x0                | X24 = val_8;//m1                        
        // 0x00BA6004: CBNZ x24, #0xba600c        | if (val_8 != null) goto label_31;       
        if(val_8 != null)
        {
            goto label_31;
        }
        // 0x00BA6008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_31:
        // 0x00BA600C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6010: MOV x0, x24                | X0 = val_8;//m1                         
        // 0x00BA6014: BL #0x266be3c              | X0 = val_8.get_Name();                  
        string val_9 = val_8.Name;
        // 0x00BA6018: MOV x24, x0                | X24 = val_9;//m1                        
        // 0x00BA601C: CBNZ x24, #0xba6024        | if (val_9 != null) goto label_32;       
        if(val_9 != null)
        {
            goto label_32;
        }
        // 0x00BA6020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
        label_32:
        // 0x00BA6024: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6028: MOV x0, x24                | X0 = val_9;//m1                         
        // 0x00BA602C: BL #0x18a4460              | X0 = val_9.get_Length();                
        int val_10 = val_9.Length;
        // 0x00BA6030: CMP w0, #0xe               | STATE = COMPARE(val_10, 0xE)            
        // 0x00BA6034: B.LT #0xba6070             | if (val_10 < 14) goto label_35;         
        if(val_10 < 14)
        {
            goto label_35;
        }
        // 0x00BA6038: CBNZ x24, #0xba6040        | if (val_9 != null) goto label_34;       
        if(val_9 != null)
        {
            goto label_34;
        }
        // 0x00BA603C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_34:
        // 0x00BA6040: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6044: MOV x0, x24                | X0 = val_9;//m1                         
        // 0x00BA6048: MOV x1, x20                | X1 = CallJSApi.jsStr;//m1               
        // 0x00BA604C: BL #0x18add38              | X0 = val_9.StartsWith(value:  CallJSApi.jsStr);
        bool val_11 = val_9.StartsWith(value:  CallJSApi.jsStr);
        // 0x00BA6050: TBZ w0, #0, #0xba6070      | if (val_11 == false) goto label_35;     
        if(val_11 == false)
        {
            goto label_35;
        }
        // 0x00BA6054: CBNZ x24, #0xba605c        | if (val_9 != null) goto label_36;       
        if(val_9 != null)
        {
            goto label_36;
        }
        // 0x00BA6058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_36:
        // 0x00BA605C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6060: MOV x0, x24                | X0 = val_9;//m1                         
        // 0x00BA6064: MOV x1, x22                | X1 = CallJSApi.jsStr;//m1               
        // 0x00BA6068: BL #0x18ab0a0              | X0 = val_9.EndsWith(value:  CallJSApi.jsStr);
        bool val_12 = val_9.EndsWith(value:  CallJSApi.jsStr);
        // 0x00BA606C: TBNZ w0, #0, #0xba611c     | if (val_12 == true) goto label_37;      
        if(val_12 == true)
        {
            goto label_37;
        }
        label_35:
        // 0x00BA6070: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_23 = 0 + 1;
        // 0x00BA6074: CMP w21, w23               | STATE = COMPARE((0 + 1), val_7)         
        // 0x00BA6078: B.LT #0xba5fe8             | if (val_23 < val_7) goto label_38;      
        if(val_23 < val_7)
        {
            goto label_38;
        }
        label_29:
        // 0x00BA607C: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
        // 0x00BA6080: LDR x8, [x8, #0x8c0]       | X8 = (string**)(1152921514875210464)("-2");
        val_25 = "-2";
        // 0x00BA6084: B #0xba60fc                |  goto label_39;                         
        goto label_39;
        label_53:
        // 0x00BA6088: MOV x19, x0                | X19 = val_12;//m1                       
        val_26 = val_12;
        // 0x00BA608C: CMP w1, #1                 | STATE = COMPARE(CallJSApi.jsStr, 0x1)   
        // 0x00BA6090: B.NE #0xba6258             | if (CallJSApi.jsStr != 0x1) goto label_40;
        if(CallJSApi.jsStr != 1)
        {
            goto label_40;
        }
        // 0x00BA6094: MOV x0, x19                | X0 = val_12;//m1                        
        // 0x00BA6098: BL #0x981060               | X0 = sub_981060( ?? val_12, ????);      
        // 0x00BA609C: MOV x20, x0                | X20 = val_12;//m1                       
        // 0x00BA60A0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00BA60A4: LDR x19, [x20]             | X19 = val_12;                           
        val_21 = mem[val_12];
        val_21 = val_26;
        // 0x00BA60A8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
        // 0x00BA60AC: LDR x1, [x19]              | X1 = val_12;                            
        // 0x00BA60B0: LDR x0, [x8]               | X0 = typeof(System.Exception);          
        // 0x00BA60B4: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
        // 0x00BA60B8: TBZ w0, #0, #0xba6230      | if ((typeof(System.Exception) & 0x1) == 0) goto label_41;
        if((null & 1) == 0)
        {
            goto label_41;
        }
        // 0x00BA60BC: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
        // 0x00BA60C0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00BA60C4: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00BA60C8: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00BA60CC: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00BA60D0: TBZ w8, #0, #0xba60e0      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_43;
        // 0x00BA60D4: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA60D8: CBNZ w8, #0xba60e0         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_43;
        // 0x00BA60DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_43:
        // 0x00BA60E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA60E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA60E8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00BA60EC: MOV x1, x19                | X1 = val_12;//m1                        
        // 0x00BA60F0: BL #0xb5b538               | EDebug.LogError(message:  0, isShowStack:  val_21);
        EDebug.LogError(message:  0, isShowStack:  val_21);
        // 0x00BA60F4: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
        // 0x00BA60F8: LDR x8, [x8, #0xa20]       | X8 = (string**)(1152921513111461536)("-1");
        val_25 = "-1";
        label_39:
        // 0x00BA60FC: LDR x0, [x8]               | X0 = "-1";                              
        label_52:
        // 0x00BA6100: SUB sp, x29, #0x40         | SP = (1152921514875238992 - 64) = 1152921514875238928 (0x10000002640B3A10);
        // 0x00BA6104: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6108: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA610C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA6110: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA6114: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA6118: RET                        |  return (System.String)"-1";            
        return (string)val_25;
        //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        label_37:
        // 0x00BA611C: CBNZ x19, #0xba6124        | if ( != 0) goto label_44;               
        if(null != 0)
        {
            goto label_44;
        }
        // 0x00BA6120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
        label_44:
        // 0x00BA6124: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6128: MOV x0, x19                | X0 = 1152921504735707136 (0x1000000007AE4000);//ML01
        // 0x00BA612C: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00BA6130: BL #0x266e1f8              | X0 = get_EntryByIndex(index:  0);       
        ICSharpCode.SharpZipLib.Zip.ZipEntry val_13 = EntryByIndex[0];
        // 0x00BA6134: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00BA6138: CBNZ x20, #0xba6140        | if (val_13 != null) goto label_45;      
        if(val_13 != null)
        {
            goto label_45;
        }
        // 0x00BA613C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_45:
        // 0x00BA6140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6144: MOV x0, x20                | X0 = val_13;//m1                        
        // 0x00BA6148: BL #0x266be44              | X0 = val_13.get_Size();                 
        long val_14 = val_13.Size;
        // 0x00BA614C: MOV x20, x0                | X20 = val_14;//m1                       
        // 0x00BA6150: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00BA6154: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x00BA6158: LDR x22, [x8]              | X22 = typeof(System.Byte[]);            
        // 0x00BA615C: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA6160: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00BA6164: AND x1, x20, #0xffffffff   | X1 = (val_14 & 4294967295);             
        long val_15 = val_14 & 4294967295;
        // 0x00BA6168: MOV x0, x22                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA616C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00BA6170: MOV x20, x0                | X20 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA6174: CBNZ x19, #0xba617c        | if ( != 0) goto label_46;               
        if(null != 0)
        {
            goto label_46;
        }
        // 0x00BA6178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_46:
        // 0x00BA617C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6180: MOV x0, x19                | X0 = 1152921504735707136 (0x1000000007AE4000);//ML01
        // 0x00BA6184: MOV w1, w21                | W1 = 0 (0x0);//ML01                     
        // 0x00BA6188: BL #0x266e1f8              | X0 = get_EntryByIndex(index:  0);       
        ICSharpCode.SharpZipLib.Zip.ZipEntry val_16 = EntryByIndex[0];
        // 0x00BA618C: MOV x21, x0                | X21 = val_16;//m1                       
        // 0x00BA6190: CBNZ x19, #0xba6198        | if ( != 0) goto label_47;               
        if(null != 0)
        {
            goto label_47;
        }
        // 0x00BA6194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_47:
        // 0x00BA6198: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA619C: MOV x0, x19                | X0 = 1152921504735707136 (0x1000000007AE4000);//ML01
        // 0x00BA61A0: MOV x1, x21                | X1 = val_16;//m1                        
        // 0x00BA61A4: BL #0x266e578              | X0 = GetInputStream(entry:  val_16);    
        System.IO.Stream val_17 = GetInputStream(entry:  val_16);
        // 0x00BA61A8: MOV x19, x0                | X19 = val_17;//m1                       
        // 0x00BA61AC: CBNZ x20, #0xba61b4        | if ( != null) goto label_48;            
        if(null != null)
        {
            goto label_48;
        }
        // 0x00BA61B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_48:
        // 0x00BA61B4: CBNZ x19, #0xba61bc        | if (val_17 != null) goto label_49;      
        if(val_17 != null)
        {
            goto label_49;
        }
        // 0x00BA61B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_49:
        // 0x00BA61BC: LDR x8, [x19]              | X8 = typeof(System.IO.Stream);          
        // 0x00BA61C0: LDR w3, [x20, #0x18]       | W3 = System.Byte[].__il2cppRuntimeField_namespaze;
        // 0x00BA61C4: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
        // 0x00BA61C8: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
        // 0x00BA61CC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA61D0: MOV x0, x19                | X0 = val_17;//m1                        
        // 0x00BA61D4: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA61D8: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
        // 0x00BA61DC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
        // 0x00BA61E0: LDR x8, [x8, #0x530]       | X8 = 1152921504924098560;               
        // 0x00BA61E4: LDR x0, [x8]               | X0 = typeof(EDebug);                    
        // 0x00BA61E8: LDRB w8, [x0, #0x10a]      | W8 = EDebug.__il2cppRuntimeField_10A;   
        // 0x00BA61EC: TBZ w8, #0, #0xba61fc      | if (EDebug.__il2cppRuntimeField_has_cctor == 0) goto label_51;
        // 0x00BA61F0: LDR w8, [x0, #0xbc]        | W8 = EDebug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA61F4: CBNZ w8, #0xba61fc         | if (EDebug.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
        // 0x00BA61F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(EDebug), ????);
        label_51:
        // 0x00BA61FC: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x00BA6200: LDR x8, [x8, #0x8b8]       | X8 = (string**)(1152921514875222832)("32013");
        // 0x00BA6204: LDR x1, [x8]               | X1 = "32013";                           
        // 0x00BA6208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA620C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA6210: ORR w2, wzr, #1            | W2 = 1(0x1);                            
        // 0x00BA6214: BL #0xb45c10               | EDebug.Log(message:  0, isShowStack:  true);
        EDebug.Log(message:  0, isShowStack:  true);
        // 0x00BA6218: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA621C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6220: MOV x1, x20                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA6224: BL #0xb32bd0               | X0 = Assets.Plugin.apktools.RsaParse.PKCS7Parse(content:  0);
        string val_18 = Assets.Plugin.apktools.RsaParse.PKCS7Parse(content:  0);
        // 0x00BA6228: B #0xba6100                |  goto label_52;                         
        goto label_52;
        // 0x00BA622C: B #0xba6088                |  goto label_53;                         
        goto label_53;
        label_41:
        // 0x00BA6230: ORR w0, wzr, #8            | W0 = 8(0x8);                            
        // 0x00BA6234: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
        // 0x00BA6238: LDR x8, [x20]              | X8 = val_12;                            
        // 0x00BA623C: STR x8, [x0]               | mem[8] = val_12;                         //  dest_result_addr=8
        mem[8] = val_26;
        // 0x00BA6240: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
        // 0x00BA6244: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6248: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
        // 0x00BA624C: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
        // 0x00BA6250: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
        val_26 = 8;
        // 0x00BA6254: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
        label_40:
        // 0x00BA6258: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
        // 0x00BA625C: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
        // 0x00BA6260: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6264 (12214884), len: 1572  VirtAddr: 0x00BA6264 RVA: 0x00BA6264 token: 100692729 methodIndex: 25627 delegateWrapperIndex: 0 methodInvoker: 0
    public static byte[] LoadDataFromStreamPath(string fileName, int max = 0)
    {
        //
        // Disasemble & Code
        //  | 
        var val_20;
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        var val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        //  | 
        var val_26;
        //  | 
        var val_27;
        //  | 
        var val_28;
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_32;
        //  | 
        var val_33;
        //  | 
        var val_34;
        //  | 
        var val_35;
        //  | 
        var val_36;
        // 0x00BA6264: STP x28, x27, [sp, #-0x60]! | stack[1152921514875542880] = ???;  stack[1152921514875542888] = ???;  //  dest_result_addr=1152921514875542880 |  dest_result_addr=1152921514875542888
        // 0x00BA6268: STP x26, x25, [sp, #0x10]  | stack[1152921514875542896] = ???;  stack[1152921514875542904] = ???;  //  dest_result_addr=1152921514875542896 |  dest_result_addr=1152921514875542904
        // 0x00BA626C: STP x24, x23, [sp, #0x20]  | stack[1152921514875542912] = ???;  stack[1152921514875542920] = ???;  //  dest_result_addr=1152921514875542912 |  dest_result_addr=1152921514875542920
        // 0x00BA6270: STP x22, x21, [sp, #0x30]  | stack[1152921514875542928] = ???;  stack[1152921514875542936] = ???;  //  dest_result_addr=1152921514875542928 |  dest_result_addr=1152921514875542936
        // 0x00BA6274: STP x20, x19, [sp, #0x40]  | stack[1152921514875542944] = ???;  stack[1152921514875542952] = ???;  //  dest_result_addr=1152921514875542944 |  dest_result_addr=1152921514875542952
        // 0x00BA6278: STP x29, x30, [sp, #0x50]  | stack[1152921514875542960] = ???;  stack[1152921514875542968] = ???;  //  dest_result_addr=1152921514875542960 |  dest_result_addr=1152921514875542968
        // 0x00BA627C: ADD x29, sp, #0x50         | X29 = (1152921514875542880 + 80) = 1152921514875542960 (0x10000002640FDDB0);
        // 0x00BA6280: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA6284: LDRB w8, [x19, #0xad9]     | W8 = (bool)static_value_03733AD9;       
        // 0x00BA6288: MOV w20, w2                | W20 = W2;//m1                           
        val_32 = W2;
        // 0x00BA628C: MOV x21, x1                | X21 = max;//m1                          
        val_33 = max;
        // 0x00BA6290: TBNZ w8, #0, #0xba62ac     | if (static_value_03733AD9 == true) goto label_0;
        // 0x00BA6294: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
        // 0x00BA6298: LDR x8, [x8, #0x510]       | X8 = 0x2B90104;                         
        // 0x00BA629C: LDR w0, [x8]               | W0 = 0x1705;                            
        // 0x00BA62A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1705, ????);     
        // 0x00BA62A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA62A8: STRB w8, [x19, #0xad9]     | static_value_03733AD9 = true;            //  dest_result_addr=57883353
        label_0:
        // 0x00BA62AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA62B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA62B4: BL #0x20c6ffc              | X0 = UnityEngine.Application.get_isEditor();
        bool val_1 = UnityEngine.Application.isEditor;
        // 0x00BA62B8: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00BA62BC: TBZ w8, #0, #0xba6330      | if ((val_1 & 1) == false) goto label_1; 
        if(val_2 == false)
        {
            goto label_1;
        }
        // 0x00BA62C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA62C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA62C8: MOV x1, x21                | X1 = max;//m1                           
        // 0x00BA62CC: BL #0x1e71834              | X0 = System.IO.File.ReadAllBytes(path:  0);
        System.Byte[] val_3 = System.IO.File.ReadAllBytes(path:  0);
        // 0x00BA62D0: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00BA62D4: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
        // 0x00BA62D8: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00BA62DC: LDR x8, [x8]               | X8 = typeof(System.IO.MemoryStream);    
        // 0x00BA62E0: MOV x0, x8                 | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
        System.IO.MemoryStream val_4 = null;
        // 0x00BA62E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00BA62E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA62EC: MOV x1, x20                | X1 = val_3;//m1                         
        // 0x00BA62F0: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
        val_34 = val_4;
        // 0x00BA62F4: BL #0x1e78658              | .ctor(buffer:  val_3);                  
        val_4 = new System.IO.MemoryStream(buffer:  val_3);
        label_26:
        // 0x00BA62F8: CBNZ x19, #0xba6304        | if ( != 0) goto label_42;               
        if(null != 0)
        {
            goto label_42;
        }
        // 0x00BA62FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(buffer:  val_3), ????);
        // 0x00BA6300: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        val_34 = 0;
        label_42:
        // 0x00BA6304: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
        // 0x00BA6308: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
        // 0x00BA630C: LDR x2, [x8, #0x2e0]       | X2 = mem[282584257677407];              
        // 0x00BA6310: LDR x1, [x8, #0x2e8]       | X1 = mem[282584257677415];              
        // 0x00BA6314: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6318: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        val_32 = ???;
        // 0x00BA631C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        val_33 = ???;
        // 0x00BA6320: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA6324: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x00BA6328: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x00BA632C: BR x2                      | goto mem[282584257677407];              
        goto mem[282584257677407];
        label_1:
        // 0x00BA6330: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
        // 0x00BA6334: LDR x8, [x8, #0xc58]       | X8 = 1152921504621809664;               
        // 0x00BA6338: LDR x0, [x8]               | X0 = typeof(System.IO.MemoryStream);    
        System.IO.MemoryStream val_5 = null;
        // 0x00BA633C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00BA6340: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6344: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA6348: BL #0x1e762f4              | .ctor();                                
        val_5 = new System.IO.MemoryStream();
        // 0x00BA634C: ADRP x25, #0x3630000       | X25 = 56819712 (0x3630000);             
        // 0x00BA6350: LDR x25, [x25, #0x3d0]     | X25 = 1152921504954501264;              
        // 0x00BA6354: LDR x22, [x25]             | X22 = typeof(System.Object[]);          
        // 0x00BA6358: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA635C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA6360: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA6364: MOV x0, x22                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6368: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA636C: MOV x22, x0                | X22 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6370: CBNZ x22, #0xba6378        | if ( != null) goto label_3;             
        if(null != null)
        {
            goto label_3;
        }
        // 0x00BA6374: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_3:
        // 0x00BA6378: CBZ x21, #0xba639c         | if ( == 0) goto label_5;                
        if(val_33 == 0)
        {
            goto label_5;
        }
        // 0x00BA637C: LDR x8, [x22]              | X8 = ;                                  
        // 0x00BA6380: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA6384: MOV x0, x21                | X0 = X21;//m1                           
        // 0x00BA6388: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? , ????);           
        // 0x00BA638C: CBNZ x0, #0xba639c         | if ( != 0) goto label_5;                
        if(val_33 != 0)
        {
            goto label_5;
        }
        // 0x00BA6390: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? , ????);           
        // 0x00BA6394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6398: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
        label_5:
        // 0x00BA639C: LDR w8, [x22, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA63A0: CBNZ w8, #0xba63b0         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_6;
        // 0x00BA63A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? , ????);           
        // 0x00BA63A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA63AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
        label_6:
        // 0x00BA63B0: STR x21, [x22, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = ;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_33;
        // 0x00BA63B4: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
        // 0x00BA63B8: LDR x8, [x8, #0xff0]       | X8 = 1152921504690180096;               
        // 0x00BA63BC: LDR x0, [x8]               | X0 = typeof(UnityEngine.AndroidJavaObject);
        // 0x00BA63C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(UnityEngine.AndroidJavaObject), ????);
        // 0x00BA63C4: MOV x21, x0                | X21 = 1152921504690180096 (0x1000000004F79000);//ML01
        // 0x00BA63C8: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
        // 0x00BA63CC: LDR x8, [x8, #0x878]       | X8 = (string**)(1152921514875437312)("java.net.URL");
        // 0x00BA63D0: LDR x1, [x8]               | X1 = "java.net.URL";                    
        // 0x00BA63D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA63D8: MOV x0, x21                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
        UnityEngine.AndroidJavaObject val_6 = null;
        // 0x00BA63DC: MOV x2, x22                | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA63E0: BL #0x20bad84              | .ctor(className:  "java.net.URL", args:  null);
        val_6 = new UnityEngine.AndroidJavaObject(className:  "java.net.URL", args:  null);
        // 0x00BA63E4: CBNZ x21, #0xba63ec        | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x00BA63E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(className:  "java.net.URL", args:  null), ????);
        label_7:
        // 0x00BA63EC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00BA63F0: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921514875437408)("openConnection");
        // 0x00BA63F4: LDR x23, [x25]             | X23 = typeof(System.Object[]);          
        // 0x00BA63F8: LDR x22, [x8]              | X22 = "openConnection";                 
        // 0x00BA63FC: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6400: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA6404: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6408: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA640C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA6410: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6414: ADRP x26, #0x3608000       | X26 = 56655872 (0x3608000);             
        // 0x00BA6418: LDR x26, [x26, #0x710]     | X26 = 1152921514474317632;              
        // 0x00BA641C: LDR x3, [x26]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00BA6420: MOV x0, x21                | X0 = 1152921504690180096 (0x1000000004F79000);//ML01
        // 0x00BA6424: MOV x1, x22                | X1 = 1152921514875437408 (0x10000002640E4160);//ML01
        // 0x00BA6428: BL #0x12f5e74              | X0 = Call<UnityEngine.AndroidJavaObject>(methodName:  "openConnection", args:  null);
        UnityEngine.AndroidJavaObject val_7 = Call<UnityEngine.AndroidJavaObject>(methodName:  "openConnection", args:  null);
        // 0x00BA642C: MOV x22, x0                | X22 = val_7;//m1                        
        // 0x00BA6430: CBNZ x22, #0xba6438        | if (val_7 != null) goto label_8;        
        if(val_7 != null)
        {
            goto label_8;
        }
        // 0x00BA6434: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_8:
        // 0x00BA6438: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
        // 0x00BA643C: LDR x8, [x8, #0x750]       | X8 = (string**)(1152921514875441600)("getContentLength");
        // 0x00BA6440: LDR x23, [x25]             | X23 = typeof(System.Object[]);          
        // 0x00BA6444: LDR x21, [x8]              | X21 = "getContentLength";               
        // 0x00BA6448: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA644C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA6450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6454: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6458: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA645C: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6460: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x00BA6464: LDR x8, [x8, #0x6c0]       | X8 = 1152921514875441712;               
        // 0x00BA6468: LDR x3, [x8]               | X3 = public System.Int32 UnityEngine.AndroidJavaObject::Call<System.Int32>(string methodName, object[] args);
        // 0x00BA646C: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x00BA6470: MOV x1, x21                | X1 = 1152921514875441600 (0x10000002640E51C0);//ML01
        // 0x00BA6474: BL #0x12f5dd4              | X0 = val_7.Call<System.Int32>(methodName:  "getContentLength", args:  null);
        int val_8 = val_7.Call<System.Int32>(methodName:  "getContentLength", args:  null);
        // 0x00BA6478: MOV w21, w0                | W21 = val_8;//m1                        
        // 0x00BA647C: CMP w21, #1                | STATE = COMPARE(val_8, 0x1)             
        // 0x00BA6480: B.LT #0xba64c0             | if (val_8 < 1) goto label_9;            
        if(val_8 < 1)
        {
            goto label_9;
        }
        // 0x00BA6484: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00BA6488: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00BA648C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00BA6490: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00BA6494: TBZ w8, #0, #0xba64a4      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00BA6498: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00BA649C: CBNZ w8, #0xba64a4         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00BA64A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_11:
        // 0x00BA64A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA64A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA64AC: ORR w2, wzr, #0x8000       | W2 = 32768(0x8000);                     
        // 0x00BA64B0: MOV w1, w21                | W1 = val_8;//m1                         
        // 0x00BA64B4: BL #0x1a6e2fc              | X0 = UnityEngine.Mathf.Min(a:  0, b:  val_8);
        int val_9 = UnityEngine.Mathf.Min(a:  0, b:  val_8);
        // 0x00BA64B8: MOV w21, w0                | W21 = val_9;//m1                        
        val_35 = val_9;
        // 0x00BA64BC: B #0xba64c4                |  goto label_12;                         
        goto label_12;
        label_9:
        // 0x00BA64C0: ORR w21, wzr, #0x8000      | W21 = 32768(0x8000);                    
        val_35 = 32768;
        label_12:
        // 0x00BA64C4: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00BA64C8: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x00BA64CC: LDR x23, [x8]              | X23 = typeof(System.Byte[]);            
        // 0x00BA64D0: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA64D4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00BA64D8: MOV w1, w21                | W1 = 32768 (0x8000);//ML01              
        // 0x00BA64DC: MOV x0, x23                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA64E0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00BA64E4: MOV x21, x0                | X21 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA64E8: CBNZ x22, #0xba64f0        | if (val_7 != null) goto label_13;       
        if(val_7 != null)
        {
            goto label_13;
        }
        // 0x00BA64EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Byte[]), ????);
        label_13:
        // 0x00BA64F0: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
        // 0x00BA64F4: LDR x8, [x8, #0xe58]       | X8 = (string**)(1152921514875442736)("getInputStream");
        // 0x00BA64F8: LDR x24, [x25]             | X24 = typeof(System.Object[]);          
        // 0x00BA64FC: LDR x23, [x8]              | X23 = "getInputStream";                 
        // 0x00BA6500: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6504: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA6508: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA650C: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6510: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA6514: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6518: LDR x3, [x26]              | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00BA651C: MOV x0, x22                | X0 = val_7;//m1                         
        // 0x00BA6520: MOV x1, x23                | X1 = 1152921514875442736 (0x10000002640E5630);//ML01
        // 0x00BA6524: BL #0x12f5e74              | X0 = val_7.Call<UnityEngine.AndroidJavaObject>(methodName:  "getInputStream", args:  null);
        UnityEngine.AndroidJavaObject val_10 = val_7.Call<UnityEngine.AndroidJavaObject>(methodName:  "getInputStream", args:  null);
        // 0x00BA6528: MOV x22, x0                | X22 = val_10;//m1                       
        // 0x00BA652C: LDR x23, [x25]             | X23 = typeof(System.Object[]);          
        // 0x00BA6530: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6534: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA6538: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA653C: MOV x0, x23                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6540: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA6544: MOV x23, x0                | X23 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6548: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
        // 0x00BA654C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
        // 0x00BA6550: LDR x0, [x8]               | X0 = typeof(System.Type);               
        // 0x00BA6554: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
        // 0x00BA6558: LDR x8, [x8, #0x888]       | X8 = 1152921504996170800;               
        // 0x00BA655C: LDR x24, [x8]              | X24 = typeof(System.Byte[]);            
        // 0x00BA6560: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
        // 0x00BA6564: TBZ w8, #0, #0xba6574      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00BA6568: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
        // 0x00BA656C: CBNZ w8, #0xba6574         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00BA6570: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
        label_15:
        // 0x00BA6574: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6578: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA657C: MOV x1, x24                | X1 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA6580: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
        // 0x00BA6584: MOV x24, x0                | X24 = val_11;//m1                       
        // 0x00BA6588: CBNZ x23, #0xba6590        | if ( != null) goto label_16;            
        if(null != null)
        {
            goto label_16;
        }
        // 0x00BA658C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_16:
        // 0x00BA6590: CBZ x24, #0xba65b4         | if (val_11 == null) goto label_18;      
        if(val_11 == null)
        {
            goto label_18;
        }
        // 0x00BA6594: LDR x8, [x23]              | X8 = ;                                  
        // 0x00BA6598: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA659C: MOV x0, x24                | X0 = val_11;//m1                        
        // 0x00BA65A0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
        // 0x00BA65A4: CBNZ x0, #0xba65b4         | if (val_11 != null) goto label_18;      
        if(val_11 != null)
        {
            goto label_18;
        }
        // 0x00BA65A8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
        // 0x00BA65AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA65B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_18:
        // 0x00BA65B4: LDR w8, [x23, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA65B8: CBNZ w8, #0xba65c8         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_19;
        // 0x00BA65BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
        // 0x00BA65C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA65C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
        label_19:
        // 0x00BA65C8: STR x24, [x23, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = val_11;  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = val_11;
        // 0x00BA65CC: CBNZ x22, #0xba65d4        | if (val_10 != null) goto label_20;      
        if(val_10 != null)
        {
            goto label_20;
        }
        // 0x00BA65D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_20:
        // 0x00BA65D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA65D8: MOV x0, x22                | X0 = val_10;//m1                        
        // 0x00BA65DC: BL #0x20b7380              | X0 = val_10.GetRawClass();              
        IntPtr val_12 = val_10.GetRawClass();
        // 0x00BA65E0: MOV x24, x0                | X24 = val_12;//m1                       
        // 0x00BA65E4: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
        // 0x00BA65E8: LDR x8, [x8, #0x4f8]       | X8 = 1152921514875451024;               
        // 0x00BA65EC: LDR x2, [x8]               | X2 = public static System.String UnityEngine.AndroidJNIHelper::GetSignature<System.Int32>(object[] args);
        // 0x00BA65F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA65F4: MOV x1, x23                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA65F8: BL #0x10cdf4c              | X0 = UnityEngine.AndroidJNIHelper.GetSignature<System.Int32>(args:  0);
        string val_13 = UnityEngine.AndroidJNIHelper.GetSignature<System.Int32>(args:  0);
        // 0x00BA65FC: MOV x3, x0                 | X3 = val_13;//m1                        
        // 0x00BA6600: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
        // 0x00BA6604: LDR x8, [x8, #0xa18]       | X8 = (string**)(1152921514875456144)("read");
        // 0x00BA6608: LDR x2, [x8]               | X2 = "read";                            
        // 0x00BA660C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6610: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA6614: MOV x1, x24                | X1 = val_12;//m1                        
        // 0x00BA6618: BL #0x20c42a8              | X0 = UnityEngine.AndroidJNIHelper.GetMethodID(javaClass:  0, methodName:  val_12, signature:  "read");
        IntPtr val_14 = UnityEngine.AndroidJNIHelper.GetMethodID(javaClass:  0, methodName:  val_12, signature:  "read");
        // 0x00BA661C: MOV x23, x0                | X23 = val_14;//m1                       
        // 0x00BA6620: LDR x24, [x25]             | X24 = typeof(System.Object[]);          
        // 0x00BA6624: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6628: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA662C: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00BA6630: MOV x0, x24                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6634: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA6638: MOV x24, x0                | X24 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA663C: CBNZ x24, #0xba6644        | if ( != null) goto label_21;            
        if(null != null)
        {
            goto label_21;
        }
        // 0x00BA6640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
        label_21:
        // 0x00BA6644: CBZ x21, #0xba6668         | if ( == null) goto label_23;            
        if(null == null)
        {
            goto label_23;
        }
        // 0x00BA6648: LDR x8, [x24]              | X8 = ;                                  
        // 0x00BA664C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
        // 0x00BA6650: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00BA6654: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(System.Byte[]), ????);
        // 0x00BA6658: CBNZ x0, #0xba6668         | if ( != null) goto label_23;            
        if(null != null)
        {
            goto label_23;
        }
        // 0x00BA665C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(System.Byte[]), ????);
        // 0x00BA6660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6664: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
        label_23:
        // 0x00BA6668: LDR w8, [x24, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
        // 0x00BA666C: CBNZ w8, #0xba667c         | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_24;
        // 0x00BA6670: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.Byte[]), ????);
        // 0x00BA6674: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6678: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Byte[]), ????);
        label_24:
        // 0x00BA667C: STR x21, [x24, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = typeof(System.Byte[]);  //  dest_result_addr=1152921504954501296
        typeof(System.Object[]).__il2cppRuntimeField_20 = null;
        // 0x00BA6680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6684: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6688: MOV x1, x24                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA668C: BL #0x20be290              | X0 = UnityEngine.AndroidJNIHelper.CreateJNIArgArray(args:  0);
        UnityEngine.jvalue[] val_15 = UnityEngine.AndroidJNIHelper.CreateJNIArgArray(args:  0);
        // 0x00BA6690: MOV x21, x0                | X21 = val_15;//m1                       
        // 0x00BA6694: CBNZ x22, #0xba669c        | if (val_10 != null) goto label_25;      
        if(val_10 != null)
        {
            goto label_25;
        }
        // 0x00BA6698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
        label_25:
        // 0x00BA669C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA66A0: MOV x0, x22                | X0 = val_10;//m1                        
        // 0x00BA66A4: BL #0x20b7a48              | X0 = val_10.GetRawObject();             
        IntPtr val_16 = val_10.GetRawObject();
        // 0x00BA66A8: MOV x24, x0                | X24 = val_16;//m1                       
        // 0x00BA66AC: ADRP x27, #0x3652000       | X27 = 56958976 (0x3652000);             
        // 0x00BA66B0: LDR x27, [x27, #0xcf0]     | X27 = 1152921514875493088;              
        // 0x00BA66B4: MOV w22, w20               | W22 = W20;//m1                          
        var val_33 = val_32;
        label_34:
        // 0x00BA66B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA66BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00BA66C0: MOV x1, x24                | X1 = val_16;//m1                        
        // 0x00BA66C4: MOV x2, x23                | X2 = val_14;//m1                        
        // 0x00BA66C8: MOV x3, x21                | X3 = val_15;//m1                        
        // 0x00BA66CC: BL #0x20c0b54              | X0 = UnityEngine.AndroidJNI.CallIntMethod(obj:  0, methodID:  val_16, args:  val_14);
        int val_17 = UnityEngine.AndroidJNI.CallIntMethod(obj:  0, methodID:  val_16, args:  val_14);
        // 0x00BA66D0: MOV w25, w0                | W25 = val_17;//m1                       
        // 0x00BA66D4: CMN w25, #1                | STATE = COMPARE(val_17, 0x1)            
        // 0x00BA66D8: B.EQ #0xba62f8             | if (val_17 == 1) goto label_26;         
        if(val_17 == 1)
        {
            goto label_26;
        }
        // 0x00BA66DC: CBNZ x21, #0xba66e4        | if (val_15 != null) goto label_27;      
        if(val_15 != null)
        {
            goto label_27;
        }
        // 0x00BA66E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
        label_27:
        // 0x00BA66E4: LDR w8, [x21, #0x18]       | W8 = val_15.Length; //P2                
        // 0x00BA66E8: CBNZ w8, #0xba66f8         | if (val_15.Length != 0) goto label_28;  
        if(val_15.Length != 0)
        {
            goto label_28;
        }
        // 0x00BA66EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
        // 0x00BA66F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA66F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
        label_28:
        // 0x00BA66F8: LDR x1, [x21, #0x20]       | X1 = val_15[0]                          
        UnityEngine.jvalue val_32 = val_15[0];
        // 0x00BA66FC: LDR x2, [x27]              | X2 = public static System.Byte[] UnityEngine.AndroidJNIHelper::ConvertFromJNIArray<System.Byte[]>(IntPtr array);
        // 0x00BA6700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA6704: BL #0x12e045c              | X0 = UnityEngine.AndroidJNIHelper.ConvertFromJNIArray<System.Byte[]>(array:  0);
        System.Byte[] val_18 = UnityEngine.AndroidJNIHelper.ConvertFromJNIArray<System.Byte[]>(array:  0);
        // 0x00BA6708: MOV x26, x0                | X26 = val_18;//m1                       
        // 0x00BA670C: CMP w20, #1                | STATE = COMPARE(, 0x1)                  
        // 0x00BA6710: B.GE #0xba6740             | if (val_32 >= 0x1) goto label_29;       
        if(val_32 >= 1)
        {
            goto label_29;
        }
        // 0x00BA6714: CBNZ x19, #0xba671c        | if ( != 0) goto label_30;               
        if(null != 0)
        {
            goto label_30;
        }
        // 0x00BA6718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_30:
        // 0x00BA671C: LDR x8, [x19]              | X8 = ;                                  
        // 0x00BA6720: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
        // 0x00BA6724: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
        // 0x00BA6728: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA672C: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA6730: MOV x1, x26                | X1 = val_18;//m1                        
        // 0x00BA6734: MOV w3, w25                | W3 = val_17;//m1                        
        // 0x00BA6738: BLR x9                     | X0 = mem[null + 608]();                 
        // 0x00BA673C: B #0xba66b8                |  goto label_34;                         
        goto label_34;
        label_29:
        // 0x00BA6740: SUB w8, w25, w22           | W8 = (val_17 - val_32);                 
        int val_19 = val_17 - val_33;
        // 0x00BA6744: TBZ w8, #0x1f, #0xba6824   | if (((val_17 - val_32) & 0x80000000) == 0) goto label_32;
        if((val_19 & 2147483648) == 0)
        {
            goto label_32;
        }
        // 0x00BA6748: CBNZ x19, #0xba6750        | if ( != 0) goto label_33;               
        if(null != 0)
        {
            goto label_33;
        }
        // 0x00BA674C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_33:
        // 0x00BA6750: LDR x8, [x19]              | X8 = ;                                  
        // 0x00BA6754: SUB w22, w22, w25          | W22 = (val_32 - val_17);                
        val_33 = val_33 - val_17;
        // 0x00BA6758: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
        // 0x00BA675C: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
        // 0x00BA6760: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA6764: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA6768: MOV x1, x26                | X1 = val_18;//m1                        
        // 0x00BA676C: MOV w3, w25                | W3 = val_17;//m1                        
        // 0x00BA6770: BLR x9                     | X0 = mem[null + 608]();                 
        // 0x00BA6774: B #0xba66b8                |  goto label_34;                         
        goto label_34;
        // 0x00BA6778: B #0xba677c                |  goto label_43;                         
        goto label_43;
        label_43:
        // 0x00BA677C: MOV x19, x0                | X19 = 1152921504621809664 (0x1000000000E45000);//ML01
        val_36 = val_5;
        // 0x00BA6780: CMP w1, #1                 | STATE = COMPARE(val_18, 0x1)            
        // 0x00BA6784: B.NE #0xba687c             | if (val_18 != 0x1) goto label_36;       
        if(val_18 != 1)
        {
            goto label_36;
        }
        // 0x00BA6788: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA678C: BL #0x981060               | X0 = sub_981060( ?? typeof(System.IO.MemoryStream), ????);
        // 0x00BA6790: MOV x20, x0                | X20 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA6794: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
        // 0x00BA6798: LDR x19, [x20]             | X19 = ;                                 
        // 0x00BA679C: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
        // 0x00BA67A0: LDR x1, [x19]              |  //  not_find_field!1:0
        // 0x00BA67A4: LDR x0, [x8]               | X0 = typeof(System.Exception);          
        // 0x00BA67A8: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
        // 0x00BA67AC: TBZ w0, #0, #0xba6854      | if ((typeof(System.Exception) & 0x1) == 0) goto label_37;
        if((null & 1) == 0)
        {
            goto label_37;
        }
        // 0x00BA67B0: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
        // 0x00BA67B4: CBNZ x19, #0xba67bc        | if ( != 0) goto label_38;               
        if(null != 0)
        {
            goto label_38;
        }
        // 0x00BA67B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Exception), ????);
        label_38:
        // 0x00BA67BC: LDR x8, [x19]              |  //  not_find_field!1:0
        // 0x00BA67C0: MOV x0, x19                | X0 = X19;//m1                           
        // 0x00BA67C4: LDP x9, x1, [x8, #0x140]   | X9 = mem[null] + 320; X1 = mem[null] + 320 + 8; //  | 
        // 0x00BA67C8: BLR x9                     | X0 = mem[null] + 320();                 
        // 0x00BA67CC: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00BA67D0: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00BA67D4: MOV x19, x0                | X19 = X0;//m1                           
        // 0x00BA67D8: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
        // 0x00BA67DC: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00BA67E0: TBZ w9, #0, #0xba67f4      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00BA67E4: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00BA67E8: CBNZ w9, #0xba67f4         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00BA67EC: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
        // 0x00BA67F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_40:
        // 0x00BA67F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA67F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA67FC: MOV x1, x19                | X1 = X19;//m1                           
        // 0x00BA6800: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
        UnityEngine.Debug.LogError(message:  0);
        // 0x00BA6804: LDP x29, x30, [sp, #0x50]  | X29 = val_20; X30 = val_21;              //  find_add[1152921514875530976] |  find_add[1152921514875530976]
        // 0x00BA6808: LDP x20, x19, [sp, #0x40]  | X20 = val_22; X19 = val_23;              //  find_add[1152921514875530976] |  find_add[1152921514875530976]
        // 0x00BA680C: LDP x22, x21, [sp, #0x30]  | X22 = val_24; X21 = val_25;              //  find_add[1152921514875530976] |  find_add[1152921514875530976]
        // 0x00BA6810: LDP x24, x23, [sp, #0x20]  | X24 = val_26; X23 = val_27;              //  find_add[1152921514875530976] |  find_add[1152921514875530976]
        // 0x00BA6814: LDP x26, x25, [sp, #0x10]  | X26 = val_28; X25 = val_29;              //  find_add[1152921514875530976] |  find_add[1152921514875530976]
        // 0x00BA6818: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA681C: LDP x28, x27, [sp], #0x60  | X28 = val_30; X27 = val_31;              //  find_add[1152921514875530976] |  find_add[1152921514875530976]
        // 0x00BA6820: RET                        |  return (System.Byte[])null;            
        return (System.Byte[])0;
        //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        label_32:
        // 0x00BA6824: CBNZ x19, #0xba682c        | if ( != 0) goto label_41;               
        if(null != 0)
        {
            goto label_41;
        }
        // 0x00BA6828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
        label_41:
        // 0x00BA682C: LDR x8, [x19]              | X8 = ;                                  
        // 0x00BA6830: LDR x9, [x8, #0x260]       |  //  not_find_field!1:608
        // 0x00BA6834: LDR x4, [x8, #0x268]       |  //  not_find_field!1:616
        // 0x00BA6838: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x00BA683C: MOV x0, x19                | X0 = 1152921504621809664 (0x1000000000E45000);//ML01
        // 0x00BA6840: MOV x1, x26                | X1 = val_18;//m1                        
        // 0x00BA6844: MOV w3, w22                | W3 = W22;//m1                           
        // 0x00BA6848: BLR x9                     | X0 = mem[null + 608]();                 
        // 0x00BA684C: B #0xba6304                |  goto label_42;                         
        goto label_42;
        // 0x00BA6850: B #0xba677c                |  goto label_43;                         
        goto label_43;
        label_37:
        // 0x00BA6854: ORR w0, wzr, #8            | W0 = 8(0x8);                            
        // 0x00BA6858: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
        // 0x00BA685C: LDR x8, [x20]              | X8 = ;                                  
        // 0x00BA6860: STR x8, [x0]               | mem[8] = ;                               //  dest_result_addr=8
        mem[8] = null;
        // 0x00BA6864: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
        // 0x00BA6868: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA686C: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
        // 0x00BA6870: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
        // 0x00BA6874: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
        val_36 = 8;
        // 0x00BA6878: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
        label_36:
        // 0x00BA687C: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
        // 0x00BA6880: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
        // 0x00BA6884: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6888 (12216456), len: 260  VirtAddr: 0x00BA6888 RVA: 0x00BA6888 token: 100692730 methodIndex: 25628 delegateWrapperIndex: 0 methodInvoker: 0
    public static string Bytes2String(byte[] bytes, string arg)
    {
        //
        // Disasemble & Code
        //  | 
        string val_4;
        // 0x00BA6888: STP x26, x25, [sp, #-0x50]! | stack[1152921514875831024] = ???;  stack[1152921514875831032] = ???;  //  dest_result_addr=1152921514875831024 |  dest_result_addr=1152921514875831032
        // 0x00BA688C: STP x24, x23, [sp, #0x10]  | stack[1152921514875831040] = ???;  stack[1152921514875831048] = ???;  //  dest_result_addr=1152921514875831040 |  dest_result_addr=1152921514875831048
        // 0x00BA6890: STP x22, x21, [sp, #0x20]  | stack[1152921514875831056] = ???;  stack[1152921514875831064] = ???;  //  dest_result_addr=1152921514875831056 |  dest_result_addr=1152921514875831064
        // 0x00BA6894: STP x20, x19, [sp, #0x30]  | stack[1152921514875831072] = ???;  stack[1152921514875831080] = ???;  //  dest_result_addr=1152921514875831072 |  dest_result_addr=1152921514875831080
        // 0x00BA6898: STP x29, x30, [sp, #0x40]  | stack[1152921514875831088] = ???;  stack[1152921514875831096] = ???;  //  dest_result_addr=1152921514875831088 |  dest_result_addr=1152921514875831096
        // 0x00BA689C: ADD x29, sp, #0x40         | X29 = (1152921514875831024 + 64) = 1152921514875831088 (0x1000000264144330);
        // 0x00BA68A0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA68A4: LDRB w8, [x20, #0xada]     | W8 = (bool)static_value_03733ADA;       
        // 0x00BA68A8: MOV x19, x1                | X19 = arg;//m1                          
        // 0x00BA68AC: TBNZ w8, #0, #0xba68c8     | if (static_value_03733ADA == true) goto label_0;
        // 0x00BA68B0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
        // 0x00BA68B4: LDR x8, [x8, #0xb78]       | X8 = 0x2B900E0;                         
        // 0x00BA68B8: LDR w0, [x8]               | W0 = 0x16FC;                            
        // 0x00BA68BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x16FC, ????);     
        // 0x00BA68C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA68C4: STRB w8, [x20, #0xada]     | static_value_03733ADA = true;            //  dest_result_addr=57883354
        label_0:
        // 0x00BA68C8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
        // 0x00BA68CC: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
        // 0x00BA68D0: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
        System.Text.StringBuilder val_1 = null;
        // 0x00BA68D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
        // 0x00BA68D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        val_4 = 0;
        // 0x00BA68DC: MOV x20, x0                | X20 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA68E0: BL #0x1b5a30c              | .ctor();                                
        val_1 = new System.Text.StringBuilder();
        // 0x00BA68E4: CBNZ x19, #0xba68ec        | if (arg != null) goto label_1;          
        if(arg != null)
        {
            goto label_1;
        }
        // 0x00BA68E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00BA68EC: LDR x22, [x19, #0x18]      | 
        // 0x00BA68F0: CMP w22, #1                | STATE = COMPARE(W22, 0x1)               
        // 0x00BA68F4: B.LT #0xba6960             | if (W22 < 0x1) goto label_2;            
        if(W22 < 1)
        {
            goto label_2;
        }
        // 0x00BA68F8: ADRP x25, #0x3655000       | X25 = 56971264 (0x3655000);             
        // 0x00BA68FC: LDR x25, [x25, #0xda0]     | X25 = (string**)(1152921509424900384)("x2");
        // 0x00BA6900: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        var val_4 = 0;
        // 0x00BA6904: ADD x24, x19, #0x20        | X24 = (arg + 32);                       
        string val_2 = arg + 32;
        label_6:
        // 0x00BA6908: CBNZ x19, #0xba6910        | if (arg != null) goto label_3;          
        if(arg != null)
        {
            goto label_3;
        }
        // 0x00BA690C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_3:
        // 0x00BA6910: LDR w8, [x19, #0x18]       | 
        // 0x00BA6914: CMP x23, x8                | STATE = COMPARE(0x0, 1152921504649605120)
        // 0x00BA6918: B.LO #0xba6928             | if (0 < 1152921504649605120) goto label_4;
        if(val_4 < 1152921504649605120)
        {
            goto label_4;
        }
        // 0x00BA691C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
        // 0x00BA6920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6924: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
        label_4:
        // 0x00BA6928: LDR x1, [x25]              | X1 = "x2";                              
        // 0x00BA692C: ADD x0, x24, x23           | X0 = typeof(System.String);//AP1        
        // 0x00BA6930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6934: BL #0x18d5968              | X0 = label_System_Byte_ToString_GL018D5968();
        // 0x00BA6938: MOV x21, x0                | X21 = 1152921504608284672 (0x100000000015F000);//ML01
        // 0x00BA693C: CBNZ x20, #0xba6944        | if ( != 0) goto label_5;                
        if(null != 0)
        {
            goto label_5;
        }
        // 0x00BA6940: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
        label_5:
        // 0x00BA6944: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA6948: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA694C: MOV x1, x21                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
        val_4 = 1152921504608284672;
        // 0x00BA6950: BL #0x1b5b818              | X0 = Append(value:  val_4 = 1152921504608284672);
        System.Text.StringBuilder val_3 = Append(value:  val_4);
        // 0x00BA6954: ADD x23, x23, #1           | X23 = (0 + 1);                          
        val_4 = val_4 + 1;
        // 0x00BA6958: CMP w22, w23               | STATE = COMPARE(W22, (0 + 1))           
        // 0x00BA695C: B.NE #0xba6908             | if (W22 != 0) goto label_6;             
        if(W22 != val_4)
        {
            goto label_6;
        }
        label_2:
        // 0x00BA6960: CBNZ x20, #0xba6968        | if ( != 0) goto label_7;                
        if(null != 0)
        {
            goto label_7;
        }
        // 0x00BA6964: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_7:
        // 0x00BA6968: LDR x8, [x20]              | X8 = ;                                  
        // 0x00BA696C: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
        // 0x00BA6970: LDP x2, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
        // 0x00BA6974: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6978: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA697C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00BA6980: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00BA6984: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00BA6988: BR x2                      | goto mem[null + 320];                   
        goto mem[null + 320];
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA698C (12216716), len: 104  VirtAddr: 0x00BA698C RVA: 0x00BA698C token: 100692731 methodIndex: 25629 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.AndroidJavaObject GetJavaStaticAJO(UnityEngine.AndroidJavaClass _javaClass, string _name)
    {
        //
        // Disasemble & Code
        // 0x00BA698C: STP x22, x21, [sp, #-0x30]! | stack[1152921514875996304] = ???;  stack[1152921514875996312] = ???;  //  dest_result_addr=1152921514875996304 |  dest_result_addr=1152921514875996312
        // 0x00BA6990: STP x20, x19, [sp, #0x10]  | stack[1152921514875996320] = ???;  stack[1152921514875996328] = ???;  //  dest_result_addr=1152921514875996320 |  dest_result_addr=1152921514875996328
        // 0x00BA6994: STP x29, x30, [sp, #0x20]  | stack[1152921514875996336] = ???;  stack[1152921514875996344] = ???;  //  dest_result_addr=1152921514875996336 |  dest_result_addr=1152921514875996344
        // 0x00BA6998: ADD x29, sp, #0x20         | X29 = (1152921514875996304 + 32) = 1152921514875996336 (0x100000026416C8B0);
        // 0x00BA699C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA69A0: LDRB w8, [x21, #0xadb]     | W8 = (bool)static_value_03733ADB;       
        // 0x00BA69A4: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00BA69A8: MOV x20, x1                | X20 = _name;//m1                        
        // 0x00BA69AC: TBNZ w8, #0, #0xba69c8     | if (static_value_03733ADB == true) goto label_0;
        // 0x00BA69B0: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
        // 0x00BA69B4: LDR x8, [x8, #0x3e8]       | X8 = 0x2B900F4;                         
        // 0x00BA69B8: LDR w0, [x8]               | W0 = 0x1701;                            
        // 0x00BA69BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1701, ????);     
        // 0x00BA69C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA69C4: STRB w8, [x21, #0xadb]     | static_value_03733ADB = true;            //  dest_result_addr=57883355
        label_0:
        // 0x00BA69C8: CBNZ x20, #0xba69d0        | if (_name != null) goto label_1;        
        if(_name != null)
        {
            goto label_1;
        }
        // 0x00BA69CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1701, ????);     
        label_1:
        // 0x00BA69D0: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x00BA69D4: LDR x8, [x8, #0x458]       | X8 = 1152921514474312400;               
        // 0x00BA69D8: MOV x0, x20                | X0 = _name;//m1                         
        // 0x00BA69DC: MOV x1, x19                | X1 = X2;//m1                            
        // 0x00BA69E0: LDR x2, [x8]               | X2 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::GetStatic<UnityEngine.AndroidJavaObject>(string fieldName);
        // 0x00BA69E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA69E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA69EC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA69F0: B #0x12e3528               | return _name.GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  X2);
        return _name.GetStatic<UnityEngine.AndroidJavaObject>(fieldName:  X2);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA69F4 (12216820), len: 104  VirtAddr: 0x00BA69F4 RVA: 0x00BA69F4 token: 100692732 methodIndex: 25630 delegateWrapperIndex: 0 methodInvoker: 0
    public static string GetJavaString(UnityEngine.AndroidJavaObject _ajo, string _name)
    {
        //
        // Disasemble & Code
        // 0x00BA69F4: STP x22, x21, [sp, #-0x30]! | stack[1152921514876125712] = ???;  stack[1152921514876125720] = ???;  //  dest_result_addr=1152921514876125712 |  dest_result_addr=1152921514876125720
        // 0x00BA69F8: STP x20, x19, [sp, #0x10]  | stack[1152921514876125728] = ???;  stack[1152921514876125736] = ???;  //  dest_result_addr=1152921514876125728 |  dest_result_addr=1152921514876125736
        // 0x00BA69FC: STP x29, x30, [sp, #0x20]  | stack[1152921514876125744] = ???;  stack[1152921514876125752] = ???;  //  dest_result_addr=1152921514876125744 |  dest_result_addr=1152921514876125752
        // 0x00BA6A00: ADD x29, sp, #0x20         | X29 = (1152921514876125712 + 32) = 1152921514876125744 (0x100000026418C230);
        // 0x00BA6A04: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA6A08: LDRB w8, [x21, #0xadc]     | W8 = (bool)static_value_03733ADC;       
        // 0x00BA6A0C: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00BA6A10: MOV x20, x1                | X20 = _name;//m1                        
        // 0x00BA6A14: TBNZ w8, #0, #0xba6a30     | if (static_value_03733ADC == true) goto label_0;
        // 0x00BA6A18: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x00BA6A1C: LDR x8, [x8, #0x7c0]       | X8 = 0x2B900F8;                         
        // 0x00BA6A20: LDR w0, [x8]               | W0 = 0x1702;                            
        // 0x00BA6A24: BL #0x2782188              | X0 = sub_2782188( ?? 0x1702, ????);     
        // 0x00BA6A28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6A2C: STRB w8, [x21, #0xadc]     | static_value_03733ADC = true;            //  dest_result_addr=57883356
        label_0:
        // 0x00BA6A30: CBNZ x20, #0xba6a38        | if (_name != null) goto label_1;        
        if(_name != null)
        {
            goto label_1;
        }
        // 0x00BA6A34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1702, ????);     
        label_1:
        // 0x00BA6A38: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
        // 0x00BA6A3C: LDR x8, [x8, #0x258]       | X8 = 1152921514876112736;               
        // 0x00BA6A40: MOV x0, x20                | X0 = _name;//m1                         
        // 0x00BA6A44: MOV x1, x19                | X1 = X2;//m1                            
        // 0x00BA6A48: LDR x2, [x8]               | X2 = public System.String UnityEngine.AndroidJavaObject::Get<System.String>(string fieldName);
        // 0x00BA6A4C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6A50: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6A54: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA6A58: B #0x12e34e0               | return _name.Get<System.String>(fieldName:  X2);
        return _name.Get<System.String>(fieldName:  X2);
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6A5C (12216924), len: 140  VirtAddr: 0x00BA6A5C RVA: 0x00BA6A5C token: 100692733 methodIndex: 25631 delegateWrapperIndex: 0 methodInvoker: 0
    public static UnityEngine.AndroidJavaObject CallJavaAJO(UnityEngine.AndroidJavaObject _ajo, string _name)
    {
        //
        // Disasemble & Code
        // 0x00BA6A5C: STP x22, x21, [sp, #-0x30]! | stack[1152921514876254096] = ???;  stack[1152921514876254104] = ???;  //  dest_result_addr=1152921514876254096 |  dest_result_addr=1152921514876254104
        // 0x00BA6A60: STP x20, x19, [sp, #0x10]  | stack[1152921514876254112] = ???;  stack[1152921514876254120] = ???;  //  dest_result_addr=1152921514876254112 |  dest_result_addr=1152921514876254120
        // 0x00BA6A64: STP x29, x30, [sp, #0x20]  | stack[1152921514876254128] = ???;  stack[1152921514876254136] = ???;  //  dest_result_addr=1152921514876254128 |  dest_result_addr=1152921514876254136
        // 0x00BA6A68: ADD x29, sp, #0x20         | X29 = (1152921514876254096 + 32) = 1152921514876254128 (0x10000002641AB7B0);
        // 0x00BA6A6C: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00BA6A70: LDRB w8, [x21, #0xadd]     | W8 = (bool)static_value_03733ADD;       
        // 0x00BA6A74: MOV x19, x2                | X19 = X2;//m1                           
        // 0x00BA6A78: MOV x20, x1                | X20 = _name;//m1                        
        // 0x00BA6A7C: TBNZ w8, #0, #0xba6a98     | if (static_value_03733ADD == true) goto label_0;
        // 0x00BA6A80: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
        // 0x00BA6A84: LDR x8, [x8, #0xf10]       | X8 = 0x2B900E4;                         
        // 0x00BA6A88: LDR w0, [x8]               | W0 = 0x16FD;                            
        // 0x00BA6A8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x16FD, ????);     
        // 0x00BA6A90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA6A94: STRB w8, [x21, #0xadd]     | static_value_03733ADD = true;            //  dest_result_addr=57883357
        label_0:
        // 0x00BA6A98: CBNZ x20, #0xba6aa0        | if (_name != null) goto label_1;        
        if(_name != null)
        {
            goto label_1;
        }
        // 0x00BA6A9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x16FD, ????);     
        label_1:
        // 0x00BA6AA0: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
        // 0x00BA6AA4: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
        // 0x00BA6AA8: LDR x21, [x8]              | X21 = typeof(System.Object[]);          
        // 0x00BA6AAC: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6AB0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
        // 0x00BA6AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA6AB8: MOV x0, x21                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6ABC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
        // 0x00BA6AC0: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00BA6AC4: LDR x8, [x8, #0x710]       | X8 = 1152921514474317632;               
        // 0x00BA6AC8: MOV x2, x0                 | X2 = 1152921504954501264 (0x1000000014B8C890);//ML01
        // 0x00BA6ACC: MOV x0, x20                | X0 = _name;//m1                         
        // 0x00BA6AD0: MOV x1, x19                | X1 = X2;//m1                            
        // 0x00BA6AD4: LDR x3, [x8]               | X3 = public UnityEngine.AndroidJavaObject UnityEngine.AndroidJavaObject::Call<UnityEngine.AndroidJavaObject>(string methodName, object[] args);
        // 0x00BA6AD8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA6ADC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00BA6AE0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00BA6AE4: B #0x12f5e74               | return _name.Call<UnityEngine.AndroidJavaObject>(methodName:  X2, args:  null);
        return _name.Call<UnityEngine.AndroidJavaObject>(methodName:  X2, args:  null);
    
    }

}
