using UnityEngine;
private class LzmaBench.CProgressInfo : ICodeProgress
{
    // Fields
    public long ApprovedStart; //  0x00000010
    public long InSize; //  0x00000018
    public System.DateTime Time; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00ADB6E4 (11384548), len: 8  VirtAddr: 0x00ADB6E4 RVA: 0x00ADB6E4 token: 100681634 methodIndex: 54788 delegateWrapperIndex: 0 methodInvoker: 0
    public LzmaBench.CProgressInfo()
    {
        //
        // Disasemble & Code
        // 0x00ADB6E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB6E8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB77C (11384700), len: 8  VirtAddr: 0x00ADB77C RVA: 0x00ADB77C token: 100681635 methodIndex: 54789 delegateWrapperIndex: 0 methodInvoker: 0
    public void Init()
    {
        //
        // Disasemble & Code
        // 0x00ADB77C: STR xzr, [x0, #0x18]       | this.InSize = 0;                         //  dest_result_addr=1152921513104993864
        this.InSize = 0;
        // 0x00ADB780: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBB28 (11385640), len: 148  VirtAddr: 0x00ADBB28 RVA: 0x00ADBB28 token: 100681636 methodIndex: 54790 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetProgress(long inSize, long outSize)
    {
        //
        // Disasemble & Code
        // 0x00ADBB28: STP x22, x21, [sp, #-0x30]! | stack[1152921513105093792] = ???;  stack[1152921513105093800] = ???;  //  dest_result_addr=1152921513105093792 |  dest_result_addr=1152921513105093800
        // 0x00ADBB2C: STP x20, x19, [sp, #0x10]  | stack[1152921513105093808] = ???;  stack[1152921513105093816] = ???;  //  dest_result_addr=1152921513105093808 |  dest_result_addr=1152921513105093816
        // 0x00ADBB30: STP x29, x30, [sp, #0x20]  | stack[1152921513105093824] = ???;  stack[1152921513105093832] = ???;  //  dest_result_addr=1152921513105093824 |  dest_result_addr=1152921513105093832
        // 0x00ADBB34: ADD x29, sp, #0x20         | X29 = (1152921513105093792 + 32) = 1152921513105093824 (0x10000001FA88F4C0);
        // 0x00ADBB38: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00ADBB3C: LDRB w8, [x21, #0x520]     | W8 = (bool)static_value_03733520;       
        // 0x00ADBB40: MOV x19, x1                | X19 = inSize;//m1                       
        // 0x00ADBB44: MOV x20, x0                | X20 = 1152921513105105840 (0x10000001FA8923B0);//ML01
        // 0x00ADBB48: TBNZ w8, #0, #0xadbb64     | if (static_value_03733520 == true) goto label_0;
        // 0x00ADBB4C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
        // 0x00ADBB50: LDR x8, [x8, #0x908]       | X8 = 0x2B92D5C;                         
        // 0x00ADBB54: LDR w0, [x8]               | W0 = 0x221C;                            
        // 0x00ADBB58: BL #0x2782188              | X0 = sub_2782188( ?? 0x221C, ????);     
        // 0x00ADBB5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00ADBB60: STRB w8, [x21, #0x520]     | static_value_03733520 = true;            //  dest_result_addr=57881888
        label_0:
        // 0x00ADBB64: LDR x8, [x20, #0x10]       | X8 = this.ApprovedStart; //P2           
        // 0x00ADBB68: CMP x8, x19                | STATE = COMPARE(this.ApprovedStart, inSize)
        // 0x00ADBB6C: B.GT #0xadbbac             | if (this.ApprovedStart > inSize) goto label_2;
        if(this.ApprovedStart > inSize)
        {
            goto label_2;
        }
        // 0x00ADBB70: LDR x8, [x20, #0x18]       | X8 = this.InSize; //P2                  
        // 0x00ADBB74: CBNZ x8, #0xadbbac         | if (this.InSize != 0) goto label_2;     
        if(this.InSize != 0)
        {
            goto label_2;
        }
        // 0x00ADBB78: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x00ADBB7C: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
        // 0x00ADBB80: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
        // 0x00ADBB84: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
        // 0x00ADBB88: TBZ w8, #0, #0xadbb98      | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00ADBB8C: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
        // 0x00ADBB90: CBNZ w8, #0xadbb98         | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00ADBB94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
        label_4:
        // 0x00ADBB98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00ADBB9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADBBA0: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
        System.DateTime val_1 = System.DateTime.UtcNow;
        // 0x00ADBBA4: STP x0, x1, [x20, #0x20]   | this.Time = val_1;  mem[1152921513105105880] = val_1.kind;  //  dest_result_addr=1152921513105105872 |  dest_result_addr=1152921513105105880
        this.Time = val_1;
        mem[1152921513105105880] = val_1.kind;
        // 0x00ADBBA8: STR x19, [x20, #0x18]      | this.InSize = inSize;                    //  dest_result_addr=1152921513105105864
        this.InSize = inSize;
        label_2:
        // 0x00ADBBAC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBBB0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBBB4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00ADBBB8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBBBC (11385788), len: 4  VirtAddr: 0x00ADBBBC RVA: 0x00ADBBBC token: 100681637 methodIndex: 54791 delegateWrapperIndex: 0 methodInvoker: 0
    public void SetProgressPercent(long fileSize, long processSize)
    {
        //
        // Disasemble & Code
        // 0x00ADBBBC: RET                        |  return;                                
        return;
    
    }

}
