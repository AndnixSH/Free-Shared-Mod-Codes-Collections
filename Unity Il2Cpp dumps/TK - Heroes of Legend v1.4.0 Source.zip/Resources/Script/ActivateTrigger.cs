using UnityEngine;
public class ActivateTrigger : MonoBehaviour
{
    // Fields
    public ActivateTrigger.Mode action; //  0x00000018
    public UnityEngine.Object target; //  0x00000020
    public UnityEngine.GameObject source; //  0x00000028
    public int triggerCount; //  0x00000030
    public bool repeatTrigger; //  0x00000034
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0272A9CC (41069004), len: 24  VirtAddr: 0x0272A9CC RVA: 0x0272A9CC token: 100663422 methodIndex: 24254 delegateWrapperIndex: 0 methodInvoker: 0
    public ActivateTrigger()
    {
        //
        // Disasemble & Code
        // 0x0272A9CC: ORR w8, wzr, #2            | W8 = 2(0x2);                            
        // 0x0272A9D0: ORR w9, wzr, #1            | W9 = 1(0x1);                            
        // 0x0272A9D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272A9D8: STR w8, [x0, #0x18]        | this.action = 0x2;                       //  dest_result_addr=1152921509942457128
        this.action = 2;
        // 0x0272A9DC: STR w9, [x0, #0x30]        | this.triggerCount = 1;                   //  dest_result_addr=1152921509942457152
        this.triggerCount = 1;
        // 0x0272A9E0: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272A9E4 (41069028), len: 1064  VirtAddr: 0x0272A9E4 RVA: 0x0272A9E4 token: 100663423 methodIndex: 24255 delegateWrapperIndex: 0 methodInvoker: 0
    private void DoActivateTrigger()
    {
        //
        // Disasemble & Code
        //  | 
        var val_16;
        //  | 
        var val_17;
        //  | 
        var val_18;
        //  | 
        var val_19;
        //  | 
        UnityEngine.Object val_20;
        //  | 
        var val_21;
        //  | 
        var val_22;
        //  | 
        var val_23;
        //  | 
        var val_24;
        //  | 
        var val_25;
        //  | 
        var val_26;
        //  | 
        var val_27;
        //  | 
        var val_28;
        //  | 
        var val_29;
        //  | 
        var val_30;
        //  | 
        var val_31;
        //  | 
        var val_33;
        //  | 
        var val_34;
        //  | 
        var val_35;
        //  | 
        var val_36;
        //  | 
        var val_37;
        //  | 
        var val_38;
        //  | 
        var val_39;
        //  | 
        var val_40;
        //  | 
        var val_41;
        //  | 
        var val_42;
        //  | 
        var val_43;
        //  | 
        var val_44;
        //  | 
        var val_45;
        //  | 
        var val_46;
        //  | 
        var val_47;
        //  | 
        var val_48;
        //  | 
        var val_51;
        //  | 
        UnityEngine.Object val_52;
        //  | 
        UnityEngine.Object val_53;
        //  | 
        UnityEngine.Object val_54;
        //  | 
        var val_55;
        // 0x0272A9E4: STP d15, d14, [sp, #-0x80]! | stack[1152921509942596000] = ???;  stack[1152921509942596008] = ???;  //  dest_result_addr=1152921509942596000 |  dest_result_addr=1152921509942596008
        // 0x0272A9E8: STP d13, d12, [sp, #0x10]  | stack[1152921509942596016] = ???;  stack[1152921509942596024] = ???;  //  dest_result_addr=1152921509942596016 |  dest_result_addr=1152921509942596024
        // 0x0272A9EC: STP d11, d10, [sp, #0x20]  | stack[1152921509942596032] = ???;  stack[1152921509942596040] = ???;  //  dest_result_addr=1152921509942596032 |  dest_result_addr=1152921509942596040
        // 0x0272A9F0: STP d9, d8, [sp, #0x30]    | stack[1152921509942596048] = ???;  stack[1152921509942596056] = ???;  //  dest_result_addr=1152921509942596048 |  dest_result_addr=1152921509942596056
        // 0x0272A9F4: STP x24, x23, [sp, #0x40]  | stack[1152921509942596064] = ???;  stack[1152921509942596072] = ???;  //  dest_result_addr=1152921509942596064 |  dest_result_addr=1152921509942596072
        // 0x0272A9F8: STP x22, x21, [sp, #0x50]  | stack[1152921509942596080] = ???;  stack[1152921509942596088] = ???;  //  dest_result_addr=1152921509942596080 |  dest_result_addr=1152921509942596088
        // 0x0272A9FC: STP x20, x19, [sp, #0x60]  | stack[1152921509942596096] = ???;  stack[1152921509942596104] = ???;  //  dest_result_addr=1152921509942596096 |  dest_result_addr=1152921509942596104
        // 0x0272AA00: STP x29, x30, [sp, #0x70]  | stack[1152921509942596112] = ???;  stack[1152921509942596120] = ???;  //  dest_result_addr=1152921509942596112 |  dest_result_addr=1152921509942596120
        // 0x0272AA04: ADD x29, sp, #0x70         | X29 = (1152921509942596000 + 112) = 1152921509942596112 (0x100000013E091210);
        // 0x0272AA08: ADRP x19, #0x3743000       | X19 = 57946112 (0x3743000);             
        // 0x0272AA0C: LDRB w8, [x19, #0xa93]     | W8 = (bool)static_value_03743A93;       
        // 0x0272AA10: MOV x20, x0                | X20 = 1152921509942608128 (0x100000013E094100);//ML01
        // 0x0272AA14: TBNZ w8, #0, #0x272aa30    | if (static_value_03743A93 == true) goto label_0;
        // 0x0272AA18: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
        // 0x0272AA1C: LDR x8, [x8, #0x630]       | X8 = 0x2B8A904;                         
        // 0x0272AA20: LDR w0, [x8]               | W0 = 0xFF;                              
        // 0x0272AA24: BL #0x2782188              | X0 = sub_2782188( ?? 0xFF, ????);       
        // 0x0272AA28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0272AA2C: STRB w8, [x19, #0xa93]     | static_value_03743A93 = true;            //  dest_result_addr=57948819
        label_0:
        // 0x0272AA30: LDR x8, [x20, #0x30]       | X8 = this.triggerCount; //P2            
        int val_51 = this.triggerCount;
        // 0x0272AA34: SUB w9, w8, #1             | W9 = (this.triggerCount - 1);           
        int val_1 = val_51 - 1;
        // 0x0272AA38: STR w9, [x20, #0x30]       | this.triggerCount = (this.triggerCount - 1);  //  dest_result_addr=1152921509942608176
        this.triggerCount = val_1;
        // 0x0272AA3C: CBZ w9, #0x272aa48         | if ((this.triggerCount - 1) == 0) goto label_1;
        if(val_1 == 0)
        {
            goto label_1;
        }
        // 0x0272AA40: AND x8, x8, #0xff00000000  | X8 = (this.triggerCount & 1095216660480);
        val_51 = val_51 & 1095216660480;
        // 0x0272AA44: CBZ x8, #0x272ad5c         | if ((this.triggerCount & 1095216660480) == 0) goto label_30;
        if(val_51 == 0)
        {
            goto label_30;
        }
        label_1:
        // 0x0272AA48: ADRP x23, #0x35fe000       | X23 = 56614912 (0x35FE000);             
        // 0x0272AA4C: LDR x23, [x23, #0x810]     | X23 = 1152921504697475072;              
        // 0x0272AA50: LDR x19, [x20, #0x20]      | X19 = this.target; //P2                 
        // 0x0272AA54: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x0272AA58: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0272AA5C: TBZ w8, #0, #0x272aa6c     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x0272AA60: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0272AA64: CBNZ w8, #0x272aa6c        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x0272AA68: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_4:
        // 0x0272AA6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272AA70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AA74: MOV x1, x19                | X1 = this.target;//m1                   
        // 0x0272AA78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272AA7C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.target);
        bool val_2 = UnityEngine.Object.op_Inequality(x:  0, y:  this.target);
        // 0x0272AA80: TBZ w0, #0, #0x272aa8c     | if (val_2 == false) goto label_5;       
        if(val_2 == false)
        {
            goto label_5;
        }
        // 0x0272AA84: LDR x0, [x20, #0x20]       | X0 = this.target; //P2                  
        val_52 = this.target;
        // 0x0272AA88: B #0x272aa98               |  goto label_6;                          
        goto label_6;
        label_5:
        // 0x0272AA8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272AA90: MOV x0, x20                | X0 = 1152921509942608128 (0x100000013E094100);//ML01
        // 0x0272AA94: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_3 = this.gameObject;
        label_6:
        // 0x0272AA98: CBZ x0, #0x272aac4         | if (val_3 == null) goto label_7;        
        if(val_3 == null)
        {
            goto label_7;
        }
        // 0x0272AA9C: ADRP x9, #0x3669000        | X9 = 57053184 (0x3669000);              
        // 0x0272AAA0: LDR x9, [x9, #0x2b0]       | X9 = 1152921504691564544;               
        // 0x0272AAA4: LDR x8, [x0]               | X8 = typeof(UnityEngine.GameObject);    
        // 0x0272AAA8: LDR x9, [x9]               | X9 = typeof(UnityEngine.Behaviour);     
        // 0x0272AAAC: LDRB w11, [x8, #0x104]     | W11 = UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x0272AAB0: LDRB w10, [x9, #0x104]     | W10 = UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth;
        // 0x0272AAB4: CMP w11, w10               | STATE = COMPARE(UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchyDepth, UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth)
        // 0x0272AAB8: B.HS #0x272aad4            | if (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchyDepth >= UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
        // 0x0272AABC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_53 = 0;
        // 0x0272AAC0: B #0x272aae8               |  goto label_9;                          
        goto label_9;
        label_7:
        // 0x0272AAC4: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_53 = 0;
        // 0x0272AAC8: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
        val_54 = 0;
        // 0x0272AACC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        val_51 = 0;
        // 0x0272AAD0: B #0x272ab00               |  goto label_10;                         
        goto label_10;
        label_8:
        // 0x0272AAD4: LDR x11, [x8, #0xb0]       | X11 = UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy;
        // 0x0272AAD8: ADD x10, x11, x10, lsl #3  | X10 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRu
        // 0x0272AADC: LDUR x10, [x10, #-8]       | X10 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
        // 0x0272AAE0: CMP x10, x9                | STATE = COMPARE((UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(UnityEngine.Behaviour))
        // 0x0272AAE4: CSEL x21, x0, xzr, eq      | X21 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_3 : 0;
        UnityEngine.Object val_5 = (((UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8) == null) ? (val_3) : 0;
        label_9:
        // 0x0272AAE8: ADRP x9, #0x3668000        | X9 = 57049088 (0x3668000);              
        // 0x0272AAEC: LDR x9, [x9, #0x30]        | X9 = 1152921504692629504;               
        // 0x0272AAF0: LDR x9, [x9]               | X9 = typeof(UnityEngine.GameObject);    
        // 0x0272AAF4: CMP x8, x9                 | STATE = COMPARE(typeof(UnityEngine.GameObject), typeof(UnityEngine.GameObject))
        // 0x0272AAF8: CSEL x19, x0, xzr, eq      | X19 = typeof(UnityEngine.GameObject) == null ? val_3 : 0;
        var val_6 = (null == null) ? (val_3) : 0;
        // 0x0272AAFC: MOV x22, x21               | X22 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_3 : 0;//m1
        val_54 = val_5;
        label_10:
        // 0x0272AB00: LDR x0, [x23]              | X0 = typeof(UnityEngine.Object);        
        // 0x0272AB04: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x0272AB08: TBZ w8, #0, #0x272ab18     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_12;
        // 0x0272AB0C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x0272AB10: CBNZ w8, #0x272ab18        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
        // 0x0272AB14: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_12:
        // 0x0272AB18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272AB1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AB20: MOV x1, x22                | X1 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_3 : 0;//m1
        // 0x0272AB24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272AB28: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_54);
        bool val_7 = UnityEngine.Object.op_Inequality(x:  0, y:  val_54);
        // 0x0272AB2C: TBZ w0, #0, #0x272ab48     | if (val_7 == false) goto label_13;      
        if(val_7 == false)
        {
            goto label_13;
        }
        // 0x0272AB30: CBNZ x22, #0x272ab38       | if ((UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_3 : 0 != 0) goto label_14;
        // 0x0272AB34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_14:
        // 0x0272AB38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272AB3C: MOV x0, x22                | X0 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_3 : 0;//m1
        // 0x0272AB40: BL #0x20d50fc              | X0 = (UnityEngine.GameObject.__il2cppRuntimeField_typeHierarchy + (UnityEngine.Behaviour.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null ? val_3 : 0.get_gameObject();
        UnityEngine.GameObject val_8 = val_54.gameObject;
        // 0x0272AB44: MOV x19, x0                | X19 = val_8;//m1                        
        val_51 = val_8;
        label_13:
        // 0x0272AB48: LDR w8, [x20, #0x18]       | W8 = this.action; //P2                  
        Mode val_52 = this.action;
        // 0x0272AB4C: ADD w9, w8, #0xc           | W9 = (this.action + 12);                
        Mode val_9 = val_52 + 12;
        // 0x0272AB50: CMP w8, #6                 | STATE = COMPARE(this.action, 0x6)       
        // 0x0272AB54: CSEL w8, w9, wzr, lo       | W8 = this.action < 0x6 ? (this.action + 12) : 0;
        val_52 = (val_52 < 6) ? (val_9) : 0;
        // 0x0272AB58: SUB w8, w8, #0xc           | W8 = (this.action < 0x6 ? (this.action + 12) : 0 - 12);
        val_52 = val_52 - 12;
        // 0x0272AB5C: CMP w8, #5                 | STATE = COMPARE((this.action < 0x6 ? (this.action + 12) : 0 - 12), 0x5)
        // 0x0272AB60: B.HI #0x272ad5c            | if (this.action > 0x5) goto label_30;   
        if(val_52 > 5)
        {
            goto label_30;
        }
        // 0x0272AB64: ADRP x9, #0x2adc000        | X9 = 44941312 (0x2ADC000);              
        // 0x0272AB68: ADD x9, x9, #0xd68         | X9 = (44941312 + 3432) = 44944744 (0x02ADCD68);
        // 0x0272AB6C: LDRSW x8, [x9, x8, lsl #2] | X8 = 44944744 + ((this.action < 0x6 ? (this.action + 12) : 0 - 12)) << 2;
        var val_53 = 44944744 + ((this.action < 0x6 ? (this.action + 12) : 0 - 12)) << 2;
        // 0x0272AB70: ADD x8, x8, x9             | X8 = (44944744 + ((this.action < 0x6 ? (this.action + 12) : 0 - 12)) << 2 + 44944744);
        val_53 = val_53 + 44944744;
        // 0x0272AB74: BR x8                      | goto (44944744 + ((this.action < 0x6 ? (this.action + 12) : 0 - 12)) << 2 + 44944744);
        goto (44944744 + ((this.action < 0x6 ? (this.action + 12) : 0 - 12)) << 2 + 44944744);
        // 0x0272AB78: CBNZ x19, #0x272ab80       | if (val_8 != null) goto label_16;       
        if(val_51 != null)
        {
            goto label_16;
        }
        // 0x0272AB7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_16:
        // 0x0272AB80: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
        // 0x0272AB84: LDR x8, [x8, #0xf90]       | X8 = (string**)(1152921509942565584)("DoActivateTrigger");
        // 0x0272AB88: MOV x0, x19                | X0 = val_8;//m1                         
        // 0x0272AB8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AB90: LDR x1, [x8]               | X1 = "DoActivateTrigger";               
        // 0x0272AB94: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x0272AB98: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x0272AB9C: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x0272ABA0: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x0272ABA4: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x0272ABA8: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x0272ABAC: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x0272ABB0: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x0272ABB4: B #0x1a63420               | val_8.BroadcastMessage(methodName:  "DoActivateTrigger"); return;
        val_51.BroadcastMessage(methodName:  "DoActivateTrigger");
        return;
        // 0x0272ABB8: LDR x0, [x23]              | X0 = ;                                  
        // 0x0272ABBC: LDR x21, [x20, #0x28]      | X21 = ??? + 40;                         
        val_53 = mem[??? + 40];
        val_53 = ??? + 40;
        // 0x0272ABC0: LDRB w8, [x0, #0x10a]      | W8 = ??? + 266;                         
        // 0x0272ABC4: TBZ w8, #0, #0x272abd4     | if ((??? + 266 & 0x1) == 0) goto label_18;
        if(((??? + 266) & 1) == 0)
        {
            goto label_18;
        }
        // 0x0272ABC8: LDR w8, [x0, #0xbc]        | W8 = ??? + 188;                         
        // 0x0272ABCC: CBNZ w8, #0x272abd4        | if (??? + 188 != 0) goto label_18;      
        if((??? + 188) != 0)
        {
            goto label_18;
        }
        // 0x0272ABD0: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
        label_18:
        // 0x0272ABD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272ABD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272ABDC: MOV x1, x21                | X1 = ??? + 40;//m1                      
        // 0x0272ABE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272ABE4: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_53);
        bool val_10 = UnityEngine.Object.op_Inequality(x:  0, y:  val_53);
        // 0x0272ABE8: TBZ w0, #0, #0x272ad5c     | if (val_10 == false) goto label_30;     
        if(val_10 == false)
        {
            goto label_30;
        }
        // 0x0272ABEC: LDR x20, [x20, #0x28]      | X20 = ??? + 40;                         
        // 0x0272ABF0: CBNZ x19, #0x272abf8       | if ( != 0) goto label_20;               
        if((???) != 0)
        {
            goto label_20;
        }
        // 0x0272ABF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_20:
        // 0x0272ABF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272ABFC: MOV x0, x19                | X0 = X19;//m1                           
        // 0x0272AC00: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_11 = ???.transform;
        // 0x0272AC04: MOV x21, x0                | X21 = val_11;//m1                       
        // 0x0272AC08: CBNZ x21, #0x272ac10       | if (val_11 != null) goto label_21;      
        if(val_11 != null)
        {
            goto label_21;
        }
        // 0x0272AC0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_21:
        // 0x0272AC10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272AC14: MOV x0, x21                | X0 = val_11;//m1                        
        // 0x0272AC18: BL #0x2693510              | X0 = val_11.get_position();             
        UnityEngine.Vector3 val_12 = val_11.position;
        // 0x0272AC1C: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
        // 0x0272AC20: MOV v9.16b, v1.16b         | V9 = val_12.y;//m1                      
        // 0x0272AC24: MOV v10.16b, v2.16b        | V10 = val_12.z;//m1                     
        // 0x0272AC28: CBNZ x19, #0x272ac30       | if ( != 0) goto label_22;               
        if((???) != 0)
        {
            goto label_22;
        }
        // 0x0272AC2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_22:
        // 0x0272AC30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272AC34: MOV x0, x19                | X0 = X19;//m1                           
        // 0x0272AC38: BL #0x1a62c1c              | X0 = get_transform();                   
        UnityEngine.Transform val_13 = ???.transform;
        // 0x0272AC3C: MOV x21, x0                | X21 = val_13;//m1                       
        // 0x0272AC40: CBNZ x21, #0x272ac48       | if (val_13 != null) goto label_23;      
        if(val_13 != null)
        {
            goto label_23;
        }
        // 0x0272AC44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_23:
        // 0x0272AC48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272AC4C: MOV x0, x21                | X0 = val_13;//m1                        
        // 0x0272AC50: BL #0x26937d8              | X0 = val_13.get_rotation();             
        UnityEngine.Quaternion val_14 = val_13.rotation;
        // 0x0272AC54: LDR x0, [x23]              | X0 = ;                                  
        // 0x0272AC58: MOV v11.16b, v0.16b        | V11 = val_14.x;//m1                     
        // 0x0272AC5C: MOV v12.16b, v1.16b        | V12 = val_14.y;//m1                     
        // 0x0272AC60: MOV v14.16b, v2.16b        | V14 = val_14.z;//m1                     
        // 0x0272AC64: LDRB w8, [x0, #0x10a]      | W8 = ??? + 266;                         
        // 0x0272AC68: MOV v13.16b, v3.16b        | V13 = val_14.w;//m1                     
        // 0x0272AC6C: TBZ w8, #0, #0x272ac7c     | if ((??? + 266 & 0x1) == 0) goto label_25;
        if(((??? + 266) & 1) == 0)
        {
            goto label_25;
        }
        // 0x0272AC70: LDR w8, [x0, #0xbc]        | W8 = ??? + 188;                         
        // 0x0272AC74: CBNZ w8, #0x272ac7c        | if (??? + 188 != 0) goto label_25;      
        if((??? + 188) != 0)
        {
            goto label_25;
        }
        // 0x0272AC78: BL #0x27977a4              | X0 = sub_27977A4( ?? , ????);           
        label_25:
        // 0x0272AC7C: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
        // 0x0272AC80: LDR x8, [x8, #0x390]       | X8 = 1152921509942573888;               
        // 0x0272AC84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272AC88: MOV x1, x20                | X1 = ??? + 40;//m1                      
        // 0x0272AC8C: MOV v0.16b, v8.16b         | V0 = val_12.x;//m1                      
        // 0x0272AC90: LDR x2, [x8]               | X2 = public static UnityEngine.GameObject UnityEngine.Object::Instantiate<UnityEngine.GameObject>(UnityEngine.GameObject original, UnityEngine.Vector3 position, UnityEngine.Quaternion rotation);
        // 0x0272AC94: MOV v1.16b, v9.16b         | V1 = val_12.y;//m1                      
        // 0x0272AC98: MOV v2.16b, v10.16b        | V2 = val_12.z;//m1                      
        // 0x0272AC9C: MOV v3.16b, v11.16b        | V3 = val_14.x;//m1                      
        // 0x0272ACA0: MOV v4.16b, v12.16b        | V4 = val_14.y;//m1                      
        // 0x0272ACA4: MOV v5.16b, v14.16b        | V5 = val_14.z;//m1                      
        // 0x0272ACA8: MOV v6.16b, v13.16b        | V6 = val_14.w;//m1                      
        // 0x0272ACAC: BL #0x23d60c8              | X0 = UnityEngine.Object.Instantiate<UnityEngine.GameObject>(original:  0, position:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, rotation:  new UnityEngine.Quaternion() {x = val_14.x, y = val_14.y, z = val_14.z, w = val_14.w});
        UnityEngine.GameObject val_15 = UnityEngine.Object.Instantiate<UnityEngine.GameObject>(original:  0, position:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, rotation:  new UnityEngine.Quaternion() {x = val_14.x, y = val_14.y, z = val_14.z, w = val_14.w});
        // 0x0272ACB0: MOV x1, x19                | X1 = X19;//m1                           
        // 0x0272ACB4: LDP x29, x30, [sp, #0x70]  | X29 = val_16; X30 = val_17;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACB8: LDP x20, x19, [sp, #0x60]  | X20 = val_18; X19 = val_19;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACBC: LDP x22, x21, [sp, #0x50]  | X22 = val_20; X21 = val_21;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACC0: LDP x24, x23, [sp, #0x40]  | X24 = val_22; X23 = val_23;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACC4: LDP d9, d8, [sp, #0x30]    | D9 = val_24; D8 = val_25;                //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACC8: LDP d11, d10, [sp, #0x20]  | D11 = val_26; D10 = val_27;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACCC: LDP d13, d12, [sp, #0x10]  | D13 = val_28; D12 = val_29;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272ACD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272ACD8: LDP d15, d14, [sp], #0x80  | D15 = val_30; D14 = val_31;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ACDC: B #0x1b78e3c               | UnityEngine.Object.DestroyObject(obj:  0); return;
        UnityEngine.Object.DestroyObject(obj:  0);
        return;
        // 0x0272ACE0: CBNZ x19, #0x272ace8       | if (val_19 != 0) goto label_26;         
        if(val_19 != 0)
        {
            goto label_26;
        }
        // 0x0272ACE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_26:
        // 0x0272ACE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272ACEC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        val_55 = 1;
        // 0x0272ACF0: B #0x272ade4               |  goto label_27;                         
        goto label_27;
        // 0x0272ACF4: LDR x0, [x23]              | X0 = val_23;                            
        // 0x0272ACF8: LDRB w8, [x0, #0x10a]      | W8 = val_23 + 266;                      
        // 0x0272ACFC: TBZ w8, #0, #0x272ad0c     | if ((val_23 + 266 & 0x1) == 0) goto label_29;
        if(((val_23 + 266) & 1) == 0)
        {
            goto label_29;
        }
        // 0x0272AD00: LDR w8, [x0, #0xbc]        | W8 = val_23 + 188;                      
        // 0x0272AD04: CBNZ w8, #0x272ad0c        | if (val_23 + 188 != 0) goto label_29;   
        if((val_23 + 188) != 0)
        {
            goto label_29;
        }
        // 0x0272AD08: BL #0x27977a4              | X0 = sub_27977A4( ?? val_23, ????);     
        label_29:
        // 0x0272AD0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0272AD10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AD14: MOV x1, x22                | X1 = val_20;//m1                        
        // 0x0272AD18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x0272AD1C: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  val_20);
        bool val_32 = UnityEngine.Object.op_Inequality(x:  0, y:  val_20);
        // 0x0272AD20: TBZ w0, #0, #0x272ad5c     | if (val_32 == false) goto label_30;     
        if(val_32 == false)
        {
            goto label_30;
        }
        // 0x0272AD24: CBNZ x22, #0x272ad2c       | if (val_20 != 0) goto label_31;         
        if(val_20 != 0)
        {
            goto label_31;
        }
        // 0x0272AD28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
        label_31:
        // 0x0272AD2C: MOV x0, x21                | X0 = val_21;//m1                        
        // 0x0272AD30: LDP x29, x30, [sp, #0x70]  | X29 = val_33; X30 = val_34;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD34: LDP x20, x19, [sp, #0x60]  | X20 = val_35; X19 = val_36;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD38: LDP x22, x21, [sp, #0x50]  | X22 = val_37; X21 = val_38;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD3C: LDP x24, x23, [sp, #0x40]  | X24 = val_39; X23 = val_40;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD40: LDP d9, d8, [sp, #0x30]    | D9 = val_41; D8 = val_42;                //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD44: LDP d11, d10, [sp, #0x20]  | D11 = val_43; D10 = val_44;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD48: LDP d13, d12, [sp, #0x10]  | D13 = val_45; D12 = val_46;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0272AD50: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x0272AD54: LDP d15, d14, [sp], #0x80  | D15 = val_47; D14 = val_48;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AD58: B #0x20cb458               | val_21.set_enabled(value:  true); return;
        val_21.enabled = true;
        return;
        label_30:
        // 0x0272AD5C: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x0272AD60: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x0272AD64: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x0272AD68: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x0272AD6C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x0272AD70: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x0272AD74: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x0272AD78: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x0272AD7C: RET                        |  return;                                
        return;
        // 0x0272AD80: CBNZ x19, #0x272ad88       | if ( != 0) goto label_32;               
        if((???) != 0)
        {
            goto label_32;
        }
        // 0x0272AD84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0xFF, ????);       
        label_32:
        // 0x0272AD88: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
        // 0x0272AD8C: LDR x8, [x8, #0xf28]       | X8 = 1152921509942579008;               
        // 0x0272AD90: MOV x0, x19                | X0 = X19;//m1                           
        // 0x0272AD94: LDR x1, [x8]               | X1 = public UnityEngine.Animation UnityEngine.GameObject::GetComponent<UnityEngine.Animation>();
        // 0x0272AD98: BL #0x23d5abc              | X0 = GetComponent<UnityEngine.Animation>();
        UnityEngine.Animation val_49 = ???.GetComponent<UnityEngine.Animation>();
        // 0x0272AD9C: MOV x19, x0                | X19 = val_49;//m1                       
        // 0x0272ADA0: CBNZ x19, #0x272ada8       | if (val_49 != null) goto label_33;      
        if(val_49 != null)
        {
            goto label_33;
        }
        // 0x0272ADA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
        label_33:
        // 0x0272ADA8: MOV x0, x19                | X0 = val_49;//m1                        
        // 0x0272ADAC: LDP x29, x30, [sp, #0x70]  | X29 = val_16; X30 = val_17;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADB0: LDP x20, x19, [sp, #0x60]  | X20 = val_18; X19 = val_19;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADB4: LDP x22, x21, [sp, #0x50]  | X22 = val_20; X21 = val_21;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADB8: LDP x24, x23, [sp, #0x40]  | X24 = val_22; X23 = val_23;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADBC: LDP d9, d8, [sp, #0x30]    | D9 = val_24; D8 = val_25;                //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADC0: LDP d11, d10, [sp, #0x20]  | D11 = val_26; D10 = val_27;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADC4: LDP d13, d12, [sp, #0x10]  | D13 = val_28; D12 = val_29;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0272ADCC: LDP d15, d14, [sp], #0x80  | D15 = val_30; D14 = val_31;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADD0: B #0x270c510               | X0 = val_49.Play(); return;             
        bool val_50 = val_49.Play();
        return;
        // 0x0272ADD4: CBNZ x19, #0x272addc       | if (val_19 != 0) goto label_34;         
        if(val_19 != 0)
        {
            goto label_34;
        }
        // 0x0272ADD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
        label_34:
        // 0x0272ADDC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        val_55 = 0;
        // 0x0272ADE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        label_27:
        // 0x0272ADE4: MOV x0, x19                | X0 = val_19;//m1                        
        // 0x0272ADE8: LDP x29, x30, [sp, #0x70]  | X29 = val_33; X30 = val_34;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADEC: LDP x20, x19, [sp, #0x60]  | X20 = val_35; X19 = val_36;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADF0: LDP x22, x21, [sp, #0x50]  | X22 = val_37; X21 = val_38;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADF4: LDP x24, x23, [sp, #0x40]  | X24 = val_39; X23 = val_40;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADF8: LDP d9, d8, [sp, #0x30]    | D9 = val_41; D8 = val_42;                //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272ADFC: LDP d11, d10, [sp, #0x20]  | D11 = val_43; D10 = val_44;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AE00: LDP d13, d12, [sp, #0x10]  | D13 = val_45; D12 = val_46;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AE04: LDP d15, d14, [sp], #0x80  | D15 = val_47; D14 = val_48;              //  find_add[1152921509942584128] |  find_add[1152921509942584128]
        // 0x0272AE08: B #0x1a62d64               | val_19.SetActive(value:  false); return;
        val_19.SetActive(value:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x0272AE0C (41070092), len: 4  VirtAddr: 0x0272AE0C RVA: 0x0272AE0C token: 100663424 methodIndex: 24256 delegateWrapperIndex: 0 methodInvoker: 0
    private void OnTriggerEnter(UnityEngine.Collider other)
    {
        //
        // Disasemble & Code
        // 0x0272AE0C: B #0x272a9e4               | this.DoActivateTrigger(); return;       
        this.DoActivateTrigger();
        return;
    
    }

}
