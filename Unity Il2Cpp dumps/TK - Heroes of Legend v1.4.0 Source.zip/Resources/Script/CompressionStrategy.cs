using UnityEngine;

namespace Pathfinding.Ionic.Zlib
{
    public enum CompressionStrategy
    {
        // Fields
        Default = 0
        ,Filtered = 1
        ,HuffmanOnly = 2
        
    
    }

}
