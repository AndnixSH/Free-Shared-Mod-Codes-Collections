using UnityEngine;

namespace ILRuntime.Runtime.CLRBinding
{
    [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28572B0
    internal static class ConstructorBindingGenerator
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x0110B12C (17871148), len: 992  VirtAddr: 0x0110B12C RVA: 0x0110B12C token: 100679931 methodIndex: 29216 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28572C0
        internal static string GenerateConstructorRegisterCode(System.Type type, System.Reflection.ConstructorInfo[] methods, System.Collections.Generic.HashSet<System.Reflection.MethodBase> excludes)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.HashSet<System.Reflection.MethodBase> val_26;
            //  | 
            System.Text.StringBuilder val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            // 0x0110B12C: STP x28, x27, [sp, #-0x60]! | stack[1152921512833205392] = ???;  stack[1152921512833205400] = ???;  //  dest_result_addr=1152921512833205392 |  dest_result_addr=1152921512833205400
            // 0x0110B130: STP x26, x25, [sp, #0x10]  | stack[1152921512833205408] = ???;  stack[1152921512833205416] = ???;  //  dest_result_addr=1152921512833205408 |  dest_result_addr=1152921512833205416
            // 0x0110B134: STP x24, x23, [sp, #0x20]  | stack[1152921512833205424] = ???;  stack[1152921512833205432] = ???;  //  dest_result_addr=1152921512833205424 |  dest_result_addr=1152921512833205432
            // 0x0110B138: STP x22, x21, [sp, #0x30]  | stack[1152921512833205440] = ???;  stack[1152921512833205448] = ???;  //  dest_result_addr=1152921512833205440 |  dest_result_addr=1152921512833205448
            // 0x0110B13C: STP x20, x19, [sp, #0x40]  | stack[1152921512833205456] = ???;  stack[1152921512833205464] = ???;  //  dest_result_addr=1152921512833205456 |  dest_result_addr=1152921512833205464
            // 0x0110B140: STP x29, x30, [sp, #0x50]  | stack[1152921512833205472] = ???;  stack[1152921512833205480] = ???;  //  dest_result_addr=1152921512833205472 |  dest_result_addr=1152921512833205480
            // 0x0110B144: ADD x29, sp, #0x50         | X29 = (1152921512833205392 + 80) = 1152921512833205472 (0x10000001EA5444E0);
            // 0x0110B148: SUB sp, sp, #0x40          | SP = (1152921512833205392 - 64) = 1152921512833205328 (0x10000001EA544450);
            // 0x0110B14C: MOV x22, x3                | X22 = X3;//m1                           
            // 0x0110B150: MOV x23, x2                | X23 = excludes;//m1                     
            val_26 = excludes;
            // 0x0110B154: STP x22, x23, [sp, #0x18]  | stack[1152921512833205352] = X3;  stack[1152921512833205360] = excludes;  //  dest_result_addr=1152921512833205352 |  dest_result_addr=1152921512833205360
            // 0x0110B158: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x0110B15C: LDRB w8, [x19, #0xb9e]     | W8 = (bool)static_value_03735B9E;       
            // 0x0110B160: MOV x24, x1                | X24 = methods;//m1                      
            // 0x0110B164: STR x24, [sp, #0x10]       | stack[1152921512833205344] = methods;    //  dest_result_addr=1152921512833205344
            // 0x0110B168: TBNZ w8, #0, #0x110b184    | if (static_value_03735B9E == true) goto label_0;
            // 0x0110B16C: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x0110B170: LDR x8, [x8, #0xa68]       | X8 = 0x2B92868;                         
            // 0x0110B174: LDR w0, [x8]               | W0 = 0x20DF;                            
            // 0x0110B178: BL #0x2782188              | X0 = sub_2782188( ?? 0x20DF, ????);     
            // 0x0110B17C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0110B180: STRB w8, [x19, #0xb9e]     | static_value_03735B9E = true;            //  dest_result_addr=57891742
            label_0:
            // 0x0110B184: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110B188: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x0110B18C: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            val_27 = null;
            // 0x0110B190: STP xzr, xzr, [sp, #0x30]  | stack[1152921512833205376] = 0x0;  stack[1152921512833205384] = 0x0;  //  dest_result_addr=1152921512833205376 |  dest_result_addr=1152921512833205384
            bool val_14 = false;
            string val_13 = 0;
            // 0x0110B194: STRB wzr, [sp, #0x2f]      | stack[1152921512833205375] = 0x0;        //  dest_result_addr=1152921512833205375
            // 0x0110B198: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x0110B19C: MOV x25, x0                | X25 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B1A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B1A4: STR x25, [sp, #8]          | stack[1152921512833205336] = typeof(System.Text.StringBuilder);  //  dest_result_addr=1152921512833205336
            // 0x0110B1A8: BL #0x1b5a30c              | .ctor();                                
            val_27 = new System.Text.StringBuilder();
            // 0x0110B1AC: ADRP x26, #0x3631000       | X26 = 56823808 (0x3631000);             
            // 0x0110B1B0: ADRP x21, #0x366a000       | X21 = 57057280 (0x366A000);             
            // 0x0110B1B4: ADRP x28, #0x35e4000       | X28 = 56508416 (0x35E4000);             
            // 0x0110B1B8: LDR x26, [x26, #0xb20]     | X26 = (string**)(1152921512833131120)("typeof(");
            // 0x0110B1BC: LDR x21, [x21, #0x170]     | X21 = (string**)(1152921509409721808)(")");
            // 0x0110B1C0: LDR x28, [x28, #0x830]     | X28 = (string**)(1152921512833131216)(".MakeByRefType()");
            // 0x0110B1C4: MOV w27, wzr               | W27 = 0 (0x0);//ML01                    
            val_28 = 0;
            // 0x0110B1C8: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            var val_26 = 0;
            // 0x0110B1CC: B #0x110b1d8               |  goto label_1;                          
            goto label_1;
            label_29:
            // 0x0110B1D0: LDR x23, [sp, #0x20]       | X23 = excludes;                         
            val_26 = val_26;
            // 0x0110B1D4: ADD w27, w27, #1           | W27 = (val_28 + 1) = val_28 (0x00000001);
            val_28 = 1;
            label_1:
            // 0x0110B1D8: CBNZ x23, #0x110b1e0       | if (excludes != 0) goto label_2;        
            if(val_26 != 0)
            {
                goto label_2;
            }
            // 0x0110B1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x0110B1E0: LDR w8, [x23, #0x18]       | W8 = excludes + 24;                     
            // 0x0110B1E4: CMP w27, w8                | STATE = COMPARE(0x1, excludes + 24)     
            // 0x0110B1E8: B.GE #0x110b4d4            | if (val_28 >= excludes + 24) goto label_3;
            if(val_28 >= (excludes + 24))
            {
                goto label_3;
            }
            // 0x0110B1EC: SXTW x19, w27              | X19 = 1 (0x00000001);                   
            // 0x0110B1F0: CMP w27, w8                | STATE = COMPARE(0x1, excludes + 24)     
            // 0x0110B1F4: B.LO #0x110b204            | if (val_28 < excludes + 24) goto label_4;
            if(val_28 < (excludes + 24))
            {
                goto label_4;
            }
            // 0x0110B1F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x0110B1FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B200: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_4:
            // 0x0110B204: ADD x8, x23, x19, lsl #3   | X8 = (excludes + 8);                    
            System.Collections.Generic.HashSet<System.Reflection.MethodBase> val_1 = val_26 + 8;
            // 0x0110B208: LDR x23, [x8, #0x20]       | X23 = (excludes + 8) + 32;              
            // 0x0110B20C: CBZ x22, #0x110b230        | if (X3 == 0) goto label_5;              
            if(X3 == 0)
            {
                goto label_5;
            }
            // 0x0110B210: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x0110B214: LDR x8, [x8, #0x2e0]       | X8 = 1152921512819970496;               
            // 0x0110B218: MOV x0, x22                | X0 = X3;//m1                            
            val_27 = X3;
            // 0x0110B21C: MOV x1, x23                | X1 = (excludes + 8) + 32;//m1           
            // 0x0110B220: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.HashSet<System.Reflection.MethodBase>::Contains(System.Reflection.MethodBase item);
            // 0x0110B224: BL #0x1f3ea80              | X0 = X3.Contains(item:  (excludes + 8) + 32);
            bool val_2 = val_27.Contains(item:  (excludes + 8) + 32);
            // 0x0110B228: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x0110B22C: TBNZ w8, #0, #0x110b1d0    | if ((val_2 & 1) == true) goto label_29; 
            if(val_3 == true)
            {
                goto label_29;
            }
            label_5:
            // 0x0110B230: MOV x1, x24                | X1 = methods;//m1                       
            // 0x0110B234: MOV x2, x23                | X2 = (excludes + 8) + 32;//m1           
            // 0x0110B238: BL #0x11084d0              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.ShouldSkipMethod(type:  bool val_2 = val_27.Contains(item:  (excludes + 8) + 32), i:  methods);
            bool val_4 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.ShouldSkipMethod(type:  val_2, i:  methods);
            // 0x0110B23C: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x0110B240: TBNZ w8, #0, #0x110b1d0    | if ((val_4 & 1) == true) goto label_29; 
            if(val_5 == true)
            {
                goto label_29;
            }
            // 0x0110B244: CBNZ x23, #0x110b24c       | if ((excludes + 8) + 32 != 0) goto label_8;
            if(((excludes + 8) + 32) != 0)
            {
                goto label_8;
            }
            // 0x0110B248: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_8:
            // 0x0110B24C: LDR x8, [x23]              | X8 = (excludes + 8) + 32;               
            // 0x0110B250: MOV x0, x23                | X0 = (excludes + 8) + 32;//m1           
            // 0x0110B254: LDR x9, [x8, #0x200]       | X9 = (excludes + 8) + 32 + 512;         
            // 0x0110B258: LDR x1, [x8, #0x208]       | X1 = (excludes + 8) + 32 + 520;         
            // 0x0110B25C: BLR x9                     | X0 = (excludes + 8) + 32 + 512();       
            // 0x0110B260: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110B264: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x0110B268: MOV x24, x0                | X24 = (excludes + 8) + 32;//m1          
            // 0x0110B26C: LDR x8, [x8]               | X8 = typeof(System.Text.StringBuilder); 
            // 0x0110B270: MOV x0, x8                 | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            System.Text.StringBuilder val_6 = null;
            // 0x0110B274: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x0110B278: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B27C: MOV x23, x0                | X23 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B280: BL #0x1b5a30c              | .ctor();                                
            val_6 = new System.Text.StringBuilder();
            // 0x0110B284: CBNZ x23, #0x110b28c       | if ( != 0) goto label_9;                
            if(null != 0)
            {
                goto label_9;
            }
            // 0x0110B288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_9:
            // 0x0110B28C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x0110B290: LDR x8, [x8, #0x638]       | X8 = (string**)(1152921512833131328)("{");
            // 0x0110B294: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B298: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B29C: LDR x1, [x8]               | X1 = "{";                               
            // 0x0110B2A0: BL #0x1b5b818              | X0 = Append(value:  "{");               
            System.Text.StringBuilder val_7 = Append(value:  "{");
            // 0x0110B2A4: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_29 = 0;
            // 0x0110B2A8: ORR w19, wzr, #1           | W19 = 1(0x1);                           
            val_30 = 1;
            // 0x0110B2AC: B #0x110b2b8               |  goto label_10;                         
            goto label_10;
            label_22:
            // 0x0110B2B0: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_30 = 0;
            // 0x0110B2B4: ADD w22, w22, #1           | W22 = (val_29 + 1) = val_29 (0x00000001);
            val_29 = 1;
            label_10:
            // 0x0110B2B8: CBNZ x24, #0x110b2c0       | if ((excludes + 8) + 32 != 0) goto label_11;
            if(((excludes + 8) + 32) != 0)
            {
                goto label_11;
            }
            // 0x0110B2BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_11:
            // 0x0110B2C0: LDR w8, [x24, #0x18]       | W8 = (excludes + 8) + 32 + 24;          
            // 0x0110B2C4: CMP w22, w8                | STATE = COMPARE(0x1, (excludes + 8) + 32 + 24)
            // 0x0110B2C8: B.GE #0x110b3cc            | if (val_29 >= (excludes + 8) + 32 + 24) goto label_12;
            if(val_29 >= ((excludes + 8) + 32 + 24))
            {
                goto label_12;
            }
            // 0x0110B2CC: SXTW x25, w22              | X25 = 1 (0x00000001);                   
            // 0x0110B2D0: CMP w22, w8                | STATE = COMPARE(0x1, (excludes + 8) + 32 + 24)
            // 0x0110B2D4: B.LO #0x110b2e4            | if (val_29 < (excludes + 8) + 32 + 24) goto label_13;
            if(val_29 < ((excludes + 8) + 32 + 24))
            {
                goto label_13;
            }
            // 0x0110B2D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x0110B2DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B2E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_13:
            // 0x0110B2E4: ADD x8, x24, x25, lsl #3   | X8 = ((excludes + 8) + 32 + 8);         
            var val_8 = ((excludes + 8) + 32) + 8;
            // 0x0110B2E8: LDR x25, [x8, #0x20]       | X25 = ((excludes + 8) + 32 + 8) + 32;   
            // 0x0110B2EC: AND w8, w19, #1            | W8 = (val_30 & 1);                      
            var val_9 = val_30 & 1;
            // 0x0110B2F0: TBNZ w8, #0, #0x110b314    | if (((val_30 & 1) & 0x1) != 0) goto label_14;
            if((val_9 & 1) != 0)
            {
                goto label_14;
            }
            // 0x0110B2F4: CBNZ x23, #0x110b2fc       | if ( != 0) goto label_15;               
            if(null != 0)
            {
                goto label_15;
            }
            // 0x0110B2F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_15:
            // 0x0110B2FC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110B300: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921509424793408)(", ");
            // 0x0110B304: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B308: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B30C: LDR x1, [x8]               | X1 = ", ";                              
            // 0x0110B310: BL #0x1b5b818              | X0 = Append(value:  ", ");              
            System.Text.StringBuilder val_10 = Append(value:  ", ");
            label_14:
            // 0x0110B314: CBNZ x23, #0x110b31c       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x0110B318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_16:
            // 0x0110B31C: LDR x1, [x26]              | X1 = "typeof(";                         
            // 0x0110B320: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B324: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B328: BL #0x1b5b818              | X0 = Append(value:  "typeof(");         
            System.Text.StringBuilder val_11 = Append(value:  "typeof(");
            // 0x0110B32C: CBNZ x25, #0x110b334       | if (((excludes + 8) + 32 + 8) + 32 != 0) goto label_17;
            if((((excludes + 8) + 32 + 8) + 32) != 0)
            {
                goto label_17;
            }
            // 0x0110B330: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_17:
            // 0x0110B334: LDR x8, [x25]              | X8 = ((excludes + 8) + 32 + 8) + 32;    
            // 0x0110B338: MOV x0, x25                | X0 = ((excludes + 8) + 32 + 8) + 32;//m1
            // 0x0110B33C: LDP x9, x1, [x8, #0x170]   | X9 = ((excludes + 8) + 32 + 8) + 32 + 368; X1 = ((excludes + 8) + 32 + 8) + 32 + 368 + 8; //  | 
            // 0x0110B340: BLR x9                     | X0 = ((excludes + 8) + 32 + 8) + 32 + 368();
            // 0x0110B344: MOV x1, x0                 | X1 = ((excludes + 8) + 32 + 8) + 32;//m1
            string val_12 = ((excludes + 8) + 32 + 8) + 32;
            // 0x0110B348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110B34C: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110B350: ADD x2, sp, #0x38          | X2 = (1152921512833205328 + 56) = 1152921512833205384 (0x10000001EA544488);
            // 0x0110B354: ADD x3, sp, #0x30          | X3 = (1152921512833205328 + 48) = 1152921512833205376 (0x10000001EA544480);
            // 0x0110B358: ADD x4, sp, #0x2f          | X4 = (1152921512833205328 + 47) = 1152921512833205375 (0x10000001EA54447F);
            // 0x0110B35C: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110B360: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  string val_12 = ((excludes + 8) + 32 + 8) + 32, realClsName: out  string val_13 = 0, isByRef: out  bool val_14 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_12, realClsName: out  val_13, isByRef: out  val_14, simpleClassName:  true);
            // 0x0110B364: LDR x25, [sp, #0x30]       | X25 = 0x0;                              
            // 0x0110B368: CBZ x23, #0x110b380        | if ( == 0) goto label_18;               
            if(null == 0)
            {
                goto label_18;
            }
            // 0x0110B36C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B370: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B374: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x0110B378: BL #0x1b5b818              | X0 = Append(value:  val_14);            
            System.Text.StringBuilder val_15 = Append(value:  val_14);
            // 0x0110B37C: B #0x110b398               |  goto label_19;                         
            goto label_19;
            label_18:
            // 0x0110B380: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x0110B384: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B388: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B38C: MOV x1, x25                | X1 = 0 (0x0);//ML01                     
            // 0x0110B390: BL #0x1b5b818              | X0 = Append(value:  val_14);            
            System.Text.StringBuilder val_16 = Append(value:  val_14);
            // 0x0110B394: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_19:
            // 0x0110B398: LDR x1, [x21]              | X1 = ")";                               
            // 0x0110B39C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B3A0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B3A4: BL #0x1b5b818              | X0 = Append(value:  ")");               
            System.Text.StringBuilder val_17 = Append(value:  ")");
            // 0x0110B3A8: LDRB w8, [sp, #0x2f]       | W8 = 0x0;                               
            // 0x0110B3AC: CBZ w8, #0x110b2b0         | if (0x0 == 0) goto label_22;            
            if(0 == 0)
            {
                goto label_22;
            }
            // 0x0110B3B0: CBNZ x23, #0x110b3b8       | if ( != 0) goto label_21;               
            if(null != 0)
            {
                goto label_21;
            }
            // 0x0110B3B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_21:
            // 0x0110B3B8: LDR x1, [x28]              | X1 = ".MakeByRefType()";                
            // 0x0110B3BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B3C0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B3C4: BL #0x1b5b818              | X0 = Append(value:  ".MakeByRefType()");
            System.Text.StringBuilder val_18 = Append(value:  ".MakeByRefType()");
            // 0x0110B3C8: B #0x110b2b0               |  goto label_22;                         
            goto label_22;
            label_12:
            // 0x0110B3CC: CBNZ x23, #0x110b3d4       | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x0110B3D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_23:
            // 0x0110B3D4: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x0110B3D8: LDR x8, [x8, #0xdd8]       | X8 = (string**)(1152921512833160080)("}");
            // 0x0110B3DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B3E0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B3E4: LDR x1, [x8]               | X1 = "}";                               
            // 0x0110B3E8: BL #0x1b5b818              | X0 = Append(value:  "}");               
            System.Text.StringBuilder val_19 = Append(value:  "}");
            // 0x0110B3EC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0110B3F0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0110B3F4: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x0110B3F8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110B3FC: LDP x24, x22, [sp, #0x10]  | X24 = methods; X22 = X3;                 //  | 
            // 0x0110B400: LDR x25, [sp, #8]          | X25 = typeof(System.Text.StringBuilder);
            // 0x0110B404: TBZ w8, #0, #0x110b414     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x0110B408: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110B40C: CBNZ w8, #0x110b414        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x0110B410: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_25:
            // 0x0110B414: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0110B418: LDR x8, [x8, #0x9a8]       | X8 = (string**)(1152921512833164256)("            args = new Type[]{0};");
            // 0x0110B41C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110B420: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110B424: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B428: LDR x1, [x8]               | X1 = "            args = new Type[]{0};";
            // 0x0110B42C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            args = new Type[]{0};");
            string val_20 = System.String.Format(format:  0, arg0:  "            args = new Type[]{0};");
            // 0x0110B430: MOV x23, x0                | X23 = val_20;//m1                       
            // 0x0110B434: CBZ x25, #0x110b44c        | if ( == 0) goto label_26;               
            if(null == 0)
            {
                goto label_26;
            }
            // 0x0110B438: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B43C: MOV x0, x25                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B440: MOV x1, x23                | X1 = val_20;//m1                        
            // 0x0110B444: BL #0x1b5c068              | X0 = AppendLine(value:  val_20);        
            System.Text.StringBuilder val_21 = AppendLine(value:  val_20);
            // 0x0110B448: B #0x110b464               |  goto label_27;                         
            goto label_27;
            label_26:
            // 0x0110B44C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            // 0x0110B450: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B454: MOV x0, x25                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B458: MOV x1, x23                | X1 = val_20;//m1                        
            // 0x0110B45C: BL #0x1b5c068              | X0 = AppendLine(value:  val_20);        
            System.Text.StringBuilder val_22 = AppendLine(value:  val_20);
            // 0x0110B460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_27:
            // 0x0110B464: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x0110B468: LDR x8, [x8, #0x1e0]       | X8 = (string**)(1152921512833176688)("            method = type.GetConstructor(flag, null, args, null);");
            // 0x0110B46C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B470: MOV x0, x25                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B474: LDR x1, [x8]               | X1 = "            method = type.GetConstructor(flag, null, args, null);";
            // 0x0110B478: BL #0x1b5c068              | X0 = AppendLine(value:  "            method = type.GetConstructor(flag, null, args, null);");
            System.Text.StringBuilder val_23 = AppendLine(value:  "            method = type.GetConstructor(flag, null, args, null);");
            // 0x0110B47C: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110B480: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110B484: ADD x1, sp, #0x28          | X1 = (1152921512833205328 + 40) = 1152921512833205368 (0x10000001EA544478);
            // 0x0110B488: STR w20, [sp, #0x28]       | stack[1152921512833205368] = 0x0;        //  dest_result_addr=1152921512833205368
            // 0x0110B48C: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110B490: BL #0x27bc028              | X0 = 1152921512833343696 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 0);
            // 0x0110B494: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x0110B498: LDR x8, [x8, #0x2f0]       | X8 = (string**)(1152921512833185088)("            app.RegisterCLRMethodRedirection(method, Ctor_{0});");
            // 0x0110B49C: MOV x2, x0                 | X2 = 1152921512833343696 (0x10000001EA5660D0);//ML01
            // 0x0110B4A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110B4A4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110B4A8: LDR x1, [x8]               | X1 = "            app.RegisterCLRMethodRedirection(method, Ctor_{0});";
            // 0x0110B4AC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRMethodRedirection(method, Ctor_{0});");
            string val_24 = System.String.Format(format:  0, arg0:  "            app.RegisterCLRMethodRedirection(method, Ctor_{0});");
            // 0x0110B4B0: MOV x23, x0                | X23 = val_24;//m1                       
            // 0x0110B4B4: CBNZ x25, #0x110b4bc       | if ( != 0) goto label_28;               
            if(null != 0)
            {
                goto label_28;
            }
            // 0x0110B4B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_28:
            // 0x0110B4BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B4C0: MOV x0, x25                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B4C4: MOV x1, x23                | X1 = val_24;//m1                        
            // 0x0110B4C8: BL #0x1b5c068              | X0 = AppendLine(value:  val_24);        
            System.Text.StringBuilder val_25 = AppendLine(value:  val_24);
            // 0x0110B4CC: ADD w20, w20, #1           | W20 = (0 + 1);                          
            val_26 = val_26 + 1;
            // 0x0110B4D0: B #0x110b1d0               |  goto label_29;                         
            goto label_29;
            label_3:
            // 0x0110B4D4: CBNZ x25, #0x110b4dc       | if ( != 0) goto label_30;               
            if(null != 0)
            {
                goto label_30;
            }
            // 0x0110B4D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_30:
            // 0x0110B4DC: LDR x8, [x25]              | X8 = ;                                  
            // 0x0110B4E0: MOV x0, x25                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B4E4: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x0110B4E8: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x0110B4EC: SUB sp, x29, #0x50         | SP = (1152921512833205472 - 80) = 1152921512833205392 (0x10000001EA544490);
            // 0x0110B4F0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0110B4F4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0110B4F8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0110B4FC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0110B500: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0110B504: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0110B508: RET                        |  return (System.String)typeof(System.Text.StringBuilder);
            return (string)val_27;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0110B50C (17872140), len: 8056  VirtAddr: 0x0110B50C RVA: 0x0110B50C token: 100679932 methodIndex: 29217 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Runtime.CompilerServices.ExtensionAttribute] // 0x28572D0
        internal static string GenerateConstructorWraperCode(System.Type type, System.Reflection.ConstructorInfo[] methods, string typeClsName, System.Collections.Generic.HashSet<System.Reflection.MethodBase> excludes, System.Collections.Generic.List<System.Type> valueTypeBinders)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.List<System.Type> val_185;
            //  | 
            var val_186;
            //  | 
            System.Reflection.ConstructorInfo[] val_187;
            //  | 
            string val_188;
            //  | 
            System.Type val_189;
            //  | 
            System.Reflection.ConstructorInfo[] val_190;
            //  | 
            string val_191;
            //  | 
            System.Reflection.ConstructorInfo[] val_192;
            //  | 
            string val_193;
            // 0x0110B50C: STP x28, x27, [sp, #-0x60]! | stack[1152921512834025904] = ???;  stack[1152921512834025912] = ???;  //  dest_result_addr=1152921512834025904 |  dest_result_addr=1152921512834025912
            // 0x0110B510: STP x26, x25, [sp, #0x10]  | stack[1152921512834025920] = ???;  stack[1152921512834025928] = ???;  //  dest_result_addr=1152921512834025920 |  dest_result_addr=1152921512834025928
            // 0x0110B514: STP x24, x23, [sp, #0x20]  | stack[1152921512834025936] = ???;  stack[1152921512834025944] = ???;  //  dest_result_addr=1152921512834025936 |  dest_result_addr=1152921512834025944
            // 0x0110B518: STP x22, x21, [sp, #0x30]  | stack[1152921512834025952] = ???;  stack[1152921512834025960] = ???;  //  dest_result_addr=1152921512834025952 |  dest_result_addr=1152921512834025960
            // 0x0110B51C: STP x20, x19, [sp, #0x40]  | stack[1152921512834025968] = ???;  stack[1152921512834025976] = ???;  //  dest_result_addr=1152921512834025968 |  dest_result_addr=1152921512834025976
            // 0x0110B520: STP x29, x30, [sp, #0x50]  | stack[1152921512834025984] = ???;  stack[1152921512834025992] = ???;  //  dest_result_addr=1152921512834025984 |  dest_result_addr=1152921512834025992
            // 0x0110B524: ADD x29, sp, #0x50         | X29 = (1152921512834025904 + 80) = 1152921512834025984 (0x10000001EA60CA00);
            // 0x0110B528: SUB sp, sp, #0xd0          | SP = (1152921512834025904 - 208) = 1152921512834025696 (0x10000001EA60C8E0);
            // 0x0110B52C: ADRP x19, #0x3735000       | X19 = 57888768 (0x3735000);             
            // 0x0110B530: LDRB w8, [x19, #0xb9f]     | W8 = (bool)static_value_03735B9F;       
            // 0x0110B534: MOV x0, x5                 | X0 = X5;//m1                            
            // 0x0110B538: MOV x21, x4                | X21 = valueTypeBinders;//m1             
            val_185 = valueTypeBinders;
            // 0x0110B53C: MOV x22, x2                | X22 = typeClsName;//m1                  
            // 0x0110B540: MOV x20, x1                | X20 = methods;//m1                      
            // 0x0110B544: STR x0, [sp, #0x48]        | stack[1152921512834025768] = X5;         //  dest_result_addr=1152921512834025768
            // 0x0110B548: STR x21, [sp, #0x18]       | stack[1152921512834025720] = valueTypeBinders;  //  dest_result_addr=1152921512834025720
            // 0x0110B54C: STR x22, [sp, #0x10]       | stack[1152921512834025712] = typeClsName;  //  dest_result_addr=1152921512834025712
            // 0x0110B550: TBNZ w8, #0, #0x110b56c    | if (static_value_03735B9F == true) goto label_0;
            // 0x0110B554: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x0110B558: LDR x8, [x8, #0xf48]       | X8 = 0x2B9286C;                         
            // 0x0110B55C: LDR w0, [x8]               | W0 = 0x20E0;                            
            // 0x0110B560: BL #0x2782188              | X0 = sub_2782188( ?? 0x20E0, ????);     
            // 0x0110B564: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0110B568: STRB w8, [x19, #0xb9f]     | static_value_03735B9F = true;            //  dest_result_addr=57891743
            label_0:
            // 0x0110B56C: STP xzr, xzr, [x29, #-0x60] | stack[1152921512834025888] = 0x0;  stack[1152921512834025896] = 0x0;  //  dest_result_addr=1152921512834025888 |  dest_result_addr=1152921512834025896
            bool val_30 = false;
            string val_29 = 0;
            // 0x0110B570: STURB wzr, [x29, #-0x61]   | stack[1152921512834025887] = 0x0;        //  dest_result_addr=1152921512834025887
            // 0x0110B574: STP xzr, xzr, [x29, #-0x78] | stack[1152921512834025864] = 0x0;  stack[1152921512834025872] = 0x0;  //  dest_result_addr=1152921512834025864 |  dest_result_addr=1152921512834025872
            bool val_84 = false;
            string val_83 = 0;
            // 0x0110B578: STURB wzr, [x29, #-0x79]   | stack[1152921512834025863] = 0x0;        //  dest_result_addr=1152921512834025863
            // 0x0110B57C: STUR xzr, [x29, #-0x88]    | stack[1152921512834025848] = 0x0;        //  dest_result_addr=1152921512834025848
            string val_101 = 0;
            // 0x0110B580: STR xzr, [sp, #0x90]       | stack[1152921512834025840] = 0x0;        //  dest_result_addr=1152921512834025840
            bool val_102 = false;
            // 0x0110B584: STRB wzr, [sp, #0x8f]      | stack[1152921512834025839] = 0x0;        //  dest_result_addr=1152921512834025839
            // 0x0110B588: STP xzr, xzr, [sp, #0x78]  | stack[1152921512834025816] = 0x0;  stack[1152921512834025824] = 0x0;  //  dest_result_addr=1152921512834025816 |  dest_result_addr=1152921512834025824
            bool val_147 = false;
            string val_146 = 0;
            // 0x0110B58C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110B590: STRB wzr, [sp, #0x77]      | stack[1152921512834025815] = 0x0;        //  dest_result_addr=1152921512834025815
            // 0x0110B594: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x0110B598: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x0110B59C: STP xzr, xzr, [sp, #0x60]  | stack[1152921512834025792] = 0x0;  stack[1152921512834025800] = 0x0;  //  dest_result_addr=1152921512834025792 |  dest_result_addr=1152921512834025800
            bool val_168 = false;
            string val_167 = 0;
            // 0x0110B5A0: STRB wzr, [sp, #0x5f]      | stack[1152921512834025791] = 0x0;        //  dest_result_addr=1152921512834025791
            // 0x0110B5A4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x0110B5A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B5AC: MOV x23, x0                | X23 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B5B0: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x0110B5B4: MOV x0, x20                | X0 = methods;//m1                       
            // 0x0110B5B8: CBNZ x0, #0x110b5c8        | if (methods != null) goto label_1;      
            if(methods != null)
            {
                goto label_1;
            }
            // 0x0110B5BC: MOV x19, x0                | X19 = methods;//m1                      
            // 0x0110B5C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? methods, ????);    
            // 0x0110B5C4: MOV x0, x19                | X0 = methods;//m1                       
            label_1:
            // 0x0110B5C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_186 = 0;
            // 0x0110B5CC: MOV x19, x0                | X19 = methods;//m1                      
            val_187 = methods;
            // 0x0110B5D0: BL #0x1b6d1cc              | X0 = methods.get_IsArray();             
            bool val_2 = methods.IsArray;
            // 0x0110B5D4: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x0110B5D8: TBZ w8, #0, #0x110b614     | if ((val_2 & 1) == false) goto label_2; 
            if(val_3 == false)
            {
                goto label_2;
            }
            // 0x0110B5DC: MOV x0, x19                | X0 = methods;//m1                       
            // 0x0110B5E0: CBNZ x0, #0x110b5f0        | if (methods != null) goto label_3;      
            if(val_187 != null)
            {
                goto label_3;
            }
            // 0x0110B5E4: MOV x19, x0                | X19 = methods;//m1                      
            val_187 = val_187;
            // 0x0110B5E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? methods, ????);    
            // 0x0110B5EC: MOV x0, x19                | X0 = methods;//m1                       
            label_3:
            // 0x0110B5F0: LDR x8, [x0]               | X8 = typeof(System.Reflection.ConstructorInfo[]);
            // 0x0110B5F4: STR x0, [sp, #0x30]        | stack[1152921512834025744] = methods;    //  dest_result_addr=1152921512834025744
            // 0x0110B5F8: LDR x9, [x8, #0x400]       | X9 = typeof(System.Reflection.ConstructorInfo[]).__il2cppRuntimeField_400;
            // 0x0110B5FC: LDR x1, [x8, #0x408]       | X1 = typeof(System.Reflection.ConstructorInfo[]).__il2cppRuntimeField_408;
            // 0x0110B600: BLR x9                     | X0 = typeof(System.Reflection.ConstructorInfo[]).__il2cppRuntimeField_400();
            // 0x0110B604: CMP w0, #1                 | STATE = COMPARE(methods, 0x1)           
            // 0x0110B608: CSET w8, gt                | W8 = val_187 > 0x1 ? 1 : 0;             
            var val_4 = (val_187 > 1) ? 1 : 0;
            // 0x0110B60C: STR w8, [sp, #0x44]        | stack[1152921512834025764] = val_187 > 0x1 ? 1 : 0;  //  dest_result_addr=1152921512834025764
            // 0x0110B610: B #0x110b61c               |  goto label_4;                          
            goto label_4;
            label_2:
            // 0x0110B614: STR x19, [sp, #0x30]       | stack[1152921512834025744] = methods;    //  dest_result_addr=1152921512834025744
            // 0x0110B618: STR wzr, [sp, #0x44]       | stack[1152921512834025764] = 0x0;        //  dest_result_addr=1152921512834025764
            label_4:
            // 0x0110B61C: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            // 0x0110B620: ADRP x25, #0x35d6000       | X25 = 56451072 (0x35D6000);             
            // 0x0110B624: STR w8, [sp, #0x24]        | stack[1152921512834025732] = 0x0;        //  dest_result_addr=1152921512834025732
            // 0x0110B628: LDR x25, [x25, #0xe38]     | X25 = 1152921504608284672;              
            // 0x0110B62C: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            // 0x0110B630: B #0x110b638               |  goto label_5;                          
            goto label_5;
            label_278:
            // 0x0110B634: ADD w24, w24, #1           | W24 = (0 + 1) = 1 (0x00000001);         
            label_5:
            // 0x0110B638: CBNZ x22, #0x110b640       | if (typeClsName != null) goto label_6;  
            if(typeClsName != null)
            {
                goto label_6;
            }
            // 0x0110B63C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x0110B640: LDR w8, [x22, #0x18]       | 
            // 0x0110B644: CMP w24, w8                | STATE = COMPARE(0x1, 0x0)               
            // 0x0110B648: B.GE #0x110d418            | if (1 >= 0) goto label_7;               
            if(1 >= 0)
            {
                goto label_7;
            }
            // 0x0110B64C: SXTW x19, w24              | X19 = 1 (0x00000001);                   
            // 0x0110B650: CMP w24, w8                | STATE = COMPARE(0x1, 0x0)               
            // 0x0110B654: STR x24, [sp, #0x38]       | stack[1152921512834025752] = 0x1;        //  dest_result_addr=1152921512834025752
            // 0x0110B658: B.LO #0x110b668            | if (1 < 0) goto label_8;                
            if(1 < 0)
            {
                goto label_8;
            }
            // 0x0110B65C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x0110B660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B664: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_8:
            // 0x0110B668: ADD x8, x22, x19, lsl #3   | X8 = (typeClsName + 8);                 
            string val_5 = typeClsName + 8;
            // 0x0110B66C: LDR x24, [x8, #0x20]       | 
            // 0x0110B670: CBZ x21, #0x110b694        | if (valueTypeBinders == null) goto label_9;
            if(val_185 == null)
            {
                goto label_9;
            }
            // 0x0110B674: ADRP x8, #0x366b000        | X8 = 57061376 (0x366B000);              
            // 0x0110B678: LDR x8, [x8, #0x2e0]       | X8 = 1152921512819970496;               
            // 0x0110B67C: MOV x0, x21                | X0 = valueTypeBinders;//m1              
            // 0x0110B680: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x0110B684: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.HashSet<System.Reflection.MethodBase>::Contains(System.Reflection.MethodBase item);
            // 0x0110B688: BL #0x1f3ea80              | X0 = valueTypeBinders.Contains(item:  1);
            bool val_6 = val_185.Contains(item:  1);
            // 0x0110B68C: AND w8, w0, #1             | W8 = (val_6 & 1);                       
            bool val_7 = val_6;
            // 0x0110B690: TBNZ w8, #0, #0x110b6c4    | if ((val_6 & 1) == true) goto label_11; 
            if(val_7 == true)
            {
                goto label_11;
            }
            label_9:
            // 0x0110B694: LDR x1, [sp, #0x30]        | X1 = methods;                           
            // 0x0110B698: MOV x2, x24                | X2 = 1 (0x1);//ML01                     
            // 0x0110B69C: BL #0x11084d0              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.ShouldSkipMethod(type:  bool val_6 = val_185.Contains(item:  1), i:  val_187);
            bool val_8 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.ShouldSkipMethod(type:  val_6, i:  val_187);
            // 0x0110B6A0: AND w8, w0, #1             | W8 = (val_8 & 1);                       
            bool val_9 = val_8;
            // 0x0110B6A4: TBNZ w8, #0, #0x110b6c4    | if ((val_8 & 1) == true) goto label_11; 
            if(val_9 == true)
            {
                goto label_11;
            }
            // 0x0110B6A8: CBNZ x24, #0x110b6b0       | if (0x1 != 0) goto label_12;            
            if(1 != 0)
            {
                goto label_12;
            }
            // 0x0110B6AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_12:
            // 0x0110B6B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110B6B4: MOV x0, x24                | X0 = 1 (0x1);//ML01                     
            // 0x0110B6B8: BL #0x13bbe68              | X0 = 1.get_IsStatic();                  
            bool val_10 = 1.IsStatic;
            // 0x0110B6BC: AND w8, w0, #1             | W8 = (val_10 & 1);                      
            bool val_11 = val_10;
            // 0x0110B6C0: TBZ w8, #0, #0x110b6cc     | if ((val_10 & 1) == false) goto label_13;
            if(val_11 == false)
            {
                goto label_13;
            }
            label_11:
            // 0x0110B6C4: LDR x24, [sp, #0x38]       | X24 = 0x1;                              
            // 0x0110B6C8: B #0x110b634               |  goto label_278;                        
            goto label_278;
            label_13:
            // 0x0110B6CC: CBNZ x24, #0x110b6d4       | if (0x1 != 0) goto label_15;            
            if(1 != 0)
            {
                goto label_15;
            }
            // 0x0110B6D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_15:
            // 0x0110B6D4: LDR x8, [x24]              | X8 = 0x10102464C45;                     
            // 0x0110B6D8: MOV x0, x24                | X0 = 1 (0x1);//ML01                     
            // 0x0110B6DC: LDR x9, [x8, #0x200]       | X9 = mem[1103844757061];                
            // 0x0110B6E0: LDR x1, [x8, #0x208]       | X1 = mem[1103844757069];                
            // 0x0110B6E4: BLR x9                     | X0 = mem[1103844757061]();              
            // 0x0110B6E8: MOV x24, x0                | X24 = 1 (0x1);//ML01                    
            // 0x0110B6EC: CBNZ x24, #0x110b6f4       | if (0x1 != 0) goto label_16;            
            if(1 != 0)
            {
                goto label_16;
            }
            // 0x0110B6F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1, ????);        
            label_16:
            // 0x0110B6F4: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110B6F8: LDR w19, [x24, #0x18]      | W19 = 0x9814;                           
            // 0x0110B6FC: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110B700: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110B704: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110B708: LDR w8, [sp, #0x24]        | W8 = 0x0;                               
            // 0x0110B70C: STR w8, [sp, #0x58]        | stack[1152921512834025784] = 0x0;        //  dest_result_addr=1152921512834025784
            // 0x0110B710: BL #0x27bc028              | X0 = 1152921512834124272 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 0);
            // 0x0110B714: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110B718: MOV x20, x0                | X20 = 1152921512834124272 (0x10000001EA6249F0);//ML01
            // 0x0110B71C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110B720: TBZ w9, #0, #0x110b734     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x0110B724: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110B728: CBNZ w9, #0x110b734        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x0110B72C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110B730: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_18:
            // 0x0110B734: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x0110B738: LDR x8, [x8, #0xdc0]       | X8 = (string**)(1152921512833470352)("        static StackObject* Ctor_{0}(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)");
            // 0x0110B73C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110B740: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110B744: MOV x2, x20                | X2 = 1152921512834124272 (0x10000001EA6249F0);//ML01
            // 0x0110B748: LDR x1, [x8]               | X1 = "        static StackObject* Ctor_{0}(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)";
            // 0x0110B74C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "        static StackObject* Ctor_{0}(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)");
            string val_12 = System.String.Format(format:  0, arg0:  "        static StackObject* Ctor_{0}(ILIntepreter __intp, StackObject* __esp, IList<object> __mStack, CLRMethod __method, bool isNewObj)");
            // 0x0110B750: MOV x20, x0                | X20 = val_12;//m1                       
            // 0x0110B754: CBZ x23, #0x110b784        | if ( == 0) goto label_19;               
            if(null == 0)
            {
                goto label_19;
            }
            // 0x0110B758: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B75C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B760: MOV x1, x20                | X1 = val_12;//m1                        
            // 0x0110B764: BL #0x1b5c068              | X0 = AppendLine(value:  val_12);        
            System.Text.StringBuilder val_13 = AppendLine(value:  val_12);
            // 0x0110B768: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x0110B76C: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921512832344928)("        {");
            // 0x0110B770: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B774: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B778: LDR x1, [x8]               | X1 = "        {";                       
            // 0x0110B77C: BL #0x1b5c068              | X0 = AppendLine(value:  "        {");   
            System.Text.StringBuilder val_14 = AppendLine(value:  "        {");
            // 0x0110B780: B #0x110b7b8               |  goto label_20;                         
            goto label_20;
            label_19:
            // 0x0110B784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            // 0x0110B788: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B78C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B790: MOV x1, x20                | X1 = val_12;//m1                        
            // 0x0110B794: BL #0x1b5c068              | X0 = AppendLine(value:  val_12);        
            System.Text.StringBuilder val_15 = AppendLine(value:  val_12);
            // 0x0110B798: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            // 0x0110B79C: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x0110B7A0: LDR x8, [x8, #0x240]       | X8 = (string**)(1152921512832344928)("        {");
            // 0x0110B7A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B7A8: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B7AC: LDR x1, [x8]               | X1 = "        {";                       
            // 0x0110B7B0: BL #0x1b5c068              | X0 = AppendLine(value:  "        {");   
            System.Text.StringBuilder val_16 = AppendLine(value:  "        {");
            // 0x0110B7B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_20:
            // 0x0110B7B8: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0110B7BC: LDR x8, [x8, #0x310]       | X8 = (string**)(1152921512833491184)("            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;");
            // 0x0110B7C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B7C4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B7C8: LDR x1, [x8]               | X1 = "            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;";
            // 0x0110B7CC: BL #0x1b5c068              | X0 = AppendLine(value:  "            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;");
            System.Text.StringBuilder val_17 = AppendLine(value:  "            ILRuntime.Runtime.Enviorment.AppDomain __domain = __intp.AppDomain;");
            // 0x0110B7D0: CBNZ x24, #0x110b7d8       | if (0x1 != 0) goto label_21;            
            if(1 != 0)
            {
                goto label_21;
            }
            // 0x0110B7D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_21:
            // 0x0110B7D8: LDR w8, [x24, #0x18]       | W8 = 0x9814;                            
            // 0x0110B7DC: CBZ w8, #0x110b800         | if (0x9814 == 0) goto label_22;         
            if(38932 == 0)
            {
                goto label_22;
            }
            // 0x0110B7E0: CBNZ x23, #0x110b7e8       | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x0110B7E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_23:
            // 0x0110B7E8: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x0110B7EC: LDR x8, [x8, #0xdb8]       | X8 = (string**)(1152921512833495520)("            StackObject* ptr_of_this_method;");
            // 0x0110B7F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B7F4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B7F8: LDR x1, [x8]               | X1 = "            StackObject* ptr_of_this_method;";
            // 0x0110B7FC: BL #0x1b5c068              | X0 = AppendLine(value:  "            StackObject* ptr_of_this_method;");
            System.Text.StringBuilder val_18 = AppendLine(value:  "            StackObject* ptr_of_this_method;");
            label_22:
            // 0x0110B800: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110B804: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110B808: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110B80C: STR w19, [sp, #0x58]       | stack[1152921512834025784] = 0x9814;     //  dest_result_addr=1152921512834025784
            // 0x0110B810: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110B814: BL #0x27bc028              | X0 = 1152921512834158064 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 38932);
            // 0x0110B818: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110B81C: MOV x20, x0                | X20 = 1152921512834158064 (0x10000001EA62CDF0);//ML01
            // 0x0110B820: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110B824: TBZ w9, #0, #0x110b838     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_25;
            // 0x0110B828: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110B82C: CBNZ w9, #0x110b838        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
            // 0x0110B830: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110B834: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_25:
            // 0x0110B838: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x0110B83C: LDR x8, [x8, #0xa10]       | X8 = (string**)(1152921512833504896)("            StackObject* __ret = ILIntepreter.Minus(__esp, {0});");
            // 0x0110B840: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110B844: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110B848: MOV x2, x20                | X2 = 1152921512834158064 (0x10000001EA62CDF0);//ML01
            // 0x0110B84C: LDR x1, [x8]               | X1 = "            StackObject* __ret = ILIntepreter.Minus(__esp, {0});";
            // 0x0110B850: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            StackObject* __ret = ILIntepreter.Minus(__esp, {0});");
            string val_19 = System.String.Format(format:  0, arg0:  "            StackObject* __ret = ILIntepreter.Minus(__esp, {0});");
            // 0x0110B854: MOV x20, x0                | X20 = val_19;//m1                       
            // 0x0110B858: CBNZ x23, #0x110b860       | if ( != 0) goto label_26;               
            if(null != 0)
            {
                goto label_26;
            }
            // 0x0110B85C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_26:
            // 0x0110B860: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B864: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110B868: MOV x1, x20                | X1 = val_19;//m1                        
            // 0x0110B86C: BL #0x1b5c068              | X0 = AppendLine(value:  val_19);        
            System.Text.StringBuilder val_20 = AppendLine(value:  val_19);
            // 0x0110B870: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x0110B874: BL #0x110a438              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.HasByRefParam(param:  System.Text.StringBuilder val_20 = AppendLine(value:  val_19));
            bool val_21 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.HasByRefParam(param:  val_20);
            // 0x0110B878: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x0110B87C: ADRP x9, #0x360f000        | X9 = 56684544 (0x360F000);              
            // 0x0110B880: STR w0, [sp, #0x54]        | stack[1152921512834025780] = val_21;     //  dest_result_addr=1152921512834025780
            // 0x0110B884: LDR x8, [x8, #0x9e0]       | X8 = (string**)(1152921509743366224)("false");
            // 0x0110B888: LDR x9, [x9, #0x4f0]       | X9 = (string**)(1152921509743366304)("true");
            // 0x0110B88C: TST w0, #1                 | STATE = COMPARE(val_21, 0x1)            
            // 0x0110B890: CSEL x8, x8, x9, ne        | X8 = val_21 != true ? "false" : "true"; 
            var val_22 = (val_21 != true) ? ("false") : ("true");
            // 0x0110B894: LDR x8, [x8]               | X8 = val_21 != true ? "false" : "true"; 
            // 0x0110B898: STR x8, [sp, #0x28]        | stack[1152921512834025736] = val_21 != true ? "false" : "true";  //  dest_result_addr=1152921512834025736
            // 0x0110B89C: CBNZ x24, #0x110b8a4       | if (0x1 != 0) goto label_27;            
            if(1 != 0)
            {
                goto label_27;
            }
            // 0x0110B8A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_27:
            // 0x0110B8A4: LDR x8, [x24, #0x18]       | X8 = 0x4000000000009814;                
            // 0x0110B8A8: CMP w8, #1                 | STATE = COMPARE(0x4000000000009814, 0x1)
            // 0x0110B8AC: B.LT #0x110c674            | if (38932 < 0x1) goto label_28;         
            if(38932 < 1)
            {
                goto label_28;
            }
            // 0x0110B8B0: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x0110B8B4: SXTW x26, w8               | X26 = 38932 (0x00009814);               
            // 0x0110B8B8: SUB w22, w8, #1            | W22 = (38932 - 1) = 4611686018427426835 (0x4000000000009813);
            // 0x0110B8BC: SUB w21, w9, w8            | W21 = (1 - 38932) = -4611686018427426835 (0xBFFFFFFFFFFF67ED);
            // 0x0110B8C0: B #0x110ba1c               |  goto label_177;                        
            goto label_177;
            label_99:
            // 0x0110B8C4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110B8C8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110B8CC: MOV x19, x26               | X19 = 38932 (0x9814);//ML01             
            // 0x0110B8D0: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110B8D4: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0110B8D8: LDR x8, [x8, #0xc08]       | X8 = 1152921504607592448;               
            // 0x0110B8DC: LDR x20, [x8]              | X20 = typeof(System.Int64);             
            // 0x0110B8E0: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110B8E4: TBZ w8, #0, #0x110b8f4     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_31;
            // 0x0110B8E8: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110B8EC: CBNZ w8, #0x110b8f4        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_31;
            // 0x0110B8F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_31:
            // 0x0110B8F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110B8F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110B8FC: MOV x1, x20                | X1 = 1152921504607592448 (0x10000000000B6000);//ML01
            // 0x0110B900: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_23 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110B904: LDUR x26, [x29, #-0x60]    | X26 = 0x0;                              
            // 0x0110B908: MOV x20, x0                | X20 = val_23;//m1                       
            // 0x0110B90C: CBNZ x27, #0x110b914       | if (X27 != 0) goto label_32;            
            if(X27 != 0)
            {
                goto label_32;
            }
            // 0x0110B910: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_32:
            // 0x0110B914: LDR x8, [x27]              | X8 = X27;                               
            // 0x0110B918: MOV x0, x27                | X0 = X27;//m1                           
            // 0x0110B91C: LDP x9, x1, [x8, #0x1a0]   | X9 = X27 + 416; X1 = X27 + 416 + 8;      //  | 
            // 0x0110B920: BLR x9                     | X0 = X27 + 416();                       
            // 0x0110B924: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110B928: MOV x27, x0                | X27 = X27;//m1                          
            // 0x0110B92C: CMP x28, x20               | STATE = COMPARE(X28, val_23)            
            // 0x0110B930: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504608284937 (0x100000000015F109);
            // 0x0110B934: LDRH w9, [x9]              | W9 = System.String.__il2cppRuntimeField_109;
            // 0x0110B938: AND w9, w9, #0x100         | W9 = (System.String.__il2cppRuntimeField_109 & 256);
            // 0x0110B93C: AND w9, w9, #0xffff        | W9 = ((System.String.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x0110B940: B.EQ #0x110b964            | if (X28 == val_23) goto label_33;       
            if(X28 == val_23)
            {
                goto label_33;
            }
            // 0x0110B944: CBZ w9, #0x110b958         | if (((System.String.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_35;
            // 0x0110B948: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110B94C: CBNZ w9, #0x110b958        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
            // 0x0110B950: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110B954: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_35:
            // 0x0110B958: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x0110B95C: LDR x8, [x8, #0x5e8]       | X8 = (string**)(1152921512833517392)("            {0} @{1} = ({0})__intp.RetriveInt64(ptr_of_this_method, __mStack);");
            // 0x0110B960: B #0x110c2c4               |  goto label_129;                        
            goto label_129;
            label_33:
            // 0x0110B964: CBZ w9, #0x110b978         | if (((System.String.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_38;
            // 0x0110B968: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110B96C: CBNZ w9, #0x110b978        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_38;
            // 0x0110B970: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110B974: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_38:
            // 0x0110B978: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x0110B97C: LDR x8, [x8, #0x398]       | X8 = (string**)(1152921512833517616)("            {0} @{1} = __intp.RetriveInt64(ptr_of_this_method, __mStack);");
            // 0x0110B980: B #0x110c2c4               |  goto label_129;                        
            goto label_129;
            label_102:
            // 0x0110B984: MOV x19, x26               | X19 = 0 (0x0);//ML01                    
            // 0x0110B988: LDUR x26, [x29, #-0x60]    | X26 = 0x0;                              
            // 0x0110B98C: CBNZ x27, #0x110b994       | if (X27 != 0) goto label_40;            
            if(X27 != 0)
            {
                goto label_40;
            }
            // 0x0110B990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_40:
            // 0x0110B994: LDR x8, [x27]              | X8 = X27;                               
            // 0x0110B998: MOV x0, x27                | X0 = X27;//m1                           
            // 0x0110B99C: LDP x9, x1, [x8, #0x1a0]   | X9 = X27 + 416; X1 = X27 + 416 + 8;      //  | 
            // 0x0110B9A0: BLR x9                     | X0 = X27 + 416();                       
            // 0x0110B9A4: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110B9A8: MOV x20, x0                | X20 = X27;//m1                          
            // 0x0110B9AC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110B9B0: TBZ w9, #0, #0x110b9c4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_42;
            // 0x0110B9B4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110B9B8: CBNZ w9, #0x110b9c4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
            // 0x0110B9BC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110B9C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_42:
            // 0x0110B9C4: ADRP x8, #0x3656000        | X8 = 56975360 (0x3656000);              
            // 0x0110B9C8: LDR x8, [x8, #0xf80]       | X8 = (string**)(1152921512833517840)("            {0} @{1} = __intp.RetriveFloat(ptr_of_this_method, __mStack);");
            // 0x0110B9CC: B #0x110c0f0               |  goto label_112;                        
            goto label_112;
            label_105:
            // 0x0110B9D0: MOV x19, x26               | X19 = 0 (0x0);//ML01                    
            // 0x0110B9D4: LDUR x26, [x29, #-0x60]    | X26 = 0x0;                              
            // 0x0110B9D8: CBNZ x27, #0x110b9e0       | if (X27 != 0) goto label_44;            
            if(X27 != 0)
            {
                goto label_44;
            }
            // 0x0110B9DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_44:
            // 0x0110B9E0: LDR x8, [x27]              | X8 = X27;                               
            // 0x0110B9E4: MOV x0, x27                | X0 = X27;//m1                           
            // 0x0110B9E8: LDP x9, x1, [x8, #0x1a0]   | X9 = X27 + 416; X1 = X27 + 416 + 8;      //  | 
            // 0x0110B9EC: BLR x9                     | X0 = X27 + 416();                       
            // 0x0110B9F0: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110B9F4: MOV x20, x0                | X20 = X27;//m1                          
            // 0x0110B9F8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110B9FC: TBZ w9, #0, #0x110ba10     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_46;
            // 0x0110BA00: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110BA04: CBNZ w9, #0x110ba10        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_46;
            // 0x0110BA08: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110BA0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_46:
            // 0x0110BA10: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x0110BA14: LDR x8, [x8, #0xa98]       | X8 = (string**)(1152921512833518064)("            {0} @{1} = __intp.RetriveDouble(ptr_of_this_method, __mStack);");
            // 0x0110BA18: B #0x110c0f0               |  goto label_112;                        
            goto label_112;
            label_177:
            // 0x0110BA1C: CBNZ x24, #0x110ba24       | if (0x1 != 0) goto label_48;            
            if(1 != 0)
            {
                goto label_48;
            }
            // 0x0110BA20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_48:
            // 0x0110BA24: LDR x8, [x24, #0x18]       | X8 = 0x4000000000009814;                
            // 0x0110BA28: CMP w22, w8                | STATE = COMPARE(0x4000000000009813, 0x4000000000009814)
            // 0x0110BA2C: B.LO #0x110ba40            | if (4611686018427426835 < 38932) goto label_49;
            if(4611686018427426835 < 38932)
            {
                goto label_49;
            }
            // 0x0110BA30: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
            // 0x0110BA34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110BA38: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            // 0x0110BA3C: LDR x8, [x24, #0x18]       | X8 = 0x4000000000009814;                
            label_49:
            // 0x0110BA40: ADD x9, x24, x26, lsl #3   | X9 = (1 + 311456) = 311457 (0x0004C0A1);
            // 0x0110BA44: LDR x27, [x9, #0x18]       | X27 = 0x3000000000339FF;                
            // 0x0110BA48: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x0110BA4C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x0110BA50: ADD w8, w21, w8            | W8 = (-4611686018427426835 + 38932) = 1 (0x00000001);
            // 0x0110BA54: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110BA58: STR w8, [sp, #0x58]        | stack[1152921512834025784] = 0x1;        //  dest_result_addr=1152921512834025784
            // 0x0110BA5C: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x0110BA60: BL #0x27bc028              | X0 = 1152921512834174448 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x0110BA64: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110BA68: MOV x20, x0                | X20 = 1152921512834174448 (0x10000001EA630DF0);//ML01
            // 0x0110BA6C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110BA70: TBZ w9, #0, #0x110ba84     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x0110BA74: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110BA78: CBNZ w9, #0x110ba84        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x0110BA7C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110BA80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_51:
            // 0x0110BA84: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x0110BA88: LDR x8, [x8, #0x6e0]       | X8 = (string**)(1152921512833522384)("            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});");
            // 0x0110BA8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BA90: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110BA94: MOV x2, x20                | X2 = 1152921512834174448 (0x10000001EA630DF0);//ML01
            // 0x0110BA98: LDR x1, [x8]               | X1 = "            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});";
            // 0x0110BA9C: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});");
            string val_26 = System.String.Format(format:  0, arg0:  "            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});");
            // 0x0110BAA0: MOV x20, x0                | X20 = val_26;//m1                       
            // 0x0110BAA4: CBNZ x23, #0x110baac       | if ( != 0) goto label_52;               
            if(null != 0)
            {
                goto label_52;
            }
            // 0x0110BAA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_52:
            // 0x0110BAAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BAB0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110BAB4: MOV x1, x20                | X1 = val_26;//m1                        
            // 0x0110BAB8: BL #0x1b5c068              | X0 = AppendLine(value:  val_26);        
            System.Text.StringBuilder val_27 = AppendLine(value:  val_26);
            // 0x0110BABC: CBNZ x27, #0x110bac4       | if (0x3000000000339FF != 0) goto label_53;
            if(211455 != 0)
            {
                goto label_53;
            }
            // 0x0110BAC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_53:
            // 0x0110BAC4: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110BAC8: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BACC: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110BAD0: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110BAD4: MOV x1, x0                 | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            string val_28 = 211455;
            // 0x0110BAD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BADC: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110BAE0: SUB x2, x29, #0x58         | X2 = (1152921512834025984 - 88) = 1152921512834025896 (0x10000001EA60C9A8);
            // 0x0110BAE4: SUB x3, x29, #0x60         | X3 = (1152921512834025984 - 96) = 1152921512834025888 (0x10000001EA60C9A0);
            // 0x0110BAE8: SUB x4, x29, #0x61         | X4 = (1152921512834025984 - 97) = 1152921512834025887 (0x10000001EA60C99F);
            // 0x0110BAEC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110BAF0: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  string val_28 = 211455, realClsName: out  string val_29 = 0, isByRef: out  bool val_30 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_28, realClsName: out  val_29, isByRef: out  val_30, simpleClassName:  true);
            // 0x0110BAF4: CBNZ x27, #0x110bafc       | if (0x3000000000339FF != 0) goto label_54;
            if(211455 != 0)
            {
                goto label_54;
            }
            // 0x0110BAF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_54:
            // 0x0110BAFC: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110BB00: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB04: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110BB08: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110BB0C: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB10: CBNZ x20, #0x110bb18       | if (0x3000000000339FF != 0) goto label_55;
            if(211455 != 0)
            {
                goto label_55;
            }
            // 0x0110BB14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_55:
            // 0x0110BB18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110BB1C: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB20: BL #0x1b6d1dc              | X0 = 211455.get_IsByRef();              
            bool val_31 = 211455.IsByRef;
            // 0x0110BB24: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110BB28: MOV w20, w0                | W20 = val_31;//m1                       
            // 0x0110BB2C: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB30: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110BB34: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110BB38: MOV x28, x0                | X28 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB3C: TBZ w20, #0, #0x110bb60    | if (val_31 == false) goto label_56;     
            if(val_31 == false)
            {
                goto label_56;
            }
            // 0x0110BB40: CBNZ x28, #0x110bb48       | if (0x3000000000339FF != 0) goto label_57;
            if(211455 != 0)
            {
                goto label_57;
            }
            // 0x0110BB44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_57:
            // 0x0110BB48: LDR x8, [x28]              | X8 = mem[216172782113995263];           
            // 0x0110BB4C: MOV x0, x28                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB50: LDR x9, [x8, #0x410]       | X9 = mem[216172782113995263] + 1040;    
            // 0x0110BB54: LDR x1, [x8, #0x418]       | X1 = mem[216172782113995263] + 1048;    
            // 0x0110BB58: BLR x9                     | X0 = mem[216172782113995263] + 1040();  
            // 0x0110BB5C: MOV x28, x0                | X28 = 216172782113995263 (0x3000000000339FF);//ML01
            label_56:
            // 0x0110BB60: ADD w20, w22, #1           | W20 = (4611686018427426835 + 1) = 4611686018427426836 (0x4000000000009814);
            // 0x0110BB64: CBNZ x28, #0x110bb6c       | if (0x3000000000339FF != 0) goto label_58;
            if(211455 != 0)
            {
                goto label_58;
            }
            // 0x0110BB68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_58:
            // 0x0110BB6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110BB70: MOV x0, x28                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB74: BL #0x1b6d264              | X0 = 211455.get_IsValueType();          
            bool val_32 = 211455.IsValueType;
            // 0x0110BB78: TBZ w0, #0, #0x110bc10     | if (val_32 == false) goto label_63;     
            if(val_32 == false)
            {
                goto label_63;
            }
            // 0x0110BB7C: CBNZ x28, #0x110bb84       | if (0x3000000000339FF != 0) goto label_60;
            if(211455 != 0)
            {
                goto label_60;
            }
            // 0x0110BB80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_60:
            // 0x0110BB84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110BB88: MOV x0, x28                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BB8C: BL #0x1b6d41c              | X0 = 211455.get_IsPrimitive();          
            bool val_33 = 211455.IsPrimitive;
            // 0x0110BB90: LDR x8, [sp, #0x48]        | X8 = X5;                                
            // 0x0110BB94: CBZ x8, #0x110bc10         | if (X5 == 0) goto label_63;             
            if(X5 == 0)
            {
                goto label_63;
            }
            // 0x0110BB98: AND w8, w0, #1             | W8 = (val_33 & 1);                      
            bool val_34 = val_33;
            // 0x0110BB9C: TBNZ w8, #0, #0x110bc10    | if ((val_33 & 1) == true) goto label_63;
            if(val_34 == true)
            {
                goto label_63;
            }
            // 0x0110BBA0: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110BBA4: LDR x8, [x8, #0x9e0]       | X8 = 1152921512820334400;               
            // 0x0110BBA8: LDR x0, [sp, #0x48]        | X0 = X5;                                
            // 0x0110BBAC: MOV x1, x28                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BBB0: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.Type>::Contains(System.Type item);
            // 0x0110BBB4: BL #0x25ead74              | X0 = X5.Contains(item:  211455);        
            bool val_35 = X5.Contains(item:  211455);
            // 0x0110BBB8: TBZ w0, #0, #0x110bc10     | if (val_35 == false) goto label_63;     
            if(val_35 == false)
            {
                goto label_63;
            }
            // 0x0110BBBC: LDUR x28, [x29, #-0x60]    | X28 = 0x0;                              
            // 0x0110BBC0: LDR w8, [sp, #0x44]        | W8 = 0x0;                               
            // 0x0110BBC4: CBZ w8, #0x110c300         | if (0x0 == 0) goto label_64;            
            if(0 == 0)
            {
                goto label_64;
            }
            // 0x0110BBC8: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110BBCC: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110BBD0: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110BBD4: STR w20, [sp, #0x58]       | stack[1152921512834025784] = 0x4000000000009814;  //  dest_result_addr=1152921512834025784
            // 0x0110BBD8: MOV w19, w20               | W19 = 4611686018427426836 (0x4000000000009814);//ML01
            // 0x0110BBDC: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110BBE0: BL #0x27bc028              | X0 = 1152921512834186736 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 38932);
            // 0x0110BBE4: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110BBE8: MOV x20, x0                | X20 = 1152921512834186736 (0x10000001EA633DF0);//ML01
            // 0x0110BBEC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110BBF0: TBZ w9, #0, #0x110bc04     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_66;
            // 0x0110BBF4: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110BBF8: CBNZ w9, #0x110bc04        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_66;
            // 0x0110BBFC: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110BC00: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_66:
            // 0x0110BC04: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x0110BC08: LDR x8, [x8, #0x278]       | X8 = (string**)(1152921512833534880)("            {0} a{1} = new {0}();");
            // 0x0110BC0C: B #0x110c344               |  goto label_67;                         
            goto label_67;
            label_63:
            // 0x0110BC10: LDURB w8, [x29, #-0x61]    | W8 = 0x0;                               
            // 0x0110BC14: CBZ w8, #0x110bfe8         | if (0x0 == 0) goto label_68;            
            if(0 == 0)
            {
                goto label_68;
            }
            // 0x0110BC18: CBNZ x27, #0x110bc20       | if (0x3000000000339FF != 0) goto label_69;
            if(211455 != 0)
            {
                goto label_69;
            }
            // 0x0110BC1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_69:
            // 0x0110BC20: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110BC24: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BC28: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110BC2C: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110BC30: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BC34: CBNZ x20, #0x110bc3c       | if (0x3000000000339FF != 0) goto label_70;
            if(211455 != 0)
            {
                goto label_70;
            }
            // 0x0110BC38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_70:
            // 0x0110BC3C: LDR x8, [x20]              | X8 = mem[216172782113995263];           
            // 0x0110BC40: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BC44: LDR x9, [x8, #0x410]       | X9 = mem[216172782113995263] + 1040;    
            // 0x0110BC48: LDR x1, [x8, #0x418]       | X1 = mem[216172782113995263] + 1048;    
            // 0x0110BC4C: BLR x9                     | X0 = mem[216172782113995263] + 1040();  
            // 0x0110BC50: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BC54: CBNZ x20, #0x110bc5c       | if (0x3000000000339FF != 0) goto label_71;
            if(211455 != 0)
            {
                goto label_71;
            }
            // 0x0110BC58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_71:
            // 0x0110BC5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110BC60: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BC64: BL #0x1b6d41c              | X0 = 211455.get_IsPrimitive();          
            bool val_36 = 211455.IsPrimitive;
            // 0x0110BC68: TBZ w0, #0, #0x110c0a8     | if (val_36 == false) goto label_72;     
            if(val_36 == false)
            {
                goto label_72;
            }
            // 0x0110BC6C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BC70: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BC74: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BC78: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x0110BC7C: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x0110BC80: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x0110BC84: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BC88: TBZ w8, #0, #0x110bc98     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_74;
            // 0x0110BC8C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BC90: CBNZ w8, #0x110bc98        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_74;
            // 0x0110BC94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_74:
            // 0x0110BC98: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BC9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BCA0: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x0110BCA4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_37 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BCA8: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_37)
            // 0x0110BCAC: B.EQ #0x110c108            | if (211455 == val_37) goto label_93;    
            if(211455 == val_37)
            {
                goto label_93;
            }
            // 0x0110BCB0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BCB4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BCB8: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BCBC: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x0110BCC0: LDR x8, [x8, #0xff0]       | X8 = 1152921504607645696;               
            // 0x0110BCC4: LDR x20, [x8]              | X20 = typeof(System.UInt32);            
            // 0x0110BCC8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BCCC: TBZ w8, #0, #0x110bcdc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_77;
            // 0x0110BCD0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BCD4: CBNZ w8, #0x110bcdc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_77;
            // 0x0110BCD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_77:
            // 0x0110BCDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BCE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BCE4: MOV x1, x20                | X1 = 1152921504607645696 (0x10000000000C3000);//ML01
            // 0x0110BCE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_38 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BCEC: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_38)
            // 0x0110BCF0: B.EQ #0x110c108            | if (211455 == val_38) goto label_93;    
            if(211455 == val_38)
            {
                goto label_93;
            }
            // 0x0110BCF4: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BCF8: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BCFC: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BD00: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0110BD04: LDR x8, [x8, #0x908]       | X8 = 1152921504607911936;               
            // 0x0110BD08: LDR x20, [x8]              | X20 = typeof(System.Int16);             
            // 0x0110BD0C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BD10: TBZ w8, #0, #0x110bd20     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_80;
            // 0x0110BD14: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BD18: CBNZ w8, #0x110bd20        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_80;
            // 0x0110BD1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_80:
            // 0x0110BD20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BD24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BD28: MOV x1, x20                | X1 = 1152921504607911936 (0x1000000000104000);//ML01
            // 0x0110BD2C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_39 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BD30: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_39)
            // 0x0110BD34: B.EQ #0x110c108            | if (211455 == val_39) goto label_93;    
            if(211455 == val_39)
            {
                goto label_93;
            }
            // 0x0110BD38: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BD3C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BD40: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BD44: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x0110BD48: LDR x8, [x8, #0x540]       | X8 = 1152921504607965184;               
            // 0x0110BD4C: LDR x20, [x8]              | X20 = typeof(System.UInt16);            
            // 0x0110BD50: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BD54: TBZ w8, #0, #0x110bd64     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_83;
            // 0x0110BD58: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BD5C: CBNZ w8, #0x110bd64        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_83;
            // 0x0110BD60: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_83:
            // 0x0110BD64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BD68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BD6C: MOV x1, x20                | X1 = 1152921504607965184 (0x1000000000111000);//ML01
            // 0x0110BD70: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_40 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BD74: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_40)
            // 0x0110BD78: B.EQ #0x110c108            | if (211455 == val_40) goto label_93;    
            if(211455 == val_40)
            {
                goto label_93;
            }
            // 0x0110BD7C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BD80: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BD84: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BD88: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x0110BD8C: LDR x8, [x8, #0x468]       | X8 = 1152921504607805440;               
            // 0x0110BD90: LDR x20, [x8]              | X20 = typeof(System.Byte);              
            // 0x0110BD94: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BD98: TBZ w8, #0, #0x110bda8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_86;
            // 0x0110BD9C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BDA0: CBNZ w8, #0x110bda8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_86;
            // 0x0110BDA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_86:
            // 0x0110BDA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BDAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BDB0: MOV x1, x20                | X1 = 1152921504607805440 (0x10000000000EA000);//ML01
            // 0x0110BDB4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_41 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BDB8: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_41)
            // 0x0110BDBC: B.EQ #0x110c108            | if (211455 == val_41) goto label_93;    
            if(211455 == val_41)
            {
                goto label_93;
            }
            // 0x0110BDC0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BDC4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BDC8: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BDCC: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x0110BDD0: LDR x8, [x8, #0xa40]       | X8 = 1152921504607858688;               
            // 0x0110BDD4: LDR x20, [x8]              | X20 = typeof(System.SByte);             
            // 0x0110BDD8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BDDC: TBZ w8, #0, #0x110bdec     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_89;
            // 0x0110BDE0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BDE4: CBNZ w8, #0x110bdec        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_89;
            // 0x0110BDE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_89:
            // 0x0110BDEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BDF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BDF4: MOV x1, x20                | X1 = 1152921504607858688 (0x10000000000F7000);//ML01
            // 0x0110BDF8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_42 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BDFC: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_42)
            // 0x0110BE00: B.EQ #0x110c108            | if (211455 == val_42) goto label_93;    
            if(211455 == val_42)
            {
                goto label_93;
            }
            // 0x0110BE04: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BE08: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BE0C: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BE10: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x0110BE14: LDR x8, [x8, #0xcc8]       | X8 = 1152921504608231424;               
            // 0x0110BE18: LDR x20, [x8]              | X20 = typeof(System.Char);              
            // 0x0110BE1C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BE20: TBZ w8, #0, #0x110be30     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_92;
            // 0x0110BE24: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BE28: CBNZ w8, #0x110be30        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_92;
            // 0x0110BE2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_92:
            // 0x0110BE30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BE34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BE38: MOV x1, x20                | X1 = 1152921504608231424 (0x1000000000152000);//ML01
            // 0x0110BE3C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_43 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BE40: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_43)
            // 0x0110BE44: B.EQ #0x110c108            | if (211455 == val_43) goto label_93;    
            if(211455 == val_43)
            {
                goto label_93;
            }
            // 0x0110BE48: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BE4C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BE50: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BE54: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0110BE58: LDR x8, [x8, #0xc08]       | X8 = 1152921504607592448;               
            // 0x0110BE5C: LDR x20, [x8]              | X20 = typeof(System.Int64);             
            // 0x0110BE60: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BE64: TBZ w8, #0, #0x110be74     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_95;
            // 0x0110BE68: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BE6C: CBNZ w8, #0x110be74        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_95;
            // 0x0110BE70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_95:
            // 0x0110BE74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BE78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BE7C: MOV x1, x20                | X1 = 1152921504607592448 (0x10000000000B6000);//ML01
            // 0x0110BE80: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_44 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BE84: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_44)
            // 0x0110BE88: B.EQ #0x110b8c4            | if (211455 == val_44) goto label_99;    
            if(211455 == val_44)
            {
                goto label_99;
            }
            // 0x0110BE8C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BE90: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BE94: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BE98: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x0110BE9C: LDR x8, [x8, #0x6a0]       | X8 = 1152921504607752192;               
            // 0x0110BEA0: LDR x20, [x8]              | X20 = typeof(System.UInt64);            
            // 0x0110BEA4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BEA8: TBZ w8, #0, #0x110beb8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_98;
            // 0x0110BEAC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BEB0: CBNZ w8, #0x110beb8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_98;
            // 0x0110BEB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_98:
            // 0x0110BEB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BEBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BEC0: MOV x1, x20                | X1 = 1152921504607752192 (0x10000000000DD000);//ML01
            // 0x0110BEC4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_45 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BEC8: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_45)
            // 0x0110BECC: B.EQ #0x110b8c4            | if (211455 == val_45) goto label_99;    
            if(211455 == val_45)
            {
                goto label_99;
            }
            // 0x0110BED0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BED4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BED8: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BEDC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x0110BEE0: LDR x8, [x8, #0xc48]       | X8 = 1152921504608444416;               
            // 0x0110BEE4: LDR x20, [x8]              | X20 = typeof(System.Single);            
            // 0x0110BEE8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BEEC: TBZ w8, #0, #0x110befc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_101;
            // 0x0110BEF0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BEF4: CBNZ w8, #0x110befc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_101;
            // 0x0110BEF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_101:
            // 0x0110BEFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BF00: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BF04: MOV x1, x20                | X1 = 1152921504608444416 (0x1000000000186000);//ML01
            // 0x0110BF08: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_46 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BF0C: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_46)
            // 0x0110BF10: B.EQ #0x110b984            | if (211455 == val_46) goto label_102;   
            if(211455 == val_46)
            {
                goto label_102;
            }
            // 0x0110BF14: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BF18: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BF1C: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BF20: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110BF24: LDR x8, [x8, #0x710]       | X8 = 1152921504608497664;               
            // 0x0110BF28: LDR x20, [x8]              | X20 = typeof(System.Double);            
            // 0x0110BF2C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BF30: TBZ w8, #0, #0x110bf40     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_104;
            // 0x0110BF34: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BF38: CBNZ w8, #0x110bf40        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_104;
            // 0x0110BF3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_104:
            // 0x0110BF40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BF44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BF48: MOV x1, x20                | X1 = 1152921504608497664 (0x1000000000193000);//ML01
            // 0x0110BF4C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_47 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BF50: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_47)
            // 0x0110BF54: B.EQ #0x110b9d0            | if (211455 == val_47) goto label_105;   
            if(211455 == val_47)
            {
                goto label_105;
            }
            // 0x0110BF58: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110BF5C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110BF60: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110BF64: ADRP x8, #0x365e000        | X8 = 57008128 (0x365E000);              
            // 0x0110BF68: LDR x8, [x8, #0xcb8]       | X8 = 1152921504608604160;               
            // 0x0110BF6C: LDR x20, [x8]              | X20 = typeof(System.Boolean);           
            // 0x0110BF70: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110BF74: TBZ w8, #0, #0x110bf84     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_107;
            // 0x0110BF78: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110BF7C: CBNZ w8, #0x110bf84        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_107;
            // 0x0110BF80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_107:
            // 0x0110BF84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110BF88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110BF8C: MOV x1, x20                | X1 = 1152921504608604160 (0x10000000001AD000);//ML01
            // 0x0110BF90: MOV x19, x26               | X19 = 38932 (0x9814);//ML01             
            // 0x0110BF94: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_48 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110BF98: CMP x28, x0                | STATE = COMPARE(0x3000000000339FF, val_48)
            // 0x0110BF9C: B.NE #0x110d450            | if (211455 != val_48) goto label_108;   
            if(211455 != val_48)
            {
                goto label_108;
            }
            // 0x0110BFA0: LDUR x26, [x29, #-0x60]    | X26 = 0x0;                              
            // 0x0110BFA4: CBNZ x27, #0x110bfac       | if (0x3000000000339FF != 0) goto label_109;
            if(211455 != 0)
            {
                goto label_109;
            }
            // 0x0110BFA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
            label_109:
            // 0x0110BFAC: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110BFB0: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BFB4: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110BFB8: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110BFBC: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110BFC0: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110BFC4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110BFC8: TBZ w9, #0, #0x110bfdc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_111;
            // 0x0110BFCC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110BFD0: CBNZ w9, #0x110bfdc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_111;
            // 0x0110BFD4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110BFD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_111:
            // 0x0110BFDC: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x0110BFE0: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921512833584176)("            {0} @{1} = __intp.RetriveInt32(ptr_of_this_method, __mStack) == 1;");
            // 0x0110BFE4: B #0x110c0f0               |  goto label_112;                        
            goto label_112;
            label_68:
            // 0x0110BFE8: LDUR x28, [x29, #-0x60]    | X28 = 0x0;                              
            // 0x0110BFEC: LDR w8, [sp, #0x44]        | W8 = 0x0;                               
            // 0x0110BFF0: CBZ w8, #0x110c1a8         | if (0x0 == 0) goto label_113;           
            if(0 == 0)
            {
                goto label_113;
            }
            // 0x0110BFF4: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110BFF8: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110BFFC: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110C000: MOV x19, x24               | X19 = 1 (0x1);//ML01                    
            // 0x0110C004: MOV x24, x26               | X24 = 38932 (0x9814);//ML01             
            // 0x0110C008: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110C00C: STR w20, [sp, #0x58]       | stack[1152921512834025784] = 0x4000000000009814;  //  dest_result_addr=1152921512834025784
            // 0x0110C010: BL #0x27bc028              | X0 = 1152921512834239984 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 38932);
            // 0x0110C014: MOV x26, x0                | X26 = 1152921512834239984 (0x10000001EA640DF0);//ML01
            // 0x0110C018: CBNZ x27, #0x110c020       | if (0x3000000000339FF != 0) goto label_114;
            if(211455 != 0)
            {
                goto label_114;
            }
            // 0x0110C01C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 38932, ????);      
            label_114:
            // 0x0110C020: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C024: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C028: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C02C: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C030: LDUR x2, [x29, #-0x60]     | X2 = 0x0;                               
            // 0x0110C034: MOV x1, x0                 | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C038: BL #0x1108f2c              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            string val_49 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            // 0x0110C03C: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C040: MOV x20, x0                | X20 = val_49;//m1                       
            // 0x0110C044: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C048: TBZ w9, #0, #0x110c05c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_116;
            // 0x0110C04C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C050: CBNZ w9, #0x110c05c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_116;
            // 0x0110C054: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C058: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_116:
            // 0x0110C05C: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x0110C060: LDR x8, [x8, #0x6c8]       | X8 = (string**)(1152921512833592592)("            {0} a{1} = {2};");
            // 0x0110C064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C068: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0110C06C: MOV x2, x28                | X2 = 0 (0x0);//ML01                     
            // 0x0110C070: LDR x1, [x8]               | X1 = "            {0} a{1} = {2};";     
            // 0x0110C074: MOV x3, x26                | X3 = 1152921512834239984 (0x10000001EA640DF0);//ML01
            // 0x0110C078: MOV x4, x20                | X4 = val_49;//m1                        
            // 0x0110C07C: BL #0x18af46c              | X0 = System.String.Format(format:  0, arg0:  "            {0} a{1} = {2};", arg1:  val_30, arg2:  4611686018427426836);
            string val_50 = System.String.Format(format:  0, arg0:  "            {0} a{1} = {2};", arg1:  val_30, arg2:  4611686018427426836);
            // 0x0110C080: MOV x20, x0                | X20 = val_50;//m1                       
            // 0x0110C084: CBNZ x23, #0x110c08c       | if ( != 0) goto label_117;              
            if(null != 0)
            {
                goto label_117;
            }
            // 0x0110C088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_50, ????);     
            label_117:
            // 0x0110C08C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C090: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C094: MOV x1, x20                | X1 = val_50;//m1                        
            // 0x0110C098: BL #0x1b5c068              | X0 = AppendLine(value:  val_50);        
            System.Text.StringBuilder val_51 = AppendLine(value:  val_50);
            // 0x0110C09C: MOV x26, x24               | X26 = 38932 (0x9814);//ML01             
            // 0x0110C0A0: MOV x24, x19               | X24 = 1 (0x1);//ML01                    
            // 0x0110C0A4: B #0x110c250               |  goto label_118;                        
            goto label_118;
            label_72:
            // 0x0110C0A8: MOV x19, x26               | X19 = 38932 (0x9814);//ML01             
            // 0x0110C0AC: LDUR x26, [x29, #-0x60]    | X26 = 0x0;                              
            // 0x0110C0B0: CBNZ x27, #0x110c0b8       | if (0x3000000000339FF != 0) goto label_119;
            if(211455 != 0)
            {
                goto label_119;
            }
            // 0x0110C0B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_119:
            // 0x0110C0B8: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C0BC: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C0C0: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110C0C4: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110C0C8: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C0CC: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C0D0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C0D4: TBZ w9, #0, #0x110c0e8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_121;
            // 0x0110C0D8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C0DC: CBNZ w9, #0x110c0e8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_121;
            // 0x0110C0E0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C0E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_121:
            // 0x0110C0E8: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x0110C0EC: LDR x8, [x8, #0x9a8]       | X8 = (string**)(1152921512833600912)("            {0} @{1} = ({0})typeof({0}).CheckCLRTypes(__intp.RetriveObject(ptr_of_this_method, __mStack));");
            label_112:
            // 0x0110C0F0: LDR x1, [x8]               | X1 = "            {0} @{1} = ({0})typeof({0}).CheckCLRTypes(__intp.RetriveObject(ptr_of_this_method, __mStack));";
            // 0x0110C0F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C0F8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110C0FC: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x0110C100: MOV x3, x20                | X3 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C104: B #0x110c2d8               |  goto label_122;                        
            goto label_122;
            label_93:
            // 0x0110C108: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0110C10C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0110C110: MOV x19, x26               | X19 = 38932 (0x9814);//ML01             
            // 0x0110C114: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0110C118: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x0110C11C: LDR x8, [x8, #0x9a8]       | X8 = 1152921504607113216;               
            // 0x0110C120: LDR x20, [x8]              | X20 = typeof(System.Int32);             
            // 0x0110C124: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0110C128: TBZ w8, #0, #0x110c138     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_124;
            // 0x0110C12C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0110C130: CBNZ w8, #0x110c138        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_124;
            // 0x0110C134: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_124:
            // 0x0110C138: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C13C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C140: MOV x1, x20                | X1 = 1152921504607113216 (0x1000000000041000);//ML01
            // 0x0110C144: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_52 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0110C148: LDUR x26, [x29, #-0x60]    | X26 = 0x0;                              
            // 0x0110C14C: MOV x20, x0                | X20 = val_52;//m1                       
            // 0x0110C150: CBNZ x27, #0x110c158       | if (0x3000000000339FF != 0) goto label_125;
            if(211455 != 0)
            {
                goto label_125;
            }
            // 0x0110C154: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_52, ????);     
            label_125:
            // 0x0110C158: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C15C: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C160: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110C164: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110C168: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C16C: MOV x27, x0                | X27 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C170: CMP x28, x20               | STATE = COMPARE(0x3000000000339FF, val_52)
            // 0x0110C174: ADD x9, x8, #0x109         | X9 = (null + 265) = 1152921504608284937 (0x100000000015F109);
            // 0x0110C178: LDRH w9, [x9]              | W9 = System.String.__il2cppRuntimeField_109;
            // 0x0110C17C: AND w9, w9, #0x100         | W9 = (System.String.__il2cppRuntimeField_109 & 256);
            // 0x0110C180: AND w9, w9, #0xffff        | W9 = ((System.String.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x0110C184: B.EQ #0x110c2a8            | if (211455 == val_52) goto label_126;   
            if(211455 == val_52)
            {
                goto label_126;
            }
            // 0x0110C188: CBZ w9, #0x110c19c         | if (((System.String.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_128;
            // 0x0110C18C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C190: CBNZ w9, #0x110c19c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_128;
            // 0x0110C194: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C198: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_128:
            // 0x0110C19C: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x0110C1A0: LDR x8, [x8, #0xc30]       | X8 = (string**)(1152921512833605296)("            {0} @{1} = ({0})__intp.RetriveInt32(ptr_of_this_method, __mStack);");
            // 0x0110C1A4: B #0x110c2c4               |  goto label_129;                        
            goto label_129;
            label_113:
            // 0x0110C1A8: MOV x19, x26               | X19 = 38932 (0x9814);//ML01             
            // 0x0110C1AC: CBNZ x27, #0x110c1b4       | if (0x3000000000339FF != 0) goto label_130;
            if(211455 != 0)
            {
                goto label_130;
            }
            // 0x0110C1B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_130:
            // 0x0110C1B4: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C1B8: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C1BC: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110C1C0: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110C1C4: MOV x26, x0                | X26 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C1C8: CBNZ x27, #0x110c1d0       | if (0x3000000000339FF != 0) goto label_131;
            if(211455 != 0)
            {
                goto label_131;
            }
            // 0x0110C1CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_131:
            // 0x0110C1D0: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C1D4: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C1D8: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C1DC: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C1E0: LDUR x2, [x29, #-0x60]     | X2 = 0x0;                               
            // 0x0110C1E4: MOV x1, x0                 | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C1E8: BL #0x1108f2c              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            string val_55 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            // 0x0110C1EC: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C1F0: MOV x20, x0                | X20 = val_55;//m1                       
            // 0x0110C1F4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C1F8: TBZ w9, #0, #0x110c20c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_133;
            // 0x0110C1FC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C200: CBNZ w9, #0x110c20c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_133;
            // 0x0110C204: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C208: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_133:
            // 0x0110C20C: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x0110C210: LDR x8, [x8, #0x140]       | X8 = (string**)(1152921512833609616)("            {0} @{1} = {2};");
            // 0x0110C214: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C218: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0110C21C: MOV x2, x28                | X2 = 0 (0x0);//ML01                     
            // 0x0110C220: LDR x1, [x8]               | X1 = "            {0} @{1} = {2};";     
            // 0x0110C224: MOV x3, x26                | X3 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C228: MOV x4, x20                | X4 = val_55;//m1                        
            // 0x0110C22C: BL #0x18af46c              | X0 = System.String.Format(format:  0, arg0:  "            {0} @{1} = {2};", arg1:  val_30, arg2:  211455);
            string val_56 = System.String.Format(format:  0, arg0:  "            {0} @{1} = {2};", arg1:  val_30, arg2:  211455);
            // 0x0110C230: MOV x20, x0                | X20 = val_56;//m1                       
            // 0x0110C234: CBNZ x23, #0x110c23c       | if ( != 0) goto label_134;              
            if(null != 0)
            {
                goto label_134;
            }
            // 0x0110C238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_56, ????);     
            label_134:
            // 0x0110C23C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C240: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C244: MOV x1, x20                | X1 = val_56;//m1                        
            // 0x0110C248: BL #0x1b5c068              | X0 = AppendLine(value:  val_56);        
            System.Text.StringBuilder val_57 = AppendLine(value:  val_56);
            // 0x0110C24C: MOV x26, x19               | X26 = 38932 (0x9814);//ML01             
            label_118:
            // 0x0110C250: LDR w8, [sp, #0x54]        | W8 = val_21;                            
            // 0x0110C254: AND w8, w8, #1             | W8 = (val_21 & 1);                      
            bool val_58 = val_21;
            // 0x0110C258: TBNZ w8, #0, #0x110c648    | if ((val_21 & 1) == true) goto label_144;
            if(val_58 == true)
            {
                goto label_144;
            }
            // 0x0110C25C: CBNZ x27, #0x110c264       | if (0x3000000000339FF != 0) goto label_136;
            if(211455 != 0)
            {
                goto label_136;
            }
            // 0x0110C260: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_57, ????);     
            label_136:
            // 0x0110C264: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C268: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C26C: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C270: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C274: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C278: CBNZ x20, #0x110c280       | if (0x3000000000339FF != 0) goto label_137;
            if(211455 != 0)
            {
                goto label_137;
            }
            // 0x0110C27C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_137:
            // 0x0110C280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C284: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C288: BL #0x1b6d41c              | X0 = 211455.get_IsPrimitive();          
            bool val_59 = 211455.IsPrimitive;
            // 0x0110C28C: AND w8, w0, #1             | W8 = (val_59 & 1);                      
            bool val_60 = val_59;
            // 0x0110C290: TBNZ w8, #0, #0x110c648    | if ((val_59 & 1) == true) goto label_144;
            if(val_60 == true)
            {
                goto label_144;
            }
            // 0x0110C294: CBNZ x23, #0x110c29c       | if ( != 0) goto label_139;              
            if(null != 0)
            {
                goto label_139;
            }
            // 0x0110C298: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_59, ????);     
            label_139:
            // 0x0110C29C: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110C2A0: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921512833617936)("            __intp.Free(ptr_of_this_method);");
            // 0x0110C2A4: B #0x110c638               |  goto label_140;                        
            goto label_140;
            label_126:
            // 0x0110C2A8: CBZ w9, #0x110c2bc         | if (((System.String.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_142;
            // 0x0110C2AC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C2B0: CBNZ w9, #0x110c2bc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_142;
            // 0x0110C2B4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C2B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_142:
            // 0x0110C2BC: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x0110C2C0: LDR x8, [x8, #0xa38]       | X8 = (string**)(1152921512833618096)("            {0} @{1} = __intp.RetriveInt32(ptr_of_this_method, __mStack);");
            label_129:
            // 0x0110C2C4: LDR x1, [x8]               | X1 = "            {0} @{1} = __intp.RetriveInt32(ptr_of_this_method, __mStack);";
            // 0x0110C2C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C2CC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110C2D0: MOV x2, x26                | X2 = 0 (0x0);//ML01                     
            // 0x0110C2D4: MOV x3, x27                | X3 = 216172782113995263 (0x3000000000339FF);//ML01
            label_122:
            // 0x0110C2D8: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "            {0} @{1} = __intp.RetriveInt32(ptr_of_this_method, __mStack);", arg1:  val_30);
            string val_61 = System.String.Format(format:  0, arg0:  "            {0} @{1} = __intp.RetriveInt32(ptr_of_this_method, __mStack);", arg1:  val_30);
            // 0x0110C2DC: MOV x20, x0                | X20 = val_61;//m1                       
            // 0x0110C2E0: CBNZ x23, #0x110c2e8       | if ( != 0) goto label_143;              
            if(null != 0)
            {
                goto label_143;
            }
            // 0x0110C2E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_61, ????);     
            label_143:
            // 0x0110C2E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C2EC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C2F0: MOV x1, x20                | X1 = val_61;//m1                        
            // 0x0110C2F4: BL #0x1b5c068              | X0 = AppendLine(value:  val_61);        
            System.Text.StringBuilder val_62 = AppendLine(value:  val_61);
            // 0x0110C2F8: MOV x26, x19               | X26 = 38932 (0x9814);//ML01             
            // 0x0110C2FC: B #0x110c648               |  goto label_144;                        
            goto label_144;
            label_64:
            // 0x0110C300: MOV w19, w20               | W19 = 4611686018427426836 (0x4000000000009814);//ML01
            // 0x0110C304: CBNZ x27, #0x110c30c       | if (0x3000000000339FF != 0) goto label_145;
            if(211455 != 0)
            {
                goto label_145;
            }
            // 0x0110C308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_145:
            // 0x0110C30C: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C310: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C314: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110C318: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110C31C: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C320: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C324: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C328: TBZ w9, #0, #0x110c33c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_147;
            // 0x0110C32C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C330: CBNZ w9, #0x110c33c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_147;
            // 0x0110C334: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C338: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_147:
            // 0x0110C33C: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x0110C340: LDR x8, [x8, #0x4c8]       | X8 = (string**)(1152921512833626512)("            {0} @{1} = new {0}();");
            label_67:
            // 0x0110C344: LDR x1, [x8]               | X1 = "            {0} @{1} = new {0}();";
            // 0x0110C348: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C34C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110C350: MOV x2, x28                | X2 = 0 (0x0);//ML01                     
            // 0x0110C354: MOV x3, x20                | X3 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C358: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "            {0} @{1} = new {0}();", arg1:  val_30);
            string val_63 = System.String.Format(format:  0, arg0:  "            {0} @{1} = new {0}();", arg1:  val_30);
            // 0x0110C35C: MOV x20, x0                | X20 = val_63;//m1                       
            // 0x0110C360: CBNZ x23, #0x110c368       | if ( != 0) goto label_148;              
            if(null != 0)
            {
                goto label_148;
            }
            // 0x0110C364: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_63, ????);     
            label_148:
            // 0x0110C368: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C36C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C370: MOV x1, x20                | X1 = val_63;//m1                        
            // 0x0110C374: BL #0x1b5c068              | X0 = AppendLine(value:  val_63);        
            System.Text.StringBuilder val_64 = AppendLine(value:  val_63);
            // 0x0110C378: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x0110C37C: LDUR x20, [x29, #-0x58]    | X20 = 0x0;                              
            // 0x0110C380: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C384: TBZ w8, #0, #0x110c394     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_150;
            // 0x0110C388: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C38C: CBNZ w8, #0x110c394        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_150;
            // 0x0110C390: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_150:
            // 0x0110C394: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x0110C398: LDR x8, [x8, #0x270]       | X8 = (string**)(1152921512833634848)("            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110C39C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C3A0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110C3A4: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110C3A8: LDR x1, [x8]               | X1 = "            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{";
            // 0x0110C3AC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            string val_65 = System.String.Format(format:  0, arg0:  "            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110C3B0: MOV x20, x0                | X20 = val_65;//m1                       
            // 0x0110C3B4: CBNZ x23, #0x110c3bc       | if ( != 0) goto label_151;              
            if(null != 0)
            {
                goto label_151;
            }
            // 0x0110C3B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_65, ????);     
            label_151:
            // 0x0110C3BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C3C0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C3C4: MOV x1, x20                | X1 = val_65;//m1                        
            // 0x0110C3C8: BL #0x1b5c068              | X0 = AppendLine(value:  val_65);        
            System.Text.StringBuilder val_66 = AppendLine(value:  val_65);
            // 0x0110C3CC: LDR w8, [sp, #0x44]        | W8 = 0x0;                               
            // 0x0110C3D0: CBZ w8, #0x110c420         | if (0x0 == 0) goto label_152;           
            if(0 == 0)
            {
                goto label_152;
            }
            // 0x0110C3D4: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110C3D8: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110C3DC: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110C3E0: MOV x28, x26               | X28 = 38932 (0x9814);//ML01             
            // 0x0110C3E4: STR w19, [sp, #0x58]       | stack[1152921512834025784] = 0x4000000000009814;  //  dest_result_addr=1152921512834025784
            // 0x0110C3E8: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110C3EC: BL #0x27bc028              | X0 = 1152921512834297328 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 38932);
            // 0x0110C3F0: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C3F4: LDUR x20, [x29, #-0x58]    | X20 = 0x0;                              
            // 0x0110C3F8: MOV x26, x0                | X26 = 1152921512834297328 (0x10000001EA64EDF0);//ML01
            // 0x0110C3FC: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C400: TBZ w9, #0, #0x110c414     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_154;
            // 0x0110C404: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C408: CBNZ w9, #0x110c414        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_154;
            // 0x0110C40C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C410: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_154:
            // 0x0110C414: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x0110C418: LDR x8, [x8, #0xda0]       | X8 = (string**)(1152921512833647376)("                ILRuntime.Runtime.Generated.CLRBindings.s_{1}_Binder.ParseValue(ref a{0}, __intp, ptr_of_this_method, __mStack, {2});");
            // 0x0110C41C: B #0x110c468               |  goto label_155;                        
            goto label_155;
            label_152:
            // 0x0110C420: MOV x28, x26               | X28 = 38932 (0x9814);//ML01             
            // 0x0110C424: CBNZ x27, #0x110c42c       | if (0x3000000000339FF != 0) goto label_156;
            if(211455 != 0)
            {
                goto label_156;
            }
            // 0x0110C428: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_66, ????);     
            label_156:
            // 0x0110C42C: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C430: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C434: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110C438: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110C43C: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C440: LDUR x20, [x29, #-0x58]    | X20 = 0x0;                              
            // 0x0110C444: MOV x26, x0                | X26 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C448: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C44C: TBZ w9, #0, #0x110c460     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_158;
            // 0x0110C450: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C454: CBNZ w9, #0x110c460        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_158;
            // 0x0110C458: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C45C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_158:
            // 0x0110C460: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x0110C464: LDR x8, [x8, #0xd48]       | X8 = (string**)(1152921512833647712)("                ILRuntime.Runtime.Generated.CLRBindings.s_{1}_Binder.ParseValue(ref @{0}, __intp, ptr_of_this_method, __mStack, {2});");
            label_155:
            // 0x0110C468: LDR x1, [x8]               | X1 = "                ILRuntime.Runtime.Generated.CLRBindings.s_{1}_Binder.ParseValue(ref @{0}, __intp, ptr_of_this_method, __mStack, {2});";
            // 0x0110C46C: LDR x4, [sp, #0x28]        | X4 = val_21 != true ? "false" : "true"; 
            // 0x0110C470: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C474: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0110C478: MOV x2, x26                | X2 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C47C: MOV x3, x20                | X3 = 0 (0x0);//ML01                     
            // 0x0110C480: BL #0x18af46c              | X0 = System.String.Format(format:  0, arg0:  "                ILRuntime.Runtime.Generated.CLRBindings.s_{1}_Binder.ParseValue(ref @{0}, __intp, ptr_of_this_method, __mStack, {2});", arg1:  211455, arg2:  val_29);
            string val_67 = System.String.Format(format:  0, arg0:  "                ILRuntime.Runtime.Generated.CLRBindings.s_{1}_Binder.ParseValue(ref @{0}, __intp, ptr_of_this_method, __mStack, {2});", arg1:  211455, arg2:  val_29);
            // 0x0110C484: MOV x20, x0                | X20 = val_67;//m1                       
            // 0x0110C488: CBNZ x23, #0x110c490       | if ( != 0) goto label_159;              
            if(null != 0)
            {
                goto label_159;
            }
            // 0x0110C48C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_67, ????);     
            label_159:
            // 0x0110C490: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C494: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C498: MOV x1, x20                | X1 = val_67;//m1                        
            // 0x0110C49C: BL #0x1b5c068              | X0 = AppendLine(value:  val_67);        
            System.Text.StringBuilder val_68 = AppendLine(value:  val_67);
            // 0x0110C4A0: CBNZ x23, #0x110c4a8       | if ( != 0) goto label_160;              
            if(null != 0)
            {
                goto label_160;
            }
            // 0x0110C4A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_68, ????);     
            label_160:
            // 0x0110C4A8: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x0110C4AC: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921512833656240)("            } else {");
            // 0x0110C4B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C4B4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C4B8: LDR x1, [x8]               | X1 = "            } else {";            
            // 0x0110C4BC: BL #0x1b5c068              | X0 = AppendLine(value:  "            } else {");
            System.Text.StringBuilder val_69 = AppendLine(value:  "            } else {");
            // 0x0110C4C0: LDURB w8, [x29, #-0x61]    | W8 = 0x0;                               
            // 0x0110C4C4: CBZ w8, #0x110c4e8         | if (0x0 == 0) goto label_161;           
            if(0 == 0)
            {
                goto label_161;
            }
            // 0x0110C4C8: CBNZ x23, #0x110c4d0       | if ( != 0) goto label_162;              
            if(null != 0)
            {
                goto label_162;
            }
            // 0x0110C4CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_69, ????);     
            label_162:
            // 0x0110C4D0: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x0110C4D4: LDR x8, [x8, #0x7c8]       | X8 = (string**)(1152921512833660448)("                ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);");
            // 0x0110C4D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C4DC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C4E0: LDR x1, [x8]               | X1 = "                ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);";
            // 0x0110C4E4: BL #0x1b5c068              | X0 = AppendLine(value:  "                ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);");
            System.Text.StringBuilder val_70 = AppendLine(value:  "                ptr_of_this_method = ILIntepreter.GetObjectAndResolveReference(ptr_of_this_method);");
            label_161:
            // 0x0110C4E8: LDR w8, [sp, #0x44]        | W8 = 0x0;                               
            // 0x0110C4EC: CBZ w8, #0x110c55c         | if (0x0 == 0) goto label_163;           
            if(0 == 0)
            {
                goto label_163;
            }
            // 0x0110C4F0: ADRP x8, #0x3652000        | X8 = 56958976 (0x3652000);              
            // 0x0110C4F4: LDR x8, [x8, #0x140]       | X8 = 1152921504607113216;               
            // 0x0110C4F8: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110C4FC: STR w19, [sp, #0x58]       | stack[1152921512834025784] = 0x4000000000009814;  //  dest_result_addr=1152921512834025784
            // 0x0110C500: LDR x0, [x8]               | X0 = typeof(System.Int32);              
            // 0x0110C504: BL #0x27bc028              | X0 = 1152921512834317808 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 38932);
            // 0x0110C508: MOV x26, x0                | X26 = 1152921512834317808 (0x10000001EA653DF0);//ML01
            // 0x0110C50C: CBNZ x27, #0x110c514       | if (0x3000000000339FF != 0) goto label_164;
            if(211455 != 0)
            {
                goto label_164;
            }
            // 0x0110C510: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 38932, ????);      
            label_164:
            // 0x0110C514: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C518: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C51C: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C520: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C524: LDUR x2, [x29, #-0x60]     | X2 = 0x0;                               
            // 0x0110C528: MOV x1, x0                 | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C52C: BL #0x1108f2c              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            string val_71 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            // 0x0110C530: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C534: MOV x20, x0                | X20 = val_71;//m1                       
            // 0x0110C538: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C53C: TBZ w9, #0, #0x110c550     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_166;
            // 0x0110C540: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C544: CBNZ w9, #0x110c550        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_166;
            // 0x0110C548: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C54C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_166:
            // 0x0110C550: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x0110C554: LDR x8, [x8, #0x700]       | X8 = (string**)(1152921512833673008)("                a{0} = {1};");
            // 0x0110C558: B #0x110c5c4               |  goto label_167;                        
            goto label_167;
            label_163:
            // 0x0110C55C: CBNZ x27, #0x110c564       | if (0x3000000000339FF != 0) goto label_168;
            if(211455 != 0)
            {
                goto label_168;
            }
            // 0x0110C560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_70, ????);     
            label_168:
            // 0x0110C564: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C568: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C56C: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110C570: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110C574: MOV x26, x0                | X26 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C578: CBNZ x27, #0x110c580       | if (0x3000000000339FF != 0) goto label_169;
            if(211455 != 0)
            {
                goto label_169;
            }
            // 0x0110C57C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_169:
            // 0x0110C580: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110C584: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C588: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C58C: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C590: LDUR x2, [x29, #-0x60]     | X2 = 0x0;                               
            // 0x0110C594: MOV x1, x0                 | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C598: BL #0x1108f2c              | X0 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            string val_72 = ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRetrieveValueCode(type:  211455, realClsName:  211455);
            // 0x0110C59C: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110C5A0: MOV x20, x0                | X20 = val_72;//m1                       
            // 0x0110C5A4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C5A8: TBZ w9, #0, #0x110c5bc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_171;
            // 0x0110C5AC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C5B0: CBNZ w9, #0x110c5bc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_171;
            // 0x0110C5B4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110C5B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_171:
            // 0x0110C5BC: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0110C5C0: LDR x8, [x8, #0x120]       | X8 = (string**)(1152921512833677232)("                @{0} = {1};");
            label_167:
            // 0x0110C5C4: LDR x1, [x8]               | X1 = "                @{0} = {1};";     
            // 0x0110C5C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C5CC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110C5D0: MOV x2, x26                | X2 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C5D4: MOV x3, x20                | X3 = val_72;//m1                        
            // 0x0110C5D8: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "                @{0} = {1};", arg1:  211455);
            string val_73 = System.String.Format(format:  0, arg0:  "                @{0} = {1};", arg1:  211455);
            // 0x0110C5DC: MOV x20, x0                | X20 = val_73;//m1                       
            // 0x0110C5E0: CBNZ x23, #0x110c5e8       | if ( != 0) goto label_172;              
            if(null != 0)
            {
                goto label_172;
            }
            // 0x0110C5E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_73, ????);     
            label_172:
            // 0x0110C5E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C5EC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C5F0: MOV x1, x20                | X1 = val_73;//m1                        
            // 0x0110C5F4: BL #0x1b5c068              | X0 = AppendLine(value:  val_73);        
            System.Text.StringBuilder val_74 = AppendLine(value:  val_73);
            // 0x0110C5F8: LDR w8, [sp, #0x54]        | W8 = val_21;                            
            // 0x0110C5FC: MOV x26, x28               | X26 = 38932 (0x9814);//ML01             
            // 0x0110C600: AND w8, w8, #1             | W8 = (val_21 & 1);                      
            bool val_75 = val_21;
            // 0x0110C604: TBNZ w8, #0, #0x110c628    | if ((val_21 & 1) == true) goto label_173;
            if(val_75 == true)
            {
                goto label_173;
            }
            // 0x0110C608: CBNZ x23, #0x110c610       | if ( != 0) goto label_174;              
            if(null != 0)
            {
                goto label_174;
            }
            // 0x0110C60C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_74, ????);     
            label_174:
            // 0x0110C610: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x0110C614: LDR x8, [x8, #0x858]       | X8 = (string**)(1152921512833685552)("                __intp.Free(ptr_of_this_method);");
            // 0x0110C618: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C61C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C620: LDR x1, [x8]               | X1 = "                __intp.Free(ptr_of_this_method);";
            // 0x0110C624: BL #0x1b5c068              | X0 = AppendLine(value:  "                __intp.Free(ptr_of_this_method);");
            System.Text.StringBuilder val_76 = AppendLine(value:  "                __intp.Free(ptr_of_this_method);");
            label_173:
            // 0x0110C628: CBNZ x23, #0x110c630       | if ( != 0) goto label_175;              
            if(null != 0)
            {
                goto label_175;
            }
            // 0x0110C62C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_76, ????);     
            label_175:
            // 0x0110C630: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x0110C634: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921512833689824)("            }");
            label_140:
            // 0x0110C638: LDR x1, [x8]               | X1 = "            }";                   
            // 0x0110C63C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C640: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C644: BL #0x1b5c068              | X0 = AppendLine(value:  "            }");
            System.Text.StringBuilder val_77 = AppendLine(value:  "            }");
            label_144:
            // 0x0110C648: SUB x26, x26, #1           | X26 = (38932 - 1) = 38931 (0x00009813); 
            // 0x0110C64C: CBNZ x23, #0x110c654       | if ( != 0) goto label_176;              
            if(null != 0)
            {
                goto label_176;
            }
            // 0x0110C650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_77, ????);     
            label_176:
            // 0x0110C654: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C658: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C65C: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_78 = AppendLine();
            // 0x0110C660: ADD x8, x26, #1            | X8 = (38931 + 1) = 38932 (0x00009814);  
            // 0x0110C664: SUB w22, w22, #1           | W22 = (4611686018427426835 - 1) = 4611686018427426834 (0x4000000000009812);
            // 0x0110C668: ADD w21, w21, #1           | W21 = (-4611686018427426835 + 1) = val_185 (0xBFFFFFFFFFFF67EE);
            val_185 = -4611686018427426834;
            // 0x0110C66C: CMP x8, #1                 | STATE = COMPARE(0x9814, 0x1)            
            // 0x0110C670: B.GT #0x110ba1c            | if (38932 > 0x1) goto label_177;        
            if(38932 > 1)
            {
                goto label_177;
            }
            label_28:
            // 0x0110C674: CBZ x23, #0x110c688        | if ( == 0) goto label_178;              
            if(null == 0)
            {
                goto label_178;
            }
            // 0x0110C678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C67C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C680: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_79 = AppendLine();
            // 0x0110C684: B #0x110c69c               |  goto label_179;                        
            goto label_179;
            label_178:
            // 0x0110C688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_78, ????);     
            // 0x0110C68C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C690: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C694: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_80 = AppendLine();
            // 0x0110C698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_80, ????);     
            label_179:
            // 0x0110C69C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x0110C6A0: LDR x8, [x8, #0x890]       | X8 = (string**)(1152921512833706304)("            var result_of_this_method = ");
            // 0x0110C6A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C6A8: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C6AC: LDR x1, [x8]               | X1 = "            var result_of_this_method = ";
            // 0x0110C6B0: BL #0x1b5b818              | X0 = Append(value:  "            var result_of_this_method = ");
            System.Text.StringBuilder val_81 = Append(value:  "            var result_of_this_method = ");
            // 0x0110C6B4: LDR w8, [sp, #0x44]        | W8 = 0x0;                               
            // 0x0110C6B8: CBZ w8, #0x110c76c         | if (0x0 == 0) goto label_180;           
            if(0 == 0)
            {
                goto label_180;
            }
            // 0x0110C6BC: LDR x0, [sp, #0x30]        | X0 = methods;                           
            // 0x0110C6C0: CBNZ x0, #0x110c6d0        | if (methods != 0) goto label_181;       
            if(val_187 != 0)
            {
                goto label_181;
            }
            // 0x0110C6C4: MOV x19, x0                | X19 = methods;//m1                      
            // 0x0110C6C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? methods, ????);    
            // 0x0110C6CC: MOV x0, x19                | X0 = methods;//m1                       
            label_181:
            // 0x0110C6D0: LDR x8, [x0]               | X8 = methods;                           
            // 0x0110C6D4: STR x0, [sp, #0x30]        | stack[1152921512834025744] = methods;    //  dest_result_addr=1152921512834025744
            // 0x0110C6D8: LDR x9, [x8, #0x410]       | X9 = methods + 1040;                    
            // 0x0110C6DC: LDR x1, [x8, #0x418]       | X1 = methods + 1048;                    
            // 0x0110C6E0: BLR x9                     | X0 = methods + 1040();                  
            // 0x0110C6E4: MOV x1, x0                 | X1 = methods;//m1                       
            string val_82 = val_187;
            // 0x0110C6E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C6EC: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110C6F0: SUB x2, x29, #0x70         | X2 = (1152921512834025984 - 112) = 1152921512834025872 (0x10000001EA60C990);
            // 0x0110C6F4: SUB x3, x29, #0x78         | X3 = (1152921512834025984 - 120) = 1152921512834025864 (0x10000001EA60C988);
            // 0x0110C6F8: SUB x4, x29, #0x79         | X4 = (1152921512834025984 - 121) = 1152921512834025863 (0x10000001EA60C987);
            // 0x0110C6FC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110C700: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  string val_82 = val_187, realClsName: out  string val_83 = 0, isByRef: out  bool val_84 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_82, realClsName: out  val_83, isByRef: out  val_84, simpleClassName:  true);
            // 0x0110C704: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x0110C708: LDUR x20, [x29, #-0x78]    | X20 = 0x0;                              
            // 0x0110C70C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C710: TBZ w8, #0, #0x110c720     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_183;
            // 0x0110C714: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C718: CBNZ w8, #0x110c720        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_183;
            // 0x0110C71C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_183:
            // 0x0110C720: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x0110C724: LDR x8, [x8, #0x660]       | X8 = (string**)(1152921512833710560)("new {0}[");
            // 0x0110C728: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C72C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110C730: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110C734: LDR x1, [x8]               | X1 = "new {0}[";                        
            // 0x0110C738: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "new {0}[");
            string val_85 = System.String.Format(format:  0, arg0:  "new {0}[");
            // 0x0110C73C: MOV x20, x0                | X20 = val_85;//m1                       
            // 0x0110C740: CBZ x23, #0x110c7f4        | if ( == 0) goto label_184;              
            if(null == 0)
            {
                goto label_184;
            }
            // 0x0110C744: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C748: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C74C: MOV x1, x20                | X1 = val_85;//m1                        
            // 0x0110C750: BL #0x1b5b818              | X0 = Append(value:  val_85);            
            System.Text.StringBuilder val_86 = Append(value:  val_85);
            // 0x0110C754: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0110C758: ORR w3, wzr, #1            | W3 = 1(0x1);                            
            // 0x0110C75C: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x0110C760: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C764: BL #0x1108cf0              | ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  System.Text.StringBuilder val_86 = Append(value:  val_85), sb:  1, isMultiArr:  false, skipLast:  1);
            ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  val_86, sb:  1, isMultiArr:  false, skipLast:  1);
            // 0x0110C768: B #0x110c820               |  goto label_185;                        
            goto label_185;
            label_180:
            // 0x0110C76C: LDR x1, [sp, #0x30]        | X1 = methods;                           
            System.Reflection.ConstructorInfo[] val_87 = val_187;
            // 0x0110C770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C774: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110C778: SUB x2, x29, #0x70         | X2 = (1152921512834025984 - 112) = 1152921512834025872 (0x10000001EA60C990);
            // 0x0110C77C: SUB x3, x29, #0x78         | X3 = (1152921512834025984 - 120) = 1152921512834025864 (0x10000001EA60C988);
            // 0x0110C780: SUB x4, x29, #0x79         | X4 = (1152921512834025984 - 121) = 1152921512834025863 (0x10000001EA60C987);
            // 0x0110C784: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110C788: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  System.Reflection.ConstructorInfo[] val_87 = val_187, realClsName: out  val_83, isByRef: out  val_84, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_87, realClsName: out  val_83, isByRef: out  val_84, simpleClassName:  true);
            // 0x0110C78C: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x0110C790: LDUR x20, [x29, #-0x78]    | X20 = 0x0;                              
            // 0x0110C794: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110C798: TBZ w8, #0, #0x110c7a8     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_187;
            // 0x0110C79C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110C7A0: CBNZ w8, #0x110c7a8        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_187;
            // 0x0110C7A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_187:
            // 0x0110C7A8: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0110C7AC: LDR x8, [x8, #0xdb8]       | X8 = (string**)(1152921512833718848)("new {0}(");
            // 0x0110C7B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110C7B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110C7B8: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110C7BC: LDR x1, [x8]               | X1 = "new {0}(";                        
            // 0x0110C7C0: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "new {0}(");
            string val_88 = System.String.Format(format:  0, arg0:  "new {0}(");
            // 0x0110C7C4: MOV x20, x0                | X20 = val_88;//m1                       
            // 0x0110C7C8: CBZ x23, #0x110c82c        | if ( == 0) goto label_188;              
            if(null == 0)
            {
                goto label_188;
            }
            // 0x0110C7CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C7D0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C7D4: MOV x1, x20                | X1 = val_88;//m1                        
            // 0x0110C7D8: BL #0x1b5b818              | X0 = Append(value:  val_88);            
            System.Text.StringBuilder val_89 = Append(value:  val_88);
            // 0x0110C7DC: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x0110C7E0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0110C7E4: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x0110C7E8: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C7EC: BL #0x1108cf0              | ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  System.Text.StringBuilder val_89 = Append(value:  val_88), sb:  1, isMultiArr:  false, skipLast:  0);
            ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  val_89, sb:  1, isMultiArr:  false, skipLast:  0);
            // 0x0110C7F0: B #0x110c858               |  goto label_189;                        
            goto label_189;
            label_184:
            // 0x0110C7F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_85, ????);     
            // 0x0110C7F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C7FC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C800: MOV x1, x20                | X1 = val_85;//m1                        
            // 0x0110C804: BL #0x1b5b818              | X0 = Append(value:  val_85);            
            System.Text.StringBuilder val_90 = Append(value:  val_85);
            // 0x0110C808: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0110C80C: ORR w3, wzr, #1            | W3 = 1(0x1);                            
            // 0x0110C810: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x0110C814: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C818: BL #0x1108cf0              | ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  System.Text.StringBuilder val_90 = Append(value:  val_85), sb:  1, isMultiArr:  false, skipLast:  1);
            ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  val_90, sb:  1, isMultiArr:  false, skipLast:  1);
            // 0x0110C81C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_90, ????);     
            label_185:
            // 0x0110C820: ADRP x8, #0x35f3000        | X8 = 56569856 (0x35F3000);              
            // 0x0110C824: LDR x8, [x8, #0xbb8]       | X8 = (string**)(1152921512833731232)("];");
            // 0x0110C828: B #0x110c860               |  goto label_190;                        
            goto label_190;
            label_188:
            // 0x0110C82C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_88, ????);     
            // 0x0110C830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C834: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C838: MOV x1, x20                | X1 = val_88;//m1                        
            // 0x0110C83C: BL #0x1b5b818              | X0 = Append(value:  val_88);            
            System.Text.StringBuilder val_91 = Append(value:  val_88);
            // 0x0110C840: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x0110C844: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0110C848: MOV x1, x24                | X1 = 1 (0x1);//ML01                     
            // 0x0110C84C: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C850: BL #0x1108cf0              | ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  System.Text.StringBuilder val_91 = Append(value:  val_88), sb:  1, isMultiArr:  false, skipLast:  0);
            ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.AppendParameters(param:  val_91, sb:  1, isMultiArr:  false, skipLast:  0);
            // 0x0110C854: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_91, ????);     
            label_189:
            // 0x0110C858: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0110C85C: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921512833735408)(");");
            label_190:
            // 0x0110C860: LDR x1, [x8]               | X1 = ");";                              
            // 0x0110C864: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C868: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C86C: BL #0x1b5c068              | X0 = AppendLine(value:  ");");          
            System.Text.StringBuilder val_92 = AppendLine(value:  ");");
            // 0x0110C870: CBNZ x23, #0x110c878       | if ( != 0) goto label_191;              
            if(null != 0)
            {
                goto label_191;
            }
            // 0x0110C874: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_92, ????);     
            label_191:
            // 0x0110C878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C87C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C880: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_93 = AppendLine();
            // 0x0110C884: CBNZ x24, #0x110c88c       | if (0x1 != 0) goto label_192;           
            if(1 != 0)
            {
                goto label_192;
            }
            // 0x0110C888: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
            label_192:
            // 0x0110C88C: LDR x8, [x24, #0x18]       | X8 = 0x4000000000009814;                
            // 0x0110C890: CMP w8, #1                 | STATE = COMPARE(0x4000000000009814, 0x1)
            // 0x0110C894: B.LT #0x110cfd4            | if (38932 < 0x1) goto label_193;        
            if(38932 < 1)
            {
                goto label_193;
            }
            // 0x0110C898: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x0110C89C: SXTW x19, w8               | X19 = 38932 (0x00009814);               
            // 0x0110C8A0: SUB w21, w9, w8            | W21 = (1 - 38932) = -4611686018427426835 (0xBFFFFFFFFFFF67ED);
            // 0x0110C8A4: SUB w22, w8, #1            | W22 = (38932 - 1) = 4611686018427426835 (0x4000000000009813);
            var val_187 = 4611686018427426835;
            // 0x0110C8A8: B #0x110c954               |  goto label_251;                        
            goto label_251;
            label_228:
            // 0x0110C8AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
            // 0x0110C8B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C8B4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C8B8: MOV x1, x20                | X1 = val_88;//m1                        
            // 0x0110C8BC: BL #0x1b5c068              | X0 = AppendLine(value:  val_88);        
            System.Text.StringBuilder val_94 = AppendLine(value:  val_88);
            // 0x0110C8C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_94, ????);     
            label_229:
            // 0x0110C8C4: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0110C8C8: LDR x8, [x8, #0x880]       | X8 = (string**)(1152921512833747776)("                } else {");
            // 0x0110C8CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C8D0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C8D4: LDR x1, [x8]               | X1 = "                } else {";        
            // 0x0110C8D8: BL #0x1b5c068              | X0 = AppendLine(value:  "                } else {");
            System.Text.StringBuilder val_95 = AppendLine(value:  "                } else {");
            // 0x0110C8DC: LDR x8, [x26]              | X8 = 0x62696C005F5F646E;                
            // 0x0110C8E0: MOV x0, x26                | X0 = 38931 (0x9813);//ML01              
            // 0x0110C8E4: LDP x9, x1, [x8, #0x170]   | X9 = mem[7091317837127443934]; X1 = mem[7091317837127443942]; //  | 
            // 0x0110C8E8: BLR x9                     | X0 = mem[7091317837127443934]();        
            // 0x0110C8EC: MOV x20, x0                | X20 = 38931 (0x9813);//ML01             
            // 0x0110C8F0: CBNZ x20, #0x110c8f8       | if (0x9813 != 0) goto label_195;        
            if(38931 != 0)
            {
                goto label_195;
            }
            // 0x0110C8F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9813, ????);     
            label_195:
            // 0x0110C8F8: LDR x8, [x20]              | X8 = 0x62696C005F5F646E;                
            // 0x0110C8FC: MOV x0, x20                | X0 = 38931 (0x9813);//ML01              
            // 0x0110C900: LDR x9, [x8, #0x410]       | X9 = mem[7091317837127444606];          
            // 0x0110C904: LDR x1, [x8, #0x418]       | X1 = mem[7091317837127444614];          
            // 0x0110C908: BLR x9                     | X0 = mem[7091317837127444606]();        
            // 0x0110C90C: LDR x8, [x26]              | X8 = 0x62696C005F5F646E;                
            // 0x0110C910: MOV x20, x0                | X20 = 38931 (0x9813);//ML01             
            // 0x0110C914: MOV x0, x26                | X0 = 38931 (0x9813);//ML01              
            // 0x0110C918: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[7091317837127443982]; X1 = mem[7091317837127443990]; //  | 
            // 0x0110C91C: BLR x9                     | X0 = mem[7091317837127443982]();        
            // 0x0110C920: MOV x1, x20                | X1 = 38931 (0x9813);//ML01              
            // 0x0110C924: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C928: MOV x3, x0                 | X3 = 38931 (0x9813);//ML01              
            // 0x0110C92C: BL #0x11093ac              | ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRefWriteBackValueCode(type:  38931, sb:  38931, paramName:  val_1);
            ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRefWriteBackValueCode(type:  38931, sb:  38931, paramName:  val_1);
            // 0x0110C930: CBNZ x23, #0x110c938       | if ( != 0) goto label_196;              
            if(null != 0)
            {
                goto label_196;
            }
            // 0x0110C934: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x9813, ????);     
            label_196:
            // 0x0110C938: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x0110C93C: LDR x8, [x8, #0x480]       | X8 = (string**)(1152921512833752000)("                }");
            // 0x0110C940: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110C944: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110C948: LDR x1, [x8]               | X1 = "                }";               
            // 0x0110C94C: BL #0x1b5c068              | X0 = AppendLine(value:  "                }");
            System.Text.StringBuilder val_96 = AppendLine(value:  "                }");
            // 0x0110C950: B #0x110cd28               |  goto label_197;                        
            goto label_197;
            label_251:
            // 0x0110C954: CBNZ x24, #0x110c95c       | if (0x1 != 0) goto label_198;           
            if(1 != 0)
            {
                goto label_198;
            }
            // 0x0110C958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
            label_198:
            // 0x0110C95C: LDR w8, [x24, #0x18]       | W8 = 0x9814;                            
            // 0x0110C960: CMP w22, w8                | STATE = COMPARE(0x4000000000009813, 0x9814)
            // 0x0110C964: B.LO #0x110c974            | if (4611686018427426835 < 38932) goto label_199;
            if(val_187 < 38932)
            {
                goto label_199;
            }
            // 0x0110C968: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_93, ????);     
            // 0x0110C96C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C970: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_93, ????);     
            label_199:
            // 0x0110C974: ADD x8, x24, x19, lsl #3   | X8 = (1 + 311456) = 311457 (0x0004C0A1);
            // 0x0110C978: LDR x26, [x8, #0x18]       | X26 = 0x3000000000339FF;                
            // 0x0110C97C: CBNZ x26, #0x110c984       | if (0x3000000000339FF != 0) goto label_200;
            if(211455 != 0)
            {
                goto label_200;
            }
            // 0x0110C980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_93, ????);     
            label_200:
            // 0x0110C984: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110C988: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C98C: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C990: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C994: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C998: CBNZ x20, #0x110c9a0       | if (0x3000000000339FF != 0) goto label_201;
            if(211455 != 0)
            {
                goto label_201;
            }
            // 0x0110C99C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_201:
            // 0x0110C9A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C9A4: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C9A8: SUB x19, x19, #1           | X19 = (38932 - 1) = 38931 (0x00009813); 
            // 0x0110C9AC: BL #0x1b6d1dc              | X0 = 211455.get_IsByRef();              
            bool val_97 = 211455.IsByRef;
            // 0x0110C9B0: LDR w8, [sp, #0x54]        | W8 = val_21;                            
            bool val_186 = val_21;
            // 0x0110C9B4: ORR w8, w8, w0             | W8 = (val_21 | val_97);                 
            val_186 = val_186 | val_97;
            // 0x0110C9B8: AND w8, w8, #1             | W8 = ((val_21 | val_97) & 1);           
            bool val_98 = val_186;
            // 0x0110C9BC: TBZ w8, #0, #0x110cfc0     | if (((val_21 | val_97) & 1) == false) goto label_202;
            if(val_98 == false)
            {
                goto label_202;
            }
            // 0x0110C9C0: CBNZ x26, #0x110c9c8       | if (0x3000000000339FF != 0) goto label_203;
            if(211455 != 0)
            {
                goto label_203;
            }
            // 0x0110C9C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_97, ????);     
            label_203:
            // 0x0110C9C8: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110C9CC: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C9D0: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110C9D4: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110C9D8: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C9DC: CBNZ x20, #0x110c9e4       | if (0x3000000000339FF != 0) goto label_204;
            if(211455 != 0)
            {
                goto label_204;
            }
            // 0x0110C9E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_204:
            // 0x0110C9E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110C9E8: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C9EC: BL #0x1b6d1dc              | X0 = 211455.get_IsByRef();              
            bool val_99 = 211455.IsByRef;
            // 0x0110C9F0: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110C9F4: MOV w20, w0                | W20 = val_99;//m1                       
            // 0x0110C9F8: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110C9FC: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110CA00: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110CA04: MOV x27, x0                | X27 = 216172782113995263 (0x3000000000339FF);//ML01
            val_188 = 211455;
            // 0x0110CA08: TBZ w20, #0, #0x110ca2c    | if (val_99 == false) goto label_205;    
            if(val_99 == false)
            {
                goto label_205;
            }
            // 0x0110CA0C: CBNZ x27, #0x110ca14       | if (0x3000000000339FF != 0) goto label_206;
            if(val_188 != 0)
            {
                goto label_206;
            }
            // 0x0110CA10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_206:
            // 0x0110CA14: LDR x8, [x27]              | X8 = mem[216172782113995263];           
            // 0x0110CA18: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CA1C: LDR x9, [x8, #0x410]       | X9 = mem[216172782113995263] + 1040;    
            // 0x0110CA20: LDR x1, [x8, #0x418]       | X1 = mem[216172782113995263] + 1048;    
            // 0x0110CA24: BLR x9                     | X0 = mem[216172782113995263] + 1040();  
            // 0x0110CA28: MOV x27, x0                | X27 = 216172782113995263 (0x3000000000339FF);//ML01
            val_188 = val_188;
            label_205:
            // 0x0110CA2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110CA30: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110CA34: SUB x2, x29, #0x88         | X2 = (1152921512834025984 - 136) = 1152921512834025848 (0x10000001EA60C978);
            // 0x0110CA38: ADD x3, sp, #0x90          | X3 = (1152921512834025696 + 144) = 1152921512834025840 (0x10000001EA60C970);
            // 0x0110CA3C: ADD x4, sp, #0x8f          | X4 = (1152921512834025696 + 143) = 1152921512834025839 (0x10000001EA60C96F);
            // 0x0110CA40: MOV x1, x27                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            string val_100 = val_188;
            // 0x0110CA44: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110CA48: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  string val_100 = val_188, realClsName: out  string val_101 = 0, isByRef: out  bool val_102 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_100, realClsName: out  val_101, isByRef: out  val_102, simpleClassName:  true);
            // 0x0110CA4C: CBNZ x24, #0x110ca54       | if (0x1 != 0) goto label_207;           
            if(1 != 0)
            {
                goto label_207;
            }
            // 0x0110CA50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_207:
            // 0x0110CA54: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x0110CA58: LDR w8, [x24, #0x18]       | W8 = 0x9814;                            
            // 0x0110CA5C: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x0110CA60: ADD x1, sp, #0x58          | X1 = (1152921512834025696 + 88) = 1152921512834025784 (0x10000001EA60C938);
            // 0x0110CA64: ADD w8, w21, w8            | W8 = (-4611686018427426835 + 38932) = -4611686018427387903 (0xC000000000000001);
            // 0x0110CA68: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x0110CA6C: STR w8, [sp, #0x58]        | stack[1152921512834025784] = 0xC000000000000001;  //  dest_result_addr=1152921512834025784
            // 0x0110CA70: BL #0x27bc028              | X0 = 1152921512834407920 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), 1);
            // 0x0110CA74: LDR x8, [x25]              | X8 = typeof(System.String);             
            // 0x0110CA78: MOV x20, x0                | X20 = 1152921512834407920 (0x10000001EA669DF0);//ML01
            // 0x0110CA7C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x0110CA80: TBZ w9, #0, #0x110ca94     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_209;
            // 0x0110CA84: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110CA88: CBNZ w9, #0x110ca94        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_209;
            // 0x0110CA8C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x0110CA90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_209:
            // 0x0110CA94: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x0110CA98: LDR x8, [x8, #0x6e0]       | X8 = (string**)(1152921512833522384)("            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});");
            // 0x0110CA9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110CAA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110CAA4: MOV x2, x20                | X2 = 1152921512834407920 (0x10000001EA669DF0);//ML01
            // 0x0110CAA8: LDR x1, [x8]               | X1 = "            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});";
            // 0x0110CAAC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});");
            string val_103 = System.String.Format(format:  0, arg0:  "            ptr_of_this_method = ILIntepreter.Minus(__esp, {0});");
            // 0x0110CAB0: MOV x20, x0                | X20 = val_103;//m1                      
            // 0x0110CAB4: CBNZ x23, #0x110cabc       | if ( != 0) goto label_210;              
            if(null != 0)
            {
                goto label_210;
            }
            // 0x0110CAB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_103, ????);    
            label_210:
            // 0x0110CABC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CAC0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CAC4: MOV x1, x20                | X1 = val_103;//m1                       
            // 0x0110CAC8: BL #0x1b5c068              | X0 = AppendLine(value:  val_103);       
            System.Text.StringBuilder val_104 = AppendLine(value:  val_103);
            // 0x0110CACC: CBNZ x26, #0x110cad4       | if (0x3000000000339FF != 0) goto label_211;
            if(211455 != 0)
            {
                goto label_211;
            }
            // 0x0110CAD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_104, ????);    
            label_211:
            // 0x0110CAD4: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CAD8: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CADC: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110CAE0: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110CAE4: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CAE8: CBNZ x20, #0x110caf0       | if (0x3000000000339FF != 0) goto label_212;
            if(211455 != 0)
            {
                goto label_212;
            }
            // 0x0110CAEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_212:
            // 0x0110CAF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110CAF4: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CAF8: BL #0x1b6d1dc              | X0 = 211455.get_IsByRef();              
            bool val_105 = 211455.IsByRef;
            // 0x0110CAFC: TBZ w0, #0, #0x110cc74     | if (val_105 == false) goto label_213;   
            if(val_105 == false)
            {
                goto label_213;
            }
            // 0x0110CB00: CBNZ x23, #0x110cb08       | if ( != 0) goto label_214;              
            if(null != 0)
            {
                goto label_214;
            }
            // 0x0110CB04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_105, ????);    
            label_214:
            // 0x0110CB08: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x0110CB0C: LDR x8, [x8, #0x830]       | X8 = (string**)(1152921512833768496)("            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.StackObjectReference:\n                    {\n                        var ___dst = ILIntepreter.ResolveReference(ptr_of_this_method);");
            // 0x0110CB10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CB14: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CB18: LDR x1, [x8]               | X1 = "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.StackObjectReference:\n                    {\n                        var ___dst = ILIntepreter.ResolveReference(ptr_of_this_method);";
            // 0x0110CB1C: BL #0x1b5c068              | X0 = AppendLine(value:  "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.StackObjectReference:\n                    {\n                        var ___dst = ILIntepreter.ResolveReference(ptr_of_this_method);");
            System.Text.StringBuilder val_106 = AppendLine(value:  "            switch(ptr_of_this_method->ObjectType)\n            {\n                case ObjectTypes.StackObjectReference:\n                    {\n                        var ___dst = ILIntepreter.ResolveReference(ptr_of_this_method);");
            // 0x0110CB20: CBNZ x26, #0x110cb28       | if (0x3000000000339FF != 0) goto label_215;
            if(211455 != 0)
            {
                goto label_215;
            }
            // 0x0110CB24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_106, ????);    
            label_215:
            // 0x0110CB28: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CB2C: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CB30: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110CB34: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110CB38: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CB3C: CBNZ x20, #0x110cb44       | if (0x3000000000339FF != 0) goto label_216;
            if(211455 != 0)
            {
                goto label_216;
            }
            // 0x0110CB40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_216:
            // 0x0110CB44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_189 = 0;
            // 0x0110CB48: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CB4C: BL #0x1b6d264              | X0 = 211455.get_IsValueType();          
            bool val_107 = 211455.IsValueType;
            // 0x0110CB50: TBZ w0, #0, #0x110cccc     | if (val_107 == false) goto label_223;   
            if(val_107 == false)
            {
                goto label_223;
            }
            // 0x0110CB54: CBNZ x26, #0x110cb5c       | if (0x3000000000339FF != 0) goto label_218;
            if(211455 != 0)
            {
                goto label_218;
            }
            // 0x0110CB58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_107, ????);    
            label_218:
            // 0x0110CB5C: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CB60: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CB64: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110CB68: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110CB6C: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CB70: CBNZ x20, #0x110cb78       | if (0x3000000000339FF != 0) goto label_219;
            if(211455 != 0)
            {
                goto label_219;
            }
            // 0x0110CB74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_219:
            // 0x0110CB78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_189 = 0;
            // 0x0110CB7C: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CB80: BL #0x1b6d41c              | X0 = 211455.get_IsPrimitive();          
            bool val_108 = 211455.IsPrimitive;
            // 0x0110CB84: LDR x8, [sp, #0x48]        | X8 = X5;                                
            // 0x0110CB88: CBZ x8, #0x110cccc         | if (X5 == 0) goto label_223;            
            if(X5 == 0)
            {
                goto label_223;
            }
            // 0x0110CB8C: AND w8, w0, #1             | W8 = (val_108 & 1);                     
            bool val_109 = val_108;
            // 0x0110CB90: TBNZ w8, #0, #0x110cccc    | if ((val_108 & 1) == true) goto label_223;
            if(val_109 == true)
            {
                goto label_223;
            }
            // 0x0110CB94: CBNZ x26, #0x110cb9c       | if (0x3000000000339FF != 0) goto label_222;
            if(211455 != 0)
            {
                goto label_222;
            }
            // 0x0110CB98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_108, ????);    
            label_222:
            // 0x0110CB9C: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CBA0: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CBA4: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110CBA8: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110CBAC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110CBB0: LDR x8, [x8, #0x9e0]       | X8 = 1152921512820334400;               
            // 0x0110CBB4: MOV x1, x0                 | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            val_189 = 211455;
            // 0x0110CBB8: LDR x0, [sp, #0x48]        | X0 = X5;                                
            // 0x0110CBBC: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.Type>::Contains(System.Type item);
            // 0x0110CBC0: BL #0x25ead74              | X0 = X5.Contains(item:  val_189 = 211455);
            bool val_110 = X5.Contains(item:  val_189);
            // 0x0110CBC4: TBZ w0, #0, #0x110cccc     | if (val_110 == false) goto label_223;   
            if(val_110 == false)
            {
                goto label_223;
            }
            // 0x0110CBC8: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x0110CBCC: LDUR x20, [x29, #-0x88]    | X20 = 0x0;                              
            // 0x0110CBD0: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110CBD4: TBZ w8, #0, #0x110cbe4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_225;
            // 0x0110CBD8: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110CBDC: CBNZ w8, #0x110cbe4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_225;
            // 0x0110CBE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_225:
            // 0x0110CBE4: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0110CBE8: LDR x8, [x8, #0x218]       | X8 = (string**)(1152921512833773136)("                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110CBEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110CBF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110CBF4: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110CBF8: LDR x1, [x8]               | X1 = "                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{";
            // 0x0110CBFC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            string val_111 = System.String.Format(format:  0, arg0:  "                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110CC00: MOV x20, x0                | X20 = val_111;//m1                      
            // 0x0110CC04: CBNZ x23, #0x110cc0c       | if ( != 0) goto label_226;              
            if(null != 0)
            {
                goto label_226;
            }
            // 0x0110CC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_111, ????);    
            label_226:
            // 0x0110CC0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CC10: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CC14: MOV x1, x20                | X1 = val_111;//m1                       
            // 0x0110CC18: BL #0x1b5c068              | X0 = AppendLine(value:  val_111);       
            System.Text.StringBuilder val_112 = AppendLine(value:  val_111);
            // 0x0110CC1C: LDR x20, [sp, #0x90]       | X20 = 0x0;                              
            // 0x0110CC20: CBNZ x26, #0x110cc28       | if (0x3000000000339FF != 0) goto label_227;
            if(211455 != 0)
            {
                goto label_227;
            }
            // 0x0110CC24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_112, ????);    
            label_227:
            // 0x0110CC28: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CC2C: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CC30: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CC34: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CC38: ADRP x8, #0x35d4000        | X8 = 56442880 (0x35D4000);              
            // 0x0110CC3C: LDR x8, [x8, #0x828]       | X8 = (string**)(1152921512833781568)("                        ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, ptr_of_this_method, __mStack, ref {1});");
            // 0x0110CC40: MOV x3, x0                 | X3 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CC44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110CC48: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0110CC4C: LDR x1, [x8]               | X1 = "                        ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, ptr_of_this_method, __mStack, ref {1});";
            // 0x0110CC50: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110CC54: BL #0x18af348              | X0 = System.String.Format(format:  0, arg0:  "                        ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, ptr_of_this_method, __mStack, ref {1});", arg1:  val_102);
            string val_113 = System.String.Format(format:  0, arg0:  "                        ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, ptr_of_this_method, __mStack, ref {1});", arg1:  val_102);
            // 0x0110CC58: MOV x20, x0                | X20 = val_113;//m1                      
            // 0x0110CC5C: CBZ x23, #0x110c8ac        | if ( == 0) goto label_228;              
            if(null == 0)
            {
                goto label_228;
            }
            // 0x0110CC60: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CC64: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CC68: MOV x1, x20                | X1 = val_113;//m1                       
            // 0x0110CC6C: BL #0x1b5c068              | X0 = AppendLine(value:  val_113);       
            System.Text.StringBuilder val_114 = AppendLine(value:  val_113);
            // 0x0110CC70: B #0x110c8c4               |  goto label_229;                        
            goto label_229;
            label_213:
            // 0x0110CC74: CBNZ x27, #0x110cc7c       | if (0x3000000000339FF != 0) goto label_230;
            if(val_188 != 0)
            {
                goto label_230;
            }
            // 0x0110CC78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_105, ????);    
            label_230:
            // 0x0110CC7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110CC80: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CC84: BL #0x1b6d264              | X0 = val_188.get_IsValueType();         
            bool val_115 = val_188.IsValueType;
            // 0x0110CC88: TBZ w0, #0, #0x110cfa0     | if (val_115 == false) goto label_235;   
            if(val_115 == false)
            {
                goto label_235;
            }
            // 0x0110CC8C: CBNZ x27, #0x110cc94       | if (0x3000000000339FF != 0) goto label_232;
            if(val_188 != 0)
            {
                goto label_232;
            }
            // 0x0110CC90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_115, ????);    
            label_232:
            // 0x0110CC94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110CC98: MOV x0, x27                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CC9C: BL #0x1b6d41c              | X0 = val_188.get_IsPrimitive();         
            bool val_116 = val_188.IsPrimitive;
            // 0x0110CCA0: AND w8, w0, #1             | W8 = (val_116 & 1);                     
            bool val_117 = val_116;
            // 0x0110CCA4: TBNZ w8, #0, #0x110cfa0    | if ((val_116 & 1) == true) goto label_235;
            if(val_117 == true)
            {
                goto label_235;
            }
            // 0x0110CCA8: CBNZ x23, #0x110ccb0       | if ( != 0) goto label_234;              
            if(null != 0)
            {
                goto label_234;
            }
            // 0x0110CCAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_116, ????);    
            label_234:
            // 0x0110CCB0: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x0110CCB4: LDR x8, [x8, #0xc40]       | X8 = (string**)(1152921512833790112)("            __intp.FreeStackValueType(ptr_of_this_method);");
            // 0x0110CCB8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CCBC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CCC0: LDR x1, [x8]               | X1 = "            __intp.FreeStackValueType(ptr_of_this_method);";
            // 0x0110CCC4: BL #0x1b5c068              | X0 = AppendLine(value:  "            __intp.FreeStackValueType(ptr_of_this_method);");
            System.Text.StringBuilder val_118 = AppendLine(value:  "            __intp.FreeStackValueType(ptr_of_this_method);");
            // 0x0110CCC8: B #0x110cfa0               |  goto label_235;                        
            goto label_235;
            label_223:
            // 0x0110CCCC: CBNZ x26, #0x110ccd4       | if (0x3000000000339FF != 0) goto label_236;
            if(211455 != 0)
            {
                goto label_236;
            }
            // 0x0110CCD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_107, ????);    
            label_236:
            // 0x0110CCD4: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CCD8: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CCDC: LDP x9, x1, [x8, #0x170]   | X9 = mem[216172782113995263] + 368; X1 = mem[216172782113995263] + 368 + 8; //  | 
            // 0x0110CCE0: BLR x9                     | X0 = mem[216172782113995263] + 368();   
            // 0x0110CCE4: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CCE8: CBNZ x20, #0x110ccf0       | if (0x3000000000339FF != 0) goto label_237;
            if(211455 != 0)
            {
                goto label_237;
            }
            // 0x0110CCEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_237:
            // 0x0110CCF0: LDR x8, [x20]              | X8 = mem[216172782113995263];           
            // 0x0110CCF4: MOV x0, x20                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CCF8: LDR x9, [x8, #0x410]       | X9 = mem[216172782113995263] + 1040;    
            // 0x0110CCFC: LDR x1, [x8, #0x418]       | X1 = mem[216172782113995263] + 1048;    
            // 0x0110CD00: BLR x9                     | X0 = mem[216172782113995263] + 1040();  
            // 0x0110CD04: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CD08: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD0C: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD10: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CD14: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CD18: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD1C: MOV x2, x23                | X2 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CD20: MOV x3, x0                 | X3 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD24: BL #0x11093ac              | ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRefWriteBackValueCode(type:  211455, sb:  211455, paramName:  val_1);
            ILRuntime.Runtime.CLRBinding.BindingGeneratorExtensions.GetRefWriteBackValueCode(type:  211455, sb:  211455, paramName:  val_1);
            label_197:
            // 0x0110CD28: CBNZ x23, #0x110cd30       | if ( != 0) goto label_238;              
            if(null != 0)
            {
                goto label_238;
            }
            // 0x0110CD2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            label_238:
            // 0x0110CD30: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x0110CD34: LDR x8, [x8, #0x280]       | X8 = (string**)(1152921512833794400)("                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = ");
            // 0x0110CD38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CD3C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CD40: LDR x1, [x8]               | X1 = "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = ";
            // 0x0110CD44: BL #0x1b5b818              | X0 = Append(value:  "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = ");
            System.Text.StringBuilder val_119 = Append(value:  "                    }\n                    break;\n                case ObjectTypes.FieldReference:\n                    {\n                        var ___obj = __mStack[ptr_of_this_method->Value];\n                        if(___obj is ILTypeInstance)\n                        {\n                            ((ILTypeInstance)___obj)[ptr_of_this_method->ValueLow] = ");
            // 0x0110CD48: CBNZ x26, #0x110cd50       | if (0x3000000000339FF != 0) goto label_239;
            if(211455 != 0)
            {
                goto label_239;
            }
            // 0x0110CD4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_119, ????);    
            label_239:
            // 0x0110CD50: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CD54: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD58: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CD5C: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CD60: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD64: CBZ x23, #0x110cd7c        | if ( == 0) goto label_240;              
            if(null == 0)
            {
                goto label_240;
            }
            // 0x0110CD68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CD6C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CD70: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD74: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_120 = Append(value:  211455);
            // 0x0110CD78: B #0x110cd94               |  goto label_241;                        
            goto label_241;
            label_240:
            // 0x0110CD7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            // 0x0110CD80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CD84: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CD88: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CD8C: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_121 = Append(value:  211455);
            // 0x0110CD90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_121, ????);    
            label_241:
            // 0x0110CD94: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x0110CD98: LDR x8, [x8, #0xdd8]       | X8 = (string**)(1152921512833807488)(";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, ");
            // 0x0110CD9C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CDA0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CDA4: LDR x1, [x8]               | X1 = ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, ";
            // 0x0110CDA8: BL #0x1b5b818              | X0 = Append(value:  ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, ");
            System.Text.StringBuilder val_122 = Append(value:  ";\n                        }\n                        else\n                        {\n                            var t = __domain.GetType(___obj.GetType()) as CLRType;\n                            t.SetFieldValue(ptr_of_this_method->ValueLow, ref ___obj, ");
            // 0x0110CDAC: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CDB0: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CDB4: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CDB8: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CDBC: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CDC0: CBZ x23, #0x110cdd8        | if ( == 0) goto label_242;              
            if(null == 0)
            {
                goto label_242;
            }
            // 0x0110CDC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CDC8: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CDCC: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CDD0: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_123 = Append(value:  211455);
            // 0x0110CDD4: B #0x110cdf0               |  goto label_243;                        
            goto label_243;
            label_242:
            // 0x0110CDD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            // 0x0110CDDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CDE0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CDE4: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CDE8: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_124 = Append(value:  211455);
            // 0x0110CDEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_124, ????);    
            label_243:
            // 0x0110CDF0: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x0110CDF4: LDR x8, [x8, #0x9a8]       | X8 = (string**)(1152921512833820368)(");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = ");
            // 0x0110CDF8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CDFC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CE00: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = ";
            // 0x0110CE04: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = ");
            System.Text.StringBuilder val_125 = Append(value:  ");\n                        }\n                    }\n                    break;\n                case ObjectTypes.StaticFieldReference:\n                    {\n                        var t = __domain.GetType(ptr_of_this_method->Value);\n                        if(t is ILType)\n                        {\n                            ((ILType)t).StaticInstance[ptr_of_this_method->ValueLow] = ");
            // 0x0110CE08: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CE0C: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE10: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CE14: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CE18: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE1C: CBZ x23, #0x110ce34        | if ( == 0) goto label_244;              
            if(null == 0)
            {
                goto label_244;
            }
            // 0x0110CE20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CE24: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CE28: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE2C: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_126 = Append(value:  211455);
            // 0x0110CE30: B #0x110ce4c               |  goto label_245;                        
            goto label_245;
            label_244:
            // 0x0110CE34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            // 0x0110CE38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CE3C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CE40: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE44: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_127 = Append(value:  211455);
            // 0x0110CE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_127, ????);    
            label_245:
            // 0x0110CE4C: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
            // 0x0110CE50: LDR x8, [x8, #0x540]       | X8 = (string**)(1152921512833833520)(";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, ");
            // 0x0110CE54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CE58: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CE5C: LDR x1, [x8]               | X1 = ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, ";
            // 0x0110CE60: BL #0x1b5b818              | X0 = Append(value:  ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, ");
            System.Text.StringBuilder val_128 = Append(value:  ";\n                        }\n                        else\n                        {\n                            ((CLRType)t).SetStaticFieldValue(ptr_of_this_method->ValueLow, ");
            // 0x0110CE64: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CE68: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE6C: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CE70: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CE74: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE78: CBZ x23, #0x110ceb8        | if ( == 0) goto label_246;              
            if(null == 0)
            {
                goto label_246;
            }
            // 0x0110CE7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CE80: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CE84: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CE88: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_129 = Append(value:  211455);
            // 0x0110CE8C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0110CE90: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921512832596224)(");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110CE94: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CE98: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CE9C: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ";
            // 0x0110CEA0: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            System.Text.StringBuilder val_130 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110CEA4: LDR x1, [sp, #0x90]        | X1 = 0x0;                               
            // 0x0110CEA8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CEAC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CEB0: BL #0x1b5b818              | X0 = Append(value:  val_102);           
            System.Text.StringBuilder val_131 = Append(value:  val_102);
            // 0x0110CEB4: B #0x110cf04               |  goto label_247;                        
            goto label_247;
            label_246:
            // 0x0110CEB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            // 0x0110CEBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CEC0: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CEC4: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CEC8: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_132 = Append(value:  211455);
            // 0x0110CECC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_132, ????);    
            // 0x0110CED0: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0110CED4: LDR x8, [x8, #0x528]       | X8 = (string**)(1152921512832596224)(");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110CED8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CEDC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CEE0: LDR x1, [x8]               | X1 = ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ";
            // 0x0110CEE4: BL #0x1b5b818              | X0 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            System.Text.StringBuilder val_133 = Append(value:  ");\n                        }\n                    }\n                    break;\n                 case ObjectTypes.ArrayReference:\n                    {\n                        var instance_of_arrayReference = __mStack[ptr_of_this_method->Value] as ");
            // 0x0110CEE8: LDR x20, [sp, #0x90]       | X20 = 0x0;                              
            // 0x0110CEEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_133, ????);    
            // 0x0110CEF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CEF4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CEF8: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x0110CEFC: BL #0x1b5b818              | X0 = Append(value:  val_102);           
            System.Text.StringBuilder val_134 = Append(value:  val_102);
            // 0x0110CF00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_134, ????);    
            label_247:
            // 0x0110CF04: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x0110CF08: LDR x8, [x8, #0xa38]       | X8 = (string**)(1152921512833862624)("[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = ");
            // 0x0110CF0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CF10: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CF14: LDR x1, [x8]               | X1 = "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = ";
            // 0x0110CF18: BL #0x1b5b818              | X0 = Append(value:  "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = ");
            System.Text.StringBuilder val_135 = Append(value:  "[];\n                        instance_of_arrayReference[ptr_of_this_method->ValueLow] = ");
            // 0x0110CF1C: LDR x8, [x26]              | X8 = mem[216172782113995263];           
            // 0x0110CF20: MOV x0, x26                | X0 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CF24: LDP x9, x1, [x8, #0x1a0]   | X9 = mem[216172782113995263] + 416; X1 = mem[216172782113995263] + 416 + 8; //  | 
            // 0x0110CF28: BLR x9                     | X0 = mem[216172782113995263] + 416();   
            // 0x0110CF2C: MOV x20, x0                | X20 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CF30: CBZ x23, #0x110cf60        | if ( == 0) goto label_248;              
            if(null == 0)
            {
                goto label_248;
            }
            // 0x0110CF34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CF38: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CF3C: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CF40: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_136 = Append(value:  211455);
            // 0x0110CF44: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x0110CF48: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921512833871072)(";\n                    }\n                    break;\n            }");
            // 0x0110CF4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CF50: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CF54: LDR x1, [x8]               | X1 = ";\n                    }\n                    break;\n            }";
            // 0x0110CF58: BL #0x1b5c068              | X0 = AppendLine(value:  ";\n                    }\n                    break;\n            }");
            System.Text.StringBuilder val_137 = AppendLine(value:  ";\n                    }\n                    break;\n            }");
            // 0x0110CF5C: B #0x110cf94               |  goto label_249;                        
            goto label_249;
            label_248:
            // 0x0110CF60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x3000000000339FF, ????);
            // 0x0110CF64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CF68: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CF6C: MOV x1, x20                | X1 = 216172782113995263 (0x3000000000339FF);//ML01
            // 0x0110CF70: BL #0x1b5b818              | X0 = Append(value:  211455);            
            System.Text.StringBuilder val_138 = Append(value:  211455);
            // 0x0110CF74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_138, ????);    
            // 0x0110CF78: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x0110CF7C: LDR x8, [x8, #0x448]       | X8 = (string**)(1152921512833871072)(";\n                    }\n                    break;\n            }");
            // 0x0110CF80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CF84: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CF88: LDR x1, [x8]               | X1 = ";\n                    }\n                    break;\n            }";
            // 0x0110CF8C: BL #0x1b5c068              | X0 = AppendLine(value:  ";\n                    }\n                    break;\n            }");
            System.Text.StringBuilder val_139 = AppendLine(value:  ";\n                    }\n                    break;\n            }");
            // 0x0110CF90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_139, ????);    
            label_249:
            // 0x0110CF94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110CF98: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CF9C: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_140 = AppendLine();
            label_235:
            // 0x0110CFA0: CBNZ x23, #0x110cfa8       | if ( != 0) goto label_250;              
            if(null != 0)
            {
                goto label_250;
            }
            // 0x0110CFA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_140, ????);    
            label_250:
            // 0x0110CFA8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x0110CFAC: LDR x8, [x8, #0xda8]       | X8 = (string**)(1152921512833617936)("            __intp.Free(ptr_of_this_method);");
            // 0x0110CFB0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110CFB4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110CFB8: LDR x1, [x8]               | X1 = "            __intp.Free(ptr_of_this_method);";
            // 0x0110CFBC: BL #0x1b5c068              | X0 = AppendLine(value:  "            __intp.Free(ptr_of_this_method);");
            System.Text.StringBuilder val_141 = AppendLine(value:  "            __intp.Free(ptr_of_this_method);");
            label_202:
            // 0x0110CFC0: ADD x8, x19, #1            | X8 = (38931 + 1);                       
            var val_142 = 38931 + 1;
            // 0x0110CFC4: ADD w21, w21, #1           | W21 = (-4611686018427426835 + 1);       
            val_185 = (-4611686018427426835) + 1;
            // 0x0110CFC8: SUB w22, w22, #1           | W22 = (4611686018427426835 - 1);        
            val_187 = val_187 - 1;
            // 0x0110CFCC: CMP x8, #2                 | STATE = COMPARE((38931 + 1), 0x2)       
            // 0x0110CFD0: B.GE #0x110c954            | if (val_142 >= 0x2) goto label_251;     
            if(val_142 >= 2)
            {
                goto label_251;
            }
            label_193:
            // 0x0110CFD4: LDR x0, [sp, #0x30]        | X0 = methods;                           
            val_190 = val_187;
            // 0x0110CFD8: CBNZ x0, #0x110cfe8        | if (methods != 0) goto label_252;       
            if(val_190 != 0)
            {
                goto label_252;
            }
            // 0x0110CFDC: MOV x19, x0                | X19 = methods;//m1                      
            // 0x0110CFE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? methods, ????);    
            // 0x0110CFE4: MOV x0, x19                | X0 = methods;//m1                       
            val_190 = val_190;
            label_252:
            // 0x0110CFE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110CFEC: MOV x24, x0                | X24 = methods;//m1                      
            // 0x0110CFF0: BL #0x1b6d264              | X0 = methods.get_IsValueType();         
            bool val_143 = val_190.IsValueType;
            // 0x0110CFF4: LDR x19, [sp, #0x48]       | X19 = X5;                               
            // 0x0110CFF8: LDP x22, x21, [sp, #0x10]  | X22 = typeClsName; X21 = valueTypeBinders; //  | 
            // 0x0110CFFC: TBZ w0, #0, #0x110d1e0     | if (val_143 == false) goto label_253;   
            if(val_143 == false)
            {
                goto label_253;
            }
            // 0x0110D000: CBZ x19, #0x110d134        | if (X5 == 0) goto label_255;            
            if(X5 == 0)
            {
                goto label_255;
            }
            // 0x0110D004: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110D008: LDR x8, [x8, #0x9e0]       | X8 = 1152921512820334400;               
            // 0x0110D00C: MOV x0, x19                | X0 = X5;//m1                            
            // 0x0110D010: MOV x1, x24                | X1 = methods;//m1                       
            // 0x0110D014: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.Type>::Contains(System.Type item);
            // 0x0110D018: BL #0x25ead74              | X0 = X5.Contains(item:  val_190);       
            bool val_144 = X5.Contains(item:  val_190);
            // 0x0110D01C: TBZ w0, #0, #0x110d134     | if (val_144 == false) goto label_255;   
            if(val_144 == false)
            {
                goto label_255;
            }
            // 0x0110D020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110D024: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110D028: ADD x2, sp, #0x80          | X2 = (1152921512834025696 + 128) = 1152921512834025824 (0x10000001EA60C960);
            // 0x0110D02C: ADD x3, sp, #0x78          | X3 = (1152921512834025696 + 120) = 1152921512834025816 (0x10000001EA60C958);
            // 0x0110D030: ADD x4, sp, #0x77          | X4 = (1152921512834025696 + 119) = 1152921512834025815 (0x10000001EA60C957);
            // 0x0110D034: MOV x1, x24                | X1 = methods;//m1                       
            string val_145 = val_190;
            // 0x0110D038: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110D03C: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  string val_145 = val_190, realClsName: out  string val_146 = 0, isByRef: out  bool val_147 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_145, realClsName: out  val_146, isByRef: out  val_147, simpleClassName:  true);
            // 0x0110D040: CBNZ x23, #0x110d048       | if ( != 0) goto label_256;              
            if(null != 0)
            {
                goto label_256;
            }
            // 0x0110D044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_256:
            // 0x0110D048: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x0110D04C: LDR x8, [x8, #0x2a8]       | X8 = (string**)(1152921512833891760)("            if(!isNewObj)\n            {\n                __ret--;");
            // 0x0110D050: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D054: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D058: LDR x1, [x8]               | X1 = "            if(!isNewObj)\n            {\n                __ret--;";
            // 0x0110D05C: BL #0x1b5c068              | X0 = AppendLine(value:  "            if(!isNewObj)\n            {\n                __ret--;");
            System.Text.StringBuilder val_148 = AppendLine(value:  "            if(!isNewObj)\n            {\n                __ret--;");
            // 0x0110D060: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x0110D064: LDR x20, [sp, #0x80]       | X20 = 0x0;                              
            // 0x0110D068: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110D06C: TBZ w8, #0, #0x110d07c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_258;
            // 0x0110D070: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110D074: CBNZ w8, #0x110d07c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_258;
            // 0x0110D078: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_258:
            // 0x0110D07C: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x0110D080: LDR x8, [x8, #0x218]       | X8 = (string**)(1152921512833773136)("                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110D084: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110D088: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110D08C: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110D090: LDR x1, [x8]               | X1 = "                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{";
            // 0x0110D094: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            string val_149 = System.String.Format(format:  0, arg0:  "                if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110D098: MOV x20, x0                | X20 = val_149;//m1                      
            // 0x0110D09C: CBNZ x23, #0x110d0a4       | if ( != 0) goto label_259;              
            if(null != 0)
            {
                goto label_259;
            }
            // 0x0110D0A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_149, ????);    
            label_259:
            // 0x0110D0A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D0A8: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D0AC: MOV x1, x20                | X1 = val_149;//m1                       
            // 0x0110D0B0: BL #0x1b5c068              | X0 = AppendLine(value:  val_149);       
            System.Text.StringBuilder val_150 = AppendLine(value:  val_149);
            // 0x0110D0B4: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x0110D0B8: LDR x2, [sp, #0x80]        | X2 = 0x0;                               
            // 0x0110D0BC: LDR x8, [x8, #0x918]       | X8 = (string**)(1152921512833904256)("                    ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, __ret, __mStack, ref result_of_this_method);");
            // 0x0110D0C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110D0C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110D0C8: LDR x1, [x8]               | X1 = "                    ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, __ret, __mStack, ref result_of_this_method);";
            // 0x0110D0CC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "                    ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, __ret, __mStack, ref result_of_this_method);");
            string val_151 = System.String.Format(format:  0, arg0:  "                    ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.WriteBackValue(__domain, __ret, __mStack, ref result_of_this_method);");
            // 0x0110D0D0: MOV x20, x0                | X20 = val_151;//m1                      
            // 0x0110D0D4: CBZ x23, #0x110d148        | if ( == 0) goto label_260;              
            if(null == 0)
            {
                goto label_260;
            }
            // 0x0110D0D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D0DC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D0E0: MOV x1, x20                | X1 = val_151;//m1                       
            // 0x0110D0E4: BL #0x1b5c068              | X0 = AppendLine(value:  val_151);       
            System.Text.StringBuilder val_152 = AppendLine(value:  val_151);
            // 0x0110D0E8: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0110D0EC: LDR x8, [x8, #0x880]       | X8 = (string**)(1152921512833747776)("                } else {");
            // 0x0110D0F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D0F4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D0F8: LDR x1, [x8]               | X1 = "                } else {";        
            // 0x0110D0FC: BL #0x1b5c068              | X0 = AppendLine(value:  "                } else {");
            System.Text.StringBuilder val_153 = AppendLine(value:  "                } else {");
            // 0x0110D100: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x0110D104: LDR x8, [x8, #0x1a8]       | X8 = (string**)(1152921512833916896)("                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);");
            // 0x0110D108: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D10C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D110: LDR x1, [x8]               | X1 = "                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);";
            // 0x0110D114: BL #0x1b5c068              | X0 = AppendLine(value:  "                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);");
            System.Text.StringBuilder val_154 = AppendLine(value:  "                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);");
            // 0x0110D118: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x0110D11C: LDR x8, [x8, #0x480]       | X8 = (string**)(1152921512833752000)("                }");
            // 0x0110D120: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D124: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D128: LDR x1, [x8]               | X1 = "                }";               
            // 0x0110D12C: BL #0x1b5c068              | X0 = AppendLine(value:  "                }");
            System.Text.StringBuilder val_155 = AppendLine(value:  "                }");
            // 0x0110D130: B #0x110d1b4               |  goto label_261;                        
            goto label_261;
            label_255:
            // 0x0110D134: CBNZ x23, #0x110d13c       | if ( != 0) goto label_262;              
            if(null != 0)
            {
                goto label_262;
            }
            // 0x0110D138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_143, ????);    
            label_262:
            // 0x0110D13C: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x0110D140: LDR x8, [x8, #0x870]       | X8 = (string**)(1152921512833925344)("            if(!isNewObj)\n            {\n                __ret--;\n                WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);\n                return __ret;\n            }");
            val_191 = "            if(!isNewObj)\n            {\n                __ret--;\n                WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);\n                return __ret;\n            }";
            // 0x0110D144: B #0x110d1bc               |  goto label_263;                        
            goto label_263;
            label_260:
            // 0x0110D148: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_151, ????);    
            // 0x0110D14C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D150: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D154: MOV x1, x20                | X1 = val_151;//m1                       
            // 0x0110D158: BL #0x1b5c068              | X0 = AppendLine(value:  val_151);       
            System.Text.StringBuilder val_156 = AppendLine(value:  val_151);
            // 0x0110D15C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_156, ????);    
            // 0x0110D160: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x0110D164: LDR x8, [x8, #0x880]       | X8 = (string**)(1152921512833747776)("                } else {");
            // 0x0110D168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D16C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D170: LDR x1, [x8]               | X1 = "                } else {";        
            // 0x0110D174: BL #0x1b5c068              | X0 = AppendLine(value:  "                } else {");
            System.Text.StringBuilder val_157 = AppendLine(value:  "                } else {");
            // 0x0110D178: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_157, ????);    
            // 0x0110D17C: ADRP x8, #0x35d5000        | X8 = 56446976 (0x35D5000);              
            // 0x0110D180: LDR x8, [x8, #0x1a8]       | X8 = (string**)(1152921512833916896)("                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);");
            // 0x0110D184: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D188: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D18C: LDR x1, [x8]               | X1 = "                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);";
            // 0x0110D190: BL #0x1b5c068              | X0 = AppendLine(value:  "                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);");
            System.Text.StringBuilder val_158 = AppendLine(value:  "                    WriteBackInstance(__domain, __ret, __mStack, ref result_of_this_method);");
            // 0x0110D194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_158, ????);    
            // 0x0110D198: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x0110D19C: LDR x8, [x8, #0x480]       | X8 = (string**)(1152921512833752000)("                }");
            // 0x0110D1A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D1A4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D1A8: LDR x1, [x8]               | X1 = "                }";               
            // 0x0110D1AC: BL #0x1b5c068              | X0 = AppendLine(value:  "                }");
            System.Text.StringBuilder val_159 = AppendLine(value:  "                }");
            // 0x0110D1B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_159, ????);    
            label_261:
            // 0x0110D1B4: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0110D1B8: LDR x8, [x8, #0x988]       | X8 = (string**)(1152921512833942208)("                return __ret;\n            }");
            val_191 = "                return __ret;\n            }";
            label_263:
            // 0x0110D1BC: LDR x1, [x8]               | X1 = "                return __ret;\n            }";
            // 0x0110D1C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D1C4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D1C8: BL #0x1b5c068              | X0 = AppendLine(value:  val_191 = "                return __ret;\n            }");
            System.Text.StringBuilder val_160 = AppendLine(value:  val_191);
            // 0x0110D1CC: CBNZ x23, #0x110d1d4       | if ( != 0) goto label_264;              
            if(null != 0)
            {
                goto label_264;
            }
            // 0x0110D1D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_160, ????);    
            label_264:
            // 0x0110D1D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110D1D8: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D1DC: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_161 = AppendLine();
            label_253:
            // 0x0110D1E0: MOV x0, x24                | X0 = methods;//m1                       
            val_192 = val_190;
            // 0x0110D1E4: CBNZ x0, #0x110d1f4        | if (methods != 0) goto label_265;       
            if(val_192 != 0)
            {
                goto label_265;
            }
            // 0x0110D1E8: MOV x20, x0                | X20 = methods;//m1                      
            // 0x0110D1EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? methods, ????);    
            // 0x0110D1F0: MOV x0, x20                | X0 = methods;//m1                       
            val_192 = val_192;
            label_265:
            // 0x0110D1F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110D1F8: STR x0, [sp, #0x30]        | stack[1152921512834025744] = methods;    //  dest_result_addr=1152921512834025744
            // 0x0110D1FC: BL #0x1b6d264              | X0 = methods.get_IsValueType();         
            bool val_162 = val_192.IsValueType;
            // 0x0110D200: LDR x24, [sp, #0x38]       | X24 = 0x1;                              
            // 0x0110D204: CBZ x19, #0x110d324        | if (X5 == 0) goto label_268;            
            if(X5 == 0)
            {
                goto label_268;
            }
            // 0x0110D208: EOR w8, w0, #1             | W8 = (val_162 ^ 1);                     
            bool val_163 = val_162 ^ 1;
            // 0x0110D20C: AND w8, w8, #1             | W8 = ((val_162 ^ 1) & 1);               
            bool val_164 = val_163;
            // 0x0110D210: TBNZ w8, #0, #0x110d324    | if (((val_162 ^ 1) & 1) == true) goto label_268;
            if(val_164 == true)
            {
                goto label_268;
            }
            // 0x0110D214: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0110D218: LDR x8, [x8, #0x9e0]       | X8 = 1152921512820334400;               
            // 0x0110D21C: LDR x1, [sp, #0x30]        | X1 = methods;                           
            // 0x0110D220: MOV x0, x19                | X0 = X5;//m1                            
            // 0x0110D224: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.List<System.Type>::Contains(System.Type item);
            // 0x0110D228: BL #0x25ead74              | X0 = X5.Contains(item:  val_192);       
            bool val_165 = X5.Contains(item:  val_192);
            // 0x0110D22C: TBZ w0, #0, #0x110d324     | if (val_165 == false) goto label_268;   
            if(val_165 == false)
            {
                goto label_268;
            }
            // 0x0110D230: LDR x1, [sp, #0x30]        | X1 = methods;                           
            System.Reflection.ConstructorInfo[] val_166 = val_192;
            // 0x0110D234: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110D238: MOV w5, wzr                | W5 = 0 (0x0);//ML01                     
            // 0x0110D23C: ADD x2, sp, #0x68          | X2 = (1152921512834025696 + 104) = 1152921512834025800 (0x10000001EA60C948);
            // 0x0110D240: ADD x3, sp, #0x60          | X3 = (1152921512834025696 + 96) = 1152921512834025792 (0x10000001EA60C940);
            // 0x0110D244: ADD x4, sp, #0x5f          | X4 = (1152921512834025696 + 95) = 1152921512834025791 (0x10000001EA60C93F);
            // 0x0110D248: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x0110D24C: BL #0x28f1c84              | ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  System.Reflection.ConstructorInfo[] val_166 = val_192, realClsName: out  string val_167 = 0, isByRef: out  bool val_168 = false, simpleClassName:  true);
            ILRuntime.Runtime.Extensions.GetClassName(type:  0, clsName: out  val_166, realClsName: out  val_167, isByRef: out  val_168, simpleClassName:  true);
            // 0x0110D250: LDR x0, [x25]              | X0 = typeof(System.String);             
            // 0x0110D254: LDR x20, [sp, #0x68]       | X20 = 0x0;                              
            // 0x0110D258: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x0110D25C: TBZ w8, #0, #0x110d26c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_270;
            // 0x0110D260: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x0110D264: CBNZ w8, #0x110d26c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_270;
            // 0x0110D268: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_270:
            // 0x0110D26C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x0110D270: LDR x8, [x8, #0x270]       | X8 = (string**)(1152921512833634848)("            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110D274: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110D278: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110D27C: MOV x2, x20                | X2 = 0 (0x0);//ML01                     
            // 0x0110D280: LDR x1, [x8]               | X1 = "            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{";
            // 0x0110D284: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            string val_169 = System.String.Format(format:  0, arg0:  "            if (ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder != null) {{");
            // 0x0110D288: MOV x20, x0                | X20 = val_169;//m1                      
            // 0x0110D28C: CBNZ x23, #0x110d294       | if ( != 0) goto label_271;              
            if(null != 0)
            {
                goto label_271;
            }
            // 0x0110D290: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_169, ????);    
            label_271:
            // 0x0110D294: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D298: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D29C: MOV x1, x20                | X1 = val_169;//m1                       
            // 0x0110D2A0: BL #0x1b5c068              | X0 = AppendLine(value:  val_169);       
            System.Text.StringBuilder val_170 = AppendLine(value:  val_169);
            // 0x0110D2A4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0110D2A8: LDR x2, [sp, #0x68]        | X2 = 0x0;                               
            // 0x0110D2AC: LDR x8, [x8, #0x8f8]       | X8 = (string**)(1152921512833958752)("                ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.PushValue(ref result_of_this_method, __intp, __ret, __mStack);");
            // 0x0110D2B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0110D2B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0110D2B8: LDR x1, [x8]               | X1 = "                ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.PushValue(ref result_of_this_method, __intp, __ret, __mStack);";
            // 0x0110D2BC: BL #0x18a01bc              | X0 = System.String.Format(format:  0, arg0:  "                ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.PushValue(ref result_of_this_method, __intp, __ret, __mStack);");
            string val_171 = System.String.Format(format:  0, arg0:  "                ILRuntime.Runtime.Generated.CLRBindings.s_{0}_Binder.PushValue(ref result_of_this_method, __intp, __ret, __mStack);");
            // 0x0110D2C0: MOV x20, x0                | X20 = val_171;//m1                      
            // 0x0110D2C4: CBZ x23, #0x110d338        | if ( == 0) goto label_272;              
            if(null == 0)
            {
                goto label_272;
            }
            // 0x0110D2C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D2CC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D2D0: MOV x1, x20                | X1 = val_171;//m1                       
            // 0x0110D2D4: BL #0x1b5c068              | X0 = AppendLine(value:  val_171);       
            System.Text.StringBuilder val_172 = AppendLine(value:  val_171);
            // 0x0110D2D8: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x0110D2DC: LDR x8, [x8, #0xce8]       | X8 = (string**)(1152921512833967280)("                return __ret + 1;");
            // 0x0110D2E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D2E4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D2E8: LDR x1, [x8]               | X1 = "                return __ret + 1;";
            // 0x0110D2EC: BL #0x1b5c068              | X0 = AppendLine(value:  "                return __ret + 1;");
            System.Text.StringBuilder val_173 = AppendLine(value:  "                return __ret + 1;");
            // 0x0110D2F0: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x0110D2F4: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921512833656240)("            } else {");
            // 0x0110D2F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D2FC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D300: LDR x1, [x8]               | X1 = "            } else {";            
            // 0x0110D304: BL #0x1b5c068              | X0 = AppendLine(value:  "            } else {");
            System.Text.StringBuilder val_174 = AppendLine(value:  "            } else {");
            // 0x0110D308: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x0110D30C: LDR x8, [x8, #0x770]       | X8 = (string**)(1152921512833975616)("                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            // 0x0110D310: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D314: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D318: LDR x1, [x8]               | X1 = "                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);";
            // 0x0110D31C: BL #0x1b5c068              | X0 = AppendLine(value:  "                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            System.Text.StringBuilder val_175 = AppendLine(value:  "                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            // 0x0110D320: B #0x110d3a4               |  goto label_273;                        
            goto label_273;
            label_268:
            // 0x0110D324: CBNZ x23, #0x110d32c       | if ( != 0) goto label_274;              
            if(null != 0)
            {
                goto label_274;
            }
            // 0x0110D328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_162, ????);    
            label_274:
            // 0x0110D32C: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x0110D330: LDR x8, [x8, #0x7b0]       | X8 = (string**)(1152921512833979968)("            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            val_193 = "            return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);";
            // 0x0110D334: B #0x110d3ac               |  goto label_275;                        
            goto label_275;
            label_272:
            // 0x0110D338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_171, ????);    
            // 0x0110D33C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D340: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D344: MOV x1, x20                | X1 = val_171;//m1                       
            // 0x0110D348: BL #0x1b5c068              | X0 = AppendLine(value:  val_171);       
            System.Text.StringBuilder val_176 = AppendLine(value:  val_171);
            // 0x0110D34C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_176, ????);    
            // 0x0110D350: ADRP x8, #0x366d000        | X8 = 57069568 (0x366D000);              
            // 0x0110D354: LDR x8, [x8, #0xce8]       | X8 = (string**)(1152921512833967280)("                return __ret + 1;");
            // 0x0110D358: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D35C: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D360: LDR x1, [x8]               | X1 = "                return __ret + 1;";
            // 0x0110D364: BL #0x1b5c068              | X0 = AppendLine(value:  "                return __ret + 1;");
            System.Text.StringBuilder val_177 = AppendLine(value:  "                return __ret + 1;");
            // 0x0110D368: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_177, ????);    
            // 0x0110D36C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x0110D370: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921512833656240)("            } else {");
            // 0x0110D374: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D378: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D37C: LDR x1, [x8]               | X1 = "            } else {";            
            // 0x0110D380: BL #0x1b5c068              | X0 = AppendLine(value:  "            } else {");
            System.Text.StringBuilder val_178 = AppendLine(value:  "            } else {");
            // 0x0110D384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_178, ????);    
            // 0x0110D388: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x0110D38C: LDR x8, [x8, #0x770]       | X8 = (string**)(1152921512833975616)("                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            // 0x0110D390: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D394: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D398: LDR x1, [x8]               | X1 = "                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);";
            // 0x0110D39C: BL #0x1b5c068              | X0 = AppendLine(value:  "                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            System.Text.StringBuilder val_179 = AppendLine(value:  "                return ILIntepreter.PushObject(__ret, __mStack, result_of_this_method);");
            // 0x0110D3A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_179, ????);    
            label_273:
            // 0x0110D3A4: ADRP x8, #0x3665000        | X8 = 57036800 (0x3665000);              
            // 0x0110D3A8: LDR x8, [x8, #0x9d0]       | X8 = (string**)(1152921512833689824)("            }");
            val_193 = "            }";
            label_275:
            // 0x0110D3AC: LDR x1, [x8]               | X1 = "            }";                   
            // 0x0110D3B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D3B4: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D3B8: BL #0x1b5c068              | X0 = AppendLine(value:  val_193 = "            }");
            System.Text.StringBuilder val_180 = AppendLine(value:  val_193);
            // 0x0110D3BC: CBZ x23, #0x110d3dc        | if ( == 0) goto label_276;              
            if(null == 0)
            {
                goto label_276;
            }
            // 0x0110D3C0: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x0110D3C4: LDR x8, [x8, #0x20]        | X8 = (string**)(1152921512832555248)("        }");
            // 0x0110D3C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D3CC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D3D0: LDR x1, [x8]               | X1 = "        }";                       
            // 0x0110D3D4: BL #0x1b5c068              | X0 = AppendLine(value:  "        }");   
            System.Text.StringBuilder val_181 = AppendLine(value:  "        }");
            // 0x0110D3D8: B #0x110d3fc               |  goto label_277;                        
            goto label_277;
            label_276:
            // 0x0110D3DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_180, ????);    
            // 0x0110D3E0: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x0110D3E4: LDR x8, [x8, #0x20]        | X8 = (string**)(1152921512832555248)("        }");
            // 0x0110D3E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0110D3EC: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D3F0: LDR x1, [x8]               | X1 = "        }";                       
            // 0x0110D3F4: BL #0x1b5c068              | X0 = AppendLine(value:  "        }");   
            System.Text.StringBuilder val_182 = AppendLine(value:  "        }");
            // 0x0110D3F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_182, ????);    
            label_277:
            // 0x0110D3FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110D400: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D404: BL #0x1b5c038              | X0 = AppendLine();                      
            System.Text.StringBuilder val_183 = AppendLine();
            // 0x0110D408: LDR w8, [sp, #0x24]        | W8 = 0x0;                               
            // 0x0110D40C: ADD w8, w8, #1             | W8 = (0 + 1) = 1 (0x00000001);          
            // 0x0110D410: STR w8, [sp, #0x24]        | stack[1152921512834025732] = 0x1;        //  dest_result_addr=1152921512834025732
            // 0x0110D414: B #0x110b634               |  goto label_278;                        
            goto label_278;
            label_7:
            // 0x0110D418: CBNZ x23, #0x110d420       | if ( != 0) goto label_279;              
            if(null != 0)
            {
                goto label_279;
            }
            // 0x0110D41C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_279:
            // 0x0110D420: LDR x8, [x23]              | X8 = ;                                  
            // 0x0110D424: MOV x0, x23                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0110D428: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x0110D42C: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x0110D430: SUB sp, x29, #0x50         | SP = (1152921512834025984 - 80) = 1152921512834025904 (0x10000001EA60C9B0);
            // 0x0110D434: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0110D438: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0110D43C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0110D440: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0110D444: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0110D448: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0110D44C: RET                        |  return (System.String)typeof(System.Text.StringBuilder);
            return (string)val_1;
            //  |  // // {name=val_0, type=System.String, size=8, nGRN=0 }
            label_108:
            // 0x0110D450: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0110D454: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x0110D458: LDR x0, [x8]               | X0 = typeof(System.NotSupportedException);
            System.NotSupportedException val_184 = null;
            // 0x0110D45C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x0110D460: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0110D464: MOV x19, x0                | X19 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x0110D468: BL #0x1701574              | .ctor();                                
            val_184 = new System.NotSupportedException();
            // 0x0110D46C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0110D470: LDR x8, [x8, #0x7b0]       | X8 = 1152921512834012976;               
            // 0x0110D474: MOV x0, x19                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            ILRuntime.CLR.Method.CLRMethod val_185 = val_184;
            // 0x0110D478: LDR x1, [x8]               | X1 = static System.String ILRuntime.Runtime.CLRBinding.ConstructorBindingGenerator::GenerateConstructorWraperCode(System.Type type, System.Reflection.ConstructorInfo[] methods, string typeClsName, System.Collections.Generic.HashSet<System.Reflection.MethodBase> excludes, System.Collections.Generic.List<System.Type> valueTypeBinders);
            // 0x0110D47C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x0110D480: BL #0x10ec5ac              | .ctor(def:  static System.String ILRuntime.Runtime.CLRBinding.ConstructorBindingGenerator::GenerateConstructorWraperCode(System.Type type, System.Reflection.ConstructorInfo[] methods, string typeClsName, System.Collections.Generic.HashSet<System.Reflection.MethodBase> excludes, System.Collections.Generic.List<System.Type> valueTypeBinders), type:  0, domain:  val_30);
            val_185 = new ILRuntime.CLR.Method.CLRMethod(def:  static System.String ILRuntime.Runtime.CLRBinding.ConstructorBindingGenerator::GenerateConstructorWraperCode(System.Type type, System.Reflection.ConstructorInfo[] methods, string typeClsName, System.Collections.Generic.HashSet<System.Reflection.MethodBase> excludes, System.Collections.Generic.List<System.Type> valueTypeBinders), type:  0, domain:  val_30);
        
        }
    
    }

}
