using UnityEngine;
public enum AnimationRunner.AniType
{
    // Fields
    none = 0
    ,win = 1
    ,idle = 2
    ,run = 3
    ,attack = 4
    ,attacked = 5
    ,death = 6
    ,active = 7
    ,rise = 8
    ,dump = 9
    ,fly = 10
    ,flying = 11
    ,down = 12
    ,Take001 = 13
    ,rage = 14
    ,reborn = 15
    ,show = 16
    ,qiyuan = 17
    ,passive1 = 18
    ,showidle = 19
    

}
