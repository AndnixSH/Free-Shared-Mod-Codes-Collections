using UnityEngine;
private class LzmaBench.CBenchRandomGenerator
{
    // Fields
    private SevenZip.LzmaBench.CBitRandomGenerator RG; //  0x00000010
    private uint Pos; //  0x00000018
    private uint Rep0; //  0x0000001C
    public uint BufferSize; //  0x00000020
    public byte[] Buffer; //  0x00000028
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00ADB444 (11383876), len: 100  VirtAddr: 0x00ADB444 RVA: 0x00ADB444 token: 100681611 methodIndex: 54777 delegateWrapperIndex: 0 methodInvoker: 0
    public LzmaBench.CBenchRandomGenerator()
    {
        //
        // Disasemble & Code
        // 0x00ADB444: STP x20, x19, [sp, #-0x20]! | stack[1152921513101884208] = ???;  stack[1152921513101884216] = ???;  //  dest_result_addr=1152921513101884208 |  dest_result_addr=1152921513101884216
        // 0x00ADB448: STP x29, x30, [sp, #0x10]  | stack[1152921513101884224] = ???;  stack[1152921513101884232] = ???;  //  dest_result_addr=1152921513101884224 |  dest_result_addr=1152921513101884232
        // 0x00ADB44C: ADD x29, sp, #0x10         | X29 = (1152921513101884208 + 16) = 1152921513101884224 (0x10000001FA57FB40);
        // 0x00ADB450: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00ADB454: LDRB w8, [x20, #0x51d]     | W8 = (bool)static_value_0373351D;       
        // 0x00ADB458: MOV x19, x0                | X19 = 1152921513101896240 (0x10000001FA582A30);//ML01
        // 0x00ADB45C: TBNZ w8, #0, #0xadb478     | if (static_value_0373351D == true) goto label_0;
        // 0x00ADB460: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x00ADB464: LDR x8, [x8, #0xe8]        | X8 = 0x2B904A8;                         
        // 0x00ADB468: LDR w0, [x8]               | W0 = 0x17EE;                            
        // 0x00ADB46C: BL #0x2782188              | X0 = sub_2782188( ?? 0x17EE, ????);     
        // 0x00ADB470: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00ADB474: STRB w8, [x20, #0x51d]     | static_value_0373351D = true;            //  dest_result_addr=57881885
        label_0:
        // 0x00ADB478: ADRP x8, #0x367e000        | X8 = 57139200 (0x367E000);              
        // 0x00ADB47C: LDR x8, [x8, #0x250]       | X8 = 1152921504833896448;               
        // 0x00ADB480: LDR x0, [x8]               | X0 = typeof(LzmaBench.CBitRandomGenerator);
        LzmaBench.CBitRandomGenerator val_1 = null;
        // 0x00ADB484: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(LzmaBench.CBitRandomGenerator), ????);
        // 0x00ADB488: MOV x20, x0                | X20 = 1152921504833896448 (0x100000000D888000);//ML01
        // 0x00ADB48C: BL #0xadb7dc               | .ctor();                                
        val_1 = new LzmaBench.CBitRandomGenerator();
        // 0x00ADB490: STR x20, [x19, #0x10]      | this.RG = typeof(LzmaBench.CBitRandomGenerator);  //  dest_result_addr=1152921513101896256
        this.RG = val_1;
        // 0x00ADB494: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB498: MOV x0, x19                | X0 = 1152921513101896240 (0x10000001FA582A30);//ML01
        // 0x00ADB49C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB4A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB4A4: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB4A8 (11383976), len: 120  VirtAddr: 0x00ADB4A8 RVA: 0x00ADB4A8 token: 100681612 methodIndex: 54778 delegateWrapperIndex: 0 methodInvoker: 0
    public void Set(uint bufferSize)
    {
        //
        // Disasemble & Code
        // 0x00ADB4A8: STP x22, x21, [sp, #-0x30]! | stack[1152921513101996192] = ???;  stack[1152921513101996200] = ???;  //  dest_result_addr=1152921513101996192 |  dest_result_addr=1152921513101996200
        // 0x00ADB4AC: STP x20, x19, [sp, #0x10]  | stack[1152921513101996208] = ???;  stack[1152921513101996216] = ???;  //  dest_result_addr=1152921513101996208 |  dest_result_addr=1152921513101996216
        // 0x00ADB4B0: STP x29, x30, [sp, #0x20]  | stack[1152921513101996224] = ???;  stack[1152921513101996232] = ???;  //  dest_result_addr=1152921513101996224 |  dest_result_addr=1152921513101996232
        // 0x00ADB4B4: ADD x29, sp, #0x20         | X29 = (1152921513101996192 + 32) = 1152921513101996224 (0x10000001FA59B0C0);
        // 0x00ADB4B8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00ADB4BC: LDRB w8, [x21, #0x51e]     | W8 = (bool)static_value_0373351E;       
        // 0x00ADB4C0: MOV w19, w1                | W19 = bufferSize;//m1                   
        // 0x00ADB4C4: MOV x20, x0                | X20 = 1152921513102008240 (0x10000001FA59DFB0);//ML01
        // 0x00ADB4C8: TBNZ w8, #0, #0xadb4e4     | if (static_value_0373351E == true) goto label_0;
        // 0x00ADB4CC: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
        // 0x00ADB4D0: LDR x8, [x8, #0xe30]       | X8 = 0x2B904AC;                         
        // 0x00ADB4D4: LDR w0, [x8]               | W0 = 0x17EF;                            
        // 0x00ADB4D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x17EF, ????);     
        // 0x00ADB4DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00ADB4E0: STRB w8, [x21, #0x51e]     | static_value_0373351E = true;            //  dest_result_addr=57881886
        label_0:
        // 0x00ADB4E4: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00ADB4E8: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
        // 0x00ADB4EC: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
        // 0x00ADB4F0: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00ADB4F4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
        // 0x00ADB4F8: MOV w1, w19                | W1 = bufferSize;//m1                    
        // 0x00ADB4FC: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
        // 0x00ADB500: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
        // 0x00ADB504: STR w19, [x20, #0x20]      | this.BufferSize = bufferSize;            //  dest_result_addr=1152921513102008272
        this.BufferSize = bufferSize;
        // 0x00ADB508: STR x0, [x20, #0x28]       | this.Buffer = typeof(System.Byte[]);     //  dest_result_addr=1152921513102008280
        this.Buffer = null;
        // 0x00ADB50C: STR wzr, [x20, #0x18]      | this.Pos = null;                         //  dest_result_addr=1152921513102008264
        this.Pos = 0;
        // 0x00ADB510: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB514: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB518: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00ADB51C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB858 (11384920), len: 44  VirtAddr: 0x00ADB858 RVA: 0x00ADB858 token: 100681613 methodIndex: 54779 delegateWrapperIndex: 0 methodInvoker: 0
    private uint GetRndBit()
    {
        //
        // Disasemble & Code
        // 0x00ADB858: STP x20, x19, [sp, #-0x20]! | stack[1152921513102112304] = ???;  stack[1152921513102112312] = ???;  //  dest_result_addr=1152921513102112304 |  dest_result_addr=1152921513102112312
        // 0x00ADB85C: STP x29, x30, [sp, #0x10]  | stack[1152921513102112320] = ???;  stack[1152921513102112328] = ???;  //  dest_result_addr=1152921513102112320 |  dest_result_addr=1152921513102112328
        // 0x00ADB860: ADD x29, sp, #0x10         | X29 = (1152921513102112304 + 16) = 1152921513102112320 (0x10000001FA5B7640);
        // 0x00ADB864: LDR x19, [x0, #0x10]       | X19 = this.RG; //P2                     
        // 0x00ADB868: CBNZ x19, #0xadb870        | if (this.RG != null) goto label_0;      
        if(this.RG != null)
        {
            goto label_0;
        }
        // 0x00ADB86C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADB870: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB874: ORR w1, wzr, #1            | W1 = 1(0x1);                            
        // 0x00ADB878: MOV x0, x19                | X0 = this.RG;//m1                       
        // 0x00ADB87C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB880: B #0xadb884                | return this.RG.GetRnd(numBits:  1);     
        return this.RG.GetRnd(numBits:  1);
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB954 (11385172), len: 88  VirtAddr: 0x00ADB954 RVA: 0x00ADB954 token: 100681614 methodIndex: 54780 delegateWrapperIndex: 0 methodInvoker: 0
    private uint GetLogRandBits(int numBits)
    {
        //
        // Disasemble & Code
        // 0x00ADB954: STP x22, x21, [sp, #-0x30]! | stack[1152921513102236576] = ???;  stack[1152921513102236584] = ???;  //  dest_result_addr=1152921513102236576 |  dest_result_addr=1152921513102236584
        // 0x00ADB958: STP x20, x19, [sp, #0x10]  | stack[1152921513102236592] = ???;  stack[1152921513102236600] = ???;  //  dest_result_addr=1152921513102236592 |  dest_result_addr=1152921513102236600
        // 0x00ADB95C: STP x29, x30, [sp, #0x20]  | stack[1152921513102236608] = ???;  stack[1152921513102236616] = ???;  //  dest_result_addr=1152921513102236608 |  dest_result_addr=1152921513102236616
        // 0x00ADB960: ADD x29, sp, #0x20         | X29 = (1152921513102236576 + 32) = 1152921513102236608 (0x10000001FA5D5BC0);
        // 0x00ADB964: MOV x19, x0                | X19 = 1152921513102248624 (0x10000001FA5D8AB0);//ML01
        // 0x00ADB968: LDR x21, [x19, #0x10]      | X21 = this.RG; //P2                     
        // 0x00ADB96C: MOV w20, w1                | W20 = numBits;//m1                      
        // 0x00ADB970: CBNZ x21, #0xadb978        | if (this.RG != null) goto label_0;      
        if(this.RG != null)
        {
            goto label_0;
        }
        // 0x00ADB974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADB978: MOV x0, x21                | X0 = this.RG;//m1                       
        // 0x00ADB97C: MOV w1, w20                | W1 = numBits;//m1                       
        // 0x00ADB980: BL #0xadb884               | X0 = this.RG.GetRnd(numBits:  numBits); 
        uint val_1 = this.RG.GetRnd(numBits:  numBits);
        // 0x00ADB984: LDR x20, [x19, #0x10]      | X20 = this.RG; //P2                     
        // 0x00ADB988: MOV w19, w0                | W19 = val_1;//m1                        
        // 0x00ADB98C: CBNZ x20, #0xadb994        | if (this.RG != null) goto label_1;      
        if(this.RG != null)
        {
            goto label_1;
        }
        // 0x00ADB990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_1:
        // 0x00ADB994: MOV x0, x20                | X0 = this.RG;//m1                       
        // 0x00ADB998: MOV w1, w19                | W1 = val_1;//m1                         
        // 0x00ADB99C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB9A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB9A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00ADB9A8: B #0xadb884                | return this.RG.GetRnd(numBits:  val_1); 
        return this.RG.GetRnd(numBits:  val_1);
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB9AC (11385260), len: 96  VirtAddr: 0x00ADB9AC RVA: 0x00ADB9AC token: 100681615 methodIndex: 54781 delegateWrapperIndex: 0 methodInvoker: 0
    private uint GetOffset()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00ADB9AC: STP x22, x21, [sp, #-0x30]! | stack[1152921513102360864] = ???;  stack[1152921513102360872] = ???;  //  dest_result_addr=1152921513102360864 |  dest_result_addr=1152921513102360872
        // 0x00ADB9B0: STP x20, x19, [sp, #0x10]  | stack[1152921513102360880] = ???;  stack[1152921513102360888] = ???;  //  dest_result_addr=1152921513102360880 |  dest_result_addr=1152921513102360888
        // 0x00ADB9B4: STP x29, x30, [sp, #0x20]  | stack[1152921513102360896] = ???;  stack[1152921513102360904] = ???;  //  dest_result_addr=1152921513102360896 |  dest_result_addr=1152921513102360904
        // 0x00ADB9B8: ADD x29, sp, #0x20         | X29 = (1152921513102360864 + 32) = 1152921513102360896 (0x10000001FA5F4140);
        // 0x00ADB9BC: MOV x20, x0                | X20 = 1152921513102372912 (0x10000001FA5F7030);//ML01
        // 0x00ADB9C0: BL #0xadb858               | X0 = this.GetRndBit();                  
        uint val_1 = this.GetRndBit();
        // 0x00ADB9C4: MOV w21, w0                | W21 = val_1;//m1                        
        // 0x00ADB9C8: ORR w1, wzr, #4            | W1 = 4(0x4);                            
        // 0x00ADB9CC: MOV x0, x20                | X0 = 1152921513102372912 (0x10000001FA5F7030);//ML01
        // 0x00ADB9D0: BL #0xadb954               | X0 = this.GetLogRandBits(numBits:  4);  
        uint val_2 = this.GetLogRandBits(numBits:  4);
        // 0x00ADB9D4: MOV w19, w0                | W19 = val_2;//m1                        
        val_4 = val_2;
        // 0x00ADB9D8: CBZ w21, #0xadb9f8         | if (val_1 == 0) goto label_0;           
        if(val_1 == 0)
        {
            goto label_0;
        }
        // 0x00ADB9DC: LDR x20, [x20, #0x10]      | X20 = this.RG; //P2                     
        // 0x00ADB9E0: CBNZ x20, #0xadb9e8        | if (this.RG != null) goto label_1;      
        if(this.RG != null)
        {
            goto label_1;
        }
        // 0x00ADB9E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_1:
        // 0x00ADB9E8: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
        // 0x00ADB9EC: MOV x0, x20                | X0 = this.RG;//m1                       
        // 0x00ADB9F0: BL #0xadb884               | X0 = this.RG.GetRnd(numBits:  10);      
        uint val_3 = this.RG.GetRnd(numBits:  10);
        // 0x00ADB9F4: ORR w19, w0, w19, lsl #10  | W19 = (val_3 | (val_2) << 10);          
        val_4 = val_3 | (val_4 << 10);
        label_0:
        // 0x00ADB9F8: MOV w0, w19                | W0 = (val_3 | (val_2) << 10);//m1       
        // 0x00ADB9FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBA00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBA04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00ADBA08: RET                        |  return (System.UInt32)(val_3 | (val_2) << 10);
        return (uint)val_4;
        //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBA0C (11385356), len: 84  VirtAddr: 0x00ADBA0C RVA: 0x00ADBA0C token: 100681616 methodIndex: 54782 delegateWrapperIndex: 0 methodInvoker: 0
    private uint GetLen1()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00ADBA0C: STP x20, x19, [sp, #-0x20]! | stack[1152921513102481072] = ???;  stack[1152921513102481080] = ???;  //  dest_result_addr=1152921513102481072 |  dest_result_addr=1152921513102481080
        // 0x00ADBA10: STP x29, x30, [sp, #0x10]  | stack[1152921513102481088] = ???;  stack[1152921513102481096] = ???;  //  dest_result_addr=1152921513102481088 |  dest_result_addr=1152921513102481096
        // 0x00ADBA14: ADD x29, sp, #0x10         | X29 = (1152921513102481072 + 16) = 1152921513102481088 (0x10000001FA6116C0);
        // 0x00ADBA18: LDR x19, [x0, #0x10]       | X19 = this.RG; //P2                     
        // 0x00ADBA1C: CBZ x19, #0xadba34         | if (this.RG == null) goto label_0;      
        if(this.RG == null)
        {
            goto label_0;
        }
        // 0x00ADBA20: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00ADBA24: MOV x0, x19                | X0 = this.RG;//m1                       
        // 0x00ADBA28: BL #0xadb884               | X0 = this.RG.GetRnd(numBits:  2);       
        uint val_1 = this.RG.GetRnd(numBits:  2);
        // 0x00ADBA2C: MOV w20, w0                | W20 = val_1;//m1                        
        val_4 = val_1;
        // 0x00ADBA30: B #0xadba4c                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00ADBA34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x00ADBA38: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00ADBA3C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00ADBA40: BL #0xadb884               | X0 = 0.GetRnd(numBits:  2);             
        uint val_2 = 0.GetRnd(numBits:  2);
        // 0x00ADBA44: MOV w20, w0                | W20 = val_2;//m1                        
        val_4 = val_2;
        // 0x00ADBA48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_1:
        // 0x00ADBA4C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBA50: ADD w1, w20, #1            | W1 = (val_2 + 1);                       
        uint val_3 = val_4 + 1;
        // 0x00ADBA54: MOV x0, x19                | X0 = this.RG;//m1                       
        // 0x00ADBA58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBA5C: B #0xadb884                | return this.RG.GetRnd(numBits:  uint val_3 = val_4 + 1);
        return this.RG.GetRnd(numBits:  val_3);
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADBA60 (11385440), len: 84  VirtAddr: 0x00ADBA60 RVA: 0x00ADBA60 token: 100681617 methodIndex: 54783 delegateWrapperIndex: 0 methodInvoker: 0
    private uint GetLen2()
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        // 0x00ADBA60: STP x20, x19, [sp, #-0x20]! | stack[1152921513102601264] = ???;  stack[1152921513102601272] = ???;  //  dest_result_addr=1152921513102601264 |  dest_result_addr=1152921513102601272
        // 0x00ADBA64: STP x29, x30, [sp, #0x10]  | stack[1152921513102601280] = ???;  stack[1152921513102601288] = ???;  //  dest_result_addr=1152921513102601280 |  dest_result_addr=1152921513102601288
        // 0x00ADBA68: ADD x29, sp, #0x10         | X29 = (1152921513102601264 + 16) = 1152921513102601280 (0x10000001FA62EC40);
        // 0x00ADBA6C: LDR x19, [x0, #0x10]       | X19 = this.RG; //P2                     
        // 0x00ADBA70: CBZ x19, #0xadba88         | if (this.RG == null) goto label_0;      
        if(this.RG == null)
        {
            goto label_0;
        }
        // 0x00ADBA74: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00ADBA78: MOV x0, x19                | X0 = this.RG;//m1                       
        // 0x00ADBA7C: BL #0xadb884               | X0 = this.RG.GetRnd(numBits:  2);       
        uint val_1 = this.RG.GetRnd(numBits:  2);
        // 0x00ADBA80: MOV w20, w0                | W20 = val_1;//m1                        
        val_4 = val_1;
        // 0x00ADBA84: B #0xadbaa0                |  goto label_1;                          
        goto label_1;
        label_0:
        // 0x00ADBA88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x00ADBA8C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
        // 0x00ADBA90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00ADBA94: BL #0xadb884               | X0 = 0.GetRnd(numBits:  2);             
        uint val_2 = 0.GetRnd(numBits:  2);
        // 0x00ADBA98: MOV w20, w0                | W20 = val_2;//m1                        
        val_4 = val_2;
        // 0x00ADBA9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_1:
        // 0x00ADBAA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADBAA4: ADD w1, w20, #2            | W1 = (val_2 + 2);                       
        uint val_3 = val_4 + 2;
        // 0x00ADBAA8: MOV x0, x19                | X0 = this.RG;//m1                       
        // 0x00ADBAAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00ADBAB0: B #0xadb884                | return this.RG.GetRnd(numBits:  uint val_3 = val_4 + 2);
        return this.RG.GetRnd(numBits:  val_3);
    
    }
    //
    // Offset in libil2cpp.so: 0x00ADB520 (11384096), len: 452  VirtAddr: 0x00ADB520 RVA: 0x00ADB520 token: 100681618 methodIndex: 54784 delegateWrapperIndex: 0 methodInvoker: 0
    public void Generate()
    {
        //
        // Disasemble & Code
        //  | 
        uint val_13;
        //  | 
        uint val_14;
        //  | 
        uint val_15;
        //  | 
        var val_16;
        //  | 
        int val_17;
        // 0x00ADB520: STP x26, x25, [sp, #-0x50]! | stack[1152921513102803328] = ???;  stack[1152921513102803336] = ???;  //  dest_result_addr=1152921513102803328 |  dest_result_addr=1152921513102803336
        // 0x00ADB524: STP x24, x23, [sp, #0x10]  | stack[1152921513102803344] = ???;  stack[1152921513102803352] = ???;  //  dest_result_addr=1152921513102803344 |  dest_result_addr=1152921513102803352
        // 0x00ADB528: STP x22, x21, [sp, #0x20]  | stack[1152921513102803360] = ???;  stack[1152921513102803368] = ???;  //  dest_result_addr=1152921513102803360 |  dest_result_addr=1152921513102803368
        // 0x00ADB52C: STP x20, x19, [sp, #0x30]  | stack[1152921513102803376] = ???;  stack[1152921513102803384] = ???;  //  dest_result_addr=1152921513102803376 |  dest_result_addr=1152921513102803384
        // 0x00ADB530: STP x29, x30, [sp, #0x40]  | stack[1152921513102803392] = ???;  stack[1152921513102803400] = ???;  //  dest_result_addr=1152921513102803392 |  dest_result_addr=1152921513102803400
        // 0x00ADB534: ADD x29, sp, #0x40         | X29 = (1152921513102803328 + 64) = 1152921513102803392 (0x10000001FA6601C0);
        // 0x00ADB538: MOV x19, x0                | X19 = 1152921513102815408 (0x10000001FA6630B0);//ML01
        // 0x00ADB53C: LDR x20, [x19, #0x10]      | X20 = this.RG; //P2                     
        // 0x00ADB540: CBNZ x20, #0xadb548        | if (this.RG != null) goto label_0;      
        if(this.RG != null)
        {
            goto label_0;
        }
        // 0x00ADB544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00ADB548: STP wzr, wzr, [x20, #0x18] | this.RG.Value = null;  this.RG.NumBits = 0;  //  dest_result_addr=0 |  dest_result_addr=0
        this.RG.Value = 0;
        this.RG.NumBits = 0;
        // 0x00ADB54C: LDR w8, [x19, #0x18]       | W8 = this.Pos; //P2                     
        val_13 = this.Pos;
        // 0x00ADB550: LDR w9, [x19, #0x20]       | W9 = this.BufferSize; //P2              
        val_14 = this.BufferSize;
        // 0x00ADB554: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x00ADB558: STR w10, [x19, #0x1c]      | this.Rep0 = 0x1;                         //  dest_result_addr=1152921513102815436
        this.Rep0 = 1;
        // 0x00ADB55C: B #0xadb568                |  goto label_1;                          
        goto label_1;
        label_19:
        // 0x00ADB560: LDR w8, [x19, #0x18]       | W8 = this.Pos; //P2                     
        val_13 = this.Pos;
        // 0x00ADB564: LDR w9, [x19, #0x20]       | W9 = this.BufferSize; //P2              
        val_14 = this.BufferSize;
        label_1:
        // 0x00ADB568: CMP w8, w9                 | STATE = COMPARE(this.Pos, this.BufferSize)
        // 0x00ADB56C: B.HS #0xadb6cc             | if (val_13 >= val_14) goto label_2;     
        if(val_13 >= val_14)
        {
            goto label_2;
        }
        // 0x00ADB570: MOV x0, x19                | X0 = 1152921513102815408 (0x10000001FA6630B0);//ML01
        // 0x00ADB574: BL #0xadb858               | X0 = this.GetRndBit();                  
        uint val_1 = this.GetRndBit();
        // 0x00ADB578: LDR w22, [x19, #0x18]      | W22 = this.Pos; //P2                    
        val_15 = this.Pos;
        // 0x00ADB57C: CBZ w0, #0xadb5d4          | if (val_1 == 0) goto label_3;           
        if(val_1 == 0)
        {
            goto label_3;
        }
        // 0x00ADB580: CBZ w22, #0xadb5d0         | if (this.Pos == 0) goto label_4;        
        if(val_15 == 0)
        {
            goto label_4;
        }
        // 0x00ADB584: LDR x20, [x19, #0x10]      | X20 = this.RG; //P2                     
        // 0x00ADB588: CBNZ x20, #0xadb590        | if (this.RG != null) goto label_5;      
        if(this.RG != null)
        {
            goto label_5;
        }
        // 0x00ADB58C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_5:
        // 0x00ADB590: ORR w1, wzr, #3            | W1 = 3(0x3);                            
        // 0x00ADB594: MOV x0, x20                | X0 = this.RG;//m1                       
        // 0x00ADB598: BL #0xadb884               | X0 = this.RG.GetRnd(numBits:  3);       
        uint val_2 = this.RG.GetRnd(numBits:  3);
        // 0x00ADB59C: CBZ w0, #0xadb62c          | if (val_2 == 0) goto label_6;           
        if(val_2 == 0)
        {
            goto label_6;
        }
        label_7:
        // 0x00ADB5A0: MOV x0, x19                | X0 = 1152921513102815408 (0x10000001FA6630B0);//ML01
        // 0x00ADB5A4: BL #0xadb9ac               | X0 = this.GetOffset();                  
        uint val_3 = this.GetOffset();
        // 0x00ADB5A8: LDR w8, [x19, #0x18]       | W8 = this.Pos; //P2                     
        // 0x00ADB5AC: STR w0, [x19, #0x1c]       | this.Rep0 = val_3;                       //  dest_result_addr=1152921513102815436
        this.Rep0 = val_3;
        // 0x00ADB5B0: CMP w0, w8                 | STATE = COMPARE(val_3, this.Pos)        
        // 0x00ADB5B4: B.HS #0xadb5a0             | if (val_3 >= this.Pos) goto label_7;    
        if(val_3 >= this.Pos)
        {
            goto label_7;
        }
        // 0x00ADB5B8: ADD w8, w0, #1             | W8 = (val_3 + 1);                       
        uint val_4 = val_3 + 1;
        // 0x00ADB5BC: MOV x0, x19                | X0 = 1152921513102815408 (0x10000001FA6630B0);//ML01
        // 0x00ADB5C0: STR w8, [x19, #0x1c]       | this.Rep0 = (val_3 + 1);                 //  dest_result_addr=1152921513102815436
        this.Rep0 = val_4;
        // 0x00ADB5C4: BL #0xadba60               | X0 = this.GetLen2();                    
        uint val_5 = this.GetLen2();
        // 0x00ADB5C8: ADD w20, w0, #2            | W20 = (val_5 + 2);                      
        val_16 = val_5 + 2;
        // 0x00ADB5CC: B #0xadb638                |  goto label_8;                          
        goto label_8;
        label_4:
        // 0x00ADB5D0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        val_15 = 0;
        label_3:
        // 0x00ADB5D4: LDR x21, [x19, #0x28]      | X21 = this.Buffer; //P2                 
        // 0x00ADB5D8: LDR x20, [x19, #0x10]      | X20 = this.RG; //P2                     
        // 0x00ADB5DC: ADD w8, w22, #1            | W8 = (val_15 + 1);                      
        uint val_6 = val_15 + 1;
        // 0x00ADB5E0: STR w8, [x19, #0x18]       | this.Pos = (val_15 + 1);                 //  dest_result_addr=1152921513102815432
        this.Pos = val_6;
        // 0x00ADB5E4: CBNZ x20, #0xadb5ec        | if (this.RG != null) goto label_9;      
        if(this.RG != null)
        {
            goto label_9;
        }
        // 0x00ADB5E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_9:
        // 0x00ADB5EC: ORR w1, wzr, #8            | W1 = 8(0x8);                            
        // 0x00ADB5F0: MOV x0, x20                | X0 = this.RG;//m1                       
        // 0x00ADB5F4: BL #0xadb884               | X0 = this.RG.GetRnd(numBits:  8);       
        uint val_7 = this.RG.GetRnd(numBits:  8);
        // 0x00ADB5F8: MOV w20, w0                | W20 = val_7;//m1                        
        // 0x00ADB5FC: CBNZ x21, #0xadb604        | if (this.Buffer != null) goto label_10; 
        if(this.Buffer != null)
        {
            goto label_10;
        }
        // 0x00ADB600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
        label_10:
        // 0x00ADB604: LDR w8, [x21, #0x18]       | W8 = this.Buffer.Length; //P2           
        // 0x00ADB608: MOV w23, w22               | W23 = 0 (0x0);//ML01                    
        // 0x00ADB60C: CMP w22, w8                | STATE = COMPARE(0x0, this.Buffer.Length)
        // 0x00ADB610: B.LO #0xadb620             | if (val_15 < this.Buffer.Length) goto label_11;
        if(val_15 < this.Buffer.Length)
        {
            goto label_11;
        }
        // 0x00ADB614: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
        // 0x00ADB618: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB61C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
        label_11:
        // 0x00ADB620: ADD x8, x21, x23           | X8 = this.Buffer[0x0]; //PARR1          
        // 0x00ADB624: STRB w20, [x8, #0x20]      | this.Buffer[0x0][0] = val_7;             //  dest_result_addr=0
        this.Buffer[val_15] = val_7;
        // 0x00ADB628: B #0xadb560                |  goto label_19;                         
        goto label_19;
        label_6:
        // 0x00ADB62C: MOV x0, x19                | X0 = 1152921513102815408 (0x10000001FA6630B0);//ML01
        // 0x00ADB630: BL #0xadba0c               | X0 = this.GetLen1();                    
        uint val_8 = this.GetLen1();
        // 0x00ADB634: ADD w20, w0, #1            | W20 = (val_8 + 1);                      
        val_16 = val_8 + 1;
        label_8:
        // 0x00ADB638: CBZ w20, #0xadb560         | if ((val_8 + 1) == 0) goto label_19;    
        if(val_16 == 0)
        {
            goto label_19;
        }
        // 0x00ADB63C: LDR x8, [x19, #0x18]       | X8 = this.Pos; //P2                     
        // 0x00ADB640: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        var val_13 = 0;
        // 0x00ADB644: MOV w22, w8                | W22 = this.Pos;//m1                     
        label_18:
        // 0x00ADB648: LDR w9, [x19, #0x20]       | W9 = this.BufferSize; //P2              
        // 0x00ADB64C: CMP w22, w9                | STATE = COMPARE(this.Pos, this.BufferSize)
        // 0x00ADB650: B.HS #0xadb560             | if (this.Pos >= this.BufferSize) goto label_19;
        if(this.Pos >= this.BufferSize)
        {
            goto label_19;
        }
        // 0x00ADB654: LDR x23, [x19, #0x28]      | X23 = this.Buffer; //P2                 
        // 0x00ADB658: LSR x24, x8, #0x20         | X24 = (this.Pos >> 32);                 
        uint val_9 = this.Pos >> 32;
        // 0x00ADB65C: CBNZ x23, #0xadb664        | if (this.Buffer != null) goto label_15; 
        if(this.Buffer != null)
        {
            goto label_15;
        }
        // 0x00ADB660: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_15:
        // 0x00ADB664: LDR x8, [x23, #0x18]       | X8 = this.Buffer.Length; //P2           
        val_17 = this.Buffer.Length;
        // 0x00ADB668: SUB w9, w22, w24           | W9 = (this.Pos - (this.Pos >> 32));     
        uint val_10 = this.Pos - val_9;
        // 0x00ADB66C: SXTW x24, w9               | X24 = (long)(int)((this.Pos - (this.Pos >> 32)));
        // 0x00ADB670: CMP w9, w8                 | STATE = COMPARE((this.Pos - (this.Pos >> 32)), this.Buffer.Length)
        // 0x00ADB674: B.LO #0xadb688             | if (val_10 < val_17) goto label_16;     
        if(val_10 < val_17)
        {
            goto label_16;
        }
        // 0x00ADB678: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00ADB67C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB680: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        // 0x00ADB684: LDR x8, [x23, #0x18]       | X8 = this.Buffer.Length; //P2           
        val_17 = this.Buffer.Length;
        label_16:
        // 0x00ADB688: ADD x9, x23, x24           | X9 = this.Buffer[(long)(int)((this.Pos - (this.Pos >> 32)))]; //PARR1 
        // 0x00ADB68C: LDRB w24, [x9, #0x20]      | W24 = this.Buffer[(long)(int)((this.Pos - (this.Pos >> 32)))][0]
        byte val_12 = this.Buffer[(long)val_10];
        // 0x00ADB690: MOV w25, w22               | W25 = this.Pos;//m1                     
        // 0x00ADB694: CMP w22, w8                | STATE = COMPARE(this.Pos, this.Buffer.Length)
        // 0x00ADB698: B.LO #0xadb6a8             | if (this.Pos < val_17) goto label_17;   
        if(this.Pos < val_17)
        {
            goto label_17;
        }
        // 0x00ADB69C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
        // 0x00ADB6A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00ADB6A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
        label_17:
        // 0x00ADB6A8: ADD x8, x23, x25           | X8 = this.Buffer[this.Pos]; //PARR1     
        // 0x00ADB6AC: STRB w24, [x8, #0x20]      | this.Buffer[this.Pos][0] = this.Buffer[(long)(int)((this.Pos - (this.Pos >> 32)))][0];  //  dest_result_addr=0
        this.Buffer[this.Pos] = val_12;
        // 0x00ADB6B0: LDR x8, [x19, #0x18]       | X8 = this.Pos; //P2                     
        // 0x00ADB6B4: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_13 = val_13 + 1;
        // 0x00ADB6B8: CMP w21, w20               | STATE = COMPARE((0 + 1), (val_8 + 1))   
        // 0x00ADB6BC: ADD w22, w8, #1            | W22 = (this.Pos + 1);                   
        uint val_11 = this.Pos + 1;
        // 0x00ADB6C0: STR w22, [x19, #0x18]      | this.Pos = (this.Pos + 1);               //  dest_result_addr=1152921513102815432
        this.Pos = val_11;
        // 0x00ADB6C4: B.LO #0xadb648             | if (0 < val_16) goto label_18;          
        if(val_13 < val_16)
        {
            goto label_18;
        }
        // 0x00ADB6C8: B #0xadb560                |  goto label_19;                         
        goto label_19;
        label_2:
        // 0x00ADB6CC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x00ADB6D0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x00ADB6D4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x00ADB6D8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x00ADB6DC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x00ADB6E0: RET                        |  return;                                
        return;
    
    }

}
