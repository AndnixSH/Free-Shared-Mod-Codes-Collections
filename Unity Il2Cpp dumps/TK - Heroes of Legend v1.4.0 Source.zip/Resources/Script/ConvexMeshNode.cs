using UnityEngine;

namespace Pathfinding
{
    public class ConvexMeshNode : MeshNode
    {
        // Fields
        private int[] indices; //  0x00000040
        protected static Pathfinding.INavmeshHolder[] navmeshHolders; // static_offset: 0x00000000
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0168AA54 (23636564), len: 128  VirtAddr: 0x0168AA54 RVA: 0x0168AA54 token: 100683034 methodIndex: 49934 delegateWrapperIndex: 0 methodInvoker: 0
        public ConvexMeshNode(AstarPath astar)
        {
            //
            // Disasemble & Code
            // 0x0168AA54: STP x22, x21, [sp, #-0x30]! | stack[1152921513376131552] = ???;  stack[1152921513376131560] = ???;  //  dest_result_addr=1152921513376131552 |  dest_result_addr=1152921513376131560
            // 0x0168AA58: STP x20, x19, [sp, #0x10]  | stack[1152921513376131568] = ???;  stack[1152921513376131576] = ???;  //  dest_result_addr=1152921513376131568 |  dest_result_addr=1152921513376131576
            // 0x0168AA5C: STP x29, x30, [sp, #0x20]  | stack[1152921513376131584] = ???;  stack[1152921513376131592] = ???;  //  dest_result_addr=1152921513376131584 |  dest_result_addr=1152921513376131592
            // 0x0168AA60: ADD x29, sp, #0x20         | X29 = (1152921513376131552 + 32) = 1152921513376131584 (0x100000020AB0AA00);
            // 0x0168AA64: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x0168AA68: LDRB w8, [x21, #0x109]     | W8 = (bool)static_value_03738109;       
            // 0x0168AA6C: MOV x20, x1                | X20 = astar;//m1                        
            // 0x0168AA70: MOV x19, x0                | X19 = 1152921513376143600 (0x100000020AB0D8F0);//ML01
            // 0x0168AA74: TBNZ w8, #0, #0x168aa90    | if (static_value_03738109 == true) goto label_0;
            // 0x0168AA78: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x0168AA7C: LDR x8, [x8, #0x128]       | X8 = 0x2B92C8C;                         
            // 0x0168AA80: LDR w0, [x8]               | W0 = 0x21E8;                            
            // 0x0168AA84: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E8, ????);     
            // 0x0168AA88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168AA8C: STRB w8, [x21, #0x109]     | static_value_03738109 = true;            //  dest_result_addr=57901321
            label_0:
            // 0x0168AA90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168AA94: MOV x0, x19                | X0 = 1152921513376143600 (0x100000020AB0D8F0);//ML01
            // 0x0168AA98: MOV x1, x20                | X1 = astar;//m1                         
            // 0x0168AA9C: BL #0x1557388              | this..ctor(astar:  astar);              
            // 0x0168AAA0: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x0168AAA4: LDR x8, [x8, #0x2d8]       | X8 = 1152921504962510832;               
            // 0x0168AAA8: LDR x20, [x8]              | X20 = typeof(System.Int32[]);           
            // 0x0168AAAC: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x0168AAB0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Int32[]), ????);
            // 0x0168AAB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168AAB8: MOV x0, x20                | X0 = 1152921504962510832 (0x100000001532FFF0);//ML01
            // 0x0168AABC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Int32[]), ????);
            // 0x0168AAC0: STR x0, [x19, #0x40]       | this.indices = typeof(System.Int32[]);   //  dest_result_addr=1152921513376143664
            this.indices = null;
            // 0x0168AAC4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168AAC8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0168AACC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168AAD0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168AAD4 (23636692), len: 112  VirtAddr: 0x0168AAD4 RVA: 0x0168AAD4 token: 100683035 methodIndex: 49935 delegateWrapperIndex: 0 methodInvoker: 0
        private static ConvexMeshNode()
        {
            //
            // Disasemble & Code
            // 0x0168AAD4: STP x20, x19, [sp, #-0x20]! | stack[1152921513376247664] = ???;  stack[1152921513376247672] = ???;  //  dest_result_addr=1152921513376247664 |  dest_result_addr=1152921513376247672
            // 0x0168AAD8: STP x29, x30, [sp, #0x10]  | stack[1152921513376247680] = ???;  stack[1152921513376247688] = ???;  //  dest_result_addr=1152921513376247680 |  dest_result_addr=1152921513376247688
            // 0x0168AADC: ADD x29, sp, #0x10         | X29 = (1152921513376247664 + 16) = 1152921513376247680 (0x100000020AB26F80);
            // 0x0168AAE0: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168AAE4: LDRB w8, [x19, #0x10a]     | W8 = (bool)static_value_0373810A;       
            // 0x0168AAE8: TBNZ w8, #0, #0x168ab04    | if (static_value_0373810A == true) goto label_0;
            // 0x0168AAEC: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x0168AAF0: LDR x8, [x8, #0x480]       | X8 = 0x2B92C88;                         
            // 0x0168AAF4: LDR w0, [x8]               | W0 = 0x21E7;                            
            // 0x0168AAF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E7, ????);     
            // 0x0168AAFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168AB00: STRB w8, [x19, #0x10a]     | static_value_0373810A = true;            //  dest_result_addr=57901322
            label_0:
            // 0x0168AB04: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x0168AB08: LDR x8, [x8, #0xc10]       | X8 = 1152921504845504512;               
            // 0x0168AB0C: ADRP x9, #0x360e000        | X9 = 56680448 (0x360E000);              
            // 0x0168AB10: LDR x8, [x8]               | X8 = typeof(Pathfinding.ConvexMeshNode);
            // 0x0168AB14: LDR x9, [x9, #0xe18]       | X9 = 1152921513373850032;               
            // 0x0168AB18: LDR x20, [x8, #0xa0]       | X20 = Pathfinding.ConvexMeshNode.__il2cppRuntimeField_static_fields;
            // 0x0168AB1C: LDR x19, [x9]              | X19 = typeof(Pathfinding.INavmeshHolder[]);
            // 0x0168AB20: MOV x0, x19                | X0 = 1152921513373850032 (0x100000020A8DD9B0);//ML01
            // 0x0168AB24: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.INavmeshHolder[]), ????);
            // 0x0168AB28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168AB2C: MOV x0, x19                | X0 = 1152921513373850032 (0x100000020A8DD9B0);//ML01
            // 0x0168AB30: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.INavmeshHolder[]), ????);
            // 0x0168AB34: STR x0, [x20]              | Pathfinding.ConvexMeshNode.navmeshHolders = typeof(Pathfinding.INavmeshHolder[]);  //  dest_result_addr=1152921504845508608
            Pathfinding.ConvexMeshNode.navmeshHolders = null;
            // 0x0168AB38: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168AB3C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0168AB40: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168AB44 (23636804), len: 160  VirtAddr: 0x0168AB44 RVA: 0x0168AB44 token: 100683036 methodIndex: 49936 delegateWrapperIndex: 0 methodInvoker: 0
        protected static Pathfinding.INavmeshHolder GetNavmeshHolder(uint graphIndex)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x0168AB44: STP x22, x21, [sp, #-0x30]! | stack[1152921513376359648] = ???;  stack[1152921513376359656] = ???;  //  dest_result_addr=1152921513376359648 |  dest_result_addr=1152921513376359656
            // 0x0168AB48: STP x20, x19, [sp, #0x10]  | stack[1152921513376359664] = ???;  stack[1152921513376359672] = ???;  //  dest_result_addr=1152921513376359664 |  dest_result_addr=1152921513376359672
            // 0x0168AB4C: STP x29, x30, [sp, #0x20]  | stack[1152921513376359680] = ???;  stack[1152921513376359688] = ???;  //  dest_result_addr=1152921513376359680 |  dest_result_addr=1152921513376359688
            // 0x0168AB50: ADD x29, sp, #0x20         | X29 = (1152921513376359648 + 32) = 1152921513376359680 (0x100000020AB42500);
            // 0x0168AB54: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168AB58: LDRB w8, [x20, #0x10b]     | W8 = (bool)static_value_0373810B;       
            // 0x0168AB5C: MOV w19, w1                | W19 = W1;//m1                           
            // 0x0168AB60: TBNZ w8, #0, #0x168ab7c    | if (static_value_0373810B == true) goto label_0;
            // 0x0168AB64: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x0168AB68: LDR x8, [x8, #0xb58]       | X8 = 0x2B92C98;                         
            // 0x0168AB6C: LDR w0, [x8]               | W0 = 0x21EB;                            
            // 0x0168AB70: BL #0x2782188              | X0 = sub_2782188( ?? 0x21EB, ????);     
            // 0x0168AB74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168AB78: STRB w8, [x20, #0x10b]     | static_value_0373810B = true;            //  dest_result_addr=57901323
            label_0:
            // 0x0168AB7C: ADRP x20, #0x360d000       | X20 = 56676352 (0x360D000);             
            // 0x0168AB80: LDR x20, [x20, #0xc10]     | X20 = 1152921504845504512;              
            // 0x0168AB84: LDR x0, [x20]              | X0 = typeof(Pathfinding.ConvexMeshNode);
            val_2 = null;
            // 0x0168AB88: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.ConvexMeshNode.__il2cppRuntimeField_10A;
            // 0x0168AB8C: TBZ w8, #0, #0x168aba0     | if (Pathfinding.ConvexMeshNode.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168AB90: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.ConvexMeshNode.__il2cppRuntimeField_cctor_finished;
            // 0x0168AB94: CBNZ w8, #0x168aba0        | if (Pathfinding.ConvexMeshNode.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168AB98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.ConvexMeshNode), ????);
            // 0x0168AB9C: LDR x0, [x20]              | X0 = typeof(Pathfinding.ConvexMeshNode);
            val_2 = null;
            label_2:
            // 0x0168ABA0: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.ConvexMeshNode.__il2cppRuntimeField_static_fields;
            // 0x0168ABA4: LDR x20, [x8]              | X20 = Pathfinding.ConvexMeshNode.navmeshHolders;
            // 0x0168ABA8: CBNZ x20, #0x168abb0       | if (Pathfinding.ConvexMeshNode.navmeshHolders != null) goto label_3;
            if(Pathfinding.ConvexMeshNode.navmeshHolders != null)
            {
                goto label_3;
            }
            // 0x0168ABAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.ConvexMeshNode), ????);
            label_3:
            // 0x0168ABB0: LDR w8, [x20, #0x18]       | W8 = Pathfinding.ConvexMeshNode.navmeshHolders.Length;
            // 0x0168ABB4: MOV w21, w19               | W21 = W1;//m1                           
            // 0x0168ABB8: CMP w8, w19                | STATE = COMPARE(Pathfinding.ConvexMeshNode.navmeshHolders.Length, W1)
            // 0x0168ABBC: B.HI #0x168abcc            | if (Pathfinding.ConvexMeshNode.navmeshHolders.Length > W1) goto label_4;
            if(Pathfinding.ConvexMeshNode.navmeshHolders.Length > W1)
            {
                goto label_4;
            }
            // 0x0168ABC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.ConvexMeshNode), ????);
            // 0x0168ABC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168ABC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.ConvexMeshNode), ????);
            label_4:
            // 0x0168ABCC: ADD x8, x20, x21, lsl #3   | X8 = (Pathfinding.ConvexMeshNode.navmeshHolders + (W1) << 3);
            Pathfinding.INavmeshHolder[] val_1 = Pathfinding.ConvexMeshNode.navmeshHolders + ((W1) << 3);
            // 0x0168ABD0: LDR x0, [x8, #0x20]        | X0 = (Pathfinding.ConvexMeshNode.navmeshHolders + (W1) << 3) + 32; //  not_find_field!2:32
            // 0x0168ABD4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168ABD8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0168ABDC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168ABE0: RET                        |  return (Pathfinding.INavmeshHolder)(Pathfinding.ConvexMeshNode.navmeshHolders + (W1) << 3) + 32;
            return (Pathfinding.INavmeshHolder)(Pathfinding.ConvexMeshNode.navmeshHolders + (W1) << 3) + 32;
            //  |  // // {name=val_0, type=Pathfinding.INavmeshHolder, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168ABE4 (23636964), len: 12  VirtAddr: 0x0168ABE4 RVA: 0x0168ABE4 token: 100683037 methodIndex: 49937 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetPosition(Pathfinding.Int3 p)
        {
            //
            // Disasemble & Code
            // 0x0168ABE4: STR x1, [x0, #0x20]        | mem[1152921513376483728] = p.x; mem[1152921513376483732] = p.y;  //  dest_result_addr=1152921513376483728 dest_result_addr=1152921513376483732
            mem[1152921513376483728] = p.x;
            mem[1152921513376483732] = p.y;
            // 0x0168ABE8: STR w2, [x0, #0x28]        | mem[1152921513376483736] = p.z;          //  dest_result_addr=1152921513376483736
            mem[1152921513376483736] = p.z;
            // 0x0168ABEC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168ABF0 (23636976), len: 84  VirtAddr: 0x0168ABF0 RVA: 0x0168ABF0 token: 100683038 methodIndex: 49938 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetVertexIndex(int i)
        {
            //
            // Disasemble & Code
            // 0x0168ABF0: STP x22, x21, [sp, #-0x30]! | stack[1152921513376620512] = ???;  stack[1152921513376620520] = ???;  //  dest_result_addr=1152921513376620512 |  dest_result_addr=1152921513376620520
            // 0x0168ABF4: STP x20, x19, [sp, #0x10]  | stack[1152921513376620528] = ???;  stack[1152921513376620536] = ???;  //  dest_result_addr=1152921513376620528 |  dest_result_addr=1152921513376620536
            // 0x0168ABF8: STP x29, x30, [sp, #0x20]  | stack[1152921513376620544] = ???;  stack[1152921513376620552] = ???;  //  dest_result_addr=1152921513376620544 |  dest_result_addr=1152921513376620552
            // 0x0168ABFC: ADD x29, sp, #0x20         | X29 = (1152921513376620512 + 32) = 1152921513376620544 (0x100000020AB82000);
            // 0x0168AC00: LDR x20, [x0, #0x40]       | X20 = this.indices; //P2                
            // 0x0168AC04: MOV w19, w1                | W19 = i;//m1                            
            // 0x0168AC08: CBNZ x20, #0x168ac10       | if (this.indices != null) goto label_0; 
            if(this.indices != null)
            {
                goto label_0;
            }
            // 0x0168AC0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0168AC10: LDR w8, [x20, #0x18]       | W8 = this.indices.Length; //P2          
            // 0x0168AC14: SXTW x21, w19              | X21 = (long)(int)(i);                   
            // 0x0168AC18: CMP w8, w19                | STATE = COMPARE(this.indices.Length, i) 
            // 0x0168AC1C: B.HI #0x168ac2c            | if (this.indices.Length > i) goto label_1;
            if(this.indices.Length > i)
            {
                goto label_1;
            }
            // 0x0168AC20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0168AC24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168AC28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_1:
            // 0x0168AC2C: ADD x8, x20, x21, lsl #2   | X8 = this.indices[(long)(int)(i)]; //PARR1 
            // 0x0168AC30: LDR w0, [x8, #0x20]        | W0 = this.indices[(long)(int)(i)][0]    
            int val_1 = this.indices[(long)i];
            // 0x0168AC34: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168AC38: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0168AC3C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168AC40: RET                        |  return (System.Int32)this.indices[(long)(int)(i)][0];
            return val_1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168AC44 (23637060), len: 260  VirtAddr: 0x0168AC44 RVA: 0x0168AC44 token: 100683039 methodIndex: 49939 delegateWrapperIndex: 0 methodInvoker: 0
        public override Pathfinding.Int3 GetVertex(int i)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x0168AC44: STP x22, x21, [sp, #-0x30]! | stack[1152921513376773472] = ???;  stack[1152921513376773480] = ???;  //  dest_result_addr=1152921513376773472 |  dest_result_addr=1152921513376773480
            // 0x0168AC48: STP x20, x19, [sp, #0x10]  | stack[1152921513376773488] = ???;  stack[1152921513376773496] = ???;  //  dest_result_addr=1152921513376773488 |  dest_result_addr=1152921513376773496
            // 0x0168AC4C: STP x29, x30, [sp, #0x20]  | stack[1152921513376773504] = ???;  stack[1152921513376773512] = ???;  //  dest_result_addr=1152921513376773504 |  dest_result_addr=1152921513376773512
            // 0x0168AC50: ADD x29, sp, #0x20         | X29 = (1152921513376773472 + 32) = 1152921513376773504 (0x100000020ABA7580);
            // 0x0168AC54: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168AC58: LDRB w8, [x19, #0x10c]     | W8 = (bool)static_value_0373810C;       
            // 0x0168AC5C: MOV w20, w1                | W20 = i;//m1                            
            // 0x0168AC60: MOV x21, x0                | X21 = 1152921513376785520 (0x100000020ABAA470);//ML01
            // 0x0168AC64: TBNZ w8, #0, #0x168ac80    | if (static_value_0373810C == true) goto label_0;
            // 0x0168AC68: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x0168AC6C: LDR x8, [x8, #0x7b0]       | X8 = 0x2B92C9C;                         
            // 0x0168AC70: LDR w0, [x8]               | W0 = 0x21EC;                            
            // 0x0168AC74: BL #0x2782188              | X0 = sub_2782188( ?? 0x21EC, ????);     
            // 0x0168AC78: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168AC7C: STRB w8, [x19, #0x10c]     | static_value_0373810C = true;            //  dest_result_addr=57901324
            label_0:
            // 0x0168AC80: ADRP x8, #0x360d000        | X8 = 56676352 (0x360D000);              
            // 0x0168AC84: LDR x8, [x8, #0xc10]       | X8 = 1152921504845504512;               
            // 0x0168AC88: LDRB w19, [x21, #0x17]     | 
            // 0x0168AC8C: LDR x0, [x8]               | X0 = typeof(Pathfinding.ConvexMeshNode);
            // 0x0168AC90: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.ConvexMeshNode.__il2cppRuntimeField_10A;
            // 0x0168AC94: TBZ w8, #0, #0x168aca4     | if (Pathfinding.ConvexMeshNode.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168AC98: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.ConvexMeshNode.__il2cppRuntimeField_cctor_finished;
            // 0x0168AC9C: CBNZ w8, #0x168aca4        | if (Pathfinding.ConvexMeshNode.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168ACA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.ConvexMeshNode), ????);
            label_2:
            // 0x0168ACA4: MOV w1, w19                | W1 = 57901056 (0x3738000);//ML01        
            // 0x0168ACA8: BL #0x168ab44              | X0 = Pathfinding.ConvexMeshNode.GetNavmeshHolder(graphIndex:  238657536);
            Pathfinding.INavmeshHolder val_1 = Pathfinding.ConvexMeshNode.GetNavmeshHolder(graphIndex:  238657536);
            // 0x0168ACAC: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x0168ACB0: MOV x0, x21                | X0 = 1152921513376785520 (0x100000020ABAA470);//ML01
            // 0x0168ACB4: MOV w1, w20                | W1 = i;//m1                             
            // 0x0168ACB8: BL #0x168abf0              | X0 = this.GetVertexIndex(i:  i);        
            int val_2 = this.GetVertexIndex(i:  i);
            // 0x0168ACBC: MOV w20, w0                | W20 = val_2;//m1                        
            // 0x0168ACC0: CBNZ x19, #0x168acc8       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x0168ACC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x0168ACC8: ADRP x9, #0x35e8000        | X9 = 56524800 (0x35E8000);              
            // 0x0168ACCC: LDR x8, [x19]              | X8 = typeof(Pathfinding.INavmeshHolder);
            // 0x0168ACD0: LDR x9, [x9, #0x280]       | X9 = 1152921504845398016;               
            // 0x0168ACD4: LDR x1, [x9]               | X1 = typeof(Pathfinding.INavmeshHolder);
            // 0x0168ACD8: LDRH w9, [x8, #0x102]      | W9 = Pathfinding.INavmeshHolder.__il2cppRuntimeField_interface_offsets_count;
            // 0x0168ACDC: CBZ x9, #0x168ad08         | if (Pathfinding.INavmeshHolder.__il2cppRuntimeField_interface_offsets_count == 0) goto label_4;
            // 0x0168ACE0: LDR x10, [x8, #0x98]       | X10 = Pathfinding.INavmeshHolder.__il2cppRuntimeField_interfaceOffsets;
            // 0x0168ACE4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x0168ACE8: ADD x10, x10, #8           | X10 = (Pathfinding.INavmeshHolder.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504845434888 (0x100000000E389008);
            label_6:
            // 0x0168ACEC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x0168ACF0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(Pathfinding.INavmeshHolder))
            // 0x0168ACF4: B.EQ #0x168ad18            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_5;
            // 0x0168ACF8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x0168ACFC: ADD x10, x10, #0x10        | X10 = (1152921504845434888 + 16) = 1152921504845434904 (0x100000000E389018);
            // 0x0168AD00: CMP x11, x9                | STATE = COMPARE((0 + 1), Pathfinding.INavmeshHolder.__il2cppRuntimeField_interface_offsets_count)
            // 0x0168AD04: B.LO #0x168acec            | if (0 < Pathfinding.INavmeshHolder.__il2cppRuntimeField_interface_offsets_count) goto label_6;
            label_4:
            // 0x0168AD08: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x0168AD0C: MOV x0, x19                | X0 = val_1;//m1                         
            val_4 = val_1;
            // 0x0168AD10: BL #0x2776c24              | X0 = sub_2776C24( ?? val_1, ????);      
            // 0x0168AD14: B #0x168ad24               |  goto label_7;                          
            goto label_7;
            label_5:
            // 0x0168AD18: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x0168AD1C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504845398016 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x0168AD20: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504845398016 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_7:
            // 0x0168AD24: LDP x8, x2, [x0]           | X8 = val_2; X2 = val_2 + 8;              //  | 
            // 0x0168AD28: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x0168AD2C: MOV w1, w20                | W1 = val_2;//m1                         
            int val_5 = val_2;
            // 0x0168AD30: BLR x8                     | X0 = val_2();                           
            // 0x0168AD34: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168AD38: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x0168AD3C: AND x1, x1, #0xffffffff    | X1 = (val_2 & 4294967295);              
            val_5 = val_5 & 4294967295;
            // 0x0168AD40: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168AD44: RET                        |  return new Pathfinding.Int3() {x = val_1, y = val_1, z = val_2};
            return new Pathfinding.Int3() {x = val_1, y = val_1, z = val_5};
            //  |  // // {name=val_0.x, type=System.Int32, size=4, nGRN=0 offset=0 }
            //  |  // // {name=val_0.y, type=System.Int32, size=4, nGRN=0 offset=4 }
            //  |  // // {name=val_0.z, type=System.Int32, size=4, nGRN=1 offset=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168AD48 (23637320), len: 40  VirtAddr: 0x0168AD48 RVA: 0x0168AD48 token: 100683040 methodIndex: 49940 delegateWrapperIndex: 0 methodInvoker: 0
        public override int GetVertexCount()
        {
            //
            // Disasemble & Code
            // 0x0168AD48: STP x20, x19, [sp, #-0x20]! | stack[1152921513376926448] = ???;  stack[1152921513376926456] = ???;  //  dest_result_addr=1152921513376926448 |  dest_result_addr=1152921513376926456
            // 0x0168AD4C: STP x29, x30, [sp, #0x10]  | stack[1152921513376926464] = ???;  stack[1152921513376926472] = ???;  //  dest_result_addr=1152921513376926464 |  dest_result_addr=1152921513376926472
            // 0x0168AD50: ADD x29, sp, #0x10         | X29 = (1152921513376926448 + 16) = 1152921513376926464 (0x100000020ABCCB00);
            // 0x0168AD54: LDR x19, [x0, #0x40]       | X19 = this.indices; //P2                
            // 0x0168AD58: CBNZ x19, #0x168ad60       | if (this.indices != null) goto label_0; 
            if(this.indices != null)
            {
                goto label_0;
            }
            // 0x0168AD5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0168AD60: LDR w0, [x19, #0x18]       | W0 = this.indices.Length; //P2          
            // 0x0168AD64: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0168AD68: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0168AD6C: RET                        |  return (System.Int32)this.indices.Length;
            return this.indices.Length;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168AD70 (23637360), len: 100  VirtAddr: 0x0168AD70 RVA: 0x0168AD70 token: 100683041 methodIndex: 49941 delegateWrapperIndex: 0 methodInvoker: 0
        public override UnityEngine.Vector3 ClosestPointOnNode(UnityEngine.Vector3 p)
        {
            //
            // Disasemble & Code
            // 0x0168AD70: STP x20, x19, [sp, #-0x20]! | stack[1152921513377076336] = ???;  stack[1152921513377076344] = ???;  //  dest_result_addr=1152921513377076336 |  dest_result_addr=1152921513377076344
            // 0x0168AD74: STP x29, x30, [sp, #0x10]  | stack[1152921513377076352] = ???;  stack[1152921513377076360] = ???;  //  dest_result_addr=1152921513377076352 |  dest_result_addr=1152921513377076360
            // 0x0168AD78: ADD x29, sp, #0x10         | X29 = (1152921513377076336 + 16) = 1152921513377076352 (0x100000020ABF1480);
            // 0x0168AD7C: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168AD80: LDRB w8, [x19, #0x10d]     | W8 = (bool)static_value_0373810D;       
            // 0x0168AD84: TBNZ w8, #0, #0x168ada0    | if (static_value_0373810D == true) goto label_0;
            // 0x0168AD88: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x0168AD8C: LDR x8, [x8, #0x7e8]       | X8 = 0x2B92C90;                         
            // 0x0168AD90: LDR w0, [x8]               | W0 = 0x21E9;                            
            // 0x0168AD94: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E9, ????);     
            // 0x0168AD98: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168AD9C: STRB w8, [x19, #0x10d]     | static_value_0373810D = true;            //  dest_result_addr=57901325
            label_0:
            // 0x0168ADA0: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0168ADA4: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x0168ADA8: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_1 = null;
            // 0x0168ADAC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x0168ADB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168ADB4: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x0168ADB8: BL #0x17014c0              | .ctor();                                
            val_1 = new System.NotImplementedException();
            // 0x0168ADBC: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x0168ADC0: LDR x8, [x8, #0x2c0]       | X8 = 1152921513377063344;               
            // 0x0168ADC4: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x0168ADC8: LDR x1, [x8]               | X1 = public UnityEngine.Vector3 Pathfinding.ConvexMeshNode::ClosestPointOnNode(UnityEngine.Vector3 p);
            // 0x0168ADCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x0168ADD0: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x0168ADD4 (23637460), len: 100  VirtAddr: 0x0168ADD4 RVA: 0x0168ADD4 token: 100683042 methodIndex: 49942 delegateWrapperIndex: 0 methodInvoker: 0
        public override UnityEngine.Vector3 ClosestPointOnNodeXZ(UnityEngine.Vector3 p)
        {
            //
            // Disasemble & Code
            // 0x0168ADD4: STP x20, x19, [sp, #-0x20]! | stack[1152921513377189360] = ???;  stack[1152921513377189368] = ???;  //  dest_result_addr=1152921513377189360 |  dest_result_addr=1152921513377189368
            // 0x0168ADD8: STP x29, x30, [sp, #0x10]  | stack[1152921513377189376] = ???;  stack[1152921513377189384] = ???;  //  dest_result_addr=1152921513377189376 |  dest_result_addr=1152921513377189384
            // 0x0168ADDC: ADD x29, sp, #0x10         | X29 = (1152921513377189360 + 16) = 1152921513377189376 (0x100000020AC0CE00);
            // 0x0168ADE0: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168ADE4: LDRB w8, [x19, #0x10e]     | W8 = (bool)static_value_0373810E;       
            // 0x0168ADE8: TBNZ w8, #0, #0x168ae04    | if (static_value_0373810E == true) goto label_0;
            // 0x0168ADEC: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x0168ADF0: LDR x8, [x8, #0x908]       | X8 = 0x2B92C94;                         
            // 0x0168ADF4: LDR w0, [x8]               | W0 = 0x21EA;                            
            // 0x0168ADF8: BL #0x2782188              | X0 = sub_2782188( ?? 0x21EA, ????);     
            // 0x0168ADFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168AE00: STRB w8, [x19, #0x10e]     | static_value_0373810E = true;            //  dest_result_addr=57901326
            label_0:
            // 0x0168AE04: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0168AE08: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x0168AE0C: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_1 = null;
            // 0x0168AE10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x0168AE14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168AE18: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x0168AE1C: BL #0x17014c0              | .ctor();                                
            val_1 = new System.NotImplementedException();
            // 0x0168AE20: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x0168AE24: LDR x8, [x8, #0x338]       | X8 = 1152921513377176368;               
            // 0x0168AE28: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x0168AE2C: LDR x1, [x8]               | X1 = public UnityEngine.Vector3 Pathfinding.ConvexMeshNode::ClosestPointOnNodeXZ(UnityEngine.Vector3 p);
            // 0x0168AE30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x0168AE34: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x0168AE38 (23637560), len: 168  VirtAddr: 0x0168AE38 RVA: 0x0168AE38 token: 100683043 methodIndex: 49943 delegateWrapperIndex: 0 methodInvoker: 0
        public override void GetConnections(Pathfinding.GraphNodeDelegate del)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x0168AE38: STP x24, x23, [sp, #-0x40]! | stack[1152921513377305424] = ???;  stack[1152921513377305432] = ???;  //  dest_result_addr=1152921513377305424 |  dest_result_addr=1152921513377305432
            // 0x0168AE3C: STP x22, x21, [sp, #0x10]  | stack[1152921513377305440] = ???;  stack[1152921513377305448] = ???;  //  dest_result_addr=1152921513377305440 |  dest_result_addr=1152921513377305448
            // 0x0168AE40: STP x20, x19, [sp, #0x20]  | stack[1152921513377305456] = ???;  stack[1152921513377305464] = ???;  //  dest_result_addr=1152921513377305456 |  dest_result_addr=1152921513377305464
            // 0x0168AE44: STP x29, x30, [sp, #0x30]  | stack[1152921513377305472] = ???;  stack[1152921513377305480] = ???;  //  dest_result_addr=1152921513377305472 |  dest_result_addr=1152921513377305480
            // 0x0168AE48: ADD x29, sp, #0x30         | X29 = (1152921513377305424 + 48) = 1152921513377305472 (0x100000020AC29380);
            // 0x0168AE4C: MOV x19, x0                | X19 = 1152921513377317488 (0x100000020AC2C270);//ML01
            // 0x0168AE50: LDR x21, [x19, #0x30]      | 
            // 0x0168AE54: MOV x20, x1                | X20 = del;//m1                          
            // 0x0168AE58: CBZ x21, #0x168aecc        | if (X21 == 0) goto label_3;             
            if(X21 == 0)
            {
                goto label_3;
            }
            // 0x0168AE5C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x0168AE60: B #0x168ae7c               |  goto label_1;                          
            goto label_1;
            label_7:
            // 0x0168AE64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168AE68: MOV x0, x20                | X0 = del;//m1                           
            // 0x0168AE6C: MOV x1, x21                | X1 = X21;//m1                           
            // 0x0168AE70: BL #0x168aee0              | del.Invoke(node:  X21);                 
            del.Invoke(node:  X21);
            // 0x0168AE74: LDR x21, [x19, #0x30]      | 
            // 0x0168AE78: ADD w22, w22, #1           | W22 = (val_3 + 1) = val_3 (0x00000001); 
            val_3 = 1;
            label_1:
            // 0x0168AE7C: CBNZ x21, #0x168ae84       | if (X21 != 0) goto label_2;             
            if(X21 != 0)
            {
                goto label_2;
            }
            // 0x0168AE80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? del, ????);        
            label_2:
            // 0x0168AE84: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
            // 0x0168AE88: CMP w22, w8                | STATE = COMPARE(0x1, X21 + 24)          
            // 0x0168AE8C: B.GE #0x168aecc            | if (val_3 >= X21 + 24) goto label_3;    
            if(val_3 >= (X21 + 24))
            {
                goto label_3;
            }
            // 0x0168AE90: LDR x21, [x19, #0x30]      | 
            // 0x0168AE94: CBNZ x21, #0x168ae9c       | if (X21 != 0) goto label_4;             
            if(X21 != 0)
            {
                goto label_4;
            }
            // 0x0168AE98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? del, ????);        
            label_4:
            // 0x0168AE9C: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
            // 0x0168AEA0: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x0168AEA4: CMP w22, w8                | STATE = COMPARE(0x1, X21 + 24)          
            // 0x0168AEA8: B.LO #0x168aeb8            | if (val_3 < X21 + 24) goto label_5;     
            if(val_3 < (X21 + 24))
            {
                goto label_5;
            }
            // 0x0168AEAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? del, ????);        
            // 0x0168AEB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168AEB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? del, ????);        
            label_5:
            // 0x0168AEB8: ADD x8, x21, x23, lsl #3   | X8 = (X21 + 8);                         
            var val_1 = X21 + 8;
            // 0x0168AEBC: LDR x21, [x8, #0x20]       | X21 = (X21 + 8) + 32;                   
            // 0x0168AEC0: CBNZ x20, #0x168ae64       | if (del != null) goto label_7;          
            if(del != null)
            {
                goto label_7;
            }
            // 0x0168AEC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? del, ????);        
            // 0x0168AEC8: B #0x168ae64               |  goto label_7;                          
            goto label_7;
            label_3:
            // 0x0168AECC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0168AED0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0168AED4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0168AED8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0168AEDC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0168B278 (23638648), len: 888  VirtAddr: 0x0168B278 RVA: 0x0168B278 token: 100683044 methodIndex: 49944 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Open(Pathfinding.Path path, Pathfinding.PathNode pathNode, Pathfinding.PathHandler handler)
        {
            //
            // Disasemble & Code
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            Pathfinding.Path val_17;
            //  | 
            Pathfinding.PathNode val_18;
            // 0x0168B278: STP x28, x27, [sp, #-0x60]! | stack[1152921513377437872] = ???;  stack[1152921513377437880] = ???;  //  dest_result_addr=1152921513377437872 |  dest_result_addr=1152921513377437880
            // 0x0168B27C: STP x26, x25, [sp, #0x10]  | stack[1152921513377437888] = ???;  stack[1152921513377437896] = ???;  //  dest_result_addr=1152921513377437888 |  dest_result_addr=1152921513377437896
            // 0x0168B280: STP x24, x23, [sp, #0x20]  | stack[1152921513377437904] = ???;  stack[1152921513377437912] = ???;  //  dest_result_addr=1152921513377437904 |  dest_result_addr=1152921513377437912
            // 0x0168B284: STP x22, x21, [sp, #0x30]  | stack[1152921513377437920] = ???;  stack[1152921513377437928] = ???;  //  dest_result_addr=1152921513377437920 |  dest_result_addr=1152921513377437928
            // 0x0168B288: STP x20, x19, [sp, #0x40]  | stack[1152921513377437936] = ???;  stack[1152921513377437944] = ???;  //  dest_result_addr=1152921513377437936 |  dest_result_addr=1152921513377437944
            // 0x0168B28C: STP x29, x30, [sp, #0x50]  | stack[1152921513377437952] = ???;  stack[1152921513377437960] = ???;  //  dest_result_addr=1152921513377437952 |  dest_result_addr=1152921513377437960
            // 0x0168B290: ADD x29, sp, #0x50         | X29 = (1152921513377437872 + 80) = 1152921513377437952 (0x100000020AC49900);
            // 0x0168B294: SUB sp, sp, #0x10          | SP = (1152921513377437872 - 16) = 1152921513377437856 (0x100000020AC498A0);
            // 0x0168B298: MOV x19, x0                | X19 = 1152921513377449968 (0x100000020AC4C7F0);//ML01
            // 0x0168B29C: LDR x23, [x19, #0x30]      | 
            // 0x0168B2A0: MOV x20, x3                | X20 = handler;//m1                      
            // 0x0168B2A4: MOV x28, x2                | X28 = pathNode;//m1                     
            // 0x0168B2A8: MOV x22, x1                | X22 = path;//m1                         
            // 0x0168B2AC: CBZ x23, #0x168b5d0        | if (X23 == 0) goto label_3;             
            if(X23 == 0)
            {
                goto label_3;
            }
            // 0x0168B2B0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x0168B2B4: B #0x168b2c0               |  goto label_1;                          
            goto label_1;
            label_39:
            // 0x0168B2B8: LDR x23, [x19, #0x30]      | 
            // 0x0168B2BC: ADD w21, w21, #1           | W21 = (val_16 + 1) = val_16 (0x00000001);
            val_16 = 1;
            label_1:
            // 0x0168B2C0: CBNZ x23, #0x168b2c8       | if (X23 != 0) goto label_2;             
            if(X23 != 0)
            {
                goto label_2;
            }
            // 0x0168B2C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0168B2C8: LDR w8, [x23, #0x18]       | W8 = X23 + 24;                          
            // 0x0168B2CC: CMP w21, w8                | STATE = COMPARE(0x1, X23 + 24)          
            // 0x0168B2D0: B.GE #0x168b5d0            | if (val_16 >= X23 + 24) goto label_3;   
            if(val_16 >= (X23 + 24))
            {
                goto label_3;
            }
            // 0x0168B2D4: LDR x23, [x19, #0x30]      | 
            // 0x0168B2D8: CBNZ x23, #0x168b2e0       | if (X23 != 0) goto label_4;             
            if(X23 != 0)
            {
                goto label_4;
            }
            // 0x0168B2DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0168B2E0: LDR w8, [x23, #0x18]       | W8 = X23 + 24;                          
            // 0x0168B2E4: SXTW x25, w21              | X25 = 1 (0x00000001);                   
            // 0x0168B2E8: CMP w21, w8                | STATE = COMPARE(0x1, X23 + 24)          
            // 0x0168B2EC: B.LO #0x168b2fc            | if (val_16 < X23 + 24) goto label_5;    
            if(val_16 < (X23 + 24))
            {
                goto label_5;
            }
            // 0x0168B2F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0168B2F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B2F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_5:
            // 0x0168B2FC: ADD x8, x23, x25, lsl #3   | X8 = (X23 + 8);                         
            var val_1 = X23 + 8;
            // 0x0168B300: LDR x23, [x8, #0x20]       | X23 = (X23 + 8) + 32;                   
            // 0x0168B304: CBNZ x22, #0x168b30c       | if (path != null) goto label_6;         
            if(path != null)
            {
                goto label_6;
            }
            // 0x0168B308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_6:
            // 0x0168B30C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B310: MOV x0, x22                | X0 = path;//m1                          
            // 0x0168B314: MOV x1, x23                | X1 = (X23 + 8) + 32;//m1                
            // 0x0168B318: BL #0x14031c8              | X0 = path.CanTraverse(node:  (X23 + 8) + 32);
            bool val_2 = path.CanTraverse(node:  (X23 + 8) + 32);
            // 0x0168B31C: TBZ w0, #0, #0x168b2b8     | if (val_2 == false) goto label_39;      
            if(val_2 == false)
            {
                goto label_39;
            }
            // 0x0168B320: CBNZ x20, #0x168b328       | if (handler != null) goto label_8;      
            if(handler != null)
            {
                goto label_8;
            }
            // 0x0168B324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x0168B328: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B32C: MOV x0, x20                | X0 = handler;//m1                       
            // 0x0168B330: MOV x1, x23                | X1 = (X23 + 8) + 32;//m1                
            // 0x0168B334: BL #0x140535c              | X0 = handler.GetPathNode(node:  (X23 + 8) + 32);
            Pathfinding.PathNode val_3 = handler.GetPathNode(node:  (X23 + 8) + 32);
            // 0x0168B338: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x0168B33C: CBNZ x24, #0x168b344       | if (val_3 != null) goto label_9;        
            if(val_3 != null)
            {
                goto label_9;
            }
            // 0x0168B340: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x0168B344: LDRH w26, [x24, #0x20]     | W26 = val_3.pathID; //P2                
            // 0x0168B348: CBNZ x20, #0x168b350       | if (handler != null) goto label_10;     
            if(handler != null)
            {
                goto label_10;
            }
            // 0x0168B34C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x0168B350: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B354: MOV x0, x20                | X0 = handler;//m1                       
            // 0x0168B358: BL #0x1404d14              | X0 = handler.get_PathID();              
            ushort val_4 = handler.PathID;
            // 0x0168B35C: CMP w26, w0, uxth          | STATE = COMPARE(val_3.pathID, val_4)    
            // 0x0168B360: B.NE #0x168b440            | if (val_3.pathID != val_4) goto label_11;
            if(val_3.pathID != val_4)
            {
                goto label_11;
            }
            // 0x0168B364: LDR x26, [x19, #0x38]      | 
            // 0x0168B368: CBNZ x26, #0x168b370       | if (val_3.pathID != 0) goto label_12;   
            if(val_3.pathID != 0)
            {
                goto label_12;
            }
            // 0x0168B36C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_12:
            // 0x0168B370: LDR w8, [x26, #0x18]       | W8 = val_3.pathID + 24;                 
            // 0x0168B374: CMP w21, w8                | STATE = COMPARE(0x1, val_3.pathID + 24) 
            // 0x0168B378: B.LO #0x168b388            | if (val_16 < val_3.pathID + 24) goto label_13;
            if(val_16 < (val_3.pathID + 24))
            {
                goto label_13;
            }
            // 0x0168B37C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x0168B380: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B384: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_13:
            // 0x0168B388: ADD x8, x26, x25, lsl #2   | X8 = (val_3.pathID + 4);                
            ushort val_5 = val_3.pathID + 4;
            // 0x0168B38C: LDR w8, [x8, #0x20]        | W8 = (val_3.pathID + 4) + 32;           
            // 0x0168B390: STR w8, [sp, #0xc]         | stack[1152921513377437868] = (val_3.pathID + 4) + 32;  //  dest_result_addr=1152921513377437868
            // 0x0168B394: CBNZ x28, #0x168b39c       | if (pathNode != null) goto label_14;    
            if(pathNode != null)
            {
                goto label_14;
            }
            // 0x0168B398: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_14:
            // 0x0168B39C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B3A0: MOV x0, x28                | X0 = pathNode;//m1                      
            // 0x0168B3A4: BL #0x1405c90              | X0 = pathNode.get_G();                  
            uint val_6 = pathNode.G;
            // 0x0168B3A8: MOV w26, w0                | W26 = val_6;//m1                        
            var val_16 = val_6;
            // 0x0168B3AC: CBNZ x22, #0x168b3b4       | if (path != null) goto label_15;        
            if(path != null)
            {
                goto label_15;
            }
            // 0x0168B3B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_15:
            // 0x0168B3B4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B3B8: MOV x0, x22                | X0 = path;//m1                          
            // 0x0168B3BC: MOV x1, x23                | X1 = (X23 + 8) + 32;//m1                
            // 0x0168B3C0: MOV x25, x28               | X25 = pathNode;//m1                     
            // 0x0168B3C4: BL #0x1403274              | X0 = path.GetTraversalCost(node:  (X23 + 8) + 32);
            uint val_7 = path.GetTraversalCost(node:  (X23 + 8) + 32);
            // 0x0168B3C8: MOV w27, w0                | W27 = val_7;//m1                        
            // 0x0168B3CC: CBNZ x24, #0x168b3d4       | if (val_3 != null) goto label_16;       
            if(val_3 != null)
            {
                goto label_16;
            }
            // 0x0168B3D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_16:
            // 0x0168B3D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B3D8: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x0168B3DC: BL #0x1405c90              | X0 = val_3.get_G();                     
            uint val_8 = val_3.G;
            // 0x0168B3E0: LDR w8, [sp, #0xc]         | W8 = (val_3.pathID + 4) + 32;           
            var val_15 = (val_3.pathID + 4) + 32;
            // 0x0168B3E4: MOV w28, w0                | W28 = val_8;//m1                        
            // 0x0168B3E8: ADD w8, w26, w8            | W8 = (val_6 + (val_3.pathID + 4) + 32); 
            val_15 = val_16 + val_15;
            // 0x0168B3EC: ADD w26, w8, w27           | W26 = ((val_6 + (val_3.pathID + 4) + 32) + val_7);
            val_16 = val_15 + val_7;
            // 0x0168B3F0: CBNZ x24, #0x168b3f8       | if (val_3 != null) goto label_17;       
            if(val_3 != null)
            {
                goto label_17;
            }
            // 0x0168B3F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_17:
            // 0x0168B3F8: CMP w26, w28               | STATE = COMPARE(((val_6 + (val_3.pathID + 4) + 32) + val_7), val_8)
            // 0x0168B3FC: B.HS #0x168b510            | if (val_6 >= val_8) goto label_18;      
            if(val_16 >= val_8)
            {
                goto label_18;
            }
            // 0x0168B400: LDR w1, [sp, #0xc]         | W1 = (val_3.pathID + 4) + 32;           
            // 0x0168B404: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B408: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x0168B40C: BL #0x1405bd4              | val_3.set_cost(value:  (val_3.pathID + 4) + 32);
            val_3.cost = (val_3.pathID + 4) + 32;
            // 0x0168B410: MOV x28, x25               | X28 = pathNode;//m1                     
            // 0x0168B414: CBNZ x24, #0x168b41c       | if (val_3 != null) goto label_19;       
            if(val_3 != null)
            {
                goto label_19;
            }
            // 0x0168B418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_19:
            // 0x0168B41C: STR x28, [x24, #0x18]      | val_3.parent = pathNode;                 //  dest_result_addr=0
            val_3.parent = pathNode;
            // 0x0168B420: CBNZ x23, #0x168b428       | if ((X23 + 8) + 32 != 0) goto label_20; 
            if(((X23 + 8) + 32) != 0)
            {
                goto label_20;
            }
            // 0x0168B424: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_20:
            // 0x0168B428: LDR x8, [x23]              | X8 = (X23 + 8) + 32;                    
            // 0x0168B42C: MOV x0, x23                | X0 = (X23 + 8) + 32;//m1                
            // 0x0168B430: MOV x1, x22                | X1 = path;//m1                          
            val_17 = path;
            // 0x0168B434: MOV x2, x24                | X2 = val_3;//m1                         
            val_18 = val_3;
            // 0x0168B438: LDP x9, x4, [x8, #0x150]   | X9 = (X23 + 8) + 32 + 336; X4 = (X23 + 8) + 32 + 336 + 8; //  | 
            // 0x0168B43C: B #0x168b5c4               |  goto label_21;                         
            goto label_21;
            label_11:
            // 0x0168B440: CBNZ x24, #0x168b448       | if (val_3 != null) goto label_22;       
            if(val_3 != null)
            {
                goto label_22;
            }
            // 0x0168B444: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_22:
            // 0x0168B448: STR x28, [x24, #0x18]      | val_3.parent = pathNode;                 //  dest_result_addr=0
            val_3.parent = pathNode;
            // 0x0168B44C: CBNZ x20, #0x168b454       | if (handler != null) goto label_23;     
            if(handler != null)
            {
                goto label_23;
            }
            // 0x0168B450: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_23:
            // 0x0168B454: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B458: MOV x0, x20                | X0 = handler;//m1                       
            // 0x0168B45C: BL #0x1404d14              | X0 = handler.get_PathID();              
            ushort val_9 = handler.PathID;
            // 0x0168B460: STRH w0, [x24, #0x20]      | val_3.pathID = val_9;                    //  dest_result_addr=0
            val_3.pathID = val_9;
            // 0x0168B464: LDR x26, [x19, #0x38]      | 
            // 0x0168B468: CBNZ x26, #0x168b470       | if (val_3.pathID != 0) goto label_24;   
            if(val_3.pathID != 0)
            {
                goto label_24;
            }
            // 0x0168B46C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_24:
            // 0x0168B470: LDR w8, [x26, #0x18]       | W8 = val_3.pathID + 24;                 
            // 0x0168B474: CMP w21, w8                | STATE = COMPARE(0x1, val_3.pathID + 24) 
            // 0x0168B478: B.LO #0x168b488            | if (val_16 < val_3.pathID + 24) goto label_25;
            if(val_16 < (val_3.pathID + 24))
            {
                goto label_25;
            }
            // 0x0168B47C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x0168B480: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B484: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_25:
            // 0x0168B488: ADD x8, x26, x25, lsl #2   | X8 = (val_3.pathID + 4);                
            ushort val_10 = val_3.pathID + 4;
            // 0x0168B48C: LDR w25, [x8, #0x20]       | W25 = (val_3.pathID + 4) + 32;          
            // 0x0168B490: CBNZ x24, #0x168b498       | if (val_3 != null) goto label_26;       
            if(val_3 != null)
            {
                goto label_26;
            }
            // 0x0168B494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_26:
            // 0x0168B498: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B49C: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x0168B4A0: MOV w1, w25                | W1 = (val_3.pathID + 4) + 32;//m1       
            // 0x0168B4A4: BL #0x1405bd4              | val_3.set_cost(value:  (val_3.pathID + 4) + 32);
            val_3.cost = (val_3.pathID + 4) + 32;
            // 0x0168B4A8: CBNZ x22, #0x168b4b0       | if (path != null) goto label_27;        
            if(path != null)
            {
                goto label_27;
            }
            // 0x0168B4AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_27:
            // 0x0168B4B0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B4B4: MOV x0, x22                | X0 = path;//m1                          
            // 0x0168B4B8: MOV x1, x23                | X1 = (X23 + 8) + 32;//m1                
            // 0x0168B4BC: BL #0x1402e98              | X0 = path.CalculateHScore(node:  (X23 + 8) + 32);
            uint val_11 = path.CalculateHScore(node:  (X23 + 8) + 32);
            // 0x0168B4C0: MOV w25, w0                | W25 = val_11;//m1                       
            // 0x0168B4C4: CBNZ x24, #0x168b4cc       | if (val_3 != null) goto label_28;       
            if(val_3 != null)
            {
                goto label_28;
            }
            // 0x0168B4C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_28:
            // 0x0168B4CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B4D0: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x0168B4D4: MOV w1, w25                | W1 = val_11;//m1                        
            // 0x0168B4D8: BL #0x1405ca8              | val_3.set_H(value:  val_11);            
            val_3.H = val_11;
            // 0x0168B4DC: CBNZ x23, #0x168b4e4       | if ((X23 + 8) + 32 != 0) goto label_29; 
            if(((X23 + 8) + 32) != 0)
            {
                goto label_29;
            }
            // 0x0168B4E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_29:
            // 0x0168B4E4: MOV x0, x23                | X0 = (X23 + 8) + 32;//m1                
            // 0x0168B4E8: MOV x1, x22                | X1 = path;//m1                          
            // 0x0168B4EC: MOV x2, x24                | X2 = val_3;//m1                         
            // 0x0168B4F0: BL #0x168b5f0              | (X23 + 8) + 32.UpdateG(path:  path, pathNode:  val_3);
            (X23 + 8) + 32.UpdateG(path:  path, pathNode:  val_3);
            // 0x0168B4F4: CBNZ x20, #0x168b4fc       | if (handler != null) goto label_30;     
            if(handler != null)
            {
                goto label_30;
            }
            // 0x0168B4F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X23 + 8) + 32, ????);
            label_30:
            // 0x0168B4FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B500: MOV x0, x20                | X0 = handler;//m1                       
            // 0x0168B504: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x0168B508: BL #0x1405258              | handler.PushNode(node:  val_3);         
            handler.PushNode(node:  val_3);
            // 0x0168B50C: B #0x168b2b8               |  goto label_39;                         
            goto label_39;
            label_18:
            // 0x0168B510: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B514: MOV x0, x24                | X0 = val_3;//m1                         
            // 0x0168B518: BL #0x1405c90              | X0 = val_3.get_G();                     
            uint val_12 = val_3.G;
            // 0x0168B51C: MOV w26, w0                | W26 = val_12;//m1                       
            // 0x0168B520: MOV x28, x25               | X28 = pathNode;//m1                     
            // 0x0168B524: CBNZ x22, #0x168b52c       | if (path != null) goto label_32;        
            if(path != null)
            {
                goto label_32;
            }
            // 0x0168B528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_32:
            // 0x0168B52C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B530: MOV x0, x22                | X0 = path;//m1                          
            // 0x0168B534: MOV x1, x19                | X1 = 1152921513377449968 (0x100000020AC4C7F0);//ML01
            // 0x0168B538: BL #0x1403274              | X0 = path.GetTraversalCost(node:  this);
            uint val_13 = path.GetTraversalCost(node:  this);
            // 0x0168B53C: MOV w27, w0                | W27 = val_13;//m1                       
            // 0x0168B540: CBNZ x28, #0x168b548       | if (pathNode != null) goto label_33;    
            if(pathNode != null)
            {
                goto label_33;
            }
            // 0x0168B544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_33:
            // 0x0168B548: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168B54C: MOV x0, x28                | X0 = pathNode;//m1                      
            // 0x0168B550: BL #0x1405c90              | X0 = pathNode.get_G();                  
            uint val_14 = pathNode.G;
            // 0x0168B554: LDR w8, [sp, #0xc]         | W8 = (val_3.pathID + 4) + 32;           
            var val_17 = (val_3.pathID + 4) + 32;
            // 0x0168B558: ADD w8, w26, w8            | W8 = (val_12 + (val_3.pathID + 4) + 32);
            val_17 = val_12 + val_17;
            // 0x0168B55C: ADD w8, w8, w27            | W8 = ((val_12 + (val_3.pathID + 4) + 32) + val_13);
            val_17 = val_17 + val_13;
            // 0x0168B560: CMP w8, w0                 | STATE = COMPARE(((val_12 + (val_3.pathID + 4) + 32) + val_13), val_14)
            // 0x0168B564: B.HS #0x168b2b8            | if ((val_3.pathID + 4) + 32 >= val_14) goto label_39;
            if(val_17 >= val_14)
            {
                goto label_39;
            }
            // 0x0168B568: CBNZ x23, #0x168b570       | if ((X23 + 8) + 32 != 0) goto label_35; 
            if(((X23 + 8) + 32) != 0)
            {
                goto label_35;
            }
            // 0x0168B56C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_35:
            // 0x0168B570: LDR x8, [x23]              | X8 = (X23 + 8) + 32;                    
            // 0x0168B574: MOV x0, x23                | X0 = (X23 + 8) + 32;//m1                
            // 0x0168B578: MOV x1, x19                | X1 = 1152921513377449968 (0x100000020AC4C7F0);//ML01
            // 0x0168B57C: LDP x9, x2, [x8, #0x1b0]   | X9 = (X23 + 8) + 32 + 432; X2 = (X23 + 8) + 32 + 432 + 8; //  | 
            // 0x0168B580: BLR x9                     | X0 = (X23 + 8) + 32 + 432();            
            // 0x0168B584: TBZ w0, #0, #0x168b2b8     | if (((X23 + 8) + 32 & 0x1) == 0) goto label_39;
            if((((X23 + 8) + 32) & 1) == 0)
            {
                goto label_39;
            }
            // 0x0168B588: CBZ x28, #0x168b594        | if (pathNode == null) goto label_37;    
            if(pathNode == null)
            {
                goto label_37;
            }
            // 0x0168B58C: STR x24, [x28, #0x18]      | pathNode.parent = val_3;                 //  dest_result_addr=0
            pathNode.parent = val_3;
            // 0x0168B590: B #0x168b5a0               |  goto label_38;                         
            goto label_38;
            label_37:
            // 0x0168B594: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X23 + 8) + 32, ????);
            // 0x0168B598: STR x24, [x28, #0x18]      | pathNode.parent = val_3;                 //  dest_result_addr=0
            pathNode.parent = val_3;
            // 0x0168B59C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (X23 + 8) + 32, ????);
            label_38:
            // 0x0168B5A0: LDR w1, [sp, #0xc]         | W1 = (val_3.pathID + 4) + 32;           
            // 0x0168B5A4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168B5A8: MOV x0, x28                | X0 = pathNode;//m1                      
            // 0x0168B5AC: BL #0x1405bd4              | pathNode.set_cost(value:  (val_3.pathID + 4) + 32);
            pathNode.cost = (val_3.pathID + 4) + 32;
            // 0x0168B5B0: LDR x8, [x19]              | X8 = typeof(Pathfinding.ConvexMeshNode);
            // 0x0168B5B4: MOV x0, x19                | X0 = 1152921513377449968 (0x100000020AC4C7F0);//ML01
            // 0x0168B5B8: MOV x1, x22                | X1 = path;//m1                          
            val_17 = path;
            // 0x0168B5BC: MOV x2, x28                | X2 = pathNode;//m1                      
            val_18 = pathNode;
            // 0x0168B5C0: LDP x9, x4, [x8, #0x150]   | X9 = public System.Void Pathfinding.MeshNode::UpdateRecursiveG(Pathfinding.Path path, Pathfinding.PathNode pathNode, Pathfinding.PathHandler handler); X4 = public System.Void Pathfinding.MeshNode::UpdateRecursiveG(Pathfinding.Path path, Pathfinding.PathNode pathNode, Pathfinding.PathHandler handler); //  | 
            label_21:
            // 0x0168B5C4: MOV x3, x20                | X3 = handler;//m1                       
            // 0x0168B5C8: BLR x9                     | this.UpdateRecursiveG(path:  val_17 = path, pathNode:  val_18 = pathNode, handler:  handler);
            this.UpdateRecursiveG(path:  val_17, pathNode:  val_18, handler:  handler);
            // 0x0168B5CC: B #0x168b2b8               |  goto label_39;                         
            goto label_39;
            label_3:
            // 0x0168B5D0: SUB sp, x29, #0x50         | SP = (1152921513377437952 - 80) = 1152921513377437872 (0x100000020AC498B0);
            // 0x0168B5D4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0168B5D8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0168B5DC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0168B5E0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0168B5E4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0168B5E8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0168B5EC: RET                        |  return;                                
            return;
        
        }
    
    }

}
