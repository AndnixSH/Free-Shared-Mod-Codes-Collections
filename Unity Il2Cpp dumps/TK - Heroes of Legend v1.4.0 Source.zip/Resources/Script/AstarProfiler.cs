using UnityEngine;

namespace Pathfinding
{
    public class AstarProfiler
    {
        // Fields
        private static System.Collections.Generic.Dictionary<string, Pathfinding.AstarProfiler.ProfilePoint> profiles; // static_offset: 0x00000000
        private static System.DateTime startTime; // static_offset: 0x00000008
        public static Pathfinding.AstarProfiler.ProfilePoint[] fastProfiles; // static_offset: 0x00000018
        public static string[] fastProfileNames; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01684D8C (23612812), len: 8  VirtAddr: 0x01684D8C RVA: 0x01684D8C token: 100683729 methodIndex: 49869 delegateWrapperIndex: 0 methodInvoker: 0
        private AstarProfiler()
        {
            //
            // Disasemble & Code
            // 0x01684D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684D90: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01684D94 (23612820), len: 728  VirtAddr: 0x01684D94 RVA: 0x01684D94 token: 100683730 methodIndex: 49870 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CE50
        public static void InitializeFastProfile(string[] profileNames)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x01684D94: STP x24, x23, [sp, #-0x40]! | stack[1152921513533791888] = ???;  stack[1152921513533791896] = ???;  //  dest_result_addr=1152921513533791888 |  dest_result_addr=1152921513533791896
            // 0x01684D98: STP x22, x21, [sp, #0x10]  | stack[1152921513533791904] = ???;  stack[1152921513533791912] = ???;  //  dest_result_addr=1152921513533791904 |  dest_result_addr=1152921513533791912
            // 0x01684D9C: STP x20, x19, [sp, #0x20]  | stack[1152921513533791920] = ???;  stack[1152921513533791928] = ???;  //  dest_result_addr=1152921513533791920 |  dest_result_addr=1152921513533791928
            // 0x01684DA0: STP x29, x30, [sp, #0x30]  | stack[1152921513533791936] = ???;  stack[1152921513533791944] = ???;  //  dest_result_addr=1152921513533791936 |  dest_result_addr=1152921513533791944
            // 0x01684DA4: ADD x29, sp, #0x30         | X29 = (1152921513533791888 + 48) = 1152921513533791936 (0x1000000214165EC0);
            // 0x01684DA8: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01684DAC: LDRB w8, [x20, #0xe5]      | W8 = (bool)static_value_037380E5;       
            // 0x01684DB0: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01684DB4: TBNZ w8, #0, #0x1684dd0    | if (static_value_037380E5 == true) goto label_0;
            // 0x01684DB8: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01684DBC: LDR x8, [x8, #0x58]        | X8 = 0x2B8ED94;                         
            // 0x01684DC0: LDR w0, [x8]               | W0 = 0x1225;                            
            // 0x01684DC4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1225, ????);     
            // 0x01684DC8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01684DCC: STRB w8, [x20, #0xe5]      | static_value_037380E5 = true;            //  dest_result_addr=57901285
            label_0:
            // 0x01684DD0: CBNZ x19, #0x1684dd8       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01684DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1225, ????);     
            label_1:
            // 0x01684DD8: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
            // 0x01684DDC: LDR x22, [x22, #0x358]     | X22 = 1152921504850882560;              
            // 0x01684DE0: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_8 = null;
            // 0x01684DE4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01684DE8: TBZ w8, #0, #0x1684dfc     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01684DEC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01684DF0: CBNZ w8, #0x1684dfc        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01684DF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01684DF8: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_8 = null;
            label_3:
            // 0x01684DFC: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x01684E00: LDR x23, [x0, #0xa0]       | X23 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684E04: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
            // 0x01684E08: LDR w9, [x19, #0x18]       | W9 = X1 + 24;                           
            // 0x01684E0C: LDR x20, [x8]              | X20 = typeof(System.String[]);          
            // 0x01684E10: ADD w21, w9, #2            | W21 = (X1 + 24 + 2);                    
            var val_1 = (X1 + 24) + 2;
            // 0x01684E14: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x01684E18: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x01684E1C: MOV x0, x20                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x01684E20: MOV x1, x21                | X1 = (X1 + 24 + 2);//m1                 
            // 0x01684E24: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x01684E28: STR x0, [x23, #0x20]       | Pathfinding.AstarProfiler.fastProfileNames = typeof(System.String[]);  //  dest_result_addr=1152921504850886688
            Pathfinding.AstarProfiler.fastProfileNames = null;
            // 0x01684E2C: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01684E30: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684E34: LDR x20, [x8, #0x20]       | X20 = typeof(System.String[]);          
            // 0x01684E38: CBNZ x19, #0x1684e40       | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x01684E3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_4:
            // 0x01684E40: LDR w3, [x19, #0x18]       | W3 = X1 + 24;                           
            // 0x01684E44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01684E48: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01684E4C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x01684E50: MOV x2, x20                | X2 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x01684E54: BL #0x18c753c              | System.Array.Copy(sourceArray:  0, destinationArray:  X1, length:  342050192);
            System.Array.Copy(sourceArray:  0, destinationArray:  X1, length:  342050192);
            // 0x01684E58: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01684E5C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684E60: LDR x19, [x8, #0x20]       | X19 = typeof(System.String[]);          
            // 0x01684E64: CBNZ x19, #0x1684e70       | if ( != null) goto label_5;             
            if(null != null)
            {
                goto label_5;
            }
            // 0x01684E68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x01684E6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_5:
            // 0x01684E70: ADRP x20, #0x366e000       | X20 = 57073664 (0x366E000);             
            // 0x01684E74: LDR x20, [x20, #0xde8]     | X20 = (string**)(1152921513533775664)("__Control1__");
            // 0x01684E78: LDR x0, [x20]              | X0 = "__Control1__";                    
            // 0x01684E7C: CBZ x0, #0x1684e9c         | if ("__Control1__" == null) goto label_7;
            // 0x01684E80: LDR x8, [x19]              | X8 = ;                                  
            // 0x01684E84: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01684E88: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "__Control1__", ????);
            // 0x01684E8C: CBNZ x0, #0x1684e9c        | if ("__Control1__" != null) goto label_7;
            if("__Control1__" != null)
            {
                goto label_7;
            }
            // 0x01684E90: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "__Control1__", ????);
            // 0x01684E94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684E98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "__Control1__", ????);
            label_7:
            // 0x01684E9C: LDR x8, [x19, #0x18]       | X8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x01684EA0: LDR x20, [x20]             | X20 = "__Control1__";                   
            // 0x01684EA4: ORR x9, xzr, #0xfffffffe00000000 | X9 = -8589934592(0xFFFFFFFE00000000);   
            // 0x01684EA8: ADD x9, x9, x8, lsl #32    | X9 = (-8589934592 + (System.String[].__il2cppRuntimeField_namespaze) << 32);
            // 0x01684EAC: ASR x21, x9, #0x20         | X21 = ((-8589934592 + (System.String[].__il2cppRuntimeField_namespaze) << 32) >> 32);
            var val_2 = ((-8589934592 + (System.String[].__il2cppRuntimeField_namespaze) << 32)) >> 32;
            // 0x01684EB0: CMP w21, w8                | STATE = COMPARE(((-8589934592 + (System.String[].__il2cppRuntimeField_namespaze) << 32) >> 32), System.String[].__il2cppRuntimeField_namespaze)
            // 0x01684EB4: B.LO #0x1684ec4            | if (val_2 < System.String[].__il2cppRuntimeField_namespaze) goto label_8;
            // 0x01684EB8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "__Control1__", ????);
            // 0x01684EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684EC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "__Control1__", ????);
            label_8:
            // 0x01684EC4: ADD x8, x19, x21, lsl #3   | X8 = (Pathfinding.AstarProfiler.fastProfileNames + (((-8589934592 + (System.String[].__il2cppRuntime
            // 0x01684EC8: STR x20, [x8, #0x20]       | mem2[0] = "__Control1__";                //  dest_result_addr=0
            mem2[0] = "__Control1__";
            // 0x01684ECC: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01684ED0: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684ED4: LDR x19, [x8, #0x20]       | X19 = typeof(System.String[]);          
            // 0x01684ED8: CBNZ x19, #0x1684ee4       | if ( != null) goto label_9;             
            if(null != null)
            {
                goto label_9;
            }
            // 0x01684EDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "__Control1__", ????);
            // 0x01684EE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "__Control1__", ????);
            label_9:
            // 0x01684EE4: ADRP x20, #0x362f000       | X20 = 56815616 (0x362F000);             
            // 0x01684EE8: LDR x20, [x20, #0xde8]     | X20 = (string**)(1152921513533775760)("__Control2__");
            // 0x01684EEC: LDR x0, [x20]              | X0 = "__Control2__";                    
            // 0x01684EF0: CBZ x0, #0x1684f10         | if ("__Control2__" == null) goto label_11;
            // 0x01684EF4: LDR x8, [x19]              | X8 = ;                                  
            // 0x01684EF8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01684EFC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "__Control2__", ????);
            // 0x01684F00: CBNZ x0, #0x1684f10        | if ("__Control2__" != null) goto label_11;
            if("__Control2__" != null)
            {
                goto label_11;
            }
            // 0x01684F04: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "__Control2__", ????);
            // 0x01684F08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684F0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "__Control2__", ????);
            label_11:
            // 0x01684F10: LDR x8, [x19, #0x18]       | X8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x01684F14: LDR x20, [x20]             | X20 = "__Control2__";                   
            // 0x01684F18: ORR x9, xzr, #0xffffffff00000000 | X9 = -4294967296(0xFFFFFFFF00000000);   
            // 0x01684F1C: ADD x9, x9, x8, lsl #32    | X9 = (-4294967296 + (System.String[].__il2cppRuntimeField_namespaze) << 32);
            // 0x01684F20: ASR x21, x9, #0x20         | X21 = ((-4294967296 + (System.String[].__il2cppRuntimeField_namespaze) << 32) >> 32);
            var val_4 = ((-4294967296 + (System.String[].__il2cppRuntimeField_namespaze) << 32)) >> 32;
            // 0x01684F24: CMP w21, w8                | STATE = COMPARE(((-4294967296 + (System.String[].__il2cppRuntimeField_namespaze) << 32) >> 32), System.String[].__il2cppRuntimeField_namespaze)
            // 0x01684F28: B.LO #0x1684f38            | if (val_4 < System.String[].__il2cppRuntimeField_namespaze) goto label_12;
            // 0x01684F2C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "__Control2__", ????);
            // 0x01684F30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01684F34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "__Control2__", ????);
            label_12:
            // 0x01684F38: ADD x8, x19, x21, lsl #3   | X8 = (Pathfinding.AstarProfiler.fastProfileNames + (((-4294967296 + (System.String[].__il2cppRuntime
            // 0x01684F3C: STR x20, [x8, #0x20]       | mem2[0] = "__Control2__";                //  dest_result_addr=0
            mem2[0] = "__Control2__";
            // 0x01684F40: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01684F44: LDR x21, [x8, #0xa0]       | X21 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684F48: LDR x20, [x21, #0x20]      | X20 = typeof(System.String[]);          
            // 0x01684F4C: CBNZ x20, #0x1684f5c       | if ( != null) goto label_13;            
            if(null != null)
            {
                goto label_13;
            }
            // 0x01684F50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "__Control2__", ????);
            // 0x01684F54: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01684F58: LDR x21, [x8, #0xa0]       | X21 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            label_13:
            // 0x01684F5C: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x01684F60: LDR x8, [x8, #0x640]       | X8 = 1152921513533775856;               
            // 0x01684F64: LDR w20, [x20, #0x18]      | W20 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x01684F68: LDR x19, [x8]              | X19 = typeof(ProfilePoint[]);           
            // 0x01684F6C: MOV x0, x19                | X0 = 1152921513533775856 (0x1000000214161FF0);//ML01
            // 0x01684F70: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ProfilePoint[]), ????);
            // 0x01684F74: MOV x0, x19                | X0 = 1152921513533775856 (0x1000000214161FF0);//ML01
            // 0x01684F78: MOV x1, x20                | X1 = System.String[].__il2cppRuntimeField_namespaze;//m1
            // 0x01684F7C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(ProfilePoint[]), ????);
            // 0x01684F80: STR x0, [x21, #0x18]       | Pathfinding.AstarProfiler.fastProfiles = typeof(ProfilePoint[]);  //  dest_result_addr=1152921504850886680
            Pathfinding.AstarProfiler.fastProfiles = null;
            // 0x01684F84: ADRP x21, #0x3628000       | X21 = 56786944 (0x3628000);             
            // 0x01684F88: LDR x21, [x21, #0x838]     | X21 = 1152921504850935808;              
            // 0x01684F8C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x01684F90: B #0x1684fa0               |  goto label_14;                         
            goto label_14;
            label_25:
            // 0x01684F94: ADD x8, x23, x24, lsl #3   | X8 = (Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields + (X24) << 3);
            // 0x01684F98: ADD w20, w20, #1           | W20 = (val_10 + 1) = val_10 (0x00000001);
            val_10 = 1;
            // 0x01684F9C: STR x19, [x8, #0x20]       | (Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields + (X24) << 3).__unknownFiledOffset_20 = typeof(ProfilePoint[]);  //  dest_result_addr=0
            (Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields + (X24) << 3).__unknownFiledOffset_20 = null;
            label_14:
            // 0x01684FA0: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_11 = null;
            // 0x01684FA4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01684FA8: TBZ w8, #0, #0x1684fbc     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x01684FAC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01684FB0: CBNZ w8, #0x1684fbc        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x01684FB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01684FB8: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_11 = null;
            label_16:
            // 0x01684FBC: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684FC0: LDR x19, [x8, #0x18]       | X19 = typeof(ProfilePoint[]);           
            // 0x01684FC4: CBNZ x19, #0x1684fcc       | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x01684FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_17:
            // 0x01684FCC: LDR w8, [x19, #0x18]       | W8 = ProfilePoint[].__il2cppRuntimeField_namespaze;
            // 0x01684FD0: CMP w20, w8                | STATE = COMPARE(0x1, ProfilePoint[].__il2cppRuntimeField_namespaze)
            // 0x01684FD4: B.GE #0x1685058            | if (val_10 >= ProfilePoint[].__il2cppRuntimeField_namespaze) goto label_18;
            // 0x01684FD8: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_12 = null;
            // 0x01684FDC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01684FE0: TBZ w8, #0, #0x1684ff4     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_20;
            // 0x01684FE4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01684FE8: CBNZ w8, #0x1684ff4        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
            // 0x01684FEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01684FF0: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_12 = null;
            label_20:
            // 0x01684FF4: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01684FF8: LDR x0, [x21]              | X0 = typeof(AstarProfiler.ProfilePoint);
            AstarProfiler.ProfilePoint val_7 = null;
            // 0x01684FFC: LDR x23, [x8, #0x18]       | X23 = typeof(ProfilePoint[]);           
            // 0x01685000: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685004: MOV x19, x0                | X19 = 1152921504850935808 (0x100000000E8C8000);//ML01
            // 0x01685008: BL #0x168506c              | .ctor();                                
            val_7 = new AstarProfiler.ProfilePoint();
            // 0x0168500C: CBNZ x23, #0x1685014       | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x01685010: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_21:
            // 0x01685014: CBZ x19, #0x1685038        | if ( == 0) goto label_23;               
            if(null == 0)
            {
                goto label_23;
            }
            // 0x01685018: LDR x8, [x23]              | X8 = ;                                  
            // 0x0168501C: MOV x0, x19                | X0 = 1152921504850935808 (0x100000000E8C8000);//ML01
            // 0x01685020: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01685024: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685028: CBNZ x0, #0x1685038        | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x0168502C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685030: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685034: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AstarProfiler.ProfilePoint), ????);
            label_23:
            // 0x01685038: LDR w8, [x23, #0x18]       | W8 = ProfilePoint[].__il2cppRuntimeField_namespaze;
            // 0x0168503C: SXTW x24, w20              | X24 = 1 (0x00000001);                   
            // 0x01685040: CMP w20, w8                | STATE = COMPARE(0x1, ProfilePoint[].__il2cppRuntimeField_namespaze)
            // 0x01685044: B.LO #0x1684f94            | if (val_10 < ProfilePoint[].__il2cppRuntimeField_namespaze) goto label_25;
            // 0x01685048: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x0168504C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685050: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685054: B #0x1684f94               |  goto label_25;                         
            goto label_25;
            label_18:
            // 0x01685058: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0168505C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01685060: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01685064: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01685068: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016850D4 (23613652), len: 188  VirtAddr: 0x016850D4 RVA: 0x016850D4 token: 100683731 methodIndex: 49871 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CE88
        public static void StartFastProfile(int tag)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x016850D4: STP x22, x21, [sp, #-0x30]! | stack[1152921513533940768] = ???;  stack[1152921513533940776] = ???;  //  dest_result_addr=1152921513533940768 |  dest_result_addr=1152921513533940776
            // 0x016850D8: STP x20, x19, [sp, #0x10]  | stack[1152921513533940784] = ???;  stack[1152921513533940792] = ???;  //  dest_result_addr=1152921513533940784 |  dest_result_addr=1152921513533940792
            // 0x016850DC: STP x29, x30, [sp, #0x20]  | stack[1152921513533940800] = ???;  stack[1152921513533940808] = ???;  //  dest_result_addr=1152921513533940800 |  dest_result_addr=1152921513533940808
            // 0x016850E0: ADD x29, sp, #0x20         | X29 = (1152921513533940768 + 32) = 1152921513533940800 (0x100000021418A440);
            // 0x016850E4: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x016850E8: LDRB w8, [x20, #0xe6]      | W8 = (bool)static_value_037380E6;       
            // 0x016850EC: MOV w19, w1                | W19 = W1;//m1                           
            // 0x016850F0: TBNZ w8, #0, #0x168510c    | if (static_value_037380E6 == true) goto label_0;
            // 0x016850F4: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x016850F8: LDR x8, [x8, #0x760]       | X8 = 0x2B8EDA4;                         
            // 0x016850FC: LDR w0, [x8]               | W0 = 0x1229;                            
            // 0x01685100: BL #0x2782188              | X0 = sub_2782188( ?? 0x1229, ????);     
            // 0x01685104: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01685108: STRB w8, [x20, #0xe6]      | static_value_037380E6 = true;            //  dest_result_addr=57901286
            label_0:
            // 0x0168510C: ADRP x20, #0x363e000       | X20 = 56877056 (0x363E000);             
            // 0x01685110: LDR x20, [x20, #0x358]     | X20 = 1152921504850882560;              
            // 0x01685114: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_2 = null;
            // 0x01685118: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x0168511C: TBZ w8, #0, #0x1685130     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01685120: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685124: CBNZ w8, #0x1685130        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01685128: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x0168512C: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_2 = null;
            label_2:
            // 0x01685130: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685134: LDR x20, [x8, #0x18]       | X20 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x01685138: CBNZ x20, #0x1685140       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_3;
            if(Pathfinding.AstarProfiler.fastProfiles != null)
            {
                goto label_3;
            }
            // 0x0168513C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_3:
            // 0x01685140: LDR w8, [x20, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x01685144: SXTW x21, w19              | X21 = (long)(int)(W1);                  
            // 0x01685148: CMP w8, w19                | STATE = COMPARE(Pathfinding.AstarProfiler.fastProfiles.Length, W1)
            // 0x0168514C: B.HI #0x168515c            | if (Pathfinding.AstarProfiler.fastProfiles.Length > W1) goto label_4;
            if(Pathfinding.AstarProfiler.fastProfiles.Length > W1)
            {
                goto label_4;
            }
            // 0x01685150: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685154: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685158: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_4:
            // 0x0168515C: ADD x8, x20, x21, lsl #3   | X8 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3);
            ProfilePoint[] val_1 = Pathfinding.AstarProfiler.fastProfiles + (((long)(int)(W1)) << 3);
            // 0x01685160: LDR x19, [x8, #0x20]       | X19 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32; //  not_find_field!2:32
            // 0x01685164: CBNZ x19, #0x168516c       | if ((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 != 0) goto label_5;
            if(((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32) != 0)
            {
                goto label_5;
            }
            // 0x01685168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_5:
            // 0x0168516C: LDR x19, [x19, #0x10]      | X19 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16;
            // 0x01685170: CBNZ x19, #0x1685178       | if ((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16 != 0) goto label_6;
            if(((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16) != 0)
            {
                goto label_6;
            }
            // 0x01685174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_6:
            // 0x01685178: MOV x0, x19                | X0 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16;//m1
            // 0x0168517C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01685180: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01685184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685188: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x0168518C: B #0x14ff804               | (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16.Start(); return;
            (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16.Start();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01685190 (23613840), len: 228  VirtAddr: 0x01685190 RVA: 0x01685190 token: 100683732 methodIndex: 49872 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CEC0
        public static void EndFastProfile(int tag)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x01685190: STP x22, x21, [sp, #-0x30]! | stack[1152921513534052768] = ???;  stack[1152921513534052776] = ???;  //  dest_result_addr=1152921513534052768 |  dest_result_addr=1152921513534052776
            // 0x01685194: STP x20, x19, [sp, #0x10]  | stack[1152921513534052784] = ???;  stack[1152921513534052792] = ???;  //  dest_result_addr=1152921513534052784 |  dest_result_addr=1152921513534052792
            // 0x01685198: STP x29, x30, [sp, #0x20]  | stack[1152921513534052800] = ???;  stack[1152921513534052808] = ???;  //  dest_result_addr=1152921513534052800 |  dest_result_addr=1152921513534052808
            // 0x0168519C: ADD x29, sp, #0x20         | X29 = (1152921513534052768 + 32) = 1152921513534052800 (0x10000002141A59C0);
            // 0x016851A0: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x016851A4: LDRB w8, [x20, #0xe7]      | W8 = (bool)static_value_037380E7;       
            // 0x016851A8: MOV w19, w1                | W19 = W1;//m1                           
            // 0x016851AC: TBNZ w8, #0, #0x16851c8    | if (static_value_037380E7 == true) goto label_0;
            // 0x016851B0: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x016851B4: LDR x8, [x8, #0x3c0]       | X8 = 0x2B8ED8C;                         
            // 0x016851B8: LDR w0, [x8]               | W0 = 0x1223;                            
            // 0x016851BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1223, ????);     
            // 0x016851C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016851C4: STRB w8, [x20, #0xe7]      | static_value_037380E7 = true;            //  dest_result_addr=57901287
            label_0:
            // 0x016851C8: ADRP x20, #0x363e000       | X20 = 56877056 (0x363E000);             
            // 0x016851CC: LDR x20, [x20, #0x358]     | X20 = 1152921504850882560;              
            // 0x016851D0: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_2 = null;
            // 0x016851D4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x016851D8: TBZ w8, #0, #0x16851ec     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016851DC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x016851E0: CBNZ w8, #0x16851ec        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016851E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016851E8: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_2 = null;
            label_2:
            // 0x016851EC: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016851F0: LDR x20, [x8, #0x18]       | X20 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x016851F4: CBNZ x20, #0x16851fc       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_3;
            if(Pathfinding.AstarProfiler.fastProfiles != null)
            {
                goto label_3;
            }
            // 0x016851F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_3:
            // 0x016851FC: LDR w8, [x20, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x01685200: SXTW x21, w19              | X21 = (long)(int)(W1);                  
            val_3 = (long)W1;
            // 0x01685204: CMP w8, w19                | STATE = COMPARE(Pathfinding.AstarProfiler.fastProfiles.Length, W1)
            // 0x01685208: B.HI #0x1685218            | if (Pathfinding.AstarProfiler.fastProfiles.Length > W1) goto label_4;
            if(Pathfinding.AstarProfiler.fastProfiles.Length > W1)
            {
                goto label_4;
            }
            // 0x0168520C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685214: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_4:
            // 0x01685218: ADD x8, x20, x21, lsl #3   | X8 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3);
            ProfilePoint[] val_1 = Pathfinding.AstarProfiler.fastProfiles + (((long)(int)(W1)) << 3);
            // 0x0168521C: LDR x19, [x8, #0x20]       | X19 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32; //  not_find_field!2:32
            // 0x01685220: CBZ x19, #0x1685234        | if ((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 == 0) goto label_5;
            if(((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32) == 0)
            {
                goto label_5;
            }
            // 0x01685224: LDR w8, [x19, #0x18]       | W8 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 24;
            var val_2 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 24;
            // 0x01685228: ADD w8, w8, #1             | W8 = ((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 24 + 1);
            val_2 = val_2 + 1;
            // 0x0168522C: STR w8, [x19, #0x18]       | mem2[0] = ((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 24 + 1);  //  dest_result_addr=0
            mem2[0] = val_2;
            // 0x01685230: B #0x1685250               |  goto label_6;                          
            goto label_6;
            label_5:
            // 0x01685234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685238: ORR w20, wzr, #0x18        | W20 = 24(0x18);                         
            // 0x0168523C: LDR w21, [x20]             | W21 = 0x9814C0;                         
            val_3 = 9966784;
            // 0x01685240: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685244: ADD w8, w21, #1            | W8 = (val_3 + 1) = 9966785 (0x009814C1);
            // 0x01685248: STR w8, [x20]              | mem[24] = 0x9814C1;                      //  dest_result_addr=24
            mem[24] = 9966785;
            // 0x0168524C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_6:
            // 0x01685250: LDR x19, [x19, #0x10]      | X19 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16;
            // 0x01685254: CBNZ x19, #0x168525c       | if ((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16 != 0) goto label_7;
            if(((Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16) != 0)
            {
                goto label_7;
            }
            // 0x01685258: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_7:
            // 0x0168525C: MOV x0, x19                | X0 = (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16;//m1
            // 0x01685260: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01685264: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01685268: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168526C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01685270: B #0x14ffb4c               | (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16.Stop(); return;
            (Pathfinding.AstarProfiler.fastProfiles + ((long)(int)(W1)) << 3) + 32 + 16.Stop();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01685274 (23614068), len: 4  VirtAddr: 0x01685274 RVA: 0x01685274 token: 100683733 methodIndex: 49873 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CEF8
        public static void EndProfile()
        {
            //
            // Disasemble & Code
            // 0x01685274: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01685278 (23614072), len: 364  VirtAddr: 0x01685278 RVA: 0x01685278 token: 100683734 methodIndex: 49874 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CF30
        public static void StartProfile(string tag)
        {
            //
            // Disasemble & Code
            //  | 
            System.Collections.Generic.Dictionary<System.String, ProfilePoint> val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            ProfilePoint val_10;
            //  | 
            var val_11;
            // 0x01685278: STP x22, x21, [sp, #-0x30]! | stack[1152921513534282912] = ???;  stack[1152921513534282920] = ???;  //  dest_result_addr=1152921513534282912 |  dest_result_addr=1152921513534282920
            // 0x0168527C: STP x20, x19, [sp, #0x10]  | stack[1152921513534282928] = ???;  stack[1152921513534282936] = ???;  //  dest_result_addr=1152921513534282928 |  dest_result_addr=1152921513534282936
            // 0x01685280: STP x29, x30, [sp, #0x20]  | stack[1152921513534282944] = ???;  stack[1152921513534282952] = ???;  //  dest_result_addr=1152921513534282944 |  dest_result_addr=1152921513534282952
            // 0x01685284: ADD x29, sp, #0x20         | X29 = (1152921513534282912 + 32) = 1152921513534282944 (0x10000002141DDCC0);
            // 0x01685288: SUB sp, sp, #0x10          | SP = (1152921513534282912 - 16) = 1152921513534282896 (0x10000002141DDC90);
            // 0x0168528C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01685290: LDRB w8, [x20, #0xe8]      | W8 = (bool)static_value_037380E8;       
            // 0x01685294: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01685298: TBNZ w8, #0, #0x16852b4    | if (static_value_037380E8 == true) goto label_0;
            // 0x0168529C: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x016852A0: LDR x8, [x8, #0xe88]       | X8 = 0x2B8EDA8;                         
            // 0x016852A4: LDR w0, [x8]               | W0 = 0x122A;                            
            // 0x016852A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x122A, ????);     
            // 0x016852AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016852B0: STRB w8, [x20, #0xe8]      | static_value_037380E8 = true;            //  dest_result_addr=57901288
            label_0:
            // 0x016852B4: ADRP x21, #0x363e000       | X21 = 56877056 (0x363E000);             
            // 0x016852B8: LDR x21, [x21, #0x358]     | X21 = 1152921504850882560;              
            val_6 = 1152921504850882560;
            // 0x016852BC: STR xzr, [sp, #8]          | stack[1152921513534282904] = 0x0;        //  dest_result_addr=1152921513534282904
            ProfilePoint val_1 = 0;
            // 0x016852C0: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_7 = null;
            // 0x016852C4: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x016852C8: TBZ w8, #0, #0x16852dc     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016852CC: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x016852D0: CBNZ w8, #0x16852dc        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016852D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016852D8: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_7 = null;
            label_2:
            // 0x016852DC: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016852E0: LDR x20, [x8]              | X20 = Pathfinding.AstarProfiler.profiles;
            // 0x016852E4: CBNZ x20, #0x16852ec       | if (Pathfinding.AstarProfiler.profiles != null) goto label_3;
            if(Pathfinding.AstarProfiler.profiles != null)
            {
                goto label_3;
            }
            // 0x016852E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_3:
            // 0x016852EC: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x016852F0: LDR x8, [x8, #0x500]       | X8 = 1152921513534268912;               
            // 0x016852F4: ADD x2, sp, #8             | X2 = (1152921513534282896 + 8) = 1152921513534282904 (0x10000002141DDC98);
            // 0x016852F8: MOV x0, x20                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x016852FC: MOV x1, x19                | X1 = X1;//m1                            
            // 0x01685300: LDR x3, [x8]               | X3 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ProfilePoint>::TryGetValue(System.String key, out ProfilePoint value);
            // 0x01685304: BL #0x23fe7ec              | X0 = Pathfinding.AstarProfiler.profiles.TryGetValue(key:  X1, value: out  ProfilePoint val_1 = 0);
            bool val_2 = Pathfinding.AstarProfiler.profiles.TryGetValue(key:  X1, value: out  val_1);
            // 0x01685308: LDR x20, [sp, #8]          | X20 = 0x0;                              
            val_8 = val_1;
            // 0x0168530C: CBZ x20, #0x1685324        | if (0x0 == 0) goto label_4;             
            if(val_8 == 0)
            {
                goto label_4;
            }
            // 0x01685310: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685314: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01685318: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168531C: BL #0x1c3f8b0              | X0 = System.GC.GetTotalMemory(forceFullCollection:  false);
            long val_3 = System.GC.GetTotalMemory(forceFullCollection:  false);
            // 0x01685320: B #0x16853a4               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x01685324: ADRP x8, #0x3628000        | X8 = 56786944 (0x3628000);              
            // 0x01685328: LDR x8, [x8, #0x838]       | X8 = 1152921504850935808;               
            // 0x0168532C: LDR x0, [x8]               | X0 = typeof(AstarProfiler.ProfilePoint);
            AstarProfiler.ProfilePoint val_4 = null;
            // 0x01685330: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685334: MOV x20, x0                | X20 = 1152921504850935808 (0x100000000E8C8000);//ML01
            val_10 = val_4;
            // 0x01685338: BL #0x168506c              | .ctor();                                
            val_4 = new AstarProfiler.ProfilePoint();
            // 0x0168533C: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_11 = null;
            // 0x01685340: STR x20, [sp, #8]          | stack[1152921513534282904] = typeof(AstarProfiler.ProfilePoint);  //  dest_result_addr=1152921513534282904
            // 0x01685344: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01685348: TBZ w8, #0, #0x1685360     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0168534C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685350: CBNZ w8, #0x1685360        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01685354: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685358: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_11 = null;
            // 0x0168535C: LDR x20, [sp, #8]          | X20 = typeof(AstarProfiler.ProfilePoint);
            val_10 = val_10;
            label_7:
            // 0x01685360: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685364: LDR x21, [x8]              | X21 = Pathfinding.AstarProfiler.profiles;
            val_6 = Pathfinding.AstarProfiler.profiles;
            // 0x01685368: CBNZ x21, #0x1685370       | if (Pathfinding.AstarProfiler.profiles != null) goto label_8;
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x0168536C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_8:
            // 0x01685370: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x01685374: LDR x8, [x8, #0x900]       | X8 = 1152921513534269936;               
            // 0x01685378: MOV x0, x21                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x0168537C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x01685380: MOV x2, x20                | X2 = 1152921504850935808 (0x100000000E8C8000);//ML01
            // 0x01685384: LDR x3, [x8]               | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, ProfilePoint>::set_Item(System.String key, ProfilePoint value);
            // 0x01685388: BL #0x23fc55c              | Pathfinding.AstarProfiler.profiles.set_Item(key:  X1, value:  val_10);
            val_6.set_Item(key:  X1, value:  val_10);
            // 0x0168538C: LDR x20, [sp, #8]          | X20 = typeof(AstarProfiler.ProfilePoint);
            val_8 = val_10;
            // 0x01685390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685394: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01685398: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168539C: BL #0x1c3f8b0              | X0 = System.GC.GetTotalMemory(forceFullCollection:  false);
            long val_5 = System.GC.GetTotalMemory(forceFullCollection:  false);
            // 0x016853A0: CBZ x20, #0x16853e0        | if ( == 0) goto label_9;                
            if(null == 0)
            {
                goto label_9;
            }
            label_5:
            // 0x016853A4: STR x0, [x20, #0x20]       | typeof(AstarProfiler.ProfilePoint).__il2cppRuntimeField_20 = val_5;  //  dest_result_addr=1152921504850935840
            typeof(AstarProfiler.ProfilePoint).__il2cppRuntimeField_20 = val_5;
            // 0x016853A8: LDR x19, [sp, #8]          | X19 = typeof(AstarProfiler.ProfilePoint);
            // 0x016853AC: CBNZ x19, #0x16853b4       | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x016853B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_10:
            // 0x016853B4: LDR x19, [x19, #0x10]      | X19 = AstarProfiler.ProfilePoint.__il2cppRuntimeField_name;
            // 0x016853B8: CBNZ x19, #0x16853c0       | if (AstarProfiler.ProfilePoint != null) goto label_11;
            if(AstarProfiler.ProfilePoint != null)
            {
                goto label_11;
            }
            // 0x016853BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_11:
            // 0x016853C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016853C4: MOV x0, x19                | X0 = 1152921507530294688 (0x10000000AE4045A0);//ML01
            // 0x016853C8: BL #0x14ff804              | Start();                                
            Start();
            // 0x016853CC: SUB sp, x29, #0x20         | SP = (1152921513534282944 - 32) = 1152921513534282912 (0x10000002141DDCA0);
            // 0x016853D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016853D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016853D8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016853DC: RET                        |  return;                                
            return;
            label_9:
            // 0x016853E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x016853E4 (23614436), len: 476  VirtAddr: 0x016853E4 RVA: 0x016853E4 token: 100683735 methodIndex: 49875 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CF68
        public static void EndProfile(string tag)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x016853E4: STP x22, x21, [sp, #-0x30]! | stack[1152921513534417664] = ???;  stack[1152921513534417672] = ???;  //  dest_result_addr=1152921513534417664 |  dest_result_addr=1152921513534417672
            // 0x016853E8: STP x20, x19, [sp, #0x10]  | stack[1152921513534417680] = ???;  stack[1152921513534417688] = ???;  //  dest_result_addr=1152921513534417680 |  dest_result_addr=1152921513534417688
            // 0x016853EC: STP x29, x30, [sp, #0x20]  | stack[1152921513534417696] = ???;  stack[1152921513534417704] = ???;  //  dest_result_addr=1152921513534417696 |  dest_result_addr=1152921513534417704
            // 0x016853F0: ADD x29, sp, #0x20         | X29 = (1152921513534417664 + 32) = 1152921513534417696 (0x10000002141FEB20);
            // 0x016853F4: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x016853F8: LDRB w8, [x20, #0xe9]      | W8 = (bool)static_value_037380E9;       
            // 0x016853FC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01685400: TBNZ w8, #0, #0x168541c    | if (static_value_037380E9 == true) goto label_0;
            // 0x01685404: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x01685408: LDR x8, [x8, #0x5f0]       | X8 = 0x2B8ED90;                         
            // 0x0168540C: LDR w0, [x8]               | W0 = 0x1224;                            
            // 0x01685410: BL #0x2782188              | X0 = sub_2782188( ?? 0x1224, ????);     
            // 0x01685414: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01685418: STRB w8, [x20, #0xe9]      | static_value_037380E9 = true;            //  dest_result_addr=57901289
            label_0:
            // 0x0168541C: ADRP x21, #0x363e000       | X21 = 56877056 (0x363E000);             
            // 0x01685420: LDR x21, [x21, #0x358]     | X21 = 1152921504850882560;              
            val_7 = 1152921504850882560;
            // 0x01685424: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_8 = null;
            // 0x01685428: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x0168542C: TBZ w8, #0, #0x1685440     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01685430: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685434: CBNZ w8, #0x1685440        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01685438: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x0168543C: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_8 = null;
            label_2:
            // 0x01685440: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685444: LDR x20, [x8]              | X20 = Pathfinding.AstarProfiler.profiles;
            // 0x01685448: CBNZ x20, #0x1685450       | if (Pathfinding.AstarProfiler.profiles != null) goto label_3;
            if(Pathfinding.AstarProfiler.profiles != null)
            {
                goto label_3;
            }
            // 0x0168544C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_3:
            // 0x01685450: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01685454: LDR x8, [x8, #0x748]       | X8 = 1152921513534391152;               
            // 0x01685458: MOV x0, x20                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x0168545C: MOV x1, x19                | X1 = X1;//m1                            
            // 0x01685460: LDR x2, [x8]               | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, ProfilePoint>::ContainsKey(System.String key);
            // 0x01685464: BL #0x23fd9f0              | X0 = Pathfinding.AstarProfiler.profiles.ContainsKey(key:  X1);
            bool val_1 = Pathfinding.AstarProfiler.profiles.ContainsKey(key:  X1);
            // 0x01685468: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x0168546C: TBZ w8, #0, #0x16854cc     | if ((val_1 & 1) == false) goto label_4; 
            if(val_2 == false)
            {
                goto label_4;
            }
            // 0x01685470: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_9 = null;
            // 0x01685474: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01685478: TBZ w8, #0, #0x168548c     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x0168547C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685480: CBNZ w8, #0x168548c        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x01685484: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685488: LDR x0, [x21]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_9 = null;
            label_6:
            // 0x0168548C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685490: LDR x20, [x8]              | X20 = Pathfinding.AstarProfiler.profiles;
            // 0x01685494: CBNZ x20, #0x168549c       | if (Pathfinding.AstarProfiler.profiles != null) goto label_7;
            if(Pathfinding.AstarProfiler.profiles != null)
            {
                goto label_7;
            }
            // 0x01685498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_7:
            // 0x0168549C: ADRP x8, #0x364c000        | X8 = 56934400 (0x364C000);              
            // 0x016854A0: LDR x8, [x8, #0xa08]       | X8 = 1152921513534392176;               
            // 0x016854A4: MOV x0, x20                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x016854A8: MOV x1, x19                | X1 = X1;//m1                            
            // 0x016854AC: LDR x2, [x8]               | X2 = public ProfilePoint System.Collections.Generic.Dictionary<System.String, ProfilePoint>::get_Item(System.String key);
            // 0x016854B0: BL #0x23fc26c              | X0 = Pathfinding.AstarProfiler.profiles.get_Item(key:  X1);
            ProfilePoint val_3 = Pathfinding.AstarProfiler.profiles.Item[X1];
            // 0x016854B4: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x016854B8: CBZ x19, #0x1685558        | if (val_3 == null) goto label_8;        
            if(val_3 == null)
            {
                goto label_8;
            }
            // 0x016854BC: LDR w8, [x19, #0x18]       | W8 = val_3.totalCalls; //P2             
            int val_7 = val_3.totalCalls;
            // 0x016854C0: ADD w8, w8, #1             | W8 = (val_3.totalCalls + 1);            
            val_7 = val_7 + 1;
            // 0x016854C4: STR w8, [x19, #0x18]       | val_3.totalCalls = (val_3.totalCalls + 1);  //  dest_result_addr=0
            val_3.totalCalls = val_7;
            // 0x016854C8: B #0x1685574               |  goto label_9;                          
            goto label_9;
            label_4:
            // 0x016854CC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x016854D0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x016854D4: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x016854D8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x016854DC: TBZ w8, #0, #0x16854ec     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x016854E0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x016854E4: CBNZ w8, #0x16854ec        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x016854E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_11:
            // 0x016854EC: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x016854F0: ADRP x9, #0x366a000        | X9 = 57057280 (0x366A000);              
            // 0x016854F4: LDR x8, [x8, #0x598]       | X8 = (string**)(1152921513534397296)("Can only end profiling for a tag which has already been started (tag was ");
            // 0x016854F8: LDR x9, [x9, #0x170]       | X9 = (string**)(1152921509409721808)(")");
            // 0x016854FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685500: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01685504: LDR x1, [x8]               | X1 = "Can only end profiling for a tag which has already been started (tag was ";
            // 0x01685508: LDR x3, [x9]               | X3 = ")";                               
            // 0x0168550C: MOV x2, x19                | X2 = X1;//m1                            
            // 0x01685510: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "Can only end profiling for a tag which has already been started (tag was ", str2:  X1);
            string val_4 = System.String.Concat(str0:  0, str1:  "Can only end profiling for a tag which has already been started (tag was ", str2:  X1);
            // 0x01685514: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01685518: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x0168551C: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x01685520: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01685524: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01685528: TBZ w9, #0, #0x168553c     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x0168552C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01685530: CBNZ w9, #0x168553c        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x01685534: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x01685538: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_13:
            // 0x0168553C: MOV x1, x19                | X1 = val_4;//m1                         
            // 0x01685540: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01685544: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01685548: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168554C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685550: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01685554: B #0x1a5d504               | UnityEngine.Debug.LogError(message:  0); return;
            UnityEngine.Debug.LogError(message:  0);
            return;
            label_8:
            // 0x01685558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x0168555C: ORR w20, wzr, #0x18        | W20 = 24(0x18);                         
            // 0x01685560: LDR w21, [x20]             | W21 = 0x9814C0;                         
            val_7 = 9966784;
            // 0x01685564: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            // 0x01685568: ADD w8, w21, #1            | W8 = (val_7 + 1) = 9966785 (0x009814C1);
            // 0x0168556C: STR w8, [x20]              | mem[24] = 0x9814C1;                      //  dest_result_addr=24
            mem[24] = 9966785;
            // 0x01685570: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x01685574: LDR x20, [x19, #0x10]      | X20 = val_3.watch; //P2                 
            // 0x01685578: CBNZ x20, #0x1685580       | if (val_3.watch != null) goto label_14; 
            if(val_3.watch != null)
            {
                goto label_14;
            }
            // 0x0168557C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_14:
            // 0x01685580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685584: MOV x0, x20                | X0 = val_3.watch;//m1                   
            // 0x01685588: BL #0x14ffb4c              | val_3.watch.Stop();                     
            val_3.watch.Stop();
            // 0x0168558C: LDR x20, [x19, #0x28]      | X20 = val_3.totalBytes; //P2            
            // 0x01685590: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685594: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x01685598: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168559C: BL #0x1c3f8b0              | X0 = System.GC.GetTotalMemory(forceFullCollection:  false);
            long val_5 = System.GC.GetTotalMemory(forceFullCollection:  false);
            // 0x016855A0: LDR x8, [x19, #0x20]       | X8 = val_3.tmpBytes; //P2               
            long val_8 = val_3.tmpBytes;
            // 0x016855A4: ADD x9, x0, x20            | X9 = (val_5 + val_3.totalBytes);        
            long val_6 = val_5 + val_3.totalBytes;
            // 0x016855A8: SUB x8, x9, x8             | X8 = ((val_5 + val_3.totalBytes) - val_3.tmpBytes);
            val_8 = val_6 - val_8;
            // 0x016855AC: STR x8, [x19, #0x28]       | val_3.totalBytes = ((val_5 + val_3.totalBytes) - val_3.tmpBytes);  //  dest_result_addr=0
            val_3.totalBytes = val_8;
            // 0x016855B0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016855B4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016855B8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016855BC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016855C0 (23614912), len: 432  VirtAddr: 0x016855C0 RVA: 0x016855C0 token: 100683736 methodIndex: 49876 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CFA0
        public static void Reset()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            System.Collections.Generic.Dictionary<System.String, ProfilePoint> val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x016855C0: STP x24, x23, [sp, #-0x40]! | stack[1152921513534547056] = ???;  stack[1152921513534547064] = ???;  //  dest_result_addr=1152921513534547056 |  dest_result_addr=1152921513534547064
            // 0x016855C4: STP x22, x21, [sp, #0x10]  | stack[1152921513534547072] = ???;  stack[1152921513534547080] = ???;  //  dest_result_addr=1152921513534547072 |  dest_result_addr=1152921513534547080
            // 0x016855C8: STP x20, x19, [sp, #0x20]  | stack[1152921513534547088] = ???;  stack[1152921513534547096] = ???;  //  dest_result_addr=1152921513534547088 |  dest_result_addr=1152921513534547096
            // 0x016855CC: STP x29, x30, [sp, #0x30]  | stack[1152921513534547104] = ???;  stack[1152921513534547112] = ???;  //  dest_result_addr=1152921513534547104 |  dest_result_addr=1152921513534547112
            // 0x016855D0: ADD x29, sp, #0x30         | X29 = (1152921513534547056 + 48) = 1152921513534547104 (0x100000021421E4A0);
            // 0x016855D4: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x016855D8: LDRB w8, [x19, #0xea]      | W8 = (bool)static_value_037380EA;       
            // 0x016855DC: TBNZ w8, #0, #0x16855f8    | if (static_value_037380EA == true) goto label_0;
            // 0x016855E0: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x016855E4: LDR x8, [x8, #0x9b8]       | X8 = 0x2B8EDA0;                         
            // 0x016855E8: LDR w0, [x8]               | W0 = 0x1228;                            
            // 0x016855EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1228, ????);     
            // 0x016855F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016855F4: STRB w8, [x19, #0xea]      | static_value_037380EA = true;            //  dest_result_addr=57901290
            label_0:
            // 0x016855F8: ADRP x20, #0x363e000       | X20 = 56877056 (0x363E000);             
            // 0x016855FC: LDR x20, [x20, #0x358]     | X20 = 1152921504850882560;              
            // 0x01685600: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_4 = null;
            // 0x01685604: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01685608: TBZ w8, #0, #0x168561c     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168560C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685610: CBNZ w8, #0x168561c        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01685614: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685618: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_4 = null;
            label_2:
            // 0x0168561C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685620: LDR x19, [x8]              | X19 = Pathfinding.AstarProfiler.profiles;
            val_5 = Pathfinding.AstarProfiler.profiles;
            // 0x01685624: CBNZ x19, #0x168562c       | if (Pathfinding.AstarProfiler.profiles != null) goto label_3;
            if(val_5 != null)
            {
                goto label_3;
            }
            // 0x01685628: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_3:
            // 0x0168562C: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x01685630: LDR x8, [x8, #0x1a8]       | X8 = 1152921513534534096;               
            // 0x01685634: MOV x0, x19                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x01685638: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, ProfilePoint>::Clear();
            // 0x0168563C: BL #0x23fd92c              | Pathfinding.AstarProfiler.profiles.Clear();
            val_5.Clear();
            // 0x01685640: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x01685644: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x01685648: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x0168564C: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x01685650: TBZ w8, #0, #0x1685660     | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01685654: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x01685658: CBNZ w8, #0x1685660        | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0168565C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_5:
            // 0x01685660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685664: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685668: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
            System.DateTime val_1 = System.DateTime.UtcNow;
            // 0x0168566C: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01685670: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685674: STP x0, x1, [x8, #8]       | Pathfinding.AstarProfiler.startTime = val_1.ticks._ticks;  Pathfinding.AstarProfiler.profiles.__il2cppRuntimeField_10 = val_1.kind;  //  dest_result_addr=1152921504850886664 |  dest_result_addr=1152921504850886672
            Pathfinding.AstarProfiler.startTime = val_1.ticks._ticks;
            Pathfinding.AstarProfiler.profiles.__il2cppRuntimeField_10 = val_1.kind;
            // 0x01685678: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_6 = null;
            // 0x0168567C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685680: LDR x8, [x8, #0x18]        | X8 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x01685684: CBZ x8, #0x168575c         | if (Pathfinding.AstarProfiler.fastProfiles == null) goto label_11;
            if(Pathfinding.AstarProfiler.fastProfiles == null)
            {
                goto label_11;
            }
            // 0x01685688: ADRP x22, #0x3628000       | X22 = 56786944 (0x3628000);             
            // 0x0168568C: LDR x22, [x22, #0x838]     | X22 = 1152921504850935808;              
            // 0x01685690: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x01685694: B #0x16856a8               |  goto label_7;                          
            goto label_7;
            label_18:
            // 0x01685698: ADD x8, x23, x24, lsl #3   | X8 = (X23 + (X24) << 3);                
            var val_2 = X23 + ((X24) << 3);
            // 0x0168569C: STR x19, [x8, #0x20]       | mem2[0] = Pathfinding.AstarProfiler.profiles;  //  dest_result_addr=0
            mem2[0] = val_5;
            // 0x016856A0: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_6 = null;
            // 0x016856A4: ADD w21, w21, #1           | W21 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            label_7:
            // 0x016856A8: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x016856AC: TBZ w8, #0, #0x16856c0     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x016856B0: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x016856B4: CBNZ w8, #0x16856c0        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x016856B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016856BC: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_6 = null;
            label_9:
            // 0x016856C0: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016856C4: LDR x19, [x8, #0x18]       | X19 = Pathfinding.AstarProfiler.fastProfiles;
            val_5 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x016856C8: CBNZ x19, #0x16856d0       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_10;
            if(val_5 != null)
            {
                goto label_10;
            }
            // 0x016856CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_10:
            // 0x016856D0: LDR w8, [x19, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x016856D4: CMP w21, w8                | STATE = COMPARE(0x1, Pathfinding.AstarProfiler.fastProfiles.Length)
            // 0x016856D8: B.GE #0x168575c            | if (val_7 >= Pathfinding.AstarProfiler.fastProfiles.Length) goto label_11;
            if(val_7 >= Pathfinding.AstarProfiler.fastProfiles.Length)
            {
                goto label_11;
            }
            // 0x016856DC: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_8 = null;
            // 0x016856E0: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x016856E4: TBZ w8, #0, #0x16856f8     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x016856E8: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x016856EC: CBNZ w8, #0x16856f8        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x016856F0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016856F4: LDR x0, [x20]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_8 = null;
            label_13:
            // 0x016856F8: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016856FC: LDR x0, [x22]              | X0 = typeof(AstarProfiler.ProfilePoint);
            AstarProfiler.ProfilePoint val_3 = null;
            // 0x01685700: LDR x23, [x8, #0x18]       | X23 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x01685704: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685708: MOV x19, x0                | X19 = 1152921504850935808 (0x100000000E8C8000);//ML01
            // 0x0168570C: BL #0x168506c              | .ctor();                                
            val_3 = new AstarProfiler.ProfilePoint();
            // 0x01685710: CBNZ x23, #0x1685718       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_14;
            if(Pathfinding.AstarProfiler.fastProfiles != null)
            {
                goto label_14;
            }
            // 0x01685714: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_14:
            // 0x01685718: CBZ x19, #0x168573c        | if ( == 0) goto label_16;               
            if(null == 0)
            {
                goto label_16;
            }
            // 0x0168571C: LDR x8, [x23]              | X8 =  typeof(ProfilePoint[]);           
            // 0x01685720: MOV x0, x19                | X0 = 1152921504850935808 (0x100000000E8C8000);//ML01
            // 0x01685724: LDR x1, [x8, #0x30]        | X1 = ProfilePoint[].__il2cppRuntimeField_element_class;
            // 0x01685728: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x0168572C: CBNZ x0, #0x168573c        | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x01685730: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685734: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685738: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AstarProfiler.ProfilePoint), ????);
            label_16:
            // 0x0168573C: LDR w8, [x23, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x01685740: SXTW x24, w21              | X24 = 1 (0x00000001);                   
            // 0x01685744: CMP w21, w8                | STATE = COMPARE(0x1, Pathfinding.AstarProfiler.fastProfiles.Length)
            // 0x01685748: B.LO #0x1685698            | if (val_7 < Pathfinding.AstarProfiler.fastProfiles.Length) goto label_18;
            if(val_7 < Pathfinding.AstarProfiler.fastProfiles.Length)
            {
                goto label_18;
            }
            // 0x0168574C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685750: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685754: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(AstarProfiler.ProfilePoint), ????);
            // 0x01685758: B #0x1685698               |  goto label_18;                         
            goto label_18;
            label_11:
            // 0x0168575C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01685760: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01685764: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01685768: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0168576C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01685770 (23615344), len: 1624  VirtAddr: 0x01685770 RVA: 0x01685770 token: 100683737 methodIndex: 49877 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285CFD8
        public static void PrintFastResults()
        {
            //
            // Disasemble & Code
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            string val_40;
            // 0x01685770: STP d9, d8, [sp, #-0x70]!  | stack[1152921513534766576] = ???;  stack[1152921513534766584] = ???;  //  dest_result_addr=1152921513534766576 |  dest_result_addr=1152921513534766584
            // 0x01685774: STP x28, x27, [sp, #0x10]  | stack[1152921513534766592] = ???;  stack[1152921513534766600] = ???;  //  dest_result_addr=1152921513534766592 |  dest_result_addr=1152921513534766600
            // 0x01685778: STP x26, x25, [sp, #0x20]  | stack[1152921513534766608] = ???;  stack[1152921513534766616] = ???;  //  dest_result_addr=1152921513534766608 |  dest_result_addr=1152921513534766616
            // 0x0168577C: STP x24, x23, [sp, #0x30]  | stack[1152921513534766624] = ???;  stack[1152921513534766632] = ???;  //  dest_result_addr=1152921513534766624 |  dest_result_addr=1152921513534766632
            // 0x01685780: STP x22, x21, [sp, #0x40]  | stack[1152921513534766640] = ???;  stack[1152921513534766648] = ???;  //  dest_result_addr=1152921513534766640 |  dest_result_addr=1152921513534766648
            // 0x01685784: STP x20, x19, [sp, #0x50]  | stack[1152921513534766656] = ???;  stack[1152921513534766664] = ???;  //  dest_result_addr=1152921513534766656 |  dest_result_addr=1152921513534766664
            // 0x01685788: STP x29, x30, [sp, #0x60]  | stack[1152921513534766672] = ???;  stack[1152921513534766680] = ???;  //  dest_result_addr=1152921513534766672 |  dest_result_addr=1152921513534766680
            // 0x0168578C: ADD x29, sp, #0x60         | X29 = (1152921513534766576 + 96) = 1152921513534766672 (0x1000000214253E50);
            // 0x01685790: SUB sp, sp, #0x50          | SP = (1152921513534766576 - 80) = 1152921513534766496 (0x1000000214253DA0);
            // 0x01685794: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01685798: LDRB w8, [x19, #0xeb]      | W8 = (bool)static_value_037380EB;       
            // 0x0168579C: TBNZ w8, #0, #0x16857b8    | if (static_value_037380EB == true) goto label_0;
            // 0x016857A0: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x016857A4: LDR x8, [x8, #0xc68]       | X8 = 0x2B8ED98;                         
            // 0x016857A8: LDR w0, [x8]               | W0 = 0x1226;                            
            // 0x016857AC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1226, ????);     
            // 0x016857B0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016857B4: STRB w8, [x19, #0xeb]      | static_value_037380EB = true;            //  dest_result_addr=57901291
            label_0:
            // 0x016857B8: STP xzr, xzr, [sp, #0x40]  | stack[1152921513534766560] = 0x0;  stack[1152921513534766568] = 0x0;  //  dest_result_addr=1152921513534766560 |  dest_result_addr=1152921513534766568
            // 0x016857BC: STR wzr, [sp, #0x3c]       | stack[1152921513534766556] = 0x0;        //  dest_result_addr=1152921513534766556
            // 0x016857C0: STP xzr, xzr, [sp, #0x28]  | stack[1152921513534766536] = 0x0;  stack[1152921513534766544] = 0x0;  //  dest_result_addr=1152921513534766536 |  dest_result_addr=1152921513534766544
            // 0x016857C4: ADRP x22, #0x363e000       | X22 = 56877056 (0x363E000);             
            // 0x016857C8: STR xzr, [sp, #0x20]       | stack[1152921513534766528] = 0x0;        //  dest_result_addr=1152921513534766528
            // 0x016857CC: LDR x22, [x22, #0x358]     | X22 = 1152921504850882560;              
            // 0x016857D0: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_36 = null;
            // 0x016857D4: STP xzr, xzr, [sp, #0x10]  | stack[1152921513534766512] = 0x0;  stack[1152921513534766520] = 0x0;  //  dest_result_addr=1152921513534766512 |  dest_result_addr=1152921513534766520
            // 0x016857D8: STR xzr, [sp, #8]          | stack[1152921513534766504] = 0x0;        //  dest_result_addr=1152921513534766504
            // 0x016857DC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x016857E0: TBZ w8, #0, #0x16857f4     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016857E4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x016857E8: CBNZ w8, #0x16857f4        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016857EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016857F0: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_36 = null;
            label_2:
            // 0x016857F4: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016857F8: LDR x19, [x8, #0x18]       | X19 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x016857FC: CBNZ x19, #0x1685808       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_3;
            if(Pathfinding.AstarProfiler.fastProfiles != null)
            {
                goto label_3;
            }
            // 0x01685800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685804: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_3:
            // 0x01685808: LDR x8, [x19, #0x18]       | X8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x0168580C: ORR x9, xzr, #0xfffffffe00000000 | X9 = -8589934592(0xFFFFFFFE00000000);   
            var val_36 = -8589934592;
            // 0x01685810: ADD x9, x9, x8, lsl #32    | X9 = (-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32);
            val_36 = val_36 + ((Pathfinding.AstarProfiler.fastProfiles.Length) << 32);
            // 0x01685814: ASR x20, x9, #0x20         | X20 = ((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32);
            var val_1 = val_36 >> 32;
            // 0x01685818: CMP w20, w8                | STATE = COMPARE(((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32), Pathfinding.AstarProfiler.fastProfiles.Length)
            // 0x0168581C: B.LO #0x168582c            | if (val_1 < Pathfinding.AstarProfiler.fastProfiles.Length) goto label_4;
            if(val_1 < Pathfinding.AstarProfiler.fastProfiles.Length)
            {
                goto label_4;
            }
            // 0x01685820: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685824: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685828: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_4:
            // 0x0168582C: ADD x8, x19, x20, lsl #3   | X8 = (Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfi
            ProfilePoint[] val_2 = Pathfinding.AstarProfiler.fastProfiles + ((((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3);
            // 0x01685830: LDR x19, [x8, #0x20]       | X19 = (Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32; //  not_find_field!2:32
            // 0x01685834: CBNZ x19, #0x168583c       | if ((Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 != 0) goto label_5;
            if(((Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32) != 0)
            {
                goto label_5;
            }
            // 0x01685838: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_5:
            // 0x0168583C: LDR x19, [x19, #0x10]      | X19 = (Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 + 16;
            // 0x01685840: CBNZ x19, #0x1685848       | if ((Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 + 16 != 0) goto label_6;
            if(((Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 + 16) != 0)
            {
                goto label_6;
            }
            // 0x01685844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_6:
            // 0x01685848: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168584C: MOV x0, x19                | X0 = (Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 + 16;//m1
            // 0x01685850: BL #0x14ff87c              | X0 = (Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 + 16.get_Elapsed();
            System.TimeSpan val_3 = (Pathfinding.AstarProfiler.fastProfiles + (((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) >> 32)) << 3) + 32 + 16.Elapsed;
            // 0x01685854: STR x0, [sp, #0x48]        | stack[1152921513534766568] = val_3._ticks;  //  dest_result_addr=1152921513534766568
            // 0x01685858: ADD x0, sp, #0x48          | X0 = (1152921513534766496 + 72) = 1152921513534766568 (0x1000000214253DE8);
            // 0x0168585C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685860: BL #0x1b67e24              | X0 = label_System_Threading_Timer_Change_GL01B67E24();
            // 0x01685864: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x01685868: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x0168586C: MOV v8.16b, v0.16b         | V8 = V0.16B;//m1                        
            float val_37 = V0.16B;
            // 0x01685870: ADRP x19, #0x2a97000       | X19 = 44658688 (0x2A97000);             
            // 0x01685874: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x01685878: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x0168587C: TBZ w8, #0, #0x168588c     | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01685880: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x01685884: CBNZ w8, #0x168588c        | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01685888: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_8:
            // 0x0168588C: LDR d9, [x19, #0x718]      | D9 = 1000;                              
            // 0x01685890: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685894: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685898: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
            System.DateTime val_4 = System.DateTime.UtcNow;
            // 0x0168589C: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x016858A0: MOV x2, x0                 | X2 = val_4.ticks._ticks;//m1            
            // 0x016858A4: MOV x6, x1                 | X6 = val_4.kind;//m1                    
            // 0x016858A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016858AC: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016858B0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x016858B4: MOV x1, x2                 | X1 = val_4.ticks._ticks;//m1            
            // 0x016858B8: MOV x2, x6                 | X2 = val_4.kind;//m1                    
            // 0x016858BC: LDP x3, x4, [x8, #8]       | X3 = Pathfinding.AstarProfiler.startTime; X4 = Pathfinding.AstarProfiler.profiles.__il2cppRuntimeField_10; //  | 
            // 0x016858C0: BL #0x1bb73e0              | X0 = System.DateTime.op_Subtraction(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_4.ticks._ticks}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = val_4.kind}, kind = Pathfinding.AstarProfiler.startTime});
            System.TimeSpan val_5 = System.DateTime.op_Subtraction(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_4.ticks._ticks}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = val_4.kind}, kind = Pathfinding.AstarProfiler.startTime});
            // 0x016858C4: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x016858C8: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x016858CC: STR x0, [sp, #0x40]        | stack[1152921513534766560] = val_5._ticks;  //  dest_result_addr=1152921513534766560
            // 0x016858D0: LDR x8, [x8]               | X8 = typeof(System.Text.StringBuilder); 
            // 0x016858D4: MOV x0, x8                 | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            System.Text.StringBuilder val_6 = null;
            // 0x016858D8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x016858DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016858E0: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x016858E4: BL #0x1b5a30c              | .ctor();                                
            val_6 = new System.Text.StringBuilder();
            // 0x016858E8: CBZ x19, #0x1685908        | if ( == 0) goto label_9;                
            if(null == 0)
            {
                goto label_9;
            }
            // 0x016858EC: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x016858F0: LDR x8, [x8, #0x438]       | X8 = (string**)(1152921513534647120)("============================\n\t\t\t\tProfile results:\n============================\n");
            // 0x016858F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016858F8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x016858FC: LDR x1, [x8]               | X1 = "============================\n\t\t\t\tProfile results:\n============================\n";
            // 0x01685900: BL #0x1b5b818              | X0 = Append(value:  "============================\n\t\t\t\tProfile results:\n============================\n");
            System.Text.StringBuilder val_7 = Append(value:  "============================\n\t\t\t\tProfile results:\n============================\n");
            // 0x01685904: B #0x1685928               |  goto label_10;                         
            goto label_10;
            label_9:
            // 0x01685908: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x0168590C: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x01685910: LDR x8, [x8, #0x438]       | X8 = (string**)(1152921513534647120)("============================\n\t\t\t\tProfile results:\n============================\n");
            // 0x01685914: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685918: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0168591C: LDR x1, [x8]               | X1 = "============================\n\t\t\t\tProfile results:\n============================\n";
            // 0x01685920: BL #0x1b5b818              | X0 = Append(value:  "============================\n\t\t\t\tProfile results:\n============================\n");
            System.Text.StringBuilder val_8 = Append(value:  "============================\n\t\t\t\tProfile results:\n============================\n");
            // 0x01685924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_10:
            // 0x01685928: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x0168592C: LDR x8, [x8, #0xbe8]       | X8 = (string**)(1152921513534655552)("Name\t\t|\tTotal Time\t|\tTotal Calls\t|\tAvg/Call\t|\tBytes");
            // 0x01685930: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685934: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685938: FDIV d8, d8, d9            | D8 = (V0.16B / 1000);                   
            val_37 = val_37 / 1000;
            // 0x0168593C: LDR x1, [x8]               | X1 = "Name\t\t|\tTotal Time\t|\tTotal Calls\t|\tAvg/Call\t|\tBytes";
            // 0x01685940: BL #0x1b5b818              | X0 = Append(value:  "Name\t\t|\tTotal Time\t|\tTotal Calls\t|\tAvg/Call\t|\tBytes");
            System.Text.StringBuilder val_9 = Append(value:  "Name\t\t|\tTotal Time\t|\tTotal Calls\t|\tAvg/Call\t|\tBytes");
            // 0x01685944: ADRP x26, #0x35e8000       | X26 = 56524800 (0x35E8000);             
            // 0x01685948: ADRP x27, #0x361e000       | X27 = 56745984 (0x361E000);             
            // 0x0168594C: ADRP x28, #0x35cd000       | X28 = 56414208 (0x35CD000);             
            // 0x01685950: ADRP x24, #0x35d0000       | X24 = 56426496 (0x35D0000);             
            // 0x01685954: LDR x26, [x26, #0xfc8]     | X26 = (string**)(1152921513534659840)("|   ");
            // 0x01685958: LDR x27, [x27, #0x4a8]     | X27 = (string**)(1152921513534659920)("0.0 ");
            // 0x0168595C: LDR x28, [x28, #0xc60]     | X28 = (string**)(1152921513534660000)("(0.0)");
            // 0x01685960: LDR x24, [x24, #0x610]     | X24 = (string**)(1152921513506795504)("0.000");
            // 0x01685964: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_37 = 0;
            // 0x01685968: B #0x1685970               |  goto label_11;                         
            goto label_11;
            label_42:
            // 0x0168596C: ADD w23, w23, #1           | W23 = (val_37 + 1) = val_37 (0x00000001);
            val_37 = 1;
            label_11:
            // 0x01685970: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_38 = null;
            // 0x01685974: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01685978: TBZ w8, #0, #0x168598c     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x0168597C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685980: CBNZ w8, #0x168598c        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x01685984: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685988: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_38 = null;
            label_13:
            // 0x0168598C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685990: LDR x20, [x8, #0x18]       | X20 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x01685994: CBNZ x20, #0x168599c       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_14;
            if(Pathfinding.AstarProfiler.fastProfiles != null)
            {
                goto label_14;
            }
            // 0x01685998: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_14:
            // 0x0168599C: LDR w8, [x20, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x016859A0: CMP w23, w8                | STATE = COMPARE(0x1, Pathfinding.AstarProfiler.fastProfiles.Length)
            // 0x016859A4: B.GE #0x1685cac            | if (val_37 >= Pathfinding.AstarProfiler.fastProfiles.Length) goto label_15;
            if(val_37 >= Pathfinding.AstarProfiler.fastProfiles.Length)
            {
                goto label_15;
            }
            // 0x016859A8: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_39 = null;
            // 0x016859AC: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x016859B0: TBZ w8, #0, #0x16859c4     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x016859B4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x016859B8: CBNZ w8, #0x16859c4        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x016859BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016859C0: LDR x0, [x22]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_39 = null;
            label_17:
            // 0x016859C4: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x016859C8: LDR x20, [x8, #0x20]       | X20 = Pathfinding.AstarProfiler.fastProfileNames;
            // 0x016859CC: CBNZ x20, #0x16859d4       | if (Pathfinding.AstarProfiler.fastProfileNames != null) goto label_18;
            if(Pathfinding.AstarProfiler.fastProfileNames != null)
            {
                goto label_18;
            }
            // 0x016859D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_18:
            // 0x016859D4: LDR w8, [x20, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfileNames.Length;
            // 0x016859D8: SXTW x21, w23              | X21 = 1 (0x00000001);                   
            // 0x016859DC: CMP w23, w8                | STATE = COMPARE(0x1, Pathfinding.AstarProfiler.fastProfileNames.Length)
            // 0x016859E0: B.LO #0x16859f0            | if (val_37 < Pathfinding.AstarProfiler.fastProfileNames.Length) goto label_19;
            if(val_37 < Pathfinding.AstarProfiler.fastProfileNames.Length)
            {
                goto label_19;
            }
            // 0x016859E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x016859E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016859EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_19:
            // 0x016859F0: LDR x8, [x22]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x016859F4: ADD x9, x20, x21, lsl #3   |  //  not_find_field:Pathfinding.AstarProfiler.fastProfileNames.8
            // 0x016859F8: LDR x20, [x9, #0x20]       | X20 = (-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) + 32;
            // 0x016859FC: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685A00: LDR x25, [x8, #0x18]       | X25 = Pathfinding.AstarProfiler.fastProfiles;
            // 0x01685A04: CBNZ x25, #0x1685a0c       | if (Pathfinding.AstarProfiler.fastProfiles != null) goto label_20;
            if(Pathfinding.AstarProfiler.fastProfiles != null)
            {
                goto label_20;
            }
            // 0x01685A08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_20:
            // 0x01685A0C: LDR w8, [x25, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length;
            // 0x01685A10: CMP w23, w8                | STATE = COMPARE(0x1, Pathfinding.AstarProfiler.fastProfiles.Length)
            // 0x01685A14: B.LO #0x1685a24            | if (val_37 < Pathfinding.AstarProfiler.fastProfiles.Length) goto label_21;
            if(val_37 < Pathfinding.AstarProfiler.fastProfiles.Length)
            {
                goto label_21;
            }
            // 0x01685A18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685A20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_21:
            // 0x01685A24: ADD x8, x25, x21, lsl #3   |  //  not_find_field:Pathfinding.AstarProfiler.fastProfiles.8
            // 0x01685A28: LDR x25, [x8, #0x20]       | X25 = Pathfinding.AstarProfiler.fastProfiles.Length + 32;
            // 0x01685A2C: CBZ x25, #0x1685a3c        | if (Pathfinding.AstarProfiler.fastProfiles.Length + 32 == 0) goto label_22;
            if((Pathfinding.AstarProfiler.fastProfiles.Length + 32) == 0)
            {
                goto label_22;
            }
            // 0x01685A30: LDR w8, [x25, #0x18]       | W8 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 24;
            // 0x01685A34: STR w8, [sp, #0x3c]        | stack[1152921513534766556] = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 24;  //  dest_result_addr=1152921513534766556
            // 0x01685A38: B #0x1685a50               |  goto label_23;                         
            goto label_23;
            label_22:
            // 0x01685A3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685A40: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x01685A44: LDR w8, [x8]               | W8 = 0x9814C0;                          
            // 0x01685A48: STR w8, [sp, #0x3c]        | stack[1152921513534766556] = 0x9814C0;   //  dest_result_addr=1152921513534766556
            // 0x01685A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_23:
            // 0x01685A50: LDR x21, [x25, #0x10]      | X21 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16;
            // 0x01685A54: CBNZ x21, #0x1685a5c       | if (Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16 != 0) goto label_24;
            if((Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16) != 0)
            {
                goto label_24;
            }
            // 0x01685A58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_24:
            // 0x01685A5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685A60: MOV x0, x21                | X0 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16;//m1
            // 0x01685A64: BL #0x14ff87c              | X0 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16.get_Elapsed();
            System.TimeSpan val_10 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16.Elapsed;
            // 0x01685A68: STR x0, [sp, #0x28]        | stack[1152921513534766536] = val_10._ticks;  //  dest_result_addr=1152921513534766536
            // 0x01685A6C: ADD x0, sp, #0x28          | X0 = (1152921513534766496 + 40) = 1152921513534766536 (0x1000000214253DC8);
            // 0x01685A70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685A74: BL #0x1b67e24              | X0 = label_System_Threading_Timer_Change_GL01B67E24();
            // 0x01685A78: LDR w8, [sp, #0x3c]        | W8 = 0x9814C0;                          
            // 0x01685A7C: SCVTF d1, w8               | D1 = 9966784;                           
            double val_38 = 9966784;
            // 0x01685A80: FMUL d1, d8, d1            | D1 = ((V0.16B / 1000) * 9966784);       
            val_38 = val_37 * val_38;
            // 0x01685A84: FSUB d0, d0, d1            | D0 = (D0 - ((V0.16B / 1000) * 9966784));
            double val_11 = D0 - val_38;
            // 0x01685A88: STR d0, [sp, #0x30]        | stack[1152921513534766544] = (D0 - ((V0.16B / 1000) * 9966784));  //  dest_result_addr=1152921513534766544
            // 0x01685A8C: CMP w8, #1                 | STATE = COMPARE(0x9814C0, 0x1)          
            // 0x01685A90: B.LT #0x168596c            | if (9966784 < 0x1) goto label_42;       
            if(9966784 < 1)
            {
                goto label_42;
            }
            // 0x01685A94: CBNZ x19, #0x1685a9c       | if ( != 0) goto label_26;               
            if(null != 0)
            {
                goto label_26;
            }
            // 0x01685A98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000214253DC8, ????);
            label_26:
            // 0x01685A9C: ADRP x8, #0x3635000        | X8 = 56840192 (0x3635000);              
            // 0x01685AA0: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509777796272)("\n");
            // 0x01685AA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685AA8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685AAC: LDR x1, [x8]               | X1 = "\n";                              
            // 0x01685AB0: BL #0x1b5b818              | X0 = Append(value:  "\n");              
            System.Text.StringBuilder val_12 = Append(value:  "\n");
            // 0x01685AB4: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x01685AB8: CBNZ x20, #0x1685ac0       | if ((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) + 32 != 0) goto label_27;
            if(((-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) + 32) != 0)
            {
                goto label_27;
            }
            // 0x01685ABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_27:
            // 0x01685AC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685AC4: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x01685AC8: MOV x0, x20                | X0 = (-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) + 32;//m1
            // 0x01685ACC: BL #0x18ada40              | X0 = (-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) + 32.PadLeft(totalWidth:  10);
            string val_13 = (-8589934592 + (Pathfinding.AstarProfiler.fastProfiles.Length) << 32) + 32.PadLeft(totalWidth:  10);
            // 0x01685AD0: MOV x20, x0                | X20 = val_13;//m1                       
            // 0x01685AD4: CBNZ x21, #0x1685adc       | if (val_12 != null) goto label_28;      
            if(val_12 != null)
            {
                goto label_28;
            }
            // 0x01685AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_28:
            // 0x01685ADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685AE0: MOV x0, x21                | X0 = val_12;//m1                        
            // 0x01685AE4: MOV x1, x20                | X1 = val_13;//m1                        
            // 0x01685AE8: BL #0x1b5b818              | X0 = val_12.Append(value:  val_13);     
            System.Text.StringBuilder val_14 = val_12.Append(value:  val_13);
            // 0x01685AEC: MOV x20, x0                | X20 = val_14;//m1                       
            // 0x01685AF0: CBNZ x20, #0x1685af8       | if (val_14 != null) goto label_29;      
            if(val_14 != null)
            {
                goto label_29;
            }
            // 0x01685AF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_29:
            // 0x01685AF8: LDR x1, [x26]              | X1 = "|   ";                            
            // 0x01685AFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685B00: MOV x0, x20                | X0 = val_14;//m1                        
            // 0x01685B04: BL #0x1b5b818              | X0 = val_14.Append(value:  "|   ");     
            System.Text.StringBuilder val_15 = val_14.Append(value:  "|   ");
            // 0x01685B08: LDR x1, [x27]              | X1 = "0.0 ";                            
            // 0x01685B0C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685B10: ADD x0, sp, #0x30          | X0 = (1152921513534766496 + 48) = 1152921513534766544 (0x1000000214253DD0);
            // 0x01685B14: BL #0x1c3883c              | X0 = (D0 - ((V0.16B / 1000) * 9966784)).ToString(format:  "0.0 ");
            string val_16 = val_11.ToString(format:  "0.0 ");
            // 0x01685B18: MOV x20, x0                | X20 = val_16;//m1                       
            // 0x01685B1C: CBNZ x20, #0x1685b24       | if (val_16 != null) goto label_30;      
            if(val_16 != null)
            {
                goto label_30;
            }
            // 0x01685B20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_30:
            // 0x01685B24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685B28: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x01685B2C: MOV x0, x20                | X0 = val_16;//m1                        
            // 0x01685B30: BL #0x18ada40              | X0 = val_16.PadLeft(totalWidth:  10);   
            string val_17 = val_16.PadLeft(totalWidth:  10);
            // 0x01685B34: MOV x20, x0                | X20 = val_17;//m1                       
            // 0x01685B38: CBNZ x19, #0x1685b40       | if ( != 0) goto label_31;               
            if(null != 0)
            {
                goto label_31;
            }
            // 0x01685B3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_31:
            // 0x01685B40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685B44: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685B48: MOV x1, x20                | X1 = val_17;//m1                        
            // 0x01685B4C: BL #0x1b5b818              | X0 = Append(value:  val_17);            
            System.Text.StringBuilder val_18 = Append(value:  val_17);
            // 0x01685B50: MOV x20, x0                | X20 = val_18;//m1                       
            // 0x01685B54: CBNZ x25, #0x1685b5c       | if (Pathfinding.AstarProfiler.fastProfiles.Length + 32 != 0) goto label_32;
            if((Pathfinding.AstarProfiler.fastProfiles.Length + 32) != 0)
            {
                goto label_32;
            }
            // 0x01685B58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_32:
            // 0x01685B5C: LDR x21, [x25, #0x10]      | X21 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16;
            // 0x01685B60: CBNZ x21, #0x1685b68       | if (Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16 != 0) goto label_33;
            if((Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16) != 0)
            {
                goto label_33;
            }
            // 0x01685B64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_33:
            // 0x01685B68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685B6C: MOV x0, x21                | X0 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16;//m1
            // 0x01685B70: BL #0x14ff87c              | X0 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16.get_Elapsed();
            System.TimeSpan val_19 = Pathfinding.AstarProfiler.fastProfiles.Length + 32 + 16.Elapsed;
            // 0x01685B74: STR x0, [sp, #0x20]        | stack[1152921513534766528] = val_19._ticks;  //  dest_result_addr=1152921513534766528
            // 0x01685B78: ADD x0, sp, #0x20          | X0 = (1152921513534766496 + 32) = 1152921513534766528 (0x1000000214253DC0);
            // 0x01685B7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685B80: BL #0x1b67e24              | X0 = label_System_Threading_Timer_Change_GL01B67E24();
            // 0x01685B84: LDR x1, [x28]              | X1 = "(0.0)";                           
            // 0x01685B88: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685B8C: ADD x0, sp, #0x18          | X0 = (1152921513534766496 + 24) = 1152921513534766520 (0x1000000214253DB8);
            // 0x01685B90: STR d0, [sp, #0x18]        | stack[1152921513534766520] = (D0 - ((V0.16B / 1000) * 9966784));  //  dest_result_addr=1152921513534766520
            // 0x01685B94: BL #0x1c3883c              | X0 = (D0 - ((V0.16B / 1000) * 9966784)).ToString(format:  "(0.0)");
            string val_20 = val_11.ToString(format:  "(0.0)");
            // 0x01685B98: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x01685B9C: CBNZ x21, #0x1685ba4       | if (val_20 != null) goto label_34;      
            if(val_20 != null)
            {
                goto label_34;
            }
            // 0x01685BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            label_34:
            // 0x01685BA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685BA8: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x01685BAC: MOV x0, x21                | X0 = val_20;//m1                        
            // 0x01685BB0: BL #0x18ada40              | X0 = val_20.PadLeft(totalWidth:  10);   
            string val_21 = val_20.PadLeft(totalWidth:  10);
            // 0x01685BB4: MOV x21, x0                | X21 = val_21;//m1                       
            // 0x01685BB8: CBNZ x20, #0x1685bc0       | if (val_18 != null) goto label_35;      
            if(val_18 != null)
            {
                goto label_35;
            }
            // 0x01685BBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_35:
            // 0x01685BC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685BC4: MOV x0, x20                | X0 = val_18;//m1                        
            // 0x01685BC8: MOV x1, x21                | X1 = val_21;//m1                        
            // 0x01685BCC: BL #0x1b5b818              | X0 = val_18.Append(value:  val_21);     
            System.Text.StringBuilder val_22 = val_18.Append(value:  val_21);
            // 0x01685BD0: MOV x20, x0                | X20 = val_22;//m1                       
            // 0x01685BD4: CBNZ x20, #0x1685bdc       | if (val_22 != null) goto label_36;      
            if(val_22 != null)
            {
                goto label_36;
            }
            // 0x01685BD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_36:
            // 0x01685BDC: LDR x1, [x26]              | X1 = "|   ";                            
            // 0x01685BE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685BE4: MOV x0, x20                | X0 = val_22;//m1                        
            // 0x01685BE8: BL #0x1b5b818              | X0 = val_22.Append(value:  "|   ");     
            System.Text.StringBuilder val_23 = val_22.Append(value:  "|   ");
            // 0x01685BEC: ADD x0, sp, #0x3c          | X0 = (1152921513534766496 + 60) = 1152921513534766556 (0x1000000214253DDC);
            // 0x01685BF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685BF4: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
            // 0x01685BF8: MOV x20, x0                | X20 = 1152921513534766556 (0x1000000214253DDC);//ML01
            // 0x01685BFC: CBNZ x20, #0x1685c04       | if (0x9814C0 != 0) goto label_37;       
            if(9966784 != 0)
            {
                goto label_37;
            }
            // 0x01685C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000214253DDC, ????);
            label_37:
            // 0x01685C04: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685C08: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x01685C0C: MOV x0, x20                | X0 = 1152921513534766556 (0x1000000214253DDC);//ML01
            // 0x01685C10: BL #0x18ada40              | X0 = 0x9814C0.PadLeft(totalWidth:  10); 
            string val_24 = 9966784.PadLeft(totalWidth:  10);
            // 0x01685C14: MOV x20, x0                | X20 = val_24;//m1                       
            // 0x01685C18: CBNZ x19, #0x1685c20       | if ( != 0) goto label_38;               
            if(null != 0)
            {
                goto label_38;
            }
            // 0x01685C1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_24, ????);     
            label_38:
            // 0x01685C20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685C24: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685C28: MOV x1, x20                | X1 = val_24;//m1                        
            // 0x01685C2C: BL #0x1b5b818              | X0 = Append(value:  val_24);            
            System.Text.StringBuilder val_25 = Append(value:  val_24);
            // 0x01685C30: MOV x20, x0                | X20 = val_25;//m1                       
            // 0x01685C34: CBNZ x20, #0x1685c3c       | if (val_25 != null) goto label_39;      
            if(val_25 != null)
            {
                goto label_39;
            }
            // 0x01685C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            label_39:
            // 0x01685C3C: LDR x1, [x26]              | X1 = "|   ";                            
            // 0x01685C40: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685C44: MOV x0, x20                | X0 = val_25;//m1                        
            // 0x01685C48: BL #0x1b5b818              | X0 = val_25.Append(value:  "|   ");     
            System.Text.StringBuilder val_26 = val_25.Append(value:  "|   ");
            // 0x01685C4C: LDR w8, [sp, #0x3c]        | W8 = 0x9814C0;                          
            // 0x01685C50: LDR d0, [sp, #0x30]        | D0 = (D0 - ((V0.16B / 1000) * 9966784));
            double val_39 = val_11;
            // 0x01685C54: LDR x1, [x24]              | X1 = "0.000";                           
            // 0x01685C58: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685C5C: SCVTF d1, w8               | D1 = 9966784;                           
            // 0x01685C60: FDIV d0, d0, d1            | D0 = ((D0 - ((V0.16B / 1000) * 9966784)) / 9966784);
            val_39 = val_39 / 9966784;
            // 0x01685C64: ADD x0, sp, #0x10          | X0 = (1152921513534766496 + 16) = 1152921513534766512 (0x1000000214253DB0);
            // 0x01685C68: STR d0, [sp, #0x10]        | stack[1152921513534766512] = ((D0 - ((V0.16B / 1000) * 9966784)) / 9966784);  //  dest_result_addr=1152921513534766512
            // 0x01685C6C: BL #0x1c3883c              | X0 = ((D0 - ((V0.16B / 1000) * 9966784)) / 9966784).ToString(format:  "0.000");
            string val_27 = val_39.ToString(format:  "0.000");
            // 0x01685C70: MOV x20, x0                | X20 = val_27;//m1                       
            // 0x01685C74: CBNZ x20, #0x1685c7c       | if (val_27 != null) goto label_40;      
            if(val_27 != null)
            {
                goto label_40;
            }
            // 0x01685C78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_40:
            // 0x01685C7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685C80: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x01685C84: MOV x0, x20                | X0 = val_27;//m1                        
            // 0x01685C88: BL #0x18ada40              | X0 = val_27.PadLeft(totalWidth:  10);   
            string val_28 = val_27.PadLeft(totalWidth:  10);
            // 0x01685C8C: MOV x20, x0                | X20 = val_28;//m1                       
            // 0x01685C90: CBNZ x19, #0x1685c98       | if ( != 0) goto label_41;               
            if(null != 0)
            {
                goto label_41;
            }
            // 0x01685C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_41:
            // 0x01685C98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685C9C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685CA0: MOV x1, x20                | X1 = val_28;//m1                        
            // 0x01685CA4: BL #0x1b5b818              | X0 = Append(value:  val_28);            
            System.Text.StringBuilder val_29 = Append(value:  val_28);
            // 0x01685CA8: B #0x168596c               |  goto label_42;                         
            goto label_42;
            label_15:
            // 0x01685CAC: CBNZ x19, #0x1685cb4       | if ( != 0) goto label_43;               
            if(null != 0)
            {
                goto label_43;
            }
            // 0x01685CB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_43:
            // 0x01685CB4: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
            // 0x01685CB8: LDR x8, [x8, #0x520]       | X8 = (string**)(1152921513534729712)("\n\n============================\n\t\tTotal runtime: ");
            // 0x01685CBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685CC0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685CC4: LDR x1, [x8]               | X1 = "\n\n============================\n\t\tTotal runtime: ";
            // 0x01685CC8: BL #0x1b5b818              | X0 = Append(value:  "\n\n============================\n\t\tTotal runtime: ");
            System.Text.StringBuilder val_30 = Append(value:  "\n\n============================\n\t\tTotal runtime: ");
            // 0x01685CCC: ADD x0, sp, #0x40          | X0 = (1152921513534766496 + 64) = 1152921513534766560 (0x1000000214253DE0);
            // 0x01685CD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685CD4: BL #0x1b6a030              | X0 = label_System_TimeSpan_get_TotalMinutes_GL01B6A030();
            // 0x01685CD8: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x01685CDC: LDR x8, [x8, #0xa60]       | X8 = (string**)(1152921513534733984)("F3");
            // 0x01685CE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685CE4: ADD x0, sp, #8             | X0 = (1152921513534766496 + 8) = 1152921513534766504 (0x1000000214253DA8);
            // 0x01685CE8: STR d0, [sp, #8]           | stack[1152921513534766504] = ???;        //  dest_result_addr=1152921513534766504
            // 0x01685CEC: LDR x1, [x8]               | X1 = "F3";                              
            // 0x01685CF0: BL #0x1c3883c              | X0 = ToString(format:  "F3");           
            string val_31 = ???.ToString(format:  "F3");
            // 0x01685CF4: MOV x20, x0                | X20 = val_31;//m1                       
            // 0x01685CF8: CBZ x19, #0x1685d28        | if ( == 0) goto label_44;               
            if(null == 0)
            {
                goto label_44;
            }
            // 0x01685CFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685D00: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685D04: MOV x1, x20                | X1 = val_31;//m1                        
            // 0x01685D08: BL #0x1b5b818              | X0 = Append(value:  val_31);            
            System.Text.StringBuilder val_32 = Append(value:  val_31);
            // 0x01685D0C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x01685D10: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513534742256)(" seconds\n============================");
            // 0x01685D14: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685D18: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685D1C: LDR x1, [x8]               | X1 = " seconds\n============================";
            val_40 = " seconds\n============================";
            // 0x01685D20: BL #0x1b5b818              | X0 = Append(value:  val_40 = " seconds\n============================");
            System.Text.StringBuilder val_33 = Append(value:  val_40);
            // 0x01685D24: B #0x1685d5c               |  goto label_45;                         
            goto label_45;
            label_44:
            // 0x01685D28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            // 0x01685D2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685D30: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685D34: MOV x1, x20                | X1 = val_31;//m1                        
            // 0x01685D38: BL #0x1b5b818              | X0 = Append(value:  val_31);            
            System.Text.StringBuilder val_34 = Append(value:  val_31);
            // 0x01685D3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_34, ????);     
            // 0x01685D40: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x01685D44: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513534742256)(" seconds\n============================");
            // 0x01685D48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685D4C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685D50: LDR x1, [x8]               | X1 = " seconds\n============================";
            val_40 = " seconds\n============================";
            // 0x01685D54: BL #0x1b5b818              | X0 = Append(value:  val_40 = " seconds\n============================");
            System.Text.StringBuilder val_35 = Append(value:  val_40);
            // 0x01685D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_45:
            // 0x01685D5C: LDR x8, [x19]              | X8 = ;                                  
            // 0x01685D60: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685D64: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x01685D68: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x01685D6C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01685D70: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01685D74: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685D78: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01685D7C: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01685D80: TBZ w9, #0, #0x1685d94     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_47;
            // 0x01685D84: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01685D88: CBNZ w9, #0x1685d94        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_47;
            // 0x01685D8C: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x01685D90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_47:
            // 0x01685D94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685D98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685D9C: MOV x1, x19                | X1 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685DA0: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
            UnityEngine.Debug.Log(message:  0);
            // 0x01685DA4: SUB sp, x29, #0x60         | SP = (1152921513534766672 - 96) = 1152921513534766576 (0x1000000214253DF0);
            // 0x01685DA8: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
            // 0x01685DAC: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
            // 0x01685DB0: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
            // 0x01685DB4: LDP x24, x23, [sp, #0x30]  | X24 = ; X23 = ;                          //  | 
            // 0x01685DB8: LDP x26, x25, [sp, #0x20]  | X26 = ; X25 = ;                          //  | 
            // 0x01685DBC: LDP x28, x27, [sp, #0x10]  | X28 = ; X27 = ;                          //  | 
            // 0x01685DC0: LDP d9, d8, [sp], #0x70    | D9 = ; D8 = ;                            //  | 
            // 0x01685DC4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01685DC8 (23616968), len: 2036  VirtAddr: 0x01685DC8 RVA: 0x01685DC8 token: 100683738 methodIndex: 49878 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.ConditionalAttribute] // 0x285D010
        public static void PrintResults()
        {
            //
            // Disasemble & Code
            //  | 
            float val_6;
            //  | 
            var val_7;
            //  | 
            var val_50;
            //  | 
            var val_51;
            //  | 
            var val_52;
            //  | 
            var val_53;
            //  | 
            var val_54;
            //  | 
            string val_55;
            // 0x01685DC8: STP x28, x27, [sp, #-0x60]! | stack[1152921513535143312] = ???;  stack[1152921513535143320] = ???;  //  dest_result_addr=1152921513535143312 |  dest_result_addr=1152921513535143320
            // 0x01685DCC: STP x26, x25, [sp, #0x10]  | stack[1152921513535143328] = ???;  stack[1152921513535143336] = ???;  //  dest_result_addr=1152921513535143328 |  dest_result_addr=1152921513535143336
            // 0x01685DD0: STP x24, x23, [sp, #0x20]  | stack[1152921513535143344] = ???;  stack[1152921513535143352] = ???;  //  dest_result_addr=1152921513535143344 |  dest_result_addr=1152921513535143352
            // 0x01685DD4: STP x22, x21, [sp, #0x30]  | stack[1152921513535143360] = ???;  stack[1152921513535143368] = ???;  //  dest_result_addr=1152921513535143360 |  dest_result_addr=1152921513535143368
            // 0x01685DD8: STP x20, x19, [sp, #0x40]  | stack[1152921513535143376] = ???;  stack[1152921513535143384] = ???;  //  dest_result_addr=1152921513535143376 |  dest_result_addr=1152921513535143384
            // 0x01685DDC: STP x29, x30, [sp, #0x50]  | stack[1152921513535143392] = ???;  stack[1152921513535143400] = ???;  //  dest_result_addr=1152921513535143392 |  dest_result_addr=1152921513535143400
            // 0x01685DE0: ADD x29, sp, #0x50         | X29 = (1152921513535143312 + 80) = 1152921513535143392 (0x10000002142AFDE0);
            // 0x01685DE4: SUB sp, sp, #0xc0          | SP = (1152921513535143312 - 192) = 1152921513535143120 (0x10000002142AFCD0);
            // 0x01685DE8: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01685DEC: LDRB w8, [x19, #0xec]      | W8 = (bool)static_value_037380EC;       
            // 0x01685DF0: TBNZ w8, #0, #0x1685e0c    | if (static_value_037380EC == true) goto label_0;
            // 0x01685DF4: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x01685DF8: LDR x8, [x8, #0xa78]       | X8 = 0x2B8ED9C;                         
            // 0x01685DFC: LDR w0, [x8]               | W0 = 0x1227;                            
            // 0x01685E00: BL #0x2782188              | X0 = sub_2782188( ?? 0x1227, ????);     
            // 0x01685E04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01685E08: STRB w8, [x19, #0xec]      | static_value_037380EC = true;            //  dest_result_addr=57901292
            label_0:
            // 0x01685E0C: STP xzr, xzr, [x29, #-0x60] | stack[1152921513535143296] = 0x0;  stack[1152921513535143304] = 0x0;  //  dest_result_addr=1152921513535143296 |  dest_result_addr=1152921513535143304
            // 0x01685E10: STUR xzr, [x29, #-0x68]    | stack[1152921513535143288] = 0x0;        //  dest_result_addr=1152921513535143288
            // 0x01685E14: STP xzr, xzr, [sp, #0x90]  | stack[1152921513535143264] = 0x0;  stack[1152921513535143272] = 0x0;  //  dest_result_addr=1152921513535143264 |  dest_result_addr=1152921513535143272
            // 0x01685E18: STP xzr, xzr, [sp, #0x80]  | stack[1152921513535143248] = 0x0;  stack[1152921513535143256] = 0x0;  //  dest_result_addr=1152921513535143248 |  dest_result_addr=1152921513535143256
            // 0x01685E1C: STP xzr, xzr, [sp, #0x70]  | stack[1152921513535143232] = 0x0;  stack[1152921513535143240] = 0x0;  //  dest_result_addr=1152921513535143232 |  dest_result_addr=1152921513535143240
            // 0x01685E20: STP xzr, xzr, [sp, #0x60]  | stack[1152921513535143216] = 0x0;  stack[1152921513535143224] = 0x0;  //  dest_result_addr=1152921513535143216 |  dest_result_addr=1152921513535143224
            // 0x01685E24: STP xzr, xzr, [sp, #0x50]  | stack[1152921513535143200] = 0x0;  stack[1152921513535143208] = 0x0;  //  dest_result_addr=1152921513535143200 |  dest_result_addr=1152921513535143208
            // 0x01685E28: STP xzr, xzr, [sp, #0x40]  | stack[1152921513535143184] = 0x0;  stack[1152921513535143192] = 0x0;  //  dest_result_addr=1152921513535143184 |  dest_result_addr=1152921513535143192
            // 0x01685E2C: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x01685E30: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x01685E34: STR wzr, [sp, #0x3c]       | stack[1152921513535143180] = 0x0;        //  dest_result_addr=1152921513535143180
            // 0x01685E38: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x01685E3C: STP xzr, xzr, [sp, #0x28]  | stack[1152921513535143160] = 0x0;  stack[1152921513535143168] = 0x0;  //  dest_result_addr=1152921513535143160 |  dest_result_addr=1152921513535143168
            // 0x01685E40: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x01685E44: TBZ w8, #0, #0x1685e54     | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01685E48: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x01685E4C: CBNZ w8, #0x1685e54        | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01685E50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_2:
            // 0x01685E54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685E58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685E5C: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
            System.DateTime val_1 = System.DateTime.UtcNow;
            // 0x01685E60: ADRP x26, #0x363e000       | X26 = 56877056 (0x363E000);             
            // 0x01685E64: LDR x26, [x26, #0x358]     | X26 = 1152921504850882560;              
            // 0x01685E68: MOV x19, x0                | X19 = val_1.ticks._ticks;//m1           
            // 0x01685E6C: MOV x20, x1                | X20 = val_1.kind;//m1                   
            // 0x01685E70: LDR x0, [x26]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_50 = null;
            // 0x01685E74: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x01685E78: TBZ w8, #0, #0x1685e8c     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01685E7C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01685E80: CBNZ w8, #0x1685e8c        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01685E84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x01685E88: LDR x0, [x26]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_50 = null;
            label_4:
            // 0x01685E8C: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685E90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685E94: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01685E98: MOV x1, x19                | X1 = val_1.ticks._ticks;//m1            
            // 0x01685E9C: LDP x3, x4, [x8, #8]       | X3 = Pathfinding.AstarProfiler.startTime; X4 = Pathfinding.AstarProfiler.profiles.__il2cppRuntimeField_10; //  | 
            // 0x01685EA0: MOV x2, x20                | X2 = val_1.kind;//m1                    
            // 0x01685EA4: BL #0x1bb73e0              | X0 = System.DateTime.op_Subtraction(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_1.ticks._ticks}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = val_1.kind}, kind = Pathfinding.AstarProfiler.startTime});
            System.TimeSpan val_2 = System.DateTime.op_Subtraction(d1:  new System.DateTime() {ticks = new System.TimeSpan(), kind = val_1.ticks._ticks}, d2:  new System.DateTime() {ticks = new System.TimeSpan() {_ticks = val_1.kind}, kind = Pathfinding.AstarProfiler.startTime});
            // 0x01685EA8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x01685EAC: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x01685EB0: STUR x0, [x29, #-0x58]     | stack[1152921513535143304] = val_2._ticks;  //  dest_result_addr=1152921513535143304
            // 0x01685EB4: LDR x8, [x8]               | X8 = typeof(System.Text.StringBuilder); 
            // 0x01685EB8: MOV x0, x8                 | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            System.Text.StringBuilder val_3 = null;
            // 0x01685EBC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x01685EC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685EC4: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685EC8: BL #0x1b5a30c              | .ctor();                                
            val_3 = new System.Text.StringBuilder();
            // 0x01685ECC: CBNZ x19, #0x1685ed4       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x01685ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x01685ED4: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x01685ED8: LDR x8, [x8, #0x438]       | X8 = (string**)(1152921513534647120)("============================\n\t\t\t\tProfile results:\n============================\n");
            // 0x01685EDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01685EE0: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01685EE4: LDR x1, [x8]               | X1 = "============================\n\t\t\t\tProfile results:\n============================\n";
            // 0x01685EE8: BL #0x1b5b818              | X0 = Append(value:  "============================\n\t\t\t\tProfile results:\n============================\n");
            System.Text.StringBuilder val_4 = Append(value:  "============================\n\t\t\t\tProfile results:\n============================\n");
            // 0x01685EEC: LDR x8, [x26]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01685EF0: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01685EF4: LDR x20, [x8]              | X20 = Pathfinding.AstarProfiler.profiles;
            // 0x01685EF8: CBNZ x20, #0x1685f00       | if (Pathfinding.AstarProfiler.profiles != null) goto label_6;
            if(Pathfinding.AstarProfiler.profiles != null)
            {
                goto label_6;
            }
            // 0x01685EFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_6:
            // 0x01685F00: ADRP x27, #0x360d000       | X27 = 56676352 (0x360D000);             
            // 0x01685F04: LDR x27, [x27, #0xe98]     | X27 = 1152921513534977280;              
            // 0x01685F08: ADD x8, sp, #8             | X8 = (1152921513535143120 + 8) = 1152921513535143128 (0x10000002142AFCD8);
            // 0x01685F0C: MOV x0, x20                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x01685F10: LDR x1, [x27]              | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, ProfilePoint>::GetEnumerator();
            // 0x01685F14: BL #0x23ff0fc              | X0 = Pathfinding.AstarProfiler.profiles.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_5 = Pathfinding.AstarProfiler.profiles.GetEnumerator();
            // 0x01685F18: LDUR q0, [sp, #0x18]       | Q0 = val_6;                              //  find_add[1152921513535131408]
            // 0x01685F1C: LDUR q1, [sp, #8]          | Q1 = val_7;                              //  find_add[1152921513535131408]
            // 0x01685F20: ADRP x23, #0x3618000       | X23 = 56721408 (0x3618000);             
            // 0x01685F24: ADRP x24, #0x363d000       | X24 = 56872960 (0x363D000);             
            // 0x01685F28: LDR x23, [x23, #0x588]     | X23 = 1152921513534978304;              
            // 0x01685F2C: LDR x24, [x24, #0xc48]     | X24 = 1152921513534979328;              
            // 0x01685F30: STP q1, q0, [sp, #0x80]    | stack[1152921513535143248] = val_7;  stack[1152921513535143264] = val_6;  //  dest_result_addr=1152921513535143248 |  dest_result_addr=1152921513535143264
            // 0x01685F34: ADRP x25, #0x35e5000       | X25 = 56512512 (0x35E5000);             
            // 0x01685F38: LDR x25, [x25, #0xb40]     | X25 = 1152921513534980352;              
            // 0x01685F3C: MOVZ w0, #0x5              | W0 = 5 (0x5);//ML01                     
            label_9:
            // 0x01685F40: LDR x1, [x23]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, ProfilePoint>::MoveNext();
            // 0x01685F44: MOV w20, w0                | W20 = 5 (0x5);//ML01                    
            // 0x01685F48: ADD x0, sp, #0x80          | X0 = (1152921513535143120 + 128) = 1152921513535143248 (0x10000002142AFD50);
            // 0x01685F4C: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x01685F50: AND w8, w0, #1             | W8 = (1152921513535143248 & 1) = 0 (0x00000000);
            // 0x01685F54: TBZ w8, #0, #0x1685fdc     | if ((0x0 & 0x1) == 0) goto label_7;     
            if((0 & 1) == 0)
            {
                goto label_7;
            }
            // 0x01685F58: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, ProfilePoint>::get_Current();
            // 0x01685F5C: ADD x0, sp, #0x80          | X0 = (1152921513535143120 + 128) = 1152921513535143248 (0x10000002142AFD50);
            // 0x01685F60: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_8 = val_7.GetHandle();
            // 0x01685F64: LDR x8, [x25]              | X8 = public System.String System.Collections.Generic.KeyValuePair<System.String, ProfilePoint>::get_Key();
            // 0x01685F68: STP x0, x1, [x29, #-0x68]  | stack[1152921513535143288] = val_8.m_Handle;  stack[1152921513535143296] = val_8.m_Version;  //  dest_result_addr=1152921513535143288 |  dest_result_addr=1152921513535143296
            // 0x01685F6C: SUB x0, x29, #0x68         | X0 = (1152921513535143392 - 104) = 1152921513535143288 (0x10000002142AFD78);
            // 0x01685F70: MOV x1, x8                 | X1 = 1152921513534980352 (0x1000000214288100);//ML01
            // 0x01685F74: BL #0x1dc9dd4              | X0 = val_8.m_Handle.get_InitialType();  
            System.Type val_9 = val_8.m_Handle.InitialType;
            // 0x01685F78: MOV x21, x0                | X21 = val_9;//m1                        
            // 0x01685F7C: CBNZ x21, #0x1685f84       | if (val_9 != null) goto label_8;        
            if(val_9 != null)
            {
                goto label_8;
            }
            // 0x01685F80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_8:
            // 0x01685F84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685F88: MOV x0, x21                | X0 = val_9;//m1                         
            // 0x01685F8C: BL #0x18a4460              | X0 = val_9.get_Length();                
            int val_10 = val_9.Length;
            // 0x01685F90: MOV w1, w0                 | W1 = val_10;//m1                        
            // 0x01685F94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01685F98: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01685F9C: MOV w2, w20                | W2 = 5 (0x5);//ML01                     
            // 0x01685FA0: BL #0x16f9490              | X0 = System.Math.Max(val1:  0, val2:  val_10);
            int val_11 = System.Math.Max(val1:  0, val2:  val_10);
            // 0x01685FA4: B #0x1685f40               |  goto label_9;                          
            goto label_9;
            // 0x01685FA8: BL #0x981060               | X0 = sub_981060( ?? val_11, ????);      
            // 0x01685FAC: LDR x21, [x0]              | X21 = val_11;                           
            // 0x01685FB0: BL #0x980920               | X0 = sub_980920( ?? val_11, ????);      
            // 0x01685FB4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x01685FB8: LDR x8, [x8, #0x998]       | X8 = 1152921513534985472;               
            // 0x01685FBC: ADD x0, sp, #0x80          | X0 = (1152921513535143120 + 128) = 1152921513535143248 (0x10000002142AFD50);
            // 0x01685FC0: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, ProfilePoint>::Dispose();
            // 0x01685FC4: BL #0xf3acac               | val_7.Dispose();                        
            val_7.Dispose();
            // 0x01685FC8: CBZ x21, #0x1685ff0        | if (val_11 == 0) goto label_11;         
            if(val_11 == 0)
            {
                goto label_11;
            }
            // 0x01685FCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01685FD0: MOV x0, x21                | X0 = val_11;//m1                        
            // 0x01685FD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x01685FD8: B #0x1685ff0               |  goto label_11;                         
            goto label_11;
            label_7:
            // 0x01685FDC: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x01685FE0: LDR x8, [x8, #0x998]       | X8 = 1152921513534985472;               
            // 0x01685FE4: ADD x0, sp, #0x80          | X0 = (1152921513535143120 + 128) = 1152921513535143248 (0x10000002142AFD50);
            // 0x01685FE8: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, ProfilePoint>::Dispose();
            // 0x01685FEC: BL #0xf3acac               | val_7.Dispose();                        
            val_7.Dispose();
            label_11:
            // 0x01685FF0: ADRP x21, #0x3605000       | X21 = 56643584 (0x3605000);             
            // 0x01685FF4: LDR x21, [x21, #0x2b0]     | X21 = (string**)(1152921513534986496)(" Name ");
            // 0x01685FF8: LDR x0, [x21]              | X0 = " Name ";                          
            // 0x01685FFC: CBNZ x0, #0x1686008        | if (" Name " != null) goto label_12;    
            if(" Name " != null)
            {
                goto label_12;
            }
            // 0x01686000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? " Name ", ????);   
            // 0x01686004: LDR x0, [x21]              | X0 = " Name ";                          
            label_12:
            // 0x01686008: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168600C: MOV w1, w20                | W1 = 5 (0x5);//ML01                     
            // 0x01686010: BL #0x18adbb8              | X0 = PadRight(totalWidth:  5);          
            string val_12 = PadRight(totalWidth:  5);
            // 0x01686014: MOV x21, x0                | X21 = val_12;//m1                       
            // 0x01686018: CBNZ x19, #0x1686020       | if ( != 0) goto label_13;               
            if(null != 0)
            {
                goto label_13;
            }
            // 0x0168601C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_13:
            // 0x01686020: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686024: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686028: MOV x1, x21                | X1 = val_12;//m1                        
            // 0x0168602C: BL #0x1b5b818              | X0 = Append(value:  val_12);            
            System.Text.StringBuilder val_13 = Append(value:  val_12);
            // 0x01686030: MOV x21, x0                | X21 = val_13;//m1                       
            // 0x01686034: CBNZ x21, #0x168603c       | if (val_13 != null) goto label_14;      
            if(val_13 != null)
            {
                goto label_14;
            }
            // 0x01686038: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_14:
            // 0x0168603C: ADRP x28, #0x35dd000       | X28 = 56479744 (0x35DD000);             
            // 0x01686040: LDR x28, [x28, #0xb30]     | X28 = (string**)(1152921513534994768)("|");
            // 0x01686044: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686048: MOV x0, x21                | X0 = val_13;//m1                        
            // 0x0168604C: LDR x1, [x28]              | X1 = "|";                               
            // 0x01686050: BL #0x1b5b818              | X0 = val_13.Append(value:  "|");        
            System.Text.StringBuilder val_14 = val_13.Append(value:  "|");
            // 0x01686054: ADRP x22, #0x367b000       | X22 = 57126912 (0x367B000);             
            // 0x01686058: LDR x22, [x22, #0x80]      | X22 = (string**)(1152921513534998944)(" Total Time\t");
            // 0x0168605C: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x01686060: LDR x8, [x22]              | X8 = " Total Time\t";                   
            val_51 = " Total Time\t";
            // 0x01686064: CBNZ x8, #0x1686070        | if (" Total Time\t" != null) goto label_15;
            if(" Total Time\t" != null)
            {
                goto label_15;
            }
            // 0x01686068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            // 0x0168606C: LDR x8, [x22]              | X8 = " Total Time\t";                   
            val_51 = " Total Time\t";
            label_15:
            // 0x01686070: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686074: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x01686078: MOV x0, x8                 | X0 = 1152921513534998944 (0x100000021428C9A0);//ML01
            // 0x0168607C: BL #0x18adbb8              | X0 = PadRight(totalWidth:  20);         
            string val_15 = PadRight(totalWidth:  20);
            // 0x01686080: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x01686084: CBNZ x21, #0x168608c       | if (val_14 != null) goto label_16;      
            if(val_14 != null)
            {
                goto label_16;
            }
            // 0x01686088: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_16:
            // 0x0168608C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686090: MOV x0, x21                | X0 = val_14;//m1                        
            // 0x01686094: MOV x1, x22                | X1 = val_15;//m1                        
            // 0x01686098: BL #0x1b5b818              | X0 = val_14.Append(value:  val_15);     
            System.Text.StringBuilder val_16 = val_14.Append(value:  val_15);
            // 0x0168609C: MOV x21, x0                | X21 = val_16;//m1                       
            // 0x016860A0: CBNZ x21, #0x16860a8       | if (val_16 != null) goto label_17;      
            if(val_16 != null)
            {
                goto label_17;
            }
            // 0x016860A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_17:
            // 0x016860A8: LDR x1, [x28]              | X1 = "|";                               
            // 0x016860AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016860B0: MOV x0, x21                | X0 = val_16;//m1                        
            // 0x016860B4: BL #0x1b5b818              | X0 = val_16.Append(value:  "|");        
            System.Text.StringBuilder val_17 = val_16.Append(value:  "|");
            // 0x016860B8: ADRP x22, #0x3636000       | X22 = 56844288 (0x3636000);             
            // 0x016860BC: LDR x22, [x22, #0x8f8]     | X22 = (string**)(1152921513535011328)(" Total Calls ");
            // 0x016860C0: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x016860C4: LDR x8, [x22]              | X8 = " Total Calls ";                   
            val_52 = " Total Calls ";
            // 0x016860C8: CBNZ x8, #0x16860d4        | if (" Total Calls " != null) goto label_18;
            if(" Total Calls " != null)
            {
                goto label_18;
            }
            // 0x016860CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            // 0x016860D0: LDR x8, [x22]              | X8 = " Total Calls ";                   
            val_52 = " Total Calls ";
            label_18:
            // 0x016860D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016860D8: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x016860DC: MOV x0, x8                 | X0 = 1152921513535011328 (0x100000021428FA00);//ML01
            // 0x016860E0: BL #0x18adbb8              | X0 = PadRight(totalWidth:  20);         
            string val_18 = PadRight(totalWidth:  20);
            // 0x016860E4: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x016860E8: CBNZ x21, #0x16860f0       | if (val_17 != null) goto label_19;      
            if(val_17 != null)
            {
                goto label_19;
            }
            // 0x016860EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_19:
            // 0x016860F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016860F4: MOV x0, x21                | X0 = val_17;//m1                        
            // 0x016860F8: MOV x1, x22                | X1 = val_18;//m1                        
            // 0x016860FC: BL #0x1b5b818              | X0 = val_17.Append(value:  val_18);     
            System.Text.StringBuilder val_19 = val_17.Append(value:  val_18);
            // 0x01686100: MOV x21, x0                | X21 = val_19;//m1                       
            // 0x01686104: CBNZ x21, #0x168610c       | if (val_19 != null) goto label_20;      
            if(val_19 != null)
            {
                goto label_20;
            }
            // 0x01686108: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_20:
            // 0x0168610C: LDR x1, [x28]              | X1 = "|";                               
            // 0x01686110: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686114: MOV x0, x21                | X0 = val_19;//m1                        
            // 0x01686118: BL #0x1b5b818              | X0 = val_19.Append(value:  "|");        
            System.Text.StringBuilder val_20 = val_19.Append(value:  "|");
            // 0x0168611C: ADRP x22, #0x35f8000       | X22 = 56590336 (0x35F8000);             
            // 0x01686120: LDR x22, [x22, #0x248]     | X22 = (string**)(1152921513535023712)(" Avg/Call ");
            // 0x01686124: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x01686128: LDR x8, [x22]              | X8 = " Avg/Call ";                      
            val_53 = " Avg/Call ";
            // 0x0168612C: CBNZ x8, #0x1686138        | if (" Avg/Call " != null) goto label_21;
            if((" Avg/Call ") != null)
            {
                goto label_21;
            }
            // 0x01686130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_20, ????);     
            // 0x01686134: LDR x8, [x22]              | X8 = " Avg/Call ";                      
            val_53 = " Avg/Call ";
            label_21:
            // 0x01686138: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168613C: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x01686140: MOV x0, x8                 | X0 = 1152921513535023712 (0x1000000214292A60);//ML01
            // 0x01686144: BL #0x18adbb8              | X0 = PadRight(totalWidth:  20);         
            string val_21 = PadRight(totalWidth:  20);
            // 0x01686148: MOV x22, x0                | X22 = val_21;//m1                       
            // 0x0168614C: CBNZ x21, #0x1686154       | if (val_20 != null) goto label_22;      
            if(val_20 != null)
            {
                goto label_22;
            }
            // 0x01686150: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
            label_22:
            // 0x01686154: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686158: MOV x0, x21                | X0 = val_20;//m1                        
            // 0x0168615C: MOV x1, x22                | X1 = val_21;//m1                        
            // 0x01686160: BL #0x1b5b818              | X0 = val_20.Append(value:  val_21);     
            System.Text.StringBuilder val_22 = val_20.Append(value:  val_21);
            // 0x01686164: LDR x0, [x26]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_54 = null;
            // 0x01686168: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_10A;
            // 0x0168616C: TBZ w8, #0, #0x1686180     | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_has_cctor == 0) goto label_24;
            // 0x01686170: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished;
            // 0x01686174: CBNZ w8, #0x1686180        | if (Pathfinding.AstarProfiler.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
            // 0x01686178: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.AstarProfiler), ????);
            // 0x0168617C: LDR x0, [x26]              | X0 = typeof(Pathfinding.AstarProfiler); 
            val_54 = null;
            label_24:
            // 0x01686180: LDR x8, [x0, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01686184: LDR x21, [x8]              | X21 = Pathfinding.AstarProfiler.profiles;
            // 0x01686188: CBNZ x21, #0x1686190       | if (Pathfinding.AstarProfiler.profiles != null) goto label_25;
            if(Pathfinding.AstarProfiler.profiles != null)
            {
                goto label_25;
            }
            // 0x0168618C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.AstarProfiler), ????);
            label_25:
            // 0x01686190: LDR x1, [x27]              | X1 = public Dictionary.Enumerator<TKey, TValue> System.Collections.Generic.Dictionary<System.String, ProfilePoint>::GetEnumerator();
            // 0x01686194: ADD x8, sp, #8             | X8 = (1152921513535143120 + 8) = 1152921513535143128 (0x10000002142AFCD8);
            // 0x01686198: MOV x0, x21                | X0 = Pathfinding.AstarProfiler.profiles;//m1
            // 0x0168619C: BL #0x23ff0fc              | X0 = Pathfinding.AstarProfiler.profiles.GetEnumerator();
            Dictionary.Enumerator<TKey, TValue> val_23 = Pathfinding.AstarProfiler.profiles.GetEnumerator();
            // 0x016861A0: ADRP x26, #0x35cf000       | X26 = 56422400 (0x35CF000);             
            // 0x016861A4: ADRP x27, #0x3635000       | X27 = 56840192 (0x3635000);             
            // 0x016861A8: ADRP x28, #0x35ce000       | X28 = 56418304 (0x35CE000);             
            // 0x016861AC: LDUR q0, [sp, #0x18]       | Q0 = val_6;                              //  find_add[1152921513535131408]
            // 0x016861B0: LDUR q1, [sp, #8]          | Q1 = val_7;                              //  find_add[1152921513535131408]
            // 0x016861B4: LDR x26, [x26, #0xa38]     | X26 = 1152921513535032000;              
            // 0x016861B8: LDR x27, [x27, #0x288]     | X27 = (string**)(1152921509777796272)("\n");
            // 0x016861BC: LDR x28, [x28, #0xe78]     | X28 = (string**)(1152921513535033024)("| ");
            // 0x016861C0: STP q1, q0, [sp, #0x50]    | stack[1152921513535143200] = val_7;  stack[1152921513535143216] = val_6;  //  dest_result_addr=1152921513535143200 |  dest_result_addr=1152921513535143216
            label_46:
            // 0x016861C4: LDR x1, [x23]              | X1 = public System.Boolean Dictionary.Enumerator<System.String, ProfilePoint>::MoveNext();
            // 0x016861C8: ADD x0, sp, #0x50          | X0 = (1152921513535143120 + 80) = 1152921513535143200 (0x10000002142AFD20);
            // 0x016861CC: BL #0xf3aa04               | X0 = label_Dictionary_Enumerator<System_Object, System_Object>_System_Collections_IDictionaryEnumerator_get_Value_GL00F3AA04();
            // 0x016861D0: AND w8, w0, #1             | W8 = (1152921513535143200 & 1) = 0 (0x00000000);
            // 0x016861D4: TBZ w8, #0, #0x16865b0     | if ((0x0 & 0x1) == 0) goto label_26;    
            if((0 & 1) == 0)
            {
                goto label_26;
            }
            // 0x016861D8: LDR x1, [x24]              | X1 = public System.Collections.Generic.KeyValuePair<TKey, TValue> Dictionary.Enumerator<System.String, ProfilePoint>::get_Current();
            // 0x016861DC: ADD x0, sp, #0x50          | X0 = (1152921513535143120 + 80) = 1152921513535143200 (0x10000002142AFD20);
            // 0x016861E0: BL #0xf3ac3c               | X0 = val_7.GetHandle();                 
            UnityEngine.Playables.PlayableHandle val_24 = val_7.GetHandle();
            // 0x016861E4: LDR x8, [x26]              | X8 = public ProfilePoint System.Collections.Generic.KeyValuePair<System.String, ProfilePoint>::get_Value();
            // 0x016861E8: STP x0, x1, [sp, #0x70]    | stack[1152921513535143232] = val_24.m_Handle;  stack[1152921513535143240] = val_24.m_Version;  //  dest_result_addr=1152921513535143232 |  dest_result_addr=1152921513535143240
            // 0x016861EC: ADD x0, sp, #0x70          | X0 = (1152921513535143120 + 112) = 1152921513535143232 (0x10000002142AFD40);
            // 0x016861F0: MOV x1, x8                 | X1 = 1152921513535032000 (0x1000000214294AC0);//ML01
            // 0x016861F4: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x016861F8: MOV x21, x0                | X21 = 1152921513535143232 (0x10000002142AFD40);//ML01
            // 0x016861FC: CBNZ x21, #0x1686204       | if (val_24.m_Handle != 0) goto label_27;
            if(val_24.m_Handle != 0)
            {
                goto label_27;
            }
            // 0x01686200: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002142AFD40, ????);
            label_27:
            // 0x01686204: LDR x21, [x21, #0x10]      | X21 = val_7;                            
            // 0x01686208: CBNZ x21, #0x1686210       | if (val_7 != 0) goto label_28;          
            if(val_7 != 0)
            {
                goto label_28;
            }
            // 0x0168620C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002142AFD40, ????);
            label_28:
            // 0x01686210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686214: MOV x0, x21                | X0 = val_7;//m1                         
            // 0x01686218: BL #0x14ff87c              | X0 = val_7.get_Elapsed();               
            System.TimeSpan val_25 = val_7.Elapsed;
            // 0x0168621C: STR x0, [sp, #0x40]        | stack[1152921513535143184] = val_25._ticks;  //  dest_result_addr=1152921513535143184
            // 0x01686220: ADD x0, sp, #0x40          | X0 = (1152921513535143120 + 64) = 1152921513535143184 (0x10000002142AFD10);
            // 0x01686224: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686228: BL #0x1b67e24              | X0 = label_System_Threading_Timer_Change_GL01B67E24();
            // 0x0168622C: LDR x1, [x26]              | X1 = public ProfilePoint System.Collections.Generic.KeyValuePair<System.String, ProfilePoint>::get_Value();
            // 0x01686230: STR d0, [sp, #0x48]        | stack[1152921513535143192] = val_6;      //  dest_result_addr=1152921513535143192
            // 0x01686234: ADD x0, sp, #0x70          | X0 = (1152921513535143120 + 112) = 1152921513535143232 (0x10000002142AFD40);
            // 0x01686238: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x0168623C: MOV x21, x0                | X21 = 1152921513535143232 (0x10000002142AFD40);//ML01
            // 0x01686240: CBNZ x21, #0x1686248       | if (val_24.m_Handle != 0) goto label_29;
            if(val_24.m_Handle != 0)
            {
                goto label_29;
            }
            // 0x01686244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002142AFD40, ????);
            label_29:
            // 0x01686248: LDR w8, [x21, #0x18]       | W8 = val_7;                             
            // 0x0168624C: STR w8, [sp, #0x3c]        | stack[1152921513535143180] = val_7;      //  dest_result_addr=1152921513535143180
            // 0x01686250: CMP w8, #0                 | STATE = COMPARE(val_7, 0x0)             
            // 0x01686254: B.LE #0x16861c4            | if (val_7 <= 0x0) goto label_46;        
            if(val_7 <= 0)
            {
                goto label_46;
            }
            // 0x01686258: LDR x1, [x25]              | X1 = public System.String System.Collections.Generic.KeyValuePair<System.String, ProfilePoint>::get_Key();
            // 0x0168625C: ADD x0, sp, #0x70          | X0 = (1152921513535143120 + 112) = 1152921513535143232 (0x10000002142AFD40);
            // 0x01686260: BL #0x1dc9dd4              | X0 = val_24.m_Handle.get_InitialType(); 
            System.Type val_26 = val_24.m_Handle.InitialType;
            // 0x01686264: MOV x22, x0                | X22 = val_26;//m1                       
            // 0x01686268: CBNZ x19, #0x1686270       | if ( != 0) goto label_31;               
            if(null != 0)
            {
                goto label_31;
            }
            // 0x0168626C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_31:
            // 0x01686270: LDR x1, [x27]              | X1 = "\n";                              
            // 0x01686274: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686278: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0168627C: BL #0x1b5b818              | X0 = Append(value:  "\n");              
            System.Text.StringBuilder val_27 = Append(value:  "\n");
            // 0x01686280: MOV x21, x0                | X21 = val_27;//m1                       
            // 0x01686284: CBNZ x22, #0x168628c       | if (val_26 != null) goto label_32;      
            if(val_26 != null)
            {
                goto label_32;
            }
            // 0x01686288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_27, ????);     
            label_32:
            // 0x0168628C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686290: MOV x0, x22                | X0 = val_26;//m1                        
            // 0x01686294: MOV w1, w20                | W1 = 5 (0x5);//ML01                     
            // 0x01686298: BL #0x18adbb8              | X0 = val_26.PadRight(totalWidth:  5);   
            string val_28 = val_26.PadRight(totalWidth:  5);
            // 0x0168629C: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x016862A0: CBNZ x21, #0x16862a8       | if (val_27 != null) goto label_33;      
            if(val_27 != null)
            {
                goto label_33;
            }
            // 0x016862A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
            label_33:
            // 0x016862A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016862AC: MOV x0, x21                | X0 = val_27;//m1                        
            // 0x016862B0: MOV x1, x22                | X1 = val_28;//m1                        
            // 0x016862B4: BL #0x1b5b818              | X0 = val_27.Append(value:  val_28);     
            System.Text.StringBuilder val_29 = val_27.Append(value:  val_28);
            // 0x016862B8: MOV x21, x0                | X21 = val_29;//m1                       
            // 0x016862BC: CBNZ x21, #0x16862c4       | if (val_29 != null) goto label_34;      
            if(val_29 != null)
            {
                goto label_34;
            }
            // 0x016862C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_34:
            // 0x016862C4: LDR x1, [x28]              | X1 = "| ";                              
            // 0x016862C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016862CC: MOV x0, x21                | X0 = val_29;//m1                        
            // 0x016862D0: BL #0x1b5b818              | X0 = val_29.Append(value:  "| ");       
            System.Text.StringBuilder val_30 = val_29.Append(value:  "| ");
            // 0x016862D4: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x016862D8: LDR x8, [x8, #0x260]       | X8 = (string**)(1152921513159459728)("0.0");
            // 0x016862DC: LDR x1, [x8]               | X1 = "0.0";                             
            // 0x016862E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016862E4: ADD x0, sp, #0x48          | X0 = (1152921513535143120 + 72) = 1152921513535143192 (0x10000002142AFD18);
            // 0x016862E8: BL #0x1c3883c              | X0 = val_6.ToString(format:  "0.0");    
            string val_31 = val_6.ToString(format:  "0.0");
            // 0x016862EC: MOV x21, x0                | X21 = val_31;//m1                       
            // 0x016862F0: CBNZ x21, #0x16862f8       | if (val_31 != null) goto label_35;      
            if(val_31 != null)
            {
                goto label_35;
            }
            // 0x016862F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_31, ????);     
            label_35:
            // 0x016862F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016862FC: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x01686300: MOV x0, x21                | X0 = val_31;//m1                        
            // 0x01686304: BL #0x18adbb8              | X0 = val_31.PadRight(totalWidth:  20);  
            string val_32 = val_31.PadRight(totalWidth:  20);
            // 0x01686308: MOV x21, x0                | X21 = val_32;//m1                       
            // 0x0168630C: CBNZ x19, #0x1686314       | if ( != 0) goto label_36;               
            if(null != 0)
            {
                goto label_36;
            }
            // 0x01686310: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_32, ????);     
            label_36:
            // 0x01686314: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686318: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0168631C: MOV x1, x21                | X1 = val_32;//m1                        
            // 0x01686320: BL #0x1b5b818              | X0 = Append(value:  val_32);            
            System.Text.StringBuilder val_33 = Append(value:  val_32);
            // 0x01686324: MOV x21, x0                | X21 = val_33;//m1                       
            // 0x01686328: CBNZ x21, #0x1686330       | if (val_33 != null) goto label_37;      
            if(val_33 != null)
            {
                goto label_37;
            }
            // 0x0168632C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_33, ????);     
            label_37:
            // 0x01686330: LDR x1, [x28]              | X1 = "| ";                              
            // 0x01686334: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686338: MOV x0, x21                | X0 = val_33;//m1                        
            // 0x0168633C: BL #0x1b5b818              | X0 = val_33.Append(value:  "| ");       
            System.Text.StringBuilder val_34 = val_33.Append(value:  "| ");
            // 0x01686340: ADD x0, sp, #0x3c          | X0 = (1152921513535143120 + 60) = 1152921513535143180 (0x10000002142AFD0C);
            // 0x01686344: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686348: BL #0x1e63cfc              | X0 = label_System_Int32_TryParse_GL01E63CFC();
            // 0x0168634C: MOV x21, x0                | X21 = 1152921513535143180 (0x10000002142AFD0C);//ML01
            // 0x01686350: CBNZ x21, #0x1686358       | if (val_7 != 0) goto label_38;          
            if(val_7 != 0)
            {
                goto label_38;
            }
            // 0x01686354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002142AFD0C, ????);
            label_38:
            // 0x01686358: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168635C: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x01686360: MOV x0, x21                | X0 = 1152921513535143180 (0x10000002142AFD0C);//ML01
            // 0x01686364: BL #0x18adbb8              | X0 = val_7.PadRight(totalWidth:  20);   
            string val_35 = val_7.PadRight(totalWidth:  20);
            // 0x01686368: MOV x21, x0                | X21 = val_35;//m1                       
            // 0x0168636C: CBNZ x19, #0x1686374       | if ( != 0) goto label_39;               
            if(null != 0)
            {
                goto label_39;
            }
            // 0x01686370: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
            label_39:
            // 0x01686374: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686378: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0168637C: MOV x1, x21                | X1 = val_35;//m1                        
            // 0x01686380: BL #0x1b5b818              | X0 = Append(value:  val_35);            
            System.Text.StringBuilder val_36 = Append(value:  val_35);
            // 0x01686384: MOV x21, x0                | X21 = val_36;//m1                       
            // 0x01686388: CBNZ x21, #0x1686390       | if (val_36 != null) goto label_40;      
            if(val_36 != null)
            {
                goto label_40;
            }
            // 0x0168638C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_36, ????);     
            label_40:
            // 0x01686390: LDR x1, [x28]              | X1 = "| ";                              
            // 0x01686394: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686398: MOV x0, x21                | X0 = val_36;//m1                        
            // 0x0168639C: BL #0x1b5b818              | X0 = val_36.Append(value:  "| ");       
            System.Text.StringBuilder val_37 = val_36.Append(value:  "| ");
            // 0x016863A0: ADRP x9, #0x35d0000        | X9 = 56426496 (0x35D0000);              
            // 0x016863A4: LDR w8, [sp, #0x3c]        | W8 = val_7;                             
            // 0x016863A8: LDR d0, [sp, #0x48]        | D0 = val_6;                             
            double val_50 = val_6;
            // 0x016863AC: LDR x9, [x9, #0x610]       | X9 = (string**)(1152921513506795504)("0.000");
            // 0x016863B0: SCVTF d1, w8               | D1 = (double)(val_7);                   
            // 0x016863B4: FDIV d0, d0, d1            | D0 = (val_6 / val_7);                   
            val_50 = val_50 / (double)val_7;
            // 0x016863B8: LDR x1, [x9]               | X1 = "0.000";                           
            // 0x016863BC: STR d0, [sp, #0x30]        | stack[1152921513535143168] = (val_6 / val_7);  //  dest_result_addr=1152921513535143168
            // 0x016863C0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016863C4: ADD x0, sp, #0x30          | X0 = (1152921513535143120 + 48) = 1152921513535143168 (0x10000002142AFD00);
            // 0x016863C8: BL #0x1c3883c              | X0 = (val_6 / val_7).ToString(format:  "0.000");
            string val_38 = val_50.ToString(format:  "0.000");
            // 0x016863CC: MOV x21, x0                | X21 = val_38;//m1                       
            // 0x016863D0: CBNZ x21, #0x16863d8       | if (val_38 != null) goto label_41;      
            if(val_38 != null)
            {
                goto label_41;
            }
            // 0x016863D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_38, ????);     
            label_41:
            // 0x016863D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016863DC: MOVZ w1, #0x14             | W1 = 20 (0x14);//ML01                   
            // 0x016863E0: MOV x0, x21                | X0 = val_38;//m1                        
            // 0x016863E4: BL #0x18adbb8              | X0 = val_38.PadRight(totalWidth:  20);  
            string val_39 = val_38.PadRight(totalWidth:  20);
            // 0x016863E8: MOV x21, x0                | X21 = val_39;//m1                       
            // 0x016863EC: CBNZ x19, #0x16863f4       | if ( != 0) goto label_42;               
            if(null != 0)
            {
                goto label_42;
            }
            // 0x016863F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_39, ????);     
            label_42:
            // 0x016863F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016863F8: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x016863FC: MOV x1, x21                | X1 = val_39;//m1                        
            // 0x01686400: BL #0x1b5b818              | X0 = Append(value:  val_39);            
            System.Text.StringBuilder val_40 = Append(value:  val_39);
            // 0x01686404: LDR x1, [x26]              | X1 = public ProfilePoint System.Collections.Generic.KeyValuePair<System.String, ProfilePoint>::get_Value();
            // 0x01686408: ADD x0, sp, #0x70          | X0 = (1152921513535143120 + 112) = 1152921513535143232 (0x10000002142AFD40);
            // 0x0168640C: BL #0x1dc9dec              | X0 = label_System_Collections_Generic_KeyValuePair<System_Object, System_Object>_set_Key_GL01DC9DEC();
            // 0x01686410: MOV x21, x0                | X21 = 1152921513535143232 (0x10000002142AFD40);//ML01
            // 0x01686414: CBNZ x21, #0x168641c       | if (val_24.m_Handle != 0) goto label_43;
            if(val_24.m_Handle != 0)
            {
                goto label_43;
            }
            // 0x01686418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002142AFD40, ????);
            label_43:
            // 0x0168641C: LDR w1, [x21, #0x28]       | W1 = val_6;                             
            // 0x01686420: BL #0x168486c              | X0 = Pathfinding.AstarMath.FormatBytesBinary(bytes:  338361664);
            string val_41 = Pathfinding.AstarMath.FormatBytesBinary(bytes:  338361664);
            // 0x01686424: MOV x21, x0                | X21 = val_41;//m1                       
            // 0x01686428: CBNZ x21, #0x1686430       | if (val_41 != null) goto label_44;      
            if(val_41 != null)
            {
                goto label_44;
            }
            // 0x0168642C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_41, ????);     
            label_44:
            // 0x01686430: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686434: MOVZ w1, #0xa              | W1 = 10 (0xA);//ML01                    
            // 0x01686438: MOV x0, x21                | X0 = val_41;//m1                        
            // 0x0168643C: BL #0x18ada40              | X0 = val_41.PadLeft(totalWidth:  10);   
            string val_42 = val_41.PadLeft(totalWidth:  10);
            // 0x01686440: MOV x21, x0                | X21 = val_42;//m1                       
            // 0x01686444: CBNZ x19, #0x168644c       | if ( != 0) goto label_45;               
            if(null != 0)
            {
                goto label_45;
            }
            // 0x01686448: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_45:
            // 0x0168644C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686450: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686454: MOV x1, x21                | X1 = val_42;//m1                        
            // 0x01686458: BL #0x1b5b818              | X0 = Append(value:  val_42);            
            System.Text.StringBuilder val_43 = Append(value:  val_42);
            // 0x0168645C: B #0x16861c4               |  goto label_46;                         
            goto label_46;
            // 0x01686460: BL #0x981060               | X0 = sub_981060( ?? val_43, ????);      
            // 0x01686464: LDR x20, [x0]              | X20 = typeof(System.Text.StringBuilder);
            // 0x01686468: BL #0x980920               | X0 = sub_980920( ?? val_43, ????);      
            // 0x0168646C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            label_54:
            // 0x01686470: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x01686474: LDR x8, [x8, #0x998]       | X8 = 1152921513534985472;               
            // 0x01686478: ADD x0, sp, #0x50          | X0 = (1152921513535143120 + 80) = 1152921513535143200 (0x10000002142AFD20);
            // 0x0168647C: LDR x1, [x8]               | X1 = public System.Void Dictionary.Enumerator<System.String, ProfilePoint>::Dispose();
            // 0x01686480: BL #0xf3acac               | val_7.Dispose();                        
            val_7.Dispose();
            // 0x01686484: TBNZ w21, #0, #0x1686498   | if ((0x0 & 0x1) != 0) goto label_48;    
            if((0 & 1) != 0)
            {
                goto label_48;
            }
            // 0x01686488: CBZ x20, #0x1686498        | if (typeof(System.Text.StringBuilder) == null) goto label_48;
            if(null == null)
            {
                goto label_48;
            }
            // 0x0168648C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686490: MOV x0, x20                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686494: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Text.StringBuilder), ????);
            label_48:
            // 0x01686498: CBNZ x19, #0x16864a0       | if ( != 0) goto label_49;               
            if(null != 0)
            {
                goto label_49;
            }
            // 0x0168649C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Text.StringBuilder), ????);
            label_49:
            // 0x016864A0: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
            // 0x016864A4: LDR x8, [x8, #0x520]       | X8 = (string**)(1152921513534729712)("\n\n============================\n\t\tTotal runtime: ");
            // 0x016864A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016864AC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x016864B0: LDR x1, [x8]               | X1 = "\n\n============================\n\t\tTotal runtime: ";
            // 0x016864B4: BL #0x1b5b818              | X0 = Append(value:  "\n\n============================\n\t\tTotal runtime: ");
            System.Text.StringBuilder val_44 = Append(value:  "\n\n============================\n\t\tTotal runtime: ");
            // 0x016864B8: SUB x0, x29, #0x58         | X0 = (1152921513535143392 - 88) = 1152921513535143304 (0x10000002142AFD88);
            // 0x016864BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016864C0: BL #0x1b6a030              | X0 = label_System_TimeSpan_get_TotalMinutes_GL01B6A030();
            // 0x016864C4: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x016864C8: LDR x8, [x8, #0xa60]       | X8 = (string**)(1152921513534733984)("F3");
            // 0x016864CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016864D0: ADD x0, sp, #0x28          | X0 = (1152921513535143120 + 40) = 1152921513535143160 (0x10000002142AFCF8);
            // 0x016864D4: STR d0, [sp, #0x28]        | stack[1152921513535143160] = (val_6 / val_7);  //  dest_result_addr=1152921513535143160
            // 0x016864D8: LDR x1, [x8]               | X1 = "F3";                              
            // 0x016864DC: BL #0x1c3883c              | X0 = (val_6 / val_7).ToString(format:  "F3");
            string val_45 = val_50.ToString(format:  "F3");
            // 0x016864E0: MOV x20, x0                | X20 = val_45;//m1                       
            // 0x016864E4: CBZ x19, #0x1686514        | if ( == 0) goto label_50;               
            if(null == 0)
            {
                goto label_50;
            }
            // 0x016864E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016864EC: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x016864F0: MOV x1, x20                | X1 = val_45;//m1                        
            // 0x016864F4: BL #0x1b5b818              | X0 = Append(value:  val_45);            
            System.Text.StringBuilder val_46 = Append(value:  val_45);
            // 0x016864F8: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x016864FC: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513534742256)(" seconds\n============================");
            // 0x01686500: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686504: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686508: LDR x1, [x8]               | X1 = " seconds\n============================";
            val_55 = " seconds\n============================";
            // 0x0168650C: BL #0x1b5b818              | X0 = Append(value:  val_55 = " seconds\n============================");
            System.Text.StringBuilder val_47 = Append(value:  val_55);
            // 0x01686510: B #0x1686548               |  goto label_51;                         
            goto label_51;
            label_50:
            // 0x01686514: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_45, ????);     
            // 0x01686518: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168651C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686520: MOV x1, x20                | X1 = val_45;//m1                        
            // 0x01686524: BL #0x1b5b818              | X0 = Append(value:  val_45);            
            System.Text.StringBuilder val_48 = Append(value:  val_45);
            // 0x01686528: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_48, ????);     
            // 0x0168652C: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x01686530: LDR x8, [x8, #0x560]       | X8 = (string**)(1152921513534742256)(" seconds\n============================");
            // 0x01686534: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686538: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0168653C: LDR x1, [x8]               | X1 = " seconds\n============================";
            val_55 = " seconds\n============================";
            // 0x01686540: BL #0x1b5b818              | X0 = Append(value:  val_55 = " seconds\n============================");
            System.Text.StringBuilder val_49 = Append(value:  val_55);
            // 0x01686544: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_49, ????);     
            label_51:
            // 0x01686548: LDR x8, [x19]              | X8 = ;                                  
            // 0x0168654C: MOV x0, x19                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686550: LDP x9, x1, [x8, #0x140]   |                                          //  not_find_field!1:320 |  not_find_field!1:328
            // 0x01686554: BLR x9                     | X0 = mem[null + 320]();                 
            // 0x01686558: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0168655C: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01686560: MOV x19, x0                | X19 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x01686564: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01686568: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x0168656C: TBZ w9, #0, #0x1686580     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_53;
            // 0x01686570: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01686574: CBNZ w9, #0x1686580        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_53;
            // 0x01686578: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x0168657C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_53:
            // 0x01686580: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686584: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01686588: MOV x1, x19                | X1 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x0168658C: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
            UnityEngine.Debug.Log(message:  0);
            // 0x01686590: SUB sp, x29, #0x50         | SP = (1152921513535143392 - 80) = 1152921513535143312 (0x10000002142AFD90);
            // 0x01686594: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01686598: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0168659C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x016865A0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x016865A4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x016865A8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x016865AC: RET                        |  return;                                
            return;
            label_26:
            // 0x016865B0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            // 0x016865B4: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            // 0x016865B8: B #0x1686470               |  goto label_54;                         
            goto label_54;
        
        }
        //
        // Offset in libil2cpp.so: 0x016865BC (23619004), len: 172  VirtAddr: 0x016865BC RVA: 0x016865BC token: 100683739 methodIndex: 49879 delegateWrapperIndex: 0 methodInvoker: 0
        private static AstarProfiler()
        {
            //
            // Disasemble & Code
            // 0x016865BC: STP x20, x19, [sp, #-0x20]! | stack[1152921513535407952] = ???;  stack[1152921513535407960] = ???;  //  dest_result_addr=1152921513535407952 |  dest_result_addr=1152921513535407960
            // 0x016865C0: STP x29, x30, [sp, #0x10]  | stack[1152921513535407968] = ???;  stack[1152921513535407976] = ???;  //  dest_result_addr=1152921513535407968 |  dest_result_addr=1152921513535407976
            // 0x016865C4: ADD x29, sp, #0x10         | X29 = (1152921513535407952 + 16) = 1152921513535407968 (0x10000002142F0760);
            // 0x016865C8: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x016865CC: LDRB w8, [x19, #0xed]      | W8 = (bool)static_value_037380ED;       
            // 0x016865D0: TBNZ w8, #0, #0x16865ec    | if (static_value_037380ED == true) goto label_0;
            // 0x016865D4: ADRP x8, #0x360c000        | X8 = 56672256 (0x360C000);              
            // 0x016865D8: LDR x8, [x8, #0x58]        | X8 = 0x2B8ED88;                         
            // 0x016865DC: LDR w0, [x8]               | W0 = 0x1222;                            
            // 0x016865E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1222, ????);     
            // 0x016865E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016865E8: STRB w8, [x19, #0xed]      | static_value_037380ED = true;            //  dest_result_addr=57901293
            label_0:
            // 0x016865EC: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x016865F0: LDR x8, [x8, #0x9d0]       | X8 = 1152921504615792640;               
            // 0x016865F4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);
            System.Collections.Generic.Dictionary<System.String, ProfilePoint> val_1 = null;
            // 0x016865F8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.Dictionary<TKey, TValue>), ????);
            // 0x016865FC: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x01686600: LDR x8, [x8, #0x8f0]       | X8 = 1152921513535394960;               
            // 0x01686604: MOV x19, x0                | X19 = 1152921504615792640 (0x1000000000888000);//ML01
            // 0x01686608: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.Dictionary<System.String, ProfilePoint>::.ctor();
            // 0x0168660C: BL #0x23fb0c4              | .ctor();                                
            val_1 = new System.Collections.Generic.Dictionary<System.String, ProfilePoint>();
            // 0x01686610: ADRP x20, #0x363e000       | X20 = 56877056 (0x363E000);             
            // 0x01686614: LDR x20, [x20, #0x358]     | X20 = 1152921504850882560;              
            // 0x01686618: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x0168661C: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01686620: STR x19, [x8]              | Pathfinding.AstarProfiler.profiles = typeof(System.Collections.Generic.Dictionary<TKey, TValue>);  //  dest_result_addr=1152921504850886656
            Pathfinding.AstarProfiler.profiles = val_1;
            // 0x01686624: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x01686628: LDR x8, [x8, #0x9e0]       | X8 = 1152921504652693504;               
            // 0x0168662C: LDR x0, [x8]               | X0 = typeof(System.DateTime);           
            // 0x01686630: LDRB w8, [x0, #0x10a]      | W8 = System.DateTime.__il2cppRuntimeField_10A;
            // 0x01686634: TBZ w8, #0, #0x1686644     | if (System.DateTime.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01686638: LDR w8, [x0, #0xbc]        | W8 = System.DateTime.__il2cppRuntimeField_cctor_finished;
            // 0x0168663C: CBNZ w8, #0x1686644        | if (System.DateTime.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01686640: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.DateTime), ????);
            label_2:
            // 0x01686644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686648: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168664C: BL #0x1bafcc8              | X0 = System.DateTime.get_UtcNow();      
            System.DateTime val_2 = System.DateTime.UtcNow;
            // 0x01686650: LDR x8, [x20]              | X8 = typeof(Pathfinding.AstarProfiler); 
            // 0x01686654: LDR x8, [x8, #0xa0]        | X8 = Pathfinding.AstarProfiler.__il2cppRuntimeField_static_fields;
            // 0x01686658: STP x0, x1, [x8, #8]       | Pathfinding.AstarProfiler.startTime = val_2.ticks._ticks;  Pathfinding.AstarProfiler.profiles.__il2cppRuntimeField_10 = val_2.kind;  //  dest_result_addr=1152921504850886664 |  dest_result_addr=1152921504850886672
            Pathfinding.AstarProfiler.startTime = val_2.ticks._ticks;
            Pathfinding.AstarProfiler.profiles.__il2cppRuntimeField_10 = val_2.kind;
            // 0x0168665C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01686660: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01686664: RET                        |  return;                                
            return;
        
        }
    
    }

}
