using UnityEngine;

namespace SevenZip
{
    public class CDoubleStream : Stream
    {
        // Fields
        public System.IO.Stream s1; //  0x00000010
        public System.IO.Stream s2; //  0x00000018
        public int fileIndex; //  0x00000020
        public long skipSize; //  0x00000028
        
        // Properties
        public override bool CanRead { get; }
        public override bool CanWrite { get; }
        public override bool CanSeek { get; }
        public override long Length { get; }
        public override long Position { get; set; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00CA74C4 (13268164), len: 104  VirtAddr: 0x00CA74C4 RVA: 0x00CA74C4 token: 100681578 methodIndex: 54560 delegateWrapperIndex: 0 methodInvoker: 0
        public CDoubleStream()
        {
            //
            // Disasemble & Code
            // 0x00CA74C4: STP x20, x19, [sp, #-0x20]! | stack[1152921513097540784] = ???;  stack[1152921513097540792] = ???;  //  dest_result_addr=1152921513097540784 |  dest_result_addr=1152921513097540792
            // 0x00CA74C8: STP x29, x30, [sp, #0x10]  | stack[1152921513097540800] = ???;  stack[1152921513097540808] = ???;  //  dest_result_addr=1152921513097540800 |  dest_result_addr=1152921513097540808
            // 0x00CA74CC: ADD x29, sp, #0x10         | X29 = (1152921513097540784 + 16) = 1152921513097540800 (0x10000001FA15B4C0);
            // 0x00CA74D0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00CA74D4: LDRB w8, [x20, #0xa4]      | W8 = (bool)static_value_037340A4;       
            // 0x00CA74D8: MOV x19, x0                | X19 = 1152921513097552816 (0x10000001FA15E3B0);//ML01
            // 0x00CA74DC: TBNZ w8, #0, #0xca74f8     | if (static_value_037340A4 == true) goto label_0;
            // 0x00CA74E0: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00CA74E4: LDR x8, [x8, #0x40]        | X8 = 0x2B904B4;                         
            // 0x00CA74E8: LDR w0, [x8]               | W0 = 0x17F1;                            
            // 0x00CA74EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F1, ????);     
            // 0x00CA74F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA74F4: STRB w8, [x20, #0xa4]      | static_value_037340A4 = true;            //  dest_result_addr=57884836
            label_0:
            // 0x00CA74F8: ADRP x8, #0x3654000        | X8 = 56967168 (0x3654000);              
            // 0x00CA74FC: LDR x8, [x8, #0x898]       | X8 = 1152921504622342144;               
            // 0x00CA7500: LDR x0, [x8]               | X0 = typeof(System.IO.Stream);          
            // 0x00CA7504: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Stream.__il2cppRuntimeField_10A;
            // 0x00CA7508: TBZ w8, #0, #0xca7518      | if (System.IO.Stream.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00CA750C: LDR w8, [x0, #0xbc]        | W8 = System.IO.Stream.__il2cppRuntimeField_cctor_finished;
            // 0x00CA7510: CBNZ w8, #0xca7518         | if (System.IO.Stream.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00CA7514: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Stream), ????);
            label_2:
            // 0x00CA7518: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA751C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA7520: MOV x0, x19                | X0 = 1152921513097552816 (0x10000001FA15E3B0);//ML01
            // 0x00CA7524: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00CA7528: B #0x1e73764               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA752C (13268268), len: 8  VirtAddr: 0x00CA752C RVA: 0x00CA752C token: 100681579 methodIndex: 54561 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanRead()
        {
            //
            // Disasemble & Code
            // 0x00CA752C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00CA7530: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA7534 (13268276), len: 8  VirtAddr: 0x00CA7534 RVA: 0x00CA7534 token: 100681580 methodIndex: 54562 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanWrite()
        {
            //
            // Disasemble & Code
            // 0x00CA7534: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00CA7538: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA753C (13268284), len: 8  VirtAddr: 0x00CA753C RVA: 0x00CA753C token: 100681581 methodIndex: 54563 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_CanSeek()
        {
            //
            // Disasemble & Code
            // 0x00CA753C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00CA7540: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA7544 (13268292), len: 108  VirtAddr: 0x00CA7544 RVA: 0x00CA7544 token: 100681582 methodIndex: 54564 delegateWrapperIndex: 0 methodInvoker: 0
        public override long get_Length()
        {
            //
            // Disasemble & Code
            // 0x00CA7544: STP x22, x21, [sp, #-0x30]! | stack[1152921513097996960] = ???;  stack[1152921513097996968] = ???;  //  dest_result_addr=1152921513097996960 |  dest_result_addr=1152921513097996968
            // 0x00CA7548: STP x20, x19, [sp, #0x10]  | stack[1152921513097996976] = ???;  stack[1152921513097996984] = ???;  //  dest_result_addr=1152921513097996976 |  dest_result_addr=1152921513097996984
            // 0x00CA754C: STP x29, x30, [sp, #0x20]  | stack[1152921513097996992] = ???;  stack[1152921513097997000] = ???;  //  dest_result_addr=1152921513097996992 |  dest_result_addr=1152921513097997000
            // 0x00CA7550: ADD x29, sp, #0x20         | X29 = (1152921513097996960 + 32) = 1152921513097996992 (0x10000001FA1CAAC0);
            // 0x00CA7554: MOV x19, x0                | X19 = 1152921513098009008 (0x10000001FA1CD9B0);//ML01
            // 0x00CA7558: LDR x20, [x19, #0x10]      | X20 = this.s1; //P2                     
            // 0x00CA755C: CBNZ x20, #0xca7564        | if (this.s1 != null) goto label_0;      
            if(this.s1 != null)
            {
                goto label_0;
            }
            // 0x00CA7560: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00CA7564: LDR x8, [x20]              | X8 = typeof(System.IO.Stream);          
            // 0x00CA7568: MOV x0, x20                | X0 = this.s1;//m1                       
            // 0x00CA756C: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_190; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_198; //  | 
            // 0x00CA7570: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_190();
            // 0x00CA7574: LDR x21, [x19, #0x18]      | X21 = this.s2; //P2                     
            // 0x00CA7578: MOV x20, x0                | X20 = this.s1;//m1                      
            // 0x00CA757C: CBNZ x21, #0xca7584        | if (this.s2 != null) goto label_1;      
            if(this.s2 != null)
            {
                goto label_1;
            }
            // 0x00CA7580: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.s1, ????);    
            label_1:
            // 0x00CA7584: LDR x8, [x21]              | X8 = typeof(System.IO.Stream);          
            // 0x00CA7588: MOV x0, x21                | X0 = this.s2;//m1                       
            var val_2 = this.s2;
            // 0x00CA758C: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_190; X1 = typeof(System.IO.Stream).__il2cppRuntimeField_198; //  | 
            // 0x00CA7590: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_190();
            // 0x00CA7594: LDR x8, [x19, #0x28]       | X8 = this.skipSize; //P2                
            // 0x00CA7598: ADD x9, x0, x20            | X9 = (this.s2 + this.s1);               
            System.IO.Stream val_1 = val_2 + this.s1;
            // 0x00CA759C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA75A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00CA75A4: SUB x0, x9, x8             | X0 = ((this.s2 + this.s1) - this.skipSize);
            val_2 = val_1 - this.skipSize;
            // 0x00CA75A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00CA75AC: RET                        |  return (System.Int64)((this.s2 + this.s1) - this.skipSize);
            return (long)val_2;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA75B0 (13268400), len: 8  VirtAddr: 0x00CA75B0 RVA: 0x00CA75B0 token: 100681583 methodIndex: 54565 delegateWrapperIndex: 0 methodInvoker: 0
        public override long get_Position()
        {
            //
            // Disasemble & Code
            // 0x00CA75B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00CA75B4: RET                        |  return (System.Int64)0;                
            return (long)0;
            //  |  // // {name=val_0, type=System.Int64, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA75B8 (13268408), len: 4  VirtAddr: 0x00CA75B8 RVA: 0x00CA75B8 token: 100681584 methodIndex: 54566 delegateWrapperIndex: 0 methodInvoker: 0
        public override void set_Position(long value)
        {
            //
            // Disasemble & Code
            // 0x00CA75B8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA75BC (13268412), len: 4  VirtAddr: 0x00CA75BC RVA: 0x00CA75BC token: 100681585 methodIndex: 54567 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Flush()
        {
            //
            // Disasemble & Code
            // 0x00CA75BC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA75C0 (13268416), len: 208  VirtAddr: 0x00CA75C0 RVA: 0x00CA75C0 token: 100681586 methodIndex: 54568 delegateWrapperIndex: 0 methodInvoker: 0
        public override int Read(byte[] buffer, int offset, int count)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            System.IO.Stream val_4;
            //  | 
            var val_5;
            //  | 
            int val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00CA75C0: STP x24, x23, [sp, #-0x40]! | stack[1152921513098498192] = ???;  stack[1152921513098498200] = ???;  //  dest_result_addr=1152921513098498192 |  dest_result_addr=1152921513098498200
            // 0x00CA75C4: STP x22, x21, [sp, #0x10]  | stack[1152921513098498208] = ???;  stack[1152921513098498216] = ???;  //  dest_result_addr=1152921513098498208 |  dest_result_addr=1152921513098498216
            // 0x00CA75C8: STP x20, x19, [sp, #0x20]  | stack[1152921513098498224] = ???;  stack[1152921513098498232] = ???;  //  dest_result_addr=1152921513098498224 |  dest_result_addr=1152921513098498232
            // 0x00CA75CC: STP x29, x30, [sp, #0x30]  | stack[1152921513098498240] = ???;  stack[1152921513098498248] = ???;  //  dest_result_addr=1152921513098498240 |  dest_result_addr=1152921513098498248
            // 0x00CA75D0: ADD x29, sp, #0x30         | X29 = (1152921513098498192 + 48) = 1152921513098498240 (0x10000001FA2450C0);
            // 0x00CA75D4: MOV w20, w3                | W20 = count;//m1                        
            val_2 = count;
            // 0x00CA75D8: MOV w21, w2                | W21 = offset;//m1                       
            val_3 = offset;
            // 0x00CA75DC: MOV x22, x1                | X22 = buffer;//m1                       
            // 0x00CA75E0: MOV x23, x0                | X23 = 1152921513098510256 (0x10000001FA247FB0);//ML01
            val_4 = this;
            // 0x00CA75E4: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_4:
            // 0x00CA75E8: CMP w20, #0                | STATE = COMPARE(count, 0x0)             
            // 0x00CA75EC: B.LE #0xca7678             | if (val_2 <= 0) goto label_0;           
            if(val_2 <= 0)
            {
                goto label_0;
            }
            // 0x00CA75F0: LDR w8, [x23, #0x20]       | W8 = this.fileIndex; //P2               
            val_6 = this.fileIndex;
            // 0x00CA75F4: CBNZ w8, #0xca7640         | if (this.fileIndex != 0) goto label_3;  
            if(val_6 != 0)
            {
                goto label_3;
            }
            // 0x00CA75F8: LDR x24, [x23, #0x10]      | X24 = this.s1; //P2                     
            // 0x00CA75FC: CBNZ x24, #0xca7604        | if (this.s1 != null) goto label_2;      
            if(this.s1 != null)
            {
                goto label_2;
            }
            // 0x00CA7600: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x00CA7604: LDR x8, [x24]              | X8 = typeof(System.IO.Stream);          
            // 0x00CA7608: MOV x0, x24                | X0 = this.s1;//m1                       
            // 0x00CA760C: MOV x1, x22                | X1 = buffer;//m1                        
            // 0x00CA7610: MOV w2, w21                | W2 = offset;//m1                        
            // 0x00CA7614: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x00CA7618: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x00CA761C: MOV w3, w20                | W3 = count;//m1                         
            // 0x00CA7620: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x00CA7624: LDR w8, [x23, #0x20]       | W8 = this.fileIndex; //P2               
            val_6 = this.fileIndex;
            // 0x00CA7628: ADD w21, w0, w21           | W21 = (this.s1 + offset);               
            val_3 = this.s1 + val_3;
            // 0x00CA762C: SUB w20, w20, w0           | W20 = (count - this.s1);                
            val_2 = val_2 - this.s1;
            // 0x00CA7630: ADD w19, w0, w19           | W19 = typeof(System.IO.Stream);//AP1    
            // 0x00CA7634: CBNZ w0, #0xca7640         | if (this.s1 != null) goto label_3;      
            if(this.s1 != null)
            {
                goto label_3;
            }
            // 0x00CA7638: ADD w8, w8, #1             | W8 = (this.fileIndex + 1);              
            val_6 = val_6 + 1;
            // 0x00CA763C: STR w8, [x23, #0x20]       | this.fileIndex = (this.fileIndex + 1);   //  dest_result_addr=1152921513098510288
            this.fileIndex = val_6;
            label_3:
            // 0x00CA7640: CMP w8, #1                 | STATE = COMPARE((this.fileIndex + 1), 0x1)
            // 0x00CA7644: B.NE #0xca75e8             | if (val_6 != 1) goto label_4;           
            if(val_6 != 1)
            {
                goto label_4;
            }
            // 0x00CA7648: LDR x23, [x23, #0x18]      | X23 = this.s2; //P2                     
            val_4 = this.s2;
            // 0x00CA764C: CBNZ x23, #0xca7654        | if (this.s2 != null) goto label_5;      
            if(val_4 != null)
            {
                goto label_5;
            }
            // 0x00CA7650: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.s1, ????);    
            label_5:
            // 0x00CA7654: LDR x8, [x23]              | X8 = typeof(System.IO.Stream);          
            // 0x00CA7658: MOV x0, x23                | X0 = this.s2;//m1                       
            // 0x00CA765C: MOV x1, x22                | X1 = buffer;//m1                        
            // 0x00CA7660: MOV w2, w21                | W2 = (this.s1 + offset);//m1            
            // 0x00CA7664: LDR x9, [x8, #0x220]       | X9 = typeof(System.IO.Stream).__il2cppRuntimeField_220;
            // 0x00CA7668: LDR x4, [x8, #0x228]       | X4 = typeof(System.IO.Stream).__il2cppRuntimeField_228;
            // 0x00CA766C: MOV w3, w20                | W3 = (count - this.s1);//m1             
            // 0x00CA7670: BLR x9                     | X0 = typeof(System.IO.Stream).__il2cppRuntimeField_220();
            // 0x00CA7674: ADD w19, w0, w19           | W19 = (this.s2 + 1152921504622342144);  
            val_8 = val_4 + 1152921504622342144;
            label_0:
            // 0x00CA7678: MOV w0, w19                | W0 = (this.s2 + 1152921504622342144);//m1
            // 0x00CA767C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA7680: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00CA7684: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00CA7688: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00CA768C: RET                        |  return (System.Int32)(this.s2 + 1152921504622342144);
            return (int)val_8;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA7690 (13268624), len: 112  VirtAddr: 0x00CA7690 RVA: 0x00CA7690 token: 100681587 methodIndex: 54569 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Write(byte[] buffer, int offset, int count)
        {
            //
            // Disasemble & Code
            // 0x00CA7690: STP x20, x19, [sp, #-0x20]! | stack[1152921513098693264] = ???;  stack[1152921513098693272] = ???;  //  dest_result_addr=1152921513098693264 |  dest_result_addr=1152921513098693272
            // 0x00CA7694: STP x29, x30, [sp, #0x10]  | stack[1152921513098693280] = ???;  stack[1152921513098693288] = ???;  //  dest_result_addr=1152921513098693280 |  dest_result_addr=1152921513098693288
            // 0x00CA7698: ADD x29, sp, #0x10         | X29 = (1152921513098693264 + 16) = 1152921513098693280 (0x10000001FA274AA0);
            // 0x00CA769C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00CA76A0: LDRB w8, [x19, #0xa5]      | W8 = (bool)static_value_037340A5;       
            // 0x00CA76A4: TBNZ w8, #0, #0xca76c0     | if (static_value_037340A5 == true) goto label_0;
            // 0x00CA76A8: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x00CA76AC: LDR x8, [x8, #0xe08]       | X8 = 0x2B904C0;                         
            // 0x00CA76B0: LDR w0, [x8]               | W0 = 0x17F4;                            
            // 0x00CA76B4: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F4, ????);     
            // 0x00CA76B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA76BC: STRB w8, [x19, #0xa5]      | static_value_037340A5 = true;            //  dest_result_addr=57884837
            label_0:
            // 0x00CA76C0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00CA76C4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00CA76C8: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x00CA76CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00CA76D0: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00CA76D4: LDR x8, [x8, #0x318]       | X8 = (string**)(1152921513098680176)("can\'t Write");
            // 0x00CA76D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00CA76DC: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA76E0: LDR x1, [x8]               | X1 = "can\'t Write";                    
            // 0x00CA76E4: BL #0x1c32b48              | .ctor(message:  "can\'t Write");        
            val_1 = new System.Exception(message:  "can\'t Write");
            // 0x00CA76E8: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x00CA76EC: LDR x8, [x8, #0x138]       | X8 = 1152921513098680272;               
            // 0x00CA76F0: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA76F4: LDR x1, [x8]               | X1 = public System.Void SevenZip.CDoubleStream::Write(byte[] buffer, int offset, int count);
            // 0x00CA76F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00CA76FC: BL #0xc8ae78               | X0 = HasCallbacks(callbackType:  public System.Void SevenZip.CDoubleStream::Write(byte[] buffer, int offset, int count));
            bool val_2 = HasCallbacks(callbackType:  public System.Void SevenZip.CDoubleStream::Write(byte[] buffer, int offset, int count));
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA7700 (13268736), len: 112  VirtAddr: 0x00CA7700 RVA: 0x00CA7700 token: 100681588 methodIndex: 54570 delegateWrapperIndex: 0 methodInvoker: 0
        public override long Seek(long offset, System.IO.SeekOrigin origin)
        {
            //
            // Disasemble & Code
            // 0x00CA7700: STP x20, x19, [sp, #-0x20]! | stack[1152921513098847344] = ???;  stack[1152921513098847352] = ???;  //  dest_result_addr=1152921513098847344 |  dest_result_addr=1152921513098847352
            // 0x00CA7704: STP x29, x30, [sp, #0x10]  | stack[1152921513098847360] = ???;  stack[1152921513098847368] = ???;  //  dest_result_addr=1152921513098847360 |  dest_result_addr=1152921513098847368
            // 0x00CA7708: ADD x29, sp, #0x10         | X29 = (1152921513098847344 + 16) = 1152921513098847360 (0x10000001FA29A480);
            // 0x00CA770C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00CA7710: LDRB w8, [x19, #0xa6]      | W8 = (bool)static_value_037340A6;       
            // 0x00CA7714: TBNZ w8, #0, #0xca7730     | if (static_value_037340A6 == true) goto label_0;
            // 0x00CA7718: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00CA771C: LDR x8, [x8, #0x988]       | X8 = 0x2B904B8;                         
            // 0x00CA7720: LDR w0, [x8]               | W0 = 0x17F2;                            
            // 0x00CA7724: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F2, ????);     
            // 0x00CA7728: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA772C: STRB w8, [x19, #0xa6]      | static_value_037340A6 = true;            //  dest_result_addr=57884838
            label_0:
            // 0x00CA7730: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00CA7734: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00CA7738: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x00CA773C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00CA7740: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x00CA7744: LDR x8, [x8, #0x9b8]       | X8 = (string**)(1152921513098834256)("can\'t Seek");
            // 0x00CA7748: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00CA774C: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA7750: LDR x1, [x8]               | X1 = "can\'t Seek";                     
            // 0x00CA7754: BL #0x1c32b48              | .ctor(message:  "can\'t Seek");         
            val_1 = new System.Exception(message:  "can\'t Seek");
            // 0x00CA7758: ADRP x8, #0x3629000        | X8 = 56791040 (0x3629000);              
            // 0x00CA775C: LDR x8, [x8, #0xc18]       | X8 = 1152921513098834352;               
            // 0x00CA7760: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA7764: LDR x1, [x8]               | X1 = public System.Int64 SevenZip.CDoubleStream::Seek(long offset, System.IO.SeekOrigin origin);
            // 0x00CA7768: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00CA776C: BL #0xc8ae78               | X0 = HasCallbacks(callbackType:  public System.Int64 SevenZip.CDoubleStream::Seek(long offset, System.IO.SeekOrigin origin));
            bool val_2 = HasCallbacks(callbackType:  public System.Int64 SevenZip.CDoubleStream::Seek(long offset, System.IO.SeekOrigin origin));
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA7770 (13268848), len: 112  VirtAddr: 0x00CA7770 RVA: 0x00CA7770 token: 100681589 methodIndex: 54571 delegateWrapperIndex: 0 methodInvoker: 0
        public override void SetLength(long value)
        {
            //
            // Disasemble & Code
            // 0x00CA7770: STP x20, x19, [sp, #-0x20]! | stack[1152921513098964576] = ???;  stack[1152921513098964584] = ???;  //  dest_result_addr=1152921513098964576 |  dest_result_addr=1152921513098964584
            // 0x00CA7774: STP x29, x30, [sp, #0x10]  | stack[1152921513098964592] = ???;  stack[1152921513098964600] = ???;  //  dest_result_addr=1152921513098964592 |  dest_result_addr=1152921513098964600
            // 0x00CA7778: ADD x29, sp, #0x10         | X29 = (1152921513098964576 + 16) = 1152921513098964592 (0x10000001FA2B6E70);
            // 0x00CA777C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00CA7780: LDRB w8, [x19, #0xa7]      | W8 = (bool)static_value_037340A7;       
            // 0x00CA7784: TBNZ w8, #0, #0xca77a0     | if (static_value_037340A7 == true) goto label_0;
            // 0x00CA7788: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00CA778C: LDR x8, [x8, #0x660]       | X8 = 0x2B904BC;                         
            // 0x00CA7790: LDR w0, [x8]               | W0 = 0x17F3;                            
            // 0x00CA7794: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F3, ????);     
            // 0x00CA7798: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA779C: STRB w8, [x19, #0xa7]      | static_value_037340A7 = true;            //  dest_result_addr=57884839
            label_0:
            // 0x00CA77A0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00CA77A4: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00CA77A8: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_1 = null;
            // 0x00CA77AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00CA77B0: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00CA77B4: LDR x8, [x8, #0xd70]       | X8 = (string**)(1152921513098951472)("can\'t SetLength");
            // 0x00CA77B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00CA77BC: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA77C0: LDR x1, [x8]               | X1 = "can\'t SetLength";                
            // 0x00CA77C4: BL #0x1c32b48              | .ctor(message:  "can\'t SetLength");    
            val_1 = new System.Exception(message:  "can\'t SetLength");
            // 0x00CA77C8: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00CA77CC: LDR x8, [x8, #0x160]       | X8 = 1152921513098951584;               
            // 0x00CA77D0: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA77D4: LDR x1, [x8]               | X1 = public System.Void SevenZip.CDoubleStream::SetLength(long value);
            // 0x00CA77D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00CA77DC: BL #0xc8ae78               | X0 = HasCallbacks(callbackType:  public System.Void SevenZip.CDoubleStream::SetLength(long value));
            bool val_2 = HasCallbacks(callbackType:  public System.Void SevenZip.CDoubleStream::SetLength(long value));
        
        }
    
    }

}
