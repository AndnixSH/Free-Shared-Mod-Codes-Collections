using UnityEngine;
public enum UIWidget.AspectRatioSource
{
    // Fields
    Free = 0
    ,BasedOnWidth = 1
    ,BasedOnHeight = 2
    

}
