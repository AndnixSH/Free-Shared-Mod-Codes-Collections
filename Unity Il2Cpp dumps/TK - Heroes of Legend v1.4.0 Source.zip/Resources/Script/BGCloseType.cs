using UnityEngine;
public enum BarrierGat.BGCloseType
{
    // Fields
    BT_round_die = 1
    

}
