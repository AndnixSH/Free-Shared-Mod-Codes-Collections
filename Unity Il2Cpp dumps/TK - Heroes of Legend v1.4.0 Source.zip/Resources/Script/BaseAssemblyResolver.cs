using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public abstract class BaseAssemblyResolver : IAssemblyResolver, IDisposable
    {
        // Fields
        private static readonly bool on_mono; // static_offset: 0x00000000
        private readonly ILRuntime.Mono.Collections.Generic.Collection<string> directories; //  0x00000010
        private ILRuntime.Mono.Collections.Generic.Collection<string> gac_paths; //  0x00000018
        private ILRuntime.Mono.Cecil.AssemblyResolveEventHandler ResolveFailure; //  0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E56604 (15033860), len: 232  VirtAddr: 0x00E56604 RVA: 0x00E56604 token: 100663731 methodIndex: 19324 delegateWrapperIndex: 0 methodInvoker: 0
        protected BaseAssemblyResolver()
        {
            //
            // Disasemble & Code
            // 0x00E56604: STP x20, x19, [sp, #-0x20]! | stack[1152921509462249408] = ???;  stack[1152921509462249416] = ???;  //  dest_result_addr=1152921509462249408 |  dest_result_addr=1152921509462249416
            // 0x00E56608: STP x29, x30, [sp, #0x10]  | stack[1152921509462249424] = ???;  stack[1152921509462249432] = ???;  //  dest_result_addr=1152921509462249424 |  dest_result_addr=1152921509462249432
            // 0x00E5660C: ADD x29, sp, #0x10         | X29 = (1152921509462249408 + 16) = 1152921509462249424 (0x1000000121678FD0);
            // 0x00E56610: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E56614: LDRB w8, [x20, #0xac6]     | W8 = (bool)static_value_03734AC6;       
            // 0x00E56618: MOV x19, x0                | X19 = 1152921509462261440 (0x100000012167BEC0);//ML01
            // 0x00E5661C: TBNZ w8, #0, #0xe56638     | if (static_value_03734AC6 == true) goto label_0;
            // 0x00E56620: ADRP x8, #0x3682000        | X8 = 57155584 (0x3682000);              
            // 0x00E56624: LDR x8, [x8, #0x748]       | X8 = 0x2B8EFEC;                         
            // 0x00E56628: LDR w0, [x8]               | W0 = 0x12BD;                            
            // 0x00E5662C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12BD, ????);     
            // 0x00E56630: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E56634: STRB w8, [x20, #0xac6]     | static_value_03734AC6 = true;            //  dest_result_addr=57887430
            label_0:
            // 0x00E56638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5663C: MOV x0, x19                | X0 = 1152921509462261440 (0x100000012167BEC0);//ML01
            // 0x00E56640: BL #0x16f59f0              | this..ctor();                           
            // 0x00E56644: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00E56648: LDR x8, [x8, #0xcb0]       | X8 = 1152921504736985088;               
            // 0x00E5664C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            ILRuntime.Mono.Collections.Generic.Collection<System.String> val_1 = null;
            // 0x00E56650: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            // 0x00E56654: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00E56658: LDR x8, [x8, #0xa60]       | X8 = 1152921509462235312;               
            // 0x00E5665C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00E56660: MOV x20, x0                | X20 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E56664: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::.ctor(int capacity);
            // 0x00E56668: BL #0x1d47070              | .ctor(capacity:  2);                    
            val_1 = new ILRuntime.Mono.Collections.Generic.Collection<System.String>(capacity:  2);
            // 0x00E5666C: CBZ x20, #0xe56694         | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x00E56670: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00E56674: ADRP x9, #0x35c1000        | X9 = 56365056 (0x35C1000);              
            // 0x00E56678: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
            // 0x00E5667C: LDR x9, [x9, #0x908]       | X9 = 1152921509462236336;               
            // 0x00E56680: MOV x0, x20                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E56684: LDR x1, [x8]               | X1 = ".";                               
            // 0x00E56688: LDR x2, [x9]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E5668C: BL #0x1d47324              | Add(item:  ".");                        
            Add(item:  ".");
            // 0x00E56690: B #0xe566bc                |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x00E56694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(capacity:  2), ????);
            // 0x00E56698: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00E5669C: ADRP x9, #0x35c1000        | X9 = 56365056 (0x35C1000);              
            // 0x00E566A0: LDR x8, [x8, #0x9a0]       | X8 = (string**)(1152921509414037808)(".");
            // 0x00E566A4: LDR x9, [x9, #0x908]       | X9 = 1152921509462236336;               
            // 0x00E566A8: MOV x0, x20                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E566AC: LDR x1, [x8]               | X1 = ".";                               
            // 0x00E566B0: LDR x2, [x9]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E566B4: BL #0x1d47324              | Add(item:  ".");                        
            Add(item:  ".");
            // 0x00E566B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            label_2:
            // 0x00E566BC: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x00E566C0: ADRP x9, #0x35c1000        | X9 = 56365056 (0x35C1000);              
            // 0x00E566C4: LDR x8, [x8, #0x518]       | X8 = (string**)(1152921509462237360)("bin");
            // 0x00E566C8: LDR x9, [x9, #0x908]       | X9 = 1152921509462236336;               
            // 0x00E566CC: MOV x0, x20                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E566D0: LDR x1, [x8]               | X1 = "bin";                             
            // 0x00E566D4: LDR x2, [x9]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E566D8: BL #0x1d47324              | Add(item:  "bin");                      
            Add(item:  "bin");
            // 0x00E566DC: STR x20, [x19, #0x10]      | this.directories = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);  //  dest_result_addr=1152921509462261456
            this.directories = val_1;
            // 0x00E566E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E566E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E566E8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E566EC (15034092), len: 132  VirtAddr: 0x00E566EC RVA: 0x00E566EC token: 100663732 methodIndex: 19325 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.AssemblyDefinition GetAssembly(string file, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            // 0x00E566EC: STP x22, x21, [sp, #-0x30]! | stack[1152921509462377776] = ???;  stack[1152921509462377784] = ???;  //  dest_result_addr=1152921509462377776 |  dest_result_addr=1152921509462377784
            // 0x00E566F0: STP x20, x19, [sp, #0x10]  | stack[1152921509462377792] = ???;  stack[1152921509462377800] = ???;  //  dest_result_addr=1152921509462377792 |  dest_result_addr=1152921509462377800
            // 0x00E566F4: STP x29, x30, [sp, #0x20]  | stack[1152921509462377808] = ???;  stack[1152921509462377816] = ???;  //  dest_result_addr=1152921509462377808 |  dest_result_addr=1152921509462377816
            // 0x00E566F8: ADD x29, sp, #0x20         | X29 = (1152921509462377776 + 32) = 1152921509462377808 (0x1000000121698550);
            // 0x00E566FC: MOV x19, x2                | X19 = parameters;//m1                   
            // 0x00E56700: MOV x20, x1                | X20 = file;//m1                         
            // 0x00E56704: MOV x21, x0                | X21 = 1152921509462389824 (0x100000012169B440);//ML01
            // 0x00E56708: CBNZ x19, #0xe56710        | if (parameters != null) goto label_0;   
            if(parameters != null)
            {
                goto label_0;
            }
            // 0x00E5670C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E56710: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56714: MOV x0, x19                | X0 = parameters;//m1                    
            // 0x00E56718: BL #0x11e490c              | X0 = parameters.get_AssemblyResolver(); 
            ILRuntime.Mono.Cecil.IAssemblyResolver val_1 = parameters.AssemblyResolver;
            // 0x00E5671C: CBNZ x0, #0xe56738         | if (val_1 != null) goto label_1;        
            if(val_1 != null)
            {
                goto label_1;
            }
            // 0x00E56720: CBNZ x19, #0xe56728        | if (parameters != null) goto label_2;   
            if(parameters != null)
            {
                goto label_2;
            }
            // 0x00E56724: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00E56728: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5672C: MOV x0, x19                | X0 = parameters;//m1                    
            // 0x00E56730: MOV x1, x21                | X1 = 1152921509462389824 (0x100000012169B440);//ML01
            // 0x00E56734: BL #0x11e4914              | parameters.set_AssemblyResolver(value:  this);
            parameters.AssemblyResolver = this;
            label_1:
            // 0x00E56738: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5673C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E56740: MOV x1, x20                | X1 = file;//m1                          
            // 0x00E56744: MOV x2, x19                | X2 = parameters;//m1                    
            // 0x00E56748: BL #0x11de748              | X0 = ILRuntime.Mono.Cecil.ModuleDefinition.ReadModule(fileName:  0, parameters:  file);
            ILRuntime.Mono.Cecil.ModuleDefinition val_2 = ILRuntime.Mono.Cecil.ModuleDefinition.ReadModule(fileName:  0, parameters:  file);
            // 0x00E5674C: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x00E56750: CBNZ x19, #0xe56758        | if (val_2 != null) goto label_3;        
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x00E56754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00E56758: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x00E5675C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E56760: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E56764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56768: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5676C: B #0x11d2bc8               | return val_2.get_Assembly();            
            return val_2.Assembly;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E56770 (15034224), len: 124  VirtAddr: 0x00E56770 RVA: 0x00E56770 token: 100663733 methodIndex: 19326 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Mono.Cecil.AssemblyDefinition Resolve(ILRuntime.Mono.Cecil.AssemblyNameReference name)
        {
            //
            // Disasemble & Code
            // 0x00E56770: STP x22, x21, [sp, #-0x30]! | stack[1152921509462510256] = ???;  stack[1152921509462510264] = ???;  //  dest_result_addr=1152921509462510256 |  dest_result_addr=1152921509462510264
            // 0x00E56774: STP x20, x19, [sp, #0x10]  | stack[1152921509462510272] = ???;  stack[1152921509462510280] = ???;  //  dest_result_addr=1152921509462510272 |  dest_result_addr=1152921509462510280
            // 0x00E56778: STP x29, x30, [sp, #0x20]  | stack[1152921509462510288] = ???;  stack[1152921509462510296] = ???;  //  dest_result_addr=1152921509462510288 |  dest_result_addr=1152921509462510296
            // 0x00E5677C: ADD x29, sp, #0x20         | X29 = (1152921509462510256 + 32) = 1152921509462510288 (0x10000001216B8AD0);
            // 0x00E56780: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E56784: LDRB w8, [x21, #0xac7]     | W8 = (bool)static_value_03734AC7;       
            // 0x00E56788: MOV x19, x1                | X19 = name;//m1                         
            // 0x00E5678C: MOV x20, x0                | X20 = 1152921509462522304 (0x10000001216BB9C0);//ML01
            // 0x00E56790: TBNZ w8, #0, #0xe567ac     | if (static_value_03734AC7 == true) goto label_0;
            // 0x00E56794: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00E56798: LDR x8, [x8, #0x768]       | X8 = 0x2B8F014;                         
            // 0x00E5679C: LDR w0, [x8]               | W0 = 0x12C7;                            
            // 0x00E567A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C7, ????);     
            // 0x00E567A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E567A8: STRB w8, [x21, #0xac7]     | static_value_03734AC7 = true;            //  dest_result_addr=57887431
            label_0:
            // 0x00E567AC: ADRP x8, #0x35ec000        | X8 = 56541184 (0x35EC000);              
            // 0x00E567B0: LDR x8, [x8, #0x5e0]       | X8 = 1152921504741670912;               
            // 0x00E567B4: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.ReaderParameters);
            ILRuntime.Mono.Cecil.ReaderParameters val_1 = null;
            // 0x00E567B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.ReaderParameters), ????);
            // 0x00E567BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E567C0: MOV x21, x0                | X21 = 1152921504741670912 (0x1000000008094000);//ML01
            // 0x00E567C4: BL #0x11e4924              | .ctor();                                
            val_1 = new ILRuntime.Mono.Cecil.ReaderParameters();
            // 0x00E567C8: LDR x8, [x20]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E567CC: MOV x0, x20                | X0 = 1152921509462522304 (0x10000001216BB9C0);//ML01
            // 0x00E567D0: MOV x1, x19                | X1 = name;//m1                          
            // 0x00E567D4: MOV x2, x21                | X2 = 1152921504741670912 (0x1000000008094000);//ML01
            // 0x00E567D8: LDP x4, x3, [x8, #0x180]   | X4 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_180; X3 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_188; //  | 
            // 0x00E567DC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E567E0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E567E4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E567E8: BR x4                      | goto typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_180;
            goto typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_180;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E567EC (15034348), len: 1204  VirtAddr: 0x00E567EC RVA: 0x00E567EC token: 100663734 methodIndex: 19327 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual ILRuntime.Mono.Cecil.AssemblyDefinition Resolve(ILRuntime.Mono.Cecil.AssemblyNameReference name, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Cecil.AssemblyNameReference val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x00E567EC: STP x26, x25, [sp, #-0x50]! | stack[1152921509462672496] = ???;  stack[1152921509462672504] = ???;  //  dest_result_addr=1152921509462672496 |  dest_result_addr=1152921509462672504
            // 0x00E567F0: STP x24, x23, [sp, #0x10]  | stack[1152921509462672512] = ???;  stack[1152921509462672520] = ???;  //  dest_result_addr=1152921509462672512 |  dest_result_addr=1152921509462672520
            // 0x00E567F4: STP x22, x21, [sp, #0x20]  | stack[1152921509462672528] = ???;  stack[1152921509462672536] = ???;  //  dest_result_addr=1152921509462672528 |  dest_result_addr=1152921509462672536
            // 0x00E567F8: STP x20, x19, [sp, #0x30]  | stack[1152921509462672544] = ???;  stack[1152921509462672552] = ???;  //  dest_result_addr=1152921509462672544 |  dest_result_addr=1152921509462672552
            // 0x00E567FC: STP x29, x30, [sp, #0x40]  | stack[1152921509462672560] = ???;  stack[1152921509462672568] = ???;  //  dest_result_addr=1152921509462672560 |  dest_result_addr=1152921509462672568
            // 0x00E56800: ADD x29, sp, #0x40         | X29 = (1152921509462672496 + 64) = 1152921509462672560 (0x10000001216E04B0);
            // 0x00E56804: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E56808: LDRB w8, [x22, #0xac8]     | W8 = (bool)static_value_03734AC8;       
            // 0x00E5680C: MOV x21, x2                | X21 = parameters;//m1                   
            // 0x00E56810: MOV x20, x1                | X20 = name;//m1                         
            val_12 = name;
            // 0x00E56814: MOV x19, x0                | X19 = 1152921509462684576 (0x10000001216E33A0);//ML01
            // 0x00E56818: TBNZ w8, #0, #0xe56834     | if (static_value_03734AC8 == true) goto label_0;
            // 0x00E5681C: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00E56820: LDR x8, [x8, #0xf08]       | X8 = 0x2B8F010;                         
            // 0x00E56824: LDR w0, [x8]               | W0 = 0x12C6;                            
            // 0x00E56828: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C6, ????);     
            // 0x00E5682C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E56830: STRB w8, [x22, #0xac8]     | static_value_03734AC8 = true;            //  dest_result_addr=57887432
            label_0:
            // 0x00E56834: ADRP x23, #0x362e000       | X23 = 56811520 (0x362E000);             
            // 0x00E56838: LDR x23, [x23, #0xa48]     | X23 = 1152921504737091584;              
            val_13 = 1152921504737091584;
            // 0x00E5683C: LDR x0, [x23]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E56840: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E56844: TBZ w8, #0, #0xe56854      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E56848: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E5684C: CBNZ w8, #0xe56854         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E56850: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E56854: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56858: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5685C: MOV x1, x20                | X1 = name;//m1                          
            // 0x00E56860: BL #0x11d9d2c              | ILRuntime.Mono.Cecil.Mixin.CheckName(name:  0);
            ILRuntime.Mono.Cecil.Mixin.CheckName(name:  0);
            // 0x00E56864: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56868: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5686C: MOV x1, x21                | X1 = parameters;//m1                    
            // 0x00E56870: BL #0x11da388              | ILRuntime.Mono.Cecil.Mixin.CheckParameters(parameters:  0);
            ILRuntime.Mono.Cecil.Mixin.CheckParameters(parameters:  0);
            // 0x00E56874: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E56878: LDR x2, [x19, #0x10]       | X2 = this.directories; //P2             
            // 0x00E5687C: MOV x0, x19                | X0 = 1152921509462684576 (0x10000001216E33A0);//ML01
            val_14 = this;
            // 0x00E56880: MOV x1, x20                | X1 = name;//m1                          
            // 0x00E56884: LDP x9, x4, [x8, #0x190]   | X9 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_190; X4 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_198; //  | 
            // 0x00E56888: MOV x3, x21                | X3 = parameters;//m1                    
            // 0x00E5688C: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_190();
            // 0x00E56890: CBNZ x0, #0xe56c50         | if (this != null) goto label_46;        
            if(this != null)
            {
                goto label_46;
            }
            // 0x00E56894: CBNZ x20, #0xe5689c        | if (name != null) goto label_4;         
            if(val_12 != null)
            {
                goto label_4;
            }
            // 0x00E56898: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x00E5689C: MOV x0, x20                | X0 = name;//m1                          
            // 0x00E568A0: BL #0xe555bc               | X0 = name.get_IsRetargetable();         
            bool val_1 = val_12.IsRetargetable;
            // 0x00E568A4: TBZ w0, #0, #0xe56934      | if (val_1 == false) goto label_5;       
            if(val_1 == false)
            {
                goto label_5;
            }
            // 0x00E568A8: CBNZ x20, #0xe568b0        | if (name != null) goto label_6;         
            if(val_12 != null)
            {
                goto label_6;
            }
            // 0x00E568AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00E568B0: LDR x0, [x23]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            val_16 = null;
            // 0x00E568B4: LDR x22, [x20, #0x10]      | X22 = name.name; //P2                   
            // 0x00E568B8: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E568BC: TBZ w8, #0, #0xe568d0      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E568C0: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E568C4: CBNZ w8, #0xe568d0         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E568C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            // 0x00E568CC: LDR x0, [x23]              | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            val_16 = null;
            label_8:
            // 0x00E568D0: ADRP x9, #0x35c0000        | X9 = 56360960 (0x35C0000);              
            // 0x00E568D4: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_static_fields;
            // 0x00E568D8: LDR x9, [x9, #0xc88]       | X9 = 1152921504737677312;               
            // 0x00E568DC: LDR x23, [x8]              | X23 = ILRuntime.Mono.Cecil.Mixin.ZeroVersion;
            // 0x00E568E0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Mono.Cecil.AssemblyNameReference);
            ILRuntime.Mono.Cecil.AssemblyNameReference val_2 = null;
            // 0x00E568E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.AssemblyNameReference), ????);
            // 0x00E568E8: MOV x1, x22                | X1 = name.name;//m1                     
            // 0x00E568EC: MOV x2, x23                | X2 = ILRuntime.Mono.Cecil.Mixin.ZeroVersion;//m1
            // 0x00E568F0: MOV x20, x0                | X20 = 1152921504737677312 (0x1000000007CC5000);//ML01
            val_12 = val_2;
            // 0x00E568F4: BL #0xe56064               | .ctor(name:  name.name, version:  ILRuntime.Mono.Cecil.Mixin.ZeroVersion);
            val_2 = new ILRuntime.Mono.Cecil.AssemblyNameReference(name:  name.name, version:  ILRuntime.Mono.Cecil.Mixin.ZeroVersion);
            // 0x00E568F8: ADRP x22, #0x365b000       | X22 = 56995840 (0x365B000);             
            // 0x00E568FC: LDR x22, [x22, #0x618]     | X22 = 1152921504736825344;              
            // 0x00E56900: LDR x0, [x22]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_17 = null;
            // 0x00E56904: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_10A;
            // 0x00E56908: TBZ w8, #0, #0xe5691c      | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00E5690C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00E56910: CBNZ w8, #0xe5691c         | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00E56914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            // 0x00E56918: LDR x0, [x22]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_17 = null;
            label_10:
            // 0x00E5691C: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_static_fields;
            // 0x00E56920: LDR x22, [x8]              | X22 = ILRuntime.Mono.Empty<T>.Array;    
            // 0x00E56924: CBNZ x20, #0xe5692c        | if ( != 0) goto label_11;               
            if(null != 0)
            {
                goto label_11;
            }
            // 0x00E56928: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            label_11:
            // 0x00E5692C: STR x22, [x20, #0x38]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_38 = ILRuntime.Mono.Empty<T>.Array;  //  dest_result_addr=1152921504737677368
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_38 = ILRuntime.Mono.Empty<T>.Array;
            // 0x00E56930: STR xzr, [x20, #0x58]      | typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0x0;  //  dest_result_addr=1152921504737677400
            typeof(ILRuntime.Mono.Cecil.AssemblyNameReference).__il2cppRuntimeField_58 = 0;
            label_5:
            // 0x00E56934: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E56938: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00E5693C: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00E56940: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00E56944: LDR x8, [x8, #0xa88]       | X8 = 1152921504606900224;               
            // 0x00E56948: LDR x22, [x8]              | X22 = typeof(System.Object);            
            // 0x00E5694C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E56950: TBZ w8, #0, #0xe56960      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x00E56954: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E56958: CBNZ w8, #0xe56960         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x00E5695C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x00E56960: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56964: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56968: MOV x1, x22                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00E5696C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_3 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E56970: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00E56974: CBNZ x22, #0xe5697c        | if (val_3 != null) goto label_14;       
            if(val_3 != null)
            {
                goto label_14;
            }
            // 0x00E56978: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_14:
            // 0x00E5697C: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E56980: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x00E56984: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.Type).__il2cppRuntimeField_1B0; X1 = typeof(System.Type).__il2cppRuntimeField_1B8; //  | 
            // 0x00E56988: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_1B0();
            // 0x00E5698C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00E56990: CBNZ x22, #0xe56998        | if (val_3 != null) goto label_15;       
            if(val_3 != null)
            {
                goto label_15;
            }
            // 0x00E56994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_15:
            // 0x00E56998: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E5699C: MOV x0, x22                | X0 = val_3;//m1                         
            // 0x00E569A0: LDP x9, x1, [x8, #0x180]   | X9 = typeof(System.Type).__il2cppRuntimeField_180; X1 = typeof(System.Type).__il2cppRuntimeField_188; //  | 
            // 0x00E569A4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_180();
            // 0x00E569A8: ADRP x25, #0x3672000       | X25 = 57090048 (0x3672000);             
            // 0x00E569AC: LDR x25, [x25, #0xc88]     | X25 = 1152921504622075904;              
            // 0x00E569B0: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x00E569B4: LDR x8, [x25]              | X8 = typeof(System.IO.Path);            
            // 0x00E569B8: LDRB w9, [x8, #0x10a]      | W9 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E569BC: TBZ w9, #0, #0xe569d0      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x00E569C0: LDR w9, [x8, #0xbc]        | W9 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E569C4: CBNZ w9, #0xe569d0         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x00E569C8: MOV x0, x8                 | X0 = 1152921504622075904 (0x1000000000E86000);//ML01
            // 0x00E569CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_17:
            // 0x00E569D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E569D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E569D8: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x00E569DC: BL #0x1e6bf14              | X0 = System.IO.Path.GetDirectoryName(path:  0);
            string val_4 = System.IO.Path.GetDirectoryName(path:  0);
            // 0x00E569E0: ADRP x24, #0x3650000       | X24 = 56950784 (0x3650000);             
            // 0x00E569E4: LDR x24, [x24, #0xbe8]     | X24 = 1152921504738156544;              
            // 0x00E569E8: MOV x23, x0                | X23 = val_4;//m1                        
            // 0x00E569EC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_18 = null;
            // 0x00E569F0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E569F4: TBZ w9, #0, #0xe56a0c      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00E569F8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E569FC: CBNZ w9, #0xe56a0c         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00E56A00: MOV x0, x8                 | X0 = 1152921504738156544 (0x1000000007D3A000);//ML01
            // 0x00E56A04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            // 0x00E56A08: LDR x8, [x24]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_18 = null;
            label_19:
            // 0x00E56A0C: ADRP x9, #0x3680000        | X9 = 57147392 (0x3680000);              
            // 0x00E56A10: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_static_fields;
            // 0x00E56A14: LDR x9, [x9, #0x2d0]       | X9 = 1152921504948897168;               
            // 0x00E56A18: LDRB w26, [x8]             | W26 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono;
            // 0x00E56A1C: LDR x22, [x9]              | X22 = typeof(System.String[]);          
            // 0x00E56A20: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E56A24: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00E56A28: CBZ w26, #0xe56afc         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false) goto label_20;
            if(ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false)
            {
                goto label_20;
            }
            // 0x00E56A2C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00E56A30: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E56A34: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00E56A38: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
            val_19 = null;
            // 0x00E56A3C: CBNZ x22, #0xe56a44        | if ( != null) goto label_21;            
            if(null != null)
            {
                goto label_21;
            }
            // 0x00E56A40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_21:
            // 0x00E56A44: CBZ x23, #0xe56a68         | if (val_4 == null) goto label_23;       
            if(val_4 == null)
            {
                goto label_23;
            }
            // 0x00E56A48: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E56A4C: MOV x0, x23                | X0 = val_4;//m1                         
            // 0x00E56A50: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E56A54: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00E56A58: CBNZ x0, #0xe56a68         | if (val_4 != null) goto label_23;       
            if(val_4 != null)
            {
                goto label_23;
            }
            // 0x00E56A5C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00E56A60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56A64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_23:
            // 0x00E56A68: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E56A6C: CBNZ w8, #0xe56a7c         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_24;
            // 0x00E56A70: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00E56A74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56A78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_24:
            // 0x00E56A7C: STR x23, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = val_4;
            // 0x00E56A80: LDR x0, [x25]              | X0 = typeof(System.IO.Path);            
            // 0x00E56A84: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E56A88: TBZ w8, #0, #0xe56a98      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_26;
            // 0x00E56A8C: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E56A90: CBNZ w8, #0xe56a98         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_26;
            // 0x00E56A94: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_26:
            // 0x00E56A98: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x00E56A9C: LDR x8, [x8, #0x230]       | X8 = (string**)(1152921509462638976)("Facades");
            // 0x00E56AA0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56AA4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E56AA8: MOV x1, x23                | X1 = val_4;//m1                         
            // 0x00E56AAC: LDR x2, [x8]               | X2 = "Facades";                         
            // 0x00E56AB0: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_4);
            string val_5 = System.IO.Path.Combine(path1:  0, path2:  val_4);
            // 0x00E56AB4: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x00E56AB8: CBZ x23, #0xe56adc         | if (val_5 == null) goto label_28;       
            if(val_5 == null)
            {
                goto label_28;
            }
            // 0x00E56ABC: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E56AC0: MOV x0, x23                | X0 = val_5;//m1                         
            // 0x00E56AC4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E56AC8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x00E56ACC: CBNZ x0, #0xe56adc         | if (val_5 != null) goto label_28;       
            if(val_5 != null)
            {
                goto label_28;
            }
            // 0x00E56AD0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x00E56AD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56AD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_28:
            // 0x00E56ADC: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E56AE0: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00E56AE4: B.HI #0xe56af4             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_29;
            // 0x00E56AE8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x00E56AEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56AF0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_29:
            // 0x00E56AF4: STR x23, [x22, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = val_5;  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = val_5;
            // 0x00E56AF8: B #0xe56b50                |  goto label_30;                         
            goto label_30;
            label_20:
            // 0x00E56AFC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E56B00: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E56B04: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00E56B08: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
            val_19 = null;
            // 0x00E56B0C: CBNZ x22, #0xe56b14        | if ( != null) goto label_31;            
            if(null != null)
            {
                goto label_31;
            }
            // 0x00E56B10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_31:
            // 0x00E56B14: CBZ x23, #0xe56b38         | if (val_4 == null) goto label_33;       
            if(val_4 == null)
            {
                goto label_33;
            }
            // 0x00E56B18: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E56B1C: MOV x0, x23                | X0 = val_4;//m1                         
            // 0x00E56B20: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E56B24: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_4, ????);      
            // 0x00E56B28: CBNZ x0, #0xe56b38         | if (val_4 != null) goto label_33;       
            if(val_4 != null)
            {
                goto label_33;
            }
            // 0x00E56B2C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_4, ????);      
            // 0x00E56B30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56B34: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_33:
            // 0x00E56B38: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E56B3C: CBNZ w8, #0xe56b4c         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_34;
            // 0x00E56B40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_4, ????);      
            // 0x00E56B44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56B48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            label_34:
            // 0x00E56B4C: STR x23, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = val_4;  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = val_4;
            label_30:
            // 0x00E56B50: CBNZ x20, #0xe56b58        | if ( != 0) goto label_35;               
            if(null != 0)
            {
                goto label_35;
            }
            // 0x00E56B54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_35:
            // 0x00E56B58: LDR x0, [x24]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E56B5C: LDR x23, [x20, #0x20]      | X23 = ILRuntime.Mono.Cecil.AssemblyNameReference.__il2cppRuntimeField_byval_arg;
            // 0x00E56B60: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E56B64: TBZ w8, #0, #0xe56b74      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_37;
            // 0x00E56B68: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E56B6C: CBNZ w8, #0xe56b74         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
            // 0x00E56B70: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_37:
            // 0x00E56B74: MOV x1, x23                | X1 = ILRuntime.Mono.Cecil.AssemblyNameReference.__il2cppRuntimeField_byval_arg;//m1
            // 0x00E56B78: BL #0xe56ca0               | X0 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.IsZero(version:  null);
            bool val_6 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.IsZero(version:  null);
            // 0x00E56B7C: TBZ w0, #0, #0xe56ba0      | if (val_6 == false) goto label_38;      
            if(val_6 == false)
            {
                goto label_38;
            }
            // 0x00E56B80: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E56B84: MOV x0, x19                | X0 = 1152921509462684576 (0x10000001216E33A0);//ML01
            val_14 = this;
            // 0x00E56B88: MOV x1, x20                | X1 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E56B8C: MOV x2, x22                | X2 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E56B90: LDP x9, x4, [x8, #0x190]   | X9 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_190; X4 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_198; //  | 
            // 0x00E56B94: MOV x3, x21                | X3 = parameters;//m1                    
            // 0x00E56B98: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_190();
            // 0x00E56B9C: CBNZ x0, #0xe56c50         | if (this != null) goto label_46;        
            if(this != null)
            {
                goto label_46;
            }
            label_38:
            // 0x00E56BA0: CBNZ x20, #0xe56ba8        | if ( != 0) goto label_40;               
            if(null != 0)
            {
                goto label_40;
            }
            // 0x00E56BA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_40:
            // 0x00E56BA8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E56BAC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E56BB0: LDR x23, [x20, #0x10]      | X23 = ILRuntime.Mono.Cecil.AssemblyNameReference.__il2cppRuntimeField_name;
            // 0x00E56BB4: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00E56BB8: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E56BBC: TBZ w8, #0, #0xe56bcc      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_42;
            // 0x00E56BC0: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E56BC4: CBNZ w8, #0xe56bcc         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_42;
            // 0x00E56BC8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_42:
            // 0x00E56BCC: ADRP x8, #0x35cd000        | X8 = 56414208 (0x35CD000);              
            // 0x00E56BD0: LDR x8, [x8, #0x748]       | X8 = (string**)(1152921509414824416)("mscorlib");
            // 0x00E56BD4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56BD8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E56BDC: MOV x1, x23                | X1 = 1152921506068135424 (0x1000000057197E00);//ML01
            // 0x00E56BE0: LDR x2, [x8]               | X2 = "mscorlib";                        
            // 0x00E56BE4: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  ILRuntime.Mono.Cecil.AssemblyNameReference.__il2cppRuntimeField_name);
            bool val_7 = System.String.op_Equality(a:  0, b:  ILRuntime.Mono.Cecil.AssemblyNameReference.__il2cppRuntimeField_name);
            // 0x00E56BE8: TBZ w0, #0, #0xe56c00      | if (val_7 == false) goto label_43;      
            if(val_7 == false)
            {
                goto label_43;
            }
            // 0x00E56BEC: MOV x0, x19                | X0 = 1152921509462684576 (0x10000001216E33A0);//ML01
            // 0x00E56BF0: MOV x1, x20                | X1 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E56BF4: MOV x2, x21                | X2 = parameters;//m1                    
            // 0x00E56BF8: BL #0xe56d28               | X0 = this.GetCorlib(reference:  val_12, parameters:  parameters);
            ILRuntime.Mono.Cecil.AssemblyDefinition val_8 = this.GetCorlib(reference:  val_12, parameters:  parameters);
            // 0x00E56BFC: CBNZ x0, #0xe56c50         | if (val_8 != null) goto label_46;       
            if(val_8 != null)
            {
                goto label_46;
            }
            label_43:
            // 0x00E56C00: MOV x0, x19                | X0 = 1152921509462684576 (0x10000001216E33A0);//ML01
            // 0x00E56C04: MOV x1, x20                | X1 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E56C08: MOV x2, x21                | X2 = parameters;//m1                    
            // 0x00E56C0C: BL #0xe57408               | X0 = this.GetAssemblyInGac(reference:  val_12, parameters:  parameters);
            ILRuntime.Mono.Cecil.AssemblyDefinition val_9 = this.GetAssemblyInGac(reference:  val_12, parameters:  parameters);
            // 0x00E56C10: CBNZ x0, #0xe56c50         | if (val_9 != null) goto label_46;       
            if(val_9 != null)
            {
                goto label_46;
            }
            // 0x00E56C14: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E56C18: MOV x0, x19                | X0 = 1152921509462684576 (0x10000001216E33A0);//ML01
            val_14 = this;
            // 0x00E56C1C: MOV x1, x20                | X1 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E56C20: MOV x2, x22                | X2 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E56C24: LDP x9, x4, [x8, #0x190]   | X9 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_190; X4 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_198; //  | 
            // 0x00E56C28: MOV x3, x21                | X3 = parameters;//m1                    
            // 0x00E56C2C: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_190();
            // 0x00E56C30: CBNZ x0, #0xe56c50         | if (this != null) goto label_46;        
            if(this != null)
            {
                goto label_46;
            }
            // 0x00E56C34: LDR x0, [x19, #0x20]       | X0 = this.ResolveFailure; //P2          
            // 0x00E56C38: CBZ x0, #0xe56c68          | if (this.ResolveFailure == null) goto label_48;
            if(this.ResolveFailure == null)
            {
                goto label_48;
            }
            // 0x00E56C3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E56C40: MOV x1, x19                | X1 = 1152921509462684576 (0x10000001216E33A0);//ML01
            // 0x00E56C44: MOV x2, x20                | X2 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E56C48: BL #0xe561f8               | X0 = this.ResolveFailure.Invoke(sender:  this, reference:  val_12);
            ILRuntime.Mono.Cecil.AssemblyDefinition val_10 = this.ResolveFailure.Invoke(sender:  this, reference:  val_12);
            // 0x00E56C4C: CBZ x0, #0xe56c68          | if (val_10 == null) goto label_48;      
            if(val_10 == null)
            {
                goto label_48;
            }
            label_46:
            // 0x00E56C50: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E56C54: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E56C58: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E56C5C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E56C60: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E56C64: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyDefinition)val_10;
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyDefinition, size=8, nGRN=0 }
            label_48:
            // 0x00E56C68: ADRP x8, #0x35c3000        | X8 = 56373248 (0x35C3000);              
            // 0x00E56C6C: LDR x8, [x8, #0x778]       | X8 = 1152921504738103296;               
            // 0x00E56C70: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.AssemblyResolutionException);
            ILRuntime.Mono.Cecil.AssemblyResolutionException val_11 = null;
            // 0x00E56C74: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Cecil.AssemblyResolutionException), ????);
            // 0x00E56C78: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56C7C: MOV x1, x20                | X1 = 1152921504737677312 (0x1000000007CC5000);//ML01
            // 0x00E56C80: MOV x19, x0                | X19 = 1152921504738103296 (0x1000000007D2D000);//ML01
            // 0x00E56C84: BL #0xe5613c               | .ctor(reference:  val_12, innerException:  0);
            val_11 = new ILRuntime.Mono.Cecil.AssemblyResolutionException(reference:  val_12, innerException:  0);
            // 0x00E56C88: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00E56C8C: LDR x8, [x8, #0x2f8]       | X8 = 1152921509462659552;               
            // 0x00E56C90: MOV x0, x19                | X0 = 1152921504738103296 (0x1000000007D2D000);//ML01
            // 0x00E56C94: LDR x1, [x8]               | X1 = public ILRuntime.Mono.Cecil.AssemblyDefinition ILRuntime.Mono.Cecil.BaseAssemblyResolver::Resolve(ILRuntime.Mono.Cecil.AssemblyNameReference name, ILRuntime.Mono.Cecil.ReaderParameters parameters);
            // 0x00E56C98: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(ILRuntime.Mono.Cecil.AssemblyResolutionException), ????);
            // 0x00E56C9C: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(ILRuntime.Mono.Cecil.AssemblyResolutionException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5752C (15037740), len: 1284  VirtAddr: 0x00E5752C RVA: 0x00E5752C token: 100663735 methodIndex: 19328 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual ILRuntime.Mono.Cecil.AssemblyDefinition SearchDirectory(ILRuntime.Mono.Cecil.AssemblyNameReference name, System.Collections.Generic.IEnumerable<string> directories, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_20;
            // 0x00E5752C: STP x28, x27, [sp, #-0x60]! | stack[1152921509462858448] = ???;  stack[1152921509462858456] = ???;  //  dest_result_addr=1152921509462858448 |  dest_result_addr=1152921509462858456
            // 0x00E57530: STP x26, x25, [sp, #0x10]  | stack[1152921509462858464] = ???;  stack[1152921509462858472] = ???;  //  dest_result_addr=1152921509462858464 |  dest_result_addr=1152921509462858472
            // 0x00E57534: STP x24, x23, [sp, #0x20]  | stack[1152921509462858480] = ???;  stack[1152921509462858488] = ???;  //  dest_result_addr=1152921509462858480 |  dest_result_addr=1152921509462858488
            // 0x00E57538: STP x22, x21, [sp, #0x30]  | stack[1152921509462858496] = ???;  stack[1152921509462858504] = ???;  //  dest_result_addr=1152921509462858496 |  dest_result_addr=1152921509462858504
            // 0x00E5753C: STP x20, x19, [sp, #0x40]  | stack[1152921509462858512] = ???;  stack[1152921509462858520] = ???;  //  dest_result_addr=1152921509462858512 |  dest_result_addr=1152921509462858520
            // 0x00E57540: STP x29, x30, [sp, #0x50]  | stack[1152921509462858528] = ???;  stack[1152921509462858536] = ???;  //  dest_result_addr=1152921509462858528 |  dest_result_addr=1152921509462858536
            // 0x00E57544: ADD x29, sp, #0x50         | X29 = (1152921509462858448 + 80) = 1152921509462858528 (0x100000012170DB20);
            // 0x00E57548: SUB sp, sp, #0x10          | SP = (1152921509462858448 - 16) = 1152921509462858432 (0x100000012170DAC0);
            // 0x00E5754C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E57550: LDRB w8, [x19, #0xac9]     | W8 = (bool)static_value_03734AC9;       
            // 0x00E57554: MOV x23, x2                | X23 = directories;//m1                  
            // 0x00E57558: MOV x20, x1                | X20 = name;//m1                         
            // 0x00E5755C: STR x3, [sp, #8]           | stack[1152921509462858440] = parameters;  //  dest_result_addr=1152921509462858440
            // 0x00E57560: STR x0, [sp]               | stack[1152921509462858432] = this;       //  dest_result_addr=1152921509462858432
            // 0x00E57564: TBNZ w8, #0, #0xe57580     | if (static_value_03734AC9 == true) goto label_0;
            // 0x00E57568: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E5756C: LDR x8, [x8, #0xab8]       | X8 = 0x2B8F018;                         
            // 0x00E57570: LDR w0, [x8]               | W0 = 0x12C8;                            
            // 0x00E57574: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C8, ????);     
            // 0x00E57578: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5757C: STRB w8, [x19, #0xac9]     | static_value_03734AC9 = true;            //  dest_result_addr=57887433
            label_0:
            // 0x00E57580: CBNZ x20, #0xe57588        | if (name != null) goto label_1;         
            if(name != null)
            {
                goto label_1;
            }
            // 0x00E57584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12C8, ????);     
            label_1:
            // 0x00E57588: MOV x0, x20                | X0 = name;//m1                          
            // 0x00E5758C: BL #0xe55630               | X0 = name.get_IsWindowsRuntime();       
            bool val_1 = name.IsWindowsRuntime;
            // 0x00E57590: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E57594: LDR x8, [x8, #0x2d0]       | X8 = 1152921504948897168;               
            // 0x00E57598: MOV w24, w0                | W24 = val_1;//m1                        
            // 0x00E5759C: LDR x22, [x8]              | X22 = typeof(System.String[]);          
            // 0x00E575A0: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E575A4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00E575A8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00E575AC: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E575B0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00E575B4: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E575B8: CBNZ x22, #0xe575c0        | if ( != null) goto label_2;             
            if(null != null)
            {
                goto label_2;
            }
            // 0x00E575BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_2:
            // 0x00E575C0: AND w8, w24, #1            | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x00E575C4: TBZ w8, #0, #0xe575d4      | if ((val_1 & 1) == false) goto label_3; 
            if(val_2 == false)
            {
                goto label_3;
            }
            // 0x00E575C8: ADRP x19, #0x35c8000       | X19 = 56393728 (0x35C8000);             
            // 0x00E575CC: LDR x19, [x19, #0xa10]     | X19 = (string**)(1152921509462829920)(".winmd");
            val_12 = ".winmd";
            // 0x00E575D0: B #0xe575dc                |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x00E575D4: ADRP x19, #0x3614000       | X19 = 56705024 (0x3614000);             
            // 0x00E575D8: LDR x19, [x19, #0xe50]     | X19 = (string**)(1152921509462830000)(".exe");
            val_12 = ".exe";
            label_4:
            // 0x00E575DC: LDR x0, [x19]              | X0 = ".exe";                            
            // 0x00E575E0: CBZ x0, #0xe57600          | if (".exe" == null) goto label_6;       
            // 0x00E575E4: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E575E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E575EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ".exe", ????);     
            // 0x00E575F0: CBNZ x0, #0xe57600         | if (".exe" != null) goto label_6;       
            if(".exe" != null)
            {
                goto label_6;
            }
            // 0x00E575F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ".exe", ????);     
            // 0x00E575F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E575FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ".exe", ????);     
            label_6:
            // 0x00E57600: LDR x19, [x19]             | X19 = ".exe";                           
            // 0x00E57604: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E57608: CBNZ w8, #0xe57618         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_7;
            // 0x00E5760C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ".exe", ????);     
            // 0x00E57610: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57614: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ".exe", ????);     
            label_7:
            // 0x00E57618: STR x19, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = ".exe";  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = ".exe";
            // 0x00E5761C: ADRP x19, #0x35d2000       | X19 = 56434688 (0x35D2000);             
            // 0x00E57620: LDR x19, [x19, #0xa70]     | X19 = (string**)(1152921509462830080)(".dll");
            // 0x00E57624: LDR x0, [x19]              | X0 = ".dll";                            
            // 0x00E57628: CBZ x0, #0xe57648          | if (".dll" == null) goto label_9;       
            // 0x00E5762C: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E57630: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E57634: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? ".dll", ????);     
            // 0x00E57638: CBNZ x0, #0xe57648         | if (".dll" != null) goto label_9;       
            if(".dll" != null)
            {
                goto label_9;
            }
            // 0x00E5763C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? ".dll", ????);     
            // 0x00E57640: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57644: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ".dll", ????);     
            label_9:
            // 0x00E57648: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E5764C: LDR x19, [x19]             | X19 = ".dll";                           
            // 0x00E57650: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00E57654: B.HI #0xe57664             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_10;
            // 0x00E57658: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? ".dll", ????);     
            // 0x00E5765C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57660: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? ".dll", ????);     
            label_10:
            // 0x00E57664: STR x19, [x22, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = ".dll";  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = ".dll";
            // 0x00E57668: CBNZ x23, #0xe57670        | if (directories != null) goto label_11; 
            if(directories != null)
            {
                goto label_11;
            }
            // 0x00E5766C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? ".dll", ????);     
            label_11:
            // 0x00E57670: ADRP x9, #0x361f000        | X9 = 56750080 (0x361F000);              
            // 0x00E57674: LDR x8, [x23]              | X8 = typeof(System.Collections.Generic.IEnumerable<System.String>);
            // 0x00E57678: LDR x9, [x9, #0xfe8]       | X9 = 1152921504608391168;               
            // 0x00E5767C: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IEnumerable<T>);
            // 0x00E57680: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E57684: CBZ x9, #0xe576b0          | if (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_12;
            // 0x00E57688: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E5768C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_12 = 0;
            // 0x00E57690: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608428040 (0x1000000000182008);
            label_14:
            // 0x00E57694: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E57698: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IEnumerable<T>))
            // 0x00E5769C: B.EQ #0xe576c0             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_13;
            // 0x00E576A0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_12 = val_12 + 1;
            // 0x00E576A4: ADD x10, x10, #0x10        | X10 = (1152921504608428040 + 16) = 1152921504608428056 (0x1000000000182018);
            // 0x00E576A8: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E576AC: B.LO #0xe57694             | if (0 < System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count) goto label_14;
            label_12:
            // 0x00E576B0: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E576B4: MOV x0, x23                | X0 = directories;//m1                   
            val_13 = directories;
            // 0x00E576B8: BL #0x2776c24              | X0 = sub_2776C24( ?? directories, ????);
            // 0x00E576BC: B #0xe576cc                |  goto label_15;                         
            goto label_15;
            label_13:
            // 0x00E576C0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E576C4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E576C8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_15:
            // 0x00E576CC: LDP x8, x1, [x0]           | X8 = ".dll"; X1 = ".dll".__il2cppRuntimeField_8; //  | 
            // 0x00E576D0: MOV x0, x23                | X0 = directories;//m1                   
            // 0x00E576D4: BLR x8                     | X0 = x8();                              
            // 0x00E576D8: ADRP x28, #0x35d6000       | X28 = 56451072 (0x35D6000);             
            // 0x00E576DC: ADRP x27, #0x3672000       | X27 = 57090048 (0x3672000);             
            // 0x00E576E0: LDR x28, [x28, #0xe38]     | X28 = 1152921504608284672;              
            // 0x00E576E4: LDR x27, [x27, #0xc88]     | X27 = 1152921504622075904;              
            // 0x00E576E8: MOV x23, x0                | X23 = directories;//m1                  
            // 0x00E576EC: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            label_29:
            // 0x00E576F0: CBNZ x23, #0xe576f8        | if (directories != null) goto label_16; 
            if(directories != null)
            {
                goto label_16;
            }
            // 0x00E576F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? directories, ????);
            label_16:
            // 0x00E576F8: ADRP x9, #0x361c000        | X9 = 56737792 (0x361C000);              
            // 0x00E576FC: LDR x8, [x23]              | X8 = typeof(System.Collections.Generic.IEnumerable<System.String>);
            // 0x00E57700: LDR x9, [x9, #0x358]       | X9 = 1152921504608018432;               
            // 0x00E57704: LDR x1, [x9]               | X1 = typeof(System.Collections.IEnumerator);
            // 0x00E57708: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E5770C: CBZ x9, #0xe57738          | if (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_17;
            // 0x00E57710: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E57714: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_13 = 0;
            // 0x00E57718: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608428040 (0x1000000000182008);
            label_19:
            // 0x00E5771C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E57720: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IEnumerator))
            // 0x00E57724: B.EQ #0xe57748             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_18;
            // 0x00E57728: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_13 = val_13 + 1;
            // 0x00E5772C: ADD x10, x10, #0x10        | X10 = (1152921504608428040 + 16) = 1152921504608428056 (0x1000000000182018);
            // 0x00E57730: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E57734: B.LO #0xe5771c             | if (0 < System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count) goto label_19;
            label_17:
            // 0x00E57738: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x00E5773C: MOV x0, x23                | X0 = directories;//m1                   
            val_14 = directories;
            // 0x00E57740: BL #0x2776c24              | X0 = sub_2776C24( ?? directories, ????);
            // 0x00E57744: B #0xe57758                |  goto label_20;                         
            goto label_20;
            label_18:
            // 0x00E57748: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E5774C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x00E57750: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x00E57754: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_20:
            // 0x00E57758: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerable<System.String>);  //  | 
            // 0x00E5775C: MOV x0, x23                | X0 = directories;//m1                   
            // 0x00E57760: BLR x8                     | X0 = sub_1000000000179000( ?? directories, ????);
            // 0x00E57764: AND w8, w0, #1             | W8 = (directories & 1);                 
            System.Collections.Generic.IEnumerable<System.String> val_5 = directories & 1;
            // 0x00E57768: TBZ w8, #0, #0xe579f8      | if (((directories & 1) & 0x1) == 0) goto label_21;
            if((val_5 & 1) == 0)
            {
                goto label_21;
            }
            // 0x00E5776C: CBNZ x23, #0xe57774        | if (directories != null) goto label_22; 
            if(directories != null)
            {
                goto label_22;
            }
            // 0x00E57770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? directories, ????);
            label_22:
            // 0x00E57774: ADRP x9, #0x361e000        | X9 = 56745984 (0x361E000);              
            // 0x00E57778: LDR x8, [x23]              | X8 = typeof(System.Collections.Generic.IEnumerable<System.String>);
            // 0x00E5777C: LDR x9, [x9, #0x858]       | X9 = 1152921504608178176;               
            // 0x00E57780: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.IEnumerator<T>);
            // 0x00E57784: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E57788: CBZ x9, #0xe577b4          | if (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_23;
            // 0x00E5778C: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E57790: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_14 = 0;
            // 0x00E57794: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608428040 (0x1000000000182008);
            label_25:
            // 0x00E57798: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E5779C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.Generic.IEnumerator<T>))
            // 0x00E577A0: B.EQ #0xe577c4             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_24;
            // 0x00E577A4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_14 = val_14 + 1;
            // 0x00E577A8: ADD x10, x10, #0x10        | X10 = (1152921504608428040 + 16) = 1152921504608428056 (0x1000000000182018);
            // 0x00E577AC: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E577B0: B.LO #0xe57798             | if (0 < System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count) goto label_25;
            label_23:
            // 0x00E577B4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E577B8: MOV x0, x23                | X0 = directories;//m1                   
            val_15 = directories;
            // 0x00E577BC: BL #0x2776c24              | X0 = sub_2776C24( ?? directories, ????);
            // 0x00E577C0: B #0xe577d0                |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x00E577C4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E577C8: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E577CC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_26:
            // 0x00E577D0: LDP x8, x1, [x0]           | X8 = typeof(System.Collections.Generic.IEnumerable<System.String>);  //  | 
            // 0x00E577D4: MOV x0, x23                | X0 = directories;//m1                   
            // 0x00E577D8: BLR x8                     | X0 = sub_1000000000179000( ?? directories, ????);
            // 0x00E577DC: MOV x24, x0                | X24 = directories;//m1                  
            // 0x00E577E0: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00E577E4: B #0xe577ec                |  goto label_27;                         
            goto label_27;
            label_40:
            // 0x00E577E8: ADD w19, w19, #1           | W19 = (val_16 + 1) = val_16 (0x00000001);
            val_16 = 1;
            label_27:
            // 0x00E577EC: CBNZ x22, #0xe577f4        | if ( != null) goto label_28;            
            if(null != null)
            {
                goto label_28;
            }
            // 0x00E577F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? directories, ????);
            label_28:
            // 0x00E577F4: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E577F8: CMP w19, w8                | STATE = COMPARE(0x1, System.String[].__il2cppRuntimeField_namespaze)
            // 0x00E577FC: B.GE #0xe576f0             | if (val_16 >= System.String[].__il2cppRuntimeField_namespaze) goto label_29;
            // 0x00E57800: CMP w19, w8                | STATE = COMPARE(0x1, System.String[].__il2cppRuntimeField_namespaze)
            // 0x00E57804: B.LO #0xe57814             | if (val_16 < System.String[].__il2cppRuntimeField_namespaze) goto label_30;
            // 0x00E57808: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? directories, ????);
            // 0x00E5780C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57810: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? directories, ????);
            label_30:
            // 0x00E57814: SXTW x8, w19               | X8 = 1 (0x00000001);                    
            // 0x00E57818: ADD x8, x22, x8, lsl #3    | X8 = (null + 8) = 1152921504948897176 (0x1000000014634598);
            // 0x00E5781C: LDR x25, [x8, #0x20]       | X25 = ".dll";                           
            // 0x00E57820: CBNZ x20, #0xe57828        | if (name != null) goto label_31;        
            if(name != null)
            {
                goto label_31;
            }
            // 0x00E57824: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? directories, ????);
            label_31:
            // 0x00E57828: LDR x0, [x28]              | X0 = typeof(System.String);             
            // 0x00E5782C: LDR x26, [x20, #0x10]      | X26 = name.name; //P2                   
            // 0x00E57830: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E57834: TBZ w8, #0, #0xe57844      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x00E57838: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E5783C: CBNZ w8, #0xe57844         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x00E57840: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_33:
            // 0x00E57844: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57848: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5784C: MOV x1, x26                | X1 = name.name;//m1                     
            // 0x00E57850: MOV x2, x25                | X2 = 1152921509462830080 (0x1000000121706C00);//ML01
            // 0x00E57854: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  name.name);
            string val_7 = System.String.Concat(str0:  0, str1:  name.name);
            // 0x00E57858: MOV x25, x0                | X25 = val_7;//m1                        
            // 0x00E5785C: LDR x0, [x27]              | X0 = typeof(System.IO.Path);            
            // 0x00E57860: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57864: TBZ w8, #0, #0xe57874      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_35;
            // 0x00E57868: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E5786C: CBNZ w8, #0xe57874         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
            // 0x00E57870: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_35:
            // 0x00E57874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57878: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5787C: MOV x1, x24                | X1 = directories;//m1                   
            // 0x00E57880: MOV x2, x25                | X2 = val_7;//m1                         
            // 0x00E57884: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  directories);
            string val_8 = System.IO.Path.Combine(path1:  0, path2:  directories);
            // 0x00E57888: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x00E5788C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57894: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00E57898: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_9 = System.IO.File.Exists(path:  0);
            // 0x00E5789C: TBZ w0, #0, #0xe577e8      | if (val_9 == false) goto label_40;      
            if(val_9 == false)
            {
                goto label_40;
            }
            // 0x00E578A0: LDP x0, x2, [sp]           | X0 = this; X2 = parameters;              //  | 
            // 0x00E578A4: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x00E578A8: BL #0xe566ec               | X0 = this.GetAssembly(file:  val_8, parameters:  parameters);
            ILRuntime.Mono.Cecil.AssemblyDefinition val_10 = this.GetAssembly(file:  val_8, parameters:  parameters);
            // 0x00E578AC: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00E578B0: B #0xe579d8                |  goto label_37;                         
            goto label_37;
            // 0x00E578B4: MOV x26, x1                | X26 = val_8;//m1                        
            val_17 = val_8;
            // 0x00E578B8: MOV x25, x0                | X25 = val_10;//m1                       
            val_18 = val_10;
            // 0x00E578BC: CMP w26, #1                | STATE = COMPARE(val_8, 0x1)             
            // 0x00E578C0: B.NE #0xe57904             | if (val_17 != 0x1) goto label_52;       
            if(val_17 != 1)
            {
                goto label_52;
            }
            // 0x00E578C4: MOV x0, x25                | X0 = val_10;//m1                        
            // 0x00E578C8: BL #0x981060               | X0 = sub_981060( ?? val_10, ????);      
            // 0x00E578CC: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00E578D0: ADRP x9, #0x365e000        | X9 = 57008128 (0x365E000);              
            // 0x00E578D4: LDR x8, [x25]              | X8 = typeof(ILRuntime.Mono.Cecil.AssemblyDefinition);
            // 0x00E578D8: LDR x9, [x9, #0x9e0]       | X9 = 1152921504652267520;               
            // 0x00E578DC: LDR x1, [x8]               | X1 = ;                                  
            // 0x00E578E0: LDR x0, [x9]               | X0 = typeof(System.BadImageFormatException);
            // 0x00E578E4: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.BadImageFormatException), ????);
            // 0x00E578E8: TBZ w0, #0, #0xe57a08      | if ((typeof(System.BadImageFormatException) & 0x1) == 0) goto label_39;
            if((null & 1) == 0)
            {
                goto label_39;
            }
            // 0x00E578EC: BL #0x980920               | X0 = sub_980920( ?? typeof(System.BadImageFormatException), ????);
            // 0x00E578F0: B #0xe577e8                |  goto label_40;                         
            goto label_40;
            // 0x00E578F4: B #0xe578f8                |  goto label_41;                         
            goto label_41;
            label_41:
            // 0x00E578F8: MOV x26, x1                | X26 = X1;//m1                           
            val_17 = null;
            // 0x00E578FC: MOV x25, x0                | X25 = 1152921504652267520 (0x1000000002B51000);//ML01
            val_18 = null;
            // 0x00E57900: ORR w21, wzr, #1           | W21 = 1(0x1);                           
            label_52:
            // 0x00E57904: MOV x0, x25                | X0 = 1152921504652267520 (0x1000000002B51000);//ML01
            // 0x00E57908: CMP w26, w21               | STATE = COMPARE(, 0x1)                  
            // 0x00E5790C: B.NE #0xe57a28             | if (val_17 != 1) goto label_42;         
            if(val_17 != 1)
            {
                goto label_42;
            }
            // 0x00E57910: BL #0x981060               | X0 = sub_981060( ?? typeof(System.BadImageFormatException), ????);
            // 0x00E57914: LDR x19, [x0]              | X19 = ;                                 
            // 0x00E57918: BL #0x980920               | X0 = sub_980920( ?? typeof(System.BadImageFormatException), ????);
            // 0x00E5791C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            // 0x00E57920: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_53:
            // 0x00E57924: CBZ x23, #0xe57990         | if (directories == null) goto label_43; 
            if(directories == null)
            {
                goto label_43;
            }
            // 0x00E57928: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x00E5792C: LDR x8, [x23]              | X8 = typeof(System.Collections.Generic.IEnumerable<System.String>);
            // 0x00E57930: LDR x9, [x9, #0x7a8]       | X9 = 1152921504608124928;               
            // 0x00E57934: LDR x1, [x9]               | X1 = typeof(System.IDisposable);        
            // 0x00E57938: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x00E5793C: CBZ x9, #0xe57968          | if (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_44;
            // 0x00E57940: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x00E57944: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_15 = 0;
            // 0x00E57948: ADD x10, x10, #8           | X10 = (System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504608428040 (0x1000000000182008);
            label_46:
            // 0x00E5794C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x00E57950: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.IDisposable))
            // 0x00E57954: B.EQ #0xe57978             | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_45;
            // 0x00E57958: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_15 = val_15 + 1;
            // 0x00E5795C: ADD x10, x10, #0x10        | X10 = (1152921504608428040 + 16) = 1152921504608428056 (0x1000000000182018);
            // 0x00E57960: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x00E57964: B.LO #0xe5794c             | if (0 < System.Collections.Generic.IEnumerable<T>.__il2cppRuntimeField_interface_offsets_count) goto label_46;
            label_44:
            // 0x00E57968: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00E5796C: MOV x0, x23                | X0 = directories;//m1                   
            val_20 = directories;
            // 0x00E57970: BL #0x2776c24              | X0 = sub_2776C24( ?? directories, ????);
            // 0x00E57974: B #0xe57984                |  goto label_47;                         
            goto label_47;
            label_45:
            // 0x00E57978: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x00E5797C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x00E57980: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504608391168 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_47:
            // 0x00E57984: LDP x8, x1, [x0]           | X8 = ; X1 = System.BadImageFormatException.__il2cppRuntimeField_gc_desc; //  | 
            // 0x00E57988: MOV x0, x23                | X0 = directories;//m1                   
            // 0x00E5798C: BLR x8                     | X0 = x8();                              
            label_43:
            // 0x00E57990: CMP w20, #0xa4             | STATE = COMPARE(0x0, 0xA4)              
            // 0x00E57994: B.EQ #0xe579b0             | if (0 == 0xA4) goto label_50;           
            if(0 == 164)
            {
                goto label_50;
            }
            // 0x00E57998: CMP w20, #0xa6             | STATE = COMPARE(0x0, 0xA6)              
            // 0x00E5799C: B.EQ #0xe579b4             | if (0 == 0xA6) goto label_49;           
            if(0 == 166)
            {
                goto label_49;
            }
            // 0x00E579A0: CBZ x19, #0xe579b0         | if ( == 0) goto label_50;               
            if(null == 0)
            {
                goto label_50;
            }
            // 0x00E579A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E579A8: MOV x0, x19                | X0 = X19;//m1                           
            // 0x00E579AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? , ????);           
            label_50:
            // 0x00E579B0: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_49:
            // 0x00E579B4: MOV x0, x25                | X0 = 0 (0x0);//ML01                     
            // 0x00E579B8: SUB sp, x29, #0x50         | SP = (1152921509462858528 - 80) = 1152921509462858448 (0x100000012170DAD0);
            // 0x00E579BC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E579C0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E579C4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E579C8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E579CC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E579D0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E579D4: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyDefinition)null;
            return (ILRuntime.Mono.Cecil.AssemblyDefinition)val_19;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyDefinition, size=8, nGRN=0 }
            label_37:
            // 0x00E579D8: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x00E579DC: MOVZ w20, #0xa6            | W20 = 166 (0xA6);//ML01                 
            // 0x00E579E0: B #0xe57924                |  goto label_53;                         
            goto label_53;
            label_54:
            // 0x00E579E4: MOV x26, x1                | X26 = val_8;//m1                        
            // 0x00E579E8: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x00E579EC: BL #0x980920               | X0 = sub_980920( ?? val_10, ????);      
            // 0x00E579F0: B #0xe57904                |  goto label_52;                         
            goto label_52;
            // 0x00E579F4: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
            label_21:
            // 0x00E579F8: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            // 0x00E579FC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            // 0x00E57A00: MOVZ w20, #0xa4            | W20 = 164 (0xA4);//ML01                 
            // 0x00E57A04: B #0xe57924                |  goto label_53;                         
            goto label_53;
            label_39:
            // 0x00E57A08: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00E57A0C: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x00E57A10: LDR x8, [x25]              | X8 = typeof(ILRuntime.Mono.Cecil.AssemblyDefinition);
            // 0x00E57A14: STR x8, [x0]               | mem[8] = typeof(ILRuntime.Mono.Cecil.AssemblyDefinition);  //  dest_result_addr=8
            mem[8] = null;
            // 0x00E57A18: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x00E57A1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57A20: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x00E57A24: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            label_42:
            // 0x00E57A28: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
            // 0x00E57A2C: B #0xe579e4                |  goto label_54;                         
            goto label_54;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E56CA0 (15035552), len: 136  VirtAddr: 0x00E56CA0 RVA: 0x00E56CA0 token: 100663736 methodIndex: 19329 delegateWrapperIndex: 0 methodInvoker: 0
        private static bool IsZero(System.Version version)
        {
            //
            // Disasemble & Code
            // 0x00E56CA0: STP x20, x19, [sp, #-0x20]! | stack[1152921509463003280] = ???;  stack[1152921509463003288] = ???;  //  dest_result_addr=1152921509463003280 |  dest_result_addr=1152921509463003288
            // 0x00E56CA4: STP x29, x30, [sp, #0x10]  | stack[1152921509463003296] = ???;  stack[1152921509463003304] = ???;  //  dest_result_addr=1152921509463003296 |  dest_result_addr=1152921509463003304
            // 0x00E56CA8: ADD x29, sp, #0x10         | X29 = (1152921509463003280 + 16) = 1152921509463003296 (0x10000001217310A0);
            // 0x00E56CAC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00E56CB0: CBNZ x19, #0xe56cb8        | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x00E56CB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? version, ????);    
            label_0:
            // 0x00E56CB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56CBC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00E56CC0: BL #0x273b9a4              | X0 = X1.get_Major();                    
            int val_1 = X1.Major;
            // 0x00E56CC4: CBNZ w0, #0xe56cf8         | if (val_1 != 0) goto label_3;           
            if(val_1 != 0)
            {
                goto label_3;
            }
            // 0x00E56CC8: CBNZ x19, #0xe56cd0        | if (X1 != 0) goto label_2;              
            if(X1 != 0)
            {
                goto label_2;
            }
            // 0x00E56CCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_2:
            // 0x00E56CD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56CD4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00E56CD8: BL #0x273b9ac              | X0 = X1.get_Minor();                    
            int val_2 = X1.Minor;
            // 0x00E56CDC: CBNZ w0, #0xe56cf8         | if (val_2 != 0) goto label_3;           
            if(val_2 != 0)
            {
                goto label_3;
            }
            // 0x00E56CE0: CBNZ x19, #0xe56ce8        | if (X1 != 0) goto label_4;              
            if(X1 != 0)
            {
                goto label_4;
            }
            // 0x00E56CE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x00E56CE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56CEC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00E56CF0: BL #0x273b99c              | X0 = X1.get_Build();                    
            int val_3 = X1.Build;
            // 0x00E56CF4: CBZ w0, #0xe56d08          | if (val_3 == 0) goto label_5;           
            if(val_3 == 0)
            {
                goto label_5;
            }
            label_3:
            // 0x00E56CF8: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            label_7:
            // 0x00E56CFC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E56D00: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E56D04: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_5:
            // 0x00E56D08: CBNZ x19, #0xe56d10        | if (X1 != 0) goto label_6;              
            if(X1 != 0)
            {
                goto label_6;
            }
            // 0x00E56D0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x00E56D10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56D14: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00E56D18: BL #0x273b9b4              | X0 = X1.get_Revision();                 
            int val_4 = X1.Revision;
            // 0x00E56D1C: CMP w0, #0                 | STATE = COMPARE(val_4, 0x0)             
            // 0x00E56D20: CSET w0, eq                | W0 = val_4 == 0 ? 1 : 0;                
            var val_5 = (val_4 == 0) ? 1 : 0;
            // 0x00E56D24: B #0xe56cfc                |  goto label_7;                          
            goto label_7;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E56D28 (15035688), len: 1760  VirtAddr: 0x00E56D28 RVA: 0x00E56D28 token: 100663737 methodIndex: 19330 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.AssemblyDefinition GetCorlib(ILRuntime.Mono.Cecil.AssemblyNameReference reference, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Mono.Cecil.ReaderParameters val_35;
            //  | 
            var val_36;
            //  | 
            var val_37;
            //  | 
            var val_38;
            //  | 
            string val_39;
            //  | 
            var val_40;
            // 0x00E56D28: STP x26, x25, [sp, #-0x50]! | stack[1152921509463182800] = ???;  stack[1152921509463182808] = ???;  //  dest_result_addr=1152921509463182800 |  dest_result_addr=1152921509463182808
            // 0x00E56D2C: STP x24, x23, [sp, #0x10]  | stack[1152921509463182816] = ???;  stack[1152921509463182824] = ???;  //  dest_result_addr=1152921509463182816 |  dest_result_addr=1152921509463182824
            // 0x00E56D30: STP x22, x21, [sp, #0x20]  | stack[1152921509463182832] = ???;  stack[1152921509463182840] = ???;  //  dest_result_addr=1152921509463182832 |  dest_result_addr=1152921509463182840
            // 0x00E56D34: STP x20, x19, [sp, #0x30]  | stack[1152921509463182848] = ???;  stack[1152921509463182856] = ???;  //  dest_result_addr=1152921509463182848 |  dest_result_addr=1152921509463182856
            // 0x00E56D38: STP x29, x30, [sp, #0x40]  | stack[1152921509463182864] = ???;  stack[1152921509463182872] = ???;  //  dest_result_addr=1152921509463182864 |  dest_result_addr=1152921509463182872
            // 0x00E56D3C: ADD x29, sp, #0x40         | X29 = (1152921509463182800 + 64) = 1152921509463182864 (0x100000012175CE10);
            // 0x00E56D40: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E56D44: LDRB w8, [x22, #0xaca]     | W8 = (bool)static_value_03734ACA;       
            // 0x00E56D48: MOV x19, x2                | X19 = parameters;//m1                   
            val_35 = parameters;
            // 0x00E56D4C: MOV x21, x1                | X21 = reference;//m1                    
            // 0x00E56D50: MOV x20, x0                | X20 = 1152921509463194880 (0x100000012175FD00);//ML01
            val_36 = this;
            // 0x00E56D54: TBNZ w8, #0, #0xe56d70     | if (static_value_03734ACA == true) goto label_0;
            // 0x00E56D58: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E56D5C: LDR x8, [x8, #0x5b0]       | X8 = 0x2B8F000;                         
            // 0x00E56D60: LDR w0, [x8]               | W0 = 0x12C2;                            
            // 0x00E56D64: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C2, ????);     
            // 0x00E56D68: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E56D6C: STRB w8, [x22, #0xaca]     | static_value_03734ACA = true;            //  dest_result_addr=57887434
            label_0:
            // 0x00E56D70: CBNZ x21, #0xe56d78        | if (reference != null) goto label_1;    
            if(reference != null)
            {
                goto label_1;
            }
            // 0x00E56D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12C2, ????);     
            label_1:
            // 0x00E56D78: ADRP x23, #0x3620000       | X23 = 56754176 (0x3620000);             
            // 0x00E56D7C: LDR x23, [x23, #0x340]     | X23 = 1152921504609562624;              
            // 0x00E56D80: ADRP x25, #0x363f000       | X25 = 56881152 (0x363F000);             
            // 0x00E56D84: LDR x21, [x21, #0x20]      | X21 = reference.version; //P2           
            // 0x00E56D88: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x00E56D8C: LDR x25, [x25, #0xa88]     | X25 = 1152921504606900224;              
            // 0x00E56D90: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E56D94: LDR x22, [x25]             | X22 = typeof(System.Object);            
            // 0x00E56D98: TBZ w8, #0, #0xe56da8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00E56D9C: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E56DA0: CBNZ w8, #0xe56da8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00E56DA4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x00E56DA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56DAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56DB0: MOV x1, x22                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00E56DB4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E56DB8: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00E56DBC: CBNZ x22, #0xe56dc4        | if (val_1 != null) goto label_4;        
            if(val_1 != null)
            {
                goto label_4;
            }
            // 0x00E56DC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00E56DC4: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E56DC8: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x00E56DCC: LDP x9, x1, [x8, #0x1f0]   | X9 = typeof(System.Type).__il2cppRuntimeField_1F0; X1 = typeof(System.Type).__il2cppRuntimeField_1F8; //  | 
            // 0x00E56DD0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_1F0();
            // 0x00E56DD4: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00E56DD8: CBNZ x22, #0xe56de0        | if (val_1 != null) goto label_5;        
            if(val_1 != null)
            {
                goto label_5;
            }
            // 0x00E56DDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_5:
            // 0x00E56DE0: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E56DE4: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x00E56DE8: LDR x9, [x8, #0x230]       | X9 = typeof(System.Type).__il2cppRuntimeField_230;
            // 0x00E56DEC: LDR x1, [x8, #0x238]       | X1 = typeof(System.Type).__il2cppRuntimeField_238;
            // 0x00E56DF0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_230();
            // 0x00E56DF4: MOV x22, x0                | X22 = val_1;//m1                        
            // 0x00E56DF8: CBNZ x22, #0xe56e00        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00E56DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00E56E00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56E04: MOV x0, x22                | X0 = val_1;//m1                         
            // 0x00E56E08: BL #0x170bd18              | X0 = val_1.get_Version();               
            System.Version val_2 = val_1.Version;
            // 0x00E56E0C: MOV x1, x0                 | X1 = val_2;//m1                         
            // 0x00E56E10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56E14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E56E18: MOV x2, x21                | X2 = reference.version;//m1             
            // 0x00E56E1C: BL #0x273bd44              | X0 = System.Version.op_Equality(v1:  0, v2:  val_2);
            bool val_3 = System.Version.op_Equality(v1:  0, v2:  val_2);
            // 0x00E56E20: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            bool val_4 = val_3;
            // 0x00E56E24: TBNZ w8, #0, #0xe56e54     | if ((val_3 & 1) == true) goto label_7;  
            if(val_4 == true)
            {
                goto label_7;
            }
            // 0x00E56E28: ADRP x24, #0x3650000       | X24 = 56950784 (0x3650000);             
            // 0x00E56E2C: LDR x24, [x24, #0xbe8]     | X24 = 1152921504738156544;              
            // 0x00E56E30: LDR x0, [x24]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E56E34: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E56E38: TBZ w8, #0, #0xe56e48      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00E56E3C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E56E40: CBNZ w8, #0xe56e48         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00E56E44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_9:
            // 0x00E56E48: MOV x1, x21                | X1 = reference.version;//m1             
            // 0x00E56E4C: BL #0xe56ca0               | X0 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.IsZero(version:  null);
            bool val_5 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.IsZero(version:  null);
            // 0x00E56E50: TBZ w0, #0, #0xe56edc      | if (val_5 == false) goto label_10;      
            if(val_5 == false)
            {
                goto label_10;
            }
            label_7:
            // 0x00E56E54: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x00E56E58: LDR x21, [x25]             | X21 = typeof(System.Object);            
            // 0x00E56E5C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E56E60: TBZ w8, #0, #0xe56e70      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x00E56E64: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E56E68: CBNZ w8, #0xe56e70         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00E56E6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_12:
            // 0x00E56E70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56E74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56E78: MOV x1, x21                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00E56E7C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E56E80: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00E56E84: CBNZ x21, #0xe56e8c        | if (val_6 != null) goto label_13;       
            if(val_6 != null)
            {
                goto label_13;
            }
            // 0x00E56E88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_13:
            // 0x00E56E8C: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x00E56E90: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x00E56E94: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.Type).__il2cppRuntimeField_1B0; X1 = typeof(System.Type).__il2cppRuntimeField_1B8; //  | 
            // 0x00E56E98: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_1B0();
            // 0x00E56E9C: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x00E56EA0: CBNZ x21, #0xe56ea8        | if (val_6 != null) goto label_14;       
            if(val_6 != null)
            {
                goto label_14;
            }
            // 0x00E56EA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_14:
            // 0x00E56EA8: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x00E56EAC: MOV x0, x21                | X0 = val_6;//m1                         
            // 0x00E56EB0: LDP x9, x1, [x8, #0x180]   | X9 = typeof(System.Type).__il2cppRuntimeField_180; X1 = typeof(System.Type).__il2cppRuntimeField_188; //  | 
            // 0x00E56EB4: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_180();
            // 0x00E56EB8: MOV x1, x0                 | X1 = val_6;//m1                         
            // 0x00E56EBC: MOV x0, x20                | X0 = 1152921509463194880 (0x100000012175FD00);//ML01
            label_76:
            // 0x00E56EC0: MOV x2, x19                | X2 = parameters;//m1                    
            // 0x00E56EC4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E56EC8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E56ECC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E56ED0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E56ED4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E56ED8: B #0xe566ec                | return this.GetAssembly(file:  val_6, parameters:  val_35);
            return this.GetAssembly(file:  val_6, parameters:  val_35);
            label_10:
            // 0x00E56EDC: LDR x0, [x23]              | X0 = typeof(System.Type);               
            // 0x00E56EE0: LDR x22, [x25]             | X22 = typeof(System.Object);            
            // 0x00E56EE4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E56EE8: TBZ w8, #0, #0xe56ef8      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x00E56EEC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E56EF0: CBNZ w8, #0xe56ef8         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x00E56EF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_16:
            // 0x00E56EF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56EFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56F00: MOV x1, x22                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00E56F04: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E56F08: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00E56F0C: CBNZ x22, #0xe56f14        | if (val_7 != null) goto label_17;       
            if(val_7 != null)
            {
                goto label_17;
            }
            // 0x00E56F10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_17:
            // 0x00E56F14: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E56F18: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x00E56F1C: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.Type).__il2cppRuntimeField_1B0; X1 = typeof(System.Type).__il2cppRuntimeField_1B8; //  | 
            // 0x00E56F20: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_1B0();
            // 0x00E56F24: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00E56F28: CBNZ x22, #0xe56f30        | if (val_7 != null) goto label_18;       
            if(val_7 != null)
            {
                goto label_18;
            }
            // 0x00E56F2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_18:
            // 0x00E56F30: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x00E56F34: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x00E56F38: LDP x9, x1, [x8, #0x180]   | X9 = typeof(System.Type).__il2cppRuntimeField_180; X1 = typeof(System.Type).__il2cppRuntimeField_188; //  | 
            // 0x00E56F3C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_180();
            // 0x00E56F40: MOV x1, x0                 | X1 = val_7;//m1                         
            // 0x00E56F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56F48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56F4C: BL #0x1e6bd78              | X0 = System.IO.Directory.GetParent(path:  0);
            System.IO.DirectoryInfo val_8 = System.IO.Directory.GetParent(path:  0);
            // 0x00E56F50: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x00E56F54: CBNZ x22, #0xe56f5c        | if (val_8 != null) goto label_19;       
            if(val_8 != null)
            {
                goto label_19;
            }
            // 0x00E56F58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_19:
            // 0x00E56F5C: LDR x8, [x22]              | X8 = typeof(System.IO.DirectoryInfo);   
            // 0x00E56F60: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x00E56F64: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B0; X1 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B8; //  | 
            // 0x00E56F68: BLR x9                     | X0 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B0();
            // 0x00E56F6C: MOV x1, x0                 | X1 = val_8;//m1                         
            // 0x00E56F70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E56F74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E56F78: BL #0x1e6bd78              | X0 = System.IO.Directory.GetParent(path:  0);
            System.IO.DirectoryInfo val_9 = System.IO.Directory.GetParent(path:  0);
            // 0x00E56F7C: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00E56F80: CBNZ x22, #0xe56f88        | if (val_9 != null) goto label_20;       
            if(val_9 != null)
            {
                goto label_20;
            }
            // 0x00E56F84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_20:
            // 0x00E56F88: LDR x8, [x22]              | X8 = typeof(System.IO.DirectoryInfo);   
            // 0x00E56F8C: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x00E56F90: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B0; X1 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B8; //  | 
            // 0x00E56F94: BLR x9                     | X0 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B0();
            // 0x00E56F98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_37 = null;
            // 0x00E56F9C: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x00E56FA0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E56FA4: TBZ w9, #0, #0xe56fbc      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_22;
            // 0x00E56FA8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E56FAC: CBNZ w9, #0xe56fbc         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
            // 0x00E56FB0: MOV x0, x8                 | X0 = 1152921504738156544 (0x1000000007D3A000);//ML01
            // 0x00E56FB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            // 0x00E56FB8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_37 = null;
            label_22:
            // 0x00E56FBC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_static_fields;
            // 0x00E56FC0: LDRB w23, [x8]             | W23 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono;
            // 0x00E56FC4: CBNZ x21, #0xe56fcc        | if (reference.version != null) goto label_23;
            if(reference.version != null)
            {
                goto label_23;
            }
            // 0x00E56FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_23:
            // 0x00E56FCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E56FD0: MOV x0, x21                | X0 = reference.version;//m1             
            // 0x00E56FD4: BL #0x273b9a4              | X0 = reference.version.get_Major();     
            int val_10 = reference.version.Major;
            // 0x00E56FD8: CBZ w23, #0xe57010         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false) goto label_24;
            if(ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false)
            {
                goto label_24;
            }
            // 0x00E56FDC: CMP w0, #1                 | STATE = COMPARE(val_10, 0x1)            
            // 0x00E56FE0: B.NE #0xe5709c             | if (val_10 != 1) goto label_25;         
            if(val_10 != 1)
            {
                goto label_25;
            }
            // 0x00E56FE4: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E56FE8: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E56FEC: LDR x0, [x8]               | X0 = typeof(System.IO.Path);            
            // 0x00E56FF0: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E56FF4: TBZ w8, #0, #0xe57004      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_27;
            // 0x00E56FF8: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E56FFC: CBNZ w8, #0xe57004         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_27;
            // 0x00E57000: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_27:
            // 0x00E57004: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x00E57008: LDR x8, [x8, #0xf18]       | X8 = (string**)(1152921509463144272)("1.0");
            val_38 = "1.0";
            // 0x00E5700C: B #0xe57278                |  goto label_58;                         
            goto label_58;
            label_24:
            // 0x00E57010: SUB w8, w0, #1             | W8 = (val_10 - 1);                      
            int val_11 = val_10 - 1;
            // 0x00E57014: ADD w9, w0, #0x20          | W9 = (val_10 + 32);                     
            int val_12 = val_10 + 32;
            // 0x00E57018: CMP w8, #4                 | STATE = COMPARE((val_10 - 1), 0x4)      
            // 0x00E5701C: CSEL w8, w9, wzr, lo       | W8 = val_11 < 4 ? (val_10 + 32) : 0;    
            var val_13 = (val_11 < 4) ? (val_12) : 0;
            // 0x00E57020: SUB w9, w8, #0x21          | W9 = (val_11 < 4 ? (val_10 + 32) : 0 - 33);
            val_12 = val_13 - 33;
            // 0x00E57024: CMP w9, #3                 | STATE = COMPARE((val_11 < 4 ? (val_10 + 32) : 0 - 33), 0x3)
            // 0x00E57028: B.HI #0xe5716c             | if (val_12 > 0x3) goto label_29;        
            if(val_12 > 3)
            {
                goto label_29;
            }
            // 0x00E5702C: ADRP x8, #0x2a98000        | X8 = 44662784 (0x2A98000);              
            // 0x00E57030: ADD x8, x8, #0x3a0         | X8 = (44662784 + 928) = 44663712 (0x02A983A0);
            var val_35 = 44663712;
            // 0x00E57034: LDRSW x9, [x8, x9, lsl #2] | X9 = 44663712 + ((val_11 < 4 ? (val_10 + 32) : 0 - 33)) << 2;
            // 0x00E57038: ADD x8, x9, x8             | X8 = (44663712 + ((val_11 < 4 ? (val_10 + 32) : 0 - 33)) << 2 + 44663712);
            val_35 = (44663712 + ((val_11 < 4 ? (val_10 + 32) : 0 - 33)) << 2) + val_35;
            // 0x00E5703C: BR x8                      | goto (44663712 + ((val_11 < 4 ? (val_10 + 32) : 0 - 33)) << 2 + 44663712);
            goto (44663712 + ((val_11 < 4 ? (val_10 + 32) : 0 - 33)) << 2 + 44663712);
            // 0x00E57040: CBNZ x21, #0xe57048        | if (reference.version != null) goto label_30;
            if(reference.version != null)
            {
                goto label_30;
            }
            // 0x00E57044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_30:
            // 0x00E57048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E5704C: MOV x0, x21                | X0 = reference.version;//m1             
            // 0x00E57050: BL #0x273b9bc              | X0 = reference.version.get_MajorRevision();
            short val_14 = reference.version.MajorRevision;
            // 0x00E57054: ADRP x9, #0x3672000        | X9 = 57090048 (0x3672000);              
            // 0x00E57058: LDR x9, [x9, #0xc88]       | X9 = 1152921504622075904;               
            // 0x00E5705C: MOV w8, w0                 | W8 = val_14;//m1                        
            // 0x00E57060: AND w10, w8, #0xffff       | W10 = (val_14 & 65535);                 
            short val_15 = val_14 & 65535;
            // 0x00E57064: CMP w10, #0xce4            | STATE = COMPARE((val_14 & 65535), 0xCE4)
            // 0x00E57068: LDR x0, [x9]               | X0 = typeof(System.IO.Path);            
            // 0x00E5706C: ADD x9, x0, #0x109         | X9 = (null + 265) = 1152921504622076169 (0x1000000000E86109);
            // 0x00E57070: LDRH w9, [x9]              | W9 = System.IO.Path.__il2cppRuntimeField_109;
            // 0x00E57074: AND w8, w9, #0x100         | W8 = (System.IO.Path.__il2cppRuntimeField_109 & 256);
            // 0x00E57078: AND w8, w8, #0xffff        | W8 = ((System.IO.Path.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00E5707C: B.NE #0xe57260             | if (val_15 != 3300) goto label_31;      
            if(val_15 != 3300)
            {
                goto label_31;
            }
            // 0x00E57080: CBZ w8, #0xe57090          | if (((System.IO.Path.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_33;
            // 0x00E57084: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57088: CBNZ w8, #0xe57090         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x00E5708C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_33:
            // 0x00E57090: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x00E57094: LDR x8, [x8, #0x118]       | X8 = (string**)(1152921509463144352)("v1.0.3705");
            val_38 = "v1.0.3705";
            // 0x00E57098: B #0xe57278                |  goto label_58;                         
            goto label_58;
            label_25:
            // 0x00E5709C: CBZ x21, #0xe570b8         | if (reference.version == null) goto label_35;
            if(reference.version == null)
            {
                goto label_35;
            }
            // 0x00E570A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E570A4: MOV x0, x21                | X0 = reference.version;//m1             
            // 0x00E570A8: BL #0x273b9a4              | X0 = reference.version.get_Major();     
            int val_18 = reference.version.Major;
            // 0x00E570AC: CMP w0, #2                 | STATE = COMPARE(val_18, 0x2)            
            // 0x00E570B0: B.EQ #0xe570d8             | if (val_18 == 2) goto label_36;         
            if(val_18 == 2)
            {
                goto label_36;
            }
            // 0x00E570B4: B #0xe5712c                |  goto label_38;                         
            goto label_38;
            label_35:
            // 0x00E570B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            // 0x00E570BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E570C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E570C4: BL #0x273b9a4              | X0 = 0.get_Major();                     
            int val_19 = 0.Major;
            // 0x00E570C8: MOV w23, w0                | W23 = val_19;//m1                       
            // 0x00E570CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            // 0x00E570D0: CMP w23, #2                | STATE = COMPARE(val_19, 0x2)            
            // 0x00E570D4: B.NE #0xe5712c             | if (val_19 != 2) goto label_38;         
            if(val_19 != 2)
            {
                goto label_38;
            }
            label_36:
            // 0x00E570D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E570DC: MOV x0, x21                | X0 = reference.version;//m1             
            // 0x00E570E0: BL #0x273b9bc              | X0 = reference.version.get_MajorRevision();
            short val_20 = reference.version.MajorRevision;
            // 0x00E570E4: ADRP x9, #0x3672000        | X9 = 57090048 (0x3672000);              
            // 0x00E570E8: LDR x9, [x9, #0xc88]       | X9 = 1152921504622075904;               
            // 0x00E570EC: MOV w8, w0                 | W8 = val_20;//m1                        
            // 0x00E570F0: AND w10, w8, #0xffff       | W10 = (val_20 & 65535);                 
            short val_21 = val_20 & 65535;
            // 0x00E570F4: CMP w10, #5                | STATE = COMPARE((val_20 & 65535), 0x5)  
            // 0x00E570F8: LDR x0, [x9]               | X0 = typeof(System.IO.Path);            
            // 0x00E570FC: ADD x9, x0, #0x109         | X9 = (null + 265) = 1152921504622076169 (0x1000000000E86109);
            // 0x00E57100: LDRH w9, [x9]              | W9 = System.IO.Path.__il2cppRuntimeField_109;
            // 0x00E57104: AND w8, w9, #0x100         | W8 = (System.IO.Path.__il2cppRuntimeField_109 & 256);
            // 0x00E57108: AND w8, w8, #0xffff        | W8 = ((System.IO.Path.__il2cppRuntimeField_109 & 256) & 65535);
            // 0x00E5710C: B.NE #0xe57244             | if (val_21 != 5) goto label_39;         
            if(val_21 != 5)
            {
                goto label_39;
            }
            // 0x00E57110: CBZ w8, #0xe57120          | if (((System.IO.Path.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_41;
            // 0x00E57114: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57118: CBNZ w8, #0xe57120         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_41;
            // 0x00E5711C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_41:
            // 0x00E57120: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00E57124: LDR x8, [x8, #0xdb8]       | X8 = (string**)(1152921509463144448)("2.1");
            val_38 = "2.1";
            // 0x00E57128: B #0xe57278                |  goto label_58;                         
            goto label_58;
            label_38:
            // 0x00E5712C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57130: MOV x0, x21                | X0 = reference.version;//m1             
            // 0x00E57134: BL #0x273b9a4              | X0 = reference.version.get_Major();     
            int val_24 = reference.version.Major;
            // 0x00E57138: CMP w0, #4                 | STATE = COMPARE(val_24, 0x4)            
            // 0x00E5713C: B.NE #0xe57170             | if (val_24 != 4) goto label_43;         
            if(val_24 != 4)
            {
                goto label_43;
            }
            // 0x00E57140: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E57144: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E57148: LDR x0, [x8]               | X0 = typeof(System.IO.Path);            
            // 0x00E5714C: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57150: TBZ w8, #0, #0xe57160      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x00E57154: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57158: CBNZ w8, #0xe57160         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x00E5715C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_45:
            // 0x00E57160: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00E57164: LDR x8, [x8, #0x470]       | X8 = (string**)(1152921509463144528)("4.0");
            val_38 = "4.0";
            // 0x00E57168: B #0xe57278                |  goto label_58;                         
            goto label_58;
            label_29:
            // 0x00E5716C: CBNZ w8, #0xe573ec         | if (val_11 < 4 ? (val_10 + 32) : 0 != 0) goto label_75;
            if(val_13 != 0)
            {
                goto label_75;
            }
            label_43:
            // 0x00E57170: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E57174: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E57178: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00E5717C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E57180: TBZ w8, #0, #0xe57190      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_49;
            // 0x00E57184: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E57188: CBNZ w8, #0xe57190         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
            // 0x00E5718C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_49:
            // 0x00E57190: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x00E57194: LDR x8, [x8, #0x5d8]       | X8 = (string**)(1152921509463144608)("Version not supported: ");
            // 0x00E57198: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5719C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E571A0: MOV x2, x21                | X2 = reference.version;//m1             
            // 0x00E571A4: LDR x1, [x8]               | X1 = "Version not supported: ";         
            // 0x00E571A8: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "Version not supported: ");
            string val_25 = System.String.Concat(arg0:  0, arg1:  "Version not supported: ");
            // 0x00E571AC: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x00E571B0: LDR x8, [x8, #0x838]       | X8 = 1152921504655409152;               
            // 0x00E571B4: MOV x19, x0                | X19 = val_25;//m1                       
            val_35 = val_25;
            // 0x00E571B8: LDR x8, [x8]               | X8 = typeof(System.NotSupportedException);
            // 0x00E571BC: MOV x0, x8                 | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            System.NotSupportedException val_26 = null;
            // 0x00E571C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotSupportedException), ????);
            // 0x00E571C4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E571C8: MOV x1, x19                | X1 = val_25;//m1                        
            // 0x00E571CC: MOV x20, x0                | X20 = 1152921504655409152 (0x1000000002E50000);//ML01
            val_36 = val_26;
            // 0x00E571D0: BL #0x16f7cac              | .ctor(message:  val_35);                
            val_26 = new System.NotSupportedException(message:  val_35);
            // 0x00E571D4: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x00E571D8: LDR x8, [x8, #0x7c0]       | X8 = 1152921509463148832;               
            // 0x00E571DC: MOV x0, x20                | X0 = 1152921504655409152 (0x1000000002E50000);//ML01
            // 0x00E571E0: LDR x1, [x8]               | X1 = ILRuntime.Mono.Cecil.AssemblyDefinition ILRuntime.Mono.Cecil.BaseAssemblyResolver::GetCorlib(ILRuntime.Mono.Cecil.AssemblyNameReference reference, ILRuntime.Mono.Cecil.ReaderParameters parameters);
            // 0x00E571E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotSupportedException), ????);
            // 0x00E571E8: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.NotSupportedException), ????);
            // 0x00E571EC: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E571F0: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E571F4: LDR x0, [x8]               | X0 = typeof(System.IO.Path);            
            // 0x00E571F8: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E571FC: TBZ w8, #0, #0xe5720c      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_51;
            // 0x00E57200: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57204: CBNZ w8, #0xe5720c         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_51;
            // 0x00E57208: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_51:
            // 0x00E5720C: ADRP x8, #0x35d9000        | X8 = 56463360 (0x35D9000);              
            // 0x00E57210: LDR x8, [x8, #0x938]       | X8 = (string**)(1152921509463149856)("v2.0.50727");
            val_38 = "v2.0.50727";
            // 0x00E57214: B #0xe57278                |  goto label_58;                         
            goto label_58;
            // 0x00E57218: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E5721C: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E57220: LDR x0, [x8]               | X0 = typeof(System.IO.Path);            
            // 0x00E57224: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57228: TBZ w8, #0, #0xe57238      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_54;
            // 0x00E5722C: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57230: CBNZ w8, #0xe57238         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_54;
            // 0x00E57234: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_54:
            // 0x00E57238: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00E5723C: LDR x8, [x8, #0xf98]       | X8 = (string**)(1152921509463149952)("v4.0.30319");
            val_38 = "v4.0.30319";
            // 0x00E57240: B #0xe57278                |  goto label_58;                         
            goto label_58;
            label_39:
            // 0x00E57244: CBZ w8, #0xe57254          | if (((System.IO.Path.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_57;
            // 0x00E57248: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E5724C: CBNZ w8, #0xe57254         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
            // 0x00E57250: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_57:
            // 0x00E57254: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x00E57258: LDR x8, [x8, #0xc60]       | X8 = (string**)(1152921509463150048)("2.0");
            val_38 = "2.0";
            // 0x00E5725C: B #0xe57278                |  goto label_58;                         
            goto label_58;
            label_31:
            // 0x00E57260: CBZ w8, #0xe57270          | if (((System.IO.Path.__il2cppRuntimeField_109 & 256) & 65535) == 0) goto label_60;
            // 0x00E57264: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57268: CBNZ w8, #0xe57270         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x00E5726C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_60:
            // 0x00E57270: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x00E57274: LDR x8, [x8, #0xc0]        | X8 = (string**)(1152921509463150128)("v1.0.5000.0");
            val_38 = "v1.0.5000.0";
            label_58:
            // 0x00E57278: LDR x2, [x8]               | X2 = "v1.0.5000.0";                     
            // 0x00E5727C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57280: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57284: MOV x1, x22                | X1 = val_9;//m1                         
            // 0x00E57288: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_9);
            string val_27 = System.IO.Path.Combine(path1:  0, path2:  val_9);
            // 0x00E5728C: ADRP x23, #0x3672000       | X23 = 57090048 (0x3672000);             
            // 0x00E57290: LDR x23, [x23, #0xc88]     | X23 = 1152921504622075904;              
            // 0x00E57294: MOV x21, x0                | X21 = val_27;//m1                       
            val_39 = val_27;
            // 0x00E57298: LDR x0, [x23]              | X0 = typeof(System.IO.Path);            
            // 0x00E5729C: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E572A0: TBZ w8, #0, #0xe572b0      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_62;
            // 0x00E572A4: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E572A8: CBNZ w8, #0xe572b0         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_62;
            // 0x00E572AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_62:
            // 0x00E572B0: ADRP x25, #0x360f000       | X25 = 56684544 (0x360F000);             
            // 0x00E572B4: LDR x25, [x25, #0x658]     | X25 = (string**)(1152921509463154320)("mscorlib.dll");
            // 0x00E572B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E572BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E572C0: MOV x1, x21                | X1 = val_27;//m1                        
            // 0x00E572C4: LDR x2, [x25]              | X2 = "mscorlib.dll";                    
            // 0x00E572C8: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_39);
            string val_28 = System.IO.Path.Combine(path1:  0, path2:  val_39);
            // 0x00E572CC: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x00E572D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E572D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E572D8: MOV x1, x22                | X1 = val_28;//m1                        
            // 0x00E572DC: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_29 = System.IO.File.Exists(path:  0);
            // 0x00E572E0: TBZ w0, #0, #0xe572f0      | if (val_29 == false) goto label_63;     
            if(val_29 == false)
            {
                goto label_63;
            }
            // 0x00E572E4: MOV x0, x20                | X0 = 1152921509463194880 (0x100000012175FD00);//ML01
            // 0x00E572E8: MOV x1, x22                | X1 = val_28;//m1                        
            // 0x00E572EC: B #0xe56ec0                |  goto label_76;                         
            goto label_76;
            label_63:
            // 0x00E572F0: LDR x0, [x24]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_40 = null;
            // 0x00E572F4: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E572F8: TBZ w8, #0, #0xe5730c      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_66;
            // 0x00E572FC: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E57300: CBNZ w8, #0xe5730c         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_66;
            // 0x00E57304: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            // 0x00E57308: LDR x0, [x24]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_40 = null;
            label_66:
            // 0x00E5730C: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_static_fields;
            // 0x00E57310: LDRB w8, [x8]              | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono;
            // 0x00E57314: CBZ w8, #0xe573ec          | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false) goto label_75;
            if(ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false)
            {
                goto label_75;
            }
            // 0x00E57318: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
            // 0x00E5731C: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
            // 0x00E57320: LDR x0, [x22]              | X0 = typeof(System.String);             
            // 0x00E57324: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E57328: TBZ w8, #0, #0xe57338      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_69;
            // 0x00E5732C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E57330: CBNZ w8, #0xe57338         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
            // 0x00E57334: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_69:
            // 0x00E57338: ADRP x24, #0x35e7000       | X24 = 56520704 (0x35E7000);             
            // 0x00E5733C: LDR x24, [x24, #0x4d8]     | X24 = (string**)(1152921509463158512)("-api");
            // 0x00E57340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57344: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57348: MOV x1, x21                | X1 = val_27;//m1                        
            // 0x00E5734C: LDR x2, [x24]              | X2 = "-api";                            
            // 0x00E57350: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_39);
            string val_30 = System.String.Concat(str0:  0, str1:  val_39);
            // 0x00E57354: MOV x1, x0                 | X1 = val_30;//m1                        
            // 0x00E57358: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5735C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57360: BL #0x1e6aa78              | X0 = System.IO.Directory.Exists(path:  0);
            bool val_31 = System.IO.Directory.Exists(path:  0);
            // 0x00E57364: TBZ w0, #0, #0xe573ec      | if (val_31 == false) goto label_75;     
            if(val_31 == false)
            {
                goto label_75;
            }
            // 0x00E57368: LDR x0, [x22]              | X0 = typeof(System.String);             
            // 0x00E5736C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E57370: TBZ w8, #0, #0xe57380      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_72;
            // 0x00E57374: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E57378: CBNZ w8, #0xe57380         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x00E5737C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_72:
            // 0x00E57380: LDR x2, [x24]              | X2 = "-api";                            
            // 0x00E57384: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57388: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5738C: MOV x1, x21                | X1 = val_27;//m1                        
            // 0x00E57390: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  val_39);
            string val_32 = System.String.Concat(str0:  0, str1:  val_39);
            // 0x00E57394: LDR x8, [x23]              | X8 = typeof(System.IO.Path);            
            // 0x00E57398: MOV x21, x0                | X21 = val_32;//m1                       
            // 0x00E5739C: LDRB w9, [x8, #0x10a]      | W9 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E573A0: TBZ w9, #0, #0xe573b4      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_74;
            // 0x00E573A4: LDR w9, [x8, #0xbc]        | W9 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E573A8: CBNZ w9, #0xe573b4         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_74;
            // 0x00E573AC: MOV x0, x8                 | X0 = 1152921504622075904 (0x1000000000E86000);//ML01
            // 0x00E573B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_74:
            // 0x00E573B4: LDR x2, [x25]              | X2 = "mscorlib.dll";                    
            // 0x00E573B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E573BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E573C0: MOV x1, x21                | X1 = val_32;//m1                        
            // 0x00E573C4: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_32);
            string val_33 = System.IO.Path.Combine(path1:  0, path2:  val_32);
            // 0x00E573C8: MOV x21, x0                | X21 = val_33;//m1                       
            val_39 = val_33;
            // 0x00E573CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E573D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E573D4: MOV x1, x21                | X1 = val_33;//m1                        
            // 0x00E573D8: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_34 = System.IO.File.Exists(path:  0);
            // 0x00E573DC: TBZ w0, #0, #0xe573ec      | if (val_34 == false) goto label_75;     
            if(val_34 == false)
            {
                goto label_75;
            }
            // 0x00E573E0: MOV x0, x20                | X0 = 1152921509463194880 (0x100000012175FD00);//ML01
            // 0x00E573E4: MOV x1, x21                | X1 = val_33;//m1                        
            // 0x00E573E8: B #0xe56ec0                |  goto label_76;                         
            goto label_76;
            label_75:
            // 0x00E573EC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E573F0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E573F4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E573F8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E573FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57400: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E57404: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyDefinition)null;
            return (ILRuntime.Mono.Cecil.AssemblyDefinition)0;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyDefinition, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E57A30 (15039024), len: 412  VirtAddr: 0x00E57A30 RVA: 0x00E57A30 token: 100663738 methodIndex: 19331 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Mono.Collections.Generic.Collection<string> GetGacPaths()
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            // 0x00E57A30: STP x24, x23, [sp, #-0x40]! | stack[1152921509463372912] = ???;  stack[1152921509463372920] = ???;  //  dest_result_addr=1152921509463372912 |  dest_result_addr=1152921509463372920
            // 0x00E57A34: STP x22, x21, [sp, #0x10]  | stack[1152921509463372928] = ???;  stack[1152921509463372936] = ???;  //  dest_result_addr=1152921509463372928 |  dest_result_addr=1152921509463372936
            // 0x00E57A38: STP x20, x19, [sp, #0x20]  | stack[1152921509463372944] = ???;  stack[1152921509463372952] = ???;  //  dest_result_addr=1152921509463372944 |  dest_result_addr=1152921509463372952
            // 0x00E57A3C: STP x29, x30, [sp, #0x30]  | stack[1152921509463372960] = ???;  stack[1152921509463372968] = ???;  //  dest_result_addr=1152921509463372960 |  dest_result_addr=1152921509463372968
            // 0x00E57A40: ADD x29, sp, #0x30         | X29 = (1152921509463372912 + 48) = 1152921509463372960 (0x100000012178B4A0);
            // 0x00E57A44: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E57A48: LDRB w8, [x19, #0xacb]     | W8 = (bool)static_value_03734ACB;       
            // 0x00E57A4C: TBNZ w8, #0, #0xe57a68     | if (static_value_03734ACB == true) goto label_0;
            // 0x00E57A50: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x00E57A54: LDR x8, [x8, #0xcf8]       | X8 = 0x2B8F00C;                         
            // 0x00E57A58: LDR w0, [x8]               | W0 = 0x12C5;                            
            // 0x00E57A5C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C5, ????);     
            // 0x00E57A60: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E57A64: STRB w8, [x19, #0xacb]     | static_value_03734ACB = true;            //  dest_result_addr=57887435
            label_0:
            // 0x00E57A68: ADRP x19, #0x3650000       | X19 = 56950784 (0x3650000);             
            // 0x00E57A6C: LDR x19, [x19, #0xbe8]     | X19 = 1152921504738156544;              
            // 0x00E57A70: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_6 = null;
            // 0x00E57A74: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E57A78: TBZ w8, #0, #0xe57a8c      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E57A7C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E57A80: CBNZ w8, #0xe57a8c         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E57A84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            // 0x00E57A88: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_6 = null;
            label_2:
            // 0x00E57A8C: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_static_fields;
            // 0x00E57A90: LDRB w8, [x8]              | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono;
            // 0x00E57A94: CBZ w8, #0xe57ac0          | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false) goto label_3;
            if(ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false)
            {
                goto label_3;
            }
            // 0x00E57A98: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E57A9C: TBZ w8, #0, #0xe57aac      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00E57AA0: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E57AA4: CBNZ w8, #0xe57aac         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00E57AA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_5:
            // 0x00E57AAC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E57AB0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E57AB4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E57AB8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E57ABC: B #0xe57bcc                | return ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetDefaultMonoGacPaths();
            return ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetDefaultMonoGacPaths();
            label_3:
            // 0x00E57AC0: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00E57AC4: LDR x8, [x8, #0xcb0]       | X8 = 1152921504736985088;               
            // 0x00E57AC8: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            ILRuntime.Mono.Collections.Generic.Collection<System.String> val_1 = null;
            // 0x00E57ACC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            // 0x00E57AD0: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00E57AD4: LDR x8, [x8, #0xa60]       | X8 = 1152921509462235312;               
            // 0x00E57AD8: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00E57ADC: MOV x19, x0                | X19 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57AE0: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::.ctor(int capacity);
            // 0x00E57AE4: BL #0x1d47070              | .ctor(capacity:  2);                    
            val_1 = new ILRuntime.Mono.Collections.Generic.Collection<System.String>(capacity:  2);
            // 0x00E57AE8: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x00E57AEC: LDR x8, [x8, #0x7d8]       | X8 = (string**)(1152921509463344320)("WINDIR");
            // 0x00E57AF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57AF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57AF8: LDR x1, [x8]               | X1 = "WINDIR";                          
            // 0x00E57AFC: BL #0x1c3d608              | X0 = System.Environment.GetEnvironmentVariable(variable:  0);
            string val_2 = System.Environment.GetEnvironmentVariable(variable:  0);
            // 0x00E57B00: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00E57B04: CBZ x20, #0xe57bb4         | if (val_2 == null) goto label_6;        
            if(val_2 == null)
            {
                goto label_6;
            }
            // 0x00E57B08: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E57B0C: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E57B10: LDR x0, [x8]               | X0 = typeof(System.IO.Path);            
            // 0x00E57B14: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57B18: TBZ w8, #0, #0xe57b28      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E57B1C: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57B20: CBNZ w8, #0xe57b28         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E57B24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_8:
            // 0x00E57B28: ADRP x23, #0x365b000       | X23 = 56995840 (0x365B000);             
            // 0x00E57B2C: LDR x23, [x23, #0x980]     | X23 = (string**)(1152921509463348496)("assembly");
            // 0x00E57B30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57B34: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57B38: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00E57B3C: LDR x2, [x23]              | X2 = "assembly";                        
            // 0x00E57B40: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_2);
            string val_3 = System.IO.Path.Combine(path1:  0, path2:  val_2);
            // 0x00E57B44: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00E57B48: CBNZ x19, #0xe57b50        | if ( != 0) goto label_9;                
            if(null != 0)
            {
                goto label_9;
            }
            // 0x00E57B4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_9:
            // 0x00E57B50: ADRP x22, #0x35c1000       | X22 = 56365056 (0x35C1000);             
            // 0x00E57B54: LDR x22, [x22, #0x908]     | X22 = 1152921509462236336;              
            // 0x00E57B58: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57B5C: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00E57B60: LDR x2, [x22]              | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E57B64: BL #0x1d47324              | Add(item:  val_3);                      
            Add(item:  val_3);
            // 0x00E57B68: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
            // 0x00E57B6C: LDR x8, [x8, #0x380]       | X8 = (string**)(1152921509463352688)("Microsoft.NET");
            // 0x00E57B70: LDR x2, [x23]              | X2 = "assembly";                        
            // 0x00E57B74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57B78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57B7C: LDR x1, [x8]               | X1 = "Microsoft.NET";                   
            // 0x00E57B80: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  "Microsoft.NET");
            string val_4 = System.IO.Path.Combine(path1:  0, path2:  "Microsoft.NET");
            // 0x00E57B84: MOV x2, x0                 | X2 = val_4;//m1                         
            // 0x00E57B88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57B8C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57B90: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00E57B94: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_2);
            string val_5 = System.IO.Path.Combine(path1:  0, path2:  val_2);
            // 0x00E57B98: MOV x20, x0                | X20 = val_5;//m1                        
            // 0x00E57B9C: CBNZ x19, #0xe57ba4        | if ( != 0) goto label_10;               
            if(null != 0)
            {
                goto label_10;
            }
            // 0x00E57BA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_10:
            // 0x00E57BA4: LDR x2, [x22]              | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E57BA8: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57BAC: MOV x1, x20                | X1 = val_5;//m1                         
            // 0x00E57BB0: BL #0x1d47324              | Add(item:  val_5);                      
            Add(item:  val_5);
            label_6:
            // 0x00E57BB4: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57BB8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E57BBC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E57BC0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E57BC4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E57BC8: RET                        |  return (ILRuntime.Mono.Collections.Generic.Collection<System.String>)typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            return (ILRuntime.Mono.Collections.Generic.Collection<System.String>)val_1;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Collections.Generic.Collection<System.String>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E57BCC (15039436), len: 764  VirtAddr: 0x00E57BCC RVA: 0x00E57BCC token: 100663739 methodIndex: 19332 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Mono.Collections.Generic.Collection<string> GetDefaultMonoGacPaths()
        {
            //
            // Disasemble & Code
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00E57BCC: STP x28, x27, [sp, #-0x60]! | stack[1152921509463564080] = ???;  stack[1152921509463564088] = ???;  //  dest_result_addr=1152921509463564080 |  dest_result_addr=1152921509463564088
            // 0x00E57BD0: STP x26, x25, [sp, #0x10]  | stack[1152921509463564096] = ???;  stack[1152921509463564104] = ???;  //  dest_result_addr=1152921509463564096 |  dest_result_addr=1152921509463564104
            // 0x00E57BD4: STP x24, x23, [sp, #0x20]  | stack[1152921509463564112] = ???;  stack[1152921509463564120] = ???;  //  dest_result_addr=1152921509463564112 |  dest_result_addr=1152921509463564120
            // 0x00E57BD8: STP x22, x21, [sp, #0x30]  | stack[1152921509463564128] = ???;  stack[1152921509463564136] = ???;  //  dest_result_addr=1152921509463564128 |  dest_result_addr=1152921509463564136
            // 0x00E57BDC: STP x20, x19, [sp, #0x40]  | stack[1152921509463564144] = ???;  stack[1152921509463564152] = ???;  //  dest_result_addr=1152921509463564144 |  dest_result_addr=1152921509463564152
            // 0x00E57BE0: STP x29, x30, [sp, #0x50]  | stack[1152921509463564160] = ???;  stack[1152921509463564168] = ???;  //  dest_result_addr=1152921509463564160 |  dest_result_addr=1152921509463564168
            // 0x00E57BE4: ADD x29, sp, #0x50         | X29 = (1152921509463564080 + 80) = 1152921509463564160 (0x10000001217B9F80);
            // 0x00E57BE8: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E57BEC: LDRB w8, [x19, #0xacc]     | W8 = (bool)static_value_03734ACC;       
            // 0x00E57BF0: TBNZ w8, #0, #0xe57c0c     | if (static_value_03734ACC == true) goto label_0;
            // 0x00E57BF4: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x00E57BF8: LDR x8, [x8, #0x78]        | X8 = 0x2B8F008;                         
            // 0x00E57BFC: LDR w0, [x8]               | W0 = 0x12C4;                            
            // 0x00E57C00: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C4, ????);     
            // 0x00E57C04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E57C08: STRB w8, [x19, #0xacc]     | static_value_03734ACC = true;            //  dest_result_addr=57887436
            label_0:
            // 0x00E57C0C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00E57C10: LDR x8, [x8, #0xcb0]       | X8 = 1152921504736985088;               
            // 0x00E57C14: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            ILRuntime.Mono.Collections.Generic.Collection<System.String> val_1 = null;
            // 0x00E57C18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), ????);
            // 0x00E57C1C: ADRP x8, #0x3600000        | X8 = 56623104 (0x3600000);              
            // 0x00E57C20: LDR x8, [x8, #0xa60]       | X8 = 1152921509462235312;               
            // 0x00E57C24: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E57C28: MOV x19, x0                | X19 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57C2C: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::.ctor(int capacity);
            // 0x00E57C30: BL #0x1d47070              | .ctor(capacity:  1);                    
            val_1 = new ILRuntime.Mono.Collections.Generic.Collection<System.String>(capacity:  1);
            // 0x00E57C34: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00E57C38: LDR x8, [x8, #0xbe8]       | X8 = 1152921504738156544;               
            // 0x00E57C3C: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E57C40: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E57C44: TBZ w8, #0, #0xe57c54      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E57C48: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E57C4C: CBNZ w8, #0xe57c54         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E57C50: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_2:
            // 0x00E57C54: BL #0xe57ec8               | X0 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetCurrentMonoGac();
            string val_2 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetCurrentMonoGac();
            // 0x00E57C58: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00E57C5C: CBZ x20, #0xe57c80         | if (val_2 == null) goto label_3;        
            if(val_2 == null)
            {
                goto label_3;
            }
            // 0x00E57C60: CBNZ x19, #0xe57c68        | if ( != 0) goto label_4;                
            if(null != 0)
            {
                goto label_4;
            }
            // 0x00E57C64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x00E57C68: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00E57C6C: LDR x8, [x8, #0x908]       | X8 = 1152921509462236336;               
            // 0x00E57C70: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57C74: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00E57C78: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E57C7C: BL #0x1d47324              | Add(item:  val_2);                      
            Add(item:  val_2);
            label_3:
            // 0x00E57C80: ADRP x8, #0x3670000        | X8 = 57081856 (0x3670000);              
            // 0x00E57C84: LDR x8, [x8, #0xb0]        | X8 = (string**)(1152921509463493456)("MONO_GAC_PREFIX");
            // 0x00E57C88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57C8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57C90: LDR x1, [x8]               | X1 = "MONO_GAC_PREFIX";                 
            // 0x00E57C94: BL #0x1c3d608              | X0 = System.Environment.GetEnvironmentVariable(variable:  0);
            string val_3 = System.Environment.GetEnvironmentVariable(variable:  0);
            // 0x00E57C98: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
            // 0x00E57C9C: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
            // 0x00E57CA0: MOV x21, x0                | X21 = val_3;//m1                        
            val_15 = val_3;
            // 0x00E57CA4: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x00E57CA8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E57CAC: TBZ w9, #0, #0xe57cc0      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00E57CB0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E57CB4: CBNZ w9, #0xe57cc0         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00E57CB8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E57CBC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_6:
            // 0x00E57CC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57CC4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57CC8: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x00E57CCC: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
            bool val_4 = System.String.IsNullOrEmpty(value:  0);
            // 0x00E57CD0: AND w8, w0, #1             | W8 = (val_4 & 1);                       
            bool val_5 = val_4;
            // 0x00E57CD4: TBNZ w8, #0, #0xe57ea8     | if ((val_4 & 1) == true) goto label_15; 
            if(val_5 == true)
            {
                goto label_15;
            }
            // 0x00E57CD8: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x00E57CDC: LDR x8, [x8, #0xd58]       | X8 = 1152921504947213072;               
            // 0x00E57CE0: LDR x22, [x8]              | X22 = typeof(System.Char[]);            
            // 0x00E57CE4: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E57CE8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Char[]), ????);
            // 0x00E57CEC: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E57CF0: MOV x0, x22                | X0 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E57CF4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Char[]), ????);
            // 0x00E57CF8: ADRP x24, #0x3672000       | X24 = 57090048 (0x3672000);             
            // 0x00E57CFC: LDR x24, [x24, #0xc88]     | X24 = 1152921504622075904;              
            // 0x00E57D00: MOV x22, x0                | X22 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E57D04: LDR x8, [x24]              | X8 = typeof(System.IO.Path);            
            val_16 = null;
            // 0x00E57D08: LDRB w9, [x8, #0x10a]      | W9 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57D0C: TBZ w9, #0, #0xe57d24      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00E57D10: LDR w9, [x8, #0xbc]        | W9 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57D14: CBNZ w9, #0xe57d24         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00E57D18: MOV x0, x8                 | X0 = 1152921504622075904 (0x1000000000E86000);//ML01
            // 0x00E57D1C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            // 0x00E57D20: LDR x8, [x24]              | X8 = typeof(System.IO.Path);            
            val_16 = null;
            label_9:
            // 0x00E57D24: LDR x8, [x8, #0xa0]        | X8 = System.IO.Path.__il2cppRuntimeField_static_fields;
            // 0x00E57D28: LDRH w25, [x8, #0xc]       | W25 = System.IO.Path.PathSeparator;     
            // 0x00E57D2C: CBNZ x22, #0xe57d34        | if ( != null) goto label_10;            
            if(null != null)
            {
                goto label_10;
            }
            // 0x00E57D30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.Path), ????);
            label_10:
            // 0x00E57D34: LDR w8, [x22, #0x18]       | W8 = System.Char[].__il2cppRuntimeField_namespaze;
            // 0x00E57D38: CBNZ w8, #0xe57d48         | if (System.Char[].__il2cppRuntimeField_namespaze != 0) goto label_11;
            // 0x00E57D3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(System.IO.Path), ????);
            // 0x00E57D40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57D44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.IO.Path), ????);
            label_11:
            // 0x00E57D48: STRH w25, [x22, #0x20]     | typeof(System.Char[]).__il2cppRuntimeField_20 = System.IO.Path.PathSeparator;  //  dest_result_addr=1152921504947213104
            typeof(System.Char[]).__il2cppRuntimeField_20 = System.IO.Path.PathSeparator;
            // 0x00E57D4C: CBNZ x21, #0xe57d54        | if (val_3 != null) goto label_12;       
            if(val_15 != null)
            {
                goto label_12;
            }
            // 0x00E57D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.IO.Path), ????);
            label_12:
            // 0x00E57D54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57D58: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x00E57D5C: MOV x1, x22                | X1 = 1152921504947213072 (0x1000000014499310);//ML01
            // 0x00E57D60: BL #0x18a881c              | X0 = val_3.Split(separator:  null);     
            System.String[] val_6 = val_15.Split(separator:  null);
            // 0x00E57D64: ADRP x26, #0x3614000       | X26 = 56705024 (0x3614000);             
            // 0x00E57D68: ADRP x27, #0x3630000       | X27 = 56819712 (0x3630000);             
            // 0x00E57D6C: ADRP x28, #0x3653000       | X28 = 56963072 (0x3653000);             
            // 0x00E57D70: LDR x26, [x26, #0xf8]      | X26 = (string**)(1152921509463534528)("lib");
            // 0x00E57D74: LDR x27, [x27, #0xfa8]     | X27 = (string**)(1152921509463534608)("mono");
            // 0x00E57D78: LDR x28, [x28, #0xaa8]     | X28 = (string**)(1152921509463534688)("gac");
            // 0x00E57D7C: MOV x21, x0                | X21 = val_6;//m1                        
            val_15 = val_6;
            // 0x00E57D80: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x00E57D84: B #0xe57d8c                |  goto label_13;                         
            goto label_13;
            label_26:
            // 0x00E57D88: ADD w25, w25, #1           | W25 = (val_17 + 1) = val_17 (0x00000001);
            val_17 = 1;
            label_13:
            // 0x00E57D8C: CBNZ x21, #0xe57d94        | if (val_6 != null) goto label_14;       
            if(val_15 != null)
            {
                goto label_14;
            }
            // 0x00E57D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_14:
            // 0x00E57D94: LDR w8, [x21, #0x18]       | W8 = val_6.Length; //P2                 
            // 0x00E57D98: CMP w25, w8                | STATE = COMPARE(0x1, val_6.Length)      
            // 0x00E57D9C: B.GE #0xe57ea8             | if (val_17 >= val_6.Length) goto label_15;
            if(val_17 >= val_6.Length)
            {
                goto label_15;
            }
            // 0x00E57DA0: SXTW x22, w25              | X22 = 1 (0x00000001);                   
            // 0x00E57DA4: CMP w25, w8                | STATE = COMPARE(0x1, val_6.Length)      
            // 0x00E57DA8: B.LO #0xe57db8             | if (val_17 < val_6.Length) goto label_16;
            if(val_17 < val_6.Length)
            {
                goto label_16;
            }
            // 0x00E57DAC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x00E57DB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E57DB4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_16:
            // 0x00E57DB8: LDR x0, [x23]              | X0 = typeof(System.String);             
            // 0x00E57DBC: ADD x8, x21, x22, lsl #3   | X8 = val_6[0x1]; //PARR1                
            // 0x00E57DC0: LDR x22, [x8, #0x20]       | X22 = val_6[0x1][0]                     
            string val_15 = val_15[1];
            // 0x00E57DC4: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E57DC8: TBZ w8, #0, #0xe57dd8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x00E57DCC: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E57DD0: CBNZ w8, #0xe57dd8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x00E57DD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_18:
            // 0x00E57DD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57DDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57DE0: MOV x1, x22                | X1 = val_6[0x1][0];//m1                 
            // 0x00E57DE4: BL #0x18ad448              | X0 = System.String.IsNullOrEmpty(value:  0);
            bool val_7 = System.String.IsNullOrEmpty(value:  0);
            // 0x00E57DE8: AND w8, w0, #1             | W8 = (val_7 & 1);                       
            bool val_8 = val_7;
            // 0x00E57DEC: TBNZ w8, #0, #0xe57d88     | if ((val_7 & 1) == true) goto label_26; 
            if(val_8 == true)
            {
                goto label_26;
            }
            // 0x00E57DF0: LDR x0, [x24]              | X0 = typeof(System.IO.Path);            
            // 0x00E57DF4: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57DF8: TBZ w8, #0, #0xe57e08      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_21;
            // 0x00E57DFC: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57E00: CBNZ w8, #0xe57e08         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_21;
            // 0x00E57E04: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_21:
            // 0x00E57E08: LDR x2, [x26]              | X2 = "lib";                             
            // 0x00E57E0C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57E10: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57E14: MOV x1, x22                | X1 = val_6[0x1][0];//m1                 
            // 0x00E57E18: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_15[1]);
            string val_9 = System.IO.Path.Combine(path1:  0, path2:  val_15);
            // 0x00E57E1C: LDR x2, [x27]              | X2 = "mono";                            
            // 0x00E57E20: MOV x1, x0                 | X1 = val_9;//m1                         
            // 0x00E57E24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57E28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57E2C: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_9);
            string val_10 = System.IO.Path.Combine(path1:  0, path2:  val_9);
            // 0x00E57E30: LDR x2, [x28]              | X2 = "gac";                             
            // 0x00E57E34: MOV x1, x0                 | X1 = val_10;//m1                        
            // 0x00E57E38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57E3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57E40: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_10);
            string val_11 = System.IO.Path.Combine(path1:  0, path2:  val_10);
            // 0x00E57E44: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x00E57E48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57E4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57E50: MOV x1, x22                | X1 = val_11;//m1                        
            // 0x00E57E54: BL #0x1e6aa78              | X0 = System.IO.Directory.Exists(path:  0);
            bool val_12 = System.IO.Directory.Exists(path:  0);
            // 0x00E57E58: TBZ w0, #0, #0xe57d88      | if (val_12 == false) goto label_26;     
            if(val_12 == false)
            {
                goto label_26;
            }
            // 0x00E57E5C: CBNZ x19, #0xe57e64        | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x00E57E60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            label_23:
            // 0x00E57E64: ADRP x8, #0x3655000        | X8 = 56971264 (0x3655000);              
            // 0x00E57E68: LDR x8, [x8, #0x608]       | X8 = 1152921509463551152;               
            // 0x00E57E6C: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57E70: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00E57E74: LDR x2, [x8]               | X2 = public System.Boolean ILRuntime.Mono.Collections.Generic.Collection<System.String>::Contains(System.String item);
            // 0x00E57E78: BL #0x1d473fc              | X0 = Contains(item:  val_2);            
            bool val_13 = Contains(item:  val_2);
            // 0x00E57E7C: AND w8, w0, #1             | W8 = (val_13 & 1);                      
            bool val_14 = val_13;
            // 0x00E57E80: TBNZ w8, #0, #0xe57d88     | if ((val_13 & 1) == true) goto label_26;
            if(val_14 == true)
            {
                goto label_26;
            }
            // 0x00E57E84: CBNZ x19, #0xe57e8c        | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x00E57E88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_25:
            // 0x00E57E8C: ADRP x8, #0x35c1000        | X8 = 56365056 (0x35C1000);              
            // 0x00E57E90: LDR x8, [x8, #0x908]       | X8 = 1152921509462236336;               
            // 0x00E57E94: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57E98: MOV x1, x22                | X1 = val_11;//m1                        
            // 0x00E57E9C: LDR x2, [x8]               | X2 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.String>::Add(System.String item);
            // 0x00E57EA0: BL #0x1d47324              | Add(item:  val_11);                     
            Add(item:  val_11);
            // 0x00E57EA4: B #0xe57d88                |  goto label_26;                         
            goto label_26;
            label_15:
            // 0x00E57EA8: MOV x0, x19                | X0 = 1152921504736985088 (0x1000000007C1C000);//ML01
            // 0x00E57EAC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E57EB0: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E57EB4: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E57EB8: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E57EBC: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E57EC0: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E57EC4: RET                        |  return (ILRuntime.Mono.Collections.Generic.Collection<System.String>)typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            return (ILRuntime.Mono.Collections.Generic.Collection<System.String>)val_1;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Collections.Generic.Collection<System.String>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E57EC8 (15040200), len: 300  VirtAddr: 0x00E57EC8 RVA: 0x00E57EC8 token: 100663740 methodIndex: 19333 delegateWrapperIndex: 0 methodInvoker: 0
        private static string GetCurrentMonoGac()
        {
            //
            // Disasemble & Code
            // 0x00E57EC8: STP x20, x19, [sp, #-0x20]! | stack[1152921509463749872] = ???;  stack[1152921509463749880] = ???;  //  dest_result_addr=1152921509463749872 |  dest_result_addr=1152921509463749880
            // 0x00E57ECC: STP x29, x30, [sp, #0x10]  | stack[1152921509463749888] = ???;  stack[1152921509463749896] = ???;  //  dest_result_addr=1152921509463749888 |  dest_result_addr=1152921509463749896
            // 0x00E57ED0: ADD x29, sp, #0x10         | X29 = (1152921509463749872 + 16) = 1152921509463749888 (0x10000001217E7500);
            // 0x00E57ED4: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E57ED8: LDRB w8, [x19, #0xacd]     | W8 = (bool)static_value_03734ACD;       
            // 0x00E57EDC: TBNZ w8, #0, #0xe57ef8     | if (static_value_03734ACD == true) goto label_0;
            // 0x00E57EE0: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x00E57EE4: LDR x8, [x8, #0x948]       | X8 = 0x2B8F004;                         
            // 0x00E57EE8: LDR w0, [x8]               | W0 = 0x12C3;                            
            // 0x00E57EEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C3, ????);     
            // 0x00E57EF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E57EF4: STRB w8, [x19, #0xacd]     | static_value_03734ACD = true;            //  dest_result_addr=57887437
            label_0:
            // 0x00E57EF8: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E57EFC: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00E57F00: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00E57F04: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x00E57F08: LDR x8, [x8, #0xa88]       | X8 = 1152921504606900224;               
            // 0x00E57F0C: LDR x19, [x8]              | X19 = typeof(System.Object);            
            // 0x00E57F10: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E57F14: TBZ w8, #0, #0xe57f24      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E57F18: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E57F1C: CBNZ w8, #0xe57f24         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E57F20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00E57F24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57F2C: MOV x1, x19                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x00E57F30: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00E57F34: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E57F38: CBNZ x19, #0xe57f40        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00E57F3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00E57F40: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00E57F44: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00E57F48: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.Type).__il2cppRuntimeField_1B0; X1 = typeof(System.Type).__il2cppRuntimeField_1B8; //  | 
            // 0x00E57F4C: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_1B0();
            // 0x00E57F50: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E57F54: CBNZ x19, #0xe57f5c        | if (val_1 != null) goto label_4;        
            if(val_1 != null)
            {
                goto label_4;
            }
            // 0x00E57F58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x00E57F5C: LDR x8, [x19]              | X8 = typeof(System.Type);               
            // 0x00E57F60: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x00E57F64: LDP x9, x1, [x8, #0x180]   | X9 = typeof(System.Type).__il2cppRuntimeField_180; X1 = typeof(System.Type).__il2cppRuntimeField_188; //  | 
            // 0x00E57F68: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_180();
            // 0x00E57F6C: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E57F70: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E57F74: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E57F78: LDR x8, [x8]               | X8 = typeof(System.IO.Path);            
            // 0x00E57F7C: LDRB w9, [x8, #0x10a]      | W9 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E57F80: TBZ w9, #0, #0xe57f94      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00E57F84: LDR w9, [x8, #0xbc]        | W9 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E57F88: CBNZ w9, #0xe57f94         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00E57F8C: MOV x0, x8                 | X0 = 1152921504622075904 (0x1000000000E86000);//ML01
            // 0x00E57F90: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_6:
            // 0x00E57F94: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57F98: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57F9C: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00E57FA0: BL #0x1e6bf14              | X0 = System.IO.Path.GetDirectoryName(path:  0);
            string val_2 = System.IO.Path.GetDirectoryName(path:  0);
            // 0x00E57FA4: MOV x1, x0                 | X1 = val_2;//m1                         
            // 0x00E57FA8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57FAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E57FB0: BL #0x1e6bd78              | X0 = System.IO.Directory.GetParent(path:  0);
            System.IO.DirectoryInfo val_3 = System.IO.Directory.GetParent(path:  0);
            // 0x00E57FB4: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x00E57FB8: CBNZ x19, #0xe57fc0        | if (val_3 != null) goto label_7;        
            if(val_3 != null)
            {
                goto label_7;
            }
            // 0x00E57FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_7:
            // 0x00E57FC0: LDR x8, [x19]              | X8 = typeof(System.IO.DirectoryInfo);   
            // 0x00E57FC4: MOV x0, x19                | X0 = val_3;//m1                         
            // 0x00E57FC8: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B0; X1 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B8; //  | 
            // 0x00E57FCC: BLR x9                     | X0 = typeof(System.IO.DirectoryInfo).__il2cppRuntimeField_1B0();
            // 0x00E57FD0: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
            // 0x00E57FD4: LDR x8, [x8, #0xaa8]       | X8 = (string**)(1152921509463534688)("gac");
            // 0x00E57FD8: MOV x1, x0                 | X1 = val_3;//m1                         
            // 0x00E57FDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57FE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E57FE4: LDR x2, [x8]               | X2 = "gac";                             
            // 0x00E57FE8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E57FEC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E57FF0: B #0x1e6ccac               | return System.IO.Path.Combine(path1:  0, path2:  val_3);
            return System.IO.Path.Combine(path1:  0, path2:  val_3);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E57408 (15037448), len: 292  VirtAddr: 0x00E57408 RVA: 0x00E57408 token: 100663741 methodIndex: 19334 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.AssemblyDefinition GetAssemblyInGac(ILRuntime.Mono.Cecil.AssemblyNameReference reference, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00E57408: STP x22, x21, [sp, #-0x30]! | stack[1152921509463964256] = ???;  stack[1152921509463964264] = ???;  //  dest_result_addr=1152921509463964256 |  dest_result_addr=1152921509463964264
            // 0x00E5740C: STP x20, x19, [sp, #0x10]  | stack[1152921509463964272] = ???;  stack[1152921509463964280] = ???;  //  dest_result_addr=1152921509463964272 |  dest_result_addr=1152921509463964280
            // 0x00E57410: STP x29, x30, [sp, #0x20]  | stack[1152921509463964288] = ???;  stack[1152921509463964296] = ???;  //  dest_result_addr=1152921509463964288 |  dest_result_addr=1152921509463964296
            // 0x00E57414: ADD x29, sp, #0x20         | X29 = (1152921509463964256 + 32) = 1152921509463964288 (0x100000012181BA80);
            // 0x00E57418: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E5741C: LDRB w8, [x22, #0xace]     | W8 = (bool)static_value_03734ACE;       
            // 0x00E57420: MOV x19, x2                | X19 = parameters;//m1                   
            // 0x00E57424: MOV x20, x1                | X20 = reference;//m1                    
            // 0x00E57428: MOV x21, x0                | X21 = 1152921509463976304 (0x100000012181E970);//ML01
            // 0x00E5742C: TBNZ w8, #0, #0xe57448     | if (static_value_03734ACE == true) goto label_0;
            // 0x00E57430: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x00E57434: LDR x8, [x8, #8]           | X8 = 0x2B8EFF4;                         
            // 0x00E57438: LDR w0, [x8]               | W0 = 0x12BF;                            
            // 0x00E5743C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12BF, ????);     
            // 0x00E57440: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E57444: STRB w8, [x22, #0xace]     | static_value_03734ACE = true;            //  dest_result_addr=57887438
            label_0:
            // 0x00E57448: CBNZ x20, #0xe57450        | if (reference != null) goto label_1;    
            if(reference != null)
            {
                goto label_1;
            }
            // 0x00E5744C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12BF, ????);     
            label_1:
            // 0x00E57450: MOV x0, x20                | X0 = reference;//m1                     
            // 0x00E57454: BL #0xe557e4               | X0 = reference.get_PublicKeyToken();    
            System.Byte[] val_1 = reference.PublicKeyToken;
            // 0x00E57458: CBZ x0, #0xe574fc          | if (val_1 == null) goto label_5;        
            if(val_1 == null)
            {
                goto label_5;
            }
            // 0x00E5745C: CBNZ x20, #0xe57464        | if (reference != null) goto label_3;    
            if(reference != null)
            {
                goto label_3;
            }
            // 0x00E57460: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00E57464: MOV x0, x20                | X0 = reference;//m1                     
            // 0x00E57468: BL #0xe557e4               | X0 = reference.get_PublicKeyToken();    
            System.Byte[] val_2 = reference.PublicKeyToken;
            // 0x00E5746C: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x00E57470: CBNZ x22, #0xe57478        | if (val_2 != null) goto label_4;        
            if(val_2 != null)
            {
                goto label_4;
            }
            // 0x00E57474: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_4:
            // 0x00E57478: LDR x8, [x22, #0x18]       | X8 = val_2.Length; //P2                 
            // 0x00E5747C: CBZ x8, #0xe574fc          | if (val_2.Length == 0) goto label_5;    
            if(val_2.Length == 0)
            {
                goto label_5;
            }
            // 0x00E57480: LDR x8, [x21, #0x18]       | X8 = this.gac_paths; //P2               
            // 0x00E57484: CBNZ x8, #0xe574b0         | if (this.gac_paths != null) goto label_6;
            if(this.gac_paths != null)
            {
                goto label_6;
            }
            // 0x00E57488: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00E5748C: LDR x8, [x8, #0xbe8]       | X8 = 1152921504738156544;               
            // 0x00E57490: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E57494: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E57498: TBZ w8, #0, #0xe574a8      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00E5749C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E574A0: CBNZ w8, #0xe574a8         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00E574A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_8:
            // 0x00E574A8: BL #0xe57a30               | X0 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetGacPaths();
            ILRuntime.Mono.Collections.Generic.Collection<System.String> val_3 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetGacPaths();
            // 0x00E574AC: STR x0, [x21, #0x18]       | this.gac_paths = val_3;                  //  dest_result_addr=1152921509463976328
            this.gac_paths = val_3;
            label_6:
            // 0x00E574B0: ADRP x22, #0x3650000       | X22 = 56950784 (0x3650000);             
            // 0x00E574B4: LDR x22, [x22, #0xbe8]     | X22 = 1152921504738156544;              
            // 0x00E574B8: LDR x0, [x22]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_4 = null;
            // 0x00E574BC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E574C0: TBZ w8, #0, #0xe574d4      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x00E574C4: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E574C8: CBNZ w8, #0xe574d4         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x00E574CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            // 0x00E574D0: LDR x0, [x22]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            val_4 = null;
            label_10:
            // 0x00E574D4: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_static_fields;
            // 0x00E574D8: LDRB w8, [x8]              | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono;
            // 0x00E574DC: CBZ w8, #0xe57510          | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false) goto label_11;
            if(ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono == false)
            {
                goto label_11;
            }
            // 0x00E574E0: MOV x1, x20                | X1 = reference;//m1                     
            // 0x00E574E4: MOV x2, x19                | X2 = parameters;//m1                    
            // 0x00E574E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E574EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E574F0: MOV x0, x21                | X0 = 1152921509463976304 (0x100000012181E970);//ML01
            // 0x00E574F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E574F8: B #0xe57ff4                | return this.GetAssemblyInMonoGac(reference:  reference, parameters:  parameters);
            return this.GetAssemblyInMonoGac(reference:  reference, parameters:  parameters);
            label_5:
            // 0x00E574FC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E57500: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E57504: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E57508: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E5750C: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyDefinition)null;
            return (ILRuntime.Mono.Cecil.AssemblyDefinition)0;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyDefinition, size=8, nGRN=0 }
            label_11:
            // 0x00E57510: MOV x1, x20                | X1 = reference;//m1                     
            // 0x00E57514: MOV x2, x19                | X2 = parameters;//m1                    
            // 0x00E57518: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5751C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E57520: MOV x0, x21                | X0 = 1152921509463976304 (0x100000012181E970);//ML01
            // 0x00E57524: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E57528: B #0xe58158                | return this.GetAssemblyInNetGac(reference:  reference, parameters:  parameters);
            return this.GetAssemblyInNetGac(reference:  reference, parameters:  parameters);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E57FF4 (15040500), len: 356  VirtAddr: 0x00E57FF4 RVA: 0x00E57FF4 token: 100663742 methodIndex: 19335 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.AssemblyDefinition GetAssemblyInMonoGac(ILRuntime.Mono.Cecil.AssemblyNameReference reference, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            // 0x00E57FF4: STP x28, x27, [sp, #-0x60]! | stack[1152921509464192944] = ???;  stack[1152921509464192952] = ???;  //  dest_result_addr=1152921509464192944 |  dest_result_addr=1152921509464192952
            // 0x00E57FF8: STP x26, x25, [sp, #0x10]  | stack[1152921509464192960] = ???;  stack[1152921509464192968] = ???;  //  dest_result_addr=1152921509464192960 |  dest_result_addr=1152921509464192968
            // 0x00E57FFC: STP x24, x23, [sp, #0x20]  | stack[1152921509464192976] = ???;  stack[1152921509464192984] = ???;  //  dest_result_addr=1152921509464192976 |  dest_result_addr=1152921509464192984
            // 0x00E58000: STP x22, x21, [sp, #0x30]  | stack[1152921509464192992] = ???;  stack[1152921509464193000] = ???;  //  dest_result_addr=1152921509464192992 |  dest_result_addr=1152921509464193000
            // 0x00E58004: STP x20, x19, [sp, #0x40]  | stack[1152921509464193008] = ???;  stack[1152921509464193016] = ???;  //  dest_result_addr=1152921509464193008 |  dest_result_addr=1152921509464193016
            // 0x00E58008: STP x29, x30, [sp, #0x50]  | stack[1152921509464193024] = ???;  stack[1152921509464193032] = ???;  //  dest_result_addr=1152921509464193024 |  dest_result_addr=1152921509464193032
            // 0x00E5800C: ADD x29, sp, #0x50         | X29 = (1152921509464192944 + 80) = 1152921509464193024 (0x1000000121853800);
            // 0x00E58010: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E58014: LDRB w8, [x22, #0xacf]     | W8 = (bool)static_value_03734ACF;       
            // 0x00E58018: MOV x19, x2                | X19 = parameters;//m1                   
            // 0x00E5801C: MOV x20, x1                | X20 = reference;//m1                    
            // 0x00E58020: MOV x21, x0                | X21 = 1152921509464205040 (0x10000001218566F0);//ML01
            // 0x00E58024: TBNZ w8, #0, #0xe58040     | if (static_value_03734ACF == true) goto label_0;
            // 0x00E58028: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x00E5802C: LDR x8, [x8, #0xcc0]       | X8 = 0x2B8EFF8;                         
            // 0x00E58030: LDR w0, [x8]               | W0 = 0x12C0;                            
            // 0x00E58034: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C0, ????);     
            // 0x00E58038: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E5803C: STRB w8, [x22, #0xacf]     | static_value_03734ACF = true;            //  dest_result_addr=57887439
            label_0:
            // 0x00E58040: ADRP x25, #0x3663000       | X25 = 57028608 (0x3663000);             
            // 0x00E58044: ADRP x26, #0x366d000       | X26 = 57069568 (0x366D000);             
            // 0x00E58048: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
            // 0x00E5804C: ADRP x28, #0x3650000       | X28 = 56950784 (0x3650000);             
            // 0x00E58050: LDR x25, [x25, #0x820]     | X25 = 1152921509464162608;              
            // 0x00E58054: LDR x26, [x26, #0xb08]     | X26 = 1152921509464163632;              
            // 0x00E58058: LDR x27, [x27, #0xe38]     | X27 = 1152921504608284672;              
            // 0x00E5805C: LDR x28, [x28, #0xbe8]     | X28 = 1152921504738156544;              
            // 0x00E58060: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_5 = 0;
            label_8:
            // 0x00E58064: LDR x23, [x21, #0x18]      | X23 = this.gac_paths; //P2              
            // 0x00E58068: CBNZ x23, #0xe58070        | if (this.gac_paths != null) goto label_1;
            if(this.gac_paths != null)
            {
                goto label_1;
            }
            // 0x00E5806C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x12C0, ????);     
            label_1:
            // 0x00E58070: LDR x1, [x25]              | X1 = public System.Int32 ILRuntime.Mono.Collections.Generic.Collection<System.String>::get_Count();
            // 0x00E58074: MOV x0, x23                | X0 = this.gac_paths;//m1                
            // 0x00E58078: BL #0x1d46b60              | X0 = this.gac_paths.get_Count();        
            int val_1 = this.gac_paths.Count;
            // 0x00E5807C: CMP w22, w0                | STATE = COMPARE(0x0, val_1)             
            // 0x00E58080: B.GE #0xe58138             | if (0 >= val_1) goto label_2;           
            if(val_5 >= val_1)
            {
                goto label_2;
            }
            // 0x00E58084: LDR x23, [x21, #0x18]      | X23 = this.gac_paths; //P2              
            // 0x00E58088: CBNZ x23, #0xe58090        | if (this.gac_paths != null) goto label_3;
            if(this.gac_paths != null)
            {
                goto label_3;
            }
            // 0x00E5808C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00E58090: LDR x2, [x26]              | X2 = public System.String ILRuntime.Mono.Collections.Generic.Collection<System.String>::get_Item(int index);
            // 0x00E58094: MOV x0, x23                | X0 = this.gac_paths;//m1                
            // 0x00E58098: MOV w1, w22                | W1 = 0 (0x0);//ML01                     
            // 0x00E5809C: BL #0x1d46b68              | X0 = this.gac_paths.get_Item(index:  0);
            string val_2 = this.gac_paths.Item[0];
            // 0x00E580A0: LDR x8, [x27]              | X8 = typeof(System.String);             
            val_5 = null;
            // 0x00E580A4: MOV x23, x0                | X23 = val_2;//m1                        
            // 0x00E580A8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E580AC: TBZ w9, #0, #0xe580c4      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00E580B0: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E580B4: CBNZ w9, #0xe580c4         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00E580B8: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E580BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00E580C0: LDR x8, [x27]              | X8 = typeof(System.String);             
            val_5 = null;
            label_5:
            // 0x00E580C4: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00E580C8: LDR x0, [x28]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E580CC: LDR x24, [x8]              | X24 = System.String.Empty;              
            // 0x00E580D0: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E580D4: TBZ w8, #0, #0xe580e4      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x00E580D8: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E580DC: CBNZ w8, #0xe580e4         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x00E580E0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_7:
            // 0x00E580E4: MOV x1, x20                | X1 = reference;//m1                     
            // 0x00E580E8: MOV x2, x24                | X2 = System.String.Empty;//m1           
            // 0x00E580EC: MOV x3, x23                | X3 = val_2;//m1                         
            // 0x00E580F0: BL #0xe58580               | X0 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetAssemblyFile(reference:  null, prefix:  reference, gac:  System.String.Empty);
            string val_3 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetAssemblyFile(reference:  null, prefix:  reference, gac:  System.String.Empty);
            // 0x00E580F4: MOV x23, x0                | X23 = val_3;//m1                        
            // 0x00E580F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E580FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58100: MOV x1, x23                | X1 = val_3;//m1                         
            // 0x00E58104: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_4 = System.IO.File.Exists(path:  0);
            // 0x00E58108: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x00E5810C: TBZ w0, #0, #0xe58064      | if (val_4 == false) goto label_8;       
            if(val_4 == false)
            {
                goto label_8;
            }
            // 0x00E58110: MOV x0, x21                | X0 = 1152921509464205040 (0x10000001218566F0);//ML01
            // 0x00E58114: MOV x1, x23                | X1 = val_3;//m1                         
            // 0x00E58118: MOV x2, x19                | X2 = parameters;//m1                    
            // 0x00E5811C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58120: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E58124: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E58128: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E5812C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E58130: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E58134: B #0xe566ec                | return this.GetAssembly(file:  val_3, parameters:  parameters);
            return this.GetAssembly(file:  val_3, parameters:  parameters);
            label_2:
            // 0x00E58138: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5813C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E58140: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E58144: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E58148: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E5814C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58150: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E58154: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyDefinition)null;
            return (ILRuntime.Mono.Cecil.AssemblyDefinition)0;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyDefinition, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58158 (15040856), len: 1064  VirtAddr: 0x00E58158 RVA: 0x00E58158 token: 100663743 methodIndex: 19336 delegateWrapperIndex: 0 methodInvoker: 0
        private ILRuntime.Mono.Cecil.AssemblyDefinition GetAssemblyInNetGac(ILRuntime.Mono.Cecil.AssemblyNameReference reference, ILRuntime.Mono.Cecil.ReaderParameters parameters)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00E58158: STP x28, x27, [sp, #-0x60]! | stack[1152921509464350416] = ???;  stack[1152921509464350424] = ???;  //  dest_result_addr=1152921509464350416 |  dest_result_addr=1152921509464350424
            // 0x00E5815C: STP x26, x25, [sp, #0x10]  | stack[1152921509464350432] = ???;  stack[1152921509464350440] = ???;  //  dest_result_addr=1152921509464350432 |  dest_result_addr=1152921509464350440
            // 0x00E58160: STP x24, x23, [sp, #0x20]  | stack[1152921509464350448] = ???;  stack[1152921509464350456] = ???;  //  dest_result_addr=1152921509464350448 |  dest_result_addr=1152921509464350456
            // 0x00E58164: STP x22, x21, [sp, #0x30]  | stack[1152921509464350464] = ???;  stack[1152921509464350472] = ???;  //  dest_result_addr=1152921509464350464 |  dest_result_addr=1152921509464350472
            // 0x00E58168: STP x20, x19, [sp, #0x40]  | stack[1152921509464350480] = ???;  stack[1152921509464350488] = ???;  //  dest_result_addr=1152921509464350480 |  dest_result_addr=1152921509464350488
            // 0x00E5816C: STP x29, x30, [sp, #0x50]  | stack[1152921509464350496] = ???;  stack[1152921509464350504] = ???;  //  dest_result_addr=1152921509464350496 |  dest_result_addr=1152921509464350504
            // 0x00E58170: ADD x29, sp, #0x50         | X29 = (1152921509464350416 + 80) = 1152921509464350496 (0x1000000121879F20);
            // 0x00E58174: SUB sp, sp, #0x20          | SP = (1152921509464350416 - 32) = 1152921509464350384 (0x1000000121879EB0);
            // 0x00E58178: STR x1, [sp, #0x10]        | stack[1152921509464350400] = reference;  //  dest_result_addr=1152921509464350400
            // 0x00E5817C: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E58180: LDRB w8, [x19, #0xad0]     | W8 = (bool)static_value_03734AD0;       
            // 0x00E58184: MOV x20, x2                | X20 = parameters;//m1                   
            // 0x00E58188: STR x0, [sp, #0x18]        | stack[1152921509464350408] = this;       //  dest_result_addr=1152921509464350408
            // 0x00E5818C: TBNZ w8, #0, #0xe581a8     | if (static_value_03734AD0 == true) goto label_0;
            // 0x00E58190: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x00E58194: LDR x8, [x8, #0xa88]       | X8 = 0x2B8EFFC;                         
            // 0x00E58198: LDR w0, [x8]               | W0 = 0x12C1;                            
            // 0x00E5819C: BL #0x2782188              | X0 = sub_2782188( ?? 0x12C1, ????);     
            // 0x00E581A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E581A4: STRB w8, [x19, #0xad0]     | static_value_03734AD0 = true;            //  dest_result_addr=57887440
            label_0:
            // 0x00E581A8: ADRP x23, #0x3680000       | X23 = 57147392 (0x3680000);             
            // 0x00E581AC: LDR x23, [x23, #0x2d0]     | X23 = 1152921504948897168;              
            // 0x00E581B0: LDR x22, [x23]             | X22 = typeof(System.String[]);          
            // 0x00E581B4: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E581B8: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00E581BC: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x00E581C0: MOV x0, x22                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E581C4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00E581C8: MOV x22, x0                | X22 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E581CC: CBNZ x22, #0xe581d4        | if ( != null) goto label_1;             
            if(null != null)
            {
                goto label_1;
            }
            // 0x00E581D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String[]), ????);
            label_1:
            // 0x00E581D4: ADRP x19, #0x3656000       | X19 = 56975360 (0x3656000);             
            // 0x00E581D8: LDR x19, [x19, #0x4e8]     | X19 = (string**)(1152921509464325808)("GAC_MSIL");
            // 0x00E581DC: LDR x0, [x19]              | X0 = "GAC_MSIL";                        
            // 0x00E581E0: CBZ x0, #0xe58200          | if ("GAC_MSIL" == null) goto label_3;   
            // 0x00E581E4: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E581E8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E581EC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "GAC_MSIL", ????); 
            // 0x00E581F0: CBNZ x0, #0xe58200         | if ("GAC_MSIL" != null) goto label_3;   
            if("GAC_MSIL" != null)
            {
                goto label_3;
            }
            // 0x00E581F4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "GAC_MSIL", ????); 
            // 0x00E581F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E581FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC_MSIL", ????); 
            label_3:
            // 0x00E58200: LDR x19, [x19]             | X19 = "GAC_MSIL";                       
            // 0x00E58204: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E58208: CBNZ w8, #0xe58218         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_4;
            // 0x00E5820C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "GAC_MSIL", ????); 
            // 0x00E58210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58214: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC_MSIL", ????); 
            label_4:
            // 0x00E58218: STR x19, [x22, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = "GAC_MSIL";  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = "GAC_MSIL";
            // 0x00E5821C: ADRP x19, #0x35c9000       | X19 = 56397824 (0x35C9000);             
            // 0x00E58220: LDR x19, [x19, #0xe0]      | X19 = (string**)(1152921509464325904)("GAC_32");
            // 0x00E58224: LDR x0, [x19]              | X0 = "GAC_32";                          
            // 0x00E58228: CBZ x0, #0xe58248          | if ("GAC_32" == null) goto label_6;     
            // 0x00E5822C: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E58230: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E58234: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "GAC_32", ????);   
            // 0x00E58238: CBNZ x0, #0xe58248         | if ("GAC_32" != null) goto label_6;     
            if("GAC_32" != null)
            {
                goto label_6;
            }
            // 0x00E5823C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "GAC_32", ????);   
            // 0x00E58240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58244: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC_32", ????);   
            label_6:
            // 0x00E58248: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E5824C: LDR x19, [x19]             | X19 = "GAC_32";                         
            // 0x00E58250: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00E58254: B.HI #0xe58264             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_7;
            // 0x00E58258: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "GAC_32", ????);   
            // 0x00E5825C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58260: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC_32", ????);   
            label_7:
            // 0x00E58264: STR x19, [x22, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = "GAC_32";  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = "GAC_32";
            // 0x00E58268: ADRP x19, #0x35cc000       | X19 = 56410112 (0x35CC000);             
            // 0x00E5826C: LDR x19, [x19, #0x5c8]     | X19 = (string**)(1152921509464325984)("GAC_64");
            // 0x00E58270: LDR x0, [x19]              | X0 = "GAC_64";                          
            // 0x00E58274: CBZ x0, #0xe58294          | if ("GAC_64" == null) goto label_9;     
            // 0x00E58278: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E5827C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E58280: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "GAC_64", ????);   
            // 0x00E58284: CBNZ x0, #0xe58294         | if ("GAC_64" != null) goto label_9;     
            if("GAC_64" != null)
            {
                goto label_9;
            }
            // 0x00E58288: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "GAC_64", ????);   
            // 0x00E5828C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58290: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC_64", ????);   
            label_9:
            // 0x00E58294: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E58298: LDR x19, [x19]             | X19 = "GAC_64";                         
            // 0x00E5829C: CMP w8, #2                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x00E582A0: B.HI #0xe582b0             | if (System.String[].__il2cppRuntimeField_namespaze > 0x2) goto label_10;
            // 0x00E582A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "GAC_64", ????);   
            // 0x00E582A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E582AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC_64", ????);   
            label_10:
            // 0x00E582B0: STR x19, [x22, #0x30]      | typeof(System.String[]).__il2cppRuntimeField_30 = "GAC_64";  //  dest_result_addr=1152921504948897216
            typeof(System.String[]).__il2cppRuntimeField_30 = "GAC_64";
            // 0x00E582B4: ADRP x19, #0x3625000       | X19 = 56774656 (0x3625000);             
            // 0x00E582B8: LDR x19, [x19, #0xcc8]     | X19 = (string**)(1152921509464326064)("GAC");
            // 0x00E582BC: LDR x0, [x19]              | X0 = "GAC";                             
            // 0x00E582C0: CBZ x0, #0xe582e0          | if ("GAC" == null) goto label_12;       
            // 0x00E582C4: LDR x8, [x22]              | X8 = ;                                  
            // 0x00E582C8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E582CC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "GAC", ????);      
            // 0x00E582D0: CBNZ x0, #0xe582e0         | if ("GAC" != null) goto label_12;       
            if("GAC" != null)
            {
                goto label_12;
            }
            // 0x00E582D4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "GAC", ????);      
            // 0x00E582D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E582DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC", ????);      
            label_12:
            // 0x00E582E0: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E582E4: LDR x19, [x19]             | X19 = "GAC";                            
            // 0x00E582E8: CMP w8, #3                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x00E582EC: B.HI #0xe582fc             | if (System.String[].__il2cppRuntimeField_namespaze > 0x3) goto label_13;
            // 0x00E582F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "GAC", ????);      
            // 0x00E582F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E582F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "GAC", ????);      
            label_13:
            // 0x00E582FC: STR x19, [x22, #0x38]      | typeof(System.String[]).__il2cppRuntimeField_38 = "GAC";  //  dest_result_addr=1152921504948897224
            typeof(System.String[]).__il2cppRuntimeField_38 = "GAC";
            // 0x00E58300: LDR x23, [x23]             | X23 = typeof(System.String[]);          
            // 0x00E58304: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E58308: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.String[]), ????);
            // 0x00E5830C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x00E58310: MOV x0, x23                | X0 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E58314: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.String[]), ????);
            // 0x00E58318: ADRP x19, #0x35d6000       | X19 = 56451072 (0x35D6000);             
            // 0x00E5831C: LDR x19, [x19, #0xe38]     | X19 = 1152921504608284672;              
            // 0x00E58320: MOV x23, x0                | X23 = 1152921504948897168 (0x1000000014634590);//ML01
            // 0x00E58324: LDR x8, [x19]              | X8 = typeof(System.String);             
            val_6 = null;
            // 0x00E58328: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E5832C: TBZ w9, #0, #0xe58338      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_14;
            // 0x00E58330: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E58334: CBZ w9, #0xe58340          | if (System.String.__il2cppRuntimeField_cctor_finished == 0) goto label_15;
            label_14:
            // 0x00E58338: STR x20, [sp, #8]          | stack[1152921509464350392] = parameters;  //  dest_result_addr=1152921509464350392
            // 0x00E5833C: B #0xe58350                |  goto label_16;                         
            goto label_16;
            label_15:
            // 0x00E58340: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E58344: STR x20, [sp, #8]          | stack[1152921509464350392] = parameters;  //  dest_result_addr=1152921509464350392
            // 0x00E58348: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            // 0x00E5834C: LDR x8, [x19]              | X8 = typeof(System.String);             
            val_6 = null;
            label_16:
            // 0x00E58350: LDR x8, [x8, #0xa0]        | X8 = System.String.__il2cppRuntimeField_static_fields;
            // 0x00E58354: LDR x24, [x8]              | X24 = System.String.Empty;              
            // 0x00E58358: CBNZ x23, #0xe58360        | if ( != null) goto label_17;            
            if(null != null)
            {
                goto label_17;
            }
            // 0x00E5835C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.String), ????);
            label_17:
            // 0x00E58360: CBZ x24, #0xe58384         | if (System.String.Empty == null) goto label_19;
            if(System.String.Empty == null)
            {
                goto label_19;
            }
            // 0x00E58364: LDR x8, [x23]              | X8 = ;                                  
            // 0x00E58368: MOV x0, x24                | X0 = System.String.Empty;//m1           
            // 0x00E5836C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E58370: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? System.String.Empty, ????);
            // 0x00E58374: CBNZ x0, #0xe58384         | if (System.String.Empty != null) goto label_19;
            if(System.String.Empty != null)
            {
                goto label_19;
            }
            // 0x00E58378: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? System.String.Empty, ????);
            // 0x00E5837C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58380: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_19:
            // 0x00E58384: LDR w8, [x23, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E58388: CBNZ w8, #0xe58398         | if (System.String[].__il2cppRuntimeField_namespaze != 0) goto label_20;
            // 0x00E5838C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? System.String.Empty, ????);
            // 0x00E58390: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58394: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? System.String.Empty, ????);
            label_20:
            // 0x00E58398: STR x24, [x23, #0x20]      | typeof(System.String[]).__il2cppRuntimeField_20 = System.String.Empty;  //  dest_result_addr=1152921504948897200
            typeof(System.String[]).__il2cppRuntimeField_20 = System.String.Empty;
            // 0x00E5839C: ADRP x19, #0x35da000       | X19 = 56467456 (0x35DA000);             
            // 0x00E583A0: LDR x19, [x19, #0x8f8]     | X19 = (string**)(1152921509464326144)("v4.0_");
            // 0x00E583A4: LDR x0, [x19]              | X0 = "v4.0_";                           
            // 0x00E583A8: CBZ x0, #0xe583c8          | if ("v4.0_" == null) goto label_22;     
            // 0x00E583AC: LDR x8, [x23]              | X8 = ;                                  
            // 0x00E583B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00E583B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "v4.0_", ????);    
            // 0x00E583B8: CBNZ x0, #0xe583c8         | if ("v4.0_" != null) goto label_22;     
            if("v4.0_" != null)
            {
                goto label_22;
            }
            // 0x00E583BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "v4.0_", ????);    
            // 0x00E583C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E583C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "v4.0_", ????);    
            label_22:
            // 0x00E583C8: LDR w8, [x23, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E583CC: LDR x19, [x19]             | X19 = "v4.0_";                          
            // 0x00E583D0: CMP w8, #1                 | STATE = COMPARE(System.String[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x00E583D4: B.HI #0xe583e4             | if (System.String[].__il2cppRuntimeField_namespaze > 0x1) goto label_23;
            // 0x00E583D8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "v4.0_", ????);    
            // 0x00E583DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E583E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "v4.0_", ????);    
            label_23:
            // 0x00E583E4: STR x19, [x23, #0x28]      | typeof(System.String[]).__il2cppRuntimeField_28 = "v4.0_";  //  dest_result_addr=1152921504948897208
            typeof(System.String[]).__il2cppRuntimeField_28 = "v4.0_";
            // 0x00E583E8: ADRP x27, #0x366d000       | X27 = 57069568 (0x366D000);             
            // 0x00E583EC: ADRP x28, #0x3672000       | X28 = 57090048 (0x3672000);             
            // 0x00E583F0: ADRP x19, #0x3650000       | X19 = 56950784 (0x3650000);             
            // 0x00E583F4: LDR x27, [x27, #0xb08]     | X27 = 1152921509464163632;              
            // 0x00E583F8: LDR x28, [x28, #0xc88]     | X28 = 1152921504622075904;              
            // 0x00E583FC: LDR x19, [x19, #0xbe8]     | X19 = 1152921504738156544;              
            // 0x00E58400: MOV x24, xzr               | X24 = 0 (0x0);//ML01                    
            label_38:
            // 0x00E58404: ADD x8, x23, x24, lsl #3   | X8 = (null + 0) = 1152921504948897168 (0x1000000014634590);
            // 0x00E58408: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x00E5840C: ADD x21, x8, #0x20         | X21 = (1152921504948897168 + 32) = 1152921504948897200 (0x10000000146345B0);
            // 0x00E58410: B #0xe58418                |  goto label_24;                         
            goto label_24;
            label_36:
            // 0x00E58414: ADD w20, w20, #1           | W20 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            label_24:
            // 0x00E58418: CBNZ x22, #0xe58420        | if ( != null) goto label_25;            
            if(null != null)
            {
                goto label_25;
            }
            // 0x00E5841C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "v4.0_", ????);    
            label_25:
            // 0x00E58420: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E58424: CMP w20, w8                | STATE = COMPARE(0x1, System.String[].__il2cppRuntimeField_namespaze)
            // 0x00E58428: B.GE #0xe58520             | if (val_7 >= System.String[].__il2cppRuntimeField_namespaze) goto label_26;
            // 0x00E5842C: LDR x8, [sp, #0x18]        | X8 = this;                              
            // 0x00E58430: LDR x25, [x8, #0x18]       | X25 = mem[1152921509464362536];         
            // 0x00E58434: CBNZ x25, #0xe5843c        | if (mem[1152921509464362536] != 0) goto label_27;
            if(mem[1152921509464362536] != 0)
            {
                goto label_27;
            }
            // 0x00E58438: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "v4.0_", ????);    
            label_27:
            // 0x00E5843C: LDR x2, [x27]              | X2 = public System.String ILRuntime.Mono.Collections.Generic.Collection<System.String>::get_Item(int index);
            // 0x00E58440: MOV x0, x25                | X0 = mem[1152921509464362536];//m1      
            // 0x00E58444: MOV w1, w24                | W1 = 0 (0x0);//ML01                     
            // 0x00E58448: BL #0x1d46b68              | X0 = mem[1152921509464362536].get_Item(index:  0);
            string val_1 = mem[1152921509464362536].Item[0];
            // 0x00E5844C: LDR w8, [x22, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E58450: MOV x25, x0                | X25 = val_1;//m1                        
            // 0x00E58454: SXTW x26, w20              | X26 = 1 (0x00000001);                   
            // 0x00E58458: CMP w20, w8                | STATE = COMPARE(0x1, System.String[].__il2cppRuntimeField_namespaze)
            // 0x00E5845C: B.LO #0xe5846c             | if (val_7 < System.String[].__il2cppRuntimeField_namespaze) goto label_28;
            // 0x00E58460: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x00E58464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58468: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_28:
            // 0x00E5846C: LDR x0, [x28]              | X0 = typeof(System.IO.Path);            
            // 0x00E58470: ADD x8, x22, x26, lsl #3   | X8 = (null + 8) = 1152921504948897176 (0x1000000014634598);
            // 0x00E58474: LDR x26, [x8, #0x20]       | X26 = "v4.0_";                          
            // 0x00E58478: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E5847C: TBZ w8, #0, #0xe5848c      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x00E58480: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E58484: CBNZ w8, #0xe5848c         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x00E58488: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_30:
            // 0x00E5848C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58490: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E58494: MOV x1, x25                | X1 = val_1;//m1                         
            // 0x00E58498: MOV x2, x26                | X2 = 1152921509464326144 (0x1000000121874000);//ML01
            // 0x00E5849C: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_1);
            string val_2 = System.IO.Path.Combine(path1:  0, path2:  val_1);
            // 0x00E584A0: MOV x25, x0                | X25 = val_2;//m1                        
            // 0x00E584A4: CBNZ x23, #0xe584ac        | if ( != null) goto label_31;            
            if(null != null)
            {
                goto label_31;
            }
            // 0x00E584A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_31:
            // 0x00E584AC: LDR w8, [x23, #0x18]       | W8 = System.String[].__il2cppRuntimeField_namespaze;
            // 0x00E584B0: CMP x24, x8                | STATE = COMPARE(0x0, System.String[].__il2cppRuntimeField_namespaze)
            // 0x00E584B4: B.LO #0xe584c4             | if (0 < System.String[].__il2cppRuntimeField_namespaze) goto label_32;
            // 0x00E584B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00E584BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E584C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_32:
            // 0x00E584C4: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E584C8: LDR x26, [x21]             | X26 = System.String.Empty;              
            // 0x00E584CC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_10A;
            // 0x00E584D0: TBZ w8, #0, #0xe584e0      | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x00E584D4: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished;
            // 0x00E584D8: CBNZ w8, #0xe584e0         | if (ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x00E584DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver), ????);
            label_34:
            // 0x00E584E0: LDR x1, [sp, #0x10]        | X1 = reference;                         
            // 0x00E584E4: MOV x2, x26                | X2 = System.String.Empty;//m1           
            // 0x00E584E8: MOV x3, x25                | X3 = val_2;//m1                         
            // 0x00E584EC: BL #0xe58580               | X0 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetAssemblyFile(reference:  null, prefix:  reference, gac:  typeof(System.String[]).__il2cppRuntimeField_20);
            string val_3 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.GetAssemblyFile(reference:  null, prefix:  reference, gac:  typeof(System.String[]).__il2cppRuntimeField_20);
            // 0x00E584F0: MOV x26, x0                | X26 = val_3;//m1                        
            // 0x00E584F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E584F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E584FC: MOV x1, x25                | X1 = val_2;//m1                         
            // 0x00E58500: BL #0x1e6aa78              | X0 = System.IO.Directory.Exists(path:  0);
            bool val_4 = System.IO.Directory.Exists(path:  0);
            // 0x00E58504: TBZ w0, #0, #0xe58414      | if (val_4 == false) goto label_36;      
            if(val_4 == false)
            {
                goto label_36;
            }
            // 0x00E58508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5850C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58510: MOV x1, x26                | X1 = val_3;//m1                         
            // 0x00E58514: BL #0x1e69484              | X0 = System.IO.File.Exists(path:  0);   
            bool val_5 = System.IO.File.Exists(path:  0);
            // 0x00E58518: TBZ w0, #0, #0xe58414      | if (val_5 == false) goto label_36;      
            if(val_5 == false)
            {
                goto label_36;
            }
            // 0x00E5851C: B #0xe58554                |  goto label_37;                         
            goto label_37;
            label_26:
            // 0x00E58520: ADD x8, x24, #1            | X8 = (0 + 1);                           
            var val_6 = 0 + 1;
            // 0x00E58524: CMP x24, #0                | STATE = COMPARE(0x0, 0x0)               
            // 0x00E58528: MOV x24, x8                | X24 = (0 + 1);//m1                      
            // 0x00E5852C: B.LE #0xe58404             | if (0 <= 0x0) goto label_38;            
            if(0 <= 0)
            {
                goto label_38;
            }
            // 0x00E58530: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58534: SUB sp, x29, #0x50         | SP = (1152921509464350496 - 80) = 1152921509464350416 (0x1000000121879ED0);
            // 0x00E58538: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E5853C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E58540: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E58544: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E58548: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E5854C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E58550: RET                        |  return (ILRuntime.Mono.Cecil.AssemblyDefinition)null;
            return (ILRuntime.Mono.Cecil.AssemblyDefinition)0;
            //  |  // // {name=val_0, type=ILRuntime.Mono.Cecil.AssemblyDefinition, size=8, nGRN=0 }
            label_37:
            // 0x00E58554: LDR x0, [sp, #0x18]        | X0 = this;                              
            // 0x00E58558: LDR x2, [sp, #8]           | X2 = parameters;                        
            // 0x00E5855C: MOV x1, x26                | X1 = val_3;//m1                         
            // 0x00E58560: SUB sp, x29, #0x50         | SP = (1152921509464350496 - 80) = 1152921509464350416 (0x1000000121879ED0);
            // 0x00E58564: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58568: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00E5856C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00E58570: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00E58574: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00E58578: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00E5857C: B #0xe566ec                | return this.GetAssembly(file:  val_3, parameters:  parameters);
            return this.GetAssembly(file:  val_3, parameters:  parameters);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58580 (15041920), len: 592  VirtAddr: 0x00E58580 RVA: 0x00E58580 token: 100663744 methodIndex: 19337 delegateWrapperIndex: 0 methodInvoker: 0
        private static string GetAssemblyFile(ILRuntime.Mono.Cecil.AssemblyNameReference reference, string prefix, string gac)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            // 0x00E58580: STP x26, x25, [sp, #-0x50]! | stack[1152921509464597680] = ???;  stack[1152921509464597688] = ???;  //  dest_result_addr=1152921509464597680 |  dest_result_addr=1152921509464597688
            // 0x00E58584: STP x24, x23, [sp, #0x10]  | stack[1152921509464597696] = ???;  stack[1152921509464597704] = ???;  //  dest_result_addr=1152921509464597696 |  dest_result_addr=1152921509464597704
            // 0x00E58588: STP x22, x21, [sp, #0x20]  | stack[1152921509464597712] = ???;  stack[1152921509464597720] = ???;  //  dest_result_addr=1152921509464597712 |  dest_result_addr=1152921509464597720
            // 0x00E5858C: STP x20, x19, [sp, #0x30]  | stack[1152921509464597728] = ???;  stack[1152921509464597736] = ???;  //  dest_result_addr=1152921509464597728 |  dest_result_addr=1152921509464597736
            // 0x00E58590: STP x29, x30, [sp, #0x40]  | stack[1152921509464597744] = ???;  stack[1152921509464597752] = ???;  //  dest_result_addr=1152921509464597744 |  dest_result_addr=1152921509464597752
            // 0x00E58594: ADD x29, sp, #0x40         | X29 = (1152921509464597680 + 64) = 1152921509464597744 (0x10000001218B64F0);
            // 0x00E58598: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00E5859C: LDRB w8, [x22, #0xad1]     | W8 = (bool)static_value_03734AD1;       
            // 0x00E585A0: MOV x20, x3                | X20 = X3;//m1                           
            // 0x00E585A4: MOV x21, x2                | X21 = gac;//m1                          
            // 0x00E585A8: MOV x19, x1                | X19 = prefix;//m1                       
            // 0x00E585AC: TBNZ w8, #0, #0xe585c8     | if (static_value_03734AD1 == true) goto label_0;
            // 0x00E585B0: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x00E585B4: LDR x8, [x8, #0xd70]       | X8 = 0x2B8EFF0;                         
            // 0x00E585B8: LDR w0, [x8]               | W0 = 0x12BE;                            
            // 0x00E585BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x12BE, ????);     
            // 0x00E585C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E585C4: STRB w8, [x22, #0xad1]     | static_value_03734AD1 = true;            //  dest_result_addr=57887441
            label_0:
            // 0x00E585C8: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x00E585CC: LDR x8, [x8, #0x978]       | X8 = 1152921504649605120;               
            // 0x00E585D0: LDR x0, [x8]               | X0 = typeof(System.Text.StringBuilder); 
            System.Text.StringBuilder val_1 = null;
            // 0x00E585D4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Text.StringBuilder), ????);
            // 0x00E585D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E585DC: MOV x22, x0                | X22 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E585E0: BL #0x1b5a30c              | .ctor();                                
            val_1 = new System.Text.StringBuilder();
            // 0x00E585E4: CBNZ x22, #0xe585ec        | if ( != 0) goto label_1;                
            if(null != 0)
            {
                goto label_1;
            }
            // 0x00E585E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_1:
            // 0x00E585EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E585F0: MOV x0, x22                | X0 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E585F4: MOV x1, x21                | X1 = gac;//m1                           
            // 0x00E585F8: BL #0x1b5b818              | X0 = Append(value:  gac);               
            System.Text.StringBuilder val_2 = Append(value:  gac);
            // 0x00E585FC: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00E58600: CBNZ x19, #0xe58608        | if (prefix != null) goto label_2;       
            if(prefix != null)
            {
                goto label_2;
            }
            // 0x00E58604: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_2:
            // 0x00E58608: LDR x22, [x19, #0x20]      | 
            // 0x00E5860C: CBNZ x21, #0xe58614        | if (val_2 != null) goto label_3;        
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x00E58610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x00E58614: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58618: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00E5861C: MOV x1, x22                | X1 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E58620: BL #0x1b5bb44              | X0 = val_2.Append(value:  val_1);       
            System.Text.StringBuilder val_3 = val_2.Append(value:  val_1);
            // 0x00E58624: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x00E58628: CBNZ x21, #0xe58630        | if (val_3 != null) goto label_4;        
            if(val_3 != null)
            {
                goto label_4;
            }
            // 0x00E5862C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_4:
            // 0x00E58630: ADRP x8, #0x3625000        | X8 = 56774656 (0x3625000);              
            // 0x00E58634: LDR x8, [x8, #0xfa0]       | X8 = (string**)(1152921509464491472)("__");
            // 0x00E58638: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E5863C: MOV x0, x21                | X0 = val_3;//m1                         
            // 0x00E58640: LDR x1, [x8]               | X1 = "__";                              
            // 0x00E58644: BL #0x1b5b818              | X0 = val_3.Append(value:  "__");        
            System.Text.StringBuilder val_4 = val_3.Append(value:  "__");
            // 0x00E58648: ADRP x24, #0x3655000       | X24 = 56971264 (0x3655000);             
            // 0x00E5864C: LDR x24, [x24, #0xda0]     | X24 = (string**)(1152921509424900384)("x2");
            // 0x00E58650: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x00E58654: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x00E58658: B #0xe58670                |  goto label_5;                          
            goto label_5;
            label_13:
            // 0x00E5865C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58660: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x00E58664: MOV x1, x22                | X1 = 1152921504649605120 (0x10000000028C7000);//ML01
            // 0x00E58668: BL #0x1b5b818              | X0 = val_4.Append(value:  val_1);       
            System.Text.StringBuilder val_5 = val_4.Append(value:  val_1);
            // 0x00E5866C: ADD w23, w23, #1           | W23 = (val_11 + 1) = val_11 (0x00000001);
            val_11 = 1;
            label_5:
            // 0x00E58670: CBNZ x19, #0xe58678        | if (prefix != null) goto label_6;       
            if(prefix != null)
            {
                goto label_6;
            }
            // 0x00E58674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_6:
            // 0x00E58678: MOV x0, x19                | X0 = prefix;//m1                        
            // 0x00E5867C: BL #0xe557e4               | X0 = prefix.get_PublicKeyToken();       
            System.Byte[] val_6 = prefix.PublicKeyToken;
            // 0x00E58680: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x00E58684: CBNZ x22, #0xe5868c        | if (val_6 != null) goto label_7;        
            if(val_6 != null)
            {
                goto label_7;
            }
            // 0x00E58688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_7:
            // 0x00E5868C: LDR w22, [x22, #0x18]      | W22 = val_6.Length; //P2                
            // 0x00E58690: CBNZ x19, #0xe58698        | if (prefix != null) goto label_8;       
            if(prefix != null)
            {
                goto label_8;
            }
            // 0x00E58694: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x00E58698: CMP w23, w22               | STATE = COMPARE(0x1, val_6.Length)      
            // 0x00E5869C: B.GE #0xe586f4             | if (val_11 >= val_6.Length) goto label_9;
            if(val_11 >= val_6.Length)
            {
                goto label_9;
            }
            // 0x00E586A0: MOV x0, x19                | X0 = prefix;//m1                        
            // 0x00E586A4: BL #0xe557e4               | X0 = prefix.get_PublicKeyToken();       
            System.Byte[] val_7 = prefix.PublicKeyToken;
            // 0x00E586A8: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x00E586AC: CBNZ x22, #0xe586b4        | if (val_7 != null) goto label_10;       
            if(val_7 != null)
            {
                goto label_10;
            }
            // 0x00E586B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7, ????);      
            label_10:
            // 0x00E586B4: LDR w8, [x22, #0x18]       | W8 = val_7.Length; //P2                 
            // 0x00E586B8: SXTW x25, w23              | X25 = 1 (0x00000001);                   
            // 0x00E586BC: CMP w23, w8                | STATE = COMPARE(0x1, val_7.Length)      
            // 0x00E586C0: B.LO #0xe586d0             | if (val_11 < val_7.Length) goto label_11;
            if(val_11 < val_7.Length)
            {
                goto label_11;
            }
            // 0x00E586C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x00E586C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E586CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_11:
            // 0x00E586D0: LDR x1, [x24]              | X1 = "x2";                              
            // 0x00E586D4: ADD x8, x22, x25           | X8 = val_7[0x1]; //PARR1                
            // 0x00E586D8: ADD x0, x8, #0x20          | X0 = val_7[0x1][0x20]; //PARR1          
            // 0x00E586DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E586E0: BL #0x18d5968              | X0 = label_System_Byte_ToString_GL018D5968();
            // 0x00E586E4: MOV x22, x0                | X22 = val_7[0x1][0x20];//m1             
            var val_11 = val_7[1][32];
            // 0x00E586E8: CBNZ x21, #0xe5865c        | if (val_4 != null) goto label_13;       
            if(val_4 != null)
            {
                goto label_13;
            }
            // 0x00E586EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_7[0x1][0x20], ????);
            // 0x00E586F0: B #0xe5865c                |  goto label_13;                         
            goto label_13;
            label_9:
            // 0x00E586F4: ADRP x8, #0x3672000        | X8 = 57090048 (0x3672000);              
            // 0x00E586F8: LDR x8, [x8, #0xc88]       | X8 = 1152921504622075904;               
            // 0x00E586FC: LDR x22, [x19, #0x10]      | X22 = prefix.length; //P2               
            // 0x00E58700: LDR x0, [x8]               | X0 = typeof(System.IO.Path);            
            // 0x00E58704: LDRB w8, [x0, #0x10a]      | W8 = System.IO.Path.__il2cppRuntimeField_10A;
            // 0x00E58708: TBZ w8, #0, #0xe58718      | if (System.IO.Path.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x00E5870C: LDR w8, [x0, #0xbc]        | W8 = System.IO.Path.__il2cppRuntimeField_cctor_finished;
            // 0x00E58710: CBNZ w8, #0xe58718         | if (System.IO.Path.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x00E58714: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.IO.Path), ????);
            label_15:
            // 0x00E58718: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E5871C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E58720: MOV x1, x20                | X1 = X3;//m1                            
            // 0x00E58724: MOV x2, x22                | X2 = prefix.length;//m1                 
            // 0x00E58728: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  X3);
            string val_8 = System.IO.Path.Combine(path1:  0, path2:  X3);
            // 0x00E5872C: MOV x20, x0                | X20 = val_8;//m1                        
            // 0x00E58730: CBNZ x21, #0xe58738        | if (val_4 != null) goto label_16;       
            if(val_4 != null)
            {
                goto label_16;
            }
            // 0x00E58734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
            label_16:
            // 0x00E58738: LDR x8, [x21]              | X8 = typeof(System.Text.StringBuilder); 
            // 0x00E5873C: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x00E58740: LDP x9, x1, [x8, #0x140]   | X9 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140; X1 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_148; //  | 
            // 0x00E58744: BLR x9                     | X0 = typeof(System.Text.StringBuilder).__il2cppRuntimeField_140();
            // 0x00E58748: MOV x2, x0                 | X2 = val_4;//m1                         
            // 0x00E5874C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58750: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E58754: MOV x1, x20                | X1 = val_8;//m1                         
            // 0x00E58758: BL #0x1e6ccac              | X0 = System.IO.Path.Combine(path1:  0, path2:  val_8);
            string val_9 = System.IO.Path.Combine(path1:  0, path2:  val_8);
            // 0x00E5875C: MOV x20, x0                | X20 = val_9;//m1                        
            // 0x00E58760: CBNZ x19, #0xe58768        | if (prefix != null) goto label_17;      
            if(prefix != null)
            {
                goto label_17;
            }
            // 0x00E58764: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_17:
            // 0x00E58768: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E5876C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E58770: LDR x19, [x19, #0x10]      | X19 = prefix.length; //P2               
            // 0x00E58774: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x00E58778: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x00E5877C: TBZ w8, #0, #0xe5878c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00E58780: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E58784: CBNZ w8, #0xe5878c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00E58788: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_19:
            // 0x00E5878C: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x00E58790: LDR x8, [x8, #0xa70]       | X8 = (string**)(1152921509462830080)(".dll");
            // 0x00E58794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58798: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5879C: MOV x1, x19                | X1 = prefix.length;//m1                 
            // 0x00E587A0: LDR x2, [x8]               | X2 = ".dll";                            
            // 0x00E587A4: BL #0x18a3e88              | X0 = System.String.Concat(str0:  0, str1:  prefix.length);
            string val_10 = System.String.Concat(str0:  0, str1:  prefix.length);
            // 0x00E587A8: MOV x1, x20                | X1 = val_9;//m1                         
            // 0x00E587AC: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00E587B0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00E587B4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00E587B8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00E587BC: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x00E587C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E587C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E587C8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00E587CC: B #0x1e6ccac               | return System.IO.Path.Combine(path1:  0, path2:  val_9);
            return System.IO.Path.Combine(path1:  0, path2:  val_9);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E587D0 (15042512), len: 56  VirtAddr: 0x00E587D0 RVA: 0x00E587D0 token: 100663745 methodIndex: 19338 delegateWrapperIndex: 0 methodInvoker: 0
        public void Dispose()
        {
            //
            // Disasemble & Code
            // 0x00E587D0: STP x20, x19, [sp, #-0x20]! | stack[1152921509464824416] = ???;  stack[1152921509464824424] = ???;  //  dest_result_addr=1152921509464824416 |  dest_result_addr=1152921509464824424
            // 0x00E587D4: STP x29, x30, [sp, #0x10]  | stack[1152921509464824432] = ???;  stack[1152921509464824440] = ???;  //  dest_result_addr=1152921509464824432 |  dest_result_addr=1152921509464824440
            // 0x00E587D8: ADD x29, sp, #0x10         | X29 = (1152921509464824416 + 16) = 1152921509464824432 (0x10000001218EDA70);
            // 0x00E587DC: MOV x19, x0                | X19 = 1152921509464836448 (0x10000001218F0960);//ML01
            // 0x00E587E0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E587E4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x00E587E8: LDP x9, x2, [x8, #0x1a0]   | X9 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_1A0; X2 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_1A8; //  | 
            // 0x00E587EC: BLR x9                     | X0 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver).__il2cppRuntimeField_1A0();
            // 0x00E587F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E587F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E587F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E587FC: MOV x1, x19                | X1 = 1152921509464836448 (0x10000001218F0960);//ML01
            // 0x00E58800: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E58804: B #0x1c3f8c0               | System.GC.SuppressFinalize(obj:  0); return;
            System.GC.SuppressFinalize(obj:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58808 (15042568), len: 4  VirtAddr: 0x00E58808 RVA: 0x00E58808 token: 100663746 methodIndex: 19339 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void Dispose(bool disposing)
        {
            //
            // Disasemble & Code
            // 0x00E58808: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E5880C (15042572), len: 184  VirtAddr: 0x00E5880C RVA: 0x00E5880C token: 100663747 methodIndex: 19340 delegateWrapperIndex: 0 methodInvoker: 0
        private static BaseAssemblyResolver()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00E5880C: STP x20, x19, [sp, #-0x20]! | stack[1152921509465056704] = ???;  stack[1152921509465056712] = ???;  //  dest_result_addr=1152921509465056704 |  dest_result_addr=1152921509465056712
            // 0x00E58810: STP x29, x30, [sp, #0x10]  | stack[1152921509465056720] = ???;  stack[1152921509465056728] = ???;  //  dest_result_addr=1152921509465056720 |  dest_result_addr=1152921509465056728
            // 0x00E58814: ADD x29, sp, #0x10         | X29 = (1152921509465056704 + 16) = 1152921509465056720 (0x10000001219265D0);
            // 0x00E58818: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E5881C: LDRB w8, [x19, #0xad2]     | W8 = (bool)static_value_03734AD2;       
            // 0x00E58820: TBNZ w8, #0, #0xe5883c     | if (static_value_03734AD2 == true) goto label_0;
            // 0x00E58824: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x00E58828: LDR x8, [x8, #0x850]       | X8 = 0x2B8EFE8;                         
            // 0x00E5882C: LDR w0, [x8]               | W0 = 0x12BC;                            
            // 0x00E58830: BL #0x2782188              | X0 = sub_2782188( ?? 0x12BC, ????);     
            // 0x00E58834: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58838: STRB w8, [x19, #0xad2]     | static_value_03734AD2 = true;            //  dest_result_addr=57887442
            label_0:
            // 0x00E5883C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00E58840: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00E58844: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00E58848: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00E5884C: TBZ w8, #0, #0xe5885c      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E58850: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00E58854: CBNZ w8, #0xe5885c         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E58858: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00E5885C: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x00E58860: LDR x8, [x8, #0x4a8]       | X8 = (string**)(1152921509465036448)("Mono.Runtime");
            // 0x00E58864: ADRP x1, #0x2a98000        | X1 = 44662784 (0x2A98000);              
            // 0x00E58868: ADD x1, x1, #0x4b5         | X1 = (44662784 + 1205) = 44663989 (0x02A984B5);
            // 0x00E5886C: LDR x19, [x8]              | X19 = "Mono.Runtime";                   
            // 0x00E58870: MOV x0, x19                | X0 = 1152921509465036448 (0x10000001219216A0);//ML01
            // 0x00E58874: BL #0x27a49f0              | X0 = sub_27A49F0( ?? "Mono.Runtime", ????);
            // 0x00E58878: MOV x1, x0                 | X1 = 1152921509465036448 (0x10000001219216A0);//ML01
            // 0x00E5887C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58880: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58884: BL #0x1b56ddc              | X0 = System.Type.GetType(typeName:  0); 
            System.Type val_1 = System.Type.GetType(typeName:  0);
            // 0x00E58888: CBNZ x0, #0xe5889c         | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00E5888C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58894: MOV x1, x19                | X1 = 1152921509465036448 (0x10000001219216A0);//ML01
            // 0x00E58898: BL #0x1b56ddc              | X0 = System.Type.GetType(typeName:  0); 
            System.Type val_2 = System.Type.GetType(typeName:  0);
            label_3:
            // 0x00E5889C: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x00E588A0: LDR x8, [x8, #0xbe8]       | X8 = 1152921504738156544;               
            // 0x00E588A4: CMP x0, #0                 | STATE = COMPARE(val_2, 0x0)             
            // 0x00E588A8: CSET w9, ne                | W9 = val_2 != null ? 1 : 0;             
            bool val_3 = (val_2 != 0) ? 1 : 0;
            // 0x00E588AC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Mono.Cecil.BaseAssemblyResolver);
            // 0x00E588B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Mono.Cecil.BaseAssemblyResolver.__il2cppRuntimeField_static_fields;
            // 0x00E588B4: STRB w9, [x8]              | ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono = val_2 != null ? 1 : 0;  //  dest_result_addr=1152921504738160640
            ILRuntime.Mono.Cecil.BaseAssemblyResolver.on_mono = val_3;
            // 0x00E588B8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E588BC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E588C0: RET                        |  return;                                
            return;
        
        }
    
    }

}
