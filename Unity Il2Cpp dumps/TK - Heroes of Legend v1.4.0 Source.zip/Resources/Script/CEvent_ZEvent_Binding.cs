using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CEvent_ZEvent_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0143811C (21201180), len: 8  VirtAddr: 0x0143811C RVA: 0x0143811C token: 100664195 methodIndex: 30242 delegateWrapperIndex: 0 methodInvoker: 0
        public CEvent_ZEvent_Binding()
        {
            //
            // Disasemble & Code
            // 0x0143811C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438120: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01438124 (21201188), len: 3424  VirtAddr: 0x01438124 RVA: 0x01438124 token: 100664196 methodIndex: 30243 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_40;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_41;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_42;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_43;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_44;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_45;
            // 0x01438124: STP x28, x27, [sp, #-0x60]! | stack[1152921510117657216] = ???;  stack[1152921510117657224] = ???;  //  dest_result_addr=1152921510117657216 |  dest_result_addr=1152921510117657224
            // 0x01438128: STP x26, x25, [sp, #0x10]  | stack[1152921510117657232] = ???;  stack[1152921510117657240] = ???;  //  dest_result_addr=1152921510117657232 |  dest_result_addr=1152921510117657240
            // 0x0143812C: STP x24, x23, [sp, #0x20]  | stack[1152921510117657248] = ???;  stack[1152921510117657256] = ???;  //  dest_result_addr=1152921510117657248 |  dest_result_addr=1152921510117657256
            // 0x01438130: STP x22, x21, [sp, #0x30]  | stack[1152921510117657264] = ???;  stack[1152921510117657272] = ???;  //  dest_result_addr=1152921510117657264 |  dest_result_addr=1152921510117657272
            // 0x01438134: STP x20, x19, [sp, #0x40]  | stack[1152921510117657280] = ???;  stack[1152921510117657288] = ???;  //  dest_result_addr=1152921510117657280 |  dest_result_addr=1152921510117657288
            // 0x01438138: STP x29, x30, [sp, #0x50]  | stack[1152921510117657296] = ???;  stack[1152921510117657304] = ???;  //  dest_result_addr=1152921510117657296 |  dest_result_addr=1152921510117657304
            // 0x0143813C: ADD x29, sp, #0x50         | X29 = (1152921510117657216 + 80) = 1152921510117657296 (0x1000000148784AD0);
            // 0x01438140: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01438144: LDRB w8, [x20, #0x60]      | W8 = (bool)static_value_03737060;       
            // 0x01438148: MOV x19, x1                | X19 = X1;//m1                           
            // 0x0143814C: TBNZ w8, #0, #0x1438168    | if (static_value_03737060 == true) goto label_0;
            // 0x01438150: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x01438154: LDR x8, [x8, #0x318]       | X8 = 0x2B904FC;                         
            // 0x01438158: LDR w0, [x8]               | W0 = 0x1803;                            
            // 0x0143815C: BL #0x2782188              | X0 = sub_2782188( ?? 0x1803, ????);     
            // 0x01438160: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01438164: STRB w8, [x20, #0x60]      | static_value_03737060 = true;            //  dest_result_addr=57897056
            label_0:
            // 0x01438168: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x0143816C: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x01438170: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x01438174: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x01438178: LDR x8, [x8, #0x668]       | X8 = 1152921504898326528;               
            // 0x0143817C: LDR x20, [x8]              | X20 = typeof(CEvent.ZEvent);            
            // 0x01438180: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01438184: TBZ w8, #0, #0x1438194     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01438188: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143818C: CBNZ w8, #0x1438194        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01438190: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01438194: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438198: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143819C: MOV x1, x20                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x014381A0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014381A4: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x014381A8: CBNZ x20, #0x14381b0       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x014381AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x014381B0: ADRP x9, #0x3610000        | X9 = 56688640 (0x3610000);              
            // 0x014381B4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014381B8: LDR x9, [x9, #0x940]       | X9 = (string**)(1152921510117562048)("args");
            // 0x014381BC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014381C0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014381C4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014381C8: LDR x1, [x9]               | X1 = "args";                            
            // 0x014381CC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014381D0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014381D4: ADRP x24, #0x366e000       | X24 = 57073664 (0x366E000);             
            // 0x014381D8: LDR x24, [x24, #0x920]     | X24 = 1152921504783790080;              
            // 0x014381DC: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014381E0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014381E4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014381E8: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache0;
            val_32 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache0;
            // 0x014381EC: CBNZ x22, #0x1438238       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_32 != null)
            {
                goto label_4;
            }
            // 0x014381F0: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x014381F4: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x014381F8: LDR x8, [x8, #0x860]       | X8 = 1152921510117562128;               
            // 0x014381FC: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01438200: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_args_0(ref object o);
            // 0x01438204: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x01438208: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143820C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438210: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438214: MOV x2, x22                | X2 = 1152921510117562128 (0x100000014876D710);//ML01
            // 0x01438218: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_33 = val_2;
            // 0x0143821C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_args_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_args_0(ref object o));
            // 0x01438220: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438224: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438228: STR x23, [x8]              | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783794176
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache0 = val_33;
            // 0x0143822C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438230: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438234: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_32 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache0;
            label_4:
            // 0x01438238: CBNZ x19, #0x1438240       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x0143823C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_args_0(ref object o)), ????);
            label_5:
            // 0x01438240: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438244: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438248: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143824C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01438250: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            // 0x01438254: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438258: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143825C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache1;
            val_34 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache1;
            // 0x01438260: CBNZ x22, #0x14382ac       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_34 != null)
            {
                goto label_6;
            }
            // 0x01438264: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x01438268: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x0143826C: LDR x8, [x8, #0xfd0]       | X8 = 1152921510117563152;               
            // 0x01438270: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01438274: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_args_0(ref object o, object v);
            // 0x01438278: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x0143827C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01438280: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438284: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438288: MOV x2, x22                | X2 = 1152921510117563152 (0x100000014876DB10);//ML01
            // 0x0143828C: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_33 = val_3;
            // 0x01438290: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_args_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_args_0(ref object o, object v));
            // 0x01438294: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438298: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143829C: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783794184
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache1 = val_33;
            // 0x014382A0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014382A4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014382A8: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_34 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache1;
            label_6:
            // 0x014382AC: CBNZ x19, #0x14382b4       | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x014382B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_args_0(ref object o, object v)), ????);
            label_7:
            // 0x014382B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014382B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014382BC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014382C0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014382C4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_34);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_34);
            // 0x014382C8: CBNZ x20, #0x14382d0       | if (val_1 != null) goto label_8;        
            if(val_1 != null)
            {
                goto label_8;
            }
            // 0x014382CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_8:
            // 0x014382D0: ADRP x9, #0x35df000        | X9 = 56487936 (0x35DF000);              
            // 0x014382D4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014382D8: LDR x9, [x9, #0x9d8]       | X9 = (string**)(1152921510117564176)("arg");
            // 0x014382DC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014382E0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014382E4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x014382E8: LDR x1, [x9]               | X1 = "arg";                             
            // 0x014382EC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x014382F0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x014382F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014382F8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x014382FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438300: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache2;
            val_35 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache2;
            // 0x01438304: CBNZ x22, #0x1438350       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache2 != null) goto label_9;
            if(val_35 != null)
            {
                goto label_9;
            }
            // 0x01438308: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x0143830C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01438310: LDR x8, [x8, #0xd00]       | X8 = 1152921510117564256;               
            // 0x01438314: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01438318: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg_1(ref object o);
            // 0x0143831C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4 = null;
            // 0x01438320: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01438324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438328: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143832C: MOV x2, x22                | X2 = 1152921510117564256 (0x100000014876DF60);//ML01
            // 0x01438330: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_33 = val_4;
            // 0x01438334: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg_1(ref object o));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg_1(ref object o));
            // 0x01438338: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x0143833C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438340: STR x23, [x8, #0x10]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783794192
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache2 = val_33;
            // 0x01438344: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438348: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143834C: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_35 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache2;
            label_9:
            // 0x01438350: CBNZ x19, #0x1438358       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01438354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg_1(ref object o)), ????);
            label_10:
            // 0x01438358: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143835C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438360: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01438364: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01438368: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_35);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_35);
            // 0x0143836C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438370: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438374: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache3;
            val_36 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache3;
            // 0x01438378: CBNZ x22, #0x14383c4       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache3 != null) goto label_11;
            if(val_36 != null)
            {
                goto label_11;
            }
            // 0x0143837C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x01438380: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01438384: LDR x8, [x8, #0x4a8]       | X8 = 1152921510117565280;               
            // 0x01438388: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x0143838C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg_1(ref object o, object v);
            // 0x01438390: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_5 = null;
            // 0x01438394: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01438398: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143839C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014383A0: MOV x2, x22                | X2 = 1152921510117565280 (0x100000014876E360);//ML01
            // 0x014383A4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_33 = val_5;
            // 0x014383A8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg_1(ref object o, object v));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg_1(ref object o, object v));
            // 0x014383AC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014383B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014383B4: STR x23, [x8, #0x18]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783794200
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache3 = val_33;
            // 0x014383B8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014383BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014383C0: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_36 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache3;
            label_11:
            // 0x014383C4: CBNZ x19, #0x14383cc       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x014383C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg_1(ref object o, object v)), ????);
            label_12:
            // 0x014383CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014383D0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014383D4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014383D8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014383DC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_36);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_36);
            // 0x014383E0: CBNZ x20, #0x14383e8       | if (val_1 != null) goto label_13;       
            if(val_1 != null)
            {
                goto label_13;
            }
            // 0x014383E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_13:
            // 0x014383E8: ADRP x9, #0x3664000        | X9 = 57032704 (0x3664000);              
            // 0x014383EC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x014383F0: LDR x9, [x9, #0x3b0]       | X9 = (string**)(1152921510117566304)("arg1");
            // 0x014383F4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x014383F8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014383FC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01438400: LDR x1, [x9]               | X1 = "arg1";                            
            // 0x01438404: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01438408: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x0143840C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438410: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01438414: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438418: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache4;
            val_37 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache4;
            // 0x0143841C: CBNZ x22, #0x1438468       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache4 != null) goto label_14;
            if(val_37 != null)
            {
                goto label_14;
            }
            // 0x01438420: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01438424: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01438428: LDR x8, [x8, #0xc98]       | X8 = 1152921510117566384;               
            // 0x0143842C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01438430: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg1_2(ref object o);
            // 0x01438434: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_6 = null;
            // 0x01438438: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x0143843C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438440: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438444: MOV x2, x22                | X2 = 1152921510117566384 (0x100000014876E7B0);//ML01
            // 0x01438448: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_33 = val_6;
            // 0x0143844C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg1_2(ref object o));
            val_6 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg1_2(ref object o));
            // 0x01438450: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438454: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438458: STR x23, [x8, #0x20]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783794208
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache4 = val_33;
            // 0x0143845C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438460: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438464: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_37 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache4;
            label_14:
            // 0x01438468: CBNZ x19, #0x1438470       | if (X1 != 0) goto label_15;             
            if(X1 != 0)
            {
                goto label_15;
            }
            // 0x0143846C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg1_2(ref object o)), ????);
            label_15:
            // 0x01438470: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438474: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438478: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x0143847C: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01438480: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_37);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_37);
            // 0x01438484: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438488: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143848C: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache5;
            val_38 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache5;
            // 0x01438490: CBNZ x22, #0x14384dc       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache5 != null) goto label_16;
            if(val_38 != null)
            {
                goto label_16;
            }
            // 0x01438494: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01438498: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x0143849C: LDR x8, [x8, #0x8f8]       | X8 = 1152921510117567408;               
            // 0x014384A0: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x014384A4: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg1_2(ref object o, object v);
            // 0x014384A8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_7 = null;
            // 0x014384AC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x014384B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014384B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014384B8: MOV x2, x22                | X2 = 1152921510117567408 (0x100000014876EBB0);//ML01
            // 0x014384BC: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_33 = val_7;
            // 0x014384C0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg1_2(ref object o, object v));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg1_2(ref object o, object v));
            // 0x014384C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014384C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014384CC: STR x23, [x8, #0x28]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783794216
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache5 = val_33;
            // 0x014384D0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014384D4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014384D8: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_38 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache5;
            label_16:
            // 0x014384DC: CBNZ x19, #0x14384e4       | if (X1 != 0) goto label_17;             
            if(X1 != 0)
            {
                goto label_17;
            }
            // 0x014384E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg1_2(ref object o, object v)), ????);
            label_17:
            // 0x014384E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014384E8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014384EC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x014384F0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x014384F4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_38);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_38);
            // 0x014384F8: CBNZ x20, #0x1438500       | if (val_1 != null) goto label_18;       
            if(val_1 != null)
            {
                goto label_18;
            }
            // 0x014384FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_18:
            // 0x01438500: ADRP x9, #0x363a000        | X9 = 56860672 (0x363A000);              
            // 0x01438504: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01438508: LDR x9, [x9, #0x570]       | X9 = (string**)(1152921510117568432)("arg2");
            // 0x0143850C: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01438510: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01438514: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01438518: LDR x1, [x9]               | X1 = "arg2";                            
            // 0x0143851C: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01438520: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01438524: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438528: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x0143852C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438530: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache6;
            val_39 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache6;
            // 0x01438534: CBNZ x22, #0x1438580       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache6 != null) goto label_19;
            if(val_39 != null)
            {
                goto label_19;
            }
            // 0x01438538: ADRP x8, #0x366a000        | X8 = 57057280 (0x366A000);              
            // 0x0143853C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01438540: LDR x8, [x8, #0x9a0]       | X8 = 1152921510117568512;               
            // 0x01438544: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01438548: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg2_3(ref object o);
            // 0x0143854C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8 = null;
            // 0x01438550: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01438554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438558: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143855C: MOV x2, x22                | X2 = 1152921510117568512 (0x100000014876F000);//ML01
            // 0x01438560: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_33 = val_8;
            // 0x01438564: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg2_3(ref object o));
            val_8 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg2_3(ref object o));
            // 0x01438568: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x0143856C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438570: STR x23, [x8, #0x30]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783794224
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache6 = val_33;
            // 0x01438574: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438578: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x0143857C: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_39 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache6;
            label_19:
            // 0x01438580: CBNZ x19, #0x1438588       | if (X1 != 0) goto label_20;             
            if(X1 != 0)
            {
                goto label_20;
            }
            // 0x01438584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::get_arg2_3(ref object o)), ????);
            label_20:
            // 0x01438588: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143858C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438590: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01438594: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01438598: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_39);
            // 0x0143859C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014385A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014385A4: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache7;
            val_40 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache7;
            // 0x014385A8: CBNZ x22, #0x14385f4       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache7 != null) goto label_21;
            if(val_40 != null)
            {
                goto label_21;
            }
            // 0x014385AC: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x014385B0: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x014385B4: LDR x8, [x8, #0xb60]       | X8 = 1152921510117569536;               
            // 0x014385B8: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x014385BC: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg2_3(ref object o, object v);
            // 0x014385C0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_9 = null;
            // 0x014385C4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x014385C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014385CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014385D0: MOV x2, x22                | X2 = 1152921510117569536 (0x100000014876F400);//ML01
            // 0x014385D4: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_33 = val_9;
            // 0x014385D8: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg2_3(ref object o, object v));
            val_9 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg2_3(ref object o, object v));
            // 0x014385DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014385E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014385E4: STR x23, [x8, #0x38]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783794232
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache7 = val_33;
            // 0x014385E8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014385EC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014385F0: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_40 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache7;
            label_21:
            // 0x014385F4: CBNZ x19, #0x14385fc       | if (X1 != 0) goto label_22;             
            if(X1 != 0)
            {
                goto label_22;
            }
            // 0x014385F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::set_arg2_3(ref object o, object v)), ????);
            label_22:
            // 0x014385FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438600: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438604: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01438608: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x0143860C: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_40);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_40);
            // 0x01438610: ADRP x26, #0x35ef000       | X26 = 56553472 (0x35EF000);             
            // 0x01438614: LDR x26, [x26, #0xff0]     | X26 = 1152921504987155056;              
            // 0x01438618: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x0143861C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438620: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01438624: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01438628: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143862C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01438630: ADRP x27, #0x3607000       | X27 = 56651776 (0x3607000);             
            // 0x01438634: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01438638: LDR x27, [x27, #0xbb8]     | X27 = 1152921504608284672;              
            // 0x0143863C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438640: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01438644: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01438648: TBZ w9, #0, #0x143865c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_24;
            // 0x0143864C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01438650: CBNZ w9, #0x143865c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_24;
            // 0x01438654: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01438658: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_24:
            // 0x0143865C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438660: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438664: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01438668: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_10 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143866C: MOV x22, x0                | X22 = val_10;//m1                       
            // 0x01438670: CBNZ x21, #0x1438678       | if ( != null) goto label_25;            
            if(null != null)
            {
                goto label_25;
            }
            // 0x01438674: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_25:
            // 0x01438678: CBZ x22, #0x143869c        | if (val_10 == null) goto label_27;      
            if(val_10 == null)
            {
                goto label_27;
            }
            // 0x0143867C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438680: MOV x0, x22                | X0 = val_10;//m1                        
            // 0x01438684: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438688: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_10, ????);     
            // 0x0143868C: CBNZ x0, #0x143869c        | if (val_10 != null) goto label_27;      
            if(val_10 != null)
            {
                goto label_27;
            }
            // 0x01438690: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_10, ????);     
            // 0x01438694: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438698: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_27:
            // 0x0143869C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014386A0: CBNZ w8, #0x14386b0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_28;
            // 0x014386A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_10, ????);     
            // 0x014386A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014386AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_10, ????);     
            label_28:
            // 0x014386B0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_10;
            // 0x014386B4: CBNZ x20, #0x14386bc       | if (val_1 != null) goto label_29;       
            if(val_1 != null)
            {
                goto label_29;
            }
            // 0x014386B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_29:
            // 0x014386BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014386C0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014386C4: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x014386C8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x014386CC: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014386D0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x014386D4: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_11 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x014386D8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014386DC: MOV x21, x0                | X21 = val_11;//m1                       
            // 0x014386E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014386E4: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache8;
            val_41 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache8;
            // 0x014386E8: CBNZ x22, #0x1438734       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache8 != null) goto label_30;
            if(val_41 != null)
            {
                goto label_30;
            }
            // 0x014386EC: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x014386F0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x014386F4: LDR x8, [x8, #0x990]       | X8 = 1152921510117578752;               
            // 0x014386F8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x014386FC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01438700: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_12 = null;
            // 0x01438704: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01438708: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143870C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438710: MOV x2, x22                | X2 = 1152921510117578752 (0x1000000148771800);//ML01
            // 0x01438714: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_12;
            // 0x01438718: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_12 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x0143871C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438720: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438724: STR x23, [x8, #0x40]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783794240
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache8 = val_33;
            // 0x01438728: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x0143872C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438730: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_41 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache8;
            label_30:
            // 0x01438734: CBNZ x19, #0x143873c       | if (X1 != 0) goto label_31;             
            if(X1 != 0)
            {
                goto label_31;
            }
            // 0x01438738: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_31:
            // 0x0143873C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438740: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438744: MOV x1, x21                | X1 = val_11;//m1                        
            // 0x01438748: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x0143874C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_11, func:  val_41);
            X1.RegisterCLRMethodRedirection(mi:  val_11, func:  val_41);
            // 0x01438750: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01438754: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438758: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x0143875C: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x01438760: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438764: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01438768: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x0143876C: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01438770: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438774: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01438778: TBZ w9, #0, #0x143878c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_33;
            // 0x0143877C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01438780: CBNZ w9, #0x143878c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_33;
            // 0x01438784: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01438788: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_33:
            // 0x0143878C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438790: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438794: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01438798: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143879C: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x014387A0: CBNZ x21, #0x14387a8       | if ( != null) goto label_34;            
            if(null != null)
            {
                goto label_34;
            }
            // 0x014387A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_34:
            // 0x014387A8: CBZ x22, #0x14387cc        | if (val_13 == null) goto label_36;      
            if(val_13 == null)
            {
                goto label_36;
            }
            // 0x014387AC: LDR x8, [x21]              | X8 = ;                                  
            // 0x014387B0: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x014387B4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014387B8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x014387BC: CBNZ x0, #0x14387cc        | if (val_13 != null) goto label_36;      
            if(val_13 != null)
            {
                goto label_36;
            }
            // 0x014387C0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x014387C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014387C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_36:
            // 0x014387CC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014387D0: CBNZ w8, #0x14387e0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_37;
            // 0x014387D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x014387D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014387DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_37:
            // 0x014387E0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_13;
            // 0x014387E4: ADRP x28, #0x363f000       | X28 = 56881152 (0x363F000);             
            // 0x014387E8: LDR x28, [x28, #0xa88]     | X28 = 1152921504606900224;              
            // 0x014387EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014387F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014387F4: LDR x1, [x28]              | X1 = typeof(System.Object);             
            // 0x014387F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_14 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014387FC: MOV x22, x0                | X22 = val_14;//m1                       
            // 0x01438800: CBZ x22, #0x1438824        | if (val_14 == null) goto label_39;      
            if(val_14 == null)
            {
                goto label_39;
            }
            // 0x01438804: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438808: MOV x0, x22                | X0 = val_14;//m1                        
            // 0x0143880C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438810: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_14, ????);     
            // 0x01438814: CBNZ x0, #0x1438824        | if (val_14 != null) goto label_39;      
            if(val_14 != null)
            {
                goto label_39;
            }
            // 0x01438818: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_14, ????);     
            // 0x0143881C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438820: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_39:
            // 0x01438824: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438828: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x0143882C: B.HI #0x143883c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_40;
            // 0x01438830: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_14, ????);     
            // 0x01438834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438838: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            label_40:
            // 0x0143883C: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_14;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_14;
            // 0x01438840: CBNZ x20, #0x1438848       | if (val_1 != null) goto label_41;       
            if(val_1 != null)
            {
                goto label_41;
            }
            // 0x01438844: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_41:
            // 0x01438848: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143884C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01438850: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x01438854: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01438858: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x0143885C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01438860: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_15 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01438864: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438868: MOV x21, x0                | X21 = val_15;//m1                       
            // 0x0143886C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438870: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache9;
            val_42 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache9;
            // 0x01438874: CBNZ x22, #0x14388c0       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache9 != null) goto label_42;
            if(val_42 != null)
            {
                goto label_42;
            }
            // 0x01438878: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x0143887C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01438880: LDR x8, [x8, #0x288]       | X8 = 1152921510117592064;               
            // 0x01438884: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01438888: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x0143888C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_16 = null;
            // 0x01438890: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01438894: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438898: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143889C: MOV x2, x22                | X2 = 1152921510117592064 (0x1000000148774C00);//ML01
            // 0x014388A0: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_16;
            // 0x014388A4: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_16 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x014388A8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014388AC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014388B0: STR x23, [x8, #0x48]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783794248
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache9 = val_33;
            // 0x014388B4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x014388B8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x014388BC: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_42 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cache9;
            label_42:
            // 0x014388C0: CBNZ x19, #0x14388c8       | if (X1 != 0) goto label_43;             
            if(X1 != 0)
            {
                goto label_43;
            }
            // 0x014388C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_43:
            // 0x014388C8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014388CC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x014388D0: MOV x1, x21                | X1 = val_15;//m1                        
            // 0x014388D4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x014388D8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_15, func:  val_42);
            X1.RegisterCLRMethodRedirection(mi:  val_15, func:  val_42);
            // 0x014388DC: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x014388E0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014388E4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x014388E8: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x014388EC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x014388F0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x014388F4: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x014388F8: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x014388FC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438900: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01438904: TBZ w9, #0, #0x1438918     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_45;
            // 0x01438908: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143890C: CBNZ w9, #0x1438918        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
            // 0x01438910: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01438914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_45:
            // 0x01438918: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143891C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438920: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01438924: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_17 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438928: MOV x22, x0                | X22 = val_17;//m1                       
            // 0x0143892C: CBNZ x21, #0x1438934       | if ( != null) goto label_46;            
            if(null != null)
            {
                goto label_46;
            }
            // 0x01438930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            label_46:
            // 0x01438934: CBZ x22, #0x1438958        | if (val_17 == null) goto label_48;      
            if(val_17 == null)
            {
                goto label_48;
            }
            // 0x01438938: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143893C: MOV x0, x22                | X0 = val_17;//m1                        
            // 0x01438940: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438944: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x01438948: CBNZ x0, #0x1438958        | if (val_17 != null) goto label_48;      
            if(val_17 != null)
            {
                goto label_48;
            }
            // 0x0143894C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_17, ????);     
            // 0x01438950: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438954: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_48:
            // 0x01438958: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x0143895C: CBNZ w8, #0x143896c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_49;
            // 0x01438960: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_17, ????);     
            // 0x01438964: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438968: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_17, ????);     
            label_49:
            // 0x0143896C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_17;
            // 0x01438970: LDR x1, [x28]              | X1 = typeof(System.Object);             
            // 0x01438974: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438978: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143897C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_18 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438980: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x01438984: CBZ x22, #0x14389a8        | if (val_18 == null) goto label_51;      
            if(val_18 == null)
            {
                goto label_51;
            }
            // 0x01438988: LDR x8, [x21]              | X8 = ;                                  
            // 0x0143898C: MOV x0, x22                | X0 = val_18;//m1                        
            // 0x01438990: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438994: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_18, ????);     
            // 0x01438998: CBNZ x0, #0x14389a8        | if (val_18 != null) goto label_51;      
            if(val_18 != null)
            {
                goto label_51;
            }
            // 0x0143899C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_18, ????);     
            // 0x014389A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014389A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_51:
            // 0x014389A8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x014389AC: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x014389B0: B.HI #0x14389c0            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_52;
            // 0x014389B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x014389B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014389BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_52:
            // 0x014389C0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_18;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_18;
            // 0x014389C4: LDR x1, [x28]              | X1 = typeof(System.Object);             
            // 0x014389C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014389CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x014389D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x014389D4: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x014389D8: CBZ x22, #0x14389fc        | if (val_19 == null) goto label_54;      
            if(val_19 == null)
            {
                goto label_54;
            }
            // 0x014389DC: LDR x8, [x21]              | X8 = ;                                  
            // 0x014389E0: MOV x0, x22                | X0 = val_19;//m1                        
            // 0x014389E4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x014389E8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x014389EC: CBNZ x0, #0x14389fc        | if (val_19 != null) goto label_54;      
            if(val_19 != null)
            {
                goto label_54;
            }
            // 0x014389F0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x014389F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014389F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_54:
            // 0x014389FC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438A00: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x01438A04: B.HI #0x1438a14            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_55;
            // 0x01438A08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x01438A0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438A10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_55:
            // 0x01438A14: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_19;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_19;
            // 0x01438A18: CBNZ x20, #0x1438a20       | if (val_1 != null) goto label_56;       
            if(val_1 != null)
            {
                goto label_56;
            }
            // 0x01438A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_19, ????);     
            label_56:
            // 0x01438A20: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438A24: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01438A28: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x01438A2C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01438A30: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438A34: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01438A38: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_20 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01438A3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438A40: MOV x21, x0                | X21 = val_20;//m1                       
            // 0x01438A44: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438A48: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheA;
            val_43 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheA;
            // 0x01438A4C: CBNZ x22, #0x1438a98       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheA != null) goto label_57;
            if(val_43 != null)
            {
                goto label_57;
            }
            // 0x01438A50: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01438A54: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01438A58: LDR x8, [x8, #0xdb0]       | X8 = 1152921510117609472;               
            // 0x01438A5C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01438A60: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01438A64: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_21 = null;
            // 0x01438A68: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01438A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438A70: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438A74: MOV x2, x22                | X2 = 1152921510117609472 (0x1000000148779000);//ML01
            // 0x01438A78: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_21;
            // 0x01438A7C: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_21 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01438A80: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438A84: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438A88: STR x23, [x8, #0x50]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783794256
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheA = val_33;
            // 0x01438A8C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438A90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438A94: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_43 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheA;
            label_57:
            // 0x01438A98: CBNZ x19, #0x1438aa0       | if (X1 != 0) goto label_58;             
            if(X1 != 0)
            {
                goto label_58;
            }
            // 0x01438A9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_58:
            // 0x01438AA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438AA4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438AA8: MOV x1, x21                | X1 = val_20;//m1                        
            // 0x01438AAC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01438AB0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_43);
            X1.RegisterCLRMethodRedirection(mi:  val_20, func:  val_43);
            // 0x01438AB4: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01438AB8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438ABC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01438AC0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x01438AC4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438AC8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01438ACC: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01438AD0: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01438AD4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438AD8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01438ADC: TBZ w9, #0, #0x1438af0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x01438AE0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01438AE4: CBNZ w9, #0x1438af0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x01438AE8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01438AEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_60:
            // 0x01438AF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438AF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438AF8: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01438AFC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_22 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438B00: MOV x22, x0                | X22 = val_22;//m1                       
            // 0x01438B04: CBNZ x21, #0x1438b0c       | if ( != null) goto label_61;            
            if(null != null)
            {
                goto label_61;
            }
            // 0x01438B08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_61:
            // 0x01438B0C: CBZ x22, #0x1438b30        | if (val_22 == null) goto label_63;      
            if(val_22 == null)
            {
                goto label_63;
            }
            // 0x01438B10: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438B14: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x01438B18: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438B1C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_22, ????);     
            // 0x01438B20: CBNZ x0, #0x1438b30        | if (val_22 != null) goto label_63;      
            if(val_22 != null)
            {
                goto label_63;
            }
            // 0x01438B24: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_22, ????);     
            // 0x01438B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438B2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_63:
            // 0x01438B30: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438B34: CBNZ w8, #0x1438b44        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_64;
            // 0x01438B38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_22, ????);     
            // 0x01438B3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438B40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_64:
            // 0x01438B44: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_22;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_22;
            // 0x01438B48: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x01438B4C: LDR x8, [x8, #0x228]       | X8 = 1152921504954501264;               
            // 0x01438B50: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438B54: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438B58: LDR x1, [x8]               | X1 = typeof(System.Object[]);           
            // 0x01438B5C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_23 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438B60: MOV x22, x0                | X22 = val_23;//m1                       
            // 0x01438B64: CBZ x22, #0x1438b88        | if (val_23 == null) goto label_66;      
            if(val_23 == null)
            {
                goto label_66;
            }
            // 0x01438B68: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438B6C: MOV x0, x22                | X0 = val_23;//m1                        
            // 0x01438B70: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438B74: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_23, ????);     
            // 0x01438B78: CBNZ x0, #0x1438b88        | if (val_23 != null) goto label_66;      
            if(val_23 != null)
            {
                goto label_66;
            }
            // 0x01438B7C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_23, ????);     
            // 0x01438B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438B84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_66:
            // 0x01438B88: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438B8C: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x01438B90: B.HI #0x1438ba0            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_67;
            // 0x01438B94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x01438B98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438B9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_67:
            // 0x01438BA0: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_23;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_23;
            // 0x01438BA4: CBNZ x20, #0x1438bac       | if (val_1 != null) goto label_68;       
            if(val_1 != null)
            {
                goto label_68;
            }
            // 0x01438BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_68:
            // 0x01438BAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438BB0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01438BB4: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x01438BB8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01438BBC: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438BC0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01438BC4: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_24 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01438BC8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438BCC: MOV x21, x0                | X21 = val_24;//m1                       
            // 0x01438BD0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438BD4: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheB;
            val_44 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheB;
            // 0x01438BD8: CBNZ x22, #0x1438c24       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheB != null) goto label_69;
            if(val_44 != null)
            {
                goto label_69;
            }
            // 0x01438BDC: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x01438BE0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01438BE4: LDR x8, [x8, #0x3d0]       | X8 = 1152921510117622784;               
            // 0x01438BE8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01438BEC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01438BF0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25 = null;
            // 0x01438BF4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01438BF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438BFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438C00: MOV x2, x22                | X2 = 1152921510117622784 (0x100000014877C400);//ML01
            // 0x01438C04: MOV x23, x0                | X23 = 1152921504823939072 (0x100000000CF09000);//ML01
            val_33 = val_25;
            // 0x01438C08: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_25 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01438C0C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438C10: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438C14: STR x23, [x8, #0x58]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783794264
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheB = val_33;
            // 0x01438C18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438C1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438C20: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_44 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheB;
            label_69:
            // 0x01438C24: CBNZ x19, #0x1438c2c       | if (X1 != 0) goto label_70;             
            if(X1 != 0)
            {
                goto label_70;
            }
            // 0x01438C28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_70:
            // 0x01438C2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438C30: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438C34: MOV x1, x21                | X1 = val_24;//m1                        
            // 0x01438C38: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01438C3C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_44);
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_44);
            // 0x01438C40: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x01438C44: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438C48: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x01438C4C: ORR w1, wzr, #4            | W1 = 4(0x4);                            
            // 0x01438C50: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438C54: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x01438C58: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x01438C5C: LDR x22, [x27]             | X22 = typeof(System.String);            
            // 0x01438C60: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438C64: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01438C68: TBZ w9, #0, #0x1438c7c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_72;
            // 0x01438C6C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01438C70: CBNZ w9, #0x1438c7c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_72;
            // 0x01438C74: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01438C78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_72:
            // 0x01438C7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438C80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438C84: MOV x1, x22                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01438C88: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_26 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438C8C: MOV x22, x0                | X22 = val_26;//m1                       
            // 0x01438C90: CBNZ x21, #0x1438c98       | if ( != null) goto label_73;            
            if(null != null)
            {
                goto label_73;
            }
            // 0x01438C94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_26, ????);     
            label_73:
            // 0x01438C98: CBZ x22, #0x1438cbc        | if (val_26 == null) goto label_75;      
            if(val_26 == null)
            {
                goto label_75;
            }
            // 0x01438C9C: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438CA0: MOV x0, x22                | X0 = val_26;//m1                        
            // 0x01438CA4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438CA8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_26, ????);     
            // 0x01438CAC: CBNZ x0, #0x1438cbc        | if (val_26 != null) goto label_75;      
            if(val_26 != null)
            {
                goto label_75;
            }
            // 0x01438CB0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_26, ????);     
            // 0x01438CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438CB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_75:
            // 0x01438CBC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438CC0: CBNZ w8, #0x1438cd0        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_76;
            // 0x01438CC4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_26, ????);     
            // 0x01438CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438CCC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            label_76:
            // 0x01438CD0: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_26;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_26;
            // 0x01438CD4: LDR x1, [x28]              | X1 = typeof(System.Object);             
            // 0x01438CD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438CDC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438CE0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_27 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438CE4: MOV x22, x0                | X22 = val_27;//m1                       
            // 0x01438CE8: CBZ x22, #0x1438d0c        | if (val_27 == null) goto label_78;      
            if(val_27 == null)
            {
                goto label_78;
            }
            // 0x01438CEC: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438CF0: MOV x0, x22                | X0 = val_27;//m1                        
            // 0x01438CF4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438CF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_27, ????);     
            // 0x01438CFC: CBNZ x0, #0x1438d0c        | if (val_27 != null) goto label_78;      
            if(val_27 != null)
            {
                goto label_78;
            }
            // 0x01438D00: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_27, ????);     
            // 0x01438D04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438D08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_78:
            // 0x01438D0C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438D10: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x01438D14: B.HI #0x1438d24            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_79;
            // 0x01438D18: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_27, ????);     
            // 0x01438D1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438D20: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            label_79:
            // 0x01438D24: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_27;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_27;
            // 0x01438D28: LDR x1, [x28]              | X1 = typeof(System.Object);             
            // 0x01438D2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438D34: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_28 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438D38: MOV x22, x0                | X22 = val_28;//m1                       
            // 0x01438D3C: CBZ x22, #0x1438d60        | if (val_28 == null) goto label_81;      
            if(val_28 == null)
            {
                goto label_81;
            }
            // 0x01438D40: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438D44: MOV x0, x22                | X0 = val_28;//m1                        
            // 0x01438D48: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438D4C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_28, ????);     
            // 0x01438D50: CBNZ x0, #0x1438d60        | if (val_28 != null) goto label_81;      
            if(val_28 != null)
            {
                goto label_81;
            }
            // 0x01438D54: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_28, ????);     
            // 0x01438D58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438D5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_81:
            // 0x01438D60: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438D64: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x01438D68: B.HI #0x1438d78            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_82;
            // 0x01438D6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_28, ????);     
            // 0x01438D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438D74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_28, ????);     
            label_82:
            // 0x01438D78: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_28;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_28;
            // 0x01438D7C: LDR x1, [x28]              | X1 = typeof(System.Object);             
            // 0x01438D80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01438D84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438D88: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_29 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01438D8C: MOV x22, x0                | X22 = val_29;//m1                       
            // 0x01438D90: CBZ x22, #0x1438db4        | if (val_29 == null) goto label_84;      
            if(val_29 == null)
            {
                goto label_84;
            }
            // 0x01438D94: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438D98: MOV x0, x22                | X0 = val_29;//m1                        
            // 0x01438D9C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01438DA0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_29, ????);     
            // 0x01438DA4: CBNZ x0, #0x1438db4        | if (val_29 != null) goto label_84;      
            if(val_29 != null)
            {
                goto label_84;
            }
            // 0x01438DA8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_29, ????);     
            // 0x01438DAC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438DB0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            label_84:
            // 0x01438DB4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x01438DB8: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x01438DBC: B.HI #0x1438dcc            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_85;
            // 0x01438DC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_29, ????);     
            // 0x01438DC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438DC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            label_85:
            // 0x01438DCC: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_29;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_29;
            // 0x01438DD0: CBNZ x20, #0x1438dd8       | if (val_1 != null) goto label_86;       
            if(val_1 != null)
            {
                goto label_86;
            }
            // 0x01438DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_29, ????);     
            label_86:
            // 0x01438DD8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01438DDC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01438DE0: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x01438DE4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01438DE8: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x01438DEC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01438DF0: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_30 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x01438DF4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438DF8: MOV x20, x0                | X20 = val_30;//m1                       
            // 0x01438DFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438E00: LDR x21, [x8, #0x60]       | X21 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheC;
            val_45 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheC;
            // 0x01438E04: CBNZ x21, #0x1438e50       | if (ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheC != null) goto label_87;
            if(val_45 != null)
            {
                goto label_87;
            }
            // 0x01438E08: ADRP x8, #0x3675000        | X8 = 57102336 (0x3675000);              
            // 0x01438E0C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x01438E10: LDR x8, [x8, #0x58]        | X8 = 1152921510117644288;               
            // 0x01438E14: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x01438E18: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x01438E1C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_31 = null;
            // 0x01438E20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x01438E24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438E28: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438E2C: MOV x2, x21                | X2 = 1152921510117644288 (0x1000000148781800);//ML01
            // 0x01438E30: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01438E34: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_31 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x01438E38: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438E3C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438E40: STR x22, [x8, #0x60]       | ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504783794272
            ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheC = val_31;
            // 0x01438E44: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding);
            // 0x01438E48: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.__il2cppRuntimeField_static_fields;
            // 0x01438E4C: LDR x21, [x8, #0x60]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_45 = ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding.<>f__mg$cacheC;
            label_87:
            // 0x01438E50: CBNZ x19, #0x1438e58       | if (X1 != 0) goto label_88;             
            if(X1 != 0)
            {
                goto label_88;
            }
            // 0x01438E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.CEvent_ZEvent_Binding::Ctor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_88:
            // 0x01438E58: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01438E5C: MOV x1, x20                | X1 = val_30;//m1                        
            // 0x01438E60: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x01438E64: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01438E68: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01438E6C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01438E70: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01438E74: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01438E78: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01438E7C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01438E80: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_45); return;
            X1.RegisterCLRMethodRedirection(mi:  val_30, func:  val_45);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01438E84 (21204612), len: 288  VirtAddr: 0x01438E84 RVA: 0x01438E84 token: 100664197 methodIndex: 30244 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_args_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01438E84: STP x20, x19, [sp, #-0x20]! | stack[1152921510117851120] = ???;  stack[1152921510117851128] = ???;  //  dest_result_addr=1152921510117851120 |  dest_result_addr=1152921510117851128
            // 0x01438E88: STP x29, x30, [sp, #0x10]  | stack[1152921510117851136] = ???;  stack[1152921510117851144] = ???;  //  dest_result_addr=1152921510117851136 |  dest_result_addr=1152921510117851144
            // 0x01438E8C: ADD x29, sp, #0x10         | X29 = (1152921510117851120 + 16) = 1152921510117851136 (0x10000001487B4000);
            // 0x01438E90: SUB sp, sp, #0x10          | SP = (1152921510117851120 - 16) = 1152921510117851104 (0x10000001487B3FE0);
            // 0x01438E94: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01438E98: LDRB w8, [x20, #0x61]      | W8 = (bool)static_value_03737061;       
            // 0x01438E9C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01438EA0: TBNZ w8, #0, #0x1438ebc    | if (static_value_03737061 == true) goto label_0;
            // 0x01438EA4: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x01438EA8: LDR x8, [x8, #0x4a8]       | X8 = 0x2B904F8;                         
            // 0x01438EAC: LDR w0, [x8]               | W0 = 0x1802;                            
            // 0x01438EB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1802, ????);     
            // 0x01438EB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01438EB8: STRB w8, [x20, #0x61]      | static_value_03737061 = true;            //  dest_result_addr=57897057
            label_0:
            // 0x01438EBC: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x01438EC0: LDR x19, [x19]             | X19 = X1;                               
            // 0x01438EC4: LDR x20, [x20, #0x440]     | X20 = 1152921504898326528;              
            // 0x01438EC8: CBZ x19, #0x1438f1c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01438ECC: LDR x8, [x19]              | X8 = X1;                                
            // 0x01438ED0: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01438ED4: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01438ED8: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01438EDC: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01438EE0: B.LO #0x1438ef8            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01438EE4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01438EE8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01438EEC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01438EF0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01438EF4: B.EQ #0x1438f20            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01438EF8: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01438EFC: MOV x8, sp                 | X8 = 1152921510117851104 (0x10000001487B3FE0);//ML01
            // 0x01438F00: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01438F04: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510117839152]
            // 0x01438F08: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01438F0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438F10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01438F14: MOV x0, sp                 | X0 = 1152921510117851104 (0x10000001487B3FE0);//ML01
            // 0x01438F18: BL #0x299a140              | 
            label_1:
            // 0x01438F1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001487B3FE0, ????);
            label_3:
            // 0x01438F20: LDR x8, [x19]              | X8 = X1;                                
            // 0x01438F24: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01438F28: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01438F2C: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01438F30: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01438F34: B.LO #0x1438f60            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01438F38: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01438F3C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01438F40: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01438F44: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01438F48: B.NE #0x1438f60            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01438F4C: LDR x0, [x19, #0x20]       | X0 = X1 + 32;                           
            // 0x01438F50: SUB sp, x29, #0x10         | SP = (1152921510117851136 - 16) = 1152921510117851120 (0x10000001487B3FF0);
            // 0x01438F54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01438F58: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01438F5C: RET                        |  return (System.Object)X1 + 32;         
            return (object)X1 + 32;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01438F60: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01438F64: ADD x8, sp, #8             | X8 = (1152921510117851104 + 8) = 1152921510117851112 (0x10000001487B3FE8);
            // 0x01438F68: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01438F6C: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510117839152]
            // 0x01438F70: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01438F74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438F78: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01438F7C: ADD x0, sp, #8             | X0 = (1152921510117851104 + 8) = 1152921510117851112 (0x10000001487B3FE8);
            // 0x01438F80: BL #0x299a140              | 
            // 0x01438F84: MOV x19, x0                | X19 = 1152921510117851112 (0x10000001487B3FE8);//ML01
            // 0x01438F88: MOV x0, sp                 | X0 = 1152921510117851104 (0x10000001487B3FE0);//ML01
            label_6:
            // 0x01438F8C: BL #0x299a140              | 
            // 0x01438F90: MOV x0, x19                | X0 = 1152921510117851112 (0x10000001487B3FE8);//ML01
            // 0x01438F94: BL #0x980800               | X0 = sub_980800( ?? 0x10000001487B3FE8, ????);
            // 0x01438F98: MOV x19, x0                | X19 = 1152921510117851112 (0x10000001487B3FE8);//ML01
            // 0x01438F9C: ADD x0, sp, #8             | X0 = (1152921510117851104 + 8) = 1152921510117851112 (0x10000001487B3FE8);
            // 0x01438FA0: B #0x1438f8c               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01438FA4 (21204900), len: 304  VirtAddr: 0x01438FA4 RVA: 0x01438FA4 token: 100664198 methodIndex: 30245 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_args_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x01438FA4: STP x22, x21, [sp, #-0x30]! | stack[1152921510117975232] = ???;  stack[1152921510117975240] = ???;  //  dest_result_addr=1152921510117975232 |  dest_result_addr=1152921510117975240
            // 0x01438FA8: STP x20, x19, [sp, #0x10]  | stack[1152921510117975248] = ???;  stack[1152921510117975256] = ???;  //  dest_result_addr=1152921510117975248 |  dest_result_addr=1152921510117975256
            // 0x01438FAC: STP x29, x30, [sp, #0x20]  | stack[1152921510117975264] = ???;  stack[1152921510117975272] = ???;  //  dest_result_addr=1152921510117975264 |  dest_result_addr=1152921510117975272
            // 0x01438FB0: ADD x29, sp, #0x20         | X29 = (1152921510117975232 + 32) = 1152921510117975264 (0x10000001487D24E0);
            // 0x01438FB4: SUB sp, sp, #0x10          | SP = (1152921510117975232 - 16) = 1152921510117975216 (0x10000001487D24B0);
            // 0x01438FB8: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01438FBC: LDRB w8, [x21, #0x62]      | W8 = (bool)static_value_03737062;       
            // 0x01438FC0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01438FC4: MOV x20, x1                | X20 = v;//m1                            
            // 0x01438FC8: TBNZ w8, #0, #0x1438fe4    | if (static_value_03737062 == true) goto label_0;
            // 0x01438FCC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x01438FD0: LDR x8, [x8, #0xaa8]       | X8 = 0x2B9050C;                         
            // 0x01438FD4: LDR w0, [x8]               | W0 = 0x1807;                            
            // 0x01438FD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1807, ????);     
            // 0x01438FDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01438FE0: STRB w8, [x21, #0x62]      | static_value_03737062 = true;            //  dest_result_addr=57897058
            label_0:
            // 0x01438FE4: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x01438FE8: CBZ x21, #0x1439044        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01438FEC: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x01438FF0: LDR x9, [x9, #0x440]       | X9 = 1152921504898326528;               
            // 0x01438FF4: LDR x8, [x21]              | X8 = ;                                  
            // 0x01438FF8: LDR x1, [x9]               | X1 = typeof(CEvent.ZEvent);             
            // 0x01438FFC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01439000: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439004: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439008: B.LO #0x1439020            | if (mem[null + 260] < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x0143900C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01439010: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439014: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439018: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x0143901C: B.EQ #0x143904c            | if ((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01439020: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01439024: MOV x8, sp                 | X8 = 1152921510117975216 (0x10000001487D24B0);//ML01
            // 0x01439028: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x0143902C: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510117963280]
            // 0x01439030: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01439034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439038: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x0143903C: MOV x0, sp                 | X0 = 1152921510117975216 (0x10000001487D24B0);//ML01
            // 0x01439040: BL #0x299a140              | 
            label_1:
            // 0x01439044: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001487D24B0, ????);
            // 0x01439048: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_4 = 0;
            label_3:
            // 0x0143904C: CBZ x19, #0x1439098        | if (X2 == 0) goto label_4;              
            if(X2 == 0)
            {
                goto label_4;
            }
            // 0x01439050: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01439054: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x01439058: MOV x0, x19                | X0 = X2;//m1                            
            val_5 = X2;
            // 0x0143905C: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x01439060: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01439064: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? X2, ????);         
            // 0x01439068: CBNZ x0, #0x143909c        | if (X2 != 0) goto label_5;              
            if(val_5 != 0)
            {
                goto label_5;
            }
            // 0x0143906C: LDR x8, [x19]              | X8 = X2;                                
            // 0x01439070: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01439074: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01439078: ADD x8, sp, #8             | X8 = (1152921510117975216 + 8) = 1152921510117975224 (0x10000001487D24B8);
            // 0x0143907C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01439080: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921510117963280]
            // 0x01439084: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x01439088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143908C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x01439090: ADD x0, sp, #8             | X0 = (1152921510117975216 + 8) = 1152921510117975224 (0x10000001487D24B8);
            // 0x01439094: BL #0x299a140              | 
            label_4:
            // 0x01439098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_5 = 0;
            label_5:
            // 0x0143909C: STR x0, [x21, #0x20]       | mem[32] = 0x0;                           //  dest_result_addr=32
            mem[32] = val_5;
            // 0x014390A0: SUB sp, x29, #0x20         | SP = (1152921510117975264 - 32) = 1152921510117975232 (0x10000001487D24C0);
            // 0x014390A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x014390A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x014390AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x014390B0: RET                        |  return;                                
            return;
            // 0x014390B4: MOV x19, x0                | 
            // 0x014390B8: MOV x0, sp                 | 
            // 0x014390BC: B #0x14390c8               | 
            // 0x014390C0: MOV x19, x0                | 
            // 0x014390C4: ADD x0, sp, #8             | 
            label_6:
            // 0x014390C8: BL #0x299a140              | 
            // 0x014390CC: MOV x0, x19                | 
            // 0x014390D0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014390D4 (21205204), len: 288  VirtAddr: 0x014390D4 RVA: 0x014390D4 token: 100664199 methodIndex: 30246 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_arg_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014390D4: STP x20, x19, [sp, #-0x20]! | stack[1152921510118099376] = ???;  stack[1152921510118099384] = ???;  //  dest_result_addr=1152921510118099376 |  dest_result_addr=1152921510118099384
            // 0x014390D8: STP x29, x30, [sp, #0x10]  | stack[1152921510118099392] = ???;  stack[1152921510118099400] = ???;  //  dest_result_addr=1152921510118099392 |  dest_result_addr=1152921510118099400
            // 0x014390DC: ADD x29, sp, #0x10         | X29 = (1152921510118099376 + 16) = 1152921510118099392 (0x10000001487F09C0);
            // 0x014390E0: SUB sp, sp, #0x10          | SP = (1152921510118099376 - 16) = 1152921510118099360 (0x10000001487F09A0);
            // 0x014390E4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014390E8: LDRB w8, [x20, #0x63]      | W8 = (bool)static_value_03737063;       
            // 0x014390EC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014390F0: TBNZ w8, #0, #0x143910c    | if (static_value_03737063 == true) goto label_0;
            // 0x014390F4: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x014390F8: LDR x8, [x8, #0xc68]       | X8 = 0x2B904EC;                         
            // 0x014390FC: LDR w0, [x8]               | W0 = 0x17FF;                            
            // 0x01439100: BL #0x2782188              | X0 = sub_2782188( ?? 0x17FF, ????);     
            // 0x01439104: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439108: STRB w8, [x20, #0x63]      | static_value_03737063 = true;            //  dest_result_addr=57897059
            label_0:
            // 0x0143910C: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x01439110: LDR x19, [x19]             | X19 = X1;                               
            // 0x01439114: LDR x20, [x20, #0x440]     | X20 = 1152921504898326528;              
            // 0x01439118: CBZ x19, #0x143916c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x0143911C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01439120: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01439124: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01439128: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143912C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439130: B.LO #0x1439148            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01439134: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01439138: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143913C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439140: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01439144: B.EQ #0x1439170            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01439148: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x0143914C: MOV x8, sp                 | X8 = 1152921510118099360 (0x10000001487F09A0);//ML01
            // 0x01439150: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01439154: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510118087408]
            // 0x01439158: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143915C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439160: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01439164: MOV x0, sp                 | X0 = 1152921510118099360 (0x10000001487F09A0);//ML01
            // 0x01439168: BL #0x299a140              | 
            label_1:
            // 0x0143916C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001487F09A0, ????);
            label_3:
            // 0x01439170: LDR x8, [x19]              | X8 = X1;                                
            // 0x01439174: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01439178: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x0143917C: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439180: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439184: B.LO #0x14391b0            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01439188: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x0143918C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439190: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439194: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01439198: B.NE #0x14391b0            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x0143919C: LDR x0, [x19, #0x28]       | X0 = X1 + 40;                           
            // 0x014391A0: SUB sp, x29, #0x10         | SP = (1152921510118099392 - 16) = 1152921510118099376 (0x10000001487F09B0);
            // 0x014391A4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x014391A8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x014391AC: RET                        |  return (System.Object)X1 + 40;         
            return (object)X1 + 40;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x014391B0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014391B4: ADD x8, sp, #8             | X8 = (1152921510118099360 + 8) = 1152921510118099368 (0x10000001487F09A8);
            // 0x014391B8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014391BC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510118087408]
            // 0x014391C0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014391C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014391C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014391CC: ADD x0, sp, #8             | X0 = (1152921510118099360 + 8) = 1152921510118099368 (0x10000001487F09A8);
            // 0x014391D0: BL #0x299a140              | 
            // 0x014391D4: MOV x19, x0                | X19 = 1152921510118099368 (0x10000001487F09A8);//ML01
            // 0x014391D8: MOV x0, sp                 | X0 = 1152921510118099360 (0x10000001487F09A0);//ML01
            label_6:
            // 0x014391DC: BL #0x299a140              | 
            // 0x014391E0: MOV x0, x19                | X0 = 1152921510118099368 (0x10000001487F09A8);//ML01
            // 0x014391E4: BL #0x980800               | X0 = sub_980800( ?? 0x10000001487F09A8, ????);
            // 0x014391E8: MOV x19, x0                | X19 = 1152921510118099368 (0x10000001487F09A8);//ML01
            // 0x014391EC: ADD x0, sp, #8             | X0 = (1152921510118099360 + 8) = 1152921510118099368 (0x10000001487F09A8);
            // 0x014391F0: B #0x14391dc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014391F4 (21205492), len: 208  VirtAddr: 0x014391F4 RVA: 0x014391F4 token: 100664200 methodIndex: 30247 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_arg_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x014391F4: STP x22, x21, [sp, #-0x30]! | stack[1152921510118223488] = ???;  stack[1152921510118223496] = ???;  //  dest_result_addr=1152921510118223488 |  dest_result_addr=1152921510118223496
            // 0x014391F8: STP x20, x19, [sp, #0x10]  | stack[1152921510118223504] = ???;  stack[1152921510118223512] = ???;  //  dest_result_addr=1152921510118223504 |  dest_result_addr=1152921510118223512
            // 0x014391FC: STP x29, x30, [sp, #0x20]  | stack[1152921510118223520] = ???;  stack[1152921510118223528] = ???;  //  dest_result_addr=1152921510118223520 |  dest_result_addr=1152921510118223528
            // 0x01439200: ADD x29, sp, #0x20         | X29 = (1152921510118223488 + 32) = 1152921510118223520 (0x100000014880EEA0);
            // 0x01439204: SUB sp, sp, #0x10          | SP = (1152921510118223488 - 16) = 1152921510118223472 (0x100000014880EE70);
            // 0x01439208: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0143920C: LDRB w8, [x21, #0x64]      | W8 = (bool)static_value_03737064;       
            // 0x01439210: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01439214: MOV x20, x1                | X20 = v;//m1                            
            // 0x01439218: TBNZ w8, #0, #0x1439234    | if (static_value_03737064 == true) goto label_0;
            // 0x0143921C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x01439220: LDR x8, [x8, #0x1f8]       | X8 = 0x2B90500;                         
            // 0x01439224: LDR w0, [x8]               | W0 = 0x1804;                            
            val_3 = 6148;
            // 0x01439228: BL #0x2782188              | X0 = sub_2782188( ?? 0x1804, ????);     
            // 0x0143922C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439230: STRB w8, [x21, #0x64]      | static_value_03737064 = true;            //  dest_result_addr=57897060
            label_0:
            // 0x01439234: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x01439238: CBZ x8, #0x14392ac         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x0143923C: ADRP x10, #0x3676000       | X10 = 57106432 (0x3676000);             
            // 0x01439240: LDR x10, [x10, #0x440]     | X10 = 1152921504898326528;              
            // 0x01439244: LDR x9, [x8]               | X9 = ;                                  
            // 0x01439248: LDR x1, [x10]              | X1 = typeof(CEvent.ZEvent);             
            // 0x0143924C: LDRB w11, [x9, #0x104]     |  //  not_find_field!1:260
            // 0x01439250: LDRB w10, [x1, #0x104]     | W10 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439254: CMP w11, w10               | STATE = COMPARE(mem[null + 260], CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439258: B.LO #0x1439288            | if (mem[null + 260] < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
            // 0x0143925C: LDR x11, [x9, #0xb0]       |  //  not_find_field!1:176
            // 0x01439260: ADD x10, x11, x10, lsl #3  | X10 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439264: LDUR x10, [x10, #-8]       | X10 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439268: CMP x10, x1                | STATE = COMPARE((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x0143926C: B.NE #0x1439288            | if ((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_3;
            // 0x01439270: STR x19, [x8, #0x28]       | typeof(System.Object).__il2cppRuntimeField_28 = X2;  //  dest_result_addr=1152921504606900264
            typeof(System.Object).__il2cppRuntimeField_28 = X2;
            // 0x01439274: SUB sp, x29, #0x20         | SP = (1152921510118223520 - 32) = 1152921510118223488 (0x100000014880EE80);
            // 0x01439278: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0143927C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01439280: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01439284: RET                        |  return;                                
            return;
            label_3:
            // 0x01439288: LDR x0, [x9, #0x30]        |  //  not_find_field!1:48
            // 0x0143928C: ADD x8, sp, #8             | X8 = (1152921510118223472 + 8) = 1152921510118223480 (0x100000014880EE78);
            // 0x01439290: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01439294: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510118211536]
            // 0x01439298: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143929C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014392A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014392A4: ADD x0, sp, #8             | X0 = (1152921510118223472 + 8) = 1152921510118223480 (0x100000014880EE78);
            // 0x014392A8: BL #0x299a140              | 
            label_1:
            // 0x014392AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014880EE78, ????);
            // 0x014392B0: MOV x19, x0                | X19 = 1152921510118223480 (0x100000014880EE78);//ML01
            // 0x014392B4: ADD x0, sp, #8             | X0 = (1152921510118223472 + 8) = 1152921510118223480 (0x100000014880EE78);
            // 0x014392B8: BL #0x299a140              | 
            // 0x014392BC: MOV x0, x19                | X0 = 1152921510118223480 (0x100000014880EE78);//ML01
            // 0x014392C0: BL #0x980800               | X0 = sub_980800( ?? 0x100000014880EE78, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x014392C4 (21205700), len: 288  VirtAddr: 0x014392C4 RVA: 0x014392C4 token: 100664201 methodIndex: 30248 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_arg1_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014392C4: STP x20, x19, [sp, #-0x20]! | stack[1152921510118347632] = ???;  stack[1152921510118347640] = ???;  //  dest_result_addr=1152921510118347632 |  dest_result_addr=1152921510118347640
            // 0x014392C8: STP x29, x30, [sp, #0x10]  | stack[1152921510118347648] = ???;  stack[1152921510118347656] = ???;  //  dest_result_addr=1152921510118347648 |  dest_result_addr=1152921510118347656
            // 0x014392CC: ADD x29, sp, #0x10         | X29 = (1152921510118347632 + 16) = 1152921510118347648 (0x100000014882D380);
            // 0x014392D0: SUB sp, sp, #0x10          | SP = (1152921510118347632 - 16) = 1152921510118347616 (0x100000014882D360);
            // 0x014392D4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014392D8: LDRB w8, [x20, #0x65]      | W8 = (bool)static_value_03737065;       
            // 0x014392DC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014392E0: TBNZ w8, #0, #0x14392fc    | if (static_value_03737065 == true) goto label_0;
            // 0x014392E4: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x014392E8: LDR x8, [x8, #0x800]       | X8 = 0x2B904F0;                         
            // 0x014392EC: LDR w0, [x8]               | W0 = 0x1800;                            
            // 0x014392F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1800, ????);     
            // 0x014392F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014392F8: STRB w8, [x20, #0x65]      | static_value_03737065 = true;            //  dest_result_addr=57897061
            label_0:
            // 0x014392FC: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x01439300: LDR x19, [x19]             | X19 = X1;                               
            // 0x01439304: LDR x20, [x20, #0x440]     | X20 = 1152921504898326528;              
            // 0x01439308: CBZ x19, #0x143935c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x0143930C: LDR x8, [x19]              | X8 = X1;                                
            // 0x01439310: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01439314: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01439318: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143931C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439320: B.LO #0x1439338            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01439324: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01439328: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143932C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439330: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01439334: B.EQ #0x1439360            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01439338: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x0143933C: MOV x8, sp                 | X8 = 1152921510118347616 (0x100000014882D360);//ML01
            // 0x01439340: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01439344: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510118335664]
            // 0x01439348: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143934C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439350: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01439354: MOV x0, sp                 | X0 = 1152921510118347616 (0x100000014882D360);//ML01
            // 0x01439358: BL #0x299a140              | 
            label_1:
            // 0x0143935C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014882D360, ????);
            label_3:
            // 0x01439360: LDR x8, [x19]              | X8 = X1;                                
            // 0x01439364: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01439368: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x0143936C: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439370: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439374: B.LO #0x14393a0            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01439378: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x0143937C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439380: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439384: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01439388: B.NE #0x14393a0            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x0143938C: LDR x0, [x19, #0x30]       | X0 = X1 + 48;                           
            // 0x01439390: SUB sp, x29, #0x10         | SP = (1152921510118347648 - 16) = 1152921510118347632 (0x100000014882D370);
            // 0x01439394: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01439398: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143939C: RET                        |  return (System.Object)X1 + 48;         
            return (object)X1 + 48;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x014393A0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x014393A4: ADD x8, sp, #8             | X8 = (1152921510118347616 + 8) = 1152921510118347624 (0x100000014882D368);
            // 0x014393A8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x014393AC: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510118335664]
            // 0x014393B0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014393B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014393B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014393BC: ADD x0, sp, #8             | X0 = (1152921510118347616 + 8) = 1152921510118347624 (0x100000014882D368);
            // 0x014393C0: BL #0x299a140              | 
            // 0x014393C4: MOV x19, x0                | X19 = 1152921510118347624 (0x100000014882D368);//ML01
            // 0x014393C8: MOV x0, sp                 | X0 = 1152921510118347616 (0x100000014882D360);//ML01
            label_6:
            // 0x014393CC: BL #0x299a140              | 
            // 0x014393D0: MOV x0, x19                | X0 = 1152921510118347624 (0x100000014882D368);//ML01
            // 0x014393D4: BL #0x980800               | X0 = sub_980800( ?? 0x100000014882D368, ????);
            // 0x014393D8: MOV x19, x0                | X19 = 1152921510118347624 (0x100000014882D368);//ML01
            // 0x014393DC: ADD x0, sp, #8             | X0 = (1152921510118347616 + 8) = 1152921510118347624 (0x100000014882D368);
            // 0x014393E0: B #0x14393cc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014393E4 (21205988), len: 208  VirtAddr: 0x014393E4 RVA: 0x014393E4 token: 100664202 methodIndex: 30249 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_arg1_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x014393E4: STP x22, x21, [sp, #-0x30]! | stack[1152921510118471744] = ???;  stack[1152921510118471752] = ???;  //  dest_result_addr=1152921510118471744 |  dest_result_addr=1152921510118471752
            // 0x014393E8: STP x20, x19, [sp, #0x10]  | stack[1152921510118471760] = ???;  stack[1152921510118471768] = ???;  //  dest_result_addr=1152921510118471760 |  dest_result_addr=1152921510118471768
            // 0x014393EC: STP x29, x30, [sp, #0x20]  | stack[1152921510118471776] = ???;  stack[1152921510118471784] = ???;  //  dest_result_addr=1152921510118471776 |  dest_result_addr=1152921510118471784
            // 0x014393F0: ADD x29, sp, #0x20         | X29 = (1152921510118471744 + 32) = 1152921510118471776 (0x100000014884B860);
            // 0x014393F4: SUB sp, sp, #0x10          | SP = (1152921510118471744 - 16) = 1152921510118471728 (0x100000014884B830);
            // 0x014393F8: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x014393FC: LDRB w8, [x21, #0x66]      | W8 = (bool)static_value_03737066;       
            // 0x01439400: MOV x19, x2                | X19 = X2;//m1                           
            // 0x01439404: MOV x20, x1                | X20 = v;//m1                            
            // 0x01439408: TBNZ w8, #0, #0x1439424    | if (static_value_03737066 == true) goto label_0;
            // 0x0143940C: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x01439410: LDR x8, [x8, #0x9d8]       | X8 = 0x2B90504;                         
            // 0x01439414: LDR w0, [x8]               | W0 = 0x1805;                            
            val_3 = 6149;
            // 0x01439418: BL #0x2782188              | X0 = sub_2782188( ?? 0x1805, ????);     
            // 0x0143941C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439420: STRB w8, [x21, #0x66]      | static_value_03737066 = true;            //  dest_result_addr=57897062
            label_0:
            // 0x01439424: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x01439428: CBZ x8, #0x143949c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x0143942C: ADRP x10, #0x3676000       | X10 = 57106432 (0x3676000);             
            // 0x01439430: LDR x10, [x10, #0x440]     | X10 = 1152921504898326528;              
            // 0x01439434: LDR x9, [x8]               | X9 = ;                                  
            // 0x01439438: LDR x1, [x10]              | X1 = typeof(CEvent.ZEvent);             
            // 0x0143943C: LDRB w11, [x9, #0x104]     |  //  not_find_field!1:260
            // 0x01439440: LDRB w10, [x1, #0x104]     | W10 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439444: CMP w11, w10               | STATE = COMPARE(mem[null + 260], CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439448: B.LO #0x1439478            | if (mem[null + 260] < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
            // 0x0143944C: LDR x11, [x9, #0xb0]       |  //  not_find_field!1:176
            // 0x01439450: ADD x10, x11, x10, lsl #3  | X10 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439454: LDUR x10, [x10, #-8]       | X10 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439458: CMP x10, x1                | STATE = COMPARE((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x0143945C: B.NE #0x1439478            | if ((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_3;
            // 0x01439460: STR x19, [x8, #0x30]       | typeof(System.Object).__il2cppRuntimeField_30 = X2;  //  dest_result_addr=1152921504606900272
            typeof(System.Object).__il2cppRuntimeField_30 = X2;
            // 0x01439464: SUB sp, x29, #0x20         | SP = (1152921510118471776 - 32) = 1152921510118471744 (0x100000014884B840);
            // 0x01439468: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0143946C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01439470: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01439474: RET                        |  return;                                
            return;
            label_3:
            // 0x01439478: LDR x0, [x9, #0x30]        |  //  not_find_field!1:48
            // 0x0143947C: ADD x8, sp, #8             | X8 = (1152921510118471728 + 8) = 1152921510118471736 (0x100000014884B838);
            // 0x01439480: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01439484: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510118459792]
            // 0x01439488: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143948C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439490: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01439494: ADD x0, sp, #8             | X0 = (1152921510118471728 + 8) = 1152921510118471736 (0x100000014884B838);
            // 0x01439498: BL #0x299a140              | 
            label_1:
            // 0x0143949C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014884B838, ????);
            // 0x014394A0: MOV x19, x0                | X19 = 1152921510118471736 (0x100000014884B838);//ML01
            // 0x014394A4: ADD x0, sp, #8             | X0 = (1152921510118471728 + 8) = 1152921510118471736 (0x100000014884B838);
            // 0x014394A8: BL #0x299a140              | 
            // 0x014394AC: MOV x0, x19                | X0 = 1152921510118471736 (0x100000014884B838);//ML01
            // 0x014394B0: BL #0x980800               | X0 = sub_980800( ?? 0x100000014884B838, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x014394B4 (21206196), len: 288  VirtAddr: 0x014394B4 RVA: 0x014394B4 token: 100664203 methodIndex: 30250 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_arg2_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x014394B4: STP x20, x19, [sp, #-0x20]! | stack[1152921510118595888] = ???;  stack[1152921510118595896] = ???;  //  dest_result_addr=1152921510118595888 |  dest_result_addr=1152921510118595896
            // 0x014394B8: STP x29, x30, [sp, #0x10]  | stack[1152921510118595904] = ???;  stack[1152921510118595912] = ???;  //  dest_result_addr=1152921510118595904 |  dest_result_addr=1152921510118595912
            // 0x014394BC: ADD x29, sp, #0x10         | X29 = (1152921510118595888 + 16) = 1152921510118595904 (0x1000000148869D40);
            // 0x014394C0: SUB sp, sp, #0x10          | SP = (1152921510118595888 - 16) = 1152921510118595872 (0x1000000148869D20);
            // 0x014394C4: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x014394C8: LDRB w8, [x20, #0x67]      | W8 = (bool)static_value_03737067;       
            // 0x014394CC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x014394D0: TBNZ w8, #0, #0x14394ec    | if (static_value_03737067 == true) goto label_0;
            // 0x014394D4: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x014394D8: LDR x8, [x8, #0x1c0]       | X8 = 0x2B904F4;                         
            // 0x014394DC: LDR w0, [x8]               | W0 = 0x1801;                            
            // 0x014394E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1801, ????);     
            // 0x014394E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014394E8: STRB w8, [x20, #0x67]      | static_value_03737067 = true;            //  dest_result_addr=57897063
            label_0:
            // 0x014394EC: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x014394F0: LDR x19, [x19]             | X19 = X1;                               
            // 0x014394F4: LDR x20, [x20, #0x440]     | X20 = 1152921504898326528;              
            // 0x014394F8: CBZ x19, #0x143954c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x014394FC: LDR x8, [x19]              | X8 = X1;                                
            // 0x01439500: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01439504: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01439508: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0143950C: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439510: B.LO #0x1439528            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01439514: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01439518: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x0143951C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439520: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01439524: B.EQ #0x1439550            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01439528: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x0143952C: MOV x8, sp                 | X8 = 1152921510118595872 (0x1000000148869D20);//ML01
            // 0x01439530: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01439534: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510118583920]
            // 0x01439538: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143953C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439540: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01439544: MOV x0, sp                 | X0 = 1152921510118595872 (0x1000000148869D20);//ML01
            // 0x01439548: BL #0x299a140              | 
            label_1:
            // 0x0143954C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148869D20, ????);
            label_3:
            // 0x01439550: LDR x8, [x19]              | X8 = X1;                                
            // 0x01439554: LDR x1, [x20]              | X1 = typeof(CEvent.ZEvent);             
            // 0x01439558: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x0143955C: LDRB w9, [x1, #0x104]      | W9 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439560: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439564: B.LO #0x1439590            | if (X1 + 260 < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01439568: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x0143956C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439570: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439574: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x01439578: B.NE #0x1439590            | if ((X1 + 176 + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x0143957C: LDR x0, [x19, #0x38]       | X0 = X1 + 56;                           
            // 0x01439580: SUB sp, x29, #0x10         | SP = (1152921510118595904 - 16) = 1152921510118595888 (0x1000000148869D30);
            // 0x01439584: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01439588: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0143958C: RET                        |  return (System.Object)X1 + 56;         
            return (object)X1 + 56;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01439590: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01439594: ADD x8, sp, #8             | X8 = (1152921510118595872 + 8) = 1152921510118595880 (0x1000000148869D28);
            // 0x01439598: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x0143959C: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510118583920]
            // 0x014395A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x014395A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014395A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x014395AC: ADD x0, sp, #8             | X0 = (1152921510118595872 + 8) = 1152921510118595880 (0x1000000148869D28);
            // 0x014395B0: BL #0x299a140              | 
            // 0x014395B4: MOV x19, x0                | X19 = 1152921510118595880 (0x1000000148869D28);//ML01
            // 0x014395B8: MOV x0, sp                 | X0 = 1152921510118595872 (0x1000000148869D20);//ML01
            label_6:
            // 0x014395BC: BL #0x299a140              | 
            // 0x014395C0: MOV x0, x19                | X0 = 1152921510118595880 (0x1000000148869D28);//ML01
            // 0x014395C4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000148869D28, ????);
            // 0x014395C8: MOV x19, x0                | X19 = 1152921510118595880 (0x1000000148869D28);//ML01
            // 0x014395CC: ADD x0, sp, #8             | X0 = (1152921510118595872 + 8) = 1152921510118595880 (0x1000000148869D28);
            // 0x014395D0: B #0x14395bc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x014395D4 (21206484), len: 208  VirtAddr: 0x014395D4 RVA: 0x014395D4 token: 100664204 methodIndex: 30251 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_arg2_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x014395D4: STP x22, x21, [sp, #-0x30]! | stack[1152921510118720000] = ???;  stack[1152921510118720008] = ???;  //  dest_result_addr=1152921510118720000 |  dest_result_addr=1152921510118720008
            // 0x014395D8: STP x20, x19, [sp, #0x10]  | stack[1152921510118720016] = ???;  stack[1152921510118720024] = ???;  //  dest_result_addr=1152921510118720016 |  dest_result_addr=1152921510118720024
            // 0x014395DC: STP x29, x30, [sp, #0x20]  | stack[1152921510118720032] = ???;  stack[1152921510118720040] = ???;  //  dest_result_addr=1152921510118720032 |  dest_result_addr=1152921510118720040
            // 0x014395E0: ADD x29, sp, #0x20         | X29 = (1152921510118720000 + 32) = 1152921510118720032 (0x1000000148888220);
            // 0x014395E4: SUB sp, sp, #0x10          | SP = (1152921510118720000 - 16) = 1152921510118719984 (0x10000001488881F0);
            // 0x014395E8: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x014395EC: LDRB w8, [x21, #0x68]      | W8 = (bool)static_value_03737068;       
            // 0x014395F0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x014395F4: MOV x20, x1                | X20 = v;//m1                            
            // 0x014395F8: TBNZ w8, #0, #0x1439614    | if (static_value_03737068 == true) goto label_0;
            // 0x014395FC: ADRP x8, #0x35de000        | X8 = 56483840 (0x35DE000);              
            // 0x01439600: LDR x8, [x8, #0x6e0]       | X8 = 0x2B90508;                         
            // 0x01439604: LDR w0, [x8]               | W0 = 0x1806;                            
            val_3 = 6150;
            // 0x01439608: BL #0x2782188              | X0 = sub_2782188( ?? 0x1806, ????);     
            // 0x0143960C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439610: STRB w8, [x21, #0x68]      | static_value_03737068 = true;            //  dest_result_addr=57897064
            label_0:
            // 0x01439614: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x01439618: CBZ x8, #0x143968c         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x0143961C: ADRP x10, #0x3676000       | X10 = 57106432 (0x3676000);             
            // 0x01439620: LDR x10, [x10, #0x440]     | X10 = 1152921504898326528;              
            // 0x01439624: LDR x9, [x8]               | X9 = ;                                  
            // 0x01439628: LDR x1, [x10]              | X1 = typeof(CEvent.ZEvent);             
            // 0x0143962C: LDRB w11, [x9, #0x104]     |  //  not_find_field!1:260
            // 0x01439630: LDRB w10, [x1, #0x104]     | W10 = CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01439634: CMP w11, w10               | STATE = COMPARE(mem[null + 260], CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01439638: B.LO #0x1439668            | if (mem[null + 260] < CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
            // 0x0143963C: LDR x11, [x9, #0xb0]       |  //  not_find_field!1:176
            // 0x01439640: ADD x10, x11, x10, lsl #3  | X10 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01439644: LDUR x10, [x10, #-8]       | X10 = (mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01439648: CMP x10, x1                | STATE = COMPARE((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.ZEvent))
            // 0x0143964C: B.NE #0x1439668            | if ((mem[null + 176] + (CEvent.ZEvent.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_3;
            // 0x01439650: STR x19, [x8, #0x38]       | typeof(System.Object).__il2cppRuntimeField_38 = X2;  //  dest_result_addr=1152921504606900280
            typeof(System.Object).__il2cppRuntimeField_38 = X2;
            // 0x01439654: SUB sp, x29, #0x20         | SP = (1152921510118720032 - 32) = 1152921510118720000 (0x1000000148888200);
            // 0x01439658: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0143965C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01439660: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01439664: RET                        |  return;                                
            return;
            label_3:
            // 0x01439668: LDR x0, [x9, #0x30]        |  //  not_find_field!1:48
            // 0x0143966C: ADD x8, sp, #8             | X8 = (1152921510118719984 + 8) = 1152921510118719992 (0x10000001488881F8);
            // 0x01439670: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01439674: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510118708048]
            // 0x01439678: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x0143967C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439680: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01439684: ADD x0, sp, #8             | X0 = (1152921510118719984 + 8) = 1152921510118719992 (0x10000001488881F8);
            // 0x01439688: BL #0x299a140              | 
            label_1:
            // 0x0143968C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001488881F8, ????);
            // 0x01439690: MOV x19, x0                | X19 = 1152921510118719992 (0x10000001488881F8);//ML01
            // 0x01439694: ADD x0, sp, #8             | X0 = (1152921510118719984 + 8) = 1152921510118719992 (0x10000001488881F8);
            // 0x01439698: BL #0x299a140              | 
            // 0x0143969C: MOV x0, x19                | X0 = 1152921510118719992 (0x10000001488881F8);//ML01
            // 0x014396A0: BL #0x980800               | X0 = sub_980800( ?? 0x10000001488881F8, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x014396A4 (21206692), len: 536  VirtAddr: 0x014396A4 RVA: 0x014396A4 token: 100664205 methodIndex: 30252 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            string val_10;
            // 0x014396A4: STP x24, x23, [sp, #-0x40]! | stack[1152921510118868768] = ???;  stack[1152921510118868776] = ???;  //  dest_result_addr=1152921510118868768 |  dest_result_addr=1152921510118868776
            // 0x014396A8: STP x22, x21, [sp, #0x10]  | stack[1152921510118868784] = ???;  stack[1152921510118868792] = ???;  //  dest_result_addr=1152921510118868784 |  dest_result_addr=1152921510118868792
            // 0x014396AC: STP x20, x19, [sp, #0x20]  | stack[1152921510118868800] = ???;  stack[1152921510118868808] = ???;  //  dest_result_addr=1152921510118868800 |  dest_result_addr=1152921510118868808
            // 0x014396B0: STP x29, x30, [sp, #0x30]  | stack[1152921510118868816] = ???;  stack[1152921510118868824] = ???;  //  dest_result_addr=1152921510118868816 |  dest_result_addr=1152921510118868824
            // 0x014396B4: ADD x29, sp, #0x30         | X29 = (1152921510118868768 + 48) = 1152921510118868816 (0x10000001488AC750);
            // 0x014396B8: SUB sp, sp, #0x10          | SP = (1152921510118868768 - 16) = 1152921510118868752 (0x10000001488AC710);
            // 0x014396BC: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x014396C0: LDRB w8, [x21, #0x69]      | W8 = (bool)static_value_03737069;       
            // 0x014396C4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x014396C8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x014396CC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x014396D0: TBNZ w8, #0, #0x14396ec    | if (static_value_03737069 == true) goto label_0;
            // 0x014396D4: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x014396D8: LDR x8, [x8, #0x7a0]       | X8 = 0x2B904D8;                         
            // 0x014396DC: LDR w0, [x8]               | W0 = 0x17FA;                            
            // 0x014396E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x17FA, ????);     
            // 0x014396E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x014396E8: STRB w8, [x21, #0x69]      | static_value_03737069 = true;            //  dest_result_addr=57897065
            label_0:
            // 0x014396EC: CBNZ x20, #0x14396f4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x014396F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17FA, ????);     
            label_1:
            // 0x014396F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014396F8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x014396FC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01439700: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01439704: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439708: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143970C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01439710: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439714: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439718: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0143971C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439720: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439724: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01439728: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143972C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439730: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01439734: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01439738: ADRP x9, #0x3607000        | X9 = 56651776 (0x3607000);              
            // 0x0143973C: MOV x22, x0                | X22 = val_3;//m1                        
            // 0x01439740: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01439744: LDR x9, [x9, #0xbb8]       | X9 = 1152921504608284672;               
            // 0x01439748: LDR x24, [x9]              | X24 = typeof(System.String);            
            // 0x0143974C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01439750: TBZ w9, #0, #0x1439764     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01439754: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01439758: CBNZ w9, #0x1439764        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0143975C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01439760: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01439764: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439768: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143976C: MOV x1, x24                | X1 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01439770: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439774: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01439778: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0143977C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01439780: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01439784: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01439788: TBZ w9, #0, #0x143979c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0143978C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01439790: CBNZ w9, #0x143979c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01439794: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01439798: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0143979C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014397A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014397A4: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x014397A8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014397AC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x014397B0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014397B4: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014397B8: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014397BC: MOV x23, x0                | X23 = val_5;//m1                        
            // 0x014397C0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014397C4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014397C8: TBZ w9, #0, #0x14397dc     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014397CC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014397D0: CBNZ w9, #0x14397dc        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014397D4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014397D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014397DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014397E0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x014397E4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x014397E8: MOV x2, x23                | X2 = val_5;//m1                         
            // 0x014397EC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x014397F0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x014397F4: CBZ x0, #0x143983c         | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x014397F8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x014397FC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01439800: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01439804: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01439808: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0143980C: MOV x23, x0                | X23 = val_6;//m1                        
            val_10 = val_6;
            // 0x01439810: B.EQ #0x143983c            | if (typeof(System.Object) == null) goto label_9;
            if(null == null)
            {
                goto label_9;
            }
            // 0x01439814: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01439818: ADD x8, sp, #8             | X8 = (1152921510118868752 + 8) = 1152921510118868760 (0x10000001488AC718);
            // 0x0143981C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01439820: LDR x0, [sp, #8]           | X0 = val_7;                              //  find_add[1152921510118856832]
            // 0x01439824: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x01439828: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143982C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x01439830: ADD x0, sp, #8             | X0 = (1152921510118868752 + 8) = 1152921510118868760 (0x10000001488AC718);
            // 0x01439834: BL #0x299a140              | 
            // 0x01439838: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_10 = 0;
            label_9:
            // 0x0143983C: CBNZ x20, #0x1439844       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01439840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001488AC718, ????);
            label_10:
            // 0x01439844: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439848: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143984C: MOV x1, x22                | X1 = val_3;//m1                         
            // 0x01439850: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01439854: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x01439858: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x0143985C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_8 = null;
            // 0x01439860: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x01439864: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439868: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0143986C: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01439870: BL #0xd80ce8               | .ctor(name:  val_10);                   
            val_8 = new CEvent.ZEvent(name:  val_10);
            // 0x01439874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439878: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0143987C: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01439880: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01439884: MOV x3, x20                | X3 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01439888: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143988C: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_9 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01439890: SUB sp, x29, #0x30         | SP = (1152921510118868816 - 48) = 1152921510118868768 (0x10000001488AC720);
            // 0x01439894: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01439898: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0143989C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x014398A0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x014398A4: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_9;
            return val_9;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x014398A8: MOV x19, x0                | 
            // 0x014398AC: ADD x0, sp, #8             | 
            // 0x014398B0: BL #0x299a140              | 
            // 0x014398B4: MOV x0, x19                | 
            // 0x014398B8: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x014398BC (21207228), len: 672  VirtAddr: 0x014398BC RVA: 0x014398BC token: 100664206 methodIndex: 30253 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            string val_14;
            // 0x014398BC: STP x26, x25, [sp, #-0x50]! | stack[1152921510119050384] = ???;  stack[1152921510119050392] = ???;  //  dest_result_addr=1152921510119050384 |  dest_result_addr=1152921510119050392
            // 0x014398C0: STP x24, x23, [sp, #0x10]  | stack[1152921510119050400] = ???;  stack[1152921510119050408] = ???;  //  dest_result_addr=1152921510119050400 |  dest_result_addr=1152921510119050408
            // 0x014398C4: STP x22, x21, [sp, #0x20]  | stack[1152921510119050416] = ???;  stack[1152921510119050424] = ???;  //  dest_result_addr=1152921510119050416 |  dest_result_addr=1152921510119050424
            // 0x014398C8: STP x20, x19, [sp, #0x30]  | stack[1152921510119050432] = ???;  stack[1152921510119050440] = ???;  //  dest_result_addr=1152921510119050432 |  dest_result_addr=1152921510119050440
            // 0x014398CC: STP x29, x30, [sp, #0x40]  | stack[1152921510119050448] = ???;  stack[1152921510119050456] = ???;  //  dest_result_addr=1152921510119050448 |  dest_result_addr=1152921510119050456
            // 0x014398D0: ADD x29, sp, #0x40         | X29 = (1152921510119050384 + 64) = 1152921510119050448 (0x10000001488D8CD0);
            // 0x014398D4: SUB sp, sp, #0x10          | SP = (1152921510119050384 - 16) = 1152921510119050368 (0x10000001488D8C80);
            // 0x014398D8: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x014398DC: LDRB w8, [x21, #0x6a]      | W8 = (bool)static_value_0373706A;       
            // 0x014398E0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x014398E4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x014398E8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x014398EC: TBNZ w8, #0, #0x1439908    | if (static_value_0373706A == true) goto label_0;
            // 0x014398F0: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
            // 0x014398F4: LDR x8, [x8, #0xd20]       | X8 = 0x2B904DC;                         
            // 0x014398F8: LDR w0, [x8]               | W0 = 0x17FB;                            
            // 0x014398FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17FB, ????);     
            // 0x01439900: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439904: STRB w8, [x21, #0x6a]      | static_value_0373706A = true;            //  dest_result_addr=57897066
            label_0:
            // 0x01439908: CBNZ x20, #0x1439910       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143990C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17FB, ????);     
            label_1:
            // 0x01439910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439914: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439918: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143991C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01439920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439924: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439928: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143992C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439930: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439934: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01439938: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143993C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439940: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01439944: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439948: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143994C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01439950: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01439954: ADRP x9, #0x363f000        | X9 = 56881152 (0x363F000);              
            // 0x01439958: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0143995C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01439960: LDR x9, [x9, #0xa88]       | X9 = 1152921504606900224;               
            // 0x01439964: LDR x24, [x9]              | X24 = typeof(System.Object);            
            // 0x01439968: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143996C: TBZ w9, #0, #0x1439980     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01439970: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01439974: CBNZ w9, #0x1439980        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01439978: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143997C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01439980: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439984: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439988: MOV x1, x24                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x0143998C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439990: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01439994: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01439998: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143999C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x014399A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x014399A4: TBZ w9, #0, #0x14399b8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x014399A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x014399AC: CBNZ w9, #0x14399b8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x014399B0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x014399B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x014399B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014399BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x014399C0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x014399C4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x014399C8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x014399CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x014399D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x014399D4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x014399D8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x014399DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x014399E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x014399E4: TBZ w9, #0, #0x14399f8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x014399E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x014399EC: CBNZ w9, #0x14399f8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x014399F0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x014399F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x014399F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x014399FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439A00: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01439A04: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01439A08: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01439A0C: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x01439A10: CBNZ x20, #0x1439a18       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x01439A14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x01439A18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439A1C: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439A20: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01439A24: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01439A28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439A2C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439A30: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01439A34: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439A38: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439A3C: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x01439A40: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x01439A44: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x01439A48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439A4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439A50: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01439A54: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439A58: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x01439A5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439A60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01439A64: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x01439A68: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01439A6C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01439A70: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01439A74: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x01439A78: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439A7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439A80: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x01439A84: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x01439A88: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_14 = 0;
            // 0x01439A8C: CBZ x0, #0x1439ad4         | if (val_10 == null) goto label_10;      
            if(val_10 == null)
            {
                goto label_10;
            }
            // 0x01439A90: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01439A94: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01439A98: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01439A9C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01439AA0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01439AA4: MOV x23, x0                | X23 = val_10;//m1                       
            val_14 = val_10;
            // 0x01439AA8: B.EQ #0x1439ad4            | if (typeof(System.Object) == null) goto label_10;
            if(null == null)
            {
                goto label_10;
            }
            // 0x01439AAC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01439AB0: ADD x8, sp, #8             | X8 = (1152921510119050368 + 8) = 1152921510119050376 (0x10000001488D8C88);
            // 0x01439AB4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01439AB8: LDR x0, [sp, #8]           | X0 = val_11;                             //  find_add[1152921510119038464]
            // 0x01439ABC: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x01439AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439AC4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x01439AC8: ADD x0, sp, #8             | X0 = (1152921510119050368 + 8) = 1152921510119050376 (0x10000001488D8C88);
            // 0x01439ACC: BL #0x299a140              | 
            // 0x01439AD0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_14 = 0;
            label_10:
            // 0x01439AD4: CBNZ x20, #0x1439adc       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x01439AD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001488D8C88, ????);
            label_11:
            // 0x01439ADC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439AE0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439AE4: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x01439AE8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01439AEC: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x01439AF0: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x01439AF4: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_12 = null;
            // 0x01439AF8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x01439AFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439B00: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x01439B04: MOV x2, x24                | X2 = val_6;//m1                         
            // 0x01439B08: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01439B0C: BL #0xd7de54               | .ctor(name:  val_14, arg:  val_6);      
            val_12 = new CEvent.ZEvent(name:  val_14, arg:  val_6);
            // 0x01439B10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439B14: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01439B18: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01439B1C: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01439B20: MOV x3, x20                | X3 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01439B24: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01439B28: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_13 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01439B2C: SUB sp, x29, #0x40         | SP = (1152921510119050448 - 64) = 1152921510119050384 (0x10000001488D8C90);
            // 0x01439B30: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01439B34: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01439B38: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01439B3C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01439B40: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01439B44: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_13;
            return val_13;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01439B48: MOV x19, x0                | 
            // 0x01439B4C: ADD x0, sp, #8             | 
            // 0x01439B50: BL #0x299a140              | 
            // 0x01439B54: MOV x0, x19                | 
            // 0x01439B58: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01439B5C (21207900), len: 800  VirtAddr: 0x01439B5C RVA: 0x01439B5C token: 100664207 methodIndex: 30254 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_15;
            //  | 
            string val_18;
            // 0x01439B5C: STP x28, x27, [sp, #-0x60]! | stack[1152921510119256576] = ???;  stack[1152921510119256584] = ???;  //  dest_result_addr=1152921510119256576 |  dest_result_addr=1152921510119256584
            // 0x01439B60: STP x26, x25, [sp, #0x10]  | stack[1152921510119256592] = ???;  stack[1152921510119256600] = ???;  //  dest_result_addr=1152921510119256592 |  dest_result_addr=1152921510119256600
            // 0x01439B64: STP x24, x23, [sp, #0x20]  | stack[1152921510119256608] = ???;  stack[1152921510119256616] = ???;  //  dest_result_addr=1152921510119256608 |  dest_result_addr=1152921510119256616
            // 0x01439B68: STP x22, x21, [sp, #0x30]  | stack[1152921510119256624] = ???;  stack[1152921510119256632] = ???;  //  dest_result_addr=1152921510119256624 |  dest_result_addr=1152921510119256632
            // 0x01439B6C: STP x20, x19, [sp, #0x40]  | stack[1152921510119256640] = ???;  stack[1152921510119256648] = ???;  //  dest_result_addr=1152921510119256640 |  dest_result_addr=1152921510119256648
            // 0x01439B70: STP x29, x30, [sp, #0x50]  | stack[1152921510119256656] = ???;  stack[1152921510119256664] = ???;  //  dest_result_addr=1152921510119256656 |  dest_result_addr=1152921510119256664
            // 0x01439B74: ADD x29, sp, #0x50         | X29 = (1152921510119256576 + 80) = 1152921510119256656 (0x100000014890B250);
            // 0x01439B78: SUB sp, sp, #0x10          | SP = (1152921510119256576 - 16) = 1152921510119256560 (0x100000014890B1F0);
            // 0x01439B7C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01439B80: LDRB w8, [x21, #0x6b]      | W8 = (bool)static_value_0373706B;       
            // 0x01439B84: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01439B88: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01439B8C: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01439B90: TBNZ w8, #0, #0x1439bac    | if (static_value_0373706B == true) goto label_0;
            // 0x01439B94: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x01439B98: LDR x8, [x8, #0xa78]       | X8 = 0x2B904E0;                         
            // 0x01439B9C: LDR w0, [x8]               | W0 = 0x17FC;                            
            // 0x01439BA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x17FC, ????);     
            // 0x01439BA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439BA8: STRB w8, [x21, #0x6b]      | static_value_0373706B = true;            //  dest_result_addr=57897067
            label_0:
            // 0x01439BAC: CBNZ x20, #0x1439bb4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01439BB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17FC, ????);     
            label_1:
            // 0x01439BB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439BB8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439BBC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01439BC0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01439BC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439BC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439BCC: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01439BD0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439BD4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439BD8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01439BDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439BE0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439BE4: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01439BE8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439BEC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439BF0: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01439BF4: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01439BF8: ADRP x27, #0x363f000       | X27 = 56881152 (0x363F000);             
            // 0x01439BFC: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x01439C00: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01439C04: LDR x27, [x27, #0xa88]     | X27 = 1152921504606900224;              
            // 0x01439C08: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01439C0C: LDR x24, [x27]             | X24 = typeof(System.Object);            
            // 0x01439C10: TBZ w9, #0, #0x1439c24     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01439C14: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01439C18: CBNZ w9, #0x1439c24        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01439C1C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01439C20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01439C24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439C28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439C2C: MOV x1, x24                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x01439C30: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439C34: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01439C38: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01439C3C: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x01439C40: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01439C44: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01439C48: TBZ w9, #0, #0x1439c5c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01439C4C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01439C50: CBNZ w9, #0x1439c5c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01439C54: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01439C58: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01439C5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439C60: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01439C64: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01439C68: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01439C6C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01439C70: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01439C74: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01439C78: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01439C7C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01439C80: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01439C84: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01439C88: TBZ w9, #0, #0x1439c9c     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01439C8C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01439C90: CBNZ w9, #0x1439c9c        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01439C94: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01439C98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01439C9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439CA0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439CA4: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x01439CA8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01439CAC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01439CB0: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x01439CB4: CBNZ x20, #0x1439cbc       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x01439CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x01439CBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439CC0: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439CC4: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x01439CC8: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01439CCC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439CD0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439CD4: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01439CD8: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439CDC: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439CE0: LDR x1, [x27]              | X1 = typeof(System.Object);             
            // 0x01439CE4: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x01439CE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439CEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439CF0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439CF4: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x01439CF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439CFC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01439D00: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x01439D04: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01439D08: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01439D0C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01439D10: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x01439D14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439D18: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439D1C: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x01439D20: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x01439D24: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x01439D28: CBNZ x20, #0x1439d30       | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x01439D2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_9:
            // 0x01439D30: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439D34: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439D38: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x01439D3C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01439D40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439D44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439D48: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x01439D4C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439D50: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439D54: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x01439D58: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x01439D5C: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x01439D60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439D64: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439D68: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01439D6C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439D70: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x01439D74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439D78: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01439D7C: MOV x1, x22                | X1 = val_11;//m1                        
            // 0x01439D80: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01439D84: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01439D88: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_13 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01439D8C: MOV x2, x0                 | X2 = val_13;//m1                        
            // 0x01439D90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439D94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439D98: MOV x1, x26                | X1 = val_12;//m1                        
            // 0x01439D9C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            object val_14 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            // 0x01439DA0: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x01439DA4: CBZ x0, #0x1439dec         | if (val_14 == null) goto label_11;      
            if(val_14 == null)
            {
                goto label_11;
            }
            // 0x01439DA8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01439DAC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01439DB0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01439DB4: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x01439DB8: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x01439DBC: MOV x23, x0                | X23 = val_14;//m1                       
            val_18 = val_14;
            // 0x01439DC0: B.EQ #0x1439dec            | if (typeof(System.Object) == null) goto label_11;
            if(null == null)
            {
                goto label_11;
            }
            // 0x01439DC4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01439DC8: ADD x8, sp, #8             | X8 = (1152921510119256560 + 8) = 1152921510119256568 (0x100000014890B1F8);
            // 0x01439DCC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01439DD0: LDR x0, [sp, #8]           | X0 = val_15;                             //  find_add[1152921510119244672]
            // 0x01439DD4: BL #0x27af090              | X0 = sub_27AF090( ?? val_15, ????);     
            // 0x01439DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439DDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            // 0x01439DE0: ADD x0, sp, #8             | X0 = (1152921510119256560 + 8) = 1152921510119256568 (0x100000014890B1F8);
            // 0x01439DE4: BL #0x299a140              | 
            // 0x01439DE8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_18 = 0;
            label_11:
            // 0x01439DEC: CBNZ x20, #0x1439df4       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01439DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014890B1F8, ????);
            label_12:
            // 0x01439DF4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439DF8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439DFC: MOV x1, x22                | X1 = val_11;//m1                        
            // 0x01439E00: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x01439E04: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x01439E08: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x01439E0C: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_16 = null;
            // 0x01439E10: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x01439E14: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01439E18: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x01439E1C: MOV x2, x25                | X2 = val_10;//m1                        
            // 0x01439E20: MOV x3, x24                | X3 = val_6;//m1                         
            // 0x01439E24: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01439E28: BL #0xd81db8               | .ctor(name:  val_18, arg:  val_10, arg1:  val_6);
            val_16 = new CEvent.ZEvent(name:  val_18, arg:  val_10, arg1:  val_6);
            // 0x01439E2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439E30: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x01439E34: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x01439E38: MOV x2, x19                | X2 = X3;//m1                            
            // 0x01439E3C: MOV x3, x20                | X3 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x01439E40: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01439E44: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_17 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x01439E48: SUB sp, x29, #0x50         | SP = (1152921510119256656 - 80) = 1152921510119256576 (0x100000014890B200);
            // 0x01439E4C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01439E50: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01439E54: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01439E58: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x01439E5C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01439E60: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01439E64: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_17;
            return val_17;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x01439E68: MOV x19, x0                | 
            // 0x01439E6C: ADD x0, sp, #8             | 
            // 0x01439E70: BL #0x299a140              | 
            // 0x01439E74: MOV x0, x19                | 
            // 0x01439E78: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01439E7C (21208700), len: 780  VirtAddr: 0x01439E7C RVA: 0x01439E7C token: 100664208 methodIndex: 30255 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_12;
            //  | 
            System.Object[] val_15;
            //  | 
            string val_16;
            // 0x01439E7C: STP x28, x27, [sp, #-0x60]! | stack[1152921510119462784] = ???;  stack[1152921510119462792] = ???;  //  dest_result_addr=1152921510119462784 |  dest_result_addr=1152921510119462792
            // 0x01439E80: STP x26, x25, [sp, #0x10]  | stack[1152921510119462800] = ???;  stack[1152921510119462808] = ???;  //  dest_result_addr=1152921510119462800 |  dest_result_addr=1152921510119462808
            // 0x01439E84: STP x24, x23, [sp, #0x20]  | stack[1152921510119462816] = ???;  stack[1152921510119462824] = ???;  //  dest_result_addr=1152921510119462816 |  dest_result_addr=1152921510119462824
            // 0x01439E88: STP x22, x21, [sp, #0x30]  | stack[1152921510119462832] = ???;  stack[1152921510119462840] = ???;  //  dest_result_addr=1152921510119462832 |  dest_result_addr=1152921510119462840
            // 0x01439E8C: STP x20, x19, [sp, #0x40]  | stack[1152921510119462848] = ???;  stack[1152921510119462856] = ???;  //  dest_result_addr=1152921510119462848 |  dest_result_addr=1152921510119462856
            // 0x01439E90: STP x29, x30, [sp, #0x50]  | stack[1152921510119462864] = ???;  stack[1152921510119462872] = ???;  //  dest_result_addr=1152921510119462864 |  dest_result_addr=1152921510119462872
            // 0x01439E94: ADD x29, sp, #0x50         | X29 = (1152921510119462784 + 80) = 1152921510119462864 (0x100000014893D7D0);
            // 0x01439E98: SUB sp, sp, #0x10          | SP = (1152921510119462784 - 16) = 1152921510119462768 (0x100000014893D770);
            // 0x01439E9C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01439EA0: LDRB w8, [x21, #0x6c]      | W8 = (bool)static_value_0373706C;       
            // 0x01439EA4: MOV x19, x3                | X19 = X3;//m1                           
            // 0x01439EA8: MOV x22, x2                | X22 = X2;//m1                           
            // 0x01439EAC: MOV x20, x1                | X20 = X1;//m1                           
            // 0x01439EB0: TBNZ w8, #0, #0x1439ecc    | if (static_value_0373706C == true) goto label_0;
            // 0x01439EB4: ADRP x8, #0x3614000        | X8 = 56705024 (0x3614000);              
            // 0x01439EB8: LDR x8, [x8, #0xeb8]       | X8 = 0x2B904E4;                         
            // 0x01439EBC: LDR w0, [x8]               | W0 = 0x17FD;                            
            // 0x01439EC0: BL #0x2782188              | X0 = sub_2782188( ?? 0x17FD, ????);     
            // 0x01439EC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01439EC8: STRB w8, [x21, #0x6c]      | static_value_0373706C = true;            //  dest_result_addr=57897068
            label_0:
            // 0x01439ECC: CBNZ x20, #0x1439ed4       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x01439ED0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17FD, ????);     
            label_1:
            // 0x01439ED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01439ED8: MOV x0, x20                | X0 = X1;//m1                            
            // 0x01439EDC: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x01439EE0: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x01439EE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439EE8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439EEC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x01439EF0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439EF4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439EF8: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01439EFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439F00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439F04: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01439F08: MOV x1, x22                | X1 = X2;//m1                            
            // 0x01439F0C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x01439F10: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01439F14: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01439F18: ADRP x9, #0x3640000        | X9 = 56885248 (0x3640000);              
            // 0x01439F1C: MOV x24, x0                | X24 = val_3;//m1                        
            // 0x01439F20: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x01439F24: LDR x9, [x9, #0x228]       | X9 = 1152921504954501264;               
            // 0x01439F28: LDR x25, [x9]              | X25 = typeof(System.Object[]);          
            // 0x01439F2C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x01439F30: TBZ w9, #0, #0x1439f44     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x01439F34: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01439F38: CBNZ w9, #0x1439f44        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x01439F3C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x01439F40: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x01439F44: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439F48: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01439F4C: MOV x1, x25                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01439F50: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01439F54: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01439F58: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x01439F5C: MOV x25, x0                | X25 = val_4;//m1                        
            // 0x01439F60: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x01439F64: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x01439F68: TBZ w9, #0, #0x1439f7c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x01439F6C: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x01439F70: CBNZ w9, #0x1439f7c        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x01439F74: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x01439F78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x01439F7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439F80: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01439F84: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x01439F88: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x01439F8C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x01439F90: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x01439F94: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x01439F98: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x01439F9C: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x01439FA0: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x01439FA4: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x01439FA8: TBZ w9, #0, #0x1439fbc     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x01439FAC: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x01439FB0: CBNZ w9, #0x1439fbc        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x01439FB4: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x01439FB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x01439FBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01439FC0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01439FC4: MOV x1, x25                | X1 = val_4;//m1                         
            // 0x01439FC8: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x01439FCC: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x01439FD0: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x01439FD4: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x01439FD8: CBZ x26, #0x143a02c        | if (val_6 == null) goto label_9;        
            if(val_6 == null)
            {
                goto label_9;
            }
            // 0x01439FDC: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01439FE0: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x01439FE4: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x01439FE8: LDR x27, [x8]              | X27 = typeof(System.Object[]);          
            // 0x01439FEC: MOV x1, x27                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01439FF0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x01439FF4: MOV x25, x0                | X25 = val_6;//m1                        
            val_15 = val_6;
            // 0x01439FF8: CBNZ x25, #0x143a02c       | if (val_6 != null) goto label_9;        
            if(val_15 != null)
            {
                goto label_9;
            }
            // 0x01439FFC: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x0143A000: MOV x1, x27                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x0143A004: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143A008: MOV x8, sp                 | X8 = 1152921510119462768 (0x100000014893D770);//ML01
            // 0x0143A00C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143A010: LDR x0, [sp]               | X0 = val_7;                              //  find_add[1152921510119450880]
            // 0x0143A014: BL #0x27af090              | X0 = sub_27AF090( ?? val_7, ????);      
            // 0x0143A018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A01C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            // 0x0143A020: MOV x0, sp                 | X0 = 1152921510119462768 (0x100000014893D770);//ML01
            // 0x0143A024: BL #0x299a140              | 
            // 0x0143A028: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_15 = 0;
            label_9:
            // 0x0143A02C: CBNZ x20, #0x143a034       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0143A030: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014893D770, ????);
            label_10:
            // 0x0143A034: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A038: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A03C: MOV x1, x24                | X1 = val_3;//m1                         
            // 0x0143A040: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143A044: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A048: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A04C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143A050: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143A054: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_8 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143A058: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0143A05C: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0143A060: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x0143A064: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A068: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A06C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143A070: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A074: MOV x24, x0                | X24 = val_9;//m1                        
            // 0x0143A078: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A07C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143A080: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0143A084: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143A088: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0143A08C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_10 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143A090: MOV x2, x0                 | X2 = val_10;//m1                        
            // 0x0143A094: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A098: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A09C: MOV x1, x24                | X1 = val_9;//m1                         
            // 0x0143A0A0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            object val_11 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_9);
            // 0x0143A0A4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x0143A0A8: CBZ x0, #0x143a0f0         | if (val_11 == null) goto label_12;      
            if(val_11 == null)
            {
                goto label_12;
            }
            // 0x0143A0AC: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0143A0B0: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0143A0B4: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143A0B8: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143A0BC: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0143A0C0: MOV x23, x0                | X23 = val_11;//m1                       
            val_16 = val_11;
            // 0x0143A0C4: B.EQ #0x143a0f0            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x0143A0C8: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143A0CC: ADD x8, sp, #8             | X8 = (1152921510119462768 + 8) = 1152921510119462776 (0x100000014893D778);
            // 0x0143A0D0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143A0D4: LDR x0, [sp, #8]           | X0 = val_12;                             //  find_add[1152921510119450880]
            // 0x0143A0D8: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0143A0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A0E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0143A0E4: ADD x0, sp, #8             | X0 = (1152921510119462768 + 8) = 1152921510119462776 (0x100000014893D778);
            // 0x0143A0E8: BL #0x299a140              | 
            // 0x0143A0EC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_16 = 0;
            label_12:
            // 0x0143A0F0: CBNZ x20, #0x143a0f8       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0143A0F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014893D778, ????);
            label_13:
            // 0x0143A0F8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A0FC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A100: MOV x1, x22                | X1 = val_8;//m1                         
            // 0x0143A104: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143A108: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x0143A10C: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x0143A110: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_13 = null;
            // 0x0143A114: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x0143A118: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A11C: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0143A120: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x0143A124: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x0143A128: BL #0xd81d7c               | .ctor(name:  val_16, args:  val_15);    
            val_13 = new CEvent.ZEvent(name:  val_16, args:  val_15);
            // 0x0143A12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A130: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0143A134: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0143A138: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0143A13C: MOV x3, x20                | X3 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x0143A140: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143A144: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_14 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0143A148: SUB sp, x29, #0x50         | SP = (1152921510119462864 - 80) = 1152921510119462784 (0x100000014893D780);
            // 0x0143A14C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0143A150: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0143A154: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0143A158: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0143A15C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0143A160: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0143A164: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_14;
            return val_14;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143A168: MOV x19, x0                | 
            // 0x0143A16C: ADD x0, sp, #8             | 
            // 0x0143A170: B #0x143a17c               | 
            // 0x0143A174: MOV x19, x0                | 
            // 0x0143A178: MOV x0, sp                 | 
            label_14:
            // 0x0143A17C: BL #0x299a140              | 
            // 0x0143A180: MOV x0, x19                | 
            // 0x0143A184: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0143A188 (21209480), len: 920  VirtAddr: 0x0143A188 RVA: 0x0143A188 token: 100664209 methodIndex: 30256 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_19;
            //  | 
            string val_22;
            // 0x0143A188: STP x28, x27, [sp, #-0x60]! | stack[1152921510119681280] = ???;  stack[1152921510119681288] = ???;  //  dest_result_addr=1152921510119681280 |  dest_result_addr=1152921510119681288
            // 0x0143A18C: STP x26, x25, [sp, #0x10]  | stack[1152921510119681296] = ???;  stack[1152921510119681304] = ???;  //  dest_result_addr=1152921510119681296 |  dest_result_addr=1152921510119681304
            // 0x0143A190: STP x24, x23, [sp, #0x20]  | stack[1152921510119681312] = ???;  stack[1152921510119681320] = ???;  //  dest_result_addr=1152921510119681312 |  dest_result_addr=1152921510119681320
            // 0x0143A194: STP x22, x21, [sp, #0x30]  | stack[1152921510119681328] = ???;  stack[1152921510119681336] = ???;  //  dest_result_addr=1152921510119681328 |  dest_result_addr=1152921510119681336
            // 0x0143A198: STP x20, x19, [sp, #0x40]  | stack[1152921510119681344] = ???;  stack[1152921510119681352] = ???;  //  dest_result_addr=1152921510119681344 |  dest_result_addr=1152921510119681352
            // 0x0143A19C: STP x29, x30, [sp, #0x50]  | stack[1152921510119681360] = ???;  stack[1152921510119681368] = ???;  //  dest_result_addr=1152921510119681360 |  dest_result_addr=1152921510119681368
            // 0x0143A1A0: ADD x29, sp, #0x50         | X29 = (1152921510119681280 + 80) = 1152921510119681360 (0x1000000148972D50);
            // 0x0143A1A4: SUB sp, sp, #0x10          | SP = (1152921510119681280 - 16) = 1152921510119681264 (0x1000000148972CF0);
            // 0x0143A1A8: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x0143A1AC: LDRB w8, [x21, #0x6d]      | W8 = (bool)static_value_0373706D;       
            // 0x0143A1B0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x0143A1B4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x0143A1B8: MOV x20, x1                | X20 = X1;//m1                           
            // 0x0143A1BC: TBNZ w8, #0, #0x143a1d8    | if (static_value_0373706D == true) goto label_0;
            // 0x0143A1C0: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x0143A1C4: LDR x8, [x8, #0xbc0]       | X8 = 0x2B904E8;                         
            // 0x0143A1C8: LDR w0, [x8]               | W0 = 0x17FE;                            
            // 0x0143A1CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17FE, ????);     
            // 0x0143A1D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0143A1D4: STRB w8, [x21, #0x6d]      | static_value_0373706D = true;            //  dest_result_addr=57897069
            label_0:
            // 0x0143A1D8: CBNZ x20, #0x143a1e0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x0143A1DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17FE, ????);     
            label_1:
            // 0x0143A1E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A1E4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A1E8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x0143A1EC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x0143A1F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A1F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A1F8: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x0143A1FC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143A200: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143A204: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x0143A208: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A20C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A210: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x0143A214: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143A218: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143A21C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0143A220: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0143A224: ADRP x27, #0x363f000       | X27 = 56881152 (0x363F000);             
            // 0x0143A228: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x0143A22C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x0143A230: LDR x27, [x27, #0xa88]     | X27 = 1152921504606900224;              
            // 0x0143A234: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x0143A238: LDR x24, [x27]             | X24 = typeof(System.Object);            
            // 0x0143A23C: TBZ w9, #0, #0x143a250     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0143A240: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0143A244: CBNZ w9, #0x143a250        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0143A248: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x0143A24C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x0143A250: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A254: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A258: MOV x1, x24                | X1 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x0143A25C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A260: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x0143A264: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x0143A268: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x0143A26C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x0143A270: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x0143A274: TBZ w9, #0, #0x143a288     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0143A278: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x0143A27C: CBNZ w9, #0x143a288        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0143A280: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x0143A284: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x0143A288: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A28C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143A290: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143A294: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143A298: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0143A29C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143A2A0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x0143A2A4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x0143A2A8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x0143A2AC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x0143A2B0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x0143A2B4: TBZ w9, #0, #0x143a2c8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x0143A2B8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x0143A2BC: CBNZ w9, #0x143a2c8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x0143A2C0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x0143A2C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x0143A2C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A2CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A2D0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x0143A2D4: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x0143A2D8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x0143A2DC: MOV x24, x0                | X24 = val_6;//m1                        
            // 0x0143A2E0: CBNZ x20, #0x143a2e8       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x0143A2E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x0143A2E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A2EC: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A2F0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x0143A2F4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143A2F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A2FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A300: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x0143A304: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143A308: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143A30C: LDR x1, [x27]              | X1 = typeof(System.Object);             
            // 0x0143A310: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x0143A314: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A318: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A31C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A320: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x0143A324: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A328: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143A32C: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x0143A330: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143A334: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0143A338: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143A33C: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x0143A340: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A344: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A348: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x0143A34C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x0143A350: MOV x25, x0                | X25 = val_10;//m1                       
            // 0x0143A354: CBNZ x20, #0x143a35c       | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x0143A358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_9:
            // 0x0143A35C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A360: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A364: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x0143A368: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143A36C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A370: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A374: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x0143A378: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143A37C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143A380: LDR x1, [x27]              | X1 = typeof(System.Object);             
            // 0x0143A384: MOV x27, x0                | X27 = val_11;//m1                       
            // 0x0143A388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A38C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A390: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A394: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x0143A398: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A39C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143A3A0: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x0143A3A4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143A3A8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0143A3AC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_13 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143A3B0: MOV x2, x0                 | X2 = val_13;//m1                        
            // 0x0143A3B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A3B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A3BC: MOV x1, x26                | X1 = val_12;//m1                        
            // 0x0143A3C0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            object val_14 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            // 0x0143A3C4: MOV x26, x0                | X26 = val_14;//m1                       
            // 0x0143A3C8: CBNZ x20, #0x143a3d0       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x0143A3CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_10:
            // 0x0143A3D0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A3D4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A3D8: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x0143A3DC: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143A3E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A3E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A3E8: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x0143A3EC: MOV x1, x22                | X1 = X2;//m1                            
            // 0x0143A3F0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x0143A3F4: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x0143A3F8: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x0143A3FC: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x0143A400: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A404: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A408: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143A40C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0143A410: MOV x27, x0                | X27 = val_16;//m1                       
            // 0x0143A414: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A418: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x0143A41C: MOV x1, x22                | X1 = val_15;//m1                        
            // 0x0143A420: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x0143A424: MOV x3, x19                | X3 = X3;//m1                            
            // 0x0143A428: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_17 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x0143A42C: MOV x2, x0                 | X2 = val_17;//m1                        
            // 0x0143A430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A434: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0143A438: MOV x1, x27                | X1 = val_16;//m1                        
            // 0x0143A43C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            object val_18 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            // 0x0143A440: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_22 = 0;
            // 0x0143A444: CBZ x0, #0x143a48c         | if (val_18 == null) goto label_12;      
            if(val_18 == null)
            {
                goto label_12;
            }
            // 0x0143A448: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0143A44C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x0143A450: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x0143A454: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x0143A458: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x0143A45C: MOV x23, x0                | X23 = val_18;//m1                       
            val_22 = val_18;
            // 0x0143A460: B.EQ #0x143a48c            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x0143A464: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x0143A468: ADD x8, sp, #8             | X8 = (1152921510119681264 + 8) = 1152921510119681272 (0x1000000148972CF8);
            // 0x0143A46C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x0143A470: LDR x0, [sp, #8]           | X0 = val_19;                             //  find_add[1152921510119669376]
            // 0x0143A474: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x0143A478: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0143A47C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x0143A480: ADD x0, sp, #8             | X0 = (1152921510119681264 + 8) = 1152921510119681272 (0x1000000148972CF8);
            // 0x0143A484: BL #0x299a140              | 
            // 0x0143A488: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_22 = 0;
            label_12:
            // 0x0143A48C: CBNZ x20, #0x143a494       | if (X1 != 0) goto label_13;             
            if(X1 != 0)
            {
                goto label_13;
            }
            // 0x0143A490: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148972CF8, ????);
            label_13:
            // 0x0143A494: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0143A498: MOV x0, x20                | X0 = X1;//m1                            
            // 0x0143A49C: MOV x1, x22                | X1 = val_15;//m1                        
            // 0x0143A4A0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x0143A4A4: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x0143A4A8: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
            // 0x0143A4AC: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
            CEvent.ZEvent val_20 = null;
            // 0x0143A4B0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
            // 0x0143A4B4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143A4B8: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x0143A4BC: MOV x2, x26                | X2 = val_14;//m1                        
            // 0x0143A4C0: MOV x3, x25                | X3 = val_10;//m1                        
            // 0x0143A4C4: MOV x4, x24                | X4 = val_6;//m1                         
            // 0x0143A4C8: MOV x20, x0                | X20 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x0143A4CC: BL #0xd81df8               | .ctor(name:  val_22, arg:  val_14, arg1:  val_10, arg2:  val_6);
            val_20 = new CEvent.ZEvent(name:  val_22, arg:  val_14, arg1:  val_10, arg2:  val_6);
            // 0x0143A4D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0143A4D4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x0143A4D8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x0143A4DC: MOV x2, x19                | X2 = X3;//m1                            
            // 0x0143A4E0: MOV x3, x20                | X3 = 1152921504898326528 (0x10000000115FA000);//ML01
            // 0x0143A4E4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0143A4E8: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_21 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  ???, isBox:  ???);
            // 0x0143A4EC: SUB sp, x29, #0x50         | SP = (1152921510119681360 - 80) = 1152921510119681280 (0x1000000148972D00);
            // 0x0143A4F0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x0143A4F4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x0143A4F8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x0143A4FC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0143A500: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x0143A504: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x0143A508: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_21;
            return val_21;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x0143A50C: MOV x19, x0                | 
            // 0x0143A510: ADD x0, sp, #8             | 
            // 0x0143A514: BL #0x299a140              | 
            // 0x0143A518: MOV x0, x19                | 
            // 0x0143A51C: BL #0x980800               | 
        
        }
    
    }

}
