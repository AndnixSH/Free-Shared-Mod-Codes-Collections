using UnityEngine;

namespace Mihua.Asset.ABLoadOperation
{
    public abstract class AssetOperation : ABOperation
    {
        // Fields
        public bool isAsync; //  0x00000011
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AAF6B8 (11204280), len: 16  VirtAddr: 0x00AAF6B8 RVA: 0x00AAF6B8 token: 100693162 methodIndex: 46902 delegateWrapperIndex: 0 methodInvoker: 0
        protected AssetOperation()
        {
            //
            // Disasemble & Code
            // 0x00AAF6B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAF6BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAF6C0: STRB w8, [x0, #0x11]       | this.isAsync = true;                     //  dest_result_addr=1152921514947114497
            this.isAsync = true;
            // 0x00AAF6C4: B #0x16f59f0               | this..ctor(); return;                   
            val_1 = new System.Object();
            return;
        
        }
        public abstract UnityEngine.Object GetAsset(); // 0
    
    }

}
