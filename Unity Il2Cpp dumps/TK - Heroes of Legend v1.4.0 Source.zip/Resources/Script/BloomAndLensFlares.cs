using UnityEngine;
[UnityEngine.RequireComponent] // 0x281A570
[UnityEngine.AddComponentMenu] // 0x281A570
[UnityEngine.ExecuteInEditMode] // 0x281A570
[Serializable]
public class BloomAndLensFlares : PostEffectsBase
{
    // Fields
    public TweakMode34 tweakMode; //  0x0000001C
    public BloomScreenBlendMode screenBlendMode; //  0x00000020
    public HDRBloomMode hdr; //  0x00000024
    private bool doHdr; //  0x00000028
    public float sepBlurSpread; //  0x0000002C
    public float useSrcAlphaAsMask; //  0x00000030
    public float bloomIntensity; //  0x00000034
    public float bloomThreshhold; //  0x00000038
    public int bloomBlurIterations; //  0x0000003C
    public bool lensflares; //  0x00000040
    public int hollywoodFlareBlurIterations; //  0x00000044
    public LensflareStyle34 lensflareMode; //  0x00000048
    public float hollyStretchWidth; //  0x0000004C
    public float lensflareIntensity; //  0x00000050
    public float lensflareThreshhold; //  0x00000054
    public UnityEngine.Color flareColorA; //  0x00000058
    public UnityEngine.Color flareColorB; //  0x00000068
    public UnityEngine.Color flareColorC; //  0x00000078
    public UnityEngine.Color flareColorD; //  0x00000088
    public float blurWidth; //  0x00000098
    public UnityEngine.Texture2D lensFlareVignetteMask; //  0x000000A0
    public UnityEngine.Shader lensFlareShader; //  0x000000A8
    private UnityEngine.Material lensFlareMaterial; //  0x000000B0
    public UnityEngine.Shader vignetteShader; //  0x000000B8
    private UnityEngine.Material vignetteMaterial; //  0x000000C0
    public UnityEngine.Shader separableBlurShader; //  0x000000C8
    private UnityEngine.Material separableBlurMaterial; //  0x000000D0
    public UnityEngine.Shader addBrightStuffOneOneShader; //  0x000000D8
    private UnityEngine.Material addBrightStuffBlendOneOneMaterial; //  0x000000E0
    public UnityEngine.Shader screenBlendShader; //  0x000000E8
    private UnityEngine.Material screenBlend; //  0x000000F0
    public UnityEngine.Shader hollywoodFlaresShader; //  0x000000F8
    private UnityEngine.Material hollywoodFlaresMaterial; //  0x00000100
    public UnityEngine.Shader brightPassFilterShader; //  0x00000108
    private UnityEngine.Material brightPassFilterMaterial; //  0x00000110
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x02673E9C (40320668), len: 332  VirtAddr: 0x02673E9C RVA: 0x02673E9C token: 100663316 methodIndex: 24400 delegateWrapperIndex: 0 methodInvoker: 0
    public BloomAndLensFlares()
    {
        //
        // Disasemble & Code
        // 0x02673E9C: STP d11, d10, [sp, #-0x40]! | stack[1152921509946338832] = ???;  stack[1152921509946338840] = ???;  //  dest_result_addr=1152921509946338832 |  dest_result_addr=1152921509946338840
        // 0x02673EA0: STP d9, d8, [sp, #0x10]    | stack[1152921509946338848] = ???;  stack[1152921509946338856] = ???;  //  dest_result_addr=1152921509946338848 |  dest_result_addr=1152921509946338856
        // 0x02673EA4: STP x20, x19, [sp, #0x20]  | stack[1152921509946338864] = ???;  stack[1152921509946338872] = ???;  //  dest_result_addr=1152921509946338864 |  dest_result_addr=1152921509946338872
        // 0x02673EA8: STP x29, x30, [sp, #0x30]  | stack[1152921509946338880] = ???;  stack[1152921509946338888] = ???;  //  dest_result_addr=1152921509946338880 |  dest_result_addr=1152921509946338888
        // 0x02673EAC: ADD x29, sp, #0x30         | X29 = (1152921509946338832 + 48) = 1152921509946338880 (0x100000013E422E40);
        // 0x02673EB0: SUB sp, sp, #0x40          | SP = (1152921509946338832 - 64) = 1152921509946338768 (0x100000013E422DD0);
        // 0x02673EB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673EB8: MOV x19, x0                | X19 = 1152921509946350896 (0x100000013E425D30);//ML01
        // 0x02673EBC: BL #0x1b76fd4              | this..ctor();                           
        val_1 = new UnityEngine.MonoBehaviour();
        // 0x02673EC0: ADRP x9, #0x2ac3000        | X9 = 44838912 (0x2AC3000);              
        // 0x02673EC4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02673EC8: LDR q0, [x9, #0xc50]       | Q0 = ;                                  
        // 0x02673ECC: ORR w9, wzr, #2            | W9 = 2(0x2);                            
        // 0x02673ED0: STR wzr, [x19, #0x24]      | this.hdr = null;                         //  dest_result_addr=1152921509946350932
        this.hdr = 0;
        // 0x02673ED4: STR w9, [x19, #0x3c]       | this.bloomBlurIterations = 2;            //  dest_result_addr=1152921509946350956
        this.bloomBlurIterations = 2;
        // 0x02673ED8: STP w9, w8, [x19, #0x44]   | this.hollywoodFlareBlurIterations = 2;  this.lensflareMode = 0x1;  //  dest_result_addr=1152921509946350964 |  dest_result_addr=1152921509946350968
        this.hollywoodFlareBlurIterations = 2;
        this.lensflareMode = 1;
        // 0x02673EDC: ORR x9, xzr, #0x3f8000003f800000 | X9 = 4575657222473777152(0x3F8000003F800000);
        // 0x02673EE0: STRB w8, [x19, #0x18]      | mem[1152921509946350920] = 0x1;          //  dest_result_addr=1152921509946350920
        mem[1152921509946350920] = 1;
        // 0x02673EE4: STRB w8, [x19, #0x1a]      | mem[1152921509946350922] = 0x1;          //  dest_result_addr=1152921509946350922
        mem[1152921509946350922] = 1;
        // 0x02673EE8: STR w8, [x19, #0x20]       | this.screenBlendMode = 0x1;              //  dest_result_addr=1152921509946350928
        this.screenBlendMode = 1;
        // 0x02673EEC: MOVZ w8, #0x3e99, lsl #16  | W8 = 1050214400 (0x3E990000);//ML01     
        // 0x02673EF0: MOVK x9, #0x4060, lsl #16  | X9 = 4575657223553810432 (0x3F8000007FE00000);
        // 0x02673EF4: MOVK w8, #0x999a           | W8 = 1050253722 (0x3E99999A);           
        // 0x02673EF8: STUR x9, [x19, #0x4c]      | this.hollyStretchWidth = NaN; this.lensflareIntensity = 1;  //  dest_result_addr=1152921509946350972 dest_result_addr=1152921509946350976
        this.hollyStretchWidth = 0f;
        this.lensflareIntensity = 1f;
        // 0x02673EFC: STR w8, [x19, #0x54]       | this.lensflareThreshhold = 0.3;          //  dest_result_addr=1152921509946350980
        this.lensflareThreshhold = 0.3f;
        // 0x02673F00: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x02673F04: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x02673F08: LDR s8, [x8, #0x790]       | S8 = 0.4;                               
        // 0x02673F0C: LDR s9, [x9, #0x918]       | S9 = 0.8;                               
        // 0x02673F10: FMOV s10, #0.75000000      | S10 = 0.75;                             
        // 0x02673F14: STUR q0, [x19, #0x2c]      | this.sepBlurSpread = ; this.useSrcAlphaAsMask = ; this.bloomIntensity = 1; this.bloomThreshhold = 0.5;  //  dest_result_addr=1152921509946350940 dest_result_addr=1152921509946350944 dest_result_addr=1152921509946350948 dest_result_addr=1152921509946350952
        this.sepBlurSpread = ;
        this.useSrcAlphaAsMask = ;
        this.bloomIntensity = 1f;
        this.bloomThreshhold = 0.5f;
        // 0x02673F18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673F1C: ADD x0, sp, #0x30          | X0 = (1152921509946338768 + 48) = 1152921509946338816 (0x100000013E422E00);
        // 0x02673F20: MOV v0.16b, v8.16b         | V0 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02673F24: MOV v1.16b, v8.16b         | V1 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02673F28: MOV v2.16b, v9.16b         | V2 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02673F2C: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x02673F30: STP xzr, xzr, [sp, #0x30]  | stack[1152921509946338816] = 0x0;  stack[1152921509946338824] = 0x0;  //  dest_result_addr=1152921509946338816 |  dest_result_addr=1152921509946338824
        // 0x02673F34: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02673F38: LDR w8, [sp, #0x30]        | W8 = 0x0;                               
        // 0x02673F3C: LDUR x9, [sp, #0x34]       | X9 = 0x0;                               
        // 0x02673F40: LDR w10, [sp, #0x3c]       | W10 = 0x0;                              
        // 0x02673F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673F48: ADD x0, sp, #0x20          | X0 = (1152921509946338768 + 32) = 1152921509946338800 (0x100000013E422DF0);
        // 0x02673F4C: MOV v0.16b, v8.16b         | V0 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02673F50: MOV v1.16b, v9.16b         | V1 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02673F54: MOV v2.16b, v9.16b         | V2 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02673F58: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x02673F5C: STR w8, [x19, #0x58]       | this.flareColorA = new UnityEngine.Color();  //  dest_result_addr=1152921509946350984
        this.flareColorA = 0;
        // 0x02673F60: STUR x9, [x19, #0x5c]      | mem[1152921509946350988] = 0x0;          //  dest_result_addr=1152921509946350988
        mem[1152921509946350988] = 0;
        // 0x02673F64: STR w10, [x19, #0x64]      | mem[1152921509946350996] = 0x0;          //  dest_result_addr=1152921509946350996
        mem[1152921509946350996] = 0;
        // 0x02673F68: STP xzr, xzr, [sp, #0x20]  | stack[1152921509946338800] = 0x0;  stack[1152921509946338808] = 0x0;  //  dest_result_addr=1152921509946338800 |  dest_result_addr=1152921509946338808
        // 0x02673F6C: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02673F70: LDR q0, [sp, #0x20]        | Q0 = 0x0;                               
        // 0x02673F74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673F78: ADD x0, sp, #0x10          | X0 = (1152921509946338768 + 16) = 1152921509946338784 (0x100000013E422DE0);
        // 0x02673F7C: MOV v1.16b, v8.16b         | V1 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02673F80: STUR q0, [x19, #0x68]      | this.flareColorB = new UnityEngine.Color();  //  dest_result_addr=1152921509946351000
        this.flareColorB = 0;
        // 0x02673F84: MOV v0.16b, v9.16b         | V0 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02673F88: MOV v2.16b, v9.16b         | V2 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02673F8C: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x02673F90: STP xzr, xzr, [sp, #0x10]  | stack[1152921509946338784] = 0x0;  stack[1152921509946338792] = 0x0;  //  dest_result_addr=1152921509946338784 |  dest_result_addr=1152921509946338792
        // 0x02673F94: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02673F98: LDR q0, [sp, #0x10]        | Q0 = 0x0;                               
        // 0x02673F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02673FA0: FMOV s2, wzr               | S2 = 0f;                                
        // 0x02673FA4: MOV x0, sp                 | X0 = 1152921509946338768 (0x100000013E422DD0);//ML01
        // 0x02673FA8: STUR q0, [x19, #0x78]      | this.flareColorC = new UnityEngine.Color();  //  dest_result_addr=1152921509946351016
        this.flareColorC = 0;
        // 0x02673FAC: MOV v0.16b, v9.16b         | V0 = 1061997773 (0x3F4CCCCD);//ML01     
        // 0x02673FB0: MOV v1.16b, v8.16b         | V1 = 1053609165 (0x3ECCCCCD);//ML01     
        // 0x02673FB4: MOV v3.16b, v10.16b        | V3 = 0.75;//m1                          
        // 0x02673FB8: STP xzr, xzr, [sp]         | stack[1152921509946338768] = 0x0;  stack[1152921509946338776] = 0x0;  //  dest_result_addr=1152921509946338768 |  dest_result_addr=1152921509946338776
        // 0x02673FBC: BL #0x20d3350              | X0 = label_UnityEngine_ClassLibraryInitializer_Init_GL020D3350();
        // 0x02673FC0: LDR q0, [sp]               | Q0 = 0x0;                               
        // 0x02673FC4: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
        // 0x02673FC8: STR w8, [x19, #0x98]       | this.blurWidth = 1;                      //  dest_result_addr=1152921509946351048
        this.blurWidth = 1f;
        // 0x02673FCC: STUR q0, [x19, #0x88]      | this.flareColorD = new UnityEngine.Color();  //  dest_result_addr=1152921509946351032
        this.flareColorD = 0;
        // 0x02673FD0: SUB sp, x29, #0x30         | SP = (1152921509946338880 - 48) = 1152921509946338832 (0x100000013E422E10);
        // 0x02673FD4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02673FD8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02673FDC: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x02673FE0: LDP d11, d10, [sp], #0x40  | D11 = ; D10 = ;                          //  | 
        // 0x02673FE4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02673FE8 (40321000), len: 248  VirtAddr: 0x02673FE8 RVA: 0x02673FE8 token: 100663317 methodIndex: 24401 delegateWrapperIndex: 0 methodInvoker: 0
    public override bool CheckResources()
    {
        //
        // Disasemble & Code
        //  | 
        var val_2;
        // 0x02673FE8: STP x20, x19, [sp, #-0x20]! | stack[1152921509946508208] = ???;  stack[1152921509946508216] = ???;  //  dest_result_addr=1152921509946508208 |  dest_result_addr=1152921509946508216
        // 0x02673FEC: STP x29, x30, [sp, #0x10]  | stack[1152921509946508224] = ???;  stack[1152921509946508232] = ???;  //  dest_result_addr=1152921509946508224 |  dest_result_addr=1152921509946508232
        // 0x02673FF0: ADD x29, sp, #0x10         | X29 = (1152921509946508208 + 16) = 1152921509946508224 (0x100000013E44C3C0);
        // 0x02673FF4: MOV x19, x0                | X19 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x02673FF8: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02673FFC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x02674000: LDP x9, x2, [x8, #0x1b0]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_1B0; X2 = typeof(BloomAndLensFlares).__il2cppRuntimeField_1B8; //  | 
        // 0x02674004: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_1B0();
        // 0x02674008: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x0267400C: LDP x1, x2, [x19, #0xe8]   | X1 = this.screenBlendShader; //P2  X2 = this.screenBlend; //P2  //  | 
        // 0x02674010: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x02674014: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x02674018: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x0267401C: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674020: STR x0, [x19, #0xf0]       | this.screenBlend = this;                 //  dest_result_addr=1152921509946520480
        this.screenBlend = this;
        // 0x02674024: LDP x1, x2, [x19, #0xa8]   | X1 = this.lensFlareShader; //P2  X2 = this.lensFlareMaterial; //P2  //  | 
        // 0x02674028: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x0267402C: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x02674030: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x02674034: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674038: STR x0, [x19, #0xb0]       | this.lensFlareMaterial = this;           //  dest_result_addr=1152921509946520416
        this.lensFlareMaterial = this;
        // 0x0267403C: LDP x1, x2, [x19, #0xb8]   | X1 = this.vignetteShader; //P2  X2 = this.vignetteMaterial; //P2  //  | 
        // 0x02674040: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x02674044: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x02674048: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x0267404C: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674050: STR x0, [x19, #0xc0]       | this.vignetteMaterial = this;            //  dest_result_addr=1152921509946520432
        this.vignetteMaterial = this;
        // 0x02674054: LDP x1, x2, [x19, #0xc8]   | X1 = this.separableBlurShader; //P2  X2 = this.separableBlurMaterial; //P2  //  | 
        // 0x02674058: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x0267405C: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x02674060: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x02674064: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674068: STR x0, [x19, #0xd0]       | this.separableBlurMaterial = this;       //  dest_result_addr=1152921509946520448
        this.separableBlurMaterial = this;
        // 0x0267406C: LDP x1, x2, [x19, #0xd8]   | X1 = this.addBrightStuffOneOneShader; //P2  X2 = this.addBrightStuffBlendOneOneMaterial; //P2  //  | 
        // 0x02674070: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x02674074: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x02674078: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x0267407C: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674080: STR x0, [x19, #0xe0]       | this.addBrightStuffBlendOneOneMaterial = this;  //  dest_result_addr=1152921509946520464
        this.addBrightStuffBlendOneOneMaterial = this;
        // 0x02674084: LDP x1, x2, [x19, #0xf8]   | X1 = this.hollywoodFlaresShader; //P2  X2 = this.hollywoodFlaresMaterial; //P2  //  | 
        // 0x02674088: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x0267408C: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x02674090: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x02674094: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674098: STR x0, [x19, #0x100]      | this.hollywoodFlaresMaterial = this;     //  dest_result_addr=1152921509946520496
        this.hollywoodFlaresMaterial = this;
        // 0x0267409C: LDP x1, x2, [x19, #0x108]  | X1 = this.brightPassFilterShader; //P2  X2 = this.brightPassFilterMaterial; //P2  //  | 
        // 0x026740A0: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x026740A4: LDP x9, x3, [x8, #0x150]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150; X3 = typeof(BloomAndLensFlares).__il2cppRuntimeField_158; //  | 
        // 0x026740A8: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_150();
        // 0x026740AC: LDRB w8, [x19, #0x1a]      | 
        // 0x026740B0: STR x0, [x19, #0x110]      | this.brightPassFilterMaterial = this;    //  dest_result_addr=1152921509946520512
        this.brightPassFilterMaterial = this;
        // 0x026740B4: CBNZ w8, #0x26740cc        | if (typeof(BloomAndLensFlares) != null) goto label_0;
        if(null != null)
        {
            goto label_0;
        }
        // 0x026740B8: LDR x8, [x19]              | X8 = typeof(BloomAndLensFlares);        
        // 0x026740BC: MOV x0, x19                | X0 = 1152921509946520240 (0x100000013E44F2B0);//ML01
        // 0x026740C0: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_1E0; X1 = typeof(BloomAndLensFlares).__il2cppRuntimeField_1E8; //  | 
        // 0x026740C4: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_1E0();
        // 0x026740C8: LDRB w8, [x19, #0x1a]      | 
        label_0:
        // 0x026740CC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026740D0: CMP w8, #0                 | STATE = COMPARE(typeof(BloomAndLensFlares), 0x0)
        // 0x026740D4: CSET w0, ne                | W0 = typeof(BloomAndLensFlares) != null ? 1 : 0;
        var val_1 = (null != 0) ? 1 : 0;
        // 0x026740D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026740DC: RET                        |  return (System.Boolean)typeof(BloomAndLensFlares) != null ? 1 : 0;
        return (bool)val_1;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x026740E0 (40321248), len: 3220  VirtAddr: 0x026740E0 RVA: 0x026740E0 token: 100663318 methodIndex: 24402 delegateWrapperIndex: 0 methodInvoker: 0
    public override void OnRenderImage(UnityEngine.RenderTexture source, UnityEngine.RenderTexture destination)
    {
        //
        // Disasemble & Code
        //  | 
        var val_44;
        //  | 
        float val_45;
        //  | 
        float val_46;
        //  | 
        float val_47;
        //  | 
        float val_48;
        // 0x026740E0: STP d13, d12, [sp, #-0x90]! | stack[1152921509946841568] = ???;  stack[1152921509946841576] = ???;  //  dest_result_addr=1152921509946841568 |  dest_result_addr=1152921509946841576
        // 0x026740E4: STP d11, d10, [sp, #0x10]  | stack[1152921509946841584] = ???;  stack[1152921509946841592] = ???;  //  dest_result_addr=1152921509946841584 |  dest_result_addr=1152921509946841592
        // 0x026740E8: STP d9, d8, [sp, #0x20]    | stack[1152921509946841600] = ???;  stack[1152921509946841608] = ???;  //  dest_result_addr=1152921509946841600 |  dest_result_addr=1152921509946841608
        // 0x026740EC: STP x28, x27, [sp, #0x30]  | stack[1152921509946841616] = ???;  stack[1152921509946841624] = ???;  //  dest_result_addr=1152921509946841616 |  dest_result_addr=1152921509946841624
        // 0x026740F0: STP x26, x25, [sp, #0x40]  | stack[1152921509946841632] = ???;  stack[1152921509946841640] = ???;  //  dest_result_addr=1152921509946841632 |  dest_result_addr=1152921509946841640
        // 0x026740F4: STP x24, x23, [sp, #0x50]  | stack[1152921509946841648] = ???;  stack[1152921509946841656] = ???;  //  dest_result_addr=1152921509946841648 |  dest_result_addr=1152921509946841656
        // 0x026740F8: STP x22, x21, [sp, #0x60]  | stack[1152921509946841664] = ???;  stack[1152921509946841672] = ???;  //  dest_result_addr=1152921509946841664 |  dest_result_addr=1152921509946841672
        // 0x026740FC: STP x20, x19, [sp, #0x70]  | stack[1152921509946841680] = ???;  stack[1152921509946841688] = ???;  //  dest_result_addr=1152921509946841680 |  dest_result_addr=1152921509946841688
        // 0x02674100: STP x29, x30, [sp, #0x80]  | stack[1152921509946841696] = ???;  stack[1152921509946841704] = ???;  //  dest_result_addr=1152921509946841696 |  dest_result_addr=1152921509946841704
        // 0x02674104: ADD x29, sp, #0x80         | X29 = (1152921509946841568 + 128) = 1152921509946841696 (0x100000013E49DA60);
        // 0x02674108: SUB sp, sp, #0x40          | SP = (1152921509946841568 - 64) = 1152921509946841504 (0x100000013E49D9A0);
        // 0x0267410C: ADRP x19, #0x3740000       | X19 = 57933824 (0x3740000);             
        // 0x02674110: LDRB w8, [x19, #0xe4c]     | W8 = (bool)static_value_03740E4C;       
        // 0x02674114: MOV x23, x2                | X23 = destination;//m1                  
        // 0x02674118: MOV x20, x1                | X20 = source;//m1                       
        // 0x0267411C: MOV x21, x0                | X21 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674120: TBNZ w8, #0, #0x267413c    | if (static_value_03740E4C == true) goto label_0;
        // 0x02674124: ADRP x8, #0x35fb000        | X8 = 56602624 (0x35FB000);              
        // 0x02674128: LDR x8, [x8, #0xaf0]       | X8 = 0x2B8F6BC;                         
        // 0x0267412C: LDR w0, [x8]               | W0 = 0x1473;                            
        // 0x02674130: BL #0x2782188              | X0 = sub_2782188( ?? 0x1473, ????);     
        // 0x02674134: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02674138: STRB w8, [x19, #0xe4c]     | static_value_03740E4C = true;            //  dest_result_addr=57937484
        label_0:
        // 0x0267413C: LDR x8, [x21]              | X8 = typeof(BloomAndLensFlares);        
        // 0x02674140: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674144: LDP x9, x1, [x8, #0x190]   | X9 = typeof(BloomAndLensFlares).__il2cppRuntimeField_190; X1 = typeof(BloomAndLensFlares).__il2cppRuntimeField_198; //  | 
        // 0x02674148: BLR x9                     | X0 = typeof(BloomAndLensFlares).__il2cppRuntimeField_190();
        // 0x0267414C: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
        // 0x02674150: TBZ w8, #0, #0x267416c     | if (((BloomAndLensFlares)[1152921509946853712] & 0x1) == 0) goto label_1;
        if((0 & 1) == 0)
        {
            goto label_1;
        }
        // 0x02674154: LDR w8, [x21, #0x24]       | W8 = this.hdr; //P2                     
        // 0x02674158: STRB wzr, [x21, #0x28]     | this.doHdr = false;                      //  dest_result_addr=1152921509946853752
        this.doHdr = false;
        // 0x0267415C: CBZ w8, #0x26741c8         | if (this.hdr == 0) goto label_2;        
        if(this.hdr == 0)
        {
            goto label_2;
        }
        // 0x02674160: CMP w8, #1                 | STATE = COMPARE(this.hdr, 0x1)          
        // 0x02674164: CSET w19, eq               | W19 = this.hdr == 0x1 ? 1 : 0;          
        var val_1 = (this.hdr == 1) ? 1 : 0;
        // 0x02674168: B #0x2674220               |  goto label_9;                          
        goto label_9;
        label_1:
        // 0x0267416C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02674170: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02674174: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674178: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267417C: TBZ w8, #0, #0x267418c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x02674180: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674184: CBNZ w8, #0x267418c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x02674188: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_5:
        // 0x0267418C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674190: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02674194: MOV x1, x20                | X1 = source;//m1                        
        // 0x02674198: MOV x2, x23                | X2 = destination;//m1                   
        // 0x0267419C: SUB sp, x29, #0x80         | SP = (1152921509946841696 - 128) = 1152921509946841568 (0x100000013E49D9E0);
        // 0x026741A0: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x026741A4: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x026741A8: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x026741AC: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x026741B0: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x026741B4: LDP x28, x27, [sp, #0x30]  | X28 = ; X27 = ;                          //  | 
        // 0x026741B8: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x026741BC: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x026741C0: LDP d13, d12, [sp], #0x90  | D13 = ; D12 = ;                          //  | 
        // 0x026741C4: B #0x1a6ba68               | UnityEngine.Graphics.Blit(source:  0, dest:  source); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  source);
        return;
        label_2:
        // 0x026741C8: CBNZ x20, #0x26741d0       | if (source != null) goto label_6;       
        if(source != null)
        {
            goto label_6;
        }
        // 0x026741CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_6:
        // 0x026741D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026741D4: MOV x0, x20                | X0 = source;//m1                        
        // 0x026741D8: BL #0x1b89830              | X0 = source.get_format();               
        UnityEngine.RenderTextureFormat val_2 = source.format;
        // 0x026741DC: CMP w0, #2                 | STATE = COMPARE(val_2, 0x2)             
        // 0x026741E0: CSET w19, eq               | W19 = val_2 == 0x2 ? 1 : 0;             
        var val_3 = (val_2 == 2) ? 1 : 0;
        // 0x026741E4: B.NE #0x2674218            | if (val_2 != 0x2) goto label_7;         
        if(val_2 != 2)
        {
            goto label_7;
        }
        // 0x026741E8: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
        // 0x026741EC: LDR x8, [x8, #0x338]       | X8 = 1152921509941328016;               
        // 0x026741F0: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x026741F4: LDR x1, [x8]               | X1 = public UnityEngine.Camera UnityEngine.Component::GetComponent<UnityEngine.Camera>();
        // 0x026741F8: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.Camera>();
        UnityEngine.Camera val_4 = this.GetComponent<UnityEngine.Camera>();
        // 0x026741FC: MOV x22, x0                | X22 = val_4;//m1                        
        // 0x02674200: CBNZ x22, #0x2674208       | if (val_4 != null) goto label_8;        
        if(val_4 != null)
        {
            goto label_8;
        }
        // 0x02674204: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x02674208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267420C: MOV x0, x22                | X0 = val_4;//m1                         
        // 0x02674210: BL #0x20cec84              | X0 = val_4.get_hdr();                   
        bool val_5 = val_4.hdr;
        // 0x02674214: AND w19, w0, #1            | W19 = (val_5 & 1);                      
        bool val_6 = val_5;
        label_7:
        // 0x02674218: CBNZ x21, #0x2674220       | if (this != null) goto label_9;         
        if(this != null)
        {
            goto label_9;
        }
        // 0x0267421C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x02674220: STRB w19, [x21, #0x28]     | this.doHdr = (val_5 & 1);                //  dest_result_addr=1152921509946853752
        this.doHdr = val_6;
        // 0x02674224: CBZ w19, #0x2674238        | if ((val_5 & 1) == false) goto label_10;
        if(val_6 == false)
        {
            goto label_10;
        }
        // 0x02674228: LDRB w8, [x21, #0x18]      | 
        // 0x0267422C: CMP w8, #0                 | STATE = COMPARE(1152921509941328016, 0x0)
        // 0x02674230: CSET w8, ne                | W8 = 1152921509941328016 != 0x0 ? 1 : 0;
        var val_7 = (1152921509941328016 != 0) ? 1 : 0;
        // 0x02674234: B #0x267423c               |  goto label_11;                         
        goto label_11;
        label_10:
        // 0x02674238: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
        label_11:
        // 0x0267423C: LDR w9, [x21, #0x20]       | W9 = this.screenBlendMode; //P2         
        // 0x02674240: CMP w8, #0                 | STATE = COMPARE(0x0, 0x0)               
        // 0x02674244: STRB w8, [x21, #0x28]      | this.doHdr = false;                      //  dest_result_addr=1152921509946853752
        this.doHdr = false;
        // 0x02674248: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0267424C: ORR w10, wzr, #7           | W10 = 7(0x7);                           
        // 0x02674250: ORR w11, wzr, #2           | W11 = 2(0x2);                           
        // 0x02674254: CSEL w8, w8, w9, ne        | W8 = false != 0x0 ? 1 : this.screenBlendMode;
        var val_8 = (false != 0) ? (1) : (this.screenBlendMode);
        // 0x02674258: CSEL w25, w11, w10, ne     | W25 = false != 0x0 ? 2 : 7;             
        var val_9 = (false != 0) ? (2) : (7);
        // 0x0267425C: STR w8, [sp, #4]           | stack[1152921509946841508] = false != 0x0 ? 1 : this.screenBlendMode;  //  dest_result_addr=1152921509946841508
        // 0x02674260: CBNZ x20, #0x2674268       | if (source != null) goto label_12;      
        if(source != null)
        {
            goto label_12;
        }
        // 0x02674264: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_12:
        // 0x02674268: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267426C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02674270: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02674274: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02674278: MOV w22, w0                | W22 = source;//m1                       
        // 0x0267427C: CBNZ x20, #0x2674284       | if (source != null) goto label_13;      
        if(source != null)
        {
            goto label_13;
        }
        // 0x02674280: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_13:
        // 0x02674284: STR x23, [sp, #8]          | stack[1152921509946841512] = destination;  //  dest_result_addr=1152921509946841512
        // 0x02674288: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267428C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02674290: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02674294: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02674298: CMP w22, #0                | STATE = COMPARE(source, 0x0)            
        // 0x0267429C: CINC w8, w22, lt           | W8 = source < null ? (source + 1) : source;
        var val_10 = (source < 0) ? (source + 1) : (source);
        // 0x026742A0: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x026742A4: CINC w9, w0, lt            | W9 = source < null ? (source + 1) : source;
        var val_11 = (source < 0) ? (source + 1) : (source);
        // 0x026742A8: ASR w1, w8, #1             | W1 = (source < null ? (source + 1) : source >> 1);
        int val_12 = val_10 >> 1;
        // 0x026742AC: ASR w2, w9, #1             | W2 = (source < null ? (source + 1) : source >> 1);
        int val_13 = val_11 >> 1;
        // 0x026742B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026742B4: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026742B8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026742BC: MOV w4, w25                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x026742C0: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  int val_12 = val_10 >> 1, depthBuffer:  int val_13 = val_11 >> 1, format:  0);
        UnityEngine.RenderTexture val_14 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_12, depthBuffer:  val_13, format:  0);
        // 0x026742C4: MOV x26, x0                | X26 = val_14;//m1                       
        // 0x026742C8: CBNZ x20, #0x26742d0       | if (source != null) goto label_14;      
        if(source != null)
        {
            goto label_14;
        }
        // 0x026742CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
        label_14:
        // 0x026742D0: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026742D4: MOV x0, x20                | X0 = source;//m1                        
        // 0x026742D8: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026742DC: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026742E0: MOV w23, w0                | W23 = source;//m1                       
        // 0x026742E4: CBNZ x20, #0x26742ec       | if (source != null) goto label_15;      
        if(source != null)
        {
            goto label_15;
        }
        // 0x026742E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_15:
        // 0x026742EC: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026742F0: MOV x0, x20                | X0 = source;//m1                        
        // 0x026742F4: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026742F8: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026742FC: ADD w8, w23, #3            | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_15 = source + 3;
        // 0x02674300: CMP w23, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02674304: ADD w9, w0, #3             | W9 = (source + 3);                      
        UnityEngine.RenderTexture val_16 = source + 3;
        // 0x02674308: CSEL w8, w8, w23, lt       | W8 = source < null ? (source + 3) : source;
        var val_17 = (source < 0) ? (val_15) : (source);
        // 0x0267430C: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x02674310: ASR w1, w8, #2             | W1 = (source < null ? (source + 3) : source >> 2);
        int val_18 = val_17 >> 2;
        // 0x02674314: CSEL w8, w9, w0, lt        | W8 = source < null ? (source + 3) : source;
        var val_19 = (source < 0) ? (val_16) : (source);
        // 0x02674318: ASR w2, w8, #2             | W2 = (source < null ? (source + 3) : source >> 2);
        int val_20 = val_19 >> 2;
        // 0x0267431C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674320: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02674324: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674328: MOV w4, w25                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x0267432C: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  int val_18 = val_17 >> 2, depthBuffer:  int val_20 = val_19 >> 2, format:  0);
        UnityEngine.RenderTexture val_21 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_18, depthBuffer:  val_20, format:  0);
        // 0x02674330: MOV x23, x0                | X23 = val_21;//m1                       
        // 0x02674334: CBNZ x20, #0x267433c       | if (source != null) goto label_16;      
        if(source != null)
        {
            goto label_16;
        }
        // 0x02674338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_21, ????);     
        label_16:
        // 0x0267433C: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02674340: MOV x0, x20                | X0 = source;//m1                        
        // 0x02674344: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02674348: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x0267434C: MOV w24, w0                | W24 = source;//m1                       
        // 0x02674350: CBNZ x20, #0x2674358       | if (source != null) goto label_17;      
        if(source != null)
        {
            goto label_17;
        }
        // 0x02674354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_17:
        // 0x02674358: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x0267435C: MOV x0, x20                | X0 = source;//m1                        
        // 0x02674360: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x02674364: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02674368: ADD w8, w24, #3            | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_22 = source + 3;
        // 0x0267436C: CMP w24, #0                | STATE = COMPARE(source, 0x0)            
        // 0x02674370: ADD w9, w0, #3             | W9 = (source + 3);                      
        UnityEngine.RenderTexture val_23 = source + 3;
        // 0x02674374: CSEL w8, w8, w24, lt       | W8 = source < null ? (source + 3) : source;
        var val_24 = (source < 0) ? (val_22) : (source);
        // 0x02674378: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x0267437C: ASR w1, w8, #2             | W1 = (source < null ? (source + 3) : source >> 2);
        int val_25 = val_24 >> 2;
        // 0x02674380: CSEL w8, w9, w0, lt        | W8 = source < null ? (source + 3) : source;
        var val_26 = (source < 0) ? (val_23) : (source);
        // 0x02674384: ASR w2, w8, #2             | W2 = (source < null ? (source + 3) : source >> 2);
        int val_27 = val_26 >> 2;
        // 0x02674388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267438C: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x02674390: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674394: MOV w4, w25                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02674398: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  int val_25 = val_24 >> 2, depthBuffer:  int val_27 = val_26 >> 2, format:  0);
        UnityEngine.RenderTexture val_28 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_25, depthBuffer:  val_27, format:  0);
        // 0x0267439C: MOV x24, x0                | X24 = val_28;//m1                       
        // 0x026743A0: CBNZ x20, #0x26743a8       | if (source != null) goto label_18;      
        if(source != null)
        {
            goto label_18;
        }
        // 0x026743A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_18:
        // 0x026743A8: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026743AC: MOV x0, x20                | X0 = source;//m1                        
        // 0x026743B0: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x026743B4: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x026743B8: MOV w27, w0                | W27 = source;//m1                       
        // 0x026743BC: CBNZ x20, #0x26743c4       | if (source != null) goto label_19;      
        if(source != null)
        {
            goto label_19;
        }
        // 0x026743C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_19:
        // 0x026743C4: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x026743C8: MOV x0, x20                | X0 = source;//m1                        
        // 0x026743CC: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x026743D0: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x026743D4: ADD w8, w27, #3            | W8 = (source + 3);                      
        UnityEngine.RenderTexture val_29 = source + 3;
        // 0x026743D8: CMP w27, #0                | STATE = COMPARE(source, 0x0)            
        // 0x026743DC: ADD w9, w0, #3             | W9 = (source + 3);                      
        UnityEngine.RenderTexture val_30 = source + 3;
        // 0x026743E0: CSEL w8, w8, w27, lt       | W8 = source < null ? (source + 3) : source;
        var val_31 = (source < 0) ? (val_29) : (source);
        // 0x026743E4: CMP w0, #0                 | STATE = COMPARE(source, 0x0)            
        // 0x026743E8: ASR w1, w8, #2             | W1 = (source < null ? (source + 3) : source >> 2);
        int val_32 = val_31 >> 2;
        // 0x026743EC: CSEL w8, w9, w0, lt        | W8 = source < null ? (source + 3) : source;
        var val_33 = (source < 0) ? (val_30) : (source);
        // 0x026743F0: ASR w2, w8, #2             | W2 = (source < null ? (source + 3) : source >> 2);
        int val_34 = val_33 >> 2;
        // 0x026743F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026743F8: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
        // 0x026743FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674400: MOV w4, w25                | W4 = false != 0x0 ? 2 : 7;//m1          
        // 0x02674404: BL #0x1b89134              | X0 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  int val_32 = val_31 >> 2, depthBuffer:  int val_34 = val_33 >> 2, format:  0);
        UnityEngine.RenderTexture val_35 = UnityEngine.RenderTexture.GetTemporary(width:  0, height:  val_32, depthBuffer:  val_34, format:  0);
        // 0x02674408: MOV x25, x0                | X25 = val_35;//m1                       
        // 0x0267440C: CBNZ x20, #0x2674414       | if (source != null) goto label_20;      
        if(source != null)
        {
            goto label_20;
        }
        // 0x02674410: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_20:
        // 0x02674414: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02674418: MOV x0, x20                | X0 = source;//m1                        
        // 0x0267441C: LDP x9, x1, [x8, #0x150]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_158; //  | 
        // 0x02674420: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_150();
        // 0x02674424: MOV w27, w0                | W27 = source;//m1                       
        // 0x02674428: CBNZ x20, #0x2674430       | if (source != null) goto label_21;      
        if(source != null)
        {
            goto label_21;
        }
        // 0x0267442C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? source, ????);     
        label_21:
        // 0x02674430: LDR x8, [x20]              | X8 = typeof(UnityEngine.RenderTexture); 
        // 0x02674434: MOV x0, x20                | X0 = source;//m1                        
        // 0x02674438: LDP x9, x1, [x8, #0x170]   | X9 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170; X1 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_178; //  | 
        // 0x0267443C: BLR x9                     | X0 = typeof(UnityEngine.RenderTexture).__il2cppRuntimeField_170();
        // 0x02674440: ADRP x19, #0x3641000       | X19 = 56889344 (0x3641000);             
        // 0x02674444: LDR x19, [x19, #0x800]     | X19 = 1152921504693481472;              
        // 0x02674448: LDR x22, [x21, #0xf0]      | X22 = this.screenBlend; //P2            
        // 0x0267444C: MOV w28, w0                | W28 = source;//m1                       
        // 0x02674450: LDR x8, [x19]              | X8 = typeof(UnityEngine.Graphics);      
        // 0x02674454: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674458: TBZ w9, #0, #0x267446c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_23;
        // 0x0267445C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674460: CBNZ w9, #0x267446c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_23;
        // 0x02674464: MOV x0, x8                 | X0 = 1152921504693481472 (0x100000000529F000);//ML01
        // 0x02674468: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_23:
        // 0x0267446C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674470: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674474: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x02674478: MOV x1, x20                | X1 = source;//m1                        
        // 0x0267447C: MOV x2, x26                | X2 = val_14;//m1                        
        // 0x02674480: MOV x3, x22                | X3 = this.screenBlend;//m1              
        // 0x02674484: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_14, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  source, mat:  val_14, pass:  this.screenBlend);
        // 0x02674488: LDR x3, [x21, #0xf0]       | X3 = this.screenBlend; //P2             
        // 0x0267448C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674490: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674494: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x02674498: MOV x1, x26                | X1 = val_14;//m1                        
        // 0x0267449C: MOV x2, x23                | X2 = val_21;//m1                        
        // 0x026744A0: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_14, mat:  val_21, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_14, mat:  val_21, pass:  this.screenBlend);
        // 0x026744A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026744A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026744AC: MOV x1, x26                | X1 = val_14;//m1                        
        // 0x026744B0: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x026744B4: LDR s0, [x21, #0x38]       | S0 = this.bloomThreshhold; //P2         
        // 0x026744B8: LDR s1, [x21, #0x30]       | S1 = this.useSrcAlphaAsMask; //P2       
        // 0x026744BC: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x026744C0: MOV x1, x23                | X1 = val_21;//m1                        
        // 0x026744C4: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x026744C8: BL #0x2674d74              | this.BrightFilter(thresh:  this.bloomThreshhold, useAlphaAsMask:  this.useSrcAlphaAsMask, from:  val_21, to:  val_28);
        this.BrightFilter(thresh:  this.bloomThreshhold, useAlphaAsMask:  this.useSrcAlphaAsMask, from:  val_21, to:  val_28);
        // 0x026744CC: CBNZ x23, #0x26744d4       | if (val_21 != null) goto label_24;      
        if(val_21 != null)
        {
            goto label_24;
        }
        // 0x026744D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_24:
        // 0x026744D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026744D8: MOV x0, x23                | X0 = val_21;//m1                        
        // 0x026744DC: SCVTF s8, w27              | S8 = (float)(source);                   
        // 0x026744E0: SCVTF s9, w28              | S9 = (float)(source);                   
        // 0x026744E4: BL #0x1b8a1e0              | val_21.DiscardContents();               
        val_21.DiscardContents();
        // 0x026744E8: LDR w8, [x21, #0x3c]       | W8 = this.bloomBlurIterations; //P2     
        // 0x026744EC: CMP w8, #0                 | STATE = COMPARE(this.bloomBlurIterations, 0x0)
        // 0x026744F0: B.GT #0x26744fc            | if (this.bloomBlurIterations > 0) goto label_25;
        if(this.bloomBlurIterations > 0)
        {
            goto label_25;
        }
        // 0x026744F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026744F8: STR w8, [x21, #0x3c]       | this.bloomBlurIterations = 1;            //  dest_result_addr=1152921509946853772
        this.bloomBlurIterations = 1;
        label_25:
        // 0x026744FC: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02674500: ADRP x27, #0x364a000       | X27 = 56926208 (0x364A000);             
        // 0x02674504: LDR s13, [x8, #0xd1c]      | S13 = 0.001953125;                      
        // 0x02674508: LDR x27, [x27, #0x178]     | X27 = (string**)(1152921509946714736)("offsets");
        // 0x0267450C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        // 0x02674510: FDIV s12, s8, s9           | S12 = (source / source);                
        float val_36 = (float)source / (float)source;
        // 0x02674514: FMOV s10, #0.50000000      | S10 = 0.5;                              
        val_45 = 0.5f;
        // 0x02674518: FMOV s9, #1.00000000       | S9 = 1;                                 
        // 0x0267451C: FMOV s8, wzr               | S8 = 0f;                                
        label_32:
        // 0x02674520: LDR s0, [x21, #0x2c]       | S0 = this.sepBlurSpread; //P2           
        // 0x02674524: SCVTF s1, w28              | S1 = 0;                                 
        float val_44 = 0f;
        // 0x02674528: FMUL s1, s1, s10           | S1 = (0f * val_45);                     
        val_44 = val_44 * val_45;
        // 0x0267452C: LDR x26, [x21, #0xd0]      | X26 = this.separableBlurMaterial; //P2  
        // 0x02674530: FADD s1, s1, s9            | S1 = ((0f * val_45) + 1f);              
        val_44 = val_44 + 1f;
        // 0x02674534: FMUL s11, s1, s0           | S11 = (((0f * val_45) + 1f) * this.sepBlurSpread);
        float val_37 = val_44 * this.sepBlurSpread;
        // 0x02674538: FMUL s1, s11, s13          | S1 = ((((0f * val_45) + 1f) * this.sepBlurSpread) * 0.001953125f);
        val_44 = val_37 * 0.001953125f;
        // 0x0267453C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674540: ADD x0, sp, #0x30          | X0 = (1152921509946841504 + 48) = 1152921509946841552 (0x100000013E49D9D0);
        // 0x02674544: MOV v0.16b, v8.16b         | V0 = 0;//m1                             
        // 0x02674548: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x0267454C: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02674550: STP xzr, xzr, [sp, #0x30]  | stack[1152921509946841552] = 0x0;  stack[1152921509946841560] = 0x0;  //  dest_result_addr=1152921509946841552 |  dest_result_addr=1152921509946841560
        // 0x02674554: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674558: CBNZ x26, #0x2674560       | if (this.separableBlurMaterial != null) goto label_26;
        if(this.separableBlurMaterial != null)
        {
            goto label_26;
        }
        // 0x0267455C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9D0, ????);
        label_26:
        // 0x02674560: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02674564: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674568: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267456C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674570: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x02674574: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674578: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267457C: LDR x22, [x21, #0xd0]      | X22 = this.separableBlurMaterial; //P2  
        // 0x02674580: CMP w28, #0                | STATE = COMPARE(0x0, 0x0)               
        // 0x02674584: CSEL x26, x24, x23, eq     | X26 = 0 == 0x0 ? val_28 : val_21;       
        UnityEngine.RenderTexture val_38 = (0 == 0) ? (val_28) : (val_21);
        // 0x02674588: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267458C: TBZ w8, #0, #0x267459c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x02674590: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674594: CBNZ w8, #0x267459c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x02674598: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_28:
        // 0x0267459C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026745A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x026745A4: MOV x1, x26                | X1 = 0 == 0x0 ? val_28 : val_21;//m1    
        // 0x026745A8: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x026745AC: MOV x3, x22                | X3 = this.separableBlurMaterial;//m1    
        // 0x026745B0: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_38, mat:  val_35);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_38, mat:  val_35);
        // 0x026745B4: CBNZ x26, #0x26745bc       | if (0 == 0x0 ? val_28 : val_21 != 0) goto label_29;
        if(val_38 != 0)
        {
            goto label_29;
        }
        // 0x026745B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_29:
        // 0x026745BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026745C0: MOV x0, x26                | X0 = 0 == 0x0 ? val_28 : val_21;//m1    
        // 0x026745C4: BL #0x1b8a1e0              | 0 == 0x0 ? val_28 : val_21.DiscardContents();
        val_38.DiscardContents();
        // 0x026745C8: LDR x26, [x21, #0xd0]      | X26 = this.separableBlurMaterial; //P2  
        // 0x026745CC: FDIV s0, s11, s12          | S0 = ((((0f * val_45) + 1f) * this.sepBlurSpread) / (source / source));
        float val_39 = val_37 / val_36;
        // 0x026745D0: FMUL s0, s0, s13           | S0 = (((((0f * val_45) + 1f) * this.sepBlurSpread) / (source / source)) * 0.001953125f);
        val_39 = val_39 * 0.001953125f;
        // 0x026745D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026745D8: ADD x0, sp, #0x30          | X0 = (1152921509946841504 + 48) = 1152921509946841552 (0x100000013E49D9D0);
        // 0x026745DC: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x026745E0: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x026745E4: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x026745E8: STP xzr, xzr, [sp, #0x30]  | stack[1152921509946841552] = 0x0;  stack[1152921509946841560] = 0x0;  //  dest_result_addr=1152921509946841552 |  dest_result_addr=1152921509946841560
        // 0x026745EC: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026745F0: CBNZ x26, #0x26745f8       | if (this.separableBlurMaterial != null) goto label_30;
        if(this.separableBlurMaterial != null)
        {
            goto label_30;
        }
        // 0x026745F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9D0, ????);
        label_30:
        // 0x026745F8: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x026745FC: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674600: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02674604: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674608: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x0267460C: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674610: LDR x3, [x21, #0xd0]       | X3 = this.separableBlurMaterial; //P2   
        // 0x02674614: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674618: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267461C: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674620: MOV x2, x23                | X2 = val_21;//m1                        
        // 0x02674624: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_21);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_21);
        // 0x02674628: CBNZ x25, #0x2674630       | if (val_35 != null) goto label_31;      
        if(val_35 != null)
        {
            goto label_31;
        }
        // 0x0267462C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_31:
        // 0x02674630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674634: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674638: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x0267463C: LDR w8, [x21, #0x3c]       | W8 = this.bloomBlurIterations; //P2     
        // 0x02674640: ADD w28, w28, #1           | W28 = (0 + 1) = 1 (0x00000001);         
        // 0x02674644: CMP w28, w8                | STATE = COMPARE(0x1, this.bloomBlurIterations)
        // 0x02674648: B.LT #0x2674520            | if (1 < this.bloomBlurIterations) goto label_32;
        if(1 < this.bloomBlurIterations)
        {
            goto label_32;
        }
        // 0x0267464C: LDRB w8, [x21, #0x40]      | W8 = this.lensflares; //P2              
        // 0x02674650: CBZ w8, #0x2674c8c         | if (this.lensflares == false) goto label_33;
        if(this.lensflares == false)
        {
            goto label_33;
        }
        // 0x02674654: LDR w8, [x21, #0x48]       | W8 = this.lensflareMode; //P2           
        // 0x02674658: CBZ w8, #0x2674a70         | if (this.lensflareMode == 0) goto label_34;
        if(this.lensflareMode == 0)
        {
            goto label_34;
        }
        // 0x0267465C: LDR s0, [x21, #0x54]       | S0 = this.lensflareThreshhold; //P2     
        // 0x02674660: LDR x26, [x21, #0x100]     | X26 = this.hollywoodFlaresMaterial; //P2 
        // 0x02674664: FMOV s2, wzr               | S2 = 0f;                                
        // 0x02674668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267466C: FSUB s1, s9, s0            | S1 = (1f - this.lensflareThreshhold);   
        float val_40 = 1f - this.lensflareThreshhold;
        // 0x02674670: FDIV s1, s9, s1            | S1 = (1f / (1f - this.lensflareThreshhold));
        val_40 = 1f / val_40;
        // 0x02674674: ADD x0, sp, #0x30          | X0 = (1152921509946841504 + 48) = 1152921509946841552 (0x100000013E49D9D0);
        // 0x02674678: MOV v3.16b, v2.16b         | V3 = 0;//m1                             
        // 0x0267467C: STP xzr, xzr, [sp, #0x30]  | stack[1152921509946841552] = 0x0;  stack[1152921509946841560] = 0x0;  //  dest_result_addr=1152921509946841552 |  dest_result_addr=1152921509946841560
        // 0x02674680: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674684: CBNZ x26, #0x267468c       | if (this.hollywoodFlaresMaterial != null) goto label_35;
        if(this.hollywoodFlaresMaterial != null)
        {
            goto label_35;
        }
        // 0x02674688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9D0, ????);
        label_35:
        // 0x0267468C: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
        // 0x02674690: LDR x8, [x8, #0x288]       | X8 = (string**)(1152921509944997328)("_Threshhold");
        // 0x02674694: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674698: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267469C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026746A0: LDR x1, [x8]               | X1 = "_Threshhold";                     
        // 0x026746A4: MOV x0, x26                | X0 = this.hollywoodFlaresMaterial;//m1  
        // 0x026746A8: BL #0x1a79fa8              | this.hollywoodFlaresMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.hollywoodFlaresMaterial.SetVector(name:  "_Threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x026746AC: LDR x26, [x21, #0x100]     | X26 = this.hollywoodFlaresMaterial; //P2 
        // 0x026746B0: LDP s0, s1, [x21, #0x58]   | S0 = this.flareColorA; //P2              //  | 
        // 0x026746B4: LDP s2, s3, [x21, #0x60]   |                                          //  | 
        // 0x026746B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026746BC: ADD x0, sp, #0x20          | X0 = (1152921509946841504 + 32) = 1152921509946841536 (0x100000013E49D9C0);
        // 0x026746C0: STP xzr, xzr, [sp, #0x20]  | stack[1152921509946841536] = 0x0;  stack[1152921509946841544] = 0x0;  //  dest_result_addr=1152921509946841536 |  dest_result_addr=1152921509946841544
        // 0x026746C4: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026746C8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x026746CC: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x026746D0: LDR s8, [x21, #0x64]       | 
        // 0x026746D4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x026746D8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x026746DC: TBZ w8, #0, #0x26746ec     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_37;
        // 0x026746E0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x026746E4: CBNZ w8, #0x26746ec        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
        // 0x026746E8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_37:
        // 0x026746EC: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026746F0: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026746F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026746F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026746FC: MOV v4.16b, v8.16b         | V4 = 0;//m1                             
        // 0x02674700: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  0f);
        UnityEngine.Vector4 val_41 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  0f);
        // 0x02674704: LDR s4, [x21, #0x50]       | S4 = this.lensflareIntensity; //P2      
        // 0x02674708: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x0267470C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674710: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = val_41.x, y = val_41.y, z = val_41.z, w = val_41.w}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_42 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = val_41.x, y = val_41.y, z = val_41.z, w = val_41.w}, d:  this.lensflareIntensity);
        // 0x02674714: MOV v8.16b, v0.16b         | V8 = val_42.x;//m1                      
        // 0x02674718: MOV v9.16b, v1.16b         | V9 = val_42.y;//m1                      
        // 0x0267471C: MOV v10.16b, v2.16b        | V10 = val_42.z;//m1                     
        val_45 = val_42.z;
        // 0x02674720: MOV v11.16b, v3.16b        | V11 = val_42.w;//m1                     
        // 0x02674724: CBNZ x26, #0x267472c       | if (this.hollywoodFlaresMaterial != null) goto label_38;
        if(this.hollywoodFlaresMaterial != null)
        {
            goto label_38;
        }
        // 0x02674728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_38:
        // 0x0267472C: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
        // 0x02674730: LDR x8, [x8, #0x990]       | X8 = (string**)(1152921509946743504)("tintColor");
        // 0x02674734: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674738: MOV x0, x26                | X0 = this.hollywoodFlaresMaterial;//m1  
        // 0x0267473C: MOV v0.16b, v8.16b         | V0 = val_42.x;//m1                      
        // 0x02674740: LDR x1, [x8]               | X1 = "tintColor";                       
        // 0x02674744: MOV v1.16b, v9.16b         | V1 = val_42.y;//m1                      
        // 0x02674748: MOV v2.16b, v10.16b        | V2 = val_42.z;//m1                      
        // 0x0267474C: MOV v3.16b, v11.16b        | V3 = val_42.w;//m1                      
        // 0x02674750: BL #0x1a79fa8              | this.hollywoodFlaresMaterial.SetVector(name:  "tintColor", value:  new UnityEngine.Vector4() {x = val_42.x, y = val_42.y, z = val_45, w = val_42.w});
        this.hollywoodFlaresMaterial.SetVector(name:  "tintColor", value:  new UnityEngine.Vector4() {x = val_42.x, y = val_42.y, z = val_45, w = val_42.w});
        // 0x02674754: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674758: LDR x22, [x21, #0x100]     | X22 = this.hollywoodFlaresMaterial; //P2 
        // 0x0267475C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674760: TBZ w8, #0, #0x2674770     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x02674764: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674768: CBNZ w8, #0x2674770        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x0267476C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_40:
        // 0x02674770: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674774: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674778: ORR w4, wzr, #2            | W4 = 2(0x2);                            
        // 0x0267477C: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674780: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x02674784: MOV x3, x22                | X3 = this.hollywoodFlaresMaterial;//m1  
        // 0x02674788: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28, pass:  this.hollywoodFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28, pass:  this.hollywoodFlaresMaterial);
        // 0x0267478C: CBNZ x25, #0x2674794       | if (val_35 != null) goto label_41;      
        if(val_35 != null)
        {
            goto label_41;
        }
        // 0x02674790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_41:
        // 0x02674794: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674798: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x0267479C: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x026747A0: LDR x3, [x21, #0x100]      | X3 = this.hollywoodFlaresMaterial; //P2 
        // 0x026747A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026747A8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026747AC: ORR w4, wzr, #3            | W4 = 3(0x3);                            
        // 0x026747B0: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x026747B4: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x026747B8: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35, pass:  this.hollywoodFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35, pass:  this.hollywoodFlaresMaterial);
        // 0x026747BC: CBNZ x24, #0x26747c4       | if (val_28 != null) goto label_42;      
        if(val_28 != null)
        {
            goto label_42;
        }
        // 0x026747C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_42:
        // 0x026747C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026747C8: MOV x0, x24                | X0 = val_28;//m1                        
        // 0x026747CC: BL #0x1b8a1e0              | val_28.DiscardContents();               
        val_28.DiscardContents();
        // 0x026747D0: LDR s0, [x21, #0x2c]       | S0 = this.sepBlurSpread; //P2           
        float val_45 = this.sepBlurSpread;
        // 0x026747D4: LDR x26, [x21, #0x100]     | X26 = this.hollywoodFlaresMaterial; //P2 
        // 0x026747D8: FMOV s1, wzr               | S1 = 0f;                                
        // 0x026747DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026747E0: FDIV s0, s0, s12           | S0 = (this.sepBlurSpread / (source / source));
        val_45 = val_45 / val_36;
        // 0x026747E4: FMUL s0, s0, s13           | S0 = ((this.sepBlurSpread / (source / source)) * 0.001953125f);
        val_45 = val_45 * 0.001953125f;
        // 0x026747E8: ADD x0, sp, #0x10          | X0 = (1152921509946841504 + 16) = 1152921509946841520 (0x100000013E49D9B0);
        // 0x026747EC: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
        // 0x026747F0: MOV v3.16b, v1.16b         | V3 = 0;//m1                             
        // 0x026747F4: STP xzr, xzr, [sp, #0x10]  | stack[1152921509946841520] = 0x0;  stack[1152921509946841528] = 0x0;  //  dest_result_addr=1152921509946841520 |  dest_result_addr=1152921509946841528
        // 0x026747F8: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026747FC: CBNZ x26, #0x2674804       | if (this.hollywoodFlaresMaterial != null) goto label_43;
        if(this.hollywoodFlaresMaterial != null)
        {
            goto label_43;
        }
        // 0x02674800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9B0, ????);
        label_43:
        // 0x02674804: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02674808: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x0267480C: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02674810: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674814: MOV x0, x26                | X0 = this.hollywoodFlaresMaterial;//m1  
        // 0x02674818: BL #0x1a79fa8              | this.hollywoodFlaresMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.hollywoodFlaresMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x0267481C: LDR x22, [x21, #0x100]     | X22 = this.hollywoodFlaresMaterial; //P2 
        // 0x02674820: LDR s8, [x21, #0x4c]       | S8 = this.hollyStretchWidth; //P2       
        // 0x02674824: CBNZ x22, #0x267482c       | if (this.hollywoodFlaresMaterial != null) goto label_44;
        if(this.hollywoodFlaresMaterial != null)
        {
            goto label_44;
        }
        // 0x02674828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.hollywoodFlaresMaterial, ????);
        label_44:
        // 0x0267482C: ADRP x26, #0x3667000       | X26 = 57044992 (0x3667000);             
        // 0x02674830: LDR x26, [x26, #0x958]     | X26 = (string**)(1152921509946759984)("stretchWidth");
        // 0x02674834: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674838: MOV x0, x22                | X0 = this.hollywoodFlaresMaterial;//m1  
        // 0x0267483C: MOV v0.16b, v8.16b         | V0 = this.hollyStretchWidth;//m1        
        // 0x02674840: LDR x1, [x26]              | X1 = "stretchWidth";                    
        // 0x02674844: BL #0x1a79ef8              | this.hollywoodFlaresMaterial.SetFloat(name:  "stretchWidth", value:  this.hollyStretchWidth);
        this.hollywoodFlaresMaterial.SetFloat(name:  "stretchWidth", value:  this.hollyStretchWidth);
        // 0x02674848: LDR x3, [x21, #0x100]      | X3 = this.hollywoodFlaresMaterial; //P2 
        // 0x0267484C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674850: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674854: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x02674858: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x0267485C: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x02674860: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28, pass:  this.hollywoodFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28, pass:  this.hollywoodFlaresMaterial);
        // 0x02674864: CBNZ x25, #0x267486c       | if (val_35 != null) goto label_45;      
        if(val_35 != null)
        {
            goto label_45;
        }
        // 0x02674868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_45:
        // 0x0267486C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674870: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674874: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x02674878: LDR x22, [x21, #0x100]     | X22 = this.hollywoodFlaresMaterial; //P2 
        // 0x0267487C: LDR s8, [x21, #0x4c]       | S8 = this.hollyStretchWidth; //P2       
        // 0x02674880: CBNZ x22, #0x2674888       | if (this.hollywoodFlaresMaterial != null) goto label_46;
        if(this.hollywoodFlaresMaterial != null)
        {
            goto label_46;
        }
        // 0x02674884: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_35, ????);     
        label_46:
        // 0x02674888: LDR x1, [x26]              | X1 = "stretchWidth";                    
        // 0x0267488C: FADD s0, s8, s8            | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        float val_43 = this.hollyStretchWidth + this.hollyStretchWidth;
        // 0x02674890: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674894: MOV x0, x22                | X0 = this.hollywoodFlaresMaterial;//m1  
        // 0x02674898: BL #0x1a79ef8              | this.hollywoodFlaresMaterial.SetFloat(name:  "stretchWidth", value:  float val_43 = this.hollyStretchWidth + this.hollyStretchWidth);
        this.hollywoodFlaresMaterial.SetFloat(name:  "stretchWidth", value:  val_43);
        // 0x0267489C: LDR x3, [x21, #0x100]      | X3 = this.hollywoodFlaresMaterial; //P2 
        // 0x026748A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026748A4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x026748A8: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x026748AC: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x026748B0: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x026748B4: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35, pass:  this.hollywoodFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35, pass:  this.hollywoodFlaresMaterial);
        // 0x026748B8: CBNZ x24, #0x26748c0       | if (val_28 != null) goto label_47;      
        if(val_28 != null)
        {
            goto label_47;
        }
        // 0x026748BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_47:
        // 0x026748C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026748C4: MOV x0, x24                | X0 = val_28;//m1                        
        // 0x026748C8: BL #0x1b8a1e0              | val_28.DiscardContents();               
        val_28.DiscardContents();
        // 0x026748CC: LDR x22, [x21, #0x100]     | X22 = this.hollywoodFlaresMaterial; //P2 
        // 0x026748D0: LDR s8, [x21, #0x4c]       | S8 = this.hollyStretchWidth; //P2       
        // 0x026748D4: CBNZ x22, #0x26748dc       | if (this.hollywoodFlaresMaterial != null) goto label_48;
        if(this.hollywoodFlaresMaterial != null)
        {
            goto label_48;
        }
        // 0x026748D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_48:
        // 0x026748DC: LDR x1, [x26]              | X1 = "stretchWidth";                    
        // 0x026748E0: FMOV s0, #4.00000000       | S0 = 4;                                 
        float val_46 = 4f;
        // 0x026748E4: FMUL s0, s8, s0            | S0 = (this.hollyStretchWidth * 4f);     
        val_46 = this.hollyStretchWidth * val_46;
        // 0x026748E8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026748EC: MOV x0, x22                | X0 = this.hollywoodFlaresMaterial;//m1  
        // 0x026748F0: BL #0x1a79ef8              | this.hollywoodFlaresMaterial.SetFloat(name:  "stretchWidth", value:  4f = this.hollyStretchWidth * 4f);
        this.hollywoodFlaresMaterial.SetFloat(name:  "stretchWidth", value:  val_46);
        // 0x026748F4: LDR x3, [x21, #0x100]      | X3 = this.hollywoodFlaresMaterial; //P2 
        // 0x026748F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026748FC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674900: ORR w4, wzr, #1            | W4 = 1(0x1);                            
        // 0x02674904: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674908: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x0267490C: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28, pass:  this.hollywoodFlaresMaterial);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28, pass:  this.hollywoodFlaresMaterial);
        // 0x02674910: CBNZ x25, #0x2674918       | if (val_35 != null) goto label_49;      
        if(val_35 != null)
        {
            goto label_49;
        }
        // 0x02674914: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_49:
        // 0x02674918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267491C: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674920: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x02674924: LDP w8, w9, [x21, #0x44]   | W8 = this.hollywoodFlareBlurIterations; //P2  W9 = this.lensflareMode; //P2  //  | 
        // 0x02674928: LDR s0, [x21, #0x4c]       | S0 = this.hollyStretchWidth; //P2       
        val_46 = this.hollyStretchWidth;
        // 0x0267492C: CMP w9, #1                 | STATE = COMPARE(this.lensflareMode, 0x1)
        // 0x02674930: B.NE #0x2674ae0            | if (this.lensflareMode != 0x1) goto label_50;
        if(this.lensflareMode != 1)
        {
            goto label_50;
        }
        // 0x02674934: CMP w8, #1                 | STATE = COMPARE(this.hollywoodFlareBlurIterations, 0x1)
        // 0x02674938: B.LT #0x2674c64            | if (this.hollywoodFlareBlurIterations < 1) goto label_60;
        if(this.hollywoodFlareBlurIterations < 1)
        {
            goto label_60;
        }
        // 0x0267493C: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        var val_48 = 0;
        // 0x02674940: FMOV s8, wzr               | S8 = 0f;                                
        // 0x02674944: B #0x267494c               |  goto label_52;                         
        goto label_52;
        label_59:
        // 0x02674948: LDR s0, [x21, #0x4c]       | S0 = this.hollyStretchWidth; //P2       
        val_47 = this.hollyStretchWidth;
        label_52:
        // 0x0267494C: LDR x26, [x21, #0xd0]      | X26 = this.separableBlurMaterial; //P2  
        // 0x02674950: FADD s0, s0, s0            | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        val_47 = val_47 + val_47;
        // 0x02674954: FDIV s0, s0, s12           | S0 = ((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source));
        val_47 = val_47 / val_36;
        // 0x02674958: FMUL s0, s0, s13           | S0 = (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f);
        val_47 = val_47 * 0.001953125f;
        // 0x0267495C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674960: ADD x0, sp, #0x30          | X0 = (1152921509946841504 + 48) = 1152921509946841552 (0x100000013E49D9D0);
        // 0x02674964: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02674968: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x0267496C: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02674970: STP xzr, xzr, [sp, #0x30]  | stack[1152921509946841552] = 0x0;  stack[1152921509946841560] = 0x0;  //  dest_result_addr=1152921509946841552 |  dest_result_addr=1152921509946841560
        // 0x02674974: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674978: CBNZ x26, #0x2674980       | if (this.separableBlurMaterial != null) goto label_53;
        if(this.separableBlurMaterial != null)
        {
            goto label_53;
        }
        // 0x0267497C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9D0, ????);
        label_53:
        // 0x02674980: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02674984: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674988: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267498C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674990: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x02674994: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674998: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x0267499C: LDR x22, [x21, #0xd0]      | X22 = this.separableBlurMaterial; //P2  
        // 0x026749A0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x026749A4: TBZ w8, #0, #0x26749b4     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_55;
        // 0x026749A8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x026749AC: CBNZ w8, #0x26749b4        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_55;
        // 0x026749B0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_55:
        // 0x026749B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026749B8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x026749BC: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x026749C0: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x026749C4: MOV x3, x22                | X3 = this.separableBlurMaterial;//m1    
        // 0x026749C8: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35);
        // 0x026749CC: CBNZ x24, #0x26749d4       | if (val_28 != null) goto label_56;      
        if(val_28 != null)
        {
            goto label_56;
        }
        // 0x026749D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_56:
        // 0x026749D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026749D8: MOV x0, x24                | X0 = val_28;//m1                        
        // 0x026749DC: BL #0x1b8a1e0              | val_28.DiscardContents();               
        val_28.DiscardContents();
        // 0x026749E0: LDR s0, [x21, #0x4c]       | S0 = this.hollyStretchWidth; //P2       
        float val_47 = this.hollyStretchWidth;
        // 0x026749E4: LDR x26, [x21, #0xd0]      | X26 = this.separableBlurMaterial; //P2  
        // 0x026749E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026749EC: ADD x0, sp, #0x20          | X0 = (1152921509946841504 + 32) = 1152921509946841536 (0x100000013E49D9C0);
        // 0x026749F0: FADD s0, s0, s0            | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        val_47 = val_47 + val_47;
        // 0x026749F4: FDIV s0, s0, s12           | S0 = ((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source));
        val_47 = val_47 / val_36;
        // 0x026749F8: FMUL s0, s0, s13           | S0 = (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f);
        val_47 = val_47 * 0.001953125f;
        // 0x026749FC: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02674A00: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02674A04: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02674A08: STP xzr, xzr, [sp, #0x20]  | stack[1152921509946841536] = 0x0;  stack[1152921509946841544] = 0x0;  //  dest_result_addr=1152921509946841536 |  dest_result_addr=1152921509946841544
        // 0x02674A0C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674A10: CBNZ x26, #0x2674a18       | if (this.separableBlurMaterial != null) goto label_57;
        if(this.separableBlurMaterial != null)
        {
            goto label_57;
        }
        // 0x02674A14: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9C0, ????);
        label_57:
        // 0x02674A18: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02674A1C: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674A20: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02674A24: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674A28: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x02674A2C: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674A30: LDR x3, [x21, #0xd0]       | X3 = this.separableBlurMaterial; //P2   
        // 0x02674A34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674A38: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02674A3C: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674A40: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x02674A44: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28);
        // 0x02674A48: CBNZ x25, #0x2674a50       | if (val_35 != null) goto label_58;      
        if(val_35 != null)
        {
            goto label_58;
        }
        // 0x02674A4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_58:
        // 0x02674A50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674A54: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674A58: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x02674A5C: LDR w8, [x21, #0x44]       | W8 = this.hollywoodFlareBlurIterations; //P2 
        // 0x02674A60: ADD w28, w28, #1           | W28 = (0 + 1);                          
        val_48 = val_48 + 1;
        // 0x02674A64: CMP w28, w8                | STATE = COMPARE((0 + 1), this.hollywoodFlareBlurIterations)
        // 0x02674A68: B.LT #0x2674948            | if (0 < this.hollywoodFlareBlurIterations) goto label_59;
        if(val_48 < this.hollywoodFlareBlurIterations)
        {
            goto label_59;
        }
        // 0x02674A6C: B #0x2674c64               |  goto label_60;                         
        goto label_60;
        label_34:
        // 0x02674A70: LDR s0, [x21, #0x54]       | S0 = this.lensflareThreshhold; //P2     
        // 0x02674A74: FMOV s1, wzr               | S1 = 0f;                                
        // 0x02674A78: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674A7C: MOV x1, x23                | X1 = val_21;//m1                        
        // 0x02674A80: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x02674A84: BL #0x2674d74              | this.BrightFilter(thresh:  this.lensflareThreshhold, useAlphaAsMask:  0f, from:  val_21, to:  val_35);
        this.BrightFilter(thresh:  this.lensflareThreshhold, useAlphaAsMask:  0f, from:  val_21, to:  val_35);
        // 0x02674A88: CBNZ x23, #0x2674a90       | if (val_21 != null) goto label_61;      
        if(val_21 != null)
        {
            goto label_61;
        }
        // 0x02674A8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_61:
        // 0x02674A90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674A94: MOV x0, x23                | X0 = val_21;//m1                        
        // 0x02674A98: BL #0x1b8a1e0              | val_21.DiscardContents();               
        val_21.DiscardContents();
        // 0x02674A9C: ADRP x8, #0x2ac3000        | X8 = 44838912 (0x2AC3000);              
        // 0x02674AA0: LDR s0, [x8, #0xd20]       | S0 = 0.975;                             
        // 0x02674AA4: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674AA8: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674AAC: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x02674AB0: BL #0x2674eb4              | this.Vignette(amount:  0.975f, from:  val_35, to:  val_28);
        this.Vignette(amount:  0.975f, from:  val_35, to:  val_28);
        // 0x02674AB4: CBNZ x25, #0x2674abc       | if (val_35 != null) goto label_62;      
        if(val_35 != null)
        {
            goto label_62;
        }
        // 0x02674AB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_62:
        // 0x02674ABC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674AC0: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674AC4: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x02674AC8: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674ACC: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x02674AD0: MOV x2, x23                | X2 = val_21;//m1                        
        // 0x02674AD4: BL #0x2675030              | this.BlendFlares(from:  val_28, to:  val_21);
        this.BlendFlares(from:  val_28, to:  val_21);
        // 0x02674AD8: CBNZ x24, #0x2674c80       | if (val_28 != null) goto label_76;      
        if(val_28 != null)
        {
            goto label_76;
        }
        // 0x02674ADC: B #0x2674c7c               |  goto label_64;                         
        goto label_64;
        label_50:
        // 0x02674AE0: CMP w8, #1                 | STATE = COMPARE(this.hollywoodFlareBlurIterations, 0x1)
        // 0x02674AE4: B.LT #0x2674c18            | if (this.hollywoodFlareBlurIterations < 1) goto label_65;
        if(this.hollywoodFlareBlurIterations < 1)
        {
            goto label_65;
        }
        // 0x02674AE8: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
        var val_50 = 0;
        // 0x02674AEC: FMOV s8, wzr               | S8 = 0f;                                
        // 0x02674AF0: B #0x2674af8               |  goto label_66;                         
        goto label_66;
        label_73:
        // 0x02674AF4: LDR s0, [x21, #0x4c]       | S0 = this.hollyStretchWidth; //P2       
        val_48 = this.hollyStretchWidth;
        label_66:
        // 0x02674AF8: LDR x26, [x21, #0xd0]      | X26 = this.separableBlurMaterial; //P2  
        // 0x02674AFC: FADD s0, s0, s0            | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        val_48 = val_48 + val_48;
        // 0x02674B00: FDIV s0, s0, s12           | S0 = ((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source));
        val_48 = val_48 / val_36;
        // 0x02674B04: FMUL s0, s0, s13           | S0 = (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f);
        val_48 = val_48 * 0.001953125f;
        // 0x02674B08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674B0C: ADD x0, sp, #0x30          | X0 = (1152921509946841504 + 48) = 1152921509946841552 (0x100000013E49D9D0);
        // 0x02674B10: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02674B14: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02674B18: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02674B1C: STP xzr, xzr, [sp, #0x30]  | stack[1152921509946841552] = 0x0;  stack[1152921509946841560] = 0x0;  //  dest_result_addr=1152921509946841552 |  dest_result_addr=1152921509946841560
        // 0x02674B20: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674B24: CBNZ x26, #0x2674b2c       | if (this.separableBlurMaterial != null) goto label_67;
        if(this.separableBlurMaterial != null)
        {
            goto label_67;
        }
        // 0x02674B28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9D0, ????);
        label_67:
        // 0x02674B2C: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02674B30: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674B34: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02674B38: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674B3C: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x02674B40: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674B44: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674B48: LDR x22, [x21, #0xd0]      | X22 = this.separableBlurMaterial; //P2  
        // 0x02674B4C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674B50: TBZ w8, #0, #0x2674b60     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_69;
        // 0x02674B54: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674B58: CBNZ w8, #0x2674b60        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_69;
        // 0x02674B5C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_69:
        // 0x02674B60: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674B64: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02674B68: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x02674B6C: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x02674B70: MOV x3, x22                | X3 = this.separableBlurMaterial;//m1    
        // 0x02674B74: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_28, mat:  val_35);
        // 0x02674B78: CBNZ x24, #0x2674b80       | if (val_28 != null) goto label_70;      
        if(val_28 != null)
        {
            goto label_70;
        }
        // 0x02674B7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_70:
        // 0x02674B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674B84: MOV x0, x24                | X0 = val_28;//m1                        
        // 0x02674B88: BL #0x1b8a1e0              | val_28.DiscardContents();               
        val_28.DiscardContents();
        // 0x02674B8C: LDR s0, [x21, #0x4c]       | S0 = this.hollyStretchWidth; //P2       
        float val_49 = this.hollyStretchWidth;
        // 0x02674B90: LDR x26, [x21, #0xd0]      | X26 = this.separableBlurMaterial; //P2  
        // 0x02674B94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674B98: ADD x0, sp, #0x20          | X0 = (1152921509946841504 + 32) = 1152921509946841536 (0x100000013E49D9C0);
        // 0x02674B9C: FADD s0, s0, s0            | S0 = (this.hollyStretchWidth + this.hollyStretchWidth);
        val_49 = val_49 + val_49;
        // 0x02674BA0: FDIV s0, s0, s12           | S0 = ((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source));
        val_49 = val_49 / val_36;
        // 0x02674BA4: FMUL s0, s0, s13           | S0 = (((this.hollyStretchWidth + this.hollyStretchWidth) / (source / source)) * 0.001953125f);
        val_49 = val_49 * 0.001953125f;
        // 0x02674BA8: MOV v1.16b, v8.16b         | V1 = 0;//m1                             
        // 0x02674BAC: MOV v2.16b, v8.16b         | V2 = 0;//m1                             
        // 0x02674BB0: MOV v3.16b, v8.16b         | V3 = 0;//m1                             
        // 0x02674BB4: STP xzr, xzr, [sp, #0x20]  | stack[1152921509946841536] = 0x0;  stack[1152921509946841544] = 0x0;  //  dest_result_addr=1152921509946841536 |  dest_result_addr=1152921509946841544
        // 0x02674BB8: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674BBC: CBNZ x26, #0x2674bc4       | if (this.separableBlurMaterial != null) goto label_71;
        if(this.separableBlurMaterial != null)
        {
            goto label_71;
        }
        // 0x02674BC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E49D9C0, ????);
        label_71:
        // 0x02674BC4: LDR x1, [x27]              | X1 = "offsets";                         
        // 0x02674BC8: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02674BCC: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x02674BD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674BD4: MOV x0, x26                | X0 = this.separableBlurMaterial;//m1    
        // 0x02674BD8: BL #0x1a79fa8              | this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.separableBlurMaterial.SetVector(name:  "offsets", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674BDC: LDR x3, [x21, #0xd0]       | X3 = this.separableBlurMaterial; //P2   
        // 0x02674BE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674BE4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02674BE8: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674BEC: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x02674BF0: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_35, mat:  val_28);
        // 0x02674BF4: CBNZ x25, #0x2674bfc       | if (val_35 != null) goto label_72;      
        if(val_35 != null)
        {
            goto label_72;
        }
        // 0x02674BF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_72:
        // 0x02674BFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674C00: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674C04: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        // 0x02674C08: LDR w8, [x21, #0x44]       | W8 = this.hollywoodFlareBlurIterations; //P2 
        // 0x02674C0C: ADD w28, w28, #1           | W28 = (0 + 1);                          
        val_50 = val_50 + 1;
        // 0x02674C10: CMP w28, w8                | STATE = COMPARE((0 + 1), this.hollywoodFlareBlurIterations)
        // 0x02674C14: B.LT #0x2674af4            | if (0 < this.hollywoodFlareBlurIterations) goto label_73;
        if(val_50 < this.hollywoodFlareBlurIterations)
        {
            goto label_73;
        }
        label_65:
        // 0x02674C18: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x02674C1C: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674C20: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x02674C24: MOV x2, x25                | X2 = val_35;//m1                        
        // 0x02674C28: BL #0x2674eb4              | this.Vignette(amount:  1f, from:  val_28, to:  val_35);
        this.Vignette(amount:  1f, from:  val_28, to:  val_35);
        // 0x02674C2C: CBNZ x24, #0x2674c34       | if (val_28 != null) goto label_74;      
        if(val_28 != null)
        {
            goto label_74;
        }
        // 0x02674C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_74:
        // 0x02674C34: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674C38: MOV x0, x24                | X0 = val_28;//m1                        
        // 0x02674C3C: BL #0x1b8a1e0              | val_28.DiscardContents();               
        val_28.DiscardContents();
        // 0x02674C40: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674C44: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674C48: MOV x2, x24                | X2 = val_28;//m1                        
        // 0x02674C4C: BL #0x2675030              | this.BlendFlares(from:  val_35, to:  val_28);
        this.BlendFlares(from:  val_35, to:  val_28);
        // 0x02674C50: CBNZ x25, #0x2674c58       | if (val_35 != null) goto label_75;      
        if(val_35 != null)
        {
            goto label_75;
        }
        // 0x02674C54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_75:
        // 0x02674C58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674C5C: MOV x0, x25                | X0 = val_35;//m1                        
        // 0x02674C60: BL #0x1b8a1e0              | val_35.DiscardContents();               
        val_35.DiscardContents();
        label_60:
        // 0x02674C64: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x02674C68: MOV x0, x21                | X0 = 1152921509946853712 (0x100000013E4A0950);//ML01
        // 0x02674C6C: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x02674C70: MOV x2, x23                | X2 = val_21;//m1                        
        // 0x02674C74: BL #0x26752c8              | this.AddTo(intensity_:  1f, from:  val_28, to:  val_21);
        this.AddTo(intensity_:  1f, from:  val_28, to:  val_21);
        // 0x02674C78: CBNZ x24, #0x2674c80       | if (val_28 != null) goto label_76;      
        if(val_28 != null)
        {
            goto label_76;
        }
        label_64:
        // 0x02674C7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_76:
        // 0x02674C80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674C84: MOV x0, x24                | X0 = val_28;//m1                        
        // 0x02674C88: BL #0x1b8a1e0              | val_28.DiscardContents();               
        val_28.DiscardContents();
        label_33:
        // 0x02674C8C: LDR x22, [x21, #0xf0]      | X22 = this.screenBlend; //P2            
        // 0x02674C90: LDR s8, [x21, #0x34]       | S8 = this.bloomIntensity; //P2          
        // 0x02674C94: CBNZ x22, #0x2674c9c       | if (this.screenBlend != null) goto label_77;
        if(this.screenBlend != null)
        {
            goto label_77;
        }
        // 0x02674C98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_28, ????);     
        label_77:
        // 0x02674C9C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x02674CA0: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921509940329520)("_Intensity");
        // 0x02674CA4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674CA8: MOV x0, x22                | X0 = this.screenBlend;//m1              
        // 0x02674CAC: MOV v0.16b, v8.16b         | V0 = this.bloomIntensity;//m1           
        // 0x02674CB0: LDR x1, [x8]               | X1 = "_Intensity";                      
        // 0x02674CB4: BL #0x1a79ef8              | this.screenBlend.SetFloat(name:  "_Intensity", value:  this.bloomIntensity);
        this.screenBlend.SetFloat(name:  "_Intensity", value:  this.bloomIntensity);
        // 0x02674CB8: LDR x22, [x21, #0xf0]      | X22 = this.screenBlend; //P2            
        // 0x02674CBC: CBNZ x22, #0x2674cc4       | if (this.screenBlend != null) goto label_78;
        if(this.screenBlend != null)
        {
            goto label_78;
        }
        // 0x02674CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.screenBlend, ????);
        label_78:
        // 0x02674CC4: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x02674CC8: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921509945091920)("_ColorBuffer");
        // 0x02674CCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02674CD0: MOV x0, x22                | X0 = this.screenBlend;//m1              
        // 0x02674CD4: MOV x2, x20                | X2 = source;//m1                        
        // 0x02674CD8: LDR x1, [x8]               | X1 = "_ColorBuffer";                    
        // 0x02674CDC: BL #0x1a780c4              | this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  source);
        this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  source);
        // 0x02674CE0: LDR x0, [x19]              | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674CE4: LDR x20, [x21, #0xf0]      | X20 = this.screenBlend; //P2            
        // 0x02674CE8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674CEC: TBZ w8, #0, #0x2674cfc     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_80;
        // 0x02674CF0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674CF4: CBNZ w8, #0x2674cfc        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_80;
        // 0x02674CF8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_80:
        // 0x02674CFC: LDR x2, [sp, #8]           | X2 = destination;                       
        // 0x02674D00: LDR w4, [sp, #4]           | W4 = false != 0x0 ? 1 : this.screenBlendMode;
        // 0x02674D04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674D08: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674D0C: MOV x1, x23                | X1 = val_21;//m1                        
        // 0x02674D10: MOV x3, x20                | X3 = this.screenBlend;//m1              
        // 0x02674D14: BL #0x1a6bc84              | UnityEngine.Graphics.Blit(source:  0, dest:  val_21, mat:  destination, pass:  this.screenBlend);
        UnityEngine.Graphics.Blit(source:  0, dest:  val_21, mat:  destination, pass:  this.screenBlend);
        // 0x02674D18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674D1C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674D20: MOV x1, x23                | X1 = val_21;//m1                        
        // 0x02674D24: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02674D28: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674D2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674D30: MOV x1, x24                | X1 = val_28;//m1                        
        // 0x02674D34: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02674D38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674D3C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674D40: MOV x1, x25                | X1 = val_35;//m1                        
        // 0x02674D44: BL #0x1b892ac              | UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        UnityEngine.RenderTexture.ReleaseTemporary(temp:  0);
        // 0x02674D48: SUB sp, x29, #0x80         | SP = (1152921509946841696 - 128) = 1152921509946841568 (0x100000013E49D9E0);
        // 0x02674D4C: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x02674D50: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x02674D54: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x02674D58: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x02674D5C: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x02674D60: LDP x28, x27, [sp, #0x30]  | X28 = ; X27 = ;                          //  | 
        // 0x02674D64: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x02674D68: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x02674D6C: LDP d13, d12, [sp], #0x90  | D13 = ; D12 = ;                          //  | 
        // 0x02674D70: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026752C8 (40325832), len: 188  VirtAddr: 0x026752C8 RVA: 0x026752C8 token: 100663319 methodIndex: 24403 delegateWrapperIndex: 0 methodInvoker: 0
    private void AddTo(float intensity_, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x026752C8: STP d9, d8, [sp, #-0x40]!  | stack[1152921509947133872] = ???;  stack[1152921509947133880] = ???;  //  dest_result_addr=1152921509947133872 |  dest_result_addr=1152921509947133880
        // 0x026752CC: STP x22, x21, [sp, #0x10]  | stack[1152921509947133888] = ???;  stack[1152921509947133896] = ???;  //  dest_result_addr=1152921509947133888 |  dest_result_addr=1152921509947133896
        // 0x026752D0: STP x20, x19, [sp, #0x20]  | stack[1152921509947133904] = ???;  stack[1152921509947133912] = ???;  //  dest_result_addr=1152921509947133904 |  dest_result_addr=1152921509947133912
        // 0x026752D4: STP x29, x30, [sp, #0x30]  | stack[1152921509947133920] = ???;  stack[1152921509947133928] = ???;  //  dest_result_addr=1152921509947133920 |  dest_result_addr=1152921509947133928
        // 0x026752D8: ADD x29, sp, #0x30         | X29 = (1152921509947133872 + 48) = 1152921509947133920 (0x100000013E4E4FE0);
        // 0x026752DC: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x026752E0: LDRB w8, [x22, #0xe4d]     | W8 = (bool)static_value_03740E4D;       
        // 0x026752E4: MOV x19, x2                | X19 = to;//m1                           
        // 0x026752E8: MOV x20, x1                | X20 = from;//m1                         
        // 0x026752EC: MOV v8.16b, v0.16b         | V8 = intensity_;//m1                    
        // 0x026752F0: MOV x21, x0                | X21 = 1152921509947145936 (0x100000013E4E7ED0);//ML01
        // 0x026752F4: TBNZ w8, #0, #0x2675310    | if (static_value_03740E4D == true) goto label_0;
        // 0x026752F8: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x026752FC: LDR x8, [x8, #0xb50]       | X8 = 0x2B8F6B0;                         
        // 0x02675300: LDR w0, [x8]               | W0 = 0x1470;                            
        // 0x02675304: BL #0x2782188              | X0 = sub_2782188( ?? 0x1470, ????);     
        // 0x02675308: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x0267530C: STRB w8, [x22, #0xe4d]     | static_value_03740E4D = true;            //  dest_result_addr=57937485
        label_0:
        // 0x02675310: LDR x22, [x21, #0xe0]      | X22 = this.addBrightStuffBlendOneOneMaterial; //P2 
        // 0x02675314: CBNZ x22, #0x267531c       | if (this.addBrightStuffBlendOneOneMaterial != null) goto label_1;
        if(this.addBrightStuffBlendOneOneMaterial != null)
        {
            goto label_1;
        }
        // 0x02675318: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1470, ????);     
        label_1:
        // 0x0267531C: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
        // 0x02675320: LDR x8, [x8, #0x720]       | X8 = (string**)(1152921509940329520)("_Intensity");
        // 0x02675324: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675328: MOV x0, x22                | X0 = this.addBrightStuffBlendOneOneMaterial;//m1
        // 0x0267532C: MOV v0.16b, v8.16b         | V0 = intensity_;//m1                    
        // 0x02675330: LDR x1, [x8]               | X1 = "_Intensity";                      
        // 0x02675334: BL #0x1a79ef8              | this.addBrightStuffBlendOneOneMaterial.SetFloat(name:  "_Intensity", value:  intensity_);
        this.addBrightStuffBlendOneOneMaterial.SetFloat(name:  "_Intensity", value:  intensity_);
        // 0x02675338: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x0267533C: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02675340: LDR x21, [x21, #0xe0]      | X21 = this.addBrightStuffBlendOneOneMaterial; //P2 
        // 0x02675344: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02675348: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x0267534C: TBZ w8, #0, #0x267535c     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x02675350: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02675354: CBNZ w8, #0x267535c        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x02675358: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_3:
        // 0x0267535C: MOV x1, x20                | X1 = from;//m1                          
        // 0x02675360: MOV x2, x19                | X2 = to;//m1                            
        // 0x02675364: MOV x3, x21                | X3 = this.addBrightStuffBlendOneOneMaterial;//m1
        // 0x02675368: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x0267536C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02675370: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02675374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675378: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267537C: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x02675380: B #0x1a6bc04               | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675030 (40325168), len: 664  VirtAddr: 0x02675030 RVA: 0x02675030 token: 100663320 methodIndex: 24404 delegateWrapperIndex: 0 methodInvoker: 0
    private void BlendFlares(UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x02675030: STP d11, d10, [sp, #-0x50]! | stack[1152921509947290912] = ???;  stack[1152921509947290920] = ???;  //  dest_result_addr=1152921509947290912 |  dest_result_addr=1152921509947290920
        // 0x02675034: STP d9, d8, [sp, #0x10]    | stack[1152921509947290928] = ???;  stack[1152921509947290936] = ???;  //  dest_result_addr=1152921509947290928 |  dest_result_addr=1152921509947290936
        // 0x02675038: STP x22, x21, [sp, #0x20]  | stack[1152921509947290944] = ???;  stack[1152921509947290952] = ???;  //  dest_result_addr=1152921509947290944 |  dest_result_addr=1152921509947290952
        // 0x0267503C: STP x20, x19, [sp, #0x30]  | stack[1152921509947290960] = ???;  stack[1152921509947290968] = ???;  //  dest_result_addr=1152921509947290960 |  dest_result_addr=1152921509947290968
        // 0x02675040: STP x29, x30, [sp, #0x40]  | stack[1152921509947290976] = ???;  stack[1152921509947290984] = ???;  //  dest_result_addr=1152921509947290976 |  dest_result_addr=1152921509947290984
        // 0x02675044: ADD x29, sp, #0x40         | X29 = (1152921509947290912 + 64) = 1152921509947290976 (0x100000013E50B560);
        // 0x02675048: SUB sp, sp, #0x40          | SP = (1152921509947290912 - 64) = 1152921509947290848 (0x100000013E50B4E0);
        // 0x0267504C: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02675050: LDRB w8, [x22, #0xe4e]     | W8 = (bool)static_value_03740E4E;       
        // 0x02675054: MOV x19, x2                | X19 = to;//m1                           
        // 0x02675058: MOV x20, x1                | X20 = from;//m1                         
        // 0x0267505C: MOV x21, x0                | X21 = 1152921509947302992 (0x100000013E50E450);//ML01
        // 0x02675060: TBNZ w8, #0, #0x267507c    | if (static_value_03740E4E == true) goto label_0;
        // 0x02675064: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x02675068: LDR x8, [x8, #0x1f8]       | X8 = 0x2B8F6B4;                         
        // 0x0267506C: LDR w0, [x8]               | W0 = 0x1471;                            
        // 0x02675070: BL #0x2782188              | X0 = sub_2782188( ?? 0x1471, ????);     
        // 0x02675074: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02675078: STRB w8, [x22, #0xe4e]     | static_value_03740E4E = true;            //  dest_result_addr=57937486
        label_0:
        // 0x0267507C: LDR x22, [x21, #0xb0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02675080: LDP s0, s1, [x21, #0x58]   | S0 = this.flareColorA; //P2              //  | 
        // 0x02675084: LDP s2, s3, [x21, #0x60]   |                                          //  | 
        // 0x02675088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267508C: ADD x0, sp, #0x30          | X0 = (1152921509947290848 + 48) = 1152921509947290896 (0x100000013E50B510);
        // 0x02675090: STP xzr, xzr, [sp, #0x30]  | stack[1152921509947290896] = 0x0;  stack[1152921509947290904] = 0x0;  //  dest_result_addr=1152921509947290896 |  dest_result_addr=1152921509947290904
        // 0x02675094: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02675098: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x0267509C: LDR x8, [x8, #0xb10]       | X8 = 1152921504708763648;               
        // 0x026750A0: LDR s8, [x21, #0x50]       | S8 = this.lensflareIntensity; //P2      
        // 0x026750A4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector4);       
        // 0x026750A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector4.__il2cppRuntimeField_10A;
        // 0x026750AC: TBZ w8, #0, #0x26750bc     | if (UnityEngine.Vector4.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x026750B0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished;
        // 0x026750B4: CBNZ w8, #0x26750bc        | if (UnityEngine.Vector4.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x026750B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector4), ????);
        label_2:
        // 0x026750BC: LDP s0, s1, [sp, #0x30]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026750C0: LDP s2, s3, [sp, #0x38]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026750C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026750C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026750CC: MOV v4.16b, v8.16b         | V4 = this.lensflareIntensity;//m1       
        // 0x026750D0: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_1 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x026750D4: MOV v8.16b, v0.16b         | V8 = val_1.x;//m1                       
        // 0x026750D8: MOV v9.16b, v1.16b         | V9 = val_1.y;//m1                       
        // 0x026750DC: MOV v10.16b, v2.16b        | V10 = val_1.z;//m1                      
        // 0x026750E0: MOV v11.16b, v3.16b        | V11 = val_1.w;//m1                      
        // 0x026750E4: CBNZ x22, #0x26750ec       | if (this.lensFlareMaterial != null) goto label_3;
        if(this.lensFlareMaterial != null)
        {
            goto label_3;
        }
        // 0x026750E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x026750EC: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
        // 0x026750F0: LDR x8, [x8, #0x778]       | X8 = (string**)(1152921509945606832)("colorA");
        // 0x026750F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026750F8: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x026750FC: MOV v0.16b, v8.16b         | V0 = val_1.x;//m1                       
        // 0x02675100: LDR x1, [x8]               | X1 = "colorA";                          
        // 0x02675104: MOV v1.16b, v9.16b         | V1 = val_1.y;//m1                       
        // 0x02675108: MOV v2.16b, v10.16b        | V2 = val_1.z;//m1                       
        // 0x0267510C: MOV v3.16b, v11.16b        | V3 = val_1.w;//m1                       
        // 0x02675110: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorA", value:  new UnityEngine.Vector4() {x = val_1.x, y = val_1.y, z = val_1.z, w = val_1.w});
        this.lensFlareMaterial.SetVector(name:  "colorA", value:  new UnityEngine.Vector4() {x = val_1.x, y = val_1.y, z = val_1.z, w = val_1.w});
        // 0x02675114: LDR x22, [x21, #0xb0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02675118: LDP s0, s1, [x21, #0x68]   | S0 = this.flareColorB; //P2              //  | 
        // 0x0267511C: LDP s2, s3, [x21, #0x70]   |                                          //  | 
        // 0x02675120: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675124: ADD x0, sp, #0x20          | X0 = (1152921509947290848 + 32) = 1152921509947290880 (0x100000013E50B500);
        // 0x02675128: STP xzr, xzr, [sp, #0x20]  | stack[1152921509947290880] = 0x0;  stack[1152921509947290888] = 0x0;  //  dest_result_addr=1152921509947290880 |  dest_result_addr=1152921509947290888
        // 0x0267512C: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02675130: LDR s4, [x21, #0x50]       | S4 = this.lensflareIntensity; //P2      
        // 0x02675134: LDP s0, s1, [sp, #0x20]    | S0 = 0; S1 = 0;                          //  | 
        // 0x02675138: LDP s2, s3, [sp, #0x28]    | S2 = 0; S3 = 0;                          //  | 
        // 0x0267513C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675144: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_2 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x02675148: MOV v8.16b, v0.16b         | V8 = val_2.x;//m1                       
        // 0x0267514C: MOV v9.16b, v1.16b         | V9 = val_2.y;//m1                       
        // 0x02675150: MOV v10.16b, v2.16b        | V10 = val_2.z;//m1                      
        // 0x02675154: MOV v11.16b, v3.16b        | V11 = val_2.w;//m1                      
        // 0x02675158: CBNZ x22, #0x2675160       | if (this.lensFlareMaterial != null) goto label_4;
        if(this.lensFlareMaterial != null)
        {
            goto label_4;
        }
        // 0x0267515C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x02675160: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
        // 0x02675164: LDR x8, [x8, #0xe0]        | X8 = (string**)(1152921509945611008)("colorB");
        // 0x02675168: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x0267516C: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x02675170: MOV v0.16b, v8.16b         | V0 = val_2.x;//m1                       
        // 0x02675174: LDR x1, [x8]               | X1 = "colorB";                          
        // 0x02675178: MOV v1.16b, v9.16b         | V1 = val_2.y;//m1                       
        // 0x0267517C: MOV v2.16b, v10.16b        | V2 = val_2.z;//m1                       
        // 0x02675180: MOV v3.16b, v11.16b        | V3 = val_2.w;//m1                       
        // 0x02675184: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorB", value:  new UnityEngine.Vector4() {x = val_2.x, y = val_2.y, z = val_2.z, w = val_2.w});
        this.lensFlareMaterial.SetVector(name:  "colorB", value:  new UnityEngine.Vector4() {x = val_2.x, y = val_2.y, z = val_2.z, w = val_2.w});
        // 0x02675188: LDR x22, [x21, #0xb0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x0267518C: LDP s0, s1, [x21, #0x78]   | S0 = this.flareColorC; //P2              //  | 
        // 0x02675190: LDP s2, s3, [x21, #0x80]   |                                          //  | 
        // 0x02675194: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02675198: ADD x0, sp, #0x10          | X0 = (1152921509947290848 + 16) = 1152921509947290864 (0x100000013E50B4F0);
        // 0x0267519C: STP xzr, xzr, [sp, #0x10]  | stack[1152921509947290864] = 0x0;  stack[1152921509947290872] = 0x0;  //  dest_result_addr=1152921509947290864 |  dest_result_addr=1152921509947290872
        // 0x026751A0: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x026751A4: LDR s4, [x21, #0x50]       | S4 = this.lensflareIntensity; //P2      
        // 0x026751A8: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x026751AC: LDP s2, s3, [sp, #0x18]    | S2 = 0; S3 = 0;                          //  | 
        // 0x026751B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026751B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026751B8: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_3 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x026751BC: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x026751C0: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x026751C4: MOV v10.16b, v2.16b        | V10 = val_3.z;//m1                      
        // 0x026751C8: MOV v11.16b, v3.16b        | V11 = val_3.w;//m1                      
        // 0x026751CC: CBNZ x22, #0x26751d4       | if (this.lensFlareMaterial != null) goto label_5;
        if(this.lensFlareMaterial != null)
        {
            goto label_5;
        }
        // 0x026751D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x026751D4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x026751D8: LDR x8, [x8, #0xbc8]       | X8 = (string**)(1152921509945615184)("colorC");
        // 0x026751DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x026751E0: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x026751E4: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x026751E8: LDR x1, [x8]               | X1 = "colorC";                          
        // 0x026751EC: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x026751F0: MOV v2.16b, v10.16b        | V2 = val_3.z;//m1                       
        // 0x026751F4: MOV v3.16b, v11.16b        | V3 = val_3.w;//m1                       
        // 0x026751F8: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorC", value:  new UnityEngine.Vector4() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w});
        this.lensFlareMaterial.SetVector(name:  "colorC", value:  new UnityEngine.Vector4() {x = val_3.x, y = val_3.y, z = val_3.z, w = val_3.w});
        // 0x026751FC: LDR x22, [x21, #0xb0]      | X22 = this.lensFlareMaterial; //P2      
        // 0x02675200: LDP s0, s1, [x21, #0x88]   | S0 = this.flareColorD; //P2              //  | 
        // 0x02675204: LDP s2, s3, [x21, #0x90]   |                                          //  | 
        // 0x02675208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267520C: MOV x0, sp                 | X0 = 1152921509947290848 (0x100000013E50B4E0);//ML01
        // 0x02675210: STP xzr, xzr, [sp]         | stack[1152921509947290848] = 0x0;  stack[1152921509947290856] = 0x0;  //  dest_result_addr=1152921509947290848 |  dest_result_addr=1152921509947290856
        // 0x02675214: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02675218: LDR s4, [x21, #0x50]       | S4 = this.lensflareIntensity; //P2      
        // 0x0267521C: LDP s0, s1, [sp]           | S0 = 0; S1 = 0;                          //  | 
        // 0x02675220: LDP s2, s3, [sp, #8]       | S2 = 0; S3 = 0;                          //  | 
        // 0x02675224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x0267522C: BL #0x269b780              | X0 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        UnityEngine.Vector4 val_4 = UnityEngine.Vector4.op_Multiply(a:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f}, d:  this.lensflareIntensity);
        // 0x02675230: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        // 0x02675234: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        // 0x02675238: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x0267523C: MOV v11.16b, v3.16b        | V11 = val_4.w;//m1                      
        // 0x02675240: CBNZ x22, #0x2675248       | if (this.lensFlareMaterial != null) goto label_6;
        if(this.lensFlareMaterial != null)
        {
            goto label_6;
        }
        // 0x02675244: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x02675248: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
        // 0x0267524C: LDR x8, [x8, #0x230]       | X8 = (string**)(1152921509945619360)("colorD");
        // 0x02675250: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02675254: MOV x0, x22                | X0 = this.lensFlareMaterial;//m1        
        // 0x02675258: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x0267525C: LDR x1, [x8]               | X1 = "colorD";                          
        // 0x02675260: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x02675264: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x02675268: MOV v3.16b, v11.16b        | V3 = val_4.w;//m1                       
        // 0x0267526C: BL #0x1a79fa8              | this.lensFlareMaterial.SetVector(name:  "colorD", value:  new UnityEngine.Vector4() {x = val_4.x, y = val_4.y, z = val_4.z, w = val_4.w});
        this.lensFlareMaterial.SetVector(name:  "colorD", value:  new UnityEngine.Vector4() {x = val_4.x, y = val_4.y, z = val_4.z, w = val_4.w});
        // 0x02675270: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02675274: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02675278: LDR x21, [x21, #0xb0]      | X21 = this.lensFlareMaterial; //P2      
        // 0x0267527C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02675280: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02675284: TBZ w8, #0, #0x2675294     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_8;
        // 0x02675288: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x0267528C: CBNZ w8, #0x2675294        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
        // 0x02675290: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_8:
        // 0x02675294: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675298: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x0267529C: MOV x1, x20                | X1 = from;//m1                          
        // 0x026752A0: MOV x2, x19                | X2 = to;//m1                            
        // 0x026752A4: MOV x3, x21                | X3 = this.lensFlareMaterial;//m1        
        // 0x026752A8: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        // 0x026752AC: SUB sp, x29, #0x40         | SP = (1152921509947290976 - 64) = 1152921509947290912 (0x100000013E50B520);
        // 0x026752B0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x026752B4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x026752B8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x026752BC: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x026752C0: LDP d11, d10, [sp], #0x50  | D11 = ; D10 = ;                          //  | 
        // 0x026752C4: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02674D74 (40324468), len: 320  VirtAddr: 0x02674D74 RVA: 0x02674D74 token: 100663321 methodIndex: 24405 delegateWrapperIndex: 0 methodInvoker: 0
    private void BrightFilter(float thresh, float useAlphaAsMask, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x02674D74: STP d9, d8, [sp, #-0x40]!  | stack[1152921509947452288] = ???;  stack[1152921509947452296] = ???;  //  dest_result_addr=1152921509947452288 |  dest_result_addr=1152921509947452296
        // 0x02674D78: STP x22, x21, [sp, #0x10]  | stack[1152921509947452304] = ???;  stack[1152921509947452312] = ???;  //  dest_result_addr=1152921509947452304 |  dest_result_addr=1152921509947452312
        // 0x02674D7C: STP x20, x19, [sp, #0x20]  | stack[1152921509947452320] = ???;  stack[1152921509947452328] = ???;  //  dest_result_addr=1152921509947452320 |  dest_result_addr=1152921509947452328
        // 0x02674D80: STP x29, x30, [sp, #0x30]  | stack[1152921509947452336] = ???;  stack[1152921509947452344] = ???;  //  dest_result_addr=1152921509947452336 |  dest_result_addr=1152921509947452344
        // 0x02674D84: ADD x29, sp, #0x30         | X29 = (1152921509947452288 + 48) = 1152921509947452336 (0x100000013E532BB0);
        // 0x02674D88: SUB sp, sp, #0x10          | SP = (1152921509947452288 - 16) = 1152921509947452272 (0x100000013E532B70);
        // 0x02674D8C: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02674D90: LDRB w8, [x22, #0xe4f]     | W8 = (bool)static_value_03740E4F;       
        // 0x02674D94: MOV x19, x2                | X19 = to;//m1                           
        // 0x02674D98: MOV x20, x1                | X20 = from;//m1                         
        // 0x02674D9C: MOV v8.16b, v1.16b         | V8 = useAlphaAsMask;//m1                
        // 0x02674DA0: MOV v9.16b, v0.16b         | V9 = thresh;//m1                        
        // 0x02674DA4: MOV x21, x0                | X21 = 1152921509947464352 (0x100000013E535AA0);//ML01
        // 0x02674DA8: TBNZ w8, #0, #0x2674dc4    | if (static_value_03740E4F == true) goto label_0;
        // 0x02674DAC: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x02674DB0: LDR x8, [x8, #0xaf0]       | X8 = 0x2B8F6B8;                         
        // 0x02674DB4: LDR w0, [x8]               | W0 = 0x1472;                            
        // 0x02674DB8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1472, ????);     
        // 0x02674DBC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02674DC0: STRB w8, [x22, #0xe4f]     | static_value_03740E4F = true;            //  dest_result_addr=57937487
        label_0:
        // 0x02674DC4: LDR x22, [x21, #0x110]     | X22 = this.brightPassFilterMaterial; //P2 
        // 0x02674DC8: LDRB w8, [x21, #0x28]      | W8 = this.doHdr; //P2                   
        // 0x02674DCC: CBZ w8, #0x2674de0         | if (this.doHdr == false) goto label_1;  
        if(this.doHdr == false)
        {
            goto label_1;
        }
        // 0x02674DD0: STP xzr, xzr, [sp]         | stack[1152921509947452272] = 0x0;  stack[1152921509947452280] = 0x0;  //  dest_result_addr=1152921509947452272 |  dest_result_addr=1152921509947452280
        // 0x02674DD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x02674DD8: FMOV s1, #1.00000000       | S1 = 1;                                 
        // 0x02674DDC: B #0x2674df4               |  goto label_2;                          
        goto label_2;
        label_1:
        // 0x02674DE0: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x02674DE4: FSUB s1, s0, s9            | S1 = (1f - thresh);                     
        float val_1 = 1f - thresh;
        // 0x02674DE8: STP xzr, xzr, [sp]         | stack[1152921509947452272] = 0x0;  stack[1152921509947452280] = 0x0;  //  dest_result_addr=1152921509947452272 |  dest_result_addr=1152921509947452280
        // 0x02674DEC: FDIV s1, s0, s1            | S1 = (1f / (1f - thresh));              
        val_1 = 1f / val_1;
        // 0x02674DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        label_2:
        // 0x02674DF4: FMOV s2, wzr               | S2 = 0f;                                
        // 0x02674DF8: MOV x0, sp                 | X0 = 1152921509947452272 (0x100000013E532B70);//ML01
        // 0x02674DFC: MOV v0.16b, v9.16b         | V0 = thresh;//m1                        
        // 0x02674E00: MOV v3.16b, v2.16b         | V3 = 0;//m1                             
        // 0x02674E04: BL #0x269b1dc              | X0 = label_UnityEngine_Vector3Int__cctor_GL0269B1DC();
        // 0x02674E08: CBNZ x22, #0x2674e10       | if (this.brightPassFilterMaterial != null) goto label_3;
        if(this.brightPassFilterMaterial != null)
        {
            goto label_3;
        }
        // 0x02674E0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000013E532B70, ????);
        label_3:
        // 0x02674E10: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
        // 0x02674E14: LDR x8, [x8, #0x248]       | X8 = (string**)(1152921509947431952)("threshhold");
        // 0x02674E18: LDR s0, [sp]               | S0 = 0;                                 
        // 0x02674E1C: LDR s1, [sp, #4]           | S1 = 0;                                 
        // 0x02674E20: LDR s2, [sp, #8]           | S2 = 0;                                 
        // 0x02674E24: LDR x1, [x8]               | X1 = "threshhold";                      
        // 0x02674E28: LDR s3, [sp, #0xc]         | S3 = 0;                                 
        // 0x02674E2C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674E30: MOV x0, x22                | X0 = this.brightPassFilterMaterial;//m1 
        // 0x02674E34: BL #0x1a79fa8              | this.brightPassFilterMaterial.SetVector(name:  "threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        this.brightPassFilterMaterial.SetVector(name:  "threshhold", value:  new UnityEngine.Vector4() {x = 0f, y = 0f, z = 0f, w = 0f});
        // 0x02674E38: LDR x22, [x21, #0x110]     | X22 = this.brightPassFilterMaterial; //P2 
        // 0x02674E3C: CBNZ x22, #0x2674e44       | if (this.brightPassFilterMaterial != null) goto label_4;
        if(this.brightPassFilterMaterial != null)
        {
            goto label_4;
        }
        // 0x02674E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.brightPassFilterMaterial, ????);
        label_4:
        // 0x02674E44: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x02674E48: LDR x8, [x8, #0xa80]       | X8 = (string**)(1152921509947436144)("useSrcAlphaAsMask");
        // 0x02674E4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674E50: MOV x0, x22                | X0 = this.brightPassFilterMaterial;//m1 
        // 0x02674E54: MOV v0.16b, v8.16b         | V0 = useAlphaAsMask;//m1                
        // 0x02674E58: LDR x1, [x8]               | X1 = "useSrcAlphaAsMask";               
        // 0x02674E5C: BL #0x1a79ef8              | this.brightPassFilterMaterial.SetFloat(name:  "useSrcAlphaAsMask", value:  useAlphaAsMask);
        this.brightPassFilterMaterial.SetFloat(name:  "useSrcAlphaAsMask", value:  useAlphaAsMask);
        // 0x02674E60: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02674E64: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02674E68: LDR x21, [x21, #0x110]     | X21 = this.brightPassFilterMaterial; //P2 
        // 0x02674E6C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674E70: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674E74: TBZ w8, #0, #0x2674e84     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x02674E78: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674E7C: CBNZ w8, #0x2674e84        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x02674E80: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_6:
        // 0x02674E84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674E88: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02674E8C: MOV x1, x20                | X1 = from;//m1                          
        // 0x02674E90: MOV x2, x19                | X2 = to;//m1                            
        // 0x02674E94: MOV x3, x21                | X3 = this.brightPassFilterMaterial;//m1 
        // 0x02674E98: BL #0x1a6bc04              | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        // 0x02674E9C: SUB sp, x29, #0x30         | SP = (1152921509947452336 - 48) = 1152921509947452288 (0x100000013E532B80);
        // 0x02674EA0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x02674EA4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x02674EA8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x02674EAC: LDP d9, d8, [sp], #0x40    | D9 = ; D8 = ;                            //  | 
        // 0x02674EB0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02674EB4 (40324788), len: 380  VirtAddr: 0x02674EB4 RVA: 0x02674EB4 token: 100663322 methodIndex: 24406 delegateWrapperIndex: 0 methodInvoker: 0
    private void Vignette(float amount, UnityEngine.RenderTexture from, UnityEngine.RenderTexture to)
    {
        //
        // Disasemble & Code
        // 0x02674EB4: STP d9, d8, [sp, #-0x50]!  | stack[1152921509947617632] = ???;  stack[1152921509947617640] = ???;  //  dest_result_addr=1152921509947617632 |  dest_result_addr=1152921509947617640
        // 0x02674EB8: STP x24, x23, [sp, #0x10]  | stack[1152921509947617648] = ???;  stack[1152921509947617656] = ???;  //  dest_result_addr=1152921509947617648 |  dest_result_addr=1152921509947617656
        // 0x02674EBC: STP x22, x21, [sp, #0x20]  | stack[1152921509947617664] = ???;  stack[1152921509947617672] = ???;  //  dest_result_addr=1152921509947617664 |  dest_result_addr=1152921509947617672
        // 0x02674EC0: STP x20, x19, [sp, #0x30]  | stack[1152921509947617680] = ???;  stack[1152921509947617688] = ???;  //  dest_result_addr=1152921509947617680 |  dest_result_addr=1152921509947617688
        // 0x02674EC4: STP x29, x30, [sp, #0x40]  | stack[1152921509947617696] = ???;  stack[1152921509947617704] = ???;  //  dest_result_addr=1152921509947617696 |  dest_result_addr=1152921509947617704
        // 0x02674EC8: ADD x29, sp, #0x40         | X29 = (1152921509947617632 + 64) = 1152921509947617696 (0x100000013E55B1A0);
        // 0x02674ECC: ADRP x22, #0x3740000       | X22 = 57933824 (0x3740000);             
        // 0x02674ED0: LDRB w8, [x22, #0xe50]     | W8 = (bool)static_value_03740E50;       
        // 0x02674ED4: MOV x19, x2                | X19 = to;//m1                           
        // 0x02674ED8: MOV x20, x1                | X20 = from;//m1                         
        // 0x02674EDC: MOV v8.16b, v0.16b         | V8 = amount;//m1                        
        // 0x02674EE0: MOV x21, x0                | X21 = 1152921509947629712 (0x100000013E55E090);//ML01
        // 0x02674EE4: TBNZ w8, #0, #0x2674f00    | if (static_value_03740E50 == true) goto label_0;
        // 0x02674EE8: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
        // 0x02674EEC: LDR x8, [x8, #0x668]       | X8 = 0x2B8F6C4;                         
        // 0x02674EF0: LDR w0, [x8]               | W0 = 0x1475;                            
        // 0x02674EF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1475, ????);     
        // 0x02674EF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x02674EFC: STRB w8, [x22, #0xe50]     | static_value_03740E50 = true;            //  dest_result_addr=57937488
        label_0:
        // 0x02674F00: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x02674F04: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x02674F08: LDR x22, [x21, #0xa0]      | X22 = this.lensFlareVignetteMask; //P2  
        // 0x02674F0C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x02674F10: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x02674F14: TBZ w8, #0, #0x2674f24     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x02674F18: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x02674F1C: CBNZ w8, #0x2674f24        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x02674F20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x02674F24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674F28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674F2C: MOV x1, x22                | X1 = this.lensFlareVignetteMask;//m1    
        // 0x02674F30: BL #0x1b79230              | X0 = UnityEngine.Object.op_Implicit(exists:  0);
        bool val_1 = UnityEngine.Object.op_Implicit(exists:  0);
        // 0x02674F34: TBZ w0, #0, #0x2674fb8     | if (val_1 == false) goto label_3;       
        if(val_1 == false)
        {
            goto label_3;
        }
        // 0x02674F38: LDR x22, [x21, #0xf0]      | X22 = this.screenBlend; //P2            
        // 0x02674F3C: LDR x23, [x21, #0xa0]      | X23 = this.lensFlareVignetteMask; //P2  
        // 0x02674F40: CBNZ x22, #0x2674f48       | if (this.screenBlend != null) goto label_4;
        if(this.screenBlend != null)
        {
            goto label_4;
        }
        // 0x02674F44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x02674F48: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
        // 0x02674F4C: LDR x8, [x8, #0xca0]       | X8 = (string**)(1152921509945091920)("_ColorBuffer");
        // 0x02674F50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x02674F54: MOV x0, x22                | X0 = this.screenBlend;//m1              
        // 0x02674F58: MOV x2, x23                | X2 = this.lensFlareVignetteMask;//m1    
        // 0x02674F5C: LDR x1, [x8]               | X1 = "_ColorBuffer";                    
        // 0x02674F60: BL #0x1a780c4              | this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  this.lensFlareVignetteMask);
        this.screenBlend.SetTexture(name:  "_ColorBuffer", value:  this.lensFlareVignetteMask);
        // 0x02674F64: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02674F68: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02674F6C: LDR x21, [x21, #0xf0]      | X21 = this.screenBlend; //P2            
        // 0x02674F70: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674F74: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674F78: TBZ w8, #0, #0x2674f88     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_6;
        // 0x02674F7C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674F80: CBNZ w8, #0x2674f88        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
        // 0x02674F84: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_6:
        // 0x02674F88: MOV x1, x20                | X1 = from;//m1                          
        // 0x02674F8C: MOV x2, x19                | X2 = to;//m1                            
        // 0x02674F90: MOV x3, x21                | X3 = this.screenBlend;//m1              
        // 0x02674F94: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02674F98: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02674F9C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x02674FA0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x02674FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02674FA8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
        // 0x02674FAC: ORR w4, wzr, #3            | W4 = 3(0x3);                            
        // 0x02674FB0: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x02674FB4: B #0x1a6bc84               | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.screenBlend); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to, pass:  this.screenBlend);
        return;
        label_3:
        // 0x02674FB8: LDR x22, [x21, #0xc0]      | X22 = this.vignetteMaterial; //P2       
        // 0x02674FBC: CBNZ x22, #0x2674fc4       | if (this.vignetteMaterial != null) goto label_7;
        if(this.vignetteMaterial != null)
        {
            goto label_7;
        }
        // 0x02674FC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_7:
        // 0x02674FC4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x02674FC8: LDR x8, [x8, #0x6a8]       | X8 = (string**)(1152921509947601504)("vignetteIntensity");
        // 0x02674FCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x02674FD0: MOV x0, x22                | X0 = this.vignetteMaterial;//m1         
        // 0x02674FD4: MOV v0.16b, v8.16b         | V0 = amount;//m1                        
        // 0x02674FD8: LDR x1, [x8]               | X1 = "vignetteIntensity";               
        // 0x02674FDC: BL #0x1a79ef8              | this.vignetteMaterial.SetFloat(name:  "vignetteIntensity", value:  amount);
        this.vignetteMaterial.SetFloat(name:  "vignetteIntensity", value:  amount);
        // 0x02674FE0: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
        // 0x02674FE4: LDR x8, [x8, #0x800]       | X8 = 1152921504693481472;               
        // 0x02674FE8: LDR x21, [x21, #0xc0]      | X21 = this.vignetteMaterial; //P2       
        // 0x02674FEC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Graphics);      
        // 0x02674FF0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Graphics.__il2cppRuntimeField_10A;
        // 0x02674FF4: TBZ w8, #0, #0x2675004     | if (UnityEngine.Graphics.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x02674FF8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished;
        // 0x02674FFC: CBNZ w8, #0x2675004        | if (UnityEngine.Graphics.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x02675000: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Graphics), ????);
        label_9:
        // 0x02675004: MOV x1, x20                | X1 = from;//m1                          
        // 0x02675008: MOV x2, x19                | X2 = to;//m1                            
        // 0x0267500C: MOV x3, x21                | X3 = this.vignetteMaterial;//m1         
        // 0x02675010: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x02675014: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x02675018: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x0267501C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x02675020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x02675024: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x02675028: LDP d9, d8, [sp], #0x50    | D9 = ; D8 = ;                            //  | 
        // 0x0267502C: B #0x1a6bc04               | UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to); return;
        UnityEngine.Graphics.Blit(source:  0, dest:  from, mat:  to);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x02675384 (40326020), len: 4  VirtAddr: 0x02675384 RVA: 0x02675384 token: 100663323 methodIndex: 24407 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Main()
    {
        //
        // Disasemble & Code
        // 0x02675384: RET                        |  return;                                
        return;
    
    }

}
