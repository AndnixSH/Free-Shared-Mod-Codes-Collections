using UnityEngine;

namespace ILRuntime.Mono.Cecil.Metadata
{
    internal sealed class BlobHeap : Heap
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E6B6E4 (15120100), len: 44  VirtAddr: 0x00E6B6E4 RVA: 0x00E6B6E4 token: 100664584 methodIndex: 19765 delegateWrapperIndex: 0 methodInvoker: 0
        public BlobHeap(byte[] data)
        {
            //
            // Disasemble & Code
            // 0x00E6B6E4: STP x20, x19, [sp, #-0x20]! | stack[1152921509570495520] = ???;  stack[1152921509570495528] = ???;  //  dest_result_addr=1152921509570495520 |  dest_result_addr=1152921509570495528
            // 0x00E6B6E8: STP x29, x30, [sp, #0x10]  | stack[1152921509570495536] = ???;  stack[1152921509570495544] = ???;  //  dest_result_addr=1152921509570495536 |  dest_result_addr=1152921509570495544
            // 0x00E6B6EC: ADD x29, sp, #0x10         | X29 = (1152921509570495520 + 16) = 1152921509570495536 (0x1000000127DB4430);
            // 0x00E6B6F0: MOV x19, x1                | X19 = data;//m1                         
            // 0x00E6B6F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E6B6F8: MOV x20, x0                | X20 = 1152921509570507552 (0x1000000127DB7320);//ML01
            // 0x00E6B6FC: BL #0x16f59f0              | this..ctor();                           
            val_1 = new System.Object();
            // 0x00E6B700: STR x19, [x20, #0x18]      | mem[1152921509570507576] = data;         //  dest_result_addr=1152921509570507576
            mem[1152921509570507576] = data;
            // 0x00E6B704: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E6B708: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E6B70C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E6B73C (15120188), len: 344  VirtAddr: 0x00E6B73C RVA: 0x00E6B73C token: 100664585 methodIndex: 19766 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] Read(uint index)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x00E6B73C: STP x22, x21, [sp, #-0x30]! | stack[1152921509570644368] = ???;  stack[1152921509570644376] = ???;  //  dest_result_addr=1152921509570644368 |  dest_result_addr=1152921509570644376
            // 0x00E6B740: STP x20, x19, [sp, #0x10]  | stack[1152921509570644384] = ???;  stack[1152921509570644392] = ???;  //  dest_result_addr=1152921509570644384 |  dest_result_addr=1152921509570644392
            // 0x00E6B744: STP x29, x30, [sp, #0x20]  | stack[1152921509570644400] = ???;  stack[1152921509570644408] = ???;  //  dest_result_addr=1152921509570644400 |  dest_result_addr=1152921509570644408
            // 0x00E6B748: ADD x29, sp, #0x20         | X29 = (1152921509570644368 + 32) = 1152921509570644400 (0x1000000127DD89B0);
            // 0x00E6B74C: SUB sp, sp, #0x10          | SP = (1152921509570644368 - 16) = 1152921509570644352 (0x1000000127DD8980);
            // 0x00E6B750: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E6B754: LDRB w8, [x21, #0xb94]     | W8 = (bool)static_value_03734B94;       
            // 0x00E6B758: MOV w20, w1                | W20 = index;//m1                        
            // 0x00E6B75C: MOV x19, x0                | X19 = 1152921509570656416 (0x1000000127DDB8A0);//ML01
            // 0x00E6B760: TBNZ w8, #0, #0xe6b77c     | if (static_value_03734B94 == true) goto label_0;
            // 0x00E6B764: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00E6B768: LDR x8, [x8, #0x198]       | X8 = 0x2B8F63C;                         
            // 0x00E6B76C: LDR w0, [x8]               | W0 = 0x1453;                            
            // 0x00E6B770: BL #0x2782188              | X0 = sub_2782188( ?? 0x1453, ????);     
            // 0x00E6B774: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E6B778: STRB w8, [x21, #0xb94]     | static_value_03734B94 = true;            //  dest_result_addr=57887636
            label_0:
            // 0x00E6B77C: STR wzr, [sp, #0xc]        | stack[1152921509570644364] = 0x0;        //  dest_result_addr=1152921509570644364
            // 0x00E6B780: CBZ w20, #0xe6b808         | if (index == 0) goto label_3;           
            if(index == 0)
            {
                goto label_3;
            }
            // 0x00E6B784: LDR x21, [x19, #0x18]      | 
            // 0x00E6B788: CBNZ x21, #0xe6b790        | if ( != 0) goto label_2;                
            if(!=0)
            {
                goto label_2;
            }
            // 0x00E6B78C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1453, ????);     
            label_2:
            // 0x00E6B790: LDR x8, [x21, #0x18]       | X8 = mem[57884696];                     
            // 0x00E6B794: ORR x10, xzr, #0xffffffff00000000 | X10 = -4294967296(0xFFFFFFFF00000000);  
            // 0x00E6B798: MOV w9, w20                | W9 = index;//m1                         
            // 0x00E6B79C: ADD x8, x10, x8, lsl #32   | X8 = (-4294967296 + (mem[57884696]) << 32);
            var val_1 = (-4294967296) + ((mem[57884696]) << 32);
            // 0x00E6B7A0: CMP x9, x8, asr #32        | STATE = COMPARE(index, ((ulong)(-4294967296 + (mem[57884696]) << 32)) >> 32)
            // 0x00E6B7A4: B.GT #0xe6b808             | if (index > val_1 >> 32) goto label_3;  
            if(index > (val_1 >> 32))
            {
                goto label_3;
            }
            // 0x00E6B7A8: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E6B7AC: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E6B7B0: STR w20, [sp, #0xc]        | stack[1152921509570644364] = index;      //  dest_result_addr=1152921509570644364
            // 0x00E6B7B4: LDR x20, [x19, #0x18]      | 
            // 0x00E6B7B8: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E6B7BC: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E6B7C0: TBZ w8, #0, #0xe6b7d0      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00E6B7C4: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E6B7C8: CBNZ w8, #0xe6b7d0         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00E6B7CC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_5:
            // 0x00E6B7D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E6B7D4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E6B7D8: ADD x2, sp, #0xc           | X2 = (1152921509570644352 + 12) = 1152921509570644364 (0x1000000127DD898C);
            // 0x00E6B7DC: MOV x1, x20                | X1 = index;//m1                         
            int val_2 = index;
            // 0x00E6B7E0: BL #0x11db8ec              | X0 = ILRuntime.Mono.Cecil.Mixin.ReadCompressedUInt32(data:  0, position: ref  int val_2 = index);
            uint val_3 = ILRuntime.Mono.Cecil.Mixin.ReadCompressedUInt32(data:  0, position: ref  val_2);
            // 0x00E6B7E4: LDR x21, [x19, #0x18]      | 
            // 0x00E6B7E8: MOV w20, w0                | W20 = val_3;//m1                        
            // 0x00E6B7EC: CBNZ x21, #0xe6b7f4        | if ( != 0) goto label_6;                
            if(!=0)
            {
                goto label_6;
            }
            // 0x00E6B7F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_6:
            // 0x00E6B7F4: LDR w8, [sp, #0xc]         | W8 = index;                             
            uint val_4 = index;
            // 0x00E6B7F8: LDR w9, [x21, #0x18]       | W9 = mem[57884696];                     
            // 0x00E6B7FC: SUB w8, w9, w8             | W8 = (mem[57884696] - index);           
            val_4 = mem[57884696] - val_4;
            // 0x00E6B800: CMP w20, w8                | STATE = COMPARE(val_3, (mem[57884696] - index))
            // 0x00E6B804: B.LE #0xe6b84c             | if (val_3 <= index) goto label_7;       
            if(val_3 <= val_4)
            {
                goto label_7;
            }
            label_3:
            // 0x00E6B808: ADRP x19, #0x365b000       | X19 = 56995840 (0x365B000);             
            // 0x00E6B80C: LDR x19, [x19, #0x618]     | X19 = 1152921504736825344;              
            // 0x00E6B810: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_5 = null;
            // 0x00E6B814: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_10A;
            // 0x00E6B818: TBZ w8, #0, #0xe6b82c      | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x00E6B81C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished;
            // 0x00E6B820: CBNZ w8, #0xe6b82c         | if (ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x00E6B824: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Empty<T>), ????);
            // 0x00E6B828: LDR x0, [x19]              | X0 = typeof(ILRuntime.Mono.Empty<T>);   
            val_5 = null;
            label_9:
            // 0x00E6B82C: LDR x8, [x0, #0xa0]        | X8 = ILRuntime.Mono.Empty<T>.__il2cppRuntimeField_static_fields;
            // 0x00E6B830: LDR x19, [x8]              | X19 = ILRuntime.Mono.Empty<T>.Array;    
            label_10:
            // 0x00E6B834: MOV x0, x19                | X0 = ILRuntime.Mono.Empty<T>.Array;//m1 
            // 0x00E6B838: SUB sp, x29, #0x20         | SP = (1152921509570644400 - 32) = 1152921509570644368 (0x1000000127DD8990);
            // 0x00E6B83C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E6B840: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E6B844: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E6B848: RET                        |  return (System.Byte[])ILRuntime.Mono.Empty<T>.Array;
            return (System.Byte[])ILRuntime.Mono.Empty<T>.Array;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
            label_7:
            // 0x00E6B84C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x00E6B850: LDR x8, [x8, #0xf00]       | X8 = 1152921504996170800;               
            // 0x00E6B854: LDR x21, [x8]              | X21 = typeof(System.Byte[]);            
            // 0x00E6B858: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E6B85C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Byte[]), ????);
            // 0x00E6B860: MOV w1, w20                | W1 = val_3;//m1                         
            // 0x00E6B864: MOV x0, x21                | X0 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E6B868: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Byte[]), ????);
            // 0x00E6B86C: LDR x1, [x19, #0x18]       | 
            // 0x00E6B870: LDR w2, [sp, #0xc]         | W2 = index;                             
            // 0x00E6B874: MOV x19, x0                | X19 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E6B878: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E6B87C: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00E6B880: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x00E6B884: MOV x3, x19                | X3 = 1152921504996170800 (0x1000000017349C30);//ML01
            // 0x00E6B888: MOV w5, w20                | W5 = val_3;//m1                         
            // 0x00E6B88C: BL #0x18b30e0              | System.Buffer.BlockCopy(src:  0, srcOffset:  val_3, dst:  index, dstOffset:  389323824, count:  0);
            System.Buffer.BlockCopy(src:  0, srcOffset:  val_3, dst:  index, dstOffset:  389323824, count:  0);
            // 0x00E6B890: B #0xe6b834                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E6B894 (15120532), len: 224  VirtAddr: 0x00E6B894 RVA: 0x00E6B894 token: 100664586 methodIndex: 19767 delegateWrapperIndex: 0 methodInvoker: 0
        public void GetView(uint signature, out byte[] buffer, out int index, out int length)
        {
            //
            // Disasemble & Code
            //  | 
            System.Byte[] val_4;
            // 0x00E6B894: STP x24, x23, [sp, #-0x40]! | stack[1152921509570768448] = ???;  stack[1152921509570768456] = ???;  //  dest_result_addr=1152921509570768448 |  dest_result_addr=1152921509570768456
            // 0x00E6B898: STP x22, x21, [sp, #0x10]  | stack[1152921509570768464] = ???;  stack[1152921509570768472] = ???;  //  dest_result_addr=1152921509570768464 |  dest_result_addr=1152921509570768472
            // 0x00E6B89C: STP x20, x19, [sp, #0x20]  | stack[1152921509570768480] = ???;  stack[1152921509570768488] = ???;  //  dest_result_addr=1152921509570768480 |  dest_result_addr=1152921509570768488
            // 0x00E6B8A0: STP x29, x30, [sp, #0x30]  | stack[1152921509570768496] = ???;  stack[1152921509570768504] = ???;  //  dest_result_addr=1152921509570768496 |  dest_result_addr=1152921509570768504
            // 0x00E6B8A4: ADD x29, sp, #0x30         | X29 = (1152921509570768448 + 48) = 1152921509570768496 (0x1000000127DF6E70);
            // 0x00E6B8A8: ADRP x24, #0x3734000       | X24 = 57884672 (0x3734000);             
            // 0x00E6B8AC: LDRB w8, [x24, #0xb95]     | W8 = (bool)static_value_03734B95;       
            // 0x00E6B8B0: MOV x19, x4                | X19 = 1152921509570820576 (0x1000000127E039E0);//ML01
            // 0x00E6B8B4: MOV x20, x3                | X20 = 1152921509570816544 (0x1000000127E02A20);//ML01
            // 0x00E6B8B8: MOV x21, x2                | X21 = 1152921509570812512 (0x1000000127E01A60);//ML01
            val_4 = 1152921509570812512;
            // 0x00E6B8BC: MOV w22, w1                | W22 = signature;//m1                    
            // 0x00E6B8C0: MOV x23, x0                | X23 = 1152921509570780512 (0x1000000127DF9D60);//ML01
            // 0x00E6B8C4: TBNZ w8, #0, #0xe6b8e0     | if (static_value_03734B95 == true) goto label_0;
            // 0x00E6B8C8: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x00E6B8CC: LDR x8, [x8, #0x520]       | X8 = 0x2B8F638;                         
            // 0x00E6B8D0: LDR w0, [x8]               | W0 = 0x1452;                            
            // 0x00E6B8D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1452, ????);     
            // 0x00E6B8D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E6B8DC: STRB w8, [x24, #0xb95]     | static_value_03734B95 = true;            //  dest_result_addr=57887637
            label_0:
            // 0x00E6B8E0: CBZ w22, #0xe6b908         | if (signature == 0) goto label_1;       
            if(signature == 0)
            {
                goto label_1;
            }
            // 0x00E6B8E4: LDR x24, [x23, #0x18]      | 
            // 0x00E6B8E8: CBNZ x24, #0xe6b8f0        | if ( != 0) goto label_2;                
            if(!=0)
            {
                goto label_2;
            }
            // 0x00E6B8EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1452, ????);     
            label_2:
            // 0x00E6B8F0: LDR x8, [x24, #0x18]       | X8 = mem[57884696];                     
            // 0x00E6B8F4: ORR x10, xzr, #0xffffffff00000000 | X10 = -4294967296(0xFFFFFFFF00000000);  
            // 0x00E6B8F8: MOV w9, w22                | W9 = signature;//m1                     
            // 0x00E6B8FC: ADD x8, x10, x8, lsl #32   | X8 = (-4294967296 + (mem[57884696]) << 32);
            System.Byte[] val_1 = (-4294967296) + ((mem[57884696]) << 32);
            // 0x00E6B900: CMP x9, x8, asr #32        | STATE = COMPARE(signature, ((ulong)(-4294967296 + (mem[57884696]) << 32)) >> 32)
            // 0x00E6B904: B.LE #0xe6b918             | if (signature <= val_1 >> 32) goto label_3;
            if(signature <= (val_1 >> 32))
            {
                goto label_3;
            }
            label_1:
            // 0x00E6B908: STR xzr, [x21]             | buffer = null;                           //  dest_result_addr=1152921509570812512
            buffer = 0;
            // 0x00E6B90C: STR wzr, [x19]             | length = 0;                              //  dest_result_addr=1152921509570820576
            length = 0;
            // 0x00E6B910: STR wzr, [x20]             | index = 0;                               //  dest_result_addr=1152921509570816544
            index = 0;
            // 0x00E6B914: B #0xe6b960                |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x00E6B918: LDR x8, [x23, #0x18]       | 
            // 0x00E6B91C: STR x8, [x21]              | buffer = (-4294967296 + (mem[57884696]) << 32);  //  dest_result_addr=1152921509570812512
            buffer = val_1;
            // 0x00E6B920: STR w22, [x20]             | index = signature;                       //  dest_result_addr=1152921509570816544
            index = signature;
            // 0x00E6B924: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E6B928: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E6B92C: LDR x21, [x21]             | X21 = (-4294967296 + (mem[57884696]) << 32);
            val_4 = buffer;
            // 0x00E6B930: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E6B934: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E6B938: TBZ w8, #0, #0xe6b948      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00E6B93C: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E6B940: CBNZ w8, #0xe6b948         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00E6B944: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_6:
            // 0x00E6B948: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E6B94C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E6B950: MOV x1, x21                | X1 = (-4294967296 + (mem[57884696]) << 32);//m1
            int val_2 = val_4;
            // 0x00E6B954: MOV x2, x20                | X2 = 1152921509570816544 (0x1000000127E02A20);//ML01
            // 0x00E6B958: BL #0x11db8ec              | X0 = ILRuntime.Mono.Cecil.Mixin.ReadCompressedUInt32(data:  0, position: ref  int val_2 = val_4);
            uint val_3 = ILRuntime.Mono.Cecil.Mixin.ReadCompressedUInt32(data:  0, position: ref  val_2);
            // 0x00E6B95C: STR w0, [x19]              | length = val_3;                          //  dest_result_addr=1152921509570820576
            length = val_3;
            label_4:
            // 0x00E6B960: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00E6B964: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00E6B968: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00E6B96C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00E6B970: RET                        |  return;                                
            return;
        
        }
    
    }

}
