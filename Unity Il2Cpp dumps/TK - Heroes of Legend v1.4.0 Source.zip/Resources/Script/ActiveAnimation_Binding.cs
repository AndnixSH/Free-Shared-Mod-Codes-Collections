using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class ActiveAnimation_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache3; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache4; // static_offset: 0x00000020
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache5; // static_offset: 0x00000028
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache6; // static_offset: 0x00000030
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache7; // static_offset: 0x00000038
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache8; // static_offset: 0x00000040
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache9; // static_offset: 0x00000048
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheA; // static_offset: 0x00000050
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheB; // static_offset: 0x00000058
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheC; // static_offset: 0x00000060
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cacheD; // static_offset: 0x00000068
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cacheE; // static_offset: 0x00000070
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cacheF; // static_offset: 0x00000078
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000080
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000088
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x028F9E70 (42966640), len: 8  VirtAddr: 0x028F9E70 RVA: 0x028F9E70 token: 100663665 methodIndex: 29710 delegateWrapperIndex: 0 methodInvoker: 0
        public ActiveAnimation_Binding()
        {
            //
            // Disasemble & Code
            // 0x028F9E70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9E74: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F9E78 (42966648), len: 4324  VirtAddr: 0x028F9E78 RVA: 0x028F9E78 token: 100663666 methodIndex: 29711 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_25;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_26;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_27;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_28;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_29;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_30;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_31;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_32;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_33;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_34;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_35;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_36;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_37;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_38;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_39;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_40;
            // 0x028F9E78: STP x28, x27, [sp, #-0x60]! | stack[1152921510030102736] = ???;  stack[1152921510030102744] = ???;  //  dest_result_addr=1152921510030102736 |  dest_result_addr=1152921510030102744
            // 0x028F9E7C: STP x26, x25, [sp, #0x10]  | stack[1152921510030102752] = ???;  stack[1152921510030102760] = ???;  //  dest_result_addr=1152921510030102752 |  dest_result_addr=1152921510030102760
            // 0x028F9E80: STP x24, x23, [sp, #0x20]  | stack[1152921510030102768] = ???;  stack[1152921510030102776] = ???;  //  dest_result_addr=1152921510030102768 |  dest_result_addr=1152921510030102776
            // 0x028F9E84: STP x22, x21, [sp, #0x30]  | stack[1152921510030102784] = ???;  stack[1152921510030102792] = ???;  //  dest_result_addr=1152921510030102784 |  dest_result_addr=1152921510030102792
            // 0x028F9E88: STP x20, x19, [sp, #0x40]  | stack[1152921510030102800] = ???;  stack[1152921510030102808] = ???;  //  dest_result_addr=1152921510030102800 |  dest_result_addr=1152921510030102808
            // 0x028F9E8C: STP x29, x30, [sp, #0x50]  | stack[1152921510030102816] = ???;  stack[1152921510030102824] = ???;  //  dest_result_addr=1152921510030102816 |  dest_result_addr=1152921510030102824
            // 0x028F9E90: ADD x29, sp, #0x50         | X29 = (1152921510030102736 + 80) = 1152921510030102816 (0x1000000143405120);
            // 0x028F9E94: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F9E98: LDRB w8, [x20, #0xa63]     | W8 = (bool)static_value_037B8A63;       
            // 0x028F9E9C: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028F9EA0: TBNZ w8, #0, #0x28f9ebc    | if (static_value_037B8A63 == true) goto label_0;
            // 0x028F9EA4: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x028F9EA8: LDR x8, [x8, #0xce8]       | X8 = 0x2B8A974;                         
            // 0x028F9EAC: LDR w0, [x8]               | W0 = 0x11B;                             
            // 0x028F9EB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x11B, ????);      
            // 0x028F9EB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F9EB8: STRB w8, [x20, #0xa63]     | static_value_037B8A63 = true;            //  dest_result_addr=58428003
            label_0:
            // 0x028F9EBC: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x028F9EC0: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x028F9EC4: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x028F9EC8: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x028F9ECC: LDR x8, [x8, #0xed8]       | X8 = 1152921504875483136;               
            // 0x028F9ED0: LDR x20, [x8]              | X20 = typeof(ActiveAnimation);          
            // 0x028F9ED4: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x028F9ED8: TBZ w8, #0, #0x28f9ee8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x028F9EDC: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028F9EE0: CBNZ w8, #0x28f9ee8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x028F9EE4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x028F9EE8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028F9EEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028F9EF0: MOV x1, x20                | X1 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028F9EF4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028F9EF8: ADRP x26, #0x35ef000       | X26 = 56553472 (0x35EF000);             
            // 0x028F9EFC: LDR x26, [x26, #0xff0]     | X26 = 1152921504987155056;              
            // 0x028F9F00: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x028F9F04: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028F9F08: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9F0C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F9F10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9F14: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9F18: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F9F1C: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9F20: CBNZ x20, #0x28f9f28       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x028F9F24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_3:
            // 0x028F9F28: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028F9F2C: LDR x8, [x8, #0xd20]       | X8 = (string**)(1152921510029977456)("get_isPlaying");
            // 0x028F9F30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F9F34: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F9F38: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F9F3C: LDR x1, [x8]               | X1 = "get_isPlaying";                   
            // 0x028F9F40: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028F9F44: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9F48: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028F9F4C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "get_isPlaying", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_2 = val_1.GetMethod(name:  "get_isPlaying", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028F9F50: ADRP x23, #0x361d000       | X23 = 56741888 (0x361D000);             
            // 0x028F9F54: LDR x23, [x23, #0x3b0]     | X23 = 1152921504782512128;              
            // 0x028F9F58: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028F9F5C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028F9F60: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F9F64: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0;
            // 0x028F9F68: CBNZ x22, #0x28f9fac       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0 != null) goto label_4;
            if((ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0) != null)
            {
                goto label_4;
            }
            // 0x028F9F6C: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x028F9F70: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028F9F74: LDR x8, [x8, #0x788]       | X8 = 1152921510029981648;               
            // 0x028F9F78: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028F9F7C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F9F80: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028F9F84: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028F9F88: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F9F8C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F9F90: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028F9F94: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028F9F98: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F9F9C: STR x0, [x8]               | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516224
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0 = null;
            // 0x028F9FA0: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028F9FA4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028F9FA8: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_4:
            // 0x028F9FAC: CBNZ x19, #0x28f9fb4       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x028F9FB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_5:
            // 0x028F9FB4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028F9FB8: MOV x1, x21                | X1 = val_2;//m1                         
            // 0x028F9FBC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028F9FC0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0);
            X1.RegisterCLRMethodRedirection(mi:  val_2, func:  ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache0);
            // 0x028F9FC4: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028F9FC8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9FCC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028F9FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028F9FD4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9FD8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028F9FDC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028F9FE0: CBNZ x20, #0x28f9fe8       | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x028F9FE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_6:
            // 0x028F9FE8: ADRP x8, #0x3634000        | X8 = 56836096 (0x3634000);              
            // 0x028F9FEC: LDR x8, [x8, #0x28]        | X8 = (string**)(1152921510029982672)("Finish");
            // 0x028F9FF0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028F9FF4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028F9FF8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F9FFC: LDR x1, [x8]               | X1 = "Finish";                          
            // 0x028FA000: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA004: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA008: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FA00C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Finish", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_3 = val_1.GetMethod(name:  "Finish", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FA010: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA014: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028FA018: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA01C: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1;
            // 0x028FA020: CBNZ x22, #0x28fa064       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1 != null) goto label_7;
            if((ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1) != null)
            {
                goto label_7;
            }
            // 0x028FA024: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x028FA028: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FA02C: LDR x8, [x8, #0xdd0]       | X8 = 1152921510029986848;               
            // 0x028FA030: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FA034: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA038: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FA03C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FA040: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA044: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA048: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA04C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA050: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA054: STR x0, [x8, #8]           | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516232
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1 = null;
            // 0x028FA058: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA05C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA060: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            label_7:
            // 0x028FA064: CBNZ x19, #0x28fa06c       | if (X1 != 0) goto label_8;              
            if(X1 != 0)
            {
                goto label_8;
            }
            // 0x028FA068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_8:
            // 0x028FA06C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FA070: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FA074: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FA078: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1);
            X1.RegisterCLRMethodRedirection(mi:  val_3, func:  ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache1);
            // 0x028FA07C: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028FA080: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA084: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028FA088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA08C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA090: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028FA094: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA098: CBNZ x20, #0x28fa0a0       | if (val_1 != null) goto label_9;        
            if(val_1 != null)
            {
                goto label_9;
            }
            // 0x028FA09C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_9:
            // 0x028FA0A0: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x028FA0A4: LDR x8, [x8, #0x620]       | X8 = (string**)(1152921510029987872)("Reset");
            // 0x028FA0A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FA0AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FA0B0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FA0B4: LDR x1, [x8]               | X1 = "Reset";                           
            // 0x028FA0B8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA0BC: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA0C0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FA0C4: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Reset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_4 = val_1.GetMethod(name:  "Reset", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FA0C8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA0CC: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x028FA0D0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA0D4: LDR x22, [x8, #0x10]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache2;
            val_25 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache2;
            // 0x028FA0D8: CBNZ x22, #0x28fa11c       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache2 != null) goto label_10;
            if(val_25 != null)
            {
                goto label_10;
            }
            // 0x028FA0DC: ADRP x8, #0x35f1000        | X8 = 56561664 (0x35F1000);              
            // 0x028FA0E0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FA0E4: LDR x8, [x8, #0x608]       | X8 = 1152921510029992048;               
            // 0x028FA0E8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FA0EC: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA0F0: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FA0F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FA0F8: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA0FC: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA100: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA104: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA108: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA10C: STR x0, [x8, #0x10]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516240
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache2 = null;
            // 0x028FA110: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA114: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA118: LDR x22, [x8, #0x10]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_25 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache2;
            label_10:
            // 0x028FA11C: CBNZ x19, #0x28fa124       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028FA120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_11:
            // 0x028FA124: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FA128: MOV x1, x21                | X1 = val_4;//m1                         
            // 0x028FA12C: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FA130: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_25);
            X1.RegisterCLRMethodRedirection(mi:  val_4, func:  val_25);
            // 0x028FA134: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028FA138: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA13C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028FA140: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x028FA144: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA148: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028FA14C: ADRP x24, #0x35ce000       | X24 = 56418304 (0x35CE000);             
            // 0x028FA150: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x028FA154: LDR x24, [x24, #0x9e8]     | X24 = 1152921504723353600;              
            // 0x028FA158: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA15C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FA160: LDR x22, [x24]             | X22 = typeof(UnityEngine.Animation);    
            // 0x028FA164: TBZ w9, #0, #0x28fa178     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_13;
            // 0x028FA168: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FA16C: CBNZ w9, #0x28fa178        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
            // 0x028FA170: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FA174: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_13:
            // 0x028FA178: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA17C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA180: MOV x1, x22                | X1 = 1152921504723353600 (0x1000000006F1C000);//ML01
            // 0x028FA184: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA188: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028FA18C: CBNZ x21, #0x28fa194       | if ( != null) goto label_14;            
            if(null != null)
            {
                goto label_14;
            }
            // 0x028FA190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_14:
            // 0x028FA194: CBZ x22, #0x28fa1b8        | if (val_5 == null) goto label_16;       
            if(val_5 == null)
            {
                goto label_16;
            }
            // 0x028FA198: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA19C: MOV x0, x22                | X0 = val_5;//m1                         
            // 0x028FA1A0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA1A4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_5, ????);      
            // 0x028FA1A8: CBNZ x0, #0x28fa1b8        | if (val_5 != null) goto label_16;       
            if(val_5 != null)
            {
                goto label_16;
            }
            // 0x028FA1AC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_5, ????);      
            // 0x028FA1B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA1B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_16:
            // 0x028FA1B8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA1BC: CBNZ w8, #0x28fa1cc        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_17;
            // 0x028FA1C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x028FA1C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA1C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_17:
            // 0x028FA1CC: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_5;
            // 0x028FA1D0: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028FA1D4: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x028FA1D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA1DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA1E0: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FA1E4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_6 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA1E8: MOV x22, x0                | X22 = val_6;//m1                        
            // 0x028FA1EC: CBZ x22, #0x28fa210        | if (val_6 == null) goto label_19;       
            if(val_6 == null)
            {
                goto label_19;
            }
            // 0x028FA1F0: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA1F4: MOV x0, x22                | X0 = val_6;//m1                         
            // 0x028FA1F8: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA1FC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_6, ????);      
            // 0x028FA200: CBNZ x0, #0x28fa210        | if (val_6 != null) goto label_19;       
            if(val_6 != null)
            {
                goto label_19;
            }
            // 0x028FA204: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_6, ????);      
            // 0x028FA208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA20C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_19:
            // 0x028FA210: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA214: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028FA218: B.HI #0x28fa228            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_20;
            // 0x028FA21C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_6, ????);      
            // 0x028FA220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA224: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            label_20:
            // 0x028FA228: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_6;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_6;
            // 0x028FA22C: ADRP x27, #0x364f000       | X27 = 56946688 (0x364F000);             
            // 0x028FA230: LDR x27, [x27, #0x2c0]     | X27 = 1152921504875589632;              
            // 0x028FA234: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA238: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA23C: LDR x1, [x27]              | X1 = typeof(AnimationOrTween.Direction);
            // 0x028FA240: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_7 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA244: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x028FA248: CBZ x22, #0x28fa26c        | if (val_7 == null) goto label_22;       
            if(val_7 == null)
            {
                goto label_22;
            }
            // 0x028FA24C: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA250: MOV x0, x22                | X0 = val_7;//m1                         
            // 0x028FA254: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA258: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_7, ????);      
            // 0x028FA25C: CBNZ x0, #0x28fa26c        | if (val_7 != null) goto label_22;       
            if(val_7 != null)
            {
                goto label_22;
            }
            // 0x028FA260: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_7, ????);      
            // 0x028FA264: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA268: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_22:
            // 0x028FA26C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA270: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x028FA274: B.HI #0x28fa284            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_23;
            // 0x028FA278: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_7, ????);      
            // 0x028FA27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA280: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_7, ????);      
            label_23:
            // 0x028FA284: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_7;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_7;
            // 0x028FA288: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x028FA28C: LDR x8, [x8, #0x8f8]       | X8 = 1152921504875642880;               
            // 0x028FA290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA294: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA298: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.EnableCondition);
            // 0x028FA29C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA2A0: MOV x22, x0                | X22 = val_8;//m1                        
            // 0x028FA2A4: CBZ x22, #0x28fa2c8        | if (val_8 == null) goto label_25;       
            if(val_8 == null)
            {
                goto label_25;
            }
            // 0x028FA2A8: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA2AC: MOV x0, x22                | X0 = val_8;//m1                         
            // 0x028FA2B0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA2B4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_8, ????);      
            // 0x028FA2B8: CBNZ x0, #0x28fa2c8        | if (val_8 != null) goto label_25;       
            if(val_8 != null)
            {
                goto label_25;
            }
            // 0x028FA2BC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_8, ????);      
            // 0x028FA2C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA2C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_25:
            // 0x028FA2C8: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA2CC: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x028FA2D0: B.HI #0x28fa2e0            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_26;
            // 0x028FA2D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_8, ????);      
            // 0x028FA2D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA2DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            label_26:
            // 0x028FA2E0: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_8;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_8;
            // 0x028FA2E4: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x028FA2E8: LDR x8, [x8, #0x138]       | X8 = 1152921504875696128;               
            // 0x028FA2EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA2F0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA2F4: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.DisableCondition);
            // 0x028FA2F8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA2FC: MOV x22, x0                | X22 = val_9;//m1                        
            // 0x028FA300: CBZ x22, #0x28fa324        | if (val_9 == null) goto label_28;       
            if(val_9 == null)
            {
                goto label_28;
            }
            // 0x028FA304: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA308: MOV x0, x22                | X0 = val_9;//m1                         
            // 0x028FA30C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA310: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_9, ????);      
            // 0x028FA314: CBNZ x0, #0x28fa324        | if (val_9 != null) goto label_28;       
            if(val_9 != null)
            {
                goto label_28;
            }
            // 0x028FA318: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_9, ????);      
            // 0x028FA31C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA320: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_28:
            // 0x028FA324: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA328: CMP w8, #4                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x028FA32C: B.HI #0x28fa33c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x4) goto label_29;
            // 0x028FA330: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9, ????);      
            // 0x028FA334: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA338: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9, ????);      
            label_29:
            // 0x028FA33C: STR x22, [x21, #0x40]      | typeof(System.Type[]).__il2cppRuntimeField_40 = val_9;  //  dest_result_addr=1152921504987155120
            typeof(System.Type[]).__il2cppRuntimeField_40 = val_9;
            // 0x028FA340: CBNZ x20, #0x28fa348       | if (val_1 != null) goto label_30;       
            if(val_1 != null)
            {
                goto label_30;
            }
            // 0x028FA344: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_30:
            // 0x028FA348: ADRP x28, #0x3653000       | X28 = 56963072 (0x3653000);             
            // 0x028FA34C: LDR x28, [x28, #0x930]     | X28 = (string**)(1152921510030013552)("Play");
            // 0x028FA350: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FA354: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FA358: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FA35C: LDR x1, [x28]              | X1 = "Play";                            
            // 0x028FA360: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA364: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA368: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FA36C: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_10 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FA370: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA374: MOV x21, x0                | X21 = val_10;//m1                       
            // 0x028FA378: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA37C: LDR x22, [x8, #0x18]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache3;
            val_26 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache3;
            // 0x028FA380: CBNZ x22, #0x28fa3c4       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache3 != null) goto label_31;
            if(val_26 != null)
            {
                goto label_31;
            }
            // 0x028FA384: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x028FA388: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FA38C: LDR x8, [x8, #0x820]       | X8 = 1152921510030017728;               
            // 0x028FA390: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FA394: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA398: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FA39C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FA3A0: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA3A4: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA3A8: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA3AC: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA3B0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA3B4: STR x0, [x8, #0x18]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516248
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache3 = null;
            // 0x028FA3B8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA3BC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA3C0: LDR x22, [x8, #0x18]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_26 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache3;
            label_31:
            // 0x028FA3C4: CBNZ x19, #0x28fa3cc       | if (X1 != 0) goto label_32;             
            if(X1 != 0)
            {
                goto label_32;
            }
            // 0x028FA3C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_32:
            // 0x028FA3CC: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FA3D0: MOV x1, x21                | X1 = val_10;//m1                        
            // 0x028FA3D4: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FA3D8: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_26);
            X1.RegisterCLRMethodRedirection(mi:  val_10, func:  val_26);
            // 0x028FA3DC: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028FA3E0: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA3E4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028FA3E8: ORR w1, wzr, #3            | W1 = 3(0x3);                            
            // 0x028FA3EC: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA3F0: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028FA3F4: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x028FA3F8: LDR x22, [x24]             | X22 = typeof(UnityEngine.Animation);    
            // 0x028FA3FC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA400: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FA404: TBZ w9, #0, #0x28fa418     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_34;
            // 0x028FA408: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FA40C: CBNZ w9, #0x28fa418        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_34;
            // 0x028FA410: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FA414: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_34:
            // 0x028FA418: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA41C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA420: MOV x1, x22                | X1 = 1152921504723353600 (0x1000000006F1C000);//ML01
            // 0x028FA424: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_11 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA428: MOV x22, x0                | X22 = val_11;//m1                       
            // 0x028FA42C: CBNZ x21, #0x28fa434       | if ( != null) goto label_35;            
            if(null != null)
            {
                goto label_35;
            }
            // 0x028FA430: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
            label_35:
            // 0x028FA434: CBZ x22, #0x28fa458        | if (val_11 == null) goto label_37;      
            if(val_11 == null)
            {
                goto label_37;
            }
            // 0x028FA438: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA43C: MOV x0, x22                | X0 = val_11;//m1                        
            // 0x028FA440: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA444: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_11, ????);     
            // 0x028FA448: CBNZ x0, #0x28fa458        | if (val_11 != null) goto label_37;      
            if(val_11 != null)
            {
                goto label_37;
            }
            // 0x028FA44C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_11, ????);     
            // 0x028FA450: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA454: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_37:
            // 0x028FA458: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA45C: CBNZ w8, #0x28fa46c        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_38;
            // 0x028FA460: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_11, ????);     
            // 0x028FA464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA468: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            label_38:
            // 0x028FA46C: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_11;
            // 0x028FA470: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028FA474: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x028FA478: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA47C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA480: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FA484: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA488: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x028FA48C: CBZ x22, #0x28fa4b0        | if (val_12 == null) goto label_40;      
            if(val_12 == null)
            {
                goto label_40;
            }
            // 0x028FA490: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA494: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x028FA498: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA49C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x028FA4A0: CBNZ x0, #0x28fa4b0        | if (val_12 != null) goto label_40;      
            if(val_12 != null)
            {
                goto label_40;
            }
            // 0x028FA4A4: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_12, ????);     
            // 0x028FA4A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA4AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_40:
            // 0x028FA4B0: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA4B4: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028FA4B8: B.HI #0x28fa4c8            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_41;
            // 0x028FA4BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_12, ????);     
            // 0x028FA4C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA4C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            label_41:
            // 0x028FA4C8: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_12;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_12;
            // 0x028FA4CC: LDR x1, [x27]              | X1 = typeof(AnimationOrTween.Direction);
            // 0x028FA4D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA4D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA4D8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA4DC: MOV x22, x0                | X22 = val_13;//m1                       
            // 0x028FA4E0: CBZ x22, #0x28fa504        | if (val_13 == null) goto label_43;      
            if(val_13 == null)
            {
                goto label_43;
            }
            // 0x028FA4E4: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA4E8: MOV x0, x22                | X0 = val_13;//m1                        
            // 0x028FA4EC: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA4F0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_13, ????);     
            // 0x028FA4F4: CBNZ x0, #0x28fa504        | if (val_13 != null) goto label_43;      
            if(val_13 != null)
            {
                goto label_43;
            }
            // 0x028FA4F8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_13, ????);     
            // 0x028FA4FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA500: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_43:
            // 0x028FA504: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA508: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x028FA50C: B.HI #0x28fa51c            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_44;
            // 0x028FA510: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_13, ????);     
            // 0x028FA514: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA518: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            label_44:
            // 0x028FA51C: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_13;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_13;
            // 0x028FA520: CBNZ x20, #0x28fa528       | if (val_1 != null) goto label_45;       
            if(val_1 != null)
            {
                goto label_45;
            }
            // 0x028FA524: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
            label_45:
            // 0x028FA528: LDR x1, [x28]              | X1 = "Play";                            
            // 0x028FA52C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FA530: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FA534: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FA538: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA53C: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA540: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FA544: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_14 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FA548: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA54C: MOV x21, x0                | X21 = val_14;//m1                       
            // 0x028FA550: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA554: LDR x22, [x8, #0x20]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache4;
            val_27 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache4;
            // 0x028FA558: CBNZ x22, #0x28fa59c       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache4 != null) goto label_46;
            if(val_27 != null)
            {
                goto label_46;
            }
            // 0x028FA55C: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x028FA560: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FA564: LDR x8, [x8, #0x840]       | X8 = 1152921510030035136;               
            // 0x028FA568: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FA56C: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA570: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FA574: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FA578: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA57C: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA580: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA584: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA588: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA58C: STR x0, [x8, #0x20]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache4 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516256
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache4 = null;
            // 0x028FA590: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA594: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA598: LDR x22, [x8, #0x20]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_27 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache4;
            label_46:
            // 0x028FA59C: CBNZ x19, #0x28fa5a4       | if (X1 != 0) goto label_47;             
            if(X1 != 0)
            {
                goto label_47;
            }
            // 0x028FA5A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_47:
            // 0x028FA5A4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FA5A8: MOV x1, x21                | X1 = val_14;//m1                        
            // 0x028FA5AC: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FA5B0: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_27);
            X1.RegisterCLRMethodRedirection(mi:  val_14, func:  val_27);
            // 0x028FA5B4: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028FA5B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA5BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028FA5C0: ORR w1, wzr, #2            | W1 = 2(0x2);                            
            // 0x028FA5C4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA5C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028FA5CC: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x028FA5D0: LDR x22, [x24]             | X22 = typeof(UnityEngine.Animation);    
            // 0x028FA5D4: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA5D8: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FA5DC: TBZ w9, #0, #0x28fa5f0     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_49;
            // 0x028FA5E0: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FA5E4: CBNZ w9, #0x28fa5f0        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_49;
            // 0x028FA5E8: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FA5EC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_49:
            // 0x028FA5F0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA5F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA5F8: MOV x1, x22                | X1 = 1152921504723353600 (0x1000000006F1C000);//ML01
            // 0x028FA5FC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_15 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA600: MOV x22, x0                | X22 = val_15;//m1                       
            // 0x028FA604: CBNZ x21, #0x28fa60c       | if ( != null) goto label_50;            
            if(null != null)
            {
                goto label_50;
            }
            // 0x028FA608: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_15, ????);     
            label_50:
            // 0x028FA60C: CBZ x22, #0x28fa630        | if (val_15 == null) goto label_52;      
            if(val_15 == null)
            {
                goto label_52;
            }
            // 0x028FA610: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA614: MOV x0, x22                | X0 = val_15;//m1                        
            // 0x028FA618: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA61C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_15, ????);     
            // 0x028FA620: CBNZ x0, #0x28fa630        | if (val_15 != null) goto label_52;      
            if(val_15 != null)
            {
                goto label_52;
            }
            // 0x028FA624: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_15, ????);     
            // 0x028FA628: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA62C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_52:
            // 0x028FA630: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA634: CBNZ w8, #0x28fa644        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_53;
            // 0x028FA638: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_15, ????);     
            // 0x028FA63C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA640: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_15, ????);     
            label_53:
            // 0x028FA644: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_15;
            // 0x028FA648: LDR x1, [x27]              | X1 = typeof(AnimationOrTween.Direction);
            // 0x028FA64C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA650: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA654: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA658: MOV x22, x0                | X22 = val_16;//m1                       
            // 0x028FA65C: CBZ x22, #0x28fa680        | if (val_16 == null) goto label_55;      
            if(val_16 == null)
            {
                goto label_55;
            }
            // 0x028FA660: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA664: MOV x0, x22                | X0 = val_16;//m1                        
            // 0x028FA668: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA66C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_16, ????);     
            // 0x028FA670: CBNZ x0, #0x28fa680        | if (val_16 != null) goto label_55;      
            if(val_16 != null)
            {
                goto label_55;
            }
            // 0x028FA674: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_16, ????);     
            // 0x028FA678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA67C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_55:
            // 0x028FA680: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA684: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028FA688: B.HI #0x28fa698            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_56;
            // 0x028FA68C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_16, ????);     
            // 0x028FA690: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA694: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            label_56:
            // 0x028FA698: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_16;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_16;
            // 0x028FA69C: CBNZ x20, #0x28fa6a4       | if (val_1 != null) goto label_57;       
            if(val_1 != null)
            {
                goto label_57;
            }
            // 0x028FA6A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
            label_57:
            // 0x028FA6A4: LDR x1, [x28]              | X1 = "Play";                            
            // 0x028FA6A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FA6AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FA6B0: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FA6B4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA6B8: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA6BC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FA6C0: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_17 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FA6C4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA6C8: MOV x21, x0                | X21 = val_17;//m1                       
            // 0x028FA6CC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA6D0: LDR x22, [x8, #0x28]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache5;
            val_28 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache5;
            // 0x028FA6D4: CBNZ x22, #0x28fa718       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache5 != null) goto label_58;
            if(val_28 != null)
            {
                goto label_58;
            }
            // 0x028FA6D8: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x028FA6DC: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FA6E0: LDR x8, [x8, #0x2a0]       | X8 = 1152921510030048448;               
            // 0x028FA6E4: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FA6E8: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA6EC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FA6F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FA6F4: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA6F8: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA6FC: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA700: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA704: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA708: STR x0, [x8, #0x28]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache5 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516264
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache5 = null;
            // 0x028FA70C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA710: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA714: LDR x22, [x8, #0x28]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_28 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache5;
            label_58:
            // 0x028FA718: CBNZ x19, #0x28fa720       | if (X1 != 0) goto label_59;             
            if(X1 != 0)
            {
                goto label_59;
            }
            // 0x028FA71C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_59:
            // 0x028FA720: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FA724: MOV x1, x21                | X1 = val_17;//m1                        
            // 0x028FA728: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FA72C: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_28);
            X1.RegisterCLRMethodRedirection(mi:  val_17, func:  val_28);
            // 0x028FA730: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028FA734: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA738: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028FA73C: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x028FA740: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA744: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028FA748: ADRP x9, #0x3683000        | X9 = 57159680 (0x3683000);              
            // 0x028FA74C: LDR x8, [x25]              | X8 = typeof(System.Type);               
            // 0x028FA750: LDR x9, [x9, #0x390]       | X9 = 1152921504724152320;               
            // 0x028FA754: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA758: LDR x22, [x9]              | X22 = typeof(UnityEngine.Animator);     
            // 0x028FA75C: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FA760: TBZ w9, #0, #0x28fa774     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_61;
            // 0x028FA764: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FA768: CBNZ w9, #0x28fa774        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_61;
            // 0x028FA76C: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FA770: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_61:
            // 0x028FA774: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA778: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA77C: MOV x1, x22                | X1 = 1152921504724152320 (0x1000000006FDF000);//ML01
            // 0x028FA780: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_18 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA784: MOV x22, x0                | X22 = val_18;//m1                       
            // 0x028FA788: CBNZ x21, #0x28fa790       | if ( != null) goto label_62;            
            if(null != null)
            {
                goto label_62;
            }
            // 0x028FA78C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_18, ????);     
            label_62:
            // 0x028FA790: CBZ x22, #0x28fa7b4        | if (val_18 == null) goto label_64;      
            if(val_18 == null)
            {
                goto label_64;
            }
            // 0x028FA794: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA798: MOV x0, x22                | X0 = val_18;//m1                        
            // 0x028FA79C: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA7A0: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_18, ????);     
            // 0x028FA7A4: CBNZ x0, #0x28fa7b4        | if (val_18 != null) goto label_64;      
            if(val_18 != null)
            {
                goto label_64;
            }
            // 0x028FA7A8: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_18, ????);     
            // 0x028FA7AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA7B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_64:
            // 0x028FA7B4: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA7B8: CBNZ w8, #0x28fa7c8        | if (System.Type[].__il2cppRuntimeField_namespaze != 0) goto label_65;
            // 0x028FA7BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_18, ????);     
            // 0x028FA7C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA7C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            label_65:
            // 0x028FA7C8: STR x22, [x21, #0x20]      | typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;  //  dest_result_addr=1152921504987155088
            typeof(System.Type[]).__il2cppRuntimeField_20 = val_18;
            // 0x028FA7CC: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028FA7D0: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x028FA7D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA7D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA7DC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FA7E0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_19 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA7E4: MOV x22, x0                | X22 = val_19;//m1                       
            // 0x028FA7E8: CBZ x22, #0x28fa80c        | if (val_19 == null) goto label_67;      
            if(val_19 == null)
            {
                goto label_67;
            }
            // 0x028FA7EC: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA7F0: MOV x0, x22                | X0 = val_19;//m1                        
            // 0x028FA7F4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA7F8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_19, ????);     
            // 0x028FA7FC: CBNZ x0, #0x28fa80c        | if (val_19 != null) goto label_67;      
            if(val_19 != null)
            {
                goto label_67;
            }
            // 0x028FA800: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_19, ????);     
            // 0x028FA804: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA808: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_67:
            // 0x028FA80C: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA810: CMP w8, #1                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x028FA814: B.HI #0x28fa824            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x1) goto label_68;
            // 0x028FA818: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_19, ????);     
            // 0x028FA81C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA820: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            label_68:
            // 0x028FA824: STR x22, [x21, #0x28]      | typeof(System.Type[]).__il2cppRuntimeField_28 = val_19;  //  dest_result_addr=1152921504987155096
            typeof(System.Type[]).__il2cppRuntimeField_28 = val_19;
            // 0x028FA828: LDR x1, [x27]              | X1 = typeof(AnimationOrTween.Direction);
            // 0x028FA82C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA830: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA834: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_20 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA838: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x028FA83C: CBZ x22, #0x28fa860        | if (val_20 == null) goto label_70;      
            if(val_20 == null)
            {
                goto label_70;
            }
            // 0x028FA840: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA844: MOV x0, x22                | X0 = val_20;//m1                        
            // 0x028FA848: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA84C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_20, ????);     
            // 0x028FA850: CBNZ x0, #0x28fa860        | if (val_20 != null) goto label_70;      
            if(val_20 != null)
            {
                goto label_70;
            }
            // 0x028FA854: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_20, ????);     
            // 0x028FA858: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA85C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_70:
            // 0x028FA860: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA864: CMP w8, #2                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x028FA868: B.HI #0x28fa878            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x2) goto label_71;
            // 0x028FA86C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_20, ????);     
            // 0x028FA870: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA874: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_20, ????);     
            label_71:
            // 0x028FA878: STR x22, [x21, #0x30]      | typeof(System.Type[]).__il2cppRuntimeField_30 = val_20;  //  dest_result_addr=1152921504987155104
            typeof(System.Type[]).__il2cppRuntimeField_30 = val_20;
            // 0x028FA87C: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x028FA880: LDR x8, [x8, #0x8f8]       | X8 = 1152921504875642880;               
            // 0x028FA884: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA888: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA88C: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.EnableCondition);
            // 0x028FA890: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_21 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA894: MOV x22, x0                | X22 = val_21;//m1                       
            // 0x028FA898: CBZ x22, #0x28fa8bc        | if (val_21 == null) goto label_73;      
            if(val_21 == null)
            {
                goto label_73;
            }
            // 0x028FA89C: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA8A0: MOV x0, x22                | X0 = val_21;//m1                        
            // 0x028FA8A4: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA8A8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_21, ????);     
            // 0x028FA8AC: CBNZ x0, #0x28fa8bc        | if (val_21 != null) goto label_73;      
            if(val_21 != null)
            {
                goto label_73;
            }
            // 0x028FA8B0: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_21, ????);     
            // 0x028FA8B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA8B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_73:
            // 0x028FA8BC: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA8C0: CMP w8, #3                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x028FA8C4: B.HI #0x28fa8d4            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x3) goto label_74;
            // 0x028FA8C8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_21, ????);     
            // 0x028FA8CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA8D0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            label_74:
            // 0x028FA8D4: STR x22, [x21, #0x38]      | typeof(System.Type[]).__il2cppRuntimeField_38 = val_21;  //  dest_result_addr=1152921504987155112
            typeof(System.Type[]).__il2cppRuntimeField_38 = val_21;
            // 0x028FA8D8: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x028FA8DC: LDR x8, [x8, #0x138]       | X8 = 1152921504875696128;               
            // 0x028FA8E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FA8E4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FA8E8: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.DisableCondition);
            // 0x028FA8EC: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_22 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FA8F0: MOV x22, x0                | X22 = val_22;//m1                       
            // 0x028FA8F4: CBZ x22, #0x28fa918        | if (val_22 == null) goto label_76;      
            if(val_22 == null)
            {
                goto label_76;
            }
            // 0x028FA8F8: LDR x8, [x21]              | X8 = ;                                  
            // 0x028FA8FC: MOV x0, x22                | X0 = val_22;//m1                        
            // 0x028FA900: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FA904: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_22, ????);     
            // 0x028FA908: CBNZ x0, #0x28fa918        | if (val_22 != null) goto label_76;      
            if(val_22 != null)
            {
                goto label_76;
            }
            // 0x028FA90C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? val_22, ????);     
            // 0x028FA910: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA914: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_76:
            // 0x028FA918: LDR w8, [x21, #0x18]       | W8 = System.Type[].__il2cppRuntimeField_namespaze;
            // 0x028FA91C: CMP w8, #4                 | STATE = COMPARE(System.Type[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x028FA920: B.HI #0x28fa930            | if (System.Type[].__il2cppRuntimeField_namespaze > 0x4) goto label_77;
            // 0x028FA924: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_22, ????);     
            // 0x028FA928: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FA92C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_22, ????);     
            label_77:
            // 0x028FA930: STR x22, [x21, #0x40]      | typeof(System.Type[]).__il2cppRuntimeField_40 = val_22;  //  dest_result_addr=1152921504987155120
            typeof(System.Type[]).__il2cppRuntimeField_40 = val_22;
            // 0x028FA934: CBNZ x20, #0x28fa93c       | if (val_1 != null) goto label_78;       
            if(val_1 != null)
            {
                goto label_78;
            }
            // 0x028FA938: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_22, ????);     
            label_78:
            // 0x028FA93C: LDR x1, [x28]              | X1 = "Play";                            
            // 0x028FA940: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FA944: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FA948: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FA94C: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA950: MOV x4, x21                | X4 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FA954: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FA958: BL #0x1b6e2ac              | X0 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.MethodInfo val_23 = val_1.GetMethod(name:  "Play", bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FA95C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA960: MOV x21, x0                | X21 = val_23;//m1                       
            // 0x028FA964: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA968: LDR x22, [x8, #0x30]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache6;
            val_29 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache6;
            // 0x028FA96C: CBNZ x22, #0x28fa9b0       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache6 != null) goto label_79;
            if(val_29 != null)
            {
                goto label_79;
            }
            // 0x028FA970: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x028FA974: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FA978: LDR x8, [x8, #0x5b8]       | X8 = 1152921510030074048;               
            // 0x028FA97C: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FA980: LDR x22, [x8]              | X22 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA984: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FA988: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FA98C: LDR x8, [x22]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA990: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA994: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FA998: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA99C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA9A0: STR x0, [x8, #0x30]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache6 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516272
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache6 = null;
            // 0x028FA9A4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA9A8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FA9AC: LDR x22, [x8, #0x30]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_29 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache6;
            label_79:
            // 0x028FA9B0: CBNZ x19, #0x28fa9b8       | if (X1 != 0) goto label_80;             
            if(X1 != 0)
            {
                goto label_80;
            }
            // 0x028FA9B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_80:
            // 0x028FA9B8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FA9BC: MOV x1, x21                | X1 = val_23;//m1                        
            // 0x028FA9C0: MOV x2, x22                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FA9C4: BL #0x28e3b20              | X1.RegisterCLRMethodRedirection(mi:  val_23, func:  val_29);
            X1.RegisterCLRMethodRedirection(mi:  val_23, func:  val_29);
            // 0x028FA9C8: CBNZ x20, #0x28fa9d0       | if (val_1 != null) goto label_81;       
            if(val_1 != null)
            {
                goto label_81;
            }
            // 0x028FA9CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_81:
            // 0x028FA9D0: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
            // 0x028FA9D4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028FA9D8: LDR x9, [x9, #0x118]       | X9 = (string**)(1152921510030075072)("current");
            // 0x028FA9DC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FA9E0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FA9E4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028FA9E8: LDR x1, [x9]               | X1 = "current";                         
            // 0x028FA9EC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028FA9F0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028FA9F4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FA9F8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028FA9FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAA00: LDR x22, [x8, #0x38]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache7;
            val_30 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache7;
            // 0x028FAA04: CBNZ x22, #0x28faa48       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache7 != null) goto label_82;
            if(val_30 != null)
            {
                goto label_82;
            }
            // 0x028FAA08: ADRP x8, #0x35cf000        | X8 = 56422400 (0x35CF000);              
            // 0x028FAA0C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028FAA10: LDR x8, [x8, #0x828]       | X8 = 1152921510030075168;               
            // 0x028FAA14: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028FAA18: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_current_0(ref object o);
            // 0x028FAA1C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028FAA20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028FAA24: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_current_0(ref object o);
            // 0x028FAA28: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_current_0(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_current_0(ref object o);
            // 0x028FAA2C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_current_0(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_current_0(ref object o);
            // 0x028FAA30: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAA34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAA38: STR x0, [x8, #0x38]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache7 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782516280
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache7 = null;
            // 0x028FAA3C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAA40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAA44: LDR x22, [x8, #0x38]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_30 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache7;
            label_82:
            // 0x028FAA48: CBNZ x19, #0x28faa50       | if (X1 != 0) goto label_83;             
            if(X1 != 0)
            {
                goto label_83;
            }
            // 0x028FAA4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_83:
            // 0x028FAA50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAA54: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FAA58: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028FAA5C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_30);
            // 0x028FAA60: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAA64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAA68: LDR x22, [x8, #0x40]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache8;
            val_31 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache8;
            // 0x028FAA6C: CBNZ x22, #0x28faab0       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache8 != null) goto label_84;
            if(val_31 != null)
            {
                goto label_84;
            }
            // 0x028FAA70: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x028FAA74: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028FAA78: LDR x8, [x8, #0xd8]        | X8 = 1152921510030076192;               
            // 0x028FAA7C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028FAA80: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_current_0(ref object o, object v);
            // 0x028FAA84: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028FAA88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028FAA8C: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_current_0(ref object o, object v);
            // 0x028FAA90: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_current_0(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_current_0(ref object o, object v);
            // 0x028FAA94: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_current_0(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_current_0(ref object o, object v);
            // 0x028FAA98: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAA9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAAA0: STR x0, [x8, #0x40]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache8 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782516288
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache8 = null;
            // 0x028FAAA4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAAA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAAAC: LDR x22, [x8, #0x40]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_31 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache8;
            label_84:
            // 0x028FAAB0: CBNZ x19, #0x28faab8       | if (X1 != 0) goto label_85;             
            if(X1 != 0)
            {
                goto label_85;
            }
            // 0x028FAAB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_85:
            // 0x028FAAB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAABC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FAAC0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028FAAC4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_31);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_31);
            // 0x028FAAC8: CBNZ x20, #0x28faad0       | if (val_1 != null) goto label_86;       
            if(val_1 != null)
            {
                goto label_86;
            }
            // 0x028FAACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_86:
            // 0x028FAAD0: ADRP x9, #0x3627000        | X9 = 56782848 (0x3627000);              
            // 0x028FAAD4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028FAAD8: LDR x9, [x9, #0xbf8]       | X9 = (string**)(1152921510030077216)("onFinished");
            // 0x028FAADC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FAAE0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FAAE4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028FAAE8: LDR x1, [x9]               | X1 = "onFinished";                      
            // 0x028FAAEC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028FAAF0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028FAAF4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAAF8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028FAAFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAB00: LDR x22, [x8, #0x48]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache9;
            val_32 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache9;
            // 0x028FAB04: CBNZ x22, #0x28fab48       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache9 != null) goto label_87;
            if(val_32 != null)
            {
                goto label_87;
            }
            // 0x028FAB08: ADRP x8, #0x3643000        | X8 = 56897536 (0x3643000);              
            // 0x028FAB0C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028FAB10: LDR x8, [x8, #0x4c0]       | X8 = 1152921510030077312;               
            // 0x028FAB14: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028FAB18: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_onFinished_1(ref object o);
            // 0x028FAB1C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028FAB20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028FAB24: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_onFinished_1(ref object o);
            // 0x028FAB28: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_onFinished_1(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_onFinished_1(ref object o);
            // 0x028FAB2C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_onFinished_1(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_onFinished_1(ref object o);
            // 0x028FAB30: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAB34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAB38: STR x0, [x8, #0x48]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache9 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782516296
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache9 = null;
            // 0x028FAB3C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAB40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAB44: LDR x22, [x8, #0x48]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_32 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cache9;
            label_87:
            // 0x028FAB48: CBNZ x19, #0x28fab50       | if (X1 != 0) goto label_88;             
            if(X1 != 0)
            {
                goto label_88;
            }
            // 0x028FAB4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_88:
            // 0x028FAB50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAB54: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FAB58: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028FAB5C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_32);
            // 0x028FAB60: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAB64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAB68: LDR x22, [x8, #0x50]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheA;
            val_33 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheA;
            // 0x028FAB6C: CBNZ x22, #0x28fabb0       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheA != null) goto label_89;
            if(val_33 != null)
            {
                goto label_89;
            }
            // 0x028FAB70: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x028FAB74: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028FAB78: LDR x8, [x8, #0xeb0]       | X8 = 1152921510030078336;               
            // 0x028FAB7C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028FAB80: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_onFinished_1(ref object o, object v);
            // 0x028FAB84: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028FAB88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028FAB8C: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_onFinished_1(ref object o, object v);
            // 0x028FAB90: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_onFinished_1(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_onFinished_1(ref object o, object v);
            // 0x028FAB94: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_onFinished_1(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_onFinished_1(ref object o, object v);
            // 0x028FAB98: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAB9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FABA0: STR x0, [x8, #0x50]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheA = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782516304
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheA = null;
            // 0x028FABA4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FABA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FABAC: LDR x22, [x8, #0x50]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_33 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheA;
            label_89:
            // 0x028FABB0: CBNZ x19, #0x28fabb8       | if (X1 != 0) goto label_90;             
            if(X1 != 0)
            {
                goto label_90;
            }
            // 0x028FABB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_90:
            // 0x028FABB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FABBC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FABC0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028FABC4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_33);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_33);
            // 0x028FABC8: CBNZ x20, #0x28fabd0       | if (val_1 != null) goto label_91;       
            if(val_1 != null)
            {
                goto label_91;
            }
            // 0x028FABCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_91:
            // 0x028FABD0: ADRP x9, #0x35d9000        | X9 = 56463360 (0x35D9000);              
            // 0x028FABD4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028FABD8: LDR x9, [x9, #0xac8]       | X9 = (string**)(1152921510030079360)("eventReceiver");
            // 0x028FABDC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FABE0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FABE4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028FABE8: LDR x1, [x9]               | X1 = "eventReceiver";                   
            // 0x028FABEC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028FABF0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028FABF4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FABF8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028FABFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAC00: LDR x22, [x8, #0x58]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheB;
            val_34 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheB;
            // 0x028FAC04: CBNZ x22, #0x28fac48       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheB != null) goto label_92;
            if(val_34 != null)
            {
                goto label_92;
            }
            // 0x028FAC08: ADRP x8, #0x3640000        | X8 = 56885248 (0x3640000);              
            // 0x028FAC0C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028FAC10: LDR x8, [x8, #0x8c8]       | X8 = 1152921510030079456;               
            // 0x028FAC14: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028FAC18: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_eventReceiver_2(ref object o);
            // 0x028FAC1C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028FAC20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028FAC24: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_eventReceiver_2(ref object o);
            // 0x028FAC28: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_eventReceiver_2(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_eventReceiver_2(ref object o);
            // 0x028FAC2C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_eventReceiver_2(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_eventReceiver_2(ref object o);
            // 0x028FAC30: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAC34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAC38: STR x0, [x8, #0x58]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheB = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782516312
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheB = null;
            // 0x028FAC3C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAC40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAC44: LDR x22, [x8, #0x58]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_34 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheB;
            label_92:
            // 0x028FAC48: CBNZ x19, #0x28fac50       | if (X1 != 0) goto label_93;             
            if(X1 != 0)
            {
                goto label_93;
            }
            // 0x028FAC4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_93:
            // 0x028FAC50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAC54: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FAC58: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028FAC5C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_34);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_34);
            // 0x028FAC60: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAC64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAC68: LDR x22, [x8, #0x60]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheC;
            val_35 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheC;
            // 0x028FAC6C: CBNZ x22, #0x28facb0       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheC != null) goto label_94;
            if(val_35 != null)
            {
                goto label_94;
            }
            // 0x028FAC70: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x028FAC74: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028FAC78: LDR x8, [x8, #0x870]       | X8 = 1152921510030080480;               
            // 0x028FAC7C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028FAC80: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_eventReceiver_2(ref object o, object v);
            // 0x028FAC84: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028FAC88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028FAC8C: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_eventReceiver_2(ref object o, object v);
            // 0x028FAC90: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_eventReceiver_2(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_eventReceiver_2(ref object o, object v);
            // 0x028FAC94: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_eventReceiver_2(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_eventReceiver_2(ref object o, object v);
            // 0x028FAC98: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAC9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FACA0: STR x0, [x8, #0x60]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheC = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782516320
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheC = null;
            // 0x028FACA4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FACA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FACAC: LDR x22, [x8, #0x60]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_35 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheC;
            label_94:
            // 0x028FACB0: CBNZ x19, #0x28facb8       | if (X1 != 0) goto label_95;             
            if(X1 != 0)
            {
                goto label_95;
            }
            // 0x028FACB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_95:
            // 0x028FACB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FACBC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FACC0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028FACC4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_35);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_35);
            // 0x028FACC8: CBNZ x20, #0x28facd0       | if (val_1 != null) goto label_96;       
            if(val_1 != null)
            {
                goto label_96;
            }
            // 0x028FACCC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_96:
            // 0x028FACD0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028FACD4: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x028FACD8: LDR x9, [x9, #0x908]       | X9 = (string**)(1152921510030081504)("callWhenFinished");
            // 0x028FACDC: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028FACE0: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FACE4: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x028FACE8: LDR x1, [x9]               | X1 = "callWhenFinished";                
            // 0x028FACEC: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x028FACF0: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x028FACF4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FACF8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x028FACFC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAD00: LDR x22, [x8, #0x68]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheD;
            val_36 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheD;
            // 0x028FAD04: CBNZ x22, #0x28fad48       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheD != null) goto label_97;
            if(val_36 != null)
            {
                goto label_97;
            }
            // 0x028FAD08: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x028FAD0C: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x028FAD10: LDR x8, [x8, #0xa00]       | X8 = 1152921510030081616;               
            // 0x028FAD14: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x028FAD18: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_callWhenFinished_3(ref object o);
            // 0x028FAD1C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            // 0x028FAD20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x028FAD24: LDR x8, [x22]              | X8 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_callWhenFinished_3(ref object o);
            // 0x028FAD28: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_callWhenFinished_3(ref object o);  //  dest_result_addr=1152921504823992352 |  dest_result_addr=1152921504823992360
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_callWhenFinished_3(ref object o);
            // 0x028FAD2C: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_callWhenFinished_3(ref object o);  //  dest_result_addr=1152921504823992336
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::get_callWhenFinished_3(ref object o);
            // 0x028FAD30: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAD34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAD38: STR x0, [x8, #0x68]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheD = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782516328
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheD = null;
            // 0x028FAD3C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAD40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAD44: LDR x22, [x8, #0x68]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_36 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheD;
            label_97:
            // 0x028FAD48: CBNZ x19, #0x28fad50       | if (X1 != 0) goto label_98;             
            if(X1 != 0)
            {
                goto label_98;
            }
            // 0x028FAD4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            label_98:
            // 0x028FAD50: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAD54: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FAD58: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x028FAD5C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_36);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_36);
            // 0x028FAD60: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAD64: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAD68: LDR x22, [x8, #0x70]       | X22 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheE;
            val_37 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheE;
            // 0x028FAD6C: CBNZ x22, #0x28fadb0       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheE != null) goto label_99;
            if(val_37 != null)
            {
                goto label_99;
            }
            // 0x028FAD70: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x028FAD74: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x028FAD78: LDR x8, [x8, #0xf70]       | X8 = 1152921510030082640;               
            // 0x028FAD7C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x028FAD80: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_callWhenFinished_3(ref object o, object v);
            // 0x028FAD84: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            // 0x028FAD88: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x028FAD8C: LDR x8, [x22]              | X8 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_callWhenFinished_3(ref object o, object v);
            // 0x028FAD90: STP xzr, x22, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_callWhenFinished_3(ref object o, object v);  //  dest_result_addr=1152921504824045600 |  dest_result_addr=1152921504824045608
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_28 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_callWhenFinished_3(ref object o, object v);
            // 0x028FAD94: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_callWhenFinished_3(ref object o, object v);  //  dest_result_addr=1152921504824045584
            typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate).__il2cppRuntimeField_10 = static System.Void ILRuntime.Runtime.Generated.ActiveAnimation_Binding::set_callWhenFinished_3(ref object o, object v);
            // 0x028FAD98: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAD9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FADA0: STR x0, [x8, #0x70]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheE = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782516336
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheE = null;
            // 0x028FADA4: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FADA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FADAC: LDR x22, [x8, #0x70]       | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_37 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheE;
            label_99:
            // 0x028FADB0: CBNZ x19, #0x28fadb8       | if (X1 != 0) goto label_100;            
            if(X1 != 0)
            {
                goto label_100;
            }
            // 0x028FADB4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            label_100:
            // 0x028FADB8: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FADBC: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x028FADC0: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x028FADC4: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_37);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_37);
            // 0x028FADC8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FADCC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FADD0: LDR x21, [x8, #0x80]       | X21 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache0;
            val_38 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache0;
            // 0x028FADD4: CBNZ x21, #0x28fae18       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache0 != null) goto label_101;
            if(val_38 != null)
            {
                goto label_101;
            }
            // 0x028FADD8: ADRP x8, #0x35ff000        | X8 = 56619008 (0x35FF000);              
            // 0x028FADDC: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x028FADE0: LDR x8, [x8, #0xa50]       | X8 = 1152921510030083664;               
            // 0x028FADE4: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x028FADE8: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__0();
            // 0x028FADEC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            // 0x028FADF0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x028FADF4: LDR x8, [x21]              | X8 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__0();
            // 0x028FADF8: STP xzr, x21, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__0();  //  dest_result_addr=1152921504824152096 |  dest_result_addr=1152921504824152104
            typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__0();
            // 0x028FADFC: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__0();  //  dest_result_addr=1152921504824152080
            typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__0();
            // 0x028FAE00: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAE04: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAE08: STR x0, [x8, #0x80]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504782516352
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache0 = null;
            // 0x028FAE0C: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAE10: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAE14: LDR x21, [x8, #0x80]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_38 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache0;
            label_101:
            // 0x028FAE18: CBNZ x19, #0x28fae20       | if (X1 != 0) goto label_102;            
            if(X1 != 0)
            {
                goto label_102;
            }
            // 0x028FAE1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            label_102:
            // 0x028FAE20: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAE24: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028FAE28: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x028FAE2C: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_38);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_38);
            // 0x028FAE30: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAE34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAE38: LDR x21, [x8, #0x88]       | X21 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache1;
            val_39 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache1;
            // 0x028FAE3C: CBNZ x21, #0x28fae80       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache1 != null) goto label_103;
            if(val_39 != null)
            {
                goto label_103;
            }
            // 0x028FAE40: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x028FAE44: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x028FAE48: LDR x8, [x8, #0x7d8]       | X8 = 1152921510030084688;               
            // 0x028FAE4C: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x028FAE50: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__1(int s);
            // 0x028FAE54: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            // 0x028FAE58: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x028FAE5C: LDR x8, [x21]              | X8 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__1(int s);
            // 0x028FAE60: STP xzr, x21, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__1(int s);  //  dest_result_addr=1152921504824205344 |  dest_result_addr=1152921504824205352
            typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate).__il2cppRuntimeField_28 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__1(int s);
            // 0x028FAE64: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__1(int s);  //  dest_result_addr=1152921504824205328
            typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate).__il2cppRuntimeField_10 = static System.Object ILRuntime.Runtime.Generated.ActiveAnimation_Binding::<Register>m__1(int s);
            // 0x028FAE68: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAE6C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAE70: STR x0, [x8, #0x88]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504782516360
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache1 = null;
            // 0x028FAE74: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAE78: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAE7C: LDR x21, [x8, #0x88]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_39 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__am$cache1;
            label_103:
            // 0x028FAE80: CBNZ x19, #0x28fae88       | if (X1 != 0) goto label_104;            
            if(X1 != 0)
            {
                goto label_104;
            }
            // 0x028FAE84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            label_104:
            // 0x028FAE88: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAE8C: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x028FAE90: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x028FAE94: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_39);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_39);
            // 0x028FAE98: LDR x21, [x26]             | X21 = typeof(System.Type[]);            
            // 0x028FAE9C: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FAEA0: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x028FAEA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FAEA8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FAEAC: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x028FAEB0: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FAEB4: CBNZ x20, #0x28faebc       | if (val_1 != null) goto label_105;      
            if(val_1 != null)
            {
                goto label_105;
            }
            // 0x028FAEB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_105:
            // 0x028FAEBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FAEC0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FAEC4: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x028FAEC8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x028FAECC: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x028FAED0: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FAED4: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_24 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x028FAED8: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAEDC: MOV x20, x0                | X20 = val_24;//m1                       
            // 0x028FAEE0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAEE4: LDR x21, [x8, #0x78]       | X21 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheF;
            val_40 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheF;
            // 0x028FAEE8: CBNZ x21, #0x28faf2c       | if (ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheF != null) goto label_106;
            if(val_40 != null)
            {
                goto label_106;
            }
            // 0x028FAEEC: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x028FAEF0: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x028FAEF4: LDR x8, [x8, #0x890]       | X8 = 1152921510030089808;               
            // 0x028FAEF8: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x028FAEFC: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FAF00: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            // 0x028FAF04: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x028FAF08: LDR x8, [x21]              | X8 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FAF0C: STP xzr, x21, [x0, #0x20]  | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0x0;  typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939104 |  dest_result_addr=1152921504823939112
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_20 = 0;
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_28 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FAF10: STR x8, [x0, #0x10]        | typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);  //  dest_result_addr=1152921504823939088
            typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate).__il2cppRuntimeField_10 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.ActiveAnimation_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x028FAF14: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAF18: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAF1C: STR x0, [x8, #0x78]        | ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheF = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782516344
            ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheF = null;
            // 0x028FAF20: LDR x8, [x23]              | X8 = typeof(ILRuntime.Runtime.Generated.ActiveAnimation_Binding);
            // 0x028FAF24: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.__il2cppRuntimeField_static_fields;
            // 0x028FAF28: LDR x21, [x8, #0x78]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_40 = ILRuntime.Runtime.Generated.ActiveAnimation_Binding.<>f__mg$cacheF;
            label_106:
            // 0x028FAF2C: CBNZ x19, #0x28faf34       | if (X1 != 0) goto label_107;            
            if(X1 != 0)
            {
                goto label_107;
            }
            // 0x028FAF30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            label_107:
            // 0x028FAF34: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FAF38: MOV x1, x20                | X1 = val_24;//m1                        
            // 0x028FAF3C: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x028FAF40: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028FAF44: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028FAF48: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028FAF4C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028FAF50: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028FAF54: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028FAF58: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_40); return;
            X1.RegisterCLRMethodRedirection(mi:  val_24, func:  val_40);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FAF5C (42970972), len: 612  VirtAddr: 0x028FAF5C RVA: 0x028FAF5C token: 100663667 methodIndex: 29712 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* get_isPlaying_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_13;
            //  | 
            bool val_14;
            //  | 
            var val_15;
            // 0x028FAF5C: STP x26, x25, [sp, #-0x50]! | stack[1152921510030345824] = ???;  stack[1152921510030345832] = ???;  //  dest_result_addr=1152921510030345824 |  dest_result_addr=1152921510030345832
            // 0x028FAF60: STP x24, x23, [sp, #0x10]  | stack[1152921510030345840] = ???;  stack[1152921510030345848] = ???;  //  dest_result_addr=1152921510030345840 |  dest_result_addr=1152921510030345848
            // 0x028FAF64: STP x22, x21, [sp, #0x20]  | stack[1152921510030345856] = ???;  stack[1152921510030345864] = ???;  //  dest_result_addr=1152921510030345856 |  dest_result_addr=1152921510030345864
            // 0x028FAF68: STP x20, x19, [sp, #0x30]  | stack[1152921510030345872] = ???;  stack[1152921510030345880] = ???;  //  dest_result_addr=1152921510030345872 |  dest_result_addr=1152921510030345880
            // 0x028FAF6C: STP x29, x30, [sp, #0x40]  | stack[1152921510030345888] = ???;  stack[1152921510030345896] = ???;  //  dest_result_addr=1152921510030345888 |  dest_result_addr=1152921510030345896
            // 0x028FAF70: ADD x29, sp, #0x40         | X29 = (1152921510030345824 + 64) = 1152921510030345888 (0x10000001434406A0);
            // 0x028FAF74: SUB sp, sp, #0x10          | SP = (1152921510030345824 - 16) = 1152921510030345808 (0x1000000143440650);
            // 0x028FAF78: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028FAF7C: LDRB w8, [x19, #0xa64]     | W8 = (bool)static_value_037B8A64;       
            // 0x028FAF80: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028FAF84: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028FAF88: MOV x20, x1                | X20 = X1;//m1                           
            // 0x028FAF8C: TBNZ w8, #0, #0x28fafa8    | if (static_value_037B8A64 == true) goto label_0;
            // 0x028FAF90: ADRP x8, #0x3627000        | X8 = 56782848 (0x3627000);              
            // 0x028FAF94: LDR x8, [x8, #0x760]       | X8 = 0x2B8A95C;                         
            // 0x028FAF98: LDR w0, [x8]               | W0 = 0x115;                             
            // 0x028FAF9C: BL #0x2782188              | X0 = sub_2782188( ?? 0x115, ????);      
            // 0x028FAFA0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FAFA4: STRB w8, [x19, #0xa64]     | static_value_037B8A64 = true;            //  dest_result_addr=58428004
            label_0:
            // 0x028FAFA8: CBNZ x20, #0x28fafb0       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028FAFAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x115, ????);      
            label_1:
            // 0x028FAFB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FAFB4: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028FAFB8: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028FAFBC: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FAFC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FAFC4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FAFC8: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FAFCC: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028FAFD0: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FAFD4: MOV x19, x0                | X19 = val_2;//m1                        
            // 0x028FAFD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FAFDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FAFE0: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FAFE4: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028FAFE8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FAFEC: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FAFF0: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FAFF4: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x028FAFF8: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028FAFFC: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FB000: LDR x9, [x9, #0xed8]       | X9 = 1152921504875483136;               
            // 0x028FB004: LDR x24, [x9]              | X24 = typeof(ActiveAnimation);          
            // 0x028FB008: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FB00C: TBZ w9, #0, #0x28fb020     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FB010: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FB014: CBNZ w9, #0x28fb020        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FB018: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FB01C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FB020: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB024: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB028: MOV x1, x24                | X1 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FB02C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB030: ADRP x25, #0x366f000       | X25 = 57077760 (0x366F000);             
            // 0x028FB034: LDR x25, [x25, #0x7a0]     | X25 = 1152921504826228736;              
            // 0x028FB038: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FB03C: LDR x8, [x25]              | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FB040: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FB044: TBZ w9, #0, #0x28fb058     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FB048: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FB04C: CBNZ w9, #0x28fb058        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FB050: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FB054: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FB058: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB05C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB060: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FB064: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB068: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028FB06C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028FB070: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FB074: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FB078: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028FB07C: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FB080: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FB084: TBZ w9, #0, #0x28fb098     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FB088: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FB08C: CBNZ w9, #0x28fb098        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FB090: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FB094: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FB098: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB09C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB0A0: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FB0A4: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028FB0A8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FB0AC: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            // 0x028FB0B0: CBZ x0, #0x28fb114         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028FB0B4: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028FB0B8: LDR x9, [x9, #0x698]       | X9 = 1152921504875483136;               
            // 0x028FB0BC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FB0C0: LDR x1, [x9]               | X1 = typeof(ActiveAnimation);           
            // 0x028FB0C4: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FB0C8: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FB0CC: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FB0D0: B.LO #0x28fb0ec            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028FB0D4: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028FB0D8: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeH
            // 0x028FB0DC: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FB0E0: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FB0E4: MOV x22, x0                | X22 = val_6;//m1                        
            val_13 = val_6;
            // 0x028FB0E8: B.EQ #0x28fb114            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028FB0EC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB0F0: ADD x8, sp, #8             | X8 = (1152921510030345808 + 8) = 1152921510030345816 (0x1000000143440658);
            // 0x028FB0F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FB0F8: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510030333904]
            // 0x028FB0FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028FB100: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB104: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028FB108: ADD x0, sp, #8             | X0 = (1152921510030345808 + 8) = 1152921510030345816 (0x1000000143440658);
            // 0x028FB10C: BL #0x299a140              | 
            // 0x028FB110: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_13 = 0;
            label_10:
            // 0x028FB114: CBNZ x20, #0x28fb11c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028FB118: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143440658, ????);
            label_11:
            // 0x028FB11C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB120: MOV x0, x20                | X0 = X1;//m1                            
            // 0x028FB124: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FB128: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028FB12C: CBNZ x22, #0x28fb134       | if (0x0 != 0) goto label_12;            
            if(val_13 != 0)
            {
                goto label_12;
            }
            // 0x028FB130: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028FB134: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB138: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028FB13C: BL #0xb1c65c               | X0 = val_13.get_isPlaying();            
            bool val_9 = val_13.isPlaying;
            // 0x028FB140: MOV w20, w0                | W20 = val_9;//m1                        
            // 0x028FB144: CBZ x19, #0x28fb158        | if (val_2 == 0) goto label_13;          
            if(val_2 == 0)
            {
                goto label_13;
            }
            // 0x028FB148: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FB14C: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028FB150: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028FB154: B #0x28fb16c               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x028FB158: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            // 0x028FB15C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FB160: STR w8, [x19]              | mem2[0] = 0x1;                           //  dest_result_addr=0
            mem2[0] = 1;
            // 0x028FB164: AND w20, w20, #1           | W20 = (val_9 & 1);                      
            val_14 = val_9;
            // 0x028FB168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9, ????);      
            label_14:
            // 0x028FB16C: STR w20, [x19, #4]         | mem2[0] = (val_9 & 1);                   //  dest_result_addr=0
            mem2[0] = val_14;
            // 0x028FB170: LDR x0, [x25]              | X0 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FB174: ORR w8, wzr, #8            | W8 = 8(0x8);                            
            val_15 = 8;
            // 0x028FB178: LDRB w9, [x0, #0x109]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_109;
            // 0x028FB17C: TBZ w9, #0, #0x28fb18c     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_valuetype == 0) goto label_15;
            // 0x028FB180: BL #0x277468c              | X0 = sub_277468C( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            // 0x028FB184: SUB w8, w0, #0x10          | W8 = (null - 16) = 1152921504826228720 (0x100000000D137FF0);
            // 0x028FB188: SXTW x8, w8                | X8 = 219381744 (0x0D137FF0);            
            val_15 = 219381744;
            label_15:
            // 0x028FB18C: ADD x0, x8, x19            | X0 = (val_15 + val_2);                  
            ILRuntime.Runtime.Stack.StackObject* val_10 = val_15 + val_2;
            // 0x028FB190: SUB sp, x29, #0x40         | SP = (1152921510030345888 - 64) = 1152921510030345824 (0x1000000143440660);
            // 0x028FB194: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028FB198: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028FB19C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028FB1A0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028FB1A4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028FB1A8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)(val_15 + val_2);
            return val_10;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028FB1AC: MOV x19, x0                | 
            // 0x028FB1B0: ADD x0, sp, #8             | 
            // 0x028FB1B4: BL #0x299a140              | 
            // 0x028FB1B8: MOV x0, x19                | 
            // 0x028FB1BC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FB1C0 (42971584), len: 528  VirtAddr: 0x028FB1C0 RVA: 0x028FB1C0 token: 100663668 methodIndex: 29713 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Finish_1(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028FB1C0: STP x24, x23, [sp, #-0x40]! | stack[1152921510030515184] = ???;  stack[1152921510030515192] = ???;  //  dest_result_addr=1152921510030515184 |  dest_result_addr=1152921510030515192
            // 0x028FB1C4: STP x22, x21, [sp, #0x10]  | stack[1152921510030515200] = ???;  stack[1152921510030515208] = ???;  //  dest_result_addr=1152921510030515200 |  dest_result_addr=1152921510030515208
            // 0x028FB1C8: STP x20, x19, [sp, #0x20]  | stack[1152921510030515216] = ???;  stack[1152921510030515224] = ???;  //  dest_result_addr=1152921510030515216 |  dest_result_addr=1152921510030515224
            // 0x028FB1CC: STP x29, x30, [sp, #0x30]  | stack[1152921510030515232] = ???;  stack[1152921510030515240] = ???;  //  dest_result_addr=1152921510030515232 |  dest_result_addr=1152921510030515240
            // 0x028FB1D0: ADD x29, sp, #0x30         | X29 = (1152921510030515184 + 48) = 1152921510030515232 (0x1000000143469C20);
            // 0x028FB1D4: SUB sp, sp, #0x10          | SP = (1152921510030515184 - 16) = 1152921510030515168 (0x1000000143469BE0);
            // 0x028FB1D8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FB1DC: LDRB w8, [x20, #0xa65]     | W8 = (bool)static_value_037B8A65;       
            // 0x028FB1E0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028FB1E4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028FB1E8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028FB1EC: TBNZ w8, #0, #0x28fb208    | if (static_value_037B8A65 == true) goto label_0;
            // 0x028FB1F0: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028FB1F4: LDR x8, [x8, #0x4e0]       | X8 = 0x2B8A94C;                         
            // 0x028FB1F8: LDR w0, [x8]               | W0 = 0x111;                             
            // 0x028FB1FC: BL #0x2782188              | X0 = sub_2782188( ?? 0x111, ????);      
            // 0x028FB200: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FB204: STRB w8, [x20, #0xa65]     | static_value_037B8A65 = true;            //  dest_result_addr=58428005
            label_0:
            // 0x028FB208: CBNZ x19, #0x28fb210       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028FB20C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x111, ????);      
            label_1:
            // 0x028FB210: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB214: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FB218: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028FB21C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FB220: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB224: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB228: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FB22C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028FB230: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB234: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FB238: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB23C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB240: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FB244: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028FB248: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB24C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FB250: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FB254: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x028FB258: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028FB25C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FB260: LDR x9, [x9, #0xed8]       | X9 = 1152921504875483136;               
            // 0x028FB264: LDR x24, [x9]              | X24 = typeof(ActiveAnimation);          
            // 0x028FB268: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FB26C: TBZ w9, #0, #0x28fb280     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FB270: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FB274: CBNZ w9, #0x28fb280        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FB278: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FB27C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FB280: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB284: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB288: MOV x1, x24                | X1 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FB28C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB290: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028FB294: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028FB298: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FB29C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FB2A0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FB2A4: TBZ w9, #0, #0x28fb2b8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FB2A8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FB2AC: CBNZ w9, #0x28fb2b8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FB2B0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FB2B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FB2B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB2BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB2C0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FB2C4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB2C8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028FB2CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028FB2D0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FB2D4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FB2D8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028FB2DC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FB2E0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FB2E4: TBZ w9, #0, #0x28fb2f8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FB2E8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FB2EC: CBNZ w9, #0x28fb2f8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FB2F0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FB2F4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FB2F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB2FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB300: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FB304: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028FB308: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FB30C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028FB310: CBZ x0, #0x28fb374         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028FB314: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028FB318: LDR x9, [x9, #0x698]       | X9 = 1152921504875483136;               
            // 0x028FB31C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FB320: LDR x1, [x9]               | X1 = typeof(ActiveAnimation);           
            // 0x028FB324: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FB328: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FB32C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FB330: B.LO #0x28fb34c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028FB334: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028FB338: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeH
            // 0x028FB33C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FB340: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FB344: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x028FB348: B.EQ #0x28fb374            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028FB34C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB350: ADD x8, sp, #8             | X8 = (1152921510030515168 + 8) = 1152921510030515176 (0x1000000143469BE8);
            // 0x028FB354: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FB358: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510030503248]
            // 0x028FB35C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028FB360: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB364: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028FB368: ADD x0, sp, #8             | X0 = (1152921510030515168 + 8) = 1152921510030515176 (0x1000000143469BE8);
            // 0x028FB36C: BL #0x299a140              | 
            // 0x028FB370: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x028FB374: CBNZ x19, #0x28fb37c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028FB378: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143469BE8, ????);
            label_11:
            // 0x028FB37C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB380: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FB384: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FB388: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028FB38C: CBNZ x22, #0x28fb394       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x028FB390: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028FB394: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB398: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028FB39C: BL #0xb1ca68               | val_9.Finish();                         
            val_9.Finish();
            // 0x028FB3A0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028FB3A4: SUB sp, x29, #0x30         | SP = (1152921510030515232 - 48) = 1152921510030515184 (0x1000000143469BF0);
            // 0x028FB3A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028FB3AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028FB3B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028FB3B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028FB3B8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028FB3BC: MOV x19, x0                | 
            // 0x028FB3C0: ADD x0, sp, #8             | 
            // 0x028FB3C4: BL #0x299a140              | 
            // 0x028FB3C8: MOV x0, x19                | 
            // 0x028FB3CC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FB3D0 (42972112), len: 528  VirtAddr: 0x028FB3D0 RVA: 0x028FB3D0 token: 100663669 methodIndex: 29714 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Reset_2(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028FB3D0: STP x24, x23, [sp, #-0x40]! | stack[1152921510030684528] = ???;  stack[1152921510030684536] = ???;  //  dest_result_addr=1152921510030684528 |  dest_result_addr=1152921510030684536
            // 0x028FB3D4: STP x22, x21, [sp, #0x10]  | stack[1152921510030684544] = ???;  stack[1152921510030684552] = ???;  //  dest_result_addr=1152921510030684544 |  dest_result_addr=1152921510030684552
            // 0x028FB3D8: STP x20, x19, [sp, #0x20]  | stack[1152921510030684560] = ???;  stack[1152921510030684568] = ???;  //  dest_result_addr=1152921510030684560 |  dest_result_addr=1152921510030684568
            // 0x028FB3DC: STP x29, x30, [sp, #0x30]  | stack[1152921510030684576] = ???;  stack[1152921510030684584] = ???;  //  dest_result_addr=1152921510030684576 |  dest_result_addr=1152921510030684584
            // 0x028FB3E0: ADD x29, sp, #0x30         | X29 = (1152921510030684528 + 48) = 1152921510030684576 (0x10000001434931A0);
            // 0x028FB3E4: SUB sp, sp, #0x10          | SP = (1152921510030684528 - 16) = 1152921510030684512 (0x1000000143493160);
            // 0x028FB3E8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FB3EC: LDRB w8, [x20, #0xa66]     | W8 = (bool)static_value_037B8A66;       
            // 0x028FB3F0: MOV x22, x3                | X22 = X3;//m1                           
            // 0x028FB3F4: MOV x21, x2                | X21 = X2;//m1                           
            // 0x028FB3F8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028FB3FC: TBNZ w8, #0, #0x28fb418    | if (static_value_037B8A66 == true) goto label_0;
            // 0x028FB400: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
            // 0x028FB404: LDR x8, [x8, #0x678]       | X8 = 0x2B8A978;                         
            // 0x028FB408: LDR w0, [x8]               | W0 = 0x11C;                             
            // 0x028FB40C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C, ????);      
            // 0x028FB410: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FB414: STRB w8, [x20, #0xa66]     | static_value_037B8A66 = true;            //  dest_result_addr=58428006
            label_0:
            // 0x028FB418: CBNZ x19, #0x28fb420       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028FB41C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11C, ????);      
            label_1:
            // 0x028FB420: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB424: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FB428: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028FB42C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FB430: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB434: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB438: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FB43C: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028FB440: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB444: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FB448: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB44C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB450: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FB454: MOV x1, x21                | X1 = X2;//m1                            
            // 0x028FB458: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB45C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FB460: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FB464: ADRP x9, #0x3633000        | X9 = 56832000 (0x3633000);              
            // 0x028FB468: MOV x21, x0                | X21 = val_3;//m1                        
            // 0x028FB46C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FB470: LDR x9, [x9, #0xed8]       | X9 = 1152921504875483136;               
            // 0x028FB474: LDR x24, [x9]              | X24 = typeof(ActiveAnimation);          
            // 0x028FB478: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FB47C: TBZ w9, #0, #0x28fb490     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FB480: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FB484: CBNZ w9, #0x28fb490        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FB488: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FB48C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FB490: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB494: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB498: MOV x1, x24                | X1 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FB49C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB4A0: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028FB4A4: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028FB4A8: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FB4AC: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FB4B0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FB4B4: TBZ w9, #0, #0x28fb4c8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FB4B8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FB4BC: CBNZ w9, #0x28fb4c8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FB4C0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FB4C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FB4C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB4CC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB4D0: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FB4D4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB4D8: MOV x3, x22                | X3 = X3;//m1                            
            // 0x028FB4DC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  ???);
            // 0x028FB4E0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FB4E4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FB4E8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x028FB4EC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FB4F0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FB4F4: TBZ w9, #0, #0x28fb508     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FB4F8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FB4FC: CBNZ w9, #0x28fb508        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FB500: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FB504: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FB508: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB50C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB510: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FB514: MOV x2, x22                | X2 = val_5;//m1                         
            // 0x028FB518: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FB51C: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x028FB520: CBZ x0, #0x28fb584         | if (val_6 == null) goto label_10;       
            if(val_6 == null)
            {
                goto label_10;
            }
            // 0x028FB524: ADRP x9, #0x3676000        | X9 = 57106432 (0x3676000);              
            // 0x028FB528: LDR x9, [x9, #0x698]       | X9 = 1152921504875483136;               
            // 0x028FB52C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FB530: LDR x1, [x9]               | X1 = typeof(ActiveAnimation);           
            // 0x028FB534: LDRB w10, [x8, #0x104]     | W10 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FB538: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FB53C: CMP w10, w9                | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FB540: B.LO #0x28fb55c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_9;
            // 0x028FB544: LDR x10, [x8, #0xb0]       | X10 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x028FB548: ADD x9, x10, x9, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeH
            // 0x028FB54C: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FB550: CMP x9, x1                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FB554: MOV x22, x0                | X22 = val_6;//m1                        
            val_9 = val_6;
            // 0x028FB558: B.EQ #0x28fb584            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_10;
            label_9:
            // 0x028FB55C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB560: ADD x8, sp, #8             | X8 = (1152921510030684512 + 8) = 1152921510030684520 (0x1000000143493168);
            // 0x028FB564: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FB568: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921510030672592]
            // 0x028FB56C: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x028FB570: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB574: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x028FB578: ADD x0, sp, #8             | X0 = (1152921510030684512 + 8) = 1152921510030684520 (0x1000000143493168);
            // 0x028FB57C: BL #0x299a140              | 
            // 0x028FB580: MOV x22, xzr               | X22 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_10:
            // 0x028FB584: CBNZ x19, #0x28fb58c       | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x028FB588: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143493168, ????);
            label_11:
            // 0x028FB58C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB590: MOV x0, x19                | X0 = X1;//m1                            
            // 0x028FB594: MOV x1, x21                | X1 = val_3;//m1                         
            // 0x028FB598: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            X1.Free(esp:  null);
            // 0x028FB59C: CBNZ x22, #0x28fb5a4       | if (0x0 != 0) goto label_12;            
            if(val_9 != 0)
            {
                goto label_12;
            }
            // 0x028FB5A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_12:
            // 0x028FB5A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB5A8: MOV x0, x22                | X0 = 0 (0x0);//ML01                     
            // 0x028FB5AC: BL #0xb1ce2c               | val_9.Reset();                          
            val_9.Reset();
            // 0x028FB5B0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x028FB5B4: SUB sp, x29, #0x30         | SP = (1152921510030684576 - 48) = 1152921510030684528 (0x1000000143493170);
            // 0x028FB5B8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028FB5BC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028FB5C0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028FB5C4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028FB5C8: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            return (ILRuntime.Runtime.Stack.StackObject*)val_2;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            // 0x028FB5CC: MOV x19, x0                | 
            // 0x028FB5D0: ADD x0, sp, #8             | 
            // 0x028FB5D4: BL #0x299a140              | 
            // 0x028FB5D8: MOV x0, x19                | 
            // 0x028FB5DC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FB5E0 (42972640), len: 1756  VirtAddr: 0x028FB5E0 RVA: 0x028FB5E0 token: 100663670 methodIndex: 29715 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_3(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_19;
            //  | 
            var val_24;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            AnimationOrTween.Direction val_36;
            //  | 
            string val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            // 0x028FB5E0: STP x28, x27, [sp, #-0x60]! | stack[1152921510030907088] = ???;  stack[1152921510030907096] = ???;  //  dest_result_addr=1152921510030907088 |  dest_result_addr=1152921510030907096
            // 0x028FB5E4: STP x26, x25, [sp, #0x10]  | stack[1152921510030907104] = ???;  stack[1152921510030907112] = ???;  //  dest_result_addr=1152921510030907104 |  dest_result_addr=1152921510030907112
            // 0x028FB5E8: STP x24, x23, [sp, #0x20]  | stack[1152921510030907120] = ???;  stack[1152921510030907128] = ???;  //  dest_result_addr=1152921510030907120 |  dest_result_addr=1152921510030907128
            // 0x028FB5EC: STP x22, x21, [sp, #0x30]  | stack[1152921510030907136] = ???;  stack[1152921510030907144] = ???;  //  dest_result_addr=1152921510030907136 |  dest_result_addr=1152921510030907144
            // 0x028FB5F0: STP x20, x19, [sp, #0x40]  | stack[1152921510030907152] = ???;  stack[1152921510030907160] = ???;  //  dest_result_addr=1152921510030907152 |  dest_result_addr=1152921510030907160
            // 0x028FB5F4: STP x29, x30, [sp, #0x50]  | stack[1152921510030907168] = ???;  stack[1152921510030907176] = ???;  //  dest_result_addr=1152921510030907168 |  dest_result_addr=1152921510030907176
            // 0x028FB5F8: ADD x29, sp, #0x50         | X29 = (1152921510030907088 + 80) = 1152921510030907168 (0x10000001434C9720);
            // 0x028FB5FC: SUB sp, sp, #0x40          | SP = (1152921510030907088 - 64) = 1152921510030907024 (0x10000001434C9690);
            // 0x028FB600: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FB604: LDRB w8, [x20, #0xa67]     | W8 = (bool)static_value_037B8A67;       
            // 0x028FB608: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028FB60C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028FB610: MOV x21, x1                | X21 = X1;//m1                           
            val_33 = X1;
            // 0x028FB614: TBNZ w8, #0, #0x28fb630    | if (static_value_037B8A67 == true) goto label_0;
            // 0x028FB618: ADRP x8, #0x35dc000        | X8 = 56475648 (0x35DC000);              
            // 0x028FB61C: LDR x8, [x8, #0x9f8]       | X8 = 0x2B8A964;                         
            // 0x028FB620: LDR w0, [x8]               | W0 = 0x117;                             
            // 0x028FB624: BL #0x2782188              | X0 = sub_2782188( ?? 0x117, ????);      
            // 0x028FB628: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FB62C: STRB w8, [x20, #0xa67]     | static_value_037B8A67 = true;            //  dest_result_addr=58428007
            label_0:
            // 0x028FB630: CBNZ x21, #0x28fb638       | if (X1 != 0) goto label_1;              
            if(val_33 != 0)
            {
                goto label_1;
            }
            // 0x028FB634: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x117, ????);      
            label_1:
            // 0x028FB638: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB63C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FB640: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_33.AppDomain;
            // 0x028FB644: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FB648: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB64C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB650: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x028FB654: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FB658: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB65C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FB660: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB664: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB668: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FB66C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FB670: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB674: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FB678: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FB67C: ADRP x9, #0x35bc000        | X9 = 56344576 (0x35BC000);              
            // 0x028FB680: MOV x25, x0                | X25 = val_3;//m1                        
            val_34 = val_3;
            // 0x028FB684: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FB688: LDR x9, [x9, #0x138]       | X9 = 1152921504875696128;               
            // 0x028FB68C: LDR x24, [x9]              | X24 = typeof(AnimationOrTween.DisableCondition);
            // 0x028FB690: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FB694: TBZ w9, #0, #0x28fb6a8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FB698: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FB69C: CBNZ w9, #0x28fb6a8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FB6A0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FB6A4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FB6A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB6AC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB6B0: MOV x1, x24                | X1 = 1152921504875696128 (0x1000000010065000);//ML01
            // 0x028FB6B4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB6B8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028FB6BC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028FB6C0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FB6C4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FB6C8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FB6CC: TBZ w9, #0, #0x28fb6e0     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FB6D0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FB6D4: CBNZ w9, #0x28fb6e0        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FB6D8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FB6DC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FB6E0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB6E4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB6E8: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FB6EC: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB6F0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FB6F4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FB6F8: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FB6FC: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FB700: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028FB704: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FB708: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FB70C: TBZ w9, #0, #0x28fb720     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FB710: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FB714: CBNZ w9, #0x28fb720        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FB718: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FB71C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FB720: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB724: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB728: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FB72C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028FB730: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FB734: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x028FB738: LDR x8, [x8, #0x278]       | X8 = 1152921504875696128;               
            // 0x028FB73C: MOV x26, x0                | X26 = val_6;//m1                        
            val_35 = val_6;
            // 0x028FB740: LDR x24, [x8]              | X24 = typeof(AnimationOrTween.DisableCondition);
            // 0x028FB744: CBNZ x26, #0x28fb74c       | if (val_6 != null) goto label_8;        
            if(val_35 != null)
            {
                goto label_8;
            }
            // 0x028FB748: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x028FB74C: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x028FB750: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB754: LDR x8, [x24, #0x30]       | X8 = AnimationOrTween.DisableCondition.__il2cppRuntimeField_element_class;
            // 0x028FB758: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.DisableCondition.__il2cppRuntimeField_element_class)
            // 0x028FB75C: B.NE #0x28fbbf4            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.DisableCondition.__il2cppRuntimeField_element_class) goto label_9;
            // 0x028FB760: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x028FB764: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_35.System.IDisposable.Dispose();
            // 0x028FB768: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x028FB76C: CBNZ x21, #0x28fb774       | if (X1 != 0) goto label_10;             
            if(val_33 != 0)
            {
                goto label_10;
            }
            // 0x028FB770: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x028FB774: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB778: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FB77C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FB780: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FB784: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB788: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB78C: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028FB790: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FB794: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB798: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x028FB79C: LDR x8, [x8, #0x8f8]       | X8 = 1152921504875642880;               
            // 0x028FB7A0: MOV x26, x0                | X26 = val_7;//m1                        
            val_35 = val_7;
            // 0x028FB7A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB7A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB7AC: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.EnableCondition);
            // 0x028FB7B0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB7B4: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x028FB7B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB7BC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB7C0: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x028FB7C4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB7C8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FB7CC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FB7D0: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x028FB7D4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB7D8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB7DC: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x028FB7E0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x028FB7E4: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028FB7E8: LDR x8, [x8, #0x5f8]       | X8 = 1152921504875642880;               
            // 0x028FB7EC: MOV x27, x0                | X27 = val_10;//m1                       
            // 0x028FB7F0: LDR x25, [x8]              | X25 = typeof(AnimationOrTween.EnableCondition);
            val_34 = null;
            // 0x028FB7F4: CBNZ x27, #0x28fb7fc       | if (val_10 != null) goto label_11;      
            if(val_10 != null)
            {
                goto label_11;
            }
            // 0x028FB7F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_11:
            // 0x028FB7FC: LDR x8, [x27]              | X8 = typeof(System.Object);             
            // 0x028FB800: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB804: LDR x8, [x25, #0x30]       | X8 = AnimationOrTween.EnableCondition.__il2cppRuntimeField_element_class;
            // 0x028FB808: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.EnableCondition.__il2cppRuntimeField_element_class)
            // 0x028FB80C: B.NE #0x28fbc18            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.EnableCondition.__il2cppRuntimeField_element_class) goto label_12;
            // 0x028FB810: MOV x0, x27                | X0 = val_10;//m1                        
            // 0x028FB814: BL #0x27bc4e8              | val_10.System.IDisposable.Dispose();    
            val_10.System.IDisposable.Dispose();
            // 0x028FB818: LDR w25, [x0]              | W25 = typeof(System.Object);            
            // 0x028FB81C: CBNZ x21, #0x28fb824       | if (X1 != 0) goto label_13;             
            if(val_33 != 0)
            {
                goto label_13;
            }
            // 0x028FB820: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_13:
            // 0x028FB824: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB828: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FB82C: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x028FB830: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FB834: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB838: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB83C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028FB840: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FB844: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB848: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x028FB84C: LDR x8, [x8, #0x2c0]       | X8 = 1152921504875589632;               
            // 0x028FB850: MOV x27, x0                | X27 = val_11;//m1                       
            // 0x028FB854: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB858: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB85C: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.Direction);
            // 0x028FB860: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB864: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x028FB868: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB86C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB870: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x028FB874: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB878: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FB87C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_13 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FB880: MOV x2, x0                 | X2 = val_13;//m1                        
            // 0x028FB884: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB888: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB88C: MOV x1, x26                | X1 = val_12;//m1                        
            // 0x028FB890: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            object val_14 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            // 0x028FB894: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028FB898: LDR x8, [x8, #0xed8]       | X8 = 1152921504875589632;               
            // 0x028FB89C: MOV x28, x0                | X28 = val_14;//m1                       
            // 0x028FB8A0: LDR x26, [x8]              | X26 = typeof(AnimationOrTween.Direction);
            val_35 = null;
            // 0x028FB8A4: CBNZ x28, #0x28fb8ac       | if (val_14 != null) goto label_14;      
            if(val_14 != null)
            {
                goto label_14;
            }
            // 0x028FB8A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_14:
            // 0x028FB8AC: LDR x8, [x28]              | X8 = typeof(System.Object);             
            // 0x028FB8B0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB8B4: LDR x8, [x26, #0x30]       | X8 = AnimationOrTween.Direction.__il2cppRuntimeField_element_class;
            // 0x028FB8B8: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.Direction.__il2cppRuntimeField_element_class)
            // 0x028FB8BC: B.NE #0x28fbc3c            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.Direction.__il2cppRuntimeField_element_class) goto label_15;
            // 0x028FB8C0: MOV x0, x28                | X0 = val_14;//m1                        
            // 0x028FB8C4: BL #0x27bc4e8              | val_14.System.IDisposable.Dispose();    
            val_14.System.IDisposable.Dispose();
            // 0x028FB8C8: LDR w26, [x0]              | W26 = typeof(System.Object);            
            // 0x028FB8CC: CBNZ x21, #0x28fb8d4       | if (X1 != 0) goto label_16;             
            if(val_33 != 0)
            {
                goto label_16;
            }
            // 0x028FB8D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_16:
            // 0x028FB8D4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB8D8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FB8DC: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x028FB8E0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FB8E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB8E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB8EC: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x028FB8F0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FB8F4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB8F8: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028FB8FC: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x028FB900: MOV x28, x0                | X28 = val_15;//m1                       
            // 0x028FB904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB908: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB90C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FB910: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB914: MOV x27, x0                | X27 = val_16;//m1                       
            // 0x028FB918: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB91C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB920: MOV x1, x28                | X1 = val_15;//m1                        
            // 0x028FB924: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB928: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FB92C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_17 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FB930: MOV x2, x0                 | X2 = val_17;//m1                        
            // 0x028FB934: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB938: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB93C: MOV x1, x27                | X1 = val_16;//m1                        
            // 0x028FB940: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            object val_18 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            // 0x028FB944: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_36 = 0;
            // 0x028FB948: CBZ x0, #0x28fb990         | if (val_18 == null) goto label_18;      
            if(val_18 == null)
            {
                goto label_18;
            }
            // 0x028FB94C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028FB950: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028FB954: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FB958: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FB95C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x028FB960: MOV x27, x0                | X27 = val_18;//m1                       
            val_36 = val_18;
            // 0x028FB964: B.EQ #0x28fb990            | if (typeof(System.Object) == null) goto label_18;
            if(null == null)
            {
                goto label_18;
            }
            // 0x028FB968: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FB96C: ADD x8, sp, #0x20          | X8 = (1152921510030907024 + 32) = 1152921510030907056 (0x10000001434C96B0);
            // 0x028FB970: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FB974: LDR x0, [sp, #0x20]        | X0 = val_19;                             //  find_add[1152921510030895184]
            // 0x028FB978: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x028FB97C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FB980: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x028FB984: ADD x0, sp, #0x20          | X0 = (1152921510030907024 + 32) = 1152921510030907056 (0x10000001434C96B0);
            // 0x028FB988: BL #0x299a140              | 
            // 0x028FB98C: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_36 = 0;
            label_18:
            // 0x028FB990: CBNZ x21, #0x28fb998       | if (X1 != 0) goto label_19;             
            if(val_33 != 0)
            {
                goto label_19;
            }
            // 0x028FB994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001434C96B0, ????);
            label_19:
            // 0x028FB998: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB99C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FB9A0: MOV x1, x28                | X1 = val_15;//m1                        
            // 0x028FB9A4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FB9A8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB9AC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FB9B0: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x028FB9B4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FB9B8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_20 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FB9BC: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x028FB9C0: LDR x8, [x8, #0x9e8]       | X8 = 1152921504723353600;               
            // 0x028FB9C4: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x028FB9C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB9CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FB9D0: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animation);     
            // 0x028FB9D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_21 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FB9D8: MOV x28, x0                | X28 = val_21;//m1                       
            // 0x028FB9DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB9E0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FB9E4: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x028FB9E8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FB9EC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FB9F0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_22 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FB9F4: MOV x2, x0                 | X2 = val_22;//m1                        
            // 0x028FB9F8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FB9FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBA00: MOV x1, x28                | X1 = val_21;//m1                        
            // 0x028FBA04: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_21);
            object val_23 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_21);
            // 0x028FBA08: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_37 = 0;
            // 0x028FBA0C: CBZ x0, #0x28fba54         | if (val_23 == null) goto label_21;      
            if(val_23 == null)
            {
                goto label_21;
            }
            // 0x028FBA10: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x028FBA14: LDR x8, [x8, #0xd98]       | X8 = 1152921504723353600;               
            // 0x028FBA18: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animation);     
            // 0x028FBA1C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FBA20: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(UnityEngine.Animation))
            // 0x028FBA24: MOV x23, x0                | X23 = val_23;//m1                       
            val_37 = val_23;
            // 0x028FBA28: B.EQ #0x28fba54            | if (typeof(System.Object) == null) goto label_21;
            if(null == null)
            {
                goto label_21;
            }
            // 0x028FBA2C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FBA30: ADD x8, sp, #0x28          | X8 = (1152921510030907024 + 40) = 1152921510030907064 (0x10000001434C96B8);
            // 0x028FBA34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FBA38: LDR x0, [sp, #0x28]        | X0 = val_24;                             //  find_add[1152921510030895184]
            // 0x028FBA3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
            // 0x028FBA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBA44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x028FBA48: ADD x0, sp, #0x28          | X0 = (1152921510030907024 + 40) = 1152921510030907064 (0x10000001434C96B8);
            // 0x028FBA4C: BL #0x299a140              | 
            // 0x028FBA50: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_37 = 0;
            label_21:
            // 0x028FBA54: CBNZ x21, #0x28fba5c       | if (X1 != 0) goto label_22;             
            if(val_33 != 0)
            {
                goto label_22;
            }
            // 0x028FBA58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001434C96B8, ????);
            label_22:
            // 0x028FBA5C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBA60: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FBA64: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x028FBA68: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FBA6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBA70: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FBA74: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x028FBA78: MOV x2, x27                | X2 = 0 (0x0);//ML01                     
            // 0x028FBA7C: MOV w3, w26                | W3 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FBA80: MOV w4, w25                | W4 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FBA84: MOV w5, w24                | W5 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FBA88: BL #0xb1df90               | X0 = ActiveAnimation.Play(anim:  0, clipName:  val_37, playDirection:  val_36, enableBeforePlay:  1152921504606900224, disableCondition:  1152921504606900224);
            ActiveAnimation val_25 = ActiveAnimation.Play(anim:  0, clipName:  val_37, playDirection:  val_36, enableBeforePlay:  1152921504606900224, disableCondition:  1152921504606900224);
            // 0x028FBA8C: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x028FBA90: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_38 = 1152921504824418304;
            // 0x028FBA94: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x028FBA98: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_39 = null;
            // 0x028FBA9C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028FBAA0: CBZ x0, #0x28fbb34         | if (val_25 == null) goto label_23;      
            if(val_25 == null)
            {
                goto label_23;
            }
            // 0x028FBAA4: CBZ x22, #0x28fbb4c        | if (val_25 == null) goto label_24;      
            if(val_25 == null)
            {
                goto label_24;
            }
            // 0x028FBAA8: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x028FBAAC: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x028FBAB0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FBAB4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028FBAB8: CBNZ x0, #0x28fbaec        | if (val_25 != null) goto label_25;      
            if(val_25 != null)
            {
                goto label_25;
            }
            // 0x028FBABC: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FBAC0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FBAC4: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FBAC8: ADD x8, sp, #0x30          | X8 = (1152921510030907024 + 48) = 1152921510030907072 (0x10000001434C96C0);
            // 0x028FBACC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FBAD0: LDR x0, [sp, #0x30]        | X0 = val_26;                             //  find_add[1152921510030895184]
            // 0x028FBAD4: BL #0x27af090              | X0 = sub_27AF090( ?? val_26, ????);     
            // 0x028FBAD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBADC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            // 0x028FBAE0: ADD x0, sp, #0x30          | X0 = (1152921510030907024 + 48) = 1152921510030907072 (0x10000001434C96C0);
            // 0x028FBAE4: BL #0x299a140              | 
            // 0x028FBAE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001434C96C0, ????);
            label_25:
            // 0x028FBAEC: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_33 = null;
            // 0x028FBAF0: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x028FBAF4: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_39 = val_33;
            // 0x028FBAF8: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028FBAFC: MOV x23, x0                | X23 = val_25;//m1                       
            val_38 = val_25;
            // 0x028FBB00: CBNZ x23, #0x28fbb58       | if (val_25 != null) goto label_26;      
            if(val_38 != null)
            {
                goto label_26;
            }
            // 0x028FBB04: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FBB08: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FBB0C: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FBB10: ADD x8, sp, #0x38          | X8 = (1152921510030907024 + 56) = 1152921510030907080 (0x10000001434C96C8);
            // 0x028FBB14: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FBB18: LDR x0, [sp, #0x38]        | X0 = val_27;                             //  find_add[1152921510030895184]
            // 0x028FBB1C: BL #0x27af090              | X0 = sub_27AF090( ?? val_27, ????);     
            // 0x028FBB20: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_39 = 0;
            // 0x028FBB24: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            // 0x028FBB28: ADD x0, sp, #0x38          | X0 = (1152921510030907024 + 56) = 1152921510030907080 (0x10000001434C96C8);
            // 0x028FBB2C: BL #0x299a140              | 
            // 0x028FBB30: B #0x28fbb54               |  goto label_27;                         
            goto label_27;
            label_23:
            // 0x028FBB34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBB38: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FBB3C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FBB40: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028FBB44: MOV x3, x22                | X3 = val_25;//m1                        
            // 0x028FBB48: B #0x28fbbcc               |  goto label_28;                         
            goto label_28;
            label_24:
            // 0x028FBB4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            // 0x028FBB50: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_33 = null;
            label_27:
            // 0x028FBB54: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_38 = 0;
            label_26:
            // 0x028FBB58: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028FBB5C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028FBB60: CBZ x9, #0x28fbb8c         | if (mem[282584257676929] == 0) goto label_29;
            if(mem[282584257676929] == 0)
            {
                goto label_29;
            }
            // 0x028FBB64: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_32 = mem[282584257676823];
            // 0x028FBB68: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_33 = 0;
            // 0x028FBB6C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_32 = val_32 + 8;
            label_31:
            // 0x028FBB70: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028FBB74: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x028FBB78: B.EQ #0x28fbba0            | if ((mem[282584257676823] + 8) + -8 == val_33) goto label_30;
            if(((mem[282584257676823] + 8) + -8) == val_33)
            {
                goto label_30;
            }
            // 0x028FBB7C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_33 = val_33 + 1;
            // 0x028FBB80: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_32 = val_32 + 16;
            // 0x028FBB84: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028FBB88: B.LO #0x28fbb70            | if (0 < mem[282584257676929]) goto label_31;
            if(val_33 < mem[282584257676929])
            {
                goto label_31;
            }
            label_29:
            // 0x028FBB8C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028FBB90: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_40 = val_38;
            // 0x028FBB94: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_39 = val_33;
            // 0x028FBB98: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028FBB9C: B #0x28fbbac               |  goto label_32;                         
            goto label_32;
            label_30:
            // 0x028FBBA0: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x028FBBA4: ADD x8, x8, x9, lsl #4     | X8 = (val_38 + ((mem[282584257676823] + 8)) << 4);
            val_38 = val_38 + (((mem[282584257676823] + 8)) << 4);
            // 0x028FBBA8: ADD x0, x8, #0x110         | X0 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_40 = val_38 + 272;
            label_32:
            // 0x028FBBAC: LDP x8, x1, [x0]           | X8 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x028FBBB0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028FBBB4: BLR x8                     | X0 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x028FBBB8: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x028FBBBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBBC0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FBBC4: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FBBC8: MOV x2, x19                | X2 = X3;//m1                            
            label_28:
            // 0x028FBBCC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FBBD0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_28 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028FBBD4: SUB sp, x29, #0x50         | SP = (1152921510030907168 - 80) = 1152921510030907088 (0x10000001434C96D0);
            // 0x028FBBD8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028FBBDC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028FBBE0: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028FBBE4: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028FBBE8: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028FBBEC: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028FBBF0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_28;
            return val_28;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_9:
            // 0x028FBBF4: ADD x8, sp, #8             | X8 = (1152921510030907024 + 8) = 1152921510030907032 (0x10000001434C9698);
            // 0x028FBBF8: MOV x1, x24                | X1 = 1152921504875696128 (0x1000000010065000);//ML01
            // 0x028FBBFC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FBC00: LDR x0, [sp, #8]           | X0 = val_29;                             //  find_add[1152921510030895184]
            // 0x028FBC04: BL #0x27af090              | X0 = sub_27AF090( ?? val_29, ????);     
            // 0x028FBC08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBC0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            // 0x028FBC10: ADD x0, sp, #8             | X0 = (1152921510030907024 + 8) = 1152921510030907032 (0x10000001434C9698);
            // 0x028FBC14: BL #0x299a140              | 
            label_12:
            // 0x028FBC18: ADD x8, sp, #0x10          | X8 = (1152921510030907024 + 16) = 1152921510030907040 (0x10000001434C96A0);
            // 0x028FBC1C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FBC20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001434C9698, ????);
            // 0x028FBC24: LDR x0, [sp, #0x10]        | X0 = val_30;                             //  find_add[1152921510030895184]
            // 0x028FBC28: BL #0x27af090              | X0 = sub_27AF090( ?? val_30, ????);     
            // 0x028FBC2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBC30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_30, ????);     
            // 0x028FBC34: ADD x0, sp, #0x10          | X0 = (1152921510030907024 + 16) = 1152921510030907040 (0x10000001434C96A0);
            // 0x028FBC38: BL #0x299a140              | 
            label_15:
            // 0x028FBC3C: ADD x8, sp, #0x18          | X8 = (1152921510030907024 + 24) = 1152921510030907048 (0x10000001434C96A8);
            // 0x028FBC40: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x028FBC44: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x10000001434C96A0, ????);
            // 0x028FBC48: LDR x0, [sp, #0x18]        | X0 = val_31;                             //  find_add[1152921510030895184]
            // 0x028FBC4C: BL #0x27af090              | X0 = sub_27AF090( ?? val_31, ????);     
            // 0x028FBC50: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBC54: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            // 0x028FBC58: ADD x0, sp, #0x18          | X0 = (1152921510030907024 + 24) = 1152921510030907048 (0x10000001434C96A8);
            // 0x028FBC5C: BL #0x299a140              | 
            // 0x028FBC60: MOV x19, x0                | X19 = 1152921510030907048 (0x10000001434C96A8);//ML01
            val_41;
            // 0x028FBC64: ADD x0, sp, #0x20          | X0 = (1152921510030907024 + 32) = 1152921510030907056 (0x10000001434C96B0);
            // 0x028FBC68: B #0x28fbc8c               |  goto label_38;                         
            goto label_38;
            // 0x028FBC6C: MOV x19, x0                | X19 = 1152921510030907056 (0x10000001434C96B0);//ML01
            val_41;
            // 0x028FBC70: ADD x0, sp, #0x28          | X0 = (1152921510030907024 + 40) = 1152921510030907064 (0x10000001434C96B8);
            // 0x028FBC74: B #0x28fbc8c               |  goto label_38;                         
            goto label_38;
            // 0x028FBC78: MOV x19, x0                | X19 = 1152921510030907064 (0x10000001434C96B8);//ML01
            val_41;
            // 0x028FBC7C: ADD x0, sp, #0x30          | X0 = (1152921510030907024 + 48) = 1152921510030907072 (0x10000001434C96C0);
            // 0x028FBC80: B #0x28fbc8c               |  goto label_38;                         
            goto label_38;
            // 0x028FBC84: MOV x19, x0                | X19 = 1152921510030907072 (0x10000001434C96C0);//ML01
            val_41;
            // 0x028FBC88: ADD x0, sp, #0x38          | X0 = (1152921510030907024 + 56) = 1152921510030907080 (0x10000001434C96C8);
            label_38:
            // 0x028FBC8C: BL #0x299a140              | 
            // 0x028FBC90: MOV x0, x19                | X0 = 1152921510030907072 (0x10000001434C96C0);//ML01
            // 0x028FBC94: BL #0x980800               | X0 = sub_980800( ?? 0x10000001434C96C0, ????);
            // 0x028FBC98: MOV x19, x0                | X19 = 1152921510030907072 (0x10000001434C96C0);//ML01
            // 0x028FBC9C: ADD x0, sp, #8             | X0 = (1152921510030907024 + 8) = 1152921510030907032 (0x10000001434C9698);
            // 0x028FBCA0: B #0x28fbc8c               |  goto label_38;                         
            goto label_38;
            // 0x028FBCA4: MOV x19, x0                | X19 = 1152921510030907032 (0x10000001434C9698);//ML01
            // 0x028FBCA8: ADD x0, sp, #0x10          | X0 = (1152921510030907024 + 16) = 1152921510030907040 (0x10000001434C96A0);
            // 0x028FBCAC: B #0x28fbc8c               |  goto label_38;                         
            goto label_38;
            // 0x028FBCB0: MOV x19, x0                | X19 = 1152921510030907040 (0x10000001434C96A0);//ML01
            // 0x028FBCB4: ADD x0, sp, #0x18          | X0 = (1152921510030907024 + 24) = 1152921510030907048 (0x10000001434C96A8);
            // 0x028FBCB8: B #0x28fbc8c               |  goto label_38;                         
            goto label_38;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FBCBC (42974396), len: 1292  VirtAddr: 0x028FBCBC RVA: 0x028FBCBC token: 100663671 methodIndex: 29716 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_4(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            var val_16;
            //  | 
            var val_18;
            //  | 
            var val_19;
            //  | 
            var val_21;
            //  | 
            var val_23;
            //  | 
            AnimationOrTween.Direction val_24;
            //  | 
            string val_25;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_28;
            //  | 
            var val_29;
            //  | 
            var val_30;
            // 0x028FBCBC: STP x26, x25, [sp, #-0x50]! | stack[1152921510031158368] = ???;  stack[1152921510031158376] = ???;  //  dest_result_addr=1152921510031158368 |  dest_result_addr=1152921510031158376
            // 0x028FBCC0: STP x24, x23, [sp, #0x10]  | stack[1152921510031158384] = ???;  stack[1152921510031158392] = ???;  //  dest_result_addr=1152921510031158384 |  dest_result_addr=1152921510031158392
            // 0x028FBCC4: STP x22, x21, [sp, #0x20]  | stack[1152921510031158400] = ???;  stack[1152921510031158408] = ???;  //  dest_result_addr=1152921510031158400 |  dest_result_addr=1152921510031158408
            // 0x028FBCC8: STP x20, x19, [sp, #0x30]  | stack[1152921510031158416] = ???;  stack[1152921510031158424] = ???;  //  dest_result_addr=1152921510031158416 |  dest_result_addr=1152921510031158424
            // 0x028FBCCC: STP x29, x30, [sp, #0x40]  | stack[1152921510031158432] = ???;  stack[1152921510031158440] = ???;  //  dest_result_addr=1152921510031158432 |  dest_result_addr=1152921510031158440
            // 0x028FBCD0: ADD x29, sp, #0x40         | X29 = (1152921510031158368 + 64) = 1152921510031158432 (0x1000000143506CA0);
            // 0x028FBCD4: SUB sp, sp, #0x30          | SP = (1152921510031158368 - 48) = 1152921510031158320 (0x1000000143506C30);
            // 0x028FBCD8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FBCDC: LDRB w8, [x20, #0xa68]     | W8 = (bool)static_value_037B8A68;       
            // 0x028FBCE0: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028FBCE4: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028FBCE8: MOV x21, x1                | X21 = X1;//m1                           
            val_23 = X1;
            // 0x028FBCEC: TBNZ w8, #0, #0x28fbd08    | if (static_value_037B8A68 == true) goto label_0;
            // 0x028FBCF0: ADRP x8, #0x3645000        | X8 = 56905728 (0x3645000);              
            // 0x028FBCF4: LDR x8, [x8, #0xb58]       | X8 = 0x2B8A968;                         
            // 0x028FBCF8: LDR w0, [x8]               | W0 = 0x118;                             
            // 0x028FBCFC: BL #0x2782188              | X0 = sub_2782188( ?? 0x118, ????);      
            // 0x028FBD00: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FBD04: STRB w8, [x20, #0xa68]     | static_value_037B8A68 = true;            //  dest_result_addr=58428008
            label_0:
            // 0x028FBD08: CBNZ x21, #0x28fbd10       | if (X1 != 0) goto label_1;              
            if(val_23 != 0)
            {
                goto label_1;
            }
            // 0x028FBD0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x118, ????);      
            label_1:
            // 0x028FBD10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBD14: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FBD18: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_23.AppDomain;
            // 0x028FBD1C: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FBD20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBD24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBD28: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028FBD2C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FBD30: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FBD34: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FBD38: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBD3C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBD40: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FBD44: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FBD48: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FBD4C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FBD50: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FBD54: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x028FBD58: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x028FBD5C: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FBD60: LDR x9, [x9, #0x2c0]       | X9 = 1152921504875589632;               
            // 0x028FBD64: LDR x24, [x9]              | X24 = typeof(AnimationOrTween.Direction);
            // 0x028FBD68: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FBD6C: TBZ w9, #0, #0x28fbd80     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FBD70: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FBD74: CBNZ w9, #0x28fbd80        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FBD78: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FBD7C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FBD80: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBD84: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBD88: MOV x1, x24                | X1 = 1152921504875589632 (0x100000001004B000);//ML01
            // 0x028FBD8C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FBD90: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028FBD94: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028FBD98: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FBD9C: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FBDA0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FBDA4: TBZ w9, #0, #0x28fbdb8     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FBDA8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FBDAC: CBNZ w9, #0x28fbdb8        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FBDB0: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FBDB4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FBDB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBDBC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FBDC0: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FBDC4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FBDC8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FBDCC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FBDD0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FBDD4: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FBDD8: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028FBDDC: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FBDE0: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FBDE4: TBZ w9, #0, #0x28fbdf8     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FBDE8: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FBDEC: CBNZ w9, #0x28fbdf8        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FBDF0: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FBDF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FBDF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBDFC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBE00: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FBE04: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028FBE08: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FBE0C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028FBE10: LDR x8, [x8, #0xed8]       | X8 = 1152921504875589632;               
            // 0x028FBE14: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x028FBE18: LDR x24, [x8]              | X24 = typeof(AnimationOrTween.Direction);
            // 0x028FBE1C: CBNZ x26, #0x28fbe24       | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x028FBE20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x028FBE24: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x028FBE28: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FBE2C: LDR x8, [x24, #0x30]       | X8 = AnimationOrTween.Direction.__il2cppRuntimeField_element_class;
            // 0x028FBE30: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.Direction.__il2cppRuntimeField_element_class)
            // 0x028FBE34: B.NE #0x28fc160            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.Direction.__il2cppRuntimeField_element_class) goto label_9;
            // 0x028FBE38: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x028FBE3C: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x028FBE40: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x028FBE44: CBNZ x21, #0x28fbe4c       | if (X1 != 0) goto label_10;             
            if(val_23 != 0)
            {
                goto label_10;
            }
            // 0x028FBE48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x028FBE4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBE50: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FBE54: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FBE58: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_23.Free(esp:  null);
            // 0x028FBE5C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBE60: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBE64: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028FBE68: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FBE6C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FBE70: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028FBE74: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x028FBE78: MOV x26, x0                | X26 = val_7;//m1                        
            // 0x028FBE7C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBE80: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBE84: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FBE88: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FBE8C: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x028FBE90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBE94: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FBE98: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x028FBE9C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FBEA0: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FBEA4: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FBEA8: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x028FBEAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBEB0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBEB4: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x028FBEB8: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x028FBEBC: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_24 = 0;
            // 0x028FBEC0: CBZ x0, #0x28fbf08         | if (val_10 == null) goto label_12;      
            if(val_10 == null)
            {
                goto label_12;
            }
            // 0x028FBEC4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028FBEC8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028FBECC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FBED0: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FBED4: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x028FBED8: MOV x25, x0                | X25 = val_10;//m1                       
            val_24 = val_10;
            // 0x028FBEDC: B.EQ #0x28fbf08            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x028FBEE0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FBEE4: ADD x8, sp, #0x10          | X8 = (1152921510031158320 + 16) = 1152921510031158336 (0x1000000143506C40);
            // 0x028FBEE8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FBEEC: LDR x0, [sp, #0x10]        | X0 = val_11;                             //  find_add[1152921510031146448]
            // 0x028FBEF0: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x028FBEF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBEF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x028FBEFC: ADD x0, sp, #0x10          | X0 = (1152921510031158320 + 16) = 1152921510031158336 (0x1000000143506C40);
            // 0x028FBF00: BL #0x299a140              | 
            // 0x028FBF04: MOV x25, xzr               | X25 = 0 (0x0);//ML01                    
            val_24 = 0;
            label_12:
            // 0x028FBF08: CBNZ x21, #0x28fbf10       | if (X1 != 0) goto label_13;             
            if(val_23 != 0)
            {
                goto label_13;
            }
            // 0x028FBF0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143506C40, ????);
            label_13:
            // 0x028FBF10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBF14: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FBF18: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x028FBF1C: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_23.Free(esp:  null);
            // 0x028FBF20: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBF24: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBF28: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028FBF2C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FBF30: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_12 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FBF34: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x028FBF38: LDR x8, [x8, #0x9e8]       | X8 = 1152921504723353600;               
            // 0x028FBF3C: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x028FBF40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBF44: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBF48: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animation);     
            // 0x028FBF4C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FBF50: MOV x26, x0                | X26 = val_13;//m1                       
            // 0x028FBF54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBF58: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FBF5C: MOV x1, x22                | X1 = val_12;//m1                        
            // 0x028FBF60: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FBF64: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FBF68: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_14 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FBF6C: MOV x2, x0                 | X2 = val_14;//m1                        
            // 0x028FBF70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBF74: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FBF78: MOV x1, x26                | X1 = val_13;//m1                        
            // 0x028FBF7C: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_13);
            object val_15 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_13);
            // 0x028FBF80: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_25 = 0;
            // 0x028FBF84: CBZ x0, #0x28fbfcc         | if (val_15 == null) goto label_15;      
            if(val_15 == null)
            {
                goto label_15;
            }
            // 0x028FBF88: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x028FBF8C: LDR x8, [x8, #0xd98]       | X8 = 1152921504723353600;               
            // 0x028FBF90: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animation);     
            // 0x028FBF94: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FBF98: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(UnityEngine.Animation))
            // 0x028FBF9C: MOV x23, x0                | X23 = val_15;//m1                       
            val_25 = val_15;
            // 0x028FBFA0: B.EQ #0x28fbfcc            | if (typeof(System.Object) == null) goto label_15;
            if(null == null)
            {
                goto label_15;
            }
            // 0x028FBFA4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FBFA8: ADD x8, sp, #0x18          | X8 = (1152921510031158320 + 24) = 1152921510031158344 (0x1000000143506C48);
            // 0x028FBFAC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FBFB0: LDR x0, [sp, #0x18]        | X0 = val_16;                             //  find_add[1152921510031146448]
            // 0x028FBFB4: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x028FBFB8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FBFBC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x028FBFC0: ADD x0, sp, #0x18          | X0 = (1152921510031158320 + 24) = 1152921510031158344 (0x1000000143506C48);
            // 0x028FBFC4: BL #0x299a140              | 
            // 0x028FBFC8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_25 = 0;
            label_15:
            // 0x028FBFCC: CBNZ x21, #0x28fbfd4       | if (X1 != 0) goto label_16;             
            if(val_23 != 0)
            {
                goto label_16;
            }
            // 0x028FBFD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143506C48, ????);
            label_16:
            // 0x028FBFD4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FBFD8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FBFDC: MOV x1, x22                | X1 = val_12;//m1                        
            // 0x028FBFE0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_23.Free(esp:  null);
            // 0x028FBFE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FBFE8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FBFEC: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x028FBFF0: MOV x2, x25                | X2 = 0 (0x0);//ML01                     
            // 0x028FBFF4: MOV w3, w24                | W3 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FBFF8: BL #0xb1e2e0               | X0 = ActiveAnimation.Play(anim:  0, clipName:  val_25, playDirection:  val_24);
            ActiveAnimation val_17 = ActiveAnimation.Play(anim:  0, clipName:  val_25, playDirection:  val_24);
            // 0x028FBFFC: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x028FC000: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_26 = 1152921504824418304;
            // 0x028FC004: MOV x22, x0                | X22 = val_17;//m1                       
            // 0x028FC008: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_27 = null;
            // 0x028FC00C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x028FC010: CBZ x0, #0x28fc0a4         | if (val_17 == null) goto label_17;      
            if(val_17 == null)
            {
                goto label_17;
            }
            // 0x028FC014: CBZ x22, #0x28fc0bc        | if (val_17 == null) goto label_18;      
            if(val_17 == null)
            {
                goto label_18;
            }
            // 0x028FC018: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x028FC01C: MOV x0, x22                | X0 = val_17;//m1                        
            // 0x028FC020: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FC024: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x028FC028: CBNZ x0, #0x28fc05c        | if (val_17 != null) goto label_19;      
            if(val_17 != null)
            {
                goto label_19;
            }
            // 0x028FC02C: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FC030: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FC034: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FC038: ADD x8, sp, #0x20          | X8 = (1152921510031158320 + 32) = 1152921510031158352 (0x1000000143506C50);
            // 0x028FC03C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FC040: LDR x0, [sp, #0x20]        | X0 = val_18;                             //  find_add[1152921510031146448]
            // 0x028FC044: BL #0x27af090              | X0 = sub_27AF090( ?? val_18, ????);     
            // 0x028FC048: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC04C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_18, ????);     
            // 0x028FC050: ADD x0, sp, #0x20          | X0 = (1152921510031158320 + 32) = 1152921510031158352 (0x1000000143506C50);
            // 0x028FC054: BL #0x299a140              | 
            // 0x028FC058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143506C50, ????);
            label_19:
            // 0x028FC05C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_23 = null;
            // 0x028FC060: MOV x0, x22                | X0 = val_17;//m1                        
            // 0x028FC064: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_27 = val_23;
            // 0x028FC068: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_17, ????);     
            // 0x028FC06C: MOV x23, x0                | X23 = val_17;//m1                       
            val_26 = val_17;
            // 0x028FC070: CBNZ x23, #0x28fc0c8       | if (val_17 != null) goto label_20;      
            if(val_26 != null)
            {
                goto label_20;
            }
            // 0x028FC074: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FC078: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FC07C: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FC080: ADD x8, sp, #0x28          | X8 = (1152921510031158320 + 40) = 1152921510031158360 (0x1000000143506C58);
            // 0x028FC084: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FC088: LDR x0, [sp, #0x28]        | X0 = val_19;                             //  find_add[1152921510031146448]
            // 0x028FC08C: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x028FC090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_27 = 0;
            // 0x028FC094: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x028FC098: ADD x0, sp, #0x28          | X0 = (1152921510031158320 + 40) = 1152921510031158360 (0x1000000143506C58);
            // 0x028FC09C: BL #0x299a140              | 
            // 0x028FC0A0: B #0x28fc0c4               |  goto label_21;                         
            goto label_21;
            label_17:
            // 0x028FC0A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC0A8: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FC0AC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FC0B0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028FC0B4: MOV x3, x22                | X3 = val_17;//m1                        
            // 0x028FC0B8: B #0x28fc13c               |  goto label_22;                         
            goto label_22;
            label_18:
            // 0x028FC0BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_17, ????);     
            // 0x028FC0C0: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_23 = null;
            label_21:
            // 0x028FC0C4: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_26 = 0;
            label_20:
            // 0x028FC0C8: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028FC0CC: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028FC0D0: CBZ x9, #0x28fc0fc         | if (mem[282584257676929] == 0) goto label_23;
            if(mem[282584257676929] == 0)
            {
                goto label_23;
            }
            // 0x028FC0D4: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_22 = mem[282584257676823];
            // 0x028FC0D8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_23 = 0;
            // 0x028FC0DC: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_22 = val_22 + 8;
            label_25:
            // 0x028FC0E0: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028FC0E4: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x028FC0E8: B.EQ #0x28fc110            | if ((mem[282584257676823] + 8) + -8 == val_23) goto label_24;
            if(((mem[282584257676823] + 8) + -8) == val_23)
            {
                goto label_24;
            }
            // 0x028FC0EC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_23 = val_23 + 1;
            // 0x028FC0F0: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_22 = val_22 + 16;
            // 0x028FC0F4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028FC0F8: B.LO #0x28fc0e0            | if (0 < mem[282584257676929]) goto label_25;
            if(val_23 < mem[282584257676929])
            {
                goto label_25;
            }
            label_23:
            // 0x028FC0FC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028FC100: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_28 = val_26;
            // 0x028FC104: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_27 = val_23;
            // 0x028FC108: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028FC10C: B #0x28fc11c               |  goto label_26;                         
            goto label_26;
            label_24:
            // 0x028FC110: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x028FC114: ADD x8, x8, x9, lsl #4     | X8 = (val_26 + ((mem[282584257676823] + 8)) << 4);
            val_26 = val_26 + (((mem[282584257676823] + 8)) << 4);
            // 0x028FC118: ADD x0, x8, #0x110         | X0 = ((val_26 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_28 = val_26 + 272;
            label_26:
            // 0x028FC11C: LDP x8, x1, [x0]           | X8 = ((val_26 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_26 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x028FC120: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028FC124: BLR x8                     | X0 = ((val_26 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x028FC128: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x028FC12C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC130: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FC134: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FC138: MOV x2, x19                | X2 = X3;//m1                            
            label_22:
            // 0x028FC13C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FC140: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_20 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028FC144: SUB sp, x29, #0x40         | SP = (1152921510031158432 - 64) = 1152921510031158368 (0x1000000143506C60);
            // 0x028FC148: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028FC14C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028FC150: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028FC154: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028FC158: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028FC15C: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_20;
            return val_20;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_9:
            // 0x028FC160: ADD x8, sp, #8             | X8 = (1152921510031158320 + 8) = 1152921510031158328 (0x1000000143506C38);
            // 0x028FC164: MOV x1, x24                | X1 = 1152921504875589632 (0x100000001004B000);//ML01
            // 0x028FC168: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FC16C: LDR x0, [sp, #8]           | X0 = val_21;                             //  find_add[1152921510031146448]
            // 0x028FC170: BL #0x27af090              | X0 = sub_27AF090( ?? val_21, ????);     
            // 0x028FC174: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC178: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_21, ????);     
            // 0x028FC17C: ADD x0, sp, #8             | X0 = (1152921510031158320 + 8) = 1152921510031158328 (0x1000000143506C38);
            // 0x028FC180: BL #0x299a140              | 
            // 0x028FC184: MOV x19, x0                | X19 = 1152921510031158328 (0x1000000143506C38);//ML01
            val_29;
            // 0x028FC188: ADD x0, sp, #0x10          | X0 = (1152921510031158320 + 16) = 1152921510031158336 (0x1000000143506C40);
            // 0x028FC18C: B #0x28fc1b0               |  goto label_30;                         
            goto label_30;
            // 0x028FC190: MOV x19, x0                | X19 = 1152921510031158336 (0x1000000143506C40);//ML01
            val_29;
            // 0x028FC194: ADD x0, sp, #0x18          | X0 = (1152921510031158320 + 24) = 1152921510031158344 (0x1000000143506C48);
            // 0x028FC198: B #0x28fc1b0               |  goto label_30;                         
            goto label_30;
            // 0x028FC19C: MOV x19, x0                | X19 = 1152921510031158344 (0x1000000143506C48);//ML01
            val_29;
            // 0x028FC1A0: ADD x0, sp, #0x20          | X0 = (1152921510031158320 + 32) = 1152921510031158352 (0x1000000143506C50);
            // 0x028FC1A4: B #0x28fc1b0               |  goto label_30;                         
            goto label_30;
            // 0x028FC1A8: MOV x19, x0                | X19 = 1152921510031158352 (0x1000000143506C50);//ML01
            val_29;
            // 0x028FC1AC: ADD x0, sp, #0x28          | X0 = (1152921510031158320 + 40) = 1152921510031158360 (0x1000000143506C58);
            label_30:
            // 0x028FC1B0: BL #0x299a140              | 
            // 0x028FC1B4: MOV x0, x19                | X0 = 1152921510031158352 (0x1000000143506C50);//ML01
            // 0x028FC1B8: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143506C50, ????);
            // 0x028FC1BC: MOV x19, x0                | X19 = 1152921510031158352 (0x1000000143506C50);//ML01
            // 0x028FC1C0: ADD x0, sp, #8             | X0 = (1152921510031158320 + 8) = 1152921510031158328 (0x1000000143506C38);
            // 0x028FC1C4: B #0x28fc1b0               |  goto label_30;                         
            goto label_30;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FC1C8 (42975688), len: 1080  VirtAddr: 0x028FC1C8 RVA: 0x028FC1C8 token: 100663672 methodIndex: 29717 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_5(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_11;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_16;
            //  | 
            var val_18;
            //  | 
            AnimationOrTween.Direction val_19;
            //  | 
            var val_20;
            //  | 
            var val_21;
            //  | 
            var val_22;
            //  | 
            var val_23;
            //  | 
            var val_24;
            // 0x028FC1C8: STP x26, x25, [sp, #-0x50]! | stack[1152921510031372768] = ???;  stack[1152921510031372776] = ???;  //  dest_result_addr=1152921510031372768 |  dest_result_addr=1152921510031372776
            // 0x028FC1CC: STP x24, x23, [sp, #0x10]  | stack[1152921510031372784] = ???;  stack[1152921510031372792] = ???;  //  dest_result_addr=1152921510031372784 |  dest_result_addr=1152921510031372792
            // 0x028FC1D0: STP x22, x21, [sp, #0x20]  | stack[1152921510031372800] = ???;  stack[1152921510031372808] = ???;  //  dest_result_addr=1152921510031372800 |  dest_result_addr=1152921510031372808
            // 0x028FC1D4: STP x20, x19, [sp, #0x30]  | stack[1152921510031372816] = ???;  stack[1152921510031372824] = ???;  //  dest_result_addr=1152921510031372816 |  dest_result_addr=1152921510031372824
            // 0x028FC1D8: STP x29, x30, [sp, #0x40]  | stack[1152921510031372832] = ???;  stack[1152921510031372840] = ???;  //  dest_result_addr=1152921510031372832 |  dest_result_addr=1152921510031372840
            // 0x028FC1DC: ADD x29, sp, #0x40         | X29 = (1152921510031372768 + 64) = 1152921510031372832 (0x100000014353B220);
            // 0x028FC1E0: SUB sp, sp, #0x20          | SP = (1152921510031372768 - 32) = 1152921510031372736 (0x100000014353B1C0);
            // 0x028FC1E4: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FC1E8: LDRB w8, [x20, #0xa69]     | W8 = (bool)static_value_037B8A69;       
            // 0x028FC1EC: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028FC1F0: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028FC1F4: MOV x21, x1                | X21 = X1;//m1                           
            val_18 = X1;
            // 0x028FC1F8: TBNZ w8, #0, #0x28fc214    | if (static_value_037B8A69 == true) goto label_0;
            // 0x028FC1FC: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x028FC200: LDR x8, [x8, #0x858]       | X8 = 0x2B8A96C;                         
            // 0x028FC204: LDR w0, [x8]               | W0 = 0x119;                             
            // 0x028FC208: BL #0x2782188              | X0 = sub_2782188( ?? 0x119, ????);      
            // 0x028FC20C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FC210: STRB w8, [x20, #0xa69]     | static_value_037B8A69 = true;            //  dest_result_addr=58428009
            label_0:
            // 0x028FC214: CBNZ x21, #0x28fc21c       | if (X1 != 0) goto label_1;              
            if(val_18 != 0)
            {
                goto label_1;
            }
            // 0x028FC218: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x119, ????);      
            label_1:
            // 0x028FC21C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC220: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC224: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_18.AppDomain;
            // 0x028FC228: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FC22C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC230: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC234: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028FC238: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC23C: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC240: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FC244: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC248: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC24C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FC250: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC254: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC258: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FC25C: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FC260: ADRP x9, #0x364f000        | X9 = 56946688 (0x364F000);              
            // 0x028FC264: MOV x25, x0                | X25 = val_3;//m1                        
            // 0x028FC268: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FC26C: LDR x9, [x9, #0x2c0]       | X9 = 1152921504875589632;               
            // 0x028FC270: LDR x24, [x9]              | X24 = typeof(AnimationOrTween.Direction);
            // 0x028FC274: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FC278: TBZ w9, #0, #0x28fc28c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FC27C: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FC280: CBNZ w9, #0x28fc28c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FC284: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FC288: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FC28C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC290: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC294: MOV x1, x24                | X1 = 1152921504875589632 (0x100000001004B000);//ML01
            // 0x028FC298: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC29C: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028FC2A0: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028FC2A4: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FC2A8: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FC2AC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FC2B0: TBZ w9, #0, #0x28fc2c4     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FC2B4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FC2B8: CBNZ w9, #0x28fc2c4        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FC2BC: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FC2C0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FC2C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC2C8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FC2CC: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FC2D0: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FC2D4: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FC2D8: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FC2DC: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FC2E0: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FC2E4: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028FC2E8: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FC2EC: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FC2F0: TBZ w9, #0, #0x28fc304     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FC2F4: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FC2F8: CBNZ w9, #0x28fc304        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FC2FC: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FC300: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FC304: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC308: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC30C: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FC310: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028FC314: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FC318: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028FC31C: LDR x8, [x8, #0xed8]       | X8 = 1152921504875589632;               
            // 0x028FC320: MOV x26, x0                | X26 = val_6;//m1                        
            // 0x028FC324: LDR x24, [x8]              | X24 = typeof(AnimationOrTween.Direction);
            // 0x028FC328: CBNZ x26, #0x28fc330       | if (val_6 != null) goto label_8;        
            if(val_6 != null)
            {
                goto label_8;
            }
            // 0x028FC32C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x028FC330: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x028FC334: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FC338: LDR x8, [x24, #0x30]       | X8 = AnimationOrTween.Direction.__il2cppRuntimeField_element_class;
            // 0x028FC33C: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.Direction.__il2cppRuntimeField_element_class)
            // 0x028FC340: B.NE #0x28fc5a4            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.Direction.__il2cppRuntimeField_element_class) goto label_9;
            // 0x028FC344: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x028FC348: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_6.System.IDisposable.Dispose();
            // 0x028FC34C: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x028FC350: CBNZ x21, #0x28fc358       | if (X1 != 0) goto label_10;             
            if(val_18 != 0)
            {
                goto label_10;
            }
            // 0x028FC354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x028FC358: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC35C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC360: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FC364: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_18.Free(esp:  null);
            // 0x028FC368: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC36C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC370: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028FC374: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC378: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC37C: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x028FC380: LDR x8, [x8, #0x9e8]       | X8 = 1152921504723353600;               
            // 0x028FC384: MOV x22, x0                | X22 = val_7;//m1                        
            // 0x028FC388: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC38C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC390: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animation);     
            // 0x028FC394: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC398: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x028FC39C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC3A0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FC3A4: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x028FC3A8: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FC3AC: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FC3B0: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FC3B4: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x028FC3B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC3BC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC3C0: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x028FC3C4: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x028FC3C8: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_19 = 0;
            // 0x028FC3CC: CBZ x0, #0x28fc414         | if (val_10 == null) goto label_12;      
            if(val_10 == null)
            {
                goto label_12;
            }
            // 0x028FC3D0: ADRP x8, #0x35c6000        | X8 = 56385536 (0x35C6000);              
            // 0x028FC3D4: LDR x8, [x8, #0xd98]       | X8 = 1152921504723353600;               
            // 0x028FC3D8: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animation);     
            // 0x028FC3DC: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FC3E0: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(UnityEngine.Animation))
            // 0x028FC3E4: MOV x23, x0                | X23 = val_10;//m1                       
            val_19 = val_10;
            // 0x028FC3E8: B.EQ #0x28fc414            | if (typeof(System.Object) == null) goto label_12;
            if(null == null)
            {
                goto label_12;
            }
            // 0x028FC3EC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FC3F0: ADD x8, sp, #8             | X8 = (1152921510031372736 + 8) = 1152921510031372744 (0x100000014353B1C8);
            // 0x028FC3F4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FC3F8: LDR x0, [sp, #8]           | X0 = val_11;                             //  find_add[1152921510031360848]
            // 0x028FC3FC: BL #0x27af090              | X0 = sub_27AF090( ?? val_11, ????);     
            // 0x028FC400: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC404: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_11, ????);     
            // 0x028FC408: ADD x0, sp, #8             | X0 = (1152921510031372736 + 8) = 1152921510031372744 (0x100000014353B1C8);
            // 0x028FC40C: BL #0x299a140              | 
            // 0x028FC410: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_19 = 0;
            label_12:
            // 0x028FC414: CBNZ x21, #0x28fc41c       | if (X1 != 0) goto label_13;             
            if(val_18 != 0)
            {
                goto label_13;
            }
            // 0x028FC418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014353B1C8, ????);
            label_13:
            // 0x028FC41C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC420: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC424: MOV x1, x22                | X1 = val_7;//m1                         
            // 0x028FC428: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_18.Free(esp:  null);
            // 0x028FC42C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC430: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC434: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x028FC438: MOV w2, w24                | W2 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FC43C: BL #0xb1e2ec               | X0 = ActiveAnimation.Play(anim:  0, playDirection:  val_19);
            ActiveAnimation val_12 = ActiveAnimation.Play(anim:  0, playDirection:  val_19);
            // 0x028FC440: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x028FC444: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_20 = 1152921504824418304;
            // 0x028FC448: MOV x22, x0                | X22 = val_12;//m1                       
            // 0x028FC44C: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_21 = null;
            // 0x028FC450: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x028FC454: CBZ x0, #0x28fc4e8         | if (val_12 == null) goto label_14;      
            if(val_12 == null)
            {
                goto label_14;
            }
            // 0x028FC458: CBZ x22, #0x28fc500        | if (val_12 == null) goto label_15;      
            if(val_12 == null)
            {
                goto label_15;
            }
            // 0x028FC45C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x028FC460: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x028FC464: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FC468: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x028FC46C: CBNZ x0, #0x28fc4a0        | if (val_12 != null) goto label_16;      
            if(val_12 != null)
            {
                goto label_16;
            }
            // 0x028FC470: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FC474: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FC478: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FC47C: ADD x8, sp, #0x10          | X8 = (1152921510031372736 + 16) = 1152921510031372752 (0x100000014353B1D0);
            // 0x028FC480: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FC484: LDR x0, [sp, #0x10]        | X0 = val_13;                             //  find_add[1152921510031360848]
            // 0x028FC488: BL #0x27af090              | X0 = sub_27AF090( ?? val_13, ????);     
            // 0x028FC48C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC490: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_13, ????);     
            // 0x028FC494: ADD x0, sp, #0x10          | X0 = (1152921510031372736 + 16) = 1152921510031372752 (0x100000014353B1D0);
            // 0x028FC498: BL #0x299a140              | 
            // 0x028FC49C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014353B1D0, ????);
            label_16:
            // 0x028FC4A0: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_18 = null;
            // 0x028FC4A4: MOV x0, x22                | X0 = val_12;//m1                        
            // 0x028FC4A8: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_21 = val_18;
            // 0x028FC4AC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_12, ????);     
            // 0x028FC4B0: MOV x23, x0                | X23 = val_12;//m1                       
            val_20 = val_12;
            // 0x028FC4B4: CBNZ x23, #0x28fc50c       | if (val_12 != null) goto label_17;      
            if(val_20 != null)
            {
                goto label_17;
            }
            // 0x028FC4B8: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FC4BC: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FC4C0: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FC4C4: ADD x8, sp, #0x18          | X8 = (1152921510031372736 + 24) = 1152921510031372760 (0x100000014353B1D8);
            // 0x028FC4C8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FC4CC: LDR x0, [sp, #0x18]        | X0 = val_14;                             //  find_add[1152921510031360848]
            // 0x028FC4D0: BL #0x27af090              | X0 = sub_27AF090( ?? val_14, ????);     
            // 0x028FC4D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_21 = 0;
            // 0x028FC4D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_14, ????);     
            // 0x028FC4DC: ADD x0, sp, #0x18          | X0 = (1152921510031372736 + 24) = 1152921510031372760 (0x100000014353B1D8);
            // 0x028FC4E0: BL #0x299a140              | 
            // 0x028FC4E4: B #0x28fc508               |  goto label_18;                         
            goto label_18;
            label_14:
            // 0x028FC4E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC4EC: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FC4F0: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FC4F4: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028FC4F8: MOV x3, x22                | X3 = val_12;//m1                        
            // 0x028FC4FC: B #0x28fc580               |  goto label_19;                         
            goto label_19;
            label_15:
            // 0x028FC500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12, ????);     
            // 0x028FC504: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_18 = null;
            label_18:
            // 0x028FC508: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_20 = 0;
            label_17:
            // 0x028FC50C: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028FC510: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028FC514: CBZ x9, #0x28fc540         | if (mem[282584257676929] == 0) goto label_20;
            if(mem[282584257676929] == 0)
            {
                goto label_20;
            }
            // 0x028FC518: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_17 = mem[282584257676823];
            // 0x028FC51C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_18 = 0;
            // 0x028FC520: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_17 = val_17 + 8;
            label_22:
            // 0x028FC524: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028FC528: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x028FC52C: B.EQ #0x28fc554            | if ((mem[282584257676823] + 8) + -8 == val_18) goto label_21;
            if(((mem[282584257676823] + 8) + -8) == val_18)
            {
                goto label_21;
            }
            // 0x028FC530: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_18 = val_18 + 1;
            // 0x028FC534: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_17 = val_17 + 16;
            // 0x028FC538: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028FC53C: B.LO #0x28fc524            | if (0 < mem[282584257676929]) goto label_22;
            if(val_18 < mem[282584257676929])
            {
                goto label_22;
            }
            label_20:
            // 0x028FC540: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028FC544: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_22 = val_20;
            // 0x028FC548: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_21 = val_18;
            // 0x028FC54C: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028FC550: B #0x28fc560               |  goto label_23;                         
            goto label_23;
            label_21:
            // 0x028FC554: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x028FC558: ADD x8, x8, x9, lsl #4     | X8 = (val_20 + ((mem[282584257676823] + 8)) << 4);
            val_20 = val_20 + (((mem[282584257676823] + 8)) << 4);
            // 0x028FC55C: ADD x0, x8, #0x110         | X0 = ((val_20 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_22 = val_20 + 272;
            label_23:
            // 0x028FC560: LDP x8, x1, [x0]           | X8 = ((val_20 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_20 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x028FC564: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028FC568: BLR x8                     | X0 = ((val_20 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x028FC56C: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x028FC570: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC574: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FC578: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FC57C: MOV x2, x19                | X2 = X3;//m1                            
            label_19:
            // 0x028FC580: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FC584: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028FC588: SUB sp, x29, #0x40         | SP = (1152921510031372832 - 64) = 1152921510031372768 (0x100000014353B1E0);
            // 0x028FC58C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028FC590: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028FC594: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028FC598: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028FC59C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028FC5A0: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_15;
            return val_15;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_9:
            // 0x028FC5A4: MOV x8, sp                 | X8 = 1152921510031372736 (0x100000014353B1C0);//ML01
            // 0x028FC5A8: MOV x1, x24                | X1 = 1152921504875589632 (0x100000001004B000);//ML01
            // 0x028FC5AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FC5B0: LDR x0, [sp]               | X0 = val_16;                             //  find_add[1152921510031360848]
            // 0x028FC5B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x028FC5B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC5BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x028FC5C0: MOV x0, sp                 | X0 = 1152921510031372736 (0x100000014353B1C0);//ML01
            // 0x028FC5C4: BL #0x299a140              | 
            // 0x028FC5C8: MOV x19, x0                | X19 = 1152921510031372736 (0x100000014353B1C0);//ML01
            val_23 = ;
            // 0x028FC5CC: ADD x0, sp, #8             | X0 = (1152921510031372736 + 8) = 1152921510031372744 (0x100000014353B1C8);
            // 0x028FC5D0: B #0x28fc5e8               |  goto label_26;                         
            goto label_26;
            // 0x028FC5D4: MOV x19, x0                | X19 = 1152921510031372744 (0x100000014353B1C8);//ML01
            val_23;
            // 0x028FC5D8: ADD x0, sp, #0x10          | X0 = (1152921510031372736 + 16) = 1152921510031372752 (0x100000014353B1D0);
            // 0x028FC5DC: B #0x28fc5e8               |  goto label_26;                         
            goto label_26;
            // 0x028FC5E0: MOV x19, x0                | X19 = 1152921510031372752 (0x100000014353B1D0);//ML01
            val_23;
            // 0x028FC5E4: ADD x0, sp, #0x18          | X0 = (1152921510031372736 + 24) = 1152921510031372760 (0x100000014353B1D8);
            label_26:
            // 0x028FC5E8: BL #0x299a140              | 
            // 0x028FC5EC: MOV x0, x19                | X0 = 1152921510031372752 (0x100000014353B1D0);//ML01
            // 0x028FC5F0: BL #0x980800               | X0 = sub_980800( ?? 0x100000014353B1D0, ????);
            // 0x028FC5F4: MOV x19, x0                | X19 = 1152921510031372752 (0x100000014353B1D0);//ML01
            // 0x028FC5F8: MOV x0, sp                 | X0 = 1152921510031372736 (0x100000014353B1C0);//ML01
            // 0x028FC5FC: B #0x28fc5e8               |  goto label_26;                         
            goto label_26;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FC600 (42976768), len: 1756  VirtAddr: 0x028FC600 RVA: 0x028FC600 token: 100663673 methodIndex: 29718 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Play_6(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            //  | 
            var val_19;
            //  | 
            var val_24;
            //  | 
            var val_26;
            //  | 
            var val_27;
            //  | 
            var val_29;
            //  | 
            var val_30;
            //  | 
            var val_31;
            //  | 
            var val_33;
            //  | 
            var val_34;
            //  | 
            var val_35;
            //  | 
            AnimationOrTween.Direction val_36;
            //  | 
            string val_37;
            //  | 
            var val_38;
            //  | 
            var val_39;
            //  | 
            var val_40;
            //  | 
            var val_41;
            //  | 
            var val_42;
            // 0x028FC600: STP x28, x27, [sp, #-0x60]! | stack[1152921510031611728] = ???;  stack[1152921510031611736] = ???;  //  dest_result_addr=1152921510031611728 |  dest_result_addr=1152921510031611736
            // 0x028FC604: STP x26, x25, [sp, #0x10]  | stack[1152921510031611744] = ???;  stack[1152921510031611752] = ???;  //  dest_result_addr=1152921510031611744 |  dest_result_addr=1152921510031611752
            // 0x028FC608: STP x24, x23, [sp, #0x20]  | stack[1152921510031611760] = ???;  stack[1152921510031611768] = ???;  //  dest_result_addr=1152921510031611760 |  dest_result_addr=1152921510031611768
            // 0x028FC60C: STP x22, x21, [sp, #0x30]  | stack[1152921510031611776] = ???;  stack[1152921510031611784] = ???;  //  dest_result_addr=1152921510031611776 |  dest_result_addr=1152921510031611784
            // 0x028FC610: STP x20, x19, [sp, #0x40]  | stack[1152921510031611792] = ???;  stack[1152921510031611800] = ???;  //  dest_result_addr=1152921510031611792 |  dest_result_addr=1152921510031611800
            // 0x028FC614: STP x29, x30, [sp, #0x50]  | stack[1152921510031611808] = ???;  stack[1152921510031611816] = ???;  //  dest_result_addr=1152921510031611808 |  dest_result_addr=1152921510031611816
            // 0x028FC618: ADD x29, sp, #0x50         | X29 = (1152921510031611728 + 80) = 1152921510031611808 (0x10000001435757A0);
            // 0x028FC61C: SUB sp, sp, #0x40          | SP = (1152921510031611728 - 64) = 1152921510031611664 (0x1000000143575710);
            // 0x028FC620: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FC624: LDRB w8, [x20, #0xa6a]     | W8 = (bool)static_value_037B8A6A;       
            // 0x028FC628: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028FC62C: MOV x22, x2                | X22 = X2;//m1                           
            // 0x028FC630: MOV x21, x1                | X21 = X1;//m1                           
            val_33 = X1;
            // 0x028FC634: TBNZ w8, #0, #0x28fc650    | if (static_value_037B8A6A == true) goto label_0;
            // 0x028FC638: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x028FC63C: LDR x8, [x8, #0xa38]       | X8 = 0x2B8A970;                         
            // 0x028FC640: LDR w0, [x8]               | W0 = 0x11A;                             
            // 0x028FC644: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A, ????);      
            // 0x028FC648: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FC64C: STRB w8, [x20, #0xa6a]     | static_value_037B8A6A = true;            //  dest_result_addr=58428010
            label_0:
            // 0x028FC650: CBNZ x21, #0x28fc658       | if (X1 != 0) goto label_1;              
            if(val_33 != 0)
            {
                goto label_1;
            }
            // 0x028FC654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11A, ????);      
            label_1:
            // 0x028FC658: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC65C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC660: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = val_33.AppDomain;
            // 0x028FC664: MOV x23, x0                | X23 = val_1;//m1                        
            // 0x028FC668: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC66C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC670: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x028FC674: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC678: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC67C: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FC680: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC684: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC688: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028FC68C: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC690: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_3 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC694: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x028FC698: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x028FC69C: ADRP x9, #0x35bc000        | X9 = 56344576 (0x35BC000);              
            // 0x028FC6A0: MOV x25, x0                | X25 = val_3;//m1                        
            val_34 = val_3;
            // 0x028FC6A4: LDR x8, [x8]               | X8 = typeof(System.Type);               
            // 0x028FC6A8: LDR x9, [x9, #0x138]       | X9 = 1152921504875696128;               
            // 0x028FC6AC: LDR x24, [x9]              | X24 = typeof(AnimationOrTween.DisableCondition);
            // 0x028FC6B0: LDRB w9, [x8, #0x10a]      | W9 = System.Type.__il2cppRuntimeField_10A;
            // 0x028FC6B4: TBZ w9, #0, #0x28fc6c8     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x028FC6B8: LDR w9, [x8, #0xbc]        | W9 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x028FC6BC: CBNZ w9, #0x28fc6c8        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x028FC6C0: MOV x0, x8                 | X0 = 1152921504609562624 (0x1000000000297000);//ML01
            // 0x028FC6C4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_3:
            // 0x028FC6C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC6CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC6D0: MOV x1, x24                | X1 = 1152921504875696128 (0x1000000010065000);//ML01
            // 0x028FC6D4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_4 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC6D8: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028FC6DC: LDR x8, [x8, #0x7a0]       | X8 = 1152921504826228736;               
            // 0x028FC6E0: MOV x24, x0                | X24 = val_4;//m1                        
            // 0x028FC6E4: LDR x8, [x8]               | X8 = typeof(ILRuntime.Runtime.Stack.StackObject);
            // 0x028FC6E8: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_10A;
            // 0x028FC6EC: TBZ w9, #0, #0x28fc700     | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x028FC6F0: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished;
            // 0x028FC6F4: CBNZ w9, #0x28fc700        | if (ILRuntime.Runtime.Stack.StackObject.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x028FC6F8: MOV x0, x8                 | X0 = 1152921504826228736 (0x100000000D138000);//ML01
            // 0x028FC6FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Runtime.Stack.StackObject), ????);
            label_5:
            // 0x028FC700: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC704: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FC708: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FC70C: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FC710: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FC714: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_5 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FC718: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x028FC71C: LDR x8, [x8, #0x4e8]       | X8 = 1152921504782352384;               
            // 0x028FC720: MOV x26, x0                | X26 = val_5;//m1                        
            // 0x028FC724: LDR x8, [x8]               | X8 = typeof(ILRuntime.CLR.Utils.Extensions);
            // 0x028FC728: LDRB w9, [x8, #0x10a]      | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_10A;
            // 0x028FC72C: TBZ w9, #0, #0x28fc740     | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_has_cctor == 0) goto label_7;
            // 0x028FC730: LDR w9, [x8, #0xbc]        | W9 = ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished;
            // 0x028FC734: CBNZ w9, #0x28fc740        | if (ILRuntime.CLR.Utils.Extensions.__il2cppRuntimeField_cctor_finished != 0) goto label_7;
            // 0x028FC738: MOV x0, x8                 | X0 = 1152921504782352384 (0x100000000A760000);//ML01
            // 0x028FC73C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.CLR.Utils.Extensions), ????);
            label_7:
            // 0x028FC740: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC744: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC748: MOV x1, x24                | X1 = val_4;//m1                         
            // 0x028FC74C: MOV x2, x26                | X2 = val_5;//m1                         
            // 0x028FC750: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            object val_6 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_4);
            // 0x028FC754: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x028FC758: LDR x8, [x8, #0x278]       | X8 = 1152921504875696128;               
            // 0x028FC75C: MOV x26, x0                | X26 = val_6;//m1                        
            val_35 = val_6;
            // 0x028FC760: LDR x24, [x8]              | X24 = typeof(AnimationOrTween.DisableCondition);
            // 0x028FC764: CBNZ x26, #0x28fc76c       | if (val_6 != null) goto label_8;        
            if(val_35 != null)
            {
                goto label_8;
            }
            // 0x028FC768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_8:
            // 0x028FC76C: LDR x8, [x26]              | X8 = typeof(System.Object);             
            // 0x028FC770: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FC774: LDR x8, [x24, #0x30]       | X8 = AnimationOrTween.DisableCondition.__il2cppRuntimeField_element_class;
            // 0x028FC778: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.DisableCondition.__il2cppRuntimeField_element_class)
            // 0x028FC77C: B.NE #0x28fcc14            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.DisableCondition.__il2cppRuntimeField_element_class) goto label_9;
            // 0x028FC780: MOV x0, x26                | X0 = val_6;//m1                         
            // 0x028FC784: BL #0x27bc4e8              | val_6.System.IDisposable.Dispose();     
            val_35.System.IDisposable.Dispose();
            // 0x028FC788: LDR w24, [x0]              | W24 = typeof(System.Object);            
            // 0x028FC78C: CBNZ x21, #0x28fc794       | if (X1 != 0) goto label_10;             
            if(val_33 != 0)
            {
                goto label_10;
            }
            // 0x028FC790: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_10:
            // 0x028FC794: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC798: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC79C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FC7A0: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FC7A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC7A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC7AC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028FC7B0: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC7B4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_7 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC7B8: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x028FC7BC: LDR x8, [x8, #0x8f8]       | X8 = 1152921504875642880;               
            // 0x028FC7C0: MOV x26, x0                | X26 = val_7;//m1                        
            val_35 = val_7;
            // 0x028FC7C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC7C8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC7CC: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.EnableCondition);
            // 0x028FC7D0: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_8 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC7D4: MOV x25, x0                | X25 = val_8;//m1                        
            // 0x028FC7D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC7DC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FC7E0: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x028FC7E4: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FC7E8: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FC7EC: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_9 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FC7F0: MOV x2, x0                 | X2 = val_9;//m1                         
            // 0x028FC7F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC7F8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC7FC: MOV x1, x25                | X1 = val_8;//m1                         
            // 0x028FC800: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            object val_10 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_8);
            // 0x028FC804: ADRP x8, #0x35bd000        | X8 = 56348672 (0x35BD000);              
            // 0x028FC808: LDR x8, [x8, #0x5f8]       | X8 = 1152921504875642880;               
            // 0x028FC80C: MOV x27, x0                | X27 = val_10;//m1                       
            // 0x028FC810: LDR x25, [x8]              | X25 = typeof(AnimationOrTween.EnableCondition);
            val_34 = null;
            // 0x028FC814: CBNZ x27, #0x28fc81c       | if (val_10 != null) goto label_11;      
            if(val_10 != null)
            {
                goto label_11;
            }
            // 0x028FC818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_11:
            // 0x028FC81C: LDR x8, [x27]              | X8 = typeof(System.Object);             
            // 0x028FC820: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FC824: LDR x8, [x25, #0x30]       | X8 = AnimationOrTween.EnableCondition.__il2cppRuntimeField_element_class;
            // 0x028FC828: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.EnableCondition.__il2cppRuntimeField_element_class)
            // 0x028FC82C: B.NE #0x28fcc38            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.EnableCondition.__il2cppRuntimeField_element_class) goto label_12;
            // 0x028FC830: MOV x0, x27                | X0 = val_10;//m1                        
            // 0x028FC834: BL #0x27bc4e8              | val_10.System.IDisposable.Dispose();    
            val_10.System.IDisposable.Dispose();
            // 0x028FC838: LDR w25, [x0]              | W25 = typeof(System.Object);            
            // 0x028FC83C: CBNZ x21, #0x28fc844       | if (X1 != 0) goto label_13;             
            if(val_33 != 0)
            {
                goto label_13;
            }
            // 0x028FC840: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
            label_13:
            // 0x028FC844: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC848: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC84C: MOV x1, x26                | X1 = val_7;//m1                         
            // 0x028FC850: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FC854: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC858: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC85C: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028FC860: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC864: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_11 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC868: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x028FC86C: LDR x8, [x8, #0x2c0]       | X8 = 1152921504875589632;               
            // 0x028FC870: MOV x27, x0                | X27 = val_11;//m1                       
            // 0x028FC874: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC878: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC87C: LDR x1, [x8]               | X1 = typeof(AnimationOrTween.Direction);
            // 0x028FC880: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_12 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC884: MOV x26, x0                | X26 = val_12;//m1                       
            // 0x028FC888: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC88C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FC890: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x028FC894: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FC898: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FC89C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_13 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FC8A0: MOV x2, x0                 | X2 = val_13;//m1                        
            // 0x028FC8A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC8A8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC8AC: MOV x1, x26                | X1 = val_12;//m1                        
            // 0x028FC8B0: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            object val_14 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_12);
            // 0x028FC8B4: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x028FC8B8: LDR x8, [x8, #0xed8]       | X8 = 1152921504875589632;               
            // 0x028FC8BC: MOV x28, x0                | X28 = val_14;//m1                       
            // 0x028FC8C0: LDR x26, [x8]              | X26 = typeof(AnimationOrTween.Direction);
            val_35 = null;
            // 0x028FC8C4: CBNZ x28, #0x28fc8cc       | if (val_14 != null) goto label_14;      
            if(val_14 != null)
            {
                goto label_14;
            }
            // 0x028FC8C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_14:
            // 0x028FC8CC: LDR x8, [x28]              | X8 = typeof(System.Object);             
            // 0x028FC8D0: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FC8D4: LDR x8, [x26, #0x30]       | X8 = AnimationOrTween.Direction.__il2cppRuntimeField_element_class;
            // 0x028FC8D8: CMP x0, x8                 | STATE = COMPARE(System.Object.__il2cppRuntimeField_element_class, AnimationOrTween.Direction.__il2cppRuntimeField_element_class)
            // 0x028FC8DC: B.NE #0x28fcc5c            | if (System.Object.__il2cppRuntimeField_element_class != AnimationOrTween.Direction.__il2cppRuntimeField_element_class) goto label_15;
            // 0x028FC8E0: MOV x0, x28                | X0 = val_14;//m1                        
            // 0x028FC8E4: BL #0x27bc4e8              | val_14.System.IDisposable.Dispose();    
            val_14.System.IDisposable.Dispose();
            // 0x028FC8E8: LDR w26, [x0]              | W26 = typeof(System.Object);            
            // 0x028FC8EC: CBNZ x21, #0x28fc8f4       | if (X1 != 0) goto label_16;             
            if(val_33 != 0)
            {
                goto label_16;
            }
            // 0x028FC8F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_14, ????);     
            label_16:
            // 0x028FC8F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC8F8: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC8FC: MOV x1, x27                | X1 = val_11;//m1                        
            // 0x028FC900: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FC904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC908: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC90C: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x028FC910: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC914: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_15 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC918: ADRP x8, #0x3607000        | X8 = 56651776 (0x3607000);              
            // 0x028FC91C: LDR x8, [x8, #0xbb8]       | X8 = 1152921504608284672;               
            // 0x028FC920: MOV x28, x0                | X28 = val_15;//m1                       
            // 0x028FC924: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC928: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC92C: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FC930: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_16 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC934: MOV x27, x0                | X27 = val_16;//m1                       
            // 0x028FC938: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC93C: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FC940: MOV x1, x28                | X1 = val_15;//m1                        
            // 0x028FC944: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FC948: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FC94C: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_17 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FC950: MOV x2, x0                 | X2 = val_17;//m1                        
            // 0x028FC954: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC958: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC95C: MOV x1, x27                | X1 = val_16;//m1                        
            // 0x028FC960: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            object val_18 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_16);
            // 0x028FC964: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_36 = 0;
            // 0x028FC968: CBZ x0, #0x28fc9b0         | if (val_18 == null) goto label_18;      
            if(val_18 == null)
            {
                goto label_18;
            }
            // 0x028FC96C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028FC970: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028FC974: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FC978: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FC97C: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(System.String))
            // 0x028FC980: MOV x27, x0                | X27 = val_18;//m1                       
            val_36 = val_18;
            // 0x028FC984: B.EQ #0x28fc9b0            | if (typeof(System.Object) == null) goto label_18;
            if(null == null)
            {
                goto label_18;
            }
            // 0x028FC988: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FC98C: ADD x8, sp, #0x20          | X8 = (1152921510031611664 + 32) = 1152921510031611696 (0x1000000143575730);
            // 0x028FC990: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FC994: LDR x0, [sp, #0x20]        | X0 = val_19;                             //  find_add[1152921510031599824]
            // 0x028FC998: BL #0x27af090              | X0 = sub_27AF090( ?? val_19, ????);     
            // 0x028FC99C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FC9A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_19, ????);     
            // 0x028FC9A4: ADD x0, sp, #0x20          | X0 = (1152921510031611664 + 32) = 1152921510031611696 (0x1000000143575730);
            // 0x028FC9A8: BL #0x299a140              | 
            // 0x028FC9AC: MOV x27, xzr               | X27 = 0 (0x0);//ML01                    
            val_36 = 0;
            label_18:
            // 0x028FC9B0: CBNZ x21, #0x28fc9b8       | if (X1 != 0) goto label_19;             
            if(val_33 != 0)
            {
                goto label_19;
            }
            // 0x028FC9B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143575730, ????);
            label_19:
            // 0x028FC9B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC9BC: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FC9C0: MOV x1, x28                | X1 = val_15;//m1                        
            // 0x028FC9C4: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FC9C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC9CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FC9D0: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x028FC9D4: MOV x1, x22                | X1 = X2;//m1                            
            // 0x028FC9D8: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            ILRuntime.Runtime.Stack.StackObject* val_20 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  null, b:  0);
            // 0x028FC9DC: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x028FC9E0: LDR x8, [x8, #0x390]       | X8 = 1152921504724152320;               
            // 0x028FC9E4: MOV x22, x0                | X22 = val_20;//m1                       
            // 0x028FC9E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FC9EC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FC9F0: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animator);      
            // 0x028FC9F4: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_21 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x028FC9F8: MOV x28, x0                | X28 = val_21;//m1                       
            // 0x028FC9FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FCA00: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x028FCA04: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x028FCA08: MOV x2, x23                | X2 = val_1;//m1                         
            // 0x028FCA0C: MOV x3, x19                | X3 = X3;//m1                            
            // 0x028FCA10: BL #0x1f90d28              | X0 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            object val_22 = ILRuntime.Runtime.Stack.StackObject.ToObject(esp:  null, appdomain:  null, mStack:  null);
            // 0x028FCA14: MOV x2, x0                 | X2 = val_22;//m1                        
            // 0x028FCA18: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FCA1C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FCA20: MOV x1, x28                | X1 = val_21;//m1                        
            // 0x028FCA24: BL #0x10ed724              | X0 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_21);
            object val_23 = ILRuntime.CLR.Utils.Extensions.CheckCLRTypes(pt:  0, obj:  val_21);
            // 0x028FCA28: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_37 = 0;
            // 0x028FCA2C: CBZ x0, #0x28fca74         | if (val_23 == null) goto label_21;      
            if(val_23 == null)
            {
                goto label_21;
            }
            // 0x028FCA30: ADRP x8, #0x3632000        | X8 = 56827904 (0x3632000);              
            // 0x028FCA34: LDR x8, [x8, #0xce0]       | X8 = 1152921504724152320;               
            // 0x028FCA38: LDR x1, [x8]               | X1 = typeof(UnityEngine.Animator);      
            // 0x028FCA3C: LDR x8, [x0]               | X8 = typeof(System.Object);             
            // 0x028FCA40: CMP x8, x1                 | STATE = COMPARE(typeof(System.Object), typeof(UnityEngine.Animator))
            // 0x028FCA44: MOV x23, x0                | X23 = val_23;//m1                       
            val_37 = val_23;
            // 0x028FCA48: B.EQ #0x28fca74            | if (typeof(System.Object) == null) goto label_21;
            if(null == null)
            {
                goto label_21;
            }
            // 0x028FCA4C: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x028FCA50: ADD x8, sp, #0x28          | X8 = (1152921510031611664 + 40) = 1152921510031611704 (0x1000000143575738);
            // 0x028FCA54: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FCA58: LDR x0, [sp, #0x28]        | X0 = val_24;                             //  find_add[1152921510031599824]
            // 0x028FCA5C: BL #0x27af090              | X0 = sub_27AF090( ?? val_24, ????);     
            // 0x028FCA60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCA64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_24, ????);     
            // 0x028FCA68: ADD x0, sp, #0x28          | X0 = (1152921510031611664 + 40) = 1152921510031611704 (0x1000000143575738);
            // 0x028FCA6C: BL #0x299a140              | 
            // 0x028FCA70: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_37 = 0;
            label_21:
            // 0x028FCA74: CBNZ x21, #0x28fca7c       | if (X1 != 0) goto label_22;             
            if(val_33 != 0)
            {
                goto label_22;
            }
            // 0x028FCA78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143575738, ????);
            label_22:
            // 0x028FCA7C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x028FCA80: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FCA84: MOV x1, x22                | X1 = val_20;//m1                        
            // 0x028FCA88: BL #0x1f8e3a4              | X1.Free(esp:  null);                    
            val_33.Free(esp:  null);
            // 0x028FCA8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FCA90: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x028FCA94: MOV x1, x23                | X1 = 0 (0x0);//ML01                     
            // 0x028FCA98: MOV x2, x27                | X2 = 0 (0x0);//ML01                     
            // 0x028FCA9C: MOV w3, w26                | W3 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FCAA0: MOV w4, w25                | W4 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FCAA4: MOV w5, w24                | W5 = 1152921504606900224 (0x100000000000D000);//ML01
            // 0x028FCAA8: BL #0xb1e304               | X0 = ActiveAnimation.Play(anim:  0, clipName:  val_37, playDirection:  val_36, enableBeforePlay:  1152921504606900224, disableCondition:  1152921504606900224);
            ActiveAnimation val_25 = ActiveAnimation.Play(anim:  0, clipName:  val_37, playDirection:  val_36, enableBeforePlay:  1152921504606900224, disableCondition:  1152921504606900224);
            // 0x028FCAAC: ADRP x23, #0x365d000       | X23 = 57004032 (0x365D000);             
            // 0x028FCAB0: LDR x23, [x23, #0xa58]     | X23 = 1152921504824418304;              
            val_38 = 1152921504824418304;
            // 0x028FCAB4: MOV x22, x0                | X22 = val_25;//m1                       
            // 0x028FCAB8: LDR x1, [x23]              | X1 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_39 = null;
            // 0x028FCABC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028FCAC0: CBZ x0, #0x28fcb54         | if (val_25 == null) goto label_23;      
            if(val_25 == null)
            {
                goto label_23;
            }
            // 0x028FCAC4: CBZ x22, #0x28fcb6c        | if (val_25 == null) goto label_24;      
            if(val_25 == null)
            {
                goto label_24;
            }
            // 0x028FCAC8: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            // 0x028FCACC: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x028FCAD0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FCAD4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028FCAD8: CBNZ x0, #0x28fcb0c        | if (val_25 != null) goto label_25;      
            if(val_25 != null)
            {
                goto label_25;
            }
            // 0x028FCADC: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FCAE0: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FCAE4: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FCAE8: ADD x8, sp, #0x30          | X8 = (1152921510031611664 + 48) = 1152921510031611712 (0x1000000143575740);
            // 0x028FCAEC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FCAF0: LDR x0, [sp, #0x30]        | X0 = val_26;                             //  find_add[1152921510031599824]
            // 0x028FCAF4: BL #0x27af090              | X0 = sub_27AF090( ?? val_26, ????);     
            // 0x028FCAF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCAFC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_26, ????);     
            // 0x028FCB00: ADD x0, sp, #0x30          | X0 = (1152921510031611664 + 48) = 1152921510031611712 (0x1000000143575740);
            // 0x028FCB04: BL #0x299a140              | 
            // 0x028FCB08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143575740, ????);
            label_25:
            // 0x028FCB0C: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_33 = null;
            // 0x028FCB10: MOV x0, x22                | X0 = val_25;//m1                        
            // 0x028FCB14: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_39 = val_33;
            // 0x028FCB18: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? val_25, ????);     
            // 0x028FCB1C: MOV x23, x0                | X23 = val_25;//m1                       
            val_38 = val_25;
            // 0x028FCB20: CBNZ x23, #0x28fcb78       | if (val_25 != null) goto label_26;      
            if(val_38 != null)
            {
                goto label_26;
            }
            // 0x028FCB24: LDR x8, [x22]              | X8 = typeof(ActiveAnimation);           
            // 0x028FCB28: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            // 0x028FCB2C: LDR x0, [x8, #0x30]        | X0 = ActiveAnimation.__il2cppRuntimeField_element_class;
            // 0x028FCB30: ADD x8, sp, #0x38          | X8 = (1152921510031611664 + 56) = 1152921510031611720 (0x1000000143575748);
            // 0x028FCB34: BL #0x27d96d4              | X0 = sub_27D96D4( ?? ActiveAnimation.__il2cppRuntimeField_element_class, ????);
            // 0x028FCB38: LDR x0, [sp, #0x38]        | X0 = val_27;                             //  find_add[1152921510031599824]
            // 0x028FCB3C: BL #0x27af090              | X0 = sub_27AF090( ?? val_27, ????);     
            // 0x028FCB40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_39 = 0;
            // 0x028FCB44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_27, ????);     
            // 0x028FCB48: ADD x0, sp, #0x38          | X0 = (1152921510031611664 + 56) = 1152921510031611720 (0x1000000143575748);
            // 0x028FCB4C: BL #0x299a140              | 
            // 0x028FCB50: B #0x28fcb74               |  goto label_27;                         
            goto label_27;
            label_23:
            // 0x028FCB54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FCB58: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FCB5C: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FCB60: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028FCB64: MOV x3, x22                | X3 = val_25;//m1                        
            // 0x028FCB68: B #0x28fcbec               |  goto label_28;                         
            goto label_28;
            label_24:
            // 0x028FCB6C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
            // 0x028FCB70: LDR x21, [x23]             | X21 = typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType);
            val_33 = null;
            label_27:
            // 0x028FCB74: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
            val_38 = 0;
            label_26:
            // 0x028FCB78: LDR x8, [x23]              | X8 = 0x10102464C457F;                   
            // 0x028FCB7C: LDRH w9, [x8, #0x102]      | W9 = mem[282584257676929];              
            // 0x028FCB80: CBZ x9, #0x28fcbac         | if (mem[282584257676929] == 0) goto label_29;
            if(mem[282584257676929] == 0)
            {
                goto label_29;
            }
            // 0x028FCB84: LDR x10, [x8, #0x98]       | X10 = mem[282584257676823];             
            var val_32 = mem[282584257676823];
            // 0x028FCB88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_33 = 0;
            // 0x028FCB8C: ADD x10, x10, #8           | X10 = (mem[282584257676823] + 8);       
            val_32 = val_32 + 8;
            label_31:
            // 0x028FCB90: LDUR x12, [x10, #-8]       | X12 = (mem[282584257676823] + 8) + -8;  
            // 0x028FCB94: CMP x12, x21               | STATE = COMPARE((mem[282584257676823] + 8) + -8, typeof(ILRuntime.Runtime.Enviorment.CrossBindingAdaptorType))
            // 0x028FCB98: B.EQ #0x28fcbc0            | if ((mem[282584257676823] + 8) + -8 == val_33) goto label_30;
            if(((mem[282584257676823] + 8) + -8) == val_33)
            {
                goto label_30;
            }
            // 0x028FCB9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_33 = val_33 + 1;
            // 0x028FCBA0: ADD x10, x10, #0x10        | X10 = ((mem[282584257676823] + 8) + 16);
            val_32 = val_32 + 16;
            // 0x028FCBA4: CMP x11, x9                | STATE = COMPARE((0 + 1), mem[282584257676929])
            // 0x028FCBA8: B.LO #0x28fcb90            | if (0 < mem[282584257676929]) goto label_31;
            if(val_33 < mem[282584257676929])
            {
                goto label_31;
            }
            label_29:
            // 0x028FCBAC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028FCBB0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            val_40 = val_38;
            // 0x028FCBB4: MOV x1, x21                | X1 = 1152921504824418304 (0x100000000CF7E000);//ML01
            val_39 = val_33;
            // 0x028FCBB8: BL #0x2776c24              | X0 = sub_2776C24( ?? 0x0, ????);        
            // 0x028FCBBC: B #0x28fcbcc               |  goto label_32;                         
            goto label_32;
            label_30:
            // 0x028FCBC0: LDR w9, [x10]              | W9 = (mem[282584257676823] + 8);        
            // 0x028FCBC4: ADD x8, x8, x9, lsl #4     | X8 = (val_38 + ((mem[282584257676823] + 8)) << 4);
            val_38 = val_38 + (((mem[282584257676823] + 8)) << 4);
            // 0x028FCBC8: ADD x0, x8, #0x110         | X0 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272);
            val_40 = val_38 + 272;
            label_32:
            // 0x028FCBCC: LDP x8, x1, [x0]           | X8 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272); X1 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272) + 8; //  | 
            // 0x028FCBD0: MOV x0, x23                | X0 = 0 (0x0);//ML01                     
            // 0x028FCBD4: BLR x8                     | X0 = ((val_38 + ((mem[282584257676823] + 8)) << 4) + 272)();
            // 0x028FCBD8: MOV x3, x0                 | X3 = 0 (0x0);//ML01                     
            // 0x028FCBDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FCBE0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FCBE4: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FCBE8: MOV x2, x19                | X2 = X3;//m1                            
            label_28:
            // 0x028FCBEC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FCBF0: BL #0x1f657ec              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            ILRuntime.Runtime.Stack.StackObject* val_28 = ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  null, mStack:  null, obj:  null, isBox:  false);
            // 0x028FCBF4: SUB sp, x29, #0x50         | SP = (1152921510031611808 - 80) = 1152921510031611728 (0x1000000143575750);
            // 0x028FCBF8: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x028FCBFC: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x028FCC00: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x028FCC04: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x028FCC08: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x028FCC0C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x028FCC10: RET                        |  return (ILRuntime.Runtime.Stack.StackObject*)val_28;
            return val_28;
            //  |  // // {name=val_0, type=ILRuntime.Runtime.Stack.StackObject*, size=8, nGRN=0 }
            label_9:
            // 0x028FCC14: ADD x8, sp, #8             | X8 = (1152921510031611664 + 8) = 1152921510031611672 (0x1000000143575718);
            // 0x028FCC18: MOV x1, x24                | X1 = 1152921504875696128 (0x1000000010065000);//ML01
            // 0x028FCC1C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x028FCC20: LDR x0, [sp, #8]           | X0 = val_29;                             //  find_add[1152921510031599824]
            // 0x028FCC24: BL #0x27af090              | X0 = sub_27AF090( ?? val_29, ????);     
            // 0x028FCC28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCC2C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_29, ????);     
            // 0x028FCC30: ADD x0, sp, #8             | X0 = (1152921510031611664 + 8) = 1152921510031611672 (0x1000000143575718);
            // 0x028FCC34: BL #0x299a140              | 
            label_12:
            // 0x028FCC38: ADD x8, sp, #0x10          | X8 = (1152921510031611664 + 16) = 1152921510031611680 (0x1000000143575720);
            // 0x028FCC3C: MOV x1, x25                | X1 = val_3;//m1                         
            // 0x028FCC40: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143575718, ????);
            // 0x028FCC44: LDR x0, [sp, #0x10]        | X0 = val_30;                             //  find_add[1152921510031599824]
            // 0x028FCC48: BL #0x27af090              | X0 = sub_27AF090( ?? val_30, ????);     
            // 0x028FCC4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCC50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_30, ????);     
            // 0x028FCC54: ADD x0, sp, #0x10          | X0 = (1152921510031611664 + 16) = 1152921510031611680 (0x1000000143575720);
            // 0x028FCC58: BL #0x299a140              | 
            label_15:
            // 0x028FCC5C: ADD x8, sp, #0x18          | X8 = (1152921510031611664 + 24) = 1152921510031611688 (0x1000000143575728);
            // 0x028FCC60: MOV x1, x26                | X1 = val_6;//m1                         
            // 0x028FCC64: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143575720, ????);
            // 0x028FCC68: LDR x0, [sp, #0x18]        | X0 = val_31;                             //  find_add[1152921510031599824]
            // 0x028FCC6C: BL #0x27af090              | X0 = sub_27AF090( ?? val_31, ????);     
            // 0x028FCC70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCC74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_31, ????);     
            // 0x028FCC78: ADD x0, sp, #0x18          | X0 = (1152921510031611664 + 24) = 1152921510031611688 (0x1000000143575728);
            // 0x028FCC7C: BL #0x299a140              | 
            // 0x028FCC80: MOV x19, x0                | X19 = 1152921510031611688 (0x1000000143575728);//ML01
            val_41;
            // 0x028FCC84: ADD x0, sp, #0x20          | X0 = (1152921510031611664 + 32) = 1152921510031611696 (0x1000000143575730);
            // 0x028FCC88: B #0x28fccac               |  goto label_38;                         
            goto label_38;
            // 0x028FCC8C: MOV x19, x0                | X19 = 1152921510031611696 (0x1000000143575730);//ML01
            val_41;
            // 0x028FCC90: ADD x0, sp, #0x28          | X0 = (1152921510031611664 + 40) = 1152921510031611704 (0x1000000143575738);
            // 0x028FCC94: B #0x28fccac               |  goto label_38;                         
            goto label_38;
            // 0x028FCC98: MOV x19, x0                | X19 = 1152921510031611704 (0x1000000143575738);//ML01
            val_41;
            // 0x028FCC9C: ADD x0, sp, #0x30          | X0 = (1152921510031611664 + 48) = 1152921510031611712 (0x1000000143575740);
            // 0x028FCCA0: B #0x28fccac               |  goto label_38;                         
            goto label_38;
            // 0x028FCCA4: MOV x19, x0                | X19 = 1152921510031611712 (0x1000000143575740);//ML01
            val_41;
            // 0x028FCCA8: ADD x0, sp, #0x38          | X0 = (1152921510031611664 + 56) = 1152921510031611720 (0x1000000143575748);
            label_38:
            // 0x028FCCAC: BL #0x299a140              | 
            // 0x028FCCB0: MOV x0, x19                | X0 = 1152921510031611712 (0x1000000143575740);//ML01
            // 0x028FCCB4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143575740, ????);
            // 0x028FCCB8: MOV x19, x0                | X19 = 1152921510031611712 (0x1000000143575740);//ML01
            // 0x028FCCBC: ADD x0, sp, #8             | X0 = (1152921510031611664 + 8) = 1152921510031611672 (0x1000000143575718);
            // 0x028FCCC0: B #0x28fccac               |  goto label_38;                         
            goto label_38;
            // 0x028FCCC4: MOV x19, x0                | X19 = 1152921510031611672 (0x1000000143575718);//ML01
            // 0x028FCCC8: ADD x0, sp, #0x10          | X0 = (1152921510031611664 + 16) = 1152921510031611680 (0x1000000143575720);
            // 0x028FCCCC: B #0x28fccac               |  goto label_38;                         
            goto label_38;
            // 0x028FCCD0: MOV x19, x0                | X19 = 1152921510031611680 (0x1000000143575720);//ML01
            // 0x028FCCD4: ADD x0, sp, #0x18          | X0 = (1152921510031611664 + 24) = 1152921510031611688 (0x1000000143575728);
            // 0x028FCCD8: B #0x28fccac               |  goto label_38;                         
            goto label_38;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FCCDC (42978524), len: 80  VirtAddr: 0x028FCCDC RVA: 0x028FCCDC token: 100663674 methodIndex: 29719 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_current_0(ref object o)
        {
            //
            // Disasemble & Code
            // 0x028FCCDC: STP x20, x19, [sp, #-0x20]! | stack[1152921510031809728] = ???;  stack[1152921510031809736] = ???;  //  dest_result_addr=1152921510031809728 |  dest_result_addr=1152921510031809736
            // 0x028FCCE0: STP x29, x30, [sp, #0x10]  | stack[1152921510031809744] = ???;  stack[1152921510031809752] = ???;  //  dest_result_addr=1152921510031809744 |  dest_result_addr=1152921510031809752
            // 0x028FCCE4: ADD x29, sp, #0x10         | X29 = (1152921510031809728 + 16) = 1152921510031809744 (0x10000001435A5CD0);
            // 0x028FCCE8: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028FCCEC: LDRB w8, [x19, #0xa6b]     | W8 = (bool)static_value_037B8A6B;       
            // 0x028FCCF0: TBNZ w8, #0, #0x28fcd0c    | if (static_value_037B8A6B == true) goto label_0;
            // 0x028FCCF4: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x028FCCF8: LDR x8, [x8, #0x6e8]       | X8 = 0x2B8A954;                         
            // 0x028FCCFC: LDR w0, [x8]               | W0 = 0x113;                             
            // 0x028FCD00: BL #0x2782188              | X0 = sub_2782188( ?? 0x113, ????);      
            // 0x028FCD04: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FCD08: STRB w8, [x19, #0xa6b]     | static_value_037B8A6B = true;            //  dest_result_addr=58428011
            label_0:
            // 0x028FCD0C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x028FCD10: LDR x8, [x8, #0x698]       | X8 = 1152921504875483136;               
            // 0x028FCD14: LDR x8, [x8]               | X8 = typeof(ActiveAnimation);           
            // 0x028FCD18: LDR x8, [x8, #0xa0]        | X8 = ActiveAnimation.__il2cppRuntimeField_static_fields;
            // 0x028FCD1C: LDR x0, [x8]               | X0 = ActiveAnimation.current;           
            // 0x028FCD20: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FCD24: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FCD28: RET                        |  return (System.Object)ActiveAnimation.current;
            return (object)ActiveAnimation.current;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028FCD2C (42978604), len: 196  VirtAddr: 0x028FCD2C RVA: 0x028FCD2C token: 100663675 methodIndex: 29720 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_current_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            ActiveAnimation val_3;
            // 0x028FCD2C: STP x20, x19, [sp, #-0x20]! | stack[1152921510031933856] = ???;  stack[1152921510031933864] = ???;  //  dest_result_addr=1152921510031933856 |  dest_result_addr=1152921510031933864
            // 0x028FCD30: STP x29, x30, [sp, #0x10]  | stack[1152921510031933872] = ???;  stack[1152921510031933880] = ???;  //  dest_result_addr=1152921510031933872 |  dest_result_addr=1152921510031933880
            // 0x028FCD34: ADD x29, sp, #0x10         | X29 = (1152921510031933856 + 16) = 1152921510031933872 (0x10000001435C41B0);
            // 0x028FCD38: SUB sp, sp, #0x10          | SP = (1152921510031933856 - 16) = 1152921510031933840 (0x10000001435C4190);
            // 0x028FCD3C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FCD40: LDRB w8, [x20, #0xa6c]     | W8 = (bool)static_value_037B8A6C;       
            // 0x028FCD44: MOV x19, x2                | X19 = X2;//m1                           
            val_3 = X2;
            // 0x028FCD48: TBNZ w8, #0, #0x28fcd64    | if (static_value_037B8A6C == true) goto label_0;
            // 0x028FCD4C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x028FCD50: LDR x8, [x8, #0x478]       | X8 = 0x2B8A980;                         
            // 0x028FCD54: LDR w0, [x8]               | W0 = 0x11E;                             
            // 0x028FCD58: BL #0x2782188              | X0 = sub_2782188( ?? 0x11E, ????);      
            // 0x028FCD5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FCD60: STRB w8, [x20, #0xa6c]     | static_value_037B8A6C = true;            //  dest_result_addr=58428012
            label_0:
            // 0x028FCD64: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x028FCD68: LDR x8, [x8, #0x698]       | X8 = 1152921504875483136;               
            // 0x028FCD6C: LDR x1, [x8]               | X1 = typeof(ActiveAnimation);           
            // 0x028FCD70: LDR x20, [x1, #0xa0]       | X20 = ActiveAnimation.__il2cppRuntimeField_static_fields;
            // 0x028FCD74: CBZ x19, #0x28fcdc4        | if (X2 == 0) goto label_1;              
            if(val_3 == 0)
            {
                goto label_1;
            }
            // 0x028FCD78: LDR x8, [x19]              | X8 = X2;                                
            // 0x028FCD7C: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FCD80: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x028FCD84: CMP w10, w9                | STATE = COMPARE(X2 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FCD88: B.LO #0x28fcda0            | if (X2 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FCD8C: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x028FCD90: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FCD94: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FCD98: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FCD9C: B.EQ #0x28fcdc8            | if ((X2 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FCDA0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028FCDA4: ADD x8, sp, #8             | X8 = (1152921510031933840 + 8) = 1152921510031933848 (0x10000001435C4198);
            // 0x028FCDA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028FCDAC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510031921888]
            // 0x028FCDB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FCDB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCDB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FCDBC: ADD x0, sp, #8             | X0 = (1152921510031933840 + 8) = 1152921510031933848 (0x10000001435C4198);
            // 0x028FCDC0: BL #0x299a140              | 
            label_1:
            // 0x028FCDC4: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_3 = 0;
            label_3:
            // 0x028FCDC8: STR x19, [x20]             | ActiveAnimation.current = null;          //  dest_result_addr=1152921504875487232
            ActiveAnimation.current = val_3;
            // 0x028FCDCC: SUB sp, x29, #0x10         | SP = (1152921510031933872 - 16) = 1152921510031933856 (0x10000001435C41A0);
            // 0x028FCDD0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FCDD4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FCDD8: RET                        |  return;                                
            return;
            // 0x028FCDDC: MOV x19, x0                | 
            // 0x028FCDE0: ADD x0, sp, #8             | 
            // 0x028FCDE4: BL #0x299a140              | 
            // 0x028FCDE8: MOV x0, x19                | 
            // 0x028FCDEC: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FCDF0 (42978800), len: 288  VirtAddr: 0x028FCDF0 RVA: 0x028FCDF0 token: 100663676 methodIndex: 29721 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_onFinished_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028FCDF0: STP x20, x19, [sp, #-0x20]! | stack[1152921510032057984] = ???;  stack[1152921510032057992] = ???;  //  dest_result_addr=1152921510032057984 |  dest_result_addr=1152921510032057992
            // 0x028FCDF4: STP x29, x30, [sp, #0x10]  | stack[1152921510032058000] = ???;  stack[1152921510032058008] = ???;  //  dest_result_addr=1152921510032058000 |  dest_result_addr=1152921510032058008
            // 0x028FCDF8: ADD x29, sp, #0x10         | X29 = (1152921510032057984 + 16) = 1152921510032058000 (0x10000001435E2690);
            // 0x028FCDFC: SUB sp, sp, #0x10          | SP = (1152921510032057984 - 16) = 1152921510032057968 (0x10000001435E2670);
            // 0x028FCE00: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FCE04: LDRB w8, [x20, #0xa6d]     | W8 = (bool)static_value_037B8A6D;       
            // 0x028FCE08: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028FCE0C: TBNZ w8, #0, #0x28fce28    | if (static_value_037B8A6D == true) goto label_0;
            // 0x028FCE10: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x028FCE14: LDR x8, [x8, #0xb70]       | X8 = 0x2B8A960;                         
            // 0x028FCE18: LDR w0, [x8]               | W0 = 0x116;                             
            // 0x028FCE1C: BL #0x2782188              | X0 = sub_2782188( ?? 0x116, ????);      
            // 0x028FCE20: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FCE24: STRB w8, [x20, #0xa6d]     | static_value_037B8A6D = true;            //  dest_result_addr=58428013
            label_0:
            // 0x028FCE28: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x028FCE2C: LDR x19, [x19]             | X19 = X1;                               
            // 0x028FCE30: LDR x20, [x20, #0x698]     | X20 = 1152921504875483136;              
            // 0x028FCE34: CBZ x19, #0x28fce88        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028FCE38: LDR x8, [x19]              | X8 = X1;                                
            // 0x028FCE3C: LDR x1, [x20]              | X1 = typeof(ActiveAnimation);           
            // 0x028FCE40: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028FCE44: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FCE48: CMP w10, w9                | STATE = COMPARE(X1 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FCE4C: B.LO #0x28fce64            | if (X1 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FCE50: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028FCE54: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FCE58: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FCE5C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FCE60: B.EQ #0x28fce8c            | if ((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FCE64: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028FCE68: MOV x8, sp                 | X8 = 1152921510032057968 (0x10000001435E2670);//ML01
            // 0x028FCE6C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028FCE70: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510032046016]
            // 0x028FCE74: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FCE78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCE7C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FCE80: MOV x0, sp                 | X0 = 1152921510032057968 (0x10000001435E2670);//ML01
            // 0x028FCE84: BL #0x299a140              | 
            label_1:
            // 0x028FCE88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001435E2670, ????);
            label_3:
            // 0x028FCE8C: LDR x8, [x19]              | X8 = X1;                                
            // 0x028FCE90: LDR x1, [x20]              | X1 = typeof(ActiveAnimation);           
            // 0x028FCE94: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028FCE98: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FCE9C: CMP w10, w9                | STATE = COMPARE(X1 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FCEA0: B.LO #0x28fcecc            | if (X1 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028FCEA4: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028FCEA8: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FCEAC: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FCEB0: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FCEB4: B.NE #0x28fcecc            | if ((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028FCEB8: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x028FCEBC: SUB sp, x29, #0x10         | SP = (1152921510032058000 - 16) = 1152921510032057984 (0x10000001435E2680);
            // 0x028FCEC0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FCEC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FCEC8: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028FCECC: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028FCED0: ADD x8, sp, #8             | X8 = (1152921510032057968 + 8) = 1152921510032057976 (0x10000001435E2678);
            // 0x028FCED4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028FCED8: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510032046016]
            // 0x028FCEDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028FCEE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCEE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028FCEE8: ADD x0, sp, #8             | X0 = (1152921510032057968 + 8) = 1152921510032057976 (0x10000001435E2678);
            // 0x028FCEEC: BL #0x299a140              | 
            // 0x028FCEF0: MOV x19, x0                | X19 = 1152921510032057976 (0x10000001435E2678);//ML01
            // 0x028FCEF4: MOV x0, sp                 | X0 = 1152921510032057968 (0x10000001435E2670);//ML01
            label_6:
            // 0x028FCEF8: BL #0x299a140              | 
            // 0x028FCEFC: MOV x0, x19                | X0 = 1152921510032057976 (0x10000001435E2678);//ML01
            // 0x028FCF00: BL #0x980800               | X0 = sub_980800( ?? 0x10000001435E2678, ????);
            // 0x028FCF04: MOV x19, x0                | X19 = 1152921510032057976 (0x10000001435E2678);//ML01
            // 0x028FCF08: ADD x0, sp, #8             | X0 = (1152921510032057968 + 8) = 1152921510032057976 (0x10000001435E2678);
            // 0x028FCF0C: B #0x28fcef8               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FCF10 (42979088), len: 420  VirtAddr: 0x028FCF10 RVA: 0x028FCF10 token: 100663677 methodIndex: 29722 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_onFinished_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            // 0x028FCF10: STP x22, x21, [sp, #-0x30]! | stack[1152921510032182096] = ???;  stack[1152921510032182104] = ???;  //  dest_result_addr=1152921510032182096 |  dest_result_addr=1152921510032182104
            // 0x028FCF14: STP x20, x19, [sp, #0x10]  | stack[1152921510032182112] = ???;  stack[1152921510032182120] = ???;  //  dest_result_addr=1152921510032182112 |  dest_result_addr=1152921510032182120
            // 0x028FCF18: STP x29, x30, [sp, #0x20]  | stack[1152921510032182128] = ???;  stack[1152921510032182136] = ???;  //  dest_result_addr=1152921510032182128 |  dest_result_addr=1152921510032182136
            // 0x028FCF1C: ADD x29, sp, #0x20         | X29 = (1152921510032182096 + 32) = 1152921510032182128 (0x1000000143600B70);
            // 0x028FCF20: SUB sp, sp, #0x20          | SP = (1152921510032182096 - 32) = 1152921510032182064 (0x1000000143600B30);
            // 0x028FCF24: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028FCF28: LDRB w8, [x21, #0xa6e]     | W8 = (bool)static_value_037B8A6E;       
            // 0x028FCF2C: MOV x19, x2                | X19 = X2;//m1                           
            val_8 = X2;
            // 0x028FCF30: MOV x20, x1                | X20 = v;//m1                            
            // 0x028FCF34: TBNZ w8, #0, #0x28fcf50    | if (static_value_037B8A6E == true) goto label_0;
            // 0x028FCF38: ADRP x8, #0x365b000        | X8 = 56995840 (0x365B000);              
            // 0x028FCF3C: LDR x8, [x8, #0xfd8]       | X8 = 0x2B8A988;                         
            // 0x028FCF40: LDR w0, [x8]               | W0 = 0x120;                             
            // 0x028FCF44: BL #0x2782188              | X0 = sub_2782188( ?? 0x120, ????);      
            // 0x028FCF48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FCF4C: STRB w8, [x21, #0xa6e]     | static_value_037B8A6E = true;            //  dest_result_addr=58428014
            label_0:
            // 0x028FCF50: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x028FCF54: CBZ x20, #0x28fd008        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028FCF58: ADRP x21, #0x3676000       | X21 = 57106432 (0x3676000);             
            // 0x028FCF5C: LDR x21, [x21, #0x698]     | X21 = 1152921504875483136;              
            val_7 = 1152921504875483136;
            // 0x028FCF60: LDR x8, [x20]              | X8 = ;                                  
            // 0x028FCF64: LDR x1, [x21]              | X1 = typeof(ActiveAnimation);           
            // 0x028FCF68: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028FCF6C: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FCF70: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FCF74: B.LO #0x28fcf8c            | if (mem[null + 260] < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FCF78: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028FCF7C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FCF80: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FCF84: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FCF88: B.EQ #0x28fcfb4            | if ((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FCF8C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FCF90: ADD x8, sp, #8             | X8 = (1152921510032182064 + 8) = 1152921510032182072 (0x1000000143600B38);
            // 0x028FCF94: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028FCF98: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510032170144]
            // 0x028FCF9C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FCFA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCFA4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FCFA8: ADD x0, sp, #8             | X0 = (1152921510032182064 + 8) = 1152921510032182072 (0x1000000143600B38);
            // 0x028FCFAC: BL #0x299a140              | 
            // 0x028FCFB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143600B38, ????);
            label_3:
            // 0x028FCFB4: LDR x8, [x20]              | X8 = ;                                  
            // 0x028FCFB8: LDR x1, [x21]              | X1 = typeof(ActiveAnimation);           
            // 0x028FCFBC: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028FCFC0: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FCFC4: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FCFC8: B.LO #0x28fcfe0            | if (mem[null + 260] < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028FCFCC: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028FCFD0: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FCFD4: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FCFD8: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FCFDC: B.EQ #0x28fd010            | if ((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028FCFE0: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FCFE4: ADD x8, sp, #0x10          | X8 = (1152921510032182064 + 16) = 1152921510032182080 (0x1000000143600B40);
            // 0x028FCFE8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028FCFEC: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510032170144]
            // 0x028FCFF0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028FCFF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FCFF8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028FCFFC: ADD x0, sp, #0x10          | X0 = (1152921510032182064 + 16) = 1152921510032182080 (0x1000000143600B40);
            // 0x028FD000: BL #0x299a140              | 
            // 0x028FD004: B #0x28fd00c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028FD008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x120, ????);      
            label_6:
            // 0x028FD00C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_5:
            // 0x028FD010: CBZ x19, #0x28fd06c        | if (X2 == 0) goto label_7;              
            if(val_8 == 0)
            {
                goto label_7;
            }
            // 0x028FD014: ADRP x9, #0x361d000        | X9 = 56741888 (0x361D000);              
            // 0x028FD018: LDR x9, [x9, #0x460]       | X9 = 1152921504616644608;               
            // 0x028FD01C: LDR x8, [x19]              | X8 = X2;                                
            // 0x028FD020: LDR x1, [x9]               | X1 = typeof(System.Collections.Generic.List<T>);
            // 0x028FD024: LDRB w10, [x8, #0x104]     | W10 = X2 + 260;                         
            // 0x028FD028: LDRB w9, [x1, #0x104]      | W9 = System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD02C: CMP w10, w9                | STATE = COMPARE(X2 + 260, System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD030: B.LO #0x28fd048            | if (X2 + 260 < System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) goto label_8;
            // 0x028FD034: LDR x10, [x8, #0xb0]       | X10 = X2 + 176;                         
            // 0x028FD038: ADD x9, x10, x9, lsl #3    | X9 = (X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD03C: LDUR x9, [x9, #-8]         | X9 = (X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD040: CMP x9, x1                 | STATE = COMPARE((X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(System.Collections.Generic.List<T>))
            // 0x028FD044: B.EQ #0x28fd070            | if ((X2 + 176 + (System.Collections.Generic.List<T>.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_9;
            label_8:
            // 0x028FD048: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028FD04C: ADD x8, sp, #0x18          | X8 = (1152921510032182064 + 24) = 1152921510032182088 (0x1000000143600B48);
            // 0x028FD050: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028FD054: LDR x0, [sp, #0x18]        | X0 = val_6;                              //  find_add[1152921510032170144]
            // 0x028FD058: BL #0x27af090              | X0 = sub_27AF090( ?? val_6, ????);      
            // 0x028FD05C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD060: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_6, ????);      
            // 0x028FD064: ADD x0, sp, #0x18          | X0 = (1152921510032182064 + 24) = 1152921510032182088 (0x1000000143600B48);
            // 0x028FD068: BL #0x299a140              | 
            label_7:
            // 0x028FD06C: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_9:
            // 0x028FD070: STR x19, [x20, #0x18]      | mem[24] = 0x0;                           //  dest_result_addr=24
            mem[24] = val_8;
            // 0x028FD074: SUB sp, x29, #0x20         | SP = (1152921510032182128 - 32) = 1152921510032182096 (0x1000000143600B50);
            // 0x028FD078: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD07C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028FD080: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028FD084: RET                        |  return;                                
            return;
            // 0x028FD088: MOV x19, x0                | 
            // 0x028FD08C: ADD x0, sp, #8             | 
            // 0x028FD090: B #0x28fd0a8               | 
            // 0x028FD094: MOV x19, x0                | 
            // 0x028FD098: ADD x0, sp, #0x10          | 
            // 0x028FD09C: B #0x28fd0a8               | 
            // 0x028FD0A0: MOV x19, x0                | 
            // 0x028FD0A4: ADD x0, sp, #0x18          | 
            label_11:
            // 0x028FD0A8: BL #0x299a140              | 
            // 0x028FD0AC: MOV x0, x19                | 
            // 0x028FD0B0: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD0B4 (42979508), len: 288  VirtAddr: 0x028FD0B4 RVA: 0x028FD0B4 token: 100663678 methodIndex: 29723 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_eventReceiver_2(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028FD0B4: STP x20, x19, [sp, #-0x20]! | stack[1152921510032306240] = ???;  stack[1152921510032306248] = ???;  //  dest_result_addr=1152921510032306240 |  dest_result_addr=1152921510032306248
            // 0x028FD0B8: STP x29, x30, [sp, #0x10]  | stack[1152921510032306256] = ???;  stack[1152921510032306264] = ???;  //  dest_result_addr=1152921510032306256 |  dest_result_addr=1152921510032306264
            // 0x028FD0BC: ADD x29, sp, #0x10         | X29 = (1152921510032306240 + 16) = 1152921510032306256 (0x100000014361F050);
            // 0x028FD0C0: SUB sp, sp, #0x10          | SP = (1152921510032306240 - 16) = 1152921510032306224 (0x100000014361F030);
            // 0x028FD0C4: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FD0C8: LDRB w8, [x20, #0xa6f]     | W8 = (bool)static_value_037B8A6F;       
            // 0x028FD0CC: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028FD0D0: TBNZ w8, #0, #0x28fd0ec    | if (static_value_037B8A6F == true) goto label_0;
            // 0x028FD0D4: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x028FD0D8: LDR x8, [x8, #0x3e0]       | X8 = 0x2B8A958;                         
            // 0x028FD0DC: LDR w0, [x8]               | W0 = 0x114;                             
            // 0x028FD0E0: BL #0x2782188              | X0 = sub_2782188( ?? 0x114, ????);      
            // 0x028FD0E4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD0E8: STRB w8, [x20, #0xa6f]     | static_value_037B8A6F = true;            //  dest_result_addr=58428015
            label_0:
            // 0x028FD0EC: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x028FD0F0: LDR x19, [x19]             | X19 = X1;                               
            // 0x028FD0F4: LDR x20, [x20, #0x698]     | X20 = 1152921504875483136;              
            // 0x028FD0F8: CBZ x19, #0x28fd14c        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028FD0FC: LDR x8, [x19]              | X8 = X1;                                
            // 0x028FD100: LDR x1, [x20]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD104: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028FD108: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD10C: CMP w10, w9                | STATE = COMPARE(X1 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD110: B.LO #0x28fd128            | if (X1 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FD114: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028FD118: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD11C: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD120: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD124: B.EQ #0x28fd150            | if ((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FD128: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028FD12C: MOV x8, sp                 | X8 = 1152921510032306224 (0x100000014361F030);//ML01
            // 0x028FD130: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028FD134: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510032294272]
            // 0x028FD138: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FD13C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD140: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FD144: MOV x0, sp                 | X0 = 1152921510032306224 (0x100000014361F030);//ML01
            // 0x028FD148: BL #0x299a140              | 
            label_1:
            // 0x028FD14C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014361F030, ????);
            label_3:
            // 0x028FD150: LDR x8, [x19]              | X8 = X1;                                
            // 0x028FD154: LDR x1, [x20]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD158: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028FD15C: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD160: CMP w10, w9                | STATE = COMPARE(X1 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD164: B.LO #0x28fd190            | if (X1 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028FD168: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028FD16C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD170: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD174: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD178: B.NE #0x28fd190            | if ((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028FD17C: LDR x0, [x19, #0x20]       | X0 = X1 + 32;                           
            // 0x028FD180: SUB sp, x29, #0x10         | SP = (1152921510032306256 - 16) = 1152921510032306240 (0x100000014361F040);
            // 0x028FD184: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD188: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FD18C: RET                        |  return (System.Object)X1 + 32;         
            return (object)X1 + 32;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028FD190: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028FD194: ADD x8, sp, #8             | X8 = (1152921510032306224 + 8) = 1152921510032306232 (0x100000014361F038);
            // 0x028FD198: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028FD19C: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510032294272]
            // 0x028FD1A0: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028FD1A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD1A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028FD1AC: ADD x0, sp, #8             | X0 = (1152921510032306224 + 8) = 1152921510032306232 (0x100000014361F038);
            // 0x028FD1B0: BL #0x299a140              | 
            // 0x028FD1B4: MOV x19, x0                | X19 = 1152921510032306232 (0x100000014361F038);//ML01
            // 0x028FD1B8: MOV x0, sp                 | X0 = 1152921510032306224 (0x100000014361F030);//ML01
            label_6:
            // 0x028FD1BC: BL #0x299a140              | 
            // 0x028FD1C0: MOV x0, x19                | X0 = 1152921510032306232 (0x100000014361F038);//ML01
            // 0x028FD1C4: BL #0x980800               | X0 = sub_980800( ?? 0x100000014361F038, ????);
            // 0x028FD1C8: MOV x19, x0                | X19 = 1152921510032306232 (0x100000014361F038);//ML01
            // 0x028FD1CC: ADD x0, sp, #8             | X0 = (1152921510032306224 + 8) = 1152921510032306232 (0x100000014361F038);
            // 0x028FD1D0: B #0x28fd1bc               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD1D4 (42979796), len: 392  VirtAddr: 0x028FD1D4 RVA: 0x028FD1D4 token: 100663679 methodIndex: 29724 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_eventReceiver_2(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028FD1D4: STP x22, x21, [sp, #-0x30]! | stack[1152921510032430352] = ???;  stack[1152921510032430360] = ???;  //  dest_result_addr=1152921510032430352 |  dest_result_addr=1152921510032430360
            // 0x028FD1D8: STP x20, x19, [sp, #0x10]  | stack[1152921510032430368] = ???;  stack[1152921510032430376] = ???;  //  dest_result_addr=1152921510032430368 |  dest_result_addr=1152921510032430376
            // 0x028FD1DC: STP x29, x30, [sp, #0x20]  | stack[1152921510032430384] = ???;  stack[1152921510032430392] = ???;  //  dest_result_addr=1152921510032430384 |  dest_result_addr=1152921510032430392
            // 0x028FD1E0: ADD x29, sp, #0x20         | X29 = (1152921510032430352 + 32) = 1152921510032430384 (0x100000014363D530);
            // 0x028FD1E4: SUB sp, sp, #0x20          | SP = (1152921510032430352 - 32) = 1152921510032430320 (0x100000014363D4F0);
            // 0x028FD1E8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028FD1EC: LDRB w8, [x21, #0xa70]     | W8 = (bool)static_value_037B8A70;       
            // 0x028FD1F0: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x028FD1F4: MOV x20, x1                | X20 = v;//m1                            
            // 0x028FD1F8: TBNZ w8, #0, #0x28fd214    | if (static_value_037B8A70 == true) goto label_0;
            // 0x028FD1FC: ADRP x8, #0x3616000        | X8 = 56713216 (0x3616000);              
            // 0x028FD200: LDR x8, [x8, #0x88]        | X8 = 0x2B8A984;                         
            // 0x028FD204: LDR w0, [x8]               | W0 = 0x11F;                             
            // 0x028FD208: BL #0x2782188              | X0 = sub_2782188( ?? 0x11F, ????);      
            // 0x028FD20C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD210: STRB w8, [x21, #0xa70]     | static_value_037B8A70 = true;            //  dest_result_addr=58428016
            label_0:
            // 0x028FD214: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x028FD218: CBZ x20, #0x28fd2cc        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028FD21C: ADRP x21, #0x3676000       | X21 = 57106432 (0x3676000);             
            // 0x028FD220: LDR x21, [x21, #0x698]     | X21 = 1152921504875483136;              
            val_6 = 1152921504875483136;
            // 0x028FD224: LDR x8, [x20]              | X8 = ;                                  
            // 0x028FD228: LDR x1, [x21]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD22C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028FD230: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD234: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD238: B.LO #0x28fd250            | if (mem[null + 260] < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FD23C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028FD240: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD244: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD248: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD24C: B.EQ #0x28fd278            | if ((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FD250: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FD254: ADD x8, sp, #8             | X8 = (1152921510032430320 + 8) = 1152921510032430328 (0x100000014363D4F8);
            // 0x028FD258: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028FD25C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510032418400]
            // 0x028FD260: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FD264: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD268: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FD26C: ADD x0, sp, #8             | X0 = (1152921510032430320 + 8) = 1152921510032430328 (0x100000014363D4F8);
            // 0x028FD270: BL #0x299a140              | 
            // 0x028FD274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014363D4F8, ????);
            label_3:
            // 0x028FD278: LDR x8, [x20]              | X8 = ;                                  
            // 0x028FD27C: LDR x1, [x21]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD280: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028FD284: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD288: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD28C: B.LO #0x28fd2a4            | if (mem[null + 260] < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028FD290: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028FD294: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD298: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD29C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD2A0: B.EQ #0x28fd2d4            | if ((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028FD2A4: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FD2A8: ADD x8, sp, #0x10          | X8 = (1152921510032430320 + 16) = 1152921510032430336 (0x100000014363D500);
            // 0x028FD2AC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028FD2B0: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510032418400]
            // 0x028FD2B4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028FD2B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD2BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028FD2C0: ADD x0, sp, #0x10          | X0 = (1152921510032430320 + 16) = 1152921510032430336 (0x100000014363D500);
            // 0x028FD2C4: BL #0x299a140              | 
            // 0x028FD2C8: B #0x28fd2d0               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028FD2CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11F, ????);      
            label_6:
            // 0x028FD2D0: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x028FD2D4: CBZ x19, #0x28fd314        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x028FD2D8: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x028FD2DC: LDR x8, [x8, #0x30]        | X8 = 1152921504692629504;               
            // 0x028FD2E0: LDR x1, [x8]               | X1 = typeof(UnityEngine.GameObject);    
            // 0x028FD2E4: LDR x8, [x19]              | X8 = X2;                                
            // 0x028FD2E8: CMP x8, x1                 | STATE = COMPARE(X2, typeof(UnityEngine.GameObject))
            // 0x028FD2EC: B.EQ #0x28fd318            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x028FD2F0: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028FD2F4: ADD x8, sp, #0x18          | X8 = (1152921510032430320 + 24) = 1152921510032430344 (0x100000014363D508);
            // 0x028FD2F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028FD2FC: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510032418400]
            // 0x028FD300: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028FD304: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD308: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028FD30C: ADD x0, sp, #0x18          | X0 = (1152921510032430320 + 24) = 1152921510032430344 (0x100000014363D508);
            // 0x028FD310: BL #0x299a140              | 
            label_7:
            // 0x028FD314: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x028FD318: STR x19, [x20, #0x20]      | mem[32] = 0x0;                           //  dest_result_addr=32
            mem[32] = val_7;
            // 0x028FD31C: SUB sp, x29, #0x20         | SP = (1152921510032430384 - 32) = 1152921510032430352 (0x100000014363D510);
            // 0x028FD320: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD324: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028FD328: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028FD32C: RET                        |  return;                                
            return;
            // 0x028FD330: MOV x19, x0                | 
            // 0x028FD334: ADD x0, sp, #8             | 
            // 0x028FD338: B #0x28fd350               | 
            // 0x028FD33C: MOV x19, x0                | 
            // 0x028FD340: ADD x0, sp, #0x10          | 
            // 0x028FD344: B #0x28fd350               | 
            // 0x028FD348: MOV x19, x0                | 
            // 0x028FD34C: ADD x0, sp, #0x18          | 
            label_10:
            // 0x028FD350: BL #0x299a140              | 
            // 0x028FD354: MOV x0, x19                | 
            // 0x028FD358: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD35C (42980188), len: 288  VirtAddr: 0x028FD35C RVA: 0x028FD35C token: 100663680 methodIndex: 29725 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_callWhenFinished_3(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x028FD35C: STP x20, x19, [sp, #-0x20]! | stack[1152921510032554496] = ???;  stack[1152921510032554504] = ???;  //  dest_result_addr=1152921510032554496 |  dest_result_addr=1152921510032554504
            // 0x028FD360: STP x29, x30, [sp, #0x10]  | stack[1152921510032554512] = ???;  stack[1152921510032554520] = ???;  //  dest_result_addr=1152921510032554512 |  dest_result_addr=1152921510032554520
            // 0x028FD364: ADD x29, sp, #0x10         | X29 = (1152921510032554496 + 16) = 1152921510032554512 (0x100000014365BA10);
            // 0x028FD368: SUB sp, sp, #0x10          | SP = (1152921510032554496 - 16) = 1152921510032554480 (0x100000014365B9F0);
            // 0x028FD36C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FD370: LDRB w8, [x20, #0xa71]     | W8 = (bool)static_value_037B8A71;       
            // 0x028FD374: MOV x19, x1                | X19 = X1;//m1                           
            // 0x028FD378: TBNZ w8, #0, #0x28fd394    | if (static_value_037B8A71 == true) goto label_0;
            // 0x028FD37C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x028FD380: LDR x8, [x8, #0x9b0]       | X8 = 0x2B8A950;                         
            // 0x028FD384: LDR w0, [x8]               | W0 = 0x112;                             
            // 0x028FD388: BL #0x2782188              | X0 = sub_2782188( ?? 0x112, ????);      
            // 0x028FD38C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD390: STRB w8, [x20, #0xa71]     | static_value_037B8A71 = true;            //  dest_result_addr=58428017
            label_0:
            // 0x028FD394: ADRP x20, #0x3676000       | X20 = 57106432 (0x3676000);             
            // 0x028FD398: LDR x19, [x19]             | X19 = X1;                               
            // 0x028FD39C: LDR x20, [x20, #0x698]     | X20 = 1152921504875483136;              
            // 0x028FD3A0: CBZ x19, #0x28fd3f4        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x028FD3A4: LDR x8, [x19]              | X8 = X1;                                
            // 0x028FD3A8: LDR x1, [x20]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD3AC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028FD3B0: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD3B4: CMP w10, w9                | STATE = COMPARE(X1 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD3B8: B.LO #0x28fd3d0            | if (X1 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FD3BC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028FD3C0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD3C4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD3C8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD3CC: B.EQ #0x28fd3f8            | if ((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FD3D0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028FD3D4: MOV x8, sp                 | X8 = 1152921510032554480 (0x100000014365B9F0);//ML01
            // 0x028FD3D8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028FD3DC: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510032542528]
            // 0x028FD3E0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FD3E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD3E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FD3EC: MOV x0, sp                 | X0 = 1152921510032554480 (0x100000014365B9F0);//ML01
            // 0x028FD3F0: BL #0x299a140              | 
            label_1:
            // 0x028FD3F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x100000014365B9F0, ????);
            label_3:
            // 0x028FD3F8: LDR x8, [x19]              | X8 = X1;                                
            // 0x028FD3FC: LDR x1, [x20]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD400: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x028FD404: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD408: CMP w10, w9                | STATE = COMPARE(X1 + 260, ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD40C: B.LO #0x28fd438            | if (X1 + 260 < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x028FD410: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x028FD414: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD418: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD41C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD420: B.NE #0x28fd438            | if ((X1 + 176 + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x028FD424: LDR x0, [x19, #0x28]       | X0 = X1 + 40;                           
            // 0x028FD428: SUB sp, x29, #0x10         | SP = (1152921510032554512 - 16) = 1152921510032554496 (0x100000014365BA00);
            // 0x028FD42C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD430: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FD434: RET                        |  return (System.Object)X1 + 40;         
            return (object)X1 + 40;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x028FD438: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x028FD43C: ADD x8, sp, #8             | X8 = (1152921510032554480 + 8) = 1152921510032554488 (0x100000014365B9F8);
            // 0x028FD440: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x028FD444: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510032542528]
            // 0x028FD448: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028FD44C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD450: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028FD454: ADD x0, sp, #8             | X0 = (1152921510032554480 + 8) = 1152921510032554488 (0x100000014365B9F8);
            // 0x028FD458: BL #0x299a140              | 
            // 0x028FD45C: MOV x19, x0                | X19 = 1152921510032554488 (0x100000014365B9F8);//ML01
            // 0x028FD460: MOV x0, sp                 | X0 = 1152921510032554480 (0x100000014365B9F0);//ML01
            label_6:
            // 0x028FD464: BL #0x299a140              | 
            // 0x028FD468: MOV x0, x19                | X0 = 1152921510032554488 (0x100000014365B9F8);//ML01
            // 0x028FD46C: BL #0x980800               | X0 = sub_980800( ?? 0x100000014365B9F8, ????);
            // 0x028FD470: MOV x19, x0                | X19 = 1152921510032554488 (0x100000014365B9F8);//ML01
            // 0x028FD474: ADD x0, sp, #8             | X0 = (1152921510032554480 + 8) = 1152921510032554488 (0x100000014365B9F8);
            // 0x028FD478: B #0x28fd464               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD47C (42980476), len: 392  VirtAddr: 0x028FD47C RVA: 0x028FD47C token: 100663681 methodIndex: 29726 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_callWhenFinished_3(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x028FD47C: STP x22, x21, [sp, #-0x30]! | stack[1152921510032678608] = ???;  stack[1152921510032678616] = ???;  //  dest_result_addr=1152921510032678608 |  dest_result_addr=1152921510032678616
            // 0x028FD480: STP x20, x19, [sp, #0x10]  | stack[1152921510032678624] = ???;  stack[1152921510032678632] = ???;  //  dest_result_addr=1152921510032678624 |  dest_result_addr=1152921510032678632
            // 0x028FD484: STP x29, x30, [sp, #0x20]  | stack[1152921510032678640] = ???;  stack[1152921510032678648] = ???;  //  dest_result_addr=1152921510032678640 |  dest_result_addr=1152921510032678648
            // 0x028FD488: ADD x29, sp, #0x20         | X29 = (1152921510032678608 + 32) = 1152921510032678640 (0x1000000143679EF0);
            // 0x028FD48C: SUB sp, sp, #0x20          | SP = (1152921510032678608 - 32) = 1152921510032678576 (0x1000000143679EB0);
            // 0x028FD490: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028FD494: LDRB w8, [x21, #0xa72]     | W8 = (bool)static_value_037B8A72;       
            // 0x028FD498: MOV x19, x2                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x028FD49C: MOV x20, x1                | X20 = v;//m1                            
            // 0x028FD4A0: TBNZ w8, #0, #0x28fd4bc    | if (static_value_037B8A72 == true) goto label_0;
            // 0x028FD4A4: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x028FD4A8: LDR x8, [x8, #0xbf0]       | X8 = 0x2B8A97C;                         
            // 0x028FD4AC: LDR w0, [x8]               | W0 = 0x11D;                             
            // 0x028FD4B0: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D, ????);      
            // 0x028FD4B4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD4B8: STRB w8, [x21, #0xa72]     | static_value_037B8A72 = true;            //  dest_result_addr=58428018
            label_0:
            // 0x028FD4BC: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x028FD4C0: CBZ x20, #0x28fd574        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x028FD4C4: ADRP x21, #0x3676000       | X21 = 57106432 (0x3676000);             
            // 0x028FD4C8: LDR x21, [x21, #0x698]     | X21 = 1152921504875483136;              
            val_6 = 1152921504875483136;
            // 0x028FD4CC: LDR x8, [x20]              | X8 = ;                                  
            // 0x028FD4D0: LDR x1, [x21]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD4D4: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028FD4D8: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD4DC: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD4E0: B.LO #0x28fd4f8            | if (mem[null + 260] < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x028FD4E4: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028FD4E8: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD4EC: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD4F0: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD4F4: B.EQ #0x28fd520            | if ((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x028FD4F8: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FD4FC: ADD x8, sp, #8             | X8 = (1152921510032678576 + 8) = 1152921510032678584 (0x1000000143679EB8);
            // 0x028FD500: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028FD504: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510032666656]
            // 0x028FD508: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x028FD50C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD510: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x028FD514: ADD x0, sp, #8             | X0 = (1152921510032678576 + 8) = 1152921510032678584 (0x1000000143679EB8);
            // 0x028FD518: BL #0x299a140              | 
            // 0x028FD51C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143679EB8, ????);
            label_3:
            // 0x028FD520: LDR x8, [x20]              | X8 = ;                                  
            // 0x028FD524: LDR x1, [x21]              | X1 = typeof(ActiveAnimation);           
            // 0x028FD528: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x028FD52C: LDRB w9, [x1, #0x104]      | W9 = ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x028FD530: CMP w10, w9                | STATE = COMPARE(mem[null + 260], ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x028FD534: B.LO #0x28fd54c            | if (mem[null + 260] < ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x028FD538: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x028FD53C: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x028FD540: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x028FD544: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(ActiveAnimation))
            // 0x028FD548: B.EQ #0x28fd57c            | if ((mem[null + 176] + (ActiveAnimation.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x028FD54C: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x028FD550: ADD x8, sp, #0x10          | X8 = (1152921510032678576 + 16) = 1152921510032678592 (0x1000000143679EC0);
            // 0x028FD554: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x028FD558: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510032666656]
            // 0x028FD55C: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x028FD560: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD564: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x028FD568: ADD x0, sp, #0x10          | X0 = (1152921510032678576 + 16) = 1152921510032678592 (0x1000000143679EC0);
            // 0x028FD56C: BL #0x299a140              | 
            // 0x028FD570: B #0x28fd578               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028FD574: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11D, ????);      
            label_6:
            // 0x028FD578: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_8 = 0;
            label_5:
            // 0x028FD57C: CBZ x19, #0x28fd5bc        | if (X2 == 0) goto label_7;              
            if(val_7 == 0)
            {
                goto label_7;
            }
            // 0x028FD580: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x028FD584: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x028FD588: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x028FD58C: LDR x8, [x19]              | X8 = X2;                                
            // 0x028FD590: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x028FD594: B.EQ #0x28fd5c0            | if (val_7 == null) goto label_8;        
            if(val_7 == null)
            {
                goto label_8;
            }
            // 0x028FD598: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x028FD59C: ADD x8, sp, #0x18          | X8 = (1152921510032678576 + 24) = 1152921510032678600 (0x1000000143679EC8);
            // 0x028FD5A0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x028FD5A4: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510032666656]
            // 0x028FD5A8: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x028FD5AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD5B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x028FD5B4: ADD x0, sp, #0x18          | X0 = (1152921510032678576 + 24) = 1152921510032678600 (0x1000000143679EC8);
            // 0x028FD5B8: BL #0x299a140              | 
            label_7:
            // 0x028FD5BC: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_8:
            // 0x028FD5C0: STR x19, [x20, #0x28]      | mem[40] = 0x0;                           //  dest_result_addr=40
            mem[40] = val_7;
            // 0x028FD5C4: SUB sp, x29, #0x20         | SP = (1152921510032678640 - 32) = 1152921510032678608 (0x1000000143679ED0);
            // 0x028FD5C8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD5CC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028FD5D0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028FD5D4: RET                        |  return;                                
            return;
            // 0x028FD5D8: MOV x19, x0                | 
            // 0x028FD5DC: ADD x0, sp, #8             | 
            // 0x028FD5E0: B #0x28fd5f8               | 
            // 0x028FD5E4: MOV x19, x0                | 
            // 0x028FD5E8: ADD x0, sp, #0x10          | 
            // 0x028FD5EC: B #0x28fd5f8               | 
            // 0x028FD5F0: MOV x19, x0                | 
            // 0x028FD5F4: ADD x0, sp, #0x18          | 
            label_10:
            // 0x028FD5F8: BL #0x299a140              | 
            // 0x028FD5FC: MOV x0, x19                | 
            // 0x028FD600: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD604 (42980868), len: 180  VirtAddr: 0x028FD604 RVA: 0x028FD604 token: 100663682 methodIndex: 29727 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x028FD604: STP x22, x21, [sp, #-0x30]! | stack[1152921510032815104] = ???;  stack[1152921510032815112] = ???;  //  dest_result_addr=1152921510032815104 |  dest_result_addr=1152921510032815112
            // 0x028FD608: STP x20, x19, [sp, #0x10]  | stack[1152921510032815120] = ???;  stack[1152921510032815128] = ???;  //  dest_result_addr=1152921510032815120 |  dest_result_addr=1152921510032815128
            // 0x028FD60C: STP x29, x30, [sp, #0x20]  | stack[1152921510032815136] = ???;  stack[1152921510032815144] = ???;  //  dest_result_addr=1152921510032815136 |  dest_result_addr=1152921510032815144
            // 0x028FD610: ADD x29, sp, #0x20         | X29 = (1152921510032815104 + 32) = 1152921510032815136 (0x100000014369B420);
            // 0x028FD614: ADRP x22, #0x37b8000       | X22 = 58425344 (0x37B8000);             
            // 0x028FD618: LDRB w8, [x22, #0xa73]     | W8 = (bool)static_value_037B8A73;       
            // 0x028FD61C: MOV x19, x3                | X19 = X3;//m1                           
            // 0x028FD620: MOV x20, x2                | X20 = X2;//m1                           
            // 0x028FD624: MOV x21, x1                | X21 = X1;//m1                           
            // 0x028FD628: TBNZ w8, #0, #0x28fd644    | if (static_value_037B8A73 == true) goto label_0;
            // 0x028FD62C: ADRP x8, #0x3660000        | X8 = 57016320 (0x3660000);              
            // 0x028FD630: LDR x8, [x8, #0x510]       | X8 = 0x2B8A948;                         
            // 0x028FD634: LDR w0, [x8]               | W0 = 0x110;                             
            // 0x028FD638: BL #0x2782188              | X0 = sub_2782188( ?? 0x110, ????);      
            // 0x028FD63C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD640: STRB w8, [x22, #0xa73]     | static_value_037B8A73 = true;            //  dest_result_addr=58428019
            label_0:
            // 0x028FD644: CBNZ x21, #0x28fd64c       | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x028FD648: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x110, ????);      
            label_1:
            // 0x028FD64C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD650: MOV x0, x21                | X0 = X1;//m1                            
            // 0x028FD654: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x028FD658: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FD65C: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028FD660: MOV x1, x20                | X1 = X2;//m1                            
            // 0x028FD664: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x028FD668: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x028FD66C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x028FD670: LDR x8, [x8, #0x698]       | X8 = 1152921504875483136;               
            // 0x028FD674: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x028FD678: LDR x8, [x8]               | X8 = typeof(ActiveAnimation);           
            // 0x028FD67C: MOV x0, x8                 | X0 = 1152921504875483136 (0x1000000010031000);//ML01
            ActiveAnimation val_3 = null;
            // 0x028FD680: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ActiveAnimation), ????);
            // 0x028FD684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD688: MOV x21, x0                | X21 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FD68C: BL #0xb1c4ec               | .ctor();                                
            val_3 = new ActiveAnimation();
            // 0x028FD690: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x028FD694: MOV x2, x19                | X2 = X3;//m1                            
            // 0x028FD698: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD69C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028FD6A0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028FD6A4: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x028FD6A8: MOV x3, x21                | X3 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FD6AC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x028FD6B0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028FD6B4: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD6B8 (42981048), len: 92  VirtAddr: 0x028FD6B8 RVA: 0x028FD6B8 token: 100663683 methodIndex: 29728 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x028FD6B8: STP x20, x19, [sp, #-0x20]! | stack[1152921510032943504] = ???;  stack[1152921510032943512] = ???;  //  dest_result_addr=1152921510032943504 |  dest_result_addr=1152921510032943512
            // 0x028FD6BC: STP x29, x30, [sp, #0x10]  | stack[1152921510032943520] = ???;  stack[1152921510032943528] = ???;  //  dest_result_addr=1152921510032943520 |  dest_result_addr=1152921510032943528
            // 0x028FD6C0: ADD x29, sp, #0x10         | X29 = (1152921510032943504 + 16) = 1152921510032943520 (0x10000001436BA9A0);
            // 0x028FD6C4: ADRP x19, #0x37b8000       | X19 = 58425344 (0x37B8000);             
            // 0x028FD6C8: LDRB w8, [x19, #0xa74]     | W8 = (bool)static_value_037B8A74;       
            // 0x028FD6CC: TBNZ w8, #0, #0x28fd6e8    | if (static_value_037B8A74 == true) goto label_0;
            // 0x028FD6D0: ADRP x8, #0x3659000        | X8 = 56987648 (0x3659000);              
            // 0x028FD6D4: LDR x8, [x8, #0x730]       | X8 = 0x2B8A98C;                         
            // 0x028FD6D8: LDR w0, [x8]               | W0 = 0x121;                             
            // 0x028FD6DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x121, ????);      
            // 0x028FD6E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD6E4: STRB w8, [x19, #0xa74]     | static_value_037B8A74 = true;            //  dest_result_addr=58428020
            label_0:
            // 0x028FD6E8: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x028FD6EC: LDR x8, [x8, #0x698]       | X8 = 1152921504875483136;               
            // 0x028FD6F0: LDR x0, [x8]               | X0 = typeof(ActiveAnimation);           
            ActiveAnimation val_1 = null;
            // 0x028FD6F4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ActiveAnimation), ????);
            // 0x028FD6F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028FD6FC: MOV x19, x0                | X19 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FD700: BL #0xb1c4ec               | .ctor();                                
            val_1 = new ActiveAnimation();
            // 0x028FD704: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD708: MOV x0, x19                | X0 = 1152921504875483136 (0x1000000010031000);//ML01
            // 0x028FD70C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FD710: RET                        |  return (System.Object)typeof(ActiveAnimation);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028FD714 (42981140), len: 92  VirtAddr: 0x028FD714 RVA: 0x028FD714 token: 100663684 methodIndex: 29729 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x028FD714: STP x20, x19, [sp, #-0x20]! | stack[1152921510033059600] = ???;  stack[1152921510033059608] = ???;  //  dest_result_addr=1152921510033059600 |  dest_result_addr=1152921510033059608
            // 0x028FD718: STP x29, x30, [sp, #0x10]  | stack[1152921510033059616] = ???;  stack[1152921510033059624] = ???;  //  dest_result_addr=1152921510033059616 |  dest_result_addr=1152921510033059624
            // 0x028FD71C: ADD x29, sp, #0x10         | X29 = (1152921510033059600 + 16) = 1152921510033059616 (0x10000001436D6F20);
            // 0x028FD720: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028FD724: LDRB w8, [x20, #0xa75]     | W8 = (bool)static_value_037B8A75;       
            // 0x028FD728: MOV w19, w1                | W19 = W1;//m1                           
            // 0x028FD72C: TBNZ w8, #0, #0x28fd748    | if (static_value_037B8A75 == true) goto label_0;
            // 0x028FD730: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
            // 0x028FD734: LDR x8, [x8, #0x4d0]       | X8 = 0x2B8A990;                         
            // 0x028FD738: LDR w0, [x8]               | W0 = 0x122;                             
            // 0x028FD73C: BL #0x2782188              | X0 = sub_2782188( ?? 0x122, ????);      
            // 0x028FD740: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028FD744: STRB w8, [x20, #0xa75]     | static_value_037B8A75 = true;            //  dest_result_addr=58428021
            label_0:
            // 0x028FD748: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x028FD74C: LDR x8, [x8, #0x938]       | X8 = 1152921510033043536;               
            // 0x028FD750: LDR x20, [x8]              | X20 = typeof(ActiveAnimation[]);        
            // 0x028FD754: MOV x0, x20                | X0 = 1152921510033043536 (0x10000001436D3050);//ML01
            // 0x028FD758: BL #0x277461c              | X0 = sub_277461C( ?? typeof(ActiveAnimation[]), ????);
            // 0x028FD75C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028FD760: MOV w1, w19                | W1 = W1;//m1                            
            // 0x028FD764: MOV x0, x20                | X0 = 1152921510033043536 (0x10000001436D3050);//ML01
            // 0x028FD768: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028FD76C: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(ActiveAnimation[]), ????);
        
        }
    
    }

}
