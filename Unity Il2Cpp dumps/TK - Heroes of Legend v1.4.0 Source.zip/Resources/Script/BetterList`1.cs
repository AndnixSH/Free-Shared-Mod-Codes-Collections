using UnityEngine;
public class BetterList<T>
{
    // Fields
    public T[] buffer; //  0x00000010
    public int size; //  0x00000018
    
    // Properties
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x2866078
    public T Item { get; set; }
    
    // Methods
    // Generic instance method:
    //
    // file offset: 0x019C19A0 VirtAddr: 0x019C19A0 -RVA: 0x019C19A0 
    // -BetterList<object>..ctor
    // -BetterList<string>..ctor
    // -BetterList<UICamera>..ctor
    // -BetterList<UIDrawCall>..ctor
    // -BetterList<UIKeyNavigation>..ctor
    // -BetterList<UILabel>..ctor
    // -BetterList<UIRect>..ctor
    // -BetterList<UIScrollView>..ctor
    // -BetterList<UITextList.Paragraph>..ctor
    // -BetterList<UIToggle>..ctor
    //
    // file offset: 0x019C58D4 VirtAddr: 0x019C58D4 -RVA: 0x019C58D4 
    // -BetterList<UnityEngine.Color>..ctor
    //
    // file offset: 0x019C2718 VirtAddr: 0x019C2718 -RVA: 0x019C2718 
    // -BetterList<float>..ctor
    //
    // file offset: 0x019C34F0 VirtAddr: 0x019C34F0 -RVA: 0x019C34F0 
    // -BetterList<TypewriterEffect.FadeEntry>..ctor
    //
    // file offset: 0x019C0C04 VirtAddr: 0x019C0C04 -RVA: 0x019C0C04 
    // -BetterList<int>..ctor
    //
    // file offset: 0x019C46B8 VirtAddr: 0x019C46B8 -RVA: 0x019C46B8 
    // -BetterList<UICamera.DepthEntry>..ctor
    //
    // file offset: 0x019C8528 VirtAddr: 0x019C8528 -RVA: 0x019C8528 
    // -BetterList<UnityEngine.Vector3>..ctor
    //
    // file offset: 0x019C94DC VirtAddr: 0x019C94DC -RVA: 0x019C94DC 
    // -BetterList<UnityEngine.Vector4>..ctor
    //
    // file offset: 0x019C76E0 VirtAddr: 0x019C76E0 -RVA: 0x019C76E0 
    // -BetterList<UnityEngine.Vector2>..ctor
    //
    // file offset: 0x019C6880 VirtAddr: 0x019C6880 -RVA: 0x019C6880 
    // -BetterList<UnityEngine.Color32>..ctor
    //
    //
    // Offset in libil2cpp.so: 0x019C19A0 (27007392), len: 44  VirtAddr: 0x019C19A0 RVA: 0x019C19A0 token: 100687847 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public BetterList<T>()
    {
        //
        // Disasemble & Code
        // 0x019C19A0: STP x20, x19, [sp, #-0x20]! | stack[1152921514152379568] = ???;  stack[1152921514152379576] = ???;  //  dest_result_addr=1152921514152379568 |  dest_result_addr=1152921514152379576
        // 0x019C19A4: STP x29, x30, [sp, #0x10]  | stack[1152921514152379584] = ???;  stack[1152921514152379592] = ???;  //  dest_result_addr=1152921514152379584 |  dest_result_addr=1152921514152379592
        // 0x019C19A8: ADD x29, sp, #0x10         | X29 = (1152921514152379568 + 16) = 1152921514152379584 (0x1000000238F544C0);
        // 0x019C19AC: MOV x19, x0                | X19 = 1152921514152391600 (0x1000000238F573B0);//ML01
        // 0x019C19B0: CBNZ x19, #0x19c19b8       | if (this != null) goto label_0;         
        if(this != null)
        {
            goto label_0;
        }
        // 0x019C19B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019C19B8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x019C19BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C19C0: MOV x0, x19                | X0 = 1152921514152391600 (0x1000000238F573B0);//ML01
        // 0x019C19C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x019C19C8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C19CC VirtAddr: 0x019C19CC -RVA: 0x019C19CC 
    // -BetterList<object>.GetEnumerator
    //
    // file offset: 0x019C0C30 VirtAddr: 0x019C0C30 -RVA: 0x019C0C30 
    // -BetterList<int>.GetEnumerator
    //
    // file offset: 0x019C2744 VirtAddr: 0x019C2744 -RVA: 0x019C2744 
    // -BetterList<float>.GetEnumerator
    //
    // file offset: 0x019C351C VirtAddr: 0x019C351C -RVA: 0x019C351C 
    // -BetterList<TypewriterEffect.FadeEntry>.GetEnumerator
    //
    // file offset: 0x019C46E4 VirtAddr: 0x019C46E4 -RVA: 0x019C46E4 
    // -BetterList<UICamera.DepthEntry>.GetEnumerator
    //
    // file offset: 0x019C5900 VirtAddr: 0x019C5900 -RVA: 0x019C5900 
    // -BetterList<UnityEngine.Color>.GetEnumerator
    //
    // file offset: 0x019C68AC VirtAddr: 0x019C68AC -RVA: 0x019C68AC 
    // -BetterList<UnityEngine.Color32>.GetEnumerator
    //
    // file offset: 0x019C770C VirtAddr: 0x019C770C -RVA: 0x019C770C 
    // -BetterList<UnityEngine.Vector2>.GetEnumerator
    //
    // file offset: 0x019C8554 VirtAddr: 0x019C8554 -RVA: 0x019C8554 
    // -BetterList<UnityEngine.Vector3>.GetEnumerator
    //
    // file offset: 0x019C9508 VirtAddr: 0x019C9508 -RVA: 0x019C9508 
    // -BetterList<UnityEngine.Vector4>.GetEnumerator
    //
    //
    // Offset in libil2cpp.so: 0x019C19CC (27007436), len: 108  VirtAddr: 0x019C19CC RVA: 0x019C19CC token: 100687848 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x2865FF8
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x2865FF8
    [System.Diagnostics.DebuggerStepThroughAttribute] // 0x2865FF8
    public System.Collections.Generic.IEnumerator<T> GetEnumerator()
    {
        //
        // Disasemble & Code
        // 0x019C19CC: STP x22, x21, [sp, #-0x30]! | stack[1152921514152491552] = ???;  stack[1152921514152491560] = ???;  //  dest_result_addr=1152921514152491552 |  dest_result_addr=1152921514152491560
        // 0x019C19D0: STP x20, x19, [sp, #0x10]  | stack[1152921514152491568] = ???;  stack[1152921514152491576] = ???;  //  dest_result_addr=1152921514152491568 |  dest_result_addr=1152921514152491576
        // 0x019C19D4: STP x29, x30, [sp, #0x20]  | stack[1152921514152491584] = ???;  stack[1152921514152491592] = ???;  //  dest_result_addr=1152921514152491584 |  dest_result_addr=1152921514152491592
        // 0x019C19D8: ADD x29, sp, #0x20         | X29 = (1152921514152491552 + 32) = 1152921514152491584 (0x1000000238F6FA40);
        // 0x019C19DC: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x019C19E0: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C19E4: MOV x19, x0                | X19 = 1152921514152503600 (0x1000000238F72930);//ML01
        // 0x019C19E8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C19EC: LDR x21, [x8]              | X21 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C19F0: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
        // 0x019C19F4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
        // 0x019C19F8: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
        // 0x019C19FC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
        // 0x019C1A00: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1A04: MOV x20, x0                | X20 = __RuntimeMethodHiddenParam + 24 + 168;//m1
        // 0x019C1A08: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1A0C: LDR x1, [x8, #8]           | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        // 0x019C1A10: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 8;
        // 0x019C1A14: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 8();
        // 0x019C1A18: CBNZ x20, #0x19c1a20       | if (__RuntimeMethodHiddenParam + 24 + 168 != 0) goto label_0;
        if((__RuntimeMethodHiddenParam + 24 + 168) != 0)
        {
            goto label_0;
        }
        // 0x019C1A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam + 24 + 168, ????);
        label_0:
        // 0x019C1A20: STR x19, [x20, #0x18]      | mem2[0] = this;                          //  dest_result_addr=0
        mem2[0] = this;
        // 0x019C1A24: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168;//m1
        // 0x019C1A28: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1A2C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1A30: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019C1A34: RET                        |  return (System.Collections.Generic.IEnumerator<T>)__RuntimeMethodHiddenParam + 24 + 168;
        return (System.Collections.Generic.IEnumerator<T>)__RuntimeMethodHiddenParam + 24 + 168;
        //  |  // // {name=val_0, type=System.Collections.Generic.IEnumerator<T>, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1A38 VirtAddr: 0x019C1A38 -RVA: 0x019C1A38 
    // -BetterList<object>.get_Item
    // -BetterList<UICamera>.get_Item
    // -BetterList<string>.get_Item
    // -BetterList<UIDrawCall>.get_Item
    // -BetterList<UIKeyNavigation>.get_Item
    // -BetterList<UILabel>.get_Item
    // -BetterList<UITextList.Paragraph>.get_Item
    // -BetterList<UIToggle>.get_Item
    //
    // file offset: 0x019C596C VirtAddr: 0x019C596C -RVA: 0x019C596C 
    // -BetterList<UnityEngine.Color>.get_Item
    //
    // file offset: 0x019C85C0 VirtAddr: 0x019C85C0 -RVA: 0x019C85C0 
    // -BetterList<UnityEngine.Vector3>.get_Item
    //
    // file offset: 0x019C0C9C VirtAddr: 0x019C0C9C -RVA: 0x019C0C9C 
    // -BetterList<int>.get_Item
    //
    // file offset: 0x019C27B0 VirtAddr: 0x019C27B0 -RVA: 0x019C27B0 
    // -BetterList<float>.get_Item
    //
    // file offset: 0x019C3588 VirtAddr: 0x019C3588 -RVA: 0x019C3588 
    // -BetterList<TypewriterEffect.FadeEntry>.get_Item
    //
    // file offset: 0x019C4750 VirtAddr: 0x019C4750 -RVA: 0x019C4750 
    // -BetterList<UICamera.DepthEntry>.get_Item
    //
    // file offset: 0x019C6918 VirtAddr: 0x019C6918 -RVA: 0x019C6918 
    // -BetterList<UnityEngine.Color32>.get_Item
    //
    // file offset: 0x019C7778 VirtAddr: 0x019C7778 -RVA: 0x019C7778 
    // -BetterList<UnityEngine.Vector2>.get_Item
    //
    // file offset: 0x019C9574 VirtAddr: 0x019C9574 -RVA: 0x019C9574 
    // -BetterList<UnityEngine.Vector4>.get_Item
    //
    //
    // Offset in libil2cpp.so: 0x019C1A38 (27007544), len: 84  VirtAddr: 0x019C1A38 RVA: 0x019C1A38 token: 100687849 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public T get_Item(int i)
    {
        //
        // Disasemble & Code
        // 0x019C1A38: STP x22, x21, [sp, #-0x30]! | stack[1152921514152603552] = ???;  stack[1152921514152603560] = ???;  //  dest_result_addr=1152921514152603552 |  dest_result_addr=1152921514152603560
        // 0x019C1A3C: STP x20, x19, [sp, #0x10]  | stack[1152921514152603568] = ???;  stack[1152921514152603576] = ???;  //  dest_result_addr=1152921514152603568 |  dest_result_addr=1152921514152603576
        // 0x019C1A40: STP x29, x30, [sp, #0x20]  | stack[1152921514152603584] = ???;  stack[1152921514152603592] = ???;  //  dest_result_addr=1152921514152603584 |  dest_result_addr=1152921514152603592
        // 0x019C1A44: ADD x29, sp, #0x20         | X29 = (1152921514152603552 + 32) = 1152921514152603584 (0x1000000238F8AFC0);
        // 0x019C1A48: LDR x20, [x0, #0x10]       | 
        // 0x019C1A4C: MOV w19, w1                | W19 = i;//m1                            
        // 0x019C1A50: CBNZ x20, #0x19c1a58       | if (X20 != 0) goto label_0;             
        if(X20 != 0)
        {
            goto label_0;
        }
        // 0x019C1A54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019C1A58: LDR w8, [x20, #0x18]       | W8 = X20 + 24;                          
        // 0x019C1A5C: SXTW x21, w19              | X21 = (long)(int)(i);                   
        // 0x019C1A60: CMP w8, w19                | STATE = COMPARE(X20 + 24, i)            
        // 0x019C1A64: B.HI #0x19c1a74            | if (X20 + 24 > i) goto label_1;         
        if((X20 + 24) > i)
        {
            goto label_1;
        }
        // 0x019C1A68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C1A6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1A70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_1:
        // 0x019C1A74: ADD x8, x20, x21, lsl #3   | X8 = (X20 + ((long)(int)(i)) << 3);     
        var val_1 = X20 + (((long)(int)(i)) << 3);
        // 0x019C1A78: LDR x0, [x8, #0x20]        | X0 = (X20 + ((long)(int)(i)) << 3) + 32;
        // 0x019C1A7C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1A80: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1A84: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019C1A88: RET                        |  return (System.Object)(X20 + ((long)(int)(i)) << 3) + 32;
        return (object)(X20 + ((long)(int)(i)) << 3) + 32;
        //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1A8C VirtAddr: 0x019C1A8C -RVA: 0x019C1A8C 
    // -BetterList<object>.set_Item
    // -BetterList<string>.set_Item
    //
    // file offset: 0x019C35F0 VirtAddr: 0x019C35F0 -RVA: 0x019C35F0 
    // -BetterList<TypewriterEffect.FadeEntry>.set_Item
    //
    // file offset: 0x019C0CF0 VirtAddr: 0x019C0CF0 -RVA: 0x019C0CF0 
    // -BetterList<int>.set_Item
    //
    // file offset: 0x019C2804 VirtAddr: 0x019C2804 -RVA: 0x019C2804 
    // -BetterList<float>.set_Item
    //
    // file offset: 0x019C47B4 VirtAddr: 0x019C47B4 -RVA: 0x019C47B4 
    // -BetterList<UICamera.DepthEntry>.set_Item
    //
    // file offset: 0x019C59C4 VirtAddr: 0x019C59C4 -RVA: 0x019C59C4 
    // -BetterList<UnityEngine.Color>.set_Item
    //
    // file offset: 0x019C696C VirtAddr: 0x019C696C -RVA: 0x019C696C 
    // -BetterList<UnityEngine.Color32>.set_Item
    //
    // file offset: 0x019C77CC VirtAddr: 0x019C77CC -RVA: 0x019C77CC 
    // -BetterList<UnityEngine.Vector2>.set_Item
    //
    // file offset: 0x019C861C VirtAddr: 0x019C861C -RVA: 0x019C861C 
    // -BetterList<UnityEngine.Vector3>.set_Item
    //
    // file offset: 0x019C95CC VirtAddr: 0x019C95CC -RVA: 0x019C95CC 
    // -BetterList<UnityEngine.Vector4>.set_Item
    //
    //
    // Offset in libil2cpp.so: 0x019C1A8C (27007628), len: 88  VirtAddr: 0x019C1A8C RVA: 0x019C1A8C token: 100687850 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public void set_Item(int i, T value)
    {
        //
        // Disasemble & Code
        // 0x019C1A8C: STP x22, x21, [sp, #-0x30]! | stack[1152921514152719648] = ???;  stack[1152921514152719656] = ???;  //  dest_result_addr=1152921514152719648 |  dest_result_addr=1152921514152719656
        // 0x019C1A90: STP x20, x19, [sp, #0x10]  | stack[1152921514152719664] = ???;  stack[1152921514152719672] = ???;  //  dest_result_addr=1152921514152719664 |  dest_result_addr=1152921514152719672
        // 0x019C1A94: STP x29, x30, [sp, #0x20]  | stack[1152921514152719680] = ???;  stack[1152921514152719688] = ???;  //  dest_result_addr=1152921514152719680 |  dest_result_addr=1152921514152719688
        // 0x019C1A98: ADD x29, sp, #0x20         | X29 = (1152921514152719648 + 32) = 1152921514152719680 (0x1000000238FA7540);
        // 0x019C1A9C: LDR x21, [x0, #0x10]       | 
        // 0x019C1AA0: MOV x19, x2                | X19 = value;//m1                        
        // 0x019C1AA4: MOV w20, w1                | W20 = i;//m1                            
        // 0x019C1AA8: CBNZ x21, #0x19c1ab0       | if (X21 != 0) goto label_0;             
        if(X21 != 0)
        {
            goto label_0;
        }
        // 0x019C1AAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019C1AB0: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
        // 0x019C1AB4: SXTW x22, w20              | X22 = (long)(int)(i);                   
        // 0x019C1AB8: CMP w8, w20                | STATE = COMPARE(X21 + 24, i)            
        // 0x019C1ABC: B.HI #0x19c1acc            | if (X21 + 24 > i) goto label_1;         
        if((X21 + 24) > i)
        {
            goto label_1;
        }
        // 0x019C1AC0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C1AC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1AC8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_1:
        // 0x019C1ACC: ADD x8, x21, x22, lsl #3   | X8 = (X21 + ((long)(int)(i)) << 3);     
        var val_1 = X21 + (((long)(int)(i)) << 3);
        // 0x019C1AD0: STR x19, [x8, #0x20]       | mem2[0] = value;                         //  dest_result_addr=0
        mem2[0] = value;
        // 0x019C1AD4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1AD8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1ADC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019C1AE0: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1AE4 VirtAddr: 0x019C1AE4 -RVA: 0x019C1AE4 
    // -BetterList<object>.AllocateMore
    //
    // file offset: 0x019C0D48 VirtAddr: 0x019C0D48 -RVA: 0x019C0D48 
    // -BetterList<int>.AllocateMore
    //
    // file offset: 0x019C2864 VirtAddr: 0x019C2864 -RVA: 0x019C2864 
    // -BetterList<float>.AllocateMore
    //
    // file offset: 0x019C367C VirtAddr: 0x019C367C -RVA: 0x019C367C 
    // -BetterList<TypewriterEffect.FadeEntry>.AllocateMore
    //
    // file offset: 0x019C4844 VirtAddr: 0x019C4844 -RVA: 0x019C4844 
    // -BetterList<UICamera.DepthEntry>.AllocateMore
    //
    // file offset: 0x019C5A3C VirtAddr: 0x019C5A3C -RVA: 0x019C5A3C 
    // -BetterList<UnityEngine.Color>.AllocateMore
    //
    // file offset: 0x019C69C4 VirtAddr: 0x019C69C4 -RVA: 0x019C69C4 
    // -BetterList<UnityEngine.Color32>.AllocateMore
    //
    // file offset: 0x019C7830 VirtAddr: 0x019C7830 -RVA: 0x019C7830 
    // -BetterList<UnityEngine.Vector2>.AllocateMore
    //
    // file offset: 0x019C8694 VirtAddr: 0x019C8694 -RVA: 0x019C8694 
    // -BetterList<UnityEngine.Vector3>.AllocateMore
    //
    // file offset: 0x019C9644 VirtAddr: 0x019C9644 -RVA: 0x019C9644 
    // -BetterList<UnityEngine.Vector4>.AllocateMore
    //
    //
    // Offset in libil2cpp.so: 0x019C1AE4 (27007716), len: 264  VirtAddr: 0x019C1AE4 RVA: 0x019C1AE4 token: 100687851 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    private void AllocateMore()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        System.Array val_4;
        // 0x019C1AE4: STP x22, x21, [sp, #-0x30]! | stack[1152921514152835744] = ???;  stack[1152921514152835752] = ???;  //  dest_result_addr=1152921514152835744 |  dest_result_addr=1152921514152835752
        // 0x019C1AE8: STP x20, x19, [sp, #0x10]  | stack[1152921514152835760] = ???;  stack[1152921514152835768] = ???;  //  dest_result_addr=1152921514152835760 |  dest_result_addr=1152921514152835768
        // 0x019C1AEC: STP x29, x30, [sp, #0x20]  | stack[1152921514152835776] = ???;  stack[1152921514152835784] = ???;  //  dest_result_addr=1152921514152835776 |  dest_result_addr=1152921514152835784
        // 0x019C1AF0: ADD x29, sp, #0x20         | X29 = (1152921514152835744 + 32) = 1152921514152835776 (0x1000000238FC3AC0);
        // 0x019C1AF4: ADRP x21, #0x3739000       | X21 = 57905152 (0x3739000);             
        // 0x019C1AF8: LDRB w8, [x21, #0x5c2]     | W8 = (bool)static_value_037395C2;       
        // 0x019C1AFC: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x019C1B00: MOV x19, x0                | X19 = 1152921514152847792 (0x1000000238FC69B0);//ML01
        // 0x019C1B04: TBNZ w8, #0, #0x19c1b20    | if (static_value_037395C2 == true) goto label_0;
        // 0x019C1B08: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
        // 0x019C1B0C: LDR x8, [x8, #0xa98]       | X8 = 0x2B8F35C;                         
        // 0x019C1B10: LDR w0, [x8]               | W0 = 0x1399;                            
        // 0x019C1B14: BL #0x2782188              | X0 = sub_2782188( ?? 0x1399, ????);     
        // 0x019C1B18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x019C1B1C: STRB w8, [x21, #0x5c2]     | static_value_037395C2 = true;            //  dest_result_addr=57906626
        label_0:
        // 0x019C1B20: LDR x21, [x19, #0x10]      | 
        // 0x019C1B24: CBZ x21, #0x19c1b88        | if ( == 0) goto label_1;                
        if(==0)
        {
            goto label_1;
        }
        // 0x019C1B28: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x019C1B2C: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x019C1B30: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x019C1B34: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x019C1B38: TBZ w8, #0, #0x19c1b48     | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x019C1B3C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x019C1B40: CBNZ w8, #0x19c1b48        | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x019C1B44: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x019C1B48: LDR w8, [x21, #0x18]       | W8 = mem[57905176];                     
        // 0x019C1B4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x019C1B50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x019C1B54: ORR w2, wzr, #0x20         | W2 = 32(0x20);                          
        // 0x019C1B58: LSL w1, w8, #1             | W1 = (mem[57905176] << 1);              
        int val_1 = mem[57905176] << 1;
        // 0x019C1B5C: BL #0x1a7da0c              | X0 = UnityEngine.Mathf.Max(a:  0, b:  int val_1 = mem[57905176] << 1);
        int val_2 = UnityEngine.Mathf.Max(a:  0, b:  val_1);
        // 0x019C1B60: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1B64: MOV w21, w0                | W21 = val_2;//m1                        
        val_3 = val_2;
        // 0x019C1B68: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1B6C: LDR x20, [x8, #0x10]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        val_4 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 16];
        val_4 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        // 0x019C1B70: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1B74: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1B78: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1B7C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1B80: MOV w1, w21                | W1 = val_2;//m1                         
        // 0x019C1B84: B #0x19c1ba8               |  goto label_4;                          
        goto label_4;
        label_1:
        // 0x019C1B88: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1B8C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1B90: LDR x20, [x8, #0x10]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        val_4 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 16];
        val_4 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        // 0x019C1B94: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1B98: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1B9C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1BA0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1BA4: ORR w1, wzr, #0x20         | W1 = 32(0x20);                          
        label_4:
        // 0x019C1BA8: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1BAC: BL #0x27c1608              | X0 = sub_27C1608( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1BB0: MOV x20, x0                | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1BB4: LDR x0, [x19, #0x10]       | 
        // 0x019C1BB8: CBZ x0, #0x19c1bd8         | if (__RuntimeMethodHiddenParam + 24 + 168 + 16 == 0) goto label_6;
        if(val_4 == 0)
        {
            goto label_6;
        }
        // 0x019C1BBC: LDR w8, [x19, #0x18]       | 
        // 0x019C1BC0: CMP w8, #1                 | STATE = COMPARE(__RuntimeMethodHiddenParam + 24 + 168, 0x1)
        // 0x019C1BC4: B.LT #0x19c1bd8            | if (__RuntimeMethodHiddenParam + 24 + 168 < 0x1) goto label_6;
        if((__RuntimeMethodHiddenParam + 24 + 168) < 1)
        {
            goto label_6;
        }
        // 0x019C1BC8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
        // 0x019C1BCC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x019C1BD0: MOV x1, x20                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1BD4: BL #0x18d10c0              | __RuntimeMethodHiddenParam + 24 + 168 + 16.CopyTo(array:  val_4, index:  0);
        val_4.CopyTo(array:  val_4, index:  0);
        label_6:
        // 0x019C1BD8: STR x20, [x19, #0x10]      | mem[1152921514152847808] = __RuntimeMethodHiddenParam + 24 + 168 + 16;  //  dest_result_addr=1152921514152847808
        mem[1152921514152847808] = val_4;
        // 0x019C1BDC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1BE0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1BE4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019C1BE8: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1BEC VirtAddr: 0x019C1BEC -RVA: 0x019C1BEC 
    // -BetterList<object>.Trim
    //
    // file offset: 0x019C0E50 VirtAddr: 0x019C0E50 -RVA: 0x019C0E50 
    // -BetterList<int>.Trim
    //
    // file offset: 0x019C296C VirtAddr: 0x019C296C -RVA: 0x019C296C 
    // -BetterList<float>.Trim
    //
    // file offset: 0x019C3784 VirtAddr: 0x019C3784 -RVA: 0x019C3784 
    // -BetterList<TypewriterEffect.FadeEntry>.Trim
    //
    // file offset: 0x019C494C VirtAddr: 0x019C494C -RVA: 0x019C494C 
    // -BetterList<UICamera.DepthEntry>.Trim
    //
    // file offset: 0x019C5B44 VirtAddr: 0x019C5B44 -RVA: 0x019C5B44 
    // -BetterList<UnityEngine.Color>.Trim
    //
    // file offset: 0x019C6ACC VirtAddr: 0x019C6ACC -RVA: 0x019C6ACC 
    // -BetterList<UnityEngine.Color32>.Trim
    //
    // file offset: 0x019C7938 VirtAddr: 0x019C7938 -RVA: 0x019C7938 
    // -BetterList<UnityEngine.Vector2>.Trim
    //
    // file offset: 0x019C879C VirtAddr: 0x019C879C -RVA: 0x019C879C 
    // -BetterList<UnityEngine.Vector3>.Trim
    //
    // file offset: 0x019C974C VirtAddr: 0x019C974C -RVA: 0x019C974C 
    // -BetterList<UnityEngine.Vector4>.Trim
    //
    //
    // Offset in libil2cpp.so: 0x019C1BEC (27007980), len: 264  VirtAddr: 0x019C1BEC RVA: 0x019C1BEC token: 100687852 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    private void Trim()
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        // 0x019C1BEC: STP x24, x23, [sp, #-0x40]! | stack[1152921514152947728] = ???;  stack[1152921514152947736] = ???;  //  dest_result_addr=1152921514152947728 |  dest_result_addr=1152921514152947736
        // 0x019C1BF0: STP x22, x21, [sp, #0x10]  | stack[1152921514152947744] = ???;  stack[1152921514152947752] = ???;  //  dest_result_addr=1152921514152947744 |  dest_result_addr=1152921514152947752
        // 0x019C1BF4: STP x20, x19, [sp, #0x20]  | stack[1152921514152947760] = ???;  stack[1152921514152947768] = ???;  //  dest_result_addr=1152921514152947760 |  dest_result_addr=1152921514152947768
        // 0x019C1BF8: STP x29, x30, [sp, #0x30]  | stack[1152921514152947776] = ???;  stack[1152921514152947784] = ???;  //  dest_result_addr=1152921514152947776 |  dest_result_addr=1152921514152947784
        // 0x019C1BFC: ADD x29, sp, #0x30         | X29 = (1152921514152947728 + 48) = 1152921514152947776 (0x1000000238FDF040);
        // 0x019C1C00: MOV x19, x0                | X19 = 1152921514152959792 (0x1000000238FE1F30);//ML01
        // 0x019C1C04: LDR w21, [x19, #0x18]      | 
        // 0x019C1C08: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x019C1C0C: CMP w21, #1                | STATE = COMPARE(W21, 0x1)               
        // 0x019C1C10: B.LT #0x19c1cdc            | if (W21 < 0x1) goto label_0;            
        if(W21 < 1)
        {
            goto label_0;
        }
        // 0x019C1C14: LDR x22, [x19, #0x10]      | 
        // 0x019C1C18: CBNZ x22, #0x19c1c20       | if (X22 != 0) goto label_1;             
        if(X22 != 0)
        {
            goto label_1;
        }
        // 0x019C1C1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_1:
        // 0x019C1C20: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
        // 0x019C1C24: CMP w21, w8                | STATE = COMPARE(W21, X22 + 24)          
        // 0x019C1C28: B.GE #0x19c1ce0            | if (W21 >= X22 + 24) goto label_9;      
        if(W21 >= (X22 + 24))
        {
            goto label_9;
        }
        // 0x019C1C2C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1C30: LDR w21, [x19, #0x18]      | 
        // 0x019C1C34: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1C38: LDR x20, [x8, #0x10]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        // 0x019C1C3C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1C40: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1C44: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1C48: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1C4C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1C50: MOV x1, x21                | X1 = X21;//m1                           
        // 0x019C1C54: BL #0x27c1608              | X0 = sub_27C1608( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1C58: LDR w8, [x19, #0x18]       | 
        // 0x019C1C5C: MOV x20, x0                | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 16;//m1
        // 0x019C1C60: CMP w8, #1                 | STATE = COMPARE(__RuntimeMethodHiddenParam + 24 + 168, 0x1)
        // 0x019C1C64: B.LT #0x19c1cd4            | if (__RuntimeMethodHiddenParam + 24 + 168 < 0x1) goto label_3;
        if((__RuntimeMethodHiddenParam + 24 + 168) < 1)
        {
            goto label_3;
        }
        // 0x019C1C68: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        label_8:
        // 0x019C1C6C: LDR x23, [x19, #0x10]      | 
        // 0x019C1C70: CBNZ x23, #0x19c1c78       | if (X23 != 0) goto label_4;             
        if(X23 != 0)
        {
            goto label_4;
        }
        // 0x019C1C74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        label_4:
        // 0x019C1C78: LDR w8, [x23, #0x18]       | W8 = X23 + 24;                          
        // 0x019C1C7C: SXTW x22, w21              | X22 = 0 (0x00000000);                   
        // 0x019C1C80: CMP w21, w8                | STATE = COMPARE(0x0, X23 + 24)          
        // 0x019C1C84: B.LO #0x19c1c94            | if (0 < X23 + 24) goto label_5;         
        if(0 < (X23 + 24))
        {
            goto label_5;
        }
        // 0x019C1C88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1C8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1C90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        label_5:
        // 0x019C1C94: ADD x8, x23, x22, lsl #3   | X8 = (X23 + 0);                         
        var val_1 = X23 + 0;
        // 0x019C1C98: LDR x23, [x8, #0x20]       | X23 = (X23 + 0) + 32;                   
        // 0x019C1C9C: CBNZ x20, #0x19c1ca4       | if (__RuntimeMethodHiddenParam + 24 + 168 + 16 != 0) goto label_6;
        if((__RuntimeMethodHiddenParam + 24 + 168 + 16) != 0)
        {
            goto label_6;
        }
        // 0x019C1CA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        label_6:
        // 0x019C1CA4: LDR w8, [x20, #0x18]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 16 + 24;
        // 0x019C1CA8: CMP w21, w8                | STATE = COMPARE(0x0, __RuntimeMethodHiddenParam + 24 + 168 + 16 + 24)
        // 0x019C1CAC: B.LO #0x19c1cbc            | if (0 < __RuntimeMethodHiddenParam + 24 + 168 + 16 + 24) goto label_7;
        if(0 < (__RuntimeMethodHiddenParam + 24 + 168 + 16 + 24))
        {
            goto label_7;
        }
        // 0x019C1CB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        // 0x019C1CB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1CB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? __RuntimeMethodHiddenParam + 24 + 168 + 16, ????);
        label_7:
        // 0x019C1CBC: ADD x8, x20, x22, lsl #3   | X8 = (__RuntimeMethodHiddenParam + 24 + 168 + 16 + 0);
        var val_2 = (__RuntimeMethodHiddenParam + 24 + 168 + 16) + 0;
        // 0x019C1CC0: STR x23, [x8, #0x20]       | mem2[0] = (X23 + 0) + 32;                //  dest_result_addr=0
        mem2[0] = (X23 + 0) + 32;
        // 0x019C1CC4: LDR w8, [x19, #0x18]       | 
        // 0x019C1CC8: ADD w21, w21, #1           | W21 = (0 + 1);                          
        val_3 = 0 + 1;
        // 0x019C1CCC: CMP w21, w8                | STATE = COMPARE((0 + 1), (__RuntimeMethodHiddenParam + 24 + 168 + 16 + 0))
        // 0x019C1CD0: B.LT #0x19c1c6c            | if (val_3 < val_2) goto label_8;        
        if(val_3 < val_2)
        {
            goto label_8;
        }
        label_3:
        // 0x019C1CD4: STR x20, [x19, #0x10]      | mem[1152921514152959808] = __RuntimeMethodHiddenParam + 24 + 168 + 16;  //  dest_result_addr=1152921514152959808
        mem[1152921514152959808] = __RuntimeMethodHiddenParam + 24 + 168 + 16;
        // 0x019C1CD8: B #0x19c1ce0               |  goto label_9;                          
        goto label_9;
        label_0:
        // 0x019C1CDC: STR xzr, [x19, #0x10]      | mem[1152921514152959808] = 0x0;          //  dest_result_addr=1152921514152959808
        mem[1152921514152959808] = 0;
        label_9:
        // 0x019C1CE0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1CE4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1CE8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019C1CEC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019C1CF0: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1CF4 VirtAddr: 0x019C1CF4 -RVA: 0x019C1CF4 
    // -BetterList<object>.Clear
    // -BetterList<string>.Clear
    // -BetterList<UIDrawCall>.Clear
    // -BetterList<UITextList.Paragraph>.Clear
    //
    // file offset: 0x019C2A74 VirtAddr: 0x019C2A74 -RVA: 0x019C2A74 
    // -BetterList<float>.Clear
    //
    // file offset: 0x019C5C64 VirtAddr: 0x019C5C64 -RVA: 0x019C5C64 
    // -BetterList<UnityEngine.Color>.Clear
    //
    // file offset: 0x019C38C4 VirtAddr: 0x019C38C4 -RVA: 0x019C38C4 
    // -BetterList<TypewriterEffect.FadeEntry>.Clear
    //
    // file offset: 0x019C4A88 VirtAddr: 0x019C4A88 -RVA: 0x019C4A88 
    // -BetterList<UICamera.DepthEntry>.Clear
    //
    // file offset: 0x019C88B8 VirtAddr: 0x019C88B8 -RVA: 0x019C88B8 
    // -BetterList<UnityEngine.Vector3>.Clear
    //
    // file offset: 0x019C7A40 VirtAddr: 0x019C7A40 -RVA: 0x019C7A40 
    // -BetterList<UnityEngine.Vector2>.Clear
    //
    // file offset: 0x019C6BD4 VirtAddr: 0x019C6BD4 -RVA: 0x019C6BD4 
    // -BetterList<UnityEngine.Color32>.Clear
    //
    // file offset: 0x019C986C VirtAddr: 0x019C986C -RVA: 0x019C986C 
    // -BetterList<UnityEngine.Vector4>.Clear
    //
    // file offset: 0x019C0F58 VirtAddr: 0x019C0F58 -RVA: 0x019C0F58 
    // -BetterList<int>.Clear
    //
    //
    // Offset in libil2cpp.so: 0x019C1CF4 (27008244), len: 8  VirtAddr: 0x019C1CF4 RVA: 0x019C1CF4 token: 100687853 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public void Clear()
    {
        //
        // Disasemble & Code
        // 0x019C1CF4: STR wzr, [x0, #0x18]       | mem[1152921514153071816] = 0x0;          //  dest_result_addr=1152921514153071816
        mem[1152921514153071816] = 0;
        // 0x019C1CF8: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1CFC VirtAddr: 0x019C1CFC -RVA: 0x019C1CFC 
    // -BetterList<object>.Release
    //
    // file offset: 0x019C0F60 VirtAddr: 0x019C0F60 -RVA: 0x019C0F60 
    // -BetterList<int>.Release
    //
    // file offset: 0x019C2A7C VirtAddr: 0x019C2A7C -RVA: 0x019C2A7C 
    // -BetterList<float>.Release
    //
    // file offset: 0x019C38CC VirtAddr: 0x019C38CC -RVA: 0x019C38CC 
    // -BetterList<TypewriterEffect.FadeEntry>.Release
    //
    // file offset: 0x019C4A90 VirtAddr: 0x019C4A90 -RVA: 0x019C4A90 
    // -BetterList<UICamera.DepthEntry>.Release
    //
    // file offset: 0x019C5C6C VirtAddr: 0x019C5C6C -RVA: 0x019C5C6C 
    // -BetterList<UnityEngine.Color>.Release
    //
    // file offset: 0x019C6BDC VirtAddr: 0x019C6BDC -RVA: 0x019C6BDC 
    // -BetterList<UnityEngine.Color32>.Release
    //
    // file offset: 0x019C7A48 VirtAddr: 0x019C7A48 -RVA: 0x019C7A48 
    // -BetterList<UnityEngine.Vector2>.Release
    //
    // file offset: 0x019C88C0 VirtAddr: 0x019C88C0 -RVA: 0x019C88C0 
    // -BetterList<UnityEngine.Vector3>.Release
    //
    // file offset: 0x019C9874 VirtAddr: 0x019C9874 -RVA: 0x019C9874 
    // -BetterList<UnityEngine.Vector4>.Release
    //
    //
    // Offset in libil2cpp.so: 0x019C1CFC (27008252), len: 12  VirtAddr: 0x019C1CFC RVA: 0x019C1CFC token: 100687854 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public void Release()
    {
        //
        // Disasemble & Code
        // 0x019C1CFC: STR wzr, [x0, #0x18]       | mem[1152921514153183816] = 0x0;          //  dest_result_addr=1152921514153183816
        mem[1152921514153183816] = 0;
        // 0x019C1D00: STR xzr, [x0, #0x10]       | mem[1152921514153183808] = 0x0;          //  dest_result_addr=1152921514153183808
        mem[1152921514153183808] = 0;
        // 0x019C1D04: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1D08 VirtAddr: 0x019C1D08 -RVA: 0x019C1D08 
    // -BetterList<object>.Add
    // -BetterList<string>.Add
    // -BetterList<UICamera>.Add
    // -BetterList<UIDrawCall>.Add
    // -BetterList<UIKeyNavigation>.Add
    // -BetterList<UILabel>.Add
    // -BetterList<UIRect>.Add
    // -BetterList<UIScrollView>.Add
    // -BetterList<UITextList.Paragraph>.Add
    // -BetterList<UIToggle>.Add
    //
    // file offset: 0x019C5C78 VirtAddr: 0x019C5C78 -RVA: 0x019C5C78 
    // -BetterList<UnityEngine.Color>.Add
    //
    // file offset: 0x019C2A88 VirtAddr: 0x019C2A88 -RVA: 0x019C2A88 
    // -BetterList<float>.Add
    //
    // file offset: 0x019C88CC VirtAddr: 0x019C88CC -RVA: 0x019C88CC 
    // -BetterList<UnityEngine.Vector3>.Add
    //
    // file offset: 0x019C7A54 VirtAddr: 0x019C7A54 -RVA: 0x019C7A54 
    // -BetterList<UnityEngine.Vector2>.Add
    //
    // file offset: 0x019C6BE8 VirtAddr: 0x019C6BE8 -RVA: 0x019C6BE8 
    // -BetterList<UnityEngine.Color32>.Add
    //
    // file offset: 0x019C0F6C VirtAddr: 0x019C0F6C -RVA: 0x019C0F6C 
    // -BetterList<int>.Add
    //
    // file offset: 0x019C38D8 VirtAddr: 0x019C38D8 -RVA: 0x019C38D8 
    // -BetterList<TypewriterEffect.FadeEntry>.Add
    //
    // file offset: 0x019C4A9C VirtAddr: 0x019C4A9C -RVA: 0x019C4A9C 
    // -BetterList<UICamera.DepthEntry>.Add
    //
    // file offset: 0x019C9880 VirtAddr: 0x019C9880 -RVA: 0x019C9880 
    // -BetterList<UnityEngine.Vector4>.Add
    //
    //
    // Offset in libil2cpp.so: 0x019C1D08 (27008264), len: 164  VirtAddr: 0x019C1D08 RVA: 0x019C1D08 token: 100687855 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public void Add(T item)
    {
        //
        // Disasemble & Code
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x019C1D08: STP x22, x21, [sp, #-0x30]! | stack[1152921514153287840] = ???;  stack[1152921514153287848] = ???;  //  dest_result_addr=1152921514153287840 |  dest_result_addr=1152921514153287848
        // 0x019C1D0C: STP x20, x19, [sp, #0x10]  | stack[1152921514153287856] = ???;  stack[1152921514153287864] = ???;  //  dest_result_addr=1152921514153287856 |  dest_result_addr=1152921514153287864
        // 0x019C1D10: STP x29, x30, [sp, #0x20]  | stack[1152921514153287872] = ???;  stack[1152921514153287880] = ???;  //  dest_result_addr=1152921514153287872 |  dest_result_addr=1152921514153287880
        // 0x019C1D14: ADD x29, sp, #0x20         | X29 = (1152921514153287840 + 32) = 1152921514153287872 (0x10000002390320C0);
        // 0x019C1D18: MOV x20, x0                | X20 = 1152921514153299888 (0x1000000239034FB0);//ML01
        // 0x019C1D1C: LDR x21, [x20, #0x10]      | 
        // 0x019C1D20: MOV x19, x1                | X19 = item;//m1                         
        // 0x019C1D24: CBZ x21, #0x19c1d38        | if (X21 == 0) goto label_0;             
        if(X21 == 0)
        {
            goto label_0;
        }
        // 0x019C1D28: LDR w22, [x20, #0x18]      | 
        // 0x019C1D2C: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
        // 0x019C1D30: CMP w22, w8                | STATE = COMPARE(W22, X21 + 24)          
        // 0x019C1D34: B.NE #0x19c1d70            | if (W22 != X21 + 24) goto label_1;      
        if(W22 != (X21 + 24))
        {
            goto label_1;
        }
        label_0:
        // 0x019C1D38: LDR x8, [x2, #0x18]        | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1D3C: MOV x0, x20                | X0 = 1152921514153299888 (0x1000000239034FB0);//ML01
        // 0x019C1D40: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1D44: LDR x1, [x8, #0x18]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
        // 0x019C1D48: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
        // 0x019C1D4C: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24();
        // 0x019C1D50: LDR w22, [x20, #0x18]      | 
        // 0x019C1D54: LDR x21, [x20, #0x10]      | 
        // 0x019C1D58: ADD w8, w22, #1            | W8 = (W22 + 1);                         
        var val_1 = W22 + 1;
        // 0x019C1D5C: STR w8, [x20, #0x18]       | mem[1152921514153299912] = (W22 + 1);    //  dest_result_addr=1152921514153299912
        mem[1152921514153299912] = val_1;
        // 0x019C1D60: CBNZ x21, #0x19c1d78       | if (X21 != 0) goto label_3;             
        if(X21 != 0)
        {
            goto label_3;
        }
        // 0x019C1D64: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x019C1D68: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
        val_4 = 0;
        // 0x019C1D6C: B #0x19c1d78               |  goto label_3;                          
        goto label_3;
        label_1:
        // 0x019C1D70: ADD w8, w22, #1            | W8 = (W22 + 1);                         
        var val_2 = W22 + 1;
        // 0x019C1D74: STR w8, [x20, #0x18]       | mem[1152921514153299912] = (W22 + 1);    //  dest_result_addr=1152921514153299912
        mem[1152921514153299912] = val_2;
        label_3:
        // 0x019C1D78: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
        // 0x019C1D7C: SXTW x20, w22              | X20 = (long)(int)(W22);                 
        // 0x019C1D80: CMP w22, w8                | STATE = COMPARE(W22, X21 + 24)          
        // 0x019C1D84: B.LO #0x19c1d94            | if (W22 < X21 + 24) goto label_4;       
        if(W22 < (X21 + 24))
        {
            goto label_4;
        }
        // 0x019C1D88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C1D8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1D90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_4:
        // 0x019C1D94: ADD x8, x21, x20, lsl #3   | X8 = (X21 + ((long)(int)(W22)) << 3);   
        var val_3 = X21 + (((long)(int)(W22)) << 3);
        // 0x019C1D98: STR x19, [x8, #0x20]       | mem2[0] = item;                          //  dest_result_addr=0
        mem2[0] = item;
        // 0x019C1D9C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1DA0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1DA4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019C1DA8: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1DAC VirtAddr: 0x019C1DAC -RVA: 0x019C1DAC 
    // -BetterList<object>.Insert
    //
    // file offset: 0x019C1010 VirtAddr: 0x019C1010 -RVA: 0x019C1010 
    // -BetterList<int>.Insert
    //
    // file offset: 0x019C2B34 VirtAddr: 0x019C2B34 -RVA: 0x019C2B34 
    // -BetterList<float>.Insert
    //
    // file offset: 0x019C39B0 VirtAddr: 0x019C39B0 -RVA: 0x019C39B0 
    // -BetterList<TypewriterEffect.FadeEntry>.Insert
    //
    // file offset: 0x019C4B74 VirtAddr: 0x019C4B74 -RVA: 0x019C4B74 
    // -BetterList<UICamera.DepthEntry>.Insert
    //
    // file offset: 0x019C5D3C VirtAddr: 0x019C5D3C -RVA: 0x019C5D3C 
    // -BetterList<UnityEngine.Color>.Insert
    //
    // file offset: 0x019C6C8C VirtAddr: 0x019C6C8C -RVA: 0x019C6C8C 
    // -BetterList<UnityEngine.Color32>.Insert
    //
    // file offset: 0x019C7B04 VirtAddr: 0x019C7B04 -RVA: 0x019C7B04 
    // -BetterList<UnityEngine.Vector2>.Insert
    //
    // file offset: 0x019C8990 VirtAddr: 0x019C8990 -RVA: 0x019C8990 
    // -BetterList<UnityEngine.Vector3>.Insert
    //
    // file offset: 0x019C9944 VirtAddr: 0x019C9944 -RVA: 0x019C9944 
    // -BetterList<UnityEngine.Vector4>.Insert
    //
    //
    // Offset in libil2cpp.so: 0x019C1DAC (27008428), len: 352  VirtAddr: 0x019C1DAC RVA: 0x019C1DAC token: 100687856 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public void Insert(int index, T item)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        // 0x019C1DAC: STP x26, x25, [sp, #-0x50]! | stack[1152921514153408000] = ???;  stack[1152921514153408008] = ???;  //  dest_result_addr=1152921514153408000 |  dest_result_addr=1152921514153408008
        // 0x019C1DB0: STP x24, x23, [sp, #0x10]  | stack[1152921514153408016] = ???;  stack[1152921514153408024] = ???;  //  dest_result_addr=1152921514153408016 |  dest_result_addr=1152921514153408024
        // 0x019C1DB4: STP x22, x21, [sp, #0x20]  | stack[1152921514153408032] = ???;  stack[1152921514153408040] = ???;  //  dest_result_addr=1152921514153408032 |  dest_result_addr=1152921514153408040
        // 0x019C1DB8: STP x20, x19, [sp, #0x30]  | stack[1152921514153408048] = ???;  stack[1152921514153408056] = ???;  //  dest_result_addr=1152921514153408048 |  dest_result_addr=1152921514153408056
        // 0x019C1DBC: STP x29, x30, [sp, #0x40]  | stack[1152921514153408064] = ???;  stack[1152921514153408072] = ???;  //  dest_result_addr=1152921514153408064 |  dest_result_addr=1152921514153408072
        // 0x019C1DC0: ADD x29, sp, #0x40         | X29 = (1152921514153408000 + 64) = 1152921514153408064 (0x100000023904F640);
        // 0x019C1DC4: MOV x19, x0                | X19 = 1152921514153420080 (0x1000000239052530);//ML01
        // 0x019C1DC8: LDR x8, [x19, #0x10]       | 
        // 0x019C1DCC: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
        var val_7 = __RuntimeMethodHiddenParam;
        // 0x019C1DD0: MOV x20, x2                | X20 = item;//m1                         
        // 0x019C1DD4: MOV w21, w1                | W21 = index;//m1                        
        // 0x019C1DD8: CBZ x8, #0x19c1dec         | if (X8 == 0) goto label_0;              
        if(X8 == 0)
        {
            goto label_0;
        }
        // 0x019C1DDC: LDR w9, [x19, #0x18]       | 
        // 0x019C1DE0: LDR w8, [x8, #0x18]        | W8 = X8 + 24;                           
        // 0x019C1DE4: CMP w9, w8                 | STATE = COMPARE(W9, X8 + 24)            
        // 0x019C1DE8: B.NE #0x19c1e04            | if (W9 != X8 + 24) goto label_1;        
        if(W9 != (X8 + 24))
        {
            goto label_1;
        }
        label_0:
        // 0x019C1DEC: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1DF0: MOV x0, x19                | X0 = 1152921514153420080 (0x1000000239052530);//ML01
        // 0x019C1DF4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1DF8: LDR x1, [x8, #0x18]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
        // 0x019C1DFC: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
        // 0x019C1E00: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24();
        label_1:
        // 0x019C1E04: TBNZ w21, #0x1f, #0x19c1edc | if ((index & 0x80000000) != 0) goto label_3;
        if((index & 2147483648) != 0)
        {
            goto label_3;
        }
        // 0x019C1E08: LDRSW x25, [x19, #0x18]    | 
        // 0x019C1E0C: CMP w25, w21               | STATE = COMPARE(W25, index)             
        // 0x019C1E10: B.LE #0x19c1edc            | if (W25 <= index) goto label_3;         
        if(W25 <= index)
        {
            goto label_3;
        }
        // 0x019C1E14: LDR x22, [x19, #0x10]      | 
        // 0x019C1E18: SXTW x23, w21              | X23 = (long)(int)(index);               
        // 0x019C1E1C: SUB w24, w25, #1           | W24 = (W25 - 1);                        
        var val_1 = W25 - 1;
        // 0x019C1E20: CMP x22, #0                | STATE = COMPARE(__RuntimeMethodHiddenParam, 0x0)
        // 0x019C1E24: CSET w8, eq                | W8 = __RuntimeMethodHiddenParam == 0x0 ? 1 : 0;
        var val_2 = (val_7 == 0) ? 1 : 0;
        label_7:
        // 0x019C1E28: TBZ w8, #0, #0x19c1e30     | if ((__RuntimeMethodHiddenParam == 0x0 ? 1 : 0 & 0x1) == 0) goto label_4;
        if((val_2 & 1) == 0)
        {
            goto label_4;
        }
        // 0x019C1E2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_4:
        // 0x019C1E30: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        val_7 = mem[__RuntimeMethodHiddenParam + 24];
        val_7 = __RuntimeMethodHiddenParam + 24;
        // 0x019C1E34: CMP w24, w8                | STATE = COMPARE((W25 - 1), __RuntimeMethodHiddenParam + 24)
        // 0x019C1E38: B.LO #0x19c1e4c            | if (val_1 < val_7) goto label_5;        
        if(val_1 < val_7)
        {
            goto label_5;
        }
        // 0x019C1E3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C1E40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1E44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        // 0x019C1E48: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        val_7 = mem[__RuntimeMethodHiddenParam + 24];
        val_7 = __RuntimeMethodHiddenParam + 24;
        label_5:
        // 0x019C1E4C: ADD x22, x22, x25, lsl #3  | X22 = (__RuntimeMethodHiddenParam + (X25) << 3);
        val_7 = val_7 + ((X25) << 3);
        // 0x019C1E50: LDR x26, [x22, #0x18]      | X26 = (__RuntimeMethodHiddenParam + (X25) << 3) + 24;
        // 0x019C1E54: SUB x25, x25, #1           | X25 = (X25 - 1);                        
        var val_3 = X25 - 1;
        // 0x019C1E58: ADD w9, w24, #1            | W9 = ((W25 - 1) + 1);                   
        var val_4 = val_1 + 1;
        // 0x019C1E5C: CMP w9, w8                 | STATE = COMPARE(((W25 - 1) + 1), __RuntimeMethodHiddenParam + 24)
        // 0x019C1E60: B.LO #0x19c1e70            | if (val_4 < val_7) goto label_6;        
        if(val_4 < val_7)
        {
            goto label_6;
        }
        // 0x019C1E64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C1E68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1E6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_6:
        // 0x019C1E70: STR x26, [x22, #0x20]      | mem2[0] = (__RuntimeMethodHiddenParam + (X25) << 3) + 24;  //  dest_result_addr=0
        mem2[0] = (__RuntimeMethodHiddenParam + (X25) << 3) + 24;
        // 0x019C1E74: LDR x22, [x19, #0x10]      | 
        // 0x019C1E78: SUB w24, w24, #1           | W24 = ((W25 - 1) - 1);                  
        val_1 = val_1 - 1;
        // 0x019C1E7C: CMP x22, #0                | STATE = COMPARE((__RuntimeMethodHiddenParam + (X25) << 3), 0x0)
        // 0x019C1E80: CSET w8, eq                | W8 = __RuntimeMethodHiddenParam == 0x0 ? 1 : 0;
        var val_5 = (val_7 == 0) ? 1 : 0;
        // 0x019C1E84: CMP x25, x23               | STATE = COMPARE((X25 - 1), (long)(int)(index))
        // 0x019C1E88: B.GT #0x19c1e28            | if (val_3 > (long)index) goto label_7;  
        if(val_3 > (long)index)
        {
            goto label_7;
        }
        // 0x019C1E8C: CBNZ x22, #0x19c1e94       | if ((__RuntimeMethodHiddenParam + (X25) << 3) != 0) goto label_8;
        if(val_7 != 0)
        {
            goto label_8;
        }
        // 0x019C1E90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_8:
        // 0x019C1E94: LDR w8, [x22, #0x18]       | W8 = (__RuntimeMethodHiddenParam + (X25) << 3) + 24;
        // 0x019C1E98: SXTW x23, w21              | X23 = (long)(int)(index);               
        // 0x019C1E9C: CMP w8, w21                | STATE = COMPARE((__RuntimeMethodHiddenParam + (X25) << 3) + 24, index)
        // 0x019C1EA0: B.HI #0x19c1eb0            | if ((__RuntimeMethodHiddenParam + (X25) << 3) + 24 > index) goto label_9;
        if(((__RuntimeMethodHiddenParam + (X25) << 3) + 24) > index)
        {
            goto label_9;
        }
        // 0x019C1EA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C1EA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1EAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_9:
        // 0x019C1EB0: ADD x8, x22, x23, lsl #3   | X8 = ((__RuntimeMethodHiddenParam + (X25) << 3) + ((long)(int)(index)) << 3);
        var val_6 = val_7 + (((long)(int)(index)) << 3);
        // 0x019C1EB4: STR x20, [x8, #0x20]       | mem2[0] = item;                          //  dest_result_addr=0
        mem2[0] = item;
        // 0x019C1EB8: LDR w8, [x19, #0x18]       | 
        // 0x019C1EBC: ADD w8, w8, #1             | W8 = (((__RuntimeMethodHiddenParam + (X25) << 3) + ((long)(int)(index)) << 3) + 1);
        val_6 = val_6 + 1;
        // 0x019C1EC0: STR w8, [x19, #0x18]       | mem[1152921514153420104] = (((__RuntimeMethodHiddenParam + (X25) << 3) + ((long)(int)(index)) << 3) + 1);  //  dest_result_addr=1152921514153420104
        mem[1152921514153420104] = val_6;
        // 0x019C1EC4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1EC8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1ECC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x019C1ED0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x019C1ED4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x019C1ED8: RET                        |  return;                                
        return;
        label_3:
        // 0x019C1EDC: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C1EE0: MOV x0, x19                | X0 = 1152921514153420080 (0x1000000239052530);//ML01
        // 0x019C1EE4: MOV x1, x20                | X1 = item;//m1                          
        // 0x019C1EE8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C1EEC: LDR x2, [x8, #0x20]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
        // 0x019C1EF0: LDR x3, [x2]               | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
        // 0x019C1EF4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1EF8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1EFC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
        // 0x019C1F00: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
        // 0x019C1F04: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
        // 0x019C1F08: BR x3                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 32;
        goto __RuntimeMethodHiddenParam + 24 + 168 + 32;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1F0C VirtAddr: 0x019C1F0C -RVA: 0x019C1F0C 
    // -BetterList<object>.Contains
    //
    // file offset: 0x019C1170 VirtAddr: 0x019C1170 -RVA: 0x019C1170 
    // -BetterList<int>.Contains
    //
    // file offset: 0x019C2CA0 VirtAddr: 0x019C2CA0 -RVA: 0x019C2CA0 
    // -BetterList<float>.Contains
    //
    // file offset: 0x019C3B74 VirtAddr: 0x019C3B74 -RVA: 0x019C3B74 
    // -BetterList<TypewriterEffect.FadeEntry>.Contains
    //
    // file offset: 0x019C4D44 VirtAddr: 0x019C4D44 -RVA: 0x019C4D44 
    // -BetterList<UICamera.DepthEntry>.Contains
    //
    // file offset: 0x019C5F08 VirtAddr: 0x019C5F08 -RVA: 0x019C5F08 
    // -BetterList<UnityEngine.Color>.Contains
    //
    // file offset: 0x019C6DEC VirtAddr: 0x019C6DEC -RVA: 0x019C6DEC 
    // -BetterList<UnityEngine.Color32>.Contains
    //
    // file offset: 0x019C7C94 VirtAddr: 0x019C7C94 -RVA: 0x019C7C94 
    // -BetterList<UnityEngine.Vector2>.Contains
    //
    // file offset: 0x019C8B44 VirtAddr: 0x019C8B44 -RVA: 0x019C8B44 
    // -BetterList<UnityEngine.Vector3>.Contains
    //
    // file offset: 0x019C9B10 VirtAddr: 0x019C9B10 -RVA: 0x019C9B10 
    // -BetterList<UnityEngine.Vector4>.Contains
    //
    //
    // Offset in libil2cpp.so: 0x019C1F0C (27008780), len: 216  VirtAddr: 0x019C1F0C RVA: 0x019C1F0C token: 100687857 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public bool Contains(T item)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        //  | 
        var val_5;
        // 0x019C1F0C: STP x24, x23, [sp, #-0x40]! | stack[1152921514153528208] = ???;  stack[1152921514153528216] = ???;  //  dest_result_addr=1152921514153528208 |  dest_result_addr=1152921514153528216
        // 0x019C1F10: STP x22, x21, [sp, #0x10]  | stack[1152921514153528224] = ???;  stack[1152921514153528232] = ???;  //  dest_result_addr=1152921514153528224 |  dest_result_addr=1152921514153528232
        // 0x019C1F14: STP x20, x19, [sp, #0x20]  | stack[1152921514153528240] = ???;  stack[1152921514153528248] = ???;  //  dest_result_addr=1152921514153528240 |  dest_result_addr=1152921514153528248
        // 0x019C1F18: STP x29, x30, [sp, #0x30]  | stack[1152921514153528256] = ???;  stack[1152921514153528264] = ???;  //  dest_result_addr=1152921514153528256 |  dest_result_addr=1152921514153528264
        // 0x019C1F1C: ADD x29, sp, #0x30         | X29 = (1152921514153528208 + 48) = 1152921514153528256 (0x100000023906CBC0);
        // 0x019C1F20: MOV x19, x0                | X19 = 1152921514153540272 (0x100000023906FAB0);//ML01
        // 0x019C1F24: LDR x22, [x19, #0x10]      | 
        // 0x019C1F28: MOV x20, x1                | X20 = item;//m1                         
        // 0x019C1F2C: CBZ x22, #0x19c1fc4        | if (X22 == 0) goto label_0;             
        if(X22 == 0)
        {
            goto label_0;
        }
        // 0x019C1F30: LDR w8, [x19, #0x18]       | 
        // 0x019C1F34: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_4 = 0;
        // 0x019C1F38: CMP w8, #1                 | STATE = COMPARE(W8, 0x1)                
        // 0x019C1F3C: B.LT #0x19c1fd0            | if (W8 < 0x1) goto label_9;             
        if(W8 < 1)
        {
            goto label_9;
        }
        // 0x019C1F40: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_5 = 0;
        // 0x019C1F44: B #0x19c1f4c               |  goto label_2;                          
        goto label_2;
        label_8:
        // 0x019C1F48: LDR x22, [x19, #0x10]      | 
        label_2:
        // 0x019C1F4C: CBNZ x22, #0x19c1f54       | if (X22 != 0) goto label_3;             
        if(X22 != 0)
        {
            goto label_3;
        }
        // 0x019C1F50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_3:
        // 0x019C1F54: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
        // 0x019C1F58: SXTW x23, w21              | X23 = 0 (0x00000000);                   
        // 0x019C1F5C: CMP w21, w8                | STATE = COMPARE(0x0, X22 + 24)          
        // 0x019C1F60: B.LO #0x19c1f70            | if (val_5 < X22 + 24) goto label_4;     
        if(val_5 < (X22 + 24))
        {
            goto label_4;
        }
        // 0x019C1F64: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C1F68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1F6C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_4:
        // 0x019C1F70: ADD x23, x22, x23, lsl #3  | X23 = (X22 + 0);                        
        var val_1 = X22 + 0;
        // 0x019C1F74: LDR x8, [x23, #0x20]!      | X8 = (X22 + 0) + 32;                    
        // 0x019C1F78: CBNZ x8, #0x19c1f80        | if ((X22 + 0) + 32 != 0) goto label_5;  
        if(((X22 + 0) + 32) != 0)
        {
            goto label_5;
        }
        // 0x019C1F7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_5:
        // 0x019C1F80: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
        // 0x019C1F84: CMP w21, w8                | STATE = COMPARE(0x0, X22 + 24)          
        // 0x019C1F88: B.LO #0x19c1f98            | if (val_5 < X22 + 24) goto label_6;     
        if(val_5 < (X22 + 24))
        {
            goto label_6;
        }
        // 0x019C1F8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C1F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C1F94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_6:
        // 0x019C1F98: LDR x0, [x23]              | X0 = (X22 + 0) + 32;                    
        // 0x019C1F9C: MOV x1, x20                | X1 = item;//m1                          
        // 0x019C1FA0: LDR x8, [x0]               | X8 = (X22 + 0) + 32;                    
        // 0x019C1FA4: LDP x9, x2, [x8, #0x110]   | X9 = (X22 + 0) + 32 + 272; X2 = (X22 + 0) + 32 + 272 + 8; //  | 
        // 0x019C1FA8: BLR x9                     | X0 = (X22 + 0) + 32 + 272();            
        // 0x019C1FAC: AND w8, w0, #1             | W8 = ((X22 + 0) + 32 & 1);              
        var val_2 = ((X22 + 0) + 32) & 1;
        // 0x019C1FB0: TBNZ w8, #0, #0x19c1fcc    | if ((((X22 + 0) + 32 & 1) & 0x1) != 0) goto label_7;
        if((val_2 & 1) != 0)
        {
            goto label_7;
        }
        // 0x019C1FB4: LDR w8, [x19, #0x18]       | 
        // 0x019C1FB8: ADD w21, w21, #1           | W21 = (val_5 + 1);                      
        val_5 = val_5 + 1;
        // 0x019C1FBC: CMP w21, w8                | STATE = COMPARE((val_5 + 1), ((X22 + 0) + 32 & 1))
        // 0x019C1FC0: B.LT #0x19c1f48            | if (val_5 < val_2) goto label_8;        
        if(val_5 < val_2)
        {
            goto label_8;
        }
        label_0:
        // 0x019C1FC4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_4 = 0;
        // 0x019C1FC8: B #0x19c1fd0               |  goto label_9;                          
        goto label_9;
        label_7:
        // 0x019C1FCC: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_4 = 1;
        label_9:
        // 0x019C1FD0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019C1FD4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019C1FD8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019C1FDC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019C1FE0: RET                        |  return (System.Boolean)true;           
        return (bool)val_4;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C1FE4 VirtAddr: 0x019C1FE4 -RVA: 0x019C1FE4 
    // -BetterList<object>.IndexOf
    //
    // file offset: 0x019C1258 VirtAddr: 0x019C1258 -RVA: 0x019C1258 
    // -BetterList<int>.IndexOf
    //
    // file offset: 0x019C2D88 VirtAddr: 0x019C2D88 -RVA: 0x019C2D88 
    // -BetterList<float>.IndexOf
    //
    // file offset: 0x019C3CDC VirtAddr: 0x019C3CDC -RVA: 0x019C3CDC 
    // -BetterList<TypewriterEffect.FadeEntry>.IndexOf
    //
    // file offset: 0x019C4EAC VirtAddr: 0x019C4EAC -RVA: 0x019C4EAC 
    // -BetterList<UICamera.DepthEntry>.IndexOf
    //
    // file offset: 0x019C6008 VirtAddr: 0x019C6008 -RVA: 0x019C6008 
    // -BetterList<UnityEngine.Color>.IndexOf
    //
    // file offset: 0x019C6F34 VirtAddr: 0x019C6F34 -RVA: 0x019C6F34 
    // -BetterList<UnityEngine.Color32>.IndexOf
    //
    // file offset: 0x019C7D80 VirtAddr: 0x019C7D80 -RVA: 0x019C7D80 
    // -BetterList<UnityEngine.Vector2>.IndexOf
    //
    // file offset: 0x019C8C4C VirtAddr: 0x019C8C4C -RVA: 0x019C8C4C 
    // -BetterList<UnityEngine.Vector3>.IndexOf
    //
    // file offset: 0x019C9C10 VirtAddr: 0x019C9C10 -RVA: 0x019C9C10 
    // -BetterList<UnityEngine.Vector4>.IndexOf
    //
    //
    // Offset in libil2cpp.so: 0x019C1FE4 (27008996), len: 208  VirtAddr: 0x019C1FE4 RVA: 0x019C1FE4 token: 100687858 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public int IndexOf(T item)
    {
        //
        // Disasemble & Code
        //  | 
        var val_3;
        //  | 
        var val_4;
        // 0x019C1FE4: STP x24, x23, [sp, #-0x40]! | stack[1152921514153648400] = ???;  stack[1152921514153648408] = ???;  //  dest_result_addr=1152921514153648400 |  dest_result_addr=1152921514153648408
        // 0x019C1FE8: STP x22, x21, [sp, #0x10]  | stack[1152921514153648416] = ???;  stack[1152921514153648424] = ???;  //  dest_result_addr=1152921514153648416 |  dest_result_addr=1152921514153648424
        // 0x019C1FEC: STP x20, x19, [sp, #0x20]  | stack[1152921514153648432] = ???;  stack[1152921514153648440] = ???;  //  dest_result_addr=1152921514153648432 |  dest_result_addr=1152921514153648440
        // 0x019C1FF0: STP x29, x30, [sp, #0x30]  | stack[1152921514153648448] = ???;  stack[1152921514153648456] = ???;  //  dest_result_addr=1152921514153648448 |  dest_result_addr=1152921514153648456
        // 0x019C1FF4: ADD x29, sp, #0x30         | X29 = (1152921514153648400 + 48) = 1152921514153648448 (0x100000023908A140);
        // 0x019C1FF8: MOV x20, x0                | X20 = 1152921514153660464 (0x100000023908D030);//ML01
        // 0x019C1FFC: LDR x22, [x20, #0x10]      | 
        // 0x019C2000: MOV x21, x1                | X21 = item;//m1                         
        // 0x019C2004: CBZ x22, #0x19c2098        | if (X22 == 0) goto label_1;             
        if(X22 == 0)
        {
            goto label_1;
        }
        // 0x019C2008: LDR w8, [x20, #0x18]       | 
        // 0x019C200C: CMP w8, #1                 | STATE = COMPARE(W8, 0x1)                
        // 0x019C2010: B.LT #0x19c2098            | if (W8 < 0x1) goto label_1;             
        if(W8 < 1)
        {
            goto label_1;
        }
        // 0x019C2014: MOV w19, wzr               | W19 = 0 (0x0);//ML01                    
        val_4 = 0;
        // 0x019C2018: B #0x19c2020               |  goto label_2;                          
        goto label_2;
        label_8:
        // 0x019C201C: LDR x22, [x20, #0x10]      | 
        label_2:
        // 0x019C2020: CBNZ x22, #0x19c2028       | if (X22 != 0) goto label_3;             
        if(X22 != 0)
        {
            goto label_3;
        }
        // 0x019C2024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_3:
        // 0x019C2028: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
        // 0x019C202C: SXTW x23, w19              | X23 = 0 (0x00000000);                   
        // 0x019C2030: CMP w19, w8                | STATE = COMPARE(0x0, X22 + 24)          
        // 0x019C2034: B.LO #0x19c2044            | if (val_4 < X22 + 24) goto label_4;     
        if(val_4 < (X22 + 24))
        {
            goto label_4;
        }
        // 0x019C2038: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C203C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2040: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_4:
        // 0x019C2044: ADD x23, x22, x23, lsl #3  | X23 = (X22 + 0);                        
        var val_1 = X22 + 0;
        // 0x019C2048: LDR x8, [x23, #0x20]!      | X8 = (X22 + 0) + 32;                    
        // 0x019C204C: CBNZ x8, #0x19c2054        | if ((X22 + 0) + 32 != 0) goto label_5;  
        if(((X22 + 0) + 32) != 0)
        {
            goto label_5;
        }
        // 0x019C2050: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x019C2054: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
        // 0x019C2058: CMP w19, w8                | STATE = COMPARE(0x0, X22 + 24)          
        // 0x019C205C: B.LO #0x19c206c            | if (val_4 < X22 + 24) goto label_6;     
        if(val_4 < (X22 + 24))
        {
            goto label_6;
        }
        // 0x019C2060: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C2064: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2068: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_6:
        // 0x019C206C: LDR x0, [x23]              | X0 = (X22 + 0) + 32;                    
        // 0x019C2070: MOV x1, x21                | X1 = item;//m1                          
        // 0x019C2074: LDR x8, [x0]               | X8 = (X22 + 0) + 32;                    
        // 0x019C2078: LDP x9, x2, [x8, #0x110]   | X9 = (X22 + 0) + 32 + 272; X2 = (X22 + 0) + 32 + 272 + 8; //  | 
        // 0x019C207C: BLR x9                     | X0 = (X22 + 0) + 32 + 272();            
        // 0x019C2080: AND w8, w0, #1             | W8 = ((X22 + 0) + 32 & 1);              
        var val_2 = ((X22 + 0) + 32) & 1;
        // 0x019C2084: TBNZ w8, #0, #0x19c209c    | if ((((X22 + 0) + 32 & 1) & 0x1) != 0) goto label_7;
        if((val_2 & 1) != 0)
        {
            goto label_7;
        }
        // 0x019C2088: LDR w8, [x20, #0x18]       | 
        // 0x019C208C: ADD w19, w19, #1           | W19 = (val_4 + 1);                      
        val_4 = val_4 + 1;
        // 0x019C2090: CMP w19, w8                | STATE = COMPARE((val_4 + 1), ((X22 + 0) + 32 & 1))
        // 0x019C2094: B.LT #0x19c201c            | if (val_4 < val_2) goto label_8;        
        if(val_4 < val_2)
        {
            goto label_8;
        }
        label_1:
        // 0x019C2098: MOVN w19, #0               | W19 = 0 (0x0);//ML01                    
        val_4 = 0;
        label_7:
        // 0x019C209C: MOV w0, w19                | W0 = 0 (0x0);//ML01                     
        // 0x019C20A0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019C20A4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019C20A8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019C20AC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019C20B0: RET                        |  return (System.Int32)0;                
        return (int)val_4;
        //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C20B4 VirtAddr: 0x019C20B4 -RVA: 0x019C20B4 
    // -BetterList<object>.Remove
    // -BetterList<UICamera>.Remove
    // -BetterList<UIDrawCall>.Remove
    // -BetterList<UIKeyNavigation>.Remove
    // -BetterList<UILabel>.Remove
    // -BetterList<UIRect>.Remove
    // -BetterList<UIScrollView>.Remove
    // -BetterList<UIToggle>.Remove
    //
    // file offset: 0x019C133C VirtAddr: 0x019C133C -RVA: 0x019C133C 
    // -BetterList<int>.Remove
    //
    // file offset: 0x019C2E6C VirtAddr: 0x019C2E6C -RVA: 0x019C2E6C 
    // -BetterList<float>.Remove
    //
    // file offset: 0x019C3E40 VirtAddr: 0x019C3E40 -RVA: 0x019C3E40 
    // -BetterList<TypewriterEffect.FadeEntry>.Remove
    //
    // file offset: 0x019C5010 VirtAddr: 0x019C5010 -RVA: 0x019C5010 
    // -BetterList<UICamera.DepthEntry>.Remove
    //
    // file offset: 0x019C6104 VirtAddr: 0x019C6104 -RVA: 0x019C6104 
    // -BetterList<UnityEngine.Color>.Remove
    //
    // file offset: 0x019C7078 VirtAddr: 0x019C7078 -RVA: 0x019C7078 
    // -BetterList<UnityEngine.Color32>.Remove
    //
    // file offset: 0x019C7E68 VirtAddr: 0x019C7E68 -RVA: 0x019C7E68 
    // -BetterList<UnityEngine.Vector2>.Remove
    //
    // file offset: 0x019C8D50 VirtAddr: 0x019C8D50 -RVA: 0x019C8D50 
    // -BetterList<UnityEngine.Vector3>.Remove
    //
    // file offset: 0x019C9D0C VirtAddr: 0x019C9D0C -RVA: 0x019C9D0C 
    // -BetterList<UnityEngine.Vector4>.Remove
    //
    //
    // Offset in libil2cpp.so: 0x019C20B4 (27009204), len: 536  VirtAddr: 0x019C20B4 RVA: 0x019C20B4 token: 100687859 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public bool Remove(T item)
    {
        //
        // Disasemble & Code
        //  | 
        var val_6;
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        // 0x019C20B4: STP x24, x23, [sp, #-0x40]! | stack[1152921514153768592] = ???;  stack[1152921514153768600] = ???;  //  dest_result_addr=1152921514153768592 |  dest_result_addr=1152921514153768600
        // 0x019C20B8: STP x22, x21, [sp, #0x10]  | stack[1152921514153768608] = ???;  stack[1152921514153768616] = ???;  //  dest_result_addr=1152921514153768608 |  dest_result_addr=1152921514153768616
        // 0x019C20BC: STP x20, x19, [sp, #0x20]  | stack[1152921514153768624] = ???;  stack[1152921514153768632] = ???;  //  dest_result_addr=1152921514153768624 |  dest_result_addr=1152921514153768632
        // 0x019C20C0: STP x29, x30, [sp, #0x30]  | stack[1152921514153768640] = ???;  stack[1152921514153768648] = ???;  //  dest_result_addr=1152921514153768640 |  dest_result_addr=1152921514153768648
        // 0x019C20C4: ADD x29, sp, #0x30         | X29 = (1152921514153768592 + 48) = 1152921514153768640 (0x10000002390A76C0);
        // 0x019C20C8: MOV x19, x0                | X19 = 1152921514153780656 (0x10000002390AA5B0);//ML01
        val_6 = this;
        // 0x019C20CC: LDR x8, [x19, #0x10]       | 
        // 0x019C20D0: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
        val_7 = __RuntimeMethodHiddenParam;
        // 0x019C20D4: MOV x20, x1                | X20 = item;//m1                         
        // 0x019C20D8: CBZ x8, #0x19c21c0         | if (X8 == 0) goto label_3;              
        if(X8 == 0)
        {
            goto label_3;
        }
        // 0x019C20DC: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C20E0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C20E4: LDR x22, [x8, #0x38]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 56;
        // 0x019C20E8: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
        // 0x019C20EC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
        // 0x019C20F0: LDRB w8, [x22, #0x10a]     | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 56 + 266;
        // 0x019C20F4: TBZ w8, #0, #0x19c2130     | if ((__RuntimeMethodHiddenParam + 24 + 168 + 56 + 266 & 0x1) == 0) goto label_2;
        if(((__RuntimeMethodHiddenParam + 24 + 168 + 56 + 266) & 1) == 0)
        {
            goto label_2;
        }
        // 0x019C20F8: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C20FC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C2100: LDR x22, [x8, #0x38]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 56;
        // 0x019C2104: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
        // 0x019C2108: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
        // 0x019C210C: LDR w8, [x22, #0xbc]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 56 + 188;
        // 0x019C2110: CBNZ w8, #0x19c2130        | if (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 188 != 0) goto label_2;
        if((__RuntimeMethodHiddenParam + 24 + 168 + 56 + 188) != 0)
        {
            goto label_2;
        }
        // 0x019C2114: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C2118: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C211C: LDR x22, [x8, #0x38]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 56;
        // 0x019C2120: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
        // 0x019C2124: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
        // 0x019C2128: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
        // 0x019C212C: BL #0x27977a4              | X0 = sub_27977A4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
        label_2:
        // 0x019C2130: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C2134: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x019C2138: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C213C: LDR x1, [x8, #0x30]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
        // 0x019C2140: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
        // 0x019C2144: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48();
        // 0x019C2148: LDR w8, [x19, #0x18]       | 
        // 0x019C214C: MOV x21, x0                | X21 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x019C2150: CMP w8, #1                 | STATE = COMPARE(__RuntimeMethodHiddenParam + 24 + 168 + 48, 0x1)
        // 0x019C2154: B.LT #0x19c21c0            | if (__RuntimeMethodHiddenParam + 24 + 168 + 48 < 0x1) goto label_3;
        if((__RuntimeMethodHiddenParam + 24 + 168 + 48) < 1)
        {
            goto label_3;
        }
        // 0x019C2158: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
        val_8 = 0;
        label_8:
        // 0x019C215C: LDR x22, [x19, #0x10]      | 
        // 0x019C2160: CBNZ x22, #0x19c2168       | if (__RuntimeMethodHiddenParam + 24 + 168 + 56 != 0) goto label_4;
        if((__RuntimeMethodHiddenParam + 24 + 168 + 56) != 0)
        {
            goto label_4;
        }
        // 0x019C2164: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_4:
        // 0x019C2168: LDR w8, [x22, #0x18]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 56 + 24;
        // 0x019C216C: SXTW x24, w23              | X24 = 0 (0x00000000);                   
        // 0x019C2170: CMP w23, w8                | STATE = COMPARE(0x0, __RuntimeMethodHiddenParam + 24 + 168 + 56 + 24)
        // 0x019C2174: B.LO #0x19c2184            | if (val_8 < __RuntimeMethodHiddenParam + 24 + 168 + 56 + 24) goto label_5;
        if(val_8 < (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 24))
        {
            goto label_5;
        }
        // 0x019C2178: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C217C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2180: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_5:
        // 0x019C2184: ADD x8, x22, x24, lsl #3   | X8 = (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 0);
        var val_1 = (__RuntimeMethodHiddenParam + 24 + 168 + 56) + 0;
        // 0x019C2188: LDR x22, [x8, #0x20]       | X22 = (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 0) + 32;
        // 0x019C218C: CBNZ x21, #0x19c2194       | if (0x0 != 0) goto label_6;             
        if(val_7 != 0)
        {
            goto label_6;
        }
        // 0x019C2190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_6:
        // 0x019C2194: LDR x8, [x21]              | X8 = 0x10102464C457F;                   
        var val_6 = 1179403647;
        // 0x019C2198: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
        // 0x019C219C: MOV x1, x22                | X1 = (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 0) + 32;//m1
        // 0x019C21A0: MOV x2, x20                | X2 = item;//m1                          
        // 0x019C21A4: LDP x9, x3, [x8, #0x1a0]   | X9 = mem[282584257677087]; X3 = mem[282584257677095]; //  | 
        // 0x019C21A8: BLR x9                     | X0 = mem[282584257677087]();            
        // 0x019C21AC: TBNZ w0, #0, #0x19c21c8    | if ((0x0 & 0x1) != 0) goto label_7;     
        if((val_7 & 1) != 0)
        {
            goto label_7;
        }
        // 0x019C21B0: LDR w8, [x19, #0x18]       | 
        // 0x019C21B4: ADD w23, w23, #1           | W23 = (val_8 + 1);                      
        val_8 = val_8 + 1;
        // 0x019C21B8: CMP w23, w8                | STATE = COMPARE((val_8 + 1), 0x10102464C457F)
        // 0x019C21BC: B.LT #0x19c215c            | if (val_8 < 1179403647) goto label_8;   
        if(val_8 < val_6)
        {
            goto label_8;
        }
        label_3:
        // 0x019C21C0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
        val_9 = 0;
        // 0x019C21C4: B #0x19c22b8               |  goto label_9;                          
        goto label_9;
        label_7:
        // 0x019C21C8: LDR w8, [x19, #0x18]       | 
        // 0x019C21CC: LDR x20, [x19, #0x10]      | 
        // 0x019C21D0: SUB w8, w8, #1             | W8 = (1179403647 - 1);                  
        val_6 = val_6 - 1;
        // 0x019C21D4: STR w8, [x19, #0x18]       | mem[1152921514153780680] = (1179403647 - 1);  //  dest_result_addr=1152921514153780680
        mem[1152921514153780680] = val_6;
        // 0x019C21D8: CBNZ x20, #0x19c21e0       | if (item != null) goto label_10;        
        if(item != null)
        {
            goto label_10;
        }
        // 0x019C21DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_10:
        // 0x019C21E0: LDR w8, [x20, #0x18]       | 
        // 0x019C21E4: CMP w23, w8                | STATE = COMPARE(0x0, (1179403647 - 1))  
        // 0x019C21E8: B.LO #0x19c21f8            | if (val_8 < 1179403647) goto label_11;  
        if(val_8 < val_6)
        {
            goto label_11;
        }
        // 0x019C21EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C21F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C21F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_11:
        // 0x019C21F8: ADD x8, x20, x24, lsl #3   | X8 = typeof(System.Object);//AP1        
        // 0x019C21FC: STR xzr, [x8, #0x20]       | typeof(System.Object).__il2cppRuntimeField_20 = 0x0;  //  dest_result_addr=1152921504606900256
        typeof(System.Object).__il2cppRuntimeField_20 = 0;
        // 0x019C2200: LDR x20, [x19, #0x10]      | 
        // 0x019C2204: LDR w22, [x19, #0x18]      | 
        // 0x019C2208: CMP x20, #0                | STATE = COMPARE(item, 0x0)              
        // 0x019C220C: CSET w8, eq                | W8 = item == null ? 1 : 0;              
        var val_2 = (item == 0) ? 1 : 0;
        // 0x019C2210: CMP w23, w22               | STATE = COMPARE(0x0, (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 0) + 32)
        // 0x019C2214: B.GE #0x19c2288            | if (val_8 >= (__RuntimeMethodHiddenParam + 24 + 168 + 56 + 0) + 32) goto label_12;
        if(val_8 >= ((__RuntimeMethodHiddenParam + 24 + 168 + 56 + 0) + 32))
        {
            goto label_12;
        }
        label_16:
        // 0x019C2218: TBZ w8, #0, #0x19c2220     | if ((item == null ? 1 : 0 & 0x1) == 0) goto label_13;
        if((val_2 & 1) == 0)
        {
            goto label_13;
        }
        // 0x019C221C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_13:
        // 0x019C2220: LDR x8, [x20, #0x18]       | 
        // 0x019C2224: ADD w21, w23, #1           | W21 = (val_8 + 1);                      
        val_7 = val_8 + 1;
        // 0x019C2228: SXTW x22, w21              | X22 = (long)(int)((val_8 + 1));         
        // 0x019C222C: CMP w21, w8                | STATE = COMPARE((val_8 + 1), item == null ? 1 : 0)
        // 0x019C2230: B.LO #0x19c2244            | if (val_7 < val_2) goto label_14;       
        if(val_7 < val_2)
        {
            goto label_14;
        }
        // 0x019C2234: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C2238: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C223C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        // 0x019C2240: LDR x8, [x20, #0x18]       | 
        label_14:
        // 0x019C2244: ADD x9, x20, x22, lsl #3   | X9 = (item + ((long)(int)((val_8 + 1))) << 3);
        object val_3 = item + (((long)(int)((val_8 + 1))) << 3);
        // 0x019C2248: LDR x22, [x9, #0x20]       | 
        // 0x019C224C: SXTW x24, w23              | X24 = 0 (0x00000000);                   
        // 0x019C2250: CMP w23, w8                | STATE = COMPARE(0x0, item == null ? 1 : 0)
        // 0x019C2254: B.LO #0x19c2264            | if (val_8 < val_2) goto label_15;       
        if(val_8 < val_2)
        {
            goto label_15;
        }
        // 0x019C2258: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C225C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2260: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_15:
        // 0x019C2264: ADD x8, x20, x24, lsl #3   | X8 = typeof(System.Object);//AP1        
        // 0x019C2268: STR x22, [x8, #0x20]       | typeof(System.Object).__il2cppRuntimeField_20 = (long)(int)((val_8 + 1));  //  dest_result_addr=1152921504606900256
        typeof(System.Object).__il2cppRuntimeField_20 = (long)val_7;
        // 0x019C226C: LDR x20, [x19, #0x10]      | 
        // 0x019C2270: LDR w22, [x19, #0x18]      | 
        // 0x019C2274: CMP x20, #0                | STATE = COMPARE(item, 0x0)              
        // 0x019C2278: CSET w8, eq                | W8 = item == null ? 1 : 0;              
        var val_4 = (item == 0) ? 1 : 0;
        // 0x019C227C: CMP w21, w22               | STATE = COMPARE((val_8 + 1), (long)(int)((val_8 + 1)))
        // 0x019C2280: MOV w23, w21               | W23 = (val_8 + 1);//m1                  
        val_8 = val_7;
        // 0x019C2284: B.LT #0x19c2218            | if (val_7 < (long)val_7) goto label_16; 
        if(val_7 < (long)val_7)
        {
            goto label_16;
        }
        label_12:
        // 0x019C2288: CBZ w8, #0x19c2290         | if (item == null ? 1 : 0 == 0) goto label_17;
        if(val_4 == 0)
        {
            goto label_17;
        }
        // 0x019C228C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_17:
        // 0x019C2290: LDR w8, [x20, #0x18]       | 
        // 0x019C2294: SXTW x19, w22              | X19 = (long)(int)((long)(int)((val_8 + 1)));
        val_6 = (long)(long)val_7;
        // 0x019C2298: CMP w22, w8                | STATE = COMPARE((long)(int)((val_8 + 1)), item == null ? 1 : 0)
        // 0x019C229C: B.LO #0x19c22ac            | if ((long)val_7 < val_4) goto label_18; 
        if((long)val_7 < val_4)
        {
            goto label_18;
        }
        // 0x019C22A0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x019C22A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C22A8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_18:
        // 0x019C22AC: ADD x8, x20, x19, lsl #3   | X8 = (item + ((long)(int)((long)(int)((val_8 + 1)))) << 3);
        object val_5 = item + (((long)(int)((long)(int)((val_8 + 1)))) << 3);
        // 0x019C22B0: STR xzr, [x8, #0x20]       | mem2[0] = 0x0;                           //  dest_result_addr=0
        mem2[0] = 0;
        // 0x019C22B4: ORR w0, wzr, #1            | W0 = 1(0x1);                            
        val_9 = 1;
        label_9:
        // 0x019C22B8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019C22BC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019C22C0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019C22C4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019C22C8: RET                        |  return (System.Boolean)true;           
        return (bool)val_9;
        //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C22CC VirtAddr: 0x019C22CC -RVA: 0x019C22CC 
    // -BetterList<object>.RemoveAt
    // -BetterList<UITextList.Paragraph>.RemoveAt
    //
    // file offset: 0x019C637C VirtAddr: 0x019C637C -RVA: 0x019C637C 
    // -BetterList<UnityEngine.Color>.RemoveAt
    //
    // file offset: 0x019C4110 VirtAddr: 0x019C4110 -RVA: 0x019C4110 
    // -BetterList<TypewriterEffect.FadeEntry>.RemoveAt
    //
    // file offset: 0x019C1554 VirtAddr: 0x019C1554 -RVA: 0x019C1554 
    // -BetterList<int>.RemoveAt
    //
    // file offset: 0x019C308C VirtAddr: 0x019C308C -RVA: 0x019C308C 
    // -BetterList<float>.RemoveAt
    //
    // file offset: 0x019C52F4 VirtAddr: 0x019C52F4 -RVA: 0x019C52F4 
    // -BetterList<UICamera.DepthEntry>.RemoveAt
    //
    // file offset: 0x019C7294 VirtAddr: 0x019C7294 -RVA: 0x019C7294 
    // -BetterList<UnityEngine.Color32>.RemoveAt
    //
    // file offset: 0x019C80A4 VirtAddr: 0x019C80A4 -RVA: 0x019C80A4 
    // -BetterList<UnityEngine.Vector2>.RemoveAt
    //
    // file offset: 0x019C8FD0 VirtAddr: 0x019C8FD0 -RVA: 0x019C8FD0 
    // -BetterList<UnityEngine.Vector3>.RemoveAt
    //
    // file offset: 0x019C9F84 VirtAddr: 0x019C9F84 -RVA: 0x019C9F84 
    // -BetterList<UnityEngine.Vector4>.RemoveAt
    //
    //
    // Offset in libil2cpp.so: 0x019C22CC (27009740), len: 300  VirtAddr: 0x019C22CC RVA: 0x019C22CC token: 100687860 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public void RemoveAt(int index)
    {
        //
        // Disasemble & Code
        //  | 
        var val_9;
        //  | 
        var val_10;
        //  | 
        var val_11;
        //  | 
        var val_12;
        //  | 
        var val_13;
        // 0x019C22CC: STP x24, x23, [sp, #-0x40]! | stack[1152921514153884688] = ???;  stack[1152921514153884696] = ???;  //  dest_result_addr=1152921514153884688 |  dest_result_addr=1152921514153884696
        // 0x019C22D0: STP x22, x21, [sp, #0x10]  | stack[1152921514153884704] = ???;  stack[1152921514153884712] = ???;  //  dest_result_addr=1152921514153884704 |  dest_result_addr=1152921514153884712
        // 0x019C22D4: STP x20, x19, [sp, #0x20]  | stack[1152921514153884720] = ???;  stack[1152921514153884728] = ???;  //  dest_result_addr=1152921514153884720 |  dest_result_addr=1152921514153884728
        // 0x019C22D8: STP x29, x30, [sp, #0x30]  | stack[1152921514153884736] = ???;  stack[1152921514153884744] = ???;  //  dest_result_addr=1152921514153884736 |  dest_result_addr=1152921514153884744
        // 0x019C22DC: ADD x29, sp, #0x30         | X29 = (1152921514153884688 + 48) = 1152921514153884736 (0x10000002390C3C40);
        // 0x019C22E0: MOV x19, x0                | X19 = 1152921514153896752 (0x10000002390C6B30);//ML01
        val_9 = this;
        // 0x019C22E4: LDR x21, [x19, #0x10]      | 
        // 0x019C22E8: MOV w20, w1                | W20 = index;//m1                        
        // 0x019C22EC: CBZ x21, #0x19c23e4        | if (X21 == 0) goto label_2;             
        if(X21 == 0)
        {
            goto label_2;
        }
        // 0x019C22F0: LSR w8, w20, #0x1e         | W8 = (index >> 30);                     
        int val_1 = index >> 30;
        // 0x019C22F4: TBNZ w8, #1, #0x19c23e4    | if (((index >> 30) & 0x2) != 0) goto label_2;
        if((val_1 & 2) != 0)
        {
            goto label_2;
        }
        // 0x019C22F8: LDR w8, [x19, #0x18]       | 
        // 0x019C22FC: CMP w8, w20                | STATE = COMPARE((index >> 30), index)   
        // 0x019C2300: B.LE #0x19c23e4            | if (val_1 <= index) goto label_2;       
        if(val_1 <= index)
        {
            goto label_2;
        }
        // 0x019C2304: SUB w8, w8, #1             | W8 = ((index >> 30) - 1);               
        val_1 = val_1 - 1;
        // 0x019C2308: STR w8, [x19, #0x18]       | mem[1152921514153896776] = ((index >> 30) - 1);  //  dest_result_addr=1152921514153896776
        mem[1152921514153896776] = val_1;
        // 0x019C230C: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
        // 0x019C2310: SXTW x22, w20              | X22 = (long)(int)(index);               
        // 0x019C2314: CMP w8, w20                | STATE = COMPARE(X21 + 24, index)        
        // 0x019C2318: B.HI #0x19c2328            | if (X21 + 24 > index) goto label_3;     
        if((X21 + 24) > index)
        {
            goto label_3;
        }
        // 0x019C231C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C2320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2324: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_3:
        // 0x019C2328: ADD x8, x21, x22, lsl #3   | X8 = (X21 + ((long)(int)(index)) << 3); 
        var val_2 = X21 + (((long)(int)(index)) << 3);
        // 0x019C232C: STR xzr, [x8, #0x20]       | mem2[0] = 0x0;                           //  dest_result_addr=0
        mem2[0] = 0;
        // 0x019C2330: LDR x21, [x19, #0x10]      | 
        // 0x019C2334: LDR w23, [x19, #0x18]      | 
        // 0x019C2338: CMP x21, #0                | STATE = COMPARE(X21, 0x0)               
        // 0x019C233C: CSET w8, eq                | W8 = X21 == 0x0 ? 1 : 0;                
        var val_3 = (X21 == 0) ? 1 : 0;
        // 0x019C2340: CMP w23, w20               | STATE = COMPARE(W23, index)             
        // 0x019C2344: B.LE #0x19c23b8            | if (W23 <= index) goto label_4;         
        if(W23 <= index)
        {
            goto label_4;
        }
        label_8:
        // 0x019C2348: TBZ w8, #0, #0x19c2350     | if ((X21 == 0x0 ? 1 : 0 & 0x1) == 0) goto label_5;
        if((val_3 & 1) == 0)
        {
            goto label_5;
        }
        // 0x019C234C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x019C2350: LDR x8, [x21, #0x18]       | X8 = X21 + 24;                          
        val_13 = mem[X21 + 24];
        val_13 = X21 + 24;
        // 0x019C2354: ADD w22, w20, #1           | W22 = (index + 1);                      
        int val_4 = index + 1;
        // 0x019C2358: SXTW x23, w22              | X23 = (long)(int)((index + 1));         
        // 0x019C235C: CMP w22, w8                | STATE = COMPARE((index + 1), X21 + 24)  
        // 0x019C2360: B.LO #0x19c2374            | if (val_4 < val_13) goto label_6;       
        if(val_4 < val_13)
        {
            goto label_6;
        }
        // 0x019C2364: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C2368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C236C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        // 0x019C2370: LDR x8, [x21, #0x18]       | X8 = X21 + 24;                          
        val_13 = mem[X21 + 24];
        val_13 = X21 + 24;
        label_6:
        // 0x019C2374: ADD x9, x21, x23, lsl #3   | X9 = (X21 + ((long)(int)((index + 1))) << 3);
        var val_5 = X21 + (((long)(int)((index + 1))) << 3);
        // 0x019C2378: LDR x23, [x9, #0x20]       | X23 = (X21 + ((long)(int)((index + 1))) << 3) + 32;
        // 0x019C237C: SXTW x24, w20              | X24 = (long)(int)(index);               
        // 0x019C2380: CMP w20, w8                | STATE = COMPARE(index, X21 + 24)        
        // 0x019C2384: B.LO #0x19c2394            | if (index < val_13) goto label_7;       
        if(index < val_13)
        {
            goto label_7;
        }
        // 0x019C2388: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C238C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2390: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_7:
        // 0x019C2394: ADD x8, x21, x24, lsl #3   | X8 = (X21 + ((long)(int)(index)) << 3); 
        var val_6 = X21 + (((long)(int)(index)) << 3);
        // 0x019C2398: STR x23, [x8, #0x20]       | mem2[0] = (X21 + ((long)(int)((index + 1))) << 3) + 32;  //  dest_result_addr=0
        mem2[0] = (X21 + ((long)(int)((index + 1))) << 3) + 32;
        // 0x019C239C: LDR x21, [x19, #0x10]      | 
        // 0x019C23A0: LDR w23, [x19, #0x18]      | 
        // 0x019C23A4: CMP x21, #0                | STATE = COMPARE(X21, 0x0)               
        // 0x019C23A8: CSET w8, eq                | W8 = X21 == 0x0 ? 1 : 0;                
        var val_7 = (X21 == 0) ? 1 : 0;
        // 0x019C23AC: CMP w22, w23               | STATE = COMPARE((index + 1), (X21 + ((long)(int)((index + 1))) << 3) + 32)
        // 0x019C23B0: MOV w20, w22               | W20 = (index + 1);//m1                  
        // 0x019C23B4: B.LT #0x19c2348            | if (val_4 < (X21 + ((long)(int)((index + 1))) << 3) + 32) goto label_8;
        if(val_4 < ((X21 + ((long)(int)((index + 1))) << 3) + 32))
        {
            goto label_8;
        }
        label_4:
        // 0x019C23B8: CBZ w8, #0x19c23c0         | if (X21 == 0x0 ? 1 : 0 == 0) goto label_9;
        if(val_7 == 0)
        {
            goto label_9;
        }
        // 0x019C23BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_9:
        // 0x019C23C0: LDR w8, [x21, #0x18]       | W8 = X21 + 24;                          
        // 0x019C23C4: SXTW x19, w23              | X19 = (long)(int)((X21 + ((long)(int)((index + 1))) << 3) + 32);
        val_9 = (long)(X21 + ((long)(int)((index + 1))) << 3) + 32;
        // 0x019C23C8: CMP w23, w8                | STATE = COMPARE((X21 + ((long)(int)((index + 1))) << 3) + 32, X21 + 24)
        // 0x019C23CC: B.LO #0x19c23dc            | if ((X21 + ((long)(int)((index + 1))) << 3) + 32 < X21 + 24) goto label_10;
        if(((X21 + ((long)(int)((index + 1))) << 3) + 32) < (X21 + 24))
        {
            goto label_10;
        }
        // 0x019C23D0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C23D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C23D8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_10:
        // 0x019C23DC: ADD x8, x21, x19, lsl #3   | X8 = (X21 + ((long)(int)((X21 + ((long)(int)((index + 1))) << 3) + 32)) << 3);
        var val_8 = X21 + (((long)(int)((X21 + ((long)(int)((index + 1))) << 3) + 32)) << 3);
        // 0x019C23E0: STR xzr, [x8, #0x20]       | mem2[0] = 0x0;                           //  dest_result_addr=0
        mem2[0] = 0;
        label_2:
        // 0x019C23E4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
        // 0x019C23E8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
        // 0x019C23EC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
        // 0x019C23F0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
        // 0x019C23F4: RET                        |  return;                                
        return;
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C23F8 VirtAddr: 0x019C23F8 -RVA: 0x019C23F8 
    // -BetterList<object>.Pop
    // -BetterList<UIDrawCall>.Pop
    //
    // file offset: 0x019C1680 VirtAddr: 0x019C1680 -RVA: 0x019C1680 
    // -BetterList<int>.Pop
    //
    // file offset: 0x019C31B8 VirtAddr: 0x019C31B8 -RVA: 0x019C31B8 
    // -BetterList<float>.Pop
    //
    // file offset: 0x019C42A8 VirtAddr: 0x019C42A8 -RVA: 0x019C42A8 
    // -BetterList<TypewriterEffect.FadeEntry>.Pop
    //
    // file offset: 0x019C54A0 VirtAddr: 0x019C54A0 -RVA: 0x019C54A0 
    // -BetterList<UICamera.DepthEntry>.Pop
    //
    // file offset: 0x019C64C0 VirtAddr: 0x019C64C0 -RVA: 0x019C64C0 
    // -BetterList<UnityEngine.Color>.Pop
    //
    // file offset: 0x019C73C0 VirtAddr: 0x019C73C0 -RVA: 0x019C73C0 
    // -BetterList<UnityEngine.Color32>.Pop
    //
    // file offset: 0x019C81D8 VirtAddr: 0x019C81D8 -RVA: 0x019C81D8 
    // -BetterList<UnityEngine.Vector2>.Pop
    //
    // file offset: 0x019C912C VirtAddr: 0x019C912C -RVA: 0x019C912C 
    // -BetterList<UnityEngine.Vector3>.Pop
    //
    // file offset: 0x019CA0C8 VirtAddr: 0x019CA0C8 -RVA: 0x019CA0C8 
    // -BetterList<UnityEngine.Vector4>.Pop
    //
    //
    // Offset in libil2cpp.so: 0x019C23F8 (27010040), len: 184  VirtAddr: 0x019C23F8 RVA: 0x019C23F8 token: 100687861 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public T Pop()
    {
        //
        // Disasemble & Code
        //  | 
        var val_5;
        //  | 
        var val_6;
        //  | 
        var val_7;
        // 0x019C23F8: STP x22, x21, [sp, #-0x30]! | stack[1152921514153996704] = ???;  stack[1152921514153996712] = ???;  //  dest_result_addr=1152921514153996704 |  dest_result_addr=1152921514153996712
        // 0x019C23FC: STP x20, x19, [sp, #0x10]  | stack[1152921514153996720] = ???;  stack[1152921514153996728] = ???;  //  dest_result_addr=1152921514153996720 |  dest_result_addr=1152921514153996728
        // 0x019C2400: STP x29, x30, [sp, #0x20]  | stack[1152921514153996736] = ???;  stack[1152921514153996744] = ???;  //  dest_result_addr=1152921514153996736 |  dest_result_addr=1152921514153996744
        // 0x019C2404: ADD x29, sp, #0x20         | X29 = (1152921514153996704 + 32) = 1152921514153996736 (0x10000002390DF1C0);
        // 0x019C2408: MOV x19, x0                | X19 = 1152921514154008752 (0x10000002390E20B0);//ML01
        // 0x019C240C: LDR x20, [x19, #0x10]      | 
        // 0x019C2410: CBZ x20, #0x19c2440        | if (X20 == 0) goto label_1;             
        if(X20 == 0)
        {
            goto label_1;
        }
        // 0x019C2414: LDR w8, [x19, #0x18]       | 
        // 0x019C2418: CBZ w8, #0x19c2440         | if (W8 == 0) goto label_1;              
        if(W8 == 0)
        {
            goto label_1;
        }
        // 0x019C241C: SUB w21, w8, #1            | W21 = (W8 - 1);                         
        val_6 = W8 - 1;
        // 0x019C2420: STR w21, [x19, #0x18]      | mem[1152921514154008776] = (W8 - 1);     //  dest_result_addr=1152921514154008776
        mem[1152921514154008776] = val_6;
        // 0x019C2424: LDR w8, [x20, #0x18]       | W8 = X20 + 24;                          
        // 0x019C2428: SXTW x22, w21              | X22 = (long)(int)((W8 - 1));            
        // 0x019C242C: CMP w21, w8                | STATE = COMPARE((W8 - 1), X20 + 24)     
        // 0x019C2430: B.HS #0x19c2448            | if (val_6 >= X20 + 24) goto label_2;    
        if(val_6 >= (X20 + 24))
        {
            goto label_2;
        }
        // 0x019C2434: ADD x8, x20, x22, lsl #3   | X8 = (X20 + ((long)(int)((W8 - 1))) << 3);
        var val_1 = X20 + (((long)(int)((W8 - 1))) << 3);
        // 0x019C2438: LDR x19, [x8, #0x20]       | X19 = (X20 + ((long)(int)((W8 - 1))) << 3) + 32;
        val_7 = mem[(X20 + ((long)(int)((W8 - 1))) << 3) + 32];
        val_7 = (X20 + ((long)(int)((W8 - 1))) << 3) + 32;
        // 0x019C243C: B #0x19c2478               |  goto label_6;                          
        goto label_6;
        label_1:
        // 0x019C2440: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
        val_7 = 0;
        // 0x019C2444: B #0x19c249c               |  goto label_4;                          
        goto label_4;
        label_2:
        // 0x019C2448: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C244C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2450: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        // 0x019C2454: ADD x9, x20, x22, lsl #3   | X9 = (X20 + ((long)(int)((W8 - 1))) << 3);
        var val_2 = X20 + (((long)(int)((W8 - 1))) << 3);
        // 0x019C2458: LDR x8, [x19, #0x10]       | 
        // 0x019C245C: LDR w21, [x19, #0x18]      | 
        // 0x019C2460: LDR x19, [x9, #0x20]       | X19 = (X20 + ((long)(int)((W8 - 1))) << 3) + 32;
        val_7 = mem[(X20 + ((long)(int)((W8 - 1))) << 3) + 32];
        val_7 = (X20 + ((long)(int)((W8 - 1))) << 3) + 32;
        // 0x019C2464: CBZ x8, #0x19c2470         | if (X20 + 24 == 0) goto label_5;        
        if((X20 + 24) == 0)
        {
            goto label_5;
        }
        // 0x019C2468: MOV x20, x8                | X20 = X20 + 24;//m1                     
        val_5 = X20 + 24;
        // 0x019C246C: B #0x19c2478               |  goto label_6;                          
        goto label_6;
        label_5:
        // 0x019C2470: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        // 0x019C2474: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
        val_5 = 0;
        label_6:
        // 0x019C2478: LDR w8, [x20, #0x18]       | W8 = 0x9814C0;                          
        // 0x019C247C: SXTW x22, w21              | X22 = (long)(int)((W8 - 1));            
        // 0x019C2480: CMP w21, w8                | STATE = COMPARE((W8 - 1), 0x9814C0)     
        // 0x019C2484: B.LO #0x19c2494            | if (val_6 < 9966784) goto label_7;      
        if(val_6 < 9966784)
        {
            goto label_7;
        }
        // 0x019C2488: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C248C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2490: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_7:
        // 0x019C2494: ADD x8, x20, x22, lsl #3   | X8 = (val_5 + ((long)(int)((W8 - 1))) << 3);
        var val_3 = val_5 + (((long)(int)((W8 - 1))) << 3);
        // 0x019C2498: STR xzr, [x8, #0x20]       | mem2[0] = 0x0;                           //  dest_result_addr=0
        mem2[0] = 0;
        label_4:
        // 0x019C249C: MOV x0, x19                | X0 = (X20 + ((long)(int)((W8 - 1))) << 3) + 32;//m1
        // 0x019C24A0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x019C24A4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x019C24A8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x019C24AC: RET                        |  return (System.Object)(X20 + ((long)(int)((W8 - 1))) << 3) + 32;
        return (object)val_7;
        //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C24B0 VirtAddr: 0x019C24B0 -RVA: 0x019C24B0 
    // -BetterList<object>.ToArray
    //
    // file offset: 0x019C9210 VirtAddr: 0x019C9210 -RVA: 0x019C9210 
    // -BetterList<UnityEngine.Vector3>.ToArray
    //
    // file offset: 0x019C82A4 VirtAddr: 0x019C82A4 -RVA: 0x019C82A4 
    // -BetterList<UnityEngine.Vector2>.ToArray
    //
    // file offset: 0x019C7478 VirtAddr: 0x019C7478 -RVA: 0x019C7478 
    // -BetterList<UnityEngine.Color32>.ToArray
    //
    // file offset: 0x019CA1AC VirtAddr: 0x019CA1AC -RVA: 0x019CA1AC 
    // -BetterList<UnityEngine.Vector4>.ToArray
    //
    // file offset: 0x019C1738 VirtAddr: 0x019C1738 -RVA: 0x019C1738 
    // -BetterList<int>.ToArray
    //
    // file offset: 0x019C3274 VirtAddr: 0x019C3274 -RVA: 0x019C3274 
    // -BetterList<float>.ToArray
    //
    // file offset: 0x019C43B0 VirtAddr: 0x019C43B0 -RVA: 0x019C43B0 
    // -BetterList<TypewriterEffect.FadeEntry>.ToArray
    //
    // file offset: 0x019C55C8 VirtAddr: 0x019C55C8 -RVA: 0x019C55C8 
    // -BetterList<UICamera.DepthEntry>.ToArray
    //
    // file offset: 0x019C65A4 VirtAddr: 0x019C65A4 -RVA: 0x019C65A4 
    // -BetterList<UnityEngine.Color>.ToArray
    //
    //
    // Offset in libil2cpp.so: 0x019C24B0 (27010224), len: 68  VirtAddr: 0x019C24B0 RVA: 0x019C24B0 token: 100687862 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    public T[] ToArray()
    {
        //
        // Disasemble & Code
        // 0x019C24B0: STP x20, x19, [sp, #-0x20]! | stack[1152921514154108720] = ???;  stack[1152921514154108728] = ???;  //  dest_result_addr=1152921514154108720 |  dest_result_addr=1152921514154108728
        // 0x019C24B4: STP x29, x30, [sp, #0x10]  | stack[1152921514154108736] = ???;  stack[1152921514154108744] = ???;  //  dest_result_addr=1152921514154108736 |  dest_result_addr=1152921514154108744
        // 0x019C24B8: ADD x29, sp, #0x10         | X29 = (1152921514154108720 + 16) = 1152921514154108736 (0x10000002390FA740);
        // 0x019C24BC: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
        // 0x019C24C0: MOV x19, x0                | X19 = 1152921514154120752 (0x10000002390FD630);//ML01
        // 0x019C24C4: CBNZ x19, #0x19c24cc       | if (this != null) goto label_0;         
        if(this != null)
        {
            goto label_0;
        }
        // 0x019C24C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x019C24CC: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C24D0: MOV x0, x19                | X0 = 1152921514154120752 (0x10000002390FD630);//ML01
        // 0x019C24D4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C24D8: LDR x1, [x8, #0x48]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 72;
        // 0x019C24DC: LDR x8, [x1]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 72;
        // 0x019C24E0: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 72();
        // 0x019C24E4: LDR x0, [x19, #0x10]       | 
        // 0x019C24E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x019C24EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x019C24F0: RET                        |  return (T[])this;                      
        return (T[])this;
        //  |  // // {name=val_0, type=T[], size=8, nGRN=0 }
    
    }
    // Generic instance method:
    //
    // file offset: 0x019C24F4 VirtAddr: 0x019C24F4 -RVA: 0x019C24F4 
    // -BetterList<object>.Sort
    // -BetterList<UICamera>.Sort
    //
    // file offset: 0x019C560C VirtAddr: 0x019C560C -RVA: 0x019C560C 
    // -BetterList<UICamera.DepthEntry>.Sort
    //
    // file offset: 0x019C177C VirtAddr: 0x019C177C -RVA: 0x019C177C 
    // -BetterList<int>.Sort
    //
    // file offset: 0x019C32B8 VirtAddr: 0x019C32B8 -RVA: 0x019C32B8 
    // -BetterList<float>.Sort
    //
    // file offset: 0x019C43F4 VirtAddr: 0x019C43F4 -RVA: 0x019C43F4 
    // -BetterList<TypewriterEffect.FadeEntry>.Sort
    //
    // file offset: 0x019C65E8 VirtAddr: 0x019C65E8 -RVA: 0x019C65E8 
    // -BetterList<UnityEngine.Color>.Sort
    //
    // file offset: 0x019C74BC VirtAddr: 0x019C74BC -RVA: 0x019C74BC 
    // -BetterList<UnityEngine.Color32>.Sort
    //
    // file offset: 0x019C82E8 VirtAddr: 0x019C82E8 -RVA: 0x019C82E8 
    // -BetterList<UnityEngine.Vector2>.Sort
    //
    // file offset: 0x019C9254 VirtAddr: 0x019C9254 -RVA: 0x019C9254 
    // -BetterList<UnityEngine.Vector3>.Sort
    //
    // file offset: 0x019CA1F0 VirtAddr: 0x019CA1F0 -RVA: 0x019CA1F0 
    // -BetterList<UnityEngine.Vector4>.Sort
    //
    //
    // Offset in libil2cpp.so: 0x019C24F4 (27010292), len: 548  VirtAddr: 0x019C24F4 RVA: 0x019C24F4 token: 100687863 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x2866040
    [System.Diagnostics.DebuggerStepThroughAttribute] // 0x2866040
    public void Sort(BetterList.CompareFunc<T> comparer)
    {
        //
        // Disasemble & Code
        //  | 
        var val_18;
        //  | 
        var val_19;
        // 0x019C24F4: STP x28, x27, [sp, #-0x60]! | stack[1152921514154224752] = ???;  stack[1152921514154224760] = ???;  //  dest_result_addr=1152921514154224752 |  dest_result_addr=1152921514154224760
        // 0x019C24F8: STP x26, x25, [sp, #0x10]  | stack[1152921514154224768] = ???;  stack[1152921514154224776] = ???;  //  dest_result_addr=1152921514154224768 |  dest_result_addr=1152921514154224776
        // 0x019C24FC: STP x24, x23, [sp, #0x20]  | stack[1152921514154224784] = ???;  stack[1152921514154224792] = ???;  //  dest_result_addr=1152921514154224784 |  dest_result_addr=1152921514154224792
        // 0x019C2500: STP x22, x21, [sp, #0x30]  | stack[1152921514154224800] = ???;  stack[1152921514154224808] = ???;  //  dest_result_addr=1152921514154224800 |  dest_result_addr=1152921514154224808
        // 0x019C2504: STP x20, x19, [sp, #0x40]  | stack[1152921514154224816] = ???;  stack[1152921514154224824] = ???;  //  dest_result_addr=1152921514154224816 |  dest_result_addr=1152921514154224824
        // 0x019C2508: STP x29, x30, [sp, #0x50]  | stack[1152921514154224832] = ???;  stack[1152921514154224840] = ???;  //  dest_result_addr=1152921514154224832 |  dest_result_addr=1152921514154224840
        // 0x019C250C: ADD x29, sp, #0x50         | X29 = (1152921514154224752 + 80) = 1152921514154224832 (0x1000000239116CC0);
        // 0x019C2510: SUB sp, sp, #0x20          | SP = (1152921514154224752 - 32) = 1152921514154224720 (0x1000000239116C50);
        // 0x019C2514: MOV x19, x0                | X19 = 1152921514154236848 (0x1000000239119BB0);//ML01
        // 0x019C2518: LDR w8, [x19, #0x18]       | 
        // 0x019C251C: MOV x21, x1                | X21 = comparer;//m1                     
        // 0x019C2520: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
        // 0x019C2524: STR wzr, [sp, #0xc]        | stack[1152921514154224732] = 0x0;        //  dest_result_addr=1152921514154224732
        // 0x019C2528: SUB w8, w8, #1             | W8 = (W8 - 1);                          
        var val_1 = W8 - 1;
        // 0x019C252C: SXTW x8, w8                | X8 = (long)(int)((W8 - 1));             
        // 0x019C2530: STP x2, x8, [sp, #0x10]    | stack[1152921514154224736] = __RuntimeMethodHiddenParam;  stack[1152921514154224744] = (long)(int)((W8 - 1));  //  dest_result_addr=1152921514154224736 |  dest_result_addr=1152921514154224744
        // 0x019C2534: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        val_18 = 1;
        // 0x019C2538: B #0x19c2640               |  goto label_1;                          
        goto label_1;
        label_20:
        // 0x019C253C: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
        val_18 = 0;
        // 0x019C2540: ADD x9, x23, x28, lsl #3   | X9 = (X23 + (X28) << 3);                
        var val_2 = X23 + ((X28) << 3);
        // 0x019C2544: STR x20, [x9, #0x20]       | mem2[0] = ???;                           //  dest_result_addr=0
        mem2[0] = ???;
        // 0x019C2548: B #0x19c2640               |  goto label_1;                          
        goto label_1;
        label_10:
        // 0x019C254C: ADD w8, w25, w26           | W8 = (W25 + W26);                       
        var val_3 = W25 + W26;
        // 0x019C2550: ADD w22, w27, w26          | W22 = (W27 + W26);                      
        var val_4 = W27 + W26;
        // 0x019C2554: SUB w9, w22, #2            | W9 = ((W27 + W26) - 2);                 
        var val_5 = val_4 - 2;
        // 0x019C2558: CMP w8, #1                 | STATE = COMPARE((W25 + W26), 0x1)       
        // 0x019C255C: CSEL w8, wzr, w9, eq       | W8 = val_3 == 0x1 ? 0 : ((W27 + W26) - 2);
        var val_6 = (val_3 == 1) ? 0 : (val_5);
        // 0x019C2560: STR w8, [sp, #0xc]         | stack[1152921514154224732] = val_3 == 0x1 ? 0 : ((W27 + W26) - 2);  //  dest_result_addr=1152921514154224732
        label_12:
        // 0x019C2564: SBFIZ x8, x22, #3, #0x20   | 
        // 0x019C2568: MOV x26, xzr               | X26 = 0 (0x0);//ML01                    
        var val_18 = 0;
        // 0x019C256C: MOV w27, w22               | W27 = (W27 + W26);//m1                  
        // 0x019C2570: SXTW x25, w22              | X25 = (long)(int)((W27 + W26));         
        // 0x019C2574: ADD x24, x8, #0x20         | X24 = (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32);
        var val_7 = val_6 + 32;
        label_9:
        // 0x019C2578: LDR x9, [sp, #0x18]        | X9 = (long)(int)((W8 - 1));             
        // 0x019C257C: ADD x8, x25, x26           | X8 = ((long)(int)((W27 + W26)) + 0);    
        var val_8 = (long)val_4 + val_18;
        // 0x019C2580: CMP x8, x9                 | STATE = COMPARE(((long)(int)((W27 + W26)) + 0), (long)(int)((W8 - 1)))
        // 0x019C2584: B.GE #0x19c2630            | if (val_8 >= (long)val_1) goto label_2; 
        if(val_8 >= (long)val_1)
        {
            goto label_2;
        }
        // 0x019C2588: LDR x22, [x19, #0x10]      | 
        // 0x019C258C: CBNZ x22, #0x19c2594       | if ((W27 + W26) != 0) goto label_3;     
        if(val_4 != 0)
        {
            goto label_3;
        }
        // 0x019C2590: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_3:
        // 0x019C2594: LDR w8, [x22, #0x18]       | W8 = (W27 + W26) + 24;                  
        // 0x019C2598: ADD w9, w27, w26           | W9 = ((W27 + W26) + 0);                 
        var val_9 = val_4 + val_18;
        // 0x019C259C: CMP w9, w8                 | STATE = COMPARE(((W27 + W26) + 0), (W27 + W26) + 24)
        // 0x019C25A0: B.LO #0x19c25b0            | if (val_9 < (W27 + W26) + 24) goto label_4;
        if(val_9 < ((W27 + W26) + 24))
        {
            goto label_4;
        }
        // 0x019C25A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C25A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C25AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_4:
        // 0x019C25B0: ADD x8, x22, x24           | X8 = ((W27 + W26) + (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32));
        var val_10 = val_4 + val_7;
        // 0x019C25B4: LDR x22, [x8, x26, lsl #3] | X22 = ((W27 + W26) + (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32)) + 0;
        // 0x019C25B8: LDR x23, [x19, #0x10]      | 
        // 0x019C25BC: CBNZ x23, #0x19c25c4       | if (X23 != 0) goto label_5;             
        if(X23 != 0)
        {
            goto label_5;
        }
        // 0x019C25C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_5:
        // 0x019C25C4: LDR w8, [x23, #0x18]       | W8 = X23 + 24;                          
        // 0x019C25C8: ADD x9, x27, x26           | X9 = ((W27 + W26) + 0);                 
        var val_11 = val_4 + val_18;
        // 0x019C25CC: ADD x9, x9, #1             | X9 = (((W27 + W26) + 0) + 1);           
        val_11 = val_11 + 1;
        // 0x019C25D0: SXTW x28, w9               | X28 = (long)(int)((((W27 + W26) + 0) + 1));
        // 0x019C25D4: CMP w9, w8                 | STATE = COMPARE((((W27 + W26) + 0) + 1), X23 + 24)
        // 0x019C25D8: B.LO #0x19c25e8            | if (val_11 < X23 + 24) goto label_6;    
        if(val_11 < (X23 + 24))
        {
            goto label_6;
        }
        // 0x019C25DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
        // 0x019C25E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C25E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
        label_6:
        // 0x019C25E8: ADD x8, x23, x28, lsl #3   | X8 = (X23 + ((long)(int)((((W27 + W26) + 0) + 1))) << 3);
        var val_12 = X23 + (((long)(int)((((W27 + W26) + 0) + 1))) << 3);
        // 0x019C25EC: LDR x23, [x8, #0x20]       | X23 = (X23 + ((long)(int)((((W27 + W26) + 0) + 1))) << 3) + 32;
        // 0x019C25F0: CBNZ x21, #0x19c25f8       | if (comparer != null) goto label_7;     
        if(comparer != null)
        {
            goto label_7;
        }
        // 0x019C25F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_7:
        // 0x019C25F8: LDR x8, [sp, #0x10]        | X8 = __RuntimeMethodHiddenParam;        
        // 0x019C25FC: MOV x0, x21                | X0 = comparer;//m1                      
        // 0x019C2600: MOV x1, x22                | X1 = ((W27 + W26) + (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32)) + 0;//m1
        // 0x019C2604: MOV x2, x23                | X2 = (X23 + ((long)(int)((((W27 + W26) + 0) + 1))) << 3) + 32;//m1
        // 0x019C2608: LDR x8, [x8, #0x18]        | X8 = __RuntimeMethodHiddenParam + 24;   
        // 0x019C260C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
        // 0x019C2610: LDR x3, [x8, #0x50]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 80;
        // 0x019C2614: LDR x8, [x3]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 80;
        // 0x019C2618: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 80();
        // 0x019C261C: CMP w0, #1                 | STATE = COMPARE(comparer, 0x1)          
        // 0x019C2620: B.GE #0x19c2648            | if (comparer >= 0x1) goto label_8;      
        if(comparer >= 1)
        {
            goto label_8;
        }
        // 0x019C2624: ADD x26, x26, #1           | X26 = (0 + 1);                          
        val_18 = val_18 + 1;
        // 0x019C2628: TBZ w20, #0, #0x19c2578    | if ((W20 & 0x1) == 0) goto label_9;     
        if((W20 & 1) == 0)
        {
            goto label_9;
        }
        // 0x019C262C: B #0x19c254c               |  goto label_10;                         
        goto label_10;
        label_2:
        // 0x019C2630: LDR w9, [sp, #0xc]         | W9 = val_3 == 0x1 ? 0 : ((W27 + W26) - 2);
        // 0x019C2634: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        val_18 = 1;
        // 0x019C2638: MOV w22, w9                | W22 = val_3 == 0x1 ? 0 : ((W27 + W26) - 2);//m1
        // 0x019C263C: TBNZ w20, #0, #0x19c26f8   | if ((W20 & 0x1) != 0) goto label_11;    
        if((W20 & 1) != 0)
        {
            goto label_11;
        }
        label_1:
        // 0x019C2640: MOV w20, w8                | W20 = 1 (0x1);//ML01                    
        // 0x019C2644: B #0x19c2564               |  goto label_12;                         
        goto label_12;
        label_8:
        // 0x019C2648: LDR x20, [x19, #0x10]      | 
        // 0x019C264C: ADD x23, x26, w25, uxtw    | X23 = (0 + (long)(int)((W27 + W26)));   
        var val_13 = val_18 + (long)val_4;
        // 0x019C2650: CBNZ x20, #0x19c2658       | if (X20 != 0) goto label_13;            
        if(X20 != 0)
        {
            goto label_13;
        }
        // 0x019C2654: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? comparer, ????);   
        label_13:
        // 0x019C2658: LDR w8, [x20, #0x18]       | W8 = X20 + 24;                          
        // 0x019C265C: ADD x22, x23, #1           | X22 = ((0 + (long)(int)((W27 + W26))) + 1);
        var val_14 = val_13 + 1;
        // 0x019C2660: CMP w23, w8                | STATE = COMPARE((0 + (long)(int)((W27 + W26))), X20 + 24)
        // 0x019C2664: B.LO #0x19c2674            | if (val_13 < X20 + 24) goto label_14;   
        if(val_13 < (X20 + 24))
        {
            goto label_14;
        }
        // 0x019C2668: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? comparer, ????);   
        // 0x019C266C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C2670: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? comparer, ????);   
        label_14:
        // 0x019C2674: ADD x8, x20, x25, lsl #3   | X8 = (X20 + ((long)(int)((W27 + W26))) << 3);
        var val_15 = X20 + (((long)(int)((W27 + W26))) << 3);
        // 0x019C2678: ADD x8, x8, x26, lsl #3    | X8 = ((X20 + ((long)(int)((W27 + W26))) << 3) + 0);
        val_15 = val_15 + 0;
        // 0x019C267C: LDR x20, [x8, #0x20]       | X20 = ((X20 + ((long)(int)((W27 + W26))) << 3) + 0) + 32;
        // 0x019C2680: LDR x24, [x19, #0x10]      | 
        // 0x019C2684: CBNZ x24, #0x19c268c       | if ((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) != 0) goto label_15;
        if(val_7 != 0)
        {
            goto label_15;
        }
        // 0x019C2688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? comparer, ????);   
        label_15:
        // 0x019C268C: LDR x8, [x24, #0x18]       | X8 = (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24;
        val_19 = mem[(val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24];
        val_19 = (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24;
        // 0x019C2690: CMP w22, w8                | STATE = COMPARE(((0 + (long)(int)((W27 + W26))) + 1), (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24)
        // 0x019C2694: B.LO #0x19c26a8            | if (val_14 < val_19) goto label_16;     
        if(val_14 < val_19)
        {
            goto label_16;
        }
        // 0x019C2698: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? comparer, ????);   
        // 0x019C269C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C26A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? comparer, ????);   
        // 0x019C26A4: LDR x8, [x24, #0x18]       | X8 = (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24;
        val_19 = mem[(val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24];
        val_19 = (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24;
        label_16:
        // 0x019C26A8: ADD x9, x24, x28, lsl #3   | X9 = ((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + ((long)(int)((((W27 + W26) + 0) + 1))) << 3);
        var val_16 = val_7 + (((long)(int)((((W27 + W26) + 0) + 1))) << 3);
        // 0x019C26AC: LDR x25, [x9, #0x20]       | X25 = ((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + ((long)(int)((((W27 + W26) + 0) + 1))) << 3) + 32;
        // 0x019C26B0: CMP w23, w8                | STATE = COMPARE((0 + (long)(int)((W27 + W26))), (val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + 24)
        // 0x019C26B4: B.LO #0x19c26c4            | if (val_13 < val_19) goto label_17;     
        if(val_13 < val_19)
        {
            goto label_17;
        }
        // 0x019C26B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? comparer, ????);   
        // 0x019C26BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C26C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? comparer, ????);   
        label_17:
        // 0x019C26C4: ADD x8, x24, w27, sxtw #3  | X8 = ((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + ((W27 + W26)) << 3);
        var val_17 = val_7 + (val_4 << 3);
        // 0x019C26C8: ADD x8, x8, x26, lsl #3    | X8 = (((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + ((W27 + W26)) << 3) + 0);
        val_17 = val_17 + 0;
        // 0x019C26CC: STR x25, [x8, #0x20]       | mem2[0] = ((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + ((long)(int)((((W27 + W26) + 0) + 1))) << 3) + 32;  //  dest_result_addr=0
        mem2[0] = ((val_3 == 0x1 ? 0 : ((W27 + W26) - 2) + 32) + ((long)(int)((((W27 + W26) + 0) + 1))) << 3) + 32;
        // 0x019C26D0: LDR x23, [x19, #0x10]      | 
        // 0x019C26D4: CBNZ x23, #0x19c26dc       | if ((0 + (long)(int)((W27 + W26))) != 0) goto label_18;
        if(val_13 != 0)
        {
            goto label_18;
        }
        // 0x019C26D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? comparer, ????);   
        label_18:
        // 0x019C26DC: LDR w8, [x23, #0x18]       | W8 = (0 + (long)(int)((W27 + W26))) + 24;
        // 0x019C26E0: CMP w22, w8                | STATE = COMPARE(((0 + (long)(int)((W27 + W26))) + 1), (0 + (long)(int)((W27 + W26))) + 24)
        // 0x019C26E4: B.LO #0x19c253c            | if (val_14 < (0 + (long)(int)((W27 + W26))) + 24) goto label_20;
        if(val_14 < ((0 + (long)(int)((W27 + W26))) + 24))
        {
            goto label_20;
        }
        // 0x019C26E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? comparer, ????);   
        // 0x019C26EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x019C26F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? comparer, ????);   
        // 0x019C26F4: B #0x19c253c               |  goto label_20;                         
        goto label_20;
        label_11:
        // 0x019C26F8: SUB sp, x29, #0x50         | SP = (1152921514154224832 - 80) = 1152921514154224752 (0x1000000239116C70);
        // 0x019C26FC: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x019C2700: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x019C2704: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x019C2708: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x019C270C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
        // 0x019C2710: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
        // 0x019C2714: RET                        |  return;                                
        return;
    
    }

}
