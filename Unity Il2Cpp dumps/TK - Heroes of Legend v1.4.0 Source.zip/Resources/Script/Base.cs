using UnityEngine;

namespace SevenZip.Compression.LZMA
{
    internal abstract class Base
    {
        // Fields
        public const uint kNumRepDistances = 4;
        public const uint kNumStates = 12;
        public const int kNumPosSlotBits = 6;
        public const int kDicLogSizeMin = 0;
        public const int kNumLenToPosStatesBits = 2;
        public const uint kNumLenToPosStates = 4;
        public const uint kMatchMinLen = 2;
        public const int kNumAlignBits = 4;
        public const uint kAlignTableSize = 16;
        public const uint kAlignMask = 15;
        public const uint kStartPosModelIndex = 4;
        public const uint kEndPosModelIndex = 14;
        public const uint kNumPosModels = 10;
        public const uint kNumFullDistances = 128;
        public const uint kNumLitPosStatesBitsEncodingMax = 4;
        public const uint kNumLitContextBitsMax = 8;
        public const int kNumPosStatesBitsMax = 4;
        public const uint kNumPosStatesMax = 16;
        public const int kNumPosStatesBitsEncodingMax = 4;
        public const uint kNumPosStatesEncodingMax = 16;
        public const int kNumLowLenBits = 3;
        public const int kNumMidLenBits = 3;
        public const int kNumHighLenBits = 8;
        public const uint kNumLowLenSymbols = 8;
        public const uint kNumMidLenSymbols = 8;
        public const uint kNumLenSymbols = 272;
        public const uint kMatchMaxLen = 273;
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00CAA994 (13281684), len: 8  VirtAddr: 0x00CAA994 RVA: 0x00CAA994 token: 100681493 methodIndex: 54622 delegateWrapperIndex: 0 methodInvoker: 0
        protected Base()
        {
            //
            // Disasemble & Code
            // 0x00CAA994: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA998: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CAA99C (13281692), len: 20  VirtAddr: 0x00CAA99C RVA: 0x00CAA99C token: 100681494 methodIndex: 54623 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint GetLenToPosState(uint len)
        {
            //
            // Disasemble & Code
            // 0x00CAA99C: SUB w8, w1, #2             | W8 = (W1 - 2);                          
            var val_1 = W1 - 2;
            // 0x00CAA9A0: CMP w8, #3                 | STATE = COMPARE((W1 - 2), 0x3)          
            // 0x00CAA9A4: ORR w9, wzr, #3            | W9 = 3(0x3);                            
            // 0x00CAA9A8: CSEL w0, w9, w8, hi        | W0 = val_1 > 0x3 ? 3 : (W1 - 2);        
            var val_2 = (val_1 > 3) ? (3) : (val_1);
            // 0x00CAA9AC: RET                        |  return (System.UInt32)val_1 > 0x3 ? 3 : (W1 - 2);
            return (uint)val_2;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
    
    }

}
