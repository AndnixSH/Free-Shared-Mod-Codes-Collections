using UnityEngine;
[UnityEngine.RequireComponent] // 0x285B7FC
[UnityEngine.RequireComponent] // 0x285B7FC
[UnityEngine.AddComponentMenu] // 0x285B7FC
public class AIFollow : MonoBehaviour
{
    // Fields
    public UnityEngine.Transform target; //  0x00000018
    public float repathRate; //  0x00000020
    public float pickNextWaypointDistance; //  0x00000024
    public float targetReached; //  0x00000028
    public float speed; //  0x0000002C
    public float rotationSpeed; //  0x00000030
    public bool drawGizmos; //  0x00000034
    public bool canSearch; //  0x00000035
    public bool canMove; //  0x00000036
    protected Seeker seeker; //  0x00000038
    protected UnityEngine.CharacterController controller; //  0x00000040
    protected NavmeshController navmeshController; //  0x00000048
    protected UnityEngine.Transform tr; //  0x00000050
    protected float lastPathSearch; //  0x00000058
    protected int pathIndex; //  0x0000005C
    protected UnityEngine.Vector3[] path; //  0x00000060
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B22EEC (11677420), len: 52  VirtAddr: 0x00B22EEC RVA: 0x00B22EEC token: 100682726 methodIndex: 24719 delegateWrapperIndex: 0 methodInvoker: 0
    public AIFollow()
    {
        //
        // Disasemble & Code
        // 0x00B22EEC: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B22EF0: LDR q0, [x8, #0xae0]       | Q0 = ;                                  
        // 0x00B22EF4: MOVZ w11, #0xc61c, lsl #16 | W11 = 3323723776 (0xC61C0000);//ML01    
        // 0x00B22EF8: ORR w9, wzr, #0x3f800000   | W9 = 1065353216(0x3F800000);            
        // 0x00B22EFC: ORR w10, wzr, #1           | W10 = 1(0x1);                           
        // 0x00B22F00: MOVK w11, #0x3c00          | W11 = 3323739136 (0xC61C3C00);          
        // 0x00B22F04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22F08: STR w9, [x0, #0x30]        | this.rotationSpeed = 1;                  //  dest_result_addr=1152921513307885520
        this.rotationSpeed = 1f;
        // 0x00B22F0C: STRB w10, [x0, #0x35]      | this.canSearch = true;                   //  dest_result_addr=1152921513307885525
        this.canSearch = true;
        // 0x00B22F10: STRB w10, [x0, #0x36]      | this.canMove = true;                     //  dest_result_addr=1152921513307885526
        this.canMove = true;
        // 0x00B22F14: STR q0, [x0, #0x20]        | this.repathRate = ; this.pickNextWaypointDistance = ; this.targetReached = 0.2; this.speed = 5;  //  dest_result_addr=1152921513307885504 dest_result_addr=1152921513307885508 dest_result_addr=1152921513307885512 dest_result_addr=1152921513307885516
        this.repathRate = ;
        this.pickNextWaypointDistance = ;
        this.targetReached = 0.2f;
        this.speed = 5f;
        // 0x00B22F18: STR w11, [x0, #0x58]       | this.lastPathSearch = -9999;             //  dest_result_addr=1152921513307885560
        this.lastPathSearch = -9999f;
        // 0x00B22F1C: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B22F20 (11677472), len: 164  VirtAddr: 0x00B22F20 RVA: 0x00B22F20 token: 100682727 methodIndex: 24720 delegateWrapperIndex: 0 methodInvoker: 0
    public void Start()
    {
        //
        // Disasemble & Code
        // 0x00B22F20: STP x20, x19, [sp, #-0x20]! | stack[1152921513308001824] = ???;  stack[1152921513308001832] = ???;  //  dest_result_addr=1152921513308001824 |  dest_result_addr=1152921513308001832
        // 0x00B22F24: STP x29, x30, [sp, #0x10]  | stack[1152921513308001840] = ???;  stack[1152921513308001848] = ???;  //  dest_result_addr=1152921513308001840 |  dest_result_addr=1152921513308001848
        // 0x00B22F28: ADD x29, sp, #0x10         | X29 = (1152921513308001824 + 16) = 1152921513308001840 (0x1000000206A11630);
        // 0x00B22F2C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B22F30: LDRB w8, [x20, #0x727]     | W8 = (bool)static_value_03733727;       
        // 0x00B22F34: MOV x19, x0                | X19 = 1152921513308013856 (0x1000000206A14520);//ML01
        // 0x00B22F38: TBNZ w8, #0, #0xb22f54     | if (static_value_03733727 == true) goto label_0;
        // 0x00B22F3C: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00B22F40: LDR x8, [x8, #0xf58]       | X8 = 0x2B8AAF8;                         
        // 0x00B22F44: LDR w0, [x8]               | W0 = 0x17C;                             
        // 0x00B22F48: BL #0x2782188              | X0 = sub_2782188( ?? 0x17C, ????);      
        // 0x00B22F4C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B22F50: STRB w8, [x20, #0x727]     | static_value_03733727 = true;            //  dest_result_addr=57882407
        label_0:
        // 0x00B22F54: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
        // 0x00B22F58: LDR x8, [x8, #0x600]       | X8 = 1152921513114926800;               
        // 0x00B22F5C: MOV x0, x19                | X0 = 1152921513308013856 (0x1000000206A14520);//ML01
        // 0x00B22F60: LDR x1, [x8]               | X1 = public Seeker UnityEngine.Component::GetComponent<Seeker>();
        // 0x00B22F64: BL #0x23d5410              | X0 = this.GetComponent<Seeker>();       
        Seeker val_1 = this.GetComponent<Seeker>();
        // 0x00B22F68: STR x0, [x19, #0x38]       | this.seeker = val_1;                     //  dest_result_addr=1152921513308013912
        this.seeker = val_1;
        // 0x00B22F6C: ADRP x8, #0x35db000        | X8 = 56471552 (0x35DB000);              
        // 0x00B22F70: LDR x8, [x8, #0xe38]       | X8 = 1152921513114936016;               
        // 0x00B22F74: MOV x0, x19                | X0 = 1152921513308013856 (0x1000000206A14520);//ML01
        // 0x00B22F78: LDR x1, [x8]               | X1 = public UnityEngine.CharacterController UnityEngine.Component::GetComponent<UnityEngine.CharacterController>();
        // 0x00B22F7C: BL #0x23d5410              | X0 = this.GetComponent<UnityEngine.CharacterController>();
        UnityEngine.CharacterController val_2 = this.GetComponent<UnityEngine.CharacterController>();
        // 0x00B22F80: STR x0, [x19, #0x40]       | this.controller = val_2;                 //  dest_result_addr=1152921513308013920
        this.controller = val_2;
        // 0x00B22F84: ADRP x8, #0x3604000        | X8 = 56639488 (0x3604000);              
        // 0x00B22F88: LDR x8, [x8, #0x7e0]       | X8 = 1152921513114941136;               
        // 0x00B22F8C: MOV x0, x19                | X0 = 1152921513308013856 (0x1000000206A14520);//ML01
        // 0x00B22F90: LDR x1, [x8]               | X1 = public NavmeshController UnityEngine.Component::GetComponent<NavmeshController>();
        // 0x00B22F94: BL #0x23d5410              | X0 = this.GetComponent<NavmeshController>();
        NavmeshController val_3 = this.GetComponent<NavmeshController>();
        // 0x00B22F98: STR x0, [x19, #0x48]       | this.navmeshController = val_3;          //  dest_result_addr=1152921513308013928
        this.navmeshController = val_3;
        // 0x00B22F9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B22FA0: MOV x0, x19                | X0 = 1152921513308013856 (0x1000000206A14520);//ML01
        // 0x00B22FA4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_4 = this.transform;
        // 0x00B22FA8: LDR x8, [x19]              | X8 = typeof(AIFollow);                  
        // 0x00B22FAC: STR x0, [x19, #0x50]       | this.tr = val_4;                         //  dest_result_addr=1152921513308013936
        this.tr = val_4;
        // 0x00B22FB0: MOV x0, x19                | X0 = 1152921513308013856 (0x1000000206A14520);//ML01
        // 0x00B22FB4: LDP x2, x1, [x8, #0x150]   | X2 = typeof(AIFollow).__il2cppRuntimeField_150; X1 = typeof(AIFollow).__il2cppRuntimeField_158; //  | 
        // 0x00B22FB8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B22FBC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B22FC0: BR x2                      | goto typeof(AIFollow).__il2cppRuntimeField_150;
        goto typeof(AIFollow).__il2cppRuntimeField_150;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B22FC4 (11677636), len: 8  VirtAddr: 0x00B22FC4 RVA: 0x00B22FC4 token: 100682728 methodIndex: 24721 delegateWrapperIndex: 0 methodInvoker: 0
    public void Reset()
    {
        //
        // Disasemble & Code
        // 0x00B22FC4: STR xzr, [x0, #0x60]       | this.path = null;                        //  dest_result_addr=1152921513308142336
        this.path = 0;
        // 0x00B22FC8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B22FCC (11677644), len: 472  VirtAddr: 0x00B22FCC RVA: 0x00B22FCC token: 100682729 methodIndex: 24722 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnPathComplete(Pathfinding.Path p)
    {
        //
        // Disasemble & Code
        //  | 
        int val_8;
        //  | 
        float val_9;
        //  | 
        UnityEngine.Vector3[] val_10;
        // 0x00B22FCC: STP d15, d14, [sp, #-0x80]! | stack[1152921513308410048] = ???;  stack[1152921513308410056] = ???;  //  dest_result_addr=1152921513308410048 |  dest_result_addr=1152921513308410056
        // 0x00B22FD0: STP d13, d12, [sp, #0x10]  | stack[1152921513308410064] = ???;  stack[1152921513308410072] = ???;  //  dest_result_addr=1152921513308410064 |  dest_result_addr=1152921513308410072
        // 0x00B22FD4: STP d11, d10, [sp, #0x20]  | stack[1152921513308410080] = ???;  stack[1152921513308410088] = ???;  //  dest_result_addr=1152921513308410080 |  dest_result_addr=1152921513308410088
        // 0x00B22FD8: STP d9, d8, [sp, #0x30]    | stack[1152921513308410096] = ???;  stack[1152921513308410104] = ???;  //  dest_result_addr=1152921513308410096 |  dest_result_addr=1152921513308410104
        // 0x00B22FDC: STP x24, x23, [sp, #0x40]  | stack[1152921513308410112] = ???;  stack[1152921513308410120] = ???;  //  dest_result_addr=1152921513308410112 |  dest_result_addr=1152921513308410120
        // 0x00B22FE0: STP x22, x21, [sp, #0x50]  | stack[1152921513308410128] = ???;  stack[1152921513308410136] = ???;  //  dest_result_addr=1152921513308410128 |  dest_result_addr=1152921513308410136
        // 0x00B22FE4: STP x20, x19, [sp, #0x60]  | stack[1152921513308410144] = ???;  stack[1152921513308410152] = ???;  //  dest_result_addr=1152921513308410144 |  dest_result_addr=1152921513308410152
        // 0x00B22FE8: STP x29, x30, [sp, #0x70]  | stack[1152921513308410160] = ???;  stack[1152921513308410168] = ???;  //  dest_result_addr=1152921513308410160 |  dest_result_addr=1152921513308410168
        // 0x00B22FEC: ADD x29, sp, #0x70         | X29 = (1152921513308410048 + 112) = 1152921513308410160 (0x1000000206A75130);
        // 0x00B22FF0: SUB sp, sp, #0x10          | SP = (1152921513308410048 - 16) = 1152921513308410032 (0x1000000206A750B0);
        // 0x00B22FF4: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B22FF8: LDRB w8, [x21, #0x728]     | W8 = (bool)static_value_03733728;       
        // 0x00B22FFC: MOV x20, x1                | X20 = p;//m1                            
        // 0x00B23000: MOV x19, x0                | X19 = 1152921513308422176 (0x1000000206A78020);//ML01
        // 0x00B23004: TBNZ w8, #0, #0xb23020     | if (static_value_03733728 == true) goto label_0;
        // 0x00B23008: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
        // 0x00B2300C: LDR x8, [x8, #0xef8]       | X8 = 0x2B8AAEC;                         
        // 0x00B23010: LDR w0, [x8]               | W0 = 0x179;                             
        // 0x00B23014: BL #0x2782188              | X0 = sub_2782188( ?? 0x179, ????);      
        // 0x00B23018: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2301C: STRB w8, [x21, #0x728]     | static_value_03733728 = true;            //  dest_result_addr=57882408
        label_0:
        // 0x00B23020: MOV x0, x19                | X0 = 1152921513308422176 (0x1000000206A78020);//ML01
        // 0x00B23024: BL #0xb231a4               | X0 = this.WaitToRepath();               
        System.Collections.IEnumerator val_1 = this.WaitToRepath();
        // 0x00B23028: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00B2302C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B23030: MOV x0, x19                | X0 = 1152921513308422176 (0x1000000206A78020);//ML01
        // 0x00B23034: BL #0x1b772bc              | X0 = this.StartCoroutine(routine:  val_1);
        UnityEngine.Coroutine val_2 = this.StartCoroutine(routine:  val_1);
        // 0x00B23038: CBNZ x20, #0xb23040        | if (p != null) goto label_1;            
        if(p != null)
        {
            goto label_1;
        }
        // 0x00B2303C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_1:
        // 0x00B23040: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23044: MOV x0, x20                | X0 = p;//m1                             
        // 0x00B23048: BL #0x1402c00              | X0 = p.get_error();                     
        bool val_3 = p.error;
        // 0x00B2304C: AND w8, w0, #1             | W8 = (val_3 & 1);                       
        bool val_4 = val_3;
        // 0x00B23050: TBNZ w8, #0, #0xb2317c     | if ((val_3 & 1) == true) goto label_2;  
        if(val_4 == true)
        {
            goto label_2;
        }
        // 0x00B23054: CBNZ x20, #0xb2305c        | if (p != null) goto label_3;            
        if(p != null)
        {
            goto label_3;
        }
        // 0x00B23058: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_3:
        // 0x00B2305C: LDR x20, [x20, #0x68]      | X20 = p.vectorPath; //P2                
        // 0x00B23060: CBNZ x20, #0xb23068        | if (p.vectorPath != null) goto label_4; 
        if(p.vectorPath != null)
        {
            goto label_4;
        }
        // 0x00B23064: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_4:
        // 0x00B23068: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
        // 0x00B2306C: LDR x8, [x8, #0x790]       | X8 = 1152921513167055872;               
        // 0x00B23070: MOV x0, x20                | X0 = p.vectorPath;//m1                  
        // 0x00B23074: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<UnityEngine.Vector3>::ToArray();
        // 0x00B23078: BL #0x2643064              | X0 = p.vectorPath.ToArray();            
        T[] val_5 = p.vectorPath.ToArray();
        // 0x00B2307C: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B23080: LDR s14, [x8, #0x930]      | S14 = Infinity;                         
        val_9 = Infinityf;
        // 0x00B23084: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
        val_8 = 0;
        // 0x00B23088: STR x0, [x19, #0x60]       | this.path = val_5;                       //  dest_result_addr=1152921513308422272
        this.path = val_5;
        // 0x00B2308C: ORR w22, wzr, #0xc         | W22 = 12(0xC);                          
        // 0x00B23090: B #0xb23160                |  goto label_6;                          
        goto label_6;
        label_12:
        // 0x00B23094: MOV v14.16b, v0.16b        | V14 = V0.16B;//m1                       
        val_9 = V0.16B;
        // 0x00B23098: STR w21, [x19, #0x5c]      | this.pathIndex = 0;                      //  dest_result_addr=1152921513308422268
        this.pathIndex = val_8;
        // 0x00B2309C: B #0xb23160                |  goto label_6;                          
        goto label_6;
        label_14:
        // 0x00B230A0: LDR x24, [x19, #0x60]      | X24 = this.path; //P2                   
        // 0x00B230A4: MOV x23, x24               | X23 = this.path;//m1                    
        val_10 = this.path;
        // 0x00B230A8: CBNZ x24, #0xb230c0        | if (this.path != null) goto label_8;    
        if(this.path != null)
        {
            goto label_8;
        }
        // 0x00B230AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        // 0x00B230B0: LDR x23, [x19, #0x60]      | X23 = this.path; //P2                   
        val_10 = this.path;
        // 0x00B230B4: CBNZ x23, #0xb230c0        | if (this.path != null) goto label_8;    
        if(val_10 != null)
        {
            goto label_8;
        }
        // 0x00B230B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        // 0x00B230BC: MOV x23, xzr               | X23 = 0 (0x0);//ML01                    
        val_10 = 0;
        label_8:
        // 0x00B230C0: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B230C4: CBNZ x20, #0xb230cc        | if (this.tr != null) goto label_9;      
        if(this.tr != null)
        {
            goto label_9;
        }
        // 0x00B230C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
        label_9:
        // 0x00B230CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B230D0: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B230D4: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_6 = this.tr.position;
        // 0x00B230D8: LDR w8, [x24, #0x18]       | W8 = this.path.Length; //P2             
        // 0x00B230DC: MOV v8.16b, v0.16b         | V8 = val_6.x;//m1                       
        // 0x00B230E0: MOV v9.16b, v1.16b         | V9 = val_6.y;//m1                       
        // 0x00B230E4: MOV v10.16b, v2.16b        | V10 = val_6.z;//m1                      
        // 0x00B230E8: SXTW x20, w21              | X20 = 0 (0x00000000);                   
        // 0x00B230EC: CMP w21, w8                | STATE = COMPARE(0x0, this.path.Length)  
        // 0x00B230F0: B.LO #0xb23100             | if (val_8 < this.path.Length) goto label_10;
        if(val_8 < this.path.Length)
        {
            goto label_10;
        }
        // 0x00B230F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.tr, ????);    
        // 0x00B230F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B230FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.tr, ????);    
        label_10:
        // 0x00B23100: MADD x8, x20, x22, x24     | X8 = (0 * 12 + this.path) = 0 (0x00000000);
        // 0x00B23104: LDR w9, [x23, #0x18]       | W9 = 0x9814C0;                          
        // 0x00B23108: LDP s13, s12, [x8, #0x20]  | S13 = 8.96831E-44; S12 = 0;              //  | 
        // 0x00B2310C: LDR s11, [x8, #0x28]       | S11 = 7.117545E-37;                     
        // 0x00B23110: ADD w21, w21, #1           | W21 = (val_8 + 1) = val_8 (0x00000001); 
        val_8 = 1;
        // 0x00B23114: SXTW x20, w21              | X20 = 1 (0x00000001);                   
        // 0x00B23118: CMP w21, w9                | STATE = COMPARE(0x1, 0x9814C0)          
        // 0x00B2311C: B.LO #0xb2312c             | if (val_8 < 9966784) goto label_11;     
        if(val_8 < 9966784)
        {
            goto label_11;
        }
        // 0x00B23120: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.tr, ????);    
        // 0x00B23124: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23128: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.tr, ????);    
        label_11:
        // 0x00B2312C: MADD x8, x20, x22, x23     | X8 = (1 * 12 + val_10) = 12 (0x0000000C);
        // 0x00B23130: LDP s3, s4, [x8, #0x20]    | S3 = 0; S4 = 0;                          //  | 
        // 0x00B23134: LDR s5, [x8, #0x28]        | S5 = 5.142877E-39;                      
        // 0x00B23138: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B2313C: MOV v0.16b, v13.16b        | V0 = 64 (0x40);//ML01                   
        // 0x00B23140: MOV v1.16b, v12.16b        | V1 = 0 (0x0);//ML01                     
        // 0x00B23144: MOV v2.16b, v11.16b        | V2 = 57815696 (0x3723290);//ML01        
        // 0x00B23148: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2314C: STP s9, s10, [sp, #4]      | stack[1152921513308410036] = val_6.y;  stack[1152921513308410040] = val_6.z;  //  dest_result_addr=1152921513308410036 |  dest_result_addr=1152921513308410040
        // 0x00B23150: STR s8, [sp]               | stack[1152921513308410032] = val_6.x;    //  dest_result_addr=1152921513308410032
        // 0x00B23154: BL #0x1684130              | X0 = Pathfinding.AstarMath.DistancePointSegmentStrict(a:  new UnityEngine.Vector3() {x = 8.96831E-44f, y = 0f, z = 7.117545E-37f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 5.142877E-39f}, p:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.z, z = ???});
        float val_7 = Pathfinding.AstarMath.DistancePointSegmentStrict(a:  new UnityEngine.Vector3() {x = 8.96831E-44f, y = 0f, z = 7.117545E-37f}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 5.142877E-39f}, p:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.z, z = ???});
        // 0x00B23158: FCMP s0, s14               | STATE = COMPARE(val_7, V0.16B)          
        // 0x00B2315C: B.MI #0xb23094             | if (val_7 < 0) goto label_12;           
        if(val_7 < 0)
        {
            goto label_12;
        }
        label_6:
        // 0x00B23160: LDR x20, [x19, #0x60]      | X20 = this.path; //P2                   
        // 0x00B23164: CBNZ x20, #0xb2316c        | if (this.path != null) goto label_13;   
        if(this.path != null)
        {
            goto label_13;
        }
        // 0x00B23168: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_13:
        // 0x00B2316C: LDR w8, [x20, #0x18]       | W8 = this.path.Length; //P2             
        int val_8 = this.path.Length;
        // 0x00B23170: SUB w8, w8, #1             | W8 = (this.path.Length - 1);            
        val_8 = val_8 - 1;
        // 0x00B23174: CMP w21, w8                | STATE = COMPARE(0x1, (this.path.Length - 1))
        // 0x00B23178: B.LT #0xb230a0             | if (val_8 < this.path.Length) goto label_14;
        if(val_8 < val_8)
        {
            goto label_14;
        }
        label_2:
        // 0x00B2317C: SUB sp, x29, #0x70         | SP = (1152921513308410160 - 112) = 1152921513308410048 (0x1000000206A750C0);
        // 0x00B23180: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B23184: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B23188: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B2318C: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B23190: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B23194: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B23198: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B2319C: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00B231A0: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B231A4 (11678116), len: 108  VirtAddr: 0x00B231A4 RVA: 0x00B231A4 token: 100682730 methodIndex: 24723 delegateWrapperIndex: 0 methodInvoker: 0
    [System.Diagnostics.DebuggerHiddenAttribute] // 0x285B8AC
    public System.Collections.IEnumerator WaitToRepath()
    {
        //
        // Disasemble & Code
        // 0x00B231A4: STP x20, x19, [sp, #-0x20]! | stack[1152921513308690080] = ???;  stack[1152921513308690088] = ???;  //  dest_result_addr=1152921513308690080 |  dest_result_addr=1152921513308690088
        // 0x00B231A8: STP x29, x30, [sp, #0x10]  | stack[1152921513308690096] = ???;  stack[1152921513308690104] = ???;  //  dest_result_addr=1152921513308690096 |  dest_result_addr=1152921513308690104
        // 0x00B231AC: ADD x29, sp, #0x10         | X29 = (1152921513308690080 + 16) = 1152921513308690096 (0x1000000206AB96B0);
        // 0x00B231B0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B231B4: LDRB w8, [x20, #0x729]     | W8 = (bool)static_value_03733729;       
        // 0x00B231B8: MOV x19, x0                | X19 = 1152921513308702112 (0x1000000206ABC5A0);//ML01
        // 0x00B231BC: TBNZ w8, #0, #0xb231d8     | if (static_value_03733729 == true) goto label_0;
        // 0x00B231C0: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
        // 0x00B231C4: LDR x8, [x8, #0x418]       | X8 = 0x2B8AB04;                         
        // 0x00B231C8: LDR w0, [x8]               | W0 = 0x17F;                             
        // 0x00B231CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F, ????);      
        // 0x00B231D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B231D4: STRB w8, [x20, #0x729]     | static_value_03733729 = true;            //  dest_result_addr=57882409
        label_0:
        // 0x00B231D8: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
        // 0x00B231DC: LDR x8, [x8, #0x698]       | X8 = 1152921504843534336;               
        // 0x00B231E0: LDR x0, [x8]               | X0 = typeof(AIFollow.<WaitToRepath>c__Iterator0);
        object val_1 = null;
        // 0x00B231E4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AIFollow.<WaitToRepath>c__Iterator0), ????);
        // 0x00B231E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B231EC: MOV x20, x0                | X20 = 1152921504843534336 (0x100000000E1B9000);//ML01
        // 0x00B231F0: BL #0x16f59f0              | .ctor();                                
        val_1 = new System.Object();
        // 0x00B231F4: CBNZ x20, #0xb231fc        | if ( != 0) goto label_1;                
        if(null != 0)
        {
            goto label_1;
        }
        // 0x00B231F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
        label_1:
        // 0x00B231FC: STR x19, [x20, #0x18]      | typeof(AIFollow.<WaitToRepath>c__Iterator0).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504843534360
        typeof(AIFollow.<WaitToRepath>c__Iterator0).__il2cppRuntimeField_18 = this;
        // 0x00B23200: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B23204: MOV x0, x20                | X0 = 1152921504843534336 (0x100000000E1B9000);//ML01
        // 0x00B23208: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B2320C: RET                        |  return (System.Collections.IEnumerator)typeof(AIFollow.<WaitToRepath>c__Iterator0);
        return (System.Collections.IEnumerator)val_1;
        //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B23218 (11678232), len: 8  VirtAddr: 0x00B23218 RVA: 0x00B23218 token: 100682731 methodIndex: 24724 delegateWrapperIndex: 0 methodInvoker: 0
    public void Stop()
    {
        //
        // Disasemble & Code
        // 0x00B23218: STURH wzr, [x0, #0x35]     | this.canSearch = false; this.canMove = false;  //  dest_result_addr=1152921513308814165 dest_result_addr=1152921513308814166
        this.canSearch = false;
        this.canMove = false;
        // 0x00B2321C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B23220 (11678240), len: 12  VirtAddr: 0x00B23220 RVA: 0x00B23220 token: 100682732 methodIndex: 24725 delegateWrapperIndex: 0 methodInvoker: 0
    public void Resume()
    {
        //
        // Disasemble & Code
        // 0x00B23220: MOVZ w8, #0x101            | W8 = 257 (0x101);//ML01                 
        // 0x00B23224: STURH w8, [x0, #0x35]      | this.canSearch = true; this.canMove = true;  //  dest_result_addr=1152921513308926165 dest_result_addr=1152921513308926166
        this.canSearch = true;
        this.canMove = true;
        // 0x00B23228: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2322C (11678252), len: 520  VirtAddr: 0x00B2322C RVA: 0x00B2322C token: 100682733 methodIndex: 24726 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void Repath()
    {
        //
        // Disasemble & Code
        // 0x00B2322C: STP d11, d10, [sp, #-0x60]! | stack[1152921513309068000] = ???;  stack[1152921513309068008] = ???;  //  dest_result_addr=1152921513309068000 |  dest_result_addr=1152921513309068008
        // 0x00B23230: STP d9, d8, [sp, #0x10]    | stack[1152921513309068016] = ???;  stack[1152921513309068024] = ???;  //  dest_result_addr=1152921513309068016 |  dest_result_addr=1152921513309068024
        // 0x00B23234: STP x24, x23, [sp, #0x20]  | stack[1152921513309068032] = ???;  stack[1152921513309068040] = ???;  //  dest_result_addr=1152921513309068032 |  dest_result_addr=1152921513309068040
        // 0x00B23238: STP x22, x21, [sp, #0x30]  | stack[1152921513309068048] = ???;  stack[1152921513309068056] = ???;  //  dest_result_addr=1152921513309068048 |  dest_result_addr=1152921513309068056
        // 0x00B2323C: STP x20, x19, [sp, #0x40]  | stack[1152921513309068064] = ???;  stack[1152921513309068072] = ???;  //  dest_result_addr=1152921513309068064 |  dest_result_addr=1152921513309068072
        // 0x00B23240: STP x29, x30, [sp, #0x50]  | stack[1152921513309068080] = ???;  stack[1152921513309068088] = ???;  //  dest_result_addr=1152921513309068080 |  dest_result_addr=1152921513309068088
        // 0x00B23244: ADD x29, sp, #0x50         | X29 = (1152921513309068000 + 80) = 1152921513309068080 (0x1000000206B15B30);
        // 0x00B23248: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B2324C: LDRB w8, [x20, #0x72a]     | W8 = (bool)static_value_0373372A;       
        // 0x00B23250: MOV x19, x0                | X19 = 1152921513309080096 (0x1000000206B18A20);//ML01
        // 0x00B23254: TBNZ w8, #0, #0xb23270     | if (static_value_0373372A == true) goto label_0;
        // 0x00B23258: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
        // 0x00B2325C: LDR x8, [x8, #0x700]       | X8 = 0x2B8AAF4;                         
        // 0x00B23260: LDR w0, [x8]               | W0 = 0x17B;                             
        // 0x00B23264: BL #0x2782188              | X0 = sub_2782188( ?? 0x17B, ????);      
        // 0x00B23268: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B2326C: STRB w8, [x20, #0x72a]     | static_value_0373372A = true;            //  dest_result_addr=57882410
        label_0:
        // 0x00B23270: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23274: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23278: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x00B2327C: STR s0, [x19, #0x58]       | this.lastPathSearch = val_1;             //  dest_result_addr=1152921513309080184
        this.lastPathSearch = val_1;
        // 0x00B23280: ADRP x21, #0x35fe000       | X21 = 56614912 (0x35FE000);             
        // 0x00B23284: LDR x21, [x21, #0x810]     | X21 = 1152921504697475072;              
        // 0x00B23288: LDR x20, [x19, #0x38]      | X20 = this.seeker; //P2                 
        // 0x00B2328C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B23290: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B23294: TBZ w8, #0, #0xb232a4      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B23298: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B2329C: CBNZ w8, #0xb232a4         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B232A0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B232A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B232A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B232AC: MOV x1, x20                | X1 = this.seeker;//m1                   
        // 0x00B232B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B232B4: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.seeker);
        bool val_2 = UnityEngine.Object.op_Equality(x:  0, y:  this.seeker);
        // 0x00B232B8: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B232BC: TBNZ w8, #0, #0xb23404     | if ((val_2 & 1) == true) goto label_9;  
        if(val_3 == true)
        {
            goto label_9;
        }
        // 0x00B232C0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B232C4: LDR x20, [x19, #0x18]      | X20 = this.target; //P2                 
        // 0x00B232C8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B232CC: TBZ w8, #0, #0xb232dc      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
        // 0x00B232D0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B232D4: CBNZ w8, #0xb232dc         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
        // 0x00B232D8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_5:
        // 0x00B232DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B232E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B232E4: MOV x1, x20                | X1 = this.target;//m1                   
        // 0x00B232E8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B232EC: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.target);
        bool val_4 = UnityEngine.Object.op_Equality(x:  0, y:  this.target);
        // 0x00B232F0: AND w8, w0, #1             | W8 = (val_4 & 1);                       
        bool val_5 = val_4;
        // 0x00B232F4: TBNZ w8, #0, #0xb23404     | if ((val_4 & 1) == true) goto label_9;  
        if(val_5 == true)
        {
            goto label_9;
        }
        // 0x00B232F8: LDRB w8, [x19, #0x35]      | W8 = this.canSearch; //P2               
        // 0x00B232FC: CBZ w8, #0xb23404          | if (this.canSearch == false) goto label_9;
        if(this.canSearch == false)
        {
            goto label_9;
        }
        // 0x00B23300: LDR x20, [x19, #0x38]      | X20 = this.seeker; //P2                 
        // 0x00B23304: CBNZ x20, #0xb2330c        | if (this.seeker != null) goto label_8;  
        if(this.seeker != null)
        {
            goto label_8;
        }
        // 0x00B23308: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_8:
        // 0x00B2330C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23310: MOV x0, x20                | X0 = this.seeker;//m1                   
        // 0x00B23314: BL #0xca5740               | X0 = this.seeker.IsDone();              
        bool val_6 = this.seeker.IsDone();
        // 0x00B23318: AND w8, w0, #1             | W8 = (val_6 & 1);                       
        bool val_7 = val_6;
        // 0x00B2331C: TBZ w8, #0, #0xb23404      | if ((val_6 & 1) == false) goto label_9; 
        if(val_7 == false)
        {
            goto label_9;
        }
        // 0x00B23320: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23324: MOV x0, x19                | X0 = 1152921513309080096 (0x1000000206B18A20);//ML01
        // 0x00B23328: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_8 = this.transform;
        // 0x00B2332C: MOV x20, x0                | X20 = val_8;//m1                        
        // 0x00B23330: CBNZ x20, #0xb23338        | if (val_8 != null) goto label_10;       
        if(val_8 != null)
        {
            goto label_10;
        }
        // 0x00B23334: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_10:
        // 0x00B23338: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2333C: MOV x0, x20                | X0 = val_8;//m1                         
        // 0x00B23340: BL #0x2693510              | X0 = val_8.get_position();              
        UnityEngine.Vector3 val_9 = val_8.position;
        // 0x00B23344: LDR x20, [x19, #0x18]      | X20 = this.target; //P2                 
        // 0x00B23348: MOV v8.16b, v0.16b         | V8 = val_9.x;//m1                       
        // 0x00B2334C: MOV v9.16b, v1.16b         | V9 = val_9.y;//m1                       
        // 0x00B23350: MOV v10.16b, v2.16b        | V10 = val_9.z;//m1                      
        // 0x00B23354: CBNZ x20, #0xb2335c        | if (this.target != null) goto label_11; 
        if(this.target != null)
        {
            goto label_11;
        }
        // 0x00B23358: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_8, ????);      
        label_11:
        // 0x00B2335C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23360: MOV x0, x20                | X0 = this.target;//m1                   
        // 0x00B23364: BL #0x2693510              | X0 = this.target.get_position();        
        UnityEngine.Vector3 val_10 = this.target.position;
        // 0x00B23368: MOV v3.16b, v0.16b         | V3 = val_10.x;//m1                      
        // 0x00B2336C: MOV v4.16b, v1.16b         | V4 = val_10.y;//m1                      
        // 0x00B23370: MOV v5.16b, v2.16b         | V5 = val_10.z;//m1                      
        // 0x00B23374: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23378: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2337C: MOV v0.16b, v8.16b         | V0 = val_9.x;//m1                       
        // 0x00B23380: MOV v1.16b, v9.16b         | V1 = val_9.y;//m1                       
        // 0x00B23384: MOV v2.16b, v10.16b        | V2 = val_9.z;//m1                       
        // 0x00B23388: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2338C: BL #0xd1c25c               | X0 = Pathfinding.ABPath.Construct(start:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, end:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, callback:  0);
        Pathfinding.ABPath val_11 = Pathfinding.ABPath.Construct(start:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z}, end:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, callback:  0);
        // 0x00B23390: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B23394: ADRP x9, #0x35fa000        | X9 = 56598528 (0x35FA000);              
        // 0x00B23398: LDR x20, [x19, #0x38]      | X20 = this.seeker; //P2                 
        // 0x00B2339C: LDR x8, [x8, #0x6a0]       | X8 = 1152921513309042784;               
        // 0x00B233A0: LDR x9, [x9, #0x288]       | X9 = 1152921504836718592;               
        // 0x00B233A4: MOV x21, x0                | X21 = val_11;//m1                       
        // 0x00B233A8: LDR x23, [x8]              | X23 = public System.Void AIFollow::OnPathComplete(Pathfinding.Path p);
        // 0x00B233AC: LDR x8, [x9]               | X8 = typeof(OnPathDelegate);            
        // 0x00B233B0: MOV x0, x8                 | X0 = 1152921504836718592 (0x100000000DB39000);//ML01
        OnPathDelegate val_12 = null;
        // 0x00B233B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
        // 0x00B233B8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B233BC: MOV x1, x19                | X1 = 1152921513309080096 (0x1000000206B18A20);//ML01
        // 0x00B233C0: MOV x2, x23                | X2 = 1152921513309042784 (0x1000000206B0F860);//ML01
        // 0x00B233C4: MOV x22, x0                | X22 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B233C8: BL #0xd1b25c               | .ctor(object:  this, method:  public System.Void AIFollow::OnPathComplete(Pathfinding.Path p));
        val_12 = new OnPathDelegate(object:  this, method:  public System.Void AIFollow::OnPathComplete(Pathfinding.Path p));
        // 0x00B233CC: CBNZ x20, #0xb233d4        | if (this.seeker != null) goto label_12; 
        if(this.seeker != null)
        {
            goto label_12;
        }
        // 0x00B233D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  public System.Void AIFollow::OnPathComplete(Pathfinding.Path p)), ????);
        label_12:
        // 0x00B233D4: MOV x0, x20                | X0 = this.seeker;//m1                   
        // 0x00B233D8: MOV x1, x21                | X1 = val_11;//m1                        
        // 0x00B233DC: MOV x2, x22                | X2 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B233E0: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B233E4: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B233E8: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B233EC: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B233F0: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B233F4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
        // 0x00B233F8: MOVN w3, #0                | W3 = 0 (0x0);//ML01                     
        // 0x00B233FC: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00B23400: B #0xca59f0                | X0 = this.seeker.StartPath(p:  val_11, callback:  val_12, graphMask:  0); return;
        Pathfinding.Path val_13 = this.seeker.StartPath(p:  val_11, callback:  val_12, graphMask:  0);
        return;
        label_9:
        // 0x00B23404: MOV x0, x19                | X0 = 1152921513309080096 (0x1000000206B18A20);//ML01
        // 0x00B23408: BL #0xb231a4               | X0 = this.WaitToRepath();               
        System.Collections.IEnumerator val_14 = this.WaitToRepath();
        // 0x00B2340C: MOV x1, x0                 | X1 = val_14;//m1                        
        // 0x00B23410: MOV x0, x19                | X0 = 1152921513309080096 (0x1000000206B18A20);//ML01
        // 0x00B23414: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B23418: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2341C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B23420: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
        // 0x00B23424: LDP d9, d8, [sp, #0x10]    | D9 = ; D8 = ;                            //  | 
        // 0x00B23428: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2342C: LDP d11, d10, [sp], #0x60  | D11 = ; D10 = ;                          //  | 
        // 0x00B23430: B #0x1b772bc               | X0 = this.StartCoroutine(routine:  val_14); return;
        UnityEngine.Coroutine val_15 = this.StartCoroutine(routine:  val_14);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B23434 (11678772), len: 360  VirtAddr: 0x00B23434 RVA: 0x00B23434 token: 100682734 methodIndex: 24727 delegateWrapperIndex: 0 methodInvoker: 0
    public void PathToTarget(UnityEngine.Vector3 targetPoint)
    {
        //
        // Disasemble & Code
        // 0x00B23434: STP d13, d12, [sp, #-0x60]! | stack[1152921513309237344] = ???;  stack[1152921513309237352] = ???;  //  dest_result_addr=1152921513309237344 |  dest_result_addr=1152921513309237352
        // 0x00B23438: STP d11, d10, [sp, #0x10]  | stack[1152921513309237360] = ???;  stack[1152921513309237368] = ???;  //  dest_result_addr=1152921513309237360 |  dest_result_addr=1152921513309237368
        // 0x00B2343C: STP d9, d8, [sp, #0x20]    | stack[1152921513309237376] = ???;  stack[1152921513309237384] = ???;  //  dest_result_addr=1152921513309237376 |  dest_result_addr=1152921513309237384
        // 0x00B23440: STP x22, x21, [sp, #0x30]  | stack[1152921513309237392] = ???;  stack[1152921513309237400] = ???;  //  dest_result_addr=1152921513309237392 |  dest_result_addr=1152921513309237400
        // 0x00B23444: STP x20, x19, [sp, #0x40]  | stack[1152921513309237408] = ???;  stack[1152921513309237416] = ???;  //  dest_result_addr=1152921513309237408 |  dest_result_addr=1152921513309237416
        // 0x00B23448: STP x29, x30, [sp, #0x50]  | stack[1152921513309237424] = ???;  stack[1152921513309237432] = ???;  //  dest_result_addr=1152921513309237424 |  dest_result_addr=1152921513309237432
        // 0x00B2344C: ADD x29, sp, #0x50         | X29 = (1152921513309237344 + 80) = 1152921513309237424 (0x1000000206B3F0B0);
        // 0x00B23450: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B23454: LDRB w8, [x20, #0x72b]     | W8 = (bool)static_value_0373372B;       
        // 0x00B23458: MOV v8.16b, v2.16b         | V8 = targetPoint.z;//m1                 
        // 0x00B2345C: MOV v9.16b, v1.16b         | V9 = targetPoint.y;//m1                 
        // 0x00B23460: MOV v10.16b, v0.16b        | V10 = targetPoint.x;//m1                
        // 0x00B23464: MOV x19, x0                | X19 = 1152921513309249440 (0x1000000206B41FA0);//ML01
        // 0x00B23468: TBNZ w8, #0, #0xb23484     | if (static_value_0373372B == true) goto label_0;
        // 0x00B2346C: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
        // 0x00B23470: LDR x8, [x8, #0x930]       | X8 = 0x2B8AAF0;                         
        // 0x00B23474: LDR w0, [x8]               | W0 = 0x17A;                             
        // 0x00B23478: BL #0x2782188              | X0 = sub_2782188( ?? 0x17A, ????);      
        // 0x00B2347C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B23480: STRB w8, [x20, #0x72b]     | static_value_0373372B = true;            //  dest_result_addr=57882411
        label_0:
        // 0x00B23484: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23488: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2348C: BL #0x2690b00              | X0 = UnityEngine.Time.get_time();       
        float val_1 = UnityEngine.Time.time;
        // 0x00B23490: STR s0, [x19, #0x58]       | this.lastPathSearch = val_1;             //  dest_result_addr=1152921513309249528
        this.lastPathSearch = val_1;
        // 0x00B23494: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B23498: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B2349C: LDR x20, [x19, #0x38]      | X20 = this.seeker; //P2                 
        // 0x00B234A0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
        // 0x00B234A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B234A8: TBZ w8, #0, #0xb234b8      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B234AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B234B0: CBNZ w8, #0xb234b8         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B234B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B234B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B234BC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B234C0: MOV x1, x20                | X1 = this.seeker;//m1                   
        // 0x00B234C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B234C8: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  this.seeker);
        bool val_2 = UnityEngine.Object.op_Equality(x:  0, y:  this.seeker);
        // 0x00B234CC: AND w8, w0, #1             | W8 = (val_2 & 1);                       
        bool val_3 = val_2;
        // 0x00B234D0: TBZ w8, #0, #0xb234f0      | if ((val_2 & 1) == false) goto label_3; 
        if(val_3 == false)
        {
            goto label_3;
        }
        // 0x00B234D4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B234D8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B234DC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B234E0: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B234E4: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B234E8: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B234EC: RET                        |  return;                                
        return;
        label_3:
        // 0x00B234F0: LDR x20, [x19, #0x38]      | X20 = this.seeker; //P2                 
        // 0x00B234F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B234F8: MOV x0, x19                | X0 = 1152921513309249440 (0x1000000206B41FA0);//ML01
        // 0x00B234FC: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_4 = this.transform;
        // 0x00B23500: MOV x21, x0                | X21 = val_4;//m1                        
        // 0x00B23504: CBNZ x21, #0xb2350c        | if (val_4 != null) goto label_4;        
        if(val_4 != null)
        {
            goto label_4;
        }
        // 0x00B23508: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_4:
        // 0x00B2350C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23510: MOV x0, x21                | X0 = val_4;//m1                         
        // 0x00B23514: BL #0x2693510              | X0 = val_4.get_position();              
        UnityEngine.Vector3 val_5 = val_4.position;
        // 0x00B23518: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
        // 0x00B2351C: ADRP x9, #0x35fa000        | X9 = 56598528 (0x35FA000);              
        // 0x00B23520: LDR x8, [x8, #0x6a0]       | X8 = 1152921513309042784;               
        // 0x00B23524: LDR x9, [x9, #0x288]       | X9 = 1152921504836718592;               
        // 0x00B23528: MOV v11.16b, v0.16b        | V11 = val_5.x;//m1                      
        // 0x00B2352C: MOV v12.16b, v1.16b        | V12 = val_5.y;//m1                      
        // 0x00B23530: LDR x22, [x8]              | X22 = public System.Void AIFollow::OnPathComplete(Pathfinding.Path p);
        // 0x00B23534: LDR x0, [x9]               | X0 = typeof(OnPathDelegate);            
        OnPathDelegate val_6 = null;
        // 0x00B23538: MOV v13.16b, v2.16b        | V13 = val_5.z;//m1                      
        // 0x00B2353C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(OnPathDelegate), ????);
        // 0x00B23540: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B23544: MOV x1, x19                | X1 = 1152921513309249440 (0x1000000206B41FA0);//ML01
        // 0x00B23548: MOV x2, x22                | X2 = 1152921513309042784 (0x1000000206B0F860);//ML01
        // 0x00B2354C: MOV x21, x0                | X21 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B23550: BL #0xd1b25c               | .ctor(object:  this, method:  public System.Void AIFollow::OnPathComplete(Pathfinding.Path p));
        val_6 = new OnPathDelegate(object:  this, method:  public System.Void AIFollow::OnPathComplete(Pathfinding.Path p));
        // 0x00B23554: CBNZ x20, #0xb2355c        | if (this.seeker != null) goto label_5;  
        if(this.seeker != null)
        {
            goto label_5;
        }
        // 0x00B23558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  this, method:  public System.Void AIFollow::OnPathComplete(Pathfinding.Path p)), ????);
        label_5:
        // 0x00B2355C: MOV x0, x20                | X0 = this.seeker;//m1                   
        // 0x00B23560: MOV v0.16b, v11.16b        | V0 = val_5.x;//m1                       
        // 0x00B23564: MOV v3.16b, v10.16b        | V3 = targetPoint.x;//m1                 
        // 0x00B23568: MOV v4.16b, v9.16b         | V4 = targetPoint.y;//m1                 
        // 0x00B2356C: MOV v5.16b, v8.16b         | V5 = targetPoint.z;//m1                 
        // 0x00B23570: MOV x1, x21                | X1 = 1152921504836718592 (0x100000000DB39000);//ML01
        // 0x00B23574: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
        // 0x00B23578: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
        // 0x00B2357C: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
        // 0x00B23580: LDP d9, d8, [sp, #0x20]    | D9 = ; D8 = ;                            //  | 
        // 0x00B23584: LDP d11, d10, [sp, #0x10]  | D11 = ; D10 = ;                          //  | 
        // 0x00B23588: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B2358C: MOV v1.16b, v12.16b        | V1 = val_5.y;//m1                       
        // 0x00B23590: MOV v2.16b, v13.16b        | V2 = val_5.z;//m1                       
        // 0x00B23594: LDP d13, d12, [sp], #0x60  | D13 = ; D12 = ;                          //  | 
        // 0x00B23598: B #0xca23ec                | X0 = this.seeker.StartPath(start:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, end:  new UnityEngine.Vector3() {x = targetPoint.x, y = targetPoint.y, z = targetPoint.z}, callback:  val_6); return;
        Pathfinding.Path val_7 = this.seeker.StartPath(start:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z}, end:  new UnityEngine.Vector3() {x = targetPoint.x, y = targetPoint.y, z = targetPoint.z}, callback:  val_6);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B2359C (11679132), len: 4  VirtAddr: 0x00B2359C RVA: 0x00B2359C token: 100682735 methodIndex: 24728 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual void ReachedEndOfPath()
    {
        //
        // Disasemble & Code
        // 0x00B2359C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B235A0 (11679136), len: 1648  VirtAddr: 0x00B235A0 RVA: 0x00B235A0 token: 100682736 methodIndex: 24729 delegateWrapperIndex: 0 methodInvoker: 0
    public void Update()
    {
        //
        // Disasemble & Code
        //  | 
        UnityEngine.CharacterController val_30;
        //  | 
        int val_31;
        //  | 
        float val_32;
        //  | 
        float val_33;
        //  | 
        float val_34;
        //  | 
        float val_35;
        //  | 
        float val_36;
        //  | 
        float val_37;
        //  | 
        float val_38;
        //  | 
        float val_39;
        //  | 
        float val_40;
        // 0x00B235A0: STP d15, d14, [sp, #-0x80]! | stack[1152921513309641536] = ???;  stack[1152921513309641544] = ???;  //  dest_result_addr=1152921513309641536 |  dest_result_addr=1152921513309641544
        // 0x00B235A4: STP d13, d12, [sp, #0x10]  | stack[1152921513309641552] = ???;  stack[1152921513309641560] = ???;  //  dest_result_addr=1152921513309641552 |  dest_result_addr=1152921513309641560
        // 0x00B235A8: STP d11, d10, [sp, #0x20]  | stack[1152921513309641568] = ???;  stack[1152921513309641576] = ???;  //  dest_result_addr=1152921513309641568 |  dest_result_addr=1152921513309641576
        // 0x00B235AC: STP d9, d8, [sp, #0x30]    | stack[1152921513309641584] = ???;  stack[1152921513309641592] = ???;  //  dest_result_addr=1152921513309641584 |  dest_result_addr=1152921513309641592
        // 0x00B235B0: STP x24, x23, [sp, #0x40]  | stack[1152921513309641600] = ???;  stack[1152921513309641608] = ???;  //  dest_result_addr=1152921513309641600 |  dest_result_addr=1152921513309641608
        // 0x00B235B4: STP x22, x21, [sp, #0x50]  | stack[1152921513309641616] = ???;  stack[1152921513309641624] = ???;  //  dest_result_addr=1152921513309641616 |  dest_result_addr=1152921513309641624
        // 0x00B235B8: STP x20, x19, [sp, #0x60]  | stack[1152921513309641632] = ???;  stack[1152921513309641640] = ???;  //  dest_result_addr=1152921513309641632 |  dest_result_addr=1152921513309641640
        // 0x00B235BC: STP x29, x30, [sp, #0x70]  | stack[1152921513309641648] = ???;  stack[1152921513309641656] = ???;  //  dest_result_addr=1152921513309641648 |  dest_result_addr=1152921513309641656
        // 0x00B235C0: ADD x29, sp, #0x70         | X29 = (1152921513309641536 + 112) = 1152921513309641648 (0x1000000206BA1BB0);
        // 0x00B235C4: SUB sp, sp, #0x50          | SP = (1152921513309641536 - 80) = 1152921513309641456 (0x1000000206BA1AF0);
        // 0x00B235C8: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B235CC: LDRB w8, [x20, #0x72c]     | W8 = (bool)static_value_0373372C;       
        // 0x00B235D0: MOV x19, x0                | X19 = 1152921513309653664 (0x1000000206BA4AA0);//ML01
        val_30 = this;
        // 0x00B235D4: TBNZ w8, #0, #0xb235f0     | if (static_value_0373372C == true) goto label_0;
        // 0x00B235D8: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
        // 0x00B235DC: LDR x8, [x8, #0xb90]       | X8 = 0x2B8AB00;                         
        // 0x00B235E0: LDR w0, [x8]               | W0 = 0x17E;                             
        // 0x00B235E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x17E, ????);      
        // 0x00B235E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B235EC: STRB w8, [x20, #0x72c]     | static_value_0373372C = true;            //  dest_result_addr=57882412
        label_0:
        // 0x00B235F0: STR wzr, [sp, #0x48]       | stack[1152921513309641528] = 0x0;        //  dest_result_addr=1152921513309641528
        // 0x00B235F4: STR xzr, [sp, #0x40]       | stack[1152921513309641520] = 0x0;        //  dest_result_addr=1152921513309641520
        // 0x00B235F8: STR wzr, [sp, #0x38]       | stack[1152921513309641512] = 0x0;        //  dest_result_addr=1152921513309641512
        // 0x00B235FC: STR xzr, [sp, #0x30]       | stack[1152921513309641504] = 0x0;        //  dest_result_addr=1152921513309641504
        // 0x00B23600: STR wzr, [sp, #0x28]       | stack[1152921513309641496] = 0x0;        //  dest_result_addr=1152921513309641496
        // 0x00B23604: STR xzr, [sp, #0x20]       | stack[1152921513309641488] = 0x0;        //  dest_result_addr=1152921513309641488
        // 0x00B23608: LDR x20, [x19, #0x60]      | X20 = this.path; //P2                   
        // 0x00B2360C: CBZ x20, #0xb23be8         | if (this.path == null) goto label_43;   
        if(this.path == null)
        {
            goto label_43;
        }
        // 0x00B23610: LDRSW x21, [x19, #0x5c]    | X21 = this.pathIndex; //P2              
        val_31 = this.pathIndex;
        // 0x00B23614: LDR w8, [x20, #0x18]       | W8 = this.path.Length; //P2             
        // 0x00B23618: CMP w21, w8                | STATE = COMPARE(this.pathIndex, this.path.Length)
        // 0x00B2361C: B.GE #0xb23be8             | if (val_31 >= this.path.Length) goto label_43;
        if(val_31 >= this.path.Length)
        {
            goto label_43;
        }
        // 0x00B23620: UBFX x9, x21, #0x1e, #2    | X9 = (ulong)((this.pathIndex>>30) & 0x3);
        // 0x00B23624: TBNZ w9, #1, #0xb23be8     | if (((ulong)((this.pathIndex>>30) & 0x3) & 0x2) != 0) goto label_43;
        if((((ulong)(val_31 >> 30) & 3) & 2) != 0)
        {
            goto label_43;
        }
        // 0x00B23628: LDRB w9, [x19, #0x36]      | W9 = this.canMove; //P2                 
        // 0x00B2362C: CBZ w9, #0xb23be8          | if (this.canMove == false) goto label_43;
        if(this.canMove == false)
        {
            goto label_43;
        }
        // 0x00B23630: CMP w21, w8                | STATE = COMPARE(this.pathIndex, this.path.Length)
        // 0x00B23634: B.LO #0xb23644             | if (val_31 < this.path.Length) goto label_5;
        if(val_31 < this.path.Length)
        {
            goto label_5;
        }
        // 0x00B23638: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x17E, ????);      
        // 0x00B2363C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23640: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x17E, ????);      
        label_5:
        // 0x00B23644: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_30 = 12;
        // 0x00B23648: MADD x8, x21, x8, x20      | X8 = (this.pathIndex * 12) + this.path; 
        val_30 = this.path + (val_31 * val_30);
        // 0x00B2364C: LDR s8, [x8, #0x20]        | S8 = (this.pathIndex * 12) + this.path + 32;
        val_32 = mem[(this.pathIndex * 12) + this.path + 32];
        val_32 = (this.pathIndex * 12) + this.path + 32;
        // 0x00B23650: LDR s9, [x8, #0x28]        | S9 = (this.pathIndex * 12) + this.path + 40;
        // 0x00B23654: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23658: CBNZ x20, #0xb23660        | if (this.tr != null) goto label_6;      
        if(this.tr != null)
        {
            goto label_6;
        }
        // 0x00B2365C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x17E, ????);      
        label_6:
        // 0x00B23660: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23664: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23668: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_1 = this.tr.position;
        // 0x00B2366C: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00B23670: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        val_31 = 1152921504695078912;
        // 0x00B23674: MOV v10.16b, v1.16b        | V10 = val_1.y;//m1                      
        val_33 = val_1.y;
        // 0x00B23678: ORR w22, wzr, #0xc         | W22 = 12(0xC);                          
        // 0x00B2367C: B #0xb23690                |  goto label_7;                          
        goto label_7;
        label_17:
        // 0x00B23680: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23684: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23688: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_2 = this.tr.position;
        // 0x00B2368C: MOV v10.16b, v1.16b        | V10 = val_2.y;//m1                      
        val_33 = val_2.y;
        label_7:
        // 0x00B23690: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23694: CBNZ x20, #0xb2369c        | if (this.tr != null) goto label_8;      
        if(this.tr != null)
        {
            goto label_8;
        }
        // 0x00B23698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tr, ????);    
        label_8:
        // 0x00B2369C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B236A0: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B236A4: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_3 = this.tr.position;
        // 0x00B236A8: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B236AC: MOV v11.16b, v0.16b        | V11 = val_3.x;//m1                      
        // 0x00B236B0: MOV v12.16b, v1.16b        | V12 = val_3.y;//m1                      
        // 0x00B236B4: MOV v13.16b, v2.16b        | V13 = val_3.z;//m1                      
        // 0x00B236B8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B236BC: TBZ w8, #0, #0xb236cc      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_10;
        // 0x00B236C0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B236C4: CBNZ w8, #0xb236cc         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
        // 0x00B236C8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_10:
        // 0x00B236CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B236D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B236D4: MOV v0.16b, v8.16b         | V0 = (this.pathIndex * 12) + this.path + 32;//m1
        val_34 = val_32;
        // 0x00B236D8: MOV v1.16b, v10.16b        | V1 = val_2.y;//m1                       
        // 0x00B236DC: MOV v2.16b, v9.16b         | V2 = (this.pathIndex * 12) + this.path + 40;//m1
        val_35 = (this.pathIndex * 12) + this.path + 40;
        // 0x00B236E0: MOV v3.16b, v11.16b        | V3 = val_3.x;//m1                       
        // 0x00B236E4: MOV v4.16b, v12.16b        | V4 = val_3.y;//m1                       
        // 0x00B236E8: MOV v5.16b, v13.16b        | V5 = val_3.z;//m1                       
        // 0x00B236EC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_34, y = val_33, z = val_35}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        UnityEngine.Vector3 val_4 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_34, y = val_33, z = val_35}, b:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z});
        // 0x00B236F0: ADD x0, sp, #0x30          | X0 = (1152921513309641456 + 48) = 1152921513309641504 (0x1000000206BA1B20);
        // 0x00B236F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B236F8: STP s0, s1, [sp, #0x30]    | stack[1152921513309641504] = val_4.x;  stack[1152921513309641508] = val_4.y;  //  dest_result_addr=1152921513309641504 |  dest_result_addr=1152921513309641508
        // 0x00B236FC: STR s2, [sp, #0x38]        | stack[1152921513309641512] = val_4.z;    //  dest_result_addr=1152921513309641512
        // 0x00B23700: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
        // 0x00B23704: LDR s1, [x19, #0x24]       | S1 = this.pickNextWaypointDistance; //P2 
        // 0x00B23708: FMUL s1, s1, s1            | S1 = (this.pickNextWaypointDistance * this.pickNextWaypointDistance);
        val_36 = this.pickNextWaypointDistance * this.pickNextWaypointDistance;
        // 0x00B2370C: FCMP s0, s1                | STATE = COMPARE(val_4.x, (this.pickNextWaypointDistance * this.pickNextWaypointDistance))
        // 0x00B23710: B.PL #0xb23824             | if (val_4.x >= 0) goto label_11;        
        if(val_4.x >= 0)
        {
            goto label_11;
        }
        // 0x00B23714: LDR w8, [x19, #0x5c]       | W8 = this.pathIndex; //P2               
        // 0x00B23718: LDR x23, [x19, #0x60]      | X23 = this.path; //P2                   
        // 0x00B2371C: ADD w20, w8, #1            | W20 = (this.pathIndex + 1);             
        int val_5 = this.pathIndex + 1;
        // 0x00B23720: STR w20, [x19, #0x5c]      | this.pathIndex = (this.pathIndex + 1);   //  dest_result_addr=1152921513309653756
        this.pathIndex = val_5;
        // 0x00B23724: CBNZ x23, #0xb2372c        | if (this.path != null) goto label_12;   
        if(this.path != null)
        {
            goto label_12;
        }
        // 0x00B23728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B20, ????);
        label_12:
        // 0x00B2372C: LDR w8, [x23, #0x18]       | W8 = this.path.Length; //P2             
        // 0x00B23730: CMP w20, w8                | STATE = COMPARE((this.pathIndex + 1), this.path.Length)
        // 0x00B23734: B.GE #0xb2377c             | if (val_5 >= this.path.Length) goto label_13;
        if(val_5 >= this.path.Length)
        {
            goto label_13;
        }
        // 0x00B23738: LDR x20, [x19, #0x60]      | X20 = this.path; //P2                   
        // 0x00B2373C: LDRSW x23, [x19, #0x5c]    | X23 = this.pathIndex; //P2              
        // 0x00B23740: CBNZ x20, #0xb23748        | if (this.path != null) goto label_14;   
        if(this.path != null)
        {
            goto label_14;
        }
        // 0x00B23744: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B20, ????);
        label_14:
        // 0x00B23748: LDR w8, [x20, #0x18]       | W8 = this.path.Length; //P2             
        // 0x00B2374C: CMP w23, w8                | STATE = COMPARE(this.pathIndex, this.path.Length)
        // 0x00B23750: B.LO #0xb23760             | if (this.pathIndex < this.path.Length) goto label_15;
        if(this.pathIndex < this.path.Length)
        {
            goto label_15;
        }
        // 0x00B23754: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1000000206BA1B20, ????);
        // 0x00B23758: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2375C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1000000206BA1B20, ????);
        label_15:
        // 0x00B23760: MADD x8, x23, x22, x20     | X8 = (this.pathIndex * 12) + this.path; 
        int val_6 = this.path + (this.pathIndex * 12);
        // 0x00B23764: LDR s8, [x8, #0x20]        | S8 = (this.pathIndex * 12) + this.path + 32;
        // 0x00B23768: LDR s9, [x8, #0x28]        | S9 = (this.pathIndex * 12) + this.path + 40;
        // 0x00B2376C: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23770: CBNZ x20, #0xb23680        | if (this.tr != null) goto label_17;     
        if(this.tr != null)
        {
            goto label_17;
        }
        // 0x00B23774: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B20, ????);
        // 0x00B23778: B #0xb23680                |  goto label_17;                         
        goto label_17;
        label_13:
        // 0x00B2377C: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23780: CBNZ x20, #0xb23788        | if (this.tr != null) goto label_18;     
        if(this.tr != null)
        {
            goto label_18;
        }
        // 0x00B23784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B20, ????);
        label_18:
        // 0x00B23788: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2378C: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23790: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_7 = this.tr.position;
        // 0x00B23794: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B23798: MOV v11.16b, v0.16b        | V11 = val_7.x;//m1                      
        // 0x00B2379C: MOV v12.16b, v1.16b        | V12 = val_7.y;//m1                      
        val_37 = val_7.y;
        // 0x00B237A0: MOV v13.16b, v2.16b        | V13 = val_7.z;//m1                      
        // 0x00B237A4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B237A8: TBZ w8, #0, #0xb237b8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B237AC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B237B0: CBNZ w8, #0xb237b8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B237B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_20:
        // 0x00B237B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B237BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B237C0: MOV v0.16b, v8.16b         | V0 = (this.pathIndex * 12) + this.path + 32;//m1
        val_34 = val_32;
        // 0x00B237C4: MOV v1.16b, v10.16b        | V1 = val_2.y;//m1                       
        // 0x00B237C8: MOV v2.16b, v9.16b         | V2 = (this.pathIndex * 12) + this.path + 40;//m1
        // 0x00B237CC: MOV v3.16b, v11.16b        | V3 = val_7.x;//m1                       
        // 0x00B237D0: MOV v4.16b, v12.16b        | V4 = val_7.y;//m1                       
        // 0x00B237D4: MOV v5.16b, v13.16b        | V5 = val_7.z;//m1                       
        // 0x00B237D8: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_34, y = val_33, z = (this.pathIndex * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_37, z = val_7.z});
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_34, y = val_33, z = (this.pathIndex * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_7.x, y = val_37, z = val_7.z});
        // 0x00B237DC: ADD x0, sp, #0x40          | X0 = (1152921513309641456 + 64) = 1152921513309641520 (0x1000000206BA1B30);
        // 0x00B237E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B237E4: STP s0, s1, [sp, #0x40]    | stack[1152921513309641520] = val_8.x;  stack[1152921513309641524] = val_8.y;  //  dest_result_addr=1152921513309641520 |  dest_result_addr=1152921513309641524
        // 0x00B237E8: STR s2, [sp, #0x48]        | stack[1152921513309641528] = val_8.z;    //  dest_result_addr=1152921513309641528
        // 0x00B237EC: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
        // 0x00B237F0: LDP s1, s2, [x19, #0x24]   | S1 = this.pickNextWaypointDistance; //P2  S2 = this.targetReached; //P2  //  | 
        float val_31 = this.pickNextWaypointDistance;
        val_35 = this.targetReached;
        // 0x00B237F4: FMUL s1, s1, s2            | S1 = (this.pickNextWaypointDistance * this.targetReached);
        val_31 = val_31 * val_35;
        // 0x00B237F8: FMUL s1, s1, s1            | S1 = ((this.pickNextWaypointDistance * this.targetReached) * (this.pickNextWaypointDistance * this.targetReached));
        val_36 = val_31 * val_31;
        // 0x00B237FC: FCMP s0, s1                | STATE = COMPARE(val_8.x, ((this.pickNextWaypointDistance * this.targetReached) * (this.pickNextWaypointDistance * this.targetReached)))
        // 0x00B23800: B.PL #0xb23818             | if (val_8.x >= 0) goto label_21;        
        if(val_8.x >= 0)
        {
            goto label_21;
        }
        // 0x00B23804: LDR x8, [x19]              | X8 = typeof(AIFollow);                  
        // 0x00B23808: MOV x0, x19                | X0 = 1152921513309653664 (0x1000000206BA4AA0);//ML01
        // 0x00B2380C: LDP x9, x1, [x8, #0x160]   | X9 = typeof(AIFollow).__il2cppRuntimeField_160; X1 = typeof(AIFollow).__il2cppRuntimeField_168; //  | 
        // 0x00B23810: BLR x9                     | X0 = typeof(AIFollow).__il2cppRuntimeField_160();
        // 0x00B23814: B #0xb23be8                |  goto label_43;                         
        goto label_43;
        label_21:
        // 0x00B23818: LDR w8, [x19, #0x5c]       | W8 = this.pathIndex; //P2               
        int val_32 = this.pathIndex;
        // 0x00B2381C: SUB w8, w8, #1             | W8 = (this.pathIndex - 1);              
        val_32 = val_32 - 1;
        // 0x00B23820: STR w8, [x19, #0x5c]       | this.pathIndex = (this.pathIndex - 1);   //  dest_result_addr=1152921513309653756
        this.pathIndex = val_32;
        label_11:
        // 0x00B23824: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23828: CBNZ x20, #0xb23830        | if (this.tr != null) goto label_23;     
        if(this.tr != null)
        {
            goto label_23;
        }
        // 0x00B2382C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B30, ????);
        label_23:
        // 0x00B23830: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23834: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23838: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_9 = this.tr.position;
        // 0x00B2383C: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B23840: MOV v11.16b, v0.16b        | V11 = val_9.x;//m1                      
        // 0x00B23844: MOV v12.16b, v1.16b        | V12 = val_9.y;//m1                      
        // 0x00B23848: MOV v13.16b, v2.16b        | V13 = val_9.z;//m1                      
        // 0x00B2384C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B23850: TBZ w8, #0, #0xb23860      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_25;
        // 0x00B23854: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B23858: CBNZ w8, #0xb23860         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_25;
        // 0x00B2385C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_25:
        // 0x00B23860: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23868: MOV v0.16b, v8.16b         | V0 = (this.pathIndex * 12) + this.path + 32;//m1
        // 0x00B2386C: MOV v1.16b, v10.16b        | V1 = val_2.y;//m1                       
        // 0x00B23870: MOV v2.16b, v9.16b         | V2 = (this.pathIndex * 12) + this.path + 40;//m1
        // 0x00B23874: MOV v3.16b, v11.16b        | V3 = val_9.x;//m1                       
        // 0x00B23878: MOV v4.16b, v12.16b        | V4 = val_9.y;//m1                       
        // 0x00B2387C: MOV v5.16b, v13.16b        | V5 = val_9.z;//m1                       
        // 0x00B23880: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_32, y = val_33, z = (this.pathIndex * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_32, y = val_33, z = (this.pathIndex * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_9.x, y = val_9.y, z = val_9.z});
        // 0x00B23884: MOV v8.16b, v0.16b         | V8 = val_10.x;//m1                      
        val_38 = val_10.x;
        // 0x00B23888: MOV v9.16b, v1.16b         | V9 = val_10.y;//m1                      
        val_39 = val_10.y;
        // 0x00B2388C: MOV v10.16b, v2.16b        | V10 = val_10.z;//m1                     
        val_40 = val_10.z;
        // 0x00B23890: STP s8, s9, [sp, #0x20]    | stack[1152921513309641488] = val_10.x;  stack[1152921513309641492] = val_10.y;  //  dest_result_addr=1152921513309641488 |  dest_result_addr=1152921513309641492
        // 0x00B23894: STR s10, [sp, #0x28]       | stack[1152921513309641496] = val_10.z;   //  dest_result_addr=1152921513309641496
        // 0x00B23898: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B2389C: CBNZ x20, #0xb238ac        | if (this.tr != null) goto label_26;     
        if(this.tr != null)
        {
            goto label_26;
        }
        // 0x00B238A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        // 0x00B238A4: LDP s8, s9, [sp, #0x20]    | S8 = val_10.x; S9 = val_10.y;            //  | 
        val_38 = val_38;
        val_39 = val_39;
        // 0x00B238A8: LDR s10, [sp, #0x28]       | S10 = val_10.z;                         
        val_40 = val_40;
        label_26:
        // 0x00B238AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B238B0: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B238B4: BL #0x26937d8              | X0 = this.tr.get_rotation();            
        UnityEngine.Quaternion val_11 = this.tr.rotation;
        // 0x00B238B8: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B238BC: STR s0, [sp, #0xc]         | stack[1152921513309641468] = val_11.x;   //  dest_result_addr=1152921513309641468
        // 0x00B238C0: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B238C4: MOV v12.16b, v1.16b        | V12 = val_11.y;//m1                     
        // 0x00B238C8: MOV v14.16b, v2.16b        | V14 = val_11.z;//m1                     
        // 0x00B238CC: MOV v13.16b, v3.16b        | V13 = val_11.w;//m1                     
        // 0x00B238D0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00B238D4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B238D8: TBZ w8, #0, #0xb238e8      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_28;
        // 0x00B238DC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B238E0: CBNZ w8, #0xb238e8         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_28;
        // 0x00B238E4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_28:
        // 0x00B238E8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B238EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B238F0: MOV v0.16b, v8.16b         | V0 = val_10.x;//m1                      
        // 0x00B238F4: MOV v1.16b, v9.16b         | V1 = val_10.y;//m1                      
        // 0x00B238F8: MOV v2.16b, v10.16b        | V2 = val_10.z;//m1                      
        // 0x00B238FC: BL #0x1b7e8c4              | X0 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_38, y = val_39, z = val_40});
        UnityEngine.Quaternion val_12 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_38, y = val_39, z = val_40});
        // 0x00B23900: LDR s11, [x19, #0x30]      | S11 = this.rotationSpeed; //P2          
        // 0x00B23904: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23908: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B2390C: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
        // 0x00B23910: MOV v9.16b, v1.16b         | V9 = val_12.y;//m1                      
        // 0x00B23914: MOV v10.16b, v2.16b        | V10 = val_12.z;//m1                     
        // 0x00B23918: MOV v15.16b, v3.16b        | V15 = val_12.w;//m1                     
        // 0x00B2391C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_13 = UnityEngine.Time.deltaTime;
        // 0x00B23920: FMUL s0, s11, s0           | S0 = (this.rotationSpeed * val_13);     
        val_13 = this.rotationSpeed * val_13;
        // 0x00B23924: STR s0, [sp]               | stack[1152921513309641456] = (this.rotationSpeed * val_13);  //  dest_result_addr=1152921513309641456
        // 0x00B23928: LDR s0, [sp, #0xc]         | S0 = val_11.x;                          
        // 0x00B2392C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23930: MOV v1.16b, v12.16b        | V1 = val_11.y;//m1                      
        // 0x00B23934: MOV v2.16b, v14.16b        | V2 = val_11.z;//m1                      
        // 0x00B23938: MOV v3.16b, v13.16b        | V3 = val_11.w;//m1                      
        // 0x00B2393C: MOV v4.16b, v8.16b         | V4 = val_12.x;//m1                      
        // 0x00B23940: MOV v5.16b, v9.16b         | V5 = val_12.y;//m1                      
        // 0x00B23944: MOV v6.16b, v10.16b        | V6 = val_12.z;//m1                      
        // 0x00B23948: MOV v7.16b, v15.16b        | V7 = val_12.w;//m1                      
        // 0x00B2394C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23950: BL #0x1b7e988              | X0 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_11.x, y = val_11.y, z = val_11.z, w = val_11.w}, b:  new UnityEngine.Quaternion() {x = val_12.x, y = val_12.y, z = val_12.z, w = val_12.w}, t:  val_13);
        UnityEngine.Quaternion val_14 = UnityEngine.Quaternion.Slerp(a:  new UnityEngine.Quaternion() {x = val_11.x, y = val_11.y, z = val_11.z, w = val_11.w}, b:  new UnityEngine.Quaternion() {x = val_12.x, y = val_12.y, z = val_12.z, w = val_12.w}, t:  val_13);
        // 0x00B23954: MOV v8.16b, v0.16b         | V8 = val_14.x;//m1                      
        // 0x00B23958: MOV v9.16b, v1.16b         | V9 = val_14.y;//m1                      
        // 0x00B2395C: MOV v10.16b, v2.16b        | V10 = val_14.z;//m1                     
        // 0x00B23960: MOV v11.16b, v3.16b        | V11 = val_14.w;//m1                     
        // 0x00B23964: CBNZ x20, #0xb2396c        | if (this.tr != null) goto label_29;     
        if(this.tr != null)
        {
            goto label_29;
        }
        // 0x00B23968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_29:
        // 0x00B2396C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23970: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23974: MOV v0.16b, v8.16b         | V0 = val_14.x;//m1                      
        // 0x00B23978: MOV v1.16b, v9.16b         | V1 = val_14.y;//m1                      
        // 0x00B2397C: MOV v2.16b, v10.16b        | V2 = val_14.z;//m1                      
        // 0x00B23980: MOV v3.16b, v11.16b        | V3 = val_14.w;//m1                      
        // 0x00B23984: BL #0x26938b0              | this.tr.set_rotation(value:  new UnityEngine.Quaternion() {x = val_14.x, y = val_14.y, z = val_14.z, w = val_14.w});
        this.tr.rotation = new UnityEngine.Quaternion() {x = val_14.x, y = val_14.y, z = val_14.z, w = val_14.w};
        // 0x00B23988: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B2398C: CBNZ x20, #0xb23994        | if (this.tr != null) goto label_30;     
        if(this.tr != null)
        {
            goto label_30;
        }
        // 0x00B23990: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.tr, ????);    
        label_30:
        // 0x00B23994: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23998: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B2399C: BL #0x2693798              | X0 = this.tr.get_eulerAngles();         
        UnityEngine.Vector3 val_15 = this.tr.eulerAngles;
        // 0x00B239A0: FMOV s0, wzr               | S0 = 0f;                                
        // 0x00B239A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B239A8: ADD x0, sp, #0x10          | X0 = (1152921513309641456 + 16) = 1152921513309641472 (0x1000000206BA1B00);
        // 0x00B239AC: MOV v2.16b, v0.16b         | V2 = 0;//m1                             
        // 0x00B239B0: STR wzr, [sp, #0x18]       | stack[1152921513309641480] = 0x0;        //  dest_result_addr=1152921513309641480
        // 0x00B239B4: STR xzr, [sp, #0x10]       | stack[1152921513309641472] = 0x0;        //  dest_result_addr=1152921513309641472
        // 0x00B239B8: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B239BC: CBNZ x20, #0xb239c4        | if (this.tr != null) goto label_31;     
        if(this.tr != null)
        {
            goto label_31;
        }
        // 0x00B239C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B00, ????);
        label_31:
        // 0x00B239C4: LDP s0, s1, [sp, #0x10]    | S0 = 0; S1 = 0;                          //  | 
        // 0x00B239C8: LDR s2, [sp, #0x18]        | S2 = 0;                                 
        // 0x00B239CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B239D0: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B239D4: BL #0x2693800              | this.tr.set_eulerAngles(value:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        this.tr.eulerAngles = new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f};
        // 0x00B239D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B239DC: MOV x0, x19                | X0 = 1152921513309653664 (0x1000000206BA4AA0);//ML01
        // 0x00B239E0: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_16 = this.transform;
        // 0x00B239E4: MOV x20, x0                | X20 = val_16;//m1                       
        // 0x00B239E8: CBNZ x20, #0xb239f0        | if (val_16 != null) goto label_32;      
        if(val_16 != null)
        {
            goto label_32;
        }
        // 0x00B239EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_16, ????);     
        label_32:
        // 0x00B239F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B239F4: MOV x0, x20                | X0 = val_16;//m1                        
        // 0x00B239F8: BL #0x2693ec0              | X0 = val_16.get_forward();              
        UnityEngine.Vector3 val_17 = val_16.forward;
        // 0x00B239FC: LDR s3, [x19, #0x2c]       | S3 = this.speed; //P2                   
        // 0x00B23A00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23A04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23A08: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, d:  this.speed);
        UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z}, d:  this.speed);
        // 0x00B23A0C: ADD x0, sp, #0x20          | X0 = (1152921513309641456 + 32) = 1152921513309641488 (0x1000000206BA1B10);
        // 0x00B23A10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23A14: MOV v8.16b, v0.16b         | V8 = val_18.x;//m1                      
        // 0x00B23A18: MOV v9.16b, v1.16b         | V9 = val_18.y;//m1                      
        // 0x00B23A1C: MOV v10.16b, v2.16b        | V10 = val_18.z;//m1                     
        // 0x00B23A20: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B23A24: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23A28: MOV v11.16b, v0.16b        | V11 = val_18.x;//m1                     
        // 0x00B23A2C: MOV v12.16b, v1.16b        | V12 = val_18.y;//m1                     
        val_37 = val_18.y;
        // 0x00B23A30: MOV v13.16b, v2.16b        | V13 = val_18.z;//m1                     
        // 0x00B23A34: CBNZ x20, #0xb23a3c        | if (this.tr != null) goto label_33;     
        if(this.tr != null)
        {
            goto label_33;
        }
        // 0x00B23A38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000206BA1B10, ????);
        label_33:
        // 0x00B23A3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23A40: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23A44: BL #0x2693ec0              | X0 = this.tr.get_forward();             
        UnityEngine.Vector3 val_19 = this.tr.forward;
        // 0x00B23A48: MOV v3.16b, v0.16b         | V3 = val_19.x;//m1                      
        // 0x00B23A4C: MOV v4.16b, v1.16b         | V4 = val_19.y;//m1                      
        // 0x00B23A50: MOV v5.16b, v2.16b         | V5 = val_19.z;//m1                      
        // 0x00B23A54: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23A58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23A5C: MOV v0.16b, v11.16b        | V0 = val_18.x;//m1                      
        // 0x00B23A60: MOV v1.16b, v12.16b        | V1 = val_18.y;//m1                      
        // 0x00B23A64: MOV v2.16b, v13.16b        | V2 = val_18.z;//m1                      
        // 0x00B23A68: BL #0x2699664              | X0 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_18.x, y = val_37, z = val_18.z}, rhs:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        float val_20 = UnityEngine.Vector3.Dot(lhs:  new UnityEngine.Vector3() {x = val_18.x, y = val_37, z = val_18.z}, rhs:  new UnityEngine.Vector3() {x = val_19.x, y = val_19.y, z = val_19.z});
        // 0x00B23A6C: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B23A70: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B23A74: MOV v11.16b, v0.16b        | V11 = val_20;//m1                       
        // 0x00B23A78: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B23A7C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B23A80: TBZ w8, #0, #0xb23a90      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_35;
        // 0x00B23A84: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B23A88: CBNZ w8, #0xb23a90         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_35;
        // 0x00B23A8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_35:
        // 0x00B23A90: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23A94: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23A98: MOV v0.16b, v11.16b        | V0 = val_20;//m1                        
        // 0x00B23A9C: BL #0x1a7dd00              | X0 = UnityEngine.Mathf.Clamp01(value:  val_20);
        float val_21 = UnityEngine.Mathf.Clamp01(value:  val_20);
        // 0x00B23AA0: MOV v3.16b, v0.16b         | V3 = val_21;//m1                        
        // 0x00B23AA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23AA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23AAC: MOV v0.16b, v8.16b         | V0 = val_18.x;//m1                      
        // 0x00B23AB0: MOV v1.16b, v9.16b         | V1 = val_18.y;//m1                      
        // 0x00B23AB4: MOV v2.16b, v10.16b        | V2 = val_18.z;//m1                      
        // 0x00B23AB8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, d:  val_21);
        UnityEngine.Vector3 val_22 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, d:  val_21);
        // 0x00B23ABC: ADRP x22, #0x35fe000       | X22 = 56614912 (0x35FE000);             
        // 0x00B23AC0: LDR x22, [x22, #0x810]     | X22 = 1152921504697475072;              
        // 0x00B23AC4: LDR x20, [x19, #0x48]      | X20 = this.navmeshController; //P2      
        // 0x00B23AC8: MOV v9.16b, v0.16b         | V9 = val_22.x;//m1                      
        // 0x00B23ACC: MOV v8.16b, v1.16b         | V8 = val_22.y;//m1                      
        val_32 = val_22.y;
        // 0x00B23AD0: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B23AD4: MOV v10.16b, v2.16b        | V10 = val_22.z;//m1                     
        val_33 = val_22.z;
        // 0x00B23AD8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B23ADC: TBZ w8, #0, #0xb23aec      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_37;
        // 0x00B23AE0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B23AE4: CBNZ w8, #0xb23aec         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
        // 0x00B23AE8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_37:
        // 0x00B23AEC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23AF0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B23AF4: MOV x1, x20                | X1 = this.navmeshController;//m1        
        // 0x00B23AF8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B23AFC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.navmeshController);
        bool val_23 = UnityEngine.Object.op_Inequality(x:  0, y:  this.navmeshController);
        // 0x00B23B00: AND w8, w0, #1             | W8 = (val_23 & 1);                      
        bool val_24 = val_23;
        // 0x00B23B04: TBNZ w8, #0, #0xb23be8     | if ((val_23 & 1) == true) goto label_43;
        if(val_24 == true)
        {
            goto label_43;
        }
        // 0x00B23B08: LDR x0, [x22]              | X0 = typeof(UnityEngine.Object);        
        // 0x00B23B0C: LDR x20, [x19, #0x40]      | X20 = this.controller; //P2             
        // 0x00B23B10: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B23B14: TBZ w8, #0, #0xb23b24      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_40;
        // 0x00B23B18: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B23B1C: CBNZ w8, #0xb23b24         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_40;
        // 0x00B23B20: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_40:
        // 0x00B23B24: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23B28: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B23B2C: MOV x1, x20                | X1 = this.controller;//m1               
        // 0x00B23B30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00B23B34: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.controller);
        bool val_25 = UnityEngine.Object.op_Inequality(x:  0, y:  this.controller);
        // 0x00B23B38: TBZ w0, #0, #0xb23b64      | if (val_25 == false) goto label_41;     
        if(val_25 == false)
        {
            goto label_41;
        }
        // 0x00B23B3C: LDR x19, [x19, #0x40]      | X19 = this.controller; //P2             
        val_30 = this.controller;
        // 0x00B23B40: CBNZ x19, #0xb23b48        | if (this.controller != null) goto label_42;
        if(val_30 != null)
        {
            goto label_42;
        }
        // 0x00B23B44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_25, ????);     
        label_42:
        // 0x00B23B48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23B4C: MOV x0, x19                | X0 = this.controller;//m1               
        // 0x00B23B50: MOV v0.16b, v9.16b         | V0 = val_22.x;//m1                      
        // 0x00B23B54: MOV v1.16b, v8.16b         | V1 = val_22.y;//m1                      
        // 0x00B23B58: MOV v2.16b, v10.16b        | V2 = val_22.z;//m1                      
        // 0x00B23B5C: BL #0x26f2da8              | X0 = this.controller.SimpleMove(speed:  new UnityEngine.Vector3() {x = val_22.x, y = val_32, z = val_33});
        bool val_26 = val_30.SimpleMove(speed:  new UnityEngine.Vector3() {x = val_22.x, y = val_32, z = val_33});
        // 0x00B23B60: B #0xb23be8                |  goto label_43;                         
        goto label_43;
        label_41:
        // 0x00B23B64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23B68: MOV x0, x19                | X0 = 1152921513309653664 (0x1000000206BA4AA0);//ML01
        // 0x00B23B6C: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_27 = this.transform;
        // 0x00B23B70: MOV x19, x0                | X19 = val_27;//m1                       
        val_30 = val_27;
        // 0x00B23B74: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23B7C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_28 = UnityEngine.Time.deltaTime;
        // 0x00B23B80: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B23B84: MOV v11.16b, v0.16b        | V11 = val_28;//m1                       
        // 0x00B23B88: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B23B8C: TBZ w8, #0, #0xb23b9c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_45;
        // 0x00B23B90: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B23B94: CBNZ w8, #0xb23b9c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_45;
        // 0x00B23B98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_45:
        // 0x00B23B9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23BA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23BA4: MOV v0.16b, v9.16b         | V0 = val_22.x;//m1                      
        // 0x00B23BA8: MOV v1.16b, v8.16b         | V1 = val_22.y;//m1                      
        // 0x00B23BAC: MOV v2.16b, v10.16b        | V2 = val_22.z;//m1                      
        // 0x00B23BB0: MOV v3.16b, v11.16b        | V3 = val_28;//m1                        
        // 0x00B23BB4: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_32, z = val_33}, d:  val_28);
        UnityEngine.Vector3 val_29 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_22.x, y = val_32, z = val_33}, d:  val_28);
        // 0x00B23BB8: MOV v8.16b, v0.16b         | V8 = val_29.x;//m1                      
        val_32 = val_29.x;
        // 0x00B23BBC: MOV v9.16b, v1.16b         | V9 = val_29.y;//m1                      
        // 0x00B23BC0: MOV v10.16b, v2.16b        | V10 = val_29.z;//m1                     
        val_33 = val_29.z;
        // 0x00B23BC4: CBNZ x19, #0xb23bcc        | if (val_27 != null) goto label_46;      
        if(val_30 != null)
        {
            goto label_46;
        }
        // 0x00B23BC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_46:
        // 0x00B23BCC: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B23BD0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B23BD4: MOV x0, x19                | X0 = val_27;//m1                        
        // 0x00B23BD8: MOV v0.16b, v8.16b         | V0 = val_29.x;//m1                      
        // 0x00B23BDC: MOV v1.16b, v9.16b         | V1 = val_29.y;//m1                      
        // 0x00B23BE0: MOV v2.16b, v10.16b        | V2 = val_29.z;//m1                      
        // 0x00B23BE4: BL #0x2694858              | val_27.Translate(translation:  new UnityEngine.Vector3() {x = val_32, y = val_29.y, z = val_33}, relativeTo:  0);
        val_30.Translate(translation:  new UnityEngine.Vector3() {x = val_32, y = val_29.y, z = val_33}, relativeTo:  0);
        label_43:
        // 0x00B23BE8: SUB sp, x29, #0x70         | SP = (1152921513309641648 - 112) = 1152921513309641536 (0x1000000206BA1B40);
        // 0x00B23BEC: LDP x29, x30, [sp, #0x70]  | X29 = ; X30 = ;                          //  | 
        // 0x00B23BF0: LDP x20, x19, [sp, #0x60]  | X20 = ; X19 = ;                          //  | 
        // 0x00B23BF4: LDP x22, x21, [sp, #0x50]  | X22 = ; X21 = ;                          //  | 
        // 0x00B23BF8: LDP x24, x23, [sp, #0x40]  | X24 = ; X23 = ;                          //  | 
        // 0x00B23BFC: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B23C00: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B23C04: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B23C08: LDP d15, d14, [sp], #0x80  | D15 = ; D14 = ;                          //  | 
        // 0x00B23C0C: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B23C10 (11680784), len: 1068  VirtAddr: 0x00B23C10 RVA: 0x00B23C10 token: 100682737 methodIndex: 24730 delegateWrapperIndex: 0 methodInvoker: 0
    public void OnDrawGizmos()
    {
        //
        // Disasemble & Code
        //  | 
        var val_13;
        // 0x00B23C10: STP d15, d14, [sp, #-0x70]! | stack[1152921513309999312] = ???;  stack[1152921513309999320] = ???;  //  dest_result_addr=1152921513309999312 |  dest_result_addr=1152921513309999320
        // 0x00B23C14: STP d13, d12, [sp, #0x10]  | stack[1152921513309999328] = ???;  stack[1152921513309999336] = ???;  //  dest_result_addr=1152921513309999328 |  dest_result_addr=1152921513309999336
        // 0x00B23C18: STP d11, d10, [sp, #0x20]  | stack[1152921513309999344] = ???;  stack[1152921513309999352] = ???;  //  dest_result_addr=1152921513309999344 |  dest_result_addr=1152921513309999352
        // 0x00B23C1C: STP d9, d8, [sp, #0x30]    | stack[1152921513309999360] = ???;  stack[1152921513309999368] = ???;  //  dest_result_addr=1152921513309999360 |  dest_result_addr=1152921513309999368
        // 0x00B23C20: STP x22, x21, [sp, #0x40]  | stack[1152921513309999376] = ???;  stack[1152921513309999384] = ???;  //  dest_result_addr=1152921513309999376 |  dest_result_addr=1152921513309999384
        // 0x00B23C24: STP x20, x19, [sp, #0x50]  | stack[1152921513309999392] = ???;  stack[1152921513309999400] = ???;  //  dest_result_addr=1152921513309999392 |  dest_result_addr=1152921513309999400
        // 0x00B23C28: STP x29, x30, [sp, #0x60]  | stack[1152921513309999408] = ???;  stack[1152921513309999416] = ???;  //  dest_result_addr=1152921513309999408 |  dest_result_addr=1152921513309999416
        // 0x00B23C2C: ADD x29, sp, #0x60         | X29 = (1152921513309999312 + 96) = 1152921513309999408 (0x1000000206BF9130);
        // 0x00B23C30: SUB sp, sp, #0x50          | SP = (1152921513309999312 - 80) = 1152921513309999232 (0x1000000206BF9080);
        // 0x00B23C34: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B23C38: LDRB w8, [x20, #0x72d]     | W8 = (bool)static_value_0373372D;       
        // 0x00B23C3C: MOV x19, x0                | X19 = 1152921513310011424 (0x1000000206BFC020);//ML01
        val_13 = this;
        // 0x00B23C40: TBNZ w8, #0, #0xb23c5c     | if (static_value_0373372D == true) goto label_0;
        // 0x00B23C44: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
        // 0x00B23C48: LDR x8, [x8, #0x20]        | X8 = 0x2B8AAE8;                         
        // 0x00B23C4C: LDR w0, [x8]               | W0 = 0x178;                             
        // 0x00B23C50: BL #0x2782188              | X0 = sub_2782188( ?? 0x178, ????);      
        // 0x00B23C54: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B23C58: STRB w8, [x20, #0x72d]     | static_value_0373372D = true;            //  dest_result_addr=57882413
        label_0:
        // 0x00B23C5C: LDRB w8, [x19, #0x34]      | W8 = this.drawGizmos; //P2              
        // 0x00B23C60: CBZ w8, #0xb24018          | if (this.drawGizmos == false) goto label_4;
        if(this.drawGizmos == false)
        {
            goto label_4;
        }
        // 0x00B23C64: LDR x20, [x19, #0x60]      | X20 = this.path; //P2                   
        // 0x00B23C68: CBZ x20, #0xb24018         | if (this.path == null) goto label_4;    
        if(this.path == null)
        {
            goto label_4;
        }
        // 0x00B23C6C: LDR w9, [x19, #0x5c]       | W9 = this.pathIndex; //P2               
        // 0x00B23C70: LDR w8, [x20, #0x18]       | W8 = this.path.Length; //P2             
        // 0x00B23C74: CMP w9, w8                 | STATE = COMPARE(this.pathIndex, this.path.Length)
        // 0x00B23C78: B.GE #0xb24018             | if (this.pathIndex >= this.path.Length) goto label_4;
        if(this.pathIndex >= this.path.Length)
        {
            goto label_4;
        }
        // 0x00B23C7C: TBNZ w9, #0x1f, #0xb24018  | if ((this.pathIndex & 0x80000000) != 0) goto label_4;
        if((this.pathIndex & 2147483648) != 0)
        {
            goto label_4;
        }
        // 0x00B23C80: SXTW x21, w9               | X21 = (long)(int)(this.pathIndex);      
        // 0x00B23C84: CMP w21, w8                | STATE = COMPARE((long)(int)(this.pathIndex), this.path.Length)
        // 0x00B23C88: B.LO #0xb23c98             | if ((long)this.pathIndex < this.path.Length) goto label_5;
        if((long)this.pathIndex < this.path.Length)
        {
            goto label_5;
        }
        // 0x00B23C8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x178, ????);      
        // 0x00B23C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23C94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x178, ????);      
        label_5:
        // 0x00B23C98: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
        var val_13 = 12;
        // 0x00B23C9C: MADD x8, x21, x8, x20      | X8 = ((long)(int)(this.pathIndex) * 12) + this.path;
        val_13 = this.path + ((long)this.pathIndex * val_13);
        // 0x00B23CA0: LDR s0, [x8, #0x20]        | S0 = ((long)(int)(this.pathIndex) * 12) + this.path + 32;
        // 0x00B23CA4: LDR x20, [x19, #0x50]      | X20 = this.tr; //P2                     
        // 0x00B23CA8: STR s0, [sp, #0x2c]        | stack[1152921513309999276] = ((long)(int)(this.pathIndex) * 12) + this.path + 32;  //  dest_result_addr=1152921513309999276
        // 0x00B23CAC: LDR s0, [x8, #0x28]        | S0 = ((long)(int)(this.pathIndex) * 12) + this.path + 40;
        // 0x00B23CB0: STR s0, [sp, #0x30]        | stack[1152921513309999280] = ((long)(int)(this.pathIndex) * 12) + this.path + 40;  //  dest_result_addr=1152921513309999280
        // 0x00B23CB4: CBNZ x20, #0xb23cbc        | if (this.tr != null) goto label_6;      
        if(this.tr != null)
        {
            goto label_6;
        }
        // 0x00B23CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x178, ????);      
        label_6:
        // 0x00B23CBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23CC0: MOV x0, x20                | X0 = this.tr;//m1                       
        // 0x00B23CC4: BL #0x2693510              | X0 = this.tr.get_position();            
        UnityEngine.Vector3 val_1 = this.tr.position;
        // 0x00B23CC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23CCC: MOV x0, x19                | X0 = 1152921513310011424 (0x1000000206BFC020);//ML01
        // 0x00B23CD0: STR s1, [sp, #0x28]        | stack[1152921513309999272] = val_1.y;    //  dest_result_addr=1152921513309999272
        // 0x00B23CD4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_2 = this.transform;
        // 0x00B23CD8: MOV x20, x0                | X20 = val_2;//m1                        
        // 0x00B23CDC: CBNZ x20, #0xb23ce4        | if (val_2 != null) goto label_7;        
        if(val_2 != null)
        {
            goto label_7;
        }
        // 0x00B23CE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        label_7:
        // 0x00B23CE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23CE8: MOV x0, x20                | X0 = val_2;//m1                         
        // 0x00B23CEC: BL #0x2693510              | X0 = val_2.get_position();              
        UnityEngine.Vector3 val_3 = val_2.position;
        // 0x00B23CF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23CF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23CF8: MOV v8.16b, v0.16b         | V8 = val_3.x;//m1                       
        // 0x00B23CFC: MOV v9.16b, v1.16b         | V9 = val_3.y;//m1                       
        // 0x00B23D00: MOV v11.16b, v2.16b        | V11 = val_3.z;//m1                      
        // 0x00B23D04: BL #0x20d3bd0              | X0 = UnityEngine.Color.get_blue();      
        UnityEngine.Color val_4 = UnityEngine.Color.blue;
        // 0x00B23D08: ADRP x20, #0x35f8000       | X20 = 56590336 (0x35F8000);             
        // 0x00B23D0C: LDR x20, [x20, #0x130]     | X20 = 1152921504692469760;              
        // 0x00B23D10: MOV v12.16b, v0.16b        | V12 = val_4.r;//m1                      
        // 0x00B23D14: MOV v10.16b, v1.16b        | V10 = val_4.g;//m1                      
        // 0x00B23D18: MOV v13.16b, v2.16b        | V13 = val_4.b;//m1                      
        // 0x00B23D1C: LDR x0, [x20]              | X0 = typeof(UnityEngine.Debug);         
        // 0x00B23D20: MOV v14.16b, v3.16b        | V14 = val_4.a;//m1                      
        // 0x00B23D24: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B23D28: TBZ w8, #0, #0xb23d38      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_9;
        // 0x00B23D2C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B23D30: CBNZ w8, #0xb23d38         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
        // 0x00B23D34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_9:
        // 0x00B23D38: STP s13, s14, [sp, #8]     | stack[1152921513309999240] = val_4.b;  stack[1152921513309999244] = val_4.a;  //  dest_result_addr=1152921513309999240 |  dest_result_addr=1152921513309999244
        // 0x00B23D3C: STP s12, s10, [sp]         | stack[1152921513309999232] = val_4.r;  stack[1152921513309999236] = val_4.g;  //  dest_result_addr=1152921513309999232 |  dest_result_addr=1152921513309999236
        // 0x00B23D40: LDP s4, s3, [sp, #0x28]    | S4 = val_1.y; S3 = ((long)(int)(this.pathIndex) * 12) + this.path + 32; //  | 
        // 0x00B23D44: LDR s5, [sp, #0x30]        | S5 = ((long)(int)(this.pathIndex) * 12) + this.path + 40;
        // 0x00B23D48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23D4C: MOV v0.16b, v8.16b         | V0 = val_3.x;//m1                       
        // 0x00B23D50: MOV v1.16b, v9.16b         | V1 = val_3.y;//m1                       
        // 0x00B23D54: MOV v2.16b, v11.16b        | V2 = val_3.z;//m1                       
        // 0x00B23D58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23D5C: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, end:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, color:  new UnityEngine.Color() {r = val_4.r, g = val_4.b});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_3.x, y = val_3.y, z = val_3.z}, end:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, color:  new UnityEngine.Color() {r = val_4.r, g = val_4.b});
        // 0x00B23D60: LDR s0, [x19, #0x24]       | S0 = this.pickNextWaypointDistance; //P2 
        // 0x00B23D64: LDR w21, [x19, #0x5c]      | W21 = this.pathIndex; //P2              
        // 0x00B23D68: LDR x22, [x19, #0x60]      | X22 = this.path; //P2                   
        // 0x00B23D6C: STR s0, [sp, #0x24]        | stack[1152921513309999268] = this.pickNextWaypointDistance;  //  dest_result_addr=1152921513309999268
        // 0x00B23D70: CBNZ x22, #0xb23d78        | if (this.path != null) goto label_10;   
        if(this.path != null)
        {
            goto label_10;
        }
        // 0x00B23D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_10:
        // 0x00B23D78: LDR w8, [x22, #0x18]       | W8 = this.path.Length; //P2             
        int val_14 = this.path.Length;
        // 0x00B23D7C: SUB w8, w8, #1             | W8 = (this.path.Length - 1);            
        val_14 = val_14 - 1;
        // 0x00B23D80: CMP w21, w8                | STATE = COMPARE(this.pathIndex, (this.path.Length - 1))
        // 0x00B23D84: B.NE #0xb23d98             | if (this.pathIndex != this.path.Length) goto label_11;
        if(this.pathIndex != val_14)
        {
            goto label_11;
        }
        // 0x00B23D88: LDR s0, [x19, #0x28]       | S0 = this.targetReached; //P2           
        // 0x00B23D8C: LDR s1, [sp, #0x24]        | S1 = this.pickNextWaypointDistance;     
        float val_15 = this.pickNextWaypointDistance;
        // 0x00B23D90: FMUL s1, s1, s0            | S1 = (this.pickNextWaypointDistance * this.targetReached);
        val_15 = val_15 * this.targetReached;
        // 0x00B23D94: STR s1, [sp, #0x24]        | stack[1152921513309999268] = (this.pickNextWaypointDistance * this.targetReached);  //  dest_result_addr=1152921513309999268
        label_11:
        // 0x00B23D98: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B23D9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23DA0: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x00B23DA4: ADD x0, sp, #0x40          | X0 = (1152921513309999232 + 64) = 1152921513309999296 (0x1000000206BF90C0);
        // 0x00B23DA8: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
        // 0x00B23DAC: STR wzr, [sp, #0x48]       | stack[1152921513309999304] = 0x0;        //  dest_result_addr=1152921513309999304
        // 0x00B23DB0: STR xzr, [sp, #0x40]       | stack[1152921513309999296] = 0x0;        //  dest_result_addr=1152921513309999296
        // 0x00B23DB4: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B23DB8: ADRP x19, #0x3673000       | X19 = 57094144 (0x3673000);             
        // 0x00B23DBC: LDR x19, [x19, #0x488]     | X19 = 1152921504695078912;              
        val_13 = 1152921504695078912;
        // 0x00B23DC0: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B23DC4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B23DC8: TBZ w8, #0, #0xb23dd8      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B23DCC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B23DD0: CBNZ w8, #0xb23dd8         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B23DD4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_13:
        // 0x00B23DD8: LDP s1, s2, [sp, #0x40]    | S1 = 0; S2 = 0;                          //  | 
        // 0x00B23DDC: LDR s3, [sp, #0x48]        | S3 = 0;                                 
        // 0x00B23DE0: LDR s0, [sp, #0x24]        | S0 = (this.pickNextWaypointDistance * this.targetReached);
        // 0x00B23DE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23DE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23DEC: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  this.pickNextWaypointDistance, a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Multiply(d:  val_15, a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B23DF0: MOV v3.16b, v0.16b         | V3 = val_5.x;//m1                       
        // 0x00B23DF4: MOV v4.16b, v1.16b         | V4 = val_5.y;//m1                       
        // 0x00B23DF8: MOV v5.16b, v2.16b         | V5 = val_5.z;//m1                       
        // 0x00B23DFC: LDP s1, s0, [sp, #0x28]    | S1 = val_1.y; S0 = ((long)(int)(this.pathIndex) * 12) + this.path + 32; //  | 
        // 0x00B23E00: LDR s2, [sp, #0x30]        | S2 = ((long)(int)(this.pathIndex) * 12) + this.path + 40;
        // 0x00B23E04: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23E08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23E0C: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
        UnityEngine.Vector3 val_6 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_5.x, y = val_5.y, z = val_5.z});
        // 0x00B23E10: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B23E14: MOV v9.16b, v0.16b         | V9 = val_6.x;//m1                       
        // 0x00B23E18: LDR s0, [x8, #0x4b4]       | S0 = 0.1;                               
        // 0x00B23E1C: ADRP x9, #0x2a92000        | X9 = 44638208 (0x2A92000);              
        // 0x00B23E20: MOV v8.16b, v1.16b         | V8 = val_6.y;//m1                       
        // 0x00B23E24: MOV v12.16b, v2.16b        | V12 = val_6.z;//m1                      
        // 0x00B23E28: STR s0, [sp, #0x20]        | stack[1152921513309999264] = 0x3DCCCCCD;  //  dest_result_addr=1152921513309999264
        // 0x00B23E2C: LDR d0, [x9, #0xb00]       | D0 = 6.28318530717959;                  
        // 0x00B23E30: FMOV d10, xzr              | D10 = 0f;                               
        // 0x00B23E34: FMOV s15, wzr              | S15 = 0f;                               
        float val_17 = 0f;
        // 0x00B23E38: STR d0, [sp, #0x18]        | stack[1152921513309999256] = 0x401921FB54442D18;  //  dest_result_addr=1152921513309999256
        label_18:
        // 0x00B23E3C: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x00B23E40: STP s9, s8, [sp, #0x34]    | stack[1152921513309999284] = val_6.x;  stack[1152921513309999288] = val_6.y;  //  dest_result_addr=1152921513309999284 |  dest_result_addr=1152921513309999288
        // 0x00B23E44: STR s12, [sp, #0x3c]       | stack[1152921513309999292] = val_6.z;    //  dest_result_addr=1152921513309999292
        // 0x00B23E48: BL #0x980ad0               | X0 = sub_980AD0( ?? 0x0, ????);         
        // 0x00B23E4C: MOV v11.16b, v0.16b        | V11 = 0;//m1                            
        // 0x00B23E50: MOV v0.16b, v10.16b        | V0 = 0;//m1                             
        // 0x00B23E54: BL #0x980640               | X0 = sub_980640( ?? 0x0, ????);         
        // 0x00B23E58: LDR s3, [sp, #0x24]        | S3 = (this.pickNextWaypointDistance * this.targetReached);
        // 0x00B23E5C: FCVT s1, d11               | S1 = (float)0);                         
        // 0x00B23E60: FCVT s2, d0                | S2 = (float)0);                         
        float val_16 = (float)0;
        // 0x00B23E64: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23E68: FMUL s0, s3, s1            | S0 = ((this.pickNextWaypointDistance * this.targetReached) * 0);
        float val_7 = val_15 * (float)0;
        // 0x00B23E6C: FMUL s2, s3, s2            | S2 = ((this.pickNextWaypointDistance * this.targetReached) * 0);
        val_16 = val_15 * val_16;
        // 0x00B23E70: ADD x0, sp, #0x40          | X0 = (1152921513309999232 + 64) = 1152921513309999296 (0x1000000206BF90C0);
        // 0x00B23E74: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B23E78: STR wzr, [sp, #0x48]       | stack[1152921513309999304] = 0x0;        //  dest_result_addr=1152921513309999304
        // 0x00B23E7C: STR xzr, [sp, #0x40]       | stack[1152921513309999296] = 0x0;        //  dest_result_addr=1152921513309999296
        // 0x00B23E80: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B23E84: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B23E88: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B23E8C: TBZ w8, #0, #0xb23e9c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_15;
        // 0x00B23E90: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B23E94: CBNZ w8, #0xb23e9c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
        // 0x00B23E98: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_15:
        // 0x00B23E9C: LDP s3, s4, [sp, #0x40]    | S3 = 0; S4 = 0;                          //  | 
        // 0x00B23EA0: LDR s5, [sp, #0x48]        | S5 = 0;                                 
        // 0x00B23EA4: LDP s1, s0, [sp, #0x28]    | S1 = val_1.y; S0 = ((long)(int)(this.pathIndex) * 12) + this.path + 32; //  | 
        // 0x00B23EA8: LDR s2, [sp, #0x30]        | S2 = ((long)(int)(this.pathIndex) * 12) + this.path + 40;
        // 0x00B23EAC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23EB0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23EB4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B23EB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23EBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23EC0: MOV v9.16b, v0.16b         | V9 = val_8.x;//m1                       
        // 0x00B23EC4: MOV v8.16b, v1.16b         | V8 = val_8.y;//m1                       
        // 0x00B23EC8: MOV v12.16b, v2.16b        | V12 = val_8.z;//m1                      
        // 0x00B23ECC: BL #0x20d3c0c              | X0 = UnityEngine.Color.get_yellow();    
        UnityEngine.Color val_9 = UnityEngine.Color.yellow;
        // 0x00B23ED0: LDR x0, [x20]              | X0 = typeof(UnityEngine.Debug);         
        // 0x00B23ED4: MOV v10.16b, v0.16b        | V10 = val_9.r;//m1                      
        // 0x00B23ED8: MOV v11.16b, v1.16b        | V11 = val_9.g;//m1                      
        // 0x00B23EDC: MOV v13.16b, v2.16b        | V13 = val_9.b;//m1                      
        // 0x00B23EE0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B23EE4: MOV v14.16b, v3.16b        | V14 = val_9.a;//m1                      
        // 0x00B23EE8: TBZ w8, #0, #0xb23ef8      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_17;
        // 0x00B23EEC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B23EF0: CBNZ w8, #0xb23ef8         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
        // 0x00B23EF4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_17:
        // 0x00B23EF8: STP s13, s14, [sp, #8]     | stack[1152921513309999240] = val_9.b;  stack[1152921513309999244] = val_9.a;  //  dest_result_addr=1152921513309999240 |  dest_result_addr=1152921513309999244
        // 0x00B23EFC: STP s10, s11, [sp]         | stack[1152921513309999232] = val_9.r;  stack[1152921513309999236] = val_9.g;  //  dest_result_addr=1152921513309999232 |  dest_result_addr=1152921513309999236
        // 0x00B23F00: LDP s0, s1, [sp, #0x34]    | S0 = val_6.x; S1 = val_6.y;              //  | 
        // 0x00B23F04: LDR s2, [sp, #0x3c]        | S2 = val_6.z;                           
        // 0x00B23F08: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23F0C: MOV v3.16b, v9.16b         | V3 = val_8.x;//m1                       
        // 0x00B23F10: MOV v4.16b, v8.16b         | V4 = val_8.y;//m1                       
        // 0x00B23F14: MOV v5.16b, v12.16b        | V5 = val_8.z;//m1                       
        // 0x00B23F18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23F1C: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, end:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, color:  new UnityEngine.Color() {r = val_9.r, g = val_9.b, a = 3.370281E+12f});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z}, end:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, color:  new UnityEngine.Color() {r = val_9.r, g = val_9.b, a = 3.370281E+12f});
        // 0x00B23F20: LDR s0, [sp, #0x20]        | S0 = 0.1;                               
        // 0x00B23F24: FADD s15, s15, s0          | S15 = (0f + 0.1f);                      
        val_17 = val_17 + 0.1f;
        // 0x00B23F28: LDR d0, [sp, #0x18]        | D0 = 6.28318530717959;                  
        // 0x00B23F2C: FCVT d10, s15              | D10 = (double)(0f + 0.1f));             
        // 0x00B23F30: FCMP d10, d0               | STATE = COMPARE((0f + 0.1f), 3370280550400)
        // 0x00B23F34: B.MI #0xb23e3c             | if ((double)0f = 0f + 0.1f < 0) goto label_18;
        if((double)val_17 < 0)
        {
            goto label_18;
        }
        // 0x00B23F38: FMOV s1, wzr               | S1 = 0f;                                
        // 0x00B23F3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23F40: FMOV s0, #1.00000000       | S0 = 1;                                 
        // 0x00B23F44: ADD x0, sp, #0x40          | X0 = (1152921513309999232 + 64) = 1152921513309999296 (0x1000000206BF90C0);
        // 0x00B23F48: MOV v2.16b, v1.16b         | V2 = 0;//m1                             
        // 0x00B23F4C: STP s12, s8, [sp, #0x38]   | stack[1152921513309999288] = val_8.z;  stack[1152921513309999292] = val_8.y;  //  dest_result_addr=1152921513309999288 |  dest_result_addr=1152921513309999292
        // 0x00B23F50: MOV v15.16b, v9.16b        | V15 = val_8.x;//m1                      
        // 0x00B23F54: STR wzr, [sp, #0x48]       | stack[1152921513309999304] = 0x0;        //  dest_result_addr=1152921513309999304
        // 0x00B23F58: STR xzr, [sp, #0x40]       | stack[1152921513309999296] = 0x0;        //  dest_result_addr=1152921513309999296
        // 0x00B23F5C: BL #0x26949e0              | X0 = label_UnityEngine_Transform_Translate_GL026949E0();
        // 0x00B23F60: LDR x0, [x19]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B23F64: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B23F68: TBZ w8, #0, #0xb23f78      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_20;
        // 0x00B23F6C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B23F70: CBNZ w8, #0xb23f78         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_20;
        // 0x00B23F74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_20:
        // 0x00B23F78: LDP s1, s2, [sp, #0x40]    | S1 = 0; S2 = 0;                          //  | 
        // 0x00B23F7C: LDR s3, [sp, #0x48]        | S3 = 0;                                 
        // 0x00B23F80: LDR s0, [sp, #0x24]        | S0 = (this.pickNextWaypointDistance * this.targetReached);
        // 0x00B23F84: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23F88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23F8C: BL #0x2699650              | X0 = UnityEngine.Vector3.op_Multiply(d:  this.pickNextWaypointDistance, a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        UnityEngine.Vector3 val_10 = UnityEngine.Vector3.op_Multiply(d:  val_15, a:  new UnityEngine.Vector3() {x = 0f, y = 0f, z = 0f});
        // 0x00B23F90: MOV v3.16b, v0.16b         | V3 = val_10.x;//m1                      
        // 0x00B23F94: MOV v4.16b, v1.16b         | V4 = val_10.y;//m1                      
        // 0x00B23F98: MOV v5.16b, v2.16b         | V5 = val_10.z;//m1                      
        // 0x00B23F9C: LDP s1, s0, [sp, #0x28]    | S1 = val_1.y; S0 = ((long)(int)(this.pathIndex) * 12) + this.path + 32; //  | 
        // 0x00B23FA0: LDR s2, [sp, #0x30]        | S2 = ((long)(int)(this.pathIndex) * 12) + this.path + 40;
        // 0x00B23FA4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23FAC: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = ((long)(int)(this.pathIndex) * 12) + this.path + 32, y = val_1.y, z = ((long)(int)(this.pathIndex) * 12) + this.path + 40}, b:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z});
        // 0x00B23FB0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B23FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B23FB8: MOV v8.16b, v0.16b         | V8 = val_11.x;//m1                      
        // 0x00B23FBC: MOV v9.16b, v1.16b         | V9 = val_11.y;//m1                      
        // 0x00B23FC0: MOV v10.16b, v2.16b        | V10 = val_11.z;//m1                     
        // 0x00B23FC4: BL #0x20d3c0c              | X0 = UnityEngine.Color.get_yellow();    
        UnityEngine.Color val_12 = UnityEngine.Color.yellow;
        // 0x00B23FC8: LDR x0, [x20]              | X0 = typeof(UnityEngine.Debug);         
        // 0x00B23FCC: MOV v11.16b, v0.16b        | V11 = val_12.r;//m1                     
        // 0x00B23FD0: MOV v12.16b, v1.16b        | V12 = val_12.g;//m1                     
        // 0x00B23FD4: MOV v13.16b, v2.16b        | V13 = val_12.b;//m1                     
        // 0x00B23FD8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B23FDC: MOV v14.16b, v3.16b        | V14 = val_12.a;//m1                     
        // 0x00B23FE0: TBZ w8, #0, #0xb23ff0      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_22;
        // 0x00B23FE4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B23FE8: CBNZ w8, #0xb23ff0         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_22;
        // 0x00B23FEC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_22:
        // 0x00B23FF0: STP s13, s14, [sp, #8]     | stack[1152921513309999240] = val_12.b;  stack[1152921513309999244] = val_12.a;  //  dest_result_addr=1152921513309999240 |  dest_result_addr=1152921513309999244
        // 0x00B23FF4: STP s11, s12, [sp]         | stack[1152921513309999232] = val_12.r;  stack[1152921513309999236] = val_12.g;  //  dest_result_addr=1152921513309999232 |  dest_result_addr=1152921513309999236
        // 0x00B23FF8: LDP s2, s1, [sp, #0x38]    | S2 = val_8.z; S1 = val_8.y;              //  | 
        // 0x00B23FFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B24000: MOV v0.16b, v15.16b        | V0 = val_8.x;//m1                       
        // 0x00B24004: MOV v3.16b, v8.16b         | V3 = val_11.x;//m1                      
        // 0x00B24008: MOV v4.16b, v9.16b         | V4 = val_11.y;//m1                      
        // 0x00B2400C: MOV v5.16b, v10.16b        | V5 = val_11.z;//m1                      
        // 0x00B24010: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B24014: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, end:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, color:  new UnityEngine.Color() {r = val_12.r, g = val_12.b, a = 3.370281E+12f});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, end:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z}, color:  new UnityEngine.Color() {r = val_12.r, g = val_12.b, a = 3.370281E+12f});
        label_4:
        // 0x00B24018: SUB sp, x29, #0x60         | SP = (1152921513309999408 - 96) = 1152921513309999312 (0x1000000206BF90D0);
        // 0x00B2401C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B24020: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B24024: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B24028: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B2402C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B24030: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B24034: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00B24038: RET                        |  return;                                
        return;
    
    }

}
