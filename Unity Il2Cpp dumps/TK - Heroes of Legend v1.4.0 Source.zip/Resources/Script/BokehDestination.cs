using UnityEngine;
[Serializable]
public enum BokehDestination
{
    // Fields
    Background = 1
    ,Foreground = 2
    ,BackgroundAndForeground = 3
    

}
