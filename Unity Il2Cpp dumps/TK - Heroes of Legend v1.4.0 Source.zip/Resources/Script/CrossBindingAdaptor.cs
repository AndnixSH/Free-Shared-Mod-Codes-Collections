using UnityEngine;

namespace ILRuntime.Runtime.Enviorment
{
    public abstract class CrossBindingAdaptor : IType
    {
        // Fields
        private ILRuntime.CLR.TypeSystem.IType type; //  0x00000010
        
        // Properties
        public abstract System.Type BaseCLRType { get; }
        public virtual System.Type[] BaseCLRTypes { get; }
        public abstract System.Type AdaptorType { get; }
        internal ILRuntime.CLR.TypeSystem.IType RuntimeType { get; set; }
        public bool IsGenericInstance { get; }
        public System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] GenericArguments { get; }
        public System.Type TypeForCLR { get; }
        public ILRuntime.CLR.TypeSystem.IType ByRefType { get; }
        public ILRuntime.CLR.TypeSystem.IType ArrayType { get; }
        public string FullName { get; }
        public string Name { get; }
        public bool IsValueType { get; }
        public bool IsPrimitive { get; }
        public bool IsEnum { get; }
        public bool IsDelegate { get; }
        public ILRuntime.Runtime.Enviorment.AppDomain AppDomain { get; }
        public System.Type ReflectionType { get; }
        public ILRuntime.CLR.TypeSystem.IType BaseType { get; }
        public ILRuntime.CLR.TypeSystem.IType[] Implements { get; }
        public bool HasGenericParameter { get; }
        public bool IsGenericParameter { get; }
        public bool IsArray { get; }
        public bool IsByRef { get; }
        public bool IsInterface { get; }
        public ILRuntime.CLR.TypeSystem.IType ElementType { get; }
        public int ArrayRank { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x028EF918 (42924312), len: 8  VirtAddr: 0x028EF918 RVA: 0x028EF918 token: 100680287 methodIndex: 29574 delegateWrapperIndex: 0 methodInvoker: 0
        protected CrossBindingAdaptor()
        {
            //
            // Disasemble & Code
            // 0x028EF918: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EF91C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        public abstract System.Type get_BaseCLRType(); // 0
        //
        // Offset in libil2cpp.so: 0x028EF920 (42924320), len: 8  VirtAddr: 0x028EF920 RVA: 0x028EF920 token: 100680289 methodIndex: 29575 delegateWrapperIndex: 0 methodInvoker: 0
        public virtual System.Type[] get_BaseCLRTypes()
        {
            //
            // Disasemble & Code
            // 0x028EF920: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x028EF924: RET                        |  return (System.Type[])null;            
            return (System.Type[])0;
            //  |  // // {name=val_0, type=System.Type[], size=8, nGRN=0 }
        
        }
        public abstract System.Type get_AdaptorType(); // 0
        public abstract object CreateCLRInstance(ILRuntime.Runtime.Enviorment.AppDomain appdomain, ILRuntime.Runtime.Intepreter.ILTypeInstance instance); // 0
        //
        // Offset in libil2cpp.so: 0x028EF928 (42924328), len: 8  VirtAddr: 0x028EF928 RVA: 0x028EF928 token: 100680292 methodIndex: 29576 delegateWrapperIndex: 0 methodInvoker: 0
        internal ILRuntime.CLR.TypeSystem.IType get_RuntimeType()
        {
            //
            // Disasemble & Code
            // 0x028EF928: LDR x0, [x0, #0x10]        | X0 = this.type; //P2                    
            // 0x028EF92C: RET                        |  return (ILRuntime.CLR.TypeSystem.IType)this.type;
            return this.type;
            //  |  // // {name=val_0, type=ILRuntime.CLR.TypeSystem.IType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028E878C (42895244), len: 8  VirtAddr: 0x028E878C RVA: 0x028E878C token: 100680293 methodIndex: 29577 delegateWrapperIndex: 0 methodInvoker: 0
        internal void set_RuntimeType(ILRuntime.CLR.TypeSystem.IType value)
        {
            //
            // Disasemble & Code
            // 0x028E878C: STR x1, [x0, #0x10]        | this.type = value;                       //  dest_result_addr=1152921512892854304
            this.type = value;
            // 0x028E8790: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x028EF930 (42924336), len: 220  VirtAddr: 0x028EF930 RVA: 0x028EF930 token: 100680294 methodIndex: 29578 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetMethod(string name, int paramCount, bool declaredOnly = False)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EF930: STP x24, x23, [sp, #-0x40]! | stack[1152921512892966512] = ???;  stack[1152921512892966520] = ???;  //  dest_result_addr=1152921512892966512 |  dest_result_addr=1152921512892966520
            // 0x028EF934: STP x22, x21, [sp, #0x10]  | stack[1152921512892966528] = ???;  stack[1152921512892966536] = ???;  //  dest_result_addr=1152921512892966528 |  dest_result_addr=1152921512892966536
            // 0x028EF938: STP x20, x19, [sp, #0x20]  | stack[1152921512892966544] = ???;  stack[1152921512892966552] = ???;  //  dest_result_addr=1152921512892966544 |  dest_result_addr=1152921512892966552
            // 0x028EF93C: STP x29, x30, [sp, #0x30]  | stack[1152921512892966560] = ???;  stack[1152921512892966568] = ???;  //  dest_result_addr=1152921512892966560 |  dest_result_addr=1152921512892966568
            // 0x028EF940: ADD x29, sp, #0x30         | X29 = (1152921512892966512 + 48) = 1152921512892966560 (0x10000001EDE426A0);
            // 0x028EF944: ADRP x23, #0x37b8000       | X23 = 58425344 (0x37B8000);             
            // 0x028EF948: LDRB w8, [x23, #0xa0d]     | W8 = (bool)static_value_037B8A0D;       
            // 0x028EF94C: MOV w20, w3                | W20 = declaredOnly;//m1                 
            // 0x028EF950: MOV w19, w2                | W19 = paramCount;//m1                   
            // 0x028EF954: MOV x21, x1                | X21 = name;//m1                         
            // 0x028EF958: MOV x22, x0                | X22 = 1152921512892978576 (0x10000001EDE45590);//ML01
            // 0x028EF95C: TBNZ w8, #0, #0x28ef978    | if (static_value_037B8A0D == true) goto label_0;
            // 0x028EF960: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x028EF964: LDR x8, [x8, #0x3b0]       | X8 = 0x2B92E6C;                         
            // 0x028EF968: LDR w0, [x8]               | W0 = 0x2260;                            
            // 0x028EF96C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2260, ????);     
            // 0x028EF970: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EF974: STRB w8, [x23, #0xa0d]     | static_value_037B8A0D = true;            //  dest_result_addr=58427917
            label_0:
            // 0x028EF978: LDR x22, [x22, #0x10]      | X22 = this.type; //P2                   
            // 0x028EF97C: CBNZ x22, #0x28ef984       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EF980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2260, ????);     
            label_1:
            // 0x028EF984: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EF988: LDR x8, [x22]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EF98C: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EF990: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EF994: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EF998: CBZ x9, #0x28ef9c4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028EF99C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EF9A0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028EF9A4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028EF9A8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EF9AC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EF9B0: B.EQ #0x28ef9d4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028EF9B4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028EF9B8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EF9BC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EF9C0: B.LO #0x28ef9a8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028EF9C4: MOVZ w2, #0x16             | W2 = 22 (0x16);//ML01                   
            // 0x028EF9C8: MOV x0, x22                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028EF9CC: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028EF9D0: B #0x28ef9e4               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028EF9D4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EF9D8: ADD w9, w9, #0x16          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 22);
            // 0x028EF9DC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 22));
            // 0x028EF9E0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 22)).272
            label_5:
            // 0x028EF9E4: LDP x5, x4, [x0]           | X5 = 0x8; X4 = 0x1200001DE6;             //  | 
            // 0x028EF9E8: AND w3, w20, #1            | W3 = (declaredOnly & 1);                
            declaredOnly = declaredOnly;
            // 0x028EF9EC: MOV x0, x22                | X0 = this.type;//m1                     
            // 0x028EF9F0: MOV x1, x21                | X1 = name;//m1                          
            // 0x028EF9F4: MOV w2, w19                | W2 = paramCount;//m1                    
            // 0x028EF9F8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028EF9FC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028EFA00: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028EFA04: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028EFA08: BR x5                      | X0 = sub_8( ?? this.type, ????);        
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFA0C (42924556), len: 244  VirtAddr: 0x028EFA0C RVA: 0x028EFA0C token: 100680295 methodIndex: 29579 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetMethod(string name, System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> param, ILRuntime.CLR.TypeSystem.IType[] genericArguments, ILRuntime.CLR.TypeSystem.IType returnType, bool declaredOnly = False)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EFA0C: STP x26, x25, [sp, #-0x50]! | stack[1152921512893139936] = ???;  stack[1152921512893139944] = ???;  //  dest_result_addr=1152921512893139936 |  dest_result_addr=1152921512893139944
            // 0x028EFA10: STP x24, x23, [sp, #0x10]  | stack[1152921512893139952] = ???;  stack[1152921512893139960] = ???;  //  dest_result_addr=1152921512893139952 |  dest_result_addr=1152921512893139960
            // 0x028EFA14: STP x22, x21, [sp, #0x20]  | stack[1152921512893139968] = ???;  stack[1152921512893139976] = ???;  //  dest_result_addr=1152921512893139968 |  dest_result_addr=1152921512893139976
            // 0x028EFA18: STP x20, x19, [sp, #0x30]  | stack[1152921512893139984] = ???;  stack[1152921512893139992] = ???;  //  dest_result_addr=1152921512893139984 |  dest_result_addr=1152921512893139992
            // 0x028EFA1C: STP x29, x30, [sp, #0x40]  | stack[1152921512893140000] = ???;  stack[1152921512893140008] = ???;  //  dest_result_addr=1152921512893140000 |  dest_result_addr=1152921512893140008
            // 0x028EFA20: ADD x29, sp, #0x40         | X29 = (1152921512893139936 + 64) = 1152921512893140000 (0x10000001EDE6CC20);
            // 0x028EFA24: ADRP x25, #0x37b8000       | X25 = 58425344 (0x37B8000);             
            // 0x028EFA28: LDRB w8, [x25, #0xa0e]     | W8 = (bool)static_value_037B8A0E;       
            // 0x028EFA2C: MOV w20, w5                | W20 = declaredOnly;//m1                 
            // 0x028EFA30: MOV x19, x4                | X19 = returnType;//m1                   
            // 0x028EFA34: MOV x21, x3                | X21 = genericArguments;//m1             
            // 0x028EFA38: MOV x22, x2                | X22 = param;//m1                        
            // 0x028EFA3C: MOV x23, x1                | X23 = name;//m1                         
            // 0x028EFA40: MOV x24, x0                | X24 = 1152921512893152016 (0x10000001EDE6FB10);//ML01
            // 0x028EFA44: TBNZ w8, #0, #0x28efa60    | if (static_value_037B8A0E == true) goto label_0;
            // 0x028EFA48: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x028EFA4C: LDR x8, [x8, #0xd0]        | X8 = 0x2B92E68;                         
            // 0x028EFA50: LDR w0, [x8]               | W0 = 0x225F;                            
            // 0x028EFA54: BL #0x2782188              | X0 = sub_2782188( ?? 0x225F, ????);     
            // 0x028EFA58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFA5C: STRB w8, [x25, #0xa0e]     | static_value_037B8A0E = true;            //  dest_result_addr=58427918
            label_0:
            // 0x028EFA60: LDR x24, [x24, #0x10]      | X24 = this.type; //P2                   
            // 0x028EFA64: CBNZ x24, #0x28efa6c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EFA68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x225F, ????);     
            label_1:
            // 0x028EFA6C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EFA70: LDR x8, [x24]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFA74: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EFA78: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFA7C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFA80: CBZ x9, #0x28efaac         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028EFA84: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFA88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028EFA8C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028EFA90: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFA94: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFA98: B.EQ #0x28efabc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028EFA9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028EFAA0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFAA4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFAA8: B.LO #0x28efa90            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028EFAAC: MOVZ w2, #0x17             | W2 = 23 (0x17);//ML01                   
            // 0x028EFAB0: MOV x0, x24                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028EFAB4: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028EFAB8: B #0x28efacc               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028EFABC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFAC0: ADD w9, w9, #0x17          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 23);
            // 0x028EFAC4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 23));
            // 0x028EFAC8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 23)).272
            label_5:
            // 0x028EFACC: LDP x7, x6, [x0]           | X7 = 0x800; X6 = 0x1200001DE600;         //  | 
            // 0x028EFAD0: AND w5, w20, #1            | W5 = (declaredOnly & 1);                
            declaredOnly = declaredOnly;
            // 0x028EFAD4: MOV x0, x24                | X0 = this.type;//m1                     
            // 0x028EFAD8: MOV x1, x23                | X1 = name;//m1                          
            // 0x028EFADC: MOV x2, x22                | X2 = param;//m1                         
            // 0x028EFAE0: MOV x3, x21                | X3 = genericArguments;//m1              
            // 0x028EFAE4: MOV x4, x19                | X4 = returnType;//m1                    
            // 0x028EFAE8: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x028EFAEC: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x028EFAF0: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x028EFAF4: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x028EFAF8: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x028EFAFC: BR x7                      | X0 = sub_800( ?? this.type, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFB00 (42924800), len: 180  VirtAddr: 0x028EFB00 RVA: 0x028EFB00 token: 100680296 methodIndex: 29580 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.List<ILRuntime.CLR.Method.IMethod> GetMethods()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EFB00: STP x20, x19, [sp, #-0x20]! | stack[1152921512893309328] = ???;  stack[1152921512893309336] = ???;  //  dest_result_addr=1152921512893309328 |  dest_result_addr=1152921512893309336
            // 0x028EFB04: STP x29, x30, [sp, #0x10]  | stack[1152921512893309344] = ???;  stack[1152921512893309352] = ???;  //  dest_result_addr=1152921512893309344 |  dest_result_addr=1152921512893309352
            // 0x028EFB08: ADD x29, sp, #0x10         | X29 = (1152921512893309328 + 16) = 1152921512893309344 (0x10000001EDE961A0);
            // 0x028EFB0C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EFB10: LDRB w8, [x20, #0xa0f]     | W8 = (bool)static_value_037B8A0F;       
            // 0x028EFB14: MOV x19, x0                | X19 = 1152921512893321360 (0x10000001EDE99090);//ML01
            // 0x028EFB18: TBNZ w8, #0, #0x28efb34    | if (static_value_037B8A0F == true) goto label_0;
            // 0x028EFB1C: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x028EFB20: LDR x8, [x8, #0xf68]       | X8 = 0x2B92E70;                         
            // 0x028EFB24: LDR w0, [x8]               | W0 = 0x2261;                            
            // 0x028EFB28: BL #0x2782188              | X0 = sub_2782188( ?? 0x2261, ????);     
            // 0x028EFB2C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFB30: STRB w8, [x20, #0xa0f]     | static_value_037B8A0F = true;            //  dest_result_addr=58427919
            label_0:
            // 0x028EFB34: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028EFB38: CBNZ x19, #0x28efb40       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EFB3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2261, ????);     
            label_1:
            // 0x028EFB40: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EFB44: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFB48: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EFB4C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFB50: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFB54: CBZ x9, #0x28efb80         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028EFB58: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFB5C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028EFB60: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028EFB64: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFB68: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFB6C: B.EQ #0x28efb90            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028EFB70: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028EFB74: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFB78: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFB7C: B.LO #0x28efb64            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028EFB80: MOVZ w2, #0x19             | W2 = 25 (0x19);//ML01                   
            // 0x028EFB84: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028EFB88: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028EFB8C: B #0x28efba0               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028EFB90: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFB94: ADD w9, w9, #0x19          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 25);
            // 0x028EFB98: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 25));
            // 0x028EFB9C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 25)).272
            label_5:
            // 0x028EFBA0: LDP x2, x1, [x0]           | X2 = 0xE600000000000000; X1 = 0x1200001D; //  | 
            // 0x028EFBA4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028EFBA8: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028EFBAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028EFBB0: BR x2                      | X0 = sub_E600000000000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFBB4 (42924980), len: 196  VirtAddr: 0x028EFBB4 RVA: 0x028EFBB4 token: 100680297 methodIndex: 29581 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetFieldIndex(object token)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EFBB4: STP x22, x21, [sp, #-0x30]! | stack[1152921512893433600] = ???;  stack[1152921512893433608] = ???;  //  dest_result_addr=1152921512893433600 |  dest_result_addr=1152921512893433608
            // 0x028EFBB8: STP x20, x19, [sp, #0x10]  | stack[1152921512893433616] = ???;  stack[1152921512893433624] = ???;  //  dest_result_addr=1152921512893433616 |  dest_result_addr=1152921512893433624
            // 0x028EFBBC: STP x29, x30, [sp, #0x20]  | stack[1152921512893433632] = ???;  stack[1152921512893433640] = ???;  //  dest_result_addr=1152921512893433632 |  dest_result_addr=1152921512893433640
            // 0x028EFBC0: ADD x29, sp, #0x20         | X29 = (1152921512893433600 + 32) = 1152921512893433632 (0x10000001EDEB4720);
            // 0x028EFBC4: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028EFBC8: LDRB w8, [x21, #0xa10]     | W8 = (bool)static_value_037B8A10;       
            // 0x028EFBCC: MOV x19, x1                | X19 = token;//m1                        
            // 0x028EFBD0: MOV x20, x0                | X20 = 1152921512893445648 (0x10000001EDEB7610);//ML01
            // 0x028EFBD4: TBNZ w8, #0, #0x28efbf0    | if (static_value_037B8A10 == true) goto label_0;
            // 0x028EFBD8: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x028EFBDC: LDR x8, [x8, #0xdc8]       | X8 = 0x2B92E64;                         
            // 0x028EFBE0: LDR w0, [x8]               | W0 = 0x225E;                            
            // 0x028EFBE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x225E, ????);     
            // 0x028EFBE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFBEC: STRB w8, [x21, #0xa10]     | static_value_037B8A10 = true;            //  dest_result_addr=58427920
            label_0:
            // 0x028EFBF0: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028EFBF4: CBNZ x20, #0x28efbfc       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EFBF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x225E, ????);     
            label_1:
            // 0x028EFBFC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EFC00: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFC04: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EFC08: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFC0C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFC10: CBZ x9, #0x28efc3c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028EFC14: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFC18: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028EFC1C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028EFC20: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFC24: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFC28: B.EQ #0x28efc4c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028EFC2C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028EFC30: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFC34: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFC38: B.LO #0x28efc20            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028EFC3C: MOVZ w2, #0x1a             | W2 = 26 (0x1A);//ML01                   
            // 0x028EFC40: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028EFC44: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028EFC48: B #0x28efc5c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028EFC4C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFC50: ADD w9, w9, #0x1a          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 26);
            // 0x028EFC54: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 26));
            // 0x028EFC58: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 26)).272
            label_5:
            // 0x028EFC5C: LDP x3, x2, [x0]           | X3 = 0x80000; X2 = 0x1200001DE60000;     //  | 
            // 0x028EFC60: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028EFC64: MOV x1, x19                | X1 = token;//m1                         
            // 0x028EFC68: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EFC6C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EFC70: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EFC74: BR x3                      | X0 = sub_80000( ?? this.type, ????);    
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFC78 (42925176), len: 196  VirtAddr: 0x028EFC78 RVA: 0x028EFC78 token: 100680298 methodIndex: 29582 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetConstructor(System.Collections.Generic.List<ILRuntime.CLR.TypeSystem.IType> param)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EFC78: STP x22, x21, [sp, #-0x30]! | stack[1152921512893561984] = ???;  stack[1152921512893561992] = ???;  //  dest_result_addr=1152921512893561984 |  dest_result_addr=1152921512893561992
            // 0x028EFC7C: STP x20, x19, [sp, #0x10]  | stack[1152921512893562000] = ???;  stack[1152921512893562008] = ???;  //  dest_result_addr=1152921512893562000 |  dest_result_addr=1152921512893562008
            // 0x028EFC80: STP x29, x30, [sp, #0x20]  | stack[1152921512893562016] = ???;  stack[1152921512893562024] = ???;  //  dest_result_addr=1152921512893562016 |  dest_result_addr=1152921512893562024
            // 0x028EFC84: ADD x29, sp, #0x20         | X29 = (1152921512893561984 + 32) = 1152921512893562016 (0x10000001EDED3CA0);
            // 0x028EFC88: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028EFC8C: LDRB w8, [x21, #0xa11]     | W8 = (bool)static_value_037B8A11;       
            // 0x028EFC90: MOV x19, x1                | X19 = param;//m1                        
            // 0x028EFC94: MOV x20, x0                | X20 = 1152921512893574032 (0x10000001EDED6B90);//ML01
            // 0x028EFC98: TBNZ w8, #0, #0x28efcb4    | if (static_value_037B8A11 == true) goto label_0;
            // 0x028EFC9C: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x028EFCA0: LDR x8, [x8, #0xfd8]       | X8 = 0x2B92E60;                         
            // 0x028EFCA4: LDR w0, [x8]               | W0 = 0x225D;                            
            // 0x028EFCA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x225D, ????);     
            // 0x028EFCAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFCB0: STRB w8, [x21, #0xa11]     | static_value_037B8A11 = true;            //  dest_result_addr=58427921
            label_0:
            // 0x028EFCB4: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028EFCB8: CBNZ x20, #0x28efcc0       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EFCBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x225D, ????);     
            label_1:
            // 0x028EFCC0: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EFCC4: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFCC8: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EFCCC: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFCD0: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFCD4: CBZ x9, #0x28efd00         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028EFCD8: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFCDC: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028EFCE0: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028EFCE4: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFCE8: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFCEC: B.EQ #0x28efd10            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028EFCF0: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028EFCF4: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFCF8: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFCFC: B.LO #0x28efce4            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028EFD00: MOVZ w2, #0x1b             | W2 = 27 (0x1B);//ML01                   
            // 0x028EFD04: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028EFD08: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028EFD0C: B #0x28efd20               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028EFD10: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFD14: ADD w9, w9, #0x1b          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 27);
            // 0x028EFD18: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 27));
            // 0x028EFD1C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 27)).272
            label_5:
            // 0x028EFD20: LDP x3, x2, [x0]           | X3 = 0x8000000; X2 = 0x1200001DE6000000; //  | 
            // 0x028EFD24: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028EFD28: MOV x1, x19                | X1 = param;//m1                         
            // 0x028EFD2C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028EFD30: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028EFD34: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028EFD38: BR x3                      | X0 = sub_8000000( ?? this.type, ????);  
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFD3C (42925372), len: 460  VirtAddr: 0x028EFD3C RVA: 0x028EFD3C token: 100680299 methodIndex: 29583 delegateWrapperIndex: 0 methodInvoker: 0
        public bool CanAssignTo(ILRuntime.CLR.TypeSystem.IType type)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.CLR.TypeSystem.IType val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            // 0x028EFD3C: STP x24, x23, [sp, #-0x40]! | stack[1152921512893772272] = ???;  stack[1152921512893772280] = ???;  //  dest_result_addr=1152921512893772272 |  dest_result_addr=1152921512893772280
            // 0x028EFD40: STP x22, x21, [sp, #0x10]  | stack[1152921512893772288] = ???;  stack[1152921512893772296] = ???;  //  dest_result_addr=1152921512893772288 |  dest_result_addr=1152921512893772296
            // 0x028EFD44: STP x20, x19, [sp, #0x20]  | stack[1152921512893772304] = ???;  stack[1152921512893772312] = ???;  //  dest_result_addr=1152921512893772304 |  dest_result_addr=1152921512893772312
            // 0x028EFD48: STP x29, x30, [sp, #0x30]  | stack[1152921512893772320] = ???;  stack[1152921512893772328] = ???;  //  dest_result_addr=1152921512893772320 |  dest_result_addr=1152921512893772328
            // 0x028EFD4C: ADD x29, sp, #0x30         | X29 = (1152921512893772272 + 48) = 1152921512893772320 (0x10000001EDF07220);
            // 0x028EFD50: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028EFD54: LDRB w8, [x21, #0xa12]     | W8 = (bool)static_value_037B8A12;       
            // 0x028EFD58: MOV x19, x1                | X19 = type;//m1                         
            // 0x028EFD5C: MOV x20, x0                | X20 = 1152921512893784336 (0x10000001EDF0A110);//ML01
            // 0x028EFD60: TBNZ w8, #0, #0x28efd7c    | if (static_value_037B8A12 == true) goto label_0;
            // 0x028EFD64: ADRP x8, #0x35da000        | X8 = 56467456 (0x35DA000);              
            // 0x028EFD68: LDR x8, [x8, #0x3c0]       | X8 = 0x2B92E04;                         
            // 0x028EFD6C: LDR w0, [x8]               | W0 = 0x2246;                            
            // 0x028EFD70: BL #0x2782188              | X0 = sub_2782188( ?? 0x2246, ????);     
            // 0x028EFD74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFD78: STRB w8, [x21, #0xa12]     | static_value_037B8A12 = true;            //  dest_result_addr=58427922
            label_0:
            // 0x028EFD7C: MOV x0, x20                | X0 = 1152921512893784336 (0x10000001EDF0A110);//ML01
            // 0x028EFD80: BL #0x28eff08              | X0 = this.get_BaseType();               
            ILRuntime.CLR.TypeSystem.IType val_1 = this.BaseType;
            // 0x028EFD84: CBZ x0, #0x28efdec         | if (val_1 == null) goto label_1;        
            if(val_1 == null)
            {
                goto label_1;
            }
            // 0x028EFD88: MOV x0, x20                | X0 = 1152921512893784336 (0x10000001EDF0A110);//ML01
            // 0x028EFD8C: BL #0x28eff08              | X0 = this.get_BaseType();               
            ILRuntime.CLR.TypeSystem.IType val_2 = this.BaseType;
            // 0x028EFD90: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x028EFD94: CBNZ x21, #0x28efd9c       | if (val_2 != null) goto label_2;        
            if(val_2 != null)
            {
                goto label_2;
            }
            // 0x028EFD98: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_2:
            // 0x028EFD9C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EFDA0: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFDA4: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EFDA8: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFDAC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFDB0: CBZ x9, #0x28efddc         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x028EFDB4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFDB8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_8 = 0;
            // 0x028EFDBC: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_5:
            // 0x028EFDC0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFDC4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFDC8: B.EQ #0x28efdfc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_4;
            // 0x028EFDCC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_8 = val_8 + 1;
            // 0x028EFDD0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFDD4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFDD8: B.LO #0x28efdc0            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x028EFDDC: ORR w2, wzr, #0x1c         | W2 = 28(0x1C);                          
            // 0x028EFDE0: MOV x0, x21                | X0 = val_2;//m1                         
            val_9 = val_2;
            // 0x028EFDE4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_2, ????);      
            // 0x028EFDE8: B #0x28efe0c               |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x028EFDEC: MOV x0, x20                | X0 = 1152921512893784336 (0x10000001EDF0A110);//ML01
            // 0x028EFDF0: BL #0x28effbc              | X0 = this.get_Implements();             
            ILRuntime.CLR.TypeSystem.IType[] val_3 = this.Implements;
            // 0x028EFDF4: MOV x20, x0                | X20 = val_3;//m1                        
            val_10 = val_3;
            // 0x028EFDF8: B #0x28efe30               |  goto label_7;                          
            goto label_7;
            label_4:
            // 0x028EFDFC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFE00: ADD w9, w9, #0x1c          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 28);
            // 0x028EFE04: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 28));
            // 0x028EFE08: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 28)).272
            label_6:
            // 0x028EFE0C: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);  //  | 
            // 0x028EFE10: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x028EFE14: MOV x1, x19                | X1 = type;//m1                          
            // 0x028EFE18: BLR x8                     | X0 = sub_100000000A746000( ?? val_2, ????);
            // 0x028EFE1C: AND w21, w0, #1            | W21 = (val_2 & 1);                      
            val_8 = val_2 & 1;
            // 0x028EFE20: MOV x0, x20                | X0 = 1152921512893784336 (0x10000001EDF0A110);//ML01
            // 0x028EFE24: BL #0x28effbc              | X0 = this.get_Implements();             
            ILRuntime.CLR.TypeSystem.IType[] val_5 = this.Implements;
            // 0x028EFE28: MOV x20, x0                | X20 = val_5;//m1                        
            val_10 = val_5;
            // 0x028EFE2C: TBNZ w21, #0, #0x28efee8   | if (((val_2 & 1) & 0x1) != 0) goto label_8;
            if((val_8 & 1) != 0)
            {
                goto label_8;
            }
            label_7:
            // 0x028EFE30: CBZ x20, #0x28efef0        | if (val_5 == null) goto label_10;       
            if(val_10 == null)
            {
                goto label_10;
            }
            // 0x028EFE34: ADRP x23, #0x3679000       | X23 = 57118720 (0x3679000);             
            // 0x028EFE38: LDR x23, [x23, #0xdf8]     | X23 = 1152921504782245888;              
            // 0x028EFE3C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            var val_10 = 0;
            label_17:
            // 0x028EFE40: LDR w8, [x20, #0x18]       | W8 = val_5.Length; //P2                 
            // 0x028EFE44: CMP w22, w8                | STATE = COMPARE(0x0, val_5.Length)      
            // 0x028EFE48: B.GE #0x28efef0            | if (0 >= val_5.Length) goto label_10;   
            if(val_10 >= val_5.Length)
            {
                goto label_10;
            }
            // 0x028EFE4C: SXTW x21, w22              | X21 = 0 (0x00000000);                   
            // 0x028EFE50: CMP w22, w8                | STATE = COMPARE(0x0, val_5.Length)      
            // 0x028EFE54: B.LO #0x28efe64            | if (0 < val_5.Length) goto label_11;    
            if(val_10 < val_5.Length)
            {
                goto label_11;
            }
            // 0x028EFE58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_5, ????);      
            // 0x028EFE5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x028EFE60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            label_11:
            // 0x028EFE64: ADD x8, x20, x21, lsl #3   | X8 = val_5[0x0]; //PARR1                
            // 0x028EFE68: LDR x21, [x8, #0x20]       | X21 = val_5[0x0][0]                     
            val_8 = val_10[0];
            // 0x028EFE6C: CBNZ x21, #0x28efe74       | if (val_5[0x0][0] != null) goto label_12;
            if(val_8 != null)
            {
                goto label_12;
            }
            // 0x028EFE70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            label_12:
            // 0x028EFE74: LDR x8, [x21]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFE78: LDR x1, [x23]              | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFE7C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFE80: CBZ x9, #0x28efeac         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_13;
            // 0x028EFE84: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFE88: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_9 = 0;
            // 0x028EFE8C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_15:
            // 0x028EFE90: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFE94: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFE98: B.EQ #0x28efebc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_14;
            // 0x028EFE9C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_9 = val_9 + 1;
            // 0x028EFEA0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFEA4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFEA8: B.LO #0x28efe90            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_15;
            label_13:
            // 0x028EFEAC: ORR w2, wzr, #0x1c         | W2 = 28(0x1C);                          
            val_11 = 28;
            // 0x028EFEB0: MOV x0, x21                | X0 = val_5[0x0][0];//m1                 
            val_12 = val_8;
            // 0x028EFEB4: BL #0x2776c24              | X0 = sub_2776C24( ?? val_5[0x0][0], ????);
            // 0x028EFEB8: B #0x28efecc               |  goto label_16;                         
            goto label_16;
            label_14:
            // 0x028EFEBC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFEC0: ADD w9, w9, #0x1c          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 28);
            // 0x028EFEC4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 28));
            // 0x028EFEC8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 28)).272
            label_16:
            // 0x028EFECC: LDP x8, x2, [x0]           | X8 = typeof(ILRuntime.CLR.TypeSystem.IType[]);  //  | 
            // 0x028EFED0: MOV x0, x21                | X0 = val_5[0x0][0];//m1                 
            // 0x028EFED4: MOV x1, x19                | X1 = type;//m1                          
            // 0x028EFED8: BLR x8                     | X0 = sub_10000000691225D0( ?? val_5[0x0][0], ????);
            // 0x028EFEDC: ADD w22, w22, #1           | W22 = (0 + 1);                          
            val_10 = val_10 + 1;
            // 0x028EFEE0: AND w8, w0, #1             | W8 = (val_5[0x0][0] & 1);               
            ILRuntime.CLR.TypeSystem.IType val_7 = val_8 & 1;
            // 0x028EFEE4: TBZ w8, #0, #0x28efe40     | if (((val_5[0x0][0] & 1) & 0x1) == 0) goto label_17;
            if((val_7 & 1) == 0)
            {
                goto label_17;
            }
            label_8:
            // 0x028EFEE8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_13 = 1;
            // 0x028EFEEC: B #0x28efef4               |  goto label_18;                         
            goto label_18;
            label_10:
            // 0x028EFEF0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_13 = 0;
            label_18:
            // 0x028EFEF4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x028EFEF8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x028EFEFC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x028EFF00: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x028EFF04: RET                        |  return (System.Boolean)false;          
            return (bool)val_13;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0070 (42926192), len: 196  VirtAddr: 0x028F0070 RVA: 0x028F0070 token: 100680300 methodIndex: 29584 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType MakeGenericInstance(System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] genericArguments)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0070: STP x22, x21, [sp, #-0x30]! | stack[1152921512894015360] = ???;  stack[1152921512894015368] = ???;  //  dest_result_addr=1152921512894015360 |  dest_result_addr=1152921512894015368
            // 0x028F0074: STP x20, x19, [sp, #0x10]  | stack[1152921512894015376] = ???;  stack[1152921512894015384] = ???;  //  dest_result_addr=1152921512894015376 |  dest_result_addr=1152921512894015384
            // 0x028F0078: STP x29, x30, [sp, #0x20]  | stack[1152921512894015392] = ???;  stack[1152921512894015400] = ???;  //  dest_result_addr=1152921512894015392 |  dest_result_addr=1152921512894015400
            // 0x028F007C: ADD x29, sp, #0x20         | X29 = (1152921512894015360 + 32) = 1152921512894015392 (0x10000001EDF427A0);
            // 0x028F0080: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F0084: LDRB w8, [x21, #0xa13]     | W8 = (bool)static_value_037B8A13;       
            // 0x028F0088: MOV x19, x1                | X19 = genericArguments;//m1             
            // 0x028F008C: MOV x20, x0                | X20 = 1152921512894027408 (0x10000001EDF45690);//ML01
            // 0x028F0090: TBNZ w8, #0, #0x28f00ac    | if (static_value_037B8A13 == true) goto label_0;
            // 0x028F0094: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x028F0098: LDR x8, [x8, #0x1f8]       | X8 = 0x2B92E80;                         
            // 0x028F009C: LDR w0, [x8]               | W0 = 0x2265;                            
            // 0x028F00A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2265, ????);     
            // 0x028F00A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F00A8: STRB w8, [x21, #0xa13]     | static_value_037B8A13 = true;            //  dest_result_addr=58427923
            label_0:
            // 0x028F00AC: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028F00B0: CBNZ x20, #0x28f00b8       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F00B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2265, ????);     
            label_1:
            // 0x028F00B8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F00BC: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F00C0: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F00C4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F00C8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F00CC: CBZ x9, #0x28f00f8         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F00D0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F00D4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F00D8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F00DC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F00E0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F00E4: B.EQ #0x28f0108            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F00E8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F00EC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F00F0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F00F4: B.LO #0x28f00dc            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F00F8: MOVZ w2, #0x1d             | W2 = 29 (0x1D);//ML01                   
            // 0x028F00FC: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0100: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0104: B #0x28f0118               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0108: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F010C: ADD w9, w9, #0x1d          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 29);
            // 0x028F0110: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 29));
            // 0x028F0114: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 29)).272
            label_5:
            // 0x028F0118: LDP x3, x2, [x0]           | X3 = 0x1200001DE6000000; X2 = 0x0;       //  | 
            // 0x028F011C: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028F0120: MOV x1, x19                | X1 = genericArguments;//m1              
            // 0x028F0124: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0128: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F012C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F0130: BR x3                      | X0 = sub_1200001DE6000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0134 (42926388), len: 180  VirtAddr: 0x028F0134 RVA: 0x028F0134 token: 100680301 methodIndex: 29585 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType MakeByRefType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0134: STP x20, x19, [sp, #-0x20]! | stack[1152921512894172432] = ???;  stack[1152921512894172440] = ???;  //  dest_result_addr=1152921512894172432 |  dest_result_addr=1152921512894172440
            // 0x028F0138: STP x29, x30, [sp, #0x10]  | stack[1152921512894172448] = ???;  stack[1152921512894172456] = ???;  //  dest_result_addr=1152921512894172448 |  dest_result_addr=1152921512894172456
            // 0x028F013C: ADD x29, sp, #0x10         | X29 = (1152921512894172432 + 16) = 1152921512894172448 (0x10000001EDF68D20);
            // 0x028F0140: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0144: LDRB w8, [x20, #0xa14]     | W8 = (bool)static_value_037B8A14;       
            // 0x028F0148: MOV x19, x0                | X19 = 1152921512894184464 (0x10000001EDF6BC10);//ML01
            // 0x028F014C: TBNZ w8, #0, #0x28f0168    | if (static_value_037B8A14 == true) goto label_0;
            // 0x028F0150: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
            // 0x028F0154: LDR x8, [x8, #0xb50]       | X8 = 0x2B92E7C;                         
            // 0x028F0158: LDR w0, [x8]               | W0 = 0x2264;                            
            // 0x028F015C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2264, ????);     
            // 0x028F0160: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0164: STRB w8, [x20, #0xa14]     | static_value_037B8A14 = true;            //  dest_result_addr=58427924
            label_0:
            // 0x028F0168: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F016C: CBNZ x19, #0x28f0174       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0170: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2264, ????);     
            label_1:
            // 0x028F0174: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0178: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F017C: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0180: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0184: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0188: CBZ x9, #0x28f01b4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F018C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0190: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0194: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0198: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F019C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F01A0: B.EQ #0x28f01c4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F01A4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F01A8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F01AC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F01B0: B.LO #0x28f0198            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F01B4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x028F01B8: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F01BC: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F01C0: B #0x28f01d4               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F01C4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F01C8: ADD w9, w9, #0x1e          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 30);
            // 0x028F01CC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 30));
            // 0x028F01D0: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 30)).272
            label_5:
            // 0x028F01D4: LDP x2, x1, [x0]           | X2 = 0x1DE600000000; X1 = 0x12;          //  | 
            // 0x028F01D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F01DC: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F01E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F01E4: BR x2                      | X0 = sub_1DE600000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F01E8 (42926568), len: 196  VirtAddr: 0x028F01E8 RVA: 0x028F01E8 token: 100680302 methodIndex: 29586 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType MakeArrayType(int rank)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F01E8: STP x22, x21, [sp, #-0x30]! | stack[1152921512894292608] = ???;  stack[1152921512894292616] = ???;  //  dest_result_addr=1152921512894292608 |  dest_result_addr=1152921512894292616
            // 0x028F01EC: STP x20, x19, [sp, #0x10]  | stack[1152921512894292624] = ???;  stack[1152921512894292632] = ???;  //  dest_result_addr=1152921512894292624 |  dest_result_addr=1152921512894292632
            // 0x028F01F0: STP x29, x30, [sp, #0x20]  | stack[1152921512894292640] = ???;  stack[1152921512894292648] = ???;  //  dest_result_addr=1152921512894292640 |  dest_result_addr=1152921512894292648
            // 0x028F01F4: ADD x29, sp, #0x20         | X29 = (1152921512894292608 + 32) = 1152921512894292640 (0x10000001EDF862A0);
            // 0x028F01F8: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F01FC: LDRB w8, [x21, #0xa15]     | W8 = (bool)static_value_037B8A15;       
            // 0x028F0200: MOV w19, w1                | W19 = rank;//m1                         
            // 0x028F0204: MOV x20, x0                | X20 = 1152921512894304656 (0x10000001EDF89190);//ML01
            // 0x028F0208: TBNZ w8, #0, #0x28f0224    | if (static_value_037B8A15 == true) goto label_0;
            // 0x028F020C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x028F0210: LDR x8, [x8, #0xce8]       | X8 = 0x2B92E78;                         
            // 0x028F0214: LDR w0, [x8]               | W0 = 0x2263;                            
            // 0x028F0218: BL #0x2782188              | X0 = sub_2782188( ?? 0x2263, ????);     
            // 0x028F021C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0220: STRB w8, [x21, #0xa15]     | static_value_037B8A15 = true;            //  dest_result_addr=58427925
            label_0:
            // 0x028F0224: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028F0228: CBNZ x20, #0x28f0230       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F022C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2263, ????);     
            label_1:
            // 0x028F0230: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0234: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0238: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F023C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0240: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0244: CBZ x9, #0x28f0270         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0248: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F024C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0250: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0254: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0258: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F025C: B.EQ #0x28f0280            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0260: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0264: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0268: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F026C: B.LO #0x28f0254            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0270: ORR w2, wzr, #0x1f         | W2 = 31(0x1F);                          
            // 0x028F0274: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0278: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F027C: B #0x28f0290               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0280: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0284: ADD w9, w9, #0x1f          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 31);
            // 0x028F0288: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 31));
            // 0x028F028C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 31)).272
            label_5:
            // 0x028F0290: LDP x3, x2, [x0]           | X3 = 0x1DE60000000000; X2 = 0x1200;      //  | 
            // 0x028F0294: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028F0298: MOV w1, w19                | W1 = rank;//m1                          
            // 0x028F029C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F02A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F02A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F02A8: BR x3                      | X0 = sub_1DE60000000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F02AC (42926764), len: 196  VirtAddr: 0x028F02AC RVA: 0x028F02AC token: 100680303 methodIndex: 29587 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType FindGenericArgument(string key)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F02AC: STP x22, x21, [sp, #-0x30]! | stack[1152921512894416896] = ???;  stack[1152921512894416904] = ???;  //  dest_result_addr=1152921512894416896 |  dest_result_addr=1152921512894416904
            // 0x028F02B0: STP x20, x19, [sp, #0x10]  | stack[1152921512894416912] = ???;  stack[1152921512894416920] = ???;  //  dest_result_addr=1152921512894416912 |  dest_result_addr=1152921512894416920
            // 0x028F02B4: STP x29, x30, [sp, #0x20]  | stack[1152921512894416928] = ???;  stack[1152921512894416936] = ???;  //  dest_result_addr=1152921512894416928 |  dest_result_addr=1152921512894416936
            // 0x028F02B8: ADD x29, sp, #0x20         | X29 = (1152921512894416896 + 32) = 1152921512894416928 (0x10000001EDFA4820);
            // 0x028F02BC: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F02C0: LDRB w8, [x21, #0xa16]     | W8 = (bool)static_value_037B8A16;       
            // 0x028F02C4: MOV x19, x1                | X19 = key;//m1                          
            // 0x028F02C8: MOV x20, x0                | X20 = 1152921512894428944 (0x10000001EDFA7710);//ML01
            // 0x028F02CC: TBNZ w8, #0, #0x28f02e8    | if (static_value_037B8A16 == true) goto label_0;
            // 0x028F02D0: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x028F02D4: LDR x8, [x8, #0xd80]       | X8 = 0x2B92E08;                         
            // 0x028F02D8: LDR w0, [x8]               | W0 = 0x2247;                            
            // 0x028F02DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2247, ????);     
            // 0x028F02E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F02E4: STRB w8, [x21, #0xa16]     | static_value_037B8A16 = true;            //  dest_result_addr=58427926
            label_0:
            // 0x028F02E8: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028F02EC: CBNZ x20, #0x28f02f4       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F02F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2247, ????);     
            label_1:
            // 0x028F02F4: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F02F8: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F02FC: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0300: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0304: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0308: CBZ x9, #0x28f0334         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F030C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0310: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0314: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0318: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F031C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0320: B.EQ #0x28f0344            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0324: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0328: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F032C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0330: B.LO #0x28f0318            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0334: ORR w2, wzr, #0x20         | W2 = 32(0x20);                          
            // 0x028F0338: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F033C: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0340: B #0x28f0354               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0344: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0348: ADD w9, w9, #0x20          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 32);
            // 0x028F034C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 32));
            // 0x028F0350: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 32)).272
            label_5:
            // 0x028F0354: LDP x3, x2, [x0]           | X3 = 0x400; X2 = 0xA00120000245D00;      //  | 
            // 0x028F0358: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028F035C: MOV x1, x19                | X1 = key;//m1                           
            // 0x028F0360: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0364: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F0368: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F036C: BR x3                      | X0 = sub_400( ?? this.type, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0370 (42926960), len: 196  VirtAddr: 0x028F0370 RVA: 0x028F0370 token: 100680304 methodIndex: 29588 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType ResolveGenericType(ILRuntime.CLR.TypeSystem.IType contextType)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0370: STP x22, x21, [sp, #-0x30]! | stack[1152921512894545280] = ???;  stack[1152921512894545288] = ???;  //  dest_result_addr=1152921512894545280 |  dest_result_addr=1152921512894545288
            // 0x028F0374: STP x20, x19, [sp, #0x10]  | stack[1152921512894545296] = ???;  stack[1152921512894545304] = ???;  //  dest_result_addr=1152921512894545296 |  dest_result_addr=1152921512894545304
            // 0x028F0378: STP x29, x30, [sp, #0x20]  | stack[1152921512894545312] = ???;  stack[1152921512894545320] = ???;  //  dest_result_addr=1152921512894545312 |  dest_result_addr=1152921512894545320
            // 0x028F037C: ADD x29, sp, #0x20         | X29 = (1152921512894545280 + 32) = 1152921512894545312 (0x10000001EDFC3DA0);
            // 0x028F0380: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F0384: LDRB w8, [x21, #0xa17]     | W8 = (bool)static_value_037B8A17;       
            // 0x028F0388: MOV x19, x1                | X19 = contextType;//m1                  
            // 0x028F038C: MOV x20, x0                | X20 = 1152921512894557328 (0x10000001EDFC6C90);//ML01
            // 0x028F0390: TBNZ w8, #0, #0x28f03ac    | if (static_value_037B8A17 == true) goto label_0;
            // 0x028F0394: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F0398: LDR x8, [x8, #0xb80]       | X8 = 0x2B92E84;                         
            // 0x028F039C: LDR w0, [x8]               | W0 = 0x2266;                            
            // 0x028F03A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2266, ????);     
            // 0x028F03A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F03A8: STRB w8, [x21, #0xa17]     | static_value_037B8A17 = true;            //  dest_result_addr=58427927
            label_0:
            // 0x028F03AC: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028F03B0: CBNZ x20, #0x28f03b8       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F03B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2266, ????);     
            label_1:
            // 0x028F03B8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F03BC: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F03C0: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F03C4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F03C8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F03CC: CBZ x9, #0x28f03f8         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F03D0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F03D4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F03D8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F03DC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F03E0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F03E4: B.EQ #0x28f0408            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F03E8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F03EC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F03F0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F03F4: B.LO #0x28f03dc            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F03F8: MOVZ w2, #0x21             | W2 = 33 (0x21);//ML01                   
            // 0x028F03FC: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0400: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0404: B #0x28f0418               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0408: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F040C: ADD w9, w9, #0x21          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 33);
            // 0x028F0410: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 33));
            // 0x028F0414: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 33)).272
            label_5:
            // 0x028F0418: LDP x3, x2, [x0]           | X3 = 0x1200001DE60000; X2 = 0x0;         //  | 
            // 0x028F041C: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028F0420: MOV x1, x19                | X1 = contextType;//m1                   
            // 0x028F0424: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0428: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F042C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F0430: BR x3                      | X0 = sub_1200001DE60000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0434 (42927156), len: 196  VirtAddr: 0x028F0434 RVA: 0x028F0434 token: 100680305 methodIndex: 29589 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.Method.IMethod GetVirtualMethod(ILRuntime.CLR.Method.IMethod method)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0434: STP x22, x21, [sp, #-0x30]! | stack[1152921512894673664] = ???;  stack[1152921512894673672] = ???;  //  dest_result_addr=1152921512894673664 |  dest_result_addr=1152921512894673672
            // 0x028F0438: STP x20, x19, [sp, #0x10]  | stack[1152921512894673680] = ???;  stack[1152921512894673688] = ???;  //  dest_result_addr=1152921512894673680 |  dest_result_addr=1152921512894673688
            // 0x028F043C: STP x29, x30, [sp, #0x20]  | stack[1152921512894673696] = ???;  stack[1152921512894673704] = ???;  //  dest_result_addr=1152921512894673696 |  dest_result_addr=1152921512894673704
            // 0x028F0440: ADD x29, sp, #0x20         | X29 = (1152921512894673664 + 32) = 1152921512894673696 (0x10000001EDFE3320);
            // 0x028F0444: ADRP x21, #0x37b8000       | X21 = 58425344 (0x37B8000);             
            // 0x028F0448: LDRB w8, [x21, #0xa18]     | W8 = (bool)static_value_037B8A18;       
            // 0x028F044C: MOV x19, x1                | X19 = method;//m1                       
            // 0x028F0450: MOV x20, x0                | X20 = 1152921512894685712 (0x10000001EDFE6210);//ML01
            // 0x028F0454: TBNZ w8, #0, #0x28f0470    | if (static_value_037B8A18 == true) goto label_0;
            // 0x028F0458: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x028F045C: LDR x8, [x8, #0x3e0]       | X8 = 0x2B92E74;                         
            // 0x028F0460: LDR w0, [x8]               | W0 = 0x2262;                            
            // 0x028F0464: BL #0x2782188              | X0 = sub_2782188( ?? 0x2262, ????);     
            // 0x028F0468: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F046C: STRB w8, [x21, #0xa18]     | static_value_037B8A18 = true;            //  dest_result_addr=58427928
            label_0:
            // 0x028F0470: LDR x20, [x20, #0x10]      | X20 = this.type; //P2                   
            // 0x028F0474: CBNZ x20, #0x28f047c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0478: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2262, ????);     
            label_1:
            // 0x028F047C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0480: LDR x8, [x20]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0484: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0488: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F048C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0490: CBZ x9, #0x28f04bc         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0494: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0498: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F049C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F04A0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F04A4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F04A8: B.EQ #0x28f04cc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F04AC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F04B0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F04B4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F04B8: B.LO #0x28f04a0            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F04BC: ORR w2, wzr, #0x18         | W2 = 24(0x18);                          
            // 0x028F04C0: MOV x0, x20                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F04C4: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F04C8: B #0x28f04dc               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F04CC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F04D0: ADD w9, w9, #0x18          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 24);
            // 0x028F04D4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 24));
            // 0x028F04D8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 24)).272
            label_5:
            // 0x028F04DC: LDP x3, x2, [x0]           | X3 = 0x1DE6000000000000; X2 = 0x120000;  //  | 
            // 0x028F04E0: MOV x0, x20                | X0 = this.type;//m1                     
            // 0x028F04E4: MOV x1, x19                | X1 = method;//m1                        
            // 0x028F04E8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x028F04EC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x028F04F0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x028F04F4: BR x3                      | X0 = sub_1DE6000000000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F04F8 (42927352), len: 176  VirtAddr: 0x028F04F8 RVA: 0x028F04F8 token: 100680306 methodIndex: 29590 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsGenericInstance()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F04F8: STP x20, x19, [sp, #-0x20]! | stack[1152921512894797968] = ???;  stack[1152921512894797976] = ???;  //  dest_result_addr=1152921512894797968 |  dest_result_addr=1152921512894797976
            // 0x028F04FC: STP x29, x30, [sp, #0x10]  | stack[1152921512894797984] = ???;  stack[1152921512894797992] = ???;  //  dest_result_addr=1152921512894797984 |  dest_result_addr=1152921512894797992
            // 0x028F0500: ADD x29, sp, #0x10         | X29 = (1152921512894797968 + 16) = 1152921512894797984 (0x10000001EE0018A0);
            // 0x028F0504: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0508: LDRB w8, [x20, #0xa19]     | W8 = (bool)static_value_037B8A19;       
            // 0x028F050C: MOV x19, x0                | X19 = 1152921512894810000 (0x10000001EE004790);//ML01
            // 0x028F0510: TBNZ w8, #0, #0x28f052c    | if (static_value_037B8A19 == true) goto label_0;
            // 0x028F0514: ADRP x8, #0x361f000        | X8 = 56750080 (0x361F000);              
            // 0x028F0518: LDR x8, [x8, #0x3a0]       | X8 = 0x2B92E40;                         
            // 0x028F051C: LDR w0, [x8]               | W0 = 0x2255;                            
            // 0x028F0520: BL #0x2782188              | X0 = sub_2782188( ?? 0x2255, ????);     
            // 0x028F0524: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0528: STRB w8, [x20, #0xa19]     | static_value_037B8A19 = true;            //  dest_result_addr=58427929
            label_0:
            // 0x028F052C: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0530: CBNZ x19, #0x28f0538       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2255, ????);     
            label_1:
            // 0x028F0538: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F053C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0540: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0544: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0548: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F054C: CBZ x9, #0x28f0578         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0550: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0554: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0558: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F055C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0560: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0564: B.EQ #0x28f0588            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0568: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F056C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0570: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0574: B.LO #0x28f055c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0578: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x028F057C: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0580: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0584: B #0x28f0594               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0588: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F058C: ADD x8, x8, x9, lsl #4     | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x028F0590: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_5:
            // 0x028F0594: LDP x2, x1, [x0]           | X2 = 0x27D8440000A00; X1 = 0x8000000;    //  | 
            // 0x028F0598: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F059C: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F05A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F05A4: BR x2                      | X0 = sub_27D8440000A00( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F05A8 (42927528), len: 180  VirtAddr: 0x028F05A8 RVA: 0x028F05A8 token: 100680307 methodIndex: 29591 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.KeyValuePair<string, ILRuntime.CLR.TypeSystem.IType>[] get_GenericArguments()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F05A8: STP x20, x19, [sp, #-0x20]! | stack[1152921512894918160] = ???;  stack[1152921512894918168] = ???;  //  dest_result_addr=1152921512894918160 |  dest_result_addr=1152921512894918168
            // 0x028F05AC: STP x29, x30, [sp, #0x10]  | stack[1152921512894918176] = ???;  stack[1152921512894918184] = ???;  //  dest_result_addr=1152921512894918176 |  dest_result_addr=1152921512894918184
            // 0x028F05B0: ADD x29, sp, #0x10         | X29 = (1152921512894918160 + 16) = 1152921512894918176 (0x10000001EE01EE20);
            // 0x028F05B4: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F05B8: LDRB w8, [x20, #0xa1a]     | W8 = (bool)static_value_037B8A1A;       
            // 0x028F05BC: MOV x19, x0                | X19 = 1152921512894930192 (0x10000001EE021D10);//ML01
            // 0x028F05C0: TBNZ w8, #0, #0x28f05dc    | if (static_value_037B8A1A == true) goto label_0;
            // 0x028F05C4: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x028F05C8: LDR x8, [x8, #0x948]       | X8 = 0x2B92E28;                         
            // 0x028F05CC: LDR w0, [x8]               | W0 = 0x224F;                            
            // 0x028F05D0: BL #0x2782188              | X0 = sub_2782188( ?? 0x224F, ????);     
            // 0x028F05D4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F05D8: STRB w8, [x20, #0xa1a]     | static_value_037B8A1A = true;            //  dest_result_addr=58427930
            label_0:
            // 0x028F05DC: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F05E0: CBNZ x19, #0x28f05e8       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F05E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224F, ????);     
            label_1:
            // 0x028F05E8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F05EC: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F05F0: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F05F4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F05F8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F05FC: CBZ x9, #0x28f0628         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0600: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0604: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0608: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F060C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0610: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0614: B.EQ #0x28f0638            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0618: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F061C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0620: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0624: B.LO #0x28f060c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0628: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x028F062C: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0630: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0634: B #0x28f0648               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0638: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F063C: ADD w9, w9, #1             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1);
            // 0x028F0640: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1));
            // 0x028F0644: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 1)).272
            label_5:
            // 0x028F0648: LDP x2, x1, [x0]           | X2 = 0xA00120000245D00; X1 = 0x27D844000; //  | 
            // 0x028F064C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0650: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0654: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0658: BR x2                      | X0 = sub_A00120000245D00( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F065C (42927708), len: 180  VirtAddr: 0x028F065C RVA: 0x028F065C token: 100680308 methodIndex: 29592 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_TypeForCLR()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F065C: STP x20, x19, [sp, #-0x20]! | stack[1152921512895038352] = ???;  stack[1152921512895038360] = ???;  //  dest_result_addr=1152921512895038352 |  dest_result_addr=1152921512895038360
            // 0x028F0660: STP x29, x30, [sp, #0x10]  | stack[1152921512895038368] = ???;  stack[1152921512895038376] = ???;  //  dest_result_addr=1152921512895038368 |  dest_result_addr=1152921512895038376
            // 0x028F0664: ADD x29, sp, #0x10         | X29 = (1152921512895038352 + 16) = 1152921512895038368 (0x10000001EE03C3A0);
            // 0x028F0668: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F066C: LDRB w8, [x20, #0xa1b]     | W8 = (bool)static_value_037B8A1B;       
            // 0x028F0670: MOV x19, x0                | X19 = 1152921512895050384 (0x10000001EE03F290);//ML01
            // 0x028F0674: TBNZ w8, #0, #0x28f0690    | if (static_value_037B8A1B == true) goto label_0;
            // 0x028F0678: ADRP x8, #0x3649000        | X8 = 56922112 (0x3649000);              
            // 0x028F067C: LDR x8, [x8, #0xd80]       | X8 = 0x2B92E5C;                         
            // 0x028F0680: LDR w0, [x8]               | W0 = 0x225C;                            
            // 0x028F0684: BL #0x2782188              | X0 = sub_2782188( ?? 0x225C, ????);     
            // 0x028F0688: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F068C: STRB w8, [x20, #0xa1b]     | static_value_037B8A1B = true;            //  dest_result_addr=58427931
            label_0:
            // 0x028F0690: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0694: CBNZ x19, #0x28f069c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0698: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x225C, ????);     
            label_1:
            // 0x028F069C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F06A0: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F06A4: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F06A8: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F06AC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F06B0: CBZ x9, #0x28f06dc         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F06B4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F06B8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F06BC: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F06C0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F06C4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F06C8: B.EQ #0x28f06ec            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F06CC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F06D0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F06D4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F06D8: B.LO #0x28f06c0            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F06DC: ORR w2, wzr, #2            | W2 = 2(0x2);                            
            // 0x028F06E0: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F06E4: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F06E8: B #0x28f06fc               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F06EC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F06F0: ADD w9, w9, #2             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2);
            // 0x028F06F4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2));
            // 0x028F06F8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 2)).272
            label_5:
            // 0x028F06FC: LDP x2, x1, [x0]           | X2 = 0x800000000; X1 = 0x1DE600000000;   //  | 
            // 0x028F0700: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0704: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0708: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F070C: BR x2                      | X0 = sub_800000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0710 (42927888), len: 180  VirtAddr: 0x028F0710 RVA: 0x028F0710 token: 100680309 methodIndex: 29593 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ByRefType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0710: STP x20, x19, [sp, #-0x20]! | stack[1152921512895158544] = ???;  stack[1152921512895158552] = ???;  //  dest_result_addr=1152921512895158544 |  dest_result_addr=1152921512895158552
            // 0x028F0714: STP x29, x30, [sp, #0x10]  | stack[1152921512895158560] = ???;  stack[1152921512895158568] = ???;  //  dest_result_addr=1152921512895158560 |  dest_result_addr=1152921512895158568
            // 0x028F0718: ADD x29, sp, #0x10         | X29 = (1152921512895158544 + 16) = 1152921512895158560 (0x10000001EE059920);
            // 0x028F071C: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0720: LDRB w8, [x20, #0xa1c]     | W8 = (bool)static_value_037B8A1C;       
            // 0x028F0724: MOV x19, x0                | X19 = 1152921512895170576 (0x10000001EE05C810);//ML01
            // 0x028F0728: TBNZ w8, #0, #0x28f0744    | if (static_value_037B8A1C == true) goto label_0;
            // 0x028F072C: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x028F0730: LDR x8, [x8, #0xa00]       | X8 = 0x2B92E1C;                         
            // 0x028F0734: LDR w0, [x8]               | W0 = 0x224C;                            
            // 0x028F0738: BL #0x2782188              | X0 = sub_2782188( ?? 0x224C, ????);     
            // 0x028F073C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0740: STRB w8, [x20, #0xa1c]     | static_value_037B8A1C = true;            //  dest_result_addr=58427932
            label_0:
            // 0x028F0744: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0748: CBNZ x19, #0x28f0750       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F074C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224C, ????);     
            label_1:
            // 0x028F0750: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0754: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0758: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F075C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0760: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0764: CBZ x9, #0x28f0790         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0768: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F076C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0770: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0774: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0778: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F077C: B.EQ #0x28f07a0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0780: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0784: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0788: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F078C: B.LO #0x28f0774            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0790: ORR w2, wzr, #6            | W2 = 6(0x6);                            
            // 0x028F0794: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0798: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F079C: B #0x28f07b0               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F07A0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F07A4: ADD w9, w9, #6             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 6);
            // 0x028F07A8: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 6));
            // 0x028F07AC: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 6)).272
            label_5:
            // 0x028F07B0: LDP x2, x1, [x0]           | X2 = 0x245D00000000; X1 = 0x27D8440000A0012; //  | 
            // 0x028F07B4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F07B8: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F07BC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F07C0: BR x2                      | X0 = sub_245D00000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F07C4 (42928068), len: 180  VirtAddr: 0x028F07C4 RVA: 0x028F07C4 token: 100680310 methodIndex: 29594 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ArrayType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F07C4: STP x20, x19, [sp, #-0x20]! | stack[1152921512895278736] = ???;  stack[1152921512895278744] = ???;  //  dest_result_addr=1152921512895278736 |  dest_result_addr=1152921512895278744
            // 0x028F07C8: STP x29, x30, [sp, #0x10]  | stack[1152921512895278752] = ???;  stack[1152921512895278760] = ???;  //  dest_result_addr=1152921512895278752 |  dest_result_addr=1152921512895278760
            // 0x028F07CC: ADD x29, sp, #0x10         | X29 = (1152921512895278736 + 16) = 1152921512895278752 (0x10000001EE076EA0);
            // 0x028F07D0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F07D4: LDRB w8, [x20, #0xa1d]     | W8 = (bool)static_value_037B8A1D;       
            // 0x028F07D8: MOV x19, x0                | X19 = 1152921512895290768 (0x10000001EE079D90);//ML01
            // 0x028F07DC: TBNZ w8, #0, #0x28f07f8    | if (static_value_037B8A1D == true) goto label_0;
            // 0x028F07E0: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x028F07E4: LDR x8, [x8, #0xbc8]       | X8 = 0x2B92E14;                         
            // 0x028F07E8: LDR w0, [x8]               | W0 = 0x224A;                            
            // 0x028F07EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x224A, ????);     
            // 0x028F07F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F07F4: STRB w8, [x20, #0xa1d]     | static_value_037B8A1D = true;            //  dest_result_addr=58427933
            label_0:
            // 0x028F07F8: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F07FC: CBNZ x19, #0x28f0804       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224A, ????);     
            label_1:
            // 0x028F0804: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0808: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F080C: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0810: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0814: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0818: CBZ x9, #0x28f0844         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F081C: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0820: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0824: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0828: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F082C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0830: B.EQ #0x28f0854            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0834: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0838: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F083C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0840: B.LO #0x28f0828            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0844: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            // 0x028F0848: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F084C: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0850: B #0x28f0864               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0854: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0858: ADD w9, w9, #7             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7);
            // 0x028F085C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7));
            // 0x028F0860: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7)).272
            label_5:
            // 0x028F0864: LDP x2, x1, [x0]           | X2 = 0x245D000000000000; X1 = 0x8440000A00120000; //  | 
            // 0x028F0868: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F086C: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0870: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0874: BR x2                      | X0 = sub_245D000000000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0878 (42928248), len: 180  VirtAddr: 0x028F0878 RVA: 0x028F0878 token: 100680311 methodIndex: 29595 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_FullName()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0878: STP x20, x19, [sp, #-0x20]! | stack[1152921512895398928] = ???;  stack[1152921512895398936] = ???;  //  dest_result_addr=1152921512895398928 |  dest_result_addr=1152921512895398936
            // 0x028F087C: STP x29, x30, [sp, #0x10]  | stack[1152921512895398944] = ???;  stack[1152921512895398952] = ???;  //  dest_result_addr=1152921512895398944 |  dest_result_addr=1152921512895398952
            // 0x028F0880: ADD x29, sp, #0x10         | X29 = (1152921512895398928 + 16) = 1152921512895398944 (0x10000001EE094420);
            // 0x028F0884: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0888: LDRB w8, [x20, #0xa1e]     | W8 = (bool)static_value_037B8A1E;       
            // 0x028F088C: MOV x19, x0                | X19 = 1152921512895410960 (0x10000001EE097310);//ML01
            // 0x028F0890: TBNZ w8, #0, #0x28f08ac    | if (static_value_037B8A1E == true) goto label_0;
            // 0x028F0894: ADRP x8, #0x3612000        | X8 = 56696832 (0x3612000);              
            // 0x028F0898: LDR x8, [x8, #0x740]       | X8 = 0x2B92E24;                         
            // 0x028F089C: LDR w0, [x8]               | W0 = 0x224E;                            
            // 0x028F08A0: BL #0x2782188              | X0 = sub_2782188( ?? 0x224E, ????);     
            // 0x028F08A4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F08A8: STRB w8, [x20, #0xa1e]     | static_value_037B8A1E = true;            //  dest_result_addr=58427934
            label_0:
            // 0x028F08AC: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F08B0: CBNZ x19, #0x28f08b8       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F08B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224E, ????);     
            label_1:
            // 0x028F08B8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F08BC: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F08C0: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F08C4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F08C8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F08CC: CBZ x9, #0x28f08f8         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F08D0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F08D4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F08D8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F08DC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F08E0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F08E4: B.EQ #0x28f0908            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F08E8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F08EC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F08F0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F08F4: B.LO #0x28f08dc            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F08F8: ORR w2, wzr, #8            | W2 = 8(0x8);                            
            // 0x028F08FC: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0900: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0904: B #0x28f0918               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0908: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F090C: ADD w9, w9, #8             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 8);
            // 0x028F0910: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 8));
            // 0x028F0914: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 8)).272
            label_5:
            // 0x028F0918: LDP x2, x1, [x0]           | X2 = 0x120000245D0000; X1 = 0x27D8440000A; //  | 
            // 0x028F091C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0920: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0924: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0928: BR x2                      | X0 = sub_120000245D0000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F092C (42928428), len: 180  VirtAddr: 0x028F092C RVA: 0x028F092C token: 100680312 methodIndex: 29596 delegateWrapperIndex: 0 methodInvoker: 0
        public string get_Name()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F092C: STP x20, x19, [sp, #-0x20]! | stack[1152921512895519120] = ???;  stack[1152921512895519128] = ???;  //  dest_result_addr=1152921512895519120 |  dest_result_addr=1152921512895519128
            // 0x028F0930: STP x29, x30, [sp, #0x10]  | stack[1152921512895519136] = ???;  stack[1152921512895519144] = ???;  //  dest_result_addr=1152921512895519136 |  dest_result_addr=1152921512895519144
            // 0x028F0934: ADD x29, sp, #0x10         | X29 = (1152921512895519120 + 16) = 1152921512895519136 (0x10000001EE0B19A0);
            // 0x028F0938: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F093C: LDRB w8, [x20, #0xa1f]     | W8 = (bool)static_value_037B8A1F;       
            // 0x028F0940: MOV x19, x0                | X19 = 1152921512895531152 (0x10000001EE0B4890);//ML01
            // 0x028F0944: TBNZ w8, #0, #0x28f0960    | if (static_value_037B8A1F == true) goto label_0;
            // 0x028F0948: ADRP x8, #0x363b000        | X8 = 56864768 (0x363B000);              
            // 0x028F094C: LDR x8, [x8, #0x8a8]       | X8 = 0x2B92E54;                         
            // 0x028F0950: LDR w0, [x8]               | W0 = 0x225A;                            
            // 0x028F0954: BL #0x2782188              | X0 = sub_2782188( ?? 0x225A, ????);     
            // 0x028F0958: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F095C: STRB w8, [x20, #0xa1f]     | static_value_037B8A1F = true;            //  dest_result_addr=58427935
            label_0:
            // 0x028F0960: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0964: CBNZ x19, #0x28f096c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x225A, ????);     
            label_1:
            // 0x028F096C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0970: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0974: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0978: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F097C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0980: CBZ x9, #0x28f09ac         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0984: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0988: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F098C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0990: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0994: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0998: B.EQ #0x28f09bc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F099C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F09A0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F09A4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F09A8: B.LO #0x28f0990            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F09AC: MOVZ w2, #0x9              | W2 = 9 (0x9);//ML01                     
            // 0x028F09B0: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F09B4: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F09B8: B #0x28f09cc               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F09BC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F09C0: ADD w9, w9, #9             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 9);
            // 0x028F09C4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 9));
            // 0x028F09C8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 9)).272
            label_5:
            // 0x028F09CC: LDP x2, x1, [x0]           | X2 = 0x800000000027D; X1 = 0x1DE6000000000000; //  | 
            // 0x028F09D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F09D4: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F09D8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F09DC: BR x2                      | X0 = sub_800000000027D( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F09E0 (42928608), len: 180  VirtAddr: 0x028F09E0 RVA: 0x028F09E0 token: 100680313 methodIndex: 29597 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsValueType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F09E0: STP x20, x19, [sp, #-0x20]! | stack[1152921512895639312] = ???;  stack[1152921512895639320] = ???;  //  dest_result_addr=1152921512895639312 |  dest_result_addr=1152921512895639320
            // 0x028F09E4: STP x29, x30, [sp, #0x10]  | stack[1152921512895639328] = ???;  stack[1152921512895639336] = ???;  //  dest_result_addr=1152921512895639328 |  dest_result_addr=1152921512895639336
            // 0x028F09E8: ADD x29, sp, #0x10         | X29 = (1152921512895639312 + 16) = 1152921512895639328 (0x10000001EE0CEF20);
            // 0x028F09EC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F09F0: LDRB w8, [x20, #0xa20]     | W8 = (bool)static_value_037B8A20;       
            // 0x028F09F4: MOV x19, x0                | X19 = 1152921512895651344 (0x10000001EE0D1E10);//ML01
            // 0x028F09F8: TBNZ w8, #0, #0x28f0a14    | if (static_value_037B8A20 == true) goto label_0;
            // 0x028F09FC: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x028F0A00: LDR x8, [x8, #0xc50]       | X8 = 0x2B92E50;                         
            // 0x028F0A04: LDR w0, [x8]               | W0 = 0x2259;                            
            // 0x028F0A08: BL #0x2782188              | X0 = sub_2782188( ?? 0x2259, ????);     
            // 0x028F0A0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0A10: STRB w8, [x20, #0xa20]     | static_value_037B8A20 = true;            //  dest_result_addr=58427936
            label_0:
            // 0x028F0A14: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0A18: CBNZ x19, #0x28f0a20       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0A1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2259, ????);     
            label_1:
            // 0x028F0A20: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0A24: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0A28: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0A2C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0A30: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0A34: CBZ x9, #0x28f0a60         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0A38: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0A3C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0A40: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0A44: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0A48: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0A4C: B.EQ #0x28f0a70            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0A50: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0A54: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0A58: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0A5C: B.LO #0x28f0a44            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0A60: ORR w2, wzr, #0xc          | W2 = 12(0xC);                           
            // 0x028F0A64: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0A68: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0A6C: B #0x28f0a80               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0A70: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0A74: ADD w9, w9, #0xc           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 12);
            // 0x028F0A78: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 12));
            // 0x028F0A7C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 12)).272
            label_5:
            // 0x028F0A80: LDP x2, x1, [x0]           | X2 = 0x800000000027D84; X1 = 0xE600000000000000; //  | 
            // 0x028F0A84: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0A88: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0A8C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0A90: BR x2                      | X0 = sub_800000000027D84( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0A94 (42928788), len: 180  VirtAddr: 0x028F0A94 RVA: 0x028F0A94 token: 100680314 methodIndex: 29598 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsPrimitive()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0A94: STP x20, x19, [sp, #-0x20]! | stack[1152921512895759504] = ???;  stack[1152921512895759512] = ???;  //  dest_result_addr=1152921512895759504 |  dest_result_addr=1152921512895759512
            // 0x028F0A98: STP x29, x30, [sp, #0x10]  | stack[1152921512895759520] = ???;  stack[1152921512895759528] = ???;  //  dest_result_addr=1152921512895759520 |  dest_result_addr=1152921512895759528
            // 0x028F0A9C: ADD x29, sp, #0x10         | X29 = (1152921512895759504 + 16) = 1152921512895759520 (0x10000001EE0EC4A0);
            // 0x028F0AA0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0AA4: LDRB w8, [x20, #0xa21]     | W8 = (bool)static_value_037B8A21;       
            // 0x028F0AA8: MOV x19, x0                | X19 = 1152921512895771536 (0x10000001EE0EF390);//ML01
            // 0x028F0AAC: TBNZ w8, #0, #0x28f0ac8    | if (static_value_037B8A21 == true) goto label_0;
            // 0x028F0AB0: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x028F0AB4: LDR x8, [x8, #0xf10]       | X8 = 0x2B92E4C;                         
            // 0x028F0AB8: LDR w0, [x8]               | W0 = 0x2258;                            
            // 0x028F0ABC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2258, ????);     
            // 0x028F0AC0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0AC4: STRB w8, [x20, #0xa21]     | static_value_037B8A21 = true;            //  dest_result_addr=58427937
            label_0:
            // 0x028F0AC8: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0ACC: CBNZ x19, #0x28f0ad4       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0AD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2258, ????);     
            label_1:
            // 0x028F0AD4: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0AD8: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0ADC: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0AE0: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0AE4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0AE8: CBZ x9, #0x28f0b14         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0AEC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0AF0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0AF4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0AF8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0AFC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0B00: B.EQ #0x28f0b24            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0B04: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0B08: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0B0C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0B10: B.LO #0x28f0af8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0B14: ORR w2, wzr, #0xe          | W2 = 14(0xE);                           
            // 0x028F0B18: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0B1C: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0B20: B #0x28f0b34               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0B24: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0B28: ADD w9, w9, #0xe           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 14);
            // 0x028F0B2C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 14));
            // 0x028F0B30: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 14)).272
            label_5:
            // 0x028F0B34: LDP x2, x1, [x0]           | X2 = 0x27D8440; X1 = 0x8;                //  | 
            // 0x028F0B38: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0B3C: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0B40: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0B44: BR x2                      | return this.type.get_tangentMode();     
            return this.type.tangentMode;
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0B48 (42928968), len: 180  VirtAddr: 0x028F0B48 RVA: 0x028F0B48 token: 100680315 methodIndex: 29599 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsEnum()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0B48: STP x20, x19, [sp, #-0x20]! | stack[1152921512895879696] = ???;  stack[1152921512895879704] = ???;  //  dest_result_addr=1152921512895879696 |  dest_result_addr=1152921512895879704
            // 0x028F0B4C: STP x29, x30, [sp, #0x10]  | stack[1152921512895879712] = ???;  stack[1152921512895879720] = ???;  //  dest_result_addr=1152921512895879712 |  dest_result_addr=1152921512895879720
            // 0x028F0B50: ADD x29, sp, #0x10         | X29 = (1152921512895879696 + 16) = 1152921512895879712 (0x10000001EE109A20);
            // 0x028F0B54: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0B58: LDRB w8, [x20, #0xa22]     | W8 = (bool)static_value_037B8A22;       
            // 0x028F0B5C: MOV x19, x0                | X19 = 1152921512895891728 (0x10000001EE10C910);//ML01
            // 0x028F0B60: TBNZ w8, #0, #0x28f0b7c    | if (static_value_037B8A22 == true) goto label_0;
            // 0x028F0B64: ADRP x8, #0x3613000        | X8 = 56700928 (0x3613000);              
            // 0x028F0B68: LDR x8, [x8, #0xd08]       | X8 = 0x2B92E3C;                         
            // 0x028F0B6C: LDR w0, [x8]               | W0 = 0x2254;                            
            // 0x028F0B70: BL #0x2782188              | X0 = sub_2782188( ?? 0x2254, ????);     
            // 0x028F0B74: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0B78: STRB w8, [x20, #0xa22]     | static_value_037B8A22 = true;            //  dest_result_addr=58427938
            label_0:
            // 0x028F0B7C: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0B80: CBNZ x19, #0x28f0b88       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0B84: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2254, ????);     
            label_1:
            // 0x028F0B88: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0B8C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0B90: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0B94: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0B98: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0B9C: CBZ x9, #0x28f0bc8         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0BA0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0BA4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0BA8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0BAC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0BB0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0BB4: B.EQ #0x28f0bd8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0BB8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0BBC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0BC0: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0BC4: B.LO #0x28f0bac            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0BC8: ORR w2, wzr, #0xf          | W2 = 15(0xF);                           
            // 0x028F0BCC: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0BD0: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0BD4: B #0x28f0be8               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0BD8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0BDC: ADD w9, w9, #0xf           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 15);
            // 0x028F0BE0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 15));
            // 0x028F0BE4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 15)).272
            label_5:
            // 0x028F0BE8: LDP x2, x1, [x0]           | X2 = 0x27D8440000A0012; X1 = 0x800000000; //  | 
            // 0x028F0BEC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0BF0: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0BF4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0BF8: BR x2                      | X0 = sub_27D8440000A0012( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0BFC (42929148), len: 180  VirtAddr: 0x028F0BFC RVA: 0x028F0BFC token: 100680316 methodIndex: 29600 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsDelegate()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0BFC: STP x20, x19, [sp, #-0x20]! | stack[1152921512895999888] = ???;  stack[1152921512895999896] = ???;  //  dest_result_addr=1152921512895999888 |  dest_result_addr=1152921512895999896
            // 0x028F0C00: STP x29, x30, [sp, #0x10]  | stack[1152921512895999904] = ???;  stack[1152921512895999912] = ???;  //  dest_result_addr=1152921512895999904 |  dest_result_addr=1152921512895999912
            // 0x028F0C04: ADD x29, sp, #0x10         | X29 = (1152921512895999888 + 16) = 1152921512895999904 (0x10000001EE126FA0);
            // 0x028F0C08: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0C0C: LDRB w8, [x20, #0xa23]     | W8 = (bool)static_value_037B8A23;       
            // 0x028F0C10: MOV x19, x0                | X19 = 1152921512896011920 (0x10000001EE129E90);//ML01
            // 0x028F0C14: TBNZ w8, #0, #0x28f0c30    | if (static_value_037B8A23 == true) goto label_0;
            // 0x028F0C18: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x028F0C1C: LDR x8, [x8, #0xec0]       | X8 = 0x2B92E38;                         
            // 0x028F0C20: LDR w0, [x8]               | W0 = 0x2253;                            
            // 0x028F0C24: BL #0x2782188              | X0 = sub_2782188( ?? 0x2253, ????);     
            // 0x028F0C28: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0C2C: STRB w8, [x20, #0xa23]     | static_value_037B8A23 = true;            //  dest_result_addr=58427939
            label_0:
            // 0x028F0C30: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0C34: CBNZ x19, #0x28f0c3c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0C38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2253, ????);     
            label_1:
            // 0x028F0C3C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0C40: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0C44: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0C48: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0C4C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0C50: CBZ x9, #0x28f0c7c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0C54: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0C58: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0C5C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0C60: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0C64: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0C68: B.EQ #0x28f0c8c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0C6C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0C70: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0C74: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0C78: B.LO #0x28f0c60            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0C7C: MOVZ w2, #0xd              | W2 = 13 (0xD);//ML01                    
            // 0x028F0C80: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0C84: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0C88: B #0x28f0c9c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0C8C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0C90: ADD w9, w9, #0xd           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 13);
            // 0x028F0C94: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 13));
            // 0x028F0C98: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 13)).272
            label_5:
            // 0x028F0C9C: LDP x2, x1, [x0]           | X2 = 0x7D8440000A001200; X1 = 0x80000000002; //  | 
            // 0x028F0CA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0CA4: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0CA8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0CAC: BR x2                      | X0 = sub_7D8440000A001200( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0CB0 (42929328), len: 180  VirtAddr: 0x028F0CB0 RVA: 0x028F0CB0 token: 100680317 methodIndex: 29601 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Runtime.Enviorment.AppDomain get_AppDomain()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0CB0: STP x20, x19, [sp, #-0x20]! | stack[1152921512896120080] = ???;  stack[1152921512896120088] = ???;  //  dest_result_addr=1152921512896120080 |  dest_result_addr=1152921512896120088
            // 0x028F0CB4: STP x29, x30, [sp, #0x10]  | stack[1152921512896120096] = ???;  stack[1152921512896120104] = ???;  //  dest_result_addr=1152921512896120096 |  dest_result_addr=1152921512896120104
            // 0x028F0CB8: ADD x29, sp, #0x10         | X29 = (1152921512896120080 + 16) = 1152921512896120096 (0x10000001EE144520);
            // 0x028F0CBC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0CC0: LDRB w8, [x20, #0xa24]     | W8 = (bool)static_value_037B8A24;       
            // 0x028F0CC4: MOV x19, x0                | X19 = 1152921512896132112 (0x10000001EE147410);//ML01
            // 0x028F0CC8: TBNZ w8, #0, #0x28f0ce4    | if (static_value_037B8A24 == true) goto label_0;
            // 0x028F0CCC: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
            // 0x028F0CD0: LDR x8, [x8, #0xce0]       | X8 = 0x2B92E0C;                         
            // 0x028F0CD4: LDR w0, [x8]               | W0 = 0x2248;                            
            // 0x028F0CD8: BL #0x2782188              | X0 = sub_2782188( ?? 0x2248, ????);     
            // 0x028F0CDC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0CE0: STRB w8, [x20, #0xa24]     | static_value_037B8A24 = true;            //  dest_result_addr=58427940
            label_0:
            // 0x028F0CE4: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0CE8: CBNZ x19, #0x28f0cf0       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0CEC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2248, ????);     
            label_1:
            // 0x028F0CF0: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0CF4: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0CF8: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0CFC: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0D00: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0D04: CBZ x9, #0x28f0d30         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0D08: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0D0C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0D10: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0D14: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0D18: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0D1C: B.EQ #0x28f0d40            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0D20: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0D24: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0D28: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0D2C: B.LO #0x28f0d14            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0D30: MOVZ w2, #0x15             | W2 = 21 (0x15);//ML01                   
            // 0x028F0D34: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0D38: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0D3C: B #0x28f0d50               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0D40: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0D44: ADD w9, w9, #0x15          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 21);
            // 0x028F0D48: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 21));
            // 0x028F0D4C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 21)).272
            label_5:
            // 0x028F0D50: LDP x2, x1, [x0]           | X2 = 0x4; X1 = 0xA00120000245D;          //  | 
            // 0x028F0D54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0D58: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0D5C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0D60: BR x2                      | X0 = sub_4( ?? this.type, ????);        
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0D64 (42929508), len: 180  VirtAddr: 0x028F0D64 RVA: 0x028F0D64 token: 100680318 methodIndex: 29602 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type get_ReflectionType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0D64: STP x20, x19, [sp, #-0x20]! | stack[1152921512896240272] = ???;  stack[1152921512896240280] = ???;  //  dest_result_addr=1152921512896240272 |  dest_result_addr=1152921512896240280
            // 0x028F0D68: STP x29, x30, [sp, #0x10]  | stack[1152921512896240288] = ???;  stack[1152921512896240296] = ???;  //  dest_result_addr=1152921512896240288 |  dest_result_addr=1152921512896240296
            // 0x028F0D6C: ADD x29, sp, #0x10         | X29 = (1152921512896240272 + 16) = 1152921512896240288 (0x10000001EE161AA0);
            // 0x028F0D70: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0D74: LDRB w8, [x20, #0xa25]     | W8 = (bool)static_value_037B8A25;       
            // 0x028F0D78: MOV x19, x0                | X19 = 1152921512896252304 (0x10000001EE164990);//ML01
            // 0x028F0D7C: TBNZ w8, #0, #0x28f0d98    | if (static_value_037B8A25 == true) goto label_0;
            // 0x028F0D80: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x028F0D84: LDR x8, [x8, #0xf78]       | X8 = 0x2B92E58;                         
            // 0x028F0D88: LDR w0, [x8]               | W0 = 0x225B;                            
            // 0x028F0D8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x225B, ????);     
            // 0x028F0D90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0D94: STRB w8, [x20, #0xa25]     | static_value_037B8A25 = true;            //  dest_result_addr=58427941
            label_0:
            // 0x028F0D98: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0D9C: CBNZ x19, #0x28f0da4       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0DA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x225B, ????);     
            label_1:
            // 0x028F0DA4: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0DA8: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0DAC: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0DB0: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0DB4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0DB8: CBZ x9, #0x28f0de4         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0DBC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0DC0: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0DC4: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0DC8: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0DCC: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0DD0: B.EQ #0x28f0df4            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0DD4: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0DD8: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0DDC: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0DE0: B.LO #0x28f0dc8            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0DE4: ORR w2, wzr, #3            | W2 = 3(0x3);                            
            // 0x028F0DE8: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0DEC: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0DF0: B #0x28f0e04               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0DF4: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0DF8: ADD w9, w9, #3             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3);
            // 0x028F0DFC: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3));
            // 0x028F0E00: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 3)).272
            label_5:
            // 0x028F0E04: LDP x2, x1, [x0]           | X2 = 0x80000000002; X1 = 0x1DE60000000000; //  | 
            // 0x028F0E08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0E0C: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0E10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0E14: BR x2                      | X0 = sub_80000000002( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFF08 (42925832), len: 180  VirtAddr: 0x028EFF08 RVA: 0x028EFF08 token: 100680319 methodIndex: 29603 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_BaseType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EFF08: STP x20, x19, [sp, #-0x20]! | stack[1152921512896360464] = ???;  stack[1152921512896360472] = ???;  //  dest_result_addr=1152921512896360464 |  dest_result_addr=1152921512896360472
            // 0x028EFF0C: STP x29, x30, [sp, #0x10]  | stack[1152921512896360480] = ???;  stack[1152921512896360488] = ???;  //  dest_result_addr=1152921512896360480 |  dest_result_addr=1152921512896360488
            // 0x028EFF10: ADD x29, sp, #0x10         | X29 = (1152921512896360464 + 16) = 1152921512896360480 (0x10000001EE17F020);
            // 0x028EFF14: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EFF18: LDRB w8, [x20, #0xa26]     | W8 = (bool)static_value_037B8A26;       
            // 0x028EFF1C: MOV x19, x0                | X19 = 1152921512896372496 (0x10000001EE181F10);//ML01
            // 0x028EFF20: TBNZ w8, #0, #0x28eff3c    | if (static_value_037B8A26 == true) goto label_0;
            // 0x028EFF24: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x028EFF28: LDR x8, [x8, #0x78]        | X8 = 0x2B92E18;                         
            // 0x028EFF2C: LDR w0, [x8]               | W0 = 0x224B;                            
            // 0x028EFF30: BL #0x2782188              | X0 = sub_2782188( ?? 0x224B, ????);     
            // 0x028EFF34: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFF38: STRB w8, [x20, #0xa26]     | static_value_037B8A26 = true;            //  dest_result_addr=58427942
            label_0:
            // 0x028EFF3C: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028EFF40: CBNZ x19, #0x28eff48       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EFF44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224B, ????);     
            label_1:
            // 0x028EFF48: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028EFF4C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFF50: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028EFF54: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028EFF58: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028EFF5C: CBZ x9, #0x28eff88         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028EFF60: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028EFF64: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028EFF68: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028EFF6C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028EFF70: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028EFF74: B.EQ #0x28eff98            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028EFF78: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028EFF7C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028EFF80: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028EFF84: B.LO #0x28eff6c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028EFF88: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x028EFF8C: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028EFF90: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028EFF94: B #0x28effa8               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028EFF98: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028EFF9C: ADD w9, w9, #4             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4);
            // 0x028EFFA0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4));
            // 0x028EFFA4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 4)).272
            label_5:
            // 0x028EFFA8: LDP x2, x1, [x0]           | X2 = 0x245D0000000000; X1 = 0x7D8440000A001200; //  | 
            // 0x028EFFAC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028EFFB0: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028EFFB4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028EFFB8: BR x2                      | X0 = sub_245D0000000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028EFFBC (42926012), len: 180  VirtAddr: 0x028EFFBC RVA: 0x028EFFBC token: 100680320 methodIndex: 29604 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType[] get_Implements()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028EFFBC: STP x20, x19, [sp, #-0x20]! | stack[1152921512896480656] = ???;  stack[1152921512896480664] = ???;  //  dest_result_addr=1152921512896480656 |  dest_result_addr=1152921512896480664
            // 0x028EFFC0: STP x29, x30, [sp, #0x10]  | stack[1152921512896480672] = ???;  stack[1152921512896480680] = ???;  //  dest_result_addr=1152921512896480672 |  dest_result_addr=1152921512896480680
            // 0x028EFFC4: ADD x29, sp, #0x10         | X29 = (1152921512896480656 + 16) = 1152921512896480672 (0x10000001EE19C5A0);
            // 0x028EFFC8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028EFFCC: LDRB w8, [x20, #0xa27]     | W8 = (bool)static_value_037B8A27;       
            // 0x028EFFD0: MOV x19, x0                | X19 = 1152921512896492688 (0x10000001EE19F490);//ML01
            // 0x028EFFD4: TBNZ w8, #0, #0x28efff0    | if (static_value_037B8A27 == true) goto label_0;
            // 0x028EFFD8: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x028EFFDC: LDR x8, [x8, #0xc60]       | X8 = 0x2B92E30;                         
            // 0x028EFFE0: LDR w0, [x8]               | W0 = 0x2251;                            
            // 0x028EFFE4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2251, ????);     
            // 0x028EFFE8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028EFFEC: STRB w8, [x20, #0xa27]     | static_value_037B8A27 = true;            //  dest_result_addr=58427943
            label_0:
            // 0x028EFFF0: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028EFFF4: CBNZ x19, #0x28efffc       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028EFFF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2251, ????);     
            label_1:
            // 0x028EFFFC: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0000: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0004: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0008: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F000C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0010: CBZ x9, #0x28f003c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0014: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0018: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F001C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0020: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0024: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0028: B.EQ #0x28f004c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F002C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0030: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0034: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0038: B.LO #0x28f0020            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F003C: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x028F0040: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0044: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0048: B #0x28f005c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F004C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0050: ADD w9, w9, #5             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5);
            // 0x028F0054: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5));
            // 0x028F0058: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5)).272
            label_5:
            // 0x028F005C: LDP x2, x1, [x0]           | X2 = 0x40000A0012000024; X1 = 0x800000000027D84; //  | 
            // 0x028F0060: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0064: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0068: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F006C: BR x2                      | X0 = sub_40000A0012000024( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0E18 (42929688), len: 180  VirtAddr: 0x028F0E18 RVA: 0x028F0E18 token: 100680321 methodIndex: 29605 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasGenericParameter()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0E18: STP x20, x19, [sp, #-0x20]! | stack[1152921512896600848] = ???;  stack[1152921512896600856] = ???;  //  dest_result_addr=1152921512896600848 |  dest_result_addr=1152921512896600856
            // 0x028F0E1C: STP x29, x30, [sp, #0x10]  | stack[1152921512896600864] = ???;  stack[1152921512896600872] = ???;  //  dest_result_addr=1152921512896600864 |  dest_result_addr=1152921512896600872
            // 0x028F0E20: ADD x29, sp, #0x10         | X29 = (1152921512896600848 + 16) = 1152921512896600864 (0x10000001EE1B9B20);
            // 0x028F0E24: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0E28: LDRB w8, [x20, #0xa28]     | W8 = (bool)static_value_037B8A28;       
            // 0x028F0E2C: MOV x19, x0                | X19 = 1152921512896612880 (0x10000001EE1BCA10);//ML01
            // 0x028F0E30: TBNZ w8, #0, #0x28f0e4c    | if (static_value_037B8A28 == true) goto label_0;
            // 0x028F0E34: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
            // 0x028F0E38: LDR x8, [x8, #0x3b0]       | X8 = 0x2B92E2C;                         
            // 0x028F0E3C: LDR w0, [x8]               | W0 = 0x2250;                            
            // 0x028F0E40: BL #0x2782188              | X0 = sub_2782188( ?? 0x2250, ????);     
            // 0x028F0E44: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0E48: STRB w8, [x20, #0xa28]     | static_value_037B8A28 = true;            //  dest_result_addr=58427944
            label_0:
            // 0x028F0E4C: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0E50: CBNZ x19, #0x28f0e58       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0E54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2250, ????);     
            label_1:
            // 0x028F0E58: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0E5C: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0E60: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0E64: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0E68: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0E6C: CBZ x9, #0x28f0e98         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0E70: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0E74: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0E78: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0E7C: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0E80: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0E84: B.EQ #0x28f0ea8            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0E88: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0E8C: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0E90: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0E94: B.LO #0x28f0e7c            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0E98: MOVZ w2, #0x13             | W2 = 19 (0x13);//ML01                   
            // 0x028F0E9C: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0EA0: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0EA4: B #0x28f0eb8               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0EA8: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0EAC: ADD w9, w9, #0x13          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 19);
            // 0x028F0EB0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 19));
            // 0x028F0EB4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 19)).272
            label_5:
            // 0x028F0EB8: LDP x2, x1, [x0]           | X2 = 0xA00120000245D; X1 = 0x27D8440;    //  | 
            // 0x028F0EBC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0EC0: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0EC4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0EC8: BR x2                      | X0 = sub_A00120000245D( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0ECC (42929868), len: 180  VirtAddr: 0x028F0ECC RVA: 0x028F0ECC token: 100680322 methodIndex: 29606 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsGenericParameter()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0ECC: STP x20, x19, [sp, #-0x20]! | stack[1152921512896721040] = ???;  stack[1152921512896721048] = ???;  //  dest_result_addr=1152921512896721040 |  dest_result_addr=1152921512896721048
            // 0x028F0ED0: STP x29, x30, [sp, #0x10]  | stack[1152921512896721056] = ???;  stack[1152921512896721064] = ???;  //  dest_result_addr=1152921512896721056 |  dest_result_addr=1152921512896721064
            // 0x028F0ED4: ADD x29, sp, #0x10         | X29 = (1152921512896721040 + 16) = 1152921512896721056 (0x10000001EE1D70A0);
            // 0x028F0ED8: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0EDC: LDRB w8, [x20, #0xa29]     | W8 = (bool)static_value_037B8A29;       
            // 0x028F0EE0: MOV x19, x0                | X19 = 1152921512896733072 (0x10000001EE1D9F90);//ML01
            // 0x028F0EE4: TBNZ w8, #0, #0x28f0f00    | if (static_value_037B8A29 == true) goto label_0;
            // 0x028F0EE8: ADRP x8, #0x3678000        | X8 = 57114624 (0x3678000);              
            // 0x028F0EEC: LDR x8, [x8, #0x7b8]       | X8 = 0x2B92E44;                         
            // 0x028F0EF0: LDR w0, [x8]               | W0 = 0x2256;                            
            // 0x028F0EF4: BL #0x2782188              | X0 = sub_2782188( ?? 0x2256, ????);     
            // 0x028F0EF8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0EFC: STRB w8, [x20, #0xa29]     | static_value_037B8A29 = true;            //  dest_result_addr=58427945
            label_0:
            // 0x028F0F00: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0F04: CBNZ x19, #0x28f0f0c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0F08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2256, ????);     
            label_1:
            // 0x028F0F0C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0F10: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0F14: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0F18: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0F1C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0F20: CBZ x9, #0x28f0f4c         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0F24: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0F28: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0F2C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0F30: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0F34: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0F38: B.EQ #0x28f0f5c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0F3C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0F40: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F0F44: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F0F48: B.LO #0x28f0f30            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F0F4C: MOVZ w2, #0x14             | W2 = 20 (0x14);//ML01                   
            // 0x028F0F50: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F0F54: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F0F58: B #0x28f0f6c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F0F5C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F0F60: ADD w9, w9, #0x14          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 20);
            // 0x028F0F64: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 20));
            // 0x028F0F68: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 20)).272
            label_5:
            // 0x028F0F6C: LDP x2, x1, [x0]           | X2 = 0x27D8440000A; X1 = 0x80000;        //  | 
            // 0x028F0F70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F0F74: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F0F78: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F0F7C: BR x2                      | X0 = sub_27D8440000A( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0F80 (42930048), len: 8  VirtAddr: 0x028F0F80 RVA: 0x028F0F80 token: 100680323 methodIndex: 29607 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsArray()
        {
            //
            // Disasemble & Code
            // 0x028F0F80: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x028F0F84: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x028F0F88 (42930056), len: 180  VirtAddr: 0x028F0F88 RVA: 0x028F0F88 token: 100680324 methodIndex: 29608 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsByRef()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F0F88: STP x20, x19, [sp, #-0x20]! | stack[1152921512896953232] = ???;  stack[1152921512896953240] = ???;  //  dest_result_addr=1152921512896953232 |  dest_result_addr=1152921512896953240
            // 0x028F0F8C: STP x29, x30, [sp, #0x10]  | stack[1152921512896953248] = ???;  stack[1152921512896953256] = ???;  //  dest_result_addr=1152921512896953248 |  dest_result_addr=1152921512896953256
            // 0x028F0F90: ADD x29, sp, #0x10         | X29 = (1152921512896953232 + 16) = 1152921512896953248 (0x10000001EE20FBA0);
            // 0x028F0F94: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F0F98: LDRB w8, [x20, #0xa2a]     | W8 = (bool)static_value_037B8A2A;       
            // 0x028F0F9C: MOV x19, x0                | X19 = 1152921512896965264 (0x10000001EE212A90);//ML01
            // 0x028F0FA0: TBNZ w8, #0, #0x28f0fbc    | if (static_value_037B8A2A == true) goto label_0;
            // 0x028F0FA4: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x028F0FA8: LDR x8, [x8, #0x2f8]       | X8 = 0x2B92E34;                         
            // 0x028F0FAC: LDR w0, [x8]               | W0 = 0x2252;                            
            // 0x028F0FB0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2252, ????);     
            // 0x028F0FB4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F0FB8: STRB w8, [x20, #0xa2a]     | static_value_037B8A2A = true;            //  dest_result_addr=58427946
            label_0:
            // 0x028F0FBC: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F0FC0: CBNZ x19, #0x28f0fc8       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F0FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2252, ????);     
            label_1:
            // 0x028F0FC8: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F0FCC: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0FD0: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F0FD4: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F0FD8: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F0FDC: CBZ x9, #0x28f1008         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F0FE0: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F0FE4: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F0FE8: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F0FEC: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F0FF0: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F0FF4: B.EQ #0x28f1018            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F0FF8: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F0FFC: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F1000: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F1004: B.LO #0x28f0fec            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F1008: ORR w2, wzr, #0x10         | W2 = 16(0x10);                          
            // 0x028F100C: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F1010: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F1014: B #0x28f1028               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F1018: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F101C: ADD w9, w9, #0x10          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 16);
            // 0x028F1020: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 16));
            // 0x028F1024: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 16)).272
            label_5:
            // 0x028F1028: LDP x2, x1, [x0]           | X2 = 0x8440000A00120000; X1 = 0x800000000027D; //  | 
            // 0x028F102C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F1030: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F1034: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F1038: BR x2                      | X0 = sub_8440000A00120000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F103C (42930236), len: 180  VirtAddr: 0x028F103C RVA: 0x028F103C token: 100680325 methodIndex: 29609 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsInterface()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F103C: STP x20, x19, [sp, #-0x20]! | stack[1152921512897073424] = ???;  stack[1152921512897073432] = ???;  //  dest_result_addr=1152921512897073424 |  dest_result_addr=1152921512897073432
            // 0x028F1040: STP x29, x30, [sp, #0x10]  | stack[1152921512897073440] = ???;  stack[1152921512897073448] = ???;  //  dest_result_addr=1152921512897073440 |  dest_result_addr=1152921512897073448
            // 0x028F1044: ADD x29, sp, #0x10         | X29 = (1152921512897073424 + 16) = 1152921512897073440 (0x10000001EE22D120);
            // 0x028F1048: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F104C: LDRB w8, [x20, #0xa2b]     | W8 = (bool)static_value_037B8A2B;       
            // 0x028F1050: MOV x19, x0                | X19 = 1152921512897085456 (0x10000001EE230010);//ML01
            // 0x028F1054: TBNZ w8, #0, #0x28f1070    | if (static_value_037B8A2B == true) goto label_0;
            // 0x028F1058: ADRP x8, #0x3631000        | X8 = 56823808 (0x3631000);              
            // 0x028F105C: LDR x8, [x8, #0xab0]       | X8 = 0x2B92E48;                         
            // 0x028F1060: LDR w0, [x8]               | W0 = 0x2257;                            
            // 0x028F1064: BL #0x2782188              | X0 = sub_2782188( ?? 0x2257, ????);     
            // 0x028F1068: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F106C: STRB w8, [x20, #0xa2b]     | static_value_037B8A2B = true;            //  dest_result_addr=58427947
            label_0:
            // 0x028F1070: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F1074: CBNZ x19, #0x28f107c       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F1078: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2257, ????);     
            label_1:
            // 0x028F107C: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F1080: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F1084: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F1088: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F108C: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F1090: CBZ x9, #0x28f10bc         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F1094: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F1098: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F109C: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F10A0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F10A4: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F10A8: B.EQ #0x28f10cc            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F10AC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F10B0: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F10B4: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F10B8: B.LO #0x28f10a0            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F10BC: MOVZ w2, #0x11             | W2 = 17 (0x11);//ML01                   
            // 0x028F10C0: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F10C4: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F10C8: B #0x28f10dc               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F10CC: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F10D0: ADD w9, w9, #0x11          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 17);
            // 0x028F10D4: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 17));
            // 0x028F10D8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 17)).272
            label_5:
            // 0x028F10DC: LDP x2, x1, [x0]           | X2 = 0x27D844000; X1 = 0x800;            //  | 
            // 0x028F10E0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F10E4: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F10E8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F10EC: BR x2                      | X0 = sub_27D844000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F10F0 (42930416), len: 180  VirtAddr: 0x028F10F0 RVA: 0x028F10F0 token: 100680326 methodIndex: 29610 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.CLR.TypeSystem.IType get_ElementType()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F10F0: STP x20, x19, [sp, #-0x20]! | stack[1152921512897193616] = ???;  stack[1152921512897193624] = ???;  //  dest_result_addr=1152921512897193616 |  dest_result_addr=1152921512897193624
            // 0x028F10F4: STP x29, x30, [sp, #0x10]  | stack[1152921512897193632] = ???;  stack[1152921512897193640] = ???;  //  dest_result_addr=1152921512897193632 |  dest_result_addr=1152921512897193640
            // 0x028F10F8: ADD x29, sp, #0x10         | X29 = (1152921512897193616 + 16) = 1152921512897193632 (0x10000001EE24A6A0);
            // 0x028F10FC: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F1100: LDRB w8, [x20, #0xa2c]     | W8 = (bool)static_value_037B8A2C;       
            // 0x028F1104: MOV x19, x0                | X19 = 1152921512897205648 (0x10000001EE24D590);//ML01
            // 0x028F1108: TBNZ w8, #0, #0x28f1124    | if (static_value_037B8A2C == true) goto label_0;
            // 0x028F110C: ADRP x8, #0x362f000        | X8 = 56815616 (0x362F000);              
            // 0x028F1110: LDR x8, [x8, #0x878]       | X8 = 0x2B92E20;                         
            // 0x028F1114: LDR w0, [x8]               | W0 = 0x224D;                            
            // 0x028F1118: BL #0x2782188              | X0 = sub_2782188( ?? 0x224D, ????);     
            // 0x028F111C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F1120: STRB w8, [x20, #0xa2c]     | static_value_037B8A2C = true;            //  dest_result_addr=58427948
            label_0:
            // 0x028F1124: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F1128: CBNZ x19, #0x28f1130       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F112C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x224D, ????);     
            label_1:
            // 0x028F1130: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F1134: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F1138: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F113C: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F1140: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F1144: CBZ x9, #0x28f1170         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F1148: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F114C: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F1150: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F1154: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F1158: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F115C: B.EQ #0x28f1180            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F1160: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F1164: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F1168: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F116C: B.LO #0x28f1154            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F1170: MOVZ w2, #0x12             | W2 = 18 (0x12);//ML01                   
            // 0x028F1174: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F1178: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F117C: B #0x28f1190               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F1180: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F1184: ADD w9, w9, #0x12          | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 18);
            // 0x028F1188: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 18));
            // 0x028F118C: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 18)).272
            label_5:
            // 0x028F1190: LDP x2, x1, [x0]           | X2 = 0x120000245D000000; X1 = 0x27D8440000A00; //  | 
            // 0x028F1194: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F1198: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F119C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F11A0: BR x2                      | X0 = sub_120000245D000000( ?? this.type, ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x028F11A4 (42930596), len: 180  VirtAddr: 0x028F11A4 RVA: 0x028F11A4 token: 100680327 methodIndex: 29611 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_ArrayRank()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            // 0x028F11A4: STP x20, x19, [sp, #-0x20]! | stack[1152921512897313808] = ???;  stack[1152921512897313816] = ???;  //  dest_result_addr=1152921512897313808 |  dest_result_addr=1152921512897313816
            // 0x028F11A8: STP x29, x30, [sp, #0x10]  | stack[1152921512897313824] = ???;  stack[1152921512897313832] = ???;  //  dest_result_addr=1152921512897313824 |  dest_result_addr=1152921512897313832
            // 0x028F11AC: ADD x29, sp, #0x10         | X29 = (1152921512897313808 + 16) = 1152921512897313824 (0x10000001EE267C20);
            // 0x028F11B0: ADRP x20, #0x37b8000       | X20 = 58425344 (0x37B8000);             
            // 0x028F11B4: LDRB w8, [x20, #0xa2d]     | W8 = (bool)static_value_037B8A2D;       
            // 0x028F11B8: MOV x19, x0                | X19 = 1152921512897325840 (0x10000001EE26AB10);//ML01
            // 0x028F11BC: TBNZ w8, #0, #0x28f11d8    | if (static_value_037B8A2D == true) goto label_0;
            // 0x028F11C0: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x028F11C4: LDR x8, [x8, #0xcb0]       | X8 = 0x2B92E10;                         
            // 0x028F11C8: LDR w0, [x8]               | W0 = 0x2249;                            
            // 0x028F11CC: BL #0x2782188              | X0 = sub_2782188( ?? 0x2249, ????);     
            // 0x028F11D0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x028F11D4: STRB w8, [x20, #0xa2d]     | static_value_037B8A2D = true;            //  dest_result_addr=58427949
            label_0:
            // 0x028F11D8: LDR x19, [x19, #0x10]      | X19 = this.type; //P2                   
            // 0x028F11DC: CBNZ x19, #0x28f11e4       | if (this.type != null) goto label_1;    
            if(this.type != null)
            {
                goto label_1;
            }
            // 0x028F11E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2249, ????);     
            label_1:
            // 0x028F11E4: ADRP x9, #0x3679000        | X9 = 57118720 (0x3679000);              
            // 0x028F11E8: LDR x8, [x19]              | X8 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F11EC: LDR x9, [x9, #0xdf8]       | X9 = 1152921504782245888;               
            // 0x028F11F0: LDR x1, [x9]               | X1 = typeof(ILRuntime.CLR.TypeSystem.IType);
            // 0x028F11F4: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count;
            // 0x028F11F8: CBZ x9, #0x28f1224         | if (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x028F11FC: LDR x10, [x8, #0x98]       | X10 = ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets;
            // 0x028F1200: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_2 = 0;
            // 0x028F1204: ADD x10, x10, #8           | X10 = (ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504782282760 (0x100000000A74F008);
            label_4:
            // 0x028F1208: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x028F120C: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(ILRuntime.CLR.TypeSystem.IType))
            // 0x028F1210: B.EQ #0x28f1234            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x028F1214: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_2 = val_2 + 1;
            // 0x028F1218: ADD x10, x10, #0x10        | X10 = (1152921504782282760 + 16) = 1152921504782282776 (0x100000000A74F018);
            // 0x028F121C: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count)
            // 0x028F1220: B.LO #0x28f1208            | if (0 < ILRuntime.CLR.TypeSystem.IType.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x028F1224: MOVZ w2, #0xb              | W2 = 11 (0xB);//ML01                    
            // 0x028F1228: MOV x0, x19                | X0 = this.type;//m1                     
            val_2 = this.type;
            // 0x028F122C: BL #0x2776c24              | X0 = sub_2776C24( ?? this.type, ????);  
            // 0x028F1230: B #0x28f1244               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x028F1234: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x028F1238: ADD w9, w9, #0xb           | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 11);
            // 0x028F123C: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 11));
            // 0x028F1240: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504782245888 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 11)).272
            label_5:
            // 0x028F1244: LDP x2, x1, [x0]           | X2 = 0x5D00000000000000; X1 = 0x40000A0012000024; //  | 
            // 0x028F1248: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x028F124C: MOV x0, x19                | X0 = this.type;//m1                     
            // 0x028F1250: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x028F1254: BR x2                      | X0 = sub_5D00000000000000( ?? this.type, ????);
        
        }
    
    }

}
