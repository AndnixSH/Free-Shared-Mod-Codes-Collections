using UnityEngine;

namespace SevenZip.Compression.RangeCoder
{
    internal struct BitTreeEncoder
    {
        // Fields
        private SevenZip.Compression.RangeCoder.BitEncoder[] Models; //  0x00000000
        private int NumBitLevels; //  0x00000008
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AD7EEC (11370220), len: 8  VirtAddr: 0x00AD7EEC RVA: 0x00AD7EEC token: 100681674 methodIndex: 54722 delegateWrapperIndex: 0 methodInvoker: 0
        public BitTreeEncoder(int numBitLevels)
        {
            //
            // Disasemble & Code
            // 0x00AD7EEC: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513109493024 (0x10000001FACC1520);
            // 0x00AD7EF0: B #0xad6100                | goto label_Encoder_LenEncoder__ctor_GL00AD6100;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7EF4 (11370228), len: 8  VirtAddr: 0x00AD7EF4 RVA: 0x00AD7EF4 token: 100681675 methodIndex: 54723 delegateWrapperIndex: 0 methodInvoker: 0
        public void Init()
        {
            //
            // Disasemble & Code
            // 0x00AD7EF4: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513109605024 (0x10000001FACDCAA0);
            // 0x00AD7EF8: B #0xad623c                | goto label_Encoder_LenEncoder_Init_GL00AD623C;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7EFC (11370236), len: 184  VirtAddr: 0x00AD7EFC RVA: 0x00AD7EFC token: 100681676 methodIndex: 54724 delegateWrapperIndex: 0 methodInvoker: 0
        public void Encode(SevenZip.Compression.RangeCoder.Encoder rangeEncoder, uint symbol)
        {
            //
            // Disasemble & Code
            // 0x00AD7EFC: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513109721120 (0x10000001FACF9020);
            // 0x00AD7F00: B #0xad64b8                | goto label_Encoder_LenEncoder_Encode_GL00AD64B8;
            label_SevenZip_Compression_RangeCoder_BitTreeEncoder_Encode_GL00AD7F04:
            // 0x00AD7F04: STP x26, x25, [sp, #-0x50]! | stack[1152921513109709024] = ???;  stack[1152921513109709032] = ???;  //  dest_result_addr=1152921513109709024 |  dest_result_addr=1152921513109709032
            // 0x00AD7F08: STP x24, x23, [sp, #0x10]  | stack[1152921513109709040] = ???;  stack[1152921513109709048] = ???;  //  dest_result_addr=1152921513109709040 |  dest_result_addr=1152921513109709048
            // 0x00AD7F0C: STP x22, x21, [sp, #0x20]  | stack[1152921513109709056] = ???;  stack[1152921513109709064] = ???;  //  dest_result_addr=1152921513109709056 |  dest_result_addr=1152921513109709064
            // 0x00AD7F10: STP x20, x19, [sp, #0x30]  | stack[1152921513109709072] = ???;  stack[1152921513109709080] = ???;  //  dest_result_addr=1152921513109709072 |  dest_result_addr=1152921513109709080
            // 0x00AD7F14: STP x29, x30, [sp, #0x40]  | stack[1152921513109709088] = ???;  stack[1152921513109709096] = ???;  //  dest_result_addr=1152921513109709088 |  dest_result_addr=1152921513109709096
            // 0x00AD7F18: ADD x29, sp, #0x40         | X29 = (1152921513109709024 + 64) = 1152921513109709088 (0x10000001FACF6120);
            // 0x00AD7F1C: MOV x19, x0                | X19 = 1152921513109721120 (0x10000001FACF9020);//ML01
            // 0x00AD7F20: LDR w8, [x19, #8]          |  //  find_add[1152921513109721104]
            // 0x00AD7F24: MOV w20, w2                | W20 = symbol;//m1                       
            uint val_2 = symbol;
            // 0x00AD7F28: MOV x21, x1                | X21 = rangeEncoder;//m1                 
            // 0x00AD7F2C: CMP w8, #1                 | STATE = COMPARE(W8, 0x1)                
            // 0x00AD7F30: B.LT #0xad7f9c             | if (W8 < 0x1) goto label_0;             
            if(W8 < 1)
            {
                goto label_0;
            }
            // 0x00AD7F34: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            var val_3 = 1;
            // 0x00AD7F38: ORR w24, wzr, #1           | W24 = 1(0x1);                           
            label_3:
            // 0x00AD7F3C: LDR x25, [x19]             | X25 = typeof(SevenZip.Compression.RangeCoder.BitTreeEncoder);
            // 0x00AD7F40: AND w22, w20, #1           | W22 = (symbol & 1);                     
            uint val_1 = val_2 & 1;
            // 0x00AD7F44: CBNZ x25, #0xad7f4c        | if (typeof(SevenZip.Compression.RangeCoder.BitTreeEncoder) != 0) goto label_1;
            if(new SevenZip.Compression.RangeCoder.BitTreeEncoder() != 0)
            {
                goto label_1;
            }
            // 0x00AD7F48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (SevenZip.Compression.RangeCoder.BitTreeEncoder)[1152921513109721104], ????);
            label_1:
            // 0x00AD7F4C: LDR w8, [x25, #0x18]       | W8 = SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze;
            // 0x00AD7F50: MOV w26, w24               | W26 = 1 (0x1);//ML01                    
            // 0x00AD7F54: CMP w24, w8                | STATE = COMPARE(0x1, SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze)
            // 0x00AD7F58: B.LO #0xad7f68             | if (1 < SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze) goto label_2;
            // 0x00AD7F5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (SevenZip.Compression.RangeCoder.BitTreeEncoder)[1152921513109721104], ????);
            // 0x00AD7F60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD7F64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (SevenZip.Compression.RangeCoder.BitTreeEncoder)[1152921513109721104], ????);
            label_2:
            // 0x00AD7F68: ADD x8, x25, x26, lsl #2   |  //  not_find_field:typeof(SevenZip.Compression.RangeCoder.BitTreeEncoder).4
            // 0x00AD7F6C: ADD x0, x8, #0x20          | X0 = (SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze + 32) = 1152921507405991936 (0x10000000A6D79000);
            // 0x00AD7F70: MOV x1, x21                | X1 = rangeEncoder;//m1                  
            // 0x00AD7F74: MOV w2, w22                | W2 = (symbol & 1);//m1                  
            // 0x00AD7F78: BL #0xad63d8               | X0 = label_Encoder_LenEncoder_Encode_GL00AD63D8();
            // 0x00AD7F7C: LDRSW x8, [x19, #8]        |  //  find_add[1152921513109721104]
            // 0x00AD7F80: MOV w9, w23                | W9 = 1 (0x1);//ML01                     
            // 0x00AD7F84: BFI w22, w24, #1, #0x1f    | W22 = (symbol & 1) | 1                  
            // 0x00AD7F88: LSR w20, w20, #1           | W20 = (symbol >> 1);                    
            val_2 = val_2 >> 1;
            // 0x00AD7F8C: CMP x9, x8                 | STATE = COMPARE(0x1, SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze)
            // 0x00AD7F90: ADD w23, w23, #1           | W23 = (1 + 1);                          
            val_3 = val_3 + 1;
            // 0x00AD7F94: MOV w24, w22               | W24 = (symbol & 1);//m1                 
            // 0x00AD7F98: B.LT #0xad7f3c             | if (1 < SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze) goto label_3;
            label_0:
            // 0x00AD7F9C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD7FA0: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD7FA4: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD7FA8: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD7FAC: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD7FB0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7FB4 (11370420), len: 8  VirtAddr: 0x00AD7FB4 RVA: 0x00AD7FB4 token: 100681677 methodIndex: 54725 delegateWrapperIndex: 0 methodInvoker: 0
        public void ReverseEncode(SevenZip.Compression.RangeCoder.Encoder rangeEncoder, uint symbol)
        {
            //
            // Disasemble & Code
            // 0x00AD7FB4: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513109841312 (0x10000001FAD165A0);
            // 0x00AD7FB8: B #0xad7f04                | goto label_SevenZip_Compression_RangeCoder_BitTreeEncoder_Encode_GL00AD7F04;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD7FBC (11370428), len: 188  VirtAddr: 0x00AD7FBC RVA: 0x00AD7FBC token: 100681678 methodIndex: 54726 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetPrice(uint symbol)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x00AD7FBC: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513109957408 (0x10000001FAD32B20);
            // 0x00AD7FC0: B #0xad68e4                | goto label_Encoder_LenEncoder_SetPrices_GL00AD68E4;
            label_SevenZip_Compression_RangeCoder_BitTreeEncoder_GetPrice_GL00AD7FC4:
            // 0x00AD7FC4: STP x26, x25, [sp, #-0x50]! | stack[1152921513109945312] = ???;  stack[1152921513109945320] = ???;  //  dest_result_addr=1152921513109945312 |  dest_result_addr=1152921513109945320
            // 0x00AD7FC8: STP x24, x23, [sp, #0x10]  | stack[1152921513109945328] = ???;  stack[1152921513109945336] = ???;  //  dest_result_addr=1152921513109945328 |  dest_result_addr=1152921513109945336
            // 0x00AD7FCC: STP x22, x21, [sp, #0x20]  | stack[1152921513109945344] = ???;  stack[1152921513109945352] = ???;  //  dest_result_addr=1152921513109945344 |  dest_result_addr=1152921513109945352
            // 0x00AD7FD0: STP x20, x19, [sp, #0x30]  | stack[1152921513109945360] = ???;  stack[1152921513109945368] = ???;  //  dest_result_addr=1152921513109945360 |  dest_result_addr=1152921513109945368
            // 0x00AD7FD4: STP x29, x30, [sp, #0x40]  | stack[1152921513109945376] = ???;  stack[1152921513109945384] = ???;  //  dest_result_addr=1152921513109945376 |  dest_result_addr=1152921513109945384
            // 0x00AD7FD8: ADD x29, sp, #0x40         | X29 = (1152921513109945312 + 64) = 1152921513109945376 (0x10000001FAD2FC20);
            // 0x00AD7FDC: MOV x19, x0                | X19 = 1152921513109957408 (0x10000001FAD32B20);//ML01
            // 0x00AD7FE0: LDR w8, [x19, #8]          |  //  find_add[1152921513109957392]
            // 0x00AD7FE4: MOV w20, w1                | W20 = symbol;//m1                       
            uint val_3 = symbol;
            // 0x00AD7FE8: CMP w8, #1                 | STATE = COMPARE(W8, 0x1)                
            // 0x00AD7FEC: B.LT #0xad8058             | if (W8 < 0x1) goto label_0;             
            if(W8 < 1)
            {
                goto label_0;
            }
            // 0x00AD7FF0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            // 0x00AD7FF4: ADD w23, w8, #1            | W23 = (W8 + 1);                         
            var val_1 = W8 + 1;
            // 0x00AD7FF8: ORR w24, wzr, #1           | W24 = 1(0x1);                           
            label_3:
            // 0x00AD7FFC: LDR x25, [x19]             | X25 = typeof(SevenZip.Compression.RangeCoder.BitTreeEncoder);
            // 0x00AD8000: AND w22, w20, #1           | W22 = (symbol & 1);                     
            uint val_2 = val_3 & 1;
            // 0x00AD8004: CBNZ x25, #0xad800c        | if (typeof(SevenZip.Compression.RangeCoder.BitTreeEncoder) != 0) goto label_1;
            if(new SevenZip.Compression.RangeCoder.BitTreeEncoder() != 0)
            {
                goto label_1;
            }
            // 0x00AD8008: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? (SevenZip.Compression.RangeCoder.BitTreeEncoder)[1152921513109957392], ????);
            label_1:
            // 0x00AD800C: LDR w8, [x25, #0x18]       | W8 = SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze;
            // 0x00AD8010: LSR w20, w20, #1           | W20 = (symbol >> 1);                    
            val_3 = val_3 >> 1;
            // 0x00AD8014: MOV w26, w24               | W26 = 1 (0x1);//ML01                    
            // 0x00AD8018: CMP w24, w8                | STATE = COMPARE(0x1, SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze)
            // 0x00AD801C: B.LO #0xad802c             | if (1 < SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze) goto label_2;
            // 0x00AD8020: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? (SevenZip.Compression.RangeCoder.BitTreeEncoder)[1152921513109957392], ????);
            // 0x00AD8024: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD8028: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? (SevenZip.Compression.RangeCoder.BitTreeEncoder)[1152921513109957392], ????);
            label_2:
            // 0x00AD802C: ADD x8, x25, x26, lsl #2   |  //  not_find_field:typeof(SevenZip.Compression.RangeCoder.BitTreeEncoder).4
            // 0x00AD8030: ADD x0, x8, #0x20          | X0 = (SevenZip.Compression.RangeCoder.BitTreeEncoder.__il2cppRuntimeField_namespaze + 32) = 1152921507405991936 (0x10000000A6D79000);
            // 0x00AD8034: MOV w1, w22                | W1 = (symbol & 1);//m1                  
            // 0x00AD8038: BL #0xad7324               | X0 = label_Encoder_LiteralEncoder_Encoder2_EncodeMatched_GL00AD7324();
            // 0x00AD803C: SUB w23, w23, #1           | W23 = ((W8 + 1) - 1);                   
            val_1 = val_1 - 1;
            // 0x00AD8040: BFI w22, w24, #1, #0x1f    | W22 = (symbol & 1) | 1                  
            // 0x00AD8044: CMP w23, #1                | STATE = COMPARE(((W8 + 1) - 1), 0x1)    
            // 0x00AD8048: ADD w21, w0, w21           | W21 = (1152921507405991936 + 0) = val_3 (0x10000000A6D79000);
            val_3 = 1152921507405991936;
            // 0x00AD804C: MOV w24, w22               | W24 = (symbol & 1);//m1                 
            // 0x00AD8050: B.GT #0xad7ffc             | if (val_1 > 0x1) goto label_3;          
            if(val_1 > 1)
            {
                goto label_3;
            }
            // 0x00AD8054: B #0xad805c                |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x00AD8058: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_3 = 0;
            label_4:
            // 0x00AD805C: MOV w0, w21                | W0 = 0 (0x0);//ML01                     
            // 0x00AD8060: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD8064: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD8068: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD806C: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD8070: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD8074: RET                        |  return (System.UInt32)null;            
            return (uint)val_3;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD8078 (11370616), len: 8  VirtAddr: 0x00AD8078 RVA: 0x00AD8078 token: 100681679 methodIndex: 54727 delegateWrapperIndex: 0 methodInvoker: 0
        public uint ReverseGetPrice(uint symbol)
        {
            //
            // Disasemble & Code
            // 0x00AD8078: ADD x0, x0, #0x10          | X0 = (this + 16) = 1152921513110069408 (0x10000001FAD4E0A0);
            // 0x00AD807C: B #0xad7fc4                | goto label_SevenZip_Compression_RangeCoder_BitTreeEncoder_GetPrice_GL00AD7FC4;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD8080 (11370624), len: 180  VirtAddr: 0x00AD8080 RVA: 0x00AD8080 token: 100681680 methodIndex: 54728 delegateWrapperIndex: 0 methodInvoker: 0
        public static uint ReverseGetPrice(SevenZip.Compression.RangeCoder.BitEncoder[] Models, uint startIndex, int NumBitLevels, uint symbol)
        {
            //
            // Disasemble & Code
            //  | 
            var val_6;
            //  | 
            var val_7;
            // 0x00AD8080: STP x26, x25, [sp, #-0x50]! | stack[1152921513110206176] = ???;  stack[1152921513110206184] = ???;  //  dest_result_addr=1152921513110206176 |  dest_result_addr=1152921513110206184
            // 0x00AD8084: STP x24, x23, [sp, #0x10]  | stack[1152921513110206192] = ???;  stack[1152921513110206200] = ???;  //  dest_result_addr=1152921513110206192 |  dest_result_addr=1152921513110206200
            // 0x00AD8088: STP x22, x21, [sp, #0x20]  | stack[1152921513110206208] = ???;  stack[1152921513110206216] = ???;  //  dest_result_addr=1152921513110206208 |  dest_result_addr=1152921513110206216
            // 0x00AD808C: STP x20, x19, [sp, #0x30]  | stack[1152921513110206224] = ???;  stack[1152921513110206232] = ???;  //  dest_result_addr=1152921513110206224 |  dest_result_addr=1152921513110206232
            // 0x00AD8090: STP x29, x30, [sp, #0x40]  | stack[1152921513110206240] = ???;  stack[1152921513110206248] = ???;  //  dest_result_addr=1152921513110206240 |  dest_result_addr=1152921513110206248
            // 0x00AD8094: ADD x29, sp, #0x40         | X29 = (1152921513110206176 + 64) = 1152921513110206240 (0x10000001FAD6F720);
            // 0x00AD8098: MOV w19, w4                | W19 = W4;//m1                           
            val_6 = W4;
            // 0x00AD809C: MOV w20, w2                | W20 = NumBitLevels;//m1                 
            // 0x00AD80A0: MOV x21, x1                | X21 = startIndex;//m1                   
            // 0x00AD80A4: CMP w3, #1                 | STATE = COMPARE(symbol, 0x1)            
            // 0x00AD80A8: B.LT #0xad8114             | if (symbol < 0x1) goto label_0;         
            if(symbol < 1)
            {
                goto label_0;
            }
            // 0x00AD80AC: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            // 0x00AD80B0: ADD w24, w3, #1            | W24 = (symbol + 1);                     
            uint val_1 = symbol + 1;
            // 0x00AD80B4: ORR w25, wzr, #1           | W25 = 1(0x1);                           
            label_3:
            // 0x00AD80B8: AND w23, w19, #1           | W23 = (W4 & 1);                         
            var val_2 = val_6 & 1;
            // 0x00AD80BC: CBNZ x21, #0xad80c4        | if (startIndex != 0) goto label_1;      
            if(startIndex != 0)
            {
                goto label_1;
            }
            // 0x00AD80C0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Models, ????);     
            label_1:
            // 0x00AD80C4: LDR w8, [x21, #0x18]       | W8 = startIndex + 24;                   
            // 0x00AD80C8: ADD w9, w25, w20           | W9 = (1 + NumBitLevels);                
            int val_3 = 1 + NumBitLevels;
            // 0x00AD80CC: LSR w19, w19, #1           | W19 = (W4 >> 1);                        
            val_6 = val_6 >> 1;
            // 0x00AD80D0: SXTW x26, w9               | X26 = (long)(int)((1 + NumBitLevels));  
            // 0x00AD80D4: CMP w9, w8                 | STATE = COMPARE((1 + NumBitLevels), startIndex + 24)
            // 0x00AD80D8: B.LO #0xad80e8             | if (val_3 < startIndex + 24) goto label_2;
            if(val_3 < (startIndex + 24))
            {
                goto label_2;
            }
            // 0x00AD80DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? Models, ????);     
            // 0x00AD80E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD80E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? Models, ????);     
            label_2:
            // 0x00AD80E8: ADD x8, x21, x26, lsl #2   | X8 = (startIndex + ((long)(int)((1 + NumBitLevels))) << 2);
            uint val_4 = startIndex + (((long)(int)((1 + NumBitLevels))) << 2);
            // 0x00AD80EC: ADD x0, x8, #0x20          | X0 = ((startIndex + ((long)(int)((1 + NumBitLevels))) << 2) + 32);
            uint val_5 = val_4 + 32;
            // 0x00AD80F0: MOV w1, w23                | W1 = (W4 & 1);//m1                      
            // 0x00AD80F4: BL #0xad7324               | X0 = label_Encoder_LiteralEncoder_Encoder2_EncodeMatched_GL00AD7324();
            // 0x00AD80F8: SUB w24, w24, #1           | W24 = ((symbol + 1) - 1);               
            val_1 = val_1 - 1;
            // 0x00AD80FC: BFI w23, w25, #1, #0x1f    | W23 = (W4 & 1) | 1                      
            // 0x00AD8100: CMP w24, #1                | STATE = COMPARE(((symbol + 1) - 1), 0x1)
            // 0x00AD8104: ADD w22, w0, w22           | W22 = (((startIndex + ((long)(int)((1 + NumBitLevels))) << 2) + 32) + 0);
            val_7 = val_5 + 0;
            // 0x00AD8108: MOV w25, w23               | W25 = (W4 & 1);//m1                     
            // 0x00AD810C: B.GT #0xad80b8             | if (val_1 > 0x1) goto label_3;          
            if(val_1 > 1)
            {
                goto label_3;
            }
            // 0x00AD8110: B #0xad8118                |  goto label_4;                          
            goto label_4;
            label_0:
            // 0x00AD8114: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_4:
            // 0x00AD8118: MOV w0, w22                | W0 = 0 (0x0);//ML01                     
            // 0x00AD811C: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD8120: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD8124: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD8128: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD812C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD8130: RET                        |  return (System.UInt32)null;            
            return (uint)val_7;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AD8134 (11370804), len: 164  VirtAddr: 0x00AD8134 RVA: 0x00AD8134 token: 100681681 methodIndex: 54729 delegateWrapperIndex: 0 methodInvoker: 0
        public static void ReverseEncode(SevenZip.Compression.RangeCoder.BitEncoder[] Models, uint startIndex, SevenZip.Compression.RangeCoder.Encoder rangeEncoder, int NumBitLevels, uint symbol)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            // 0x00AD8134: STP x26, x25, [sp, #-0x50]! | stack[1152921513110396000] = ???;  stack[1152921513110396008] = ???;  //  dest_result_addr=1152921513110396000 |  dest_result_addr=1152921513110396008
            // 0x00AD8138: STP x24, x23, [sp, #0x10]  | stack[1152921513110396016] = ???;  stack[1152921513110396024] = ???;  //  dest_result_addr=1152921513110396016 |  dest_result_addr=1152921513110396024
            // 0x00AD813C: STP x22, x21, [sp, #0x20]  | stack[1152921513110396032] = ???;  stack[1152921513110396040] = ???;  //  dest_result_addr=1152921513110396032 |  dest_result_addr=1152921513110396040
            // 0x00AD8140: STP x20, x19, [sp, #0x30]  | stack[1152921513110396048] = ???;  stack[1152921513110396056] = ???;  //  dest_result_addr=1152921513110396048 |  dest_result_addr=1152921513110396056
            // 0x00AD8144: STP x29, x30, [sp, #0x40]  | stack[1152921513110396064] = ???;  stack[1152921513110396072] = ???;  //  dest_result_addr=1152921513110396064 |  dest_result_addr=1152921513110396072
            // 0x00AD8148: ADD x29, sp, #0x40         | X29 = (1152921513110396000 + 64) = 1152921513110396064 (0x10000001FAD9DCA0);
            // 0x00AD814C: MOV w19, w5                | W19 = W5;//m1                           
            val_5 = W5;
            // 0x00AD8150: MOV w20, w4                | W20 = symbol;//m1                       
            uint val_5 = symbol;
            // 0x00AD8154: MOV x21, x3                | X21 = NumBitLevels;//m1                 
            // 0x00AD8158: MOV w22, w2                | W22 = rangeEncoder;//m1                 
            // 0x00AD815C: MOV x23, x1                | X23 = startIndex;//m1                   
            // 0x00AD8160: CMP w20, #1                | STATE = COMPARE(symbol, 0x1)            
            // 0x00AD8164: B.LT #0xad81c0             | if (symbol < 0x1) goto label_0;         
            if(val_5 < 1)
            {
                goto label_0;
            }
            // 0x00AD8168: ORR w25, wzr, #1           | W25 = 1(0x1);                           
            label_3:
            // 0x00AD816C: AND w24, w19, #1           | W24 = (W5 & 1);                         
            var val_1 = val_5 & 1;
            // 0x00AD8170: CBNZ x23, #0xad8178        | if (startIndex != 0) goto label_1;      
            if(startIndex != 0)
            {
                goto label_1;
            }
            // 0x00AD8174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? Models, ????);     
            label_1:
            // 0x00AD8178: LDR w8, [x23, #0x18]       | W8 = startIndex + 24;                   
            // 0x00AD817C: ADD w9, w25, w22           | W9 = (1 + rangeEncoder);                
            SevenZip.Compression.RangeCoder.Encoder val_2 = 1 + rangeEncoder;
            // 0x00AD8180: SXTW x26, w9               | X26 = (long)(int)((1 + rangeEncoder));  
            // 0x00AD8184: CMP w9, w8                 | STATE = COMPARE((1 + rangeEncoder), startIndex + 24)
            // 0x00AD8188: B.LO #0xad8198             | if (val_2 < startIndex + 24) goto label_2;
            if(val_2 < (startIndex + 24))
            {
                goto label_2;
            }
            // 0x00AD818C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? Models, ????);     
            // 0x00AD8190: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AD8194: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? Models, ????);     
            label_2:
            // 0x00AD8198: ADD x8, x23, x26, lsl #2   | X8 = (startIndex + ((long)(int)((1 + rangeEncoder))) << 2);
            uint val_3 = startIndex + (((long)(int)((1 + rangeEncoder))) << 2);
            // 0x00AD819C: ADD x0, x8, #0x20          | X0 = ((startIndex + ((long)(int)((1 + rangeEncoder))) << 2) + 32);
            uint val_4 = val_3 + 32;
            // 0x00AD81A0: MOV x1, x21                | X1 = NumBitLevels;//m1                  
            // 0x00AD81A4: MOV w2, w24                | W2 = (W5 & 1);//m1                      
            // 0x00AD81A8: BL #0xad63d8               | X0 = label_Encoder_LenEncoder_Encode_GL00AD63D8();
            // 0x00AD81AC: BFI w24, w25, #1, #0x1f    | W24 = (W5 & 1) | 1                      
            // 0x00AD81B0: LSR w19, w19, #1           | W19 = (W5 >> 1);                        
            val_5 = val_5 >> 1;
            // 0x00AD81B4: SUB w20, w20, #1           | W20 = (symbol - 1);                     
            val_5 = val_5 - 1;
            // 0x00AD81B8: MOV w25, w24               | W25 = (W5 & 1);//m1                     
            // 0x00AD81BC: CBNZ w20, #0xad816c        | if ((symbol - 1) != 0) goto label_3;    
            if(val_5 != 0)
            {
                goto label_3;
            }
            label_0:
            // 0x00AD81C0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00AD81C4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x00AD81C8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x00AD81CC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00AD81D0: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x00AD81D4: RET                        |  return;                                
            return;
        
        }
    
    }

}
