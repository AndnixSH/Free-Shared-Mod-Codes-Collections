using UnityEngine;

namespace wxb
{
    internal class ArrayFloatType : ArraySerialize<float>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2BBC8 (14859208), len: 80  VirtAddr: 0x00E2BBC8 RVA: 0x00E2BBC8 token: 100681205 methodIndex: 57205 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayFloatType()
        {
            //
            // Disasemble & Code
            // 0x00E2BBC8: STP x20, x19, [sp, #-0x20]! | stack[1152921513026320800] = ???;  stack[1152921513026320808] = ???;  //  dest_result_addr=1152921513026320800 |  dest_result_addr=1152921513026320808
            // 0x00E2BBCC: STP x29, x30, [sp, #0x10]  | stack[1152921513026320816] = ???;  stack[1152921513026320824] = ???;  //  dest_result_addr=1152921513026320816 |  dest_result_addr=1152921513026320824
            // 0x00E2BBD0: ADD x29, sp, #0x10         | X29 = (1152921513026320800 + 16) = 1152921513026320816 (0x10000001F5D6F9B0);
            // 0x00E2BBD4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2BBD8: LDRB w8, [x20, #0x8ed]     | W8 = (bool)static_value_037348ED;       
            // 0x00E2BBDC: MOV x19, x0                | X19 = 1152921513026332832 (0x10000001F5D728A0);//ML01
            // 0x00E2BBE0: TBNZ w8, #0, #0xe2bbfc     | if (static_value_037348ED == true) goto label_0;
            // 0x00E2BBE4: ADRP x8, #0x3661000        | X8 = 57020416 (0x3661000);              
            // 0x00E2BBE8: LDR x8, [x8, #0xb80]       | X8 = 0x2B8E73C;                         
            // 0x00E2BBEC: LDR w0, [x8]               | W0 = 0x108D;                            
            // 0x00E2BBF0: BL #0x2782188              | X0 = sub_2782188( ?? 0x108D, ????);     
            // 0x00E2BBF4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2BBF8: STRB w8, [x20, #0x8ed]     | static_value_037348ED = true;            //  dest_result_addr=57886957
            label_0:
            // 0x00E2BBFC: ADRP x8, #0x3646000        | X8 = 56909824 (0x3646000);              
            // 0x00E2BC00: LDR x8, [x8, #0xe10]       | X8 = 1152921513026307808;               
            // 0x00E2BC04: MOV x0, x19                | X0 = 1152921513026332832 (0x10000001F5D728A0);//ML01
            // 0x00E2BC08: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Single>::.ctor();
            // 0x00E2BC0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BC10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BC14: B #0x1d87264               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BC18 (14859288), len: 8  VirtAddr: 0x00E2BC18 RVA: 0x00E2BC18 token: 100681206 methodIndex: 57206 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2BC18: ORR w0, wzr, #4            | W0 = 4(0x4);                            
            // 0x00E2BC1C: RET                        |  return (System.Int32)4;                
            return (int)4;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BC20 (14859296), len: 60  VirtAddr: 0x00E2BC20 RVA: 0x00E2BC20 token: 100681207 methodIndex: 57207 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, float value)
        {
            //
            // Disasemble & Code
            // 0x00E2BC20: STP d9, d8, [sp, #-0x30]!  | stack[1152921513026548880] = ???;  stack[1152921513026548888] = ???;  //  dest_result_addr=1152921513026548880 |  dest_result_addr=1152921513026548888
            // 0x00E2BC24: STP x20, x19, [sp, #0x10]  | stack[1152921513026548896] = ???;  stack[1152921513026548904] = ???;  //  dest_result_addr=1152921513026548896 |  dest_result_addr=1152921513026548904
            // 0x00E2BC28: STP x29, x30, [sp, #0x20]  | stack[1152921513026548912] = ???;  stack[1152921513026548920] = ???;  //  dest_result_addr=1152921513026548912 |  dest_result_addr=1152921513026548920
            // 0x00E2BC2C: ADD x29, sp, #0x20         | X29 = (1152921513026548880 + 32) = 1152921513026548912 (0x10000001F5DA74B0);
            // 0x00E2BC30: MOV v8.16b, v0.16b         | V8 = value;//m1                         
            // 0x00E2BC34: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BC38: CBNZ x19, #0xe2bc40        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BC3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BC40: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BC44: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BC48: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BC4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BC50: MOV v0.16b, v8.16b         | V0 = value;//m1                         
            // 0x00E2BC54: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00E2BC58: B #0x26a572c               | stream.WriteFloat(value:  value); return;
            stream.WriteFloat(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BC5C (14859356), len: 44  VirtAddr: 0x00E2BC5C RVA: 0x00E2BC5C token: 100681208 methodIndex: 57208 delegateWrapperIndex: 0 methodInvoker: 0
        protected override float Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2BC5C: STP x20, x19, [sp, #-0x20]! | stack[1152921513026669088] = ???;  stack[1152921513026669096] = ???;  //  dest_result_addr=1152921513026669088 |  dest_result_addr=1152921513026669096
            // 0x00E2BC60: STP x29, x30, [sp, #0x10]  | stack[1152921513026669104] = ???;  stack[1152921513026669112] = ???;  //  dest_result_addr=1152921513026669104 |  dest_result_addr=1152921513026669112
            // 0x00E2BC64: ADD x29, sp, #0x10         | X29 = (1152921513026669088 + 16) = 1152921513026669104 (0x10000001F5DC4A30);
            // 0x00E2BC68: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BC6C: CBNZ x19, #0xe2bc74        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BC70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BC74: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BC78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BC7C: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BC80: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BC84: B #0x26a593c               | return stream.ReadFloat();              
            return stream.ReadFloat();
        
        }
    
    }

}
