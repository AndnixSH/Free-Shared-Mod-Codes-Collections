using UnityEngine;

namespace wxb
{
    internal class ArrayShortType : ArraySerialize<short>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2C27C (14860924), len: 80  VirtAddr: 0x00E2C27C RVA: 0x00E2C27C token: 100681197 methodIndex: 57225 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayShortType()
        {
            //
            // Disasemble & Code
            // 0x00E2C27C: STP x20, x19, [sp, #-0x20]! | stack[1152921513025389984] = ???;  stack[1152921513025389992] = ???;  //  dest_result_addr=1152921513025389984 |  dest_result_addr=1152921513025389992
            // 0x00E2C280: STP x29, x30, [sp, #0x10]  | stack[1152921513025390000] = ???;  stack[1152921513025390008] = ???;  //  dest_result_addr=1152921513025390000 |  dest_result_addr=1152921513025390008
            // 0x00E2C284: ADD x29, sp, #0x10         | X29 = (1152921513025389984 + 16) = 1152921513025390000 (0x10000001F5C8C5B0);
            // 0x00E2C288: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2C28C: LDRB w8, [x20, #0x8f4]     | W8 = (bool)static_value_037348F4;       
            // 0x00E2C290: MOV x19, x0                | X19 = 1152921513025402016 (0x10000001F5C8F4A0);//ML01
            // 0x00E2C294: TBNZ w8, #0, #0xe2c2b0     | if (static_value_037348F4 == true) goto label_0;
            // 0x00E2C298: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x00E2C29C: LDR x8, [x8, #0x940]       | X8 = 0x2B8E828;                         
            // 0x00E2C2A0: LDR w0, [x8]               | W0 = 0x10C8;                            
            // 0x00E2C2A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x10C8, ????);     
            // 0x00E2C2A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2C2AC: STRB w8, [x20, #0x8f4]     | static_value_037348F4 = true;            //  dest_result_addr=57886964
            label_0:
            // 0x00E2C2B0: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00E2C2B4: LDR x8, [x8, #0x4d8]       | X8 = 1152921513025376992;               
            // 0x00E2C2B8: MOV x0, x19                | X0 = 1152921513025402016 (0x10000001F5C8F4A0);//ML01
            // 0x00E2C2BC: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Int16>::.ctor();
            // 0x00E2C2C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C2C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C2C8: B #0x1d86ff8               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C2CC (14861004), len: 8  VirtAddr: 0x00E2C2CC RVA: 0x00E2C2CC token: 100681198 methodIndex: 57226 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2C2CC: ORR w0, wzr, #2            | W0 = 2(0x2);                            
            // 0x00E2C2D0: RET                        |  return (System.Int32)2;                
            return (int)2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C2D4 (14861012), len: 52  VirtAddr: 0x00E2C2D4 RVA: 0x00E2C2D4 token: 100681199 methodIndex: 57227 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, short value)
        {
            //
            // Disasemble & Code
            // 0x00E2C2D4: STP x20, x19, [sp, #-0x20]! | stack[1152921513025618080] = ???;  stack[1152921513025618088] = ???;  //  dest_result_addr=1152921513025618080 |  dest_result_addr=1152921513025618088
            // 0x00E2C2D8: STP x29, x30, [sp, #0x10]  | stack[1152921513025618096] = ???;  stack[1152921513025618104] = ???;  //  dest_result_addr=1152921513025618096 |  dest_result_addr=1152921513025618104
            // 0x00E2C2DC: ADD x29, sp, #0x10         | X29 = (1152921513025618080 + 16) = 1152921513025618096 (0x10000001F5CC40B0);
            // 0x00E2C2E0: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2C2E4: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2C2E8: CBNZ x20, #0xe2c2f0        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C2EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C2F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C2F4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2C2F8: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2C2FC: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2C300: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C304: B #0x269fe28               | stream.WriteInt16(value:  value); return;
            stream.WriteInt16(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2C308 (14861064), len: 44  VirtAddr: 0x00E2C308 RVA: 0x00E2C308 token: 100681200 methodIndex: 57228 delegateWrapperIndex: 0 methodInvoker: 0
        protected override short Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2C308: STP x20, x19, [sp, #-0x20]! | stack[1152921513025738272] = ???;  stack[1152921513025738280] = ???;  //  dest_result_addr=1152921513025738272 |  dest_result_addr=1152921513025738280
            // 0x00E2C30C: STP x29, x30, [sp, #0x10]  | stack[1152921513025738288] = ???;  stack[1152921513025738296] = ???;  //  dest_result_addr=1152921513025738288 |  dest_result_addr=1152921513025738296
            // 0x00E2C310: ADD x29, sp, #0x10         | X29 = (1152921513025738272 + 16) = 1152921513025738288 (0x10000001F5CE1630);
            // 0x00E2C314: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2C318: CBNZ x19, #0xe2c320        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2C31C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2C320: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2C324: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2C328: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2C32C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2C330: B #0x269ff60               | return stream.ReadInt16();              
            return stream.ReadInt16();
        
        }
    
    }

}
