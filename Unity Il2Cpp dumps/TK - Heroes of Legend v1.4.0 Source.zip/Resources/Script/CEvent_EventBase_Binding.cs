using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class CEvent_EventBase_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache3; // static_offset: 0x00000018
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x01437A1C (21199388), len: 8  VirtAddr: 0x01437A1C RVA: 0x01437A1C token: 100664189 methodIndex: 30236 delegateWrapperIndex: 0 methodInvoker: 0
        public CEvent_EventBase_Binding()
        {
            //
            // Disasemble & Code
            // 0x01437A1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437A20: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01437A24 (21199396), len: 708  VirtAddr: 0x01437A24 RVA: 0x01437A24 token: 100664190 methodIndex: 30237 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_6;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_7;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_8;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_9;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_10;
            // 0x01437A24: STP x24, x23, [sp, #-0x40]! | stack[1152921510116837088] = ???;  stack[1152921510116837096] = ???;  //  dest_result_addr=1152921510116837088 |  dest_result_addr=1152921510116837096
            // 0x01437A28: STP x22, x21, [sp, #0x10]  | stack[1152921510116837104] = ???;  stack[1152921510116837112] = ???;  //  dest_result_addr=1152921510116837104 |  dest_result_addr=1152921510116837112
            // 0x01437A2C: STP x20, x19, [sp, #0x20]  | stack[1152921510116837120] = ???;  stack[1152921510116837128] = ???;  //  dest_result_addr=1152921510116837120 |  dest_result_addr=1152921510116837128
            // 0x01437A30: STP x29, x30, [sp, #0x30]  | stack[1152921510116837136] = ???;  stack[1152921510116837144] = ???;  //  dest_result_addr=1152921510116837136 |  dest_result_addr=1152921510116837144
            // 0x01437A34: ADD x29, sp, #0x30         | X29 = (1152921510116837088 + 48) = 1152921510116837136 (0x10000001486BC710);
            // 0x01437A38: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01437A3C: LDRB w8, [x20, #0x5b]      | W8 = (bool)static_value_0373705B;       
            // 0x01437A40: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01437A44: TBNZ w8, #0, #0x1437a60    | if (static_value_0373705B == true) goto label_0;
            // 0x01437A48: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x01437A4C: LDR x8, [x8, #0x30]        | X8 = 0x2B904CC;                         
            // 0x01437A50: LDR w0, [x8]               | W0 = 0x17F7;                            
            // 0x01437A54: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F7, ????);     
            // 0x01437A58: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437A5C: STRB w8, [x20, #0x5b]      | static_value_0373705B = true;            //  dest_result_addr=57897051
            label_0:
            // 0x01437A60: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x01437A64: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x01437A68: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x01437A6C: ADRP x8, #0x35e5000        | X8 = 56512512 (0x35E5000);              
            // 0x01437A70: LDR x8, [x8, #0x888]       | X8 = 1152921504898060288;               
            // 0x01437A74: LDR x20, [x8]              | X20 = typeof(CEvent.EventBase);         
            // 0x01437A78: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01437A7C: TBZ w8, #0, #0x1437a8c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01437A80: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01437A84: CBNZ w8, #0x1437a8c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01437A88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01437A8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01437A90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01437A94: MOV x1, x20                | X1 = 1152921504898060288 (0x10000000115B9000);//ML01
            // 0x01437A98: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x01437A9C: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01437AA0: CBNZ x20, #0x1437aa8       | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x01437AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x01437AA8: ADRP x9, #0x35c6000        | X9 = 56385536 (0x35C6000);              
            // 0x01437AAC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01437AB0: LDR x9, [x9, #0x5f0]       | X9 = (string**)(1152921509593945888)("name");
            // 0x01437AB4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01437AB8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01437ABC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01437AC0: LDR x1, [x9]               | X1 = "name";                            
            // 0x01437AC4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01437AC8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01437ACC: ADRP x24, #0x3633000       | X24 = 56832000 (0x3633000);             
            // 0x01437AD0: LDR x24, [x24, #0x838]     | X24 = 1152921504783736832;              
            // 0x01437AD4: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01437AD8: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437ADC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437AE0: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache0;
            val_6 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache0;
            // 0x01437AE4: CBNZ x22, #0x1437b30       | if (ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_6 != null)
            {
                goto label_4;
            }
            // 0x01437AE8: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x01437AEC: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01437AF0: LDR x8, [x8, #0xa90]       | X8 = 1152921510116821056;               
            // 0x01437AF4: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01437AF8: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_name_0(ref object o);
            // 0x01437AFC: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x01437B00: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01437B04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437B08: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437B0C: MOV x2, x22                | X2 = 1152921510116821056 (0x10000001486B8840);//ML01
            // 0x01437B10: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_7 = val_2;
            // 0x01437B14: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_name_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_name_0(ref object o));
            // 0x01437B18: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437B1C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437B20: STR x23, [x8]              | ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783740928
            ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache0 = val_7;
            // 0x01437B24: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437B28: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437B2C: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_6 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache0;
            label_4:
            // 0x01437B30: CBNZ x19, #0x1437b38       | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x01437B34: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_name_0(ref object o)), ????);
            label_5:
            // 0x01437B38: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437B3C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01437B40: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01437B44: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01437B48: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_6);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_6);
            // 0x01437B4C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437B50: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437B54: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache1;
            val_8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache1;
            // 0x01437B58: CBNZ x22, #0x1437ba4       | if (ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_8 != null)
            {
                goto label_6;
            }
            // 0x01437B5C: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x01437B60: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01437B64: LDR x8, [x8, #0x668]       | X8 = 1152921510116822080;               
            // 0x01437B68: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01437B6C: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_name_0(ref object o, object v);
            // 0x01437B70: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x01437B74: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01437B78: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437B7C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437B80: MOV x2, x22                | X2 = 1152921510116822080 (0x10000001486B8C40);//ML01
            // 0x01437B84: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_7 = val_3;
            // 0x01437B88: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_name_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_name_0(ref object o, object v));
            // 0x01437B8C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437B90: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437B94: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783740936
            ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache1 = val_7;
            // 0x01437B98: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437B9C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437BA0: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache1;
            label_6:
            // 0x01437BA4: CBNZ x19, #0x1437bac       | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x01437BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_name_0(ref object o, object v)), ????);
            label_7:
            // 0x01437BAC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437BB0: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01437BB4: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x01437BB8: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01437BBC: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_8);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_8);
            // 0x01437BC0: CBNZ x20, #0x1437bc8       | if (val_1 != null) goto label_8;        
            if(val_1 != null)
            {
                goto label_8;
            }
            // 0x01437BC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? X1, ????);         
            label_8:
            // 0x01437BC8: ADRP x9, #0x3655000        | X9 = 56971264 (0x3655000);              
            // 0x01437BCC: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x01437BD0: LDR x9, [x9, #0x698]       | X9 = (string**)(1152921510033349600)("target");
            // 0x01437BD4: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x01437BD8: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x01437BDC: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x01437BE0: LDR x1, [x9]               | X1 = "target";                          
            // 0x01437BE4: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x01437BE8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x01437BEC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437BF0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x01437BF4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437BF8: LDR x21, [x8, #0x10]       | X21 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache2;
            val_9 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache2;
            // 0x01437BFC: CBNZ x21, #0x1437c48       | if (ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache2 != null) goto label_9;
            if(val_9 != null)
            {
                goto label_9;
            }
            // 0x01437C00: ADRP x8, #0x35d0000        | X8 = 56426496 (0x35D0000);              
            // 0x01437C04: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x01437C08: LDR x8, [x8, #0xb28]       | X8 = 1152921510116823104;               
            // 0x01437C0C: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x01437C10: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_target_1(ref object o);
            // 0x01437C14: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_4 = null;
            // 0x01437C18: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x01437C1C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437C20: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437C24: MOV x2, x21                | X2 = 1152921510116823104 (0x10000001486B9040);//ML01
            // 0x01437C28: MOV x22, x0                | X22 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01437C2C: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_target_1(ref object o));
            val_4 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_target_1(ref object o));
            // 0x01437C30: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437C34: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437C38: STR x22, [x8, #0x10]       | ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504783740944
            ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache2 = val_4;
            // 0x01437C3C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437C40: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437C44: LDR x21, [x8, #0x10]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_9 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache2;
            label_9:
            // 0x01437C48: CBNZ x19, #0x1437c50       | if (X1 != 0) goto label_10;             
            if(X1 != 0)
            {
                goto label_10;
            }
            // 0x01437C4C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::get_target_1(ref object o)), ????);
            label_10:
            // 0x01437C50: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437C54: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01437C58: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01437C5C: MOV x2, x21                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x01437C60: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_9);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_9);
            // 0x01437C64: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437C68: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437C6C: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache3;
            val_10 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache3;
            // 0x01437C70: CBNZ x21, #0x1437cbc       | if (ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache3 != null) goto label_11;
            if(val_10 != null)
            {
                goto label_11;
            }
            // 0x01437C74: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x01437C78: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x01437C7C: LDR x8, [x8, #0xaf0]       | X8 = 1152921510116824128;               
            // 0x01437C80: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x01437C84: LDR x21, [x8]              | X21 = static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_target_1(ref object o, object v);
            // 0x01437C88: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_5 = null;
            // 0x01437C8C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x01437C90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437C94: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437C98: MOV x2, x21                | X2 = 1152921510116824128 (0x10000001486B9440);//ML01
            // 0x01437C9C: MOV x22, x0                | X22 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01437CA0: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_target_1(ref object o, object v));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_target_1(ref object o, object v));
            // 0x01437CA4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437CA8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437CAC: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache3 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504783740952
            ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache3 = val_5;
            // 0x01437CB0: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.CEvent_EventBase_Binding);
            // 0x01437CB4: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.__il2cppRuntimeField_static_fields;
            // 0x01437CB8: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_10 = ILRuntime.Runtime.Generated.CEvent_EventBase_Binding.<>f__mg$cache3;
            label_11:
            // 0x01437CBC: CBNZ x19, #0x1437cc4       | if (X1 != 0) goto label_12;             
            if(X1 != 0)
            {
                goto label_12;
            }
            // 0x01437CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.CEvent_EventBase_Binding::set_target_1(ref object o, object v)), ????);
            label_12:
            // 0x01437CC4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x01437CC8: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x01437CCC: MOV x2, x21                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x01437CD0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01437CD4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01437CD8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01437CDC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01437CE0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01437CE4: B #0x28e59c8               | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10); return;
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01437CE8 (21200104), len: 288  VirtAddr: 0x01437CE8 RVA: 0x01437CE8 token: 100664191 methodIndex: 30238 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_name_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01437CE8: STP x20, x19, [sp, #-0x20]! | stack[1152921510116961328] = ???;  stack[1152921510116961336] = ???;  //  dest_result_addr=1152921510116961328 |  dest_result_addr=1152921510116961336
            // 0x01437CEC: STP x29, x30, [sp, #0x10]  | stack[1152921510116961344] = ???;  stack[1152921510116961352] = ???;  //  dest_result_addr=1152921510116961344 |  dest_result_addr=1152921510116961352
            // 0x01437CF0: ADD x29, sp, #0x10         | X29 = (1152921510116961328 + 16) = 1152921510116961344 (0x10000001486DAC40);
            // 0x01437CF4: SUB sp, sp, #0x10          | SP = (1152921510116961328 - 16) = 1152921510116961312 (0x10000001486DAC20);
            // 0x01437CF8: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01437CFC: LDRB w8, [x20, #0x5c]      | W8 = (bool)static_value_0373705C;       
            // 0x01437D00: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01437D04: TBNZ w8, #0, #0x1437d20    | if (static_value_0373705C == true) goto label_0;
            // 0x01437D08: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x01437D0C: LDR x8, [x8, #0x4b8]       | X8 = 0x2B904C4;                         
            // 0x01437D10: LDR w0, [x8]               | W0 = 0x17F5;                            
            // 0x01437D14: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F5, ????);     
            // 0x01437D18: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437D1C: STRB w8, [x20, #0x5c]      | static_value_0373705C = true;            //  dest_result_addr=57897052
            label_0:
            // 0x01437D20: ADRP x20, #0x366e000       | X20 = 57073664 (0x366E000);             
            // 0x01437D24: LDR x19, [x19]             | X19 = X1;                               
            // 0x01437D28: LDR x20, [x20, #0xa60]     | X20 = 1152921504898060288;              
            // 0x01437D2C: CBZ x19, #0x1437d80        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01437D30: LDR x8, [x19]              | X8 = X1;                                
            // 0x01437D34: LDR x1, [x20]              | X1 = typeof(CEvent.EventBase);          
            // 0x01437D38: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437D3C: LDRB w9, [x1, #0x104]      | W9 = CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437D40: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437D44: B.LO #0x1437d5c            | if (X1 + 260 < CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01437D48: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437D4C: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437D50: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437D54: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.EventBase))
            // 0x01437D58: B.EQ #0x1437d84            | if ((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01437D5C: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01437D60: MOV x8, sp                 | X8 = 1152921510116961312 (0x10000001486DAC20);//ML01
            // 0x01437D64: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437D68: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510116949360]
            // 0x01437D6C: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01437D70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437D74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437D78: MOV x0, sp                 | X0 = 1152921510116961312 (0x10000001486DAC20);//ML01
            // 0x01437D7C: BL #0x299a140              | 
            label_1:
            // 0x01437D80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001486DAC20, ????);
            label_3:
            // 0x01437D84: LDR x8, [x19]              | X8 = X1;                                
            // 0x01437D88: LDR x1, [x20]              | X1 = typeof(CEvent.EventBase);          
            // 0x01437D8C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437D90: LDRB w9, [x1, #0x104]      | W9 = CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437D94: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437D98: B.LO #0x1437dc4            | if (X1 + 260 < CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01437D9C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437DA0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437DA4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437DA8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.EventBase))
            // 0x01437DAC: B.NE #0x1437dc4            | if ((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01437DB0: LDR x0, [x19, #0x10]       | X0 = X1 + 16;                           
            // 0x01437DB4: SUB sp, x29, #0x10         | SP = (1152921510116961344 - 16) = 1152921510116961328 (0x10000001486DAC30);
            // 0x01437DB8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01437DBC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01437DC0: RET                        |  return (System.Object)X1 + 16;         
            return (object)X1 + 16;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01437DC4: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01437DC8: ADD x8, sp, #8             | X8 = (1152921510116961312 + 8) = 1152921510116961320 (0x10000001486DAC28);
            // 0x01437DCC: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437DD0: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510116949360]
            // 0x01437DD4: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x01437DD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437DDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01437DE0: ADD x0, sp, #8             | X0 = (1152921510116961312 + 8) = 1152921510116961320 (0x10000001486DAC28);
            // 0x01437DE4: BL #0x299a140              | 
            // 0x01437DE8: MOV x19, x0                | X19 = 1152921510116961320 (0x10000001486DAC28);//ML01
            // 0x01437DEC: MOV x0, sp                 | X0 = 1152921510116961312 (0x10000001486DAC20);//ML01
            label_6:
            // 0x01437DF0: BL #0x299a140              | 
            // 0x01437DF4: MOV x0, x19                | X0 = 1152921510116961320 (0x10000001486DAC28);//ML01
            // 0x01437DF8: BL #0x980800               | X0 = sub_980800( ?? 0x10000001486DAC28, ????);
            // 0x01437DFC: MOV x19, x0                | X19 = 1152921510116961320 (0x10000001486DAC28);//ML01
            // 0x01437E00: ADD x0, sp, #8             | X0 = (1152921510116961312 + 8) = 1152921510116961320 (0x10000001486DAC28);
            // 0x01437E04: B #0x1437df0               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x01437E08 (21200392), len: 292  VirtAddr: 0x01437E08 RVA: 0x01437E08 token: 100664192 methodIndex: 30239 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_name_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x01437E08: STP x22, x21, [sp, #-0x30]! | stack[1152921510117085440] = ???;  stack[1152921510117085448] = ???;  //  dest_result_addr=1152921510117085440 |  dest_result_addr=1152921510117085448
            // 0x01437E0C: STP x20, x19, [sp, #0x10]  | stack[1152921510117085456] = ???;  stack[1152921510117085464] = ???;  //  dest_result_addr=1152921510117085456 |  dest_result_addr=1152921510117085464
            // 0x01437E10: STP x29, x30, [sp, #0x20]  | stack[1152921510117085472] = ???;  stack[1152921510117085480] = ???;  //  dest_result_addr=1152921510117085472 |  dest_result_addr=1152921510117085480
            // 0x01437E14: ADD x29, sp, #0x20         | X29 = (1152921510117085440 + 32) = 1152921510117085472 (0x10000001486F9120);
            // 0x01437E18: SUB sp, sp, #0x10          | SP = (1152921510117085440 - 16) = 1152921510117085424 (0x10000001486F90F0);
            // 0x01437E1C: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01437E20: LDRB w8, [x21, #0x5d]      | W8 = (bool)static_value_0373705D;       
            // 0x01437E24: MOV x19, x2                | X19 = X2;//m1                           
            val_4 = X2;
            // 0x01437E28: MOV x20, x1                | X20 = v;//m1                            
            // 0x01437E2C: TBNZ w8, #0, #0x1437e48    | if (static_value_0373705D == true) goto label_0;
            // 0x01437E30: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x01437E34: LDR x8, [x8, #0xf70]       | X8 = 0x2B904D0;                         
            // 0x01437E38: LDR w0, [x8]               | W0 = 0x17F8;                            
            // 0x01437E3C: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F8, ????);     
            // 0x01437E40: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437E44: STRB w8, [x21, #0x5d]      | static_value_0373705D = true;            //  dest_result_addr=57897053
            label_0:
            // 0x01437E48: LDR x20, [x20]             | X20 = typeof(System.Object);            
            // 0x01437E4C: CBZ x20, #0x1437ea8        | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01437E50: ADRP x9, #0x366e000        | X9 = 57073664 (0x366E000);              
            // 0x01437E54: LDR x9, [x9, #0xa60]       | X9 = 1152921504898060288;               
            // 0x01437E58: LDR x8, [x20]              | X8 = ;                                  
            // 0x01437E5C: LDR x1, [x9]               | X1 = typeof(CEvent.EventBase);          
            // 0x01437E60: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x01437E64: LDRB w9, [x1, #0x104]      | W9 = CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437E68: CMP w10, w9                | STATE = COMPARE(mem[null + 260], CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437E6C: B.LO #0x1437e84            | if (mem[null + 260] < CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01437E70: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x01437E74: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437E78: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437E7C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.EventBase))
            // 0x01437E80: B.EQ #0x1437eb0            | if ((mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01437E84: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01437E88: MOV x8, sp                 | X8 = 1152921510117085424 (0x10000001486F90F0);//ML01
            // 0x01437E8C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x01437E90: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510117073488]
            // 0x01437E94: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01437E98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437E9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437EA0: MOV x0, sp                 | X0 = 1152921510117085424 (0x10000001486F90F0);//ML01
            // 0x01437EA4: BL #0x299a140              | 
            label_1:
            // 0x01437EA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001486F90F0, ????);
            // 0x01437EAC: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_3:
            // 0x01437EB0: CBZ x19, #0x1437ef0        | if (X2 == 0) goto label_4;              
            if(val_4 == 0)
            {
                goto label_4;
            }
            // 0x01437EB4: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01437EB8: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01437EBC: LDR x1, [x8]               | X1 = typeof(System.String);             
            // 0x01437EC0: LDR x8, [x19]              | X8 = X2;                                
            // 0x01437EC4: CMP x8, x1                 | STATE = COMPARE(X2, typeof(System.String))
            // 0x01437EC8: B.EQ #0x1437ef4            | if (val_4 == null) goto label_5;        
            if(val_4 == null)
            {
                goto label_5;
            }
            // 0x01437ECC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x01437ED0: ADD x8, sp, #8             | X8 = (1152921510117085424 + 8) = 1152921510117085432 (0x10000001486F90F8);
            // 0x01437ED4: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X2 + 48, ????);    
            // 0x01437ED8: LDR x0, [sp, #8]           | X0 = val_3;                              //  find_add[1152921510117073488]
            // 0x01437EDC: BL #0x27af090              | X0 = sub_27AF090( ?? val_3, ????);      
            // 0x01437EE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437EE4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            // 0x01437EE8: ADD x0, sp, #8             | X0 = (1152921510117085424 + 8) = 1152921510117085432 (0x10000001486F90F8);
            // 0x01437EEC: BL #0x299a140              | 
            label_4:
            // 0x01437EF0: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_4 = 0;
            label_5:
            // 0x01437EF4: STR x19, [x20, #0x10]      | mem[16] = 0x0;                           //  dest_result_addr=16
            mem[16] = val_4;
            // 0x01437EF8: SUB sp, x29, #0x20         | SP = (1152921510117085472 - 32) = 1152921510117085440 (0x10000001486F9100);
            // 0x01437EFC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01437F00: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01437F04: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01437F08: RET                        |  return;                                
            return;
            // 0x01437F0C: MOV x19, x0                | 
            // 0x01437F10: MOV x0, sp                 | 
            // 0x01437F14: B #0x1437f20               | 
            // 0x01437F18: MOV x19, x0                | 
            // 0x01437F1C: ADD x0, sp, #8             | 
            label_6:
            // 0x01437F20: BL #0x299a140              | 
            // 0x01437F24: MOV x0, x19                | 
            // 0x01437F28: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x01437F2C (21200684), len: 288  VirtAddr: 0x01437F2C RVA: 0x01437F2C token: 100664193 methodIndex: 30240 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_target_1(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x01437F2C: STP x20, x19, [sp, #-0x20]! | stack[1152921510117209584] = ???;  stack[1152921510117209592] = ???;  //  dest_result_addr=1152921510117209584 |  dest_result_addr=1152921510117209592
            // 0x01437F30: STP x29, x30, [sp, #0x10]  | stack[1152921510117209600] = ???;  stack[1152921510117209608] = ???;  //  dest_result_addr=1152921510117209600 |  dest_result_addr=1152921510117209608
            // 0x01437F34: ADD x29, sp, #0x10         | X29 = (1152921510117209584 + 16) = 1152921510117209600 (0x1000000148717600);
            // 0x01437F38: SUB sp, sp, #0x10          | SP = (1152921510117209584 - 16) = 1152921510117209568 (0x10000001487175E0);
            // 0x01437F3C: ADRP x20, #0x3737000       | X20 = 57896960 (0x3737000);             
            // 0x01437F40: LDRB w8, [x20, #0x5e]      | W8 = (bool)static_value_0373705E;       
            // 0x01437F44: MOV x19, x1                | X19 = X1;//m1                           
            // 0x01437F48: TBNZ w8, #0, #0x1437f64    | if (static_value_0373705E == true) goto label_0;
            // 0x01437F4C: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01437F50: LDR x8, [x8, #0x400]       | X8 = 0x2B904C8;                         
            // 0x01437F54: LDR w0, [x8]               | W0 = 0x17F6;                            
            // 0x01437F58: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F6, ????);     
            // 0x01437F5C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01437F60: STRB w8, [x20, #0x5e]      | static_value_0373705E = true;            //  dest_result_addr=57897054
            label_0:
            // 0x01437F64: ADRP x20, #0x366e000       | X20 = 57073664 (0x366E000);             
            // 0x01437F68: LDR x19, [x19]             | X19 = X1;                               
            // 0x01437F6C: LDR x20, [x20, #0xa60]     | X20 = 1152921504898060288;              
            // 0x01437F70: CBZ x19, #0x1437fc4        | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x01437F74: LDR x8, [x19]              | X8 = X1;                                
            // 0x01437F78: LDR x1, [x20]              | X1 = typeof(CEvent.EventBase);          
            // 0x01437F7C: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437F80: LDRB w9, [x1, #0x104]      | W9 = CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437F84: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437F88: B.LO #0x1437fa0            | if (X1 + 260 < CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x01437F8C: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437F90: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437F94: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437F98: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.EventBase))
            // 0x01437F9C: B.EQ #0x1437fc8            | if ((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x01437FA0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x01437FA4: MOV x8, sp                 | X8 = 1152921510117209568 (0x10000001487175E0);//ML01
            // 0x01437FA8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01437FAC: LDR x0, [sp]               | X0 = val_2;                              //  find_add[1152921510117197616]
            // 0x01437FB0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x01437FB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01437FB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x01437FBC: MOV x0, sp                 | X0 = 1152921510117209568 (0x10000001487175E0);//ML01
            // 0x01437FC0: BL #0x299a140              | 
            label_1:
            // 0x01437FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000001487175E0, ????);
            label_3:
            // 0x01437FC8: LDR x8, [x19]              | X8 = X1;                                
            // 0x01437FCC: LDR x1, [x20]              | X1 = typeof(CEvent.EventBase);          
            // 0x01437FD0: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x01437FD4: LDRB w9, [x1, #0x104]      | W9 = CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x01437FD8: CMP w10, w9                | STATE = COMPARE(X1 + 260, CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x01437FDC: B.LO #0x1438008            | if (X1 + 260 < CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x01437FE0: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x01437FE4: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x01437FE8: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x01437FEC: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.EventBase))
            // 0x01437FF0: B.NE #0x1438008            | if ((X1 + 176 + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x01437FF4: LDR x0, [x19, #0x18]       | X0 = X1 + 24;                           
            // 0x01437FF8: SUB sp, x29, #0x10         | SP = (1152921510117209600 - 16) = 1152921510117209584 (0x10000001487175F0);
            // 0x01437FFC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01438000: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01438004: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x01438008: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x0143800C: ADD x8, sp, #8             | X8 = (1152921510117209568 + 8) = 1152921510117209576 (0x10000001487175E8);
            // 0x01438010: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x01438014: LDR x0, [sp, #8]           | X0 = val_4;                              //  find_add[1152921510117197616]
            // 0x01438018: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x0143801C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01438020: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x01438024: ADD x0, sp, #8             | X0 = (1152921510117209568 + 8) = 1152921510117209576 (0x10000001487175E8);
            // 0x01438028: BL #0x299a140              | 
            // 0x0143802C: MOV x19, x0                | X19 = 1152921510117209576 (0x10000001487175E8);//ML01
            // 0x01438030: MOV x0, sp                 | X0 = 1152921510117209568 (0x10000001487175E0);//ML01
            label_6:
            // 0x01438034: BL #0x299a140              | 
            // 0x01438038: MOV x0, x19                | X0 = 1152921510117209576 (0x10000001487175E8);//ML01
            // 0x0143803C: BL #0x980800               | X0 = sub_980800( ?? 0x10000001487175E8, ????);
            // 0x01438040: MOV x19, x0                | X19 = 1152921510117209576 (0x10000001487175E8);//ML01
            // 0x01438044: ADD x0, sp, #8             | X0 = (1152921510117209568 + 8) = 1152921510117209576 (0x10000001487175E8);
            // 0x01438048: B #0x1438034               |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x0143804C (21200972), len: 208  VirtAddr: 0x0143804C RVA: 0x0143804C token: 100664194 methodIndex: 30241 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_target_1(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x0143804C: STP x22, x21, [sp, #-0x30]! | stack[1152921510117333696] = ???;  stack[1152921510117333704] = ???;  //  dest_result_addr=1152921510117333696 |  dest_result_addr=1152921510117333704
            // 0x01438050: STP x20, x19, [sp, #0x10]  | stack[1152921510117333712] = ???;  stack[1152921510117333720] = ???;  //  dest_result_addr=1152921510117333712 |  dest_result_addr=1152921510117333720
            // 0x01438054: STP x29, x30, [sp, #0x20]  | stack[1152921510117333728] = ???;  stack[1152921510117333736] = ???;  //  dest_result_addr=1152921510117333728 |  dest_result_addr=1152921510117333736
            // 0x01438058: ADD x29, sp, #0x20         | X29 = (1152921510117333696 + 32) = 1152921510117333728 (0x1000000148735AE0);
            // 0x0143805C: SUB sp, sp, #0x10          | SP = (1152921510117333696 - 16) = 1152921510117333680 (0x1000000148735AB0);
            // 0x01438060: ADRP x21, #0x3737000       | X21 = 57896960 (0x3737000);             
            // 0x01438064: LDRB w8, [x21, #0x5f]      | W8 = (bool)static_value_0373705F;       
            // 0x01438068: MOV x19, x2                | X19 = X2;//m1                           
            // 0x0143806C: MOV x20, x1                | X20 = v;//m1                            
            // 0x01438070: TBNZ w8, #0, #0x143808c    | if (static_value_0373705F == true) goto label_0;
            // 0x01438074: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x01438078: LDR x8, [x8, #0x9f8]       | X8 = 0x2B904D4;                         
            // 0x0143807C: LDR w0, [x8]               | W0 = 0x17F9;                            
            val_3 = 6137;
            // 0x01438080: BL #0x2782188              | X0 = sub_2782188( ?? 0x17F9, ????);     
            // 0x01438084: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01438088: STRB w8, [x21, #0x5f]      | static_value_0373705F = true;            //  dest_result_addr=57897055
            label_0:
            // 0x0143808C: LDR x8, [x20]              | X8 = typeof(System.Object);             
            // 0x01438090: CBZ x8, #0x1438104         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x01438094: ADRP x10, #0x366e000       | X10 = 57073664 (0x366E000);             
            // 0x01438098: LDR x10, [x10, #0xa60]     | X10 = 1152921504898060288;              
            // 0x0143809C: LDR x9, [x8]               | X9 = ;                                  
            // 0x014380A0: LDR x1, [x10]              | X1 = typeof(CEvent.EventBase);          
            // 0x014380A4: LDRB w11, [x9, #0x104]     |  //  not_find_field!1:260
            // 0x014380A8: LDRB w10, [x1, #0x104]     | W10 = CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x014380AC: CMP w11, w10               | STATE = COMPARE(mem[null + 260], CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x014380B0: B.LO #0x14380e0            | if (mem[null + 260] < CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
            // 0x014380B4: LDR x11, [x9, #0xb0]       |  //  not_find_field!1:176
            // 0x014380B8: ADD x10, x11, x10, lsl #3  | X10 = (mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x014380BC: LDUR x10, [x10, #-8]       | X10 = (mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x014380C0: CMP x10, x1                | STATE = COMPARE((mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(CEvent.EventBase))
            // 0x014380C4: B.NE #0x14380e0            | if ((mem[null + 176] + (CEvent.EventBase.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_3;
            // 0x014380C8: STR x19, [x8, #0x18]       | typeof(System.Object).__il2cppRuntimeField_18 = X2;  //  dest_result_addr=1152921504606900248
            typeof(System.Object).__il2cppRuntimeField_18 = X2;
            // 0x014380CC: SUB sp, x29, #0x20         | SP = (1152921510117333728 - 32) = 1152921510117333696 (0x1000000148735AC0);
            // 0x014380D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x014380D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x014380D8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x014380DC: RET                        |  return;                                
            return;
            label_3:
            // 0x014380E0: LDR x0, [x9, #0x30]        |  //  not_find_field!1:48
            // 0x014380E4: ADD x8, sp, #8             | X8 = (1152921510117333680 + 8) = 1152921510117333688 (0x1000000148735AB8);
            // 0x014380E8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x014380EC: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510117321744]
            // 0x014380F0: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x014380F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x014380F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x014380FC: ADD x0, sp, #8             | X0 = (1152921510117333680 + 8) = 1152921510117333688 (0x1000000148735AB8);
            // 0x01438100: BL #0x299a140              | 
            label_1:
            // 0x01438104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000148735AB8, ????);
            // 0x01438108: MOV x19, x0                | X19 = 1152921510117333688 (0x1000000148735AB8);//ML01
            // 0x0143810C: ADD x0, sp, #8             | X0 = (1152921510117333680 + 8) = 1152921510117333688 (0x1000000148735AB8);
            // 0x01438110: BL #0x299a140              | 
            // 0x01438114: MOV x0, x19                | X0 = 1152921510117333688 (0x1000000148735AB8);//ML01
            // 0x01438118: BL #0x980800               | X0 = sub_980800( ?? 0x1000000148735AB8, ????);
        
        }
    
    }

}
