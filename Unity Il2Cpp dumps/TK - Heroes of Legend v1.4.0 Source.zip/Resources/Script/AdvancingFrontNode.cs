using UnityEngine;

namespace Pathfinding.Poly2Tri
{
    public class AdvancingFrontNode
    {
        // Fields
        public Pathfinding.Poly2Tri.AdvancingFrontNode Next; //  0x00000010
        public Pathfinding.Poly2Tri.AdvancingFrontNode Prev; //  0x00000018
        public double Value; //  0x00000020
        public Pathfinding.Poly2Tri.TriangulationPoint Point; //  0x00000028
        public Pathfinding.Poly2Tri.DelaunayTriangle Triangle; //  0x00000030
        
        // Properties
        public bool HasNext { get; }
        public bool HasPrev { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0273CFFC (41144316), len: 60  VirtAddr: 0x0273CFFC RVA: 0x0273CFFC token: 100663353 methodIndex: 21570 delegateWrapperIndex: 0 methodInvoker: 0
        public AdvancingFrontNode(Pathfinding.Poly2Tri.TriangulationPoint point)
        {
            //
            // Disasemble & Code
            // 0x0273CFFC: STP x20, x19, [sp, #-0x20]! | stack[1152921509768395904] = ???;  stack[1152921509768395912] = ???;  //  dest_result_addr=1152921509768395904 |  dest_result_addr=1152921509768395912
            // 0x0273D000: STP x29, x30, [sp, #0x10]  | stack[1152921509768395920] = ???;  stack[1152921509768395928] = ???;  //  dest_result_addr=1152921509768395920 |  dest_result_addr=1152921509768395928
            // 0x0273D004: ADD x29, sp, #0x10         | X29 = (1152921509768395904 + 16) = 1152921509768395920 (0x1000000133A6FC90);
            // 0x0273D008: MOV x20, x1                | X20 = point;//m1                        
            // 0x0273D00C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0273D010: MOV x19, x0                | X19 = 1152921509768407936 (0x1000000133A72B80);//ML01
            // 0x0273D014: BL #0x16f59f0              | this..ctor();                           
            // 0x0273D018: STR x20, [x19, #0x28]      | this.Point = point;                      //  dest_result_addr=1152921509768407976
            this.Point = point;
            // 0x0273D01C: CBNZ x20, #0x273d024       | if (point != null) goto label_0;        
            if(point != null)
            {
                goto label_0;
            }
            // 0x0273D020: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x0273D024: LDR x8, [x20, #0x10]       | X8 = point.X; //P2                      
            // 0x0273D028: STR x8, [x19, #0x20]       | this.Value = point.X;                    //  dest_result_addr=1152921509768407968
            this.Value = point.X;
            // 0x0273D02C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0273D030: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0273D034: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0273D038 (41144376), len: 16  VirtAddr: 0x0273D038 RVA: 0x0273D038 token: 100663354 methodIndex: 21571 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasNext()
        {
            //
            // Disasemble & Code
            // 0x0273D038: LDR x8, [x0, #0x10]        | X8 = this.Next; //P2                    
            // 0x0273D03C: CMP x8, #0                 | STATE = COMPARE(this.Next, 0x0)         
            // 0x0273D040: CSET w0, ne                | W0 = this.Next != null ? 1 : 0;         
            var val_1 = (this.Next != 0) ? 1 : 0;
            // 0x0273D044: RET                        |  return (System.Boolean)this.Next != null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0273D048 (41144392), len: 16  VirtAddr: 0x0273D048 RVA: 0x0273D048 token: 100663355 methodIndex: 21572 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_HasPrev()
        {
            //
            // Disasemble & Code
            // 0x0273D048: LDR x8, [x0, #0x18]        | X8 = this.Prev; //P2                    
            // 0x0273D04C: CMP x8, #0                 | STATE = COMPARE(this.Prev, 0x0)         
            // 0x0273D050: CSET w0, ne                | W0 = this.Prev != null ? 1 : 0;         
            var val_1 = (this.Prev != 0) ? 1 : 0;
            // 0x0273D054: RET                        |  return (System.Boolean)this.Prev != null ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
    
    }

}
