using UnityEngine;

namespace ILRuntime.Runtime.Generated
{
    internal class AnimatedColor_Binding
    {
        // Fields
        private static ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate <>f__mg$cache0; // static_offset: 0x00000000
        private static ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate <>f__mg$cache1; // static_offset: 0x00000008
        private static ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate <>f__mg$cache2; // static_offset: 0x00000010
        private static ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate <>f__am$cache0; // static_offset: 0x00000018
        private static ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate <>f__am$cache1; // static_offset: 0x00000020
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00BB8220 (12288544), len: 8  VirtAddr: 0x00BB8220 RVA: 0x00BB8220 token: 100663742 methodIndex: 29787 delegateWrapperIndex: 0 methodInvoker: 0
        public AnimatedColor_Binding()
        {
            //
            // Disasemble & Code
            // 0x00BB8220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8224: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8228 (12288552), len: 852  VirtAddr: 0x00BB8228 RVA: 0x00BB8228 token: 100663743 methodIndex: 29788 delegateWrapperIndex: 0 methodInvoker: 0
        public static void Register(ILRuntime.Runtime.Enviorment.AppDomain app)
        {
            //
            // Disasemble & Code
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_8;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_9;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_10;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_11;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_12;
            //  | 
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_13;
            // 0x00BB8228: STP x24, x23, [sp, #-0x40]! | stack[1152921510041299568] = ???;  stack[1152921510041299576] = ???;  //  dest_result_addr=1152921510041299568 |  dest_result_addr=1152921510041299576
            // 0x00BB822C: STP x22, x21, [sp, #0x10]  | stack[1152921510041299584] = ???;  stack[1152921510041299592] = ???;  //  dest_result_addr=1152921510041299584 |  dest_result_addr=1152921510041299592
            // 0x00BB8230: STP x20, x19, [sp, #0x20]  | stack[1152921510041299600] = ???;  stack[1152921510041299608] = ???;  //  dest_result_addr=1152921510041299600 |  dest_result_addr=1152921510041299608
            // 0x00BB8234: STP x29, x30, [sp, #0x30]  | stack[1152921510041299616] = ???;  stack[1152921510041299624] = ???;  //  dest_result_addr=1152921510041299616 |  dest_result_addr=1152921510041299624
            // 0x00BB8238: ADD x29, sp, #0x30         | X29 = (1152921510041299568 + 48) = 1152921510041299616 (0x1000000143EB2AA0);
            // 0x00BB823C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB8240: LDRB w8, [x20, #0xb4d]     | W8 = (bool)static_value_03733B4D;       
            // 0x00BB8244: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB8248: TBNZ w8, #0, #0xbb8264     | if (static_value_03733B4D == true) goto label_0;
            // 0x00BB824C: ADRP x8, #0x3668000        | X8 = 57049088 (0x3668000);              
            // 0x00BB8250: LDR x8, [x8, #0x608]       | X8 = 0x2B8AD80;                         
            // 0x00BB8254: LDR w0, [x8]               | W0 = 0x21E;                             
            // 0x00BB8258: BL #0x2782188              | X0 = sub_2782188( ?? 0x21E, ????);      
            // 0x00BB825C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB8260: STRB w8, [x20, #0xb4d]     | static_value_03733B4D = true;            //  dest_result_addr=57883469
            label_0:
            // 0x00BB8264: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00BB8268: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x00BB826C: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x00BB8270: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00BB8274: LDR x8, [x8, #0xe28]       | X8 = 1152921504877985792;               
            // 0x00BB8278: LDR x20, [x8]              | X20 = typeof(AnimatedColor);            
            // 0x00BB827C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x00BB8280: TBZ w8, #0, #0xbb8290      | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00BB8284: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x00BB8288: CBNZ w8, #0xbb8290         | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00BB828C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x00BB8290: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB8294: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB8298: MOV x1, x20                | X1 = 1152921504877985792 (0x1000000010294000);//ML01
            // 0x00BB829C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x00BB82A0: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00BB82A4: CBNZ x20, #0xbb82ac        | if (val_1 != null) goto label_3;        
            if(val_1 != null)
            {
                goto label_3;
            }
            // 0x00BB82A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_3:
            // 0x00BB82AC: ADRP x9, #0x362d000        | X9 = 56807424 (0x362D000);              
            // 0x00BB82B0: LDR x8, [x20]              | X8 = typeof(System.Type);               
            // 0x00BB82B4: LDR x9, [x9, #0xc58]       | X9 = (string**)(1152921510041278336)("color");
            // 0x00BB82B8: ORR w2, wzr, #0x1e         | W2 = 30(0x1E);                          
            // 0x00BB82BC: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB82C0: LDR x3, [x8, #0x478]       | X3 = typeof(System.Type).__il2cppRuntimeField_478;
            // 0x00BB82C4: LDR x1, [x9]               | X1 = "color";                           
            // 0x00BB82C8: LDR x9, [x8, #0x470]       | X9 = typeof(System.Type).__il2cppRuntimeField_470;
            // 0x00BB82CC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_470();
            // 0x00BB82D0: ADRP x24, #0x3637000       | X24 = 56848384 (0x3637000);             
            // 0x00BB82D4: LDR x24, [x24, #0x3a8]     | X24 = 1152921504782725120;              
            // 0x00BB82D8: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00BB82DC: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB82E0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB82E4: LDR x22, [x8]              | X22 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache0;
            val_8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache0;
            // 0x00BB82E8: CBNZ x22, #0xbb8334        | if (ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache0 != null) goto label_4;
            if(val_8 != null)
            {
                goto label_4;
            }
            // 0x00BB82EC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x00BB82F0: ADRP x9, #0x35cb000        | X9 = 56406016 (0x35CB000);              
            // 0x00BB82F4: LDR x8, [x8, #0x9c8]       | X8 = 1152921510041278416;               
            // 0x00BB82F8: LDR x9, [x9, #0xd70]       | X9 = 1152921504823992320;               
            // 0x00BB82FC: LDR x22, [x8]              | X22 = static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::get_color_0(ref object o);
            // 0x00BB8300: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate val_2 = null;
            // 0x00BB8304: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate), ????);
            // 0x00BB8308: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB830C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8310: MOV x2, x22                | X2 = 1152921510041278416 (0x1000000143EAD7D0);//ML01
            // 0x00BB8314: MOV x23, x0                | X23 = 1152921504823992320 (0x100000000CF16000);//ML01
            val_9 = val_2;
            // 0x00BB8318: BL #0x28e8fd0              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::get_color_0(ref object o));
            val_2 = new ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::get_color_0(ref object o));
            // 0x00BB831C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8320: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8324: STR x23, [x8]              | ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);  //  dest_result_addr=1152921504782729216
            ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache0 = val_9;
            // 0x00BB8328: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB832C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8330: LDR x22, [x8]              | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldGetterDelegate);
            val_8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache0;
            label_4:
            // 0x00BB8334: CBNZ x19, #0xbb833c        | if (X1 != 0) goto label_5;              
            if(X1 != 0)
            {
                goto label_5;
            }
            // 0x00BB8338: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::get_color_0(ref object o)), ????);
            label_5:
            // 0x00BB833C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8340: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB8344: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB8348: MOV x2, x22                | X2 = 1152921504823992320 (0x100000000CF16000);//ML01
            // 0x00BB834C: BL #0x28e5914              | X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_8);
            X1.RegisterCLRFieldGetter(f:  val_1, getter:  val_8);
            // 0x00BB8350: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8354: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8358: LDR x22, [x8, #8]          | X22 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache1;
            val_10 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache1;
            // 0x00BB835C: CBNZ x22, #0xbb83a8        | if (ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache1 != null) goto label_6;
            if(val_10 != null)
            {
                goto label_6;
            }
            // 0x00BB8360: ADRP x8, #0x35d1000        | X8 = 56430592 (0x35D1000);              
            // 0x00BB8364: ADRP x9, #0x364b000        | X9 = 56930304 (0x364B000);              
            // 0x00BB8368: LDR x8, [x8, #0x9a0]       | X8 = 1152921510041279440;               
            // 0x00BB836C: LDR x9, [x9, #0x430]       | X9 = 1152921504824045568;               
            // 0x00BB8370: LDR x22, [x8]              | X22 = static System.Void ILRuntime.Runtime.Generated.AnimatedColor_Binding::set_color_0(ref object o, object v);
            // 0x00BB8374: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate val_3 = null;
            // 0x00BB8378: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate), ????);
            // 0x00BB837C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8380: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8384: MOV x2, x22                | X2 = 1152921510041279440 (0x1000000143EADBD0);//ML01
            // 0x00BB8388: MOV x23, x0                | X23 = 1152921504824045568 (0x100000000CF23000);//ML01
            val_9 = val_3;
            // 0x00BB838C: BL #0x28e9240              | .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedColor_Binding::set_color_0(ref object o, object v));
            val_3 = new ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedColor_Binding::set_color_0(ref object o, object v));
            // 0x00BB8390: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8394: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8398: STR x23, [x8, #8]          | ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);  //  dest_result_addr=1152921504782729224
            ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache1 = val_9;
            // 0x00BB839C: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB83A0: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB83A4: LDR x22, [x8, #8]          | X22 = typeof(ILRuntime.Runtime.Enviorment.CLRFieldSetterDelegate);
            val_10 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache1;
            label_6:
            // 0x00BB83A8: CBNZ x19, #0xbb83b0        | if (X1 != 0) goto label_7;              
            if(X1 != 0)
            {
                goto label_7;
            }
            // 0x00BB83AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Void ILRuntime.Runtime.Generated.AnimatedColor_Binding::set_color_0(ref object o, object v)), ????);
            label_7:
            // 0x00BB83B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB83B4: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB83B8: MOV x1, x21                | X1 = val_1;//m1                         
            // 0x00BB83BC: MOV x2, x22                | X2 = 1152921504824045568 (0x100000000CF23000);//ML01
            // 0x00BB83C0: BL #0x28e59c8              | X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            X1.RegisterCLRFieldSetter(f:  val_1, setter:  val_10);
            // 0x00BB83C4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB83C8: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB83CC: LDR x21, [x8, #0x18]       | X21 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache0;
            val_11 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache0;
            // 0x00BB83D0: CBNZ x21, #0xbb841c        | if (ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache0 != null) goto label_8;
            if(val_11 != null)
            {
                goto label_8;
            }
            // 0x00BB83D4: ADRP x8, #0x3669000        | X8 = 57053184 (0x3669000);              
            // 0x00BB83D8: ADRP x9, #0x3682000        | X9 = 57155584 (0x3682000);              
            // 0x00BB83DC: LDR x8, [x8, #0x6b8]       | X8 = 1152921510041280464;               
            // 0x00BB83E0: LDR x9, [x9, #0x9a0]       | X9 = 1152921504824152064;               
            // 0x00BB83E4: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__0();
            // 0x00BB83E8: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate val_4 = null;
            // 0x00BB83EC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate), ????);
            // 0x00BB83F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB83F4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB83F8: MOV x2, x21                | X2 = 1152921510041280464 (0x1000000143EADFD0);//ML01
            // 0x00BB83FC: MOV x22, x0                | X22 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB8400: BL #0x28e8d84              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__0());
            val_4 = new ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__0());
            // 0x00BB8404: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8408: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB840C: STR x22, [x8, #0x18]       | ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);  //  dest_result_addr=1152921504782729240
            ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache0 = val_4;
            // 0x00BB8410: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8414: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8418: LDR x21, [x8, #0x18]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateDefaultInstanceDelegate);
            val_11 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache0;
            label_8:
            // 0x00BB841C: CBNZ x19, #0xbb8424        | if (X1 != 0) goto label_9;              
            if(X1 != 0)
            {
                goto label_9;
            }
            // 0x00BB8420: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__0()), ????);
            label_9:
            // 0x00BB8424: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8428: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB842C: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB8430: MOV x2, x21                | X2 = 1152921504824152064 (0x100000000CF3D000);//ML01
            // 0x00BB8434: BL #0x28e5b28              | X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            X1.RegisterCLRCreateDefaultInstance(t:  val_1, createDefaultInstance:  val_11);
            // 0x00BB8438: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB843C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8440: LDR x21, [x8, #0x20]       | X21 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache1;
            val_12 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache1;
            // 0x00BB8444: CBNZ x21, #0xbb8490        | if (ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache1 != null) goto label_10;
            if(val_12 != null)
            {
                goto label_10;
            }
            // 0x00BB8448: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x00BB844C: ADRP x9, #0x3651000        | X9 = 56954880 (0x3651000);              
            // 0x00BB8450: LDR x8, [x8, #0x9b8]       | X8 = 1152921510041281488;               
            // 0x00BB8454: LDR x9, [x9, #0x3f8]       | X9 = 1152921504824205312;               
            // 0x00BB8458: LDR x21, [x8]              | X21 = static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__1(int s);
            // 0x00BB845C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate val_5 = null;
            // 0x00BB8460: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate), ????);
            // 0x00BB8464: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8468: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB846C: MOV x2, x21                | X2 = 1152921510041281488 (0x1000000143EAE3D0);//ML01
            // 0x00BB8470: MOV x22, x0                | X22 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB8474: BL #0x28e8ac8              | .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__1(int s));
            val_5 = new ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__1(int s));
            // 0x00BB8478: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB847C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8480: STR x22, [x8, #0x20]       | ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache1 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);  //  dest_result_addr=1152921504782729248
            ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache1 = val_5;
            // 0x00BB8484: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8488: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB848C: LDR x21, [x8, #0x20]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRCreateArrayInstanceDelegate);
            val_12 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__am$cache1;
            label_10:
            // 0x00BB8490: CBNZ x19, #0xbb8498        | if (X1 != 0) goto label_11;             
            if(X1 != 0)
            {
                goto label_11;
            }
            // 0x00BB8494: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static System.Object ILRuntime.Runtime.Generated.AnimatedColor_Binding::<Register>m__1(int s)), ????);
            label_11:
            // 0x00BB8498: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB849C: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB84A0: MOV x1, x20                | X1 = val_1;//m1                         
            // 0x00BB84A4: MOV x2, x21                | X2 = 1152921504824205312 (0x100000000CF4A000);//ML01
            // 0x00BB84A8: BL #0x28e5bd8              | X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            X1.RegisterCLRCreateArrayInstance(t:  val_1, createArray:  val_12);
            // 0x00BB84AC: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x00BB84B0: LDR x8, [x8, #0xff0]       | X8 = 1152921504987155056;               
            // 0x00BB84B4: LDR x21, [x8]              | X21 = typeof(System.Type[]);            
            // 0x00BB84B8: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB84BC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Type[]), ????);
            // 0x00BB84C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB84C4: MOV x0, x21                | X0 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB84C8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Type[]), ????);
            // 0x00BB84CC: MOV x21, x0                | X21 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB84D0: CBNZ x20, #0xbb84d8        | if (val_1 != null) goto label_12;       
            if(val_1 != null)
            {
                goto label_12;
            }
            // 0x00BB84D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Type[]), ????);
            label_12:
            // 0x00BB84D8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00BB84DC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x00BB84E0: ORR w1, wzr, #0x1e         | W1 = 30(0x1E);                          
            // 0x00BB84E4: MOV x0, x20                | X0 = val_1;//m1                         
            // 0x00BB84E8: MOV x3, x21                | X3 = 1152921504987155056 (0x1000000016AB0A70);//ML01
            // 0x00BB84EC: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB84F0: BL #0x1b6ea10              | X0 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            System.Reflection.ConstructorInfo val_6 = val_1.GetConstructor(bindingAttr:  30, binder:  0, types:  null, modifiers:  0);
            // 0x00BB84F4: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB84F8: MOV x20, x0                | X20 = val_6;//m1                        
            // 0x00BB84FC: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8500: LDR x21, [x8, #0x10]       | X21 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache2;
            val_13 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache2;
            // 0x00BB8504: CBNZ x21, #0xbb8550        | if (ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache2 != null) goto label_13;
            if(val_13 != null)
            {
                goto label_13;
            }
            // 0x00BB8508: ADRP x8, #0x363c000        | X8 = 56868864 (0x363C000);              
            // 0x00BB850C: ADRP x9, #0x3649000        | X9 = 56922112 (0x3649000);              
            // 0x00BB8510: LDR x8, [x8, #0xdc0]       | X8 = 1152921510041286608;               
            // 0x00BB8514: LDR x9, [x9, #0x548]       | X9 = 1152921504823939072;               
            // 0x00BB8518: LDR x21, [x8]              | X21 = static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedColor_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj);
            // 0x00BB851C: LDR x0, [x9]               | X0 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate val_7 = null;
            // 0x00BB8520: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate), ????);
            // 0x00BB8524: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8528: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB852C: MOV x2, x21                | X2 = 1152921510041286608 (0x1000000143EAF7D0);//ML01
            // 0x00BB8530: MOV x22, x0                | X22 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB8534: BL #0x28e3b10              | .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedColor_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            val_7 = new ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedColor_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj));
            // 0x00BB8538: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB853C: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB8540: STR x22, [x8, #0x10]       | ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache2 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);  //  dest_result_addr=1152921504782729232
            ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache2 = val_7;
            // 0x00BB8544: LDR x8, [x24]              | X8 = typeof(ILRuntime.Runtime.Generated.AnimatedColor_Binding);
            // 0x00BB8548: LDR x8, [x8, #0xa0]        | X8 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.__il2cppRuntimeField_static_fields;
            // 0x00BB854C: LDR x21, [x8, #0x10]       | X21 = typeof(ILRuntime.Runtime.Enviorment.CLRRedirectionDelegate);
            val_13 = ILRuntime.Runtime.Generated.AnimatedColor_Binding.<>f__mg$cache2;
            label_13:
            // 0x00BB8550: CBNZ x19, #0xbb8558        | if (X1 != 0) goto label_14;             
            if(X1 != 0)
            {
                goto label_14;
            }
            // 0x00BB8554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(object:  0, method:  static ILRuntime.Runtime.Stack.StackObject* ILRuntime.Runtime.Generated.AnimatedColor_Binding::Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)), ????);
            label_14:
            // 0x00BB8558: MOV x0, x19                | X0 = X1;//m1                            
            // 0x00BB855C: MOV x1, x20                | X1 = val_6;//m1                         
            // 0x00BB8560: MOV x2, x21                | X2 = 1152921504823939072 (0x100000000CF09000);//ML01
            // 0x00BB8564: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8568: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB856C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00BB8570: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB8574: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00BB8578: B #0x28e3b20               | X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_13); return;
            X1.RegisterCLRMethodRedirection(mi:  val_6, func:  val_13);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB857C (12289404), len: 312  VirtAddr: 0x00BB857C RVA: 0x00BB857C token: 100663744 methodIndex: 29789 delegateWrapperIndex: 0 methodInvoker: 0
        private static object get_color_0(ref object o)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            // 0x00BB857C: STP x20, x19, [sp, #-0x20]! | stack[1152921510041432000] = ???;  stack[1152921510041432008] = ???;  //  dest_result_addr=1152921510041432000 |  dest_result_addr=1152921510041432008
            // 0x00BB8580: STP x29, x30, [sp, #0x10]  | stack[1152921510041432016] = ???;  stack[1152921510041432024] = ???;  //  dest_result_addr=1152921510041432016 |  dest_result_addr=1152921510041432024
            // 0x00BB8584: ADD x29, sp, #0x10         | X29 = (1152921510041432000 + 16) = 1152921510041432016 (0x1000000143ED2FD0);
            // 0x00BB8588: SUB sp, sp, #0x20          | SP = (1152921510041432000 - 32) = 1152921510041431968 (0x1000000143ED2FA0);
            // 0x00BB858C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB8590: LDRB w8, [x20, #0xb4e]     | W8 = (bool)static_value_03733B4E;       
            // 0x00BB8594: MOV x19, x1                | X19 = X1;//m1                           
            // 0x00BB8598: TBNZ w8, #0, #0xbb85b4     | if (static_value_03733B4E == true) goto label_0;
            // 0x00BB859C: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00BB85A0: LDR x8, [x8, #0xc88]       | X8 = 0x2B8AD7C;                         
            // 0x00BB85A4: LDR w0, [x8]               | W0 = 0x21D;                             
            // 0x00BB85A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x21D, ????);      
            // 0x00BB85AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB85B0: STRB w8, [x20, #0xb4e]     | static_value_03733B4E = true;            //  dest_result_addr=57883470
            label_0:
            // 0x00BB85B4: ADRP x20, #0x362d000       | X20 = 56807424 (0x362D000);             
            // 0x00BB85B8: LDR x19, [x19]             | X19 = X1;                               
            // 0x00BB85BC: LDR x20, [x20, #0x1c8]     | X20 = 1152921504877985792;              
            // 0x00BB85C0: CBZ x19, #0xbb8614         | if (X1 == 0) goto label_1;              
            if(X1 == 0)
            {
                goto label_1;
            }
            // 0x00BB85C4: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB85C8: LDR x1, [x20]              | X1 = typeof(AnimatedColor);             
            // 0x00BB85CC: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB85D0: LDRB w9, [x1, #0x104]      | W9 = AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB85D4: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB85D8: B.LO #0xbb85f0             | if (X1 + 260 < AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB85DC: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB85E0: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB85E4: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB85E8: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedColor))
            // 0x00BB85EC: B.EQ #0xbb8618             | if ((X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB85F0: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB85F4: ADD x8, sp, #0x10          | X8 = (1152921510041431968 + 16) = 1152921510041431984 (0x1000000143ED2FB0);
            // 0x00BB85F8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB85FC: LDR x0, [sp, #0x10]        | X0 = val_2;                              //  find_add[1152921510041420032]
            // 0x00BB8600: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB8604: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8608: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB860C: ADD x0, sp, #0x10          | X0 = (1152921510041431968 + 16) = 1152921510041431984 (0x1000000143ED2FB0);
            // 0x00BB8610: BL #0x299a140              | 
            label_1:
            // 0x00BB8614: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143ED2FB0, ????);
            label_3:
            // 0x00BB8618: LDR x8, [x19]              | X8 = X1;                                
            // 0x00BB861C: LDR x1, [x20]              | X1 = typeof(AnimatedColor);             
            // 0x00BB8620: LDRB w10, [x8, #0x104]     | W10 = X1 + 260;                         
            // 0x00BB8624: LDRB w9, [x1, #0x104]      | W9 = AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB8628: CMP w10, w9                | STATE = COMPARE(X1 + 260, AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB862C: B.LO #0xbb8670             | if (X1 + 260 < AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) goto label_5;
            // 0x00BB8630: LDR x10, [x8, #0xb0]       | X10 = X1 + 176;                         
            // 0x00BB8634: ADD x9, x10, x9, lsl #3    | X9 = (X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB8638: LDUR x9, [x9, #-8]         | X9 = (X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB863C: CMP x9, x1                 | STATE = COMPARE((X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedColor))
            // 0x00BB8640: B.NE #0xbb8670             | if ((X1 + 176 + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_5;
            // 0x00BB8644: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00BB8648: LDUR q0, [x19, #0x18]      | Q0 = X1 + 24;                           
            // 0x00BB864C: LDR x8, [x8, #0x178]       | X8 = 1152921504700510208;               
            // 0x00BB8650: MOV x1, sp                 | X1 = 1152921510041431968 (0x1000000143ED2FA0);//ML01
            // 0x00BB8654: STR q0, [sp]               | stack[1152921510041431968] = X1 + 24;    //  dest_result_addr=1152921510041431968
            // 0x00BB8658: LDR x0, [x8]               | X0 = typeof(UnityEngine.Color);         
            // 0x00BB865C: BL #0x27bc028              | X0 = 1152921510041480048 = (Il2CppObject*)Box((RuntimeClass*)typeof(UnityEngine.Color), X1 + 24);
            // 0x00BB8660: SUB sp, x29, #0x10         | SP = (1152921510041432016 - 16) = 1152921510041432000 (0x1000000143ED2FC0);
            // 0x00BB8664: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8668: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB866C: RET                        |  return (System.Object)X1 + 24;         
            return (object)X1 + 24;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_5:
            // 0x00BB8670: LDR x0, [x8, #0x30]        | X0 = X1 + 48;                           
            // 0x00BB8674: ADD x8, sp, #0x18          | X8 = (1152921510041431968 + 24) = 1152921510041431992 (0x1000000143ED2FB8);
            // 0x00BB8678: BL #0x27d96d4              | X0 = sub_27D96D4( ?? X1 + 48, ????);    
            // 0x00BB867C: LDR x0, [sp, #0x18]        | X0 = val_4;                              //  find_add[1152921510041420032]
            // 0x00BB8680: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB8684: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8688: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB868C: ADD x0, sp, #0x18          | X0 = (1152921510041431968 + 24) = 1152921510041431992 (0x1000000143ED2FB8);
            // 0x00BB8690: BL #0x299a140              | 
            // 0x00BB8694: MOV x19, x0                | X19 = 1152921510041431992 (0x1000000143ED2FB8);//ML01
            // 0x00BB8698: ADD x0, sp, #0x10          | X0 = (1152921510041431968 + 16) = 1152921510041431984 (0x1000000143ED2FB0);
            label_6:
            // 0x00BB869C: BL #0x299a140              | 
            // 0x00BB86A0: MOV x0, x19                | X0 = 1152921510041431992 (0x1000000143ED2FB8);//ML01
            // 0x00BB86A4: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143ED2FB8, ????);
            // 0x00BB86A8: MOV x19, x0                | X19 = 1152921510041431992 (0x1000000143ED2FB8);//ML01
            // 0x00BB86AC: ADD x0, sp, #0x18          | X0 = (1152921510041431968 + 24) = 1152921510041431992 (0x1000000143ED2FB8);
            // 0x00BB86B0: B #0xbb869c                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB86B4 (12289716), len: 412  VirtAddr: 0x00BB86B4 RVA: 0x00BB86B4 token: 100663745 methodIndex: 29790 delegateWrapperIndex: 0 methodInvoker: 0
        private static void set_color_0(ref object o, object v)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x00BB86B4: STP x22, x21, [sp, #-0x30]! | stack[1152921510041560208] = ???;  stack[1152921510041560216] = ???;  //  dest_result_addr=1152921510041560208 |  dest_result_addr=1152921510041560216
            // 0x00BB86B8: STP x20, x19, [sp, #0x10]  | stack[1152921510041560224] = ???;  stack[1152921510041560232] = ???;  //  dest_result_addr=1152921510041560224 |  dest_result_addr=1152921510041560232
            // 0x00BB86BC: STP x29, x30, [sp, #0x20]  | stack[1152921510041560240] = ???;  stack[1152921510041560248] = ???;  //  dest_result_addr=1152921510041560240 |  dest_result_addr=1152921510041560248
            // 0x00BB86C0: ADD x29, sp, #0x20         | X29 = (1152921510041560208 + 32) = 1152921510041560240 (0x1000000143EF24B0);
            // 0x00BB86C4: SUB sp, sp, #0x20          | SP = (1152921510041560208 - 32) = 1152921510041560176 (0x1000000143EF2470);
            // 0x00BB86C8: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00BB86CC: LDRB w8, [x21, #0xb4f]     | W8 = (bool)static_value_03733B4F;       
            // 0x00BB86D0: MOV x19, x2                | X19 = X2;//m1                           
            // 0x00BB86D4: MOV x20, x1                | X20 = v;//m1                            
            // 0x00BB86D8: TBNZ w8, #0, #0xbb86f4     | if (static_value_03733B4F == true) goto label_0;
            // 0x00BB86DC: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00BB86E0: LDR x8, [x8, #0xe90]       | X8 = 0x2B8AD84;                         
            // 0x00BB86E4: LDR w0, [x8]               | W0 = 0x21F;                             
            // 0x00BB86E8: BL #0x2782188              | X0 = sub_2782188( ?? 0x21F, ????);      
            // 0x00BB86EC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB86F0: STRB w8, [x21, #0xb4f]     | static_value_03733B4F = true;            //  dest_result_addr=57883471
            label_0:
            // 0x00BB86F4: LDR x21, [x20]             | X21 = typeof(System.Object);            
            // 0x00BB86F8: CBZ x21, #0xbb87ac         | if (typeof(System.Object) == null) goto label_1;
            if(null == null)
            {
                goto label_1;
            }
            // 0x00BB86FC: ADRP x20, #0x362d000       | X20 = 56807424 (0x362D000);             
            // 0x00BB8700: LDR x20, [x20, #0x1c8]     | X20 = 1152921504877985792;              
            // 0x00BB8704: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB8708: LDR x1, [x20]              | X1 = typeof(AnimatedColor);             
            // 0x00BB870C: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB8710: LDRB w9, [x1, #0x104]      | W9 = AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB8714: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB8718: B.LO #0xbb8730             | if (mem[null + 260] < AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) goto label_2;
            // 0x00BB871C: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB8720: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB8724: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB8728: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedColor))
            // 0x00BB872C: B.EQ #0xbb8758             | if ((mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_3;
            label_2:
            // 0x00BB8730: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB8734: ADD x8, sp, #8             | X8 = (1152921510041560176 + 8) = 1152921510041560184 (0x1000000143EF2478);
            // 0x00BB8738: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB873C: LDR x0, [sp, #8]           | X0 = val_2;                              //  find_add[1152921510041548256]
            // 0x00BB8740: BL #0x27af090              | X0 = sub_27AF090( ?? val_2, ????);      
            // 0x00BB8744: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8748: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            // 0x00BB874C: ADD x0, sp, #8             | X0 = (1152921510041560176 + 8) = 1152921510041560184 (0x1000000143EF2478);
            // 0x00BB8750: BL #0x299a140              | 
            // 0x00BB8754: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1000000143EF2478, ????);
            label_3:
            // 0x00BB8758: LDR x8, [x21]              | X8 = ;                                  
            // 0x00BB875C: LDR x1, [x20]              | X1 = typeof(AnimatedColor);             
            // 0x00BB8760: LDRB w10, [x8, #0x104]     |  //  not_find_field!1:260
            // 0x00BB8764: LDRB w9, [x1, #0x104]      | W9 = AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x00BB8768: CMP w10, w9                | STATE = COMPARE(mem[null + 260], AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x00BB876C: B.LO #0xbb8784             | if (mem[null + 260] < AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x00BB8770: LDR x10, [x8, #0xb0]       |  //  not_find_field!1:176
            // 0x00BB8774: ADD x9, x10, x9, lsl #3    | X9 = (mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3);
            // 0x00BB8778: LDUR x9, [x9, #-8]         | X9 = (mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x00BB877C: CMP x9, x1                 | STATE = COMPARE((mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(AnimatedColor))
            // 0x00BB8780: B.EQ #0xbb87b4             | if ((mem[null + 176] + (AnimatedColor.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x00BB8784: LDR x0, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x00BB8788: ADD x8, sp, #0x10          | X8 = (1152921510041560176 + 16) = 1152921510041560192 (0x1000000143EF2480);
            // 0x00BB878C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? mem[null + 48], ????);
            // 0x00BB8790: LDR x0, [sp, #0x10]        | X0 = val_4;                              //  find_add[1152921510041548256]
            // 0x00BB8794: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x00BB8798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB879C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x00BB87A0: ADD x0, sp, #0x10          | X0 = (1152921510041560176 + 16) = 1152921510041560192 (0x1000000143EF2480);
            // 0x00BB87A4: BL #0x299a140              | 
            // 0x00BB87A8: B #0xbb87b0                |  goto label_6;                          
            goto label_6;
            label_1:
            // 0x00BB87AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x21F, ????);      
            label_6:
            // 0x00BB87B0: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_5:
            // 0x00BB87B4: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x00BB87B8: LDR x8, [x8, #0x178]       | X8 = 1152921504700510208;               
            // 0x00BB87BC: LDR x20, [x8]              | X20 = typeof(UnityEngine.Color);        
            // 0x00BB87C0: CBNZ x19, #0xbb87c8        | if (X2 != 0) goto label_7;              
            if(X2 != 0)
            {
                goto label_7;
            }
            // 0x00BB87C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x21F, ????);      
            label_7:
            // 0x00BB87C8: LDR x8, [x19]              | X8 = X2;                                
            // 0x00BB87CC: LDR x0, [x8, #0x30]        | X0 = X2 + 48;                           
            // 0x00BB87D0: LDR x8, [x20, #0x30]       | X8 = UnityEngine.Color.__il2cppRuntimeField_element_class;
            // 0x00BB87D4: CMP x0, x8                 | STATE = COMPARE(X2 + 48, UnityEngine.Color.__il2cppRuntimeField_element_class)
            // 0x00BB87D8: B.NE #0xbb8820             | if (X2 + 48 != UnityEngine.Color.__il2cppRuntimeField_element_class) goto label_8;
            // 0x00BB87DC: MOV x0, x19                | X0 = X2;//m1                            
            // 0x00BB87E0: BL #0x27bc4e8              | X2.System.IDisposable.Dispose();        
            X2.System.IDisposable.Dispose();
            // 0x00BB87E4: LDR q0, [x0]               | Q0 = X2;                                
            // 0x00BB87E8: STUR q0, [x21, #0x18]      | mem[24] = X2;                            //  dest_result_addr=24
            mem[24] = X2;
            // 0x00BB87EC: SUB sp, x29, #0x20         | SP = (1152921510041560240 - 32) = 1152921510041560208 (0x1000000143EF2490);
            // 0x00BB87F0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB87F4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB87F8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB87FC: RET                        |  return;                                
            return;
            // 0x00BB8800: MOV x19, x0                | X19 = X2;//m1                           
            val_7 = X2;
            // 0x00BB8804: ADD x0, sp, #8             | X0 = (1152921510041560256 + 8) = 1152921510041560264 (0x1000000143EF24C8);
            // 0x00BB8808: B #0xbb8814                |  goto label_10;                         
            goto label_10;
            // 0x00BB880C: MOV x19, x0                | X19 = 1152921510041560264 (0x1000000143EF24C8);//ML01
            val_7;
            // 0x00BB8810: ADD x0, sp, #0x10          | X0 = (1152921510041560256 + 16) = 1152921510041560272 (0x1000000143EF24D0);
            label_10:
            // 0x00BB8814: BL #0x299a140              | 
            // 0x00BB8818: MOV x0, x19                | X0 = 1152921510041560264 (0x1000000143EF24C8);//ML01
            // 0x00BB881C: BL #0x980800               | X0 = sub_980800( ?? 0x1000000143EF24C8, ????);
            label_8:
            // 0x00BB8820: ADD x8, sp, #0x18          | X8 = (1152921510041560256 + 24) = 1152921510041560280 (0x1000000143EF24D8);
            // 0x00BB8824: MOV x1, x20                | X1 = X20;//m1                           
            // 0x00BB8828: BL #0x27d96d4              | X0 = sub_27D96D4( ?? 0x1000000143EF24C8, ????);
            // 0x00BB882C: LDR x0, [sp, #0x18]        | X0 = val_5;                              //  find_add[1152921510041548256]
            // 0x00BB8830: BL #0x27af090              | X0 = sub_27AF090( ?? val_5, ????);      
            // 0x00BB8834: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8838: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_5, ????);      
            // 0x00BB883C: ADD x0, sp, #0x18          | X0 = (1152921510041560256 + 24) = 1152921510041560280 (0x1000000143EF24D8);
            // 0x00BB8840: BL #0x299a140              | 
            // 0x00BB8844: MOV x19, x0                | X19 = 1152921510041560280 (0x1000000143EF24D8);//ML01
            // 0x00BB8848: ADD x0, sp, #0x18          | X0 = (1152921510041560256 + 24) = 1152921510041560280 (0x1000000143EF24D8);
            // 0x00BB884C: B #0xbb8814                |  goto label_10;                         
            goto label_10;
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8850 (12290128), len: 180  VirtAddr: 0x00BB8850 RVA: 0x00BB8850 token: 100663746 methodIndex: 29791 delegateWrapperIndex: 0 methodInvoker: 0
        private static ILRuntime.Runtime.Stack.StackObject* Ctor_0(ILRuntime.Runtime.Intepreter.ILIntepreter __intp, ILRuntime.Runtime.Stack.StackObject* __esp, System.Collections.Generic.IList<object> __mStack, ILRuntime.CLR.Method.CLRMethod __method, bool isNewObj)
        {
            //
            // Disasemble & Code
            // 0x00BB8850: STP x22, x21, [sp, #-0x30]! | stack[1152921510041696704] = ???;  stack[1152921510041696712] = ???;  //  dest_result_addr=1152921510041696704 |  dest_result_addr=1152921510041696712
            // 0x00BB8854: STP x20, x19, [sp, #0x10]  | stack[1152921510041696720] = ???;  stack[1152921510041696728] = ???;  //  dest_result_addr=1152921510041696720 |  dest_result_addr=1152921510041696728
            // 0x00BB8858: STP x29, x30, [sp, #0x20]  | stack[1152921510041696736] = ???;  stack[1152921510041696744] = ???;  //  dest_result_addr=1152921510041696736 |  dest_result_addr=1152921510041696744
            // 0x00BB885C: ADD x29, sp, #0x20         | X29 = (1152921510041696704 + 32) = 1152921510041696736 (0x1000000143F139E0);
            // 0x00BB8860: ADRP x22, #0x3733000       | X22 = 57880576 (0x3733000);             
            // 0x00BB8864: LDRB w8, [x22, #0xb50]     | W8 = (bool)static_value_03733B50;       
            // 0x00BB8868: MOV x19, x3                | X19 = X3;//m1                           
            // 0x00BB886C: MOV x20, x2                | X20 = X2;//m1                           
            // 0x00BB8870: MOV x21, x1                | X21 = X1;//m1                           
            // 0x00BB8874: TBNZ w8, #0, #0xbb8890     | if (static_value_03733B50 == true) goto label_0;
            // 0x00BB8878: ADRP x8, #0x364e000        | X8 = 56942592 (0x364E000);              
            // 0x00BB887C: LDR x8, [x8, #0x1a0]       | X8 = 0x2B8AD78;                         
            // 0x00BB8880: LDR w0, [x8]               | W0 = 0x21C;                             
            // 0x00BB8884: BL #0x2782188              | X0 = sub_2782188( ?? 0x21C, ????);      
            // 0x00BB8888: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB888C: STRB w8, [x22, #0xb50]     | static_value_03733B50 = true;            //  dest_result_addr=57883472
            label_0:
            // 0x00BB8890: CBNZ x21, #0xbb8898        | if (X1 != 0) goto label_1;              
            if(X1 != 0)
            {
                goto label_1;
            }
            // 0x00BB8894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x21C, ????);      
            label_1:
            // 0x00BB8898: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB889C: MOV x0, x21                | X0 = X1;//m1                            
            // 0x00BB88A0: BL #0x1f90204              | X0 = X1.get_AppDomain();                
            ILRuntime.Runtime.Enviorment.AppDomain val_1 = X1.AppDomain;
            // 0x00BB88A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB88A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x00BB88AC: MOV x1, x20                | X1 = X2;//m1                            
            // 0x00BB88B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00BB88B4: BL #0x1f92448              | X0 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            ILRuntime.Runtime.Stack.StackObject* val_2 = ILRuntime.Runtime.Intepreter.ILIntepreter.Minus(a:  ???, b:  ???);
            // 0x00BB88B8: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BB88BC: LDR x8, [x8, #0x1c8]       | X8 = 1152921504877985792;               
            // 0x00BB88C0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00BB88C4: LDR x8, [x8]               | X8 = typeof(AnimatedColor);             
            // 0x00BB88C8: MOV x0, x8                 | X0 = 1152921504877985792 (0x1000000010294000);//ML01
            AnimatedColor val_3 = null;
            // 0x00BB88CC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnimatedColor), ????);
            // 0x00BB88D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB88D4: MOV x21, x0                | X21 = 1152921504877985792 (0x1000000010294000);//ML01
            // 0x00BB88D8: BL #0xb27460               | .ctor();                                
            val_3 = new AnimatedColor();
            // 0x00BB88DC: MOV x1, x20                | X1 = val_2;//m1                         
            // 0x00BB88E0: MOV x2, x19                | X2 = X3;//m1                            
            // 0x00BB88E4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB88E8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00BB88EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00BB88F0: MOV w4, wzr                | W4 = 0 (0x0);//ML01                     
            // 0x00BB88F4: MOV x3, x21                | X3 = 1152921504877985792 (0x1000000010294000);//ML01
            // 0x00BB88F8: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x00BB88FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00BB8900: B #0x1f657ec               | return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
            return ILRuntime.Runtime.Intepreter.ILIntepreter.PushObject(esp:  __esp, mStack:  __mStack, obj:  __method, isBox:  isNewObj);
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8904 (12290308), len: 92  VirtAddr: 0x00BB8904 RVA: 0x00BB8904 token: 100663747 methodIndex: 29792 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__0()
        {
            //
            // Disasemble & Code
            // 0x00BB8904: STP x20, x19, [sp, #-0x20]! | stack[1152921510041825104] = ???;  stack[1152921510041825112] = ???;  //  dest_result_addr=1152921510041825104 |  dest_result_addr=1152921510041825112
            // 0x00BB8908: STP x29, x30, [sp, #0x10]  | stack[1152921510041825120] = ???;  stack[1152921510041825128] = ???;  //  dest_result_addr=1152921510041825120 |  dest_result_addr=1152921510041825128
            // 0x00BB890C: ADD x29, sp, #0x10         | X29 = (1152921510041825104 + 16) = 1152921510041825120 (0x1000000143F32F60);
            // 0x00BB8910: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
            // 0x00BB8914: LDRB w8, [x19, #0xb51]     | W8 = (bool)static_value_03733B51;       
            // 0x00BB8918: TBNZ w8, #0, #0xbb8934     | if (static_value_03733B51 == true) goto label_0;
            // 0x00BB891C: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x00BB8920: LDR x8, [x8, #0x420]       | X8 = 0x2B8AD88;                         
            // 0x00BB8924: LDR w0, [x8]               | W0 = 0x220;                             
            // 0x00BB8928: BL #0x2782188              | X0 = sub_2782188( ?? 0x220, ????);      
            // 0x00BB892C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB8930: STRB w8, [x19, #0xb51]     | static_value_03733B51 = true;            //  dest_result_addr=57883473
            label_0:
            // 0x00BB8934: ADRP x8, #0x362d000        | X8 = 56807424 (0x362D000);              
            // 0x00BB8938: LDR x8, [x8, #0x1c8]       | X8 = 1152921504877985792;               
            // 0x00BB893C: LDR x0, [x8]               | X0 = typeof(AnimatedColor);             
            AnimatedColor val_1 = null;
            // 0x00BB8940: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AnimatedColor), ????);
            // 0x00BB8944: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00BB8948: MOV x19, x0                | X19 = 1152921504877985792 (0x1000000010294000);//ML01
            // 0x00BB894C: BL #0xb27460               | .ctor();                                
            val_1 = new AnimatedColor();
            // 0x00BB8950: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB8954: MOV x0, x19                | X0 = 1152921504877985792 (0x1000000010294000);//ML01
            // 0x00BB8958: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB895C: RET                        |  return (System.Object)typeof(AnimatedColor);
            return (object)val_1;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00BB8960 (12290400), len: 92  VirtAddr: 0x00BB8960 RVA: 0x00BB8960 token: 100663748 methodIndex: 29793 delegateWrapperIndex: 0 methodInvoker: 0
        private static object <Register>m__1(int s)
        {
            //
            // Disasemble & Code
            // 0x00BB8960: STP x20, x19, [sp, #-0x20]! | stack[1152921510041941200] = ???;  stack[1152921510041941208] = ???;  //  dest_result_addr=1152921510041941200 |  dest_result_addr=1152921510041941208
            // 0x00BB8964: STP x29, x30, [sp, #0x10]  | stack[1152921510041941216] = ???;  stack[1152921510041941224] = ???;  //  dest_result_addr=1152921510041941216 |  dest_result_addr=1152921510041941224
            // 0x00BB8968: ADD x29, sp, #0x10         | X29 = (1152921510041941200 + 16) = 1152921510041941216 (0x1000000143F4F4E0);
            // 0x00BB896C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00BB8970: LDRB w8, [x20, #0xb52]     | W8 = (bool)static_value_03733B52;       
            // 0x00BB8974: MOV w19, w1                | W19 = W1;//m1                           
            // 0x00BB8978: TBNZ w8, #0, #0xbb8994     | if (static_value_03733B52 == true) goto label_0;
            // 0x00BB897C: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x00BB8980: LDR x8, [x8, #0xfd8]       | X8 = 0x2B8AD8C;                         
            // 0x00BB8984: LDR w0, [x8]               | W0 = 0x221;                             
            // 0x00BB8988: BL #0x2782188              | X0 = sub_2782188( ?? 0x221, ????);      
            // 0x00BB898C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00BB8990: STRB w8, [x20, #0xb52]     | static_value_03733B52 = true;            //  dest_result_addr=57883474
            label_0:
            // 0x00BB8994: ADRP x8, #0x3683000        | X8 = 57159680 (0x3683000);              
            // 0x00BB8998: LDR x8, [x8, #0x600]       | X8 = 1152921510041925136;               
            // 0x00BB899C: LDR x20, [x8]              | X20 = typeof(AnimatedColor[]);          
            // 0x00BB89A0: MOV x0, x20                | X0 = 1152921510041925136 (0x1000000143F4B610);//ML01
            // 0x00BB89A4: BL #0x277461c              | X0 = sub_277461C( ?? typeof(AnimatedColor[]), ????);
            // 0x00BB89A8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00BB89AC: MOV w1, w19                | W1 = W1;//m1                            
            // 0x00BB89B0: MOV x0, x20                | X0 = 1152921510041925136 (0x1000000143F4B610);//ML01
            // 0x00BB89B4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00BB89B8: B #0x27c1608               | X0 = sub_27C1608( ?? typeof(AnimatedColor[]), ????);
        
        }
    
    }

}
