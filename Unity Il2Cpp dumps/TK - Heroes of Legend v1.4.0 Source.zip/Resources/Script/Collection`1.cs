using UnityEngine;

namespace ILRuntime.Mono.Collections.Generic
{
    public class Collection<T> : IList<T>, ICollection<T>, IEnumerable<T>, IEnumerable, IList, ICollection
    {
        // Fields
        internal T[] items; //  0x00000010
        internal int size; //  0x00000018
        private int version; //  0x0000001C
        
        // Properties
        public int Count { get; }
        public T Item { get; set; }
        private bool System.Collections.Generic.ICollection<T>.IsReadOnly { get; }
        private bool System.Collections.IList.IsFixedSize { get; }
        private bool System.Collections.IList.IsReadOnly { get; }
        private object System.Collections.IList.Item { get; set; }
        private int System.Collections.ICollection.Count { get; }
        private bool System.Collections.ICollection.IsSynchronized { get; }
        private object System.Collections.ICollection.SyncRoot { get; }
        
        // Methods
        // Generic instance method:
        //
        // file offset: 0x01D46B60 VirtAddr: 0x01D46B60 -RVA: 0x01D46B60 
        // -Collection<object>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.CustomAttribute>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.ModuleDefinition>.get_Count
        // -Collection<string>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.TypeReference>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.FieldDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.MethodDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.PropertyDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.EventDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.ModuleReference>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.ExportedType>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.MethodReference>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Resource>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.ExceptionHandler>.get_Count
        //
        // file offset: 0x019D4114 VirtAddr: 0x019D4114 -RVA: 0x019D4114 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.get_Count
        //
        // file offset: 0x019D5A40 VirtAddr: 0x019D5A40 -RVA: 0x019D5A40 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.get_Count
        //
        // file offset: 0x01D483F4 VirtAddr: 0x01D483F4 -RVA: 0x01D483F4 
        // -Collection<uint>.get_Count
        //
        // file offset: 0x01D41E90 VirtAddr: 0x01D41E90 -RVA: 0x01D41E90 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.get_Count
        //
        // file offset: 0x01D45288 VirtAddr: 0x01D45288 -RVA: 0x01D45288 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.get_Count
        //
        // file offset: 0x01D43768 VirtAddr: 0x01D43768 -RVA: 0x01D43768 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.get_Count
        //
        // file offset: 0x019D736C VirtAddr: 0x019D736C -RVA: 0x019D736C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.get_Count
        //
        // file offset: 0x019D8C98 VirtAddr: 0x019D8C98 -RVA: 0x019D8C98 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.get_Count
        //
        //
        // Offset in libil2cpp.so: 0x01D46B60 (30698336), len: 8  VirtAddr: 0x01D46B60 RVA: 0x01D46B60 token: 100663304 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public int get_Count()
        {
            //
            // Disasemble & Code
            // 0x01D46B60: LDR w0, [x0, #0x18]        | 
            // 0x01D46B64: RET                        |  return (System.Int32)this;             
            return (int)this;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46B68 VirtAddr: 0x01D46B68 -RVA: 0x01D46B68 
        // -Collection<object>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.ModuleDefinition>.get_Item
        // -Collection<string>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.CustomAttribute>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.FieldDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.MethodDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.PropertyDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.EventDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.ModuleReference>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.ExportedType>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.TypeReference>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.ExceptionHandler>.get_Item
        //
        // file offset: 0x019D411C VirtAddr: 0x019D411C -RVA: 0x019D411C 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.get_Item
        //
        // file offset: 0x019D5A48 VirtAddr: 0x019D5A48 -RVA: 0x019D5A48 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.get_Item
        //
        // file offset: 0x01D483FC VirtAddr: 0x01D483FC -RVA: 0x01D483FC 
        // -Collection<uint>.get_Item
        //
        // file offset: 0x01D41E98 VirtAddr: 0x01D41E98 -RVA: 0x01D41E98 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.get_Item
        //
        // file offset: 0x01D45290 VirtAddr: 0x01D45290 -RVA: 0x01D45290 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.get_Item
        //
        // file offset: 0x01D43770 VirtAddr: 0x01D43770 -RVA: 0x01D43770 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.get_Item
        //
        // file offset: 0x019D7374 VirtAddr: 0x019D7374 -RVA: 0x019D7374 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.get_Item
        //
        // file offset: 0x019D8CA0 VirtAddr: 0x019D8CA0 -RVA: 0x019D8CA0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.get_Item
        //
        //
        // Offset in libil2cpp.so: 0x01D46B68 (30698344), len: 188  VirtAddr: 0x01D46B68 RVA: 0x01D46B68 token: 100663305 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public T get_Item(int index)
        {
            //
            // Disasemble & Code
            // 0x01D46B68: STP x22, x21, [sp, #-0x30]! | stack[1152921509401455648] = ???;  stack[1152921509401455656] = ???;  //  dest_result_addr=1152921509401455648 |  dest_result_addr=1152921509401455656
            // 0x01D46B6C: STP x20, x19, [sp, #0x10]  | stack[1152921509401455664] = ???;  stack[1152921509401455672] = ???;  //  dest_result_addr=1152921509401455664 |  dest_result_addr=1152921509401455672
            // 0x01D46B70: STP x29, x30, [sp, #0x20]  | stack[1152921509401455680] = ???;  stack[1152921509401455688] = ???;  //  dest_result_addr=1152921509401455680 |  dest_result_addr=1152921509401455688
            // 0x01D46B74: ADD x29, sp, #0x20         | X29 = (1152921509401455648 + 32) = 1152921509401455680 (0x100000011DC7EC40);
            // 0x01D46B78: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01D46B7C: LDRB w8, [x21, #0xa51]     | W8 = (bool)static_value_0373CA51;       
            // 0x01D46B80: MOV w19, w1                | W19 = index;//m1                        
            // 0x01D46B84: MOV x20, x0                | X20 = 1152921509401467696 (0x100000011DC81B30);//ML01
            // 0x01D46B88: TBNZ w8, #0, #0x1d46ba4    | if (static_value_0373CA51 == true) goto label_0;
            // 0x01D46B8C: ADRP x8, #0x360e000        | X8 = 56680448 (0x360E000);              
            // 0x01D46B90: LDR x8, [x8, #0x3b8]       | X8 = 0x2B910F0;                         
            // 0x01D46B94: LDR w0, [x8]               | W0 = 0x1B00;                            
            // 0x01D46B98: BL #0x2782188              | X0 = sub_2782188( ?? 0x1B00, ????);     
            // 0x01D46B9C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D46BA0: STRB w8, [x21, #0xa51]     | static_value_0373CA51 = true;            //  dest_result_addr=57920081
            label_0:
            // 0x01D46BA4: LDR w8, [x20, #0x18]       | 
            // 0x01D46BA8: CMP w8, w19                | STATE = COMPARE(0x1, index)             
            // 0x01D46BAC: B.LE #0x1d46bf0            | if (true <= index) goto label_1;        
            if(true <= index)
            {
                goto label_1;
            }
            // 0x01D46BB0: LDR x20, [x20, #0x10]      | 
            // 0x01D46BB4: CBNZ x20, #0x1d46bbc       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x01D46BB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1B00, ????);     
            label_2:
            // 0x01D46BBC: LDR w8, [x20, #0x18]       | 
            // 0x01D46BC0: SXTW x21, w19              | X21 = (long)(int)(index);               
            // 0x01D46BC4: CMP w8, w19                | STATE = COMPARE(0x1, index)             
            // 0x01D46BC8: B.HI #0x1d46bd8            | if (true > index) goto label_3;         
            if(true > index)
            {
                goto label_3;
            }
            // 0x01D46BCC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1B00, ????);     
            // 0x01D46BD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D46BD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1B00, ????);     
            label_3:
            // 0x01D46BD8: ADD x8, x20, x21, lsl #3   | X8 = (this + ((long)(int)(index)) << 3);
            ILRuntime.Mono.Collections.Generic.Collection<T> val_1 = this + (((long)(int)(index)) << 3);
            // 0x01D46BDC: LDR x0, [x8, #0x20]        | 
            // 0x01D46BE0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D46BE4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D46BE8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D46BEC: RET                        |  return (System.Object)0x1B00;          
            return (object)6912;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
            label_1:
            // 0x01D46BF0: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01D46BF4: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x01D46BF8: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_2 = null;
            // 0x01D46BFC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D46C00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D46C04: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D46C08: BL #0x18cb840              | .ctor();                                
            val_2 = new System.ArgumentOutOfRangeException();
            // 0x01D46C0C: ADRP x8, #0x3680000        | X8 = 57147392 (0x3680000);              
            // 0x01D46C10: LDR x8, [x8, #0xb38]       | X8 = 1152921509401442672;               
            // 0x01D46C14: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D46C18: LDR x1, [x8]               | X1 = public System.Object ILRuntime.Mono.Collections.Generic.Collection<System.Object>::get_Item(int index);
            // 0x01D46C1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D46C20: BL #0x1d41f54              | set_Item(index:  499628400, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
            set_Item(index:  499628400, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46C24 VirtAddr: 0x01D46C24 -RVA: 0x01D46C24 
        // -Collection<object>.set_Item
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.set_Item
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.set_Item
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.set_Item
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.set_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.set_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.set_Item
        //
        // file offset: 0x019D5B04 VirtAddr: 0x019D5B04 -RVA: 0x019D5B04 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.set_Item
        //
        // file offset: 0x019D7430 VirtAddr: 0x019D7430 -RVA: 0x019D7430 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.set_Item
        //
        // file offset: 0x019D41D8 VirtAddr: 0x019D41D8 -RVA: 0x019D41D8 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.set_Item
        //
        // file offset: 0x019D8D70 VirtAddr: 0x019D8D70 -RVA: 0x019D8D70 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.set_Item
        //
        // file offset: 0x01D41F54 VirtAddr: 0x01D41F54 -RVA: 0x01D41F54 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.set_Item
        //
        // file offset: 0x01D4383C VirtAddr: 0x01D4383C -RVA: 0x01D4383C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.set_Item
        //
        // file offset: 0x01D4534C VirtAddr: 0x01D4534C -RVA: 0x01D4534C 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.set_Item
        //
        // file offset: 0x01D484B8 VirtAddr: 0x01D484B8 -RVA: 0x01D484B8 
        // -Collection<uint>.set_Item
        //
        //
        // Offset in libil2cpp.so: 0x01D46C24 (30698532), len: 268  VirtAddr: 0x01D46C24 RVA: 0x01D46C24 token: 100663306 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void set_Item(int index, T value)
        {
            //
            // Disasemble & Code
            // 0x01D46C24: STP x24, x23, [sp, #-0x40]! | stack[1152921509401572752] = ???;  stack[1152921509401572760] = ???;  //  dest_result_addr=1152921509401572752 |  dest_result_addr=1152921509401572760
            // 0x01D46C28: STP x22, x21, [sp, #0x10]  | stack[1152921509401572768] = ???;  stack[1152921509401572776] = ???;  //  dest_result_addr=1152921509401572768 |  dest_result_addr=1152921509401572776
            // 0x01D46C2C: STP x20, x19, [sp, #0x20]  | stack[1152921509401572784] = ???;  stack[1152921509401572792] = ???;  //  dest_result_addr=1152921509401572784 |  dest_result_addr=1152921509401572792
            // 0x01D46C30: STP x29, x30, [sp, #0x30]  | stack[1152921509401572800] = ???;  stack[1152921509401572808] = ???;  //  dest_result_addr=1152921509401572800 |  dest_result_addr=1152921509401572808
            // 0x01D46C34: ADD x29, sp, #0x30         | X29 = (1152921509401572752 + 48) = 1152921509401572800 (0x100000011DC9B5C0);
            // 0x01D46C38: ADRP x23, #0x373c000       | X23 = 57917440 (0x373C000);             
            // 0x01D46C3C: LDRB w8, [x23, #0xa52]     | W8 = (bool)static_value_0373CA52;       
            // 0x01D46C40: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D46C44: MOV x19, x2                | X19 = value;//m1                        
            // 0x01D46C48: MOV w20, w1                | W20 = index;//m1                        
            // 0x01D46C4C: MOV x21, x0                | X21 = 1152921509401584816 (0x100000011DC9E4B0);//ML01
            // 0x01D46C50: TBNZ w8, #0, #0x1d46c6c    | if (static_value_0373CA52 == true) goto label_0;
            // 0x01D46C54: ADRP x8, #0x35ef000        | X8 = 56553472 (0x35EF000);              
            // 0x01D46C58: LDR x8, [x8, #0x728]       | X8 = 0x2B913F8;                         
            // 0x01D46C5C: LDR w0, [x8]               | W0 = 0x1BC2;                            
            // 0x01D46C60: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BC2, ????);     
            // 0x01D46C64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D46C68: STRB w8, [x23, #0xa52]     | static_value_0373CA52 = true;            //  dest_result_addr=57920082
            label_0:
            // 0x01D46C6C: CBNZ x21, #0x1d46c74       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D46C70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1BC2, ????);     
            label_1:
            // 0x01D46C74: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46C78: MOV x0, x21                | X0 = 1152921509401584816 (0x100000011DC9E4B0);//ML01
            // 0x01D46C7C: MOV w1, w20                | W1 = index;//m1                         
            // 0x01D46C80: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46C84: LDR x2, [x8]               | X2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46C88: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46C8C: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168();
            // 0x01D46C90: LDR w8, [x21, #0x18]       | 
            // 0x01D46C94: CMP w8, w20                | STATE = COMPARE(__RuntimeMethodHiddenParam + 24 + 168, index)
            // 0x01D46C98: B.EQ #0x1d46cfc            | if (__RuntimeMethodHiddenParam + 24 + 168 == index) goto label_2;
            if((__RuntimeMethodHiddenParam + 24 + 168) == index)
            {
                goto label_2;
            }
            // 0x01D46C9C: LDR x8, [x21]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D46CA0: MOV x0, x21                | X0 = 1152921509401584816 (0x100000011DC9E4B0);//ML01
            // 0x01D46CA4: MOV x1, x19                | X1 = value;//m1                         
            // 0x01D46CA8: MOV w2, w20                | W2 = index;//m1                         
            // 0x01D46CAC: LDR x9, [x8, #0x340]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_340;
            // 0x01D46CB0: LDR x3, [x8, #0x348]       | X3 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_348;
            // 0x01D46CB4: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_340();
            // 0x01D46CB8: LDR x21, [x21, #0x10]      | 
            // 0x01D46CBC: CBNZ x21, #0x1d46cc4       | if (this != null) goto label_3;         
            if(this != null)
            {
                goto label_3;
            }
            // 0x01D46CC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x01D46CC4: LDR w8, [x21, #0x18]       | 
            // 0x01D46CC8: SXTW x22, w20              | X22 = (long)(int)(index);               
            // 0x01D46CCC: CMP w8, w20                | STATE = COMPARE(typeof(ILRuntime.Mono.Collections.Generic.Collection<T>), index)
            // 0x01D46CD0: B.HI #0x1d46ce0            | if (typeof(ILRuntime.Mono.Collections.Generic.Collection<T>) > index) goto label_4;
            if(null > index)
            {
                goto label_4;
            }
            // 0x01D46CD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01D46CD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D46CDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_4:
            // 0x01D46CE0: ADD x8, x21, x22, lsl #3   | X8 = (this + ((long)(int)(index)) << 3);
            ILRuntime.Mono.Collections.Generic.Collection<T> val_1 = this + (((long)(int)(index)) << 3);
            // 0x01D46CE4: STR x19, [x8, #0x20]       | mem2[0] = value;                         //  dest_result_addr=0
            mem2[0] = value;
            // 0x01D46CE8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D46CEC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D46CF0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D46CF4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D46CF8: RET                        |  return;                                
            return;
            label_2:
            // 0x01D46CFC: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01D46D00: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x01D46D04: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_2 = null;
            // 0x01D46D08: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D46D0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D46D10: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D46D14: BL #0x18cb840              | .ctor();                                
            val_2 = new System.ArgumentOutOfRangeException();
            // 0x01D46D18: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
            // 0x01D46D1C: LDR x8, [x8, #0x800]       | X8 = 1152921509401559792;               
            // 0x01D46D20: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D46D24: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.Object>::set_Item(int index, System.Object value);
            // 0x01D46D28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D46D2C: BL #0x1d41f54              | set_Item(index:  499745520, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam + 24 + 168}});
            set_Item(index:  499745520, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam + 24 + 168}});
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46D30 VirtAddr: 0x01D46D30 -RVA: 0x01D46D30 
        // -Collection<object>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x019D42EC VirtAddr: 0x019D42EC -RVA: 0x019D42EC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x019D5C18 VirtAddr: 0x019D5C18 -RVA: 0x019D5C18 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x019D7544 VirtAddr: 0x019D7544 -RVA: 0x019D7544 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x019D8ED4 VirtAddr: 0x019D8ED4 -RVA: 0x019D8ED4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x01D42060 VirtAddr: 0x01D42060 -RVA: 0x01D42060 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x01D4398C VirtAddr: 0x01D4398C -RVA: 0x01D4398C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x01D45458 VirtAddr: 0x01D45458 -RVA: 0x01D45458 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        // file offset: 0x01D485C4 VirtAddr: 0x01D485C4 -RVA: 0x01D485C4 
        // -Collection<uint>.System.Collections.Generic.ICollection<T>.get_IsReadOnly
        //
        //
        // Offset in libil2cpp.so: 0x01D46D30 (30698800), len: 8  VirtAddr: 0x01D46D30 RVA: 0x01D46D30 token: 100663307 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.Generic.ICollection<T>.get_IsReadOnly()
        {
            //
            // Disasemble & Code
            // 0x01D46D30: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x01D46D34: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46D38 VirtAddr: 0x01D46D38 -RVA: 0x01D46D38 
        // -Collection<object>.System.Collections.IList.get_IsFixedSize
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.get_IsFixedSize
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.get_IsFixedSize
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.get_IsFixedSize
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.get_IsFixedSize
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.get_IsFixedSize
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x019D42F4 VirtAddr: 0x019D42F4 -RVA: 0x019D42F4 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x019D5C20 VirtAddr: 0x019D5C20 -RVA: 0x019D5C20 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x019D754C VirtAddr: 0x019D754C -RVA: 0x019D754C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x019D8EDC VirtAddr: 0x019D8EDC -RVA: 0x019D8EDC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x01D42068 VirtAddr: 0x01D42068 -RVA: 0x01D42068 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x01D43994 VirtAddr: 0x01D43994 -RVA: 0x01D43994 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x01D45460 VirtAddr: 0x01D45460 -RVA: 0x01D45460 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.get_IsFixedSize
        //
        // file offset: 0x01D485CC VirtAddr: 0x01D485CC -RVA: 0x01D485CC 
        // -Collection<uint>.System.Collections.IList.get_IsFixedSize
        //
        //
        // Offset in libil2cpp.so: 0x01D46D38 (30698808), len: 8  VirtAddr: 0x01D46D38 RVA: 0x01D46D38 token: 100663308 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.IList.get_IsFixedSize()
        {
            //
            // Disasemble & Code
            // 0x01D46D38: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x01D46D3C: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46D40 VirtAddr: 0x01D46D40 -RVA: 0x01D46D40 
        // -Collection<object>.System.Collections.IList.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.get_IsReadOnly
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x019D42FC VirtAddr: 0x019D42FC -RVA: 0x019D42FC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x019D5C28 VirtAddr: 0x019D5C28 -RVA: 0x019D5C28 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x019D7554 VirtAddr: 0x019D7554 -RVA: 0x019D7554 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x019D8EE4 VirtAddr: 0x019D8EE4 -RVA: 0x019D8EE4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x01D42070 VirtAddr: 0x01D42070 -RVA: 0x01D42070 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x01D4399C VirtAddr: 0x01D4399C -RVA: 0x01D4399C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x01D45468 VirtAddr: 0x01D45468 -RVA: 0x01D45468 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.get_IsReadOnly
        //
        // file offset: 0x01D485D4 VirtAddr: 0x01D485D4 -RVA: 0x01D485D4 
        // -Collection<uint>.System.Collections.IList.get_IsReadOnly
        //
        //
        // Offset in libil2cpp.so: 0x01D46D40 (30698816), len: 8  VirtAddr: 0x01D46D40 RVA: 0x01D46D40 token: 100663309 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.IList.get_IsReadOnly()
        {
            //
            // Disasemble & Code
            // 0x01D46D40: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x01D46D44: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46D48 VirtAddr: 0x01D46D48 -RVA: 0x01D46D48 
        // -Collection<object>.System.Collections.IList.get_Item
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.get_Item
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.get_Item
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.get_Item
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.get_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.get_Item
        //
        // file offset: 0x019D4304 VirtAddr: 0x019D4304 -RVA: 0x019D4304 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.get_Item
        //
        // file offset: 0x019D5C30 VirtAddr: 0x019D5C30 -RVA: 0x019D5C30 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.get_Item
        //
        // file offset: 0x019D755C VirtAddr: 0x019D755C -RVA: 0x019D755C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.get_Item
        //
        // file offset: 0x019D8EEC VirtAddr: 0x019D8EEC -RVA: 0x019D8EEC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.get_Item
        //
        // file offset: 0x01D42078 VirtAddr: 0x01D42078 -RVA: 0x01D42078 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.get_Item
        //
        // file offset: 0x01D439A4 VirtAddr: 0x01D439A4 -RVA: 0x01D439A4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.get_Item
        //
        // file offset: 0x01D45470 VirtAddr: 0x01D45470 -RVA: 0x01D45470 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.get_Item
        //
        // file offset: 0x01D485DC VirtAddr: 0x01D485DC -RVA: 0x01D485DC 
        // -Collection<uint>.System.Collections.IList.get_Item
        //
        //
        // Offset in libil2cpp.so: 0x01D46D48 (30698824), len: 76  VirtAddr: 0x01D46D48 RVA: 0x01D46D48 token: 100663310 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private object System.Collections.IList.get_Item(int index)
        {
            //
            // Disasemble & Code
            // 0x01D46D48: STP x22, x21, [sp, #-0x30]! | stack[1152921509402024864] = ???;  stack[1152921509402024872] = ???;  //  dest_result_addr=1152921509402024864 |  dest_result_addr=1152921509402024872
            // 0x01D46D4C: STP x20, x19, [sp, #0x10]  | stack[1152921509402024880] = ???;  stack[1152921509402024888] = ???;  //  dest_result_addr=1152921509402024880 |  dest_result_addr=1152921509402024888
            // 0x01D46D50: STP x29, x30, [sp, #0x20]  | stack[1152921509402024896] = ???;  stack[1152921509402024904] = ???;  //  dest_result_addr=1152921509402024896 |  dest_result_addr=1152921509402024904
            // 0x01D46D54: ADD x29, sp, #0x20         | X29 = (1152921509402024864 + 32) = 1152921509402024896 (0x100000011DD09BC0);
            // 0x01D46D58: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D46D5C: MOV w19, w1                | W19 = index;//m1                        
            // 0x01D46D60: MOV x20, x0                | X20 = 1152921509402036912 (0x100000011DD0CAB0);//ML01
            // 0x01D46D64: CBNZ x20, #0x1d46d6c       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D46D68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D46D6C: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46D70: MOV x0, x20                | X0 = 1152921509402036912 (0x100000011DD0CAB0);//ML01
            // 0x01D46D74: MOV w1, w19                | W1 = index;//m1                         
            // 0x01D46D78: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46D7C: LDR x2, [x8, #0x10]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x01D46D80: LDR x3, [x2]               | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 16;
            // 0x01D46D84: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D46D88: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D46D8C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D46D90: BR x3                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 16;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 16;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46D94 VirtAddr: 0x01D46D94 -RVA: 0x01D46D94 
        // -Collection<object>.System.Collections.IList.set_Item
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.set_Item
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.set_Item
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.set_Item
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.set_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.set_Item
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.set_Item
        //
        // file offset: 0x019D4380 VirtAddr: 0x019D4380 -RVA: 0x019D4380 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.set_Item
        //
        // file offset: 0x019D5CAC VirtAddr: 0x019D5CAC -RVA: 0x019D5CAC 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.set_Item
        //
        // file offset: 0x019D75D8 VirtAddr: 0x019D75D8 -RVA: 0x019D75D8 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.set_Item
        //
        // file offset: 0x019D8F78 VirtAddr: 0x019D8F78 -RVA: 0x019D8F78 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.set_Item
        //
        // file offset: 0x01D420F4 VirtAddr: 0x01D420F4 -RVA: 0x01D420F4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.set_Item
        //
        // file offset: 0x01D43A28 VirtAddr: 0x01D43A28 -RVA: 0x01D43A28 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.set_Item
        //
        // file offset: 0x01D454EC VirtAddr: 0x01D454EC -RVA: 0x01D454EC 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.set_Item
        //
        // file offset: 0x01D48658 VirtAddr: 0x01D48658 -RVA: 0x01D48658 
        // -Collection<uint>.System.Collections.IList.set_Item
        //
        //
        // Offset in libil2cpp.so: 0x01D46D94 (30698900), len: 484  VirtAddr: 0x01D46D94 RVA: 0x01D46D94 token: 100663311 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.set_Item(int index, object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D46D94: STP x24, x23, [sp, #-0x40]! | stack[1152921509402140944] = ???;  stack[1152921509402140952] = ???;  //  dest_result_addr=1152921509402140944 |  dest_result_addr=1152921509402140952
            // 0x01D46D98: STP x22, x21, [sp, #0x10]  | stack[1152921509402140960] = ???;  stack[1152921509402140968] = ???;  //  dest_result_addr=1152921509402140960 |  dest_result_addr=1152921509402140968
            // 0x01D46D9C: STP x20, x19, [sp, #0x20]  | stack[1152921509402140976] = ???;  stack[1152921509402140984] = ???;  //  dest_result_addr=1152921509402140976 |  dest_result_addr=1152921509402140984
            // 0x01D46DA0: STP x29, x30, [sp, #0x30]  | stack[1152921509402140992] = ???;  stack[1152921509402141000] = ???;  //  dest_result_addr=1152921509402140992 |  dest_result_addr=1152921509402141000
            // 0x01D46DA4: ADD x29, sp, #0x30         | X29 = (1152921509402140944 + 48) = 1152921509402140992 (0x100000011DD26140);
            // 0x01D46DA8: SUB sp, sp, #0x10          | SP = (1152921509402140944 - 16) = 1152921509402140928 (0x100000011DD26100);
            // 0x01D46DAC: ADRP x23, #0x373c000       | X23 = 57917440 (0x373C000);             
            // 0x01D46DB0: LDRB w8, [x23, #0xa53]     | W8 = (bool)static_value_0373CA53;       
            // 0x01D46DB4: MOV x20, x3                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D46DB8: MOV x22, x2                | X22 = value;//m1                        
            // 0x01D46DBC: MOV w19, w1                | W19 = index;//m1                        
            // 0x01D46DC0: MOV x21, x0                | X21 = 1152921509402153008 (0x100000011DD29030);//ML01
            // 0x01D46DC4: TBNZ w8, #0, #0x1d46de0    | if (static_value_0373CA53 == true) goto label_0;
            // 0x01D46DC8: ADRP x8, #0x35eb000        | X8 = 56537088 (0x35EB000);              
            // 0x01D46DCC: LDR x8, [x8, #0xd58]       | X8 = 0x2B915AC;                         
            // 0x01D46DD0: LDR w0, [x8]               | W0 = 0x1C2F;                            
            // 0x01D46DD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C2F, ????);     
            // 0x01D46DD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D46DDC: STRB w8, [x23, #0xa53]     | static_value_0373CA53 = true;            //  dest_result_addr=57920083
            label_0:
            // 0x01D46DE0: CBNZ x21, #0x1d46de8       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D46DE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C2F, ????);     
            label_1:
            // 0x01D46DE8: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46DEC: MOV x0, x21                | X0 = 1152921509402153008 (0x100000011DD29030);//ML01
            // 0x01D46DF0: MOV w1, w19                | W1 = index;//m1                         
            // 0x01D46DF4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46DF8: LDR x2, [x8]               | X2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46DFC: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46E00: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168();
            // 0x01D46E04: CBNZ x21, #0x1d46e0c       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x01D46E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x01D46E0C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46E10: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46E14: LDP x23, x9, [x8, #0x18]   | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 24; X9 = __RuntimeMethodHiddenParam + 24 + 168 + 24 + 8; //  | 
            // 0x01D46E18: LDR x24, [x9]              | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 24 + 8;
            // 0x01D46E1C: MOV x0, x23                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D46E20: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x01D46E24: CBZ x22, #0x1d46e68        | if (value == null) goto label_3;        
            if(value == null)
            {
                goto label_3;
            }
            // 0x01D46E28: MOV x0, x22                | X0 = value;//m1                         
            // 0x01D46E2C: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D46E30: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x01D46E34: MOV x2, x0                 | X2 = value;//m1                         
            // 0x01D46E38: CBNZ x2, #0x1d46e6c        | if (value != null) goto label_4;        
            if(value != null)
            {
                goto label_4;
            }
            // 0x01D46E3C: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x01D46E40: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01D46E44: ADD x8, sp, #8             | X8 = (1152921509402140928 + 8) = 1152921509402140936 (0x100000011DD26108);
            // 0x01D46E48: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D46E4C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01D46E50: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921509402129008]
            // 0x01D46E54: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x01D46E58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D46E5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x01D46E60: ADD x0, sp, #8             | X0 = (1152921509402140928 + 8) = 1152921509402140936 (0x100000011DD26108);
            // 0x01D46E64: BL #0x299a140              | 
            label_3:
            // 0x01D46E68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            label_4:
            // 0x01D46E6C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46E70: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46E74: LDR x3, [x8, #0x20]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 32;
            // 0x01D46E78: MOV x0, x21                | X0 = 1152921509402153008 (0x100000011DD29030);//ML01
            // 0x01D46E7C: MOV w1, w19                | W1 = index;//m1                         
            // 0x01D46E80: BLR x24                    | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24 + 8();
            // 0x01D46E84: SUB sp, x29, #0x30         | SP = (1152921509402140992 - 48) = 1152921509402140944 (0x100000011DD26110);
            // 0x01D46E88: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D46E8C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D46E90: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D46E94: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D46E98: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46F78 VirtAddr: 0x01D46F78 -RVA: 0x01D46F78 
        // -Collection<object>.System.Collections.ICollection.get_Count
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.ICollection.get_Count
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.ICollection.get_Count
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.ICollection.get_Count
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.ICollection.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.ICollection.get_Count
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x019D4568 VirtAddr: 0x019D4568 -RVA: 0x019D4568 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x019D5E94 VirtAddr: 0x019D5E94 -RVA: 0x019D5E94 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x019D77C0 VirtAddr: 0x019D77C0 -RVA: 0x019D77C0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x019D9178 VirtAddr: 0x019D9178 -RVA: 0x019D9178 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x01D422DC VirtAddr: 0x01D422DC -RVA: 0x01D422DC 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x01D43C28 VirtAddr: 0x01D43C28 -RVA: 0x01D43C28 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x01D456D4 VirtAddr: 0x01D456D4 -RVA: 0x01D456D4 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.ICollection.get_Count
        //
        // file offset: 0x01D48840 VirtAddr: 0x01D48840 -RVA: 0x01D48840 
        // -Collection<uint>.System.Collections.ICollection.get_Count
        //
        //
        // Offset in libil2cpp.so: 0x01D46F78 (30699384), len: 60  VirtAddr: 0x01D46F78 RVA: 0x01D46F78 token: 100663312 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private int System.Collections.ICollection.get_Count()
        {
            //
            // Disasemble & Code
            // 0x01D46F78: STP x20, x19, [sp, #-0x20]! | stack[1152921509402257072] = ???;  stack[1152921509402257080] = ???;  //  dest_result_addr=1152921509402257072 |  dest_result_addr=1152921509402257080
            // 0x01D46F7C: STP x29, x30, [sp, #0x10]  | stack[1152921509402257088] = ???;  stack[1152921509402257096] = ???;  //  dest_result_addr=1152921509402257088 |  dest_result_addr=1152921509402257096
            // 0x01D46F80: ADD x29, sp, #0x10         | X29 = (1152921509402257072 + 16) = 1152921509402257088 (0x100000011DD426C0);
            // 0x01D46F84: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D46F88: MOV x20, x0                | X20 = 1152921509402269104 (0x100000011DD455B0);//ML01
            // 0x01D46F8C: CBNZ x20, #0x1d46f94       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D46F90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D46F94: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46F98: MOV x0, x20                | X0 = 1152921509402269104 (0x100000011DD455B0);//ML01
            // 0x01D46F9C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46FA0: LDR x1, [x8, #0x28]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 40;
            // 0x01D46FA4: LDR x2, [x1]               | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 40;
            // 0x01D46FA8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D46FAC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D46FB0: BR x2                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 40;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 40;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46FB4 VirtAddr: 0x01D46FB4 -RVA: 0x01D46FB4 
        // -Collection<object>.System.Collections.ICollection.get_IsSynchronized
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.ICollection.get_IsSynchronized
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.ICollection.get_IsSynchronized
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.ICollection.get_IsSynchronized
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.ICollection.get_IsSynchronized
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.ICollection.get_IsSynchronized
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x019D45A4 VirtAddr: 0x019D45A4 -RVA: 0x019D45A4 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x019D5ED0 VirtAddr: 0x019D5ED0 -RVA: 0x019D5ED0 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x019D77FC VirtAddr: 0x019D77FC -RVA: 0x019D77FC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x019D91B4 VirtAddr: 0x019D91B4 -RVA: 0x019D91B4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x01D42318 VirtAddr: 0x01D42318 -RVA: 0x01D42318 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x01D43C64 VirtAddr: 0x01D43C64 -RVA: 0x01D43C64 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x01D45710 VirtAddr: 0x01D45710 -RVA: 0x01D45710 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.ICollection.get_IsSynchronized
        //
        // file offset: 0x01D4887C VirtAddr: 0x01D4887C -RVA: 0x01D4887C 
        // -Collection<uint>.System.Collections.ICollection.get_IsSynchronized
        //
        //
        // Offset in libil2cpp.so: 0x01D46FB4 (30699444), len: 8  VirtAddr: 0x01D46FB4 RVA: 0x01D46FB4 token: 100663313 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.ICollection.get_IsSynchronized()
        {
            //
            // Disasemble & Code
            // 0x01D46FB4: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x01D46FB8: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46FBC VirtAddr: 0x01D46FBC -RVA: 0x01D46FBC 
        // -Collection<object>.System.Collections.ICollection.get_SyncRoot
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.ICollection.get_SyncRoot
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.ICollection.get_SyncRoot
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.ICollection.get_SyncRoot
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.ICollection.get_SyncRoot
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.ICollection.get_SyncRoot
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x019D45AC VirtAddr: 0x019D45AC -RVA: 0x019D45AC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x019D5ED8 VirtAddr: 0x019D5ED8 -RVA: 0x019D5ED8 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x019D7804 VirtAddr: 0x019D7804 -RVA: 0x019D7804 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x019D91BC VirtAddr: 0x019D91BC -RVA: 0x019D91BC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x01D42320 VirtAddr: 0x01D42320 -RVA: 0x01D42320 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x01D43C6C VirtAddr: 0x01D43C6C -RVA: 0x01D43C6C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x01D45718 VirtAddr: 0x01D45718 -RVA: 0x01D45718 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.ICollection.get_SyncRoot
        //
        // file offset: 0x01D48884 VirtAddr: 0x01D48884 -RVA: 0x01D48884 
        // -Collection<uint>.System.Collections.ICollection.get_SyncRoot
        //
        //
        // Offset in libil2cpp.so: 0x01D46FBC (30699452), len: 4  VirtAddr: 0x01D46FBC RVA: 0x01D46FBC token: 100663314 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private object System.Collections.ICollection.get_SyncRoot()
        {
            //
            // Disasemble & Code
            // 0x01D46FBC: RET                        |  return (System.Object)this;            
            return (object)this;
            //  |  // // {name=val_0, type=System.Object, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D46FC0 VirtAddr: 0x01D46FC0 -RVA: 0x01D46FC0 
        // -Collection<object>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.ImportTarget>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.ExceptionHandler>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>..ctor
        // -Collection<ILRuntime.Mono.Cecil.TypeReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>..ctor
        // -Collection<ILRuntime.Mono.Cecil.CustomAttribute>..ctor
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>..ctor
        // -Collection<ILRuntime.Mono.Cecil.MethodDefinition>..ctor
        // -Collection<ILRuntime.Mono.Cecil.MethodReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ExportedType>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.StateMachineScope>..ctor
        // -Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ModuleReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Resource>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>..ctor
        // -Collection<ILRuntime.Mono.Cecil.SecurityAttribute>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>..ctor
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>..ctor
        //
        // file offset: 0x019D45B0 VirtAddr: 0x019D45B0 -RVA: 0x019D45B0 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>..ctor
        //
        // file offset: 0x019D7808 VirtAddr: 0x019D7808 -RVA: 0x019D7808 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>..ctor
        //
        // file offset: 0x019D91C0 VirtAddr: 0x019D91C0 -RVA: 0x019D91C0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>..ctor
        //
        // file offset: 0x019D5EDC VirtAddr: 0x019D5EDC -RVA: 0x019D5EDC 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>..ctor
        //
        // file offset: 0x01D42324 VirtAddr: 0x01D42324 -RVA: 0x01D42324 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>..ctor
        //
        // file offset: 0x01D43C70 VirtAddr: 0x01D43C70 -RVA: 0x01D43C70 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>..ctor
        //
        // file offset: 0x01D4571C VirtAddr: 0x01D4571C -RVA: 0x01D4571C 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>..ctor
        //
        // file offset: 0x01D48888 VirtAddr: 0x01D48888 -RVA: 0x01D48888 
        // -Collection<uint>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x01D46FC0 (30699456), len: 176  VirtAddr: 0x01D46FC0 RVA: 0x01D46FC0 token: 100663315 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public Collection<T>()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D46FC0: STP x22, x21, [sp, #-0x30]! | stack[1152921509402593056] = ???;  stack[1152921509402593064] = ???;  //  dest_result_addr=1152921509402593056 |  dest_result_addr=1152921509402593064
            // 0x01D46FC4: STP x20, x19, [sp, #0x10]  | stack[1152921509402593072] = ???;  stack[1152921509402593080] = ???;  //  dest_result_addr=1152921509402593072 |  dest_result_addr=1152921509402593080
            // 0x01D46FC8: STP x29, x30, [sp, #0x20]  | stack[1152921509402593088] = ???;  stack[1152921509402593096] = ???;  //  dest_result_addr=1152921509402593088 |  dest_result_addr=1152921509402593096
            // 0x01D46FCC: ADD x29, sp, #0x20         | X29 = (1152921509402593056 + 32) = 1152921509402593088 (0x100000011DD94740);
            // 0x01D46FD0: MOV x20, x1                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D46FD4: MOV x19, x0                | X19 = 1152921509402605104 (0x100000011DD97630);//ML01
            // 0x01D46FD8: CBNZ x19, #0x1d46fe0       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D46FDC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D46FE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D46FE4: MOV x0, x19                | X0 = 1152921509402605104 (0x100000011DD97630);//ML01
            // 0x01D46FE8: BL #0x16f59f0              | this..ctor();                           
            // 0x01D46FEC: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D46FF0: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D46FF4: LDR x21, [x8, #0x30]       | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            val_1 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 48];
            val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            // 0x01D46FF8: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48;//m1
            // 0x01D46FFC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 48, ????);
            // 0x01D47000: LDRB w8, [x21, #0x10a]     | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 48 + 266;
            // 0x01D47004: TBZ w8, #0, #0x1d47040     | if ((__RuntimeMethodHiddenParam + 24 + 168 + 48 + 266 & 0x1) == 0) goto label_2;
            if(((__RuntimeMethodHiddenParam + 24 + 168 + 48 + 266) & 1) == 0)
            {
                goto label_2;
            }
            // 0x01D47008: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D4700C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47010: LDR x21, [x8, #0x30]       | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            val_1 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 48];
            val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            // 0x01D47014: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48;//m1
            // 0x01D47018: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 48, ????);
            // 0x01D4701C: LDR w8, [x21, #0xbc]       | W8 = __RuntimeMethodHiddenParam + 24 + 168 + 48 + 188;
            // 0x01D47020: CBNZ w8, #0x1d47040        | if (__RuntimeMethodHiddenParam + 24 + 168 + 48 + 188 != 0) goto label_2;
            if((__RuntimeMethodHiddenParam + 24 + 168 + 48 + 188) != 0)
            {
                goto label_2;
            }
            // 0x01D47024: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47028: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D4702C: LDR x21, [x8, #0x30]       | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            val_1 = mem[__RuntimeMethodHiddenParam + 24 + 168 + 48];
            val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            // 0x01D47030: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48;//m1
            // 0x01D47034: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 48, ????);
            // 0x01D47038: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48;//m1
            // 0x01D4703C: BL #0x27977a4              | X0 = sub_27977A4( ?? __RuntimeMethodHiddenParam + 24 + 168 + 48, ????);
            label_2:
            // 0x01D47040: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47044: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47048: LDR x20, [x8, #0x30]       | X20 = __RuntimeMethodHiddenParam + 24 + 168 + 48;
            // 0x01D4704C: MOV x0, x20                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 48;//m1
            // 0x01D47050: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 48, ????);
            // 0x01D47054: LDR x8, [x20, #0xa0]       | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 48 + 160;
            // 0x01D47058: LDR x8, [x8]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 48 + 160;
            // 0x01D4705C: STR x8, [x19, #0x10]       | mem[1152921509402605120] = __RuntimeMethodHiddenParam + 24 + 168 + 48 + 160;  //  dest_result_addr=1152921509402605120
            mem[1152921509402605120] = __RuntimeMethodHiddenParam + 24 + 168 + 48 + 160;
            // 0x01D47060: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47064: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47068: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D4706C: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47070 VirtAddr: 0x01D47070 -RVA: 0x01D47070 
        // -Collection<object>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ModuleDefinition>..ctor
        // -Collection<string>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>..ctor
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>..ctor
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Resource>..ctor
        // -Collection<ILRuntime.Mono.Cecil.TypeReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.MethodReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.CustomAttribute>..ctor
        // -Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>..ctor
        // -Collection<ILRuntime.Mono.Cecil.SecurityAttribute>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ExportedType>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.ConstantDebugInformation>..ctor
        // -Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>..ctor
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>..ctor
        //
        // file offset: 0x019D4660 VirtAddr: 0x019D4660 -RVA: 0x019D4660 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>..ctor
        //
        // file offset: 0x019D9270 VirtAddr: 0x019D9270 -RVA: 0x019D9270 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>..ctor
        //
        // file offset: 0x019D78B8 VirtAddr: 0x019D78B8 -RVA: 0x019D78B8 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>..ctor
        //
        // file offset: 0x019D5F8C VirtAddr: 0x019D5F8C -RVA: 0x019D5F8C 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>..ctor
        //
        // file offset: 0x01D423D4 VirtAddr: 0x01D423D4 -RVA: 0x01D423D4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>..ctor
        //
        // file offset: 0x01D43D20 VirtAddr: 0x01D43D20 -RVA: 0x01D43D20 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>..ctor
        //
        // file offset: 0x01D457CC VirtAddr: 0x01D457CC -RVA: 0x01D457CC 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>..ctor
        //
        // file offset: 0x01D48938 VirtAddr: 0x01D48938 -RVA: 0x01D48938 
        // -Collection<uint>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x01D47070 (30699632), len: 200  VirtAddr: 0x01D47070 RVA: 0x01D47070 token: 100663316 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public Collection<T>(int capacity)
        {
            //
            // Disasemble & Code
            // 0x01D47070: STP x22, x21, [sp, #-0x30]! | stack[1152921509402706080] = ???;  stack[1152921509402706088] = ???;  //  dest_result_addr=1152921509402706080 |  dest_result_addr=1152921509402706088
            // 0x01D47074: STP x20, x19, [sp, #0x10]  | stack[1152921509402706096] = ???;  stack[1152921509402706104] = ???;  //  dest_result_addr=1152921509402706096 |  dest_result_addr=1152921509402706104
            // 0x01D47078: STP x29, x30, [sp, #0x20]  | stack[1152921509402706112] = ???;  stack[1152921509402706120] = ???;  //  dest_result_addr=1152921509402706112 |  dest_result_addr=1152921509402706120
            // 0x01D4707C: ADD x29, sp, #0x20         | X29 = (1152921509402706080 + 32) = 1152921509402706112 (0x100000011DDB00C0);
            // 0x01D47080: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D47084: LDRB w8, [x22, #0xa54]     | W8 = (bool)static_value_0373CA54;       
            // 0x01D47088: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D4708C: MOV w20, w1                | W20 = capacity;//m1                     
            // 0x01D47090: MOV x19, x0                | X19 = 1152921509402718128 (0x100000011DDB2FB0);//ML01
            // 0x01D47094: TBNZ w8, #0, #0x1d470b0    | if (static_value_0373CA54 == true) goto label_0;
            // 0x01D47098: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x01D4709C: LDR x8, [x8, #0xa48]       | X8 = 0x2B90EEC;                         
            // 0x01D470A0: LDR w0, [x8]               | W0 = 0x1A7F;                            
            // 0x01D470A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A7F, ????);     
            // 0x01D470A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D470AC: STRB w8, [x22, #0xa54]     | static_value_0373CA54 = true;            //  dest_result_addr=57920084
            label_0:
            // 0x01D470B0: CBNZ x19, #0x1d470b8       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D470B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A7F, ????);     
            label_1:
            // 0x01D470B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D470BC: MOV x0, x19                | X0 = 1152921509402718128 (0x100000011DDB2FB0);//ML01
            // 0x01D470C0: BL #0x16f59f0              | this..ctor();                           
            // 0x01D470C4: TBNZ w20, #0x1f, #0x1d47104 | if ((capacity & 0x80000000) != 0) goto label_2;
            if((capacity & 2147483648) != 0)
            {
                goto label_2;
            }
            // 0x01D470C8: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D470CC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D470D0: LDR x21, [x8, #0x38]       | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 56;
            // 0x01D470D4: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D470D8: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x01D470DC: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D470E0: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x01D470E4: MOV w1, w20                | W1 = capacity;//m1                      
            // 0x01D470E8: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D470EC: BL #0x27c1608              | X0 = sub_27C1608( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x01D470F0: STR x0, [x19, #0x10]       | mem[1152921509402718144] = __RuntimeMethodHiddenParam + 24 + 168 + 56;  //  dest_result_addr=1152921509402718144
            mem[1152921509402718144] = __RuntimeMethodHiddenParam + 24 + 168 + 56;
            // 0x01D470F4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D470F8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D470FC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47100: RET                        |  return;                                
            return;
            label_2:
            // 0x01D47104: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01D47108: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x01D4710C: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_1 = null;
            // 0x01D47110: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47114: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47118: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D4711C: BL #0x18cb840              | .ctor();                                
            val_1 = new System.ArgumentOutOfRangeException();
            // 0x01D47120: ADRP x8, #0x3606000        | X8 = 56647680 (0x3606000);              
            // 0x01D47124: LDR x8, [x8, #0xf38]       | X8 = 1152921509402693104;               
            // 0x01D47128: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D4712C: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.Object>::.ctor(int capacity);
            // 0x01D47130: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47134: BL #0x1d41f54              | set_Item(index:  500878832, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
            set_Item(index:  500878832, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47138 VirtAddr: 0x01D47138 -RVA: 0x01D47138 
        // -Collection<object>..ctor
        // -Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>..ctor
        // -Collection<ILRuntime.Mono.Cecil.ModuleReference>..ctor
        //
        // file offset: 0x019D4728 VirtAddr: 0x019D4728 -RVA: 0x019D4728 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>..ctor
        //
        // file offset: 0x019D6054 VirtAddr: 0x019D6054 -RVA: 0x019D6054 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>..ctor
        //
        // file offset: 0x019D7980 VirtAddr: 0x019D7980 -RVA: 0x019D7980 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>..ctor
        //
        // file offset: 0x019D9338 VirtAddr: 0x019D9338 -RVA: 0x019D9338 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>..ctor
        //
        // file offset: 0x01D4249C VirtAddr: 0x01D4249C -RVA: 0x01D4249C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>..ctor
        //
        // file offset: 0x01D43DE8 VirtAddr: 0x01D43DE8 -RVA: 0x01D43DE8 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>..ctor
        //
        // file offset: 0x01D45894 VirtAddr: 0x01D45894 -RVA: 0x01D45894 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>..ctor
        //
        // file offset: 0x01D48A00 VirtAddr: 0x01D48A00 -RVA: 0x01D48A00 
        // -Collection<uint>..ctor
        //
        //
        // Offset in libil2cpp.so: 0x01D47138 (30699832), len: 492  VirtAddr: 0x01D47138 RVA: 0x01D47138 token: 100663317 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public Collection<T>(System.Collections.Generic.ICollection<T> items)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x01D47138: STP x24, x23, [sp, #-0x40]! | stack[1152921509402823264] = ???;  stack[1152921509402823272] = ???;  //  dest_result_addr=1152921509402823264 |  dest_result_addr=1152921509402823272
            // 0x01D4713C: STP x22, x21, [sp, #0x10]  | stack[1152921509402823280] = ???;  stack[1152921509402823288] = ???;  //  dest_result_addr=1152921509402823280 |  dest_result_addr=1152921509402823288
            // 0x01D47140: STP x20, x19, [sp, #0x20]  | stack[1152921509402823296] = ???;  stack[1152921509402823304] = ???;  //  dest_result_addr=1152921509402823296 |  dest_result_addr=1152921509402823304
            // 0x01D47144: STP x29, x30, [sp, #0x30]  | stack[1152921509402823312] = ???;  stack[1152921509402823320] = ???;  //  dest_result_addr=1152921509402823312 |  dest_result_addr=1152921509402823320
            // 0x01D47148: ADD x29, sp, #0x30         | X29 = (1152921509402823264 + 48) = 1152921509402823312 (0x100000011DDCCA90);
            // 0x01D4714C: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D47150: LDRB w8, [x22, #0xa55]     | W8 = (bool)static_value_0373CA55;       
            // 0x01D47154: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47158: MOV x20, x1                | X20 = items;//m1                        
            // 0x01D4715C: MOV x19, x0                | X19 = 1152921509402835328 (0x100000011DDCF980);//ML01
            // 0x01D47160: TBNZ w8, #0, #0x1d4717c    | if (static_value_0373CA55 == true) goto label_0;
            // 0x01D47164: ADRP x8, #0x35e1000        | X8 = 56496128 (0x35E1000);              
            // 0x01D47168: LDR x8, [x8, #0x8b0]       | X8 = 0x2B90E90;                         
            // 0x01D4716C: LDR w0, [x8]               | W0 = 0x1A68;                            
            // 0x01D47170: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A68, ????);     
            // 0x01D47174: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D47178: STRB w8, [x22, #0xa55]     | static_value_0373CA55 = true;            //  dest_result_addr=57920085
            label_0:
            // 0x01D4717C: CBNZ x19, #0x1d47184       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D47180: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1A68, ????);     
            label_1:
            // 0x01D47184: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_4 = 0;
            // 0x01D47188: MOV x0, x19                | X0 = 1152921509402835328 (0x100000011DDCF980);//ML01
            // 0x01D4718C: BL #0x16f59f0              | this..ctor();                           
            // 0x01D47190: CBZ x20, #0x1d472e4        | if (items == null) goto label_2;        
            if(items == null)
            {
                goto label_2;
            }
            // 0x01D47194: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47198: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D4719C: LDR x22, [x8, #0x40]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x01D471A0: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64;//m1
            // 0x01D471A4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 64, ????);
            // 0x01D471A8: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.ICollection<T>);
            // 0x01D471AC: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x01D471B0: CBZ x9, #0x1d471dc         | if (System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_3;
            // 0x01D471B4: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x01D471B8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_4 = 0;
            // 0x01D471BC: ADD x10, x10, #8           | X10 = (System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609493000 (0x1000000000286008);
            label_5:
            // 0x01D471C0: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x01D471C4: CMP x12, x22               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, __RuntimeMethodHiddenParam + 24 + 168 + 64)
            // 0x01D471C8: B.EQ #0x1d471f0            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == __RuntimeMethodHiddenParam + 24 + 168 + 64) goto label_4;
            // 0x01D471CC: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x01D471D0: ADD x10, x10, #0x10        | X10 = (1152921504609493000 + 16) = 1152921504609493016 (0x1000000000286018);
            // 0x01D471D4: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x01D471D8: B.LO #0x1d471c0            | if (0 < System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count) goto label_5;
            label_3:
            // 0x01D471DC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01D471E0: MOV x0, x20                | X0 = items;//m1                         
            val_5 = items;
            // 0x01D471E4: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 64;//m1
            val_4 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x01D471E8: BL #0x2776c24              | X0 = sub_2776C24( ?? items, ????);      
            // 0x01D471EC: B #0x1d471fc               |  goto label_6;                          
            goto label_6;
            label_4:
            // 0x01D471F0: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x01D471F4: ADD x8, x8, x9, lsl #4     | X8 = (1152921504609456128 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4);
            // 0x01D471F8: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609456128 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset) << 4).272
            label_6:
            // 0x01D471FC: LDP x8, x1, [x0]           | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 64; X1 = __RuntimeMethodHiddenParam + 24 + 168 + 64 + 8; //  | 
            // 0x01D47200: MOV x0, x20                | X0 = items;//m1                         
            // 0x01D47204: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64();
            // 0x01D47208: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D4720C: MOV w23, w0                | W23 = items;//m1                        
            // 0x01D47210: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47214: LDR x22, [x8, #0x38]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 56;
            // 0x01D47218: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D4721C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x01D47220: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D47224: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x01D47228: MOV w1, w23                | W1 = items;//m1                         
            // 0x01D4722C: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D47230: BL #0x27c1608              | X0 = sub_27C1608( ?? __RuntimeMethodHiddenParam + 24 + 168 + 56, ????);
            // 0x01D47234: MOV x22, x0                | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D47238: STR x22, [x19, #0x10]      | mem[1152921509402835344] = __RuntimeMethodHiddenParam + 24 + 168 + 56;  //  dest_result_addr=1152921509402835344
            mem[1152921509402835344] = __RuntimeMethodHiddenParam + 24 + 168 + 56;
            // 0x01D4723C: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47240: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47244: LDR x21, [x8, #0x40]       | X21 = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x01D47248: MOV x0, x21                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64;//m1
            // 0x01D4724C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 64, ????);
            // 0x01D47250: LDR x8, [x20]              | X8 = typeof(System.Collections.Generic.ICollection<T>);
            // 0x01D47254: LDRH w9, [x8, #0x102]      | W9 = System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x01D47258: CBZ x9, #0x1d47284         | if (System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_7;
            // 0x01D4725C: LDR x10, [x8, #0x98]       | X10 = System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x01D47260: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_5 = 0;
            // 0x01D47264: ADD x10, x10, #8           | X10 = (System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504609493000 (0x1000000000286008);
            label_9:
            // 0x01D47268: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x01D4726C: CMP x12, x21               | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, __RuntimeMethodHiddenParam + 24 + 168 + 64)
            // 0x01D47270: B.EQ #0x1d47298            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == __RuntimeMethodHiddenParam + 24 + 168 + 64) goto label_8;
            // 0x01D47274: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_5 = val_5 + 1;
            // 0x01D47278: ADD x10, x10, #0x10        | X10 = (1152921504609493000 + 16) = 1152921504609493016 (0x1000000000286018);
            // 0x01D4727C: CMP x11, x9                | STATE = COMPARE((0 + 1), System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x01D47280: B.LO #0x1d47268            | if (0 < System.Collections.Generic.ICollection<T>.__il2cppRuntimeField_interface_offsets_count) goto label_9;
            label_7:
            // 0x01D47284: MOVZ w2, #0x5              | W2 = 5 (0x5);//ML01                     
            // 0x01D47288: MOV x0, x20                | X0 = items;//m1                         
            val_6 = items;
            // 0x01D4728C: MOV x1, x21                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 64;//m1
            // 0x01D47290: BL #0x2776c24              | X0 = sub_2776C24( ?? items, ????);      
            // 0x01D47294: B #0x1d472a8               |  goto label_10;                         
            goto label_10;
            label_8:
            // 0x01D47298: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x01D4729C: ADD w9, w9, #5             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5);
            // 0x01D472A0: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504609456128 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5));
            // 0x01D472A4: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504609456128 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 5)).272
            label_10:
            // 0x01D472A8: LDP x8, x3, [x0]           | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 64; X3 = __RuntimeMethodHiddenParam + 24 + 168 + 64 + 8; //  | 
            // 0x01D472AC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01D472B0: MOV x0, x20                | X0 = items;//m1                         
            // 0x01D472B4: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 56;//m1
            // 0x01D472B8: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 64();
            // 0x01D472BC: LDR x20, [x19, #0x10]      | 
            // 0x01D472C0: CBNZ x20, #0x1d472c8       | if (items != null) goto label_11;       
            if(items != null)
            {
                goto label_11;
            }
            // 0x01D472C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? items, ????);      
            label_11:
            // 0x01D472C8: LDR x8, [x20, #0x18]       | 
            // 0x01D472CC: STR w8, [x19, #0x18]       | mem[1152921509402835352] = __RuntimeMethodHiddenParam + 24 + 168 + 64;  //  dest_result_addr=1152921509402835352
            mem[1152921509402835352] = __RuntimeMethodHiddenParam + 24 + 168 + 64;
            // 0x01D472D0: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D472D4: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D472D8: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D472DC: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D472E0: RET                        |  return;                                
            return;
            label_2:
            // 0x01D472E4: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01D472E8: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x01D472EC: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_3 = null;
            // 0x01D472F0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x01D472F4: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
            // 0x01D472F8: LDR x8, [x8, #0x218]       | X8 = (string**)(1152921509402810224)("items");
            // 0x01D472FC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01D47300: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01D47304: LDR x1, [x8]               | X1 = "items";                           
            // 0x01D47308: BL #0x18b3df0              | .ctor(paramName:  "items");             
            val_3 = new System.ArgumentNullException(paramName:  "items");
            // 0x01D4730C: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x01D47310: LDR x8, [x8, #0xc08]       | X8 = 1152921509402810304;               
            // 0x01D47314: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01D47318: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.Object>::.ctor(System.Collections.Generic.ICollection<T> items);
            // 0x01D4731C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x01D47320: BL #0x1d41f54              | set_Item(index:  500996032, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken()});
            set_Item(index:  500996032, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken()});
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47324 VirtAddr: 0x01D47324 -RVA: 0x01D47324 
        // -Collection<object>.Add
        // -Collection<ILRuntime.Mono.Cecil.ModuleDefinition>.Add
        // -Collection<string>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.ExceptionHandler>.Add
        // -Collection<ILRuntime.Mono.Cecil.TypeReference>.Add
        // -Collection<ILRuntime.Mono.Cecil.Resource>.Add
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.Add
        // -Collection<ILRuntime.Mono.Cecil.FieldDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.EventDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.PropertyDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.MethodDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.Add
        // -Collection<ILRuntime.Mono.Cecil.MethodReference>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.CustomAttribute>.Add
        // -Collection<ILRuntime.Mono.Cecil.SecurityDeclaration>.Add
        // -Collection<ILRuntime.Mono.Cecil.SecurityAttribute>.Add
        // -Collection<ILRuntime.Mono.Cecil.ExportedType>.Add
        // -Collection<ILRuntime.Mono.Cecil.ModuleReference>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDebugInformation>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.ConstantDebugInformation>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.ImportTarget>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.StateMachineScope>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.CustomDebugInformation>.Add
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>.Add
        // -Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>.Add
        //
        // file offset: 0x019D4914 VirtAddr: 0x019D4914 -RVA: 0x019D4914 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Add
        //
        // file offset: 0x019D9524 VirtAddr: 0x019D9524 -RVA: 0x019D9524 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Add
        //
        // file offset: 0x019D6240 VirtAddr: 0x019D6240 -RVA: 0x019D6240 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Add
        //
        // file offset: 0x019D7B6C VirtAddr: 0x019D7B6C -RVA: 0x019D7B6C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Add
        //
        // file offset: 0x01D42688 VirtAddr: 0x01D42688 -RVA: 0x01D42688 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Add
        //
        // file offset: 0x01D43FD4 VirtAddr: 0x01D43FD4 -RVA: 0x01D43FD4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Add
        //
        // file offset: 0x01D45A80 VirtAddr: 0x01D45A80 -RVA: 0x01D45A80 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Add
        //
        // file offset: 0x01D48BEC VirtAddr: 0x01D48BEC -RVA: 0x01D48BEC 
        // -Collection<uint>.Add
        //
        //
        // Offset in libil2cpp.so: 0x01D47324 (30700324), len: 216  VirtAddr: 0x01D47324 RVA: 0x01D47324 token: 100663318 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void Add(T item)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x01D47324: STP x22, x21, [sp, #-0x30]! | stack[1152921509402943472] = ???;  stack[1152921509402943480] = ???;  //  dest_result_addr=1152921509402943472 |  dest_result_addr=1152921509402943480
            // 0x01D47328: STP x20, x19, [sp, #0x10]  | stack[1152921509402943488] = ???;  stack[1152921509402943496] = ???;  //  dest_result_addr=1152921509402943488 |  dest_result_addr=1152921509402943496
            // 0x01D4732C: STP x29, x30, [sp, #0x20]  | stack[1152921509402943504] = ???;  stack[1152921509402943512] = ???;  //  dest_result_addr=1152921509402943504 |  dest_result_addr=1152921509402943512
            // 0x01D47330: ADD x29, sp, #0x20         | X29 = (1152921509402943472 + 32) = 1152921509402943504 (0x100000011DDEA010);
            // 0x01D47334: MOV x19, x0                | X19 = 1152921509402955520 (0x100000011DDECF00);//ML01
            // 0x01D47338: LDR w21, [x19, #0x18]      | 
            // 0x01D4733C: LDR x22, [x19, #0x10]      | 
            // 0x01D47340: MOV x20, x1                | X20 = item;//m1                         
            // 0x01D47344: CBNZ x22, #0x1d4734c       | if (X22 != 0) goto label_0;             
            if(X22 != 0)
            {
                goto label_0;
            }
            // 0x01D47348: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D4734C: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
            // 0x01D47350: CMP w21, w8                | STATE = COMPARE(W21, X22 + 24)          
            // 0x01D47354: B.NE #0x1d47380            | if (W21 != X22 + 24) goto label_1;      
            if(W21 != (X22 + 24))
            {
                goto label_1;
            }
            // 0x01D47358: CBNZ x19, #0x1d47360       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x01D4735C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x01D47360: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D47364: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01D47368: MOV x0, x19                | X0 = 1152921509402955520 (0x100000011DDECF00);//ML01
            // 0x01D4736C: LDR x9, [x8, #0x370]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_370;
            // 0x01D47370: LDR x2, [x8, #0x378]       | X2 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_378;
            // 0x01D47374: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_370();
            // 0x01D47378: LDR w21, [x19, #0x18]      | 
            // 0x01D4737C: B #0x1d4738c               |  goto label_4;                          
            goto label_4;
            label_1:
            // 0x01D47380: LDR w21, [x19, #0x18]      | 
            // 0x01D47384: CBNZ x19, #0x1d4738c       | if (this != null) goto label_4;         
            if(this != null)
            {
                goto label_4;
            }
            // 0x01D47388: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x01D4738C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D47390: MOV x0, x19                | X0 = 1152921509402955520 (0x100000011DDECF00);//ML01
            // 0x01D47394: MOV x1, x20                | X1 = item;//m1                          
            // 0x01D47398: MOV w2, w21                | W2 = W21;//m1                           
            // 0x01D4739C: LDR x9, [x8, #0x320]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_320;
            // 0x01D473A0: LDR x3, [x8, #0x328]       | X3 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_328;
            // 0x01D473A4: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_320();
            // 0x01D473A8: LDRSW x21, [x19, #0x18]    | 
            // 0x01D473AC: LDR x22, [x19, #0x10]      | 
            // 0x01D473B0: ADD w8, w21, #1            | W8 = (W21 + 1);                         
            var val_1 = W21 + 1;
            // 0x01D473B4: STR w8, [x19, #0x18]       | mem[1152921509402955544] = (W21 + 1);    //  dest_result_addr=1152921509402955544
            mem[1152921509402955544] = val_1;
            // 0x01D473B8: CBNZ x22, #0x1d473c0       | if (X22 != 0) goto label_5;             
            if(X22 != 0)
            {
                goto label_5;
            }
            // 0x01D473BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_5:
            // 0x01D473C0: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
            // 0x01D473C4: CMP w21, w8                | STATE = COMPARE(W21, X22 + 24)          
            // 0x01D473C8: B.LO #0x1d473d8            | if (W21 < X22 + 24) goto label_6;       
            if(W21 < (X22 + 24))
            {
                goto label_6;
            }
            // 0x01D473CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01D473D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D473D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_6:
            // 0x01D473D8: ADD x8, x22, x21, lsl #3   | X8 = (X22 + (X21) << 3);                
            var val_2 = X22 + ((X21) << 3);
            // 0x01D473DC: STR x20, [x8, #0x20]       | mem2[0] = item;                          //  dest_result_addr=0
            mem2[0] = item;
            // 0x01D473E0: LDR w8, [x19, #0x1c]       | 
            // 0x01D473E4: ADD w8, w8, #1             | W8 = ((X22 + (X21) << 3) + 1);          
            val_2 = val_2 + 1;
            // 0x01D473E8: STR w8, [x19, #0x1c]       | mem[1152921509402955548] = ((X22 + (X21) << 3) + 1);  //  dest_result_addr=1152921509402955548
            mem[1152921509402955548] = val_2;
            // 0x01D473EC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D473F0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D473F4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D473F8: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D473FC VirtAddr: 0x01D473FC -RVA: 0x01D473FC 
        // -Collection<object>.Contains
        // -Collection<string>.Contains
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.Contains
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.Contains
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.Contains
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.Contains
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.Contains
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.Contains
        //
        // file offset: 0x019D49FC VirtAddr: 0x019D49FC -RVA: 0x019D49FC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Contains
        //
        // file offset: 0x019D6328 VirtAddr: 0x019D6328 -RVA: 0x019D6328 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Contains
        //
        // file offset: 0x019D7C54 VirtAddr: 0x019D7C54 -RVA: 0x019D7C54 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Contains
        //
        // file offset: 0x019D9670 VirtAddr: 0x019D9670 -RVA: 0x019D9670 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Contains
        //
        // file offset: 0x01D42760 VirtAddr: 0x01D42760 -RVA: 0x01D42760 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Contains
        //
        // file offset: 0x01D4410C VirtAddr: 0x01D4410C -RVA: 0x01D4410C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Contains
        //
        // file offset: 0x01D45B58 VirtAddr: 0x01D45B58 -RVA: 0x01D45B58 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Contains
        //
        // file offset: 0x01D48CC4 VirtAddr: 0x01D48CC4 -RVA: 0x01D48CC4 
        // -Collection<uint>.Contains
        //
        //
        // Offset in libil2cpp.so: 0x01D473FC (30700540), len: 88  VirtAddr: 0x01D473FC RVA: 0x01D473FC token: 100663319 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public bool Contains(T item)
        {
            //
            // Disasemble & Code
            // 0x01D473FC: STP x22, x21, [sp, #-0x30]! | stack[1152921509403063664] = ???;  stack[1152921509403063672] = ???;  //  dest_result_addr=1152921509403063664 |  dest_result_addr=1152921509403063672
            // 0x01D47400: STP x20, x19, [sp, #0x10]  | stack[1152921509403063680] = ???;  stack[1152921509403063688] = ???;  //  dest_result_addr=1152921509403063680 |  dest_result_addr=1152921509403063688
            // 0x01D47404: STP x29, x30, [sp, #0x20]  | stack[1152921509403063696] = ???;  stack[1152921509403063704] = ???;  //  dest_result_addr=1152921509403063696 |  dest_result_addr=1152921509403063704
            // 0x01D47408: ADD x29, sp, #0x20         | X29 = (1152921509403063664 + 32) = 1152921509403063696 (0x100000011DE07590);
            // 0x01D4740C: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47410: MOV x19, x1                | X19 = item;//m1                         
            // 0x01D47414: MOV x20, x0                | X20 = 1152921509403075712 (0x100000011DE0A480);//ML01
            // 0x01D47418: CBNZ x20, #0x1d47420       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D4741C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D47420: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47424: MOV x0, x20                | X0 = 1152921509403075712 (0x100000011DE0A480);//ML01
            // 0x01D47428: MOV x1, x19                | X1 = item;//m1                          
            // 0x01D4742C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47430: LDR x2, [x8, #0x58]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D47434: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D47438: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 88();
            // 0x01D4743C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47440: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47444: CMN w0, #1                 | STATE = COMPARE(this, 0x1)              
            // 0x01D47448: CSET w0, ne                | W0 = this != 0x1 ? 1 : 0;               
            var val_1 = (this != 1) ? 1 : 0;
            // 0x01D4744C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47450: RET                        |  return (System.Boolean)this != 0x1 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47454 VirtAddr: 0x01D47454 -RVA: 0x01D47454 
        // -Collection<object>.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.IndexOf
        //
        // file offset: 0x019D4A5C VirtAddr: 0x019D4A5C -RVA: 0x019D4A5C 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.IndexOf
        //
        // file offset: 0x019D6388 VirtAddr: 0x019D6388 -RVA: 0x019D6388 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.IndexOf
        //
        // file offset: 0x019D7CB4 VirtAddr: 0x019D7CB4 -RVA: 0x019D7CB4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.IndexOf
        //
        // file offset: 0x019D96EC VirtAddr: 0x019D96EC -RVA: 0x019D96EC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.IndexOf
        //
        // file offset: 0x01D427B8 VirtAddr: 0x01D427B8 -RVA: 0x01D427B8 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.IndexOf
        //
        // file offset: 0x01D44180 VirtAddr: 0x01D44180 -RVA: 0x01D44180 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.IndexOf
        //
        // file offset: 0x01D45BB0 VirtAddr: 0x01D45BB0 -RVA: 0x01D45BB0 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.IndexOf
        //
        // file offset: 0x01D48D1C VirtAddr: 0x01D48D1C -RVA: 0x01D48D1C 
        // -Collection<uint>.IndexOf
        //
        //
        // Offset in libil2cpp.so: 0x01D47454 (30700628), len: 48  VirtAddr: 0x01D47454 RVA: 0x01D47454 token: 100663320 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public int IndexOf(T item)
        {
            //
            // Disasemble & Code
            // 0x01D47454: LDR x8, [x2, #0x18]        | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47458: LDR w4, [x0, #0x18]        | 
            // 0x01D4745C: MOV x9, x1                 | X9 = item;//m1                          
            // 0x01D47460: MOV x2, x9                 | X2 = item;//m1                          
            // 0x01D47464: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47468: MOV w3, wzr                | W3 = 0 (0x0);//ML01                     
            // 0x01D4746C: LDR x5, [x8, #0x60]        | X5 = __RuntimeMethodHiddenParam + 24 + 168 + 96;
            // 0x01D47470: LDR x8, [x0, #0x10]        | 
            // 0x01D47474: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D47478: LDR x6, [x5]               | X6 = __RuntimeMethodHiddenParam + 24 + 168 + 96;
            // 0x01D4747C: MOV x1, x8                 | X1 = __RuntimeMethodHiddenParam + 24 + 168;//m1
            // 0x01D47480: BR x6                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 96;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 96;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47484 VirtAddr: 0x01D47484 -RVA: 0x01D47484 
        // -Collection<object>.Insert
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.Insert
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.Insert
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.Insert
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.Insert
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.Insert
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.Insert
        //
        // file offset: 0x019D4A94 VirtAddr: 0x019D4A94 -RVA: 0x019D4A94 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Insert
        //
        // file offset: 0x019D63C0 VirtAddr: 0x019D63C0 -RVA: 0x019D63C0 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Insert
        //
        // file offset: 0x019D7CEC VirtAddr: 0x019D7CEC -RVA: 0x019D7CEC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Insert
        //
        // file offset: 0x019D9758 VirtAddr: 0x019D9758 -RVA: 0x019D9758 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Insert
        //
        // file offset: 0x01D427E8 VirtAddr: 0x01D427E8 -RVA: 0x01D427E8 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Insert
        //
        // file offset: 0x01D441E4 VirtAddr: 0x01D441E4 -RVA: 0x01D441E4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Insert
        //
        // file offset: 0x01D45BDC VirtAddr: 0x01D45BDC -RVA: 0x01D45BDC 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Insert
        //
        // file offset: 0x01D48D4C VirtAddr: 0x01D48D4C -RVA: 0x01D48D4C 
        // -Collection<uint>.Insert
        //
        //
        // Offset in libil2cpp.so: 0x01D47484 (30700676), len: 284  VirtAddr: 0x01D47484 RVA: 0x01D47484 token: 100663321 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void Insert(int index, T item)
        {
            //
            // Disasemble & Code
            // 0x01D47484: STP x24, x23, [sp, #-0x40]! | stack[1152921509403304032] = ???;  stack[1152921509403304040] = ???;  //  dest_result_addr=1152921509403304032 |  dest_result_addr=1152921509403304040
            // 0x01D47488: STP x22, x21, [sp, #0x10]  | stack[1152921509403304048] = ???;  stack[1152921509403304056] = ???;  //  dest_result_addr=1152921509403304048 |  dest_result_addr=1152921509403304056
            // 0x01D4748C: STP x20, x19, [sp, #0x20]  | stack[1152921509403304064] = ???;  stack[1152921509403304072] = ???;  //  dest_result_addr=1152921509403304064 |  dest_result_addr=1152921509403304072
            // 0x01D47490: STP x29, x30, [sp, #0x30]  | stack[1152921509403304080] = ???;  stack[1152921509403304088] = ???;  //  dest_result_addr=1152921509403304080 |  dest_result_addr=1152921509403304088
            // 0x01D47494: ADD x29, sp, #0x30         | X29 = (1152921509403304032 + 48) = 1152921509403304080 (0x100000011DE42090);
            // 0x01D47498: MOV x22, x3                | X22 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D4749C: MOV x20, x2                | X20 = item;//m1                         
            // 0x01D474A0: MOV w21, w1                | W21 = index;//m1                        
            // 0x01D474A4: MOV x19, x0                | X19 = 1152921509403316096 (0x100000011DE44F80);//ML01
            // 0x01D474A8: CBNZ x19, #0x1d474b0       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D474AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D474B0: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D474B4: MOV x0, x19                | X0 = 1152921509403316096 (0x100000011DE44F80);//ML01
            // 0x01D474B8: MOV w1, w21                | W1 = index;//m1                         
            // 0x01D474BC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D474C0: LDR x2, [x8]               | X2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D474C4: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D474C8: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168();
            // 0x01D474CC: LDR w23, [x19, #0x18]      | 
            // 0x01D474D0: LDR x24, [x19, #0x10]      | 
            // 0x01D474D4: CBNZ x24, #0x1d474dc       | if (X24 != 0) goto label_1;             
            if(X24 != 0)
            {
                goto label_1;
            }
            // 0x01D474D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x01D474DC: LDR w8, [x24, #0x18]       | W8 = X24 + 24;                          
            // 0x01D474E0: CMP w23, w8                | STATE = COMPARE(W23, X24 + 24)          
            // 0x01D474E4: B.NE #0x1d47508            | if (W23 != X24 + 24) goto label_2;      
            if(W23 != (X24 + 24))
            {
                goto label_2;
            }
            // 0x01D474E8: CBNZ x19, #0x1d474f0       | if (this != null) goto label_3;         
            if(this != null)
            {
                goto label_3;
            }
            // 0x01D474EC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_3:
            // 0x01D474F0: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D474F4: ORR w1, wzr, #1            | W1 = 1(0x1);                            
            // 0x01D474F8: MOV x0, x19                | X0 = 1152921509403316096 (0x100000011DE44F80);//ML01
            // 0x01D474FC: LDR x9, [x8, #0x370]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_370;
            // 0x01D47500: LDR x2, [x8, #0x378]       | X2 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_378;
            // 0x01D47504: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_370();
            label_2:
            // 0x01D47508: CBZ x19, #0x1d47598        | if (this == null) goto label_4;         
            if(this == null)
            {
                goto label_4;
            }
            // 0x01D4750C: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D47510: MOV x0, x19                | X0 = 1152921509403316096 (0x100000011DE44F80);//ML01
            // 0x01D47514: MOV x1, x20                | X1 = item;//m1                          
            // 0x01D47518: MOV w2, w21                | W2 = index;//m1                         
            // 0x01D4751C: LDR x9, [x8, #0x330]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_330;
            // 0x01D47520: LDR x3, [x8, #0x338]       | X3 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_338;
            // 0x01D47524: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_330();
            // 0x01D47528: LDR x8, [x22, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D4752C: ORR w2, wzr, #1            | W2 = 1(0x1);                            
            // 0x01D47530: MOV x0, x19                | X0 = 1152921509403316096 (0x100000011DE44F80);//ML01
            // 0x01D47534: MOV w1, w21                | W1 = index;//m1                         
            // 0x01D47538: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D4753C: LDR x3, [x8, #0x70]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            // 0x01D47540: LDR x8, [x3]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            // 0x01D47544: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 112();
            // 0x01D47548: LDR x22, [x19, #0x10]      | 
            // 0x01D4754C: CBNZ x22, #0x1d47554       | if (__RuntimeMethodHiddenParam != 0) goto label_5;
            if(__RuntimeMethodHiddenParam != 0)
            {
                goto label_5;
            }
            // 0x01D47550: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_5:
            // 0x01D47554: LDR w8, [x22, #0x18]       | W8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47558: SXTW x23, w21              | X23 = (long)(int)(index);               
            // 0x01D4755C: CMP w8, w21                | STATE = COMPARE(__RuntimeMethodHiddenParam + 24, index)
            // 0x01D47560: B.HI #0x1d47570            | if (__RuntimeMethodHiddenParam + 24 > index) goto label_6;
            if((__RuntimeMethodHiddenParam + 24) > index)
            {
                goto label_6;
            }
            // 0x01D47564: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01D47568: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D4756C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_6:
            // 0x01D47570: ADD x8, x22, x23, lsl #3   | X8 = (__RuntimeMethodHiddenParam + ((long)(int)(index)) << 3);
            var val_1 = __RuntimeMethodHiddenParam + (((long)(int)(index)) << 3);
            // 0x01D47574: STR x20, [x8, #0x20]       | mem2[0] = item;                          //  dest_result_addr=0
            mem2[0] = item;
            // 0x01D47578: LDR w8, [x19, #0x1c]       | 
            // 0x01D4757C: ADD w8, w8, #1             | W8 = ((__RuntimeMethodHiddenParam + ((long)(int)(index)) << 3) + 1);
            val_1 = val_1 + 1;
            // 0x01D47580: STR w8, [x19, #0x1c]       | mem[1152921509403316124] = ((__RuntimeMethodHiddenParam + ((long)(int)(index)) << 3) + 1);  //  dest_result_addr=1152921509403316124
            mem[1152921509403316124] = val_1;
            // 0x01D47584: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47588: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D4758C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D47590: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D47594: RET                        |  return;                                
            return;
            label_4:
            // 0x01D47598: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01D4759C: BRK #0x1                   | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D475A0 VirtAddr: 0x01D475A0 -RVA: 0x01D475A0 
        // -Collection<object>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.Cil.SequencePoint>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.RemoveAt
        //
        // file offset: 0x019D4BC0 VirtAddr: 0x019D4BC0 -RVA: 0x019D4BC0 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.RemoveAt
        //
        // file offset: 0x019D64EC VirtAddr: 0x019D64EC -RVA: 0x019D64EC 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.RemoveAt
        //
        // file offset: 0x019D7E18 VirtAddr: 0x019D7E18 -RVA: 0x019D7E18 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.RemoveAt
        //
        // file offset: 0x019D98D0 VirtAddr: 0x019D98D0 -RVA: 0x019D98D0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.RemoveAt
        //
        // file offset: 0x01D42904 VirtAddr: 0x01D42904 -RVA: 0x01D42904 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.RemoveAt
        //
        // file offset: 0x01D44348 VirtAddr: 0x01D44348 -RVA: 0x01D44348 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.RemoveAt
        //
        // file offset: 0x01D45CF8 VirtAddr: 0x01D45CF8 -RVA: 0x01D45CF8 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.RemoveAt
        //
        // file offset: 0x01D48E68 VirtAddr: 0x01D48E68 -RVA: 0x01D48E68 
        // -Collection<uint>.RemoveAt
        //
        //
        // Offset in libil2cpp.so: 0x01D475A0 (30700960), len: 276  VirtAddr: 0x01D475A0 RVA: 0x01D475A0 token: 100663322 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void RemoveAt(int index)
        {
            //
            // Disasemble & Code
            // 0x01D475A0: STP x22, x21, [sp, #-0x30]! | stack[1152921509403421168] = ???;  stack[1152921509403421176] = ???;  //  dest_result_addr=1152921509403421168 |  dest_result_addr=1152921509403421176
            // 0x01D475A4: STP x20, x19, [sp, #0x10]  | stack[1152921509403421184] = ???;  stack[1152921509403421192] = ???;  //  dest_result_addr=1152921509403421184 |  dest_result_addr=1152921509403421192
            // 0x01D475A8: STP x29, x30, [sp, #0x20]  | stack[1152921509403421200] = ???;  stack[1152921509403421208] = ???;  //  dest_result_addr=1152921509403421200 |  dest_result_addr=1152921509403421208
            // 0x01D475AC: ADD x29, sp, #0x20         | X29 = (1152921509403421168 + 32) = 1152921509403421200 (0x100000011DE5EA10);
            // 0x01D475B0: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D475B4: LDRB w8, [x22, #0xa56]     | W8 = (bool)static_value_0373CA56;       
            // 0x01D475B8: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D475BC: MOV w20, w1                | W20 = index;//m1                        
            // 0x01D475C0: MOV x19, x0                | X19 = 1152921509403433216 (0x100000011DE61900);//ML01
            // 0x01D475C4: TBNZ w8, #0, #0x1d475e0    | if (static_value_0373CA56 == true) goto label_0;
            // 0x01D475C8: ADRP x8, #0x3644000        | X8 = 56901632 (0x3644000);              
            // 0x01D475CC: LDR x8, [x8, #0x758]       | X8 = 0x2B9139C;                         
            // 0x01D475D0: LDR w0, [x8]               | W0 = 0x1BAB;                            
            // 0x01D475D4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BAB, ????);     
            // 0x01D475D8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D475DC: STRB w8, [x22, #0xa56]     | static_value_0373CA56 = true;            //  dest_result_addr=57920086
            label_0:
            // 0x01D475E0: TBNZ w20, #0x1f, #0x1d47678 | if ((index & 0x80000000) != 0) goto label_2;
            if((index & 2147483648) != 0)
            {
                goto label_2;
            }
            // 0x01D475E4: LDR w8, [x19, #0x18]       | 
            // 0x01D475E8: CMP w8, w20                | STATE = COMPARE(0x1, index)             
            // 0x01D475EC: B.LE #0x1d47678            | if (true <= index) goto label_2;        
            if(true <= index)
            {
                goto label_2;
            }
            // 0x01D475F0: LDR x22, [x19, #0x10]      | 
            // 0x01D475F4: CBNZ x22, #0x1d475fc       | if ( != 0) goto label_3;                
            if(!=0)
            {
                goto label_3;
            }
            // 0x01D475F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1BAB, ????);     
            label_3:
            // 0x01D475FC: LDR w8, [x22, #0x18]       | W8 = mem[57917464];                     
            // 0x01D47600: CMP w8, w20                | STATE = COMPARE(mem[57917464], index)   
            // 0x01D47604: B.HI #0x1d47614            | if (mem[57917464] > index) goto label_4;
            if(mem[57917464] > index)
            {
                goto label_4;
            }
            // 0x01D47608: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x1BAB, ????);     
            // 0x01D4760C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47610: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x1BAB, ????);     
            label_4:
            // 0x01D47614: CBZ x19, #0x1d476ac        | if (this == null) goto label_5;         
            if(this == null)
            {
                goto label_5;
            }
            // 0x01D47618: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D4761C: SXTW x9, w20               | X9 = (long)(int)(index);                
            // 0x01D47620: ADD x9, x22, x9, lsl #3    | X9 = (57917440 + ((long)(int)(index)) << 3);
            var val_1 = 57917440 + (((long)(int)(index)) << 3);
            // 0x01D47624: LDR x1, [x9, #0x20]        | X1 = (57917440 + ((long)(int)(index)) << 3) + 32;
            // 0x01D47628: LDR x9, [x8, #0x350]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_350;
            // 0x01D4762C: LDR x3, [x8, #0x358]       | X3 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_358;
            // 0x01D47630: MOV x0, x19                | X0 = 1152921509403433216 (0x100000011DE61900);//ML01
            // 0x01D47634: MOV w2, w20                | W2 = index;//m1                         
            // 0x01D47638: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_350();
            // 0x01D4763C: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47640: MOVN w2, #0                | W2 = 0 (0x0);//ML01                     
            // 0x01D47644: MOV x0, x19                | X0 = 1152921509403433216 (0x100000011DE61900);//ML01
            // 0x01D47648: MOV w1, w20                | W1 = index;//m1                         
            // 0x01D4764C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47650: LDR x3, [x8, #0x70]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            // 0x01D47654: LDR x8, [x3]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            var val_3 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            // 0x01D47658: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 112();
            // 0x01D4765C: LDR w8, [x19, #0x1c]       | 
            // 0x01D47660: ADD w8, w8, #1             | W8 = (__RuntimeMethodHiddenParam + 24 + 168 + 112 + 1);
            val_3 = val_3 + 1;
            // 0x01D47664: STR w8, [x19, #0x1c]       | mem[1152921509403433244] = (__RuntimeMethodHiddenParam + 24 + 168 + 112 + 1);  //  dest_result_addr=1152921509403433244
            mem[1152921509403433244] = val_3;
            // 0x01D47668: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D4766C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47670: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47674: RET                        |  return;                                
            return;
            label_2:
            // 0x01D47678: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01D4767C: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x01D47680: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_2 = null;
            // 0x01D47684: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47688: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D4768C: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D47690: BL #0x18cb840              | .ctor();                                
            val_2 = new System.ArgumentOutOfRangeException();
            // 0x01D47694: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x01D47698: LDR x8, [x8, #0xe78]       | X8 = 1152921509403408192;               
            // 0x01D4769C: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D476A0: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Collections.Generic.Collection<System.Object>::RemoveAt(int index);
            // 0x01D476A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D476A8: BL #0x1d41f54              | set_Item(index:  501593920, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
            set_Item(index:  501593920, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
            label_5:
            // 0x01D476AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D476B0: BRK #0x1                   | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D476B4 VirtAddr: 0x01D476B4 -RVA: 0x01D476B4 
        // -Collection<object>.Remove
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.Remove
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.Remove
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.Remove
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.Remove
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.Remove
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.Remove
        //
        // file offset: 0x019D4CD4 VirtAddr: 0x019D4CD4 -RVA: 0x019D4CD4 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Remove
        //
        // file offset: 0x019D6600 VirtAddr: 0x019D6600 -RVA: 0x019D6600 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Remove
        //
        // file offset: 0x019D7F2C VirtAddr: 0x019D7F2C -RVA: 0x019D7F2C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Remove
        //
        // file offset: 0x019D9A1C VirtAddr: 0x019D9A1C -RVA: 0x019D9A1C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Remove
        //
        // file offset: 0x01D42A18 VirtAddr: 0x01D42A18 -RVA: 0x01D42A18 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Remove
        //
        // file offset: 0x01D44488 VirtAddr: 0x01D44488 -RVA: 0x01D44488 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Remove
        //
        // file offset: 0x01D45E0C VirtAddr: 0x01D45E0C -RVA: 0x01D45E0C 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Remove
        //
        // file offset: 0x01D48F7C VirtAddr: 0x01D48F7C -RVA: 0x01D48F7C 
        // -Collection<uint>.Remove
        //
        //
        // Offset in libil2cpp.so: 0x01D476B4 (30701236), len: 188  VirtAddr: 0x01D476B4 RVA: 0x01D476B4 token: 100663323 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public bool Remove(T item)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D476B4: STP x22, x21, [sp, #-0x30]! | stack[1152921509403537264] = ???;  stack[1152921509403537272] = ???;  //  dest_result_addr=1152921509403537264 |  dest_result_addr=1152921509403537272
            // 0x01D476B8: STP x20, x19, [sp, #0x10]  | stack[1152921509403537280] = ???;  stack[1152921509403537288] = ???;  //  dest_result_addr=1152921509403537280 |  dest_result_addr=1152921509403537288
            // 0x01D476BC: STP x29, x30, [sp, #0x20]  | stack[1152921509403537296] = ???;  stack[1152921509403537304] = ???;  //  dest_result_addr=1152921509403537296 |  dest_result_addr=1152921509403537304
            // 0x01D476C0: ADD x29, sp, #0x20         | X29 = (1152921509403537264 + 32) = 1152921509403537296 (0x100000011DE7AF90);
            // 0x01D476C4: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D476C8: MOV x21, x1                | X21 = item;//m1                         
            // 0x01D476CC: MOV x19, x0                | X19 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D476D0: CBNZ x19, #0x1d476d8       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D476D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D476D8: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D476DC: MOV x0, x19                | X0 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D476E0: MOV x1, x21                | X1 = item;//m1                          
            // 0x01D476E4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D476E8: LDR x2, [x8, #0x58]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D476EC: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D476F0: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 88();
            // 0x01D476F4: MOV w22, w0                | W22 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D476F8: CMN w22, #1                | STATE = COMPARE(this, 0x1)              
            // 0x01D476FC: B.EQ #0x1d47754            | if (this == 0x1) goto label_1;          
            if(this == 1)
            {
                goto label_1;
            }
            // 0x01D47700: CBZ x19, #0x1d47768        | if (this == null) goto label_2;         
            if(this == null)
            {
                goto label_2;
            }
            // 0x01D47704: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D47708: MOV x0, x19                | X0 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D4770C: MOV x1, x21                | X1 = item;//m1                          
            // 0x01D47710: MOV w2, w22                | W2 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D47714: LDR x9, [x8, #0x350]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_350;
            // 0x01D47718: LDR x3, [x8, #0x358]       | X3 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_358;
            // 0x01D4771C: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_350();
            // 0x01D47720: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47724: MOVN w2, #0                | W2 = 0 (0x0);//ML01                     
            // 0x01D47728: MOV x0, x19                | X0 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D4772C: MOV w1, w22                | W1 = 1152921509403549312 (0x100000011DE7DE80);//ML01
            // 0x01D47730: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47734: LDR x3, [x8, #0x70]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            // 0x01D47738: LDR x8, [x3]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            var val_1 = __RuntimeMethodHiddenParam + 24 + 168 + 112;
            // 0x01D4773C: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 112();
            // 0x01D47740: LDR w8, [x19, #0x1c]       | 
            // 0x01D47744: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_1 = 1;
            // 0x01D47748: ADD w8, w8, #1             | W8 = (__RuntimeMethodHiddenParam + 24 + 168 + 112 + 1);
            val_1 = val_1 + 1;
            // 0x01D4774C: STR w8, [x19, #0x1c]       | mem[1152921509403549340] = (__RuntimeMethodHiddenParam + 24 + 168 + 112 + 1);  //  dest_result_addr=1152921509403549340
            mem[1152921509403549340] = val_1;
            // 0x01D47750: B #0x1d47758               |  goto label_3;                          
            goto label_3;
            label_1:
            // 0x01D47754: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_1 = 0;
            label_3:
            // 0x01D47758: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D4775C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47760: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47764: RET                        |  return (System.Boolean)false;          
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_2:
            // 0x01D47768: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01D4776C: BRK #0x1                   | 
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47770 VirtAddr: 0x01D47770 -RVA: 0x01D47770 
        // -Collection<object>.Clear
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.Clear
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.Clear
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.Clear
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.Clear
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.Clear
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.Clear
        //
        // file offset: 0x019D7FFC VirtAddr: 0x019D7FFC -RVA: 0x019D7FFC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Clear
        //
        // file offset: 0x019D9B2C VirtAddr: 0x019D9B2C -RVA: 0x019D9B2C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Clear
        //
        // file offset: 0x019D4DA4 VirtAddr: 0x019D4DA4 -RVA: 0x019D4DA4 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Clear
        //
        // file offset: 0x019D66D0 VirtAddr: 0x019D66D0 -RVA: 0x019D66D0 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Clear
        //
        // file offset: 0x01D42AD4 VirtAddr: 0x01D42AD4 -RVA: 0x01D42AD4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Clear
        //
        // file offset: 0x01D44588 VirtAddr: 0x01D44588 -RVA: 0x01D44588 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Clear
        //
        // file offset: 0x01D45ECC VirtAddr: 0x01D45ECC -RVA: 0x01D45ECC 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Clear
        //
        // file offset: 0x01D49038 VirtAddr: 0x01D49038 -RVA: 0x01D49038 
        // -Collection<uint>.Clear
        //
        //
        // Offset in libil2cpp.so: 0x01D47770 (30701424), len: 92  VirtAddr: 0x01D47770 RVA: 0x01D47770 token: 100663324 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void Clear()
        {
            //
            // Disasemble & Code
            // 0x01D47770: STP x20, x19, [sp, #-0x20]! | stack[1152921509403653376] = ???;  stack[1152921509403653384] = ???;  //  dest_result_addr=1152921509403653376 |  dest_result_addr=1152921509403653384
            // 0x01D47774: STP x29, x30, [sp, #0x10]  | stack[1152921509403653392] = ???;  stack[1152921509403653400] = ???;  //  dest_result_addr=1152921509403653392 |  dest_result_addr=1152921509403653400
            // 0x01D47778: ADD x29, sp, #0x10         | X29 = (1152921509403653376 + 16) = 1152921509403653392 (0x100000011DE97510);
            // 0x01D4777C: MOV x19, x0                | X19 = 1152921509403665408 (0x100000011DE9A400);//ML01
            // 0x01D47780: CBNZ x19, #0x1d47788       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D47784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D47788: LDR x8, [x19]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D4778C: MOV x0, x19                | X0 = 1152921509403665408 (0x100000011DE9A400);//ML01
            // 0x01D47790: LDR x9, [x8, #0x360]       | X9 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_360;
            // 0x01D47794: LDR x1, [x8, #0x368]       | X1 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_368;
            // 0x01D47798: BLR x9                     | X0 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_360();
            // 0x01D4779C: LDR x1, [x19, #0x10]       | 
            // 0x01D477A0: LDR w3, [x19, #0x18]       | 
            // 0x01D477A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D477A8: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01D477AC: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01D477B0: BL #0x18b3424              | System.Array.Clear(array:  0, index:  typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_368>>0&0xFFFFFFFF, length:  0);
            System.Array.Clear(array:  0, index:  typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).__il2cppRuntimeField_368>>0&0xFFFFFFFF, length:  0);
            // 0x01D477B4: LDR w8, [x19, #0x1c]       | 
            // 0x01D477B8: ADD w8, w8, #1             |  //  not_find_field:typeof(ILRuntime.Mono.Collections.Generic.Collection<T>).1
            // 0x01D477BC: STP wzr, w8, [x19, #0x18]  | mem[1152921509403665432] = 0x0;  mem[1152921509403665436] = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);  //  dest_result_addr=1152921509403665432 |  dest_result_addr=1152921509403665436
            mem[1152921509403665432] = 0;
            mem[1152921509403665436] = null;
            // 0x01D477C0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D477C4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D477C8: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D477CC VirtAddr: 0x01D477CC -RVA: 0x01D477CC 
        // -Collection<object>.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.CopyTo
        //
        // file offset: 0x019D4E00 VirtAddr: 0x019D4E00 -RVA: 0x019D4E00 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.CopyTo
        //
        // file offset: 0x019D672C VirtAddr: 0x019D672C -RVA: 0x019D672C 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.CopyTo
        //
        // file offset: 0x019D8058 VirtAddr: 0x019D8058 -RVA: 0x019D8058 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.CopyTo
        //
        // file offset: 0x019D9B88 VirtAddr: 0x019D9B88 -RVA: 0x019D9B88 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.CopyTo
        //
        // file offset: 0x01D42B30 VirtAddr: 0x01D42B30 -RVA: 0x01D42B30 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.CopyTo
        //
        // file offset: 0x01D445E4 VirtAddr: 0x01D445E4 -RVA: 0x01D445E4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.CopyTo
        //
        // file offset: 0x01D45F28 VirtAddr: 0x01D45F28 -RVA: 0x01D45F28 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.CopyTo
        //
        // file offset: 0x01D49094 VirtAddr: 0x01D49094 -RVA: 0x01D49094 
        // -Collection<uint>.CopyTo
        //
        //
        // Offset in libil2cpp.so: 0x01D477CC (30701516), len: 44  VirtAddr: 0x01D477CC RVA: 0x01D477CC token: 100663325 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public void CopyTo(T[] array, int arrayIndex)
        {
            //
            // Disasemble & Code
            // 0x01D477CC: LDR x8, [x0, #0x10]        | 
            // 0x01D477D0: LDR w5, [x0, #0x18]        | 
            // 0x01D477D4: MOV w9, w2                 | W9 = arrayIndex;//m1                    
            // 0x01D477D8: MOV x10, x1                | X10 = array;//m1                        
            // 0x01D477DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D477E0: MOV x1, x8                 | X1 = X8;//m1                            
            // 0x01D477E4: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01D477E8: MOV x3, x10                | X3 = array;//m1                         
            // 0x01D477EC: MOV w4, w9                 | W4 = arrayIndex;//m1                    
            // 0x01D477F0: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01D477F4: B #0x18ce87c               | System.Array.Copy(sourceArray:  0, sourceIndex:  X8, destinationArray:  0, destinationIndex:  array, length:  arrayIndex); return;
            System.Array.Copy(sourceArray:  0, sourceIndex:  X8, destinationArray:  0, destinationIndex:  array, length:  arrayIndex);
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D477F8 VirtAddr: 0x01D477F8 -RVA: 0x01D477F8 
        // -Collection<object>.CheckIndex
        //
        // file offset: 0x019D4E2C VirtAddr: 0x019D4E2C -RVA: 0x019D4E2C 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.CheckIndex
        //
        // file offset: 0x019D6758 VirtAddr: 0x019D6758 -RVA: 0x019D6758 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.CheckIndex
        //
        // file offset: 0x019D8084 VirtAddr: 0x019D8084 -RVA: 0x019D8084 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.CheckIndex
        //
        // file offset: 0x019D9BB4 VirtAddr: 0x019D9BB4 -RVA: 0x019D9BB4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.CheckIndex
        //
        // file offset: 0x01D42B5C VirtAddr: 0x01D42B5C -RVA: 0x01D42B5C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.CheckIndex
        //
        // file offset: 0x01D44610 VirtAddr: 0x01D44610 -RVA: 0x01D44610 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.CheckIndex
        //
        // file offset: 0x01D45F54 VirtAddr: 0x01D45F54 -RVA: 0x01D45F54 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.CheckIndex
        //
        // file offset: 0x01D490C0 VirtAddr: 0x01D490C0 -RVA: 0x01D490C0 
        // -Collection<uint>.CheckIndex
        //
        //
        // Offset in libil2cpp.so: 0x01D477F8 (30701560), len: 144  VirtAddr: 0x01D477F8 RVA: 0x01D477F8 token: 100663326 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void CheckIndex(int index)
        {
            //
            // Disasemble & Code
            // 0x01D477F8: STP x22, x21, [sp, #-0x30]! | stack[1152921509403952112] = ???;  stack[1152921509403952120] = ???;  //  dest_result_addr=1152921509403952112 |  dest_result_addr=1152921509403952120
            // 0x01D477FC: STP x20, x19, [sp, #0x10]  | stack[1152921509403952128] = ???;  stack[1152921509403952136] = ???;  //  dest_result_addr=1152921509403952128 |  dest_result_addr=1152921509403952136
            // 0x01D47800: STP x29, x30, [sp, #0x20]  | stack[1152921509403952144] = ???;  stack[1152921509403952152] = ???;  //  dest_result_addr=1152921509403952144 |  dest_result_addr=1152921509403952152
            // 0x01D47804: ADD x29, sp, #0x20         | X29 = (1152921509403952112 + 32) = 1152921509403952144 (0x100000011DEE0410);
            // 0x01D47808: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01D4780C: LDRB w8, [x21, #0xa57]     | W8 = (bool)static_value_0373CA57;       
            // 0x01D47810: MOV w19, w1                | W19 = index;//m1                        
            // 0x01D47814: MOV x20, x0                | X20 = 1152921509403964160 (0x100000011DEE3300);//ML01
            // 0x01D47818: TBNZ w8, #0, #0x1d47834    | if (static_value_0373CA57 == true) goto label_0;
            // 0x01D4781C: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x01D47820: LDR x8, [x8, #0x9a8]       | X8 = 0x2B90F1C;                         
            // 0x01D47824: LDR w0, [x8]               | W0 = 0x1A8B;                            
            // 0x01D47828: BL #0x2782188              | X0 = sub_2782188( ?? 0x1A8B, ????);     
            // 0x01D4782C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D47830: STRB w8, [x21, #0xa57]     | static_value_0373CA57 = true;            //  dest_result_addr=57920087
            label_0:
            // 0x01D47834: TBNZ w19, #0x1f, #0x1d47854 | if ((index & 0x80000000) != 0) goto label_2;
            if((index & 2147483648) != 0)
            {
                goto label_2;
            }
            // 0x01D47838: LDR w8, [x20, #0x18]       | 
            // 0x01D4783C: CMP w8, w19                | STATE = COMPARE(0x1, index)             
            // 0x01D47840: B.LT #0x1d47854            | if (true < index) goto label_2;         
            if(true < index)
            {
                goto label_2;
            }
            // 0x01D47844: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47848: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D4784C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47850: RET                        |  return;                                
            return;
            label_2:
            // 0x01D47854: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01D47858: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x01D4785C: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_1 = null;
            // 0x01D47860: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47868: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D4786C: BL #0x18cb840              | .ctor();                                
            val_1 = new System.ArgumentOutOfRangeException();
            // 0x01D47870: ADRP x8, #0x35e8000        | X8 = 56524800 (0x35E8000);              
            // 0x01D47874: LDR x8, [x8, #0x5d8]       | X8 = 1152921509403939136;               
            // 0x01D47878: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D4787C: LDR x1, [x8]               | X1 = System.Void ILRuntime.Mono.Collections.Generic.Collection<System.Object>::CheckIndex(int index);
            // 0x01D47880: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47884: BL #0x1d41f54              | set_Item(index:  502124864, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
            set_Item(index:  502124864, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47888 VirtAddr: 0x01D47888 -RVA: 0x01D47888 
        // -Collection<object>.Shift
        //
        // file offset: 0x019D4EBC VirtAddr: 0x019D4EBC -RVA: 0x019D4EBC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Shift
        //
        // file offset: 0x019D67E8 VirtAddr: 0x019D67E8 -RVA: 0x019D67E8 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Shift
        //
        // file offset: 0x019D8114 VirtAddr: 0x019D8114 -RVA: 0x019D8114 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Shift
        //
        // file offset: 0x019D9C44 VirtAddr: 0x019D9C44 -RVA: 0x019D9C44 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Shift
        //
        // file offset: 0x01D42BEC VirtAddr: 0x01D42BEC -RVA: 0x01D42BEC 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Shift
        //
        // file offset: 0x01D446A0 VirtAddr: 0x01D446A0 -RVA: 0x01D446A0 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Shift
        //
        // file offset: 0x01D45FE4 VirtAddr: 0x01D45FE4 -RVA: 0x01D45FE4 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Shift
        //
        // file offset: 0x01D49150 VirtAddr: 0x01D49150 -RVA: 0x01D49150 
        // -Collection<uint>.Shift
        //
        //
        // Offset in libil2cpp.so: 0x01D47888 (30701704), len: 120  VirtAddr: 0x01D47888 RVA: 0x01D47888 token: 100663327 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void Shift(int start, int delta)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            // 0x01D47888: STP x20, x19, [sp, #-0x20]! | stack[1152921509404064128] = ???;  stack[1152921509404064136] = ???;  //  dest_result_addr=1152921509404064128 |  dest_result_addr=1152921509404064136
            // 0x01D4788C: STP x29, x30, [sp, #0x10]  | stack[1152921509404064144] = ???;  stack[1152921509404064152] = ???;  //  dest_result_addr=1152921509404064144 |  dest_result_addr=1152921509404064152
            // 0x01D47890: ADD x29, sp, #0x10         | X29 = (1152921509404064128 + 16) = 1152921509404064144 (0x100000011DEFB990);
            // 0x01D47894: MOV x19, x0                | X19 = 1152921509404076160 (0x100000011DEFE880);//ML01
            // 0x01D47898: LDR w8, [x19, #0x18]       | 
            // 0x01D4789C: MOV w20, w2                | W20 = delta;//m1                        
            // 0x01D478A0: AND w9, w20, w20, asr #31  | W9 = (delta & ((int)delta) >> 31);      
            int val_1 = delta & (delta >> 31);
            // 0x01D478A4: SUB w2, w1, w9             | W2 = (start - (delta & ((int)delta) >> 31));
            delta = start - val_1;
            // 0x01D478A8: SUBS w5, w8, w2            | W5 = (W8 - (start - (delta & ((int)delta) >> 31)));
            int val_2 = W8 - delta;
            // 0x01D478AC: B.LE #0x1d478cc            | if ( <= ) goto label_0;                 
            if()
            {
                goto label_0;
            }
            // 0x01D478B0: LDR x1, [x19, #0x10]       | 
            // 0x01D478B4: ADD w4, w2, w20            | W4 = ((start - (delta & ((int)delta) >> 31)) + delta);
            int val_3 = delta + delta;
            // 0x01D478B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D478BC: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01D478C0: MOV x3, x1                 | X3 = start;//m1                         
            // 0x01D478C4: BL #0x18ce87c              | System.Array.Copy(sourceArray:  0, sourceIndex:  start, destinationArray:  delta = start - val_1, destinationIndex:  start, length:  int val_3 = delta + delta);
            System.Array.Copy(sourceArray:  0, sourceIndex:  start, destinationArray:  delta, destinationIndex:  start, length:  val_3);
            // 0x01D478C8: LDR w8, [x19, #0x18]       | 
            label_0:
            // 0x01D478CC: ADD w2, w8, w20            | W2 = (W8 + delta);                      
            int val_4 = W8 + delta;
            // 0x01D478D0: STR w2, [x19, #0x18]       | mem[1152921509404076184] = (W8 + delta);  //  dest_result_addr=1152921509404076184
            mem[1152921509404076184] = val_4;
            // 0x01D478D4: TBNZ w20, #0x1f, #0x1d478e4 | if ((delta & 0x80000000) != 0) goto label_1;
            if((delta & 2147483648) != 0)
            {
                goto label_1;
            }
            // 0x01D478D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D478DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D478E0: RET                        |  return;                                
            return;
            label_1:
            // 0x01D478E4: LDR x1, [x19, #0x10]       | 
            // 0x01D478E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D478EC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D478F0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01D478F4: NEG w3, w20                | W3 = -(delta);                          
            // 0x01D478F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D478FC: B #0x18b3424               | System.Array.Clear(array:  0, index:  start, length:  int val_4 = W8 + delta); return;
            System.Array.Clear(array:  0, index:  start, length:  val_4);
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47900 VirtAddr: 0x01D47900 -RVA: 0x01D47900 
        // -Collection<object>.OnAdd
        //
        // file offset: 0x019D4F34 VirtAddr: 0x019D4F34 -RVA: 0x019D4F34 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.OnAdd
        //
        // file offset: 0x019D6860 VirtAddr: 0x019D6860 -RVA: 0x019D6860 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.OnAdd
        //
        // file offset: 0x019D818C VirtAddr: 0x019D818C -RVA: 0x019D818C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.OnAdd
        //
        // file offset: 0x019D9CBC VirtAddr: 0x019D9CBC -RVA: 0x019D9CBC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.OnAdd
        //
        // file offset: 0x01D42C64 VirtAddr: 0x01D42C64 -RVA: 0x01D42C64 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.OnAdd
        //
        // file offset: 0x01D44718 VirtAddr: 0x01D44718 -RVA: 0x01D44718 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.OnAdd
        //
        // file offset: 0x01D4605C VirtAddr: 0x01D4605C -RVA: 0x01D4605C 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.OnAdd
        //
        // file offset: 0x01D491C8 VirtAddr: 0x01D491C8 -RVA: 0x01D491C8 
        // -Collection<uint>.OnAdd
        //
        //
        // Offset in libil2cpp.so: 0x01D47900 (30701824), len: 4  VirtAddr: 0x01D47900 RVA: 0x01D47900 token: 100663328 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void OnAdd(T item, int index)
        {
            //
            // Disasemble & Code
            // 0x01D47900: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47904 VirtAddr: 0x01D47904 -RVA: 0x01D47904 
        // -Collection<object>.OnInsert
        //
        // file offset: 0x019D4F38 VirtAddr: 0x019D4F38 -RVA: 0x019D4F38 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.OnInsert
        //
        // file offset: 0x019D6864 VirtAddr: 0x019D6864 -RVA: 0x019D6864 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.OnInsert
        //
        // file offset: 0x019D8190 VirtAddr: 0x019D8190 -RVA: 0x019D8190 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.OnInsert
        //
        // file offset: 0x019D9CC0 VirtAddr: 0x019D9CC0 -RVA: 0x019D9CC0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.OnInsert
        //
        // file offset: 0x01D42C68 VirtAddr: 0x01D42C68 -RVA: 0x01D42C68 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.OnInsert
        //
        // file offset: 0x01D4471C VirtAddr: 0x01D4471C -RVA: 0x01D4471C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.OnInsert
        //
        // file offset: 0x01D46060 VirtAddr: 0x01D46060 -RVA: 0x01D46060 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.OnInsert
        //
        // file offset: 0x01D491CC VirtAddr: 0x01D491CC -RVA: 0x01D491CC 
        // -Collection<uint>.OnInsert
        //
        //
        // Offset in libil2cpp.so: 0x01D47904 (30701828), len: 4  VirtAddr: 0x01D47904 RVA: 0x01D47904 token: 100663329 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void OnInsert(T item, int index)
        {
            //
            // Disasemble & Code
            // 0x01D47904: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47908 VirtAddr: 0x01D47908 -RVA: 0x01D47908 
        // -Collection<object>.OnSet
        //
        // file offset: 0x019D4F3C VirtAddr: 0x019D4F3C -RVA: 0x019D4F3C 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.OnSet
        //
        // file offset: 0x019D6868 VirtAddr: 0x019D6868 -RVA: 0x019D6868 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.OnSet
        //
        // file offset: 0x019D8194 VirtAddr: 0x019D8194 -RVA: 0x019D8194 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.OnSet
        //
        // file offset: 0x019D9CC4 VirtAddr: 0x019D9CC4 -RVA: 0x019D9CC4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.OnSet
        //
        // file offset: 0x01D42C6C VirtAddr: 0x01D42C6C -RVA: 0x01D42C6C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.OnSet
        //
        // file offset: 0x01D44720 VirtAddr: 0x01D44720 -RVA: 0x01D44720 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.OnSet
        //
        // file offset: 0x01D46064 VirtAddr: 0x01D46064 -RVA: 0x01D46064 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.OnSet
        //
        // file offset: 0x01D491D0 VirtAddr: 0x01D491D0 -RVA: 0x01D491D0 
        // -Collection<uint>.OnSet
        //
        //
        // Offset in libil2cpp.so: 0x01D47908 (30701832), len: 4  VirtAddr: 0x01D47908 RVA: 0x01D47908 token: 100663330 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void OnSet(T item, int index)
        {
            //
            // Disasemble & Code
            // 0x01D47908: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D4790C VirtAddr: 0x01D4790C -RVA: 0x01D4790C 
        // -Collection<object>.OnRemove
        //
        // file offset: 0x019D4F40 VirtAddr: 0x019D4F40 -RVA: 0x019D4F40 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.OnRemove
        //
        // file offset: 0x019D686C VirtAddr: 0x019D686C -RVA: 0x019D686C 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.OnRemove
        //
        // file offset: 0x019D8198 VirtAddr: 0x019D8198 -RVA: 0x019D8198 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.OnRemove
        //
        // file offset: 0x019D9CC8 VirtAddr: 0x019D9CC8 -RVA: 0x019D9CC8 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.OnRemove
        //
        // file offset: 0x01D42C70 VirtAddr: 0x01D42C70 -RVA: 0x01D42C70 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.OnRemove
        //
        // file offset: 0x01D44724 VirtAddr: 0x01D44724 -RVA: 0x01D44724 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.OnRemove
        //
        // file offset: 0x01D46068 VirtAddr: 0x01D46068 -RVA: 0x01D46068 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.OnRemove
        //
        // file offset: 0x01D491D4 VirtAddr: 0x01D491D4 -RVA: 0x01D491D4 
        // -Collection<uint>.OnRemove
        //
        //
        // Offset in libil2cpp.so: 0x01D4790C (30701836), len: 4  VirtAddr: 0x01D4790C RVA: 0x01D4790C token: 100663331 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void OnRemove(T item, int index)
        {
            //
            // Disasemble & Code
            // 0x01D4790C: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47910 VirtAddr: 0x01D47910 -RVA: 0x01D47910 
        // -Collection<object>.OnClear
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.OnClear
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.OnClear
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.OnClear
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.OnClear
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.OnClear
        //
        // file offset: 0x019D4F44 VirtAddr: 0x019D4F44 -RVA: 0x019D4F44 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.OnClear
        //
        // file offset: 0x019D6870 VirtAddr: 0x019D6870 -RVA: 0x019D6870 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.OnClear
        //
        // file offset: 0x019D819C VirtAddr: 0x019D819C -RVA: 0x019D819C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.OnClear
        //
        // file offset: 0x019D9CCC VirtAddr: 0x019D9CCC -RVA: 0x019D9CCC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.OnClear
        //
        // file offset: 0x01D42C74 VirtAddr: 0x01D42C74 -RVA: 0x01D42C74 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.OnClear
        //
        // file offset: 0x01D44728 VirtAddr: 0x01D44728 -RVA: 0x01D44728 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.OnClear
        //
        // file offset: 0x01D4606C VirtAddr: 0x01D4606C -RVA: 0x01D4606C 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.OnClear
        //
        // file offset: 0x01D491D8 VirtAddr: 0x01D491D8 -RVA: 0x01D491D8 
        // -Collection<uint>.OnClear
        //
        //
        // Offset in libil2cpp.so: 0x01D47910 (30701840), len: 4  VirtAddr: 0x01D47910 RVA: 0x01D47910 token: 100663332 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected virtual void OnClear()
        {
            //
            // Disasemble & Code
            // 0x01D47910: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47914 VirtAddr: 0x01D47914 -RVA: 0x01D47914 
        // -Collection<object>.Grow
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.Grow
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.Grow
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.Grow
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.Grow
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.Grow
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.Grow
        //
        // file offset: 0x019D4F48 VirtAddr: 0x019D4F48 -RVA: 0x019D4F48 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Grow
        //
        // file offset: 0x019D6874 VirtAddr: 0x019D6874 -RVA: 0x019D6874 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Grow
        //
        // file offset: 0x019D81A0 VirtAddr: 0x019D81A0 -RVA: 0x019D81A0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Grow
        //
        // file offset: 0x019D9CD0 VirtAddr: 0x019D9CD0 -RVA: 0x019D9CD0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Grow
        //
        // file offset: 0x01D42C78 VirtAddr: 0x01D42C78 -RVA: 0x01D42C78 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Grow
        //
        // file offset: 0x01D4472C VirtAddr: 0x01D4472C -RVA: 0x01D4472C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Grow
        //
        // file offset: 0x01D46070 VirtAddr: 0x01D46070 -RVA: 0x01D46070 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Grow
        //
        // file offset: 0x01D491DC VirtAddr: 0x01D491DC -RVA: 0x01D491DC 
        // -Collection<uint>.Grow
        //
        //
        // Offset in libil2cpp.so: 0x01D47914 (30701844), len: 168  VirtAddr: 0x01D47914 RVA: 0x01D47914 token: 100663333 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        internal virtual void Grow(int desired)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_11;
            //  | 
            var val_12;
            // 0x01D47914: STP x22, x21, [sp, #-0x30]! | stack[1152921509404768880] = ???;  stack[1152921509404768888] = ???;  //  dest_result_addr=1152921509404768880 |  dest_result_addr=1152921509404768888
            // 0x01D47918: STP x20, x19, [sp, #0x10]  | stack[1152921509404768896] = ???;  stack[1152921509404768904] = ???;  //  dest_result_addr=1152921509404768896 |  dest_result_addr=1152921509404768904
            // 0x01D4791C: STP x29, x30, [sp, #0x20]  | stack[1152921509404768912] = ???;  stack[1152921509404768920] = ???;  //  dest_result_addr=1152921509404768912 |  dest_result_addr=1152921509404768920
            // 0x01D47920: ADD x29, sp, #0x20         | X29 = (1152921509404768880 + 32) = 1152921509404768912 (0x100000011DFA7A90);
            // 0x01D47924: MOV x19, x0                | X19 = 1152921509404780928 (0x100000011DFAA980);//ML01
            val_11 = this;
            // 0x01D47928: LDR w8, [x19, #0x18]       | 
            // 0x01D4792C: LDR x22, [x19, #0x10]      | 
            // 0x01D47930: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47934: ADD w21, w8, w1            | W21 = (W8 + desired);                   
            val_12 = W8 + desired;
            // 0x01D47938: CBNZ x22, #0x1d47940       | if (X22 != 0) goto label_0;             
            if(X22 != 0)
            {
                goto label_0;
            }
            // 0x01D4793C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D47940: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
            // 0x01D47944: CMP w21, w8                | STATE = COMPARE((W8 + desired), X22 + 24)
            // 0x01D47948: B.LE #0x1d479ac            | if (val_12 <= X22 + 24) goto label_1;   
            if(val_12 <= (X22 + 24))
            {
                goto label_1;
            }
            // 0x01D4794C: LDR x22, [x19, #0x10]      | 
            // 0x01D47950: CBNZ x22, #0x1d47958       | if (X22 != 0) goto label_2;             
            if(X22 != 0)
            {
                goto label_2;
            }
            // 0x01D47954: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x01D47958: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
            // 0x01D4795C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D47960: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01D47964: ORR w2, wzr, #4            | W2 = 4(0x4);                            
            // 0x01D47968: LSL w1, w8, #1             | W1 = (X22 + 24 << 1);                   
            int val_1 = (X22 + 24) << 1;
            // 0x01D4796C: BL #0x16f9490              | X0 = System.Math.Max(val1:  0, val2:  int val_1 = (X22 + 24) << 1);
            int val_2 = System.Math.Max(val1:  0, val2:  val_1);
            // 0x01D47970: MOV w1, w0                 | W1 = val_2;//m1                         
            // 0x01D47974: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D47978: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01D4797C: MOV w2, w21                | W2 = (W8 + desired);//m1                
            // 0x01D47980: BL #0x16f9490              | X0 = System.Math.Max(val1:  0, val2:  val_2);
            int val_3 = System.Math.Max(val1:  0, val2:  val_2);
            // 0x01D47984: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47988: MOV w1, w0                 | W1 = val_3;//m1                         
            // 0x01D4798C: MOV x0, x19                | X0 = 1152921509404780928 (0x100000011DFAA980);//ML01
            // 0x01D47990: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47994: LDR x2, [x8, #0x88]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 136;
            // 0x01D47998: LDR x3, [x2]               | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 136;
            // 0x01D4799C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D479A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            val_11 = ???;
            // 0x01D479A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            val_12 = ???;
            // 0x01D479A8: BR x3                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 136;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 136;
            label_1:
            // 0x01D479AC: LDP x29, x30, [sp, #0x20]  | X29 = val_4; X30 = val_5;                //  find_add[1152921509404756928] |  find_add[1152921509404756928]
            // 0x01D479B0: LDP x20, x19, [sp, #0x10]  | X20 = val_6; X19 = val_7;                //  find_add[1152921509404756928] |  find_add[1152921509404756928]
            // 0x01D479B4: LDP x22, x21, [sp], #0x30  | X22 = val_8; X21 = val_9;                //  find_add[1152921509404756928] |  find_add[1152921509404756928]
            // 0x01D479B8: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D479BC VirtAddr: 0x01D479BC -RVA: 0x01D479BC 
        // -Collection<object>.Resize
        //
        // file offset: 0x019D4FF0 VirtAddr: 0x019D4FF0 -RVA: 0x019D4FF0 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.Resize
        //
        // file offset: 0x019D691C VirtAddr: 0x019D691C -RVA: 0x019D691C 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.Resize
        //
        // file offset: 0x019D8248 VirtAddr: 0x019D8248 -RVA: 0x019D8248 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.Resize
        //
        // file offset: 0x019D9D78 VirtAddr: 0x019D9D78 -RVA: 0x019D9D78 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.Resize
        //
        // file offset: 0x01D42D20 VirtAddr: 0x01D42D20 -RVA: 0x01D42D20 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.Resize
        //
        // file offset: 0x01D447D4 VirtAddr: 0x01D447D4 -RVA: 0x01D447D4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.Resize
        //
        // file offset: 0x01D46118 VirtAddr: 0x01D46118 -RVA: 0x01D46118 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.Resize
        //
        // file offset: 0x01D49284 VirtAddr: 0x01D49284 -RVA: 0x01D49284 
        // -Collection<uint>.Resize
        //
        //
        // Offset in libil2cpp.so: 0x01D479BC (30702012), len: 220  VirtAddr: 0x01D479BC RVA: 0x01D479BC token: 100663334 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        protected void Resize(int new_size)
        {
            //
            // Disasemble & Code
            // 0x01D479BC: STP x22, x21, [sp, #-0x30]! | stack[1152921509404881904] = ???;  stack[1152921509404881912] = ???;  //  dest_result_addr=1152921509404881904 |  dest_result_addr=1152921509404881912
            // 0x01D479C0: STP x20, x19, [sp, #0x10]  | stack[1152921509404881920] = ???;  stack[1152921509404881928] = ???;  //  dest_result_addr=1152921509404881920 |  dest_result_addr=1152921509404881928
            // 0x01D479C4: STP x29, x30, [sp, #0x20]  | stack[1152921509404881936] = ???;  stack[1152921509404881944] = ???;  //  dest_result_addr=1152921509404881936 |  dest_result_addr=1152921509404881944
            // 0x01D479C8: ADD x29, sp, #0x20         | X29 = (1152921509404881904 + 32) = 1152921509404881936 (0x100000011DFC3410);
            // 0x01D479CC: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D479D0: LDRB w8, [x22, #0xa58]     | W8 = (bool)static_value_0373CA58;       
            // 0x01D479D4: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D479D8: MOV w20, w1                | W20 = new_size;//m1                     
            // 0x01D479DC: MOV x19, x0                | X19 = 1152921509404893952 (0x100000011DFC6300);//ML01
            // 0x01D479E0: TBNZ w8, #0, #0x1d479fc    | if (static_value_0373CA58 == true) goto label_0;
            // 0x01D479E4: ADRP x8, #0x3666000        | X8 = 57040896 (0x3666000);              
            // 0x01D479E8: LDR x8, [x8, #0xee0]       | X8 = 0x2B913C8;                         
            // 0x01D479EC: LDR w0, [x8]               | W0 = 0x1BB6;                            
            // 0x01D479F0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BB6, ????);     
            // 0x01D479F4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D479F8: STRB w8, [x22, #0xa58]     | static_value_0373CA58 = true;            //  dest_result_addr=57920088
            label_0:
            // 0x01D479FC: LDR w8, [x19, #0x18]       | 
            // 0x01D47A00: CMP w8, w20                | STATE = COMPARE(0x1, new_size)          
            // 0x01D47A04: B.EQ #0x1d47a54            | if (true == new_size) goto label_1;     
            if(true == new_size)
            {
                goto label_1;
            }
            // 0x01D47A08: B.GT #0x1d47a64            | if (true > new_size) goto label_2;      
            if(true > new_size)
            {
                goto label_2;
            }
            // 0x01D47A0C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x01D47A10: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x01D47A14: LDR x22, [x19, #0x10]      | 
            // 0x01D47A18: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x01D47A1C: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x01D47A20: TBZ w8, #0, #0x1d47a30     | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01D47A24: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x01D47A28: CBNZ w8, #0x1d47a30        | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01D47A2C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_4:
            // 0x01D47A30: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47A34: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D47A38: MOV x1, x22                | X1 = 57917440 (0x373C000);//ML01        
            // 0x01D47A3C: MOV w2, w20                | W2 = new_size;//m1                      
            // 0x01D47A40: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47A44: LDR x3, [x8, #0x90]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 144;
            // 0x01D47A48: LDR x8, [x3]               | X8 = __RuntimeMethodHiddenParam + 24 + 168 + 144;
            // 0x01D47A4C: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 144();
            // 0x01D47A50: STR x0, [x19, #0x10]       | mem[1152921509404893968] = 0x0;          //  dest_result_addr=1152921509404893968
            mem[1152921509404893968] = 0;
            label_1:
            // 0x01D47A54: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47A58: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47A5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47A60: RET                        |  return;                                
            return;
            label_2:
            // 0x01D47A64: ADRP x8, #0x35ea000        | X8 = 56532992 (0x35EA000);              
            // 0x01D47A68: LDR x8, [x8, #0x2b0]       | X8 = 1152921504651948032;               
            // 0x01D47A6C: LDR x0, [x8]               | X0 = typeof(System.ArgumentOutOfRangeException);
            System.ArgumentOutOfRangeException val_1 = null;
            // 0x01D47A70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47A74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47A78: MOV x19, x0                | X19 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D47A7C: BL #0x18cb840              | .ctor();                                
            val_1 = new System.ArgumentOutOfRangeException();
            // 0x01D47A80: ADRP x8, #0x360b000        | X8 = 56668160 (0x360B000);              
            // 0x01D47A84: LDR x8, [x8, #0xd20]       | X8 = 1152921509404868928;               
            // 0x01D47A88: MOV x0, x19                | X0 = 1152921504651948032 (0x1000000002B03000);//ML01
            // 0x01D47A8C: LDR x1, [x8]               | X1 = System.Void ILRuntime.Mono.Collections.Generic.Collection<System.Object>::Resize(int new_size);
            // 0x01D47A90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentOutOfRangeException), ????);
            // 0x01D47A94: BL #0x1d41f54              | set_Item(index:  503054656, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
            set_Item(index:  503054656, value:  new ILRuntime.Mono.Cecil.Metadata.Row<System.UInt32, ILRuntime.Mono.Cecil.MetadataToken>() {Col2 = new ILRuntime.Mono.Cecil.MetadataToken() {token = __RuntimeMethodHiddenParam}});
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47A98 VirtAddr: 0x01D47A98 -RVA: 0x01D47A98 
        // -Collection<object>.System.Collections.IList.Add
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.Add
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.Add
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.Add
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.Add
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.Add
        //
        // file offset: 0x019D50CC VirtAddr: 0x019D50CC -RVA: 0x019D50CC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.Add
        //
        // file offset: 0x019D69F8 VirtAddr: 0x019D69F8 -RVA: 0x019D69F8 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.Add
        //
        // file offset: 0x019D8324 VirtAddr: 0x019D8324 -RVA: 0x019D8324 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.Add
        //
        // file offset: 0x019D9E54 VirtAddr: 0x019D9E54 -RVA: 0x019D9E54 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.Add
        //
        // file offset: 0x01D42DFC VirtAddr: 0x01D42DFC -RVA: 0x01D42DFC 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.Add
        //
        // file offset: 0x01D448B0 VirtAddr: 0x01D448B0 -RVA: 0x01D448B0 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.Add
        //
        // file offset: 0x01D461F4 VirtAddr: 0x01D461F4 -RVA: 0x01D461F4 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.Add
        //
        // file offset: 0x01D49360 VirtAddr: 0x01D49360 -RVA: 0x01D49360 
        // -Collection<uint>.System.Collections.IList.Add
        //
        //
        // Offset in libil2cpp.so: 0x01D47A98 (30702232), len: 452  VirtAddr: 0x01D47A98 RVA: 0x01D47A98 token: 100663335 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private int System.Collections.IList.Add(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D47A98: STP x24, x23, [sp, #-0x40]! | stack[1152921509404997984] = ???;  stack[1152921509404997992] = ???;  //  dest_result_addr=1152921509404997984 |  dest_result_addr=1152921509404997992
            // 0x01D47A9C: STP x22, x21, [sp, #0x10]  | stack[1152921509404998000] = ???;  stack[1152921509404998008] = ???;  //  dest_result_addr=1152921509404998000 |  dest_result_addr=1152921509404998008
            // 0x01D47AA0: STP x20, x19, [sp, #0x20]  | stack[1152921509404998016] = ???;  stack[1152921509404998024] = ???;  //  dest_result_addr=1152921509404998016 |  dest_result_addr=1152921509404998024
            // 0x01D47AA4: STP x29, x30, [sp, #0x30]  | stack[1152921509404998032] = ???;  stack[1152921509404998040] = ???;  //  dest_result_addr=1152921509404998032 |  dest_result_addr=1152921509404998040
            // 0x01D47AA8: ADD x29, sp, #0x30         | X29 = (1152921509404997984 + 48) = 1152921509404998032 (0x100000011DFDF990);
            // 0x01D47AAC: SUB sp, sp, #0x10          | SP = (1152921509404997984 - 16) = 1152921509404997968 (0x100000011DFDF950);
            // 0x01D47AB0: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D47AB4: LDRB w8, [x22, #0xa59]     | W8 = (bool)static_value_0373CA59;       
            // 0x01D47AB8: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47ABC: MOV x21, x1                | X21 = value;//m1                        
            // 0x01D47AC0: MOV x19, x0                | X19 = 1152921509405010048 (0x100000011DFE2880);//ML01
            // 0x01D47AC4: TBNZ w8, #0, #0x1d47ae0    | if (static_value_0373CA59 == true) goto label_0;
            // 0x01D47AC8: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01D47ACC: LDR x8, [x8, #0x408]       | X8 = 0x2B914E8;                         
            // 0x01D47AD0: LDR w0, [x8]               | W0 = 0x1BFE;                            
            // 0x01D47AD4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BFE, ????);     
            // 0x01D47AD8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D47ADC: STRB w8, [x22, #0xa59]     | static_value_0373CA59 = true;            //  dest_result_addr=57920089
            label_0:
            // 0x01D47AE0: CBNZ x19, #0x1d47ae8       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D47AE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1BFE, ????);     
            label_1:
            // 0x01D47AE8: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47AEC: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47AF0: LDR x9, [x8, #0x98]        | X9 = __RuntimeMethodHiddenParam + 24 + 168 + 152;
            // 0x01D47AF4: LDR x22, [x8, #0x18]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x01D47AF8: LDR x23, [x9]              | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 152;
            // 0x01D47AFC: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47B00: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x01D47B04: CBZ x21, #0x1d47b48        | if (value == null) goto label_2;        
            if(value == null)
            {
                goto label_2;
            }
            // 0x01D47B08: MOV x0, x21                | X0 = value;//m1                         
            // 0x01D47B0C: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47B10: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x01D47B14: MOV x1, x0                 | X1 = value;//m1                         
            // 0x01D47B18: CBNZ x1, #0x1d47b4c        | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x01D47B1C: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x01D47B20: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01D47B24: ADD x8, sp, #8             | X8 = (1152921509404997968 + 8) = 1152921509404997976 (0x100000011DFDF958);
            // 0x01D47B28: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47B2C: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01D47B30: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921509404986048]
            // 0x01D47B34: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x01D47B38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47B3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x01D47B40: ADD x0, sp, #8             | X0 = (1152921509404997968 + 8) = 1152921509404997976 (0x100000011DFDF958);
            // 0x01D47B44: BL #0x299a140              | 
            label_2:
            // 0x01D47B48: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_3:
            // 0x01D47B4C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47B50: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47B54: LDR x2, [x8, #0x98]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 152;
            // 0x01D47B58: MOV x0, x19                | X0 = 1152921509405010048 (0x100000011DFE2880);//ML01
            // 0x01D47B5C: BLR x23                    | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 152();
            // 0x01D47B60: LDR w8, [x19, #0x18]       | 
            // 0x01D47B64: SUB w0, w8, #1             | W0 = (__RuntimeMethodHiddenParam + 24 + 168 - 1);
            var val_2 = (__RuntimeMethodHiddenParam + 24 + 168) - 1;
            // 0x01D47B68: SUB sp, x29, #0x30         | SP = (1152921509404998032 - 48) = 1152921509404997984 (0x100000011DFDF960);
            // 0x01D47B6C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47B70: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47B74: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D47B78: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D47B7C: RET                        |  return (System.Int32)(__RuntimeMethodHiddenParam + 24 + 168 - 1);
            return (int)val_2;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47C5C VirtAddr: 0x01D47C5C -RVA: 0x01D47C5C 
        // -Collection<object>.System.Collections.IList.Clear
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.Clear
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.Clear
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.Clear
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.Clear
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.Clear
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.Clear
        //
        // file offset: 0x019D5294 VirtAddr: 0x019D5294 -RVA: 0x019D5294 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.Clear
        //
        // file offset: 0x019D6BC0 VirtAddr: 0x019D6BC0 -RVA: 0x019D6BC0 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.Clear
        //
        // file offset: 0x019D84EC VirtAddr: 0x019D84EC -RVA: 0x019D84EC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.Clear
        //
        // file offset: 0x019DA034 VirtAddr: 0x019DA034 -RVA: 0x019DA034 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.Clear
        //
        // file offset: 0x01D42FC4 VirtAddr: 0x01D42FC4 -RVA: 0x01D42FC4 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.Clear
        //
        // file offset: 0x01D44A90 VirtAddr: 0x01D44A90 -RVA: 0x01D44A90 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.Clear
        //
        // file offset: 0x01D463BC VirtAddr: 0x01D463BC -RVA: 0x01D463BC 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.Clear
        //
        // file offset: 0x01D49528 VirtAddr: 0x01D49528 -RVA: 0x01D49528 
        // -Collection<uint>.System.Collections.IList.Clear
        //
        //
        // Offset in libil2cpp.so: 0x01D47C5C (30702684), len: 60  VirtAddr: 0x01D47C5C RVA: 0x01D47C5C token: 100663336 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.Clear()
        {
            //
            // Disasemble & Code
            // 0x01D47C5C: STP x20, x19, [sp, #-0x20]! | stack[1152921509405114112] = ???;  stack[1152921509405114120] = ???;  //  dest_result_addr=1152921509405114112 |  dest_result_addr=1152921509405114120
            // 0x01D47C60: STP x29, x30, [sp, #0x10]  | stack[1152921509405114128] = ???;  stack[1152921509405114136] = ???;  //  dest_result_addr=1152921509405114128 |  dest_result_addr=1152921509405114136
            // 0x01D47C64: ADD x29, sp, #0x10         | X29 = (1152921509405114112 + 16) = 1152921509405114128 (0x100000011DFFBF10);
            // 0x01D47C68: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47C6C: MOV x20, x0                | X20 = 1152921509405126144 (0x100000011DFFEE00);//ML01
            // 0x01D47C70: CBNZ x20, #0x1d47c78       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D47C74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D47C78: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47C7C: MOV x0, x20                | X0 = 1152921509405126144 (0x100000011DFFEE00);//ML01
            // 0x01D47C80: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47C84: LDR x1, [x8, #0xa0]        | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 160;
            // 0x01D47C88: LDR x2, [x1]               | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 160;
            // 0x01D47C8C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47C90: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D47C94: BR x2                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 160;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 160;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47C98 VirtAddr: 0x01D47C98 -RVA: 0x01D47C98 
        // -Collection<object>.System.Collections.IList.Contains
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.Contains
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.Contains
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.Contains
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.Contains
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.Contains
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.Contains
        //
        // file offset: 0x019D52D0 VirtAddr: 0x019D52D0 -RVA: 0x019D52D0 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.Contains
        //
        // file offset: 0x019D6BFC VirtAddr: 0x019D6BFC -RVA: 0x019D6BFC 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.Contains
        //
        // file offset: 0x019D8528 VirtAddr: 0x019D8528 -RVA: 0x019D8528 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.Contains
        //
        // file offset: 0x019DA070 VirtAddr: 0x019DA070 -RVA: 0x019DA070 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.Contains
        //
        // file offset: 0x01D43000 VirtAddr: 0x01D43000 -RVA: 0x01D43000 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.Contains
        //
        // file offset: 0x01D44ACC VirtAddr: 0x01D44ACC -RVA: 0x01D44ACC 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.Contains
        //
        // file offset: 0x01D463F8 VirtAddr: 0x01D463F8 -RVA: 0x01D463F8 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.Contains
        //
        // file offset: 0x01D49564 VirtAddr: 0x01D49564 -RVA: 0x01D49564 
        // -Collection<uint>.System.Collections.IList.Contains
        //
        //
        // Offset in libil2cpp.so: 0x01D47C98 (30702744), len: 204  VirtAddr: 0x01D47C98 RVA: 0x01D47C98 token: 100663337 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private bool System.Collections.IList.Contains(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x01D47C98: STP x22, x21, [sp, #-0x30]! | stack[1152921509405230192] = ???;  stack[1152921509405230200] = ???;  //  dest_result_addr=1152921509405230192 |  dest_result_addr=1152921509405230200
            // 0x01D47C9C: STP x20, x19, [sp, #0x10]  | stack[1152921509405230208] = ???;  stack[1152921509405230216] = ???;  //  dest_result_addr=1152921509405230208 |  dest_result_addr=1152921509405230216
            // 0x01D47CA0: STP x29, x30, [sp, #0x20]  | stack[1152921509405230224] = ???;  stack[1152921509405230232] = ???;  //  dest_result_addr=1152921509405230224 |  dest_result_addr=1152921509405230232
            // 0x01D47CA4: ADD x29, sp, #0x20         | X29 = (1152921509405230192 + 32) = 1152921509405230224 (0x100000011E018490);
            // 0x01D47CA8: ADRP x21, #0x373c000       | X21 = 57917440 (0x373C000);             
            // 0x01D47CAC: LDRB w8, [x21, #0xa5a]     | W8 = (bool)static_value_0373CA5A;       
            // 0x01D47CB0: MOV x19, x1                | X19 = value;//m1                        
            // 0x01D47CB4: MOV x20, x0                | X20 = 1152921509405242240 (0x100000011E01B380);//ML01
            // 0x01D47CB8: TBNZ w8, #0, #0x1d47cd4    | if (static_value_0373CA5A == true) goto label_0;
            // 0x01D47CBC: ADRP x8, #0x3662000        | X8 = 57024512 (0x3662000);              
            // 0x01D47CC0: LDR x8, [x8, #0x30]        | X8 = 0x2B91510;                         
            // 0x01D47CC4: LDR w0, [x8]               | W0 = 0x1C08;                            
            // 0x01D47CC8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C08, ????);     
            // 0x01D47CCC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D47CD0: STRB w8, [x21, #0xa5a]     | static_value_0373CA5A = true;            //  dest_result_addr=57920090
            label_0:
            // 0x01D47CD4: CBNZ x20, #0x1d47cdc       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D47CD8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C08, ????);     
            label_1:
            // 0x01D47CDC: ADRP x9, #0x3605000        | X9 = 56643584 (0x3605000);              
            // 0x01D47CE0: LDR x8, [x20]              | X8 = typeof(ILRuntime.Mono.Collections.Generic.Collection<T>);
            // 0x01D47CE4: LDR x9, [x9, #0x308]       | X9 = 1152921504609349632;               
            // 0x01D47CE8: LDR x1, [x9]               | X1 = typeof(System.Collections.IList);  
            // 0x01D47CEC: LDRH w9, [x8, #0x102]      | W9 = ILRuntime.Mono.Collections.Generic.Collection<T>.__il2cppRuntimeField_interface_offsets_count;
            // 0x01D47CF0: CBZ x9, #0x1d47d1c         | if (ILRuntime.Mono.Collections.Generic.Collection<T>.__il2cppRuntimeField_interface_offsets_count == 0) goto label_2;
            // 0x01D47CF4: LDR x10, [x8, #0x98]       | X10 = ILRuntime.Mono.Collections.Generic.Collection<T>.__il2cppRuntimeField_interfaceOffsets;
            // 0x01D47CF8: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x01D47CFC: ADD x10, x10, #8           | X10 = (ILRuntime.Mono.Collections.Generic.Collection<T>.__il2cppRuntimeField_interfaceOffsets + 8) = 1152921504737021960 (0x1000000007C25008);
            label_4:
            // 0x01D47D00: LDUR x12, [x10, #-8]       | X12 = Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType;
            // 0x01D47D04: CMP x12, x1                | STATE = COMPARE(Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType, typeof(System.Collections.IList))
            // 0x01D47D08: B.EQ #0x1d47d2c            | if (Klass->__il2cppRuntimeField_interfaceOffsets[].interfaceType == null) goto label_3;
            // 0x01D47D0C: ADD x11, x11, #1           | X11 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x01D47D10: ADD x10, x10, #0x10        | X10 = (1152921504737021960 + 16) = 1152921504737021976 (0x1000000007C25018);
            // 0x01D47D14: CMP x11, x9                | STATE = COMPARE((0 + 1), ILRuntime.Mono.Collections.Generic.Collection<T>.__il2cppRuntimeField_interface_offsets_count)
            // 0x01D47D18: B.LO #0x1d47d00            | if (0 < ILRuntime.Mono.Collections.Generic.Collection<T>.__il2cppRuntimeField_interface_offsets_count) goto label_4;
            label_2:
            // 0x01D47D1C: ORR w2, wzr, #7            | W2 = 7(0x7);                            
            // 0x01D47D20: MOV x0, x20                | X0 = 1152921509405242240 (0x100000011E01B380);//ML01
            val_3 = this;
            // 0x01D47D24: BL #0x2776c24              | X0 = sub_2776C24( ?? this, ????);       
            // 0x01D47D28: B #0x1d47d3c               |  goto label_5;                          
            goto label_5;
            label_3:
            // 0x01D47D2C: LDR w9, [x10]              | W9 = Klass->__il2cppRuntimeField_interfaceOffsets[].offset;
            // 0x01D47D30: ADD w9, w9, #7             | W9 = (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7);
            // 0x01D47D34: ADD x8, x8, w9, uxtw #4    | X8 = (1152921504736985088 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7));
            // 0x01D47D38: ADD x0, x8, #0x110         |  //  not_find_field:(1152921504736985088 + (Klass->__il2cppRuntimeField_interfaceOffsets[].offset + 7)).272
            label_5:
            // 0x01D47D3C: LDP x8, x2, [x0]           | X8 = 0xA0012000014DB; X2 = 0x27A6010;    //  | 
            // 0x01D47D40: MOV x0, x20                | X0 = 1152921509405242240 (0x100000011E01B380);//ML01
            // 0x01D47D44: MOV x1, x19                | X1 = value;//m1                         
            // 0x01D47D48: BLR x8                     | X0 = sub_A0012000014DB( ?? this, ????); 
            // 0x01D47D4C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47D50: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47D54: CMP w0, #0                 | STATE = COMPARE(this, 0x0)              
            // 0x01D47D58: CSET w0, ge                | W0 = this >= null ? 1 : 0;              
            var val_2 = (this >= 0) ? 1 : 0;
            // 0x01D47D5C: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D47D60: RET                        |  return (System.Boolean)this >= null ? 1 : 0;
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47D64 VirtAddr: 0x01D47D64 -RVA: 0x01D47D64 
        // -Collection<object>.System.Collections.IList.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.IndexOf
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.IndexOf
        //
        // file offset: 0x019D539C VirtAddr: 0x019D539C -RVA: 0x019D539C 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.IndexOf
        //
        // file offset: 0x019D6CC8 VirtAddr: 0x019D6CC8 -RVA: 0x019D6CC8 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.IndexOf
        //
        // file offset: 0x019D85F4 VirtAddr: 0x019D85F4 -RVA: 0x019D85F4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.IndexOf
        //
        // file offset: 0x019DA13C VirtAddr: 0x019DA13C -RVA: 0x019DA13C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.IndexOf
        //
        // file offset: 0x01D430CC VirtAddr: 0x01D430CC -RVA: 0x01D430CC 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.IndexOf
        //
        // file offset: 0x01D44B98 VirtAddr: 0x01D44B98 -RVA: 0x01D44B98 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.IndexOf
        //
        // file offset: 0x01D464C4 VirtAddr: 0x01D464C4 -RVA: 0x01D464C4 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.IndexOf
        //
        // file offset: 0x01D49630 VirtAddr: 0x01D49630 -RVA: 0x01D49630 
        // -Collection<uint>.System.Collections.IList.IndexOf
        //
        //
        // Offset in libil2cpp.so: 0x01D47D64 (30702948), len: 400  VirtAddr: 0x01D47D64 RVA: 0x01D47D64 token: 100663338 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private int System.Collections.IList.IndexOf(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D47D64: STP x24, x23, [sp, #-0x40]! | stack[1152921509405350368] = ???;  stack[1152921509405350376] = ???;  //  dest_result_addr=1152921509405350368 |  dest_result_addr=1152921509405350376
            // 0x01D47D68: STP x22, x21, [sp, #0x10]  | stack[1152921509405350384] = ???;  stack[1152921509405350392] = ???;  //  dest_result_addr=1152921509405350384 |  dest_result_addr=1152921509405350392
            // 0x01D47D6C: STP x20, x19, [sp, #0x20]  | stack[1152921509405350400] = ???;  stack[1152921509405350408] = ???;  //  dest_result_addr=1152921509405350400 |  dest_result_addr=1152921509405350408
            // 0x01D47D70: STP x29, x30, [sp, #0x30]  | stack[1152921509405350416] = ???;  stack[1152921509405350424] = ???;  //  dest_result_addr=1152921509405350416 |  dest_result_addr=1152921509405350424
            // 0x01D47D74: ADD x29, sp, #0x30         | X29 = (1152921509405350368 + 48) = 1152921509405350416 (0x100000011E035A10);
            // 0x01D47D78: SUB sp, sp, #0x10          | SP = (1152921509405350368 - 16) = 1152921509405350352 (0x100000011E0359D0);
            // 0x01D47D7C: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D47D80: LDRB w8, [x22, #0xa5b]     | W8 = (bool)static_value_0373CA5B;       
            // 0x01D47D84: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47D88: MOV x21, x1                | X21 = value;//m1                        
            // 0x01D47D8C: MOV x19, x0                | X19 = 1152921509405362432 (0x100000011E038900);//ML01
            // 0x01D47D90: TBNZ w8, #0, #0x1d47dac    | if (static_value_0373CA5B == true) goto label_0;
            // 0x01D47D94: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x01D47D98: LDR x8, [x8, #0x8e8]       | X8 = 0x2B9153C;                         
            // 0x01D47D9C: LDR w0, [x8]               | W0 = 0x1C13;                            
            // 0x01D47DA0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C13, ????);     
            // 0x01D47DA4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D47DA8: STRB w8, [x22, #0xa5b]     | static_value_0373CA5B = true;            //  dest_result_addr=57920091
            label_0:
            // 0x01D47DAC: CBNZ x19, #0x1d47db4       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D47DB0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C13, ????);     
            label_1:
            // 0x01D47DB4: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47DB8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47DBC: LDR x9, [x8, #0x58]        | X9 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D47DC0: LDR x22, [x8, #0x18]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x01D47DC4: LDR x23, [x9]              | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D47DC8: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47DCC: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x01D47DD0: CBZ x21, #0x1d47e14        | if (value == null) goto label_2;        
            if(value == null)
            {
                goto label_2;
            }
            // 0x01D47DD4: MOV x0, x21                | X0 = value;//m1                         
            // 0x01D47DD8: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47DDC: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x01D47DE0: MOV x1, x0                 | X1 = value;//m1                         
            // 0x01D47DE4: CBNZ x1, #0x1d47e18        | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x01D47DE8: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x01D47DEC: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01D47DF0: ADD x8, sp, #8             | X8 = (1152921509405350352 + 8) = 1152921509405350360 (0x100000011E0359D8);
            // 0x01D47DF4: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47DF8: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01D47DFC: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921509405338432]
            // 0x01D47E00: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x01D47E04: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47E08: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x01D47E0C: ADD x0, sp, #8             | X0 = (1152921509405350352 + 8) = 1152921509405350360 (0x100000011E0359D8);
            // 0x01D47E10: BL #0x299a140              | 
            label_2:
            // 0x01D47E14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_3:
            // 0x01D47E18: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47E1C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47E20: LDR x2, [x8, #0x58]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 88;
            // 0x01D47E24: MOV x0, x19                | X0 = 1152921509405362432 (0x100000011E038900);//ML01
            // 0x01D47E28: BLR x23                    | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 88();
            // 0x01D47E2C: SUB sp, x29, #0x30         | SP = (1152921509405350416 - 48) = 1152921509405350368 (0x100000011E0359E0);
            // 0x01D47E30: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47E34: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47E38: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D47E3C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D47E40: RET                        |  return (System.Int32)this;             
            return (int)this;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D47EF4 VirtAddr: 0x01D47EF4 -RVA: 0x01D47EF4 
        // -Collection<object>.System.Collections.IList.Insert
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.Insert
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.Insert
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.Insert
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.Insert
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.Insert
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.Insert
        //
        // file offset: 0x019D5530 VirtAddr: 0x019D5530 -RVA: 0x019D5530 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.Insert
        //
        // file offset: 0x019D6E5C VirtAddr: 0x019D6E5C -RVA: 0x019D6E5C 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.Insert
        //
        // file offset: 0x019D8788 VirtAddr: 0x019D8788 -RVA: 0x019D8788 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.Insert
        //
        // file offset: 0x019DA2E8 VirtAddr: 0x019DA2E8 -RVA: 0x019DA2E8 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.Insert
        //
        // file offset: 0x01D43260 VirtAddr: 0x01D43260 -RVA: 0x01D43260 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.Insert
        //
        // file offset: 0x01D44D44 VirtAddr: 0x01D44D44 -RVA: 0x01D44D44 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.Insert
        //
        // file offset: 0x01D46658 VirtAddr: 0x01D46658 -RVA: 0x01D46658 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.Insert
        //
        // file offset: 0x01D497C4 VirtAddr: 0x01D497C4 -RVA: 0x01D497C4 
        // -Collection<uint>.System.Collections.IList.Insert
        //
        //
        // Offset in libil2cpp.so: 0x01D47EF4 (30703348), len: 488  VirtAddr: 0x01D47EF4 RVA: 0x01D47EF4 token: 100663339 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.Insert(int index, object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D47EF4: STP x24, x23, [sp, #-0x40]! | stack[1152921509405470560] = ???;  stack[1152921509405470568] = ???;  //  dest_result_addr=1152921509405470560 |  dest_result_addr=1152921509405470568
            // 0x01D47EF8: STP x22, x21, [sp, #0x10]  | stack[1152921509405470576] = ???;  stack[1152921509405470584] = ???;  //  dest_result_addr=1152921509405470576 |  dest_result_addr=1152921509405470584
            // 0x01D47EFC: STP x20, x19, [sp, #0x20]  | stack[1152921509405470592] = ???;  stack[1152921509405470600] = ???;  //  dest_result_addr=1152921509405470592 |  dest_result_addr=1152921509405470600
            // 0x01D47F00: STP x29, x30, [sp, #0x30]  | stack[1152921509405470608] = ???;  stack[1152921509405470616] = ???;  //  dest_result_addr=1152921509405470608 |  dest_result_addr=1152921509405470616
            // 0x01D47F04: ADD x29, sp, #0x30         | X29 = (1152921509405470560 + 48) = 1152921509405470608 (0x100000011E052F90);
            // 0x01D47F08: SUB sp, sp, #0x10          | SP = (1152921509405470560 - 16) = 1152921509405470544 (0x100000011E052F50);
            // 0x01D47F0C: ADRP x23, #0x373c000       | X23 = 57917440 (0x373C000);             
            // 0x01D47F10: LDRB w8, [x23, #0xa5c]     | W8 = (bool)static_value_0373CA5C;       
            // 0x01D47F14: MOV x20, x3                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D47F18: MOV x22, x2                | X22 = value;//m1                        
            // 0x01D47F1C: MOV w19, w1                | W19 = index;//m1                        
            // 0x01D47F20: MOV x21, x0                | X21 = 1152921509405482624 (0x100000011E055E80);//ML01
            // 0x01D47F24: TBNZ w8, #0, #0x1d47f40    | if (static_value_0373CA5C == true) goto label_0;
            // 0x01D47F28: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x01D47F2C: LDR x8, [x8, #0x310]       | X8 = 0x2B91564;                         
            // 0x01D47F30: LDR w0, [x8]               | W0 = 0x1C1D;                            
            // 0x01D47F34: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C1D, ????);     
            // 0x01D47F38: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D47F3C: STRB w8, [x23, #0xa5c]     | static_value_0373CA5C = true;            //  dest_result_addr=57920092
            label_0:
            // 0x01D47F40: CBNZ x21, #0x1d47f48       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D47F44: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C1D, ????);     
            label_1:
            // 0x01D47F48: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47F4C: MOV x0, x21                | X0 = 1152921509405482624 (0x100000011E055E80);//ML01
            // 0x01D47F50: MOV w1, w19                | W1 = index;//m1                         
            // 0x01D47F54: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47F58: LDR x2, [x8]               | X2 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47F5C: LDR x8, [x2]               | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47F60: BLR x8                     | X0 = __RuntimeMethodHiddenParam + 24 + 168();
            // 0x01D47F64: CBNZ x21, #0x1d47f6c       | if (this != null) goto label_2;         
            if(this != null)
            {
                goto label_2;
            }
            // 0x01D47F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x01D47F6C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47F70: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47F74: LDR x9, [x8, #0xa8]        | X9 = __RuntimeMethodHiddenParam + 24 + 168 + 168;
            // 0x01D47F78: LDR x23, [x8, #0x18]       | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x01D47F7C: LDR x24, [x9]              | X24 = __RuntimeMethodHiddenParam + 24 + 168 + 168;
            // 0x01D47F80: MOV x0, x23                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47F84: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x01D47F88: CBZ x22, #0x1d47fcc        | if (value == null) goto label_3;        
            if(value == null)
            {
                goto label_3;
            }
            // 0x01D47F8C: MOV x0, x22                | X0 = value;//m1                         
            // 0x01D47F90: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47F94: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x01D47F98: MOV x2, x0                 | X2 = value;//m1                         
            // 0x01D47F9C: CBNZ x2, #0x1d47fd0        | if (value != null) goto label_4;        
            if(value != null)
            {
                goto label_4;
            }
            // 0x01D47FA0: LDR x8, [x22]              | X8 = typeof(System.Object);             
            // 0x01D47FA4: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01D47FA8: ADD x8, sp, #8             | X8 = (1152921509405470544 + 8) = 1152921509405470552 (0x100000011E052F58);
            // 0x01D47FAC: MOV x1, x23                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D47FB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01D47FB4: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921509405458624]
            // 0x01D47FB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x01D47FBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D47FC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x01D47FC4: ADD x0, sp, #8             | X0 = (1152921509405470544 + 8) = 1152921509405470552 (0x100000011E052F58);
            // 0x01D47FC8: BL #0x299a140              | 
            label_3:
            // 0x01D47FCC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            label_4:
            // 0x01D47FD0: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D47FD4: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D47FD8: LDR x3, [x8, #0xa8]        | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 168;
            // 0x01D47FDC: MOV x0, x21                | X0 = 1152921509405482624 (0x100000011E055E80);//ML01
            // 0x01D47FE0: MOV w1, w19                | W1 = index;//m1                         
            // 0x01D47FE4: BLR x24                    | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 168();
            // 0x01D47FE8: SUB sp, x29, #0x30         | SP = (1152921509405470608 - 48) = 1152921509405470560 (0x100000011E052F60);
            // 0x01D47FEC: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D47FF0: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D47FF4: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D47FF8: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D47FFC: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D480DC VirtAddr: 0x01D480DC -RVA: 0x01D480DC 
        // -Collection<object>.System.Collections.IList.Remove
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.Remove
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.Remove
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.Remove
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.Remove
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.Remove
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.Remove
        //
        // file offset: 0x019D571C VirtAddr: 0x019D571C -RVA: 0x019D571C 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.Remove
        //
        // file offset: 0x019D7048 VirtAddr: 0x019D7048 -RVA: 0x019D7048 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.Remove
        //
        // file offset: 0x019D8974 VirtAddr: 0x019D8974 -RVA: 0x019D8974 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.Remove
        //
        // file offset: 0x019DA4EC VirtAddr: 0x019DA4EC -RVA: 0x019DA4EC 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.Remove
        //
        // file offset: 0x01D4344C VirtAddr: 0x01D4344C -RVA: 0x01D4344C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.Remove
        //
        // file offset: 0x01D44F48 VirtAddr: 0x01D44F48 -RVA: 0x01D44F48 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.Remove
        //
        // file offset: 0x01D46844 VirtAddr: 0x01D46844 -RVA: 0x01D46844 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.Remove
        //
        // file offset: 0x01D499B0 VirtAddr: 0x01D499B0 -RVA: 0x01D499B0 
        // -Collection<uint>.System.Collections.IList.Remove
        //
        //
        // Offset in libil2cpp.so: 0x01D480DC (30703836), len: 396  VirtAddr: 0x01D480DC RVA: 0x01D480DC token: 100663340 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.Remove(object value)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x01D480DC: STP x24, x23, [sp, #-0x40]! | stack[1152921509405590752] = ???;  stack[1152921509405590760] = ???;  //  dest_result_addr=1152921509405590752 |  dest_result_addr=1152921509405590760
            // 0x01D480E0: STP x22, x21, [sp, #0x10]  | stack[1152921509405590768] = ???;  stack[1152921509405590776] = ???;  //  dest_result_addr=1152921509405590768 |  dest_result_addr=1152921509405590776
            // 0x01D480E4: STP x20, x19, [sp, #0x20]  | stack[1152921509405590784] = ???;  stack[1152921509405590792] = ???;  //  dest_result_addr=1152921509405590784 |  dest_result_addr=1152921509405590792
            // 0x01D480E8: STP x29, x30, [sp, #0x30]  | stack[1152921509405590800] = ???;  stack[1152921509405590808] = ???;  //  dest_result_addr=1152921509405590800 |  dest_result_addr=1152921509405590808
            // 0x01D480EC: ADD x29, sp, #0x30         | X29 = (1152921509405590752 + 48) = 1152921509405590800 (0x100000011E070510);
            // 0x01D480F0: SUB sp, sp, #0x10          | SP = (1152921509405590752 - 16) = 1152921509405590736 (0x100000011E0704D0);
            // 0x01D480F4: ADRP x22, #0x373c000       | X22 = 57917440 (0x373C000);             
            // 0x01D480F8: LDRB w8, [x22, #0xa5d]     | W8 = (bool)static_value_0373CA5D;       
            // 0x01D480FC: MOV x20, x2                | X20 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D48100: MOV x21, x1                | X21 = value;//m1                        
            // 0x01D48104: MOV x19, x0                | X19 = 1152921509405602816 (0x100000011E073400);//ML01
            // 0x01D48108: TBNZ w8, #0, #0x1d48124    | if (static_value_0373CA5D == true) goto label_0;
            // 0x01D4810C: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
            // 0x01D48110: LDR x8, [x8, #0xc70]       | X8 = 0x2B91574;                         
            // 0x01D48114: LDR w0, [x8]               | W0 = 0x1C21;                            
            // 0x01D48118: BL #0x2782188              | X0 = sub_2782188( ?? 0x1C21, ????);     
            // 0x01D4811C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01D48120: STRB w8, [x22, #0xa5d]     | static_value_0373CA5D = true;            //  dest_result_addr=57920093
            label_0:
            // 0x01D48124: CBNZ x19, #0x1d4812c       | if (this != null) goto label_1;         
            if(this != null)
            {
                goto label_1;
            }
            // 0x01D48128: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1C21, ????);     
            label_1:
            // 0x01D4812C: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D48130: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D48134: LDR x9, [x8, #0xb0]        | X9 = __RuntimeMethodHiddenParam + 24 + 168 + 176;
            // 0x01D48138: LDR x22, [x8, #0x18]       | X22 = __RuntimeMethodHiddenParam + 24 + 168 + 24;
            // 0x01D4813C: LDR x23, [x9]              | X23 = __RuntimeMethodHiddenParam + 24 + 168 + 176;
            // 0x01D48140: MOV x0, x22                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D48144: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 24, ????);
            // 0x01D48148: CBZ x21, #0x1d4818c        | if (value == null) goto label_2;        
            if(value == null)
            {
                goto label_2;
            }
            // 0x01D4814C: MOV x0, x21                | X0 = value;//m1                         
            // 0x01D48150: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D48154: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? value, ????);      
            // 0x01D48158: MOV x1, x0                 | X1 = value;//m1                         
            // 0x01D4815C: CBNZ x1, #0x1d48190        | if (value != null) goto label_3;        
            if(value != null)
            {
                goto label_3;
            }
            // 0x01D48160: LDR x8, [x21]              | X8 = typeof(System.Object);             
            // 0x01D48164: LDR x0, [x8, #0x30]        | X0 = System.Object.__il2cppRuntimeField_element_class;
            // 0x01D48168: ADD x8, sp, #8             | X8 = (1152921509405590736 + 8) = 1152921509405590744 (0x100000011E0704D8);
            // 0x01D4816C: MOV x1, x22                | X1 = __RuntimeMethodHiddenParam + 24 + 168 + 24;//m1
            // 0x01D48170: BL #0x27d96d4              | X0 = sub_27D96D4( ?? System.Object.__il2cppRuntimeField_element_class, ????);
            // 0x01D48174: LDR x0, [sp, #8]           | X0 = val_1;                              //  find_add[1152921509405578816]
            // 0x01D48178: BL #0x27af090              | X0 = sub_27AF090( ?? val_1, ????);      
            // 0x01D4817C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01D48180: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            // 0x01D48184: ADD x0, sp, #8             | X0 = (1152921509405590736 + 8) = 1152921509405590744 (0x100000011E0704D8);
            // 0x01D48188: BL #0x299a140              | 
            label_2:
            // 0x01D4818C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            label_3:
            // 0x01D48190: LDR x8, [x20, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D48194: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D48198: LDR x2, [x8, #0xb0]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 176;
            // 0x01D4819C: MOV x0, x19                | X0 = 1152921509405602816 (0x100000011E073400);//ML01
            // 0x01D481A0: BLR x23                    | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 176();
            // 0x01D481A4: SUB sp, x29, #0x30         | SP = (1152921509405590800 - 48) = 1152921509405590752 (0x100000011E0704E0);
            // 0x01D481A8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01D481AC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01D481B0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01D481B4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01D481B8: RET                        |  return;                                
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D48268 VirtAddr: 0x01D48268 -RVA: 0x01D48268 
        // -Collection<object>.System.Collections.IList.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IList.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IList.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IList.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IList.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IList.RemoveAt
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x019D58AC VirtAddr: 0x019D58AC -RVA: 0x019D58AC 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x019D71D8 VirtAddr: 0x019D71D8 -RVA: 0x019D71D8 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x019D8B04 VirtAddr: 0x019D8B04 -RVA: 0x019D8B04 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x019DA694 VirtAddr: 0x019DA694 -RVA: 0x019DA694 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x01D435DC VirtAddr: 0x01D435DC -RVA: 0x01D435DC 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x01D450F0 VirtAddr: 0x01D450F0 -RVA: 0x01D450F0 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x01D469D4 VirtAddr: 0x01D469D4 -RVA: 0x01D469D4 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IList.RemoveAt
        //
        // file offset: 0x01D49B40 VirtAddr: 0x01D49B40 -RVA: 0x01D49B40 
        // -Collection<uint>.System.Collections.IList.RemoveAt
        //
        //
        // Offset in libil2cpp.so: 0x01D48268 (30704232), len: 76  VirtAddr: 0x01D48268 RVA: 0x01D48268 token: 100663341 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.IList.RemoveAt(int index)
        {
            //
            // Disasemble & Code
            // 0x01D48268: STP x22, x21, [sp, #-0x30]! | stack[1152921509405706864] = ???;  stack[1152921509405706872] = ???;  //  dest_result_addr=1152921509405706864 |  dest_result_addr=1152921509405706872
            // 0x01D4826C: STP x20, x19, [sp, #0x10]  | stack[1152921509405706880] = ???;  stack[1152921509405706888] = ???;  //  dest_result_addr=1152921509405706880 |  dest_result_addr=1152921509405706888
            // 0x01D48270: STP x29, x30, [sp, #0x20]  | stack[1152921509405706896] = ???;  stack[1152921509405706904] = ???;  //  dest_result_addr=1152921509405706896 |  dest_result_addr=1152921509405706904
            // 0x01D48274: ADD x29, sp, #0x20         | X29 = (1152921509405706864 + 32) = 1152921509405706896 (0x100000011E08CA90);
            // 0x01D48278: MOV x21, x2                | X21 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D4827C: MOV w19, w1                | W19 = index;//m1                        
            // 0x01D48280: MOV x20, x0                | X20 = 1152921509405718912 (0x100000011E08F980);//ML01
            // 0x01D48284: CBNZ x20, #0x1d4828c       | if (this != null) goto label_0;         
            if(this != null)
            {
                goto label_0;
            }
            // 0x01D48288: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x01D4828C: LDR x8, [x21, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D48290: MOV x0, x20                | X0 = 1152921509405718912 (0x100000011E08F980);//ML01
            // 0x01D48294: MOV w1, w19                | W1 = index;//m1                         
            // 0x01D48298: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D4829C: LDR x2, [x8, #0xb8]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 184;
            // 0x01D482A0: LDR x3, [x2]               | X3 = __RuntimeMethodHiddenParam + 24 + 168 + 184;
            // 0x01D482A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01D482A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01D482AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01D482B0: BR x3                      | goto __RuntimeMethodHiddenParam + 24 + 168 + 184;
            goto __RuntimeMethodHiddenParam + 24 + 168 + 184;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D482B4 VirtAddr: 0x01D482B4 -RVA: 0x01D482B4 
        // -Collection<object>.System.Collections.ICollection.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.ICollection.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.ICollection.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.ICollection.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.ICollection.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.ICollection.CopyTo
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x019D58F8 VirtAddr: 0x019D58F8 -RVA: 0x019D58F8 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x019D7224 VirtAddr: 0x019D7224 -RVA: 0x019D7224 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x019D8B50 VirtAddr: 0x019D8B50 -RVA: 0x019D8B50 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x019DA6E0 VirtAddr: 0x019DA6E0 -RVA: 0x019DA6E0 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x01D43628 VirtAddr: 0x01D43628 -RVA: 0x01D43628 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x01D4513C VirtAddr: 0x01D4513C -RVA: 0x01D4513C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x01D46A20 VirtAddr: 0x01D46A20 -RVA: 0x01D46A20 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.ICollection.CopyTo
        //
        // file offset: 0x01D49B8C VirtAddr: 0x01D49B8C -RVA: 0x01D49B8C 
        // -Collection<uint>.System.Collections.ICollection.CopyTo
        //
        //
        // Offset in libil2cpp.so: 0x01D482B4 (30704308), len: 44  VirtAddr: 0x01D482B4 RVA: 0x01D482B4 token: 100663342 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private void System.Collections.ICollection.CopyTo(System.Array array, int index)
        {
            //
            // Disasemble & Code
            // 0x01D482B4: LDR x8, [x0, #0x10]        | 
            // 0x01D482B8: LDR w5, [x0, #0x18]        | 
            // 0x01D482BC: MOV w9, w2                 | W9 = index;//m1                         
            // 0x01D482C0: MOV x10, x1                | X10 = array;//m1                        
            // 0x01D482C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01D482C8: MOV x1, x8                 | X1 = X8;//m1                            
            // 0x01D482CC: MOV w2, wzr                | W2 = 0 (0x0);//ML01                     
            // 0x01D482D0: MOV x3, x10                | X3 = array;//m1                         
            // 0x01D482D4: MOV w4, w9                 | W4 = index;//m1                         
            // 0x01D482D8: MOV x6, xzr                | X6 = 0 (0x0);//ML01                     
            // 0x01D482DC: B #0x18ce87c               | System.Array.Copy(sourceArray:  0, sourceIndex:  X8, destinationArray:  0, destinationIndex:  array, length:  index); return;
            System.Array.Copy(sourceArray:  0, sourceIndex:  X8, destinationArray:  0, destinationIndex:  array, length:  index);
            return;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D482E0 VirtAddr: 0x01D482E0 -RVA: 0x01D482E0 
        // -Collection<object>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.Cil.StateMachineScope>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.CustomAttribute>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.Cil.ScopeDebugInformation>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.MethodReference>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.AssemblyNameReference>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.TypeReference>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.MethodDefinition>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.FieldDefinition>.GetEnumerator
        //
        // file offset: 0x019DA70C VirtAddr: 0x019DA70C -RVA: 0x019DA70C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.GetEnumerator
        //
        // file offset: 0x019D5924 VirtAddr: 0x019D5924 -RVA: 0x019D5924 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.GetEnumerator
        //
        // file offset: 0x019D7250 VirtAddr: 0x019D7250 -RVA: 0x019D7250 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.GetEnumerator
        //
        // file offset: 0x019D8B7C VirtAddr: 0x019D8B7C -RVA: 0x019D8B7C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.GetEnumerator
        //
        // file offset: 0x01D43654 VirtAddr: 0x01D43654 -RVA: 0x01D43654 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.GetEnumerator
        //
        // file offset: 0x01D45168 VirtAddr: 0x01D45168 -RVA: 0x01D45168 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.GetEnumerator
        //
        // file offset: 0x01D46A4C VirtAddr: 0x01D46A4C -RVA: 0x01D46A4C 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.GetEnumerator
        //
        // file offset: 0x01D49BB8 VirtAddr: 0x01D49BB8 -RVA: 0x01D49BB8 
        // -Collection<uint>.GetEnumerator
        //
        //
        // Offset in libil2cpp.so: 0x01D482E0 (30704352), len: 36  VirtAddr: 0x01D482E0 RVA: 0x01D482E0 token: 100663343 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        public ILRuntime.Mono.Collections.Generic.Collection.Enumerator<T> GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x01D482E0: STP xzr, xzr, [x8, #8]     | mem2[0] = 0x0;  mem2[0] = 0x0;           //  dest_result_addr=0 |  dest_result_addr=0
            mem2[0] = 0;
            mem2[0] = 0;
            // 0x01D482E4: STR xzr, [x8]              | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x01D482E8: LDR x9, [x1, #0x18]        | X9 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D482EC: LDR x9, [x9, #0xa8]        | X9 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D482F0: LDR x2, [x9, #0xc8]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 200;
            // 0x01D482F4: MOV x9, x0                 | X9 = 1152921509405951104 (0x100000011E0C8480);//ML01
            // 0x01D482F8: MOV x0, x8                 | X0 = X8;//m1                            
            // 0x01D482FC: MOV x1, x9                 | X1 = 1152921509405951104 (0x100000011E0C8480);//ML01
            // 0x01D48300: B #0x19d3c58               | goto label_Collection_Enumerator<System_Object>_System_Collections_IEnumerator_get_Current_GL019D3C58;
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D48304 VirtAddr: 0x01D48304 -RVA: 0x01D48304 
        // -Collection<object>.System.Collections.IEnumerable.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.IEnumerable.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.IEnumerable.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.IEnumerable.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.IEnumerable.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.IEnumerable.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x019D5960 VirtAddr: 0x019D5960 -RVA: 0x019D5960 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x019D728C VirtAddr: 0x019D728C -RVA: 0x019D728C 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x019D8BB8 VirtAddr: 0x019D8BB8 -RVA: 0x019D8BB8 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x019DA74C VirtAddr: 0x019DA74C -RVA: 0x019DA74C 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x01D43678 VirtAddr: 0x01D43678 -RVA: 0x01D43678 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x01D45190 VirtAddr: 0x01D45190 -RVA: 0x01D45190 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x01D46A70 VirtAddr: 0x01D46A70 -RVA: 0x01D46A70 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.IEnumerable.GetEnumerator
        //
        // file offset: 0x01D49BDC VirtAddr: 0x01D49BDC -RVA: 0x01D49BDC 
        // -Collection<uint>.System.Collections.IEnumerable.GetEnumerator
        //
        //
        // Offset in libil2cpp.so: 0x01D48304 (30704388), len: 120  VirtAddr: 0x01D48304 RVA: 0x01D48304 token: 100663344 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x01D48304: STP x20, x19, [sp, #-0x20]! | stack[1152921509406051072] = ???;  stack[1152921509406051080] = ???;  //  dest_result_addr=1152921509406051072 |  dest_result_addr=1152921509406051080
            // 0x01D48308: STP x29, x30, [sp, #0x10]  | stack[1152921509406051088] = ???;  stack[1152921509406051096] = ???;  //  dest_result_addr=1152921509406051088 |  dest_result_addr=1152921509406051096
            // 0x01D4830C: ADD x29, sp, #0x10         | X29 = (1152921509406051072 + 16) = 1152921509406051088 (0x100000011E0E0B10);
            // 0x01D48310: SUB sp, sp, #0x30          | SP = (1152921509406051072 - 48) = 1152921509406051024 (0x100000011E0E0AD0);
            // 0x01D48314: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D48318: STP xzr, xzr, [sp, #0x20]  | stack[1152921509406051056] = 0x0;  stack[1152921509406051064] = 0x0;  //  dest_result_addr=1152921509406051056 |  dest_result_addr=1152921509406051064
            // 0x01D4831C: STR xzr, [sp, #0x18]       | stack[1152921509406051048] = 0x0;        //  dest_result_addr=1152921509406051048
            // 0x01D48320: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D48324: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D48328: LDR x2, [x8, #0xc8]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 200;
            // 0x01D4832C: MOV x8, x0                 | X8 = 1152921509406063104 (0x100000011E0E3A00);//ML01
            // 0x01D48330: ADD x0, sp, #0x18          | X0 = (1152921509406051024 + 24) = 1152921509406051048 (0x100000011E0E0AE8);
            // 0x01D48334: MOV x1, x8                 | X1 = 1152921509406063104 (0x100000011E0E3A00);//ML01
            // 0x01D48338: BL #0x19d3c58              | X0 = label_Collection_Enumerator<System_Object>_System_Collections_IEnumerator_get_Current_GL019D3C58();
            // 0x01D4833C: LDR x8, [sp, #0x28]        | X8 = 0x0;                               
            // 0x01D48340: LDUR q0, [sp, #0x18]       | Q0 = 0x0;                               
            // 0x01D48344: STR x8, [sp, #0x10]        | stack[1152921509406051040] = 0x0;        //  dest_result_addr=1152921509406051040
            // 0x01D48348: STR q0, [sp]               | stack[1152921509406051024] = 0x0;        //  dest_result_addr=1152921509406051024
            // 0x01D4834C: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D48350: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D48354: LDR x19, [x8, #0xc0]       | X19 = __RuntimeMethodHiddenParam + 24 + 168 + 192;
            // 0x01D48358: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 192;//m1
            // 0x01D4835C: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 192, ????);
            // 0x01D48360: MOV x1, sp                 | X1 = 1152921509406051024 (0x100000011E0E0AD0);//ML01
            // 0x01D48364: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 192;//m1
            // 0x01D48368: BL #0x27bc028              | X0 = 0 = (Il2CppObject*)Box((RuntimeClass*)typeof(__RuntimeMethodHiddenParam + 24 + 168 + 192), 0x0);
            // 0x01D4836C: SUB sp, x29, #0x10         | SP = (1152921509406051088 - 16) = 1152921509406051072 (0x100000011E0E0B00);
            // 0x01D48370: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D48374: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D48378: RET                        |  return (System.Collections.IEnumerator)0x100000011E0E0AD0;
            return (System.Collections.IEnumerator);
            //  |  // // {name=val_0, type=System.Collections.IEnumerator, size=8, nGRN=0 }
        
        }
        // Generic instance method:
        //
        // file offset: 0x01D4837C VirtAddr: 0x01D4837C -RVA: 0x01D4837C 
        // -Collection<object>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.GenericParameter>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.ParameterDefinition>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.InterfaceImplementation>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.TypeDefinition>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.Cil.VariableDefinition>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        // -Collection<ILRuntime.Mono.Cecil.Cil.Instruction>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x019D59D0 VirtAddr: 0x019D59D0 -RVA: 0x019D59D0 
        // -Collection<ILRuntime.Mono.Cecil.ArrayDimension>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x019D72FC VirtAddr: 0x019D72FC -RVA: 0x019D72FC 
        // -Collection<ILRuntime.Mono.Cecil.Cil.InstructionOffset>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x019D8C28 VirtAddr: 0x019D8C28 -RVA: 0x019D8C28 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeArgument>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x019DA7C4 VirtAddr: 0x019DA7C4 -RVA: 0x019DA7C4 
        // -Collection<ILRuntime.Mono.Cecil.CustomAttributeNamedArgument>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x01D436F0 VirtAddr: 0x01D436F0 -RVA: 0x01D436F0 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.MetadataToken>>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x01D4520C VirtAddr: 0x01D4520C -RVA: 0x01D4520C 
        // -Collection<ILRuntime.Mono.Cecil.Metadata.Row<uint, ILRuntime.Mono.Cecil.Range, ILRuntime.Mono.Cecil.Range, uint, uint, uint>>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x01D46AE8 VirtAddr: 0x01D46AE8 -RVA: 0x01D46AE8 
        // -Collection<ILRuntime.Mono.Cecil.MetadataToken>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        // file offset: 0x01D49C54 VirtAddr: 0x01D49C54 -RVA: 0x01D49C54 
        // -Collection<uint>.System.Collections.Generic.IEnumerable<T>.GetEnumerator
        //
        //
        // Offset in libil2cpp.so: 0x01D4837C (30704508), len: 120  VirtAddr: 0x01D4837C RVA: 0x01D4837C token: 100663345 methodIndex: -1 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Collections.Generic.IEnumerator<T> System.Collections.Generic.IEnumerable<T>.GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x01D4837C: STP x20, x19, [sp, #-0x20]! | stack[1152921509406163072] = ???;  stack[1152921509406163080] = ???;  //  dest_result_addr=1152921509406163072 |  dest_result_addr=1152921509406163080
            // 0x01D48380: STP x29, x30, [sp, #0x10]  | stack[1152921509406163088] = ???;  stack[1152921509406163096] = ???;  //  dest_result_addr=1152921509406163088 |  dest_result_addr=1152921509406163096
            // 0x01D48384: ADD x29, sp, #0x10         | X29 = (1152921509406163072 + 16) = 1152921509406163088 (0x100000011E0FC090);
            // 0x01D48388: SUB sp, sp, #0x30          | SP = (1152921509406163072 - 48) = 1152921509406163024 (0x100000011E0FC050);
            // 0x01D4838C: MOV x19, x1                | X19 = __RuntimeMethodHiddenParam;//m1   
            // 0x01D48390: STP xzr, xzr, [sp, #0x20]  | stack[1152921509406163056] = 0x0;  stack[1152921509406163064] = 0x0;  //  dest_result_addr=1152921509406163056 |  dest_result_addr=1152921509406163064
            // 0x01D48394: STR xzr, [sp, #0x18]       | stack[1152921509406163048] = 0x0;        //  dest_result_addr=1152921509406163048
            // 0x01D48398: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D4839C: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D483A0: LDR x2, [x8, #0xc8]        | X2 = __RuntimeMethodHiddenParam + 24 + 168 + 200;
            // 0x01D483A4: MOV x8, x0                 | X8 = 1152921509406175104 (0x100000011E0FEF80);//ML01
            // 0x01D483A8: ADD x0, sp, #0x18          | X0 = (1152921509406163024 + 24) = 1152921509406163048 (0x100000011E0FC068);
            // 0x01D483AC: MOV x1, x8                 | X1 = 1152921509406175104 (0x100000011E0FEF80);//ML01
            // 0x01D483B0: BL #0x19d3c58              | X0 = label_Collection_Enumerator<System_Object>_System_Collections_IEnumerator_get_Current_GL019D3C58();
            // 0x01D483B4: LDR x8, [sp, #0x28]        | X8 = 0x0;                               
            // 0x01D483B8: LDUR q0, [sp, #0x18]       | Q0 = 0x0;                               
            // 0x01D483BC: STR x8, [sp, #0x10]        | stack[1152921509406163040] = 0x0;        //  dest_result_addr=1152921509406163040
            // 0x01D483C0: STR q0, [sp]               | stack[1152921509406163024] = 0x0;        //  dest_result_addr=1152921509406163024
            // 0x01D483C4: LDR x8, [x19, #0x18]       | X8 = __RuntimeMethodHiddenParam + 24;   
            // 0x01D483C8: LDR x8, [x8, #0xa8]        | X8 = __RuntimeMethodHiddenParam + 24 + 168;
            // 0x01D483CC: LDR x19, [x8, #0xc0]       | X19 = __RuntimeMethodHiddenParam + 24 + 168 + 192;
            // 0x01D483D0: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 192;//m1
            // 0x01D483D4: BL #0x277461c              | X0 = sub_277461C( ?? __RuntimeMethodHiddenParam + 24 + 168 + 192, ????);
            // 0x01D483D8: MOV x1, sp                 | X1 = 1152921509406163024 (0x100000011E0FC050);//ML01
            // 0x01D483DC: MOV x0, x19                | X0 = __RuntimeMethodHiddenParam + 24 + 168 + 192;//m1
            // 0x01D483E0: BL #0x27bc028              | X0 = 0 = (Il2CppObject*)Box((RuntimeClass*)typeof(__RuntimeMethodHiddenParam + 24 + 168 + 192), 0x0);
            // 0x01D483E4: SUB sp, x29, #0x10         | SP = (1152921509406163088 - 16) = 1152921509406163072 (0x100000011E0FC080);
            // 0x01D483E8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01D483EC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01D483F0: RET                        |  return (System.Collections.Generic.IEnumerator<T>)0x100000011E0FC050;
            return (System.Collections.Generic.IEnumerator<T>);
            //  |  // // {name=val_0, type=System.Collections.Generic.IEnumerator<T>, size=8, nGRN=0 }
        
        }
    
    }

}
