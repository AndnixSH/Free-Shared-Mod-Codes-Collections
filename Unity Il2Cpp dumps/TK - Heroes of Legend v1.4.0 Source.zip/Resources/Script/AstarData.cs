using UnityEngine;

namespace Pathfinding
{
    [Serializable]
    public class AstarData
    {
        // Fields
        public Pathfinding.NavMeshGraph navmesh; //  0x00000010
        public Pathfinding.GridGraph gridGraph; //  0x00000018
        public Pathfinding.PointGraph pointGraph; //  0x00000020
        public Pathfinding.RecastGraph recastGraph; //  0x00000028
        public System.Type[] graphTypes; //  0x00000030
        public Pathfinding.NavGraph[] graphs; //  0x00000038
        public Pathfinding.UserConnection[] userConnections; //  0x00000040
        public bool hasBeenReverted; //  0x00000048
        [UnityEngine.SerializeField] // 0x285A3B4
        private byte[] data; //  0x00000050
        public uint dataChecksum; //  0x00000058
        public byte[] data_backup; //  0x00000060
        public UnityEngine.TextAsset file_cachedStartup; //  0x00000068
        public byte[] data_cachedStartup; //  0x00000070
        [UnityEngine.SerializeField] // 0x285A3C4
        public bool cacheStartup; //  0x00000078
        
        // Properties
        public AstarPath active { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x0167F824 (23590948), len: 144  VirtAddr: 0x0167F824 RVA: 0x0167F824 token: 100681896 methodIndex: 49760 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarData()
        {
            //
            // Disasemble & Code
            // 0x0167F824: STP x20, x19, [sp, #-0x20]! | stack[1152921513142359200] = ???;  stack[1152921513142359208] = ???;  //  dest_result_addr=1152921513142359200 |  dest_result_addr=1152921513142359208
            // 0x0167F828: STP x29, x30, [sp, #0x10]  | stack[1152921513142359216] = ???;  stack[1152921513142359224] = ???;  //  dest_result_addr=1152921513142359216 |  dest_result_addr=1152921513142359224
            // 0x0167F82C: ADD x29, sp, #0x10         | X29 = (1152921513142359200 + 16) = 1152921513142359216 (0x10000001FCC194B0);
            // 0x0167F830: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167F834: LDRB w8, [x20, #0xb4]      | W8 = (bool)static_value_037380B4;       
            // 0x0167F838: MOV x19, x0                | X19 = 1152921513142371232 (0x10000001FCC1C3A0);//ML01
            // 0x0167F83C: TBNZ w8, #0, #0x167f858    | if (static_value_037380B4 == true) goto label_0;
            // 0x0167F840: ADRP x8, #0x35f0000        | X8 = 56557568 (0x35F0000);              
            // 0x0167F844: LDR x8, [x8, #0x5b8]       | X8 = 0x2B8EBE8;                         
            // 0x0167F848: LDR w0, [x8]               | W0 = 0x11BA;                            
            // 0x0167F84C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11BA, ????);     
            // 0x0167F850: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167F854: STRB w8, [x20, #0xb4]      | static_value_037380B4 = true;            //  dest_result_addr=57901236
            label_0:
            // 0x0167F858: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0167F85C: LDR x8, [x8, #0xd20]       | X8 = 1152921507421177472;               
            // 0x0167F860: LDR x20, [x8]              | X20 = typeof(Pathfinding.NavGraph[]);   
            // 0x0167F864: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x0167F868: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x0167F86C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F870: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x0167F874: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x0167F878: STR x0, [x19, #0x38]       | this.graphs = typeof(Pathfinding.NavGraph[]);  //  dest_result_addr=1152921513142371288
            this.graphs = null;
            // 0x0167F87C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x0167F880: LDR x8, [x8, #0x870]       | X8 = 1152921507462440560;               
            // 0x0167F884: LDR x20, [x8]              | X20 = typeof(Pathfinding.UserConnection[]);
            // 0x0167F888: MOV x0, x20                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x0167F88C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x0167F890: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F894: MOV x0, x20                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x0167F898: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x0167F89C: STR x0, [x19, #0x40]       | this.userConnections = typeof(Pathfinding.UserConnection[]);  //  dest_result_addr=1152921513142371296
            this.userConnections = null;
            // 0x0167F8A0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F8A4: MOV x0, x19                | X0 = 1152921513142371232 (0x10000001FCC1C3A0);//ML01
            // 0x0167F8A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F8AC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167F8B0: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F8B4 (23591092), len: 104  VirtAddr: 0x0167F8B4 RVA: 0x0167F8B4 token: 100681897 methodIndex: 49761 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarPath get_active()
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            // 0x0167F8B4: STP x20, x19, [sp, #-0x20]! | stack[1152921513142471200] = ???;  stack[1152921513142471208] = ???;  //  dest_result_addr=1152921513142471200 |  dest_result_addr=1152921513142471208
            // 0x0167F8B8: STP x29, x30, [sp, #0x10]  | stack[1152921513142471216] = ???;  stack[1152921513142471224] = ???;  //  dest_result_addr=1152921513142471216 |  dest_result_addr=1152921513142471224
            // 0x0167F8BC: ADD x29, sp, #0x10         | X29 = (1152921513142471200 + 16) = 1152921513142471216 (0x10000001FCC34A30);
            // 0x0167F8C0: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0167F8C4: LDRB w8, [x19, #0xb5]      | W8 = (bool)static_value_037380B5;       
            // 0x0167F8C8: TBNZ w8, #0, #0x167f8e4    | if (static_value_037380B5 == true) goto label_0;
            // 0x0167F8CC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x0167F8D0: LDR x8, [x8, #0xfc0]       | X8 = 0x2B8EC1C;                         
            // 0x0167F8D4: LDR w0, [x8]               | W0 = 0x11C7;                            
            // 0x0167F8D8: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C7, ????);     
            // 0x0167F8DC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167F8E0: STRB w8, [x19, #0xb5]      | static_value_037380B5 = true;            //  dest_result_addr=57901237
            label_0:
            // 0x0167F8E4: ADRP x19, #0x362c000       | X19 = 56803328 (0x362C000);             
            // 0x0167F8E8: LDR x19, [x19, #0xe80]     | X19 = 1152921504837996544;              
            // 0x0167F8EC: LDR x0, [x19]              | X0 = typeof(AstarPath);                 
            val_1 = null;
            // 0x0167F8F0: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167F8F4: TBZ w8, #0, #0x167f908     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167F8F8: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167F8FC: CBNZ w8, #0x167f908        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167F900: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167F904: LDR x0, [x19]              | X0 = typeof(AstarPath);                 
            val_1 = null;
            label_2:
            // 0x0167F908: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167F90C: LDR x0, [x8, #0x18]        | X0 = AstarPath.active;                  
            // 0x0167F910: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F914: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167F918: RET                        |  return (AstarPath)AstarPath.active;    
            return AstarPath.active;
            //  |  // // {name=val_0, type=AstarPath, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F91C (23591196), len: 8  VirtAddr: 0x0167F91C RVA: 0x0167F91C token: 100681898 methodIndex: 49762 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] GetData()
        {
            //
            // Disasemble & Code
            // 0x0167F91C: LDR x0, [x0, #0x50]        | X0 = this.data; //P2                    
            // 0x0167F920: RET                        |  return (System.Byte[])this.data;       
            return this.data;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F924 (23591204), len: 12  VirtAddr: 0x0167F924 RVA: 0x0167F924 token: 100681899 methodIndex: 49763 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetData(byte[] data, uint checksum)
        {
            //
            // Disasemble & Code
            // 0x0167F924: STR x1, [x0, #0x50]        | this.data = data;                        //  dest_result_addr=1152921513142817904
            this.data = data;
            // 0x0167F928: STR w2, [x0, #0x58]        | this.dataChecksum = checksum;            //  dest_result_addr=1152921513142817912
            this.dataChecksum = checksum;
            // 0x0167F92C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167F930 (23591216), len: 244  VirtAddr: 0x0167F930 RVA: 0x0167F930 token: 100681900 methodIndex: 49764 delegateWrapperIndex: 0 methodInvoker: 0
        public void Awake()
        {
            //
            // Disasemble & Code
            // 0x0167F930: STP x20, x19, [sp, #-0x20]! | stack[1152921513142995616] = ???;  stack[1152921513142995624] = ???;  //  dest_result_addr=1152921513142995616 |  dest_result_addr=1152921513142995624
            // 0x0167F934: STP x29, x30, [sp, #0x10]  | stack[1152921513142995632] = ???;  stack[1152921513142995640] = ???;  //  dest_result_addr=1152921513142995632 |  dest_result_addr=1152921513142995640
            // 0x0167F938: ADD x29, sp, #0x10         | X29 = (1152921513142995616 + 16) = 1152921513142995632 (0x10000001FCCB4AB0);
            // 0x0167F93C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167F940: LDRB w8, [x20, #0xb6]      | W8 = (bool)static_value_037380B6;       
            // 0x0167F944: MOV x19, x0                | X19 = 1152921513143007648 (0x10000001FCCB79A0);//ML01
            // 0x0167F948: TBNZ w8, #0, #0x167f964    | if (static_value_037380B6 == true) goto label_0;
            // 0x0167F94C: ADRP x8, #0x3648000        | X8 = 56918016 (0x3648000);              
            // 0x0167F950: LDR x8, [x8, #0xe48]       | X8 = 0x2B8EBF8;                         
            // 0x0167F954: LDR w0, [x8]               | W0 = 0x11BE;                            
            // 0x0167F958: BL #0x2782188              | X0 = sub_2782188( ?? 0x11BE, ????);     
            // 0x0167F95C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167F960: STRB w8, [x20, #0xb6]      | static_value_037380B6 = true;            //  dest_result_addr=57901238
            label_0:
            // 0x0167F964: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x0167F968: LDR x8, [x8, #0x870]       | X8 = 1152921507462440560;               
            // 0x0167F96C: LDR x20, [x8]              | X20 = typeof(Pathfinding.UserConnection[]);
            // 0x0167F970: MOV x0, x20                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x0167F974: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x0167F978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F97C: MOV x0, x20                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x0167F980: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x0167F984: STR x0, [x19, #0x40]       | this.userConnections = typeof(Pathfinding.UserConnection[]);  //  dest_result_addr=1152921513143007712
            this.userConnections = null;
            // 0x0167F988: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x0167F98C: LDR x8, [x8, #0xd20]       | X8 = 1152921507421177472;               
            // 0x0167F990: LDR x20, [x8]              | X20 = typeof(Pathfinding.NavGraph[]);   
            // 0x0167F994: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x0167F998: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x0167F99C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167F9A0: MOV x0, x20                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x0167F9A4: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x0167F9A8: LDRB w8, [x19, #0x78]      | W8 = this.cacheStartup; //P2            
            // 0x0167F9AC: STR x0, [x19, #0x38]       | this.graphs = typeof(Pathfinding.NavGraph[]);  //  dest_result_addr=1152921513143007704
            this.graphs = null;
            // 0x0167F9B0: CBZ w8, #0x167fa00         | if (this.cacheStartup == false) goto label_4;
            if(this.cacheStartup == false)
            {
                goto label_4;
            }
            // 0x0167F9B4: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0167F9B8: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x0167F9BC: LDR x20, [x19, #0x68]      | X20 = this.file_cachedStartup; //P2     
            // 0x0167F9C0: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
            // 0x0167F9C4: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167F9C8: TBZ w8, #0, #0x167f9d8     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x0167F9CC: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167F9D0: CBNZ w8, #0x167f9d8        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x0167F9D4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_3:
            // 0x0167F9D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167F9DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167F9E0: MOV x1, x20                | X1 = this.file_cachedStartup;//m1       
            // 0x0167F9E4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167F9E8: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.file_cachedStartup);
            bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.file_cachedStartup);
            // 0x0167F9EC: TBZ w0, #0, #0x167fa00     | if (val_1 == false) goto label_4;       
            if(val_1 == false)
            {
                goto label_4;
            }
            // 0x0167F9F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167F9F4: MOV x0, x19                | X0 = 1152921513143007648 (0x10000001FCCB79A0);//ML01
            // 0x0167F9F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167F9FC: B #0x167fa24               | this.LoadFromCache(); return;           
            this.LoadFromCache();
            return;
            label_4:
            // 0x0167FA00: LDR x1, [x19, #0x50]       | X1 = this.data; //P2                    
            // 0x0167FA04: CBZ x1, #0x167fa18         | if (this.data == null) goto label_5;    
            if(this.data == null)
            {
                goto label_5;
            }
            // 0x0167FA08: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167FA0C: MOV x0, x19                | X0 = 1152921513143007648 (0x10000001FCCB79A0);//ML01
            // 0x0167FA10: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167FA14: B #0x167ff58               | this.DeserializeGraphs(bytes:  this.data); return;
            this.DeserializeGraphs(bytes:  this.data);
            return;
            label_5:
            // 0x0167FA18: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167FA1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167FA20: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167FB58 (23591768), len: 740  VirtAddr: 0x0167FB58 RVA: 0x0167FB58 token: 100681901 methodIndex: 49765 delegateWrapperIndex: 0 methodInvoker: 0
        public void UpdateShortcuts()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_8;
            //  | 
            var val_12;
            //  | 
            var val_16;
            //  | 
            Pathfinding.NavMeshGraph val_17;
            //  | 
            Pathfinding.GridGraph val_18;
            //  | 
            Pathfinding.PointGraph val_19;
            //  | 
            Pathfinding.RecastGraph val_20;
            // 0x0167FB58: STP x20, x19, [sp, #-0x20]! | stack[1152921513143181344] = ???;  stack[1152921513143181352] = ???;  //  dest_result_addr=1152921513143181344 |  dest_result_addr=1152921513143181352
            // 0x0167FB5C: STP x29, x30, [sp, #0x10]  | stack[1152921513143181360] = ???;  stack[1152921513143181368] = ???;  //  dest_result_addr=1152921513143181360 |  dest_result_addr=1152921513143181368
            // 0x0167FB60: ADD x29, sp, #0x10         | X29 = (1152921513143181344 + 16) = 1152921513143181360 (0x10000001FCCE2030);
            // 0x0167FB64: SUB sp, sp, #0x20          | SP = (1152921513143181344 - 32) = 1152921513143181312 (0x10000001FCCE2000);
            // 0x0167FB68: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167FB6C: LDRB w8, [x20, #0xb7]      | W8 = (bool)static_value_037380B7;       
            // 0x0167FB70: MOV x19, x0                | X19 = 1152921513143193376 (0x10000001FCCE4F20);//ML01
            // 0x0167FB74: TBNZ w8, #0, #0x167fb90    | if (static_value_037380B7 == true) goto label_0;
            // 0x0167FB78: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x0167FB7C: LDR x8, [x8, #0x118]       | X8 = 0x2B8EC48;                         
            // 0x0167FB80: LDR w0, [x8]               | W0 = 0x11D2;                            
            // 0x0167FB84: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D2, ????);     
            // 0x0167FB88: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167FB8C: STRB w8, [x20, #0xb7]      | static_value_037380B7 = true;            //  dest_result_addr=57901239
            label_0:
            // 0x0167FB90: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x0167FB94: LDR x8, [x8, #0x340]       | X8 = 1152921504609562624;               
            // 0x0167FB98: LDR x0, [x8]               | X0 = typeof(System.Type);               
            // 0x0167FB9C: ADRP x8, #0x3674000        | X8 = 57098240 (0x3674000);              
            // 0x0167FBA0: LDR x8, [x8, #0x880]       | X8 = 1152921504845131776;               
            // 0x0167FBA4: LDR x20, [x8]              | X20 = typeof(Pathfinding.NavMeshGraph); 
            // 0x0167FBA8: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0167FBAC: TBZ w8, #0, #0x167fbbc     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167FBB0: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x0167FBB4: CBNZ w8, #0x167fbbc        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167FBB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x0167FBBC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FBC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FBC4: MOV x1, x20                | X1 = 1152921504845131776 (0x100000000E33F000);//ML01
            // 0x0167FBC8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0167FBCC: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x0167FBD0: MOV x0, x19                | X0 = 1152921513143193376 (0x10000001FCCE4F20);//ML01
            // 0x0167FBD4: BL #0x167fe3c              | X0 = this.FindGraphOfType(type:  val_1);
            Pathfinding.NavGraph val_2 = this.FindGraphOfType(type:  val_1);
            // 0x0167FBD8: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_17 = 0;
            // 0x0167FBDC: CBZ x0, #0x167fc40         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x0167FBE0: ADRP x9, #0x3610000        | X9 = 56688640 (0x3610000);              
            // 0x0167FBE4: LDR x9, [x9, #0x9b0]       | X9 = 1152921504845131776;               
            // 0x0167FBE8: LDR x8, [x0]               | X8 = typeof(Pathfinding.NavGraph);      
            // 0x0167FBEC: LDR x1, [x9]               | X1 = typeof(Pathfinding.NavMeshGraph);  
            // 0x0167FBF0: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FBF4: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.NavMeshGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FBF8: CMP w10, w9                | STATE = COMPARE(Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.NavMeshGraph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0167FBFC: B.LO #0x167fc18            | if (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.NavMeshGraph.__il2cppRuntimeField_typeHierarchyDepth) goto label_4;
            // 0x0167FC00: LDR x10, [x8, #0xb0]       | X10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy;
            // 0x0167FC04: ADD x9, x10, x9, lsl #3    | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavMeshGraph.__il2cppRu
            // 0x0167FC08: LDUR x9, [x9, #-8]         | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavMeshGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0167FC0C: CMP x9, x1                 | STATE = COMPARE((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavMeshGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.NavMeshGraph))
            // 0x0167FC10: MOV x9, x0                 | X9 = val_2;//m1                         
            val_17 = val_2;
            // 0x0167FC14: B.EQ #0x167fc40            | if ((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavMeshGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_5;
            label_4:
            // 0x0167FC18: LDR x0, [x8, #0x30]        | X0 = Pathfinding.NavGraph.__il2cppRuntimeField_element_class;
            // 0x0167FC1C: MOV x8, sp                 | X8 = 1152921513143181312 (0x10000001FCCE2000);//ML01
            // 0x0167FC20: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Pathfinding.NavGraph.__il2cppRuntimeField_element_class, ????);
            // 0x0167FC24: LDR x0, [sp]               | X0 = val_4;                              //  find_add[1152921513143169376]
            // 0x0167FC28: BL #0x27af090              | X0 = sub_27AF090( ?? val_4, ????);      
            // 0x0167FC2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FC30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_4, ????);      
            // 0x0167FC34: MOV x0, sp                 | X0 = 1152921513143181312 (0x10000001FCCE2000);//ML01
            // 0x0167FC38: BL #0x299a140              | 
            // 0x0167FC3C: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_17 = 0;
            label_5:
            // 0x0167FC40: STR x9, [x19, #0x10]       | this.navmesh = null;                     //  dest_result_addr=1152921513143193392
            this.navmesh = val_17;
            // 0x0167FC44: ADRP x8, #0x35bc000        | X8 = 56344576 (0x35BC000);              
            // 0x0167FC48: LDR x8, [x8, #0x5e8]       | X8 = 1152921504844599296;               
            // 0x0167FC4C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FC50: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FC54: LDR x1, [x8]               | X1 = typeof(Pathfinding.GridGraph);     
            // 0x0167FC58: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0167FC5C: MOV x1, x0                 | X1 = val_5;//m1                         
            // 0x0167FC60: MOV x0, x19                | X0 = 1152921513143193376 (0x10000001FCCE4F20);//ML01
            // 0x0167FC64: BL #0x167fe3c              | X0 = this.FindGraphOfType(type:  val_5);
            Pathfinding.NavGraph val_6 = this.FindGraphOfType(type:  val_5);
            // 0x0167FC68: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_18 = 0;
            // 0x0167FC6C: CBZ x0, #0x167fcd0         | if (val_6 == null) goto label_8;        
            if(val_6 == null)
            {
                goto label_8;
            }
            // 0x0167FC70: ADRP x9, #0x3668000        | X9 = 57049088 (0x3668000);              
            // 0x0167FC74: LDR x9, [x9, #0xd58]       | X9 = 1152921504844599296;               
            // 0x0167FC78: LDR x8, [x0]               | X8 = typeof(Pathfinding.NavGraph);      
            // 0x0167FC7C: LDR x1, [x9]               | X1 = typeof(Pathfinding.GridGraph);     
            // 0x0167FC80: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FC84: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.GridGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FC88: CMP w10, w9                | STATE = COMPARE(Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.GridGraph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0167FC8C: B.LO #0x167fca8            | if (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.GridGraph.__il2cppRuntimeField_typeHierarchyDepth) goto label_7;
            // 0x0167FC90: LDR x10, [x8, #0xb0]       | X10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy;
            // 0x0167FC94: ADD x9, x10, x9, lsl #3    | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.GridGraph.__il2cppRunti
            // 0x0167FC98: LDUR x9, [x9, #-8]         | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.GridGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0167FC9C: CMP x9, x1                 | STATE = COMPARE((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.GridGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.GridGraph))
            // 0x0167FCA0: MOV x9, x0                 | X9 = val_6;//m1                         
            val_18 = val_6;
            // 0x0167FCA4: B.EQ #0x167fcd0            | if ((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.GridGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_8;
            label_7:
            // 0x0167FCA8: LDR x0, [x8, #0x30]        | X0 = Pathfinding.NavGraph.__il2cppRuntimeField_element_class;
            // 0x0167FCAC: ADD x8, sp, #8             | X8 = (1152921513143181312 + 8) = 1152921513143181320 (0x10000001FCCE2008);
            // 0x0167FCB0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Pathfinding.NavGraph.__il2cppRuntimeField_element_class, ????);
            // 0x0167FCB4: LDR x0, [sp, #8]           | X0 = val_8;                              //  find_add[1152921513143169376]
            // 0x0167FCB8: BL #0x27af090              | X0 = sub_27AF090( ?? val_8, ????);      
            // 0x0167FCBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FCC0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_8, ????);      
            // 0x0167FCC4: ADD x0, sp, #8             | X0 = (1152921513143181312 + 8) = 1152921513143181320 (0x10000001FCCE2008);
            // 0x0167FCC8: BL #0x299a140              | 
            // 0x0167FCCC: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_18 = 0;
            label_8:
            // 0x0167FCD0: STR x9, [x19, #0x18]       | this.gridGraph = null;                   //  dest_result_addr=1152921513143193400
            this.gridGraph = val_18;
            // 0x0167FCD4: ADRP x8, #0x3617000        | X8 = 56717312 (0x3617000);              
            // 0x0167FCD8: LDR x8, [x8, #0xfb0]       | X8 = 1152921504845557760;               
            // 0x0167FCDC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FCE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FCE4: LDR x1, [x8]               | X1 = typeof(Pathfinding.PointGraph);    
            // 0x0167FCE8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_9 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0167FCEC: MOV x1, x0                 | X1 = val_9;//m1                         
            // 0x0167FCF0: MOV x0, x19                | X0 = 1152921513143193376 (0x10000001FCCE4F20);//ML01
            // 0x0167FCF4: BL #0x167fe3c              | X0 = this.FindGraphOfType(type:  val_9);
            Pathfinding.NavGraph val_10 = this.FindGraphOfType(type:  val_9);
            // 0x0167FCF8: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_19 = 0;
            // 0x0167FCFC: CBZ x0, #0x167fd60         | if (val_10 == null) goto label_11;      
            if(val_10 == null)
            {
                goto label_11;
            }
            // 0x0167FD00: ADRP x9, #0x35ed000        | X9 = 56545280 (0x35ED000);              
            // 0x0167FD04: LDR x9, [x9, #0xf68]       | X9 = 1152921504845557760;               
            // 0x0167FD08: LDR x8, [x0]               | X8 = typeof(Pathfinding.NavGraph);      
            // 0x0167FD0C: LDR x1, [x9]               | X1 = typeof(Pathfinding.PointGraph);    
            // 0x0167FD10: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FD14: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.PointGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FD18: CMP w10, w9                | STATE = COMPARE(Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.PointGraph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0167FD1C: B.LO #0x167fd38            | if (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.PointGraph.__il2cppRuntimeField_typeHierarchyDepth) goto label_10;
            // 0x0167FD20: LDR x10, [x8, #0xb0]       | X10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy;
            // 0x0167FD24: ADD x9, x10, x9, lsl #3    | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PointGraph.__il2cppRunt
            // 0x0167FD28: LDUR x9, [x9, #-8]         | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PointGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0167FD2C: CMP x9, x1                 | STATE = COMPARE((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PointGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.PointGraph))
            // 0x0167FD30: MOV x9, x0                 | X9 = val_10;//m1                        
            val_19 = val_10;
            // 0x0167FD34: B.EQ #0x167fd60            | if ((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.PointGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_11;
            label_10:
            // 0x0167FD38: LDR x0, [x8, #0x30]        | X0 = Pathfinding.NavGraph.__il2cppRuntimeField_element_class;
            // 0x0167FD3C: ADD x8, sp, #0x10          | X8 = (1152921513143181312 + 16) = 1152921513143181328 (0x10000001FCCE2010);
            // 0x0167FD40: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Pathfinding.NavGraph.__il2cppRuntimeField_element_class, ????);
            // 0x0167FD44: LDR x0, [sp, #0x10]        | X0 = val_12;                             //  find_add[1152921513143169376]
            // 0x0167FD48: BL #0x27af090              | X0 = sub_27AF090( ?? val_12, ????);     
            // 0x0167FD4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FD50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_12, ????);     
            // 0x0167FD54: ADD x0, sp, #0x10          | X0 = (1152921513143181312 + 16) = 1152921513143181328 (0x10000001FCCE2010);
            // 0x0167FD58: BL #0x299a140              | 
            // 0x0167FD5C: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_19 = 0;
            label_11:
            // 0x0167FD60: STR x9, [x19, #0x20]       | this.pointGraph = null;                  //  dest_result_addr=1152921513143193408
            this.pointGraph = val_19;
            // 0x0167FD64: ADRP x8, #0x3623000        | X8 = 56766464 (0x3623000);              
            // 0x0167FD68: LDR x8, [x8, #0xff0]       | X8 = 1152921504845770752;               
            // 0x0167FD6C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FD70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FD74: LDR x1, [x8]               | X1 = typeof(Pathfinding.RecastGraph);   
            // 0x0167FD78: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_13 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x0167FD7C: MOV x1, x0                 | X1 = val_13;//m1                        
            // 0x0167FD80: MOV x0, x19                | X0 = 1152921513143193376 (0x10000001FCCE4F20);//ML01
            // 0x0167FD84: BL #0x167fe3c              | X0 = this.FindGraphOfType(type:  val_13);
            Pathfinding.NavGraph val_14 = this.FindGraphOfType(type:  val_13);
            // 0x0167FD88: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_20 = 0;
            // 0x0167FD8C: CBZ x0, #0x167fdf0         | if (val_14 == null) goto label_14;      
            if(val_14 == null)
            {
                goto label_14;
            }
            // 0x0167FD90: ADRP x9, #0x364c000        | X9 = 56934400 (0x364C000);              
            // 0x0167FD94: LDR x9, [x9, #0x778]       | X9 = 1152921504845770752;               
            // 0x0167FD98: LDR x8, [x0]               | X8 = typeof(Pathfinding.NavGraph);      
            // 0x0167FD9C: LDR x1, [x9]               | X1 = typeof(Pathfinding.RecastGraph);   
            // 0x0167FDA0: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FDA4: LDRB w9, [x1, #0x104]      | W9 = Pathfinding.RecastGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x0167FDA8: CMP w10, w9                | STATE = COMPARE(Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.RecastGraph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x0167FDAC: B.LO #0x167fdc8            | if (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.RecastGraph.__il2cppRuntimeField_typeHierarchyDepth) goto label_13;
            // 0x0167FDB0: LDR x10, [x8, #0xb0]       | X10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy;
            // 0x0167FDB4: ADD x9, x10, x9, lsl #3    | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.RecastGraph.__il2cppRun
            // 0x0167FDB8: LDUR x9, [x9, #-8]         | X9 = (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.RecastGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0167FDBC: CMP x9, x1                 | STATE = COMPARE((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.RecastGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.RecastGraph))
            // 0x0167FDC0: MOV x9, x0                 | X9 = val_14;//m1                        
            val_20 = val_14;
            // 0x0167FDC4: B.EQ #0x167fdf0            | if ((Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchy + (Pathfinding.RecastGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 == null) goto label_14;
            label_13:
            // 0x0167FDC8: LDR x0, [x8, #0x30]        | X0 = Pathfinding.NavGraph.__il2cppRuntimeField_element_class;
            // 0x0167FDCC: ADD x8, sp, #0x18          | X8 = (1152921513143181312 + 24) = 1152921513143181336 (0x10000001FCCE2018);
            // 0x0167FDD0: BL #0x27d96d4              | X0 = sub_27D96D4( ?? Pathfinding.NavGraph.__il2cppRuntimeField_element_class, ????);
            // 0x0167FDD4: LDR x0, [sp, #0x18]        | X0 = val_16;                             //  find_add[1152921513143169376]
            // 0x0167FDD8: BL #0x27af090              | X0 = sub_27AF090( ?? val_16, ????);     
            // 0x0167FDDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FDE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_16, ????);     
            // 0x0167FDE4: ADD x0, sp, #0x18          | X0 = (1152921513143181312 + 24) = 1152921513143181336 (0x10000001FCCE2018);
            // 0x0167FDE8: BL #0x299a140              | 
            // 0x0167FDEC: MOV x9, xzr                | X9 = 0 (0x0);//ML01                     
            val_20 = 0;
            label_14:
            // 0x0167FDF0: STR x9, [x19, #0x28]       | this.recastGraph = null;                 //  dest_result_addr=1152921513143193416
            this.recastGraph = val_20;
            // 0x0167FDF4: SUB sp, x29, #0x10         | SP = (1152921513143181360 - 16) = 1152921513143181344 (0x10000001FCCE2020);
            // 0x0167FDF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167FDFC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167FE00: RET                        |  return;                                
            return;
            // 0x0167FE04: MOV x19, x0                | 
            // 0x0167FE08: MOV x0, sp                 | 
            // 0x0167FE0C: B #0x167fe30               | 
            // 0x0167FE10: MOV x19, x0                | 
            // 0x0167FE14: ADD x0, sp, #8             | 
            // 0x0167FE18: B #0x167fe30               | 
            // 0x0167FE1C: MOV x19, x0                | 
            // 0x0167FE20: ADD x0, sp, #0x10          | 
            // 0x0167FE24: B #0x167fe30               | 
            // 0x0167FE28: MOV x19, x0                | 
            // 0x0167FE2C: ADD x0, sp, #0x18          | 
            label_17:
            // 0x0167FE30: BL #0x299a140              | 
            // 0x0167FE34: MOV x0, x19                | 
            // 0x0167FE38: BL #0x980800               | 
        
        }
        //
        // Offset in libil2cpp.so: 0x0167FA24 (23591460), len: 292  VirtAddr: 0x0167FA24 RVA: 0x0167FA24 token: 100681902 methodIndex: 49766 delegateWrapperIndex: 0 methodInvoker: 0
        public void LoadFromCache()
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            // 0x0167FA24: STP x20, x19, [sp, #-0x20]! | stack[1152921513143371344] = ???;  stack[1152921513143371352] = ???;  //  dest_result_addr=1152921513143371344 |  dest_result_addr=1152921513143371352
            // 0x0167FA28: STP x29, x30, [sp, #0x10]  | stack[1152921513143371360] = ???;  stack[1152921513143371368] = ???;  //  dest_result_addr=1152921513143371360 |  dest_result_addr=1152921513143371368
            // 0x0167FA2C: ADD x29, sp, #0x10         | X29 = (1152921513143371344 + 16) = 1152921513143371360 (0x10000001FCD10660);
            // 0x0167FA30: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0167FA34: LDRB w8, [x20, #0xb8]      | W8 = (bool)static_value_037380B8;       
            // 0x0167FA38: MOV x19, x0                | X19 = 1152921513143383376 (0x10000001FCD13550);//ML01
            // 0x0167FA3C: TBNZ w8, #0, #0x167fa58    | if (static_value_037380B8 == true) goto label_0;
            // 0x0167FA40: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x0167FA44: LDR x8, [x8, #0xf80]       | X8 = 0x2B8EC40;                         
            // 0x0167FA48: LDR w0, [x8]               | W0 = 0x11D0;                            
            // 0x0167FA4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D0, ????);     
            // 0x0167FA50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167FA54: STRB w8, [x20, #0xb8]      | static_value_037380B8 = true;            //  dest_result_addr=57901240
            label_0:
            // 0x0167FA58: ADRP x20, #0x362c000       | X20 = 56803328 (0x362C000);             
            // 0x0167FA5C: LDR x20, [x20, #0xe80]     | X20 = 1152921504837996544;              
            // 0x0167FA60: LDR x0, [x20]              | X0 = typeof(AstarPath);                 
            val_3 = null;
            // 0x0167FA64: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167FA68: TBZ w8, #0, #0x167fa7c     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167FA6C: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167FA70: CBNZ w8, #0x167fa7c        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167FA74: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167FA78: LDR x0, [x20]              | X0 = typeof(AstarPath);                 
            val_3 = null;
            label_2:
            // 0x0167FA7C: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167FA80: LDR x20, [x8, #0x18]       | X20 = AstarPath.active;                 
            // 0x0167FA84: CBNZ x20, #0x167fa8c       | if (AstarPath.active != null) goto label_3;
            if(AstarPath.active != null)
            {
                goto label_3;
            }
            // 0x0167FA88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_3:
            // 0x0167FA8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FA90: MOV x0, x20                | X0 = AstarPath.active;//m1              
            // 0x0167FA94: BL #0xb3a084               | AstarPath.active.BlockUntilPathQueueBlocked();
            AstarPath.active.BlockUntilPathQueueBlocked();
            // 0x0167FA98: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x0167FA9C: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
            // 0x0167FAA0: LDR x20, [x19, #0x68]      | X20 = this.file_cachedStartup; //P2     
            // 0x0167FAA4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Object);        
            // 0x0167FAA8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x0167FAAC: TBZ w8, #0, #0x167fabc     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x0167FAB0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x0167FAB4: CBNZ w8, #0x167fabc        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x0167FAB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_5:
            // 0x0167FABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FAC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FAC4: MOV x1, x20                | X1 = this.file_cachedStartup;//m1       
            // 0x0167FAC8: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167FACC: BL #0x1b798c4              | X0 = UnityEngine.Object.op_Inequality(x:  0, y:  this.file_cachedStartup);
            bool val_1 = UnityEngine.Object.op_Inequality(x:  0, y:  this.file_cachedStartup);
            // 0x0167FAD0: TBZ w0, #0, #0x167fb08     | if (val_1 == false) goto label_6;       
            if(val_1 == false)
            {
                goto label_6;
            }
            // 0x0167FAD4: LDR x20, [x19, #0x68]      | X20 = this.file_cachedStartup; //P2     
            // 0x0167FAD8: CBNZ x20, #0x167fae0       | if (this.file_cachedStartup != null) goto label_7;
            if(this.file_cachedStartup != null)
            {
                goto label_7;
            }
            // 0x0167FADC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_7:
            // 0x0167FAE0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FAE4: MOV x0, x20                | X0 = this.file_cachedStartup;//m1       
            // 0x0167FAE8: BL #0x268e974              | X0 = this.file_cachedStartup.get_bytes();
            System.Byte[] val_2 = this.file_cachedStartup.bytes;
            // 0x0167FAEC: MOV x1, x0                 | X1 = val_2;//m1                         
            // 0x0167FAF0: MOV x0, x19                | X0 = 1152921513143383376 (0x10000001FCD13550);//ML01
            // 0x0167FAF4: BL #0x167ff58              | this.DeserializeGraphs(bytes:  val_2);  
            this.DeserializeGraphs(bytes:  val_2);
            // 0x0167FAF8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167FAFC: ORR w1, wzr, #0x20         | W1 = 32(0x20);                          
            // 0x0167FB00: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167FB04: B #0x16801d8               | Pathfinding.GraphModifier.TriggerEvent(type:  this); return;
            Pathfinding.GraphModifier.TriggerEvent(type:  this);
            return;
            label_6:
            // 0x0167FB08: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0167FB0C: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x0167FB10: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x0167FB14: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x0167FB18: TBZ w8, #0, #0x167fb28     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_9;
            // 0x0167FB1C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x0167FB20: CBNZ w8, #0x167fb28        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_9;
            // 0x0167FB24: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_9:
            // 0x0167FB28: ADRP x8, #0x365d000        | X8 = 57004032 (0x365D000);              
            // 0x0167FB2C: LDR x8, [x8, #0xe28]       | X8 = (string**)(1152921513143359200)("Can\'t load from cache since the cache is empty");
            // 0x0167FB30: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FB34: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FB38: LDR x1, [x8]               | X1 = "Can\'t load from cache since the cache is empty";
            // 0x0167FB3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x0167FB40: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x0167FB44: B #0x1a5d504               | UnityEngine.Debug.LogError(message:  0); return;
            UnityEngine.Debug.LogError(message:  0);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016804A4 (23594148), len: 68  VirtAddr: 0x016804A4 RVA: 0x016804A4 token: 100681903 methodIndex: 49767 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] SerializeGraphs()
        {
            //
            // Disasemble & Code
            // 0x016804A4: STP x20, x19, [sp, #-0x20]! | stack[1152921513143569360] = ???;  stack[1152921513143569368] = ???;  //  dest_result_addr=1152921513143569360 |  dest_result_addr=1152921513143569368
            // 0x016804A8: STP x29, x30, [sp, #0x10]  | stack[1152921513143569376] = ???;  stack[1152921513143569384] = ???;  //  dest_result_addr=1152921513143569376 |  dest_result_addr=1152921513143569384
            // 0x016804AC: ADD x29, sp, #0x10         | X29 = (1152921513143569360 + 16) = 1152921513143569376 (0x10000001FCD40BE0);
            // 0x016804B0: SUB sp, sp, #0x10          | SP = (1152921513143569360 - 16) = 1152921513143569344 (0x10000001FCD40BC0);
            // 0x016804B4: MOV x19, x0                | X19 = 1152921513143581392 (0x10000001FCD43AD0);//ML01
            // 0x016804B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016804BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016804C0: BL #0x28bdafc              | X0 = Pathfinding.Serialization.SerializeSettings.get_Settings();
            Pathfinding.Serialization.SerializeSettings val_1 = Pathfinding.Serialization.SerializeSettings.Settings;
            // 0x016804C4: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x016804C8: ADD x2, sp, #0xc           | X2 = (1152921513143569344 + 12) = 1152921513143569356 (0x10000001FCD40BCC);
            // 0x016804CC: MOV x0, x19                | X0 = 1152921513143581392 (0x10000001FCD43AD0);//ML01
            // 0x016804D0: STR wzr, [sp, #0xc]        | stack[1152921513143569356] = 0x0;        //  dest_result_addr=1152921513143569356
            uint val_2 = 0;
            // 0x016804D4: BL #0x168050c              | X0 = this.SerializeGraphs(settings:  val_1, checksum: out  uint val_2 = 0);
            System.Byte[] val_3 = this.SerializeGraphs(settings:  val_1, checksum: out  val_2);
            // 0x016804D8: SUB sp, x29, #0x10         | SP = (1152921513143569376 - 16) = 1152921513143569360 (0x10000001FCD40BD0);
            // 0x016804DC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x016804E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x016804E4: RET                        |  return (System.Byte[])val_3;           
            return val_3;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x016804E8 (23594216), len: 36  VirtAddr: 0x016804E8 RVA: 0x016804E8 token: 100681904 methodIndex: 49768 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] SerializeGraphs(Pathfinding.Serialization.SerializeSettings settings)
        {
            //
            // Disasemble & Code
            // 0x016804E8: STP x29, x30, [sp, #-0x10]! | stack[1152921513143763296] = ???;  stack[1152921513143763304] = ???;  //  dest_result_addr=1152921513143763296 |  dest_result_addr=1152921513143763304
            // 0x016804EC: MOV x29, sp                | X29 = 1152921513143763296 (0x10000001FCD70160);//ML01
            // 0x016804F0: SUB sp, sp, #0x10          | SP = (1152921513143763296 - 16) = 1152921513143763280 (0x10000001FCD70150);
            // 0x016804F4: SUB x2, x29, #4            | X2 = ( - 4) = 1152921513143763292 (0x10000001FCD7015C);
            // 0x016804F8: STUR wzr, [x29, #-4]       | stack[1152921513143763292] = 0x0;        //  dest_result_addr=1152921513143763292
            uint val_1 = 0;
            // 0x016804FC: BL #0x168050c              | X0 = this.SerializeGraphs(settings:  settings, checksum: out  uint val_1 = 0);
            System.Byte[] val_2 = this.SerializeGraphs(settings:  settings, checksum: out  val_1);
            // 0x01680500: MOV sp, x29                | SP = 1152921513143763296 (0x10000001FCD70160);//ML01
            // 0x01680504: LDP x29, x30, [sp], #0x10  | X29 = ; X30 = ;                          //  | 
            // 0x01680508: RET                        |  return (System.Byte[])val_2;           
            return val_2;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168050C (23594252), len: 300  VirtAddr: 0x0168050C RVA: 0x0168050C token: 100681905 methodIndex: 49769 delegateWrapperIndex: 0 methodInvoker: 0
        public byte[] SerializeGraphs(Pathfinding.Serialization.SerializeSettings settings, out uint checksum)
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x0168050C: STP x22, x21, [sp, #-0x30]! | stack[1152921513143998064] = ???;  stack[1152921513143998072] = ???;  //  dest_result_addr=1152921513143998064 |  dest_result_addr=1152921513143998072
            // 0x01680510: STP x20, x19, [sp, #0x10]  | stack[1152921513143998080] = ???;  stack[1152921513143998088] = ???;  //  dest_result_addr=1152921513143998080 |  dest_result_addr=1152921513143998088
            // 0x01680514: STP x29, x30, [sp, #0x20]  | stack[1152921513143998096] = ???;  stack[1152921513143998104] = ???;  //  dest_result_addr=1152921513143998096 |  dest_result_addr=1152921513143998104
            // 0x01680518: ADD x29, sp, #0x20         | X29 = (1152921513143998064 + 32) = 1152921513143998096 (0x10000001FCDA9690);
            // 0x0168051C: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x01680520: LDRB w8, [x22, #0xb9]      | W8 = (bool)static_value_037380B9;       
            // 0x01680524: MOV x19, x2                | X19 = 1152921513144046208 (0x10000001FCDB5280);//ML01
            // 0x01680528: MOV x21, x1                | X21 = settings;//m1                     
            // 0x0168052C: MOV x20, x0                | X20 = 1152921513144010112 (0x10000001FCDAC580);//ML01
            // 0x01680530: TBNZ w8, #0, #0x168054c    | if (static_value_037380B9 == true) goto label_0;
            // 0x01680534: ADRP x8, #0x361a000        | X8 = 56729600 (0x361A000);              
            // 0x01680538: LDR x8, [x8, #0xe70]       | X8 = 0x2B8EC44;                         
            // 0x0168053C: LDR w0, [x8]               | W0 = 0x11D1;                            
            // 0x01680540: BL #0x2782188              | X0 = sub_2782188( ?? 0x11D1, ????);     
            // 0x01680544: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01680548: STRB w8, [x22, #0xb9]      | static_value_037380B9 = true;            //  dest_result_addr=57901241
            label_0:
            // 0x0168054C: ADRP x22, #0x362c000       | X22 = 56803328 (0x362C000);             
            // 0x01680550: LDR x22, [x22, #0xe80]     | X22 = 1152921504837996544;              
            // 0x01680554: LDR x0, [x22]              | X0 = typeof(AstarPath);                 
            val_5 = null;
            // 0x01680558: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0168055C: TBZ w8, #0, #0x1680570     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01680560: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x01680564: CBNZ w8, #0x1680570        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01680568: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0168056C: LDR x0, [x22]              | X0 = typeof(AstarPath);                 
            val_5 = null;
            label_2:
            // 0x01680570: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x01680574: LDR x22, [x8, #0x18]       | X22 = AstarPath.active;                 
            // 0x01680578: CBNZ x22, #0x1680580       | if (AstarPath.active != null) goto label_3;
            if(AstarPath.active != null)
            {
                goto label_3;
            }
            // 0x0168057C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_3:
            // 0x01680580: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680584: MOV x0, x22                | X0 = AstarPath.active;//m1              
            // 0x01680588: BL #0xb3a084               | AstarPath.active.BlockUntilPathQueueBlocked();
            AstarPath.active.BlockUntilPathQueueBlocked();
            // 0x0168058C: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x01680590: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x01680594: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            Pathfinding.Serialization.AstarSerializer val_1 = null;
            // 0x01680598: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            // 0x0168059C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x016805A0: MOV x1, x20                | X1 = 1152921513144010112 (0x10000001FCDAC580);//ML01
            // 0x016805A4: MOV x2, x21                | X2 = settings;//m1                      
            // 0x016805A8: MOV x22, x0                | X22 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x016805AC: BL #0x28bdb6c              | .ctor(data:  this, settings:  settings);
            val_1 = new Pathfinding.Serialization.AstarSerializer(data:  this, settings:  settings);
            // 0x016805B0: CBZ x22, #0x16805e0        | if ( == 0) goto label_4;                
            if(null == 0)
            {
                goto label_4;
            }
            // 0x016805B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016805B8: MOV x0, x22                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x016805BC: BL #0x28bde0c              | OpenSerialize();                        
            OpenSerialize();
            // 0x016805C0: MOV x0, x20                | X0 = 1152921513144010112 (0x10000001FCDAC580);//ML01
            // 0x016805C4: MOV x1, x22                | X1 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x016805C8: BL #0x1680638              | this.SerializeGraphsPart(sr:  val_1);   
            this.SerializeGraphsPart(sr:  val_1);
            // 0x016805CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016805D0: MOV x0, x22                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x016805D4: BL #0x28be148              | X0 = CloseSerialize();                  
            System.Byte[] val_2 = CloseSerialize();
            // 0x016805D8: MOV x20, x0                | X20 = val_2;//m1                        
            val_6 = val_2;
            // 0x016805DC: B #0x1680614               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x016805E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(data:  this, settings:  settings), ????);
            // 0x016805E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016805E8: MOV x0, x22                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x016805EC: BL #0x28bde0c              | OpenSerialize();                        
            OpenSerialize();
            // 0x016805F0: MOV x0, x20                | X0 = 1152921513144010112 (0x10000001FCDAC580);//ML01
            // 0x016805F4: MOV x1, x22                | X1 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x016805F8: BL #0x1680638              | this.SerializeGraphsPart(sr:  val_1);   
            this.SerializeGraphsPart(sr:  val_1);
            // 0x016805FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x01680600: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680604: MOV x0, x22                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680608: BL #0x28be148              | X0 = CloseSerialize();                  
            System.Byte[] val_3 = CloseSerialize();
            // 0x0168060C: MOV x20, x0                | X20 = val_3;//m1                        
            val_6 = val_3;
            // 0x01680610: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_5:
            // 0x01680614: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680618: MOV x0, x22                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x0168061C: BL #0x28bde04              | X0 = GetChecksum();                     
            uint val_4 = GetChecksum();
            // 0x01680620: STR w0, [x19]              | checksum = val_4;                        //  dest_result_addr=1152921513144046208
            checksum = val_4;
            // 0x01680624: MOV x0, x20                | X0 = val_3;//m1                         
            // 0x01680628: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x0168062C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01680630: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01680634: RET                        |  return (System.Byte[])val_3;           
            return (System.Byte[])val_6;
            //  |  // // {name=val_0, type=System.Byte[], size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01680638 (23594552), len: 168  VirtAddr: 0x01680638 RVA: 0x01680638 token: 100681906 methodIndex: 49770 delegateWrapperIndex: 0 methodInvoker: 0
        public void SerializeGraphsPart(Pathfinding.Serialization.AstarSerializer sr)
        {
            //
            // Disasemble & Code
            // 0x01680638: STP x22, x21, [sp, #-0x30]! | stack[1152921513144306592] = ???;  stack[1152921513144306600] = ???;  //  dest_result_addr=1152921513144306592 |  dest_result_addr=1152921513144306600
            // 0x0168063C: STP x20, x19, [sp, #0x10]  | stack[1152921513144306608] = ???;  stack[1152921513144306616] = ???;  //  dest_result_addr=1152921513144306608 |  dest_result_addr=1152921513144306616
            // 0x01680640: STP x29, x30, [sp, #0x20]  | stack[1152921513144306624] = ???;  stack[1152921513144306632] = ???;  //  dest_result_addr=1152921513144306624 |  dest_result_addr=1152921513144306632
            // 0x01680644: ADD x29, sp, #0x20         | X29 = (1152921513144306592 + 32) = 1152921513144306624 (0x10000001FCDF4BC0);
            // 0x01680648: MOV x20, x0                | X20 = 1152921513144318640 (0x10000001FCDF7AB0);//ML01
            // 0x0168064C: LDR x21, [x20, #0x38]      | X21 = this.graphs; //P2                 
            // 0x01680650: MOV x19, x1                | X19 = sr;//m1                           
            // 0x01680654: CBZ x19, #0x1680688        | if (sr == null) goto label_0;           
            if(sr == null)
            {
                goto label_0;
            }
            // 0x01680658: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168065C: MOV x0, x19                | X0 = sr;//m1                            
            // 0x01680660: MOV x1, x21                | X1 = this.graphs;//m1                   
            // 0x01680664: BL #0x28be6a4              | sr.SerializeGraphs(_graphs:  this.graphs);
            sr.SerializeGraphs(_graphs:  this.graphs);
            // 0x01680668: LDR x1, [x20, #0x40]       | X1 = this.userConnections; //P2         
            // 0x0168066C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680670: MOV x0, x19                | X0 = sr;//m1                            
            // 0x01680674: BL #0x28be9e0              | sr.SerializeUserConnections(conns:  this.userConnections);
            sr.SerializeUserConnections(conns:  this.userConnections);
            // 0x01680678: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168067C: MOV x0, x19                | X0 = sr;//m1                            
            // 0x01680680: BL #0x28bed90              | sr.SerializeNodes();                    
            sr.SerializeNodes();
            // 0x01680684: B #0x16806c8               |  goto label_1;                          
            goto label_1;
            label_0:
            // 0x01680688: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x0168068C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680690: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680694: MOV x1, x21                | X1 = this.graphs;//m1                   
            // 0x01680698: BL #0x28be6a4              | 0.SerializeGraphs(_graphs:  this.graphs);
            0.SerializeGraphs(_graphs:  this.graphs);
            // 0x0168069C: LDR x20, [x20, #0x40]      | X20 = this.userConnections; //P2        
            // 0x016806A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x016806A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016806A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016806AC: MOV x1, x20                | X1 = this.userConnections;//m1          
            // 0x016806B0: BL #0x28be9e0              | 0.SerializeUserConnections(conns:  this.userConnections);
            0.SerializeUserConnections(conns:  this.userConnections);
            // 0x016806B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            // 0x016806B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016806BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016806C0: BL #0x28bed90              | 0.SerializeNodes();                     
            0.SerializeNodes();
            // 0x016806C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_1:
            // 0x016806C8: MOV x0, x19                | X0 = sr;//m1                            
            // 0x016806CC: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016806D0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016806D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016806D8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016806DC: B #0x28bf07c               | sr.SerializeExtraInfo(); return;        
            sr.SerializeExtraInfo();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167FB48 (23591752), len: 16  VirtAddr: 0x0167FB48 RVA: 0x0167FB48 token: 100681907 methodIndex: 49771 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeGraphs()
        {
            //
            // Disasemble & Code
            // 0x0167FB48: LDR x1, [x0, #0x50]        | X1 = this.data; //P2                    
            // 0x0167FB4C: CBZ x1, #0x167fb54         | if (this.data == null) goto label_0;    
            if(this.data == null)
            {
                goto label_0;
            }
            // 0x0167FB50: B #0x167ff58               | this.DeserializeGraphs(bytes:  this.data); return;
            this.DeserializeGraphs(bytes:  this.data);
            return;
            label_0:
            // 0x0167FB54: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016806E0 (23594720), len: 228  VirtAddr: 0x016806E0 RVA: 0x016806E0 token: 100681908 methodIndex: 49772 delegateWrapperIndex: 0 methodInvoker: 0
        private void ClearGraphs()
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_1;
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x016806E0: STP x22, x21, [sp, #-0x30]! | stack[1152921513144874656] = ???;  stack[1152921513144874664] = ???;  //  dest_result_addr=1152921513144874656 |  dest_result_addr=1152921513144874664
            // 0x016806E4: STP x20, x19, [sp, #0x10]  | stack[1152921513144874672] = ???;  stack[1152921513144874680] = ???;  //  dest_result_addr=1152921513144874672 |  dest_result_addr=1152921513144874680
            // 0x016806E8: STP x29, x30, [sp, #0x20]  | stack[1152921513144874688] = ???;  stack[1152921513144874696] = ???;  //  dest_result_addr=1152921513144874688 |  dest_result_addr=1152921513144874696
            // 0x016806EC: ADD x29, sp, #0x20         | X29 = (1152921513144874656 + 32) = 1152921513144874688 (0x10000001FCE7F6C0);
            // 0x016806F0: MOV x19, x0                | X19 = 1152921513144886704 (0x10000001FCE825B0);//ML01
            // 0x016806F4: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            val_1 = this.graphs;
            // 0x016806F8: CBZ x20, #0x16807b4        | if (this.graphs == null) goto label_0;  
            if(val_1 == null)
            {
                goto label_0;
            }
            // 0x016806FC: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_2 = 0;
            // 0x01680700: B #0x168070c               |  goto label_1;                          
            goto label_1;
            label_10:
            // 0x01680704: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            val_1 = this.graphs;
            // 0x01680708: ADD w21, w21, #1           | W21 = (val_2 + 1) = val_2 (0x00000001); 
            val_2 = 1;
            label_1:
            // 0x0168070C: CBNZ x20, #0x1680714       | if (this.graphs != null) goto label_2;  
            if(val_1 != null)
            {
                goto label_2;
            }
            // 0x01680710: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x01680714: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680718: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0168071C: B.GE #0x168079c            | if (val_2 >= this.graphs.Length) goto label_3;
            if(val_2 >= this.graphs.Length)
            {
                goto label_3;
            }
            // 0x01680720: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01680724: CBNZ x22, #0x168072c       | if (this.graphs != null) goto label_4;  
            if(this.graphs != null)
            {
                goto label_4;
            }
            // 0x01680728: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0168072C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680730: SXTW x20, w21              | X20 = 1 (0x00000001);                   
            // 0x01680734: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680738: B.LO #0x1680748            | if (val_2 < this.graphs.Length) goto label_5;
            if(val_2 < this.graphs.Length)
            {
                goto label_5;
            }
            // 0x0168073C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01680740: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x01680744: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_5:
            // 0x01680748: ADD x8, x22, x20, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x0168074C: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_1 = this.graphs[1];
            // 0x01680750: CBZ x8, #0x1680704         | if (this.graphs[0x1][0] == null) goto label_10;
            if(val_1 == null)
            {
                goto label_10;
            }
            // 0x01680754: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01680758: CBNZ x22, #0x1680760       | if (this.graphs != null) goto label_7;  
            if(this.graphs != null)
            {
                goto label_7;
            }
            // 0x0168075C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x01680760: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680764: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680768: B.LO #0x1680778            | if (val_2 < this.graphs.Length) goto label_8;
            if(val_2 < this.graphs.Length)
            {
                goto label_8;
            }
            // 0x0168076C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x01680770: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_3 = 0;
            // 0x01680774: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_8:
            // 0x01680778: ADD x8, x22, x20, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x0168077C: LDR x20, [x8, #0x20]       | X20 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_2 = this.graphs[1];
            // 0x01680780: CBNZ x20, #0x1680788       | if (this.graphs[0x1][0] != null) goto label_9;
            if(val_2 != null)
            {
                goto label_9;
            }
            // 0x01680784: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_9:
            // 0x01680788: LDR x8, [x20]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x0168078C: MOV x0, x20                | X0 = this.graphs[0x1][0];//m1           
            // 0x01680790: LDP x9, x1, [x8, #0x1c0]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1C0; X1 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1C8; //  | 
            // 0x01680794: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1C0();
            // 0x01680798: B #0x1680704               |  goto label_10;                         
            goto label_10;
            label_3:
            // 0x0168079C: STR xzr, [x19, #0x38]      | this.graphs = null;                      //  dest_result_addr=1152921513144886760
            this.graphs = 0;
            // 0x016807A0: MOV x0, x19                | X0 = 1152921513144886704 (0x10000001FCE825B0);//ML01
            // 0x016807A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016807A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016807AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016807B0: B #0x167fb58               | this.UpdateShortcuts(); return;         
            this.UpdateShortcuts();
            return;
            label_0:
            // 0x016807B4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016807B8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016807BC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016807C0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x016807C4 (23594948), len: 4  VirtAddr: 0x016807C4 RVA: 0x016807C4 token: 100681909 methodIndex: 49773 delegateWrapperIndex: 0 methodInvoker: 0
        public void OnDestroy()
        {
            //
            // Disasemble & Code
            // 0x016807C4: B #0x16806e0               | this.ClearGraphs(); return;             
            this.ClearGraphs();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x0167FF58 (23592792), len: 640  VirtAddr: 0x0167FF58 RVA: 0x0167FF58 token: 100681910 methodIndex: 49774 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeGraphs(byte[] bytes)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x0167FF58: STP x22, x21, [sp, #-0x30]! | stack[1152921513145301072] = ???;  stack[1152921513145301080] = ???;  //  dest_result_addr=1152921513145301072 |  dest_result_addr=1152921513145301080
            // 0x0167FF5C: STP x20, x19, [sp, #0x10]  | stack[1152921513145301088] = ???;  stack[1152921513145301096] = ???;  //  dest_result_addr=1152921513145301088 |  dest_result_addr=1152921513145301096
            // 0x0167FF60: STP x29, x30, [sp, #0x20]  | stack[1152921513145301104] = ???;  stack[1152921513145301112] = ???;  //  dest_result_addr=1152921513145301104 |  dest_result_addr=1152921513145301112
            // 0x0167FF64: ADD x29, sp, #0x20         | X29 = (1152921513145301072 + 32) = 1152921513145301104 (0x10000001FCEE7870);
            // 0x0167FF68: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x0167FF6C: LDRB w8, [x21, #0xba]      | W8 = (bool)static_value_037380BA;       
            // 0x0167FF70: MOV x19, x1                | X19 = bytes;//m1                        
            // 0x0167FF74: MOV x20, x0                | X20 = 1152921513145313120 (0x10000001FCEEA760);//ML01
            // 0x0167FF78: TBNZ w8, #0, #0x167ff94    | if (static_value_037380BA == true) goto label_0;
            // 0x0167FF7C: ADRP x8, #0x3663000        | X8 = 57028608 (0x3663000);              
            // 0x0167FF80: LDR x8, [x8, #0x768]       | X8 = 0x2B8EC04;                         
            // 0x0167FF84: LDR w0, [x8]               | W0 = 0x11C1;                            
            // 0x0167FF88: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C1, ????);     
            // 0x0167FF8C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0167FF90: STRB w8, [x21, #0xba]      | static_value_037380BA = true;            //  dest_result_addr=57901242
            label_0:
            // 0x0167FF94: ADRP x21, #0x362c000       | X21 = 56803328 (0x362C000);             
            // 0x0167FF98: LDR x21, [x21, #0xe80]     | X21 = 1152921504837996544;              
            // 0x0167FF9C: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            val_7 = null;
            // 0x0167FFA0: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x0167FFA4: TBZ w8, #0, #0x167ffb8     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0167FFA8: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x0167FFAC: CBNZ w8, #0x167ffb8        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0167FFB0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x0167FFB4: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            val_7 = null;
            label_2:
            // 0x0167FFB8: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x0167FFBC: LDR x21, [x8, #0x18]       | X21 = AstarPath.active;                 
            // 0x0167FFC0: CBNZ x21, #0x167ffc8       | if (AstarPath.active != null) goto label_3;
            if(AstarPath.active != null)
            {
                goto label_3;
            }
            // 0x0167FFC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_3:
            // 0x0167FFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FFCC: MOV x0, x21                | X0 = AstarPath.active;//m1              
            // 0x0167FFD0: BL #0xb3a084               | AstarPath.active.BlockUntilPathQueueBlocked();
            AstarPath.active.BlockUntilPathQueueBlocked();
            // 0x0167FFD4: CBZ x19, #0x16800ac        | if (bytes == null) goto label_4;        
            if(bytes == null)
            {
                goto label_4;
            }
            // 0x0167FFD8: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x0167FFDC: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x0167FFE0: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x0167FFE4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            // 0x0167FFE8: MOV x21, x0                | X21 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x0167FFEC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0167FFF0: MOV x0, x21                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            Pathfinding.Serialization.AstarSerializer val_1 = null;
            // 0x0167FFF4: MOV x1, x20                | X1 = 1152921513145313120 (0x10000001FCEEA760);//ML01
            // 0x0167FFF8: BL #0x28bda70              | .ctor(data:  this);                     
            val_1 = new Pathfinding.Serialization.AstarSerializer(data:  this);
            // 0x0167FFFC: CBNZ x21, #0x1680004       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x01680000: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(data:  this), ????);
            label_5:
            // 0x01680004: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680008: MOV x0, x21                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x0168000C: MOV x1, x19                | X1 = bytes;//m1                         
            // 0x01680010: BL #0x28bfa50              | X0 = OpenDeserialize(bytes:  bytes);    
            bool val_2 = OpenDeserialize(bytes:  bytes);
            // 0x01680014: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x01680018: TBZ w8, #0, #0x1680048     | if ((val_2 & 1) == false) goto label_6; 
            if(val_3 == false)
            {
                goto label_6;
            }
            // 0x0168001C: MOV x0, x20                | X0 = 1152921513145313120 (0x10000001FCEEA760);//ML01
            // 0x01680020: MOV x1, x21                | X1 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680024: BL #0x16807c8              | this.DeserializeGraphsPart(sr:  null);  
            this.DeserializeGraphsPart(sr:  null);
            // 0x01680028: CBNZ x21, #0x1680030       | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x0168002C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x01680030: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680034: MOV x0, x21                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680038: BL #0x28c03ec              | CloseDeserialize();                     
            CloseDeserialize();
            // 0x0168003C: MOV x0, x20                | X0 = 1152921513145313120 (0x10000001FCEEA760);//ML01
            // 0x01680040: BL #0x167fb58              | this.UpdateShortcuts();                 
            this.UpdateShortcuts();
            // 0x01680044: B #0x1680080               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x01680048: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0168004C: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01680050: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x01680054: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01680058: TBZ w8, #0, #0x1680068     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x0168005C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01680060: CBNZ w8, #0x1680068        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x01680064: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_10:
            // 0x01680068: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x0168006C: LDR x8, [x8, #0x200]       | X8 = (string**)(1152921513145279216)("Invalid data file (cannot read zip).\nThe data is either corrupt or it was saved using a 3.0.x or earlier version of the system");
            // 0x01680070: LDR x1, [x8]               | X1 = "Invalid data file (cannot read zip).\nThe data is either corrupt or it was saved using a 3.0.x or earlier version of the system";
            // 0x01680074: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680078: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x0168007C: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
            UnityEngine.Debug.Log(message:  0);
            label_8:
            // 0x01680080: BL #0x167f8b4              | X0 = this.get_active();                 
            AstarPath val_4 = this.active;
            // 0x01680084: MOV x21, x0                | X21 = val_4;//m1                        
            // 0x01680088: CBNZ x21, #0x1680090       | if (val_4 != null) goto label_11;       
            if(val_4 != null)
            {
                goto label_11;
            }
            // 0x0168008C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x01680090: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680094: MOV x0, x21                | X0 = val_4;//m1                         
            // 0x01680098: BL #0xb3c044               | val_4.VerifyIntegrity();                
            val_4.VerifyIntegrity();
            label_18:
            // 0x0168009C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016800A0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016800A4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016800A8: RET                        |  return;                                
            return;
            label_4:
            // 0x016800AC: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x016800B0: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x016800B4: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            // 0x016800B8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x016800BC: MOV x21, x0                | X21 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x016800C0: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x016800C4: LDR x8, [x8, #0x7b8]       | X8 = (string**)(1152921513145283648)("Bytes should not be null when passed to DeserializeGraphs");
            // 0x016800C8: LDR x1, [x8]               | X1 = "Bytes should not be null when passed to DeserializeGraphs";
            // 0x016800CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016800D0: MOV x0, x21                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            System.ArgumentNullException val_5 = null;
            // 0x016800D4: BL #0x18b3df0              | .ctor(paramName:  "Bytes should not be null when passed to DeserializeGraphs");
            val_5 = new System.ArgumentNullException(paramName:  "Bytes should not be null when passed to DeserializeGraphs");
            // 0x016800D8: ADRP x8, #0x35f5000        | X8 = 56578048 (0x35F5000);              
            // 0x016800DC: LDR x8, [x8, #0xbb0]       | X8 = 1152921513145283840;               
            // 0x016800E0: LDR x1, [x8]               | X1 = public System.Void Pathfinding.AstarData::DeserializeGraphs(byte[] bytes);
            // 0x016800E4: MOV x0, x21                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x016800E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x016800EC: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
            // 0x016800F0: MOV x21, x0                | X21 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_8 = null;
            // 0x016800F4: CMP w1, #1                 | STATE = COMPARE(public System.Void Pathfinding.AstarData::DeserializeGraphs(byte[] bytes), 0x1)
            // 0x016800F8: B.NE #0x16801cc            | if (public System.Void Pathfinding.AstarData::DeserializeGraphs(byte[] bytes) != 0x1) goto label_12;
            if((public System.Void Pathfinding.AstarData::DeserializeGraphs(byte[] bytes)) != 1)
            {
                goto label_12;
            }
            // 0x016800FC: MOV x0, x21                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01680100: BL #0x981060               | X0 = sub_981060( ?? typeof(System.ArgumentNullException), ????);
            // 0x01680104: MOV x22, x0                | X22 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01680108: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x0168010C: LDR x21, [x22]             | X21 = ;                                 
            // 0x01680110: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x01680114: LDR x1, [x21]              |  //  not_find_field!1:0
            // 0x01680118: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x0168011C: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
            // 0x01680120: TBZ w0, #0, #0x16801a4     | if ((typeof(System.Exception) & 0x1) == 0) goto label_13;
            if((null & 1) == 0)
            {
                goto label_13;
            }
            // 0x01680124: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
            // 0x01680128: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x0168012C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01680130: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01680134: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01680138: TBZ w8, #0, #0x1680148     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x0168013C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01680140: CBNZ w8, #0x1680148        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x01680144: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_15:
            // 0x01680148: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x0168014C: LDR x8, [x8, #0xb60]       | X8 = (string**)(1152921513145284864)("Caught exception while deserializing data.\n");
            // 0x01680150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680154: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01680158: MOV x2, x21                | X2 = X21;//m1                           
            // 0x0168015C: LDR x1, [x8]               | X1 = "Caught exception while deserializing data.\n";
            // 0x01680160: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "Caught exception while deserializing data.\n");
            string val_6 = System.String.Concat(arg0:  0, arg1:  "Caught exception while deserializing data.\n");
            // 0x01680164: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01680168: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x0168016C: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x01680170: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01680174: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01680178: TBZ w9, #0, #0x168018c     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x0168017C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01680180: CBNZ w9, #0x168018c        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x01680184: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x01680188: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_17:
            // 0x0168018C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680190: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680194: MOV x1, x21                | X1 = val_6;//m1                         
            // 0x01680198: BL #0x1a5dba0              | UnityEngine.Debug.LogWarning(message:  0);
            UnityEngine.Debug.LogWarning(message:  0);
            // 0x0168019C: STR x19, [x20, #0x60]      | this.data_backup = bytes;                //  dest_result_addr=1152921513145313216
            this.data_backup = bytes;
            // 0x016801A0: B #0x168009c               |  goto label_18;                         
            goto label_18;
            label_13:
            // 0x016801A4: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x016801A8: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x016801AC: LDR x8, [x22]              | X8 = ;                                  
            // 0x016801B0: STR x8, [x0]               | mem[8] = ;                               //  dest_result_addr=8
            mem[8] = null;
            // 0x016801B4: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x016801B8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016801BC: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x016801C0: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x016801C4: MOV x21, x0                | X21 = 8 (0x8);//ML01                    
            val_8 = 8;
            // 0x016801C8: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            label_12:
            // 0x016801CC: MOV x0, x21                | X0 = 8 (0x8);//ML01                     
            // 0x016801D0: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
            // 0x016801D4: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x01680A50 (23595600), len: 636  VirtAddr: 0x01680A50 RVA: 0x01680A50 token: 100681911 methodIndex: 49775 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeGraphsAdditive(byte[] bytes)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            var val_8;
            // 0x01680A50: STP x22, x21, [sp, #-0x30]! | stack[1152921513145504352] = ???;  stack[1152921513145504360] = ???;  //  dest_result_addr=1152921513145504352 |  dest_result_addr=1152921513145504360
            // 0x01680A54: STP x20, x19, [sp, #0x10]  | stack[1152921513145504368] = ???;  stack[1152921513145504376] = ???;  //  dest_result_addr=1152921513145504368 |  dest_result_addr=1152921513145504376
            // 0x01680A58: STP x29, x30, [sp, #0x20]  | stack[1152921513145504384] = ???;  stack[1152921513145504392] = ???;  //  dest_result_addr=1152921513145504384 |  dest_result_addr=1152921513145504392
            // 0x01680A5C: ADD x29, sp, #0x20         | X29 = (1152921513145504352 + 32) = 1152921513145504384 (0x10000001FCF19280);
            // 0x01680A60: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01680A64: LDRB w8, [x21, #0xbb]      | W8 = (bool)static_value_037380BB;       
            // 0x01680A68: MOV x20, x1                | X20 = bytes;//m1                        
            // 0x01680A6C: MOV x19, x0                | X19 = 1152921513145516400 (0x10000001FCF1C170);//ML01
            // 0x01680A70: TBNZ w8, #0, #0x1680a8c    | if (static_value_037380BB == true) goto label_0;
            // 0x01680A74: ADRP x8, #0x35c9000        | X8 = 56397824 (0x35C9000);              
            // 0x01680A78: LDR x8, [x8, #0xd98]       | X8 = 0x2B8EC08;                         
            // 0x01680A7C: LDR w0, [x8]               | W0 = 0x11C2;                            
            // 0x01680A80: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C2, ????);     
            // 0x01680A84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01680A88: STRB w8, [x21, #0xbb]      | static_value_037380BB = true;            //  dest_result_addr=57901243
            label_0:
            // 0x01680A8C: ADRP x21, #0x362c000       | X21 = 56803328 (0x362C000);             
            // 0x01680A90: LDR x21, [x21, #0xe80]     | X21 = 1152921504837996544;              
            // 0x01680A94: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            val_7 = null;
            // 0x01680A98: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x01680A9C: TBZ w8, #0, #0x1680ab0     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01680AA0: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x01680AA4: CBNZ w8, #0x1680ab0        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01680AA8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x01680AAC: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            val_7 = null;
            label_2:
            // 0x01680AB0: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x01680AB4: LDR x21, [x8, #0x18]       | X21 = AstarPath.active;                 
            // 0x01680AB8: CBNZ x21, #0x1680ac0       | if (AstarPath.active != null) goto label_3;
            if(AstarPath.active != null)
            {
                goto label_3;
            }
            // 0x01680ABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_3:
            // 0x01680AC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680AC4: MOV x0, x21                | X0 = AstarPath.active;//m1              
            // 0x01680AC8: BL #0xb3a084               | AstarPath.active.BlockUntilPathQueueBlocked();
            AstarPath.active.BlockUntilPathQueueBlocked();
            // 0x01680ACC: CBZ x20, #0x1680b9c        | if (bytes == null) goto label_4;        
            if(bytes == null)
            {
                goto label_4;
            }
            // 0x01680AD0: ADRP x8, #0x3615000        | X8 = 56709120 (0x3615000);              
            // 0x01680AD4: LDR x8, [x8, #0x5d0]       | X8 = 1152921504841830400;               
            // 0x01680AD8: LDR x0, [x8]               | X0 = typeof(Pathfinding.Serialization.AstarSerializer);
            // 0x01680ADC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.Serialization.AstarSerializer), ????);
            // 0x01680AE0: MOV x21, x0                | X21 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680AE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680AE8: MOV x0, x21                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            Pathfinding.Serialization.AstarSerializer val_1 = null;
            // 0x01680AEC: MOV x1, x19                | X1 = 1152921513145516400 (0x10000001FCF1C170);//ML01
            // 0x01680AF0: BL #0x28bda70              | .ctor(data:  this);                     
            val_1 = new Pathfinding.Serialization.AstarSerializer(data:  this);
            // 0x01680AF4: CBNZ x21, #0x1680afc       | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x01680AF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(data:  this), ????);
            label_5:
            // 0x01680AFC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680B00: MOV x0, x21                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680B04: MOV x1, x20                | X1 = bytes;//m1                         
            // 0x01680B08: BL #0x28bfa50              | X0 = OpenDeserialize(bytes:  bytes);    
            bool val_2 = OpenDeserialize(bytes:  bytes);
            // 0x01680B0C: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x01680B10: TBZ w8, #0, #0x1680b38     | if ((val_2 & 1) == false) goto label_6; 
            if(val_3 == false)
            {
                goto label_6;
            }
            // 0x01680B14: MOV x0, x19                | X0 = 1152921513145516400 (0x10000001FCF1C170);//ML01
            // 0x01680B18: MOV x1, x21                | X1 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680B1C: BL #0x1680ccc              | this.DeserializeGraphsPartAdditive(sr:  null);
            this.DeserializeGraphsPartAdditive(sr:  null);
            // 0x01680B20: CBNZ x21, #0x1680b28       | if ( != 0) goto label_7;                
            if(null != 0)
            {
                goto label_7;
            }
            // 0x01680B24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x01680B28: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680B2C: MOV x0, x21                | X0 = 1152921504841830400 (0x100000000E019000);//ML01
            // 0x01680B30: BL #0x28c03ec              | CloseDeserialize();                     
            CloseDeserialize();
            // 0x01680B34: B #0x1680b70               |  goto label_8;                          
            goto label_8;
            label_6:
            // 0x01680B38: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01680B3C: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01680B40: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x01680B44: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01680B48: TBZ w8, #0, #0x1680b58     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_10;
            // 0x01680B4C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01680B50: CBNZ w8, #0x1680b58        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_10;
            // 0x01680B54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_10:
            // 0x01680B58: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x01680B5C: LDR x8, [x8, #0xb70]       | X8 = (string**)(1152921513145483040)("Invalid data file (cannot read zip).");
            // 0x01680B60: LDR x1, [x8]               | X1 = "Invalid data file (cannot read zip).";
            // 0x01680B64: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680B68: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680B6C: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
            UnityEngine.Debug.Log(message:  0);
            label_8:
            // 0x01680B70: BL #0x167f8b4              | X0 = this.get_active();                 
            AstarPath val_4 = this.active;
            // 0x01680B74: MOV x19, x0                | X19 = val_4;//m1                        
            // 0x01680B78: CBNZ x19, #0x1680b80       | if (val_4 != null) goto label_11;       
            if(val_4 != null)
            {
                goto label_11;
            }
            // 0x01680B7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
            label_11:
            // 0x01680B80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680B84: MOV x0, x19                | X0 = val_4;//m1                         
            // 0x01680B88: BL #0xb3c044               | val_4.VerifyIntegrity();                
            val_4.VerifyIntegrity();
            // 0x01680B8C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01680B90: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01680B94: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01680B98: RET                        |  return;                                
            return;
            label_4:
            // 0x01680B9C: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x01680BA0: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x01680BA4: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            // 0x01680BA8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x01680BAC: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01680BB0: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x01680BB4: LDR x8, [x8, #0x7b8]       | X8 = (string**)(1152921513145283648)("Bytes should not be null when passed to DeserializeGraphs");
            // 0x01680BB8: LDR x1, [x8]               | X1 = "Bytes should not be null when passed to DeserializeGraphs";
            // 0x01680BBC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680BC0: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            System.ArgumentNullException val_5 = null;
            // 0x01680BC4: BL #0x18b3df0              | .ctor(paramName:  "Bytes should not be null when passed to DeserializeGraphs");
            val_5 = new System.ArgumentNullException(paramName:  "Bytes should not be null when passed to DeserializeGraphs");
            // 0x01680BC8: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
            // 0x01680BCC: LDR x8, [x8, #0x1e8]       | X8 = 1152921513145487280;               
            // 0x01680BD0: LDR x1, [x8]               | X1 = public System.Void Pathfinding.AstarData::DeserializeGraphsAdditive(byte[] bytes);
            // 0x01680BD4: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01680BD8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x01680BDC: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
            // 0x01680BE0: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            val_8 = null;
            // 0x01680BE4: CMP w1, #1                 | STATE = COMPARE(public System.Void Pathfinding.AstarData::DeserializeGraphsAdditive(byte[] bytes), 0x1)
            // 0x01680BE8: B.NE #0x1680cc0            | if (public System.Void Pathfinding.AstarData::DeserializeGraphsAdditive(byte[] bytes) != 0x1) goto label_12;
            if((public System.Void Pathfinding.AstarData::DeserializeGraphsAdditive(byte[] bytes)) != 1)
            {
                goto label_12;
            }
            // 0x01680BEC: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01680BF0: BL #0x981060               | X0 = sub_981060( ?? typeof(System.ArgumentNullException), ????);
            // 0x01680BF4: MOV x20, x0                | X20 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01680BF8: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x01680BFC: LDR x19, [x20]             | X19 = ;                                 
            // 0x01680C00: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x01680C04: LDR x1, [x19]              |  //  not_find_field!1:0
            // 0x01680C08: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x01680C0C: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
            // 0x01680C10: TBZ w0, #0, #0x1680c98     | if ((typeof(System.Exception) & 0x1) == 0) goto label_13;
            if((null & 1) == 0)
            {
                goto label_13;
            }
            // 0x01680C14: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
            // 0x01680C18: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01680C1C: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01680C20: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01680C24: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01680C28: TBZ w8, #0, #0x1680c38     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_15;
            // 0x01680C2C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01680C30: CBNZ w8, #0x1680c38        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_15;
            // 0x01680C34: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_15:
            // 0x01680C38: ADRP x8, #0x367f000        | X8 = 57143296 (0x367F000);              
            // 0x01680C3C: LDR x8, [x8, #0xb60]       | X8 = (string**)(1152921513145284864)("Caught exception while deserializing data.\n");
            // 0x01680C40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680C44: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01680C48: MOV x2, x19                | X2 = X19;//m1                           
            // 0x01680C4C: LDR x1, [x8]               | X1 = "Caught exception while deserializing data.\n";
            // 0x01680C50: BL #0x18b034c              | X0 = System.String.Concat(arg0:  0, arg1:  "Caught exception while deserializing data.\n");
            string val_6 = System.String.Concat(arg0:  0, arg1:  "Caught exception while deserializing data.\n");
            // 0x01680C54: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01680C58: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01680C5C: MOV x19, x0                | X19 = val_6;//m1                        
            // 0x01680C60: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01680C64: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01680C68: TBZ w9, #0, #0x1680c7c     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x01680C6C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01680C70: CBNZ w9, #0x1680c7c        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x01680C74: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x01680C78: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_17:
            // 0x01680C7C: MOV x1, x19                | X1 = val_6;//m1                         
            // 0x01680C80: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x01680C84: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x01680C88: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01680C8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680C90: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x01680C94: B #0x1a5dba0               | UnityEngine.Debug.LogWarning(message:  0); return;
            UnityEngine.Debug.LogWarning(message:  0);
            return;
            label_13:
            // 0x01680C98: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x01680C9C: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x01680CA0: LDR x8, [x20]              | X8 = ;                                  
            // 0x01680CA4: STR x8, [x0]               | mem[8] = ;                               //  dest_result_addr=8
            mem[8] = null;
            // 0x01680CA8: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x01680CAC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01680CB0: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x01680CB4: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x01680CB8: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
            val_8 = 8;
            // 0x01680CBC: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            label_12:
            // 0x01680CC0: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
            // 0x01680CC4: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
            // 0x01680CC8: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x016807C8 (23594952), len: 648  VirtAddr: 0x016807C8 RVA: 0x016807C8 token: 100681912 methodIndex: 49776 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeGraphsPart(Pathfinding.Serialization.AstarSerializer sr)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_5;
            //  | 
            uint val_6;
            //  | 
            var val_7;
            // 0x016807C8: STP x26, x25, [sp, #-0x50]! | stack[1152921513146014656] = ???;  stack[1152921513146014664] = ???;  //  dest_result_addr=1152921513146014656 |  dest_result_addr=1152921513146014664
            // 0x016807CC: STP x24, x23, [sp, #0x10]  | stack[1152921513146014672] = ???;  stack[1152921513146014680] = ???;  //  dest_result_addr=1152921513146014672 |  dest_result_addr=1152921513146014680
            // 0x016807D0: STP x22, x21, [sp, #0x20]  | stack[1152921513146014688] = ???;  stack[1152921513146014696] = ???;  //  dest_result_addr=1152921513146014688 |  dest_result_addr=1152921513146014696
            // 0x016807D4: STP x20, x19, [sp, #0x30]  | stack[1152921513146014704] = ???;  stack[1152921513146014712] = ???;  //  dest_result_addr=1152921513146014704 |  dest_result_addr=1152921513146014712
            // 0x016807D8: STP x29, x30, [sp, #0x40]  | stack[1152921513146014720] = ???;  stack[1152921513146014728] = ???;  //  dest_result_addr=1152921513146014720 |  dest_result_addr=1152921513146014728
            // 0x016807DC: ADD x29, sp, #0x40         | X29 = (1152921513146014656 + 64) = 1152921513146014720 (0x10000001FCF95C00);
            // 0x016807E0: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x016807E4: LDRB w8, [x21, #0xbc]      | W8 = (bool)static_value_037380BC;       
            // 0x016807E8: MOV x19, x1                | X19 = sr;//m1                           
            // 0x016807EC: MOV x20, x0                | X20 = 1152921513146026736 (0x10000001FCF98AF0);//ML01
            // 0x016807F0: TBNZ w8, #0, #0x168080c    | if (static_value_037380BC == true) goto label_0;
            // 0x016807F4: ADRP x8, #0x35dd000        | X8 = 56479744 (0x35DD000);              
            // 0x016807F8: LDR x8, [x8, #0x30]        | X8 = 0x2B8EC0C;                         
            // 0x016807FC: LDR w0, [x8]               | W0 = 0x11C3;                            
            // 0x01680800: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C3, ????);     
            // 0x01680804: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01680808: STRB w8, [x21, #0xbc]      | static_value_037380BC = true;            //  dest_result_addr=57901244
            label_0:
            // 0x0168080C: MOV x0, x20                | X0 = 1152921513146026736 (0x10000001FCF98AF0);//ML01
            // 0x01680810: BL #0x16806e0              | this.ClearGraphs();                     
            this.ClearGraphs();
            // 0x01680814: CBNZ x19, #0x168081c       | if (sr != null) goto label_1;           
            if(sr != null)
            {
                goto label_1;
            }
            // 0x01680818: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x0168081C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680820: MOV x0, x19                | X0 = sr;//m1                            
            // 0x01680824: BL #0x28c043c              | X0 = sr.DeserializeGraphs();            
            Pathfinding.NavGraph[] val_1 = sr.DeserializeGraphs();
            // 0x01680828: MOV x21, x0                | X21 = val_1;//m1                        
            val_5 = val_1;
            // 0x0168082C: STR x21, [x20, #0x38]      | this.graphs = val_1;                     //  dest_result_addr=1152921513146026792
            this.graphs = val_5;
            // 0x01680830: CBZ x21, #0x16808c8        | if (val_1 == null) goto label_5;        
            if(val_5 == null)
            {
                goto label_5;
            }
            // 0x01680834: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x01680838: B #0x1680844               |  goto label_3;                          
            goto label_3;
            label_12:
            // 0x0168083C: LDR x21, [x20, #0x38]      | X21 = this.graphs; //P2                 
            val_5 = this.graphs;
            // 0x01680840: ADD w22, w22, #1           | W22 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            label_3:
            // 0x01680844: CBNZ x21, #0x168084c       | if (this.graphs != null) goto label_4;  
            if(val_5 != null)
            {
                goto label_4;
            }
            // 0x01680848: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_4:
            // 0x0168084C: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680850: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680854: B.GE #0x16808c8            | if (val_6 >= this.graphs.Length) goto label_5;
            if(val_6 >= this.graphs.Length)
            {
                goto label_5;
            }
            // 0x01680858: LDR x23, [x20, #0x38]      | X23 = this.graphs; //P2                 
            // 0x0168085C: CBNZ x23, #0x1680864       | if (this.graphs != null) goto label_6;  
            if(this.graphs != null)
            {
                goto label_6;
            }
            // 0x01680860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x01680864: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680868: SXTW x21, w22              | X21 = 1 (0x00000001);                   
            // 0x0168086C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680870: B.LO #0x1680880            | if (val_6 < this.graphs.Length) goto label_7;
            if(val_6 < this.graphs.Length)
            {
                goto label_7;
            }
            // 0x01680874: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01680878: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168087C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_7:
            // 0x01680880: ADD x8, x23, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01680884: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_5 = this.graphs[1];
            // 0x01680888: CBZ x8, #0x168083c         | if (this.graphs[0x1][0] == null) goto label_12;
            if(val_5 == null)
            {
                goto label_12;
            }
            // 0x0168088C: LDR x23, [x20, #0x38]      | X23 = this.graphs; //P2                 
            // 0x01680890: CBNZ x23, #0x1680898       | if (this.graphs != null) goto label_9;  
            if(this.graphs != null)
            {
                goto label_9;
            }
            // 0x01680894: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_9:
            // 0x01680898: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168089C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016808A0: B.LO #0x16808b0            | if (val_6 < this.graphs.Length) goto label_10;
            if(val_6 < this.graphs.Length)
            {
                goto label_10;
            }
            // 0x016808A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x016808A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016808AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_10:
            // 0x016808B0: ADD x8, x23, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x016808B4: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_6 = this.graphs[1];
            // 0x016808B8: CBNZ x21, #0x16808c0       | if (this.graphs[0x1][0] != null) goto label_11;
            if(val_6 != null)
            {
                goto label_11;
            }
            // 0x016808BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_11:
            // 0x016808C0: STR w22, [x21, #0x28]      | this.graphs[0x1][0].graphIndex = 0x1;    //  dest_result_addr=0
            this.graphs[0x1][0].graphIndex = val_6;
            // 0x016808C4: B #0x168083c               |  goto label_12;                         
            goto label_12;
            label_5:
            // 0x016808C8: CBZ x19, #0x16808e0        | if (sr == null) goto label_13;          
            if(sr == null)
            {
                goto label_13;
            }
            // 0x016808CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016808D0: MOV x0, x19                | X0 = sr;//m1                            
            // 0x016808D4: BL #0x28c0e8c              | X0 = sr.DeserializeUserConnections();   
            Pathfinding.UserConnection[] val_2 = sr.DeserializeUserConnections();
            // 0x016808D8: STR x0, [x20, #0x40]       | this.userConnections = val_2;            //  dest_result_addr=1152921513146026800
            this.userConnections = val_2;
            // 0x016808DC: B #0x16808f8               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x016808E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x016808E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016808E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016808EC: BL #0x28c0e8c              | X0 = 0.DeserializeUserConnections();    
            Pathfinding.UserConnection[] val_3 = 0.DeserializeUserConnections();
            // 0x016808F0: STR x0, [x20, #0x40]       | this.userConnections = val_3;            //  dest_result_addr=1152921513146026800
            this.userConnections = val_3;
            // 0x016808F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_14:
            // 0x016808F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016808FC: MOV x0, x19                | X0 = sr;//m1                            
            // 0x01680900: BL #0x28c13d0              | sr.DeserializeExtraInfo();              
            sr.DeserializeExtraInfo();
            // 0x01680904: ADRP x8, #0x367d000        | X8 = 57135104 (0x367D000);              
            // 0x01680908: LDR x8, [x8, #0x900]       | X8 = 1152921504837570560;               
            // 0x0168090C: LDR x0, [x8]               | X0 = typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3);
            object val_4 = null;
            // 0x01680910: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3), ????);
            // 0x01680914: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680918: MOV x21, x0                | X21 = 1152921504837570560 (0x100000000DC09000);//ML01
            // 0x0168091C: BL #0x16f59f0              | .ctor();                                
            val_4 = new System.Object();
            // 0x01680920: CBNZ x21, #0x1680928       | if ( != 0) goto label_15;               
            if(null != 0)
            {
                goto label_15;
            }
            // 0x01680924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_15:
            // 0x01680928: ADRP x24, #0x3656000       | X24 = 56975360 (0x3656000);             
            // 0x0168092C: ADRP x25, #0x35ec000       | X25 = 56541184 (0x35EC000);             
            // 0x01680930: LDR x24, [x24, #0x18]      | X24 = 1152921513145882928;              
            // 0x01680934: LDR x25, [x25, #0xed0]     | X25 = 1152921504840179712;              
            // 0x01680938: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x0168093C: B #0x1680944               |  goto label_16;                         
            goto label_16;
            label_29:
            // 0x01680940: ADD w22, w22, #1           | W22 = (val_7 + 1) = val_7 (0x00000001); 
            val_7 = 1;
            label_16:
            // 0x01680944: STR w22, [x21, #0x10]      | typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3).__il2cppRuntimeField_10 = 0x1;  //  dest_result_addr=1152921504837570576
            typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3).__il2cppRuntimeField_10 = val_7;
            // 0x01680948: LDR x23, [x20, #0x38]      | X23 = this.graphs; //P2                 
            // 0x0168094C: CBNZ x23, #0x1680954       | if (this.graphs != null) goto label_17; 
            if(this.graphs != null)
            {
                goto label_17;
            }
            // 0x01680950: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_17:
            // 0x01680954: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680958: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0168095C: B.GE #0x1680a28            | if (val_7 >= this.graphs.Length) goto label_18;
            if(val_7 >= this.graphs.Length)
            {
                goto label_18;
            }
            // 0x01680960: LDR x22, [x20, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01680964: CBNZ x21, #0x168096c       | if ( != 0) goto label_19;               
            if(null != 0)
            {
                goto label_19;
            }
            // 0x01680968: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_19:
            // 0x0168096C: LDRSW x23, [x21, #0x10]    | X23 = 0x1;                              
            // 0x01680970: CBNZ x22, #0x1680978       | if (this.graphs != null) goto label_20; 
            if(this.graphs != null)
            {
                goto label_20;
            }
            // 0x01680974: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_20:
            // 0x01680978: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168097C: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680980: B.LO #0x1680990            | if (typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3).__il2cppRuntimeField_10 < this.graphs.Length) goto label_21;
            // 0x01680984: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x01680988: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168098C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_21:
            // 0x01680990: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01680994: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_7 = this.graphs[typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3).__il2cppRuntimeField_10];
            // 0x01680998: CBZ x8, #0x1680a0c         | if (this.graphs[0x1][0] == null) goto label_22;
            if(val_7 == null)
            {
                goto label_22;
            }
            // 0x0168099C: LDR x22, [x20, #0x38]      | X22 = this.graphs; //P2                 
            // 0x016809A0: CBNZ x21, #0x16809a8       | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x016809A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_23:
            // 0x016809A8: LDRSW x23, [x21, #0x10]    | X23 = 0x1;                              
            // 0x016809AC: CBNZ x22, #0x16809b4       | if (this.graphs != null) goto label_24; 
            if(this.graphs != null)
            {
                goto label_24;
            }
            // 0x016809B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_24:
            // 0x016809B4: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016809B8: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016809BC: B.LO #0x16809cc            | if (typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3).__il2cppRuntimeField_10 < this.graphs.Length) goto label_25;
            // 0x016809C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x016809C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016809C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_25:
            // 0x016809CC: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x016809D0: LDR x0, [x25]              | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            // 0x016809D4: LDR x26, [x24]             | X26 = System.Boolean AstarData.<DeserializeGraphsPart>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);
            // 0x016809D8: LDR x22, [x8, #0x20]       | X22 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_8 = this.graphs[typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3).__il2cppRuntimeField_10];
            // 0x016809DC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x016809E0: LDR x8, [x26]              | X8 = System.Boolean AstarData.<DeserializeGraphsPart>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);
            // 0x016809E4: MOV x23, x0                | X23 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x016809E8: STP x21, x26, [x23, #0x20] | typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_20 = typeof(AstarData.<DeserializeGraphsPart>c__AnonStorey3);  typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_28 = System.Boolean AstarData.<DeserializeGraphsPart>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);  //  dest_result_addr=1152921504840179744 |  dest_result_addr=1152921504840179752
            typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_20 = val_4;
            typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_28 = System.Boolean AstarData.<DeserializeGraphsPart>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);
            // 0x016809EC: STR x8, [x23, #0x10]       | typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_10 = System.Boolean AstarData.<DeserializeGraphsPart>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);  //  dest_result_addr=1152921504840179728
            typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_10 = System.Boolean AstarData.<DeserializeGraphsPart>c__AnonStorey3::<>m__0(Pathfinding.GraphNode node);
            // 0x016809F0: CBNZ x22, #0x16809f8       | if (this.graphs[0x1][0] != null) goto label_26;
            if(val_8 != null)
            {
                goto label_26;
            }
            // 0x016809F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            label_26:
            // 0x016809F8: LDR x8, [x22]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x016809FC: MOV x0, x22                | X0 = this.graphs[0x1][0];//m1           
            // 0x01680A00: MOV x1, x23                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x01680A04: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x01680A08: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            label_22:
            // 0x01680A0C: CBZ x21, #0x1680a18        | if ( == 0) goto label_27;               
            if(null == 0)
            {
                goto label_27;
            }
            // 0x01680A10: LDR w22, [x21, #0x10]      | W22 = 0x1;                              
            // 0x01680A14: B #0x1680940               |  goto label_29;                         
            goto label_29;
            label_27:
            // 0x01680A18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.graphs[0x1][0], ????);
            // 0x01680A1C: LDR w22, [x21, #0x10]      | W22 = 0x1;                              
            // 0x01680A20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.graphs[0x1][0], ????);
            // 0x01680A24: B #0x1680940               |  goto label_29;                         
            goto label_29;
            label_18:
            // 0x01680A28: CBNZ x19, #0x1680a30       | if (sr != null) goto label_30;          
            if(sr != null)
            {
                goto label_30;
            }
            // 0x01680A2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_30:
            // 0x01680A30: MOV x0, x19                | X0 = sr;//m1                            
            // 0x01680A34: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01680A38: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01680A3C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01680A40: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01680A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680A48: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01680A4C: B #0x28c1d38               | sr.PostDeserialization(); return;       
            sr.PostDeserialization();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01680CCC (23596236), len: 1588  VirtAddr: 0x01680CCC RVA: 0x01680CCC token: 100681913 methodIndex: 49777 delegateWrapperIndex: 0 methodInvoker: 0
        public void DeserializeGraphsPartAdditive(Pathfinding.Serialization.AstarSerializer sr)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_13;
            //  | 
            Pathfinding.NavGraph[] val_14;
            //  | 
            uint val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            //  | 
            var val_18;
            //  | 
            var val_19;
            // 0x01680CCC: STP x28, x27, [sp, #-0x60]! | stack[1152921513147301488] = ???;  stack[1152921513147301496] = ???;  //  dest_result_addr=1152921513147301488 |  dest_result_addr=1152921513147301496
            // 0x01680CD0: STP x26, x25, [sp, #0x10]  | stack[1152921513147301504] = ???;  stack[1152921513147301512] = ???;  //  dest_result_addr=1152921513147301504 |  dest_result_addr=1152921513147301512
            // 0x01680CD4: STP x24, x23, [sp, #0x20]  | stack[1152921513147301520] = ???;  stack[1152921513147301528] = ???;  //  dest_result_addr=1152921513147301520 |  dest_result_addr=1152921513147301528
            // 0x01680CD8: STP x22, x21, [sp, #0x30]  | stack[1152921513147301536] = ???;  stack[1152921513147301544] = ???;  //  dest_result_addr=1152921513147301536 |  dest_result_addr=1152921513147301544
            // 0x01680CDC: STP x20, x19, [sp, #0x40]  | stack[1152921513147301552] = ???;  stack[1152921513147301560] = ???;  //  dest_result_addr=1152921513147301552 |  dest_result_addr=1152921513147301560
            // 0x01680CE0: STP x29, x30, [sp, #0x50]  | stack[1152921513147301568] = ???;  stack[1152921513147301576] = ???;  //  dest_result_addr=1152921513147301568 |  dest_result_addr=1152921513147301576
            // 0x01680CE4: ADD x29, sp, #0x50         | X29 = (1152921513147301488 + 80) = 1152921513147301568 (0x10000001FD0CFEC0);
            // 0x01680CE8: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01680CEC: LDRB w8, [x21, #0xbd]      | W8 = (bool)static_value_037380BD;       
            // 0x01680CF0: MOV x20, x1                | X20 = sr;//m1                           
            // 0x01680CF4: MOV x19, x0                | X19 = 1152921513147313584 (0x10000001FD0D2DB0);//ML01
            // 0x01680CF8: TBNZ w8, #0, #0x1680d14    | if (static_value_037380BD == true) goto label_0;
            // 0x01680CFC: ADRP x8, #0x364d000        | X8 = 56938496 (0x364D000);              
            // 0x01680D00: LDR x8, [x8, #0xd80]       | X8 = 0x2B8EC10;                         
            // 0x01680D04: LDR w0, [x8]               | W0 = 0x11C4;                            
            // 0x01680D08: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C4, ????);     
            // 0x01680D0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01680D10: STRB w8, [x21, #0xbd]      | static_value_037380BD = true;            //  dest_result_addr=57901245
            label_0:
            // 0x01680D14: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            val_13 = this.graphs;
            // 0x01680D18: CBNZ x22, #0x1680d44       | if (this.graphs != null) goto label_1;  
            if(val_13 != null)
            {
                goto label_1;
            }
            // 0x01680D1C: ADRP x8, #0x3626000        | X8 = 56778752 (0x3626000);              
            // 0x01680D20: LDR x8, [x8, #0xd20]       | X8 = 1152921507421177472;               
            // 0x01680D24: LDR x21, [x8]              | X21 = typeof(Pathfinding.NavGraph[]);   
            // 0x01680D28: MOV x0, x21                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x01680D2C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x01680D30: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680D34: MOV x0, x21                | X0 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            // 0x01680D38: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.NavGraph[]), ????);
            // 0x01680D3C: MOV x22, x0                | X22 = 1152921507421177472 (0x10000000A7BF4680);//ML01
            val_13 = null;
            // 0x01680D40: STR x22, [x19, #0x38]      | this.graphs = typeof(Pathfinding.NavGraph[]);  //  dest_result_addr=1152921513147313640
            this.graphs = val_13;
            label_1:
            // 0x01680D44: LDR x8, [x19, #0x40]       | X8 = this.userConnections; //P2         
            // 0x01680D48: CBNZ x8, #0x1680d74        | if (this.userConnections != null) goto label_2;
            if(this.userConnections != null)
            {
                goto label_2;
            }
            // 0x01680D4C: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01680D50: LDR x8, [x8, #0x870]       | X8 = 1152921507462440560;               
            // 0x01680D54: LDR x21, [x8]              | X21 = typeof(Pathfinding.UserConnection[]);
            // 0x01680D58: MOV x0, x21                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x01680D5C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x01680D60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680D64: MOV x0, x21                | X0 = 1152921507462440560 (0x10000000AA34E670);//ML01
            // 0x01680D68: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(Pathfinding.UserConnection[]), ????);
            // 0x01680D6C: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            val_13 = this.graphs;
            // 0x01680D70: STR x0, [x19, #0x40]       | this.userConnections = typeof(Pathfinding.UserConnection[]);  //  dest_result_addr=1152921513147313648
            this.userConnections = null;
            label_2:
            // 0x01680D74: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x01680D78: LDR x8, [x8, #0x450]       | X8 = 1152921504616644608;               
            // 0x01680D7C: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.NavGraph> val_1 = null;
            // 0x01680D80: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x01680D84: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01680D88: LDR x8, [x8, #0x5c8]       | X8 = 1152921513146581680;               
            // 0x01680D8C: MOV x1, x22                | X1 = this.graphs;//m1                   
            // 0x01680D90: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680D94: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.NavGraph>::.ctor(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01680D98: BL #0x25e9524              | .ctor(collection:  val_13);             
            val_1 = new System.Collections.Generic.List<Pathfinding.NavGraph>(collection:  val_13);
            // 0x01680D9C: CBNZ x20, #0x1680da4       | if (sr != null) goto label_3;           
            if(sr != null)
            {
                goto label_3;
            }
            // 0x01680DA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(collection:  val_13), ????);
            label_3:
            // 0x01680DA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680DA8: MOV x0, x20                | X0 = sr;//m1                            
            // 0x01680DAC: BL #0x28c043c              | X0 = sr.DeserializeGraphs();            
            Pathfinding.NavGraph[] val_2 = sr.DeserializeGraphs();
            // 0x01680DB0: MOV x22, x0                | X22 = val_2;//m1                        
            // 0x01680DB4: CBZ x21, #0x1680dd4        | if ( == 0) goto label_4;                
            if(null == 0)
            {
                goto label_4;
            }
            // 0x01680DB8: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x01680DBC: LDR x8, [x8, #0xa08]       | X8 = 1152921513146619568;               
            // 0x01680DC0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680DC4: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x01680DC8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.NavGraph>::AddRange(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01680DCC: BL #0x25eab10              | AddRange(collection:  val_2);           
            AddRange(collection:  val_2);
            // 0x01680DD0: B #0x1680df4               |  goto label_5;                          
            goto label_5;
            label_4:
            // 0x01680DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            // 0x01680DD8: ADRP x8, #0x35ed000        | X8 = 56545280 (0x35ED000);              
            // 0x01680DDC: LDR x8, [x8, #0xa08]       | X8 = 1152921513146619568;               
            // 0x01680DE0: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680DE4: MOV x1, x22                | X1 = val_2;//m1                         
            // 0x01680DE8: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.NavGraph>::AddRange(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01680DEC: BL #0x25eab10              | AddRange(collection:  val_2);           
            AddRange(collection:  val_2);
            // 0x01680DF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_5:
            // 0x01680DF4: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x01680DF8: LDR x8, [x8, #0xdc8]       | X8 = 1152921513146620592;               
            // 0x01680DFC: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680E00: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<Pathfinding.NavGraph>::ToArray();
            // 0x01680E04: BL #0x25ed474              | X0 = ToArray();                         
            T[] val_3 = ToArray();
            // 0x01680E08: MOV x21, x0                | X21 = val_3;//m1                        
            val_14 = val_3;
            // 0x01680E0C: STR x21, [x19, #0x38]      | this.graphs = val_3;                     //  dest_result_addr=1152921513147313640
            this.graphs = val_14;
            // 0x01680E10: CBZ x21, #0x1680ea8        | if (val_3 == null) goto label_9;        
            if(val_14 == null)
            {
                goto label_9;
            }
            // 0x01680E14: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_15 = 0;
            // 0x01680E18: B #0x1680e24               |  goto label_7;                          
            goto label_7;
            label_16:
            // 0x01680E1C: LDR x21, [x19, #0x38]      | X21 = this.graphs; //P2                 
            val_14 = this.graphs;
            // 0x01680E20: ADD w22, w22, #1           | W22 = (val_15 + 1) = val_15 (0x00000001);
            val_15 = 1;
            label_7:
            // 0x01680E24: CBNZ x21, #0x1680e2c       | if (this.graphs != null) goto label_8;  
            if(val_14 != null)
            {
                goto label_8;
            }
            // 0x01680E28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_8:
            // 0x01680E2C: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680E30: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680E34: B.GE #0x1680ea8            | if (val_15 >= this.graphs.Length) goto label_9;
            if(val_15 >= this.graphs.Length)
            {
                goto label_9;
            }
            // 0x01680E38: LDR x23, [x19, #0x38]      | X23 = this.graphs; //P2                 
            // 0x01680E3C: CBNZ x23, #0x1680e44       | if (this.graphs != null) goto label_10; 
            if(this.graphs != null)
            {
                goto label_10;
            }
            // 0x01680E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x01680E44: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680E48: SXTW x21, w22              | X21 = 1 (0x00000001);                   
            // 0x01680E4C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680E50: B.LO #0x1680e60            | if (val_15 < this.graphs.Length) goto label_11;
            if(val_15 < this.graphs.Length)
            {
                goto label_11;
            }
            // 0x01680E54: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x01680E58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680E5C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_11:
            // 0x01680E60: ADD x8, x23, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01680E64: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_13 = this.graphs[1];
            // 0x01680E68: CBZ x8, #0x1680e1c         | if (this.graphs[0x1][0] == null) goto label_16;
            if(val_13 == null)
            {
                goto label_16;
            }
            // 0x01680E6C: LDR x23, [x19, #0x38]      | X23 = this.graphs; //P2                 
            // 0x01680E70: CBNZ x23, #0x1680e78       | if (this.graphs != null) goto label_13; 
            if(this.graphs != null)
            {
                goto label_13;
            }
            // 0x01680E74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_13:
            // 0x01680E78: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680E7C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680E80: B.LO #0x1680e90            | if (val_15 < this.graphs.Length) goto label_14;
            if(val_15 < this.graphs.Length)
            {
                goto label_14;
            }
            // 0x01680E84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x01680E88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680E8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_14:
            // 0x01680E90: ADD x8, x23, x21, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01680E94: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_14 = this.graphs[1];
            // 0x01680E98: CBNZ x21, #0x1680ea0       | if (this.graphs[0x1][0] != null) goto label_15;
            if(val_14 != null)
            {
                goto label_15;
            }
            // 0x01680E9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_15:
            // 0x01680EA0: STR w22, [x21, #0x28]      | this.graphs[0x1][0].graphIndex = 0x1;    //  dest_result_addr=0
            this.graphs[0x1][0].graphIndex = val_15;
            // 0x01680EA4: B #0x1680e1c               |  goto label_16;                         
            goto label_16;
            label_9:
            // 0x01680EA8: ADRP x8, #0x35b7000        | X8 = 56324096 (0x35B7000);              
            // 0x01680EAC: LDR x22, [x19, #0x40]      | X22 = this.userConnections; //P2        
            // 0x01680EB0: LDR x8, [x8, #0xc18]       | X8 = 1152921504616644608;               
            // 0x01680EB4: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.UserConnection> val_4 = null;
            // 0x01680EB8: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x01680EBC: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x01680EC0: LDR x8, [x8, #0x508]       | X8 = 1152921513146814128;               
            // 0x01680EC4: MOV x1, x22                | X1 = this.userConnections;//m1          
            // 0x01680EC8: MOV x21, x0                | X21 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680ECC: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.UserConnection>::.ctor(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01680ED0: BL #0x25e9524              | .ctor(collection:  this.userConnections);
            val_4 = new System.Collections.Generic.List<Pathfinding.UserConnection>(collection:  this.userConnections);
            // 0x01680ED4: CBNZ x20, #0x1680edc       | if (sr != null) goto label_17;          
            if(sr != null)
            {
                goto label_17;
            }
            // 0x01680ED8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(collection:  this.userConnections), ????);
            label_17:
            // 0x01680EDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680EE0: MOV x0, x20                | X0 = sr;//m1                            
            // 0x01680EE4: BL #0x28c0e8c              | X0 = sr.DeserializeUserConnections();   
            Pathfinding.UserConnection[] val_5 = sr.DeserializeUserConnections();
            // 0x01680EE8: MOV x22, x0                | X22 = val_5;//m1                        
            // 0x01680EEC: CBZ x21, #0x1680f0c        | if ( == 0) goto label_18;               
            if(null == 0)
            {
                goto label_18;
            }
            // 0x01680EF0: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01680EF4: LDR x8, [x8, #0xc10]       | X8 = 1152921513146852016;               
            // 0x01680EF8: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680EFC: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x01680F00: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.UserConnection>::AddRange(System.Collections.Generic.IEnumerable<T> collection);
            val_16 = public System.Void System.Collections.Generic.List<Pathfinding.UserConnection>::AddRange(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01680F04: BL #0x25eab10              | AddRange(collection:  val_5);           
            AddRange(collection:  val_5);
            // 0x01680F08: B #0x1680f2c               |  goto label_19;                         
            goto label_19;
            label_18:
            // 0x01680F0C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_5, ????);      
            // 0x01680F10: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x01680F14: LDR x8, [x8, #0xc10]       | X8 = 1152921513146852016;               
            // 0x01680F18: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680F1C: MOV x1, x22                | X1 = val_5;//m1                         
            // 0x01680F20: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.UserConnection>::AddRange(System.Collections.Generic.IEnumerable<T> collection);
            val_16 = public System.Void System.Collections.Generic.List<Pathfinding.UserConnection>::AddRange(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01680F24: BL #0x25eab10              | AddRange(collection:  val_5);           
            AddRange(collection:  val_5);
            // 0x01680F28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_19:
            // 0x01680F2C: ADRP x8, #0x35f9000        | X8 = 56594432 (0x35F9000);              
            // 0x01680F30: LDR x8, [x8, #0xd90]       | X8 = 1152921513146853040;               
            // 0x01680F34: MOV x0, x21                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01680F38: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<Pathfinding.UserConnection>::ToArray();
            // 0x01680F3C: BL #0x25ed474              | X0 = ToArray();                         
            T[] val_6 = ToArray();
            // 0x01680F40: STR x0, [x19, #0x40]       | this.userConnections = val_6;            //  dest_result_addr=1152921513147313648
            this.userConnections = val_6;
            // 0x01680F44: CBNZ x20, #0x1680f4c       | if (sr != null) goto label_20;          
            if(sr != null)
            {
                goto label_20;
            }
            // 0x01680F48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_20:
            // 0x01680F4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680F50: MOV x0, x20                | X0 = sr;//m1                            
            // 0x01680F54: BL #0x28c1024              | sr.DeserializeNodes();                  
            sr.DeserializeNodes();
            // 0x01680F58: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x01680F5C: LDR x8, [x8, #0xf40]       | X8 = 1152921504837623808;               
            // 0x01680F60: LDR x0, [x8]               | X0 = typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4);
            object val_7 = null;
            // 0x01680F64: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4), ????);
            // 0x01680F68: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680F6C: MOV x21, x0                | X21 = 1152921504837623808 (0x100000000DC16000);//ML01
            // 0x01680F70: BL #0x16f59f0              | .ctor();                                
            val_7 = new System.Object();
            // 0x01680F74: CBNZ x21, #0x1680f7c       | if ( != 0) goto label_21;               
            if(null != 0)
            {
                goto label_21;
            }
            // 0x01680F78: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_21:
            // 0x01680F7C: ADRP x24, #0x35fb000       | X24 = 56602624 (0x35FB000);             
            // 0x01680F80: ADRP x25, #0x35ec000       | X25 = 56541184 (0x35EC000);             
            // 0x01680F84: LDR x24, [x24, #0xda0]     | X24 = 1152921513146890928;              
            // 0x01680F88: LDR x25, [x25, #0xed0]     | X25 = 1152921504840179712;              
            // 0x01680F8C: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_17 = 0;
            // 0x01680F90: B #0x1680f98               |  goto label_22;                         
            goto label_22;
            label_35:
            // 0x01680F94: ADD w22, w22, #1           | W22 = (val_17 + 1) = val_17 (0x00000001);
            val_17 = 1;
            label_22:
            // 0x01680F98: STR w22, [x21, #0x10]      | typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4).__il2cppRuntimeField_10 = 0x1;  //  dest_result_addr=1152921504837623824
            typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4).__il2cppRuntimeField_10 = val_17;
            // 0x01680F9C: LDR x23, [x19, #0x38]      | X23 = this.graphs; //P2                 
            // 0x01680FA0: CBNZ x23, #0x1680fa8       | if (this.graphs != null) goto label_23; 
            if(this.graphs != null)
            {
                goto label_23;
            }
            // 0x01680FA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_23:
            // 0x01680FA8: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680FAC: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680FB0: B.GE #0x168107c            | if (val_17 >= this.graphs.Length) goto label_24;
            if(val_17 >= this.graphs.Length)
            {
                goto label_24;
            }
            // 0x01680FB4: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01680FB8: CBNZ x21, #0x1680fc0       | if ( != 0) goto label_25;               
            if(null != 0)
            {
                goto label_25;
            }
            // 0x01680FBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_25:
            // 0x01680FC0: LDRSW x23, [x21, #0x10]    | X23 = 0x1;                              
            // 0x01680FC4: CBNZ x22, #0x1680fcc       | if (this.graphs != null) goto label_26; 
            if(this.graphs != null)
            {
                goto label_26;
            }
            // 0x01680FC8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_26:
            // 0x01680FCC: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01680FD0: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01680FD4: B.LO #0x1680fe4            | if (typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4).__il2cppRuntimeField_10 < this.graphs.Length) goto label_27;
            // 0x01680FD8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x01680FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01680FE0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_27:
            // 0x01680FE4: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01680FE8: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_15 = this.graphs[typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4).__il2cppRuntimeField_10];
            // 0x01680FEC: CBZ x8, #0x1681060         | if (this.graphs[0x1][0] == null) goto label_28;
            if(val_15 == null)
            {
                goto label_28;
            }
            // 0x01680FF0: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01680FF4: CBNZ x21, #0x1680ffc       | if ( != 0) goto label_29;               
            if(null != 0)
            {
                goto label_29;
            }
            // 0x01680FF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_29:
            // 0x01680FFC: LDRSW x23, [x21, #0x10]    | X23 = 0x1;                              
            // 0x01681000: CBNZ x22, #0x1681008       | if (this.graphs != null) goto label_30; 
            if(this.graphs != null)
            {
                goto label_30;
            }
            // 0x01681004: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_30:
            // 0x01681008: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168100C: CMP w23, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01681010: B.LO #0x1681020            | if (typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4).__il2cppRuntimeField_10 < this.graphs.Length) goto label_31;
            // 0x01681014: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x01681018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168101C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_31:
            // 0x01681020: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01681024: LDR x0, [x25]              | X0 = typeof(Pathfinding.GraphNodeDelegateCancelable);
            // 0x01681028: LDR x26, [x24]             | X26 = System.Boolean AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);
            // 0x0168102C: LDR x22, [x8, #0x20]       | X22 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_16 = this.graphs[typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4).__il2cppRuntimeField_10];
            // 0x01681030: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            // 0x01681034: LDR x8, [x26]              | X8 = System.Boolean AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);
            // 0x01681038: MOV x23, x0                | X23 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x0168103C: STP x21, x26, [x23, #0x20] | typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_20 = typeof(AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4);  typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_28 = System.Boolean AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);  //  dest_result_addr=1152921504840179744 |  dest_result_addr=1152921504840179752
            typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_20 = val_7;
            typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_28 = System.Boolean AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);
            // 0x01681040: STR x8, [x23, #0x10]       | typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_10 = System.Boolean AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);  //  dest_result_addr=1152921504840179728
            typeof(Pathfinding.GraphNodeDelegateCancelable).__il2cppRuntimeField_10 = System.Boolean AstarData.<DeserializeGraphsPartAdditive>c__AnonStorey4::<>m__0(Pathfinding.GraphNode node);
            // 0x01681044: CBNZ x22, #0x168104c       | if (this.graphs[0x1][0] != null) goto label_32;
            if(val_16 != null)
            {
                goto label_32;
            }
            // 0x01681048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(Pathfinding.GraphNodeDelegateCancelable), ????);
            label_32:
            // 0x0168104C: LDR x8, [x22]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x01681050: MOV x0, x22                | X0 = this.graphs[0x1][0];//m1           
            // 0x01681054: MOV x1, x23                | X1 = 1152921504840179712 (0x100000000DE86000);//ML01
            // 0x01681058: LDP x9, x2, [x8, #0x160]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160; X2 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_168; //  | 
            // 0x0168105C: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_160();
            label_28:
            // 0x01681060: CBZ x21, #0x168106c        | if ( == 0) goto label_33;               
            if(null == 0)
            {
                goto label_33;
            }
            // 0x01681064: LDR w22, [x21, #0x10]      | W22 = 0x1;                              
            // 0x01681068: B #0x1680f94               |  goto label_35;                         
            goto label_35;
            label_33:
            // 0x0168106C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.graphs[0x1][0], ????);
            // 0x01681070: LDR w22, [x21, #0x10]      | W22 = 0x1;                              
            // 0x01681074: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.graphs[0x1][0], ????);
            // 0x01681078: B #0x1680f94               |  goto label_35;                         
            goto label_35;
            label_24:
            // 0x0168107C: CBZ x20, #0x1681090        | if (sr == null) goto label_36;          
            if(sr == null)
            {
                goto label_36;
            }
            // 0x01681080: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681084: MOV x0, x20                | X0 = sr;//m1                            
            // 0x01681088: BL #0x28c13d0              | sr.DeserializeExtraInfo();              
            sr.DeserializeExtraInfo();
            // 0x0168108C: B #0x16810a4               |  goto label_37;                         
            goto label_37;
            label_36:
            // 0x01681090: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x01681094: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681098: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168109C: BL #0x28c13d0              | 0.DeserializeExtraInfo();               
            0.DeserializeExtraInfo();
            // 0x016810A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_37:
            // 0x016810A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016810A8: MOV x0, x20                | X0 = sr;//m1                            
            // 0x016810AC: BL #0x28c1d38              | sr.PostDeserialization();               
            sr.PostDeserialization();
            // 0x016810B0: ADRP x24, #0x35d0000       | X24 = 56426496 (0x35D0000);             
            // 0x016810B4: LDR x24, [x24, #0x9b8]     | X24 = 1152921504850989056;              
            // 0x016810B8: MOV w28, wzr               | W28 = 0 (0x0);//ML01                    
            val_18 = 0;
            // 0x016810BC: B #0x16810c4               |  goto label_38;                         
            goto label_38;
            label_66:
            // 0x016810C0: MOV w28, w27               | W28 = W27;//m1                          
            val_18 = W27;
            label_38:
            // 0x016810C4: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x016810C8: CBNZ x20, #0x16810d0       | if (this.graphs != null) goto label_39; 
            if(this.graphs != null)
            {
                goto label_39;
            }
            // 0x016810CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? sr, ????);         
            label_39:
            // 0x016810D0: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016810D4: CMP w28, w8                | STATE = COMPARE(W27, this.graphs.Length)
            // 0x016810D8: B.GE #0x16812e4            | if (val_18 >= this.graphs.Length) goto label_40;
            if(val_18 >= this.graphs.Length)
            {
                goto label_40;
            }
            // 0x016810DC: ADD w27, w28, #1           | W27 = (W27 + 1);                        
            var val_8 = val_18 + 1;
            // 0x016810E0: SXTW x25, w28              | X25 = (long)(int)(W27);                 
            // 0x016810E4: MOV w26, w27               | W26 = (W27 + 1);//m1                    
            val_19 = val_8;
            // 0x016810E8: B #0x16810f0               |  goto label_41;                         
            goto label_41;
            label_58:
            // 0x016810EC: ADD w26, w26, #1           | W26 = ((W27 + 1) + 1);                  
            val_19 = val_19 + 1;
            label_41:
            // 0x016810F0: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x016810F4: CBNZ x20, #0x16810fc       | if (this.graphs != null) goto label_42; 
            if(this.graphs != null)
            {
                goto label_42;
            }
            // 0x016810F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? sr, ????);         
            label_42:
            // 0x016810FC: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681100: CMP w26, w8                | STATE = COMPARE(((W27 + 1) + 1), this.graphs.Length)
            // 0x01681104: B.GE #0x16810c0            | if (val_19 >= this.graphs.Length) goto label_66;
            if(val_19 >= this.graphs.Length)
            {
                goto label_66;
            }
            // 0x01681108: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x0168110C: CBNZ x20, #0x1681114       | if (this.graphs != null) goto label_44; 
            if(this.graphs != null)
            {
                goto label_44;
            }
            // 0x01681110: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? sr, ????);         
            label_44:
            // 0x01681114: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681118: CMP w28, w8                | STATE = COMPARE(W27, this.graphs.Length)
            // 0x0168111C: B.LO #0x168112c            | if (val_18 < this.graphs.Length) goto label_45;
            if(val_18 < this.graphs.Length)
            {
                goto label_45;
            }
            // 0x01681120: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? sr, ????);         
            // 0x01681124: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681128: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? sr, ????);         
            label_45:
            // 0x0168112C: ADD x8, x20, x25, lsl #3   | X8 = this.graphs[(long)(int)(W27)]; //PARR1 
            // 0x01681130: LDR x8, [x8, #0x20]        | X8 = this.graphs[(long)(int)(W27)][0]   
            Pathfinding.NavGraph val_17 = this.graphs[(long)val_18];
            // 0x01681134: CBZ x8, #0x16810ec         | if (this.graphs[(long)(int)(W27)][0] == null) goto label_58;
            if(val_17 == null)
            {
                goto label_58;
            }
            // 0x01681138: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x0168113C: CBNZ x20, #0x1681144       | if (this.graphs != null) goto label_47; 
            if(this.graphs != null)
            {
                goto label_47;
            }
            // 0x01681140: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? sr, ????);         
            label_47:
            // 0x01681144: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681148: SXTW x22, w26              | X22 = (long)(int)(((W27 + 1) + 1));     
            // 0x0168114C: CMP w26, w8                | STATE = COMPARE(((W27 + 1) + 1), this.graphs.Length)
            // 0x01681150: B.LO #0x1681160            | if (val_19 < this.graphs.Length) goto label_48;
            if(val_19 < this.graphs.Length)
            {
                goto label_48;
            }
            // 0x01681154: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? sr, ????);         
            // 0x01681158: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168115C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? sr, ????);         
            label_48:
            // 0x01681160: ADD x8, x20, x22, lsl #3   | X8 = this.graphs[(long)(int)(((W27 + 1) + 1))]; //PARR1 
            // 0x01681164: LDR x8, [x8, #0x20]        | X8 = this.graphs[(long)(int)(((W27 + 1) + 1))][0]
            Pathfinding.NavGraph val_18 = this.graphs[(long)val_19];
            // 0x01681168: CBZ x8, #0x16810ec         | if (this.graphs[(long)(int)(((W27 + 1) + 1))][0] == null) goto label_58;
            if(val_18 == null)
            {
                goto label_58;
            }
            // 0x0168116C: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x01681170: CBNZ x20, #0x1681178       | if (this.graphs != null) goto label_50; 
            if(this.graphs != null)
            {
                goto label_50;
            }
            // 0x01681174: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? sr, ????);         
            label_50:
            // 0x01681178: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168117C: CMP w28, w8                | STATE = COMPARE(W27, this.graphs.Length)
            // 0x01681180: B.LO #0x1681190            | if (val_18 < this.graphs.Length) goto label_51;
            if(val_18 < this.graphs.Length)
            {
                goto label_51;
            }
            // 0x01681184: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? sr, ????);         
            // 0x01681188: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168118C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? sr, ????);         
            label_51:
            // 0x01681190: ADD x8, x20, x25, lsl #3   | X8 = this.graphs[(long)(int)(W27)]; //PARR1 
            // 0x01681194: LDR x20, [x8, #0x20]       | X20 = this.graphs[(long)(int)(W27)][0]  
            Pathfinding.NavGraph val_19 = this.graphs[(long)val_18];
            // 0x01681198: CBNZ x20, #0x16811a0       | if (this.graphs[(long)(int)(W27)][0] != null) goto label_52;
            if(val_19 != null)
            {
                goto label_52;
            }
            // 0x0168119C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? sr, ????);         
            label_52:
            // 0x016811A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016811A4: MOV x0, x20                | X0 = this.graphs[(long)(int)(W27)][0];//m1
            // 0x016811A8: BL #0x155d0d0              | X0 = this.graphs[(long)(int)(W27)][0].get_guid();
            Pathfinding.Util.Guid val_9 = val_19.guid;
            // 0x016811AC: LDR x23, [x19, #0x38]      | X23 = this.graphs; //P2                 
            // 0x016811B0: MOV x20, x0                | X20 = val_9._a;//m1                     
            // 0x016811B4: MOV x21, x1                | X21 = val_9._b;//m1                     
            // 0x016811B8: CBNZ x23, #0x16811c0       | if (this.graphs != null) goto label_53; 
            if(this.graphs != null)
            {
                goto label_53;
            }
            // 0x016811BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9._a, ????);   
            label_53:
            // 0x016811C0: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016811C4: CMP w26, w8                | STATE = COMPARE(((W27 + 1) + 1), this.graphs.Length)
            // 0x016811C8: B.LO #0x16811d8            | if (val_19 < this.graphs.Length) goto label_54;
            if(val_19 < this.graphs.Length)
            {
                goto label_54;
            }
            // 0x016811CC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_9._a, ????);   
            // 0x016811D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016811D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_9._a, ????);   
            label_54:
            // 0x016811D8: ADD x8, x23, x22, lsl #3   | X8 = this.graphs[(long)(int)(((W27 + 1) + 1))]; //PARR1 
            // 0x016811DC: LDR x22, [x8, #0x20]       | X22 = this.graphs[(long)(int)(((W27 + 1) + 1))][0]
            Pathfinding.NavGraph val_20 = this.graphs[(long)val_19];
            // 0x016811E0: CBNZ x22, #0x16811e8       | if (this.graphs[(long)(int)(((W27 + 1) + 1))][0] != null) goto label_55;
            if(val_20 != null)
            {
                goto label_55;
            }
            // 0x016811E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_9._a, ????);   
            label_55:
            // 0x016811E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016811EC: MOV x0, x22                | X0 = this.graphs[(long)(int)(((W27 + 1) + 1))][0];//m1
            // 0x016811F0: BL #0x155d0d0              | X0 = this.graphs[(long)(int)(((W27 + 1) + 1))][0].get_guid();
            Pathfinding.Util.Guid val_10 = val_20.guid;
            // 0x016811F4: MOV x22, x0                | X22 = val_10._a;//m1                    
            // 0x016811F8: LDR x0, [x24]              | X0 = typeof(Pathfinding.Util.Guid);     
            // 0x016811FC: MOV x23, x1                | X23 = val_10._b;//m1                    
            // 0x01681200: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_10A;
            // 0x01681204: TBZ w8, #0, #0x1681214     | if (Pathfinding.Util.Guid.__il2cppRuntimeField_has_cctor == 0) goto label_57;
            // 0x01681208: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished;
            // 0x0168120C: CBNZ w8, #0x1681214        | if (Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished != 0) goto label_57;
            // 0x01681210: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Guid), ????);
            label_57:
            // 0x01681214: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681218: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x0168121C: MOV x1, x20                | X1 = val_9._a;//m1                      
            // 0x01681220: MOV x2, x21                | X2 = val_9._b;//m1                      
            // 0x01681224: MOV x3, x22                | X3 = val_10._a;//m1                     
            // 0x01681228: MOV x4, x23                | X4 = val_10._b;//m1                     
            // 0x0168122C: BL #0x28ce7d0              | X0 = Pathfinding.Util.Guid.op_Equality(lhs:  new Pathfinding.Util.Guid() {_b = val_9._a}, rhs:  new Pathfinding.Util.Guid() {_a = val_9._b, _b = val_10._a});
            bool val_11 = Pathfinding.Util.Guid.op_Equality(lhs:  new Pathfinding.Util.Guid() {_b = val_9._a}, rhs:  new Pathfinding.Util.Guid() {_a = val_9._b, _b = val_10._a});
            // 0x01681230: TBZ w0, #0, #0x16810ec     | if (val_11 == false) goto label_58;     
            if(val_11 == false)
            {
                goto label_58;
            }
            // 0x01681234: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01681238: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x0168123C: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x01681240: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01681244: TBZ w8, #0, #0x1681254     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_60;
            // 0x01681248: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x0168124C: CBNZ w8, #0x1681254        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_60;
            // 0x01681250: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_60:
            // 0x01681254: ADRP x8, #0x35c4000        | X8 = 56377344 (0x35C4000);              
            // 0x01681258: LDR x8, [x8, #0x228]       | X8 = (string**)(1152921513147248304)("Guid Conflict when importing graphs additively. Imported graph will get a new Guid.\nThis message is (relatively) harmless.");
            // 0x0168125C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681260: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01681264: LDR x1, [x8]               | X1 = "Guid Conflict when importing graphs additively. Imported graph will get a new Guid.\nThis message is (relatively) harmless.";
            // 0x01681268: BL #0x1a5dba0              | UnityEngine.Debug.LogWarning(message:  0);
            UnityEngine.Debug.LogWarning(message:  0);
            // 0x0168126C: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x01681270: CBNZ x20, #0x1681278       | if (this.graphs != null) goto label_61; 
            if(this.graphs != null)
            {
                goto label_61;
            }
            // 0x01681274: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_61:
            // 0x01681278: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168127C: CMP w28, w8                | STATE = COMPARE(W27, this.graphs.Length)
            // 0x01681280: B.LO #0x1681290            | if (val_18 < this.graphs.Length) goto label_62;
            if(val_18 < this.graphs.Length)
            {
                goto label_62;
            }
            // 0x01681284: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x01681288: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168128C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_62:
            // 0x01681290: LDR x0, [x24]              | X0 = typeof(Pathfinding.Util.Guid);     
            // 0x01681294: ADD x8, x20, x25, lsl #3   | X8 = this.graphs[(long)(int)(W27)]; //PARR1 
            // 0x01681298: LDR x20, [x8, #0x20]       | X20 = this.graphs[(long)(int)(W27)][0]  
            Pathfinding.NavGraph val_21 = this.graphs[(long)val_18];
            // 0x0168129C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_10A;
            // 0x016812A0: TBZ w8, #0, #0x16812b0     | if (Pathfinding.Util.Guid.__il2cppRuntimeField_has_cctor == 0) goto label_64;
            // 0x016812A4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished;
            // 0x016812A8: CBNZ w8, #0x16812b0        | if (Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished != 0) goto label_64;
            // 0x016812AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Guid), ????);
            label_64:
            // 0x016812B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016812B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016812B8: BL #0x28ce1f0              | X0 = Pathfinding.Util.Guid.NewGuid();   
            Pathfinding.Util.Guid val_12 = Pathfinding.Util.Guid.NewGuid();
            // 0x016812BC: MOV x21, x0                | X21 = val_12._a;//m1                    
            // 0x016812C0: MOV x22, x1                | X22 = val_12._b;//m1                    
            // 0x016812C4: CBNZ x20, #0x16812cc       | if (this.graphs[(long)(int)(W27)][0] != null) goto label_65;
            if(val_21 != null)
            {
                goto label_65;
            }
            // 0x016812C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_12._a, ????);  
            label_65:
            // 0x016812CC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x016812D0: MOV x0, x20                | X0 = this.graphs[(long)(int)(W27)][0];//m1
            // 0x016812D4: MOV x1, x21                | X1 = val_12._a;//m1                     
            // 0x016812D8: MOV x2, x22                | X2 = val_12._b;//m1                     
            // 0x016812DC: BL #0x155d188              | this.graphs[(long)(int)(W27)][0].set_guid(value:  new Pathfinding.Util.Guid() {_a = val_12._a, _b = val_12._b});
            val_21.guid = new Pathfinding.Util.Guid() {_a = val_12._a, _b = val_12._b};
            // 0x016812E0: B #0x16810c0               |  goto label_66;                         
            goto label_66;
            label_40:
            // 0x016812E4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x016812E8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x016812EC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x016812F0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x016812F4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x016812F8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x016812FC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01681320 (23597856), len: 520  VirtAddr: 0x01681320 RVA: 0x01681320 token: 100681914 methodIndex: 49778 delegateWrapperIndex: 0 methodInvoker: 0
        public void FindGraphTypes()
        {
            //
            // Disasemble & Code
            //  | 
            var val_8;
            //  | 
            object val_9;
            // 0x01681320: STP x28, x27, [sp, #-0x60]! | stack[1152921513148289008] = ???;  stack[1152921513148289016] = ???;  //  dest_result_addr=1152921513148289008 |  dest_result_addr=1152921513148289016
            // 0x01681324: STP x26, x25, [sp, #0x10]  | stack[1152921513148289024] = ???;  stack[1152921513148289032] = ???;  //  dest_result_addr=1152921513148289024 |  dest_result_addr=1152921513148289032
            // 0x01681328: STP x24, x23, [sp, #0x20]  | stack[1152921513148289040] = ???;  stack[1152921513148289048] = ???;  //  dest_result_addr=1152921513148289040 |  dest_result_addr=1152921513148289048
            // 0x0168132C: STP x22, x21, [sp, #0x30]  | stack[1152921513148289056] = ???;  stack[1152921513148289064] = ???;  //  dest_result_addr=1152921513148289056 |  dest_result_addr=1152921513148289064
            // 0x01681330: STP x20, x19, [sp, #0x40]  | stack[1152921513148289072] = ???;  stack[1152921513148289080] = ???;  //  dest_result_addr=1152921513148289072 |  dest_result_addr=1152921513148289080
            // 0x01681334: STP x29, x30, [sp, #0x50]  | stack[1152921513148289088] = ???;  stack[1152921513148289096] = ???;  //  dest_result_addr=1152921513148289088 |  dest_result_addr=1152921513148289096
            // 0x01681338: ADD x29, sp, #0x50         | X29 = (1152921513148289008 + 80) = 1152921513148289088 (0x10000001FD1C1040);
            // 0x0168133C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01681340: LDRB w8, [x20, #0xbe]      | W8 = (bool)static_value_037380BE;       
            // 0x01681344: MOV x19, x0                | X19 = 1152921513148301104 (0x10000001FD1C3F30);//ML01
            // 0x01681348: TBNZ w8, #0, #0x1681364    | if (static_value_037380BE == true) goto label_0;
            // 0x0168134C: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x01681350: LDR x8, [x8, #0xfb0]       | X8 = 0x2B8EC18;                         
            // 0x01681354: LDR w0, [x8]               | W0 = 0x11C6;                            
            // 0x01681358: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C6, ????);     
            // 0x0168135C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01681360: STRB w8, [x20, #0xbe]      | static_value_037380BE = true;            //  dest_result_addr=57901246
            label_0:
            // 0x01681364: ADRP x25, #0x3620000       | X25 = 56754176 (0x3620000);             
            // 0x01681368: LDR x25, [x25, #0x340]     | X25 = 1152921504609562624;              
            // 0x0168136C: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x01681370: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x01681374: LDR x8, [x8, #0x690]       | X8 = 1152921504837996544;               
            // 0x01681378: LDR x20, [x8]              | X20 = typeof(AstarPath);                
            // 0x0168137C: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x01681380: TBZ w8, #0, #0x1681390     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01681384: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01681388: CBNZ w8, #0x1681390        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168138C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_2:
            // 0x01681390: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681394: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01681398: MOV x1, x20                | X1 = 1152921504837996544 (0x100000000DC71000);//ML01
            // 0x0168139C: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_1 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x016813A0: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x016813A4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016813A8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016813AC: BL #0x170a838              | X0 = System.Reflection.Assembly.GetAssembly(type:  0);
            System.Reflection.Assembly val_2 = System.Reflection.Assembly.GetAssembly(type:  0);
            // 0x016813B0: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x016813B4: CBNZ x20, #0x16813bc       | if (val_2 != null) goto label_3;        
            if(val_2 != null)
            {
                goto label_3;
            }
            // 0x016813B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_3:
            // 0x016813BC: LDR x8, [x20]              | X8 = typeof(System.Reflection.Assembly);
            // 0x016813C0: MOV x0, x20                | X0 = val_2;//m1                         
            // 0x016813C4: LDP x9, x1, [x8, #0x1e0]   | X9 = typeof(System.Reflection.Assembly).__il2cppRuntimeField_1E0; X1 = typeof(System.Reflection.Assembly).__il2cppRuntimeField_1E8; //  | 
            // 0x016813C8: BLR x9                     | X0 = typeof(System.Reflection.Assembly).__il2cppRuntimeField_1E0();
            // 0x016813CC: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
            // 0x016813D0: LDR x8, [x8, #0x218]       | X8 = 1152921504616644608;               
            // 0x016813D4: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x016813D8: LDR x8, [x8]               | X8 = typeof(System.Collections.Generic.List<T>);
            // 0x016813DC: MOV x0, x8                 | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            System.Collections.Generic.List<System.Type> val_3 = null;
            // 0x016813E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x016813E4: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x016813E8: LDR x8, [x8, #0x728]       | X8 = 1152921513148224880;               
            // 0x016813EC: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x016813F0: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.Type>::.ctor();
            // 0x016813F4: BL #0x25e9474              | .ctor();                                
            val_3 = new System.Collections.Generic.List<System.Type>();
            // 0x016813F8: ADRP x27, #0x35d6000       | X27 = 56451072 (0x35D6000);             
            // 0x016813FC: ADRP x28, #0x35f5000       | X28 = 56578048 (0x35F5000);             
            // 0x01681400: LDR x27, [x27, #0x920]     | X27 = 1152921504844173312;              
            // 0x01681404: LDR x28, [x28, #0x3d0]     | X28 = 1152921513148225904;              
            // 0x01681408: MOV w26, wzr               | W26 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x0168140C: B #0x1681414               |  goto label_4;                          
            goto label_4;
            label_17:
            // 0x01681410: ADD w26, w26, #1           | W26 = (val_8 + 1) = val_8 (0x00000001); 
            val_8 = 1;
            label_4:
            // 0x01681414: CBNZ x21, #0x168141c       | if (val_2 != null) goto label_5;        
            if(val_2 != null)
            {
                goto label_5;
            }
            // 0x01681418: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x0168141C: LDR w8, [x21, #0x18]       | W8 = val_2.resolve_event_holder; //P2   
            // 0x01681420: CMP w26, w8                | STATE = COMPARE(0x1, val_2.resolve_event_holder)
            // 0x01681424: B.GE #0x16814ec            | if (val_8 >= val_2.resolve_event_holder) goto label_6;
            if(val_8 >= val_2.resolve_event_holder)
            {
                goto label_6;
            }
            // 0x01681428: SXTW x22, w26              | X22 = 1 (0x00000001);                   
            // 0x0168142C: CMP w26, w8                | STATE = COMPARE(0x1, val_2.resolve_event_holder)
            // 0x01681430: B.LO #0x1681440            | if (val_8 < val_2.resolve_event_holder) goto label_7;
            if(val_8 < val_2.resolve_event_holder)
            {
                goto label_7;
            }
            // 0x01681434: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x01681438: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168143C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_7:
            // 0x01681440: ADD x8, x21, x22, lsl #3   | X8 = (val_2 + 8);                       
            System.Reflection.Assembly val_4 = val_2 + 8;
            // 0x01681444: LDR x22, [x8, #0x20]       | X22 = (val_2 + 8)._evidence; //P2       
            // 0x01681448: CBNZ x22, #0x1681450       | if ((val_2 + 8)._evidence != null) goto label_8;
            if(((val_2 + 8)._evidence) != null)
            {
                goto label_8;
            }
            // 0x0168144C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_8:
            // 0x01681450: LDR x8, [x22]              | X8 = typeof(System.Security.Policy.Evidence);
            // 0x01681454: MOV x0, x22                | X0 = (val_2 + 8)._evidence;//m1         
            val_9 = (val_2 + 8)._evidence;
            // 0x01681458: LDR x9, [x8, #0x220]       | X9 = typeof(System.Security.Policy.Evidence).__il2cppRuntimeField_220;
            // 0x0168145C: LDR x1, [x8, #0x228]       | X1 = typeof(System.Security.Policy.Evidence).__il2cppRuntimeField_228;
            // 0x01681460: B #0x1681474               |  goto label_9;                          
            goto label_9;
            label_15:
            // 0x01681464: LDR x8, [x23]              | X8 = X23;                               
            // 0x01681468: MOV x0, x23                | X0 = X23;//m1                           
            val_9 = X23;
            // 0x0168146C: LDR x9, [x8, #0x220]       | X9 = X23 + 544;                         
            // 0x01681470: LDR x1, [x8, #0x228]       | X1 = X23 + 552;                         
            label_9:
            // 0x01681474: BLR x9                     | X0 = X23 + 544();                       
            // 0x01681478: MOV x23, x0                | X23 = X23;//m1                          
            // 0x0168147C: CBZ x23, #0x1681410        | if (X23 == 0) goto label_17;            
            if(val_9 == 0)
            {
                goto label_17;
            }
            // 0x01681480: LDR x0, [x25]              | X0 = typeof(System.Type);               
            // 0x01681484: LDR x24, [x27]             | X24 = typeof(Pathfinding.NavGraph);     
            // 0x01681488: LDRB w8, [x0, #0x10a]      | W8 = System.Type.__il2cppRuntimeField_10A;
            // 0x0168148C: TBZ w8, #0, #0x168149c     | if (System.Type.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x01681490: LDR w8, [x0, #0xbc]        | W8 = System.Type.__il2cppRuntimeField_cctor_finished;
            // 0x01681494: CBNZ w8, #0x168149c        | if (System.Type.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x01681498: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.Type), ????);
            label_12:
            // 0x0168149C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016814A0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016814A4: MOV x1, x24                | X1 = 1152921504844173312 (0x100000000E255000);//ML01
            // 0x016814A8: BL #0x1b6d31c              | X0 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            System.Type val_5 = System.Type.GetTypeFromHandle(handle:  new System.RuntimeTypeHandle());
            // 0x016814AC: MOV x2, x0                 | X2 = val_5;//m1                         
            // 0x016814B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016814B4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x016814B8: MOV x1, x23                | X1 = X23;//m1                           
            // 0x016814BC: BL #0x1708de4              | X0 = System.Object.Equals(objA:  0, objB:  val_9);
            bool val_6 = System.Object.Equals(objA:  0, objB:  val_9);
            // 0x016814C0: TBNZ w0, #0, #0x16814d0    | if (val_6 == true) goto label_13;       
            if(val_6 == true)
            {
                goto label_13;
            }
            // 0x016814C4: CBNZ x23, #0x1681464       | if (X23 != 0) goto label_15;            
            if(val_9 != 0)
            {
                goto label_15;
            }
            // 0x016814C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x016814CC: B #0x1681464               |  goto label_15;                         
            goto label_15;
            label_13:
            // 0x016814D0: CBNZ x20, #0x16814d8       | if ( != 0) goto label_16;               
            if(null != 0)
            {
                goto label_16;
            }
            // 0x016814D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_16:
            // 0x016814D8: LDR x2, [x28]              | X2 = public System.Void System.Collections.Generic.List<System.Type>::Add(System.Type item);
            // 0x016814DC: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x016814E0: MOV x1, x22                | X1 = (val_2 + 8)._evidence;//m1         
            // 0x016814E4: BL #0x25ea480              | Add(item:  (val_2 + 8)._evidence);      
            Add(item:  (val_2 + 8)._evidence);
            // 0x016814E8: B #0x1681410               |  goto label_17;                         
            goto label_17;
            label_6:
            // 0x016814EC: CBNZ x20, #0x16814f4       | if ( != 0) goto label_18;               
            if(null != 0)
            {
                goto label_18;
            }
            // 0x016814F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_18:
            // 0x016814F4: ADRP x8, #0x363e000        | X8 = 56877056 (0x363E000);              
            // 0x016814F8: LDR x8, [x8, #0xb30]       | X8 = 1152921513148239216;               
            // 0x016814FC: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01681500: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<System.Type>::ToArray();
            // 0x01681504: BL #0x25ed474              | X0 = ToArray();                         
            T[] val_7 = ToArray();
            // 0x01681508: STR x0, [x19, #0x30]       | this.graphTypes = val_7;                 //  dest_result_addr=1152921513148301152
            this.graphTypes = val_7;
            // 0x0168150C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01681510: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01681514: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x01681518: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x0168151C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x01681520: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x01681524: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01681528 (23598376), len: 308  VirtAddr: 0x01681528 RVA: 0x01681528 token: 100681915 methodIndex: 49779 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Type GetGraphType(string type)
        {
            //
            // Disasemble & Code
            //  | 
            System.Type[] val_2;
            //  | 
            var val_3;
            //  | 
            System.Type[] val_4;
            //  | 
            System.Type val_5;
            // 0x01681528: STP x24, x23, [sp, #-0x40]! | stack[1152921513148581264] = ???;  stack[1152921513148581272] = ???;  //  dest_result_addr=1152921513148581264 |  dest_result_addr=1152921513148581272
            // 0x0168152C: STP x22, x21, [sp, #0x10]  | stack[1152921513148581280] = ???;  stack[1152921513148581288] = ???;  //  dest_result_addr=1152921513148581280 |  dest_result_addr=1152921513148581288
            // 0x01681530: STP x20, x19, [sp, #0x20]  | stack[1152921513148581296] = ???;  stack[1152921513148581304] = ???;  //  dest_result_addr=1152921513148581296 |  dest_result_addr=1152921513148581304
            // 0x01681534: STP x29, x30, [sp, #0x30]  | stack[1152921513148581312] = ???;  stack[1152921513148581320] = ???;  //  dest_result_addr=1152921513148581312 |  dest_result_addr=1152921513148581320
            // 0x01681538: ADD x29, sp, #0x30         | X29 = (1152921513148581264 + 48) = 1152921513148581312 (0x10000001FD2085C0);
            // 0x0168153C: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01681540: LDRB w8, [x21, #0xbf]      | W8 = (bool)static_value_037380BF;       
            // 0x01681544: MOV x19, x1                | X19 = type;//m1                         
            val_2 = type;
            // 0x01681548: MOV x20, x0                | X20 = 1152921513148593328 (0x10000001FD20B4B0);//ML01
            // 0x0168154C: TBNZ w8, #0, #0x1681568    | if (static_value_037380BF == true) goto label_0;
            // 0x01681550: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x01681554: LDR x8, [x8, #0xb60]       | X8 = 0x2B8EC28;                         
            // 0x01681558: LDR w0, [x8]               | W0 = 0x11CA;                            
            // 0x0168155C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CA, ????);     
            // 0x01681560: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01681564: STRB w8, [x21, #0xbf]      | static_value_037380BF = true;            //  dest_result_addr=57901247
            label_0:
            // 0x01681568: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
            // 0x0168156C: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
            // 0x01681570: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x01681574: B #0x168157c               |  goto label_1;                          
            goto label_1;
            label_9:
            // 0x01681578: ADD w22, w22, #1           | W22 = (val_3 + 1) = val_3 (0x00000001); 
            val_3 = 1;
            label_1:
            // 0x0168157C: LDR x21, [x20, #0x30]      | X21 = this.graphTypes; //P2             
            val_4 = this.graphTypes;
            // 0x01681580: CBNZ x21, #0x1681588       | if (this.graphTypes != null) goto label_2;
            if(val_4 != null)
            {
                goto label_2;
            }
            // 0x01681584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CA, ????);     
            label_2:
            // 0x01681588: LDR w8, [x21, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x0168158C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681590: B.GE #0x1681644            | if (val_3 >= this.graphTypes.Length) goto label_3;
            if(val_3 >= this.graphTypes.Length)
            {
                goto label_3;
            }
            // 0x01681594: LDR x21, [x20, #0x30]      | X21 = this.graphTypes; //P2             
            // 0x01681598: CBNZ x21, #0x16815a0       | if (this.graphTypes != null) goto label_4;
            if(this.graphTypes != null)
            {
                goto label_4;
            }
            // 0x0168159C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CA, ????);     
            label_4:
            // 0x016815A0: LDR w8, [x21, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x016815A4: SXTW x24, w22              | X24 = 1 (0x00000001);                   
            // 0x016815A8: CMP w22, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x016815AC: B.LO #0x16815bc            | if (val_3 < this.graphTypes.Length) goto label_5;
            if(val_3 < this.graphTypes.Length)
            {
                goto label_5;
            }
            // 0x016815B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11CA, ????);     
            // 0x016815B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016815B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11CA, ????);     
            label_5:
            // 0x016815BC: ADD x8, x21, x24, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x016815C0: LDR x21, [x8, #0x20]       | X21 = this.graphTypes[0x1][0]           
            System.Type val_2 = this.graphTypes[1];
            // 0x016815C4: CBNZ x21, #0x16815cc       | if (this.graphTypes[0x1][0] != null) goto label_6;
            if(val_2 != null)
            {
                goto label_6;
            }
            // 0x016815C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CA, ????);     
            label_6:
            // 0x016815CC: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x016815D0: MOV x0, x21                | X0 = this.graphTypes[0x1][0];//m1       
            // 0x016815D4: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Type).__il2cppRuntimeField_190; X1 = typeof(System.Type).__il2cppRuntimeField_198; //  | 
            // 0x016815D8: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_190();
            // 0x016815DC: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x016815E0: MOV x21, x0                | X21 = this.graphTypes[0x1][0];//m1      
            val_4 = val_2;
            // 0x016815E4: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x016815E8: TBZ w9, #0, #0x16815fc     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x016815EC: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x016815F0: CBNZ w9, #0x16815fc        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x016815F4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x016815F8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x016815FC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681600: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01681604: MOV x1, x21                | X1 = this.graphTypes[0x1][0];//m1       
            // 0x01681608: MOV x2, x19                | X2 = type;//m1                          
            // 0x0168160C: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  val_4);
            bool val_1 = System.String.op_Equality(a:  0, b:  val_4);
            // 0x01681610: TBZ w0, #0, #0x1681578     | if (val_1 == false) goto label_9;       
            if(val_1 == false)
            {
                goto label_9;
            }
            // 0x01681614: LDR x19, [x20, #0x30]      | X19 = this.graphTypes; //P2             
            val_2 = this.graphTypes;
            // 0x01681618: CBNZ x19, #0x1681620       | if (this.graphTypes != null) goto label_10;
            if(val_2 != null)
            {
                goto label_10;
            }
            // 0x0168161C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_10:
            // 0x01681620: LDR w8, [x19, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x01681624: CMP w22, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681628: B.LO #0x1681638            | if (val_3 < this.graphTypes.Length) goto label_11;
            if(val_3 < this.graphTypes.Length)
            {
                goto label_11;
            }
            // 0x0168162C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01681630: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681634: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_11:
            // 0x01681638: ADD x8, x19, x24, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x0168163C: LDR x0, [x8, #0x20]        | X0 = this.graphTypes[0x1][0]            
            val_5 = val_2[1];
            // 0x01681640: B #0x1681648               |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x01681644: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_5 = 0;
            label_12:
            // 0x01681648: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0168164C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01681650: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01681654: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01681658: RET                        |  return (System.Type)null;              
            return (System.Type)val_5;
            //  |  // // {name=val_0, type=System.Type, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168165C (23598684), len: 568  VirtAddr: 0x0168165C RVA: 0x0168165C token: 100681916 methodIndex: 49780 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph CreateGraph(string type)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            // 0x0168165C: STP x26, x25, [sp, #-0x50]! | stack[1152921513148947536] = ???;  stack[1152921513148947544] = ???;  //  dest_result_addr=1152921513148947536 |  dest_result_addr=1152921513148947544
            // 0x01681660: STP x24, x23, [sp, #0x10]  | stack[1152921513148947552] = ???;  stack[1152921513148947560] = ???;  //  dest_result_addr=1152921513148947552 |  dest_result_addr=1152921513148947560
            // 0x01681664: STP x22, x21, [sp, #0x20]  | stack[1152921513148947568] = ???;  stack[1152921513148947576] = ???;  //  dest_result_addr=1152921513148947568 |  dest_result_addr=1152921513148947576
            // 0x01681668: STP x20, x19, [sp, #0x30]  | stack[1152921513148947584] = ???;  stack[1152921513148947592] = ???;  //  dest_result_addr=1152921513148947584 |  dest_result_addr=1152921513148947592
            // 0x0168166C: STP x29, x30, [sp, #0x40]  | stack[1152921513148947600] = ???;  stack[1152921513148947608] = ???;  //  dest_result_addr=1152921513148947600 |  dest_result_addr=1152921513148947608
            // 0x01681670: ADD x29, sp, #0x40         | X29 = (1152921513148947536 + 64) = 1152921513148947600 (0x10000001FD261C90);
            // 0x01681674: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01681678: LDRB w8, [x21, #0xc0]      | W8 = (bool)static_value_037380C0;       
            // 0x0168167C: MOV x19, x1                | X19 = type;//m1                         
            // 0x01681680: MOV x20, x0                | X20 = 1152921513148959616 (0x10000001FD264B80);//ML01
            // 0x01681684: TBNZ w8, #0, #0x16816a0    | if (static_value_037380C0 == true) goto label_0;
            // 0x01681688: ADRP x8, #0x3647000        | X8 = 56913920 (0x3647000);              
            // 0x0168168C: LDR x8, [x8, #0xfc8]       | X8 = 0x2B8EBFC;                         
            // 0x01681690: LDR w0, [x8]               | W0 = 0x11BF;                            
            // 0x01681694: BL #0x2782188              | X0 = sub_2782188( ?? 0x11BF, ????);     
            // 0x01681698: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168169C: STRB w8, [x21, #0xc0]      | static_value_037380C0 = true;            //  dest_result_addr=57901248
            label_0:
            // 0x016816A0: ADRP x22, #0x35d6000       | X22 = 56451072 (0x35D6000);             
            // 0x016816A4: LDR x22, [x22, #0xe38]     | X22 = 1152921504608284672;              
            // 0x016816A8: LDR x0, [x22]              | X0 = typeof(System.String);             
            // 0x016816AC: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x016816B0: TBZ w8, #0, #0x16816c0     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x016816B4: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x016816B8: CBNZ w8, #0x16816c0        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x016816BC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x016816C0: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x016816C4: ADRP x9, #0x35d4000        | X9 = 56442880 (0x35D4000);              
            // 0x016816C8: LDR x8, [x8, #0xf20]       | X8 = (string**)(1152921513148808304)("Creating Graph of type \'");
            // 0x016816CC: LDR x9, [x9, #0xbc8]       | X9 = (string**)(1152921509747346240)("\'");
            // 0x016816D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016816D4: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x016816D8: LDR x1, [x8]               | X1 = "Creating Graph of type \'";       
            // 0x016816DC: LDR x3, [x9]               | X3 = "\'";                              
            // 0x016816E0: MOV x2, x19                | X2 = type;//m1                          
            // 0x016816E4: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "Creating Graph of type \'", str2:  type);
            string val_1 = System.String.Concat(str0:  0, str1:  "Creating Graph of type \'", str2:  type);
            // 0x016816E8: ADRP x23, #0x35f8000       | X23 = 56590336 (0x35F8000);             
            // 0x016816EC: LDR x23, [x23, #0x130]     | X23 = 1152921504692469760;              
            // 0x016816F0: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x016816F4: LDR x8, [x23]              | X8 = typeof(UnityEngine.Debug);         
            // 0x016816F8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x016816FC: TBZ w9, #0, #0x1681710     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x01681700: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01681704: CBNZ w9, #0x1681710        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x01681708: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x0168170C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_4:
            // 0x01681710: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681714: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01681718: MOV x1, x21                | X1 = val_1;//m1                         
            val_4 = val_1;
            // 0x0168171C: BL #0x1a5d154              | UnityEngine.Debug.Log(message:  0);     
            UnityEngine.Debug.Log(message:  0);
            // 0x01681720: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x01681724: B #0x168172c               |  goto label_5;                          
            goto label_5;
            label_13:
            // 0x01681728: ADD w24, w24, #1           | W24 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_5:
            // 0x0168172C: LDR x21, [x20, #0x30]      | X21 = this.graphTypes; //P2             
            // 0x01681730: CBNZ x21, #0x1681738       | if (this.graphTypes != null) goto label_6;
            if(this.graphTypes != null)
            {
                goto label_6;
            }
            // 0x01681734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_6:
            // 0x01681738: LDR w8, [x21, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x0168173C: CMP w24, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681740: B.GE #0x1681808            | if (val_5 >= this.graphTypes.Length) goto label_7;
            if(val_5 >= this.graphTypes.Length)
            {
                goto label_7;
            }
            // 0x01681744: LDR x21, [x20, #0x30]      | X21 = this.graphTypes; //P2             
            // 0x01681748: CBNZ x21, #0x1681750       | if (this.graphTypes != null) goto label_8;
            if(this.graphTypes != null)
            {
                goto label_8;
            }
            // 0x0168174C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_8:
            // 0x01681750: LDR w8, [x21, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x01681754: SXTW x25, w24              | X25 = 1 (0x00000001);                   
            // 0x01681758: CMP w24, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x0168175C: B.LO #0x168176c            | if (val_5 < this.graphTypes.Length) goto label_9;
            if(val_5 < this.graphTypes.Length)
            {
                goto label_9;
            }
            // 0x01681760: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x01681764: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_4 = 0;
            // 0x01681768: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_9:
            // 0x0168176C: ADD x8, x21, x25, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x01681770: LDR x21, [x8, #0x20]       | X21 = this.graphTypes[0x1][0]           
            System.Type val_4 = this.graphTypes[1];
            // 0x01681774: CBNZ x21, #0x168177c       | if (this.graphTypes[0x1][0] != null) goto label_10;
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x01681778: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_10:
            // 0x0168177C: LDR x8, [x21]              | X8 = typeof(System.Type);               
            // 0x01681780: MOV x0, x21                | X0 = this.graphTypes[0x1][0];//m1       
            // 0x01681784: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Type).__il2cppRuntimeField_190; X1 = typeof(System.Type).__il2cppRuntimeField_198; //  | 
            // 0x01681788: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_190();
            // 0x0168178C: LDR x8, [x22]              | X8 = typeof(System.String);             
            // 0x01681790: MOV x21, x0                | X21 = this.graphTypes[0x1][0];//m1      
            // 0x01681794: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x01681798: TBZ w9, #0, #0x16817ac     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x0168179C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x016817A0: CBNZ w9, #0x16817ac        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x016817A4: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x016817A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_12:
            // 0x016817AC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016817B0: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x016817B4: MOV x1, x21                | X1 = this.graphTypes[0x1][0];//m1       
            // 0x016817B8: MOV x2, x19                | X2 = type;//m1                          
            // 0x016817BC: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.graphTypes[1]);
            bool val_2 = System.String.op_Equality(a:  0, b:  val_4);
            // 0x016817C0: TBZ w0, #0, #0x1681728     | if (val_2 == false) goto label_13;      
            if(val_2 == false)
            {
                goto label_13;
            }
            // 0x016817C4: LDR x19, [x20, #0x30]      | X19 = this.graphTypes; //P2             
            // 0x016817C8: CBNZ x19, #0x16817d0       | if (this.graphTypes != null) goto label_14;
            if(this.graphTypes != null)
            {
                goto label_14;
            }
            // 0x016817CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_14:
            // 0x016817D0: LDR w8, [x19, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x016817D4: CMP w24, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x016817D8: B.LO #0x16817e8            | if (val_5 < this.graphTypes.Length) goto label_15;
            if(val_5 < this.graphTypes.Length)
            {
                goto label_15;
            }
            // 0x016817DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x016817E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016817E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_15:
            // 0x016817E8: ADD x8, x19, x25, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x016817EC: LDR x1, [x8, #0x20]        | X1 = this.graphTypes[0x1][0]            
            System.Type val_5 = this.graphTypes[1];
            // 0x016817F0: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x016817F4: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x016817F8: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x016817FC: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01681800: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01681804: B #0x1681894               | return val_2.CreateGraph(type:  this.graphTypes[1]);
            return val_2.CreateGraph(type:  val_5);
            label_7:
            // 0x01681808: LDR x0, [x22]              | X0 = typeof(System.String);             
            // 0x0168180C: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01681810: TBZ w8, #0, #0x1681820     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_17;
            // 0x01681814: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01681818: CBNZ w8, #0x1681820        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_17;
            // 0x0168181C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_17:
            // 0x01681820: ADRP x8, #0x3671000        | X8 = 57085952 (0x3671000);              
            // 0x01681824: ADRP x9, #0x35de000        | X9 = 56483840 (0x35DE000);              
            // 0x01681828: LDR x8, [x8, #0xf08]       | X8 = (string**)(1152921513148931312)("Graph type (");
            // 0x0168182C: LDR x9, [x9, #0x8f0]       | X9 = (string**)(1152921513148931408)(") wasn\'t found");
            // 0x01681830: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681834: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01681838: LDR x1, [x8]               | X1 = "Graph type (";                    
            // 0x0168183C: LDR x3, [x9]               | X3 = ") wasn\'t found";                 
            // 0x01681840: MOV x2, x19                | X2 = type;//m1                          
            // 0x01681844: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "Graph type (", str2:  type);
            string val_3 = System.String.Concat(str0:  0, str1:  "Graph type (", str2:  type);
            // 0x01681848: LDR x8, [x23]              | X8 = typeof(UnityEngine.Debug);         
            // 0x0168184C: MOV x19, x0                | X19 = val_3;//m1                        
            // 0x01681850: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01681854: TBZ w9, #0, #0x1681868     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x01681858: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x0168185C: CBNZ w9, #0x1681868        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x01681860: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x01681864: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_19:
            // 0x01681868: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168186C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01681870: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x01681874: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
            UnityEngine.Debug.LogError(message:  0);
            // 0x01681878: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0168187C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01681880: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01681884: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01681888: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168188C: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01681890: RET                        |  return (Pathfinding.NavGraph)null;     
            return (Pathfinding.NavGraph)0;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01681894 (23599252), len: 160  VirtAddr: 0x01681894 RVA: 0x01681894 token: 100681917 methodIndex: 49781 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph CreateGraph(System.Type type)
        {
            //
            // Disasemble & Code
            // 0x01681894: STP x20, x19, [sp, #-0x20]! | stack[1152921513149207040] = ???;  stack[1152921513149207048] = ???;  //  dest_result_addr=1152921513149207040 |  dest_result_addr=1152921513149207048
            // 0x01681898: STP x29, x30, [sp, #0x10]  | stack[1152921513149207056] = ???;  stack[1152921513149207064] = ???;  //  dest_result_addr=1152921513149207056 |  dest_result_addr=1152921513149207064
            // 0x0168189C: ADD x29, sp, #0x10         | X29 = (1152921513149207040 + 16) = 1152921513149207056 (0x10000001FD2A1210);
            // 0x016818A0: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x016818A4: LDRB w8, [x20, #0xc1]      | W8 = (bool)static_value_037380C1;       
            // 0x016818A8: MOV x19, x1                | X19 = type;//m1                         
            // 0x016818AC: TBNZ w8, #0, #0x16818c8    | if (static_value_037380C1 == true) goto label_0;
            // 0x016818B0: ADRP x8, #0x3657000        | X8 = 56979456 (0x3657000);              
            // 0x016818B4: LDR x8, [x8, #0x728]       | X8 = 0x2B8EC00;                         
            // 0x016818B8: LDR w0, [x8]               | W0 = 0x11C0;                            
            // 0x016818BC: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C0, ????);     
            // 0x016818C0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016818C4: STRB w8, [x20, #0xc1]      | static_value_037380C1 = true;            //  dest_result_addr=57901249
            label_0:
            // 0x016818C8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016818CC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016818D0: MOV x1, x19                | X1 = type;//m1                          
            // 0x016818D4: BL #0x18c8eb0              | X0 = System.Activator.CreateInstance(type:  0);
            object val_1 = System.Activator.CreateInstance(type:  0);
            // 0x016818D8: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x016818DC: CBZ x19, #0x168192c        | if (val_1 == null) goto label_3;        
            if(val_1 == null)
            {
                goto label_3;
            }
            // 0x016818E0: ADRP x8, #0x3603000        | X8 = 56635392 (0x3603000);              
            // 0x016818E4: LDR x8, [x8, #0x930]       | X8 = 1152921504844173312;               
            // 0x016818E8: LDR x9, [x19]              | X9 = typeof(System.Object);             
            // 0x016818EC: LDR x8, [x8]               | X8 = typeof(Pathfinding.NavGraph);      
            // 0x016818F0: LDRB w11, [x9, #0x104]     | W11 = System.Object.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x016818F4: LDRB w10, [x8, #0x104]     | W10 = Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth;
            // 0x016818F8: CMP w11, w10               | STATE = COMPARE(System.Object.__il2cppRuntimeField_typeHierarchyDepth, Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth)
            // 0x016818FC: B.LO #0x168192c            | if (System.Object.__il2cppRuntimeField_typeHierarchyDepth < Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth) goto label_3;
            // 0x01681900: LDR x9, [x9, #0xb0]        | X9 = System.Object.__il2cppRuntimeField_typeHierarchy;
            // 0x01681904: ADD x9, x9, x10, lsl #3    | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavGraph.__il2cppRuntimeField_
            // 0x01681908: LDUR x9, [x9, #-8]         | X9 = (System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8;
            // 0x0168190C: CMP x9, x8                 | STATE = COMPARE((System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8, typeof(Pathfinding.NavGraph))
            // 0x01681910: B.NE #0x168192c            | if ((System.Object.__il2cppRuntimeField_typeHierarchy + (Pathfinding.NavGraph.__il2cppRuntimeField_typeHierarchyDepth) << 3) + -8 != null) goto label_3;
            // 0x01681914: BL #0x167f8b4              | X0 = val_1.get_active();                
            AstarPath val_2 = val_1.active;
            // 0x01681918: STR x0, [x19, #0x18]       | mem2[0] = val_2;                         //  dest_result_addr=0
            mem2[0] = val_2;
            // 0x0168191C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01681920: MOV x0, x19                | X0 = val_1;//m1                         
            // 0x01681924: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01681928: RET                        |  return (Pathfinding.NavGraph)val_1;    
            return (Pathfinding.NavGraph)val_1;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
            label_3:
            // 0x0168192C: BL #0x167f8b4              | X0 = val_1.get_active();                
            AstarPath val_3 = val_1.active;
            // 0x01681930: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        
        }
        //
        // Offset in libil2cpp.so: 0x01681934 (23599412), len: 472  VirtAddr: 0x01681934 RVA: 0x01681934 token: 100681918 methodIndex: 49782 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph AddGraph(string type)
        {
            //
            // Disasemble & Code
            //  | 
            string val_4;
            //  | 
            var val_5;
            //  | 
            Pathfinding.NavGraph val_6;
            // 0x01681934: STP x26, x25, [sp, #-0x50]! | stack[1152921513149466672] = ???;  stack[1152921513149466680] = ???;  //  dest_result_addr=1152921513149466672 |  dest_result_addr=1152921513149466680
            // 0x01681938: STP x24, x23, [sp, #0x10]  | stack[1152921513149466688] = ???;  stack[1152921513149466696] = ???;  //  dest_result_addr=1152921513149466688 |  dest_result_addr=1152921513149466696
            // 0x0168193C: STP x22, x21, [sp, #0x20]  | stack[1152921513149466704] = ???;  stack[1152921513149466712] = ???;  //  dest_result_addr=1152921513149466704 |  dest_result_addr=1152921513149466712
            // 0x01681940: STP x20, x19, [sp, #0x30]  | stack[1152921513149466720] = ???;  stack[1152921513149466728] = ???;  //  dest_result_addr=1152921513149466720 |  dest_result_addr=1152921513149466728
            // 0x01681944: STP x29, x30, [sp, #0x40]  | stack[1152921513149466736] = ???;  stack[1152921513149466744] = ???;  //  dest_result_addr=1152921513149466736 |  dest_result_addr=1152921513149466744
            // 0x01681948: ADD x29, sp, #0x40         | X29 = (1152921513149466672 + 64) = 1152921513149466736 (0x10000001FD2E0870);
            // 0x0168194C: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01681950: LDRB w8, [x21, #0xc2]      | W8 = (bool)static_value_037380C2;       
            // 0x01681954: MOV x19, x1                | X19 = type;//m1                         
            val_4 = type;
            // 0x01681958: MOV x20, x0                | X20 = 1152921513149478752 (0x10000001FD2E3760);//ML01
            // 0x0168195C: TBNZ w8, #0, #0x1681978    | if (static_value_037380C2 == true) goto label_0;
            // 0x01681960: ADRP x8, #0x35c7000        | X8 = 56389632 (0x35C7000);              
            // 0x01681964: LDR x8, [x8, #0xdf0]       | X8 = 0x2B8EBF0;                         
            // 0x01681968: LDR w0, [x8]               | W0 = 0x11BC;                            
            // 0x0168196C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11BC, ????);     
            // 0x01681970: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01681974: STRB w8, [x21, #0xc2]      | static_value_037380C2 = true;            //  dest_result_addr=57901250
            label_0:
            // 0x01681978: ADRP x23, #0x35d6000       | X23 = 56451072 (0x35D6000);             
            // 0x0168197C: LDR x23, [x23, #0xe38]     | X23 = 1152921504608284672;              
            // 0x01681980: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x01681984: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x01681988: B #0x1681990               |  goto label_1;                          
            goto label_1;
            label_12:
            // 0x0168198C: ADD w24, w24, #1           | W24 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_1:
            // 0x01681990: LDR x22, [x20, #0x30]      | X22 = this.graphTypes; //P2             
            // 0x01681994: CBNZ x22, #0x168199c       | if (this.graphTypes != null) goto label_2;
            if(this.graphTypes != null)
            {
                goto label_2;
            }
            // 0x01681998: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11BC, ????);     
            label_2:
            // 0x0168199C: LDR w8, [x22, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x016819A0: CMP w24, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x016819A4: B.GE #0x1681a60            | if (val_5 >= this.graphTypes.Length) goto label_3;
            if(val_5 >= this.graphTypes.Length)
            {
                goto label_3;
            }
            // 0x016819A8: LDR x22, [x20, #0x30]      | X22 = this.graphTypes; //P2             
            // 0x016819AC: CBNZ x22, #0x16819b4       | if (this.graphTypes != null) goto label_4;
            if(this.graphTypes != null)
            {
                goto label_4;
            }
            // 0x016819B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11BC, ????);     
            label_4:
            // 0x016819B4: LDR w8, [x22, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x016819B8: SXTW x25, w24              | X25 = 1 (0x00000001);                   
            // 0x016819BC: CMP w24, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x016819C0: B.LO #0x16819d0            | if (val_5 < this.graphTypes.Length) goto label_5;
            if(val_5 < this.graphTypes.Length)
            {
                goto label_5;
            }
            // 0x016819C4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11BC, ????);     
            // 0x016819C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016819CC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11BC, ????);     
            label_5:
            // 0x016819D0: ADD x8, x22, x25, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x016819D4: LDR x22, [x8, #0x20]       | X22 = this.graphTypes[0x1][0]           
            System.Type val_4 = this.graphTypes[1];
            // 0x016819D8: CBNZ x22, #0x16819e0       | if (this.graphTypes[0x1][0] != null) goto label_6;
            if(val_4 != null)
            {
                goto label_6;
            }
            // 0x016819DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11BC, ????);     
            label_6:
            // 0x016819E0: LDR x8, [x22]              | X8 = typeof(System.Type);               
            // 0x016819E4: MOV x0, x22                | X0 = this.graphTypes[0x1][0];//m1       
            // 0x016819E8: LDP x9, x1, [x8, #0x190]   | X9 = typeof(System.Type).__il2cppRuntimeField_190; X1 = typeof(System.Type).__il2cppRuntimeField_198; //  | 
            // 0x016819EC: BLR x9                     | X0 = typeof(System.Type).__il2cppRuntimeField_190();
            // 0x016819F0: LDR x8, [x23]              | X8 = typeof(System.String);             
            // 0x016819F4: MOV x22, x0                | X22 = this.graphTypes[0x1][0];//m1      
            // 0x016819F8: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x016819FC: TBZ w9, #0, #0x1681a10     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x01681A00: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01681A04: CBNZ w9, #0x1681a10        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x01681A08: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01681A0C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_8:
            // 0x01681A10: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681A14: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01681A18: MOV x1, x22                | X1 = this.graphTypes[0x1][0];//m1       
            // 0x01681A1C: MOV x2, x19                | X2 = type;//m1                          
            // 0x01681A20: BL #0x18a2cbc              | X0 = System.String.op_Equality(a:  0, b:  this.graphTypes[1]);
            bool val_1 = System.String.op_Equality(a:  0, b:  val_4);
            // 0x01681A24: TBZ w0, #0, #0x168198c     | if (val_1 == false) goto label_12;      
            if(val_1 == false)
            {
                goto label_12;
            }
            // 0x01681A28: LDR x21, [x20, #0x30]      | X21 = this.graphTypes; //P2             
            // 0x01681A2C: CBNZ x21, #0x1681a34       | if (this.graphTypes != null) goto label_10;
            if(this.graphTypes != null)
            {
                goto label_10;
            }
            // 0x01681A30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_10:
            // 0x01681A34: LDR w8, [x21, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x01681A38: CMP w24, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681A3C: B.LO #0x1681a4c            | if (val_5 < this.graphTypes.Length) goto label_11;
            if(val_5 < this.graphTypes.Length)
            {
                goto label_11;
            }
            // 0x01681A40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01681A44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681A48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_11:
            // 0x01681A4C: ADD x8, x21, x25, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x01681A50: LDR x1, [x8, #0x20]        | X1 = this.graphTypes[0x1][0]            
            System.Type val_5 = this.graphTypes[1];
            // 0x01681A54: BL #0x1681894              | X0 = val_1.CreateGraph(type:  this.graphTypes[1]);
            Pathfinding.NavGraph val_2 = val_1.CreateGraph(type:  val_5);
            // 0x01681A58: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x01681A5C: B #0x168198c               |  goto label_12;                         
            goto label_12;
            label_3:
            // 0x01681A60: CBZ x21, #0x1681a74        | if (0x0 == 0) goto label_13;            
            if(val_6 == 0)
            {
                goto label_13;
            }
            // 0x01681A64: MOV x0, x20                | X0 = 1152921513149478752 (0x10000001FD2E3760);//ML01
            // 0x01681A68: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x01681A6C: BL #0x1681b0c              | this.AddGraph(graph:  val_6);           
            this.AddGraph(graph:  val_6);
            // 0x01681A70: B #0x1681af0               |  goto label_14;                         
            goto label_14;
            label_13:
            // 0x01681A74: LDR x0, [x23]              | X0 = typeof(System.String);             
            // 0x01681A78: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01681A7C: TBZ w8, #0, #0x1681a8c     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_16;
            // 0x01681A80: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01681A84: CBNZ w8, #0x1681a8c        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_16;
            // 0x01681A88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_16:
            // 0x01681A8C: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x01681A90: ADRP x9, #0x366f000        | X9 = 57077760 (0x366F000);              
            // 0x01681A94: LDR x8, [x8, #0xd80]       | X8 = (string**)(1152921513149450432)("No NavGraph of type \'");
            // 0x01681A98: LDR x9, [x9, #0xb20]       | X9 = (string**)(1152921513149450544)("\' could be found");
            // 0x01681A9C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681AA0: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01681AA4: LDR x1, [x8]               | X1 = "No NavGraph of type \'";          
            // 0x01681AA8: LDR x3, [x9]               | X3 = "\' could be found";               
            // 0x01681AAC: MOV x2, x19                | X2 = type;//m1                          
            // 0x01681AB0: BL #0x18a311c              | X0 = System.String.Concat(str0:  0, str1:  "No NavGraph of type \'", str2:  val_4);
            string val_3 = System.String.Concat(str0:  0, str1:  "No NavGraph of type \'", str2:  val_4);
            // 0x01681AB4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x01681AB8: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01681ABC: MOV x19, x0                | X19 = val_3;//m1                        
            val_4 = val_3;
            // 0x01681AC0: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01681AC4: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x01681AC8: TBZ w9, #0, #0x1681adc     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_18;
            // 0x01681ACC: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01681AD0: CBNZ w9, #0x1681adc        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_18;
            // 0x01681AD4: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x01681AD8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_18:
            // 0x01681ADC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681AE0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01681AE4: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x01681AE8: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
            UnityEngine.Debug.LogError(message:  0);
            // 0x01681AEC: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_6 = 0;
            label_14:
            // 0x01681AF0: MOV x0, x21                | X0 = 0 (0x0);//ML01                     
            // 0x01681AF4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01681AF8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01681AFC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01681B00: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01681B04: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01681B08: RET                        |  return (Pathfinding.NavGraph)null;     
            return (Pathfinding.NavGraph)val_6;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01681E44 (23600708), len: 828  VirtAddr: 0x01681E44 RVA: 0x01681E44 token: 100681919 methodIndex: 49783 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph AddGraph(System.Type type)
        {
            //
            // Disasemble & Code
            //  | 
            System.Type val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            Pathfinding.NavGraph val_7;
            // 0x01681E44: STP x24, x23, [sp, #-0x40]! | stack[1152921513149882032] = ???;  stack[1152921513149882040] = ???;  //  dest_result_addr=1152921513149882032 |  dest_result_addr=1152921513149882040
            // 0x01681E48: STP x22, x21, [sp, #0x10]  | stack[1152921513149882048] = ???;  stack[1152921513149882056] = ???;  //  dest_result_addr=1152921513149882048 |  dest_result_addr=1152921513149882056
            // 0x01681E4C: STP x20, x19, [sp, #0x20]  | stack[1152921513149882064] = ???;  stack[1152921513149882072] = ???;  //  dest_result_addr=1152921513149882064 |  dest_result_addr=1152921513149882072
            // 0x01681E50: STP x29, x30, [sp, #0x30]  | stack[1152921513149882080] = ???;  stack[1152921513149882088] = ???;  //  dest_result_addr=1152921513149882080 |  dest_result_addr=1152921513149882088
            // 0x01681E54: ADD x29, sp, #0x30         | X29 = (1152921513149882032 + 48) = 1152921513149882080 (0x10000001FD345EE0);
            // 0x01681E58: SUB sp, sp, #0x10          | SP = (1152921513149882032 - 16) = 1152921513149882016 (0x10000001FD345EA0);
            // 0x01681E5C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01681E60: LDRB w8, [x20, #0xc3]      | W8 = (bool)static_value_037380C3;       
            // 0x01681E64: MOV x21, x1                | X21 = type;//m1                         
            val_4 = type;
            // 0x01681E68: MOV x19, x0                | X19 = 1152921513149894096 (0x10000001FD348DD0);//ML01
            val_5 = this;
            // 0x01681E6C: TBNZ w8, #0, #0x1681e88    | if (static_value_037380C3 == true) goto label_0;
            // 0x01681E70: ADRP x8, #0x35fd000        | X8 = 56610816 (0x35FD000);              
            // 0x01681E74: LDR x8, [x8, #0x138]       | X8 = 0x2B8EBF4;                         
            // 0x01681E78: LDR w0, [x8]               | W0 = 0x11BD;                            
            // 0x01681E7C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11BD, ????);     
            // 0x01681E80: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01681E84: STRB w8, [x20, #0xc3]      | static_value_037380C3 = true;            //  dest_result_addr=57901251
            label_0:
            // 0x01681E88: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_6 = 0;
            // 0x01681E8C: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_7 = 0;
            // 0x01681E90: B #0x1681e98               |  goto label_1;                          
            goto label_1;
            label_9:
            // 0x01681E94: ADD w22, w22, #1           | W22 = (val_6 + 1) = val_6 (0x00000001); 
            val_6 = 1;
            label_1:
            // 0x01681E98: LDR x23, [x19, #0x30]      | X23 = this.graphTypes; //P2             
            // 0x01681E9C: CBNZ x23, #0x1681ea4       | if (this.graphTypes != null) goto label_2;
            if(this.graphTypes != null)
            {
                goto label_2;
            }
            // 0x01681EA0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11BD, ????);     
            label_2:
            // 0x01681EA4: LDR w8, [x23, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x01681EA8: CMP w22, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681EAC: B.GE #0x1681f2c            | if (val_6 >= this.graphTypes.Length) goto label_3;
            if(val_6 >= this.graphTypes.Length)
            {
                goto label_3;
            }
            // 0x01681EB0: LDR x24, [x19, #0x30]      | X24 = this.graphTypes; //P2             
            // 0x01681EB4: CBNZ x24, #0x1681ebc       | if (this.graphTypes != null) goto label_4;
            if(this.graphTypes != null)
            {
                goto label_4;
            }
            // 0x01681EB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11BD, ????);     
            label_4:
            // 0x01681EBC: LDR w8, [x24, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x01681EC0: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x01681EC4: CMP w22, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681EC8: B.LO #0x1681ed8            | if (val_6 < this.graphTypes.Length) goto label_5;
            if(val_6 < this.graphTypes.Length)
            {
                goto label_5;
            }
            // 0x01681ECC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11BD, ????);     
            // 0x01681ED0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681ED4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11BD, ????);     
            label_5:
            // 0x01681ED8: ADD x8, x24, x23, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x01681EDC: LDR x1, [x8, #0x20]        | X1 = this.graphTypes[0x1][0]            
            System.Type val_4 = this.graphTypes[1];
            // 0x01681EE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681EE4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01681EE8: MOV x2, x21                | X2 = type;//m1                          
            // 0x01681EEC: BL #0x1708de4              | X0 = System.Object.Equals(objA:  0, objB:  this.graphTypes[1]);
            bool val_1 = System.Object.Equals(objA:  0, objB:  val_4);
            // 0x01681EF0: TBZ w0, #0, #0x1681e94     | if (val_1 == false) goto label_9;       
            if(val_1 == false)
            {
                goto label_9;
            }
            // 0x01681EF4: LDR x20, [x19, #0x30]      | X20 = this.graphTypes; //P2             
            // 0x01681EF8: CBNZ x20, #0x1681f00       | if (this.graphTypes != null) goto label_7;
            if(this.graphTypes != null)
            {
                goto label_7;
            }
            // 0x01681EFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_7:
            // 0x01681F00: LDR w8, [x20, #0x18]       | W8 = this.graphTypes.Length; //P2       
            // 0x01681F04: CMP w22, w8                | STATE = COMPARE(0x1, this.graphTypes.Length)
            // 0x01681F08: B.LO #0x1681f18            | if (val_6 < this.graphTypes.Length) goto label_8;
            if(val_6 < this.graphTypes.Length)
            {
                goto label_8;
            }
            // 0x01681F0C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
            // 0x01681F10: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681F14: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
            label_8:
            // 0x01681F18: ADD x8, x20, x23, lsl #3   | X8 = this.graphTypes[0x1]; //PARR1      
            // 0x01681F1C: LDR x1, [x8, #0x20]        | X1 = this.graphTypes[0x1][0]            
            System.Type val_5 = this.graphTypes[1];
            // 0x01681F20: BL #0x1681894              | X0 = val_1.CreateGraph(type:  this.graphTypes[1]);
            Pathfinding.NavGraph val_2 = val_1.CreateGraph(type:  val_5);
            // 0x01681F24: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x01681F28: B #0x1681e94               |  goto label_9;                          
            goto label_9;
            label_3:
            // 0x01681F2C: CBZ x20, #0x1681f40        | if (0x0 == 0) goto label_10;            
            if(val_7 == 0)
            {
                goto label_10;
            }
            // 0x01681F30: MOV x0, x19                | X0 = 1152921513149894096 (0x10000001FD348DD0);//ML01
            // 0x01681F34: MOV x1, x20                | X1 = 0 (0x0);//ML01                     
            // 0x01681F38: BL #0x1681b0c              | this.AddGraph(graph:  val_7);           
            this.AddGraph(graph:  val_7);
            // 0x01681F3C: B #0x1682164               |  goto label_11;                         
            goto label_11;
            label_10:
            // 0x01681F40: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x01681F44: LDR x8, [x8, #0x3d0]       | X8 = 1152921504954501264;               
            // 0x01681F48: LDR x20, [x8]              | X20 = typeof(System.Object[]);          
            // 0x01681F4C: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01681F50: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.Object[]), ????);
            // 0x01681F54: MOVZ w1, #0x5              | W1 = 5 (0x5);//ML01                     
            // 0x01681F58: MOV x0, x20                | X0 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01681F5C: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.Object[]), ????);
            // 0x01681F60: MOV x20, x0                | X20 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01681F64: CBNZ x20, #0x1681f6c       | if ( != null) goto label_12;            
            if(null != null)
            {
                goto label_12;
            }
            // 0x01681F68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Object[]), ????);
            label_12:
            // 0x01681F6C: ADRP x22, #0x35c5000       | X22 = 56381440 (0x35C5000);             
            // 0x01681F70: LDR x22, [x22, #0xd80]     | X22 = (string**)(1152921513149450432)("No NavGraph of type \'");
            // 0x01681F74: LDR x0, [x22]              | X0 = "No NavGraph of type \'";          
            // 0x01681F78: CBZ x0, #0x1681f98         | if ("No NavGraph of type \'" == null) goto label_14;
            // 0x01681F7C: LDR x8, [x20]              | X8 = ;                                  
            // 0x01681F80: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01681F84: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "No NavGraph of type \'", ????);
            // 0x01681F88: CBNZ x0, #0x1681f98        | if ("No NavGraph of type \'" != null) goto label_14;
            if("No NavGraph of type \'" != null)
            {
                goto label_14;
            }
            // 0x01681F8C: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "No NavGraph of type \'", ????);
            // 0x01681F90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681F94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "No NavGraph of type \'", ????);
            label_14:
            // 0x01681F98: LDR x22, [x22]             | X22 = "No NavGraph of type \'";         
            // 0x01681F9C: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01681FA0: CBNZ w8, #0x1681fb0        | if (System.Object[].__il2cppRuntimeField_namespaze != 0) goto label_15;
            // 0x01681FA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "No NavGraph of type \'", ????);
            // 0x01681FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681FAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "No NavGraph of type \'", ????);
            label_15:
            // 0x01681FB0: STR x22, [x20, #0x20]      | typeof(System.Object[]).__il2cppRuntimeField_20 = "No NavGraph of type \'";  //  dest_result_addr=1152921504954501296
            typeof(System.Object[]).__il2cppRuntimeField_20 = "No NavGraph of type \'";
            // 0x01681FB4: CBZ x21, #0x1681fd8        | if (type == null) goto label_17;        
            if(val_4 == null)
            {
                goto label_17;
            }
            // 0x01681FB8: LDR x8, [x20]              | X8 = ;                                  
            // 0x01681FBC: MOV x0, x21                | X0 = type;//m1                          
            // 0x01681FC0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x01681FC4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? type, ????);       
            // 0x01681FC8: CBNZ x0, #0x1681fd8        | if (type != null) goto label_17;        
            if(val_4 != null)
            {
                goto label_17;
            }
            // 0x01681FCC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? type, ????);       
            // 0x01681FD0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681FD4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? type, ????);       
            label_17:
            // 0x01681FD8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01681FDC: CMP w8, #1                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x1)
            // 0x01681FE0: B.HI #0x1681ff0            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x1) goto label_18;
            // 0x01681FE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? type, ????);       
            // 0x01681FE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01681FEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? type, ????);       
            label_18:
            // 0x01681FF0: STR x21, [x20, #0x28]      | typeof(System.Object[]).__il2cppRuntimeField_28 = type;  //  dest_result_addr=1152921504954501304
            typeof(System.Object[]).__il2cppRuntimeField_28 = val_4;
            // 0x01681FF4: ADRP x21, #0x3608000       | X21 = 56655872 (0x3608000);             
            // 0x01681FF8: LDR x21, [x21, #0x7b0]     | X21 = (string**)(1152921513149824800)("\' could be found, ");
            // 0x01681FFC: LDR x0, [x21]              | X0 = "\' could be found, ";             
            // 0x01682000: CBZ x0, #0x1682020         | if ("\' could be found, " == null) goto label_20;
            // 0x01682004: LDR x8, [x20]              | X8 = ;                                  
            // 0x01682008: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0168200C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? "\' could be found, ", ????);
            // 0x01682010: CBNZ x0, #0x1682020        | if ("\' could be found, " != null) goto label_20;
            if("\' could be found, " != null)
            {
                goto label_20;
            }
            // 0x01682014: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? "\' could be found, ", ????);
            // 0x01682018: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168201C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\' could be found, ", ????);
            label_20:
            // 0x01682020: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01682024: LDR x21, [x21]             | X21 = "\' could be found, ";            
            val_4 = "\' could be found, ";
            // 0x01682028: CMP w8, #2                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x2)
            // 0x0168202C: B.HI #0x168203c            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x2) goto label_21;
            // 0x01682030: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? "\' could be found, ", ????);
            // 0x01682034: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682038: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? "\' could be found, ", ????);
            label_21:
            // 0x0168203C: STR x21, [x20, #0x30]      | typeof(System.Object[]).__il2cppRuntimeField_30 = "\' could be found, ";  //  dest_result_addr=1152921504954501312
            typeof(System.Object[]).__il2cppRuntimeField_30 = val_4;
            // 0x01682040: LDR x19, [x19, #0x30]      | X19 = this.graphTypes; //P2             
            // 0x01682044: CBNZ x19, #0x168204c       | if (this.graphTypes != null) goto label_22;
            if(this.graphTypes != null)
            {
                goto label_22;
            }
            // 0x01682048: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? "\' could be found, ", ????);
            label_22:
            // 0x0168204C: ADRP x9, #0x3652000        | X9 = 56958976 (0x3652000);              
            // 0x01682050: LDR x8, [x19, #0x18]       | X8 = this.graphTypes.Length; //P2       
            // 0x01682054: LDR x9, [x9, #0x140]       | X9 = 1152921504607113216;               
            // 0x01682058: ADD x1, sp, #0xc           | X1 = (1152921513149882016 + 12) = 1152921513149882028 (0x10000001FD345EAC);
            // 0x0168205C: STR w8, [sp, #0xc]         | stack[1152921513149882028] = this.graphTypes.Length;  //  dest_result_addr=1152921513149882028
            // 0x01682060: LDR x0, [x9]               | X0 = typeof(System.Int32);              
            // 0x01682064: BL #0x27bc028              | X0 = 1152921513150089936 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.Int32), this.graphTypes.Length);
            // 0x01682068: MOV x19, x0                | X19 = 1152921513150089936 (0x10000001FD378AD0);//ML01
            // 0x0168206C: CBZ x19, #0x1682090        | if (this.graphTypes.Length == 0) goto label_24;
            if(this.graphTypes.Length == 0)
            {
                goto label_24;
            }
            // 0x01682070: LDR x8, [x20]              | X8 = ;                                  
            // 0x01682074: MOV x0, x19                | X0 = 1152921513150089936 (0x10000001FD378AD0);//ML01
            // 0x01682078: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x0168207C: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? this.graphTypes.Length, ????);
            // 0x01682080: CBNZ x0, #0x1682090        | if (this.graphTypes.Length != 0) goto label_24;
            if(this.graphTypes.Length != 0)
            {
                goto label_24;
            }
            // 0x01682084: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? this.graphTypes.Length, ????);
            // 0x01682088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168208C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.graphTypes.Length, ????);
            label_24:
            // 0x01682090: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x01682094: CMP w8, #3                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x3)
            // 0x01682098: B.HI #0x16820a8            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x3) goto label_25;
            // 0x0168209C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.graphTypes.Length, ????);
            // 0x016820A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016820A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.graphTypes.Length, ????);
            label_25:
            // 0x016820A8: STR x19, [x20, #0x38]      | typeof(System.Object[]).__il2cppRuntimeField_38 = this.graphTypes.Length; typeof(System.Object[]).__il2cppRuntimeField_3C = 0x10000001;  //  dest_result_addr=1152921504954501320 dest_result_addr=1152921504954501324
            typeof(System.Object[]).__il2cppRuntimeField_38 = this.graphTypes.Length;
            typeof(System.Object[]).__il2cppRuntimeField_3C = 268435457;
            // 0x016820AC: ADRP x19, #0x363e000       | X19 = 56877056 (0x363E000);             
            // 0x016820B0: LDR x19, [x19, #0x278]     | X19 = (string**)(1152921513149865872)(" graph types are avaliable");
            // 0x016820B4: LDR x0, [x19]              | X0 = " graph types are avaliable";      
            // 0x016820B8: CBZ x0, #0x16820d8         | if (" graph types are avaliable" == null) goto label_27;
            // 0x016820BC: LDR x8, [x20]              | X8 = ;                                  
            // 0x016820C0: LDR x1, [x8, #0x30]        |  //  not_find_field!1:48
            // 0x016820C4: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? " graph types are avaliable", ????);
            // 0x016820C8: CBNZ x0, #0x16820d8        | if (" graph types are avaliable" != null) goto label_27;
            if(" graph types are avaliable" != null)
            {
                goto label_27;
            }
            // 0x016820CC: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? " graph types are avaliable", ????);
            // 0x016820D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016820D4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " graph types are avaliable", ????);
            label_27:
            // 0x016820D8: LDR w8, [x20, #0x18]       | W8 = System.Object[].__il2cppRuntimeField_namespaze;
            // 0x016820DC: LDR x19, [x19]             | X19 = " graph types are avaliable";     
            // 0x016820E0: CMP w8, #4                 | STATE = COMPARE(System.Object[].__il2cppRuntimeField_namespaze, 0x4)
            // 0x016820E4: B.HI #0x16820f4            | if (System.Object[].__il2cppRuntimeField_namespaze > 0x4) goto label_28;
            // 0x016820E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? " graph types are avaliable", ????);
            // 0x016820EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016820F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? " graph types are avaliable", ????);
            label_28:
            // 0x016820F4: STR x19, [x20, #0x40]      | typeof(System.Object[]).__il2cppRuntimeField_40 = " graph types are avaliable";  //  dest_result_addr=1152921504954501328
            typeof(System.Object[]).__il2cppRuntimeField_40 = " graph types are avaliable";
            // 0x016820F8: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x016820FC: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01682100: LDR x0, [x8]               | X0 = typeof(System.String);             
            // 0x01682104: LDRB w8, [x0, #0x10a]      | W8 = System.String.__il2cppRuntimeField_10A;
            // 0x01682108: TBZ w8, #0, #0x1682118     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_30;
            // 0x0168210C: LDR w8, [x0, #0xbc]        | W8 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01682110: CBNZ w8, #0x1682118        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_30;
            // 0x01682114: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_30:
            // 0x01682118: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168211C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01682120: MOV x1, x20                | X1 = 1152921504954501264 (0x1000000014B8C890);//ML01
            // 0x01682124: BL #0x18b07f0              | X0 = System.String.Concat(args:  0);    
            string val_3 = System.String.Concat(args:  0);
            // 0x01682128: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0168212C: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x01682130: MOV x19, x0                | X19 = val_3;//m1                        
            val_5 = val_3;
            // 0x01682134: LDR x8, [x8]               | X8 = typeof(UnityEngine.Debug);         
            // 0x01682138: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x0168213C: TBZ w9, #0, #0x1682150     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_32;
            // 0x01682140: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x01682144: CBNZ w9, #0x1682150        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_32;
            // 0x01682148: MOV x0, x8                 | X0 = 1152921504692469760 (0x10000000051A8000);//ML01
            // 0x0168214C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_32:
            // 0x01682150: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01682154: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01682158: MOV x1, x19                | X1 = val_3;//m1                         
            // 0x0168215C: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
            UnityEngine.Debug.LogError(message:  0);
            // 0x01682160: MOV x20, xzr               | X20 = 0 (0x0);//ML01                    
            val_7 = 0;
            label_11:
            // 0x01682164: MOV x0, x20                | X0 = 0 (0x0);//ML01                     
            // 0x01682168: SUB sp, x29, #0x30         | SP = (1152921513149882080 - 48) = 1152921513149882032 (0x10000001FD345EB0);
            // 0x0168216C: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01682170: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01682174: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01682178: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0168217C: RET                        |  return (Pathfinding.NavGraph)null;     
            return (Pathfinding.NavGraph)val_7;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01681B0C (23599884), len: 824  VirtAddr: 0x01681B0C RVA: 0x01681B0C token: 100681920 methodIndex: 49784 delegateWrapperIndex: 0 methodInvoker: 0
        public void AddGraph(Pathfinding.NavGraph graph)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            uint val_11;
            //  | 
            Pathfinding.NavGraph[] val_12;
            // 0x01681B0C: STP x24, x23, [sp, #-0x40]! | stack[1152921513150340672] = ???;  stack[1152921513150340680] = ???;  //  dest_result_addr=1152921513150340672 |  dest_result_addr=1152921513150340680
            // 0x01681B10: STP x22, x21, [sp, #0x10]  | stack[1152921513150340688] = ???;  stack[1152921513150340696] = ???;  //  dest_result_addr=1152921513150340688 |  dest_result_addr=1152921513150340696
            // 0x01681B14: STP x20, x19, [sp, #0x20]  | stack[1152921513150340704] = ???;  stack[1152921513150340712] = ???;  //  dest_result_addr=1152921513150340704 |  dest_result_addr=1152921513150340712
            // 0x01681B18: STP x29, x30, [sp, #0x30]  | stack[1152921513150340720] = ???;  stack[1152921513150340728] = ???;  //  dest_result_addr=1152921513150340720 |  dest_result_addr=1152921513150340728
            // 0x01681B1C: ADD x29, sp, #0x30         | X29 = (1152921513150340672 + 48) = 1152921513150340720 (0x10000001FD3B5E70);
            // 0x01681B20: SUB sp, sp, #0x10          | SP = (1152921513150340672 - 16) = 1152921513150340656 (0x10000001FD3B5E30);
            // 0x01681B24: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01681B28: LDRB w8, [x21, #0xc4]      | W8 = (bool)static_value_037380C4;       
            // 0x01681B2C: MOV x19, x1                | X19 = graph;//m1                        
            val_7 = graph;
            // 0x01681B30: MOV x20, x0                | X20 = 1152921513150352736 (0x10000001FD3B8D60);//ML01
            val_8 = this;
            // 0x01681B34: TBNZ w8, #0, #0x1681b50    | if (static_value_037380C4 == true) goto label_0;
            // 0x01681B38: ADRP x8, #0x366f000        | X8 = 57077760 (0x366F000);              
            // 0x01681B3C: LDR x8, [x8, #0x960]       | X8 = 0x2B8EBEC;                         
            // 0x01681B40: LDR w0, [x8]               | W0 = 0x11BB;                            
            // 0x01681B44: BL #0x2782188              | X0 = sub_2782188( ?? 0x11BB, ????);     
            // 0x01681B48: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01681B4C: STRB w8, [x21, #0xc4]      | static_value_037380C4 = true;            //  dest_result_addr=57901252
            label_0:
            // 0x01681B50: ADRP x21, #0x362c000       | X21 = 56803328 (0x362C000);             
            // 0x01681B54: LDR x21, [x21, #0xe80]     | X21 = 1152921504837996544;              
            // 0x01681B58: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            val_9 = null;
            // 0x01681B5C: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x01681B60: TBZ w8, #0, #0x1681b74     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01681B64: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x01681B68: CBNZ w8, #0x1681b74        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01681B6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x01681B70: LDR x0, [x21]              | X0 = typeof(AstarPath);                 
            val_9 = null;
            label_2:
            // 0x01681B74: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x01681B78: LDR x21, [x8, #0x18]       | X21 = AstarPath.active;                 
            // 0x01681B7C: CBNZ x21, #0x1681b84       | if (AstarPath.active != null) goto label_3;
            if(AstarPath.active != null)
            {
                goto label_3;
            }
            // 0x01681B80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AstarPath), ????);
            label_3:
            // 0x01681B84: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x01681B88: MOV x0, x21                | X0 = AstarPath.active;//m1              
            // 0x01681B8C: BL #0xb3a084               | AstarPath.active.BlockUntilPathQueueBlocked();
            AstarPath.active.BlockUntilPathQueueBlocked();
            // 0x01681B90: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_11 = 0;
            // 0x01681B94: B #0x1681b9c               |  goto label_4;                          
            goto label_4;
            label_9:
            // 0x01681B98: ADD w22, w22, #1           | W22 = (val_11 + 1) = val_11 (0x00000001);
            val_11 = 1;
            label_4:
            // 0x01681B9C: LDR x23, [x20, #0x38]      | X23 = this.graphs; //P2                 
            // 0x01681BA0: MOV x21, x23               | X21 = this.graphs;//m1                  
            val_12 = this.graphs;
            // 0x01681BA4: CBNZ x23, #0x1681bb0       | if (this.graphs != null) goto label_5;  
            if(this.graphs != null)
            {
                goto label_5;
            }
            // 0x01681BA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? AstarPath.active, ????);
            // 0x01681BAC: LDR x21, [x20, #0x38]      | X21 = this.graphs; //P2                 
            val_12 = this.graphs;
            label_5:
            // 0x01681BB0: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681BB4: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01681BB8: B.GE #0x1681c50            | if (val_11 >= this.graphs.Length) goto label_6;
            if(val_11 >= this.graphs.Length)
            {
                goto label_6;
            }
            // 0x01681BBC: CBNZ x21, #0x1681bc4       | if (this.graphs != null) goto label_7;  
            if(val_12 != null)
            {
                goto label_7;
            }
            // 0x01681BC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? AstarPath.active, ????);
            label_7:
            // 0x01681BC4: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681BC8: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x01681BCC: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01681BD0: B.LO #0x1681be0            | if (val_11 < this.graphs.Length) goto label_8;
            if(val_11 < this.graphs.Length)
            {
                goto label_8;
            }
            // 0x01681BD4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? AstarPath.active, ????);
            // 0x01681BD8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x01681BDC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? AstarPath.active, ????);
            label_8:
            // 0x01681BE0: ADD x8, x21, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01681BE4: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_7 = val_12[1];
            // 0x01681BE8: CBNZ x8, #0x1681b98        | if (this.graphs[0x1][0] != null) goto label_9;
            if(val_7 != null)
            {
                goto label_9;
            }
            // 0x01681BEC: LDR x21, [x20, #0x38]      | X21 = this.graphs; //P2                 
            // 0x01681BF0: CBNZ x21, #0x1681bf8       | if (this.graphs != null) goto label_10; 
            if(this.graphs != null)
            {
                goto label_10;
            }
            // 0x01681BF4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? AstarPath.active, ????);
            label_10:
            // 0x01681BF8: CBZ x19, #0x1681c1c        | if (graph == null) goto label_12;       
            if(val_7 == null)
            {
                goto label_12;
            }
            // 0x01681BFC: LDR x8, [x21]              | X8 = typeof(Pathfinding.NavGraph[]);    
            // 0x01681C00: MOV x0, x19                | X0 = graph;//m1                         
            // 0x01681C04: LDR x1, [x8, #0x30]        | X1 = Pathfinding.NavGraph[].__il2cppRuntimeField_element_class;
            // 0x01681C08: BL #0x27bc2e0              | X0 = sub_27BC2E0( ?? graph, ????);      
            // 0x01681C0C: CBNZ x0, #0x1681c1c        | if (graph != null) goto label_12;       
            if(val_7 != null)
            {
                goto label_12;
            }
            // 0x01681C10: BL #0x27af1e4              | X0 = sub_27AF1E4( ?? graph, ????);      
            // 0x01681C14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x01681C18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? graph, ????);      
            label_12:
            // 0x01681C1C: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681C20: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01681C24: B.LO #0x1681c34            | if (val_11 < this.graphs.Length) goto label_13;
            if(val_11 < this.graphs.Length)
            {
                goto label_13;
            }
            // 0x01681C28: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? graph, ????);      
            // 0x01681C2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            val_10 = 0;
            // 0x01681C30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? graph, ????);      
            label_13:
            // 0x01681C34: ADD x8, x21, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01681C38: STR x19, [x8, #0x20]       | this.graphs[0x1][0] = graph;             //  dest_result_addr=0
            this.graphs[1] = val_7;
            // 0x01681C3C: BL #0x167f8b4              | X0 = graph.get_active();                
            AstarPath val_1 = val_7.active;
            // 0x01681C40: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x01681C44: CBZ x19, #0x1681dfc        | if (graph == null) goto label_14;       
            if(val_7 == null)
            {
                goto label_14;
            }
            // 0x01681C48: STR x21, [x19, #0x18]      | graph.active = val_1;                    //  dest_result_addr=0
            graph.active = val_1;
            // 0x01681C4C: B #0x1681e0c               |  goto label_15;                         
            goto label_15;
            label_6:
            // 0x01681C50: CBZ x21, #0x1681d0c        | if (this.graphs == null) goto label_16; 
            if(val_12 == null)
            {
                goto label_16;
            }
            // 0x01681C54: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01681C58: CMP w8, #0xff              | STATE = COMPARE(this.graphs.Length, 0xFF)
            // 0x01681C5C: B.LT #0x1681d10            | if (this.graphs.Length < 255) goto label_17;
            if(this.graphs.Length < 255)
            {
                goto label_17;
            }
            // 0x01681C60: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x01681C64: LDR x8, [x8, #0xe18]       | X8 = 1152921504607645696;               
            // 0x01681C68: ADD x1, sp, #0xc           | X1 = (1152921513150340656 + 12) = 1152921513150340668 (0x10000001FD3B5E3C);
            // 0x01681C6C: LDR x0, [x8]               | X0 = typeof(System.UInt32);             
            // 0x01681C70: ORR w8, wzr, #0xff         | W8 = 255(0xFF);                         
            // 0x01681C74: STR w8, [sp, #0xc]         | stack[1152921513150340668] = 0xFF;       //  dest_result_addr=1152921513150340668
            // 0x01681C78: BL #0x27bc028              | X0 = 1152921513150507616 = (Il2CppObject*)Box((RuntimeClass*)typeof(System.UInt32), 0xFF);
            // 0x01681C7C: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x01681C80: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x01681C84: MOV x19, x0                | X19 = 1152921513150507616 (0x10000001FD3DEA60);//ML01
            // 0x01681C88: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x01681C8C: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x01681C90: TBZ w9, #0, #0x1681ca4     | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x01681C94: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x01681C98: CBNZ w9, #0x1681ca4        | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x01681C9C: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x01681CA0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_19:
            // 0x01681CA4: ADRP x8, #0x35e4000        | X8 = 56508416 (0x35E4000);              
            // 0x01681CA8: ADRP x9, #0x35c7000        | X9 = 56389632 (0x35C7000);              
            // 0x01681CAC: LDR x8, [x8, #0x6c8]       | X8 = (string**)(1152921513150281104)("Graph Count Limit Reached. You cannot have more than ");
            // 0x01681CB0: LDR x9, [x9, #0xb78]       | X9 = (string**)(1152921513150281280)(" graphs. Some compiler directives can change this limit, e.g ASTAR_MORE_AREAS, look under the \'Optimizations\' tab in the A* Inspector");
            // 0x01681CB4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01681CB8: MOV x4, xzr                | X4 = 0 (0x0);//ML01                     
            // 0x01681CBC: LDR x1, [x8]               | X1 = "Graph Count Limit Reached. You cannot have more than ";
            // 0x01681CC0: LDR x3, [x9]               | X3 = " graphs. Some compiler directives can change this limit, e.g ASTAR_MORE_AREAS, look under the \'Optimizations\' tab in the A* Inspector";
            // 0x01681CC4: MOV x2, x19                | X2 = 1152921513150507616 (0x10000001FD3DEA60);//ML01
            // 0x01681CC8: BL #0x18a8bac              | X0 = System.String.Concat(arg0:  0, arg1:  "Graph Count Limit Reached. You cannot have more than ", arg2:  255);
            string val_2 = System.String.Concat(arg0:  0, arg1:  "Graph Count Limit Reached. You cannot have more than ", arg2:  255);
            // 0x01681CCC: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x01681CD0: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x01681CD4: MOV x19, x0                | X19 = val_2;//m1                        
            val_7 = val_2;
            // 0x01681CD8: LDR x8, [x8]               | X8 = typeof(System.Exception);          
            // 0x01681CDC: MOV x0, x8                 | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            System.Exception val_3 = null;
            // 0x01681CE0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x01681CE4: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01681CE8: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x01681CEC: MOV x20, x0                | X20 = 1152921504609882112 (0x10000000002E5000);//ML01
            val_8 = val_3;
            // 0x01681CF0: BL #0x1c32b48              | .ctor(message:  val_7);                 
            val_3 = new System.Exception(message:  val_7);
            // 0x01681CF4: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x01681CF8: LDR x8, [x8, #0xd78]       | X8 = 1152921513150285728;               
            // 0x01681CFC: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x01681D00: LDR x1, [x8]               | X1 = public System.Void Pathfinding.AstarData::AddGraph(Pathfinding.NavGraph graph);
            // 0x01681D04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x01681D08: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
            label_16:
            // 0x01681D0C: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            val_12 = 0;
            label_17:
            // 0x01681D10: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x01681D14: LDR x8, [x8, #0x450]       | X8 = 1152921504616644608;               
            // 0x01681D18: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Pathfinding.NavGraph> val_4 = null;
            // 0x01681D1C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x01681D20: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
            // 0x01681D24: LDR x8, [x8, #0x5c8]       | X8 = 1152921513146581680;               
            // 0x01681D28: MOV x1, x21                | X1 = 0 (0x0);//ML01                     
            // 0x01681D2C: MOV x22, x0                | X22 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01681D30: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.NavGraph>::.ctor(System.Collections.Generic.IEnumerable<T> collection);
            // 0x01681D34: BL #0x25e9524              | .ctor(collection:  val_12);             
            val_4 = new System.Collections.Generic.List<Pathfinding.NavGraph>(collection:  val_12);
            // 0x01681D38: CBZ x22, #0x1681d58        | if ( == 0) goto label_20;               
            if(null == 0)
            {
                goto label_20;
            }
            // 0x01681D3C: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x01681D40: LDR x8, [x8, #0xf10]       | X8 = 1152921513150286752;               
            // 0x01681D44: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01681D48: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x01681D4C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.NavGraph>::Add(Pathfinding.NavGraph item);
            // 0x01681D50: BL #0x25ea480              | Add(item:  val_7);                      
            Add(item:  val_7);
            // 0x01681D54: B #0x1681d78               |  goto label_21;                         
            goto label_21;
            label_20:
            // 0x01681D58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(collection:  val_12), ????);
            // 0x01681D5C: ADRP x8, #0x3650000        | X8 = 56950784 (0x3650000);              
            // 0x01681D60: LDR x8, [x8, #0xf10]       | X8 = 1152921513150286752;               
            // 0x01681D64: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01681D68: MOV x1, x19                | X1 = val_2;//m1                         
            // 0x01681D6C: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Pathfinding.NavGraph>::Add(Pathfinding.NavGraph item);
            // 0x01681D70: BL #0x25ea480              | Add(item:  val_7);                      
            Add(item:  val_7);
            // 0x01681D74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_21:
            // 0x01681D78: ADRP x8, #0x367a000        | X8 = 57122816 (0x367A000);              
            // 0x01681D7C: LDR x8, [x8, #0xdc8]       | X8 = 1152921513146620592;               
            // 0x01681D80: MOV x0, x22                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x01681D84: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<Pathfinding.NavGraph>::ToArray();
            // 0x01681D88: BL #0x25ed474              | X0 = ToArray();                         
            T[] val_5 = ToArray();
            // 0x01681D8C: STR x0, [x20, #0x38]       | typeof(System.Exception).__il2cppRuntimeField_38 = val_5;  //  dest_result_addr=1152921504609882168
            typeof(System.Exception).__il2cppRuntimeField_38 = val_5;
            // 0x01681D90: MOV x0, x20                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x01681D94: BL #0x167fb58              | UpdateShortcuts();                      
            UpdateShortcuts();
            // 0x01681D98: BL #0x167f8b4              | X0 = get_active();                      
            AstarPath val_6 = active;
            // 0x01681D9C: MOV x21, x0                | X21 = val_6;//m1                        
            // 0x01681DA0: CBZ x19, #0x1681dac        | if (val_2 == null) goto label_22;       
            if(val_7 == null)
            {
                goto label_22;
            }
            // 0x01681DA4: STR x21, [x19, #0x18]      | mem2[0] = val_6;                         //  dest_result_addr=0
            mem2[0] = val_6;
            // 0x01681DA8: B #0x1681dbc               |  goto label_23;                         
            goto label_23;
            label_22:
            // 0x01681DAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            // 0x01681DB0: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x01681DB4: STR x21, [x8]              | mem[24] = val_6;                         //  dest_result_addr=24
            mem[24] = val_6;
            // 0x01681DB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
            label_23:
            // 0x01681DBC: LDR x8, [x19]              | X8 = typeof(System.String);             
            // 0x01681DC0: MOV x0, x19                | X0 = val_2;//m1                         
            // 0x01681DC4: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(System.String).__il2cppRuntimeField_1B0; X1 = typeof(System.String).__il2cppRuntimeField_1B8; //  | 
            // 0x01681DC8: BLR x9                     | X0 = typeof(System.String).__il2cppRuntimeField_1B0();
            // 0x01681DCC: LDR x20, [x20, #0x38]      | X20 = val_5;                            
            // 0x01681DD0: CBNZ x20, #0x1681dd8       | if (val_5 != 0) goto label_24;          
            if(typeof(System.Exception).__il2cppRuntimeField_38 != 0)
            {
                goto label_24;
            }
            // 0x01681DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_24:
            // 0x01681DD8: LDR w8, [x20, #0x18]       | W8 = val_5 + 24;                        
            var val_8 = val_5 + 24;
            // 0x01681DDC: SUB w8, w8, #1             | W8 = (val_5 + 24 - 1);                  
            val_8 = val_8 - 1;
            // 0x01681DE0: STR w8, [x19, #0x28]       | mem2[0] = (val_5 + 24 - 1);              //  dest_result_addr=0
            mem2[0] = val_8;
            // 0x01681DE4: SUB sp, x29, #0x30         | SP = (1152921513150340720 - 48) = 1152921513150340672 (0x10000001FD3B5E40);
            // 0x01681DE8: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01681DEC: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01681DF0: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01681DF4: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01681DF8: RET                        |  return;                                
            return;
            label_14:
            // 0x01681DFC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            // 0x01681E00: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x01681E04: STR x21, [x8]              | mem[24] = val_1;                         //  dest_result_addr=24
            mem[24] = val_1;
            // 0x01681E08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_15:
            // 0x01681E0C: LDR x8, [x19]              | X8 = typeof(Pathfinding.NavGraph);      
            // 0x01681E10: MOV x0, x19                | X0 = graph;//m1                         
            // 0x01681E14: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1B0; X1 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1B8; //  | 
            // 0x01681E18: BLR x9                     | X0 = typeof(Pathfinding.NavGraph).__il2cppRuntimeField_1B0();
            // 0x01681E1C: CBNZ x19, #0x1681e24       | if (graph != null) goto label_25;       
            if(val_7 != null)
            {
                goto label_25;
            }
            // 0x01681E20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? graph, ????);      
            label_25:
            // 0x01681E24: STR w22, [x19, #0x28]      | graph.graphIndex = 0x1;                  //  dest_result_addr=0
            graph.graphIndex = val_11;
            // 0x01681E28: MOV x0, x20                | X0 = 1152921513150352736 (0x10000001FD3B8D60);//ML01
            // 0x01681E2C: SUB sp, x29, #0x30         | SP = (1152921513150340720 - 48) = 1152921513150340672 (0x10000001FD3B5E40);
            // 0x01681E30: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x01681E34: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01681E38: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01681E3C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01681E40: B #0x167fb58               | this.UpdateShortcuts(); return;         
            this.UpdateShortcuts();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01682180 (23601536), len: 252  VirtAddr: 0x01682180 RVA: 0x01682180 token: 100681921 methodIndex: 49785 delegateWrapperIndex: 0 methodInvoker: 0
        public bool RemoveGraph(Pathfinding.NavGraph graph)
        {
            //
            // Disasemble & Code
            //  | 
            var val_1;
            //  | 
            var val_2;
            // 0x01682180: STP x24, x23, [sp, #-0x40]! | stack[1152921513150780352] = ???;  stack[1152921513150780360] = ???;  //  dest_result_addr=1152921513150780352 |  dest_result_addr=1152921513150780360
            // 0x01682184: STP x22, x21, [sp, #0x10]  | stack[1152921513150780368] = ???;  stack[1152921513150780376] = ???;  //  dest_result_addr=1152921513150780368 |  dest_result_addr=1152921513150780376
            // 0x01682188: STP x20, x19, [sp, #0x20]  | stack[1152921513150780384] = ???;  stack[1152921513150780392] = ???;  //  dest_result_addr=1152921513150780384 |  dest_result_addr=1152921513150780392
            // 0x0168218C: STP x29, x30, [sp, #0x30]  | stack[1152921513150780400] = ???;  stack[1152921513150780408] = ???;  //  dest_result_addr=1152921513150780400 |  dest_result_addr=1152921513150780408
            // 0x01682190: ADD x29, sp, #0x30         | X29 = (1152921513150780352 + 48) = 1152921513150780400 (0x10000001FD4213F0);
            // 0x01682194: MOV x20, x1                | X20 = graph;//m1                        
            // 0x01682198: MOV x19, x0                | X19 = 1152921513150792416 (0x10000001FD4242E0);//ML01
            // 0x0168219C: CBNZ x20, #0x16821a4       | if (graph != null) goto label_0;        
            if(graph != null)
            {
                goto label_0;
            }
            // 0x016821A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x016821A4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016821A8: MOV x0, x20                | X0 = graph;//m1                         
            // 0x016821AC: BL #0x155d894              | graph.SafeOnDestroy();                  
            graph.SafeOnDestroy();
            // 0x016821B0: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_1 = 0;
            // 0x016821B4: B #0x16821bc               |  goto label_1;                          
            goto label_1;
            label_6:
            // 0x016821B8: ADD w21, w21, #1           | W21 = (val_1 + 1) = val_1 (0x00000001); 
            val_1 = 1;
            label_1:
            // 0x016821BC: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            // 0x016821C0: CBNZ x22, #0x16821c8       | if (this.graphs != null) goto label_2;  
            if(this.graphs != null)
            {
                goto label_2;
            }
            // 0x016821C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? graph, ????);      
            label_2:
            // 0x016821C8: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016821CC: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016821D0: B.GE #0x168220c            | if (val_1 >= this.graphs.Length) goto label_3;
            if(val_1 >= this.graphs.Length)
            {
                goto label_3;
            }
            // 0x016821D4: LDR x22, [x19, #0x38]      | X22 = this.graphs; //P2                 
            // 0x016821D8: CBNZ x22, #0x16821e0       | if (this.graphs != null) goto label_4;  
            if(this.graphs != null)
            {
                goto label_4;
            }
            // 0x016821DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? graph, ????);      
            label_4:
            // 0x016821E0: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016821E4: SXTW x23, w21              | X23 = 1 (0x00000001);                   
            // 0x016821E8: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016821EC: B.LO #0x16821fc            | if (val_1 < this.graphs.Length) goto label_5;
            if(val_1 < this.graphs.Length)
            {
                goto label_5;
            }
            // 0x016821F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? graph, ????);      
            // 0x016821F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016821F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? graph, ????);      
            label_5:
            // 0x016821FC: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01682200: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_1 = this.graphs[1];
            // 0x01682204: CMP x8, x20                | STATE = COMPARE(this.graphs[0x1][0], graph)
            // 0x01682208: B.NE #0x16821b8            | if (this.graphs[1] != graph) goto label_6;
            if(val_1 != graph)
            {
                goto label_6;
            }
            label_3:
            // 0x0168220C: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x01682210: CBNZ x20, #0x1682218       | if (this.graphs != null) goto label_7;  
            if(this.graphs != null)
            {
                goto label_7;
            }
            // 0x01682214: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? graph, ????);      
            label_7:
            // 0x01682218: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168221C: CMP w8, w21                | STATE = COMPARE(this.graphs.Length, 0x1)
            // 0x01682220: B.NE #0x168222c            | if (this.graphs.Length != val_1) goto label_8;
            if(this.graphs.Length != val_1)
            {
                goto label_8;
            }
            // 0x01682224: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_2 = 0;
            // 0x01682228: B #0x1682268               |  goto label_9;                          
            goto label_9;
            label_8:
            // 0x0168222C: LDR x20, [x19, #0x38]      | X20 = this.graphs; //P2                 
            // 0x01682230: CBNZ x20, #0x1682238       | if (this.graphs != null) goto label_10; 
            if(this.graphs != null)
            {
                goto label_10;
            }
            // 0x01682234: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? graph, ????);      
            label_10:
            // 0x01682238: LDR w8, [x20, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168223C: SXTW x22, w21              | X22 = 1 (0x00000001);                   
            // 0x01682240: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01682244: B.LO #0x1682254            | if (val_1 < this.graphs.Length) goto label_11;
            if(val_1 < this.graphs.Length)
            {
                goto label_11;
            }
            // 0x01682248: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? graph, ????);      
            // 0x0168224C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682250: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? graph, ????);      
            label_11:
            // 0x01682254: ADD x8, x20, x22, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01682258: MOV x0, x19                | X0 = 1152921513150792416 (0x10000001FD4242E0);//ML01
            // 0x0168225C: STR xzr, [x8, #0x20]       | this.graphs[0x1][0] = null;              //  dest_result_addr=0
            this.graphs[1] = 0;
            // 0x01682260: BL #0x167fb58              | this.UpdateShortcuts();                 
            this.UpdateShortcuts();
            // 0x01682264: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_2 = 1;
            label_9:
            // 0x01682268: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0168226C: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x01682270: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01682274: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01682278: RET                        |  return (System.Boolean)true;           
            return (bool)val_2;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168227C (23601788), len: 256  VirtAddr: 0x0168227C RVA: 0x0168227C token: 100681922 methodIndex: 49786 delegateWrapperIndex: 0 methodInvoker: 0
        public static Pathfinding.NavGraph GetGraph(Pathfinding.GraphNode node)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            // 0x0168227C: STP x20, x19, [sp, #-0x20]! | stack[1152921513151052128] = ???;  stack[1152921513151052136] = ???;  //  dest_result_addr=1152921513151052128 |  dest_result_addr=1152921513151052136
            // 0x01682280: STP x29, x30, [sp, #0x10]  | stack[1152921513151052144] = ???;  stack[1152921513151052152] = ???;  //  dest_result_addr=1152921513151052144 |  dest_result_addr=1152921513151052152
            // 0x01682284: ADD x29, sp, #0x10         | X29 = (1152921513151052128 + 16) = 1152921513151052144 (0x10000001FD463970);
            // 0x01682288: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168228C: LDRB w8, [x20, #0xc5]      | W8 = (bool)static_value_037380C5;       
            // 0x01682290: MOV x19, x1                | X19 = X1;//m1                           
            val_4 = X1;
            // 0x01682294: TBNZ w8, #0, #0x16822b0    | if (static_value_037380C5 == true) goto label_0;
            // 0x01682298: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x0168229C: LDR x8, [x8, #0x1f8]       | X8 = 0x2B8EC20;                         
            // 0x016822A0: LDR w0, [x8]               | W0 = 0x11C8;                            
            // 0x016822A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C8, ????);     
            // 0x016822A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016822AC: STRB w8, [x20, #0xc5]      | static_value_037380C5 = true;            //  dest_result_addr=57901253
            label_0:
            // 0x016822B0: CBZ x19, #0x168236c        | if (X1 == 0) goto label_10;             
            if(val_4 == 0)
            {
                goto label_10;
            }
            // 0x016822B4: ADRP x20, #0x362c000       | X20 = 56803328 (0x362C000);             
            // 0x016822B8: LDR x20, [x20, #0xe80]     | X20 = 1152921504837996544;              
            // 0x016822BC: LDR x0, [x20]              | X0 = typeof(AstarPath);                 
            val_5 = null;
            // 0x016822C0: LDRB w8, [x0, #0x10a]      | W8 = AstarPath.__il2cppRuntimeField_10A;
            // 0x016822C4: TBZ w8, #0, #0x16822d8     | if (AstarPath.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x016822C8: LDR w8, [x0, #0xbc]        | W8 = AstarPath.__il2cppRuntimeField_cctor_finished;
            // 0x016822CC: CBNZ w8, #0x16822d8        | if (AstarPath.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x016822D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AstarPath), ????);
            // 0x016822D4: LDR x0, [x20]              | X0 = typeof(AstarPath);                 
            val_5 = null;
            label_3:
            // 0x016822D8: ADRP x9, #0x35fe000        | X9 = 56614912 (0x35FE000);              
            // 0x016822DC: LDR x8, [x0, #0xa0]        | X8 = AstarPath.__il2cppRuntimeField_static_fields;
            // 0x016822E0: LDR x9, [x9, #0x810]       | X9 = 1152921504697475072;               
            // 0x016822E4: LDR x20, [x8, #0x18]       | X20 = AstarPath.active;                 
            // 0x016822E8: LDR x0, [x9]               | X0 = typeof(UnityEngine.Object);        
            // 0x016822EC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Object.__il2cppRuntimeField_10A;
            // 0x016822F0: TBZ w8, #0, #0x1682300     | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x016822F4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
            // 0x016822F8: CBNZ w8, #0x1682300        | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x016822FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
            label_5:
            // 0x01682300: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01682304: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01682308: MOV x1, x20                | X1 = AstarPath.active;//m1              
            // 0x0168230C: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x01682310: BL #0x1b77a00              | X0 = UnityEngine.Object.op_Equality(x:  0, y:  AstarPath.active);
            bool val_1 = UnityEngine.Object.op_Equality(x:  0, y:  AstarPath.active);
            // 0x01682314: MOV w8, w0                 | W8 = val_1;//m1                         
            // 0x01682318: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            // 0x0168231C: AND w8, w8, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x01682320: TBNZ w8, #0, #0x1682370    | if ((val_1 & 1) == true) goto label_12; 
            if(val_2 == true)
            {
                goto label_12;
            }
            // 0x01682324: CBNZ x20, #0x168232c       | if (AstarPath.active != null) goto label_7;
            if(AstarPath.active != null)
            {
                goto label_7;
            }
            // 0x01682328: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
            label_7:
            // 0x0168232C: LDR x8, [x20, #0x18]       | X8 = AstarPath.active.astarData;        
            // 0x01682330: CBZ x8, #0x168236c         | if ( == 0) goto label_10;               
            if(null == 0)
            {
                goto label_10;
            }
            // 0x01682334: LDR x20, [x8, #0x38]       | X20 = Pathfinding.AstarData.__il2cppRuntimeField_castClass;
            // 0x01682338: CBZ x20, #0x168236c        | if (Pathfinding.AstarData.__il2cppRuntimeField_castClass == 0) goto label_10;
            // 0x0168233C: LDR x8, [x20, #0x18]       | X8 = Pathfinding.AstarData.__il2cppRuntimeField_castClass + 24; //  not_find_field!2:24
            // 0x01682340: LDRB w19, [x19, #0x17]     | W19 = X1 + 23;                          
            val_4 = mem[X1 + 23];
            val_4 = X1 + 23;
            // 0x01682344: CMP x19, w8, sxtw          | STATE = COMPARE(X1 + 23, (Pathfinding.AstarData.__il2cppRuntimeField_castClass + 24) << )
            // 0x01682348: B.GE #0x168236c            | if (val_4 >= (Pathfinding.AstarData.__il2cppRuntimeField_castClass + 24) << ) goto label_10;
            // 0x0168234C: CMP w19, w8                | STATE = COMPARE(X1 + 23, Pathfinding.AstarData.__il2cppRuntimeField_castClass + 24)
            // 0x01682350: B.LO #0x1682360            | if (val_4 < Pathfinding.AstarData.__il2cppRuntimeField_castClass + 24) goto label_11;
            // 0x01682354: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
            // 0x01682358: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168235C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_11:
            // 0x01682360: ADD x8, x20, x19, lsl #3   | X8 = (Pathfinding.AstarData.__il2cppRuntimeField_castClass + (X1 + 23) << 3);
            // 0x01682364: LDR x0, [x8, #0x20]        | X0 = (Pathfinding.AstarData.__il2cppRuntimeField_castClass + (X1 + 23) << 3) + 32; //  not_find_field!2:32
            val_6 = mem[(Pathfinding.AstarData.__il2cppRuntimeField_castClass + (X1 + 23) << 3) + 32];
            val_6 = (Pathfinding.AstarData.__il2cppRuntimeField_castClass + (X1 + 23) << 3) + 32;
            // 0x01682368: B #0x1682370               |  goto label_12;                         
            goto label_12;
            label_10:
            // 0x0168236C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_12:
            // 0x01682370: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01682374: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01682378: RET                        |  return (Pathfinding.NavGraph)null;     
            return (Pathfinding.NavGraph)val_6;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01682384 (23602052), len: 100  VirtAddr: 0x01682384 RVA: 0x01682384 token: 100681923 methodIndex: 49787 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.GraphNode GetNode(int graphIndex, int nodeIndex)
        {
            //
            // Disasemble & Code
            // 0x01682384: STP x20, x19, [sp, #-0x20]! | stack[1152921513151169248] = ???;  stack[1152921513151169256] = ???;  //  dest_result_addr=1152921513151169248 |  dest_result_addr=1152921513151169256
            // 0x01682388: STP x29, x30, [sp, #0x10]  | stack[1152921513151169264] = ???;  stack[1152921513151169272] = ???;  //  dest_result_addr=1152921513151169264 |  dest_result_addr=1152921513151169272
            // 0x0168238C: ADD x29, sp, #0x10         | X29 = (1152921513151169248 + 16) = 1152921513151169264 (0x10000001FD4802F0);
            // 0x01682390: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01682394: LDRB w8, [x19, #0xc6]      | W8 = (bool)static_value_037380C6;       
            // 0x01682398: TBNZ w8, #0, #0x16823b4    | if (static_value_037380C6 == true) goto label_0;
            // 0x0168239C: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x016823A0: LDR x8, [x8, #0x870]       | X8 = 0x2B8EC2C;                         
            // 0x016823A4: LDR w0, [x8]               | W0 = 0x11CB;                            
            // 0x016823A8: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CB, ????);     
            // 0x016823AC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016823B0: STRB w8, [x19, #0xc6]      | static_value_037380C6 = true;            //  dest_result_addr=57901254
            label_0:
            // 0x016823B4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x016823B8: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x016823BC: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_1 = null;
            // 0x016823C0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x016823C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016823C8: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x016823CC: BL #0x17014c0              | .ctor();                                
            val_1 = new System.NotImplementedException();
            // 0x016823D0: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x016823D4: LDR x8, [x8, #0x358]       | X8 = 1152921513151156256;               
            // 0x016823D8: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x016823DC: LDR x1, [x8]               | X1 = public Pathfinding.GraphNode Pathfinding.AstarData::GetNode(int graphIndex, int nodeIndex, Pathfinding.NavGraph[] graphs);
            // 0x016823E0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x016823E4: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x016823E8 (23602152), len: 100  VirtAddr: 0x016823E8 RVA: 0x016823E8 token: 100681924 methodIndex: 49788 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.GraphNode GetNode(int graphIndex, int nodeIndex, Pathfinding.NavGraph[] graphs)
        {
            //
            // Disasemble & Code
            // 0x016823E8: STP x20, x19, [sp, #-0x20]! | stack[1152921513151318112] = ???;  stack[1152921513151318120] = ???;  //  dest_result_addr=1152921513151318112 |  dest_result_addr=1152921513151318120
            // 0x016823EC: STP x29, x30, [sp, #0x10]  | stack[1152921513151318128] = ???;  stack[1152921513151318136] = ???;  //  dest_result_addr=1152921513151318128 |  dest_result_addr=1152921513151318136
            // 0x016823F0: ADD x29, sp, #0x10         | X29 = (1152921513151318112 + 16) = 1152921513151318128 (0x10000001FD4A4870);
            // 0x016823F4: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x016823F8: LDRB w8, [x19, #0xc6]      | W8 = (bool)static_value_037380C6;       
            // 0x016823FC: TBNZ w8, #0, #0x1682418    | if (static_value_037380C6 == true) goto label_0;
            // 0x01682400: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x01682404: LDR x8, [x8, #0x870]       | X8 = 0x2B8EC2C;                         
            // 0x01682408: LDR w0, [x8]               | W0 = 0x11CB;                            
            // 0x0168240C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CB, ????);     
            // 0x01682410: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01682414: STRB w8, [x19, #0xc6]      | static_value_037380C6 = true;            //  dest_result_addr=57901254
            label_0:
            // 0x01682418: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x0168241C: LDR x8, [x8, #0x320]       | X8 = 1152921504655355904;               
            // 0x01682420: LDR x0, [x8]               | X0 = typeof(System.NotImplementedException);
            System.NotImplementedException val_1 = null;
            // 0x01682424: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.NotImplementedException), ????);
            // 0x01682428: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168242C: MOV x19, x0                | X19 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x01682430: BL #0x17014c0              | .ctor();                                
            val_1 = new System.NotImplementedException();
            // 0x01682434: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x01682438: LDR x8, [x8, #0x358]       | X8 = 1152921513151156256;               
            // 0x0168243C: MOV x0, x19                | X0 = 1152921504655355904 (0x1000000002E43000);//ML01
            // 0x01682440: LDR x1, [x8]               | X1 = public Pathfinding.GraphNode Pathfinding.AstarData::GetNode(int graphIndex, int nodeIndex, Pathfinding.NavGraph[] graphs);
            // 0x01682444: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.NotImplementedException), ????);
            // 0x01682448: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x0167FE3C (23592508), len: 284  VirtAddr: 0x0167FE3C RVA: 0x0167FE3C token: 100681925 methodIndex: 49789 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph FindGraphOfType(System.Type type)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_3;
            //  | 
            Pathfinding.NavGraph[] val_4;
            //  | 
            var val_5;
            //  | 
            Pathfinding.NavGraph val_6;
            // 0x0167FE3C: STP x24, x23, [sp, #-0x40]! | stack[1152921513151671744] = ???;  stack[1152921513151671752] = ???;  //  dest_result_addr=1152921513151671744 |  dest_result_addr=1152921513151671752
            // 0x0167FE40: STP x22, x21, [sp, #0x10]  | stack[1152921513151671760] = ???;  stack[1152921513151671768] = ???;  //  dest_result_addr=1152921513151671760 |  dest_result_addr=1152921513151671768
            // 0x0167FE44: STP x20, x19, [sp, #0x20]  | stack[1152921513151671776] = ???;  stack[1152921513151671784] = ???;  //  dest_result_addr=1152921513151671776 |  dest_result_addr=1152921513151671784
            // 0x0167FE48: STP x29, x30, [sp, #0x30]  | stack[1152921513151671792] = ???;  stack[1152921513151671800] = ???;  //  dest_result_addr=1152921513151671792 |  dest_result_addr=1152921513151671800
            // 0x0167FE4C: ADD x29, sp, #0x30         | X29 = (1152921513151671744 + 48) = 1152921513151671792 (0x10000001FD4FADF0);
            // 0x0167FE50: MOV x19, x0                | X19 = 1152921513151683808 (0x10000001FD4FDCE0);//ML01
            val_3 = this;
            // 0x0167FE54: LDR x21, [x19, #0x38]      | X21 = this.graphs; //P2                 
            val_4 = this.graphs;
            // 0x0167FE58: MOV x20, x1                | X20 = type;//m1                         
            // 0x0167FE5C: CBZ x21, #0x167ff40        | if (this.graphs == null) goto label_3;  
            if(val_4 == null)
            {
                goto label_3;
            }
            // 0x0167FE60: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x0167FE64: B #0x167fe70               |  goto label_1;                          
            goto label_1;
            label_10:
            // 0x0167FE68: LDR x21, [x19, #0x38]      | X21 = this.graphs; //P2                 
            val_4 = this.graphs;
            // 0x0167FE6C: ADD w22, w22, #1           | W22 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_1:
            // 0x0167FE70: CBNZ x21, #0x167fe78       | if (this.graphs != null) goto label_2;  
            if(val_4 != null)
            {
                goto label_2;
            }
            // 0x0167FE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_2:
            // 0x0167FE78: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0167FE7C: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0167FE80: B.GE #0x167ff40            | if (val_5 >= this.graphs.Length) goto label_3;
            if(val_5 >= this.graphs.Length)
            {
                goto label_3;
            }
            // 0x0167FE84: LDR x21, [x19, #0x38]      | X21 = this.graphs; //P2                 
            // 0x0167FE88: CBNZ x21, #0x167fe90       | if (this.graphs != null) goto label_4;  
            if(this.graphs != null)
            {
                goto label_4;
            }
            // 0x0167FE8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_4:
            // 0x0167FE90: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0167FE94: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x0167FE98: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0167FE9C: B.LO #0x167feac            | if (val_5 < this.graphs.Length) goto label_5;
            if(val_5 < this.graphs.Length)
            {
                goto label_5;
            }
            // 0x0167FEA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0167FEA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FEA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_5:
            // 0x0167FEAC: ADD x8, x21, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x0167FEB0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_3 = this.graphs[1];
            // 0x0167FEB4: CBZ x8, #0x167fe68         | if (this.graphs[0x1][0] == null) goto label_10;
            if(val_3 == null)
            {
                goto label_10;
            }
            // 0x0167FEB8: LDR x21, [x19, #0x38]      | X21 = this.graphs; //P2                 
            // 0x0167FEBC: CBNZ x21, #0x167fec4       | if (this.graphs != null) goto label_7;  
            if(this.graphs != null)
            {
                goto label_7;
            }
            // 0x0167FEC0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_7:
            // 0x0167FEC4: LDR w8, [x21, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0167FEC8: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0167FECC: B.LO #0x167fedc            | if (val_5 < this.graphs.Length) goto label_8;
            if(val_5 < this.graphs.Length)
            {
                goto label_8;
            }
            // 0x0167FED0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x0167FED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FED8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_8:
            // 0x0167FEDC: ADD x8, x21, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x0167FEE0: LDR x21, [x8, #0x20]       | X21 = this.graphs[0x1][0]               
            val_4 = this.graphs[1];
            // 0x0167FEE4: CBNZ x21, #0x167feec       | if (this.graphs[0x1][0] != null) goto label_9;
            if(val_4 != null)
            {
                goto label_9;
            }
            // 0x0167FEE8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_9:
            // 0x0167FEEC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FEF0: MOV x0, x21                | X0 = this.graphs[0x1][0];//m1           
            // 0x0167FEF4: BL #0x16fb28c              | X0 = this.graphs[0x1][0].GetType();     
            System.Type val_1 = val_4.GetType();
            // 0x0167FEF8: MOV x1, x0                 | X1 = val_1;//m1                         
            // 0x0167FEFC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0167FF00: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x0167FF04: MOV x2, x20                | X2 = type;//m1                          
            // 0x0167FF08: BL #0x1708de4              | X0 = System.Object.Equals(objA:  0, objB:  val_1);
            bool val_2 = System.Object.Equals(objA:  0, objB:  val_1);
            // 0x0167FF0C: TBZ w0, #0, #0x167fe68     | if (val_2 == false) goto label_10;      
            if(val_2 == false)
            {
                goto label_10;
            }
            // 0x0167FF10: LDR x19, [x19, #0x38]      | X19 = this.graphs; //P2                 
            val_3 = this.graphs;
            // 0x0167FF14: CBNZ x19, #0x167ff1c       | if (this.graphs != null) goto label_11; 
            if(val_3 != null)
            {
                goto label_11;
            }
            // 0x0167FF18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_11:
            // 0x0167FF1C: LDR w8, [x19, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0167FF20: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0167FF24: B.LO #0x167ff34            | if (val_5 < this.graphs.Length) goto label_12;
            if(val_5 < this.graphs.Length)
            {
                goto label_12;
            }
            // 0x0167FF28: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x0167FF2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0167FF30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_12:
            // 0x0167FF34: ADD x8, x19, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x0167FF38: LDR x0, [x8, #0x20]        | X0 = this.graphs[0x1][0]                
            val_6 = val_3[1];
            // 0x0167FF3C: B #0x167ff44               |  goto label_13;                         
            goto label_13;
            label_3:
            // 0x0167FF40: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_13:
            // 0x0167FF44: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x0167FF48: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x0167FF4C: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x0167FF50: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x0167FF54: RET                        |  return (Pathfinding.NavGraph)null;     
            return (Pathfinding.NavGraph)val_6;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168244C (23602252), len: 156  VirtAddr: 0x0168244C RVA: 0x0168244C token: 100681926 methodIndex: 49790 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.DebuggerHiddenAttribute] // 0x285A3D4
        public System.Collections.IEnumerable FindGraphsOfType(System.Type type)
        {
            //
            // Disasemble & Code
            // 0x0168244C: STP x22, x21, [sp, #-0x30]! | stack[1152921513151992656] = ???;  stack[1152921513151992664] = ???;  //  dest_result_addr=1152921513151992656 |  dest_result_addr=1152921513151992664
            // 0x01682450: STP x20, x19, [sp, #0x10]  | stack[1152921513151992672] = ???;  stack[1152921513151992680] = ???;  //  dest_result_addr=1152921513151992672 |  dest_result_addr=1152921513151992680
            // 0x01682454: STP x29, x30, [sp, #0x20]  | stack[1152921513151992688] = ???;  stack[1152921513151992696] = ???;  //  dest_result_addr=1152921513151992688 |  dest_result_addr=1152921513151992696
            // 0x01682458: ADD x29, sp, #0x20         | X29 = (1152921513151992656 + 32) = 1152921513151992688 (0x10000001FD549370);
            // 0x0168245C: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01682460: LDRB w8, [x21, #0xc7]      | W8 = (bool)static_value_037380C7;       
            // 0x01682464: MOV x20, x1                | X20 = type;//m1                         
            // 0x01682468: MOV x19, x0                | X19 = 1152921513152004704 (0x10000001FD54C260);//ML01
            // 0x0168246C: TBNZ w8, #0, #0x1682488    | if (static_value_037380C7 == true) goto label_0;
            // 0x01682470: ADRP x8, #0x3637000        | X8 = 56848384 (0x3637000);              
            // 0x01682474: LDR x8, [x8, #0x368]       | X8 = 0x2B8EC14;                         
            // 0x01682478: LDR w0, [x8]               | W0 = 0x11C5;                            
            // 0x0168247C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C5, ????);     
            // 0x01682480: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01682484: STRB w8, [x21, #0xc7]      | static_value_037380C7 = true;            //  dest_result_addr=57901255
            label_0:
            // 0x01682488: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x0168248C: LDR x8, [x8, #0x2d8]       | X8 = 1152921504837677056;               
            // 0x01682490: LDR x0, [x8]               | X0 = typeof(AstarData.<FindGraphsOfType>c__Iterator0);
            object val_1 = null;
            // 0x01682494: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarData.<FindGraphsOfType>c__Iterator0), ????);
            // 0x01682498: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168249C: MOV x21, x0                | X21 = 1152921504837677056 (0x100000000DC23000);//ML01
            // 0x016824A0: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x016824A4: CBZ x21, #0x16824b0        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x016824A8: STP x20, x19, [x21, #0x18] | typeof(AstarData.<FindGraphsOfType>c__Iterator0).__il2cppRuntimeField_18 = type;  typeof(AstarData.<FindGraphsOfType>c__Iterator0).__il2cppRuntimeField_20 = this;  //  dest_result_addr=1152921504837677080 |  dest_result_addr=1152921504837677088
            typeof(AstarData.<FindGraphsOfType>c__Iterator0).__il2cppRuntimeField_18 = type;
            typeof(AstarData.<FindGraphsOfType>c__Iterator0).__il2cppRuntimeField_20 = this;
            // 0x016824AC: B #0x16824cc               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x016824B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x016824B4: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x016824B8: STR x20, [x8]              | mem[24] = type;                          //  dest_result_addr=24
            mem[24] = type;
            // 0x016824BC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x016824C0: ORR w8, wzr, #0x20         | W8 = 32(0x20);                          
            // 0x016824C4: STR x19, [x8]              | mem[32] = this;                          //  dest_result_addr=32
            mem[32] = this;
            // 0x016824C8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x016824CC: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            // 0x016824D0: STR w8, [x21, #0x34]       | typeof(AstarData.<FindGraphsOfType>c__Iterator0).__il2cppRuntimeField_34 = 0xFFFFFFFFFFFFFFFE;  //  dest_result_addr=1152921504837677108
            typeof(AstarData.<FindGraphsOfType>c__Iterator0).__il2cppRuntimeField_34 = -2;
            // 0x016824D4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x016824D8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x016824DC: MOV x0, x21                | X0 = 1152921504837677056 (0x100000000DC23000);//ML01
            // 0x016824E0: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x016824E4: RET                        |  return (System.Collections.IEnumerable)typeof(AstarData.<FindGraphsOfType>c__Iterator0);
            return (System.Collections.IEnumerable)val_1;
            //  |  // // {name=val_0, type=System.Collections.IEnumerable, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x016824F0 (23602416), len: 132  VirtAddr: 0x016824F0 RVA: 0x016824F0 token: 100681927 methodIndex: 49791 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.DebuggerHiddenAttribute] // 0x285A3E4
        public System.Collections.IEnumerable GetUpdateableGraphs()
        {
            //
            // Disasemble & Code
            // 0x016824F0: STP x20, x19, [sp, #-0x20]! | stack[1152921513152108768] = ???;  stack[1152921513152108776] = ???;  //  dest_result_addr=1152921513152108768 |  dest_result_addr=1152921513152108776
            // 0x016824F4: STP x29, x30, [sp, #0x10]  | stack[1152921513152108784] = ???;  stack[1152921513152108792] = ???;  //  dest_result_addr=1152921513152108784 |  dest_result_addr=1152921513152108792
            // 0x016824F8: ADD x29, sp, #0x10         | X29 = (1152921513152108768 + 16) = 1152921513152108784 (0x10000001FD5658F0);
            // 0x016824FC: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x01682500: LDRB w8, [x20, #0xc8]      | W8 = (bool)static_value_037380C8;       
            // 0x01682504: MOV x19, x0                | X19 = 1152921513152120800 (0x10000001FD5687E0);//ML01
            // 0x01682508: TBNZ w8, #0, #0x1682524    | if (static_value_037380C8 == true) goto label_0;
            // 0x0168250C: ADRP x8, #0x360a000        | X8 = 56664064 (0x360A000);              
            // 0x01682510: LDR x8, [x8, #0xd30]       | X8 = 0x2B8EC34;                         
            // 0x01682514: LDR w0, [x8]               | W0 = 0x11CD;                            
            // 0x01682518: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CD, ????);     
            // 0x0168251C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01682520: STRB w8, [x20, #0xc8]      | static_value_037380C8 = true;            //  dest_result_addr=57901256
            label_0:
            // 0x01682524: ADRP x8, #0x363d000        | X8 = 56872960 (0x363D000);              
            // 0x01682528: LDR x8, [x8, #0x928]       | X8 = 1152921504837730304;               
            // 0x0168252C: LDR x0, [x8]               | X0 = typeof(AstarData.<GetUpdateableGraphs>c__Iterator1);
            object val_1 = null;
            // 0x01682530: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarData.<GetUpdateableGraphs>c__Iterator1), ????);
            // 0x01682534: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682538: MOV x20, x0                | X20 = 1152921504837730304 (0x100000000DC30000);//ML01
            // 0x0168253C: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x01682540: CBZ x20, #0x168254c        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x01682544: STR x19, [x20, #0x18]      | typeof(AstarData.<GetUpdateableGraphs>c__Iterator1).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504837730328
            typeof(AstarData.<GetUpdateableGraphs>c__Iterator1).__il2cppRuntimeField_18 = this;
            // 0x01682548: B #0x168255c               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x0168254C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x01682550: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x01682554: STR x19, [x8]              | mem[24] = this;                          //  dest_result_addr=24
            mem[24] = this;
            // 0x01682558: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x0168255C: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            // 0x01682560: STR w8, [x20, #0x2c]       | typeof(AstarData.<GetUpdateableGraphs>c__Iterator1).__il2cppRuntimeField_2C = 0xFFFFFFFFFFFFFFFE;  //  dest_result_addr=1152921504837730348
            typeof(AstarData.<GetUpdateableGraphs>c__Iterator1).__il2cppRuntimeField_2C = -2;
            // 0x01682564: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x01682568: MOV x0, x20                | X0 = 1152921504837730304 (0x100000000DC30000);//ML01
            // 0x0168256C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x01682570: RET                        |  return (System.Collections.IEnumerable)typeof(AstarData.<GetUpdateableGraphs>c__Iterator1);
            return (System.Collections.IEnumerable)val_1;
            //  |  // // {name=val_0, type=System.Collections.IEnumerable, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x0168257C (23602556), len: 132  VirtAddr: 0x0168257C RVA: 0x0168257C token: 100681928 methodIndex: 49792 delegateWrapperIndex: 0 methodInvoker: 0
        [System.Diagnostics.DebuggerHiddenAttribute] // 0x285A3F4
        public System.Collections.IEnumerable GetRaycastableGraphs()
        {
            //
            // Disasemble & Code
            // 0x0168257C: STP x20, x19, [sp, #-0x20]! | stack[1152921513152220768] = ???;  stack[1152921513152220776] = ???;  //  dest_result_addr=1152921513152220768 |  dest_result_addr=1152921513152220776
            // 0x01682580: STP x29, x30, [sp, #0x10]  | stack[1152921513152220784] = ???;  stack[1152921513152220792] = ???;  //  dest_result_addr=1152921513152220784 |  dest_result_addr=1152921513152220792
            // 0x01682584: ADD x29, sp, #0x10         | X29 = (1152921513152220768 + 16) = 1152921513152220784 (0x10000001FD580E70);
            // 0x01682588: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x0168258C: LDRB w8, [x20, #0xc9]      | W8 = (bool)static_value_037380C9;       
            // 0x01682590: MOV x19, x0                | X19 = 1152921513152232800 (0x10000001FD583D60);//ML01
            // 0x01682594: TBNZ w8, #0, #0x16825b0    | if (static_value_037380C9 == true) goto label_0;
            // 0x01682598: ADRP x8, #0x35df000        | X8 = 56487936 (0x35DF000);              
            // 0x0168259C: LDR x8, [x8, #0xaa8]       | X8 = 0x2B8EC30;                         
            // 0x016825A0: LDR w0, [x8]               | W0 = 0x11CC;                            
            // 0x016825A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CC, ????);     
            // 0x016825A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016825AC: STRB w8, [x20, #0xc9]      | static_value_037380C9 = true;            //  dest_result_addr=57901257
            label_0:
            // 0x016825B0: ADRP x8, #0x35b9000        | X8 = 56332288 (0x35B9000);              
            // 0x016825B4: LDR x8, [x8, #0x5d8]       | X8 = 1152921504837783552;               
            // 0x016825B8: LDR x0, [x8]               | X0 = typeof(AstarData.<GetRaycastableGraphs>c__Iterator2);
            object val_1 = null;
            // 0x016825BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AstarData.<GetRaycastableGraphs>c__Iterator2), ????);
            // 0x016825C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016825C4: MOV x20, x0                | X20 = 1152921504837783552 (0x100000000DC3D000);//ML01
            // 0x016825C8: BL #0x16f59f0              | .ctor();                                
            val_1 = new System.Object();
            // 0x016825CC: CBZ x20, #0x16825d8        | if ( == 0) goto label_1;                
            if(null == 0)
            {
                goto label_1;
            }
            // 0x016825D0: STR x19, [x20, #0x18]      | typeof(AstarData.<GetRaycastableGraphs>c__Iterator2).__il2cppRuntimeField_18 = this;  //  dest_result_addr=1152921504837783576
            typeof(AstarData.<GetRaycastableGraphs>c__Iterator2).__il2cppRuntimeField_18 = this;
            // 0x016825D4: B #0x16825e8               |  goto label_2;                          
            goto label_2;
            label_1:
            // 0x016825D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            // 0x016825DC: ORR w8, wzr, #0x18         | W8 = 24(0x18);                          
            // 0x016825E0: STR x19, [x8]              | mem[24] = this;                          //  dest_result_addr=24
            mem[24] = this;
            // 0x016825E4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_2:
            // 0x016825E8: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            // 0x016825EC: STR w8, [x20, #0x2c]       | typeof(AstarData.<GetRaycastableGraphs>c__Iterator2).__il2cppRuntimeField_2C = 0xFFFFFFFFFFFFFFFE;  //  dest_result_addr=1152921504837783596
            typeof(AstarData.<GetRaycastableGraphs>c__Iterator2).__il2cppRuntimeField_2C = -2;
            // 0x016825F0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x016825F4: MOV x0, x20                | X0 = 1152921504837783552 (0x100000000DC3D000);//ML01
            // 0x016825F8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x016825FC: RET                        |  return (System.Collections.IEnumerable)typeof(AstarData.<GetRaycastableGraphs>c__Iterator2);
            return (System.Collections.IEnumerable)val_1;
            //  |  // // {name=val_0, type=System.Collections.IEnumerable, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x01682608 (23602696), len: 320  VirtAddr: 0x01682608 RVA: 0x01682608 token: 100681929 methodIndex: 49793 delegateWrapperIndex: 0 methodInvoker: 0
        public int GetGraphIndex(Pathfinding.NavGraph graph)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_2;
            //  | 
            var val_3;
            // 0x01682608: STP x24, x23, [sp, #-0x40]! | stack[1152921513152452656] = ???;  stack[1152921513152452664] = ???;  //  dest_result_addr=1152921513152452656 |  dest_result_addr=1152921513152452664
            // 0x0168260C: STP x22, x21, [sp, #0x10]  | stack[1152921513152452672] = ???;  stack[1152921513152452680] = ???;  //  dest_result_addr=1152921513152452672 |  dest_result_addr=1152921513152452680
            // 0x01682610: STP x20, x19, [sp, #0x20]  | stack[1152921513152452688] = ???;  stack[1152921513152452696] = ???;  //  dest_result_addr=1152921513152452688 |  dest_result_addr=1152921513152452696
            // 0x01682614: STP x29, x30, [sp, #0x30]  | stack[1152921513152452704] = ???;  stack[1152921513152452712] = ???;  //  dest_result_addr=1152921513152452704 |  dest_result_addr=1152921513152452712
            // 0x01682618: ADD x29, sp, #0x30         | X29 = (1152921513152452656 + 48) = 1152921513152452704 (0x10000001FD5B9860);
            // 0x0168261C: ADRP x21, #0x3738000       | X21 = 57901056 (0x3738000);             
            // 0x01682620: LDRB w8, [x21, #0xca]      | W8 = (bool)static_value_037380CA;       
            // 0x01682624: MOV x19, x1                | X19 = graph;//m1                        
            // 0x01682628: MOV x20, x0                | X20 = 1152921513152464720 (0x10000001FD5BC750);//ML01
            // 0x0168262C: TBNZ w8, #0, #0x1682648    | if (static_value_037380CA == true) goto label_0;
            // 0x01682630: ADRP x8, #0x366e000        | X8 = 57073664 (0x366E000);              
            // 0x01682634: LDR x8, [x8, #0xfe8]       | X8 = 0x2B8EC24;                         
            // 0x01682638: LDR w0, [x8]               | W0 = 0x11C9;                            
            // 0x0168263C: BL #0x2782188              | X0 = sub_2782188( ?? 0x11C9, ????);     
            // 0x01682640: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x01682644: STRB w8, [x21, #0xca]      | static_value_037380CA = true;            //  dest_result_addr=57901258
            label_0:
            // 0x01682648: CBZ x19, #0x1682708        | if (graph == null) goto label_1;        
            if(graph == null)
            {
                goto label_1;
            }
            // 0x0168264C: LDR x22, [x20, #0x38]      | X22 = this.graphs; //P2                 
            val_2 = this.graphs;
            // 0x01682650: CBZ x22, #0x16826b4        | if (this.graphs == null) goto label_5;  
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x01682654: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_3 = 0;
            // 0x01682658: B #0x1682664               |  goto label_3;                          
            goto label_3;
            label_8:
            // 0x0168265C: LDR x22, [x20, #0x38]      | X22 = this.graphs; //P2                 
            val_2 = this.graphs;
            // 0x01682660: ADD w21, w21, #1           | W21 = (val_3 + 1) = val_3 (0x00000001); 
            val_3 = 1;
            label_3:
            // 0x01682664: CBNZ x22, #0x168266c       | if (this.graphs != null) goto label_4;  
            if(val_2 != null)
            {
                goto label_4;
            }
            // 0x01682668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11C9, ????);     
            label_4:
            // 0x0168266C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01682670: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01682674: B.GE #0x16826b4            | if (val_3 >= this.graphs.Length) goto label_5;
            if(val_3 >= this.graphs.Length)
            {
                goto label_5;
            }
            // 0x01682678: LDR x22, [x20, #0x38]      | X22 = this.graphs; //P2                 
            // 0x0168267C: CBNZ x22, #0x1682684       | if (this.graphs != null) goto label_6;  
            if(this.graphs != null)
            {
                goto label_6;
            }
            // 0x01682680: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11C9, ????);     
            label_6:
            // 0x01682684: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01682688: SXTW x23, w21              | X23 = 1 (0x00000001);                   
            // 0x0168268C: CMP w21, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01682690: B.LO #0x16826a0            | if (val_3 < this.graphs.Length) goto label_7;
            if(val_3 < this.graphs.Length)
            {
                goto label_7;
            }
            // 0x01682694: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11C9, ????);     
            // 0x01682698: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168269C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11C9, ????);     
            label_7:
            // 0x016826A0: ADD x8, x22, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x016826A4: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_2 = this.graphs[1];
            // 0x016826A8: CMP x8, x19                | STATE = COMPARE(this.graphs[0x1][0], graph)
            // 0x016826AC: B.NE #0x168265c            | if (this.graphs[1] != graph) goto label_8;
            if(val_2 != graph)
            {
                goto label_8;
            }
            // 0x016826B0: B #0x16826f0               |  goto label_9;                          
            goto label_9;
            label_5:
            // 0x016826B4: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x016826B8: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x016826BC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x016826C0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x016826C4: TBZ w8, #0, #0x16826d4     | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x016826C8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x016826CC: CBNZ w8, #0x16826d4        | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x016826D0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_11:
            // 0x016826D4: ADRP x8, #0x361d000        | X8 = 56741888 (0x361D000);              
            // 0x016826D8: LDR x8, [x8, #0x468]       | X8 = (string**)(1152921513152439584)("Graph doesn\'t exist");
            // 0x016826DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016826E0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x016826E4: LDR x1, [x8]               | X1 = "Graph doesn\'t exist";            
            // 0x016826E8: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
            UnityEngine.Debug.LogError(message:  0);
            // 0x016826EC: MOVN w21, #0               | W21 = 0 (0x0);//ML01                    
            val_3 = 0;
            label_9:
            // 0x016826F0: MOV w0, w21                | W0 = 0 (0x0);//ML01                     
            // 0x016826F4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x016826F8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x016826FC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x01682700: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x01682704: RET                        |  return (System.Int32)0;                
            return (int)val_3;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
            label_1:
            // 0x01682708: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x0168270C: LDR x8, [x8, #0xe0]        | X8 = 1152921504651894784;               
            // 0x01682710: LDR x0, [x8]               | X0 = typeof(System.ArgumentNullException);
            System.ArgumentNullException val_1 = null;
            // 0x01682714: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.ArgumentNullException), ????);
            // 0x01682718: ADRP x8, #0x3684000        | X8 = 57163776 (0x3684000);              
            // 0x0168271C: LDR x8, [x8, #0x390]       | X8 = (string**)(1152921513124056064)("graph");
            // 0x01682720: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x01682724: MOV x19, x0                | X19 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x01682728: LDR x1, [x8]               | X1 = "graph";                           
            // 0x0168272C: BL #0x18b3df0              | .ctor(paramName:  "graph");             
            val_1 = new System.ArgumentNullException(paramName:  "graph");
            // 0x01682730: ADRP x8, #0x35f7000        | X8 = 56586240 (0x35F7000);              
            // 0x01682734: LDR x8, [x8, #0x610]       | X8 = 1152921513152439696;               
            // 0x01682738: MOV x0, x19                | X0 = 1152921504651894784 (0x1000000002AF6000);//ML01
            // 0x0168273C: LDR x1, [x8]               | X1 = public System.Int32 Pathfinding.AstarData::GetGraphIndex(Pathfinding.NavGraph graph);
            // 0x01682740: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.ArgumentNullException), ????);
            // 0x01682744: BL #0x167ef74              | OnDrawGizmosSelected();                 
            OnDrawGizmosSelected();
        
        }
        //
        // Offset in libil2cpp.so: 0x01682748 (23603016), len: 344  VirtAddr: 0x01682748 RVA: 0x01682748 token: 100681930 methodIndex: 49794 delegateWrapperIndex: 0 methodInvoker: 0
        public int GuidToIndex(Pathfinding.Util.Guid guid)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_4;
            //  | 
            var val_5;
            // 0x01682748: STP x26, x25, [sp, #-0x50]! | stack[1152921513152839072] = ???;  stack[1152921513152839080] = ???;  //  dest_result_addr=1152921513152839072 |  dest_result_addr=1152921513152839080
            // 0x0168274C: STP x24, x23, [sp, #0x10]  | stack[1152921513152839088] = ???;  stack[1152921513152839096] = ???;  //  dest_result_addr=1152921513152839088 |  dest_result_addr=1152921513152839096
            // 0x01682750: STP x22, x21, [sp, #0x20]  | stack[1152921513152839104] = ???;  stack[1152921513152839112] = ???;  //  dest_result_addr=1152921513152839104 |  dest_result_addr=1152921513152839112
            // 0x01682754: STP x20, x19, [sp, #0x30]  | stack[1152921513152839120] = ???;  stack[1152921513152839128] = ???;  //  dest_result_addr=1152921513152839120 |  dest_result_addr=1152921513152839128
            // 0x01682758: STP x29, x30, [sp, #0x40]  | stack[1152921513152839136] = ???;  stack[1152921513152839144] = ???;  //  dest_result_addr=1152921513152839136 |  dest_result_addr=1152921513152839144
            // 0x0168275C: ADD x29, sp, #0x40         | X29 = (1152921513152839072 + 64) = 1152921513152839136 (0x10000001FD617DE0);
            // 0x01682760: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x01682764: LDRB w8, [x22, #0xcb]      | W8 = (bool)static_value_037380CB;       
            // 0x01682768: MOV x19, x2                | X19 = guid._b;//m1                      
            // 0x0168276C: MOV x20, x1                | X20 = guid._a;//m1                      
            // 0x01682770: MOV x21, x0                | X21 = 1152921513152851152 (0x10000001FD61ACD0);//ML01
            // 0x01682774: TBNZ w8, #0, #0x1682790    | if (static_value_037380CB == true) goto label_0;
            // 0x01682778: ADRP x8, #0x35ee000        | X8 = 56549376 (0x35EE000);              
            // 0x0168277C: LDR x8, [x8, #0x518]       | X8 = 0x2B8EC3C;                         
            // 0x01682780: LDR w0, [x8]               | W0 = 0x11CF;                            
            // 0x01682784: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CF, ????);     
            // 0x01682788: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x0168278C: STRB w8, [x22, #0xcb]      | static_value_037380CB = true;            //  dest_result_addr=57901259
            label_0:
            // 0x01682790: LDR x23, [x21, #0x38]      | X23 = this.graphs; //P2                 
            val_4 = this.graphs;
            // 0x01682794: CBZ x23, #0x1682880        | if (this.graphs == null) goto label_4;  
            if(val_4 == null)
            {
                goto label_4;
            }
            // 0x01682798: ADRP x25, #0x35d0000       | X25 = 56426496 (0x35D0000);             
            // 0x0168279C: LDR x25, [x25, #0x9b8]     | X25 = 1152921504850989056;              
            // 0x016827A0: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x016827A4: B #0x16827b0               |  goto label_2;                          
            goto label_2;
            label_13:
            // 0x016827A8: LDR x23, [x21, #0x38]      | X23 = this.graphs; //P2                 
            val_4 = this.graphs;
            // 0x016827AC: ADD w22, w22, #1           | W22 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_2:
            // 0x016827B0: CBNZ x23, #0x16827b8       | if (this.graphs != null) goto label_3;  
            if(val_4 != null)
            {
                goto label_3;
            }
            // 0x016827B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CF, ????);     
            label_3:
            // 0x016827B8: LDR w8, [x23, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016827BC: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016827C0: B.GE #0x1682880            | if (val_5 >= this.graphs.Length) goto label_4;
            if(val_5 >= this.graphs.Length)
            {
                goto label_4;
            }
            // 0x016827C4: LDR x24, [x21, #0x38]      | X24 = this.graphs; //P2                 
            // 0x016827C8: CBNZ x24, #0x16827d0       | if (this.graphs != null) goto label_5;  
            if(this.graphs != null)
            {
                goto label_5;
            }
            // 0x016827CC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CF, ????);     
            label_5:
            // 0x016827D0: LDR w8, [x24, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016827D4: SXTW x23, w22              | X23 = 1 (0x00000001);                   
            // 0x016827D8: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016827DC: B.LO #0x16827ec            | if (val_5 < this.graphs.Length) goto label_6;
            if(val_5 < this.graphs.Length)
            {
                goto label_6;
            }
            // 0x016827E0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11CF, ????);     
            // 0x016827E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016827E8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11CF, ????);     
            label_6:
            // 0x016827EC: ADD x8, x24, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x016827F0: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_4 = this.graphs[1];
            // 0x016827F4: CBZ x8, #0x16827a8         | if (this.graphs[0x1][0] == null) goto label_13;
            if(val_4 == null)
            {
                goto label_13;
            }
            // 0x016827F8: LDR x24, [x21, #0x38]      | X24 = this.graphs; //P2                 
            // 0x016827FC: CBNZ x24, #0x1682804       | if (this.graphs != null) goto label_8;  
            if(this.graphs != null)
            {
                goto label_8;
            }
            // 0x01682800: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CF, ????);     
            label_8:
            // 0x01682804: LDR w8, [x24, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01682808: CMP w22, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x0168280C: B.LO #0x168281c            | if (val_5 < this.graphs.Length) goto label_9;
            if(val_5 < this.graphs.Length)
            {
                goto label_9;
            }
            // 0x01682810: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11CF, ????);     
            // 0x01682814: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682818: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11CF, ????);     
            label_9:
            // 0x0168281C: ADD x8, x24, x23, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01682820: LDR x23, [x8, #0x20]       | X23 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_5 = this.graphs[1];
            // 0x01682824: CBNZ x23, #0x168282c       | if (this.graphs[0x1][0] != null) goto label_10;
            if(val_5 != null)
            {
                goto label_10;
            }
            // 0x01682828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CF, ????);     
            label_10:
            // 0x0168282C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682830: MOV x0, x23                | X0 = this.graphs[0x1][0];//m1           
            // 0x01682834: BL #0x155d0d0              | X0 = this.graphs[0x1][0].get_guid();    
            Pathfinding.Util.Guid val_1 = val_5.guid;
            // 0x01682838: MOV x23, x0                | X23 = val_1._a;//m1                     
            val_4 = val_1._a;
            // 0x0168283C: LDR x0, [x25]              | X0 = typeof(Pathfinding.Util.Guid);     
            // 0x01682840: MOV x24, x1                | X24 = val_1._b;//m1                     
            // 0x01682844: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_10A;
            // 0x01682848: TBZ w8, #0, #0x1682858     | if (Pathfinding.Util.Guid.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x0168284C: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished;
            // 0x01682850: CBNZ w8, #0x1682858        | if (Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x01682854: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Guid), ????);
            label_12:
            // 0x01682858: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168285C: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x01682860: MOV x1, x23                | X1 = val_1._a;//m1                      
            // 0x01682864: MOV x2, x24                | X2 = val_1._b;//m1                      
            // 0x01682868: MOV x3, x20                | X3 = guid._a;//m1                       
            // 0x0168286C: MOV x4, x19                | X4 = guid._b;//m1                       
            // 0x01682870: BL #0x28ce7d0              | X0 = Pathfinding.Util.Guid.op_Equality(lhs:  new Pathfinding.Util.Guid() {_b = val_4}, rhs:  new Pathfinding.Util.Guid() {_a = val_1._b, _b = guid._a});
            bool val_2 = Pathfinding.Util.Guid.op_Equality(lhs:  new Pathfinding.Util.Guid() {_b = val_4}, rhs:  new Pathfinding.Util.Guid() {_a = val_1._b, _b = guid._a});
            // 0x01682874: AND w8, w0, #1             | W8 = (val_2 & 1);                       
            bool val_3 = val_2;
            // 0x01682878: TBZ w8, #0, #0x16827a8     | if ((val_2 & 1) == false) goto label_13;
            if(val_3 == false)
            {
                goto label_13;
            }
            // 0x0168287C: B #0x1682884               |  goto label_14;                         
            goto label_14;
            label_4:
            // 0x01682880: MOVN w22, #0               | W22 = 0 (0x0);//ML01                    
            val_5 = 0;
            label_14:
            // 0x01682884: MOV w0, w22                | W0 = 0 (0x0);//ML01                     
            // 0x01682888: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x0168288C: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01682890: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01682894: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01682898: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x0168289C: RET                        |  return (System.Int32)0;                
            return (int)val_5;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x016828A0 (23603360), len: 380  VirtAddr: 0x016828A0 RVA: 0x016828A0 token: 100681931 methodIndex: 49795 delegateWrapperIndex: 0 methodInvoker: 0
        public Pathfinding.NavGraph GuidToGraph(Pathfinding.Util.Guid guid)
        {
            //
            // Disasemble & Code
            //  | 
            Pathfinding.NavGraph[] val_3;
            //  | 
            Pathfinding.NavGraph[] val_4;
            //  | 
            var val_5;
            //  | 
            Pathfinding.NavGraph val_6;
            // 0x016828A0: STP x26, x25, [sp, #-0x50]! | stack[1152921513153303328] = ???;  stack[1152921513153303336] = ???;  //  dest_result_addr=1152921513153303328 |  dest_result_addr=1152921513153303336
            // 0x016828A4: STP x24, x23, [sp, #0x10]  | stack[1152921513153303344] = ???;  stack[1152921513153303352] = ???;  //  dest_result_addr=1152921513153303344 |  dest_result_addr=1152921513153303352
            // 0x016828A8: STP x22, x21, [sp, #0x20]  | stack[1152921513153303360] = ???;  stack[1152921513153303368] = ???;  //  dest_result_addr=1152921513153303360 |  dest_result_addr=1152921513153303368
            // 0x016828AC: STP x20, x19, [sp, #0x30]  | stack[1152921513153303376] = ???;  stack[1152921513153303384] = ???;  //  dest_result_addr=1152921513153303376 |  dest_result_addr=1152921513153303384
            // 0x016828B0: STP x29, x30, [sp, #0x40]  | stack[1152921513153303392] = ???;  stack[1152921513153303400] = ???;  //  dest_result_addr=1152921513153303392 |  dest_result_addr=1152921513153303400
            // 0x016828B4: ADD x29, sp, #0x40         | X29 = (1152921513153303328 + 64) = 1152921513153303392 (0x10000001FD689360);
            // 0x016828B8: ADRP x22, #0x3738000       | X22 = 57901056 (0x3738000);             
            // 0x016828BC: LDRB w8, [x22, #0xcc]      | W8 = (bool)static_value_037380CC;       
            // 0x016828C0: MOV x19, x2                | X19 = guid._b;//m1                      
            val_3 = guid._b;
            // 0x016828C4: MOV x20, x1                | X20 = guid._a;//m1                      
            // 0x016828C8: MOV x21, x0                | X21 = 1152921513153315408 (0x10000001FD68C250);//ML01
            // 0x016828CC: TBNZ w8, #0, #0x16828e8    | if (static_value_037380CC == true) goto label_0;
            // 0x016828D0: ADRP x8, #0x3679000        | X8 = 57118720 (0x3679000);              
            // 0x016828D4: LDR x8, [x8, #0x7f0]       | X8 = 0x2B8EC38;                         
            // 0x016828D8: LDR w0, [x8]               | W0 = 0x11CE;                            
            // 0x016828DC: BL #0x2782188              | X0 = sub_2782188( ?? 0x11CE, ????);     
            // 0x016828E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016828E4: STRB w8, [x22, #0xcc]      | static_value_037380CC = true;            //  dest_result_addr=57901260
            label_0:
            // 0x016828E8: LDR x22, [x21, #0x38]      | X22 = this.graphs; //P2                 
            val_4 = this.graphs;
            // 0x016828EC: CBZ x22, #0x1682a00        | if (this.graphs == null) goto label_4;  
            if(val_4 == null)
            {
                goto label_4;
            }
            // 0x016828F0: ADRP x25, #0x35d0000       | X25 = 56426496 (0x35D0000);             
            // 0x016828F4: LDR x25, [x25, #0x9b8]     | X25 = 1152921504850989056;              
            // 0x016828F8: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_5 = 0;
            // 0x016828FC: B #0x1682908               |  goto label_2;                          
            goto label_2;
            label_13:
            // 0x01682900: LDR x22, [x21, #0x38]      | X22 = this.graphs; //P2                 
            val_4 = this.graphs;
            // 0x01682904: ADD w24, w24, #1           | W24 = (val_5 + 1) = val_5 (0x00000001); 
            val_5 = 1;
            label_2:
            // 0x01682908: CBNZ x22, #0x1682910       | if (this.graphs != null) goto label_3;  
            if(val_4 != null)
            {
                goto label_3;
            }
            // 0x0168290C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CE, ????);     
            label_3:
            // 0x01682910: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01682914: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01682918: B.GE #0x1682a00            | if (val_5 >= this.graphs.Length) goto label_4;
            if(val_5 >= this.graphs.Length)
            {
                goto label_4;
            }
            // 0x0168291C: LDR x22, [x21, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01682920: CBNZ x22, #0x1682928       | if (this.graphs != null) goto label_5;  
            if(this.graphs != null)
            {
                goto label_5;
            }
            // 0x01682924: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CE, ????);     
            label_5:
            // 0x01682928: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x0168292C: SXTW x26, w24              | X26 = 1 (0x00000001);                   
            // 0x01682930: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01682934: B.LO #0x1682944            | if (val_5 < this.graphs.Length) goto label_6;
            if(val_5 < this.graphs.Length)
            {
                goto label_6;
            }
            // 0x01682938: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11CE, ????);     
            // 0x0168293C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682940: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11CE, ????);     
            label_6:
            // 0x01682944: ADD x8, x22, x26, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01682948: LDR x8, [x8, #0x20]        | X8 = this.graphs[0x1][0]                
            Pathfinding.NavGraph val_3 = this.graphs[1];
            // 0x0168294C: CBZ x8, #0x1682900         | if (this.graphs[0x1][0] == null) goto label_13;
            if(val_3 == null)
            {
                goto label_13;
            }
            // 0x01682950: LDR x22, [x21, #0x38]      | X22 = this.graphs; //P2                 
            // 0x01682954: CBNZ x22, #0x168295c       | if (this.graphs != null) goto label_8;  
            if(this.graphs != null)
            {
                goto label_8;
            }
            // 0x01682958: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CE, ????);     
            label_8:
            // 0x0168295C: LDR w8, [x22, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x01682960: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x01682964: B.LO #0x1682974            | if (val_5 < this.graphs.Length) goto label_9;
            if(val_5 < this.graphs.Length)
            {
                goto label_9;
            }
            // 0x01682968: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x11CE, ????);     
            // 0x0168296C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682970: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x11CE, ????);     
            label_9:
            // 0x01682974: ADD x8, x22, x26, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x01682978: LDR x22, [x8, #0x20]       | X22 = this.graphs[0x1][0]               
            Pathfinding.NavGraph val_4 = this.graphs[1];
            // 0x0168297C: CBNZ x22, #0x1682984       | if (this.graphs[0x1][0] != null) goto label_10;
            if(val_4 != null)
            {
                goto label_10;
            }
            // 0x01682980: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11CE, ????);     
            label_10:
            // 0x01682984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01682988: MOV x0, x22                | X0 = this.graphs[0x1][0];//m1           
            // 0x0168298C: BL #0x155d0d0              | X0 = this.graphs[0x1][0].get_guid();    
            Pathfinding.Util.Guid val_1 = val_4.guid;
            // 0x01682990: MOV x22, x0                | X22 = val_1._a;//m1                     
            // 0x01682994: LDR x0, [x25]              | X0 = typeof(Pathfinding.Util.Guid);     
            // 0x01682998: MOV x23, x1                | X23 = val_1._b;//m1                     
            // 0x0168299C: LDRB w8, [x0, #0x10a]      | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_10A;
            // 0x016829A0: TBZ w8, #0, #0x16829b0     | if (Pathfinding.Util.Guid.__il2cppRuntimeField_has_cctor == 0) goto label_12;
            // 0x016829A4: LDR w8, [x0, #0xbc]        | W8 = Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished;
            // 0x016829A8: CBNZ w8, #0x16829b0        | if (Pathfinding.Util.Guid.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x016829AC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Pathfinding.Util.Guid), ????);
            label_12:
            // 0x016829B0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016829B4: MOV x5, xzr                | X5 = 0 (0x0);//ML01                     
            // 0x016829B8: MOV x1, x22                | X1 = val_1._a;//m1                      
            // 0x016829BC: MOV x2, x23                | X2 = val_1._b;//m1                      
            // 0x016829C0: MOV x3, x20                | X3 = guid._a;//m1                       
            // 0x016829C4: MOV x4, x19                | X4 = guid._b;//m1                       
            // 0x016829C8: BL #0x28ce7d0              | X0 = Pathfinding.Util.Guid.op_Equality(lhs:  new Pathfinding.Util.Guid() {_b = val_1._a}, rhs:  new Pathfinding.Util.Guid() {_a = val_1._b, _b = guid._a});
            bool val_2 = Pathfinding.Util.Guid.op_Equality(lhs:  new Pathfinding.Util.Guid() {_b = val_1._a}, rhs:  new Pathfinding.Util.Guid() {_a = val_1._b, _b = guid._a});
            // 0x016829CC: TBZ w0, #0, #0x1682900     | if (val_2 == false) goto label_13;      
            if(val_2 == false)
            {
                goto label_13;
            }
            // 0x016829D0: LDR x19, [x21, #0x38]      | X19 = this.graphs; //P2                 
            val_3 = this.graphs;
            // 0x016829D4: CBNZ x19, #0x16829dc       | if (this.graphs != null) goto label_14; 
            if(val_3 != null)
            {
                goto label_14;
            }
            // 0x016829D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_14:
            // 0x016829DC: LDR w8, [x19, #0x18]       | W8 = this.graphs.Length; //P2           
            // 0x016829E0: CMP w24, w8                | STATE = COMPARE(0x1, this.graphs.Length)
            // 0x016829E4: B.LO #0x16829f4            | if (val_5 < this.graphs.Length) goto label_15;
            if(val_5 < this.graphs.Length)
            {
                goto label_15;
            }
            // 0x016829E8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x016829EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016829F0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_15:
            // 0x016829F4: ADD x8, x19, x26, lsl #3   | X8 = this.graphs[0x1]; //PARR1          
            // 0x016829F8: LDR x0, [x8, #0x20]        | X0 = this.graphs[0x1][0]                
            val_6 = val_3[1];
            // 0x016829FC: B #0x1682a04               |  goto label_16;                         
            goto label_16;
            label_4:
            // 0x01682A00: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_6 = 0;
            label_16:
            // 0x01682A04: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x01682A08: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            // 0x01682A0C: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            // 0x01682A10: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x01682A14: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            // 0x01682A18: RET                        |  return (Pathfinding.NavGraph)null;     
            return (Pathfinding.NavGraph)val_6;
            //  |  // // {name=val_0, type=Pathfinding.NavGraph, size=8, nGRN=0 }
        
        }
    
    }

}
