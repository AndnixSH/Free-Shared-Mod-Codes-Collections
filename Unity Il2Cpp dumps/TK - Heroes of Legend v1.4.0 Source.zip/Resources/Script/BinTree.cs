using UnityEngine;

namespace SevenZip.Compression.LZ
{
    public class BinTree : InWindow, IMatchFinder, IInWindowStream
    {
        // Fields
        private uint _cyclicBufferPos; //  0x00000044
        private uint _cyclicBufferSize; //  0x00000048
        private uint _matchMaxLen; //  0x0000004C
        private uint[] _son; //  0x00000050
        private uint[] _hash; //  0x00000058
        private uint _cutValue; //  0x00000060
        private uint _hashMask; //  0x00000064
        private uint _hashSizeSum; //  0x00000068
        private bool HASH_ARRAY; //  0x0000006C
        private const uint kHash2Size = 1024;
        private const uint kHash3Size = 65536;
        private const uint kBT2HashSize = 65536;
        private const uint kStartMaxLen = 1;
        private const uint kHash3Offset = 1024;
        private const uint kEmptyHashValue = 0;
        private const uint kMaxValForNormalize = 2147483647;
        private uint kNumHashDirectBytes; //  0x00000070
        private uint kMinMatchCheck; //  0x00000074
        private uint kFixHashSize; //  0x00000078
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00CA8794 (13272980), len: 40  VirtAddr: 0x00CA8794 RVA: 0x00CA8794 token: 100681456 methodIndex: 54585 delegateWrapperIndex: 0 methodInvoker: 0
        public BinTree()
        {
            //
            // Disasemble & Code
            // 0x00CA8794: MOVZ x10, #0x1, lsl #48    | X10 = 281474976710656 (0x1000000000000);//ML01
            // 0x00CA8798: MOVK x10, #0x400, lsl #32  | X10 = 285873023221760 (0x1040000000000);
            // 0x00CA879C: ORR w8, wzr, #0xff         | W8 = 255(0xFF);                         
            // 0x00CA87A0: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00CA87A4: MOVK x10, #0x4             | X10 = 285873023221764 (0x1040000000004);
            // 0x00CA87A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA87AC: STR w8, [x0, #0x60]        | this._cutValue = 0xFF;                   //  dest_result_addr=1152921513062424688
            this._cutValue = 255;
            // 0x00CA87B0: STRB w9, [x0, #0x6c]       | this.HASH_ARRAY = true;                  //  dest_result_addr=1152921513062424700
            this.HASH_ARRAY = true;
            // 0x00CA87B4: STUR x10, [x0, #0x74]      | this.kMinMatchCheck = 0x4; this.kFixHashSize = 0x400;  //  dest_result_addr=1152921513062424708 dest_result_addr=1152921513062424712
            this.kMinMatchCheck = 4;
            this.kFixHashSize = 1024;
            // 0x00CA87B8: B #0x16f59f0               | this..ctor(); return;                   
            val_1 = new System.Object();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA87C4 (13273028), len: 52  VirtAddr: 0x00CA87C4 RVA: 0x00CA87C4 token: 100681457 methodIndex: 54586 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetType(int numHashBytes)
        {
            //
            // Disasemble & Code
            // 0x00CA87C4: CMP w1, #2                 | STATE = COMPARE(numHashBytes, 0x2)      
            // 0x00CA87C8: MOVZ w10, #0x1, lsl #16    | W10 = 65536 (0x10000);//ML01            
            // 0x00CA87CC: ORR w8, wzr, #2            | W8 = 2(0x2);                            
            // 0x00CA87D0: ORR w9, wzr, #3            | W9 = 3(0x3);                            
            // 0x00CA87D4: MOVK w10, #0x400           | W10 = 66560 (0x10400);                  
            // 0x00CA87D8: CSET w11, gt               | W11 = numHashBytes > 2 ? 1 : 0;         
            bool val_1 = (numHashBytes > 2) ? 1 : 0;
            // 0x00CA87DC: CSEL w8, wzr, w8, gt       | W8 = numHashBytes > 2 ? 0 : 2;          
            uint val_2 = (numHashBytes > 2) ? 0 : (2);
            // 0x00CA87E0: CINC w9, w9, gt            | W9 = numHashBytes > 2 ? (3 + 1) : 3;    
            uint val_3 = (numHashBytes > 2) ? (3 + 1) : (3);
            // 0x00CA87E4: CSEL w10, w10, wzr, gt     | W10 = numHashBytes > 2 ? 66560 : 0;     
            uint val_4 = (numHashBytes > 2) ? 66560 : 0;
            // 0x00CA87E8: STRB w11, [x0, #0x6c]      | this.HASH_ARRAY = numHashBytes > 2 ? 1 : 0;  //  dest_result_addr=1152921513062536700
            this.HASH_ARRAY = val_1;
            // 0x00CA87EC: STP w8, w9, [x0, #0x70]    | this.kNumHashDirectBytes = numHashBytes > 2 ? 0 : 2;  this.kMinMatchCheck = numHashBytes > 2 ? (3 + 1) : 3;  //  dest_result_addr=1152921513062536704 |  dest_result_addr=1152921513062536708
            this.kNumHashDirectBytes = val_2;
            this.kMinMatchCheck = val_3;
            // 0x00CA87F0: STR w10, [x0, #0x78]       | this.kFixHashSize = numHashBytes > 2 ? 66560 : 0;  //  dest_result_addr=1152921513062536712
            this.kFixHashSize = val_4;
            // 0x00CA87F4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA87F8 (13273080), len: 8  VirtAddr: 0x00CA87F8 RVA: 0x00CA87F8 token: 100681458 methodIndex: 54587 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetStream(System.IO.Stream stream)
        {
            //
            // Disasemble & Code
            // 0x00CA87F8: STR x1, [x0, #0x18]        | mem[1152921513062652712] = stream;       //  dest_result_addr=1152921513062652712
            mem[1152921513062652712] = stream;
            // 0x00CA87FC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8808 (13273096), len: 8  VirtAddr: 0x00CA8808 RVA: 0x00CA8808 token: 100681459 methodIndex: 54588 delegateWrapperIndex: 0 methodInvoker: 0
        public void ReleaseStream()
        {
            //
            // Disasemble & Code
            // 0x00CA8808: STR xzr, [x0, #0x18]       | mem[1152921513062768808] = 0x0;          //  dest_result_addr=1152921513062768808
            mem[1152921513062768808] = 0;
            // 0x00CA880C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8818 (13273112), len: 188  VirtAddr: 0x00CA8818 RVA: 0x00CA8818 token: 100681460 methodIndex: 54589 delegateWrapperIndex: 0 methodInvoker: 0
        public void Init()
        {
            //
            // Disasemble & Code
            // 0x00CA8818: STP x22, x21, [sp, #-0x30]! | stack[1152921513062905600] = ???;  stack[1152921513062905608] = ???;  //  dest_result_addr=1152921513062905600 |  dest_result_addr=1152921513062905608
            // 0x00CA881C: STP x20, x19, [sp, #0x10]  | stack[1152921513062905616] = ???;  stack[1152921513062905624] = ???;  //  dest_result_addr=1152921513062905616 |  dest_result_addr=1152921513062905624
            // 0x00CA8820: STP x29, x30, [sp, #0x20]  | stack[1152921513062905632] = ???;  stack[1152921513062905640] = ???;  //  dest_result_addr=1152921513062905632 |  dest_result_addr=1152921513062905640
            // 0x00CA8824: ADD x29, sp, #0x20         | X29 = (1152921513062905600 + 32) = 1152921513062905632 (0x10000001F8053720);
            // 0x00CA8828: MOV x19, x0                | X19 = 1152921513062917648 (0x10000001F8056610);//ML01
            // 0x00CA882C: LDR x8, [x19]              | X8 = typeof(SevenZip.Compression.LZ.BinTree);
            // 0x00CA8830: STRB wzr, [x19, #0x24]     | mem[1152921513062917684] = 0x0;          //  dest_result_addr=1152921513062917684
            mem[1152921513062917684] = 0;
            // 0x00CA8834: STR wzr, [x19, #0x2c]      | mem[1152921513062917692] = 0x0;          //  dest_result_addr=1152921513062917692
            mem[1152921513062917692] = 0;
            // 0x00CA8838: STR wzr, [x19, #0x34]      | mem[1152921513062917700] = 0x0;          //  dest_result_addr=1152921513062917700
            mem[1152921513062917700] = 0;
            // 0x00CA883C: STR wzr, [x19, #0x40]      | mem[1152921513062917712] = 0x0;          //  dest_result_addr=1152921513062917712
            mem[1152921513062917712] = 0;
            // 0x00CA8840: LDP x9, x1, [x8, #0x150]   | X9 = typeof(SevenZip.Compression.LZ.BinTree).__il2cppRuntimeField_150; X1 = typeof(SevenZip.Compression.LZ.BinTree).__il2cppRuntimeField_158; //  | 
            // 0x00CA8844: BLR x9                     | X0 = typeof(SevenZip.Compression.LZ.BinTree).__il2cppRuntimeField_150();
            // 0x00CA8848: LDR w8, [x19, #0x68]       | W8 = this._hashSizeSum; //P2            
            // 0x00CA884C: CBZ w8, #0xca8894          | if (this._hashSizeSum == 0) goto label_0;
            if(this._hashSizeSum == 0)
            {
                goto label_0;
            }
            // 0x00CA8850: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            var val_4 = 0;
            label_3:
            // 0x00CA8854: LDR x21, [x19, #0x58]      | X21 = this._hash; //P2                  
            // 0x00CA8858: CBNZ x21, #0xca8860        | if (this._hash != null) goto label_1;   
            if(this._hash != null)
            {
                goto label_1;
            }
            // 0x00CA885C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00CA8860: LDR w8, [x21, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA8864: MOV w22, w20               | W22 = 0 (0x0);//ML01                    
            // 0x00CA8868: CMP w20, w8                | STATE = COMPARE(0x0, this._hash.Length) 
            // 0x00CA886C: B.LO #0xca887c             | if (0 < this._hash.Length) goto label_2;
            if(val_4 < this._hash.Length)
            {
                goto label_2;
            }
            // 0x00CA8870: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00CA8874: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA8878: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_2:
            // 0x00CA887C: ADD x8, x21, x22, lsl #2   | X8 = this._hash[0x0]; //PARR1           
            // 0x00CA8880: STR wzr, [x8, #0x20]       | this._hash[0x0][0] = null;               //  dest_result_addr=0
            this._hash[val_4] = 0;
            // 0x00CA8884: LDR w8, [x19, #0x68]       | W8 = this._hashSizeSum; //P2            
            uint val_5 = this._hashSizeSum;
            // 0x00CA8888: ADD w20, w20, #1           | W20 = (0 + 1);                          
            val_4 = val_4 + 1;
            // 0x00CA888C: CMP w20, w8                | STATE = COMPARE((0 + 1), this._hashSizeSum)
            // 0x00CA8890: B.LO #0xca8854             | if (0 < this._hashSizeSum) goto label_3;
            if(val_4 < val_5)
            {
                goto label_3;
            }
            label_0:
            // 0x00CA8894: LDR w8, [x19, #0x2c]       | 
            // 0x00CA8898: LDR w9, [x19, #0x20]       | 
            // 0x00CA889C: LDR w10, [x19, #0x34]      | 
            // 0x00CA88A0: LDR w11, [x19, #0x40]      | 
            // 0x00CA88A4: SUB w8, w8, #1             | W8 = (this._hashSizeSum - 1);           
            val_5 = val_5 - 1;
            // 0x00CA88A8: ADD w9, w9, #1             | W9 = (typeof(SevenZip.Compression.LZ.BinTree).__il2cppRuntimeField_150 + 1);
            // 0x00CA88AC: ADD w10, w10, #1           | W10 = (W10 + 1);                        
            var val_2 = W10 + 1;
            // 0x00CA88B0: ADD w11, w11, #1           | W11 = (W11 + 1);                        
            var val_3 = W11 + 1;
            // 0x00CA88B4: STR w8, [x19, #0x2c]       | mem[1152921513062917692] = (this._hashSizeSum - 1);  //  dest_result_addr=1152921513062917692
            mem[1152921513062917692] = val_5;
            // 0x00CA88B8: STR w9, [x19, #0x20]       | mem[1152921513062917680] = (typeof(SevenZip.Compression.LZ.BinTree).__il2cppRuntimeField_150 + 1);  //  dest_result_addr=1152921513062917680
            mem[1152921513062917680] = (typeof(SevenZip.Compression.LZ.BinTree).__il2cppRuntimeField_150 + 1);
            // 0x00CA88BC: STR w10, [x19, #0x34]      | mem[1152921513062917700] = (W10 + 1);    //  dest_result_addr=1152921513062917700
            mem[1152921513062917700] = val_2;
            // 0x00CA88C0: STP w11, wzr, [x19, #0x40] | mem[1152921513062917712] = (W11 + 1);  this._cyclicBufferPos = null;  //  dest_result_addr=1152921513062917712 |  dest_result_addr=1152921513062917716
            mem[1152921513062917712] = val_3;
            this._cyclicBufferPos = 0;
            // 0x00CA88C4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA88C8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00CA88CC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00CA88D0: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8924 (13273380), len: 84  VirtAddr: 0x00CA8924 RVA: 0x00CA8924 token: 100681461 methodIndex: 54590 delegateWrapperIndex: 0 methodInvoker: 0
        public void MovePos()
        {
            //
            // Disasemble & Code
            // 0x00CA8924: STP x20, x19, [sp, #-0x20]! | stack[1152921513063054480] = ???;  stack[1152921513063054488] = ???;  //  dest_result_addr=1152921513063054480 |  dest_result_addr=1152921513063054488
            // 0x00CA8928: STP x29, x30, [sp, #0x10]  | stack[1152921513063054496] = ???;  stack[1152921513063054504] = ???;  //  dest_result_addr=1152921513063054496 |  dest_result_addr=1152921513063054504
            // 0x00CA892C: ADD x29, sp, #0x10         | X29 = (1152921513063054480 + 16) = 1152921513063054496 (0x10000001F8077CA0);
            // 0x00CA8930: MOV x19, x0                | X19 = 1152921513063066512 (0x10000001F807AB90);//ML01
            // 0x00CA8934: LDP w8, w9, [x19, #0x44]   | W8 = this._cyclicBufferPos; //P2  W9 = this._cyclicBufferSize; //P2  //  | 
            // 0x00CA8938: ADD w10, w8, #1            | W10 = (this._cyclicBufferPos + 1);      
            uint val_1 = this._cyclicBufferPos + 1;
            // 0x00CA893C: CMP w10, w9                | STATE = COMPARE((this._cyclicBufferPos + 1), this._cyclicBufferSize)
            // 0x00CA8940: CSINC w8, wzr, w8, hs      | W8 = val_1 >= this._cyclicBufferSize ? 0 : (this._cyclicBufferPos + 1);
            uint val_2 = (val_1 >= this._cyclicBufferSize) ? 0 : (this._cyclicBufferPos + 1);
            // 0x00CA8944: STR w8, [x19, #0x44]       | this._cyclicBufferPos = val_1 >= this._cyclicBufferSize ? 0 : (this._cyclicBufferPos + 1);  //  dest_result_addr=1152921513063066580
            this._cyclicBufferPos = val_2;
            // 0x00CA8948: BL #0xca8978               | this.MovePos();                         
            this.MovePos();
            // 0x00CA894C: LDR w8, [x19, #0x34]       | 
            // 0x00CA8950: ORR w9, wzr, #0x7fffffff   | W9 = 2147483647(0x7FFFFFFF);            
            // 0x00CA8954: CMP w8, w9                 | STATE = COMPARE(val_1 >= this._cyclicBufferSize ? 0 : (this._cyclicBufferPos + 1), 0x7FFFFFFF)
            // 0x00CA8958: B.NE #0xca896c             | if (val_2 != 2147483647) goto label_0;  
            if(val_2 != 2147483647)
            {
                goto label_0;
            }
            // 0x00CA895C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA8960: MOV x0, x19                | X0 = 1152921513063066512 (0x10000001F807AB90);//ML01
            // 0x00CA8964: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00CA8968: B #0xca89dc                | this.Normalize(); return;               
            this.Normalize();
            return;
            label_0:
            // 0x00CA896C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA8970: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00CA8974: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8A54 (13273684), len: 4  VirtAddr: 0x00CA8A54 RVA: 0x00CA8A54 token: 100681462 methodIndex: 54591 delegateWrapperIndex: 0 methodInvoker: 0
        public byte GetIndexByte(int index)
        {
            //
            // Disasemble & Code
            // 0x00CA8A54: B #0xca8a58                | return this.GetIndexByte(index:  index);
            return this.GetIndexByte(index:  index);
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8AE4 (13273828), len: 4  VirtAddr: 0x00CA8AE4 RVA: 0x00CA8AE4 token: 100681463 methodIndex: 54592 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetMatchLen(int index, uint distance, uint limit)
        {
            //
            // Disasemble & Code
            // 0x00CA8AE4: B #0xca8ae8                | return this.GetMatchLen(index:  index, distance:  distance, limit:  limit);
            return this.GetMatchLen(index:  index, distance:  distance, limit:  limit);
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8BEC (13274092), len: 16  VirtAddr: 0x00CA8BEC RVA: 0x00CA8BEC token: 100681464 methodIndex: 54593 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetNumAvailableBytes()
        {
            //
            // Disasemble & Code
            // 0x00CA8BEC: LDR w8, [x0, #0x40]        | 
            // 0x00CA8BF0: LDR w9, [x0, #0x34]        | 
            // 0x00CA8BF4: SUB w0, w8, w9             | W0 = (W8 - W9);                         
            var val_1 = W8 - W9;
            // 0x00CA8BF8: RET                        |  return (System.UInt32)(W8 - W9);       
            return (uint)val_1;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8C0C (13274124), len: 396  VirtAddr: 0x00CA8C0C RVA: 0x00CA8C0C token: 100681465 methodIndex: 54594 delegateWrapperIndex: 0 methodInvoker: 0
        public void Create(uint historySize, uint keepAddBufferBefore, uint matchMaxLen, uint keepAddBufferAfter)
        {
            //
            // Disasemble & Code
            //  | 
            uint val_12;
            // 0x00CA8C0C: STP x24, x23, [sp, #-0x40]! | stack[1152921513063503472] = ???;  stack[1152921513063503480] = ???;  //  dest_result_addr=1152921513063503472 |  dest_result_addr=1152921513063503480
            // 0x00CA8C10: STP x22, x21, [sp, #0x10]  | stack[1152921513063503488] = ???;  stack[1152921513063503496] = ???;  //  dest_result_addr=1152921513063503488 |  dest_result_addr=1152921513063503496
            // 0x00CA8C14: STP x20, x19, [sp, #0x20]  | stack[1152921513063503504] = ???;  stack[1152921513063503512] = ???;  //  dest_result_addr=1152921513063503504 |  dest_result_addr=1152921513063503512
            // 0x00CA8C18: STP x29, x30, [sp, #0x30]  | stack[1152921513063503520] = ???;  stack[1152921513063503528] = ???;  //  dest_result_addr=1152921513063503520 |  dest_result_addr=1152921513063503528
            // 0x00CA8C1C: ADD x29, sp, #0x30         | X29 = (1152921513063503472 + 48) = 1152921513063503520 (0x10000001F80E56A0);
            // 0x00CA8C20: ADRP x24, #0x3734000       | X24 = 57884672 (0x3734000);             
            // 0x00CA8C24: LDRB w8, [x24, #0xb1]      | W8 = (bool)static_value_037340B1;       
            // 0x00CA8C28: MOV w22, w4                | W22 = keepAddBufferAfter;//m1           
            // 0x00CA8C2C: MOV w21, w3                | W21 = matchMaxLen;//m1                  
            // 0x00CA8C30: MOV w23, w2                | W23 = keepAddBufferBefore;//m1          
            // 0x00CA8C34: MOV w20, w1                | W20 = historySize;//m1                  
            // 0x00CA8C38: MOV x19, x0                | X19 = 1152921513063515536 (0x10000001F80E8590);//ML01
            // 0x00CA8C3C: TBNZ w8, #0, #0xca8c58     | if (static_value_037340B1 == true) goto label_0;
            // 0x00CA8C40: ADRP x8, #0x35bb000        | X8 = 56340480 (0x35BB000);              
            // 0x00CA8C44: LDR x8, [x8, #0x2b0]       | X8 = 0x2B8F568;                         
            // 0x00CA8C48: LDR w0, [x8]               | W0 = 0x141C;                            
            // 0x00CA8C4C: BL #0x2782188              | X0 = sub_2782188( ?? 0x141C, ????);     
            // 0x00CA8C50: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA8C54: STRB w8, [x24, #0xb1]      | static_value_037340B1 = true;            //  dest_result_addr=57884849
            label_0:
            // 0x00CA8C58: ORR w8, wzr, #0x7fffff00   | W8 = 2147483392(0x7FFFFF00);            
            // 0x00CA8C5C: CMP w20, w8                | STATE = COMPARE(historySize, 0x7FFFFF00)
            // 0x00CA8C60: B.HS #0xca8d64             | if (historySize >= 2147483392) goto label_1;
            if(historySize >= 2147483392)
            {
                goto label_1;
            }
            // 0x00CA8C64: LSR w8, w21, #1            | W8 = (matchMaxLen >> 1);                
            uint val_1 = matchMaxLen >> 1;
            // 0x00CA8C68: ADD w1, w23, w20           | W1 = (keepAddBufferBefore + historySize);
            historySize = keepAddBufferBefore + historySize;
            // 0x00CA8C6C: ADD w8, w8, #0x10          | W8 = ((matchMaxLen >> 1) + 16);         
            val_1 = val_1 + 16;
            // 0x00CA8C70: ADD w9, w1, w21            | W9 = ((keepAddBufferBefore + historySize) + matchMaxLen);
            uint val_2 = historySize + matchMaxLen;
            // 0x00CA8C74: STR w8, [x19, #0x60]       | this._cutValue = ((matchMaxLen >> 1) + 16);  //  dest_result_addr=1152921513063515632
            this._cutValue = val_1;
            // 0x00CA8C78: ADD w8, w9, w22            | W8 = (((keepAddBufferBefore + historySize) + matchMaxLen) + keepAddBufferAfter);
            uint val_3 = val_2 + keepAddBufferAfter;
            // 0x00CA8C7C: LSR w8, w8, #1             | W8 = ((((keepAddBufferBefore + historySize) + matchMaxLen) + keepAddBufferAfter) >> 1);
            val_3 = val_3 >> 1;
            // 0x00CA8C80: ADD w3, w8, #0x100         | W3 = (((((keepAddBufferBefore + historySize) + matchMaxLen) + keepAddBufferAfter) >> 1) + 256);
            matchMaxLen = val_3 + 256;
            // 0x00CA8C84: ADD w2, w22, w21           | W2 = (keepAddBufferAfter + matchMaxLen);
            uint val_4 = keepAddBufferAfter + matchMaxLen;
            // 0x00CA8C88: MOV x0, x19                | X0 = 1152921513063515536 (0x10000001F80E8590);//ML01
            // 0x00CA8C8C: BL #0xca8d98               | this.Create(keepSizeBefore:  historySize = keepAddBufferBefore + historySize, keepSizeAfter:  uint val_4 = keepAddBufferAfter + matchMaxLen, keepSizeReserv:  matchMaxLen = val_3 + 256);
            this.Create(keepSizeBefore:  historySize, keepSizeAfter:  val_4, keepSizeReserv:  matchMaxLen);
            // 0x00CA8C90: LDR w9, [x19, #0x48]       | W9 = this._cyclicBufferSize; //P2       
            // 0x00CA8C94: ADD w8, w20, #1            | W8 = (historySize + 1);                 
            uint val_5 = historySize + 1;
            // 0x00CA8C98: STR w21, [x19, #0x4c]      | this._matchMaxLen = matchMaxLen;         //  dest_result_addr=1152921513063515612
            this._matchMaxLen = matchMaxLen;
            // 0x00CA8C9C: CMP w9, w8                 | STATE = COMPARE(this._cyclicBufferSize, (historySize + 1))
            // 0x00CA8CA0: B.EQ #0xca8cd0             | if (this._cyclicBufferSize == val_5) goto label_2;
            if(this._cyclicBufferSize == val_5)
            {
                goto label_2;
            }
            // 0x00CA8CA4: STR w8, [x19, #0x48]       | this._cyclicBufferSize = (historySize + 1);  //  dest_result_addr=1152921513063515608
            this._cyclicBufferSize = val_5;
            // 0x00CA8CA8: ADRP x9, #0x367c000        | X9 = 57131008 (0x367C000);              
            // 0x00CA8CAC: LDR x9, [x9, #0x1b8]       | X9 = 1152921505007033440;               
            // 0x00CA8CB0: LSL w22, w8, #1            | W22 = ((historySize + 1) << 1);         
            uint val_6 = val_5 << 1;
            // 0x00CA8CB4: LDR x21, [x9]              | X21 = typeof(System.UInt32[]);          
            // 0x00CA8CB8: MOV x0, x21                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00CA8CBC: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x00CA8CC0: MOV x0, x21                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00CA8CC4: MOV x1, x22                | X1 = ((historySize + 1) << 1);//m1      
            // 0x00CA8CC8: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x00CA8CCC: STR x0, [x19, #0x50]       | this._son = typeof(System.UInt32[]);     //  dest_result_addr=1152921513063515616
            this._son = null;
            label_2:
            // 0x00CA8CD0: LDRB w8, [x19, #0x6c]      | W8 = this.HASH_ARRAY; //P2              
            // 0x00CA8CD4: CBZ w8, #0xca8d18          | if (this.HASH_ARRAY == false) goto label_3;
            if(this.HASH_ARRAY == false)
            {
                goto label_3;
            }
            // 0x00CA8CD8: SUB w8, w20, #1            | W8 = (historySize - 1);                 
            uint val_7 = historySize - 1;
            // 0x00CA8CDC: ORR w8, w8, w8, lsr #1     | W8 = ((historySize - 1) | ((historySize - 1)) >> 1);
            val_7 = val_7 | (val_7 >> 1);
            // 0x00CA8CE0: ORR w8, w8, w8, lsr #2     | W8 = (((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >> 
            val_7 = val_7 | (val_7 >> 2);
            // 0x00CA8CE4: ORR w8, w8, w8, lsr #4     | W8 = ((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >>
            val_7 = val_7 | (val_7 >> 4);
            // 0x00CA8CE8: ORR w8, w8, w8, lsr #8     | W8 = (((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >
            val_7 = val_7 | (val_7 >> 8);
            // 0x00CA8CEC: LSR w8, w8, #1             | W8 = ((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >> 1)) >> 2) | ((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1) >> 1);
            val_7 = val_7 >> 1;
            // 0x00CA8CF0: ORR w9, wzr, #0x1000000    | W9 = 16777216(0x1000000);               
            // 0x00CA8CF4: LDR w10, [x19, #0x78]      | W10 = this.kFixHashSize; //P2           
            // 0x00CA8CF8: ORR w8, w8, #0xffff        | W8 = (((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1))
            val_7 = val_7 | 65535;
            // 0x00CA8CFC: CMP w8, w9                 | STATE = COMPARE((((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >> 1)) >> 2) | ((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - , 0x1000000)
            // 0x00CA8D00: CSET w9, hi                | W9 = val_7 > 16777216 ? 1 : 0;          
            var val_8 = (val_7 > 16777216) ? 1 : 0;
            // 0x00CA8D04: LSR w8, w8, w9             | W8 = ((((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >> 1)) >> 2) | ((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize -  >> val_7 > 16777216 ? 1 : 0);
            val_7 = val_7 >> val_8;
            // 0x00CA8D08: STR w8, [x19, #0x64]       | this._hashMask = ((((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1)) >> 1)) >> 2) | ((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize -  >> val_7 > 16777216 ? 1 : 0);  //  dest_result_addr=1152921513063515636
            this._hashMask = val_7;
            // 0x00CA8D0C: ADD w8, w8, w10            | W8 = (((((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize - 1
            val_7 = val_7 + this.kFixHashSize;
            // 0x00CA8D10: ADD w21, w8, #1            | W21 = ((((((((((historySize - 1) | ((historySize - 1)) >> 1) | (((historySize - 1) | ((historySize -
            val_12 = val_7 + 1;
            // 0x00CA8D14: B #0xca8d1c                |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x00CA8D18: ORR w21, wzr, #0x10000     | W21 = 65536(0x10000);                   
            val_12 = 65536;
            label_4:
            // 0x00CA8D1C: LDR w8, [x19, #0x68]       | W8 = this._hashSizeSum; //P2            
            // 0x00CA8D20: CMP w21, w8                | STATE = COMPARE(0x10000, this._hashSizeSum)
            // 0x00CA8D24: B.EQ #0xca8d50             | if (val_12 == this._hashSizeSum) goto label_5;
            if(val_12 == this._hashSizeSum)
            {
                goto label_5;
            }
            // 0x00CA8D28: STR w21, [x19, #0x68]      | this._hashSizeSum = 0x10000;             //  dest_result_addr=1152921513063515640
            this._hashSizeSum = val_12;
            // 0x00CA8D2C: ADRP x8, #0x367c000        | X8 = 57131008 (0x367C000);              
            // 0x00CA8D30: LDR x8, [x8, #0x1b8]       | X8 = 1152921505007033440;               
            // 0x00CA8D34: LDR x20, [x8]              | X20 = typeof(System.UInt32[]);          
            // 0x00CA8D38: MOV x0, x20                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00CA8D3C: BL #0x277461c              | X0 = sub_277461C( ?? typeof(System.UInt32[]), ????);
            // 0x00CA8D40: MOV w1, w21                | W1 = 65536 (0x10000);//ML01             
            // 0x00CA8D44: MOV x0, x20                | X0 = 1152921505007033440 (0x1000000017DA5C60);//ML01
            // 0x00CA8D48: BL #0x27c1608              | X0 = sub_27C1608( ?? typeof(System.UInt32[]), ????);
            // 0x00CA8D4C: STR x0, [x19, #0x58]       | this._hash = typeof(System.UInt32[]);    //  dest_result_addr=1152921513063515624
            this._hash = null;
            label_5:
            // 0x00CA8D50: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA8D54: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00CA8D58: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00CA8D5C: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00CA8D60: RET                        |  return;                                
            return;
            label_1:
            // 0x00CA8D64: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x00CA8D68: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x00CA8D6C: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            System.Exception val_9 = null;
            // 0x00CA8D70: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Exception), ????);
            // 0x00CA8D74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA8D78: MOV x19, x0                | X19 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA8D7C: BL #0x1c3e258              | .ctor();                                
            val_9 = new System.Exception();
            // 0x00CA8D80: ADRP x8, #0x3610000        | X8 = 56688640 (0x3610000);              
            // 0x00CA8D84: LDR x8, [x8, #0x8e8]       | X8 = 1152921513063490512;               
            // 0x00CA8D88: MOV x0, x19                | X0 = 1152921504609882112 (0x10000000002E5000);//ML01
            // 0x00CA8D8C: LDR x1, [x8]               | X1 = public System.Void SevenZip.Compression.LZ.BinTree::Create(uint historySize, uint keepAddBufferBefore, uint matchMaxLen, uint keepAddBufferAfter);
            // 0x00CA8D90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.Exception), ????);
            // 0x00CA8D94: BL #0xc8ae78               | X0 = HasCallbacks(callbackType:  public System.Void SevenZip.Compression.LZ.BinTree::Create(uint historySize, uint keepAddBufferBefore, uint matchMaxLen, uint keepAddBufferAfter));
            bool val_10 = HasCallbacks(callbackType:  public System.Void SevenZip.Compression.LZ.BinTree::Create(uint historySize, uint keepAddBufferBefore, uint matchMaxLen, uint keepAddBufferAfter));
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA8E4C (13274700), len: 3292  VirtAddr: 0x00CA8E4C RVA: 0x00CA8E4C token: 100681466 methodIndex: 54595 delegateWrapperIndex: 0 methodInvoker: 0
        public uint GetMatches(uint[] distances)
        {
            //
            // Disasemble & Code
            //  | 
            uint val_72;
            //  | 
            var val_73;
            //  | 
            var val_74;
            //  | 
            var val_75;
            //  | 
            var val_76;
            //  | 
            var val_77;
            //  | 
            var val_78;
            //  | 
            uint val_79;
            //  | 
            uint val_80;
            //  | 
            System.UInt32[] val_81;
            //  | 
            var val_82;
            //  | 
            var val_83;
            //  | 
            var val_84;
            //  | 
            System.UInt32[] val_85;
            //  | 
            var val_86;
            //  | 
            uint val_87;
            //  | 
            uint val_88;
            //  | 
            System.UInt32[] val_89;
            //  | 
            var val_90;
            //  | 
            System.UInt32[] val_91;
            //  | 
            var val_92;
            //  | 
            var val_93;
            //  | 
            var val_94;
            //  | 
            var val_95;
            //  | 
            var val_96;
            //  | 
            System.UInt32[] val_97;
            //  | 
            var val_98;
            //  | 
            var val_99;
            //  | 
            var val_100;
            //  | 
            var val_101;
            // 0x00CA8E4C: STP x28, x27, [sp, #-0x60]! | stack[1152921513063873488] = ???;  stack[1152921513063873496] = ???;  //  dest_result_addr=1152921513063873488 |  dest_result_addr=1152921513063873496
            // 0x00CA8E50: STP x26, x25, [sp, #0x10]  | stack[1152921513063873504] = ???;  stack[1152921513063873512] = ???;  //  dest_result_addr=1152921513063873504 |  dest_result_addr=1152921513063873512
            // 0x00CA8E54: STP x24, x23, [sp, #0x20]  | stack[1152921513063873520] = ???;  stack[1152921513063873528] = ???;  //  dest_result_addr=1152921513063873520 |  dest_result_addr=1152921513063873528
            // 0x00CA8E58: STP x22, x21, [sp, #0x30]  | stack[1152921513063873536] = ???;  stack[1152921513063873544] = ???;  //  dest_result_addr=1152921513063873536 |  dest_result_addr=1152921513063873544
            // 0x00CA8E5C: STP x20, x19, [sp, #0x40]  | stack[1152921513063873552] = ???;  stack[1152921513063873560] = ???;  //  dest_result_addr=1152921513063873552 |  dest_result_addr=1152921513063873560
            // 0x00CA8E60: STP x29, x30, [sp, #0x50]  | stack[1152921513063873568] = ???;  stack[1152921513063873576] = ???;  //  dest_result_addr=1152921513063873568 |  dest_result_addr=1152921513063873576
            // 0x00CA8E64: ADD x29, sp, #0x50         | X29 = (1152921513063873488 + 80) = 1152921513063873568 (0x10000001F813FC20);
            // 0x00CA8E68: SUB sp, sp, #0x50          | SP = (1152921513063873488 - 80) = 1152921513063873408 (0x10000001F813FB80);
            // 0x00CA8E6C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00CA8E70: LDRB w8, [x20, #0xb2]      | W8 = (bool)static_value_037340B2;       
            // 0x00CA8E74: MOV x19, x0                | X19 = 1152921513063885584 (0x10000001F8142B10);//ML01
            // 0x00CA8E78: STR x1, [sp, #0x20]        | stack[1152921513063873440] = distances;  //  dest_result_addr=1152921513063873440
            // 0x00CA8E7C: TBNZ w8, #0, #0xca8e98     | if (static_value_037340B2 == true) goto label_0;
            // 0x00CA8E80: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
            // 0x00CA8E84: LDR x8, [x8, #0x1c8]       | X8 = 0x2B8F56C;                         
            // 0x00CA8E88: LDR w0, [x8]               | W0 = 0x141D;                            
            // 0x00CA8E8C: BL #0x2782188              | X0 = sub_2782188( ?? 0x141D, ????);     
            // 0x00CA8E90: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA8E94: STRB w8, [x20, #0xb2]      | static_value_037340B2 = true;            //  dest_result_addr=57884850
            label_0:
            // 0x00CA8E98: LDR w25, [x19, #0x34]      | 
            // 0x00CA8E9C: LDR w11, [x19, #0x4c]      | W11 = this._matchMaxLen; //P2           
            // 0x00CA8EA0: LDR w10, [x19, #0x40]      | 
            // 0x00CA8EA4: ADD w8, w11, w25           | W8 = (this._matchMaxLen + W25);         
            uint val_1 = this._matchMaxLen + W25;
            // 0x00CA8EA8: CMP w8, w10                | STATE = COMPARE((this._matchMaxLen + W25), W10)
            // 0x00CA8EAC: STR w11, [sp, #0x10]       | stack[1152921513063873424] = this._matchMaxLen;  //  dest_result_addr=1152921513063873424
            // 0x00CA8EB0: B.LS #0xca8ed8             | if (val_1 <= W10) goto label_2;         
            if(val_1 <= W10)
            {
                goto label_2;
            }
            // 0x00CA8EB4: LDR w8, [x19, #0x74]       | W8 = this.kMinMatchCheck; //P2          
            // 0x00CA8EB8: SUB w9, w10, w25           | W9 = (W10 - W25);                       
            var val_2 = W10 - W25;
            // 0x00CA8EBC: STR w9, [sp, #0x10]        | stack[1152921513063873424] = (W10 - W25);  //  dest_result_addr=1152921513063873424
            // 0x00CA8EC0: CMP w9, w8                 | STATE = COMPARE((W10 - W25), this.kMinMatchCheck)
            // 0x00CA8EC4: B.HS #0xca8ed8             | if (val_2 >= this.kMinMatchCheck) goto label_2;
            if(val_2 >= this.kMinMatchCheck)
            {
                goto label_2;
            }
            // 0x00CA8EC8: MOV x0, x19                | X0 = 1152921513063885584 (0x10000001F8142B10);//ML01
            // 0x00CA8ECC: BL #0xca8924               | this.MovePos();                         
            this.MovePos();
            // 0x00CA8ED0: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_73 = 0;
            // 0x00CA8ED4: B #0xca9a44                |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x00CA8ED8: LDR w8, [x19, #0x48]       | W8 = this._cyclicBufferSize; //P2       
            uint val_68 = this._cyclicBufferSize;
            // 0x00CA8EDC: LDR w12, [x19, #0x2c]      | 
            // 0x00CA8EE0: LDRB w9, [x19, #0x6c]      | W9 = this.HASH_ARRAY; //P2              
            // 0x00CA8EE4: SUBS w8, w25, w8           | W8 = (W25 - this._cyclicBufferSize);    
            val_68 = W25 - val_68;
            // 0x00CA8EE8: CSEL w27, w8, wzr, hi      | W27 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;
            var val_3 = (val_1 > W10) ? (val_68) : 0;
            // 0x00CA8EEC: ADD w23, w25, w12          | W23 = (W25 + W12);                      
            var val_4 = W25 + W12;
            // 0x00CA8EF0: STR w12, [sp, #0x40]       | stack[1152921513063873472] = ???;        //  dest_result_addr=1152921513063873472
            // 0x00CA8EF4: CBZ w9, #0xca8f18          | if (this.HASH_ARRAY == false) goto label_4;
            if(this.HASH_ARRAY == false)
            {
                goto label_4;
            }
            // 0x00CA8EF8: ADRP x20, #0x35c8000       | X20 = 56393728 (0x35C8000);             
            // 0x00CA8EFC: LDR x20, [x20, #0x988]     | X20 = 1152921504832512000;              
            // 0x00CA8F00: LDR x0, [x20]              | X0 = typeof(SevenZip.CRC);              
            val_75 = null;
            // 0x00CA8F04: LDRB w8, [x0, #0x10a]      | W8 = SevenZip.CRC.__il2cppRuntimeField_10A;
            // 0x00CA8F08: TBNZ w8, #0, #0xca8f9c     | if (SevenZip.CRC.__il2cppRuntimeField_has_cctor != 0) goto label_5;
            // 0x00CA8F0C: STR w11, [sp, #0x2c]       | stack[1152921513063873452] = this._matchMaxLen;  //  dest_result_addr=1152921513063873452
            // 0x00CA8F10: STR w10, [sp, #0x3c]       | stack[1152921513063873468] = ???;        //  dest_result_addr=1152921513063873468
            // 0x00CA8F14: B #0xca8fb4                |  goto label_12;                         
            goto label_12;
            label_4:
            // 0x00CA8F18: LDR x20, [x19, #0x10]      | 
            // 0x00CA8F1C: STR w11, [sp, #0x2c]       | stack[1152921513063873452] = this._matchMaxLen;  //  dest_result_addr=1152921513063873452
            // 0x00CA8F20: STR w10, [sp, #0x3c]       | stack[1152921513063873468] = ???;        //  dest_result_addr=1152921513063873468
            // 0x00CA8F24: CBNZ x20, #0xca8f2c        | if ( != 0) goto label_7;                
            if(!=0)
            {
                goto label_7;
            }
            // 0x00CA8F28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x141D, ????);     
            label_7:
            // 0x00CA8F2C: LDR w8, [x20, #0x18]       | W8 = mem[57884696];                     
            // 0x00CA8F30: MOV w21, w23               | W21 = (W25 + W12);//m1                  
            // 0x00CA8F34: STR w23, [sp, #0x48]       | stack[1152921513063873480] = (W25 + W12);  //  dest_result_addr=1152921513063873480
            // 0x00CA8F38: CMP w23, w8                | STATE = COMPARE((W25 + W12), mem[57884696])
            // 0x00CA8F3C: B.LO #0xca8f4c             | if (val_4 < mem[57884696]) goto label_8;
            if(val_4 < mem[57884696])
            {
                goto label_8;
            }
            // 0x00CA8F40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x141D, ????);     
            // 0x00CA8F44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA8F48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x141D, ????);     
            label_8:
            // 0x00CA8F4C: ADD x8, x20, x21           | X8 = (57884672 + (W25 + W12));          
            var val_5 = 57884672 + val_4;
            // 0x00CA8F50: LDRB w20, [x8, #0x20]      | W20 = (57884672 + (W25 + W12)) + 32;    
            // 0x00CA8F54: LDR x22, [x19, #0x10]      | 
            // 0x00CA8F58: CBNZ x22, #0xca8f60        | if (X22 != 0) goto label_9;             
            if(X22 != 0)
            {
                goto label_9;
            }
            // 0x00CA8F5C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x141D, ????);     
            label_9:
            // 0x00CA8F60: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_69 = val_4;
            // 0x00CA8F64: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
            // 0x00CA8F68: ADD w9, w9, #1             | W9 = ((W25 + W12) + 1);                 
            val_69 = val_69 + 1;
            // 0x00CA8F6C: SXTW x23, w9               | X23 = (long)(int)(((W25 + W12) + 1));   
            // 0x00CA8F70: CMP w9, w8                 | STATE = COMPARE(((W25 + W12) + 1), X22 + 24)
            // 0x00CA8F74: B.LO #0xca8f84             | if (val_4 < X22 + 24) goto label_10;    
            if(val_69 < (X22 + 24))
            {
                goto label_10;
            }
            // 0x00CA8F78: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x141D, ????);     
            // 0x00CA8F7C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA8F80: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x141D, ????);     
            label_10:
            // 0x00CA8F84: ADD x8, x22, x23           | X8 = (X22 + (long)(int)(((W25 + W12) + 1)));
            var val_6 = X22 + (long)val_69;
            // 0x00CA8F88: LDRB w8, [x8, #0x20]       | W8 = (X22 + (long)(int)(((W25 + W12) + 1))) + 32;
            // 0x00CA8F8C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_76 = 0;
            // 0x00CA8F90: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_77 = 0;
            // 0x00CA8F94: BFI w20, w8, #8, #8        | W20 = (57884672 + (W25 + W12)) + 32 | (X22 + (long)(int)(((W25 + W12) + 1))) + 32
            // 0x00CA8F98: B #0xca9114                |  goto label_11;                         
            goto label_11;
            label_5:
            // 0x00CA8F9C: LDR w8, [x0, #0xbc]        | W8 = SevenZip.CRC.__il2cppRuntimeField_cctor_finished;
            // 0x00CA8FA0: STR w11, [sp, #0x2c]       | stack[1152921513063873452] = this._matchMaxLen;  //  dest_result_addr=1152921513063873452
            // 0x00CA8FA4: STR w10, [sp, #0x3c]       | stack[1152921513063873468] = ???;        //  dest_result_addr=1152921513063873468
            // 0x00CA8FA8: CBNZ w8, #0xca8fb4         | if (SevenZip.CRC.__il2cppRuntimeField_cctor_finished != 0) goto label_12;
            // 0x00CA8FAC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA8FB0: LDR x0, [x20]              | X0 = typeof(SevenZip.CRC);              
            val_75 = null;
            label_12:
            // 0x00CA8FB4: LDR x8, [x0, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00CA8FB8: LDR x22, [x19, #0x10]      | 
            // 0x00CA8FBC: LDR x21, [x8]              | X21 = SevenZip.CRC.Table;               
            // 0x00CA8FC0: CBNZ x22, #0xca8fc8        | if (X22 != 0) goto label_13;            
            if(X22 != 0)
            {
                goto label_13;
            }
            // 0x00CA8FC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_13:
            // 0x00CA8FC8: LDR w8, [x22, #0x18]       | W8 = X22 + 24;                          
            // 0x00CA8FCC: MOV w9, w23                | W9 = (W25 + W12);//m1                   
            // 0x00CA8FD0: MOV w23, w9                | W23 = (W25 + W12);//m1                  
            // 0x00CA8FD4: STR w9, [sp, #0x48]        | stack[1152921513063873480] = (W25 + W12);  //  dest_result_addr=1152921513063873480
            // 0x00CA8FD8: CMP w9, w8                 | STATE = COMPARE((W25 + W12), X22 + 24)  
            // 0x00CA8FDC: B.LO #0xca8fec             | if (val_4 < X22 + 24) goto label_14;    
            if(val_4 < (X22 + 24))
            {
                goto label_14;
            }
            // 0x00CA8FE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA8FE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA8FE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_14:
            // 0x00CA8FEC: ADD x8, x22, x23           | X8 = (X22 + (W25 + W12));               
            var val_7 = X22 + val_4;
            // 0x00CA8FF0: LDRB w22, [x8, #0x20]      | W22 = (X22 + (W25 + W12)) + 32;         
            // 0x00CA8FF4: CBNZ x21, #0xca8ffc        | if (SevenZip.CRC.Table != null) goto label_15;
            if(SevenZip.CRC.Table != null)
            {
                goto label_15;
            }
            // 0x00CA8FF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_15:
            // 0x00CA8FFC: LDR w8, [x21, #0x18]       | W8 = SevenZip.CRC.Table.Length;         
            // 0x00CA9000: CMP w22, w8                | STATE = COMPARE((X22 + (W25 + W12)) + 32, SevenZip.CRC.Table.Length)
            // 0x00CA9004: B.LO #0xca9014             | if ((X22 + (W25 + W12)) + 32 < SevenZip.CRC.Table.Length) goto label_16;
            if(((X22 + (W25 + W12)) + 32) < SevenZip.CRC.Table.Length)
            {
                goto label_16;
            }
            // 0x00CA9008: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA900C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9010: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_16:
            // 0x00CA9014: ADD x8, x21, x22, lsl #2   | X8 = (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2);
            System.UInt32[] val_8 = SevenZip.CRC.Table + (((X22 + (W25 + W12)) + 32) << 2);
            // 0x00CA9018: LDR w21, [x8, #0x20]       | W21 = (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32; //  not_find_field!2:32
            var val_72 = (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32;
            // 0x00CA901C: LDR x22, [x19, #0x10]      | 
            // 0x00CA9020: CBNZ x22, #0xca9028        | if ((X22 + (W25 + W12)) + 32 != 0) goto label_17;
            if(((X22 + (W25 + W12)) + 32) != 0)
            {
                goto label_17;
            }
            // 0x00CA9024: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_17:
            // 0x00CA9028: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_70 = val_4;
            // 0x00CA902C: LDR w8, [x22, #0x18]       | W8 = (X22 + (W25 + W12)) + 32 + 24;     
            // 0x00CA9030: ADD w9, w9, #1             | W9 = ((W25 + W12) + 1);                 
            val_70 = val_70 + 1;
            // 0x00CA9034: SXTW x23, w9               | X23 = (long)(int)(((W25 + W12) + 1));   
            // 0x00CA9038: CMP w9, w8                 | STATE = COMPARE(((W25 + W12) + 1), (X22 + (W25 + W12)) + 32 + 24)
            // 0x00CA903C: B.LO #0xca904c             | if (val_4 < (X22 + (W25 + W12)) + 32 + 24) goto label_18;
            if(val_70 < ((X22 + (W25 + W12)) + 32 + 24))
            {
                goto label_18;
            }
            // 0x00CA9040: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9044: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9048: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_18:
            // 0x00CA904C: ADD x8, x22, x23           | X8 = ((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1)));
            var val_9 = ((X22 + (W25 + W12)) + 32) + (long)val_70;
            // 0x00CA9050: LDRB w22, [x8, #0x20]      | W22 = ((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32;
            // 0x00CA9054: LDR x23, [x19, #0x10]      | 
            // 0x00CA9058: CBNZ x23, #0xca9060        | if ((long)(int)(((W25 + W12) + 1)) != 0) goto label_19;
            if((long)val_70 != 0)
            {
                goto label_19;
            }
            // 0x00CA905C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_19:
            // 0x00CA9060: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_71 = val_4;
            // 0x00CA9064: LDR w8, [x23, #0x18]       | W8 = (long)(int)(((W25 + W12) + 1)) + 24;
            // 0x00CA9068: ADD w9, w9, #2             | W9 = ((W25 + W12) + 2);                 
            val_71 = val_71 + 2;
            // 0x00CA906C: SXTW x26, w9               | X26 = (long)(int)(((W25 + W12) + 2));   
            // 0x00CA9070: CMP w9, w8                 | STATE = COMPARE(((W25 + W12) + 2), (long)(int)(((W25 + W12) + 1)) + 24)
            // 0x00CA9074: B.LO #0xca9084             | if (val_4 < (long)(int)(((W25 + W12) + 1)) + 24) goto label_20;
            if(val_71 < ((long)(int)(((W25 + W12) + 1)) + 24))
            {
                goto label_20;
            }
            // 0x00CA9078: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA907C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9080: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_20:
            // 0x00CA9084: LDR x8, [x20]              | X8 = typeof(SevenZip.CRC);              
            // 0x00CA9088: ADD x9, x23, x26           | X9 = ((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)));
            val_71 = (long)val_70 + (long)val_71;
            // 0x00CA908C: LDRB w23, [x9, #0x20]      | W23 = ((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) + 32;
            // 0x00CA9090: LDR x26, [x19, #0x10]      | 
            // 0x00CA9094: LDR x8, [x8, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00CA9098: LDR x20, [x8]              | X20 = SevenZip.CRC.Table;               
            // 0x00CA909C: CBNZ x26, #0xca90a4        | if ((long)(int)(((W25 + W12) + 2)) != 0) goto label_21;
            if((long)val_71 != 0)
            {
                goto label_21;
            }
            // 0x00CA90A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_21:
            // 0x00CA90A4: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_73 = val_4;
            // 0x00CA90A8: LDR w8, [x26, #0x18]       | W8 = (long)(int)(((W25 + W12) + 2)) + 24;
            // 0x00CA90AC: EOR w21, w22, w21          | W21 = (((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X2
            val_72 = (((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32) ^ val_72;
            // 0x00CA90B0: ADD w9, w9, #3             | W9 = ((W25 + W12) + 3);                 
            val_73 = val_73 + 3;
            // 0x00CA90B4: SXTW x22, w9               | X22 = (long)(int)(((W25 + W12) + 3));   
            // 0x00CA90B8: CMP w9, w8                 | STATE = COMPARE(((W25 + W12) + 3), (long)(int)(((W25 + W12) + 2)) + 24)
            // 0x00CA90BC: B.LO #0xca90cc             | if (val_4 < (long)(int)(((W25 + W12) + 2)) + 24) goto label_22;
            if(val_73 < ((long)(int)(((W25 + W12) + 2)) + 24))
            {
                goto label_22;
            }
            // 0x00CA90C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA90C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA90C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_22:
            // 0x00CA90CC: ADD x8, x26, x22           | X8 = ((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3)));
            var val_10 = (long)val_71 + (long)val_73;
            // 0x00CA90D0: LDRB w26, [x8, #0x20]      | W26 = ((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32;
            // 0x00CA90D4: EOR w22, w21, w23, lsl #8  | W22 = ((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X
            var val_11 = val_72 ^ ((((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) + 32) << 8);
            // 0x00CA90D8: CBNZ x20, #0xca90e0        | if (SevenZip.CRC.Table != null) goto label_23;
            if(SevenZip.CRC.Table != null)
            {
                goto label_23;
            }
            // 0x00CA90DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_23:
            // 0x00CA90E0: LDR w8, [x20, #0x18]       | W8 = SevenZip.CRC.Table.Length;         
            // 0x00CA90E4: AND w23, w21, #0x3ff       | W23 = ((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X
            val_77 = val_72 & 1023;
            // 0x00CA90E8: AND w21, w22, #0xffff      | W21 = (((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((
            val_76 = val_11 & 65535;
            // 0x00CA90EC: CMP w26, w8                | STATE = COMPARE(((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32, SevenZip.CRC.Table.Length)
            // 0x00CA90F0: B.LO #0xca9100             | if (((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32 < SevenZip.CRC.Table.Length) goto label_24;
            if((((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32) < SevenZip.CRC.Table.Length)
            {
                goto label_24;
            }
            // 0x00CA90F4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA90F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA90FC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_24:
            // 0x00CA9100: ADD x8, x20, x26, lsl #2   | X8 = (SevenZip.CRC.Table + (((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32) 
            System.UInt32[] val_12 = SevenZip.CRC.Table + ((((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32) << 2);
            // 0x00CA9104: LDR w8, [x8, #0x20]        | W8 = (SevenZip.CRC.Table + (((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32) << 2) + 32; //  not_find_field!2:32
            var val_74 = (SevenZip.CRC.Table + (((long)(int)(((W25 + W12) + 2)) + (long)(int)(((W25 + W12) + 3))) + 32) << 2) + 32;
            // 0x00CA9108: LDR w9, [x19, #0x64]       | W9 = this._hashMask; //P2               
            uint val_75 = this._hashMask;
            // 0x00CA910C: EOR w8, w22, w8, lsl #5    | W8 = (((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X
            val_74 = val_11 ^ (val_74 << 5);
            // 0x00CA9110: AND w20, w8, w9            | W20 = ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + (
            val_78 = val_74 & val_75;
            label_11:
            // 0x00CA9114: LDR x22, [x19, #0x58]      | X22 = this._hash; //P2                  
            // 0x00CA9118: LDR w24, [x19, #0x78]      | W24 = this.kFixHashSize; //P2           
            // 0x00CA911C: CBNZ x22, #0xca9124        | if (this._hash != null) goto label_25;  
            if(this._hash != null)
            {
                goto label_25;
            }
            // 0x00CA9120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_25:
            // 0x00CA9124: LDR w8, [x22, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9128: ADD w9, w24, w20           | W9 = (this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (Se
            val_75 = this.kFixHashSize + val_78;
            // 0x00CA912C: SXTW x24, w9               | X24 = (long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int);
            // 0x00CA9130: CMP w9, w8                 | STATE = COMPARE((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int, this._hash.Length)
            // 0x00CA9134: B.LO #0xca9144             | if (this._hashMask < this._hash.Length) goto label_26;
            if(val_75 < this._hash.Length)
            {
                goto label_26;
            }
            // 0x00CA9138: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA913C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9140: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_26:
            // 0x00CA9144: ADD x8, x22, x24, lsl #2   | X8 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)]; //PARR1 
            // 0x00CA9148: LDR w24, [x8, #0x20]       | W24 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0]
            val_79 = this._hash[(long)val_75];
            // 0x00CA914C: LDRB w8, [x19, #0x6c]      | W8 = this.HASH_ARRAY; //P2              
            // 0x00CA9150: CBZ w8, #0xca930c          | if (this.HASH_ARRAY == false) goto label_27;
            if(this.HASH_ARRAY == false)
            {
                goto label_27;
            }
            // 0x00CA9154: LDR x22, [x19, #0x58]      | X22 = this._hash; //P2                  
            // 0x00CA9158: STR w24, [sp, #0x4c]       | stack[1152921513063873484] = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];  //  dest_result_addr=1152921513063873484
            // 0x00CA915C: CBNZ x22, #0xca9164        | if (this._hash != null) goto label_28;  
            if(this._hash != null)
            {
                goto label_28;
            }
            // 0x00CA9160: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_28:
            // 0x00CA9164: LDR w8, [x22, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9168: MOV w24, w27               | W24 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;//m1
            // 0x00CA916C: CMP w23, w8                | STATE = COMPARE(((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023), this._hash.Length)
            // 0x00CA9170: B.LO #0xca9180             | if (val_77 < this._hash.Length) goto label_29;
            if(val_77 < this._hash.Length)
            {
                goto label_29;
            }
            // 0x00CA9174: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA917C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_29:
            // 0x00CA9180: ADD x8, x22, x23, lsl #2   | X8 = this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)]; //PARR1 
            // 0x00CA9184: LDR w22, [x8, #0x20]       | W22 = this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0]
            val_80 = this._hash[val_77];
            // 0x00CA9188: LDR x27, [x19, #0x58]      | X27 = this._hash; //P2                  
            // 0x00CA918C: CBNZ x27, #0xca9194        | if (this._hash != null) goto label_30;  
            if(this._hash != null)
            {
                goto label_30;
            }
            // 0x00CA9190: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_30:
            // 0x00CA9194: LDR w8, [x27, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9198: ADD w26, w21, #0x400       | W26 = ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + (
            var val_13 = val_76 + 1024;
            // 0x00CA919C: CMP w26, w8                | STATE = COMPARE(((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))), this._hash.Length)
            // 0x00CA91A0: B.LO #0xca91b0             | if (val_13 < this._hash.Length) goto label_31;
            if(val_13 < this._hash.Length)
            {
                goto label_31;
            }
            // 0x00CA91A4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA91A8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA91AC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_31:
            // 0x00CA91B0: ADD x8, x27, x26, lsl #2   | X8 = this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))]; //PARR1 
            // 0x00CA91B4: LDR x27, [x19, #0x58]      | X27 = this._hash; //P2                  
            // 0x00CA91B8: LDR w21, [x8, #0x20]       | W21 = this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))][0]
            uint val_76 = this._hash[val_13];
            // 0x00CA91BC: LDR w28, [x19, #0x34]      | 
            // 0x00CA91C0: CBNZ x27, #0xca91c8        | if (this._hash != null) goto label_32;  
            if(this._hash != null)
            {
                goto label_32;
            }
            // 0x00CA91C4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_32:
            // 0x00CA91C8: LDR w8, [x27, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA91CC: CMP w23, w8                | STATE = COMPARE(((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023), this._hash.Length)
            // 0x00CA91D0: B.LO #0xca91e0             | if (val_77 < this._hash.Length) goto label_33;
            if(val_77 < this._hash.Length)
            {
                goto label_33;
            }
            // 0x00CA91D4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA91D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA91DC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_33:
            // 0x00CA91E0: ADD x8, x27, x23, lsl #2   | X8 = this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)]; //PARR1 
            // 0x00CA91E4: STR w28, [x8, #0x20]       | this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0] = ;  //  dest_result_addr=0
            this._hash[val_77] = ;
            // 0x00CA91E8: LDR x23, [x19, #0x58]      | X23 = this._hash; //P2                  
            // 0x00CA91EC: LDR w27, [x19, #0x34]      | 
            // 0x00CA91F0: CBNZ x23, #0xca91f8        | if (this._hash != null) goto label_34;  
            if(this._hash != null)
            {
                goto label_34;
            }
            // 0x00CA91F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_34:
            // 0x00CA91F8: LDR w8, [x23, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA91FC: CMP w26, w8                | STATE = COMPARE(((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))), this._hash.Length)
            // 0x00CA9200: B.LO #0xca9210             | if (val_13 < this._hash.Length) goto label_35;
            if(val_13 < this._hash.Length)
            {
                goto label_35;
            }
            // 0x00CA9204: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9208: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA920C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_35:
            // 0x00CA9210: ADD x8, x23, x26, lsl #2   | X8 = this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))]; //PARR1 
            // 0x00CA9214: STR w27, [x8, #0x20]       | this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))][0] = this._hash;  //  dest_result_addr=0
            this._hash[val_13] = this._hash;
            // 0x00CA9218: MOV w27, w24               | W27 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;//m1
            val_74 = val_3;
            // 0x00CA921C: CMP w22, w27               | STATE = COMPARE(this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0], val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0)
            // 0x00CA9220: B.LS #0xca9320             | if (val_80 <= val_74) goto label_36;    
            if(val_80 <= val_74)
            {
                goto label_36;
            }
            // 0x00CA9224: LDR x23, [x19, #0x10]      | 
            // 0x00CA9228: LDR w24, [x19, #0x2c]      | 
            // 0x00CA922C: CBNZ x23, #0xca9234        | if (this._hash != null) goto label_37;  
            if(this._hash != null)
            {
                goto label_37;
            }
            // 0x00CA9230: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_37:
            // 0x00CA9234: LDR w8, [x23, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9238: ADD w9, w24, w22           | W9 = (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (l
            uint val_14 = val_3 + val_80;
            // 0x00CA923C: SXTW x24, w9               | X24 = (long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023));
            // 0x00CA9240: CMP w9, w8                 | STATE = COMPARE((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023), this._hash.Length)
            // 0x00CA9244: B.LO #0xca9254             | if (val_14 < this._hash.Length) goto label_38;
            if(val_14 < this._hash.Length)
            {
                goto label_38;
            }
            // 0x00CA9248: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA924C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9250: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_38:
            // 0x00CA9254: ADD x8, x23, x24           | X8 = this._hash[(long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023))]; //PARR1 
            // 0x00CA9258: LDRB w23, [x8, #0x20]      | W23 = this._hash[(long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023))][0]
            uint val_77 = this._hash[(long)val_14];
            // 0x00CA925C: LDR x26, [x19, #0x10]      | 
            // 0x00CA9260: MOV w28, w27               | W28 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;//m1
            // 0x00CA9264: CBNZ x26, #0xca926c        | if (((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) != 0) goto label_39;
            if(val_13 != 0)
            {
                goto label_39;
            }
            // 0x00CA9268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_39:
            // 0x00CA926C: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            // 0x00CA9270: LDR w8, [x26, #0x18]       | W8 = ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) + 24;
            // 0x00CA9274: MOV w27, w9                | W27 = (W25 + W12);//m1                  
            // 0x00CA9278: CMP w9, w8                 | STATE = COMPARE((W25 + W12), ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) + 24)
            // 0x00CA927C: B.LO #0xca928c             | if (val_4 < ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) + 24) goto label_40;
            if(val_4 < (((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2))) + 24))
            {
                goto label_40;
            }
            // 0x00CA9280: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9284: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9288: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_40:
            // 0x00CA928C: ADD x8, x26, x27           | X8 = (((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + (
            var val_15 = val_13 + val_4;
            // 0x00CA9290: LDRB w8, [x8, #0x20]       | W8 = (((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)) + 32;
            // 0x00CA9294: CMP w23, w8                | STATE = COMPARE(this._hash[(long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023))][0], (((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)) + 32)
            // 0x00CA9298: B.NE #0xca932c             | if (this._hash[(long)val_14] != (((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)) + 32) goto label_41;
            if(val_77 != ((((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)) + 32))
            {
                goto label_41;
            }
            // 0x00CA929C: LDR x8, [sp, #0x20]        | X8 = distances;                         
            val_81 = distances;
            // 0x00CA92A0: CBNZ x8, #0xca92b0         | if (distances != 0) goto label_42;      
            if(val_81 != 0)
            {
                goto label_42;
            }
            // 0x00CA92A4: MOV x23, x8                | X23 = distances;//m1                    
            // 0x00CA92A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA92AC: MOV x8, x23                | X8 = distances;//m1                     
            val_81 = val_81;
            label_42:
            // 0x00CA92B0: MOV x24, x8                | X24 = distances;//m1                    
            // 0x00CA92B4: LDR x8, [x24, #0x18]       | X8 = distances + 24;                    
            val_82 = mem[distances + 24];
            val_82 = distances + 24;
            // 0x00CA92B8: CBNZ w8, #0xca92cc         | if (distances + 24 != 0) goto label_43; 
            if(val_82 != 0)
            {
                goto label_43;
            }
            // 0x00CA92BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA92C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA92C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA92C8: LDR x8, [x24, #0x18]       | X8 = distances + 24;                    
            val_82 = mem[distances + 24];
            val_82 = distances + 24;
            label_43:
            // 0x00CA92CC: ORR w9, wzr, #2            | W9 = 2(0x2);                            
            // 0x00CA92D0: STR w9, [x24, #0x20]       | mem2[0] = 0x2;                           //  dest_result_addr=0
            mem2[0] = 2;
            // 0x00CA92D4: LDR w9, [x19, #0x34]       | 
            // 0x00CA92D8: MVN w10, w22               | W10 = ~(this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0]);
            // 0x00CA92DC: CMP w8, #1                 | STATE = COMPARE(distances + 24, 0x1)    
            // 0x00CA92E0: MOV w27, w28               | W27 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;//m1
            val_74 = val_74;
            // 0x00CA92E4: ADD w23, w9, w10           | W23 = (2 + ~(this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ
            var val_16 = 2 + (~val_80);
            // 0x00CA92E8: B.HI #0xca92f8             | if (val_82 > 0x1) goto label_44;        
            if(val_82 > 1)
            {
                goto label_44;
            }
            // 0x00CA92EC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA92F0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA92F4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_44:
            // 0x00CA92F8: STR w23, [x24, #0x24]      | mem2[0] = (2 + ~(this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0]));  //  dest_result_addr=0
            mem2[0] = val_16;
            // 0x00CA92FC: ORR w26, wzr, #2           | W26 = 2(0x2);                           
            val_83 = 2;
            // 0x00CA9300: ORR w23, wzr, #2           | W23 = 2(0x2);                           
            val_84 = 2;
            // 0x00CA9304: STR x24, [sp, #0x20]       | stack[1152921513063873440] = distances;  //  dest_result_addr=1152921513063873440
            // 0x00CA9308: B #0xca9338                |  goto label_47;                         
            goto label_47;
            label_27:
            // 0x00CA930C: MOV w8, wzr                | W8 = 0 (0x0);//ML01                     
            // 0x00CA9310: STR w8, [sp, #0x30]        | stack[1152921513063873456] = 0x0;        //  dest_result_addr=1152921513063873456
            // 0x00CA9314: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA9318: STR w8, [sp, #0x14]        | stack[1152921513063873428] = 0x1;        //  dest_result_addr=1152921513063873428
            // 0x00CA931C: B #0xca9488                |  goto label_46;                         
            goto label_46;
            label_36:
            // 0x00CA9320: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_84 = 0;
            // 0x00CA9324: ORR w26, wzr, #1           | W26 = 1(0x1);                           
            val_83 = 1;
            // 0x00CA9328: B #0xca9338                |  goto label_47;                         
            goto label_47;
            label_41:
            // 0x00CA932C: MOV w23, wzr               | W23 = 0 (0x0);//ML01                    
            val_84 = 0;
            // 0x00CA9330: ORR w26, wzr, #1           | W26 = 1(0x1);                           
            val_83 = 1;
            // 0x00CA9334: MOV w27, w28               | W27 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;//m1
            val_74 = val_74;
            label_47:
            // 0x00CA9338: CMP w21, w27               | STATE = COMPARE(this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))][0], val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0)
            // 0x00CA933C: B.LS #0xca9458             | if (this._hash[val_13] <= val_74) goto label_48;
            if(val_76 <= val_74)
            {
                goto label_48;
            }
            // 0x00CA9340: STR w27, [sp, #0x34]       | stack[1152921513063873460] = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;  //  dest_result_addr=1152921513063873460
            // 0x00CA9344: LDR x27, [x19, #0x10]      | 
            // 0x00CA9348: LDR w24, [x19, #0x2c]      | 
            // 0x00CA934C: CBNZ x27, #0xca9354        | if (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 != 0) goto label_49;
            if(val_74 != 0)
            {
                goto label_49;
            }
            // 0x00CA9350: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_49:
            // 0x00CA9354: LDR w8, [x27, #0x18]       | W8 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24;
            // 0x00CA9358: ADD w9, w24, w21           | W9 = ((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W1
            uint val_17 = (long)val_14 + val_76;
            // 0x00CA935C: SXTW x24, w9               | X24 = (long)(int)(((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) );
            // 0x00CA9360: CMP w9, w8                 | STATE = COMPARE(((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) , val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24)
            // 0x00CA9364: B.LO #0xca9374             | if (val_17 < val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24) goto label_50;
            if(val_17 < (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24))
            {
                goto label_50;
            }
            // 0x00CA9368: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA936C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9370: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_50:
            // 0x00CA9374: ADD x8, x27, x24           | X8 = (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (long)(int)(((long)(int)((val_1 > W10 ? (W2
            var val_18 = val_74 + (long)val_17;
            // 0x00CA9378: LDRB w27, [x8, #0x20]      | W27 = (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (long)(int)(((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1)) + 32;
            // 0x00CA937C: LDR x28, [x19, #0x10]      | 
            // 0x00CA9380: CBNZ x28, #0xca9388        | if (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 != 0) goto label_51;
            if(val_74 != 0)
            {
                goto label_51;
            }
            // 0x00CA9384: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_51:
            // 0x00CA9388: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            // 0x00CA938C: LDR w8, [x28, #0x18]       | W8 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24;
            // 0x00CA9390: MOV w24, w9                | W24 = (W25 + W12);//m1                  
            // 0x00CA9394: CMP w9, w8                 | STATE = COMPARE((W25 + W12), val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24)
            // 0x00CA9398: B.LO #0xca93a8             | if (val_4 < val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24) goto label_52;
            if(val_4 < (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + 24))
            {
                goto label_52;
            }
            // 0x00CA939C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA93A0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA93A4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_52:
            // 0x00CA93A8: ADD x8, x28, x24           | X8 = (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (W25 + W12));
            var val_19 = val_74 + val_4;
            // 0x00CA93AC: LDRB w8, [x8, #0x20]       | W8 = (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (W25 + W12)) + 32;
            // 0x00CA93B0: CMP w27, w8                | STATE = COMPARE((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (long)(int)(((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1)) + 32, (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (W25 + W12)) + 32)
            // 0x00CA93B4: B.NE #0xca9454             | if ((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (long)(int)(((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1)) + 32 != (val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (W25 + W12)) + 32) goto label_53;
            if(((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (long)(int)(((long)(int)((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1)) + 32) != ((val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0 + (W25 + W12)) + 32))
            {
                goto label_53;
            }
            // 0x00CA93B8: SUB w8, w23, #2            | W8 = (val_84 - 2);                      
            var val_20 = val_84 - 2;
            // 0x00CA93BC: CMP w21, w22               | STATE = COMPARE(this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))][0], this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0])
            // 0x00CA93C0: CSEL w24, w8, w23, eq      | W24 = this._hash[val_13] == val_80 ? (val_84 - 2) : val_84;
            var val_21 = (val_76 == val_80) ? (val_20) : (val_84);
            // 0x00CA93C4: LDR x8, [sp, #0x20]        | X8 = distances;                         
            val_85 = val_81;
            // 0x00CA93C8: CBNZ x8, #0xca93d8         | if (distances != 0) goto label_54;      
            if(val_85 != 0)
            {
                goto label_54;
            }
            // 0x00CA93CC: MOV x22, x8                | X22 = distances;//m1                    
            // 0x00CA93D0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA93D4: MOV x8, x22                | X8 = distances;//m1                     
            val_85 = val_85;
            label_54:
            // 0x00CA93D8: MOV x28, x8                | X28 = distances;//m1                    
            // 0x00CA93DC: LDR x8, [x28, #0x18]       | X8 = distances + 24;                    
            val_86 = mem[distances + 24];
            val_86 = distances + 24;
            // 0x00CA93E0: ORR w22, w24, #1           | W22 = (this._hash[val_13] == val_80 ? (val_84 - 2) : val_84 | 1);
            var val_22 = val_21 | 1;
            // 0x00CA93E4: MOV w23, w24               | W23 = this._hash[val_13] == val_80 ? (val_84 - 2) : val_84;//m1
            // 0x00CA93E8: CMP w24, w8                | STATE = COMPARE(this._hash[val_13] == val_80 ? (val_84 - 2) : val_84, distances + 24)
            // 0x00CA93EC: B.LO #0xca9400             | if (val_21 < val_86) goto label_55;     
            if(val_21 < val_86)
            {
                goto label_55;
            }
            // 0x00CA93F0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA93F4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA93F8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA93FC: LDR x8, [x28, #0x18]       | X8 = distances + 24;                    
            val_86 = mem[distances + 24];
            val_86 = distances + 24;
            label_55:
            // 0x00CA9400: ADD x9, x28, x23, lsl #2   | X9 = (distances + (this._hash[val_13] == val_80 ? (val_84 - 2) : val_84) << 2);
            System.UInt32[] val_23 = val_85 + ((this._hash[val_13] == val_80 ? (val_84 - 2) : val_84) << 2);
            // 0x00CA9404: ORR w10, wzr, #3           | W10 = 3(0x3);                           
            // 0x00CA9408: STR w10, [x9, #0x20]       | mem2[0] = 0x3;                           //  dest_result_addr=0
            mem2[0] = 3;
            // 0x00CA940C: LDR w9, [x19, #0x34]       | 
            // 0x00CA9410: LDR w24, [sp, #0x4c]       | W24 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];
            val_79 = val_79;
            // 0x00CA9414: MVN w10, w21               | W10 = ~(this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))][0]);
            // 0x00CA9418: ADD w23, w22, #1           | W23 = ((this._hash[val_13] == val_80 ? (val_84 - 2) : val_84 | 1) + 1);
            val_84 = val_22 + 1;
            // 0x00CA941C: MOV w26, w22               | W26 = (this._hash[val_13] == val_80 ? (val_84 - 2) : val_84 | 1);//m1
            // 0x00CA9420: ADD w27, w9, w10           | W27 = ((distances + (this._hash[val_13] == val_80 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[((((
            System.UInt32[] val_24 = val_23 + (~val_76);
            // 0x00CA9424: CMP w22, w8                | STATE = COMPARE((this._hash[val_13] == val_80 ? (val_84 - 2) : val_84 | 1), distances + 24)
            // 0x00CA9428: B.LO #0xca9438             | if (val_22 < val_86) goto label_56;     
            if(val_22 < val_86)
            {
                goto label_56;
            }
            // 0x00CA942C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9430: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9434: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_56:
            // 0x00CA9438: ADD x8, x28, x26, lsl #2   | X8 = (distances + ((this._hash[val_13] == val_80 ? (val_84 - 2) : val_84 | 1)) << 2);
            System.UInt32[] val_25 = val_85 + (((this._hash[val_13] == val_80 ? (val_84 - 2) : val_84 | 1)) << 2);
            // 0x00CA943C: STR w27, [x8, #0x20]       | mem2[0] = ((distances + (this._hash[val_13] == val_80 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W1;  //  dest_result_addr=0
            mem2[0] = val_24;
            // 0x00CA9440: LDR w27, [sp, #0x34]       | W27 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;
            val_74 = val_74;
            // 0x00CA9444: ORR w26, wzr, #3           | W26 = 3(0x3);                           
            val_83 = 3;
            // 0x00CA9448: MOV w22, w21               | W22 = this._hash[((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)(((W25 + W12) + 2)))][0];//m1
            val_80 = val_76;
            // 0x00CA944C: STR x28, [sp, #0x20]       | stack[1152921513063873440] = distances;  //  dest_result_addr=1152921513063873440
            // 0x00CA9450: B #0xca945c                |  goto label_57;                         
            goto label_57;
            label_53:
            // 0x00CA9454: LDR w27, [sp, #0x34]       | W27 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;
            val_74 = val_74;
            label_48:
            // 0x00CA9458: LDR w24, [sp, #0x4c]       | W24 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];
            val_79 = val_79;
            label_57:
            // 0x00CA945C: CMP w23, #0                | STATE = COMPARE(0x0, 0x0)               
            // 0x00CA9460: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00CA9464: CSET w10, ne               | W10 = val_84 != 0x0 ? 1 : 0;            
            var val_26 = (val_84 != 0) ? 1 : 0;
            // 0x00CA9468: CMP w22, w24               | STATE = COMPARE(this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0], this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0])
            // 0x00CA946C: CSET w11, eq               | W11 = val_80 == val_79 ? 1 : 0;         
            var val_27 = (val_80 == val_79) ? 1 : 0;
            // 0x00CA9470: SUB w8, w23, #2            | W8 = (val_84 - 2);                      
            var val_28 = val_84 - 2;
            // 0x00CA9474: TST w11, w10               | STATE = COMPARE(val_80 == val_79 ? 1 : 0, val_84 != 0x0 ? 1 : 0)
            // 0x00CA9478: CSEL w9, w9, w26, ne       | W9 = val_27 != val_26 ? 1 : val_83;     
            var val_29 = (val_27 != val_26) ? (1) : (val_83);
            // 0x00CA947C: CSEL w8, w8, w23, ne       | W8 = val_27 != val_26 ? (val_84 - 2) : val_84;
            var val_30 = (val_27 != val_26) ? (val_28) : (val_84);
            // 0x00CA9480: STR w9, [sp, #0x14]        | stack[1152921513063873428] = val_27 != val_26 ? 1 : val_83;  //  dest_result_addr=1152921513063873428
            // 0x00CA9484: STR w8, [sp, #0x30]        | stack[1152921513063873456] = val_27 != val_26 ? (val_84 - 2) : val_84;  //  dest_result_addr=1152921513063873456
            label_46:
            // 0x00CA9488: LDR x21, [x19, #0x58]      | X21 = this._hash; //P2                  
            // 0x00CA948C: LDR w23, [x19, #0x78]      | W23 = this.kFixHashSize; //P2           
            // 0x00CA9490: LDR w22, [x19, #0x34]      | 
            // 0x00CA9494: CBNZ x21, #0xca949c        | if (this._hash != null) goto label_58;  
            if(this._hash != null)
            {
                goto label_58;
            }
            // 0x00CA9498: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_58:
            // 0x00CA949C: LDR w8, [x21, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA94A0: ADD w9, w23, w20           | W9 = (this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (Se
            uint val_31 = this.kFixHashSize + val_78;
            // 0x00CA94A4: SXTW x20, w9               | X20 = (long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int);
            // 0x00CA94A8: CMP w9, w8                 | STATE = COMPARE((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int, this._hash.Length)
            // 0x00CA94AC: B.LO #0xca94bc             | if (val_31 < this._hash.Length) goto label_59;
            if(val_31 < this._hash.Length)
            {
                goto label_59;
            }
            // 0x00CA94B0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA94B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA94B8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_59:
            // 0x00CA94BC: ADD x8, x21, x20, lsl #2   | X8 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)]; //PARR1 
            // 0x00CA94C0: STR w22, [x8, #0x20]       | this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0] = this._hash[((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) & 1023)][0];  //  dest_result_addr=0
            this._hash[(long)val_31] = val_80;
            // 0x00CA94C4: LDR w8, [x19, #0x44]       | W8 = this._cyclicBufferPos; //P2        
            val_87 = this._cyclicBufferPos;
            // 0x00CA94C8: LDR w23, [x19, #0x70]      | W23 = this.kNumHashDirectBytes; //P2    
            val_88 = this.kNumHashDirectBytes;
            // 0x00CA94CC: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00CA94D0: CMP w24, w27               | STATE = COMPARE(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0], val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0)
            // 0x00CA94D4: LSL w10, w8, #1            | W10 = (this._cyclicBufferPos << 1);     
            uint val_32 = val_87 << 1;
            // 0x00CA94D8: BFI w9, w8, #1, #0x1f      | W9 = 1 | this._cyclicBufferPos          
            // 0x00CA94DC: STR w10, [sp, #0xc]        | stack[1152921513063873420] = (this._cyclicBufferPos << 1);  //  dest_result_addr=1152921513063873420
            // 0x00CA94E0: STR w9, [sp, #0x44]        | stack[1152921513063873476] = 0x1;        //  dest_result_addr=1152921513063873476
            // 0x00CA94E4: B.LS #0xca9600             | if (val_79 <= val_74) goto label_66;    
            if(val_79 <= val_74)
            {
                goto label_66;
            }
            // 0x00CA94E8: CBZ w23, #0xca9600         | if (this.kNumHashDirectBytes == 0) goto label_66;
            if(val_88 == 0)
            {
                goto label_66;
            }
            // 0x00CA94EC: LDR x20, [x19, #0x10]      | 
            // 0x00CA94F0: LDR w21, [x19, #0x2c]      | 
            // 0x00CA94F4: CBNZ x20, #0xca94fc        | if ((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int) != 0) goto label_62;
            if((long)val_31 != 0)
            {
                goto label_62;
            }
            // 0x00CA94F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_62:
            // 0x00CA94FC: LDR w8, [x20, #0x18]       | W8 = (long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int) + 24;
            // 0x00CA9500: ADD w9, w23, w24           | W9 = (this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)
            uint val_33 = val_88 + val_79;
            // 0x00CA9504: ADD w9, w9, w21            | W9 = ((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12
            val_33 = val_33 + this._hash;
            // 0x00CA9508: SXTW x21, w9               | X21 = (long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +);
            // 0x00CA950C: CMP w9, w8                 | STATE = COMPARE(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +, (long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int) + 24)
            // 0x00CA9510: B.LO #0xca9520             | if (val_33 < (long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int) + 24) goto label_63;
            if(val_33 < ((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int) + 24))
            {
                goto label_63;
            }
            // 0x00CA9514: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9518: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA951C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_63:
            // 0x00CA9520: ADD x8, x20, x21           | X8 = ((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1)
            var val_34 = (long)val_31 + (long)val_33;
            // 0x00CA9524: LDR x21, [x19, #0x10]      | 
            // 0x00CA9528: LDRB w20, [x8, #0x20]      | W20 = ((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + 32;
            // 0x00CA952C: LDR w22, [x19, #0x70]      | W22 = this.kNumHashDirectBytes; //P2    
            // 0x00CA9530: CBNZ x21, #0xca9538        | if ((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +) != 0) goto label_64;
            if((long)val_33 != 0)
            {
                goto label_64;
            }
            // 0x00CA9534: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_64:
            // 0x00CA9538: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_78 = val_4;
            // 0x00CA953C: LDR w8, [x21, #0x18]       | W8 = (long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +) + 24;
            // 0x00CA9540: ADD w9, w22, w9            | W9 = (this.kNumHashDirectBytes + (W25 + W12));
            val_78 = this.kNumHashDirectBytes + val_78;
            // 0x00CA9544: SXTW x22, w9               | X22 = (long)(int)((this.kNumHashDirectBytes + (W25 + W12)));
            // 0x00CA9548: CMP w9, w8                 | STATE = COMPARE((this.kNumHashDirectBytes + (W25 + W12)), (long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +) + 24)
            // 0x00CA954C: B.LO #0xca955c             | if (val_4 < (long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +) + 24) goto label_65;
            if(val_78 < ((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) +) + 24))
            {
                goto label_65;
            }
            // 0x00CA9550: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9554: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9558: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_65:
            // 0x00CA955C: ADD x8, x21, x22           | X8 = ((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22
            var val_35 = (long)val_33 + (long)val_78;
            // 0x00CA9560: LDRB w8, [x8, #0x20]       | W8 = ((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12))  + 32;
            val_87 = mem[((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12))  + 32];
            val_87 = ((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12))  + 32;
            // 0x00CA9564: CMP w20, w8                | STATE = COMPARE(((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + 32, ((long)(int)(((this.kNumHashDirectBytes + this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12))  + 32)
            // 0x00CA9568: B.EQ #0xca9600             | if (((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + 32 == val_87) goto label_66;
            if((((long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + 32) == val_87)
            {
                goto label_66;
            }
            // 0x00CA956C: LDR w8, [x19, #0x70]       | W8 = this.kNumHashDirectBytes; //P2     
            // 0x00CA9570: MOV w26, w23               | W26 = this.kNumHashDirectBytes;//m1     
            // 0x00CA9574: STR w8, [sp, #0x14]        | stack[1152921513063873428] = this.kNumHashDirectBytes;  //  dest_result_addr=1152921513063873428
            // 0x00CA9578: LDR x8, [sp, #0x20]        | X8 = distances;                         
            val_89 = val_85;
            // 0x00CA957C: CBNZ x8, #0xca958c         | if (distances != 0) goto label_67;      
            if(val_89 != 0)
            {
                goto label_67;
            }
            // 0x00CA9580: MOV x20, x8                | X20 = distances;//m1                    
            // 0x00CA9584: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9588: MOV x8, x20                | X8 = distances;//m1                     
            val_89 = val_89;
            label_67:
            // 0x00CA958C: MOV x23, x8                | X23 = distances;//m1                    
            // 0x00CA9590: LDR w22, [sp, #0x30]       | W22 = val_27 != val_26 ? (val_84 - 2) : val_84;
            var val_79 = val_30;
            // 0x00CA9594: LDR x8, [x23, #0x18]       | X8 = distances + 24;                    
            val_90 = mem[distances + 24];
            val_90 = distances + 24;
            // 0x00CA9598: ADD w20, w22, #1           | W20 = (val_27 != val_26 ? (val_84 - 2) : val_84 + 1);
            var val_36 = val_79 + 1;
            // 0x00CA959C: MOV w21, w22               | W21 = val_27 != val_26 ? (val_84 - 2) : val_84;//m1
            // 0x00CA95A0: CMP w22, w8                | STATE = COMPARE(val_27 != val_26 ? (val_84 - 2) : val_84, distances + 24)
            // 0x00CA95A4: B.LO #0xca95b8             | if (val_30 < val_90) goto label_68;     
            if(val_79 < val_90)
            {
                goto label_68;
            }
            // 0x00CA95A8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA95AC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA95B0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA95B4: LDR x8, [x23, #0x18]       | X8 = distances + 24;                    
            val_90 = mem[distances + 24];
            val_90 = distances + 24;
            label_68:
            // 0x00CA95B8: LDR w10, [sp, #0x14]       | W10 = this.kNumHashDirectBytes;         
            // 0x00CA95BC: ADD x9, x23, x21, lsl #2   | X9 = (distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2);
            System.UInt32[] val_37 = val_89 + ((val_27 != val_26 ? (val_84 - 2) : val_84) << 2);
            // 0x00CA95C0: ADD w22, w22, #2           | W22 = (val_27 != val_26 ? (val_84 - 2) : val_84 + 2);
            val_79 = val_79 + 2;
            // 0x00CA95C4: STR w22, [sp, #0x30]       | stack[1152921513063873456] = (val_27 != val_26 ? (val_84 - 2) : val_84 + 2);  //  dest_result_addr=1152921513063873456
            // 0x00CA95C8: STR w10, [x9, #0x20]       | mem2[0] = this.kNumHashDirectBytes;      //  dest_result_addr=0
            mem2[0] = this.kNumHashDirectBytes;
            // 0x00CA95CC: LDR w9, [x19, #0x34]       | 
            // 0x00CA95D0: MVN w10, w24               | W10 = ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0]);
            // 0x00CA95D4: MOV w21, w20               | W21 = (val_27 != val_26 ? (val_84 - 2) : val_84 + 1);//m1
            // 0x00CA95D8: CMP w20, w8                | STATE = COMPARE((val_27 != val_26 ? (val_84 - 2) : val_84 + 1), distances + 24)
            // 0x00CA95DC: ADD w22, w9, w10           | W22 = ((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((thi
            System.UInt32[] val_38 = val_37 + (~val_79);
            // 0x00CA95E0: B.LO #0xca95f0             | if (val_36 < val_90) goto label_69;     
            if(val_36 < val_90)
            {
                goto label_69;
            }
            // 0x00CA95E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA95E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA95EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_69:
            // 0x00CA95F0: ADD x8, x23, x21, lsl #2   | X8 = (distances + ((val_27 != val_26 ? (val_84 - 2) : val_84 + 1)) << 2);
            val_87 = val_89 + (((val_27 != val_26 ? (val_84 - 2) : val_84 + 1)) << 2);
            // 0x00CA95F4: STR x23, [sp, #0x20]       | stack[1152921513063873440] = distances;  //  dest_result_addr=1152921513063873440
            // 0x00CA95F8: MOV w23, w26               | W23 = this.kNumHashDirectBytes;//m1     
            val_88 = val_88;
            // 0x00CA95FC: STR w22, [x8, #0x20]       | mem2[0] = ((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Tabl;  //  dest_result_addr=0
            mem2[0] = val_38;
            label_66:
            // 0x00CA9600: CMP w24, w27               | STATE = COMPARE(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0], val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0)
            // 0x00CA9604: B.LS #0xca99d0             | if (val_79 <= val_74) goto label_70;    
            if(val_79 <= val_74)
            {
                goto label_70;
            }
            // 0x00CA9608: ADD x26, x19, #0x50        | X26 = this._son;//AP2 res_addr=1152921513063885664
            val_91 = this._son;
            // 0x00CA960C: STR w27, [sp, #0x34]       | stack[1152921513063873460] = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;  //  dest_result_addr=1152921513063873460
            // 0x00CA9610: LDR w28, [x19, #0x60]      | W28 = this._cutValue; //P2              
            // 0x00CA9614: STR x26, [sp, #0x18]       | stack[1152921513063873432] = this._son;  //  dest_result_addr=1152921513063873432
            // 0x00CA9618: LDP w11, w8, [sp, #0x3c]   | W11 = ; W8 = ;                           //  | 
            // 0x00CA961C: LDR w10, [sp, #0x2c]       | W10 = this._matchMaxLen;                
            uint val_80 = this._matchMaxLen;
            // 0x00CA9620: STR w23, [sp, #0x38]       | stack[1152921513063873464] = this.kNumHashDirectBytes;  //  dest_result_addr=1152921513063873464
            // 0x00CA9624: MVN w9, w11                | W9 = ~(W11);                            
            // 0x00CA9628: ADD w10, w10, w25          | W10 = (this._matchMaxLen + W25);        
            val_80 = val_80 + W25;
            // 0x00CA962C: MVN w10, w10               | W10 = ~((this._matchMaxLen + W25));     
            // 0x00CA9630: ADD w21, w25, w8           | W21 = (W25 + ???);                      
            var val_39 = W25 + (???);
            // 0x00CA9634: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            uint val_81 = -2;
            // 0x00CA9638: CMP w9, w10                | STATE = COMPARE(~(???), ~((this._matchMaxLen + W25)))
            // 0x00CA963C: SUB w8, w8, w25            | W8 = (-2 - W25);                        
            val_81 = val_81 - W25;
            // 0x00CA9640: CSINV w9, w10, w11, ls     | W9 = ~(???) <= ~this._matchMaxLen ? ~((this._matchMaxLen + W25)) : ( !???);
            var val_40 = ((~(???)) <= (~val_80)) ? (~val_80) : (!(???));
            // 0x00CA9644: SUB w27, w8, w9            | W27 = ((-2 - W25) - ~(???) <= ~this._matchMaxLen ? ~((this._matchMaxLen + W25)) : ( !???));
            val_74 = val_81 - val_40;
            label_104:
            // 0x00CA9648: LDR w1, [sp, #0x38]        | W1 = this.kNumHashDirectBytes;          
            // 0x00CA964C: STR w23, [sp, #0x2c]       | stack[1152921513063873452] = this.kNumHashDirectBytes;  //  dest_result_addr=1152921513063873452
            label_99:
            // 0x00CA9650: CBZ w28, #0xca99d4         | if (this._cutValue == 0) goto label_105;
            if(this._cutValue == 0)
            {
                goto label_105;
            }
            // 0x00CA9654: LDR w8, [x19, #0x34]       | 
            // 0x00CA9658: LDR w9, [x19, #0x44]       | W9 = this._cyclicBufferPos; //P2        
            // 0x00CA965C: SUB w8, w8, w24            | W8 = ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long
            val_81 = val_81 - val_79;
            // 0x00CA9660: SUBS w25, w9, w8           | W25 = (this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 +
            val_92 = this._cyclicBufferPos - val_81;
            // 0x00CA9664: STR w8, [sp, #0x3c]        | stack[1152921513063873468] = ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long);  //  dest_result_addr=1152921513063873468
            // 0x00CA9668: B.HS #0xca9674             | if (~(???) >= ~this._matchMaxLen) goto label_72;
            if((~(???)) >= (~val_80))
            {
                goto label_72;
            }
            // 0x00CA966C: LDR w8, [x19, #0x48]       | W8 = this._cyclicBufferSize; //P2       
            // 0x00CA9670: ADD w25, w25, w8           | W25 = ((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 
            val_92 = val_92 + this._cyclicBufferSize;
            label_72:
            // 0x00CA9674: LDR w22, [x19, #0x2c]      | 
            // 0x00CA9678: LDR w2, [sp, #0x2c]        | W2 = this.kNumHashDirectBytes;          
            // 0x00CA967C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00CA9680: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00CA9684: ADD w20, w22, w24          | W20 = (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((th
            System.UInt32[] val_41 = val_38 + val_79;
            // 0x00CA9688: STR w24, [sp, #0x4c]       | stack[1152921513063873484] = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];  //  dest_result_addr=1152921513063873484
            // 0x00CA968C: STR w1, [sp, #0x38]        | stack[1152921513063873464] = this.kNumHashDirectBytes;  //  dest_result_addr=1152921513063873464
            // 0x00CA9690: BL #0x16f9694              | X0 = System.Math.Min(val1:  0, val2:  val_88);
            uint val_42 = System.Math.Min(val1:  0, val2:  val_88);
            // 0x00CA9694: LDR x24, [x19, #0x10]      | 
            // 0x00CA9698: MOV w23, w0                | W23 = val_42;//m1                       
            val_93 = val_42;
            // 0x00CA969C: CBNZ x24, #0xca96a4        | if (this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0] != 0) goto label_73;
            if(val_79 != 0)
            {
                goto label_73;
            }
            // 0x00CA96A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_73:
            // 0x00CA96A4: LDR w8, [x24, #0x18]       | W8 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0] + 24;
            // 0x00CA96A8: ADD w9, w23, w20           | W9 = (val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)
            uint val_43 = val_93 + val_41;
            // 0x00CA96AC: SXTW x26, w9               | X26 = (long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ);
            // 0x00CA96B0: STR w20, [sp, #0x40]       | stack[1152921513063873472] = (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Tab;  //  dest_result_addr=1152921513063873472
            // 0x00CA96B4: CMP w9, w8                 | STATE = COMPARE((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ, this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0] + 24)
            // 0x00CA96B8: B.LO #0xca96c8             | if (val_43 < this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0] + 24) goto label_74;
            if(val_43 < (this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0] + 24))
            {
                goto label_74;
            }
            // 0x00CA96BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA96C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA96C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_74:
            // 0x00CA96C8: ADD x8, x24, x26           | X8 = (this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 
            uint val_44 = val_79 + (long)val_43;
            // 0x00CA96CC: LDRB w24, [x8, #0x20]      | W24 = (this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + + 32;
            // 0x00CA96D0: LDR x26, [x19, #0x10]      | 
            // 0x00CA96D4: MOV w20, w28               | W20 = this._cutValue;//m1               
            val_94 = this._cutValue;
            // 0x00CA96D8: CBNZ x26, #0xca96e0        | if ((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ) != 0) goto label_75;
            if((long)val_43 != 0)
            {
                goto label_75;
            }
            // 0x00CA96DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_75:
            // 0x00CA96E0: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_82 = val_4;
            // 0x00CA96E4: LDR w8, [x26, #0x18]       | W8 = (long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ) + 24;
            // 0x00CA96E8: ADD w9, w23, w9            | W9 = (val_42 + (W25 + W12));            
            val_82 = val_93 + val_82;
            // 0x00CA96EC: SXTW x28, w9               | X28 = (long)(int)((val_42 + (W25 + W12)));
            // 0x00CA96F0: CMP w9, w8                 | STATE = COMPARE((val_42 + (W25 + W12)), (long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ) + 24)
            // 0x00CA96F4: B.LO #0xca9704             | if (val_4 < (long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ) + 24) goto label_76;
            if(val_82 < ((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZ) + 24))
            {
                goto label_76;
            }
            // 0x00CA96F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA96FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9700: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_76:
            // 0x00CA9704: ADD x8, x26, x28           | X8 = ((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this
            var val_45 = (long)val_43 + (long)val_82;
            // 0x00CA9708: LDRB w8, [x8, #0x20]       | W8 = ((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + + 32;
            // 0x00CA970C: LSL w25, w25, #1           | W25 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);
            val_72 = val_92 << 1;
            // 0x00CA9710: CMP w24, w8                | STATE = COMPARE((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + + 32, ((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + + 32)
            // 0x00CA9714: B.NE #0xca9858             | if ((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + + 32 != ((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + + 32) goto label_77;
            if(((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + + 32) != (((long)(int)((val_42 + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + + 32))
            {
                goto label_77;
            }
            // 0x00CA9718: LDR w8, [sp, #0x4c]        | W8 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];
            // 0x00CA971C: ADD w22, w8, w22           | W22 = (this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25
            val_38 = val_79 + val_38;
            label_83:
            // 0x00CA9720: MOV w24, w23               | W24 = val_42;//m1                       
            // 0x00CA9724: CMP w27, w24               | STATE = COMPARE(((-2 - W25) - ~(???) <= ~this._matchMaxLen ? ~((this._matchMaxLen + W25)) : ( !???)), val_42)
            // 0x00CA9728: B.EQ #0xca97b0             | if (val_74 == val_93) goto label_78;    
            if(val_74 == val_93)
            {
                goto label_78;
            }
            // 0x00CA972C: LDR x23, [x19, #0x10]      | 
            // 0x00CA9730: CBNZ x23, #0xca9738        | if (val_42 != 0) goto label_79;         
            if(val_93 != 0)
            {
                goto label_79;
            }
            // 0x00CA9734: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_79:
            // 0x00CA9738: LDR w8, [x23, #0x18]       | W8 = val_42 + 24;                       
            // 0x00CA973C: ADD w9, w22, w24           | W9 = ((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25
            uint val_46 = val_38 + val_93;
            // 0x00CA9740: ADD w9, w9, #1             | W9 = (((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W2
            val_46 = val_46 + 1;
            // 0x00CA9744: SXTW x26, w9               | X26 = (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25);
            // 0x00CA9748: CMP w9, w8                 | STATE = COMPARE((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25, val_42 + 24)
            // 0x00CA974C: B.LO #0xca975c             | if (val_46 < val_42 + 24) goto label_80;
            if(val_46 < (val_42 + 24))
            {
                goto label_80;
            }
            // 0x00CA9750: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9754: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9758: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_80:
            // 0x00CA975C: ADD x8, x23, x26           | X8 = (val_42 + (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) +
            uint val_47 = val_93 + (long)val_46;
            // 0x00CA9760: LDRB w28, [x8, #0x20]      | W28 = (val_42 + (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) + 32;
            // 0x00CA9764: LDR x26, [x19, #0x10]      | 
            // 0x00CA9768: CBNZ x26, #0xca9770        | if ((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25) != 0) goto label_81;
            if((long)val_46 != 0)
            {
                goto label_81;
            }
            // 0x00CA976C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_81:
            // 0x00CA9770: LDR w8, [x26, #0x18]       | W8 = (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25) + 24;
            // 0x00CA9774: ADD w9, w21, w24           | W9 = ((W25 + ???) + val_42);            
            uint val_48 = val_39 + val_93;
            // 0x00CA9778: ADD w9, w9, #1             | W9 = (((W25 + ???) + val_42) + 1);      
            val_48 = val_48 + 1;
            // 0x00CA977C: ADD w23, w24, #1           | W23 = (val_42 + 1);                     
            val_93 = val_93 + 1;
            // 0x00CA9780: SXTW x24, w9               | X24 = (long)(int)((((W25 + ???) + val_42) + 1));
            // 0x00CA9784: CMP w9, w8                 | STATE = COMPARE((((W25 + ???) + val_42) + 1), (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25) + 24)
            // 0x00CA9788: B.LO #0xca9798             | if (val_48 < (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25) + 24) goto label_82;
            if(val_48 < ((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25) + 24))
            {
                goto label_82;
            }
            // 0x00CA978C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9790: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9794: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_82:
            // 0x00CA9798: ADD x8, x26, x24           | X8 = ((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (lo
            var val_49 = (long)val_46 + (long)val_48;
            // 0x00CA979C: LDRB w8, [x8, #0x20]       | W8 = ((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((lon + 32;
            // 0x00CA97A0: CMP w28, w8                | STATE = COMPARE((val_42 + (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) + 32, ((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((lon + 32)
            // 0x00CA97A4: B.EQ #0xca9720             | if ((val_42 + (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) + 32 == ((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((lon + 32) goto label_83;
            if(((val_42 + (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) + 32) == (((long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((lon + 32))
            {
                goto label_83;
            }
            // 0x00CA97A8: MOV w22, wzr               | W22 = 0 (0x0);//ML01                    
            val_95 = 0;
            // 0x00CA97AC: B #0xca97b8                |  goto label_84;                         
            goto label_84;
            label_78:
            // 0x00CA97B0: LDR w23, [sp, #0x10]       | W23 = (W10 - W25);                      
            val_93 = val_2;
            // 0x00CA97B4: ORR w22, wzr, #1           | W22 = 1(0x1);                           
            val_95 = 1;
            label_84:
            // 0x00CA97B8: LDR w8, [sp, #0x14]        | W8 = this.kNumHashDirectBytes;          
            // 0x00CA97BC: MOV w28, w20               | W28 = this._cutValue;//m1               
            val_96 = val_94;
            // 0x00CA97C0: CMP w8, w23                | STATE = COMPARE(this.kNumHashDirectBytes, (W10 - W25))
            // 0x00CA97C4: B.HS #0xca985c             | if (this.kNumHashDirectBytes >= val_93) goto label_85;
            if(this.kNumHashDirectBytes >= val_93)
            {
                goto label_85;
            }
            // 0x00CA97C8: LDR x8, [sp, #0x20]        | X8 = distances;                         
            val_97 = val_89;
            // 0x00CA97CC: MOV w20, w28               | W20 = this._cutValue;//m1               
            val_94 = val_96;
            // 0x00CA97D0: CBNZ x8, #0xca97e0         | if (distances != 0) goto label_86;      
            if(val_97 != 0)
            {
                goto label_86;
            }
            // 0x00CA97D4: MOV x24, x8                | X24 = distances;//m1                    
            // 0x00CA97D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            // 0x00CA97DC: MOV x8, x24                | X8 = distances;//m1                     
            val_97 = val_97;
            label_86:
            // 0x00CA97E0: MOV x28, x8                | X28 = distances;//m1                    
            // 0x00CA97E4: LDR w9, [sp, #0x30]        | W9 = (val_27 != val_26 ? (val_84 - 2) : val_84 + 2);
            // 0x00CA97E8: LDR x8, [x28, #0x18]       | X8 = distances + 24;                    
            val_98 = mem[distances + 24];
            val_98 = distances + 24;
            // 0x00CA97EC: ADD w24, w9, #1            | W24 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 1);
            var val_50 = val_79 + 1;
            // 0x00CA97F0: MOV w26, w9                | W26 = (val_27 != val_26 ? (val_84 - 2) : val_84 + 2);//m1
            // 0x00CA97F4: CMP w9, w8                 | STATE = COMPARE((val_27 != val_26 ? (val_84 - 2) : val_84 + 2), distances + 24)
            // 0x00CA97F8: B.LO #0xca980c             | if (val_30 < val_98) goto label_87;     
            if(val_79 < val_98)
            {
                goto label_87;
            }
            // 0x00CA97FC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9800: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9804: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            // 0x00CA9808: LDR x8, [x28, #0x18]       | X8 = distances + 24;                    
            val_98 = mem[distances + 24];
            val_98 = distances + 24;
            label_87:
            // 0x00CA980C: LDR w10, [sp, #0x30]       | W10 = (val_27 != val_26 ? (val_84 - 2) : val_84 + 2);
            var val_83 = val_79;
            // 0x00CA9810: ADD x9, x28, x26, lsl #2   | X9 = (distances + ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2)) << 2);
            System.UInt32[] val_51 = val_97 + (((val_27 != val_26 ? (val_84 - 2) : val_84 + 2)) << 2);
            // 0x00CA9814: STR x28, [sp, #0x20]       | stack[1152921513063873440] = distances;  //  dest_result_addr=1152921513063873440
            // 0x00CA9818: MOV w26, w24               | W26 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 1);//m1
            // 0x00CA981C: ADD w10, w10, #2           | W10 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);
            val_83 = val_83 + 2;
            // 0x00CA9820: STR w10, [sp, #0x30]       | stack[1152921513063873456] = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);  //  dest_result_addr=1152921513063873456
            // 0x00CA9824: LDR w10, [sp, #0x3c]       | W10 = ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long);
            // 0x00CA9828: STR w23, [x9, #0x20]       | mem2[0] = (W10 - W25);                   //  dest_result_addr=0
            mem2[0] = val_93;
            // 0x00CA982C: CMP w24, w8                | STATE = COMPARE(((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 1), distances + 24)
            // 0x00CA9830: SUB w28, w10, #1           | W28 = (((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (lo
            uint val_52 = val_81 - 1;
            // 0x00CA9834: B.LO #0xca9844             | if (val_50 < val_98) goto label_88;     
            if(val_50 < val_98)
            {
                goto label_88;
            }
            // 0x00CA9838: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA983C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9840: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_88:
            // 0x00CA9844: LDR x8, [sp, #0x20]        | X8 = distances;                         
            System.UInt32[] val_84 = val_97;
            // 0x00CA9848: ADD x8, x8, x26, lsl #2    | X8 = (distances + (((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 1)) << 2);
            val_84 = val_84 + ((((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 1)) << 2);
            // 0x00CA984C: STR w28, [x8, #0x20]       | mem2[0] = (((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long;  //  dest_result_addr=0
            mem2[0] = val_52;
            // 0x00CA9850: CBNZ w22, #0xca9a68        | if (0x1 != 0) goto label_89;            
            if(val_95 != 0)
            {
                goto label_89;
            }
            // 0x00CA9854: STR w23, [sp, #0x14]       | stack[1152921513063873428] = (W10 - W25);  //  dest_result_addr=1152921513063873428
            label_77:
            // 0x00CA9858: MOV w28, w20               | W28 = this._cutValue;//m1               
            val_96 = val_94;
            label_85:
            // 0x00CA985C: LDR w20, [sp, #0x40]       | W20 = (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Tab;
            // 0x00CA9860: LDR x22, [x19, #0x10]      | 
            // 0x00CA9864: CBNZ x22, #0xca986c        | if (0x1 != 0) goto label_90;            
            if(val_95 != 0)
            {
                goto label_90;
            }
            // 0x00CA9868: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_90:
            // 0x00CA986C: LDR w8, [x22, #0x18]       | W8 = 0x9814;                            
            // 0x00CA9870: LDR x26, [sp, #0x18]       | X26 = this._son;                        
            val_91 = val_91;
            // 0x00CA9874: ADD w9, w23, w20           | W9 = ((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(
            System.UInt32[] val_53 = val_93 + val_41;
            // 0x00CA9878: SXTW x20, w9               | X20 = (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S);
            // 0x00CA987C: CMP w9, w8                 | STATE = COMPARE(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S, 0x9814)
            // 0x00CA9880: B.LO #0xca9890             | if (val_53 < 38932) goto label_91;      
            if(val_53 < 38932)
            {
                goto label_91;
            }
            // 0x00CA9884: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9888: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA988C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_91:
            // 0x00CA9890: ADD x8, x22, x20           | X8 = (val_95 + (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) 
            var val_54 = val_95 + (long)val_53;
            // 0x00CA9894: LDRB w22, [x8, #0x20]      | W22 = (val_95 + (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + + 32;
            // 0x00CA9898: LDR x20, [x19, #0x10]      | 
            // 0x00CA989C: CBNZ x20, #0xca98a4        | if ((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S) != 0) goto label_92;
            if((long)val_53 != 0)
            {
                goto label_92;
            }
            // 0x00CA98A0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_92:
            // 0x00CA98A4: LDR w9, [sp, #0x48]        | W9 = (W25 + W12);                       
            var val_85 = val_4;
            // 0x00CA98A8: LDR w8, [x20, #0x18]       | W8 = (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S) + 24;
            // 0x00CA98AC: ADD w9, w23, w9            | W9 = ((W10 - W25) + (W25 + W12));       
            val_85 = val_93 + val_85;
            // 0x00CA98B0: SXTW x24, w9               | X24 = (long)(int)(((W10 - W25) + (W25 + W12)));
            // 0x00CA98B4: CMP w9, w8                 | STATE = COMPARE(((W10 - W25) + (W25 + W12)), (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S) + 24)
            // 0x00CA98B8: B.LO #0xca98c8             | if (val_4 < (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S) + 24) goto label_93;
            if(val_85 < ((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (S) + 24))
            {
                goto label_93;
            }
            // 0x00CA98BC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA98C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA98C4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_93:
            // 0x00CA98C8: ADD x8, x20, x24           | X8 = ((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~
            var val_55 = (long)val_53 + (long)val_85;
            // 0x00CA98CC: LDRB w24, [x8, #0x20]      | W24 = ((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1 + 32;
            // 0x00CA98D0: LDR x20, [x26]             | X20 = this._son;                        
            // 0x00CA98D4: SUB w28, w28, #1           | W28 = (this._cutValue - 1);             
            val_96 = val_96 - 1;
            // 0x00CA98D8: CBNZ x20, #0xca98e0        | if (this._son != 0) goto label_94;      
            if(val_91 != 0)
            {
                goto label_94;
            }
            // 0x00CA98DC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_94:
            // 0x00CA98E0: CMP w22, w24               | STATE = COMPARE((val_95 + (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + + 32, ((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1 + 32)
            // 0x00CA98E4: B.LO #0xca995c             | if ((val_95 + (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + + 32 < ((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1 + 32) goto label_95;
            if(((val_95 + (long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + + 32) < (((long)(int)(((W10 - W25) + (((distances + (val_27 != val_26 ? (val_84 - 2) : val_84) << 2) + ~(this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1 + 32))
            {
                goto label_95;
            }
            // 0x00CA98E8: LDR w9, [sp, #0x44]        | W9 = 0x1;                               
            // 0x00CA98EC: LDR w8, [x20, #0x18]       | W8 = this._son + 24;                    
            // 0x00CA98F0: LDR w24, [sp, #0x4c]       | W24 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];
            // 0x00CA98F4: MOV w22, w9                | W22 = 1 (0x1);//ML01                    
            // 0x00CA98F8: CMP w9, w8                 | STATE = COMPARE(0x1, this._son + 24)    
            // 0x00CA98FC: B.LO #0xca990c             | if (1 < this._son + 24) goto label_96;  
            if(1 < (this._son + 24))
            {
                goto label_96;
            }
            // 0x00CA9900: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9904: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9908: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_96:
            // 0x00CA990C: ADD x8, x20, x22, lsl #2   | X8 = (this._son + 4);                   
            System.UInt32[] val_56 = val_91 + 4;
            // 0x00CA9910: STR w24, [x8, #0x20]       | mem2[0] = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];  //  dest_result_addr=0
            mem2[0] = val_79;
            // 0x00CA9914: LDR x20, [x26]             | X20 = this._son;                        
            // 0x00CA9918: CBNZ x20, #0xca9920        | if (this._son != 0) goto label_97;      
            if(val_91 != 0)
            {
                goto label_97;
            }
            // 0x00CA991C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_97:
            // 0x00CA9920: LDR w8, [x20, #0x18]       | W8 = this._son + 24;                    
            // 0x00CA9924: MOV w22, w25               | W22 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);//m1
            // 0x00CA9928: CMP w25, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1), this._son + 24)
            // 0x00CA992C: B.LO #0xca993c             | if (val_72 < this._son + 24) goto label_98;
            if(val_72 < (this._son + 24))
            {
                goto label_98;
            }
            // 0x00CA9930: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9934: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9938: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_98:
            // 0x00CA993C: ADD x8, x20, x22, lsl #2   | X8 = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSiz
            System.UInt32[] val_57 = val_91 + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1)) << 2);
            // 0x00CA9940: LDR w24, [x8, #0x20]       | W24 = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32;
            // 0x00CA9944: LDR w8, [sp, #0x34]        | W8 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;
            // 0x00CA9948: STR w25, [sp, #0x44]       | stack[1152921513063873476] = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);  //  dest_result_addr=1152921513063873476
            // 0x00CA994C: CMP w24, w8                | STATE = COMPARE((this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32, val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0)
            // 0x00CA9950: MOV w1, w23                | W1 = (W10 - W25);//m1                   
            // 0x00CA9954: B.HI #0xca9650             | if ((this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32 > val_74) goto label_99;
            if(((this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32) > val_74)
            {
                goto label_99;
            }
            // 0x00CA9958: B #0xca99e0                |  goto label_100;                        
            goto label_100;
            label_95:
            // 0x00CA995C: LDR w9, [sp, #0xc]         | W9 = (this._cyclicBufferPos << 1);      
            // 0x00CA9960: LDR w8, [x20, #0x18]       | W8 = this._son + 24;                    
            // 0x00CA9964: LDR w24, [sp, #0x4c]       | W24 = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];
            // 0x00CA9968: MOV w22, w9                | W22 = (this._cyclicBufferPos << 1);//m1 
            // 0x00CA996C: CMP w9, w8                 | STATE = COMPARE((this._cyclicBufferPos << 1), this._son + 24)
            // 0x00CA9970: B.LO #0xca9980             | if (val_32 < this._son + 24) goto label_101;
            if(val_32 < (this._son + 24))
            {
                goto label_101;
            }
            // 0x00CA9974: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9978: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA997C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_101:
            // 0x00CA9980: ADD x8, x20, x22, lsl #2   | X8 = (this._son + ((this._cyclicBufferPos << 1)) << 2);
            System.UInt32[] val_58 = val_91 + (((this._cyclicBufferPos << 1)) << 2);
            // 0x00CA9984: STR w24, [x8, #0x20]       | mem2[0] = this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) + 32) << 2) + 32) ^ (((long)(int)(((W25 + W12) + 1)) + (long)(int)][0];  //  dest_result_addr=0
            mem2[0] = val_79;
            // 0x00CA9988: LDR x20, [x26]             | X20 = this._son;                        
            // 0x00CA998C: ORR w24, w25, #1           | W24 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X2
            uint val_59 = val_72 | 1;
            // 0x00CA9990: CBNZ x20, #0xca9998        | if (this._son != 0) goto label_102;     
            if(val_91 != 0)
            {
                goto label_102;
            }
            // 0x00CA9994: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_102:
            // 0x00CA9998: LDR w8, [x20, #0x18]       | W8 = this._son + 24;                    
            // 0x00CA999C: MOV w22, w24               | W22 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ;//m1
            // 0x00CA99A0: STR w24, [sp, #0xc]        | stack[1152921513063873420] = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ;  //  dest_result_addr=1152921513063873420
            // 0x00CA99A4: CMP w24, w8                | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) , this._son + 24)
            // 0x00CA99A8: B.LO #0xca99b8             | if (val_59 < this._son + 24) goto label_103;
            if(val_59 < (this._son + 24))
            {
                goto label_103;
            }
            // 0x00CA99AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA99B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA99B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_103:
            // 0x00CA99B8: ADD x8, x20, x22, lsl #2   | X8 = (this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSi
            System.UInt32[] val_60 = val_91 + ((((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ) << 2);
            // 0x00CA99BC: LDR w24, [x8, #0x20]       | W24 = (this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + + 32;
            // 0x00CA99C0: LDR w8, [sp, #0x34]        | W8 = val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0;
            // 0x00CA99C4: CMP w24, w8                | STATE = COMPARE((this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + + 32, val_1 > W10 ? (W25 - this._cyclicBufferSize) : 0)
            // 0x00CA99C8: B.HI #0xca9648             | if ((this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + + 32 > val_74) goto label_104;
            if(((this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + + 32) > val_74)
            {
                goto label_104;
            }
            // 0x00CA99CC: B #0xca99d4                |  goto label_105;                        
            goto label_105;
            label_70:
            // 0x00CA99D0: ADD x26, x19, #0x50        | X26 = this._son;//AP2 res_addr=1152921513063885664
            val_91 = this._son;
            label_105:
            // 0x00CA99D4: LDR w23, [sp, #0x30]       | W23 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);
            val_73 = val_83;
            // 0x00CA99D8: LDR w25, [sp, #0x44]       | W25 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);
            val_72 = val_72;
            // 0x00CA99DC: B #0xca99e4                |  goto label_106;                        
            goto label_106;
            label_100:
            // 0x00CA99E0: LDR w23, [sp, #0x30]       | W23 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);
            val_73 = val_83;
            label_106:
            // 0x00CA99E4: LDR w24, [sp, #0xc]        | W24 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ;
            // 0x00CA99E8: LDR x20, [x26]             | X20 = this._son;                        
            // 0x00CA99EC: CBNZ x20, #0xca99f4        | if (this._son != 0) goto label_107;     
            if(val_91 != 0)
            {
                goto label_107;
            }
            // 0x00CA99F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_107:
            // 0x00CA99F4: LDR x8, [x20, #0x18]       | X8 = this._son + 24;                    
            val_99 = mem[this._son + 24];
            val_99 = this._son + 24;
            // 0x00CA99F8: MOV w21, w24               | W21 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ;//m1
            // 0x00CA99FC: CMP w24, w8                | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) , this._son + 24)
            // 0x00CA9A00: B.LO #0xca9a14             | if (val_59 < val_99) goto label_108;    
            if(val_59 < val_99)
            {
                goto label_108;
            }
            // 0x00CA9A04: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9A08: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9A0C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            // 0x00CA9A10: LDR x8, [x20, #0x18]       | X8 = this._son + 24;                    
            val_99 = mem[this._son + 24];
            val_99 = this._son + 24;
            label_108:
            // 0x00CA9A14: ADD x9, x20, x21, lsl #2   | X9 = (this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSi
            System.UInt32[] val_61 = val_91 + ((((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ) << 2);
            // 0x00CA9A18: MOV w21, w25               | W21 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);//m1
            // 0x00CA9A1C: STR wzr, [x9, #0x20]       | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            // 0x00CA9A20: CMP w25, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1), this._son + 24)
            // 0x00CA9A24: B.LO #0xca9a34             | if (val_72 < val_99) goto label_109;    
            if(val_72 < val_99)
            {
                goto label_109;
            }
            // 0x00CA9A28: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9A2C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9A30: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_109:
            // 0x00CA9A34: ADD x8, x20, x21, lsl #2   | X8 = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSiz
            System.UInt32[] val_62 = val_91 + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1)) << 2);
            // 0x00CA9A38: STR wzr, [x8, #0x20]       | mem2[0] = 0x0;                           //  dest_result_addr=0
            mem2[0] = 0;
            label_116:
            // 0x00CA9A3C: MOV x0, x19                | X0 = 1152921513063885584 (0x10000001F8142B10);//ML01
            // 0x00CA9A40: BL #0xca8924               | this.MovePos();                         
            this.MovePos();
            label_3:
            // 0x00CA9A44: MOV w0, w23                | W0 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);//m1
            // 0x00CA9A48: SUB sp, x29, #0x50         | SP = (1152921513063873568 - 80) = 1152921513063873488 (0x10000001F813FBD0);
            // 0x00CA9A4C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA9A50: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00CA9A54: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00CA9A58: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00CA9A5C: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00CA9A60: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00CA9A64: RET                        |  return (System.UInt32)((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);
            return (uint)val_73;
            //  |  // // {name=val_0, type=System.UInt32, size=4, nGRN=0 }
            label_89:
            // 0x00CA9A68: LDR x23, [sp, #0x18]       | X23 = this._son;                        
            // 0x00CA9A6C: LDR x20, [x23]             | X20 = this._son;                        
            // 0x00CA9A70: CBNZ x20, #0xca9a78        | if (this._son != 0) goto label_110;     
            if(val_91 != 0)
            {
                goto label_110;
            }
            // 0x00CA9A74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_110:
            // 0x00CA9A78: LDR x8, [x20, #0x18]       | X8 = this._son + 24;                    
            val_100 = mem[this._son + 24];
            val_100 = this._son + 24;
            // 0x00CA9A7C: MOV w21, w25               | W21 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);//m1
            // 0x00CA9A80: CMP w25, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1), this._son + 24)
            // 0x00CA9A84: B.LO #0xca9a98             | if (val_72 < val_100) goto label_111;   
            if(val_72 < val_100)
            {
                goto label_111;
            }
            // 0x00CA9A88: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9A8C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9A90: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            // 0x00CA9A94: LDR x8, [x20, #0x18]       | X8 = this._son + 24;                    
            val_100 = mem[this._son + 24];
            val_100 = this._son + 24;
            label_111:
            // 0x00CA9A98: ADD x9, x20, x21, lsl #2   | X9 = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSiz
            System.UInt32[] val_63 = val_91 + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1)) << 2);
            // 0x00CA9A9C: LDR w21, [x9, #0x20]       | W21 = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32;
            // 0x00CA9AA0: LDR w9, [sp, #0xc]         | W9 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ;
            // 0x00CA9AA4: MOV w22, w9                | W22 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ;//m1
            // 0x00CA9AA8: CMP w9, w8                 | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) , this._son + 24)
            // 0x00CA9AAC: B.LO #0xca9abc             | if (val_59 < val_100) goto label_112;   
            if(val_59 < val_100)
            {
                goto label_112;
            }
            // 0x00CA9AB0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9AB4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9AB8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_112:
            // 0x00CA9ABC: ADD x8, x20, x22, lsl #2   | X8 = (this._son + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSi
            System.UInt32[] val_64 = val_91 + ((((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) ) << 2);
            // 0x00CA9AC0: STR w21, [x8, #0x20]       | mem2[0] = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32;  //  dest_result_addr=0
            mem2[0] = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 +  + 32;
            // 0x00CA9AC4: LDR x20, [x23]             | X20 = this._son;                        
            // 0x00CA9AC8: CBNZ x20, #0xca9ad0        | if (this._son != 0) goto label_113;     
            if(val_91 != 0)
            {
                goto label_113;
            }
            // 0x00CA9ACC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_42, ????);     
            label_113:
            // 0x00CA9AD0: LDR x8, [x20, #0x18]       | X8 = this._son + 24;                    
            val_101 = mem[this._son + 24];
            val_101 = this._son + 24;
            // 0x00CA9AD4: ORR w9, w25, #1            | W9 = ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22
            uint val_65 = val_72 | 1;
            // 0x00CA9AD8: SXTW x21, w9               | X21 = (long)(int)(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) );
            // 0x00CA9ADC: CMP w9, w8                 | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) , this._son + 24)
            // 0x00CA9AE0: B.LO #0xca9af4             | if (val_65 < val_101) goto label_114;   
            if(val_65 < val_101)
            {
                goto label_114;
            }
            // 0x00CA9AE4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9AE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9AEC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            // 0x00CA9AF0: LDR x8, [x20, #0x18]       | X8 = this._son + 24;                    
            val_101 = mem[this._son + 24];
            val_101 = this._son + 24;
            label_114:
            // 0x00CA9AF4: ADD x9, x20, x21, lsl #2   | X9 = (this._son + ((long)(int)(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((thi
            System.UInt32[] val_66 = val_91 + (((long)(int)(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) )) << 2);
            // 0x00CA9AF8: LDR w21, [x9, #0x20]       | W21 = (this._son + ((long)(int)(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Tab + 32;
            // 0x00CA9AFC: LDR w9, [sp, #0x44]        | W9 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);
            // 0x00CA9B00: LDR w23, [sp, #0x30]       | W23 = ((val_27 != val_26 ? (val_84 - 2) : val_84 + 2) + 2);
            // 0x00CA9B04: MOV w22, w9                | W22 = (((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1);//m1
            // 0x00CA9B08: CMP w9, w8                 | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1), this._son + 24)
            // 0x00CA9B0C: B.LO #0xca9b1c             | if (val_72 < val_101) goto label_115;   
            if(val_72 < val_101)
            {
                goto label_115;
            }
            // 0x00CA9B10: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_42, ????);     
            // 0x00CA9B14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9B18: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_42, ????);     
            label_115:
            // 0x00CA9B1C: ADD x8, x20, x22, lsl #2   | X8 = (this._son + ((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSiz
            System.UInt32[] val_67 = val_91 + (((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Table + ((X22 + (W25 + W12)) +  << 1)) << 2);
            // 0x00CA9B20: STR w21, [x8, #0x20]       | mem2[0] = (this._son + ((long)(int)(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Tab + 32;  //  dest_result_addr=0
            mem2[0] = (this._son + ((long)(int)(((((this._cyclicBufferPos - ((-2 - W25) - this._hash[(long)(int)((this.kFixHashSize + ((((((X22 + (W25 + W12)) + 32 + (long)(int)(((W25 + W12) + 1))) + 32 ^ (SevenZip.CRC.Tab + 32;
            // 0x00CA9B24: B #0xca9a3c                |  goto label_116;                        
            goto label_116;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA9B28 (13277992), len: 2044  VirtAddr: 0x00CA9B28 RVA: 0x00CA9B28 token: 100681467 methodIndex: 54596 delegateWrapperIndex: 0 methodInvoker: 0
        public void Skip(uint num)
        {
            //
            // Disasemble & Code
            //  | 
            System.UInt32[] val_40;
            //  | 
            uint val_41;
            //  | 
            uint val_42;
            //  | 
            uint val_43;
            //  | 
            var val_44;
            //  | 
            var val_45;
            //  | 
            uint val_46;
            //  | 
            var val_47;
            //  | 
            var val_48;
            //  | 
            int val_49;
            //  | 
            int val_50;
            //  | 
            int val_51;
            // 0x00CA9B28: STP x28, x27, [sp, #-0x60]! | stack[1152921513064612176] = ???;  stack[1152921513064612184] = ???;  //  dest_result_addr=1152921513064612176 |  dest_result_addr=1152921513064612184
            // 0x00CA9B2C: STP x26, x25, [sp, #0x10]  | stack[1152921513064612192] = ???;  stack[1152921513064612200] = ???;  //  dest_result_addr=1152921513064612192 |  dest_result_addr=1152921513064612200
            // 0x00CA9B30: STP x24, x23, [sp, #0x20]  | stack[1152921513064612208] = ???;  stack[1152921513064612216] = ???;  //  dest_result_addr=1152921513064612208 |  dest_result_addr=1152921513064612216
            // 0x00CA9B34: STP x22, x21, [sp, #0x30]  | stack[1152921513064612224] = ???;  stack[1152921513064612232] = ???;  //  dest_result_addr=1152921513064612224 |  dest_result_addr=1152921513064612232
            // 0x00CA9B38: STP x20, x19, [sp, #0x40]  | stack[1152921513064612240] = ???;  stack[1152921513064612248] = ???;  //  dest_result_addr=1152921513064612240 |  dest_result_addr=1152921513064612248
            // 0x00CA9B3C: STP x29, x30, [sp, #0x50]  | stack[1152921513064612256] = ???;  stack[1152921513064612264] = ???;  //  dest_result_addr=1152921513064612256 |  dest_result_addr=1152921513064612264
            // 0x00CA9B40: ADD x29, sp, #0x50         | X29 = (1152921513064612176 + 80) = 1152921513064612256 (0x10000001F81F41A0);
            // 0x00CA9B44: SUB sp, sp, #0x30          | SP = (1152921513064612176 - 48) = 1152921513064612128 (0x10000001F81F4120);
            // 0x00CA9B48: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00CA9B4C: LDRB w8, [x19, #0xb3]      | W8 = (bool)static_value_037340B3;       
            // 0x00CA9B50: MOV w21, w1                | W21 = num;//m1                          
            val_41 = num;
            // 0x00CA9B54: MOV x20, x0                | X20 = 1152921513064624272 (0x10000001F81F7090);//ML01
            // 0x00CA9B58: TBNZ w8, #0, #0xca9b74     | if (static_value_037340B3 == true) goto label_74;
            // 0x00CA9B5C: ADRP x8, #0x35c5000        | X8 = 56381440 (0x35C5000);              
            // 0x00CA9B60: LDR x8, [x8, #0x728]       | X8 = 0x2B8F570;                         
            // 0x00CA9B64: LDR w0, [x8]               | W0 = 0x141E;                            
            // 0x00CA9B68: BL #0x2782188              | X0 = sub_2782188( ?? 0x141E, ????);     
            // 0x00CA9B6C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00CA9B70: STRB w8, [x19, #0xb3]      | static_value_037340B3 = true;            //  dest_result_addr=57884851
            label_74:
            // 0x00CA9B74: LDR w23, [x20, #0x34]      | 
            // 0x00CA9B78: LDR w25, [x20, #0x4c]      | W25 = this._matchMaxLen; //P2           
            val_43 = this._matchMaxLen;
            // 0x00CA9B7C: LDR w22, [x20, #0x40]      | 
            // 0x00CA9B80: ADD w8, w25, w23           | W8 = (this._matchMaxLen + W23);         
            uint val_1 = val_43 + W23;
            // 0x00CA9B84: CMP w8, w22                | STATE = COMPARE((this._matchMaxLen + W23), W22)
            // 0x00CA9B88: B.LS #0xca9ba8             | if (val_1 <= W22) goto label_2;         
            if(val_1 <= W22)
            {
                goto label_2;
            }
            // 0x00CA9B8C: LDR w8, [x20, #0x74]       | W8 = this.kMinMatchCheck; //P2          
            // 0x00CA9B90: SUB w9, w22, w23           | W9 = (W22 - W23);                       
            var val_2 = W22 - W23;
            // 0x00CA9B94: CMP w9, w8                 | STATE = COMPARE((W22 - W23), this.kMinMatchCheck)
            // 0x00CA9B98: B.HS #0xca9ba8             | if (val_2 >= this.kMinMatchCheck) goto label_2;
            if(val_2 >= this.kMinMatchCheck)
            {
                goto label_2;
            }
            // 0x00CA9B9C: MOV x0, x20                | X0 = 1152921513064624272 (0x10000001F81F7090);//ML01
            // 0x00CA9BA0: BL #0xca8924               | this.MovePos();                         
            this.MovePos();
            // 0x00CA9BA4: B #0xcaa2fc                |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x00CA9BA8: LDR w8, [x20, #0x48]       | W8 = this._cyclicBufferSize; //P2       
            uint val_37 = this._cyclicBufferSize;
            // 0x00CA9BAC: LDR w10, [x20, #0x2c]      | 
            // 0x00CA9BB0: LDRB w9, [x20, #0x6c]      | W9 = this.HASH_ARRAY; //P2              
            // 0x00CA9BB4: SUBS w8, w23, w8           | W8 = (W23 - this._cyclicBufferSize);    
            val_37 = W23 - val_37;
            // 0x00CA9BB8: CSEL w28, w8, wzr, hi      | W28 = val_1 > W22 ? (W23 - this._cyclicBufferSize) : 0;
            var val_3 = (val_1 > W22) ? (val_37) : 0;
            // 0x00CA9BBC: ADD w27, w23, w10          | W27 = (W23 + W10);                      
            var val_4 = W23 + W10;
            // 0x00CA9BC0: STR w28, [sp, #0x18]       | stack[1152921513064612152] = val_1 > W22 ? (W23 - this._cyclicBufferSize) : 0;  //  dest_result_addr=1152921513064612152
            // 0x00CA9BC4: CBZ w9, #0xca9bf0          | if (this.HASH_ARRAY == false) goto label_4;
            if(this.HASH_ARRAY == false)
            {
                goto label_4;
            }
            // 0x00CA9BC8: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00CA9BCC: LDR x8, [x8, #0x988]       | X8 = 1152921504832512000;               
            // 0x00CA9BD0: LDR x0, [x8]               | X0 = typeof(SevenZip.CRC);              
            val_44 = null;
            // 0x00CA9BD4: LDRB w8, [x0, #0x10a]      | W8 = SevenZip.CRC.__il2cppRuntimeField_10A;
            // 0x00CA9BD8: TBZ w8, #0, #0xca9be4      | if (SevenZip.CRC.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00CA9BDC: LDR w8, [x0, #0xbc]        | W8 = SevenZip.CRC.__il2cppRuntimeField_cctor_finished;
            // 0x00CA9BE0: CBZ w8, #0xca9c64          | if (SevenZip.CRC.__il2cppRuntimeField_cctor_finished == 0) goto label_6;
            label_5:
            // 0x00CA9BE4: STR w10, [sp, #0x24]       | stack[1152921513064612164] = ???;        //  dest_result_addr=1152921513064612164
            // 0x00CA9BE8: STR w21, [sp, #0xc]        | stack[1152921513064612140] = num;        //  dest_result_addr=1152921513064612140
            // 0x00CA9BEC: B #0xca9c7c                |  goto label_7;                          
            goto label_7;
            label_4:
            // 0x00CA9BF0: LDR x19, [x20, #0x10]      | 
            // 0x00CA9BF4: STR w10, [sp, #0x24]       | stack[1152921513064612164] = ???;        //  dest_result_addr=1152921513064612164
            // 0x00CA9BF8: STR w21, [sp, #0xc]        | stack[1152921513064612140] = num;        //  dest_result_addr=1152921513064612140
            // 0x00CA9BFC: CBNZ x19, #0xca9c04        | if ( != 0) goto label_8;                
            if(!=0)
            {
                goto label_8;
            }
            // 0x00CA9C00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x141E, ????);     
            label_8:
            // 0x00CA9C04: LDR w8, [x19, #0x18]       | W8 = mem[57884696];                     
            // 0x00CA9C08: MOV w21, w27               | W21 = (W23 + W10);//m1                  
            // 0x00CA9C0C: CMP w27, w8                | STATE = COMPARE((W23 + W10), mem[57884696])
            // 0x00CA9C10: B.LO #0xca9c20             | if (val_4 < mem[57884696]) goto label_9;
            if(val_4 < mem[57884696])
            {
                goto label_9;
            }
            // 0x00CA9C14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x141E, ????);     
            // 0x00CA9C18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9C1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x141E, ????);     
            label_9:
            // 0x00CA9C20: ADD x8, x19, x21           | X8 = (57884672 + (W23 + W10));          
            var val_5 = 57884672 + val_4;
            // 0x00CA9C24: LDRB w21, [x8, #0x20]      | W21 = (57884672 + (W23 + W10)) + 32;    
            // 0x00CA9C28: LDR x19, [x20, #0x10]      | 
            // 0x00CA9C2C: CBNZ x19, #0xca9c34        | if ( != 0) goto label_10;               
            if(!=0)
            {
                goto label_10;
            }
            // 0x00CA9C30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x141E, ????);     
            label_10:
            // 0x00CA9C34: LDR w8, [x19, #0x18]       | W8 = mem[57884696];                     
            // 0x00CA9C38: ADD w9, w27, #1            | W9 = ((W23 + W10) + 1);                 
            var val_6 = val_4 + 1;
            // 0x00CA9C3C: SXTW x24, w9               | X24 = (long)(int)(((W23 + W10) + 1));   
            // 0x00CA9C40: CMP w9, w8                 | STATE = COMPARE(((W23 + W10) + 1), mem[57884696])
            // 0x00CA9C44: B.LO #0xca9c54             | if (val_6 < mem[57884696]) goto label_11;
            if(val_6 < mem[57884696])
            {
                goto label_11;
            }
            // 0x00CA9C48: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x141E, ????);     
            // 0x00CA9C4C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9C50: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x141E, ????);     
            label_11:
            // 0x00CA9C54: ADD x8, x19, x24           | X8 = (57884672 + (long)(int)(((W23 + W10) + 1)));
            var val_7 = 57884672 + (long)val_6;
            // 0x00CA9C58: LDRB w8, [x8, #0x20]       | W8 = (57884672 + (long)(int)(((W23 + W10) + 1))) + 32;
            // 0x00CA9C5C: BFI w21, w8, #8, #8        | W21 = (57884672 + (W23 + W10)) + 32 | (57884672 + (long)(int)(((W23 + W10) + 1))) + 32
            // 0x00CA9C60: B #0xca9e34                |  goto label_12;                         
            goto label_12;
            label_6:
            // 0x00CA9C64: STR w10, [sp, #0x24]       | stack[1152921513064612164] = ???;        //  dest_result_addr=1152921513064612164
            // 0x00CA9C68: STR w21, [sp, #0xc]        | stack[1152921513064612140] = num;        //  dest_result_addr=1152921513064612140
            // 0x00CA9C6C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9C70: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00CA9C74: LDR x8, [x8, #0x988]       | X8 = 1152921504832512000;               
            // 0x00CA9C78: LDR x0, [x8]               | X0 = typeof(SevenZip.CRC);              
            val_44 = null;
            label_7:
            // 0x00CA9C7C: LDR x8, [x0, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00CA9C80: LDR x21, [x20, #0x10]      | 
            // 0x00CA9C84: LDR x19, [x8]              | X19 = SevenZip.CRC.Table;               
            // 0x00CA9C88: CBNZ x21, #0xca9c90        | if (num != 0) goto label_13;            
            if(val_41 != 0)
            {
                goto label_13;
            }
            // 0x00CA9C8C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_13:
            // 0x00CA9C90: LDR w8, [x21, #0x18]       | W8 = num + 24;                          
            // 0x00CA9C94: MOV w24, w27               | W24 = (W23 + W10);//m1                  
            // 0x00CA9C98: CMP w27, w8                | STATE = COMPARE((W23 + W10), num + 24)  
            // 0x00CA9C9C: B.LO #0xca9cac             | if (val_4 < num + 24) goto label_14;    
            if(val_4 < (num + 24))
            {
                goto label_14;
            }
            // 0x00CA9CA0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9CA4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9CA8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_14:
            // 0x00CA9CAC: ADD x8, x21, x24           | X8 = (num + (W23 + W10));               
            uint val_8 = val_41 + val_4;
            // 0x00CA9CB0: LDRB w21, [x8, #0x20]      | W21 = (num + (W23 + W10)) + 32;         
            // 0x00CA9CB4: CBNZ x19, #0xca9cbc        | if (SevenZip.CRC.Table != null) goto label_15;
            if(SevenZip.CRC.Table != null)
            {
                goto label_15;
            }
            // 0x00CA9CB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_15:
            // 0x00CA9CBC: LDR w8, [x19, #0x18]       | W8 = SevenZip.CRC.Table.Length;         
            // 0x00CA9CC0: CMP w21, w8                | STATE = COMPARE((num + (W23 + W10)) + 32, SevenZip.CRC.Table.Length)
            // 0x00CA9CC4: B.LO #0xca9cd4             | if ((num + (W23 + W10)) + 32 < SevenZip.CRC.Table.Length) goto label_16;
            if(((num + (W23 + W10)) + 32) < SevenZip.CRC.Table.Length)
            {
                goto label_16;
            }
            // 0x00CA9CC8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9CCC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9CD0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_16:
            // 0x00CA9CD4: ADD x8, x19, x21, lsl #2   | X8 = (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2);
            System.UInt32[] val_9 = SevenZip.CRC.Table + (((num + (W23 + W10)) + 32) << 2);
            // 0x00CA9CD8: LDR w19, [x8, #0x20]       | W19 = (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32; //  not_find_field!2:32
            var val_38 = (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32;
            // 0x00CA9CDC: LDR x21, [x20, #0x10]      | 
            // 0x00CA9CE0: CBNZ x21, #0xca9ce8        | if ((num + (W23 + W10)) + 32 != 0) goto label_17;
            if(((num + (W23 + W10)) + 32) != 0)
            {
                goto label_17;
            }
            // 0x00CA9CE4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_17:
            // 0x00CA9CE8: LDR w8, [x21, #0x18]       | W8 = (num + (W23 + W10)) + 32 + 24;     
            // 0x00CA9CEC: ADD w9, w27, #1            | W9 = ((W23 + W10) + 1);                 
            var val_10 = val_4 + 1;
            // 0x00CA9CF0: SXTW x24, w9               | X24 = (long)(int)(((W23 + W10) + 1));   
            // 0x00CA9CF4: CMP w9, w8                 | STATE = COMPARE(((W23 + W10) + 1), (num + (W23 + W10)) + 32 + 24)
            // 0x00CA9CF8: B.LO #0xca9d08             | if (val_10 < (num + (W23 + W10)) + 32 + 24) goto label_18;
            if(val_10 < ((num + (W23 + W10)) + 32 + 24))
            {
                goto label_18;
            }
            // 0x00CA9CFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9D00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9D04: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_18:
            // 0x00CA9D08: ADD x8, x21, x24           | X8 = ((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1)));
            var val_11 = ((num + (W23 + W10)) + 32) + (long)val_10;
            // 0x00CA9D0C: LDRB w8, [x8, #0x20]       | W8 = ((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32;
            // 0x00CA9D10: LDR x21, [x20, #0x58]      | X21 = this._hash; //P2                  
            // 0x00CA9D14: LDR w24, [x20, #0x34]      | 
            // 0x00CA9D18: EOR w19, w8, w19           | W19 = (((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((nu
            val_38 = (((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32) ^ val_38;
            // 0x00CA9D1C: AND w26, w19, #0x3ff       | W26 = ((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((n
            var val_12 = val_38 & 1023;
            // 0x00CA9D20: CBNZ x21, #0xca9d28        | if (this._hash != null) goto label_19;  
            if(this._hash != null)
            {
                goto label_19;
            }
            // 0x00CA9D24: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_19:
            // 0x00CA9D28: LDR w8, [x21, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9D2C: CMP w26, w8                | STATE = COMPARE(((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) & 1023), this._hash.Length)
            // 0x00CA9D30: B.LO #0xca9d40             | if (val_12 < this._hash.Length) goto label_20;
            if(val_12 < this._hash.Length)
            {
                goto label_20;
            }
            // 0x00CA9D34: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9D38: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9D3C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_20:
            // 0x00CA9D40: ADD x8, x21, x26, lsl #2   | X8 = this._hash[((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) & 1023)]; //PARR1 
            // 0x00CA9D44: STR w24, [x8, #0x20]       | this._hash[((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) & 1023)][0] = (long)(int)(((W23 + W10) + 1));  //  dest_result_addr=0
            this._hash[val_12] = (long)val_10;
            // 0x00CA9D48: LDR x21, [x20, #0x10]      | 
            // 0x00CA9D4C: CBNZ x21, #0xca9d54        | if (this._hash != null) goto label_21;  
            if(this._hash != null)
            {
                goto label_21;
            }
            // 0x00CA9D50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_21:
            // 0x00CA9D54: LDR w8, [x21, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9D58: ADD w9, w27, #2            | W9 = ((W23 + W10) + 2);                 
            var val_13 = val_4 + 2;
            // 0x00CA9D5C: SXTW x24, w9               | X24 = (long)(int)(((W23 + W10) + 2));   
            // 0x00CA9D60: CMP w9, w8                 | STATE = COMPARE(((W23 + W10) + 2), this._hash.Length)
            // 0x00CA9D64: B.LO #0xca9d74             | if (val_13 < this._hash.Length) goto label_22;
            if(val_13 < this._hash.Length)
            {
                goto label_22;
            }
            // 0x00CA9D68: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9D6C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9D70: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_22:
            // 0x00CA9D74: ADD x8, x21, x24           | X8 = this._hash[(long)(int)(((W23 + W10) + 2))]; //PARR1 
            // 0x00CA9D78: LDRB w8, [x8, #0x20]       | W8 = this._hash[(long)(int)(((W23 + W10) + 2))][0]
            uint val_39 = this._hash[(long)val_13];
            // 0x00CA9D7C: LDR x21, [x20, #0x58]      | X21 = this._hash; //P2                  
            // 0x00CA9D80: LDR w24, [x20, #0x34]      | 
            // 0x00CA9D84: EOR w19, w19, w8, lsl #8   | W19 = ((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((n
            val_38 = val_38 ^ (val_39 << 8);
            // 0x00CA9D88: AND w26, w19, #0xffff      | W26 = (((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((
            var val_14 = val_38 & 65535;
            // 0x00CA9D8C: CBNZ x21, #0xca9d94        | if (this._hash != null) goto label_23;  
            if(this._hash != null)
            {
                goto label_23;
            }
            // 0x00CA9D90: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_23:
            // 0x00CA9D94: LDR w8, [x21, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9D98: ADD w26, w26, #0x400       | W26 = ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + (
            val_14 = val_14 + 1024;
            // 0x00CA9D9C: CMP w26, w8                | STATE = COMPARE(((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0]) << 8) & 65535) + 1, this._hash.Length)
            // 0x00CA9DA0: B.LO #0xca9db0             | if (val_14 < this._hash.Length) goto label_24;
            if(val_14 < this._hash.Length)
            {
                goto label_24;
            }
            // 0x00CA9DA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9DA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9DAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_24:
            // 0x00CA9DB0: ADD x8, x21, x26, lsl #2   | X8 = this._hash[((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0]) << 8) & 65535) + 1]; //PARR1 
            // 0x00CA9DB4: STR w24, [x8, #0x20]       | this._hash[((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0]) << 8) & 65535) + 1][0] = (long)(int)(((W23 + W10) + 2));  //  dest_result_addr=0
            this._hash[val_14] = (long)val_13;
            // 0x00CA9DB8: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00CA9DBC: LDR x8, [x8, #0x988]       | X8 = 1152921504832512000;               
            // 0x00CA9DC0: LDR x24, [x20, #0x10]      | 
            // 0x00CA9DC4: LDR x8, [x8]               | X8 = typeof(SevenZip.CRC);              
            // 0x00CA9DC8: LDR x8, [x8, #0xa0]        | X8 = SevenZip.CRC.__il2cppRuntimeField_static_fields;
            // 0x00CA9DCC: LDR x21, [x8]              | X21 = SevenZip.CRC.Table;               
            // 0x00CA9DD0: CBNZ x24, #0xca9dd8        | if ((long)(int)(((W23 + W10) + 2)) != 0) goto label_25;
            if((long)val_13 != 0)
            {
                goto label_25;
            }
            // 0x00CA9DD4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_25:
            // 0x00CA9DD8: LDR w8, [x24, #0x18]       | W8 = (long)(int)(((W23 + W10) + 2)) + 24;
            // 0x00CA9DDC: ADD w9, w27, #3            | W9 = ((W23 + W10) + 3);                 
            var val_15 = val_4 + 3;
            // 0x00CA9DE0: SXTW x26, w9               | X26 = (long)(int)(((W23 + W10) + 3));   
            // 0x00CA9DE4: CMP w9, w8                 | STATE = COMPARE(((W23 + W10) + 3), (long)(int)(((W23 + W10) + 2)) + 24)
            // 0x00CA9DE8: B.LO #0xca9df8             | if (val_15 < (long)(int)(((W23 + W10) + 2)) + 24) goto label_26;
            if(val_15 < ((long)(int)(((W23 + W10) + 2)) + 24))
            {
                goto label_26;
            }
            // 0x00CA9DEC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9DF0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9DF4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_26:
            // 0x00CA9DF8: ADD x8, x24, x26           | X8 = ((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3)));
            var val_16 = (long)val_13 + (long)val_15;
            // 0x00CA9DFC: LDRB w24, [x8, #0x20]      | W24 = ((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32;
            // 0x00CA9E00: CBNZ x21, #0xca9e08        | if (SevenZip.CRC.Table != null) goto label_27;
            if(SevenZip.CRC.Table != null)
            {
                goto label_27;
            }
            // 0x00CA9E04: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_27:
            // 0x00CA9E08: LDR w8, [x21, #0x18]       | W8 = SevenZip.CRC.Table.Length;         
            // 0x00CA9E0C: CMP w24, w8                | STATE = COMPARE(((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32, SevenZip.CRC.Table.Length)
            // 0x00CA9E10: B.LO #0xca9e20             | if (((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32 < SevenZip.CRC.Table.Length) goto label_28;
            if((((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32) < SevenZip.CRC.Table.Length)
            {
                goto label_28;
            }
            // 0x00CA9E14: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9E18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9E1C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_28:
            // 0x00CA9E20: ADD x8, x21, x24, lsl #2   | X8 = (SevenZip.CRC.Table + (((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32) 
            System.UInt32[] val_17 = SevenZip.CRC.Table + ((((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32) << 2);
            // 0x00CA9E24: LDR w8, [x8, #0x20]        | W8 = (SevenZip.CRC.Table + (((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32) << 2) + 32; //  not_find_field!2:32
            var val_40 = (SevenZip.CRC.Table + (((long)(int)(((W23 + W10) + 2)) + (long)(int)(((W23 + W10) + 3))) + 32) << 2) + 32;
            // 0x00CA9E28: LDR w9, [x20, #0x64]       | W9 = this._hashMask; //P2               
            uint val_41 = this._hashMask;
            // 0x00CA9E2C: EOR w8, w19, w8, lsl #5    | W8 = (((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((n
            val_40 = val_38 ^ (val_40 << 5);
            // 0x00CA9E30: AND w21, w8, w9            | W21 = ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + (
            val_45 = val_40 & val_41;
            label_12:
            // 0x00CA9E34: LDR x19, [x20, #0x58]      | X19 = this._hash; //P2                  
            // 0x00CA9E38: LDR w24, [x20, #0x78]      | W24 = this.kFixHashSize; //P2           
            // 0x00CA9E3C: CBNZ x19, #0xca9e44        | if (this._hash != null) goto label_29;  
            if(this._hash != null)
            {
                goto label_29;
            }
            // 0x00CA9E40: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_29:
            // 0x00CA9E44: LDR w8, [x19, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9E48: ADD w9, w24, w21           | W9 = (this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (Se
            val_41 = this.kFixHashSize + val_45;
            // 0x00CA9E4C: SXTW x24, w9               | X24 = (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0);
            // 0x00CA9E50: STR w27, [sp, #0x28]       | stack[1152921513064612168] = (W23 + W10);  //  dest_result_addr=1152921513064612168
            // 0x00CA9E54: CMP w9, w8                 | STATE = COMPARE((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0, this._hash.Length)
            // 0x00CA9E58: B.LO #0xca9e68             | if (this._hashMask < this._hash.Length) goto label_30;
            if(val_41 < this._hash.Length)
            {
                goto label_30;
            }
            // 0x00CA9E5C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9E60: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9E64: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_30:
            // 0x00CA9E68: ADD x8, x19, x24, lsl #2   | X8 = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)]; //PARR1 
            // 0x00CA9E6C: LDR x24, [x20, #0x58]      | X24 = this._hash; //P2                  
            // 0x00CA9E70: LDR w27, [x20, #0x78]      | W27 = this.kFixHashSize; //P2           
            val_46 = this.kFixHashSize;
            // 0x00CA9E74: LDR w19, [x8, #0x20]       | W19 = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0]
            uint val_42 = this._hash[(long)val_41];
            // 0x00CA9E78: LDR w26, [x20, #0x34]      | 
            // 0x00CA9E7C: CBNZ x24, #0xca9e84        | if (this._hash != null) goto label_31;  
            if(this._hash != null)
            {
                goto label_31;
            }
            // 0x00CA9E80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(SevenZip.CRC), ????);
            label_31:
            // 0x00CA9E84: LDR w8, [x24, #0x18]       | W8 = this._hash.Length; //P2            
            // 0x00CA9E88: ADD w9, w27, w21           | W9 = (this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (Se
            uint val_18 = val_46 + val_45;
            // 0x00CA9E8C: SXTW x21, w9               | X21 = (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0);
            var val_45 = (long)val_18;
            // 0x00CA9E90: CMP w9, w8                 | STATE = COMPARE((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0, this._hash.Length)
            // 0x00CA9E94: B.LO #0xca9ea4             | if (val_18 < this._hash.Length) goto label_32;
            if(val_18 < this._hash.Length)
            {
                goto label_32;
            }
            // 0x00CA9E98: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? typeof(SevenZip.CRC), ????);
            // 0x00CA9E9C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9EA0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(SevenZip.CRC), ????);
            label_32:
            // 0x00CA9EA4: ADD x8, x24, x21, lsl #2   | X8 = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)]; //PARR1 
            // 0x00CA9EA8: STR w26, [x8, #0x20]       | this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0] = (long)(int)(((W23 + W10) + 3));  //  dest_result_addr=0
            this._hash[val_45] = (long)val_15;
            // 0x00CA9EAC: LDR w8, [x20, #0x44]       | W8 = this._cyclicBufferPos; //P2        
            // 0x00CA9EB0: ORR w9, wzr, #1            | W9 = 1(0x1);                            
            // 0x00CA9EB4: CMP w19, w28               | STATE = COMPARE(this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0], val_1 > W22 ? (W23 - this._cyclicBufferSize) : 0)
            // 0x00CA9EB8: LSL w10, w8, #1            | W10 = (this._cyclicBufferPos << 1);     
            uint val_19 = this._cyclicBufferPos << 1;
            // 0x00CA9EBC: BFI w9, w8, #1, #0x1f      | W9 = 1 | this._cyclicBufferPos          
            // 0x00CA9EC0: STR w10, [sp, #0x10]       | stack[1152921513064612144] = (this._cyclicBufferPos << 1);  //  dest_result_addr=1152921513064612144
            // 0x00CA9EC4: STR w9, [sp, #0x2c]        | stack[1152921513064612172] = 0x1;        //  dest_result_addr=1152921513064612172
            // 0x00CA9EC8: B.LS #0xcaa294             | if (this._hash[(long)this._hashMask] <= val_3) goto label_63;
            if(val_42 <= val_3)
            {
                goto label_63;
            }
            // 0x00CA9ECC: LDR w8, [sp, #0x24]        | W8 = ;                                  
            // 0x00CA9ED0: LDR w1, [x20, #0x70]       | W1 = this.kNumHashDirectBytes; //P2     
            // 0x00CA9ED4: ADD w10, w25, w23          | W10 = (this._matchMaxLen + W23);        
            uint val_20 = val_43 + W23;
            // 0x00CA9ED8: LDR w28, [x20, #0x60]      | W28 = this._cutValue; //P2              
            // 0x00CA9EDC: MVN w9, w22                | W9 = ~(W22);                            
            // 0x00CA9EE0: MVN w10, w10               | W10 = ~((this._matchMaxLen + W23));     
            // 0x00CA9EE4: ADD w24, w23, w8           | W24 = (W23 + ???);                      
            var val_21 = W23 + (???);
            // 0x00CA9EE8: ORR w8, wzr, #0xfffffffe   | W8 = -2(0xFFFFFFFFFFFFFFFE);            
            var val_43 = -2;
            // 0x00CA9EEC: CMP w9, w10                | STATE = COMPARE(~(W22), ~((this._matchMaxLen + W23)))
            // 0x00CA9EF0: SUB w8, w8, w23            | W8 = (-2 - W23);                        
            val_43 = val_43 - W23;
            // 0x00CA9EF4: CSINV w9, w10, w22, ls     | W9 = ~W22 <= ~val_20 ? ~((this._matchMaxLen + W23)) : ( !W22);
            var val_22 = ((~W22) <= (~val_20)) ? (~val_20) : (!W22);
            // 0x00CA9EF8: SUB w25, w8, w9            | W25 = ((-2 - W23) - ~W22 <= ~val_20 ? ~((this._matchMaxLen + W23)) : ( !W22));
            val_43 = val_43 - val_22;
            // 0x00CA9EFC: MOV w27, w1                | W27 = this.kNumHashDirectBytes;//m1     
            val_46 = this.kNumHashDirectBytes;
            label_62:
            // 0x00CA9F00: STR w27, [sp, #0x14]       | stack[1152921513064612148] = this.kNumHashDirectBytes;  //  dest_result_addr=1152921513064612148
            label_57:
            // 0x00CA9F04: CBZ w28, #0xcaa294         | if (this._cutValue == 0) goto label_63; 
            if(this._cutValue == 0)
            {
                goto label_63;
            }
            // 0x00CA9F08: LDR w8, [x20, #0x34]       | 
            // 0x00CA9F0C: LDR w9, [x20, #0x44]       | W9 = this._cyclicBufferPos; //P2        
            // 0x00CA9F10: SUB w8, w8, w19            | W8 = ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long
            val_43 = val_43 - val_42;
            // 0x00CA9F14: SUBS w22, w9, w8           | W22 = (this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num +
            val_47 = this._cyclicBufferPos - val_43;
            // 0x00CA9F18: B.HS #0xca9f24             | if (~W22 >= ~val_20) goto label_35;     
            if((~W22) >= (~val_20))
            {
                goto label_35;
            }
            // 0x00CA9F1C: LDR w8, [x20, #0x48]       | W8 = this._cyclicBufferSize; //P2       
            // 0x00CA9F20: ADD w22, w22, w8           | W22 = ((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num 
            val_47 = val_47 + this._cyclicBufferSize;
            label_35:
            // 0x00CA9F24: LDR w21, [x20, #0x2c]      | 
            // 0x00CA9F28: LDR w2, [sp, #0x14]        | W2 = this.kNumHashDirectBytes;          
            // 0x00CA9F2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00CA9F30: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00CA9F34: STR w19, [sp, #0x24]       | stack[1152921513064612164] = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0];  //  dest_result_addr=1152921513064612164
            // 0x00CA9F38: ADD w19, w21, w19          | W19 = ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1
            val_42 = val_45 + val_42;
            // 0x00CA9F3C: STR w1, [sp, #8]           | stack[1152921513064612136] = this.kNumHashDirectBytes;  //  dest_result_addr=1152921513064612136
            // 0x00CA9F40: BL #0x16f9694              | X0 = System.Math.Min(val1:  0, val2:  this.kNumHashDirectBytes);
            uint val_23 = System.Math.Min(val1:  0, val2:  this.kNumHashDirectBytes);
            // 0x00CA9F44: LDR x27, [x20, #0x10]      | 
            // 0x00CA9F48: MOV w23, w0                | W23 = val_23;//m1                       
            // 0x00CA9F4C: CBNZ x27, #0xca9f54        | if (this.kNumHashDirectBytes != 0) goto label_36;
            if(val_46 != 0)
            {
                goto label_36;
            }
            // 0x00CA9F50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_36:
            // 0x00CA9F54: LDR w8, [x27, #0x18]       | W8 = this.kNumHashDirectBytes + 24;     
            // 0x00CA9F58: ADD w9, w23, w19           | W9 = (val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 +
            uint val_24 = val_23 + val_42;
            // 0x00CA9F5C: SXTW x26, w9               | X26 = (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int);
            // 0x00CA9F60: STR w28, [sp, #0x1c]       | stack[1152921513064612156] = this._cutValue;  //  dest_result_addr=1152921513064612156
            // 0x00CA9F64: CMP w9, w8                 | STATE = COMPARE((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int, this.kNumHashDirectBytes + 24)
            // 0x00CA9F68: B.LO #0xca9f78             | if (val_24 < this.kNumHashDirectBytes + 24) goto label_37;
            if(val_24 < (this.kNumHashDirectBytes + 24))
            {
                goto label_37;
            }
            // 0x00CA9F6C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CA9F70: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9F74: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_37:
            // 0x00CA9F78: ADD x8, x27, x26           | X8 = (this.kNumHashDirectBytes + (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num +
            uint val_25 = val_46 + (long)val_24;
            // 0x00CA9F7C: LDRB w27, [x8, #0x20]      | W27 = (this.kNumHashDirectBytes + (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 32;
            val_46 = mem[(this.kNumHashDirectBytes + (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 32];
            val_46 = (this.kNumHashDirectBytes + (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 32;
            // 0x00CA9F80: LDR x28, [x20, #0x10]      | 
            // 0x00CA9F84: CBNZ x28, #0xca9f8c        | if (this._cutValue != 0) goto label_38; 
            if(this._cutValue != 0)
            {
                goto label_38;
            }
            // 0x00CA9F88: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_38:
            // 0x00CA9F8C: LDR w9, [sp, #0x28]        | W9 = (W23 + W10);                       
            var val_44 = val_4;
            // 0x00CA9F90: LDR w8, [x28, #0x18]       | W8 = this._cutValue + 24;               
            // 0x00CA9F94: ADD w9, w23, w9            | W9 = (val_23 + (W23 + W10));            
            val_44 = val_23 + val_44;
            // 0x00CA9F98: SXTW x26, w9               | X26 = (long)(int)((val_23 + (W23 + W10)));
            // 0x00CA9F9C: CMP w9, w8                 | STATE = COMPARE((val_23 + (W23 + W10)), this._cutValue + 24)
            // 0x00CA9FA0: B.LO #0xca9fb0             | if (val_4 < this._cutValue + 24) goto label_39;
            if(val_44 < (this._cutValue + 24))
            {
                goto label_39;
            }
            // 0x00CA9FA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CA9FA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CA9FAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_39:
            // 0x00CA9FB0: ADD x8, x28, x26           | X8 = (this._cutValue + (long)(int)((val_23 + (W23 + W10))));
            uint val_26 = this._cutValue + (long)val_44;
            // 0x00CA9FB4: LDRB w8, [x8, #0x20]       | W8 = (this._cutValue + (long)(int)((val_23 + (W23 + W10)))) + 32;
            // 0x00CA9FB8: LSL w9, w22, #1            | W9 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);
            uint val_27 = val_47 << 1;
            // 0x00CA9FBC: STR w9, [sp, #0x20]        | stack[1152921513064612160] = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);  //  dest_result_addr=1152921513064612160
            // 0x00CA9FC0: CMP w27, w8                | STATE = COMPARE((this.kNumHashDirectBytes + (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 32, (this._cutValue + (long)(int)((val_23 + (W23 + W10)))) + 32)
            // 0x00CA9FC4: B.NE #0xcaa05c             | if (val_46 != (this._cutValue + (long)(int)((val_23 + (W23 + W10)))) + 32) goto label_40;
            if(val_46 != ((this._cutValue + (long)(int)((val_23 + (W23 + W10)))) + 32))
            {
                goto label_40;
            }
            // 0x00CA9FC8: LDR w8, [sp, #0x24]        | W8 = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0];
            // 0x00CA9FCC: ADD w21, w8, w21           | W21 = (this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23
            val_45 = val_42 + val_45;
            label_46:
            // 0x00CA9FD0: CMP w25, w23               | STATE = COMPARE(((-2 - W23) - ~W22 <= ~val_20 ? ~((this._matchMaxLen + W23)) : ( !W22)), val_23)
            // 0x00CA9FD4: B.EQ #0xcaa1d0             | if (val_43 == val_23) goto label_41;    
            if(val_43 == val_23)
            {
                goto label_41;
            }
            // 0x00CA9FD8: LDR x22, [x20, #0x10]      | 
            // 0x00CA9FDC: CBNZ x22, #0xca9fe4        | if (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  != 0) goto label_42;
            if(val_47 != 0)
            {
                goto label_42;
            }
            // 0x00CA9FE0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_42:
            // 0x00CA9FE4: LDR w8, [x22, #0x18]       | W8 = ((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 24;
            // 0x00CA9FE8: ADD w9, w21, w23           | W9 = ((this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23
            uint val_28 = val_45 + val_23;
            // 0x00CA9FEC: ADD w9, w9, #1             | W9 = (((this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W2
            val_28 = val_28 + 1;
            // 0x00CA9FF0: SXTW x26, w9               | X26 = (long)(int)((((this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)();
            // 0x00CA9FF4: CMP w9, w8                 | STATE = COMPARE((((this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(, ((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 24)
            // 0x00CA9FF8: B.LO #0xcaa008             | if (val_28 < ((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 24) goto label_43;
            if(val_28 < (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  + 24))
            {
                goto label_43;
            }
            // 0x00CA9FFC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA000: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA004: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_43:
            // 0x00CAA008: ADD x8, x22, x26           | X8 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num 
            uint val_29 = val_47 + (long)val_28;
            // 0x00CAA00C: LDRB w22, [x8, #0x20]      | W22 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + + 32;
            // 0x00CAA010: LDR x28, [x20, #0x10]      | 
            // 0x00CAA014: CBNZ x28, #0xcaa01c        | if (this._cutValue != 0) goto label_44; 
            if(this._cutValue != 0)
            {
                goto label_44;
            }
            // 0x00CAA018: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_44:
            // 0x00CAA01C: LDR w8, [x28, #0x18]       | W8 = this._cutValue + 24;               
            // 0x00CAA020: ADD w9, w24, w23           | W9 = ((W23 + ???) + val_23);            
            uint val_30 = val_21 + val_23;
            // 0x00CAA024: ADD w9, w9, #1             | W9 = (((W23 + ???) + val_23) + 1);      
            val_30 = val_30 + 1;
            // 0x00CAA028: ADD w27, w23, #1           | W27 = (val_23 + 1);                     
            val_46 = val_23 + 1;
            // 0x00CAA02C: SXTW x23, w9               | X23 = (long)(int)((((W23 + ???) + val_23) + 1));
            // 0x00CAA030: CMP w9, w8                 | STATE = COMPARE((((W23 + ???) + val_23) + 1), this._cutValue + 24)
            // 0x00CAA034: B.LO #0xcaa044             | if (val_30 < this._cutValue + 24) goto label_45;
            if(val_30 < (this._cutValue + 24))
            {
                goto label_45;
            }
            // 0x00CAA038: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA03C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA040: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_45:
            // 0x00CAA044: ADD x8, x28, x23           | X8 = (this._cutValue + (long)(int)((((W23 + ???) + val_23) + 1)));
            uint val_31 = this._cutValue + (long)val_30;
            // 0x00CAA048: LDRB w8, [x8, #0x20]       | W8 = (this._cutValue + (long)(int)((((W23 + ???) + val_23) + 1))) + 32;
            // 0x00CAA04C: CMP w22, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + + 32, (this._cutValue + (long)(int)((((W23 + ???) + val_23) + 1))) + 32)
            // 0x00CAA050: MOV w23, w27               | W23 = (val_23 + 1);//m1                 
            // 0x00CAA054: B.EQ #0xca9fd0             | if ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + + 32 == (this._cutValue + (long)(int)((((W23 + ???) + val_23) + 1))) + 32) goto label_46;
            if(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + + 32) == ((this._cutValue + (long)(int)((((W23 + ???) + val_23) + 1))) + 32))
            {
                goto label_46;
            }
            // 0x00CAA058: B #0xcaa060                |  goto label_47;                         
            goto label_47;
            label_40:
            // 0x00CAA05C: MOV w27, w23               | W27 = val_23;//m1                       
            val_46 = val_23;
            label_47:
            // 0x00CAA060: LDR x21, [x20, #0x10]      | 
            // 0x00CAA064: CBNZ x21, #0xcaa06c        | if ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) != 0) goto label_48;
            if(val_45 != 0)
            {
                goto label_48;
            }
            // 0x00CAA068: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_48:
            // 0x00CAA06C: LDR w8, [x21, #0x18]       | W8 = (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24;
            // 0x00CAA070: LDP w26, w28, [sp, #0x18]  | W26 = val_1 > W22 ? (W23 - this._cyclicBufferSize) : 0; W28 = this._cutValue; //  | 
            uint val_47 = this._cutValue;
            // 0x00CAA074: ADD w9, w27, w19           | W9 = (val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 +
            uint val_32 = val_46 + val_42;
            // 0x00CAA078: SXTW x22, w9               | X22 = (long)(int)((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int);
            // 0x00CAA07C: CMP w9, w8                 | STATE = COMPARE((val_23 + ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int, (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24)
            // 0x00CAA080: B.LO #0xcaa090             | if (val_32 < (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24) goto label_49;
            if(val_32 < ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24))
            {
                goto label_49;
            }
            // 0x00CAA084: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA088: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA08C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_49:
            // 0x00CAA090: ADD x8, x21, x22           | X8 = ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1)
            var val_33 = val_45 + (long)val_32;
            // 0x00CAA094: LDRB w23, [x8, #0x20]      | W23 = ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32;
            // 0x00CAA098: LDR x21, [x20, #0x10]      | 
            // 0x00CAA09C: LDR w19, [sp, #0x24]       | W19 = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0];
            // 0x00CAA0A0: CBNZ x21, #0xcaa0a8        | if ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) != 0) goto label_50;
            if(val_45 != 0)
            {
                goto label_50;
            }
            // 0x00CAA0A4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_50:
            // 0x00CAA0A8: LDR w9, [sp, #0x28]        | W9 = (W23 + W10);                       
            var val_46 = val_4;
            // 0x00CAA0AC: LDR w8, [x21, #0x18]       | W8 = (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24;
            // 0x00CAA0B0: ADD w9, w27, w9            | W9 = (val_23 + (W23 + W10));            
            val_46 = val_46 + val_46;
            // 0x00CAA0B4: SXTW x22, w9               | X22 = (long)(int)((val_23 + (W23 + W10)));
            // 0x00CAA0B8: CMP w9, w8                 | STATE = COMPARE((val_23 + (W23 + W10)), (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24)
            // 0x00CAA0BC: B.LO #0xcaa0cc             | if (val_4 < (long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24) goto label_51;
            if(val_46 < ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0) + 24))
            {
                goto label_51;
            }
            // 0x00CAA0C0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA0C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA0C8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_51:
            // 0x00CAA0CC: ADD x8, x21, x22           | X8 = ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1)
            var val_34 = val_45 + (long)val_46;
            // 0x00CAA0D0: LDRB w22, [x8, #0x20]      | W22 = ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32;
            // 0x00CAA0D4: LDR x21, [x20, #0x50]      | X21 = this._son; //P2                   
            // 0x00CAA0D8: SUB w28, w28, #1           | W28 = (this._cutValue - 1);             
            val_47 = val_47 - 1;
            // 0x00CAA0DC: CBNZ x21, #0xcaa0e4        | if (this._son != null) goto label_52;   
            if(this._son != null)
            {
                goto label_52;
            }
            // 0x00CAA0E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_52:
            // 0x00CAA0E4: CMP w23, w22               | STATE = COMPARE(((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32, ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32)
            // 0x00CAA0E8: B.LO #0xcaa15c             | if (((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32 < ((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32) goto label_53;
            if((((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32) < (((long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 +  + 32))
            {
                goto label_53;
            }
            // 0x00CAA0EC: LDR w9, [sp, #0x2c]        | W9 = 0x1;                               
            // 0x00CAA0F0: LDR w8, [x21, #0x18]       | W8 = this._son.Length; //P2             
            // 0x00CAA0F4: LDR w23, [sp, #0x20]       | W23 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);
            val_42 = val_27;
            // 0x00CAA0F8: MOV w22, w9                | W22 = 1 (0x1);//ML01                    
            // 0x00CAA0FC: CMP w9, w8                 | STATE = COMPARE(0x1, this._son.Length)  
            // 0x00CAA100: B.LO #0xcaa110             | if (1 < this._son.Length) goto label_54;
            if(1 < this._son.Length)
            {
                goto label_54;
            }
            // 0x00CAA104: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA108: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA10C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_54:
            // 0x00CAA110: ADD x8, x21, x22, lsl #2   | X8 = this._son[0x1]; //PARR1            
            // 0x00CAA114: STR w19, [x8, #0x20]       | this._son[0x1][0] = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0];  //  dest_result_addr=0
            this._son[1] = val_42;
            // 0x00CAA118: LDR x19, [x20, #0x50]      | X19 = this._son; //P2                   
            // 0x00CAA11C: CBNZ x19, #0xcaa124        | if (this._son != null) goto label_55;   
            if(this._son != null)
            {
                goto label_55;
            }
            // 0x00CAA120: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_55:
            // 0x00CAA124: LDR w8, [x19, #0x18]       | W8 = this._son.Length; //P2             
            // 0x00CAA128: MOV w21, w23               | W21 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);//m1
            // 0x00CAA12C: CMP w23, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1), this._son.Length)
            // 0x00CAA130: B.LO #0xcaa140             | if (val_42 < this._son.Length) goto label_56;
            if(val_42 < this._son.Length)
            {
                goto label_56;
            }
            // 0x00CAA134: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA138: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA13C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_56:
            // 0x00CAA140: ADD x8, x19, x21, lsl #2   | X8 = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)]; //PARR1 
            // 0x00CAA144: LDR w19, [x8, #0x20]       | W19 = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)][0]
            uint val_48 = this._son[val_42];
            // 0x00CAA148: STR w23, [sp, #0x2c]       | stack[1152921513064612172] = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);  //  dest_result_addr=1152921513064612172
            // 0x00CAA14C: CMP w19, w26               | STATE = COMPARE(this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)][0], val_1 > W22 ? (W23 - this._cyclicBufferSize) : 0)
            // 0x00CAA150: MOV w1, w27                | W1 = val_23;//m1                        
            // 0x00CAA154: B.HI #0xca9f04             | if (this._son[val_42] > val_3) goto label_57;
            if(val_48 > val_3)
            {
                goto label_57;
            }
            // 0x00CAA158: B #0xcaa290                |  goto label_58;                         
            goto label_58;
            label_53:
            // 0x00CAA15C: LDR w9, [sp, #0x10]        | W9 = (this._cyclicBufferPos << 1);      
            // 0x00CAA160: LDR w8, [x21, #0x18]       | W8 = this._son.Length; //P2             
            // 0x00CAA164: LDR w23, [sp, #0x20]       | W23 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);
            val_42 = val_27;
            // 0x00CAA168: MOV w22, w9                | W22 = (this._cyclicBufferPos << 1);//m1 
            // 0x00CAA16C: CMP w9, w8                 | STATE = COMPARE((this._cyclicBufferPos << 1), this._son.Length)
            // 0x00CAA170: B.LO #0xcaa180             | if (val_19 < this._son.Length) goto label_59;
            if(val_19 < this._son.Length)
            {
                goto label_59;
            }
            // 0x00CAA174: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA17C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_59:
            // 0x00CAA180: ADD x8, x21, x22, lsl #2   | X8 = this._son[(this._cyclicBufferPos << 1)]; //PARR1 
            // 0x00CAA184: STR w19, [x8, #0x20]       | this._son[(this._cyclicBufferPos << 1)][0] = this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) + 32) << 2) + 32) ^ (this._hash[(long)(int)(((W23 + W10) + 2))][0)][0];  //  dest_result_addr=0
            this._son[val_19] = val_42;
            // 0x00CAA188: LDR x19, [x20, #0x50]      | X19 = this._son; //P2                   
            // 0x00CAA18C: ORR w22, w23, #1           | W22 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((nu
            uint val_35 = val_42 | 1;
            // 0x00CAA190: CBNZ x19, #0xcaa198        | if (this._son != null) goto label_60;   
            if(this._son != null)
            {
                goto label_60;
            }
            // 0x00CAA194: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_60:
            // 0x00CAA198: LDR w8, [x19, #0x18]       | W8 = this._son.Length; //P2             
            // 0x00CAA19C: MOV w21, w22               | W21 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ;//m1
            // 0x00CAA1A0: STR w22, [sp, #0x10]       | stack[1152921513064612144] = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ;  //  dest_result_addr=1152921513064612144
            // 0x00CAA1A4: CMP w22, w8                | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) , this._son.Length)
            // 0x00CAA1A8: B.LO #0xcaa1b8             | if (val_35 < this._son.Length) goto label_61;
            if(val_35 < this._son.Length)
            {
                goto label_61;
            }
            // 0x00CAA1AC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA1B0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA1B4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_61:
            // 0x00CAA1B8: ADD x8, x19, x21, lsl #2   | X8 = this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ]; //PARR1 
            // 0x00CAA1BC: LDR w19, [x8, #0x20]       | W19 = this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ][0]
            uint val_49 = this._son[val_35];
            // 0x00CAA1C0: LDR w1, [sp, #8]           | W1 = this.kNumHashDirectBytes;          
            // 0x00CAA1C4: CMP w19, w26               | STATE = COMPARE(this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ][0], val_1 > W22 ? (W23 - this._cyclicBufferSize) : 0)
            // 0x00CAA1C8: B.HI #0xca9f00             | if (this._son[val_35] > val_3) goto label_62;
            if(val_49 > val_3)
            {
                goto label_62;
            }
            // 0x00CAA1CC: B #0xcaa294                |  goto label_63;                         
            goto label_63;
            label_41:
            // 0x00CAA1D0: LDR x19, [x20, #0x50]      | X19 = this._son; //P2                   
            // 0x00CAA1D4: CBNZ x19, #0xcaa1dc        | if (this._son != null) goto label_64;   
            if(this._son != null)
            {
                goto label_64;
            }
            // 0x00CAA1D8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_64:
            // 0x00CAA1DC: LDR x8, [x19, #0x18]       | X8 = this._son.Length; //P2             
            val_49 = this._son.Length;
            // 0x00CAA1E0: LDR w10, [sp, #0x20]       | W10 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);
            // 0x00CAA1E4: LDR w23, [sp, #0x10]       | W23 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ;
            val_42 = val_35;
            // 0x00CAA1E8: MOV w21, w10               | W21 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);//m1
            // 0x00CAA1EC: CMP w10, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1), this._son.Length)
            // 0x00CAA1F0: MOV w24, w10               | W24 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);//m1
            // 0x00CAA1F4: B.LO #0xcaa208             | if (val_27 < val_49) goto label_65;     
            if(val_27 < val_49)
            {
                goto label_65;
            }
            // 0x00CAA1F8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA1FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA200: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            // 0x00CAA204: LDR x8, [x19, #0x18]       | X8 = this._son.Length; //P2             
            val_49 = this._son.Length;
            label_65:
            // 0x00CAA208: ADD x9, x19, x21, lsl #2   | X9 = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)]; //PARR1 
            // 0x00CAA20C: LDR w21, [x9, #0x20]       | W21 = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)][0]
            uint val_50 = this._son[val_27];
            // 0x00CAA210: MOV w22, w23               | W22 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ;//m1
            // 0x00CAA214: CMP w23, w8                | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) , this._son.Length)
            // 0x00CAA218: B.LO #0xcaa228             | if (val_42 < val_49) goto label_66;     
            if(val_42 < val_49)
            {
                goto label_66;
            }
            // 0x00CAA21C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA220: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA224: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_66:
            // 0x00CAA228: ADD x8, x19, x22, lsl #2   | X8 = this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ]; //PARR1 
            // 0x00CAA22C: STR w21, [x8, #0x20]       | this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ][0] = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)][0];  //  dest_result_addr=0
            this._son[val_42] = val_50;
            // 0x00CAA230: LDR x19, [x20, #0x50]      | X19 = this._son; //P2                   
            val_40 = this._son;
            // 0x00CAA234: CBNZ x19, #0xcaa23c        | if (this._son != null) goto label_67;   
            if(val_40 != null)
            {
                goto label_67;
            }
            // 0x00CAA238: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_67:
            // 0x00CAA23C: LDR x8, [x19, #0x18]       | X8 = this._son.Length; //P2             
            val_50 = this._son.Length;
            // 0x00CAA240: ORR w9, w24, #1            | W9 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num
            uint val_36 = val_27 | 1;
            // 0x00CAA244: SXTW x21, w9               | X21 = (long)(int)(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) );
            // 0x00CAA248: CMP w9, w8                 | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) , this._son.Length)
            // 0x00CAA24C: B.LO #0xcaa260             | if (val_36 < val_50) goto label_68;     
            if(val_36 < val_50)
            {
                goto label_68;
            }
            // 0x00CAA250: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA254: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA258: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            // 0x00CAA25C: LDR x8, [x19, #0x18]       | X8 = this._son.Length; //P2             
            val_50 = this._son.Length;
            label_68:
            // 0x00CAA260: ADD x9, x19, x21, lsl #2   | X9 = this._son[(long)(int)(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) )]; //PARR1 
            // 0x00CAA264: LDR w21, [x9, #0x20]       | W21 = this._son[(long)(int)(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) )][0]
            uint val_51 = val_40[(long)val_36];
            // 0x00CAA268: LDR w9, [sp, #0x2c]        | W9 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);
            // 0x00CAA26C: MOV w22, w9                | W22 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);//m1
            // 0x00CAA270: CMP w9, w8                 | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1), this._son.Length)
            // 0x00CAA274: B.LO #0xcaa284             | if (val_42 < val_50) goto label_69;     
            if(val_42 < val_50)
            {
                goto label_69;
            }
            // 0x00CAA278: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA280: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_69:
            // 0x00CAA284: ADD x8, x19, x22, lsl #2   | X8 = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)]; //PARR1 
            // 0x00CAA288: STR w21, [x8, #0x20]       | this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)][0] = this._son[(long)(int)(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) )][0];  //  dest_result_addr=0
            val_40[val_42] = val_51;
            // 0x00CAA28C: B #0xcaa2f0                |  goto label_70;                         
            goto label_70;
            label_58:
            // 0x00CAA290: STR w23, [sp, #0x2c]       | stack[1152921513064612172] = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);  //  dest_result_addr=1152921513064612172
            label_63:
            // 0x00CAA294: LDR x19, [x20, #0x50]      | X19 = this._son; //P2                   
            val_40 = this._son;
            // 0x00CAA298: CBNZ x19, #0xcaa2a0        | if (this._son != null) goto label_71;   
            if(val_40 != null)
            {
                goto label_71;
            }
            // 0x00CAA29C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_23, ????);     
            label_71:
            // 0x00CAA2A0: LDR w9, [sp, #0x10]        | W9 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ;
            // 0x00CAA2A4: LDR x8, [x19, #0x18]       | X8 = this._son.Length; //P2             
            val_51 = this._son.Length;
            // 0x00CAA2A8: MOV w21, w9                | W21 = ((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ;//m1
            // 0x00CAA2AC: CMP w9, w8                 | STATE = COMPARE(((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) , this._son.Length)
            // 0x00CAA2B0: B.LO #0xcaa2c4             | if (val_35 < val_51) goto label_72;     
            if(val_35 < val_51)
            {
                goto label_72;
            }
            // 0x00CAA2B4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA2B8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA2BC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            // 0x00CAA2C0: LDR x8, [x19, #0x18]       | X8 = this._son.Length; //P2             
            val_51 = this._son.Length;
            label_72:
            // 0x00CAA2C4: LDR w10, [sp, #0x2c]       | W10 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);
            // 0x00CAA2C8: ADD x9, x19, x21, lsl #2   | X9 = this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ]; //PARR1 
            // 0x00CAA2CC: STR wzr, [x9, #0x20]       | this._son[((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) ][0] = null;  //  dest_result_addr=0
            val_40[val_35] = 0;
            // 0x00CAA2D0: MOV w21, w10               | W21 = (((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1);//m1
            // 0x00CAA2D4: CMP w10, w8                | STATE = COMPARE((((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1), this._son.Length)
            // 0x00CAA2D8: B.LO #0xcaa2e8             | if (val_42 < val_51) goto label_73;     
            if(val_42 < val_51)
            {
                goto label_73;
            }
            // 0x00CAA2DC: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_23, ????);     
            // 0x00CAA2E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA2E4: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_23, ????);     
            label_73:
            // 0x00CAA2E8: ADD x8, x19, x21, lsl #2   | X8 = this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)]; //PARR1 
            // 0x00CAA2EC: STR wzr, [x8, #0x20]       | this._son[(((this._cyclicBufferPos - ((-2 - W23) - this._hash[(long)(int)((this.kFixHashSize + ((((((num + (W23 + W10)) + 32 + (long)(int)(((W23 + W10) + 1))) + 32 ^ (SevenZip.CRC.Table + ((num + (W23 + W10)) +  << 1)][0] = null;  //  dest_result_addr=0
            val_40[val_42] = 0;
            label_70:
            // 0x00CAA2F0: MOV x0, x20                | X0 = 1152921513064624272 (0x10000001F81F7090);//ML01
            // 0x00CAA2F4: BL #0xca8924               | this.MovePos();                         
            this.MovePos();
            // 0x00CAA2F8: LDR w21, [sp, #0xc]        | W21 = num;                              
            val_41 = val_41;
            label_3:
            // 0x00CAA2FC: SUB w21, w21, #1           | W21 = (num - 1);                        
            val_41 = val_41 - 1;
            // 0x00CAA300: CBNZ w21, #0xca9b74        | if ((num - 1) != 0) goto label_74;      
            if(val_41 != 0)
            {
                goto label_74;
            }
            // 0x00CAA304: SUB sp, x29, #0x50         | SP = (1152921513064612256 - 80) = 1152921513064612176 (0x10000001F81F4150);
            // 0x00CAA308: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00CAA30C: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00CAA310: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00CAA314: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00CAA318: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00CAA31C: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00CAA320: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CAA324 (13280036), len: 148  VirtAddr: 0x00CAA324 RVA: 0x00CAA324 token: 100681468 methodIndex: 54597 delegateWrapperIndex: 0 methodInvoker: 0
        private void NormalizeLinks(uint[] items, uint numItems, uint subValue)
        {
            //
            // Disasemble & Code
            //  | 
            int val_3;
            // 0x00CAA324: STP x24, x23, [sp, #-0x40]! | stack[1152921513065129712] = ???;  stack[1152921513065129720] = ???;  //  dest_result_addr=1152921513065129712 |  dest_result_addr=1152921513065129720
            // 0x00CAA328: STP x22, x21, [sp, #0x10]  | stack[1152921513065129728] = ???;  stack[1152921513065129736] = ???;  //  dest_result_addr=1152921513065129728 |  dest_result_addr=1152921513065129736
            // 0x00CAA32C: STP x20, x19, [sp, #0x20]  | stack[1152921513065129744] = ???;  stack[1152921513065129752] = ???;  //  dest_result_addr=1152921513065129744 |  dest_result_addr=1152921513065129752
            // 0x00CAA330: STP x29, x30, [sp, #0x30]  | stack[1152921513065129760] = ???;  stack[1152921513065129768] = ???;  //  dest_result_addr=1152921513065129760 |  dest_result_addr=1152921513065129768
            // 0x00CAA334: ADD x29, sp, #0x30         | X29 = (1152921513065129712 + 48) = 1152921513065129760 (0x10000001F8272720);
            // 0x00CAA338: MOV w19, w3                | W19 = subValue;//m1                     
            // 0x00CAA33C: MOV x20, x1                | X20 = items;//m1                        
            // 0x00CAA340: CBZ w2, #0xcaa3a4          | if (numItems == 0) goto label_0;        
            if(numItems == 0)
            {
                goto label_0;
            }
            // 0x00CAA344: MOV x21, xzr               | X21 = 0 (0x0);//ML01                    
            var val_3 = 0;
            // 0x00CAA348: ADD x22, x20, #0x20        | X22 = items[0x20]; //PARR1              
            // 0x00CAA34C: MOV w23, w2                | W23 = numItems;//m1                     
            label_4:
            // 0x00CAA350: CBNZ x20, #0xcaa358        | if (items != null) goto label_1;        
            if(items != null)
            {
                goto label_1;
            }
            // 0x00CAA354: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_1:
            // 0x00CAA358: LDR w8, [x20, #0x18]       | W8 = items.Length; //P2                 
            val_3 = items.Length;
            // 0x00CAA35C: CMP x21, x8                | STATE = COMPARE(0x0, items.Length)      
            // 0x00CAA360: B.LO #0xcaa374             | if (0 < val_3) goto label_2;            
            if(val_3 < val_3)
            {
                goto label_2;
            }
            // 0x00CAA364: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00CAA368: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA36C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            // 0x00CAA370: LDR w8, [x20, #0x18]       | W8 = items.Length; //P2                 
            val_3 = items.Length;
            label_2:
            // 0x00CAA374: LDR w9, [x22, x21, lsl #2] | W9 = typeof(System.UInt32[]);           
            // 0x00CAA378: SUBS w9, w9, w19           | W9 = (1152921505007033440 - subValue);  
            System.UInt32[] val_1 = 1152921505007033440 - subValue;
            // 0x00CAA37C: CSEL w24, w9, wzr, hi      | W24 = 0 > val_3 ? (1152921505007033440 - subValue) : 0;
            var val_2 = (val_3 > val_3) ? (val_1) : 0;
            // 0x00CAA380: CMP x21, x8                | STATE = COMPARE(0x0, items.Length)      
            // 0x00CAA384: B.LO #0xcaa394             | if (0 < val_3) goto label_3;            
            if(val_3 < val_3)
            {
                goto label_3;
            }
            // 0x00CAA388: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00CAA38C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00CAA390: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_3:
            // 0x00CAA394: STR w24, [x22, x21, lsl #2] | mem2[0] = 0 > val_3 ? (1152921505007033440 - subValue) : 0;  //  dest_result_addr=0
            mem2[0] = val_2;
            // 0x00CAA398: ADD x21, x21, #1           | X21 = (0 + 1);                          
            val_3 = val_3 + 1;
            // 0x00CAA39C: CMP w23, w21               | STATE = COMPARE(numItems, (0 + 1))      
            // 0x00CAA3A0: B.NE #0xcaa350             | if (numItems != 0) goto label_4;        
            if(numItems != val_3)
            {
                goto label_4;
            }
            label_0:
            // 0x00CAA3A4: LDP x29, x30, [sp, #0x30]  | X29 = ; X30 = ;                          //  | 
            // 0x00CAA3A8: LDP x20, x19, [sp, #0x20]  | X20 = ; X19 = ;                          //  | 
            // 0x00CAA3AC: LDP x22, x21, [sp, #0x10]  | X22 = ; X21 = ;                          //  | 
            // 0x00CAA3B0: LDP x24, x23, [sp], #0x40  | X24 = ; X23 = ;                          //  | 
            // 0x00CAA3B4: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CA89DC (13273564), len: 120  VirtAddr: 0x00CA89DC RVA: 0x00CA89DC token: 100681469 methodIndex: 54598 delegateWrapperIndex: 0 methodInvoker: 0
        private void Normalize()
        {
            //
            // Disasemble & Code
            // 0x00CA89DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513065352336] = ???;  stack[1152921513065352344] = ???;  //  dest_result_addr=1152921513065352336 |  dest_result_addr=1152921513065352344
            // 0x00CA89E0: STP x29, x30, [sp, #0x10]  | stack[1152921513065352352] = ???;  stack[1152921513065352360] = ???;  //  dest_result_addr=1152921513065352352 |  dest_result_addr=1152921513065352360
            // 0x00CA89E4: ADD x29, sp, #0x10         | X29 = (1152921513065352336 + 16) = 1152921513065352352 (0x10000001F82A8CA0);
            // 0x00CA89E8: MOV x19, x0                | X19 = 1152921513065364368 (0x10000001F82ABB90);//ML01
            // 0x00CA89EC: LDR w8, [x19, #0x34]       | 
            // 0x00CA89F0: LDR w9, [x19, #0x48]       | W9 = this._cyclicBufferSize; //P2       
            uint val_6 = this._cyclicBufferSize;
            // 0x00CA89F4: LDR x1, [x19, #0x50]       | X1 = this._son; //P2                    
            // 0x00CA89F8: SUB w20, w8, w9            | W20 = (W8 - this._cyclicBufferSize);    
            uint val_1 = W8 - val_6;
            // 0x00CA89FC: LSL w2, w9, #1             | W2 = (this._cyclicBufferSize << 1);     
            uint val_2 = val_6 << 1;
            // 0x00CA8A00: MOV w3, w20                | W3 = (W8 - this._cyclicBufferSize);//m1 
            // 0x00CA8A04: BL #0xcaa324               | this.NormalizeLinks(items:  this._son, numItems:  uint val_2 = this._cyclicBufferSize << 1, subValue:  val_1);
            this.NormalizeLinks(items:  this._son, numItems:  val_2, subValue:  val_1);
            // 0x00CA8A08: LDR x1, [x19, #0x58]       | X1 = this._hash; //P2                   
            // 0x00CA8A0C: LDR w2, [x19, #0x68]       | W2 = this._hashSizeSum; //P2            
            // 0x00CA8A10: MOV w3, w20                | W3 = (W8 - this._cyclicBufferSize);//m1 
            // 0x00CA8A14: BL #0xcaa324               | this.NormalizeLinks(items:  this._hash, numItems:  this._hashSizeSum, subValue:  val_1);
            this.NormalizeLinks(items:  this._hash, numItems:  this._hashSizeSum, subValue:  val_1);
            // 0x00CA8A18: LDR w11, [x19, #0x40]      | 
            // 0x00CA8A1C: LDR w8, [x19, #0x2c]       | 
            // 0x00CA8A20: LDR w9, [x19, #0x20]       | 
            // 0x00CA8A24: LDR w10, [x19, #0x34]      | 
            // 0x00CA8A28: SUB w11, w11, w20          | W11 = (W11 - (W8 - this._cyclicBufferSize));
            uint val_3 = W11 - val_1;
            // 0x00CA8A2C: ADD w8, w8, w20            | W8 = (W8 + (W8 - this._cyclicBufferSize));
            uint val_4 = W8 + val_1;
            // 0x00CA8A30: SUB w9, w9, w20            | W9 = (this._cyclicBufferSize - (W8 - this._cyclicBufferSize));
            val_6 = val_6 - val_1;
            // 0x00CA8A34: SUB w10, w10, w20          | W10 = (W10 - (W8 - this._cyclicBufferSize));
            uint val_5 = W10 - val_1;
            // 0x00CA8A38: STR w11, [x19, #0x40]      | mem[1152921513065364432] = (W11 - (W8 - this._cyclicBufferSize));  //  dest_result_addr=1152921513065364432
            mem[1152921513065364432] = val_3;
            // 0x00CA8A3C: STR w8, [x19, #0x2c]       | mem[1152921513065364412] = (W8 + (W8 - this._cyclicBufferSize));  //  dest_result_addr=1152921513065364412
            mem[1152921513065364412] = val_4;
            // 0x00CA8A40: STR w9, [x19, #0x20]       | mem[1152921513065364400] = (this._cyclicBufferSize - (W8 - this._cyclicBufferSize));  //  dest_result_addr=1152921513065364400
            mem[1152921513065364400] = val_6;
            // 0x00CA8A44: STR w10, [x19, #0x34]      | mem[1152921513065364420] = (W10 - (W8 - this._cyclicBufferSize));  //  dest_result_addr=1152921513065364420
            mem[1152921513065364420] = val_5;
            // 0x00CA8A48: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00CA8A4C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00CA8A50: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00CAA3B8 (13280184), len: 8  VirtAddr: 0x00CAA3B8 RVA: 0x00CAA3B8 token: 100681470 methodIndex: 54599 delegateWrapperIndex: 0 methodInvoker: 0
        public void SetCutValue(uint cutValue)
        {
            //
            // Disasemble & Code
            // 0x00CAA3B8: STR w1, [x0, #0x60]        | this._cutValue = cutValue;               //  dest_result_addr=1152921513065550192
            this._cutValue = cutValue;
            // 0x00CAA3BC: RET                        |  return;                                
            return;
        
        }
    
    }

}
