using UnityEngine;
[ProtoBuf.ProtoContractAttribute] // 0x286B99C
[Serializable]
public class CameraAnis : IExtensible
{
    // Fields
    private readonly System.Collections.Generic.List<CameraAniMap> _cameraMaps; //  0x00000010
    private ProtoBuf.IExtension extensionObject; //  0x00000018
    
    // Properties
    [ProtoBuf.ProtoMemberAttribute] // 0x286B9E0
    public System.Collections.Generic.List<CameraAniMap> cameraMaps { get; }
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA777C (12220284), len: 112  VirtAddr: 0x00BA777C RVA: 0x00BA777C token: 100690297 methodIndex: 25664 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAnis()
    {
        //
        // Disasemble & Code
        // 0x00BA777C: STP x20, x19, [sp, #-0x20]! | stack[1152921514505159776] = ???;  stack[1152921514505159784] = ???;  //  dest_result_addr=1152921514505159776 |  dest_result_addr=1152921514505159784
        // 0x00BA7780: STP x29, x30, [sp, #0x10]  | stack[1152921514505159792] = ???;  stack[1152921514505159800] = ???;  //  dest_result_addr=1152921514505159792 |  dest_result_addr=1152921514505159800
        // 0x00BA7784: ADD x29, sp, #0x10         | X29 = (1152921514505159776 + 16) = 1152921514505159792 (0x100000024DFC4470);
        // 0x00BA7788: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00BA778C: LDRB w8, [x20, #0xaea]     | W8 = (bool)static_value_03733AEA;       
        // 0x00BA7790: MOV x19, x0                | X19 = 1152921514505171808 (0x100000024DFC7360);//ML01
        // 0x00BA7794: TBNZ w8, #0, #0xba77b0     | if (static_value_03733AEA == true) goto label_0;
        // 0x00BA7798: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
        // 0x00BA779C: LDR x8, [x8, #0x7f0]       | X8 = 0x2B9015C;                         
        // 0x00BA77A0: LDR w0, [x8]               | W0 = 0x171B;                            
        // 0x00BA77A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x171B, ????);     
        // 0x00BA77A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA77AC: STRB w8, [x20, #0xaea]     | static_value_03733AEA = true;            //  dest_result_addr=57883370
        label_0:
        // 0x00BA77B0: ADRP x8, #0x35f4000        | X8 = 56573952 (0x35F4000);              
        // 0x00BA77B4: LDR x8, [x8, #0xe40]       | X8 = 1152921504616644608;               
        // 0x00BA77B8: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
        System.Collections.Generic.List<CameraAniMap> val_1 = null;
        // 0x00BA77BC: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
        // 0x00BA77C0: ADRP x8, #0x3602000        | X8 = 56631296 (0x3602000);              
        // 0x00BA77C4: LDR x8, [x8, #0x420]       | X8 = 1152921514505146784;               
        // 0x00BA77C8: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
        // 0x00BA77CC: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<CameraAniMap>::.ctor();
        // 0x00BA77D0: BL #0x25e9474              | .ctor();                                
        val_1 = new System.Collections.Generic.List<CameraAniMap>();
        // 0x00BA77D4: STR x20, [x19, #0x10]      | this._cameraMaps = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921514505171824
        this._cameraMaps = val_1;
        // 0x00BA77D8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA77DC: MOV x0, x19                | X0 = 1152921514505171808 (0x100000024DFC7360);//ML01
        // 0x00BA77E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA77E4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA77E8: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA6FE4 (12218340), len: 8  VirtAddr: 0x00BA6FE4 RVA: 0x00BA6FE4 token: 100690298 methodIndex: 25665 delegateWrapperIndex: 0 methodInvoker: 0
    public System.Collections.Generic.List<CameraAniMap> get_cameraMaps()
    {
        //
        // Disasemble & Code
        // 0x00BA6FE4: LDR x0, [x0, #0x10]        | X0 = this._cameraMaps; //P2             
        // 0x00BA6FE8: RET                        |  return (System.Collections.Generic.List<CameraAniMap>)this._cameraMaps;
        return this._cameraMaps;
        //  |  // // {name=val_0, type=System.Collections.Generic.List<CameraAniMap>, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA77EC (12220396), len: 24  VirtAddr: 0x00BA77EC RVA: 0x00BA77EC token: 100690299 methodIndex: 25666 delegateWrapperIndex: 0 methodInvoker: 0
    private ProtoBuf.IExtension ProtoBuf.IExtensible.GetExtensionObject(bool createIfMissing)
    {
        //
        // Disasemble & Code
        // 0x00BA77EC: ADD x8, x0, #0x18          | X8 = this.extensionObject;//AP2 res_addr=1152921514505404024
        // 0x00BA77F0: AND w2, w1, #1             | W2 = (createIfMissing & 1);             
        bool val_1 = createIfMissing;
        // 0x00BA77F4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        ProtoBuf.IExtension val_2 = 0;
        // 0x00BA77F8: MOV x1, x8                 | X1 = this.extensionObject;//m1          
        // 0x00BA77FC: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
        // 0x00BA7800: B #0xc7c9f0                | return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  ProtoBuf.IExtension val_2 = 0, createIfMissing:  this.extensionObject);
        return ProtoBuf.Extensible.GetExtensionObject(extensionObject: ref  val_2, createIfMissing:  this.extensionObject);
    
    }

}
