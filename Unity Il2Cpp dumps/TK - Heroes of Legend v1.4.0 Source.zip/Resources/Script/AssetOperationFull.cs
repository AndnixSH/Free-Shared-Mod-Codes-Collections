using UnityEngine;

namespace Mihua.Asset.ABLoadOperation
{
    public class AssetOperationFull : AssetOperation
    {
        // Fields
        protected string m_AssetBundleName; //  0x00000018
        protected string m_AssetName; //  0x00000020
        protected string m_DownloadingError; //  0x00000028
        protected UnityEngine.AssetBundleRequest m_Request; //  0x00000030
        protected string[] allAssetNames; //  0x00000038
        protected Mihua.Asset.OnLoadAsset m_OnLoadAsset; //  0x00000040
        
        // Properties
        public override float progress { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00AAF6C8 (11204296), len: 72  VirtAddr: 0x00AAF6C8 RVA: 0x00AAF6C8 token: 100693183 methodIndex: 46903 delegateWrapperIndex: 0 methodInvoker: 0
        public AssetOperationFull(string bundleName, string assetName, Mihua.Asset.OnLoadAsset onLoadAsset)
        {
            //
            // Disasemble & Code
            // 0x00AAF6C8: STP x22, x21, [sp, #-0x30]! | stack[1152921514949447904] = ???;  stack[1152921514949447912] = ???;  //  dest_result_addr=1152921514949447904 |  dest_result_addr=1152921514949447912
            // 0x00AAF6CC: STP x20, x19, [sp, #0x10]  | stack[1152921514949447920] = ???;  stack[1152921514949447928] = ???;  //  dest_result_addr=1152921514949447920 |  dest_result_addr=1152921514949447928
            // 0x00AAF6D0: STP x29, x30, [sp, #0x20]  | stack[1152921514949447936] = ???;  stack[1152921514949447944] = ???;  //  dest_result_addr=1152921514949447936 |  dest_result_addr=1152921514949447944
            // 0x00AAF6D4: ADD x29, sp, #0x20         | X29 = (1152921514949447904 + 32) = 1152921514949447936 (0x1000000268779100);
            // 0x00AAF6D8: MOV x21, x1                | X21 = bundleName;//m1                   
            // 0x00AAF6DC: MOV x22, x0                | X22 = 1152921514949459952 (0x100000026877BFF0);//ML01
            // 0x00AAF6E0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAF6E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAF6E8: MOV x19, x3                | X19 = onLoadAsset;//m1                  
            // 0x00AAF6EC: MOV x20, x2                | X20 = assetName;//m1                    
            // 0x00AAF6F0: STRB w8, [x22, #0x11]      | mem[1152921514949459969] = 0x1;          //  dest_result_addr=1152921514949459969
            mem[1152921514949459969] = 1;
            // 0x00AAF6F4: BL #0x16f59f0              | assetName..ctor();                      
            val_1 = new System.Object();
            // 0x00AAF6F8: STP x21, x20, [x22, #0x18] | this.m_AssetBundleName = bundleName;  this.m_AssetName = assetName;  //  dest_result_addr=1152921514949459976 |  dest_result_addr=1152921514949459984
            this.m_AssetBundleName = bundleName;
            this.m_AssetName = val_1;
            // 0x00AAF6FC: STR x19, [x22, #0x40]      | this.m_OnLoadAsset = onLoadAsset;        //  dest_result_addr=1152921514949460016
            this.m_OnLoadAsset = onLoadAsset;
            // 0x00AAF700: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAF704: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AAF708: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AAF70C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF710 (11204368), len: 140  VirtAddr: 0x00AAF710 RVA: 0x00AAF710 token: 100693184 methodIndex: 46904 delegateWrapperIndex: 0 methodInvoker: 0
        public override UnityEngine.Object GetAsset()
        {
            //
            // Disasemble & Code
            //  | 
            string val_2;
            //  | 
            var val_3;
            // 0x00AAF710: STP x20, x19, [sp, #-0x20]! | stack[1152921514949580400] = ???;  stack[1152921514949580408] = ???;  //  dest_result_addr=1152921514949580400 |  dest_result_addr=1152921514949580408
            // 0x00AAF714: STP x29, x30, [sp, #0x10]  | stack[1152921514949580416] = ???;  stack[1152921514949580424] = ???;  //  dest_result_addr=1152921514949580416 |  dest_result_addr=1152921514949580424
            // 0x00AAF718: ADD x29, sp, #0x10         | X29 = (1152921514949580400 + 16) = 1152921514949580416 (0x1000000268799680);
            // 0x00AAF71C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AAF720: LDRB w8, [x20, #0x3d5]     | W8 = (bool)static_value_037333D5;       
            // 0x00AAF724: MOV x19, x0                | X19 = 1152921514949592432 (0x100000026879C570);//ML01
            val_2 = this;
            // 0x00AAF728: TBNZ w8, #0, #0xaaf744     | if (static_value_037333D5 == true) goto label_0;
            // 0x00AAF72C: ADRP x8, #0x35ca000        | X8 = 56401920 (0x35CA000);              
            // 0x00AAF730: LDR x8, [x8, #0xef0]       | X8 = 0x2B8EBA8;                         
            // 0x00AAF734: LDR w0, [x8]               | W0 = 0x11AA;                            
            // 0x00AAF738: BL #0x2782188              | X0 = sub_2782188( ?? 0x11AA, ????);     
            // 0x00AAF73C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAF740: STRB w8, [x20, #0x3d5]     | static_value_037333D5 = true;            //  dest_result_addr=57881557
            label_0:
            // 0x00AAF744: LDRB w8, [x19, #0x10]      | 
            // 0x00AAF748: CBZ w8, #0xaaf78c          | if (0x1 == 0) goto label_1;             
            if(true == 0)
            {
                goto label_1;
            }
            // 0x00AAF74C: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AAF750: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AAF754: LDR x19, [x19, #0x20]      | X19 = this.m_AssetName; //P2            
            val_2 = this.m_AssetName;
            // 0x00AAF758: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AAF75C: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAF760: TBZ w8, #0, #0xaaf770      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_3;
            // 0x00AAF764: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAF768: CBNZ w8, #0xaaf770         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
            // 0x00AAF76C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_3:
            // 0x00AAF770: ADRP x8, #0x35e3000        | X8 = 56504320 (0x35E3000);              
            // 0x00AAF774: LDR x8, [x8, #0xef8]       | X8 = 1152921514947326768;               
            // 0x00AAF778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AAF77C: MOV x1, x19                | X1 = this.m_AssetName;//m1              
            // 0x00AAF780: LDR x2, [x8]               | X2 = public static UnityEngine.Object Mihua.Asset.AssetMgr::GetLoadedAsset<UnityEngine.Object>(string assetName);
            // 0x00AAF784: BL #0xfd8bec               | X0 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
            UnityEngine.Object val_1 = Mihua.Asset.AssetMgr.GetLoadedAsset<UnityEngine.Object>(assetName:  0);
            // 0x00AAF788: B #0xaaf790                |  goto label_4;                          
            goto label_4;
            label_1:
            // 0x00AAF78C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            val_3 = 0;
            label_4:
            // 0x00AAF790: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAF794: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AAF798: RET                        |  return (UnityEngine.Object)null;       
            return (UnityEngine.Object)val_3;
            //  |  // // {name=val_0, type=UnityEngine.Object, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAF79C (11204508), len: 244  VirtAddr: 0x00AAF79C RVA: 0x00AAF79C token: 100693185 methodIndex: 46905 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool Update()
        {
            //
            // Disasemble & Code
            //  | 
            var val_5;
            //  | 
            string val_6;
            // 0x00AAF79C: STP x22, x21, [sp, #-0x30]! | stack[1152921514949766112] = ???;  stack[1152921514949766120] = ???;  //  dest_result_addr=1152921514949766112 |  dest_result_addr=1152921514949766120
            // 0x00AAF7A0: STP x20, x19, [sp, #0x10]  | stack[1152921514949766128] = ???;  stack[1152921514949766136] = ???;  //  dest_result_addr=1152921514949766128 |  dest_result_addr=1152921514949766136
            // 0x00AAF7A4: STP x29, x30, [sp, #0x20]  | stack[1152921514949766144] = ???;  stack[1152921514949766152] = ???;  //  dest_result_addr=1152921514949766144 |  dest_result_addr=1152921514949766152
            // 0x00AAF7A8: ADD x29, sp, #0x20         | X29 = (1152921514949766112 + 32) = 1152921514949766144 (0x10000002687C6C00);
            // 0x00AAF7AC: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AAF7B0: LDRB w8, [x20, #0x3d6]     | W8 = (bool)static_value_037333D6;       
            // 0x00AAF7B4: MOV x19, x0                | X19 = 1152921514949778160 (0x10000002687C9AF0);//ML01
            // 0x00AAF7B8: TBNZ w8, #0, #0xaaf7d4     | if (static_value_037333D6 == true) goto label_0;
            // 0x00AAF7BC: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00AAF7C0: LDR x8, [x8, #0x218]       | X8 = 0x2B8EBB0;                         
            // 0x00AAF7C4: LDR w0, [x8]               | W0 = 0x11AC;                            
            // 0x00AAF7C8: BL #0x2782188              | X0 = sub_2782188( ?? 0x11AC, ????);     
            // 0x00AAF7CC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAF7D0: STRB w8, [x20, #0x3d6]     | static_value_037333D6 = true;            //  dest_result_addr=57881558
            label_0:
            // 0x00AAF7D4: LDR x8, [x19, #0x30]       | X8 = this.m_Request; //P2               
            // 0x00AAF7D8: CBZ x8, #0xaaf7e4          | if (this.m_Request == null) goto label_1;
            if(this.m_Request == null)
            {
                goto label_1;
            }
            // 0x00AAF7DC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AAF7E0: B #0xaaf880                |  goto label_9;                          
            goto label_9;
            label_1:
            // 0x00AAF7E4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AAF7E8: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AAF7EC: LDR x20, [x19, #0x18]      | X20 = this.m_AssetBundleName; //P2      
            // 0x00AAF7F0: ADD x21, x19, #0x28        | X21 = this.m_DownloadingError;//AP2 res_addr=1152921514949778200
            val_6 = this.m_DownloadingError;
            // 0x00AAF7F4: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AAF7F8: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAF7FC: TBZ w8, #0, #0xaaf80c      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00AAF800: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAF804: CBNZ w8, #0xaaf80c         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00AAF808: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_4:
            // 0x00AAF80C: MOV x1, x20                | X1 = this.m_AssetBundleName;//m1        
            string val_1 = this.m_AssetBundleName;
            // 0x00AAF810: MOV x2, x21                | X2 = this.m_DownloadingError;//m1       
            // 0x00AAF814: BL #0xaaf890               | X0 = Mihua.Asset.AssetMgr.GetLoadedAssetBundle(assetBundleName:  null, error: out  string val_1 = this.m_AssetBundleName);
            Mihua.Asset.LoadedAssetBundle val_2 = Mihua.Asset.AssetMgr.GetLoadedAssetBundle(assetBundleName:  null, error: out  val_1);
            // 0x00AAF818: MOV x20, x0                | X20 = val_2;//m1                        
            // 0x00AAF81C: CBZ x20, #0xaaf850         | if (val_2 == null) goto label_5;        
            if(val_2 == null)
            {
                goto label_5;
            }
            // 0x00AAF820: LDR x21, [x20, #0x10]      | X21 = val_2.m_AssetBundle; //P2         
            val_6 = val_2.m_AssetBundle;
            // 0x00AAF824: CBNZ x21, #0xaaf82c        | if (val_2.m_AssetBundle != null) goto label_6;
            if(val_6 != null)
            {
                goto label_6;
            }
            // 0x00AAF828: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00AAF82C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAF830: MOV x0, x21                | X0 = val_2.m_AssetBundle;//m1           
            // 0x00AAF834: BL #0x20ca24c              | X0 = val_2.m_AssetBundle.GetAllAssetNames();
            System.String[] val_3 = val_6.GetAllAssetNames();
            // 0x00AAF838: STR x0, [x19, #0x38]       | this.allAssetNames = val_3;              //  dest_result_addr=1152921514949778216
            this.allAssetNames = val_3;
            // 0x00AAF83C: LDR x8, [x20, #0x20]       | X8 = val_2.m_Request; //P2              
            // 0x00AAF840: CBZ x8, #0xaaf858          | if (val_2.m_Request == null) goto label_7;
            if(val_2.m_Request == null)
            {
                goto label_7;
            }
            // 0x00AAF844: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AAF848: STR x8, [x19, #0x30]       | this.m_Request = val_2.m_Request;        //  dest_result_addr=1152921514949778208
            this.m_Request = val_2.m_Request;
            // 0x00AAF84C: B #0xaaf880                |  goto label_9;                          
            goto label_9;
            label_5:
            // 0x00AAF850: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_5 = 1;
            // 0x00AAF854: B #0xaaf880                |  goto label_9;                          
            goto label_9;
            label_7:
            // 0x00AAF858: LDR x21, [x20, #0x10]      | X21 = val_2.m_AssetBundle; //P2         
            val_6 = val_2.m_AssetBundle;
            // 0x00AAF85C: CBNZ x21, #0xaaf864        | if (val_2.m_AssetBundle != null) goto label_10;
            if(val_6 != null)
            {
                goto label_10;
            }
            // 0x00AAF860: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_10:
            // 0x00AAF864: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAF868: MOV x0, x21                | X0 = val_2.m_AssetBundle;//m1           
            // 0x00AAF86C: BL #0x20ca0ac              | X0 = val_2.m_AssetBundle.LoadAllAssetsAsync();
            UnityEngine.AssetBundleRequest val_4 = val_6.LoadAllAssetsAsync();
            // 0x00AAF870: MOV x8, x0                 | X8 = val_4;//m1                         
            // 0x00AAF874: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_5 = 0;
            // 0x00AAF878: STR x8, [x19, #0x30]       | this.m_Request = val_4;                  //  dest_result_addr=1152921514949778208
            this.m_Request = val_4;
            // 0x00AAF87C: STR x8, [x20, #0x20]       | val_2.m_Request = val_4;                 //  dest_result_addr=0
            val_2.m_Request = val_4;
            label_9:
            // 0x00AAF880: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAF884: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AAF888: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00AAF88C: RET                        |  return (System.Boolean)false;          
            return (bool)val_5;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAFB10 (11205392), len: 164  VirtAddr: 0x00AAFB10 RVA: 0x00AAFB10 token: 100693186 methodIndex: 46906 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool IsDone()
        {
            //
            // Disasemble & Code
            //  | 
            string val_1;
            // 0x00AAFB10: STP x20, x19, [sp, #-0x20]! | stack[1152921514949951856] = ???;  stack[1152921514949951864] = ???;  //  dest_result_addr=1152921514949951856 |  dest_result_addr=1152921514949951864
            // 0x00AAFB14: STP x29, x30, [sp, #0x10]  | stack[1152921514949951872] = ???;  stack[1152921514949951880] = ???;  //  dest_result_addr=1152921514949951872 |  dest_result_addr=1152921514949951880
            // 0x00AAFB18: ADD x29, sp, #0x10         | X29 = (1152921514949951856 + 16) = 1152921514949951872 (0x10000002687F4180);
            // 0x00AAFB1C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AAFB20: LDRB w8, [x20, #0x3d7]     | W8 = (bool)static_value_037333D7;       
            // 0x00AAFB24: MOV x19, x0                | X19 = 1152921514949963888 (0x10000002687F7070);//ML01
            val_1 = this;
            // 0x00AAFB28: TBNZ w8, #0, #0xaafb44     | if (static_value_037333D7 == true) goto label_0;
            // 0x00AAFB2C: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00AAFB30: LDR x8, [x8, #0xbc0]       | X8 = 0x2B8EBAC;                         
            // 0x00AAFB34: LDR w0, [x8]               | W0 = 0x11AB;                            
            // 0x00AAFB38: BL #0x2782188              | X0 = sub_2782188( ?? 0x11AB, ????);     
            // 0x00AAFB3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAFB40: STRB w8, [x20, #0x3d7]     | static_value_037333D7 = true;            //  dest_result_addr=57881559
            label_0:
            // 0x00AAFB44: LDRB w8, [x19, #0x10]      | 
            // 0x00AAFB48: CBNZ w8, #0xaafb9c         | if (0x1 != 0) goto label_1;             
            if(true != 0)
            {
                goto label_1;
            }
            // 0x00AAFB4C: LDR x0, [x19, #0x30]       | X0 = this.m_Request; //P2               
            // 0x00AAFB50: CBZ x0, #0xaafb64          | if (this.m_Request == null) goto label_2;
            if(this.m_Request == null)
            {
                goto label_2;
            }
            // 0x00AAFB54: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFB58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFB5C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFB60: B #0x20ca724               | return this.m_Request.get_isDone();     
            return this.m_Request.isDone;
            label_2:
            // 0x00AAFB64: LDR x19, [x19, #0x28]      | X19 = this.m_DownloadingError; //P2     
            val_1 = this.m_DownloadingError;
            // 0x00AAFB68: CBZ x19, #0xaafbac         | if (this.m_DownloadingError == null) goto label_3;
            if(val_1 == null)
            {
                goto label_3;
            }
            // 0x00AAFB6C: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
            // 0x00AAFB70: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
            // 0x00AAFB74: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
            // 0x00AAFB78: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
            // 0x00AAFB7C: TBZ w8, #0, #0xaafb8c      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_5;
            // 0x00AAFB80: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFB84: CBNZ w8, #0xaafb8c         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_5;
            // 0x00AAFB88: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
            label_5:
            // 0x00AAFB8C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00AAFB90: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AAFB94: MOV x1, x19                | X1 = this.m_DownloadingError;//m1       
            // 0x00AAFB98: BL #0x1a5d504              | UnityEngine.Debug.LogError(message:  0);
            UnityEngine.Debug.LogError(message:  0);
            label_1:
            // 0x00AAFB9C: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            label_6:
            // 0x00AAFBA0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFBA4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFBA8: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            label_3:
            // 0x00AAFBAC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00AAFBB0: B #0xaafba0                |  goto label_6;                          
            goto label_6;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AAFBB4 (11205556), len: 488  VirtAddr: 0x00AAFBB4 RVA: 0x00AAFBB4 token: 100693187 methodIndex: 46907 delegateWrapperIndex: 0 methodInvoker: 0
        public override void CacheAsset()
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x00AAFBB4: STP x28, x27, [sp, #-0x60]! | stack[1152921514950215344] = ???;  stack[1152921514950215352] = ???;  //  dest_result_addr=1152921514950215344 |  dest_result_addr=1152921514950215352
            // 0x00AAFBB8: STP x26, x25, [sp, #0x10]  | stack[1152921514950215360] = ???;  stack[1152921514950215368] = ???;  //  dest_result_addr=1152921514950215360 |  dest_result_addr=1152921514950215368
            // 0x00AAFBBC: STP x24, x23, [sp, #0x20]  | stack[1152921514950215376] = ???;  stack[1152921514950215384] = ???;  //  dest_result_addr=1152921514950215376 |  dest_result_addr=1152921514950215384
            // 0x00AAFBC0: STP x22, x21, [sp, #0x30]  | stack[1152921514950215392] = ???;  stack[1152921514950215400] = ???;  //  dest_result_addr=1152921514950215392 |  dest_result_addr=1152921514950215400
            // 0x00AAFBC4: STP x20, x19, [sp, #0x40]  | stack[1152921514950215408] = ???;  stack[1152921514950215416] = ???;  //  dest_result_addr=1152921514950215408 |  dest_result_addr=1152921514950215416
            // 0x00AAFBC8: STP x29, x30, [sp, #0x50]  | stack[1152921514950215424] = ???;  stack[1152921514950215432] = ???;  //  dest_result_addr=1152921514950215424 |  dest_result_addr=1152921514950215432
            // 0x00AAFBCC: ADD x29, sp, #0x50         | X29 = (1152921514950215344 + 80) = 1152921514950215424 (0x1000000268834700);
            // 0x00AAFBD0: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AAFBD4: LDRB w8, [x20, #0x3d8]     | W8 = (bool)static_value_037333D8;       
            // 0x00AAFBD8: MOV x19, x0                | X19 = 1152921514950227440 (0x10000002688375F0);//ML01
            // 0x00AAFBDC: TBNZ w8, #0, #0xaafbf8     | if (static_value_037333D8 == true) goto label_0;
            // 0x00AAFBE0: ADRP x8, #0x35bf000        | X8 = 56356864 (0x35BF000);              
            // 0x00AAFBE4: LDR x8, [x8, #0xd00]       | X8 = 0x2B8EBA0;                         
            // 0x00AAFBE8: LDR w0, [x8]               | W0 = 0x11A8;                            
            // 0x00AAFBEC: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A8, ????);     
            // 0x00AAFBF0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAFBF4: STRB w8, [x20, #0x3d8]     | static_value_037333D8 = true;            //  dest_result_addr=57881560
            label_0:
            // 0x00AAFBF8: LDR x8, [x19, #0x28]       | X8 = this.m_DownloadingError; //P2      
            // 0x00AAFBFC: CBNZ x8, #0xaafd60         | if (this.m_DownloadingError != null) goto label_1;
            if(this.m_DownloadingError != null)
            {
                goto label_1;
            }
            // 0x00AAFC00: LDR x20, [x19, #0x30]      | X20 = this.m_Request; //P2              
            // 0x00AAFC04: CBNZ x20, #0xaafc0c        | if (this.m_Request != null) goto label_2;
            if(this.m_Request != null)
            {
                goto label_2;
            }
            // 0x00AAFC08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x11A8, ????);     
            label_2:
            // 0x00AAFC0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFC10: MOV x0, x20                | X0 = this.m_Request;//m1                
            // 0x00AAFC14: BL #0x20ca544              | X0 = this.m_Request.get_allAssets();    
            UnityEngine.Object[] val_1 = this.m_Request.allAssets;
            // 0x00AAFC18: ADRP x24, #0x35c8000       | X24 = 56393728 (0x35C8000);             
            // 0x00AAFC1C: LDR x24, [x24, #0x270]     | X24 = 1152921504903331840;              
            // 0x00AAFC20: MOV x20, x0                | X20 = val_1;//m1                        
            // 0x00AAFC24: LDR x8, [x24]              | X8 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AAFC28: LDRB w9, [x8, #0x10a]      | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFC2C: TBZ w9, #0, #0xaafc40      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_4;
            // 0x00AAFC30: LDR w9, [x8, #0xbc]        | W9 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFC34: CBNZ w9, #0xaafc40         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
            // 0x00AAFC38: MOV x0, x8                 | X0 = 1152921504903331840 (0x1000000011AC0000);//ML01
            // 0x00AAFC3C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_4:
            // 0x00AAFC40: BL #0xaafd9c               | X0 = Mihua.Asset.AssetMgr.get_cacheAssets();
            System.Collections.Generic.Dictionary<System.String, UnityEngine.Object> val_2 = Mihua.Asset.AssetMgr.cacheAssets;
            // 0x00AAFC44: ADRP x26, #0x3616000       | X26 = 56713216 (0x3616000);             
            // 0x00AAFC48: ADRP x27, #0x35e6000       | X27 = 56516608 (0x35E6000);             
            // 0x00AAFC4C: LDR x26, [x26, #0xad8]     | X26 = 1152921514948372656;              
            // 0x00AAFC50: LDR x27, [x27, #0xcb8]     | X27 = 1152921514948381872;              
            // 0x00AAFC54: MOV x21, x0                | X21 = val_2;//m1                        
            // 0x00AAFC58: MOV w25, wzr               | W25 = 0 (0x0);//ML01                    
            val_4 = 0;
            // 0x00AAFC5C: B #0xaafc64                |  goto label_5;                          
            goto label_5;
            label_17:
            // 0x00AAFC60: ADD w25, w25, #1           | W25 = (val_4 + 1) = val_4 (0x00000001); 
            val_4 = 1;
            label_5:
            // 0x00AAFC64: CBNZ x20, #0xaafc6c        | if (val_1 != null) goto label_6;        
            if(val_1 != null)
            {
                goto label_6;
            }
            // 0x00AAFC68: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_6:
            // 0x00AAFC6C: LDR w8, [x20, #0x18]       | W8 = val_1.Length; //P2                 
            // 0x00AAFC70: CMP w25, w8                | STATE = COMPARE(0x1, val_1.Length)      
            // 0x00AAFC74: B.GE #0xaafd3c             | if (val_4 >= val_1.Length) goto label_7;
            if(val_4 >= val_1.Length)
            {
                goto label_7;
            }
            // 0x00AAFC78: LDR x22, [x19, #0x38]      | X22 = this.allAssetNames; //P2          
            // 0x00AAFC7C: CBNZ x22, #0xaafc84        | if (this.allAssetNames != null) goto label_8;
            if(this.allAssetNames != null)
            {
                goto label_8;
            }
            // 0x00AAFC80: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_8:
            // 0x00AAFC84: LDR w8, [x22, #0x18]       | W8 = this.allAssetNames.Length; //P2    
            // 0x00AAFC88: SXTW x23, w25              | X23 = 1 (0x00000001);                   
            // 0x00AAFC8C: CMP w25, w8                | STATE = COMPARE(0x1, this.allAssetNames.Length)
            // 0x00AAFC90: B.LO #0xaafca0             | if (val_4 < this.allAssetNames.Length) goto label_9;
            if(val_4 < this.allAssetNames.Length)
            {
                goto label_9;
            }
            // 0x00AAFC94: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_2, ????);      
            // 0x00AAFC98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFC9C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_2, ????);      
            label_9:
            // 0x00AAFCA0: ADD x8, x22, x23, lsl #3   | X8 = this.allAssetNames[0x1]; //PARR1   
            // 0x00AAFCA4: LDR x22, [x8, #0x20]       | X22 = this.allAssetNames[0x1][0]        
            string val_4 = this.allAssetNames[1];
            // 0x00AAFCA8: CBNZ x21, #0xaafcb0        | if (val_2 != null) goto label_10;       
            if(val_2 != null)
            {
                goto label_10;
            }
            // 0x00AAFCAC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
            label_10:
            // 0x00AAFCB0: LDR x2, [x26]              | X2 = public System.Boolean System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::ContainsKey(System.String key);
            // 0x00AAFCB4: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00AAFCB8: MOV x1, x22                | X1 = this.allAssetNames[0x1][0];//m1    
            // 0x00AAFCBC: BL #0x23fd9f0              | X0 = val_2.ContainsKey(key:  this.allAssetNames[1]);
            bool val_3 = val_2.ContainsKey(key:  val_4);
            // 0x00AAFCC0: AND w8, w0, #1             | W8 = (val_3 & 1);                       
            this.allAssetNames[1] = val_3;
            // 0x00AAFCC4: TBNZ w8, #0, #0xaafc60     | if ((val_3 & 1) == true) goto label_17; 
            if(this.allAssetNames[1] == true)
            {
                goto label_17;
            }
            // 0x00AAFCC8: LDR x22, [x19, #0x38]      | X22 = this.allAssetNames; //P2          
            // 0x00AAFCCC: CBNZ x22, #0xaafcd4        | if (this.allAssetNames != null) goto label_12;
            if(this.allAssetNames != null)
            {
                goto label_12;
            }
            // 0x00AAFCD0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_12:
            // 0x00AAFCD4: LDR w8, [x22, #0x18]       | W8 = this.allAssetNames.Length; //P2    
            // 0x00AAFCD8: CMP w25, w8                | STATE = COMPARE(0x1, this.allAssetNames.Length)
            // 0x00AAFCDC: B.LO #0xaafcec             | if (val_4 < this.allAssetNames.Length) goto label_13;
            if(val_4 < this.allAssetNames.Length)
            {
                goto label_13;
            }
            // 0x00AAFCE0: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00AAFCE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFCE8: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_13:
            // 0x00AAFCEC: ADD x8, x22, x23, lsl #3   | X8 = this.allAssetNames[0x1]; //PARR1   
            // 0x00AAFCF0: LDR x22, [x8, #0x20]       | X22 = this.allAssetNames[0x1][0]        
            string val_5 = this.allAssetNames[1];
            // 0x00AAFCF4: CBNZ x20, #0xaafcfc        | if (val_1 != null) goto label_14;       
            if(val_1 != null)
            {
                goto label_14;
            }
            // 0x00AAFCF8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_14:
            // 0x00AAFCFC: LDR w8, [x20, #0x18]       | W8 = val_1.Length; //P2                 
            // 0x00AAFD00: CMP w25, w8                | STATE = COMPARE(0x1, val_1.Length)      
            // 0x00AAFD04: B.LO #0xaafd14             | if (val_4 < val_1.Length) goto label_15;
            if(val_4 < val_1.Length)
            {
                goto label_15;
            }
            // 0x00AAFD08: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_3, ????);      
            // 0x00AAFD0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AAFD10: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_3, ????);      
            label_15:
            // 0x00AAFD14: ADD x8, x20, x23, lsl #3   | X8 = val_1[0x1]; //PARR1                
            // 0x00AAFD18: LDR x23, [x8, #0x20]       | X23 = val_1[0x1][0]                     
            UnityEngine.Object val_6 = val_1[1];
            // 0x00AAFD1C: CBNZ x21, #0xaafd24        | if (val_2 != null) goto label_16;       
            if(val_2 != null)
            {
                goto label_16;
            }
            // 0x00AAFD20: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
            label_16:
            // 0x00AAFD24: LDR x3, [x27]              | X3 = public System.Void System.Collections.Generic.Dictionary<System.String, UnityEngine.Object>::Add(System.String key, UnityEngine.Object value);
            // 0x00AAFD28: MOV x0, x21                | X0 = val_2;//m1                         
            // 0x00AAFD2C: MOV x1, x22                | X1 = this.allAssetNames[0x1][0];//m1    
            // 0x00AAFD30: MOV x2, x23                | X2 = val_1[0x1][0];//m1                 
            // 0x00AAFD34: BL #0x23fd44c              | val_2.Add(key:  this.allAssetNames[1], value:  val_1[1]);
            val_2.Add(key:  val_5, value:  val_6);
            // 0x00AAFD38: B #0xaafc60                |  goto label_17;                         
            goto label_17;
            label_7:
            // 0x00AAFD3C: LDR x0, [x24]              | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AAFD40: LDR x20, [x19, #0x18]      | X20 = this.m_AssetBundleName; //P2      
            // 0x00AAFD44: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AAFD48: TBZ w8, #0, #0xaafd58      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_19;
            // 0x00AAFD4C: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AAFD50: CBNZ w8, #0xaafd58         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_19;
            // 0x00AAFD54: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_19:
            // 0x00AAFD58: MOV x1, x20                | X1 = this.m_AssetBundleName;//m1        
            // 0x00AAFD5C: BL #0xaafe04               | Mihua.Asset.AssetMgr.UnloadAssetBundle(assetBundleName:  null);
            Mihua.Asset.AssetMgr.UnloadAssetBundle(assetBundleName:  null);
            label_1:
            // 0x00AAFD60: LDR x0, [x19, #0x40]       | X0 = this.m_OnLoadAsset; //P2           
            // 0x00AAFD64: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AAFD68: STRB w8, [x19, #0x10]      | mem[1152921514950227456] = 0x1;          //  dest_result_addr=1152921514950227456
            mem[1152921514950227456] = 1;
            // 0x00AAFD6C: CBZ x0, #0xaafd80          | if (this.m_OnLoadAsset == null) goto label_20;
            if(this.m_OnLoadAsset == null)
            {
                goto label_20;
            }
            // 0x00AAFD70: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00AAFD74: MOV x1, x19                | X1 = 1152921514950227440 (0x10000002688375F0);//ML01
            // 0x00AAFD78: BL #0xaafed4               | this.m_OnLoadAsset.Invoke(assetOperation:  this);
            this.m_OnLoadAsset.Invoke(assetOperation:  this);
            // 0x00AAFD7C: STR xzr, [x19, #0x40]      | this.m_OnLoadAsset = null;               //  dest_result_addr=1152921514950227504
            this.m_OnLoadAsset = 0;
            label_20:
            // 0x00AAFD80: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00AAFD84: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00AAFD88: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00AAFD8C: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00AAFD90: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00AAFD94: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00AAFD98: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB026C (11207276), len: 192  VirtAddr: 0x00AB026C RVA: 0x00AB026C token: 100693188 methodIndex: 46908 delegateWrapperIndex: 0 methodInvoker: 0
        public override float get_progress()
        {
            //
            // Disasemble & Code
            //  | 
            string val_4;
            //  | 
            float val_5;
            //  | 
            var val_6;
            // 0x00AB026C: STP d9, d8, [sp, #-0x30]!  | stack[1152921514950478944] = ???;  stack[1152921514950478952] = ???;  //  dest_result_addr=1152921514950478944 |  dest_result_addr=1152921514950478952
            // 0x00AB0270: STP x20, x19, [sp, #0x10]  | stack[1152921514950478960] = ???;  stack[1152921514950478968] = ???;  //  dest_result_addr=1152921514950478960 |  dest_result_addr=1152921514950478968
            // 0x00AB0274: STP x29, x30, [sp, #0x20]  | stack[1152921514950478976] = ???;  stack[1152921514950478984] = ???;  //  dest_result_addr=1152921514950478976 |  dest_result_addr=1152921514950478984
            // 0x00AB0278: ADD x29, sp, #0x20         | X29 = (1152921514950478944 + 32) = 1152921514950478976 (0x1000000268874C80);
            // 0x00AB027C: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00AB0280: LDRB w8, [x20, #0x3d9]     | W8 = (bool)static_value_037333D9;       
            // 0x00AB0284: MOV x19, x0                | X19 = 1152921514950490992 (0x1000000268877B70);//ML01
            val_4 = this;
            // 0x00AB0288: TBNZ w8, #0, #0xab02a4     | if (static_value_037333D9 == true) goto label_0;
            // 0x00AB028C: ADRP x8, #0x35f2000        | X8 = 56565760 (0x35F2000);              
            // 0x00AB0290: LDR x8, [x8, #0x700]       | X8 = 0x2B8EBA4;                         
            // 0x00AB0294: LDR w0, [x8]               | W0 = 0x11A9;                            
            // 0x00AB0298: BL #0x2782188              | X0 = sub_2782188( ?? 0x11A9, ????);     
            // 0x00AB029C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00AB02A0: STRB w8, [x20, #0x3d9]     | static_value_037333D9 = true;            //  dest_result_addr=57881561
            label_0:
            // 0x00AB02A4: LDRB w8, [x19, #0x10]      | 
            // 0x00AB02A8: FMOV s8, #1.00000000       | S8 = 1;                                 
            val_5 = 1f;
            // 0x00AB02AC: CBNZ w8, #0xab0318         | if (0x1 != 0) goto label_2;             
            if(true != 0)
            {
                goto label_2;
            }
            // 0x00AB02B0: LDR x8, [x19]              | X8 = typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull);
            // 0x00AB02B4: MOV x0, x19                | X0 = 1152921514950490992 (0x1000000268877B70);//ML01
            // 0x00AB02B8: LDP x9, x1, [x8, #0x1b0]   | X9 = typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_1B0; X1 = typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_1B8; //  | 
            // 0x00AB02BC: BLR x9                     | X0 = typeof(Mihua.Asset.ABLoadOperation.AssetOperationFull).__il2cppRuntimeField_1B0();
            // 0x00AB02C0: AND w8, w0, #1             | W8 = (this & 1) = 0 (0x00000000);       
            // 0x00AB02C4: TBNZ w8, #0, #0xab0318     | if (((Mihua.Asset.ABLoadOperation.AssetOperationFull)[1152921514950490992] & 0x1) != 0) goto label_2;
            if((0 & 1) != 0)
            {
                goto label_2;
            }
            // 0x00AB02C8: LDR x0, [x19, #0x30]       | X0 = this.m_Request; //P2               
            // 0x00AB02CC: CBZ x0, #0xab02e4          | if (this.m_Request == null) goto label_3;
            if(this.m_Request == null)
            {
                goto label_3;
            }
            // 0x00AB02D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00AB02D4: BL #0x20ca78c              | X0 = this.m_Request.get_progress();     
            float val_1 = this.m_Request.progress;
            // 0x00AB02D8: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x00AB02DC: FADD s0, s0, s1            | S0 = (val_1 + 1f);                      
            val_1 = val_1 + 1f;
            // 0x00AB02E0: B #0xab0310                |  goto label_4;                          
            goto label_4;
            label_3:
            // 0x00AB02E4: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00AB02E8: LDR x8, [x8, #0x270]       | X8 = 1152921504903331840;               
            // 0x00AB02EC: LDR x19, [x19, #0x18]      | X19 = this.m_AssetBundleName; //P2      
            val_4 = this.m_AssetBundleName;
            // 0x00AB02F0: LDR x0, [x8]               | X0 = typeof(Mihua.Asset.AssetMgr);      
            // 0x00AB02F4: LDRB w8, [x0, #0x10a]      | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_10A;
            // 0x00AB02F8: TBZ w8, #0, #0xab0308      | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_has_cctor == 0) goto label_6;
            // 0x00AB02FC: LDR w8, [x0, #0xbc]        | W8 = Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished;
            // 0x00AB0300: CBNZ w8, #0xab0308         | if (Mihua.Asset.AssetMgr.__il2cppRuntimeField_cctor_finished != 0) goto label_6;
            // 0x00AB0304: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(Mihua.Asset.AssetMgr), ????);
            label_6:
            // 0x00AB0308: MOV x1, x19                | X1 = this.m_AssetBundleName;//m1        
            // 0x00AB030C: BL #0xab032c               | X0 = Mihua.Asset.AssetMgr.GetProgress(assetBundleName:  null);
            float val_2 = Mihua.Asset.AssetMgr.GetProgress(assetBundleName:  null);
            label_4:
            // 0x00AB0310: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x00AB0314: FMUL s8, s0, s1            | S8 = (val_2 * 0.5f);                    
            val_5 = val_2 * 0.5f;
            label_2:
            // 0x00AB0318: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00AB031C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00AB0320: MOV v0.16b, v8.16b         | V0 = (val_2 * 0.5f);//m1                
            // 0x00AB0324: LDP d9, d8, [sp], #0x30    | D9 = ; D8 = ;                            //  | 
            // 0x00AB0328: RET                        |  return (System.Single)(val_2 * 0.5f);  
            return (float)val_5;
            //  |  // // {name=val_0, type=System.Single, size=4, nSRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB04C4 (11207876), len: 8  VirtAddr: 0x00AB04C4 RVA: 0x00AB04C4 token: 100693189 methodIndex: 46909 delegateWrapperIndex: 0 methodInvoker: 0
        public override void ClearOnLoad()
        {
            //
            // Disasemble & Code
            // 0x00AB04C4: STR xzr, [x0, #0x40]       | this.m_OnLoadAsset = null;               //  dest_result_addr=1152921514950611248
            this.m_OnLoadAsset = 0;
            // 0x00AB04C8: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00AB04CC (11207884), len: 8  VirtAddr: 0x00AB04CC RVA: 0x00AB04CC token: 100693190 methodIndex: 46910 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Clear()
        {
            //
            // Disasemble & Code
            // 0x00AB04CC: STR xzr, [x0, #0x30]       | this.m_Request = null;                   //  dest_result_addr=1152921514950723232
            this.m_Request = 0;
            // 0x00AB04D0: RET                        |  return;                                
            return;
        
        }
    
    }

}
