using UnityEngine;

namespace Newtonsoft.Json.Bson
{
    internal class BsonArray : BsonToken, IEnumerable<Newtonsoft.Json.Bson.BsonToken>, IEnumerable
    {
        // Fields
        private readonly System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonToken> _children; //  0x00000020
        
        // Properties
        public override Newtonsoft.Json.Bson.BsonType Type { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00ACF774 (11335540), len: 112  VirtAddr: 0x00ACF774 RVA: 0x00ACF774 token: 100684771 methodIndex: 47354 delegateWrapperIndex: 0 methodInvoker: 0
        public BsonArray()
        {
            //
            // Disasemble & Code
            // 0x00ACF774: STP x20, x19, [sp, #-0x20]! | stack[1152921513723037104] = ???;  stack[1152921513723037112] = ???;  //  dest_result_addr=1152921513723037104 |  dest_result_addr=1152921513723037112
            // 0x00ACF778: STP x29, x30, [sp, #0x10]  | stack[1152921513723037120] = ???;  stack[1152921513723037128] = ???;  //  dest_result_addr=1152921513723037120 |  dest_result_addr=1152921513723037128
            // 0x00ACF77C: ADD x29, sp, #0x10         | X29 = (1152921513723037104 + 16) = 1152921513723037120 (0x100000021F5E05C0);
            // 0x00ACF780: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00ACF784: LDRB w8, [x20, #0x4c3]     | W8 = (bool)static_value_037334C3;       
            // 0x00ACF788: MOV x19, x0                | X19 = 1152921513723049136 (0x100000021F5E34B0);//ML01
            // 0x00ACF78C: TBNZ w8, #0, #0xacf7a8     | if (static_value_037334C3 == true) goto label_0;
            // 0x00ACF790: ADRP x8, #0x364a000        | X8 = 56926208 (0x364A000);              
            // 0x00ACF794: LDR x8, [x8, #0x9e8]       | X8 = 0x2B8F958;                         
            // 0x00ACF798: LDR w0, [x8]               | W0 = 0x151A;                            
            // 0x00ACF79C: BL #0x2782188              | X0 = sub_2782188( ?? 0x151A, ????);     
            // 0x00ACF7A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00ACF7A4: STRB w8, [x20, #0x4c3]     | static_value_037334C3 = true;            //  dest_result_addr=57881795
            label_0:
            // 0x00ACF7A8: ADRP x8, #0x362b000        | X8 = 56799232 (0x362B000);              
            // 0x00ACF7AC: LDR x8, [x8, #0xab0]       | X8 = 1152921504616644608;               
            // 0x00ACF7B0: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonToken> val_1 = null;
            // 0x00ACF7B4: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00ACF7B8: ADRP x8, #0x362c000        | X8 = 56803328 (0x362C000);              
            // 0x00ACF7BC: LDR x8, [x8, #0xf18]       | X8 = 1152921513723024112;               
            // 0x00ACF7C0: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00ACF7C4: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonToken>::.ctor();
            // 0x00ACF7C8: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonToken>();
            // 0x00ACF7CC: STR x20, [x19, #0x20]      | this._children = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513723049168
            this._children = val_1;
            // 0x00ACF7D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACF7D4: MOV x0, x19                | X0 = 1152921513723049136 (0x100000021F5E34B0);//ML01
            object val_2 = this;
            // 0x00ACF7D8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00ACF7DC: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00ACF7E0: B #0x16f59f0               | this..ctor(); return;                   
            val_2 = new System.Object();
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF7EC (11335660), len: 124  VirtAddr: 0x00ACF7EC RVA: 0x00ACF7EC token: 100684772 methodIndex: 47355 delegateWrapperIndex: 0 methodInvoker: 0
        public void Add(Newtonsoft.Json.Bson.BsonToken token)
        {
            //
            // Disasemble & Code
            // 0x00ACF7EC: STP x22, x21, [sp, #-0x30]! | stack[1152921513723158304] = ???;  stack[1152921513723158312] = ???;  //  dest_result_addr=1152921513723158304 |  dest_result_addr=1152921513723158312
            // 0x00ACF7F0: STP x20, x19, [sp, #0x10]  | stack[1152921513723158320] = ???;  stack[1152921513723158328] = ???;  //  dest_result_addr=1152921513723158320 |  dest_result_addr=1152921513723158328
            // 0x00ACF7F4: STP x29, x30, [sp, #0x20]  | stack[1152921513723158336] = ???;  stack[1152921513723158344] = ???;  //  dest_result_addr=1152921513723158336 |  dest_result_addr=1152921513723158344
            // 0x00ACF7F8: ADD x29, sp, #0x20         | X29 = (1152921513723158304 + 32) = 1152921513723158336 (0x100000021F5FDF40);
            // 0x00ACF7FC: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
            // 0x00ACF800: LDRB w8, [x21, #0x4c4]     | W8 = (bool)static_value_037334C4;       
            // 0x00ACF804: MOV x19, x1                | X19 = token;//m1                        
            // 0x00ACF808: MOV x20, x0                | X20 = 1152921513723170352 (0x100000021F600E30);//ML01
            // 0x00ACF80C: TBNZ w8, #0, #0xacf828     | if (static_value_037334C4 == true) goto label_0;
            // 0x00ACF810: ADRP x8, #0x3630000        | X8 = 56819712 (0x3630000);              
            // 0x00ACF814: LDR x8, [x8, #0x28]        | X8 = 0x2B8F95C;                         
            // 0x00ACF818: LDR w0, [x8]               | W0 = 0x151B;                            
            // 0x00ACF81C: BL #0x2782188              | X0 = sub_2782188( ?? 0x151B, ????);     
            // 0x00ACF820: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00ACF824: STRB w8, [x21, #0x4c4]     | static_value_037334C4 = true;            //  dest_result_addr=57881796
            label_0:
            // 0x00ACF828: LDR x21, [x20, #0x20]      | X21 = this._children; //P2              
            // 0x00ACF82C: CBNZ x21, #0xacf834        | if (this._children != null) goto label_1;
            if(this._children != null)
            {
                goto label_1;
            }
            // 0x00ACF830: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x151B, ????);     
            label_1:
            // 0x00ACF834: ADRP x8, #0x361e000        | X8 = 56745984 (0x361E000);              
            // 0x00ACF838: LDR x8, [x8, #0x790]       | X8 = 1152921513723145328;               
            // 0x00ACF83C: MOV x0, x21                | X0 = this._children;//m1                
            // 0x00ACF840: MOV x1, x19                | X1 = token;//m1                         
            // 0x00ACF844: LDR x2, [x8]               | X2 = public System.Void System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonToken>::Add(Newtonsoft.Json.Bson.BsonToken item);
            // 0x00ACF848: BL #0x25ea480              | this._children.Add(item:  token);       
            this._children.Add(item:  token);
            // 0x00ACF84C: CBNZ x19, #0xacf854        | if (token != null) goto label_2;        
            if(token != null)
            {
                goto label_2;
            }
            // 0x00ACF850: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this._children, ????);
            label_2:
            // 0x00ACF854: STR x20, [x19, #0x10]      | token.<Parent>k__BackingField = this;    //  dest_result_addr=0
            token.<Parent>k__BackingField = this;
            // 0x00ACF858: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACF85C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00ACF860: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00ACF864: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF870 (11335792), len: 8  VirtAddr: 0x00ACF870 RVA: 0x00ACF870 token: 100684773 methodIndex: 47356 delegateWrapperIndex: 0 methodInvoker: 0
        public override Newtonsoft.Json.Bson.BsonType get_Type()
        {
            //
            // Disasemble & Code
            // 0x00ACF870: ORR w0, wzr, #4            | W0 = 4(0x4);                            
            // 0x00ACF874: RET                        |  return (Newtonsoft.Json.Bson.BsonType)0x4;
            return (Newtonsoft.Json.Bson.BsonType)4;
            //  |  // // {name=val_0, type=Newtonsoft.Json.Bson.BsonType, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF878 (11335800), len: 144  VirtAddr: 0x00ACF878 RVA: 0x00ACF878 token: 100684774 methodIndex: 47357 delegateWrapperIndex: 0 methodInvoker: 0
        public System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken> GetEnumerator()
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            // 0x00ACF878: STP x20, x19, [sp, #-0x20]! | stack[1152921513723399728] = ???;  stack[1152921513723399736] = ???;  //  dest_result_addr=1152921513723399728 |  dest_result_addr=1152921513723399736
            // 0x00ACF87C: STP x29, x30, [sp, #0x10]  | stack[1152921513723399744] = ???;  stack[1152921513723399752] = ???;  //  dest_result_addr=1152921513723399744 |  dest_result_addr=1152921513723399752
            // 0x00ACF880: ADD x29, sp, #0x10         | X29 = (1152921513723399728 + 16) = 1152921513723399744 (0x100000021F638E40);
            // 0x00ACF884: SUB sp, sp, #0x30          | SP = (1152921513723399728 - 48) = 1152921513723399680 (0x100000021F638E00);
            // 0x00ACF888: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
            // 0x00ACF88C: LDRB w8, [x20, #0x4c5]     | W8 = (bool)static_value_037334C5;       
            // 0x00ACF890: MOV x19, x0                | X19 = 1152921513723411760 (0x100000021F63BD30);//ML01
            // 0x00ACF894: TBNZ w8, #0, #0xacf8b0     | if (static_value_037334C5 == true) goto label_0;
            // 0x00ACF898: ADRP x8, #0x366c000        | X8 = 57065472 (0x366C000);              
            // 0x00ACF89C: LDR x8, [x8, #0xc20]       | X8 = 0x2B8F960;                         
            // 0x00ACF8A0: LDR w0, [x8]               | W0 = 0x151C;                            
            // 0x00ACF8A4: BL #0x2782188              | X0 = sub_2782188( ?? 0x151C, ????);     
            // 0x00ACF8A8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00ACF8AC: STRB w8, [x20, #0x4c5]     | static_value_037334C5 = true;            //  dest_result_addr=57881797
            label_0:
            // 0x00ACF8B0: LDR x19, [x19, #0x20]      | X19 = this._children; //P2              
            // 0x00ACF8B4: CBNZ x19, #0xacf8bc        | if (this._children != null) goto label_1;
            if(this._children != null)
            {
                goto label_1;
            }
            // 0x00ACF8B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x151C, ????);     
            label_1:
            // 0x00ACF8BC: ADRP x8, #0x3609000        | X8 = 56659968 (0x3609000);              
            // 0x00ACF8C0: LDR x8, [x8, #0xff8]       | X8 = 1152921513723382640;               
            // 0x00ACF8C4: MOV x0, x19                | X0 = this._children;//m1                
            // 0x00ACF8C8: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<Newtonsoft.Json.Bson.BsonToken>::GetEnumerator();
            // 0x00ACF8CC: ADD x8, sp, #0x18          | X8 = (1152921513723399680 + 24) = 1152921513723399704 (0x100000021F638E18);
            // 0x00ACF8D0: BL #0x25ebf2c              | X0 = this._children.GetEnumerator();    
            List.Enumerator<T> val_1 = this._children.GetEnumerator();
            // 0x00ACF8D4: ADRP x9, #0x361a000        | X9 = 56729600 (0x361A000);              
            // 0x00ACF8D8: LDR x8, [sp, #0x28]        | X8 = val_2;                              //  find_add[1152921513723387760]
            // 0x00ACF8DC: LDUR q0, [sp, #0x18]       | Q0 = val_3;                              //  find_add[1152921513723387760]
            // 0x00ACF8E0: LDR x9, [x9, #0xc48]       | X9 = 1152921504616697856;               
            // 0x00ACF8E4: MOV x1, sp                 | X1 = 1152921513723399680 (0x100000021F638E00);//ML01
            // 0x00ACF8E8: STR x8, [sp, #0x10]        | stack[1152921513723399696] = val_2;      //  dest_result_addr=1152921513723399696
            // 0x00ACF8EC: LDR x0, [x9]               | X0 = typeof(List.Enumerator<T>);        
            // 0x00ACF8F0: STR q0, [sp]               | stack[1152921513723399680] = val_3;      //  dest_result_addr=1152921513723399680
            // 0x00ACF8F4: BL #0x27bc028              | X0 = 1152921513723447856 = (Il2CppObject*)Box((RuntimeClass*)typeof(List.Enumerator<T>), val_3);
            // 0x00ACF8F8: SUB sp, x29, #0x10         | SP = (1152921513723399744 - 16) = 1152921513723399728 (0x100000021F638E30);
            // 0x00ACF8FC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00ACF900: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00ACF904: RET                        |  return (System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>)val_3;
            return (System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>)val_3;
            //  |  // // {name=val_0, type=System.Collections.Generic.IEnumerator<Newtonsoft.Json.Bson.BsonToken>, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00ACF908 (11335944), len: 4  VirtAddr: 0x00ACF908 RVA: 0x00ACF908 token: 100684775 methodIndex: 47358 delegateWrapperIndex: 0 methodInvoker: 0
        private System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            //
            // Disasemble & Code
            // 0x00ACF908: B #0xacf878                | return this.GetEnumerator();            
            return this.GetEnumerator();
        
        }
    
    }

}
