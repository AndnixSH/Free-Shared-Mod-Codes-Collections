using UnityEngine;
public class BAMCameras
{
    // Fields
    public UnityEngine.Camera camera; //  0x00000010
    public bool initEnable; //  0x00000018
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8CB34 (12110644), len: 72  VirtAddr: 0x00B8CB34 RVA: 0x00B8CB34 token: 100690199 methodIndex: 25075 delegateWrapperIndex: 0 methodInvoker: 0
    public BAMCameras(UnityEngine.Camera camera)
    {
        //
        // Disasemble & Code
        // 0x00B8CB34: STP x20, x19, [sp, #-0x20]! | stack[1152921514485910416] = ???;  stack[1152921514485910424] = ???;  //  dest_result_addr=1152921514485910416 |  dest_result_addr=1152921514485910424
        // 0x00B8CB38: STP x29, x30, [sp, #0x10]  | stack[1152921514485910432] = ???;  stack[1152921514485910440] = ???;  //  dest_result_addr=1152921514485910432 |  dest_result_addr=1152921514485910440
        // 0x00B8CB3C: ADD x29, sp, #0x10         | X29 = (1152921514485910416 + 16) = 1152921514485910432 (0x100000024CD68BA0);
        // 0x00B8CB40: MOV x20, x1                | X20 = camera;//m1                       
        // 0x00B8CB44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CB48: MOV x19, x0                | X19 = 1152921514485922448 (0x100000024CD6BA90);//ML01
        // 0x00B8CB4C: BL #0x16f59f0              | this..ctor();                           
        // 0x00B8CB50: STR x20, [x19, #0x10]      | this.camera = camera;                    //  dest_result_addr=1152921514485922464
        this.camera = camera;
        // 0x00B8CB54: CBNZ x20, #0xb8cb5c        | if (camera != null) goto label_0;       
        if(camera != null)
        {
            goto label_0;
        }
        // 0x00B8CB58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
        label_0:
        // 0x00B8CB5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8CB60: MOV x0, x20                | X0 = camera;//m1                        
        // 0x00B8CB64: BL #0x20cb3f0              | X0 = camera.get_enabled();              
        bool val_1 = camera.enabled;
        // 0x00B8CB68: AND w8, w0, #1             | W8 = (val_1 & 1);                       
        bool val_2 = val_1;
        // 0x00B8CB6C: STRB w8, [x19, #0x18]      | this.initEnable = (val_1 & 1);           //  dest_result_addr=1152921514485922472
        this.initEnable = val_2;
        // 0x00B8CB70: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8CB74: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8CB78: RET                        |  return;                                
        return;
    
    }

}
