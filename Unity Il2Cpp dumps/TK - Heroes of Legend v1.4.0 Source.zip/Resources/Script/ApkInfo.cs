using UnityEngine;

namespace Iteedee.ApkReader
{
    public class ApkInfo
    {
        // Fields
        public static int FINE; // static_offset: 0x00000000
        public static int NULL_VERSION_CODE; // static_offset: 0x00000004
        public static int NULL_VERSION_NAME; // static_offset: 0x00000008
        public static int NULL_PERMISSION; // static_offset: 0x0000000C
        public static int NULL_ICON; // static_offset: 0x00000010
        public static int NULL_CERT_FILE; // static_offset: 0x00000014
        public static int BAD_CERT; // static_offset: 0x00000018
        public static int NULL_SF_FILE; // static_offset: 0x0000001C
        public static int BAD_SF; // static_offset: 0x00000020
        public static int NULL_MANIFEST; // static_offset: 0x00000024
        public static int NULL_RESOURCES; // static_offset: 0x00000028
        public static int NULL_DEX; // static_offset: 0x0000002C
        public static int NULL_METAINFO; // static_offset: 0x00000030
        public static int BAD_JAR; // static_offset: 0x00000034
        public static int BAD_READ_INFO; // static_offset: 0x00000038
        public static int NULL_FILE; // static_offset: 0x0000003C
        public static int HAS_REF; // static_offset: 0x00000040
        public string label; //  0x00000010
        public string versionName; //  0x00000018
        public string versionCode; //  0x00000020
        public string minSdkVersion; //  0x00000028
        public string targetSdkVersion; //  0x00000030
        public string packageName; //  0x00000038
        public string debuggable; //  0x00000040
        public System.Collections.Generic.List<string> Permissions; //  0x00000048
        public System.Collections.Generic.List<string> iconFileName; //  0x00000050
        public System.Collections.Generic.List<string> iconFileNameToGet; //  0x00000058
        public System.Collections.Generic.List<string> iconHash; //  0x00000060
        public string resourcesFileName; //  0x00000068
        public byte[] resourcesFileBytes; //  0x00000070
        public bool hasIcon; //  0x00000078
        public bool supportSmallScreens; //  0x00000079
        public bool supportNormalScreens; //  0x0000007A
        public bool supportLargeScreens; //  0x0000007B
        public bool supportAnyDensity; //  0x0000007C
        public System.Collections.Generic.Dictionary<string, System.Collections.Generic.List<string>> resStrings; //  0x00000080
        public System.Collections.Generic.Dictionary<string, string> layoutStrings; //  0x00000088
        
        // Properties
        public bool IsDebuggable { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x017B7FA8 (24870824), len: 136  VirtAddr: 0x017B7FA8 RVA: 0x017B7FA8 token: 100684400 methodIndex: 45970 delegateWrapperIndex: 0 methodInvoker: 0
        public ApkInfo()
        {
            //
            // Disasemble & Code
            // 0x017B7FA8: STP x20, x19, [sp, #-0x20]! | stack[1152921513629517424] = ???;  stack[1152921513629517432] = ???;  //  dest_result_addr=1152921513629517424 |  dest_result_addr=1152921513629517432
            // 0x017B7FAC: STP x29, x30, [sp, #0x10]  | stack[1152921513629517440] = ???;  stack[1152921513629517448] = ???;  //  dest_result_addr=1152921513629517440 |  dest_result_addr=1152921513629517448
            // 0x017B7FB0: ADD x29, sp, #0x10         | X29 = (1152921513629517424 + 16) = 1152921513629517440 (0x1000000219CB0680);
            // 0x017B7FB4: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017B7FB8: LDRB w8, [x20, #0x949]     | W8 = (bool)static_value_03738949;       
            // 0x017B7FBC: MOV x19, x0                | X19 = 1152921513629529456 (0x1000000219CB3570);//ML01
            // 0x017B7FC0: TBNZ w8, #0, #0x17b7fdc    | if (static_value_03738949 == true) goto label_0;
            // 0x017B7FC4: ADRP x8, #0x363a000        | X8 = 56860672 (0x363A000);              
            // 0x017B7FC8: LDR x8, [x8, #0xe00]       | X8 = 0x2B8AFEC;                         
            // 0x017B7FCC: LDR w0, [x8]               | W0 = 0x2B9;                             
            // 0x017B7FD0: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B9, ????);      
            // 0x017B7FD4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B7FD8: STRB w8, [x20, #0x949]     | static_value_03738949 = true;            //  dest_result_addr=57903433
            label_0:
            // 0x017B7FDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B7FE0: MOV x0, x19                | X0 = 1152921513629529456 (0x1000000219CB3570);//ML01
            // 0x017B7FE4: BL #0x16f59f0              | this..ctor();                           
            // 0x017B7FE8: STR wzr, [x19, #0x78]      | this.hasIcon = false; this.supportSmallScreens = false; this.supportNormalScreens = false; this.supportLargeScreens = false;  //  dest_result_addr=1152921513629529576 dest_result_addr=1152921513629529577 dest_result_addr=1152921513629529578 dest_result_addr=1152921513629529579
            this.hasIcon = false;
            this.supportSmallScreens = false;
            this.supportNormalScreens = false;
            this.supportLargeScreens = false;
            // 0x017B7FEC: STP xzr, xzr, [x19, #0x18] | this.versionName = null;  this.versionCode = null;  //  dest_result_addr=1152921513629529480 |  dest_result_addr=1152921513629529488
            this.versionName = 0;
            this.versionCode = 0;
            // 0x017B7FF0: STP xzr, xzr, [x19, #0x50] | this.iconFileName = null;  this.iconFileNameToGet = null;  //  dest_result_addr=1152921513629529536 |  dest_result_addr=1152921513629529544
            this.iconFileName = 0;
            this.iconFileNameToGet = 0;
            // 0x017B7FF4: ADRP x9, #0x367b000        | X9 = 57126912 (0x367B000);              
            // 0x017B7FF8: LDR x9, [x9, #0xe00]       | X9 = 1152921504616644608;               
            // 0x017B7FFC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B8000: STRB w8, [x19, #0x7c]      | this.supportAnyDensity = true;           //  dest_result_addr=1152921513629529580
            this.supportAnyDensity = true;
            // 0x017B8004: LDR x0, [x9]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<System.String> val_1 = null;
            // 0x017B8008: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x017B800C: ADRP x8, #0x35e9000        | X8 = 56528896 (0x35E9000);              
            // 0x017B8010: LDR x8, [x8, #0xe88]       | X8 = 1152921510893072720;               
            // 0x017B8014: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x017B8018: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<System.String>::.ctor();
            // 0x017B801C: BL #0x25e9474              | .ctor();                                
            val_1 = new System.Collections.Generic.List<System.String>();
            // 0x017B8020: STR x20, [x19, #0x48]      | this.Permissions = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=1152921513629529528
            this.Permissions = val_1;
            // 0x017B8024: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B8028: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B802C: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x017B8030 (24870960), len: 104  VirtAddr: 0x017B8030 RVA: 0x017B8030 token: 100684401 methodIndex: 45971 delegateWrapperIndex: 0 methodInvoker: 0
        public bool get_IsDebuggable()
        {
            //
            // Disasemble & Code
            // 0x017B8030: STP x20, x19, [sp, #-0x20]! | stack[1152921513629633520] = ???;  stack[1152921513629633528] = ???;  //  dest_result_addr=1152921513629633520 |  dest_result_addr=1152921513629633528
            // 0x017B8034: STP x29, x30, [sp, #0x10]  | stack[1152921513629633536] = ???;  stack[1152921513629633544] = ???;  //  dest_result_addr=1152921513629633536 |  dest_result_addr=1152921513629633544
            // 0x017B8038: ADD x29, sp, #0x10         | X29 = (1152921513629633520 + 16) = 1152921513629633536 (0x1000000219CCCC00);
            // 0x017B803C: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017B8040: LDRB w8, [x20, #0x94a]     | W8 = (bool)static_value_0373894A;       
            // 0x017B8044: MOV x19, x0                | X19 = 1152921513629645552 (0x1000000219CCFAF0);//ML01
            // 0x017B8048: TBNZ w8, #0, #0x17b8064    | if (static_value_0373894A == true) goto label_0;
            // 0x017B804C: ADRP x8, #0x35c0000        | X8 = 56360960 (0x35C0000);              
            // 0x017B8050: LDR x8, [x8, #0xf0]        | X8 = 0x2B8AFF0;                         
            // 0x017B8054: LDR w0, [x8]               | W0 = 0x2BA;                             
            // 0x017B8058: BL #0x2782188              | X0 = sub_2782188( ?? 0x2BA, ????);      
            // 0x017B805C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B8060: STRB w8, [x20, #0x94a]     | static_value_0373894A = true;            //  dest_result_addr=57903434
            label_0:
            // 0x017B8064: LDR x0, [x19, #0x40]       | X0 = this.debuggable; //P2              
            // 0x017B8068: CBZ x0, #0x17b8088         | if (this.debuggable == null) goto label_1;
            if(this.debuggable == null)
            {
                goto label_1;
            }
            // 0x017B806C: ADRP x8, #0x367b000        | X8 = 57126912 (0x367B000);              
            // 0x017B8070: LDR x8, [x8, #0xa20]       | X8 = (string**)(1152921513111461536)("-1");
            // 0x017B8074: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8078: LDR x1, [x8]               | X1 = "-1";                              
            // 0x017B807C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B8080: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B8084: B #0x18a8334               | return this.debuggable.Equals(value:  "-1");
            return this.debuggable.Equals(value:  "-1");
            label_1:
            // 0x017B8088: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B808C: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x017B8090: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B8094: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B8098 (24871064), len: 68  VirtAddr: 0x017B8098 RVA: 0x017B8098 token: 100684402 methodIndex: 45972 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool supportSmallScreen(byte[] dpi)
        {
            //
            // Disasemble & Code
            // 0x017B8098: STP x20, x19, [sp, #-0x20]! | stack[1152921513629786480] = ???;  stack[1152921513629786488] = ???;  //  dest_result_addr=1152921513629786480 |  dest_result_addr=1152921513629786488
            // 0x017B809C: STP x29, x30, [sp, #0x10]  | stack[1152921513629786496] = ???;  stack[1152921513629786504] = ???;  //  dest_result_addr=1152921513629786496 |  dest_result_addr=1152921513629786504
            // 0x017B80A0: ADD x29, sp, #0x10         | X29 = (1152921513629786480 + 16) = 1152921513629786496 (0x1000000219CF2180);
            // 0x017B80A4: MOV x19, x1                | X19 = X1;//m1                           
            // 0x017B80A8: CBNZ x19, #0x17b80b0       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x017B80AC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? dpi, ????);        
            label_0:
            // 0x017B80B0: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x017B80B4: CBNZ w8, #0x17b80c4        | if (X1 + 24 != 0) goto label_1;         
            if((X1 + 24) != 0)
            {
                goto label_1;
            }
            // 0x017B80B8: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? dpi, ????);        
            // 0x017B80BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B80C0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? dpi, ????);        
            label_1:
            // 0x017B80C4: LDRB w8, [x19, #0x20]      | W8 = X1 + 32;                           
            // 0x017B80C8: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B80CC: CMP w8, #1                 | STATE = COMPARE(X1 + 32, 0x1)           
            // 0x017B80D0: CSET w0, eq                | W0 = X1 + 32 == 0x1 ? 1 : 0;            
            var val_1 = ((X1 + 32) == 1) ? 1 : 0;
            // 0x017B80D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B80D8: RET                        |  return (System.Boolean)X1 + 32 == 0x1 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B80DC (24871132), len: 72  VirtAddr: 0x017B80DC RVA: 0x017B80DC token: 100684403 methodIndex: 45973 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool supportNormalScreen(byte[] dpi)
        {
            //
            // Disasemble & Code
            // 0x017B80DC: STP x20, x19, [sp, #-0x20]! | stack[1152921513629972208] = ???;  stack[1152921513629972216] = ???;  //  dest_result_addr=1152921513629972208 |  dest_result_addr=1152921513629972216
            // 0x017B80E0: STP x29, x30, [sp, #0x10]  | stack[1152921513629972224] = ???;  stack[1152921513629972232] = ???;  //  dest_result_addr=1152921513629972224 |  dest_result_addr=1152921513629972232
            // 0x017B80E4: ADD x29, sp, #0x10         | X29 = (1152921513629972208 + 16) = 1152921513629972224 (0x1000000219D1F700);
            // 0x017B80E8: MOV x19, x1                | X19 = X1;//m1                           
            // 0x017B80EC: CBNZ x19, #0x17b80f4       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x017B80F0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? dpi, ????);        
            label_0:
            // 0x017B80F4: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x017B80F8: CMP w8, #1                 | STATE = COMPARE(X1 + 24, 0x1)           
            // 0x017B80FC: B.HI #0x17b810c            | if (X1 + 24 > 0x1) goto label_1;        
            if((X1 + 24) > 1)
            {
                goto label_1;
            }
            // 0x017B8100: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? dpi, ????);        
            // 0x017B8104: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8108: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? dpi, ????);        
            label_1:
            // 0x017B810C: LDRB w8, [x19, #0x21]      | W8 = X1 + 33;                           
            // 0x017B8110: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B8114: CMP w8, #1                 | STATE = COMPARE(X1 + 33, 0x1)           
            // 0x017B8118: CSET w0, eq                | W0 = X1 + 33 == 0x1 ? 1 : 0;            
            var val_1 = ((X1 + 33) == 1) ? 1 : 0;
            // 0x017B811C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B8120: RET                        |  return (System.Boolean)X1 + 33 == 0x1 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B8124 (24871204), len: 72  VirtAddr: 0x017B8124 RVA: 0x017B8124 token: 100684404 methodIndex: 45974 delegateWrapperIndex: 0 methodInvoker: 0
        public static bool supportLargeScreen(byte[] dpi)
        {
            //
            // Disasemble & Code
            // 0x017B8124: STP x20, x19, [sp, #-0x20]! | stack[1152921513630157936] = ???;  stack[1152921513630157944] = ???;  //  dest_result_addr=1152921513630157936 |  dest_result_addr=1152921513630157944
            // 0x017B8128: STP x29, x30, [sp, #0x10]  | stack[1152921513630157952] = ???;  stack[1152921513630157960] = ???;  //  dest_result_addr=1152921513630157952 |  dest_result_addr=1152921513630157960
            // 0x017B812C: ADD x29, sp, #0x10         | X29 = (1152921513630157936 + 16) = 1152921513630157952 (0x1000000219D4CC80);
            // 0x017B8130: MOV x19, x1                | X19 = X1;//m1                           
            // 0x017B8134: CBNZ x19, #0x17b813c       | if (X1 != 0) goto label_0;              
            if(X1 != 0)
            {
                goto label_0;
            }
            // 0x017B8138: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? dpi, ????);        
            label_0:
            // 0x017B813C: LDR w8, [x19, #0x18]       | W8 = X1 + 24;                           
            // 0x017B8140: CMP w8, #2                 | STATE = COMPARE(X1 + 24, 0x2)           
            // 0x017B8144: B.HI #0x17b8154            | if (X1 + 24 > 0x2) goto label_1;        
            if((X1 + 24) > 2)
            {
                goto label_1;
            }
            // 0x017B8148: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? dpi, ????);        
            // 0x017B814C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8150: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? dpi, ????);        
            label_1:
            // 0x017B8154: LDRB w8, [x19, #0x22]      | W8 = X1 + 34;                           
            // 0x017B8158: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B815C: CMP w8, #1                 | STATE = COMPARE(X1 + 34, 0x1)           
            // 0x017B8160: CSET w0, eq                | W0 = X1 + 34 == 0x1 ? 1 : 0;            
            var val_1 = ((X1 + 34) == 1) ? 1 : 0;
            // 0x017B8164: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B8168: RET                        |  return (System.Boolean)X1 + 34 == 0x1 ? 1 : 0;
            return (bool)val_1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B816C (24871276), len: 464  VirtAddr: 0x017B816C RVA: 0x017B816C token: 100684405 methodIndex: 45975 delegateWrapperIndex: 0 methodInvoker: 0
        private bool isReference(System.Collections.Generic.List<string> strs)
        {
            //
            // Disasemble & Code
            //  | 
            var val_2;
            //  | 
            var val_3;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            // 0x017B816C: STP x22, x21, [sp, #-0x30]! | stack[1152921513630320096] = ???;  stack[1152921513630320104] = ???;  //  dest_result_addr=1152921513630320096 |  dest_result_addr=1152921513630320104
            // 0x017B8170: STP x20, x19, [sp, #0x10]  | stack[1152921513630320112] = ???;  stack[1152921513630320120] = ???;  //  dest_result_addr=1152921513630320112 |  dest_result_addr=1152921513630320120
            // 0x017B8174: STP x29, x30, [sp, #0x20]  | stack[1152921513630320128] = ???;  stack[1152921513630320136] = ???;  //  dest_result_addr=1152921513630320128 |  dest_result_addr=1152921513630320136
            // 0x017B8178: ADD x29, sp, #0x20         | X29 = (1152921513630320096 + 32) = 1152921513630320128 (0x1000000219D74600);
            // 0x017B817C: SUB sp, sp, #0x40          | SP = (1152921513630320096 - 64) = 1152921513630320032 (0x1000000219D745A0);
            // 0x017B8180: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017B8184: LDRB w8, [x20, #0x94b]     | W8 = (bool)static_value_0373894B;       
            // 0x017B8188: MOV x19, x1                | X19 = strs;//m1                         
            // 0x017B818C: TBNZ w8, #0, #0x17b81a8    | if (static_value_0373894B == true) goto label_0;
            // 0x017B8190: ADRP x8, #0x35d7000        | X8 = 56455168 (0x35D7000);              
            // 0x017B8194: LDR x8, [x8, #0xd60]       | X8 = 0x2B8AFF8;                         
            // 0x017B8198: LDR w0, [x8]               | W0 = 0x2BC;                             
            // 0x017B819C: BL #0x2782188              | X0 = sub_2782188( ?? 0x2BC, ????);      
            // 0x017B81A0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B81A4: STRB w8, [x20, #0x94b]     | static_value_0373894B = true;            //  dest_result_addr=57903435
            label_0:
            // 0x017B81A8: STP xzr, xzr, [sp, #0x28]  | stack[1152921513630320072] = 0x0;  stack[1152921513630320080] = 0x0;  //  dest_result_addr=1152921513630320072 |  dest_result_addr=1152921513630320080
            // 0x017B81AC: STR xzr, [sp, #0x20]       | stack[1152921513630320064] = 0x0;        //  dest_result_addr=1152921513630320064
            // 0x017B81B0: CBNZ x19, #0x17b81b8       | if (strs != null) goto label_1;         
            if(strs != null)
            {
                goto label_1;
            }
            // 0x017B81B4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x2BC, ????);      
            label_1:
            // 0x017B81B8: ADRP x8, #0x364f000        | X8 = 56946688 (0x364F000);              
            // 0x017B81BC: LDR x8, [x8, #0xb00]       | X8 = 1152921510022785904;               
            // 0x017B81C0: LDR x1, [x8]               | X1 = public List.Enumerator<T> System.Collections.Generic.List<System.String>::GetEnumerator();
            // 0x017B81C4: ADD x8, sp, #8             | X8 = (1152921513630320032 + 8) = 1152921513630320040 (0x1000000219D745A8);
            // 0x017B81C8: MOV x0, x19                | X0 = strs;//m1                          
            // 0x017B81CC: BL #0x25ebf2c              | X0 = strs.GetEnumerator();              
            List.Enumerator<T> val_1 = strs.GetEnumerator();
            // 0x017B81D0: LDR x8, [sp, #0x18]        | X8 = val_2;                              //  find_add[1152921513630308144]
            // 0x017B81D4: LDUR q0, [sp, #8]          | Q0 = val_3;                              //  find_add[1152921513630308144]
            // 0x017B81D8: ADRP x19, #0x3637000       | X19 = 56848384 (0x3637000);             
            // 0x017B81DC: ADRP x20, #0x3640000       | X20 = 56885248 (0x3640000);             
            // 0x017B81E0: LDR x19, [x19, #0x1a8]     | X19 = 1152921510022786928;              
            // 0x017B81E4: STR x8, [sp, #0x30]        | stack[1152921513630320080] = val_2;      //  dest_result_addr=1152921513630320080
            // 0x017B81E8: STR q0, [sp, #0x20]        | stack[1152921513630320064] = val_3;      //  dest_result_addr=1152921513630320064
            // 0x017B81EC: LDR x20, [x20, #0x8d0]     | X20 = 1152921510022787952;              
            label_3:
            // 0x017B81F0: LDR x1, [x19]              | X1 = public System.Boolean List.Enumerator<System.String>::MoveNext();
            // 0x017B81F4: ADD x0, sp, #0x20          | X0 = (1152921513630320032 + 32) = 1152921513630320064 (0x1000000219D745C0);
            // 0x017B81F8: BL #0x133720c              | X0 = label_List_Enumerator<System_Object>_VerifyState_GL0133720C();
            // 0x017B81FC: AND w8, w0, #1             | W8 = (1152921513630320064 & 1) = 0 (0x00000000);
            // 0x017B8200: TBZ w8, #0, #0x17b8258     | if ((0x0 & 0x1) == 0) goto label_2;     
            if((0 & 1) == 0)
            {
                goto label_2;
            }
            // 0x017B8204: LDR x1, [x20]              | X1 = public System.String List.Enumerator<System.String>::get_Current();
            // 0x017B8208: ADD x0, sp, #0x20          | X0 = (1152921513630320032 + 32) = 1152921513630320064 (0x1000000219D745C0);
            // 0x017B820C: BL #0x13372d8              | X0 = val_3.get_InitialType();           
            System.Type val_4 = val_3.InitialType;
            // 0x017B8210: MOV x1, x0                 | X1 = val_4;//m1                         
            // 0x017B8214: BL #0x17b833c              | X0 = val_4.isReference(str:  val_4);    
            bool val_5 = val_4.isReference(str:  val_4);
            // 0x017B8218: AND w8, w0, #1             | W8 = (val_5 & 1);                       
            bool val_6 = val_5;
            // 0x017B821C: TBZ w8, #0, #0x17b81f0     | if ((val_5 & 1) == false) goto label_3; 
            if(val_6 == false)
            {
                goto label_3;
            }
            // 0x017B8220: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x017B8224: ORR w20, wzr, #1           | W20 = 1(0x1);                           
            val_9 = 1;
            // 0x017B8228: MOVZ w21, #0x50            | W21 = 80 (0x50);//ML01                  
            val_10 = 80;
            // 0x017B822C: B #0x17b8264               |  goto label_6;                          
            goto label_6;
            // 0x017B8230: MOV x19, x0                | X19 = val_5;//m1                        
            val_11 = val_5;
            // 0x017B8234: CMP w1, #1                 | STATE = COMPARE(val_4, 0x1)             
            // 0x017B8238: B.NE #0x17b82b8            | if (val_4 != 0x1) goto label_5;         
            if(val_4 != 1)
            {
                goto label_5;
            }
            // 0x017B823C: MOV x0, x19                | X0 = val_5;//m1                         
            // 0x017B8240: BL #0x981060               | X0 = sub_981060( ?? val_5, ????);       
            // 0x017B8244: LDR x19, [x0]              | X19 = val_5;                            
            val_8 = mem[val_5];
            val_8 = val_11;
            // 0x017B8248: BL #0x980920               | X0 = sub_980920( ?? val_5, ????);       
            // 0x017B824C: MOV w21, wzr               | W21 = 0 (0x0);//ML01                    
            val_10 = 0;
            // 0x017B8250: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x017B8254: B #0x17b8264               |  goto label_6;                          
            goto label_6;
            label_2:
            // 0x017B8258: MOV x19, xzr               | X19 = 0 (0x0);//ML01                    
            val_8 = 0;
            // 0x017B825C: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_9 = 0;
            // 0x017B8260: MOVZ w21, #0x46            | W21 = 70 (0x46);//ML01                  
            val_10 = 70;
            label_6:
            // 0x017B8264: ADRP x8, #0x35d3000        | X8 = 56438784 (0x35D3000);              
            // 0x017B8268: LDR x8, [x8, #0xd70]       | X8 = 1152921510022801264;               
            // 0x017B826C: LDR x1, [x8]               | X1 = public System.Void List.Enumerator<System.String>::Dispose();
            // 0x017B8270: ADD x0, sp, #0x20          | X0 = (1152921513630320032 + 32) = 1152921513630320064 (0x1000000219D745C0);
            // 0x017B8274: BL #0x13371f4              | val_3.Dispose();                        
            val_3.Dispose();
            // 0x017B8278: CMP w21, #0x46             | STATE = COMPARE(0x46, 0x46)             
            // 0x017B827C: B.EQ #0x17b8298            | if (0x46 == 0x46) goto label_9;         
            if(70 == 70)
            {
                goto label_9;
            }
            // 0x017B8280: CMP w21, #0x50             | STATE = COMPARE(0x46, 0x50)             
            // 0x017B8284: B.EQ #0x17b829c            | if (0x46 == 0x50) goto label_8;         
            if(70 == 80)
            {
                goto label_8;
            }
            // 0x017B8288: CBZ x19, #0x17b8298        | if (0x0 == 0) goto label_9;             
            if(val_8 == 0)
            {
                goto label_9;
            }
            // 0x017B828C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x017B8290: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x017B8294: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
            label_9:
            // 0x017B8298: MOV w20, wzr               | W20 = 0 (0x0);//ML01                    
            val_9 = 0;
            label_8:
            // 0x017B829C: MOV w0, w20                | W0 = 0 (0x0);//ML01                     
            // 0x017B82A0: SUB sp, x29, #0x20         | SP = (1152921513630320128 - 32) = 1152921513630320096 (0x1000000219D745E0);
            // 0x017B82A4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x017B82A8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x017B82AC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x017B82B0: RET                        |  return (System.Boolean)false;          
            return (bool)val_9;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
            // 0x017B82B4: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            val_11 = val_9;
            label_5:
            // 0x017B82B8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B82BC: CMP w1, w8                 | STATE = COMPARE(0x0, 0x1)               
            // 0x017B82C0: B.NE #0x17b8330            | if (0 != 1) goto label_10;              
            if(0 != 1)
            {
                goto label_10;
            }
            // 0x017B82C4: MOV x0, x19                | X0 = 0 (0x0);//ML01                     
            // 0x017B82C8: BL #0x981060               | X0 = sub_981060( ?? 0x0, ????);         
            // 0x017B82CC: MOV x19, x0                | X19 = 0 (0x0);//ML01                    
            // 0x017B82D0: ADRP x8, #0x3624000        | X8 = 56770560 (0x3624000);              
            // 0x017B82D4: LDR x20, [x19]             | X20 = 0x10102464C457F;                  
            // 0x017B82D8: LDR x8, [x8, #0xf98]       | X8 = 1152921504609882112;               
            // 0x017B82DC: LDR x1, [x20]              | X1 = mem[282584257676671];              
            // 0x017B82E0: LDR x0, [x8]               | X0 = typeof(System.Exception);          
            // 0x017B82E4: BL #0x2774c70              | X0 = sub_2774C70( ?? typeof(System.Exception), ????);
            // 0x017B82E8: TBZ w0, #0, #0x17b8308     | if ((typeof(System.Exception) & 0x1) == 0) goto label_11;
            if((null & 1) == 0)
            {
                goto label_11;
            }
            // 0x017B82EC: BL #0x980920               | X0 = sub_980920( ?? typeof(System.Exception), ????);
            // 0x017B82F0: ADRP x8, #0x364b000        | X8 = 56930304 (0x364B000);              
            // 0x017B82F4: LDR x8, [x8, #0x408]       | X8 = 1152921513630303024;               
            // 0x017B82F8: MOV x0, x20                | X0 = 282584257676671 (0x10102464C457F);//ML01
            // 0x017B82FC: LDR x1, [x8]               | X1 = System.Boolean Iteedee.ApkReader.ApkInfo::isReference(System.Collections.Generic.List<string> strs);
            // 0x017B8300: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10102464C457F, ????);
            // 0x017B8304: BL #0x17b754c              | X0 = 1179403647.System.Collections.IEnumerable.GetEnumerator();
            System.Collections.IEnumerator val_7 = 1179403647.System.Collections.IEnumerable.GetEnumerator();
            label_11:
            // 0x017B8308: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x017B830C: BL #0x9802b0               | X0 = sub_9802B0( ?? 0x8, ????);         
            // 0x017B8310: LDR x8, [x19]              | X8 = 0x10102464C457F;                   
            // 0x017B8314: STR x8, [x0]               | mem[8] = 0x10102464C457F;                //  dest_result_addr=8
            mem[8] = 1179403647;
            // 0x017B8318: ADRP x1, #0x3462000        | X1 = 54927360 (0x3462000);              
            // 0x017B831C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8320: ADD x1, x1, #0xf8          | X1 = (54927360 + 248) = 54927608 (0x034620F8);
            // 0x017B8324: BL #0x980e60               | X0 = sub_980E60( ?? 0x8, ????);         
            // 0x017B8328: MOV x19, x0                | X19 = 8 (0x8);//ML01                    
            val_11 = 8;
            // 0x017B832C: BL #0x980920               | X0 = sub_980920( ?? 0x8, ????);         
            label_10:
            // 0x017B8330: MOV x0, x19                | X0 = 8 (0x8);//ML01                     
            // 0x017B8334: BL #0x980800               | X0 = sub_980800( ?? 0x8, ????);         
            // 0x017B8338: BL #0xab7a54               | X0 = label_Mihua_Assets_AssetUtil_LoadDataFromStreamPath_GL00AB7A54();
        
        }
        //
        // Offset in libil2cpp.so: 0x017B833C (24871740), len: 264  VirtAddr: 0x017B833C RVA: 0x017B833C token: 100684406 methodIndex: 45976 delegateWrapperIndex: 0 methodInvoker: 0
        private bool isReference(string str)
        {
            //
            // Disasemble & Code
            //  | 
            var val_4;
            // 0x017B833C: STP x20, x19, [sp, #-0x20]! | stack[1152921513630448496] = ???;  stack[1152921513630448504] = ???;  //  dest_result_addr=1152921513630448496 |  dest_result_addr=1152921513630448504
            // 0x017B8340: STP x29, x30, [sp, #0x10]  | stack[1152921513630448512] = ???;  stack[1152921513630448520] = ???;  //  dest_result_addr=1152921513630448512 |  dest_result_addr=1152921513630448520
            // 0x017B8344: ADD x29, sp, #0x10         | X29 = (1152921513630448496 + 16) = 1152921513630448512 (0x1000000219D93B80);
            // 0x017B8348: ADRP x20, #0x3738000       | X20 = 57901056 (0x3738000);             
            // 0x017B834C: LDRB w8, [x20, #0x94c]     | W8 = (bool)static_value_0373894C;       
            // 0x017B8350: MOV x19, x1                | X19 = str;//m1                          
            // 0x017B8354: TBNZ w8, #0, #0x17b8370    | if (static_value_0373894C == true) goto label_0;
            // 0x017B8358: ADRP x8, #0x3633000        | X8 = 56832000 (0x3633000);              
            // 0x017B835C: LDR x8, [x8, #0xd70]       | X8 = 0x2B8AFF4;                         
            // 0x017B8360: LDR w0, [x8]               | W0 = 0x2BB;                             
            // 0x017B8364: BL #0x2782188              | X0 = sub_2782188( ?? 0x2BB, ????);      
            // 0x017B8368: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B836C: STRB w8, [x20, #0x94c]     | static_value_0373894C = true;            //  dest_result_addr=57903436
            label_0:
            // 0x017B8370: CBZ x19, #0x17b83b0        | if (str == null) goto label_2;          
            if(str == null)
            {
                goto label_2;
            }
            // 0x017B8374: ADRP x8, #0x35e7000        | X8 = 56520704 (0x35E7000);              
            // 0x017B8378: LDR x8, [x8, #0xf68]       | X8 = (string**)(1152921512830278272)("@");
            // 0x017B837C: LDR x1, [x8]               | X1 = "@";                               
            // 0x017B8380: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x017B8384: MOV x0, x19                | X0 = str;//m1                           
            // 0x017B8388: BL #0x18add38              | X0 = str.StartsWith(value:  "@");       
            bool val_1 = str.StartsWith(value:  "@");
            // 0x017B838C: AND w8, w0, #1             | W8 = (val_1 & 1);                       
            bool val_2 = val_1;
            // 0x017B8390: TBZ w8, #0, #0x17b83b0     | if ((val_1 & 1) == false) goto label_2; 
            if(val_2 == false)
            {
                goto label_2;
            }
            // 0x017B8394: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x017B8398: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x017B839C: MOVZ w2, #0x203            | W2 = 515 (0x203);//ML01                 
            // 0x017B83A0: MOV x1, x19                | X1 = str;//m1                           
            // 0x017B83A4: BL #0x1e623b0              | X0 = System.Int32.Parse(s:  0, style:  str);
            int val_3 = System.Int32.Parse(s:  0, style:  str);
            // 0x017B83A8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            val_4 = 1;
            // 0x017B83AC: B #0x17b83b4               |  goto label_3;                          
            goto label_3;
            label_2:
            // 0x017B83B0: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            val_4 = 0;
            label_3:
            // 0x017B83B4: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B83B8: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B83BC: RET                        |  return (System.Boolean)false;          
            return (bool)val_4;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x017B8444 (24872004), len: 324  VirtAddr: 0x017B8444 RVA: 0x017B8444 token: 100684407 methodIndex: 45977 delegateWrapperIndex: 0 methodInvoker: 0
        private static ApkInfo()
        {
            //
            // Disasemble & Code
            // 0x017B8444: STP x20, x19, [sp, #-0x20]! | stack[1152921513630564592] = ???;  stack[1152921513630564600] = ???;  //  dest_result_addr=1152921513630564592 |  dest_result_addr=1152921513630564600
            // 0x017B8448: STP x29, x30, [sp, #0x10]  | stack[1152921513630564608] = ???;  stack[1152921513630564616] = ???;  //  dest_result_addr=1152921513630564608 |  dest_result_addr=1152921513630564616
            // 0x017B844C: ADD x29, sp, #0x10         | X29 = (1152921513630564592 + 16) = 1152921513630564608 (0x1000000219DB0100);
            // 0x017B8450: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x017B8454: LDRB w8, [x19, #0x94d]     | W8 = (bool)static_value_0373894D;       
            // 0x017B8458: TBNZ w8, #0, #0x17b8474    | if (static_value_0373894D == true) goto label_0;
            // 0x017B845C: ADRP x8, #0x35e6000        | X8 = 56516608 (0x35E6000);              
            // 0x017B8460: LDR x8, [x8, #0x5b8]       | X8 = 0x2B8AFE8;                         
            // 0x017B8464: LDR w0, [x8]               | W0 = 0x2B8;                             
            // 0x017B8468: BL #0x2782188              | X0 = sub_2782188( ?? 0x2B8, ????);      
            // 0x017B846C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x017B8470: STRB w8, [x19, #0x94d]     | static_value_0373894D = true;            //  dest_result_addr=57903437
            label_0:
            // 0x017B8474: ADRP x8, #0x35ba000        | X8 = 56336384 (0x35BA000);              
            // 0x017B8478: LDR x8, [x8, #0xfc0]       | X8 = 1152921504856526848;               
            // 0x017B847C: ORR w10, wzr, #1           | W10 = 1(0x1);                           
            // 0x017B8480: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8484: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8488: STR w10, [x9, #4]          | Iteedee.ApkReader.ApkInfo.NULL_VERSION_CODE = 1;  //  dest_result_addr=1152921504856530948
            Iteedee.ApkReader.ApkInfo.NULL_VERSION_CODE = 1;
            // 0x017B848C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8490: ORR w10, wzr, #2           | W10 = 2(0x2);                           
            // 0x017B8494: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8498: STR w10, [x9, #8]          | Iteedee.ApkReader.ApkInfo.NULL_VERSION_NAME = 2;  //  dest_result_addr=1152921504856530952
            Iteedee.ApkReader.ApkInfo.NULL_VERSION_NAME = 2;
            // 0x017B849C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B84A0: ORR w10, wzr, #3           | W10 = 3(0x3);                           
            // 0x017B84A4: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B84A8: STR w10, [x9, #0xc]        | Iteedee.ApkReader.ApkInfo.NULL_PERMISSION = 3;  //  dest_result_addr=1152921504856530956
            Iteedee.ApkReader.ApkInfo.NULL_PERMISSION = 3;
            // 0x017B84AC: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B84B0: ORR w10, wzr, #4           | W10 = 4(0x4);                           
            // 0x017B84B4: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B84B8: STR w10, [x9, #0x10]       | Iteedee.ApkReader.ApkInfo.NULL_ICON = 4;  //  dest_result_addr=1152921504856530960
            Iteedee.ApkReader.ApkInfo.NULL_ICON = 4;
            // 0x017B84BC: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B84C0: MOVZ w10, #0x5             | W10 = 5 (0x5);//ML01                    
            // 0x017B84C4: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B84C8: STR w10, [x9, #0x14]       | Iteedee.ApkReader.ApkInfo.NULL_CERT_FILE = 5;  //  dest_result_addr=1152921504856530964
            Iteedee.ApkReader.ApkInfo.NULL_CERT_FILE = 5;
            // 0x017B84CC: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B84D0: ORR w10, wzr, #6           | W10 = 6(0x6);                           
            // 0x017B84D4: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B84D8: STR w10, [x9, #0x18]       | Iteedee.ApkReader.ApkInfo.BAD_CERT = 6;  //  dest_result_addr=1152921504856530968
            Iteedee.ApkReader.ApkInfo.BAD_CERT = 6;
            // 0x017B84DC: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B84E0: ORR w10, wzr, #7           | W10 = 7(0x7);                           
            // 0x017B84E4: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B84E8: STR w10, [x9, #0x1c]       | Iteedee.ApkReader.ApkInfo.NULL_SF_FILE = 7;  //  dest_result_addr=1152921504856530972
            Iteedee.ApkReader.ApkInfo.NULL_SF_FILE = 7;
            // 0x017B84EC: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B84F0: ORR w10, wzr, #8           | W10 = 8(0x8);                           
            // 0x017B84F4: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B84F8: STR w10, [x9, #0x20]       | Iteedee.ApkReader.ApkInfo.BAD_SF = 8;    //  dest_result_addr=1152921504856530976
            Iteedee.ApkReader.ApkInfo.BAD_SF = 8;
            // 0x017B84FC: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8500: MOVZ w10, #0x9             | W10 = 9 (0x9);//ML01                    
            // 0x017B8504: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8508: STR w10, [x9, #0x24]       | Iteedee.ApkReader.ApkInfo.NULL_MANIFEST = 9;  //  dest_result_addr=1152921504856530980
            Iteedee.ApkReader.ApkInfo.NULL_MANIFEST = 9;
            // 0x017B850C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8510: MOVZ w10, #0xa             | W10 = 10 (0xA);//ML01                   
            // 0x017B8514: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8518: STR w10, [x9, #0x28]       | Iteedee.ApkReader.ApkInfo.NULL_RESOURCES = 10;  //  dest_result_addr=1152921504856530984
            Iteedee.ApkReader.ApkInfo.NULL_RESOURCES = 10;
            // 0x017B851C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8520: MOVZ w10, #0xd             | W10 = 13 (0xD);//ML01                   
            // 0x017B8524: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8528: STR w10, [x9, #0x2c]       | Iteedee.ApkReader.ApkInfo.NULL_DEX = 13;  //  dest_result_addr=1152921504856530988
            Iteedee.ApkReader.ApkInfo.NULL_DEX = 13;
            // 0x017B852C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8530: ORR w10, wzr, #0xe         | W10 = 14(0xE);                          
            // 0x017B8534: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8538: STR w10, [x9, #0x30]       | Iteedee.ApkReader.ApkInfo.NULL_METAINFO = 14;  //  dest_result_addr=1152921504856530992
            Iteedee.ApkReader.ApkInfo.NULL_METAINFO = 14;
            // 0x017B853C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8540: MOVZ w10, #0xb             | W10 = 11 (0xB);//ML01                   
            // 0x017B8544: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8548: STR w10, [x9, #0x34]       | Iteedee.ApkReader.ApkInfo.BAD_JAR = 11;  //  dest_result_addr=1152921504856530996
            Iteedee.ApkReader.ApkInfo.BAD_JAR = 11;
            // 0x017B854C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8550: ORR w10, wzr, #0xc         | W10 = 12(0xC);                          
            // 0x017B8554: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8558: STR w10, [x9, #0x38]       | Iteedee.ApkReader.ApkInfo.BAD_READ_INFO = 12;  //  dest_result_addr=1152921504856531000
            Iteedee.ApkReader.ApkInfo.BAD_READ_INFO = 12;
            // 0x017B855C: LDR x9, [x8]               | X9 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8560: ORR w10, wzr, #0xf         | W10 = 15(0xF);                          
            // 0x017B8564: LDR x9, [x9, #0xa0]        | X9 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8568: STR w10, [x9, #0x3c]       | Iteedee.ApkReader.ApkInfo.NULL_FILE = 15;  //  dest_result_addr=1152921504856531004
            Iteedee.ApkReader.ApkInfo.NULL_FILE = 15;
            // 0x017B856C: LDR x8, [x8]               | X8 = typeof(Iteedee.ApkReader.ApkInfo); 
            // 0x017B8570: ORR w9, wzr, #0x10         | W9 = 16(0x10);                          
            // 0x017B8574: LDR x8, [x8, #0xa0]        | X8 = Iteedee.ApkReader.ApkInfo.__il2cppRuntimeField_static_fields;
            // 0x017B8578: STR w9, [x8, #0x40]        | Iteedee.ApkReader.ApkInfo.HAS_REF = 16;  //  dest_result_addr=1152921504856531008
            Iteedee.ApkReader.ApkInfo.HAS_REF = 16;
            // 0x017B857C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x017B8580: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x017B8584: RET                        |  return;                                
            return;
        
        }
    
    }

}
