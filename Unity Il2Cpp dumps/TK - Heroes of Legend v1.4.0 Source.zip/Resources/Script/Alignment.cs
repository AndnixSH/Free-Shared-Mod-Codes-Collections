using UnityEngine;
public enum NGUIText.Alignment
{
    // Fields
    Automatic = 0
    ,Left = 1
    ,Center = 2
    ,Right = 3
    ,Justified = 4
    

}
