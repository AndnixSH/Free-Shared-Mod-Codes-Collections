using UnityEngine;

namespace wxb
{
    internal class ArrayByteType : ArraySerialize<byte>
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E2B998 (14858648), len: 80  VirtAddr: 0x00E2B998 RVA: 0x00E2B998 token: 100681189 methodIndex: 57193 delegateWrapperIndex: 0 methodInvoker: 0
        public ArrayByteType()
        {
            //
            // Disasemble & Code
            // 0x00E2B998: STP x20, x19, [sp, #-0x20]! | stack[1152921513024459168] = ???;  stack[1152921513024459176] = ???;  //  dest_result_addr=1152921513024459168 |  dest_result_addr=1152921513024459176
            // 0x00E2B99C: STP x29, x30, [sp, #0x10]  | stack[1152921513024459184] = ???;  stack[1152921513024459192] = ???;  //  dest_result_addr=1152921513024459184 |  dest_result_addr=1152921513024459192
            // 0x00E2B9A0: ADD x29, sp, #0x10         | X29 = (1152921513024459168 + 16) = 1152921513024459184 (0x10000001F5BA91B0);
            // 0x00E2B9A4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E2B9A8: LDRB w8, [x20, #0x8ea]     | W8 = (bool)static_value_037348EA;       
            // 0x00E2B9AC: MOV x19, x0                | X19 = 1152921513024471200 (0x10000001F5BAC0A0);//ML01
            // 0x00E2B9B0: TBNZ w8, #0, #0xe2b9cc     | if (static_value_037348EA == true) goto label_0;
            // 0x00E2B9B4: ADRP x8, #0x3651000        | X8 = 56954880 (0x3651000);              
            // 0x00E2B9B8: LDR x8, [x8, #0x4b8]       | X8 = 0x2B8E710;                         
            // 0x00E2B9BC: LDR w0, [x8]               | W0 = 0x1082;                            
            // 0x00E2B9C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x1082, ????);     
            // 0x00E2B9C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E2B9C8: STRB w8, [x20, #0x8ea]     | static_value_037348EA = true;            //  dest_result_addr=57886954
            label_0:
            // 0x00E2B9CC: ADRP x8, #0x365f000        | X8 = 57012224 (0x365F000);              
            // 0x00E2B9D0: LDR x8, [x8, #0xbb0]       | X8 = 1152921513024446176;               
            // 0x00E2B9D4: MOV x0, x19                | X0 = 1152921513024471200 (0x10000001F5BAC0A0);//ML01
            // 0x00E2B9D8: LDR x1, [x8]               | X1 = System.Void wxb.ArraySerialize<System.Byte>::.ctor();
            // 0x00E2B9DC: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2B9E0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2B9E4: B #0x1d86e84               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2B9E8 (14858728), len: 8  VirtAddr: 0x00E2B9E8 RVA: 0x00E2B9E8 token: 100681190 methodIndex: 57194 delegateWrapperIndex: 0 methodInvoker: 0
        protected override int GetElementSize()
        {
            //
            // Disasemble & Code
            // 0x00E2B9E8: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00E2B9EC: RET                        |  return (System.Int32)1;                
            return (int)1;
            //  |  // // {name=val_0, type=System.Int32, size=4, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2B9F0 (14858736), len: 52  VirtAddr: 0x00E2B9F0 RVA: 0x00E2B9F0 token: 100681191 methodIndex: 57195 delegateWrapperIndex: 0 methodInvoker: 0
        protected override void Write(wxb.WRStream stream, byte value)
        {
            //
            // Disasemble & Code
            // 0x00E2B9F0: STP x20, x19, [sp, #-0x20]! | stack[1152921513024687264] = ???;  stack[1152921513024687272] = ???;  //  dest_result_addr=1152921513024687264 |  dest_result_addr=1152921513024687272
            // 0x00E2B9F4: STP x29, x30, [sp, #0x10]  | stack[1152921513024687280] = ???;  stack[1152921513024687288] = ???;  //  dest_result_addr=1152921513024687280 |  dest_result_addr=1152921513024687288
            // 0x00E2B9F8: ADD x29, sp, #0x10         | X29 = (1152921513024687264 + 16) = 1152921513024687280 (0x10000001F5BE0CB0);
            // 0x00E2B9FC: MOV w19, w2                | W19 = value;//m1                        
            // 0x00E2BA00: MOV x20, x1                | X20 = stream;//m1                       
            // 0x00E2BA04: CBNZ x20, #0xe2ba0c        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BA08: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BA0C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BA10: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E2BA14: MOV x0, x20                | X0 = stream;//m1                        
            // 0x00E2BA18: MOV w1, w19                | W1 = value;//m1                         
            // 0x00E2BA1C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BA20: B #0x26a5270               | stream.WriteByte(value:  value); return;
            stream.WriteByte(value:  value);
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00E2BA24 (14858788), len: 44  VirtAddr: 0x00E2BA24 RVA: 0x00E2BA24 token: 100681192 methodIndex: 57196 delegateWrapperIndex: 0 methodInvoker: 0
        protected override byte Read(wxb.WRStream stream)
        {
            //
            // Disasemble & Code
            // 0x00E2BA24: STP x20, x19, [sp, #-0x20]! | stack[1152921513024807456] = ???;  stack[1152921513024807464] = ???;  //  dest_result_addr=1152921513024807456 |  dest_result_addr=1152921513024807464
            // 0x00E2BA28: STP x29, x30, [sp, #0x10]  | stack[1152921513024807472] = ???;  stack[1152921513024807480] = ???;  //  dest_result_addr=1152921513024807472 |  dest_result_addr=1152921513024807480
            // 0x00E2BA2C: ADD x29, sp, #0x10         | X29 = (1152921513024807456 + 16) = 1152921513024807472 (0x10000001F5BFE230);
            // 0x00E2BA30: MOV x19, x1                | X19 = stream;//m1                       
            // 0x00E2BA34: CBNZ x19, #0xe2ba3c        | if (stream != null) goto label_0;       
            if(stream != null)
            {
                goto label_0;
            }
            // 0x00E2BA38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_0:
            // 0x00E2BA3C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E2BA40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E2BA44: MOV x0, x19                | X0 = stream;//m1                        
            // 0x00E2BA48: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E2BA4C: B #0x26a52d8               | return stream.ReadByte();               
            return stream.ReadByte();
        
        }
    
    }

}
