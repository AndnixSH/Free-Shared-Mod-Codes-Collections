using UnityEngine;

namespace ILRuntime.Mono.Cecil
{
    public sealed class ByReferenceType : TypeSpecification
    {
        // Properties
        public override string Name { get; }
        public override string FullName { get; }
        public override bool IsValueType { get; set; }
        public override bool IsByReference { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00E588C4 (15042756), len: 140  VirtAddr: 0x00E588C4 RVA: 0x00E588C4 token: 100664262 methodIndex: 19341 delegateWrapperIndex: 0 methodInvoker: 0
        public override string get_Name()
        {
            //
            // Disasemble & Code
            // 0x00E588C4: STP x20, x19, [sp, #-0x20]! | stack[1152921509527446560] = ???;  stack[1152921509527446568] = ???;  //  dest_result_addr=1152921509527446560 |  dest_result_addr=1152921509527446568
            // 0x00E588C8: STP x29, x30, [sp, #0x10]  | stack[1152921509527446576] = ???;  stack[1152921509527446584] = ???;  //  dest_result_addr=1152921509527446576 |  dest_result_addr=1152921509527446584
            // 0x00E588CC: ADD x29, sp, #0x10         | X29 = (1152921509527446560 + 16) = 1152921509527446576 (0x10000001254A6430);
            // 0x00E588D0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E588D4: LDRB w8, [x20, #0xad3]     | W8 = (bool)static_value_03734AD3;       
            // 0x00E588D8: MOV x19, x0                | X19 = 1152921509527458592 (0x10000001254A9320);//ML01
            // 0x00E588DC: TBNZ w8, #0, #0xe588f8     | if (static_value_03734AD3 == true) goto label_0;
            // 0x00E588E0: ADRP x8, #0x3618000        | X8 = 56721408 (0x3618000);              
            // 0x00E588E4: LDR x8, [x8, #0x208]       | X8 = 0x2B8FF00;                         
            // 0x00E588E8: LDR w0, [x8]               | W0 = 0x1684;                            
            // 0x00E588EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1684, ????);     
            // 0x00E588F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E588F4: STRB w8, [x20, #0xad3]     | static_value_03734AD3 = true;            //  dest_result_addr=57887443
            label_0:
            // 0x00E588F8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E588FC: MOV x0, x19                | X0 = 1152921509527458592 (0x10000001254A9320);//ML01
            // 0x00E58900: BL #0x11dfd58              | X0 = this.get_Name();                   
            string val_1 = this.Name;
            // 0x00E58904: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E58908: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E5890C: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E58910: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00E58914: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E58918: TBZ w9, #0, #0xe5892c      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E5891C: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E58920: CBNZ w9, #0xe5892c         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E58924: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E58928: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00E5892C: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00E58930: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921509527434512)("&");
            // 0x00E58934: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58938: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E5893C: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00E58940: LDR x2, [x8]               | X2 = "&";                               
            // 0x00E58944: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58948: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E5894C: B #0x18a3e88               | return System.String.Concat(str0:  0, str1:  val_1);
            return System.String.Concat(str0:  0, str1:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58950 (15042896), len: 140  VirtAddr: 0x00E58950 RVA: 0x00E58950 token: 100664263 methodIndex: 19342 delegateWrapperIndex: 0 methodInvoker: 0
        public override string get_FullName()
        {
            //
            // Disasemble & Code
            // 0x00E58950: STP x20, x19, [sp, #-0x20]! | stack[1152921509527566752] = ???;  stack[1152921509527566760] = ???;  //  dest_result_addr=1152921509527566752 |  dest_result_addr=1152921509527566760
            // 0x00E58954: STP x29, x30, [sp, #0x10]  | stack[1152921509527566768] = ???;  stack[1152921509527566776] = ???;  //  dest_result_addr=1152921509527566768 |  dest_result_addr=1152921509527566776
            // 0x00E58958: ADD x29, sp, #0x10         | X29 = (1152921509527566752 + 16) = 1152921509527566768 (0x10000001254C39B0);
            // 0x00E5895C: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00E58960: LDRB w8, [x20, #0xad4]     | W8 = (bool)static_value_03734AD4;       
            // 0x00E58964: MOV x19, x0                | X19 = 1152921509527578784 (0x10000001254C68A0);//ML01
            // 0x00E58968: TBNZ w8, #0, #0xe58984     | if (static_value_03734AD4 == true) goto label_0;
            // 0x00E5896C: ADRP x8, #0x360f000        | X8 = 56684544 (0x360F000);              
            // 0x00E58970: LDR x8, [x8, #0x878]       | X8 = 0x2B8FEFC;                         
            // 0x00E58974: LDR w0, [x8]               | W0 = 0x1683;                            
            // 0x00E58978: BL #0x2782188              | X0 = sub_2782188( ?? 0x1683, ????);     
            // 0x00E5897C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58980: STRB w8, [x20, #0xad4]     | static_value_03734AD4 = true;            //  dest_result_addr=57887444
            label_0:
            // 0x00E58984: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58988: MOV x0, x19                | X0 = 1152921509527578784 (0x10000001254C68A0);//ML01
            // 0x00E5898C: BL #0x11dfeb0              | X0 = this.get_FullName();               
            string val_1 = this.FullName;
            // 0x00E58990: ADRP x8, #0x35d6000        | X8 = 56451072 (0x35D6000);              
            // 0x00E58994: LDR x8, [x8, #0xe38]       | X8 = 1152921504608284672;               
            // 0x00E58998: MOV x19, x0                | X19 = val_1;//m1                        
            // 0x00E5899C: LDR x8, [x8]               | X8 = typeof(System.String);             
            // 0x00E589A0: LDRB w9, [x8, #0x10a]      | W9 = System.String.__il2cppRuntimeField_10A;
            // 0x00E589A4: TBZ w9, #0, #0xe589b8      | if (System.String.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E589A8: LDR w9, [x8, #0xbc]        | W9 = System.String.__il2cppRuntimeField_cctor_finished;
            // 0x00E589AC: CBNZ w9, #0xe589b8         | if (System.String.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E589B0: MOV x0, x8                 | X0 = 1152921504608284672 (0x100000000015F000);//ML01
            // 0x00E589B4: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(System.String), ????);
            label_2:
            // 0x00E589B8: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
            // 0x00E589BC: LDR x8, [x8, #0x40]        | X8 = (string**)(1152921509527434512)("&");
            // 0x00E589C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E589C4: MOV x3, xzr                | X3 = 0 (0x0);//ML01                     
            // 0x00E589C8: MOV x1, x19                | X1 = val_1;//m1                         
            // 0x00E589CC: LDR x2, [x8]               | X2 = "&";                               
            // 0x00E589D0: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00E589D4: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00E589D8: B #0x18a3e88               | return System.String.Concat(str0:  0, str1:  val_1);
            return System.String.Concat(str0:  0, str1:  val_1);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E589DC (15043036), len: 8  VirtAddr: 0x00E589DC RVA: 0x00E589DC token: 100664264 methodIndex: 19343 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_IsValueType()
        {
            //
            // Disasemble & Code
            // 0x00E589DC: MOV w0, wzr                | W0 = 0 (0x0);//ML01                     
            // 0x00E589E0: RET                        |  return (System.Boolean)false;          
            return (bool)0;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E589E4 (15043044), len: 100  VirtAddr: 0x00E589E4 RVA: 0x00E589E4 token: 100664265 methodIndex: 19344 delegateWrapperIndex: 0 methodInvoker: 0
        public override void set_IsValueType(bool value)
        {
            //
            // Disasemble & Code
            // 0x00E589E4: STP x20, x19, [sp, #-0x20]! | stack[1152921509527795872] = ???;  stack[1152921509527795880] = ???;  //  dest_result_addr=1152921509527795872 |  dest_result_addr=1152921509527795880
            // 0x00E589E8: STP x29, x30, [sp, #0x10]  | stack[1152921509527795888] = ???;  stack[1152921509527795896] = ???;  //  dest_result_addr=1152921509527795888 |  dest_result_addr=1152921509527795896
            // 0x00E589EC: ADD x29, sp, #0x10         | X29 = (1152921509527795872 + 16) = 1152921509527795888 (0x10000001254FB8B0);
            // 0x00E589F0: ADRP x19, #0x3734000       | X19 = 57884672 (0x3734000);             
            // 0x00E589F4: LDRB w8, [x19, #0xad5]     | W8 = (bool)static_value_03734AD5;       
            // 0x00E589F8: TBNZ w8, #0, #0xe58a14     | if (static_value_03734AD5 == true) goto label_0;
            // 0x00E589FC: ADRP x8, #0x35cb000        | X8 = 56406016 (0x35CB000);              
            // 0x00E58A00: LDR x8, [x8, #0x210]       | X8 = 0x2B8FF04;                         
            // 0x00E58A04: LDR w0, [x8]               | W0 = 0x1685;                            
            // 0x00E58A08: BL #0x2782188              | X0 = sub_2782188( ?? 0x1685, ????);     
            // 0x00E58A0C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58A10: STRB w8, [x19, #0xad5]     | static_value_03734AD5 = true;            //  dest_result_addr=57887445
            label_0:
            // 0x00E58A14: ADRP x8, #0x3636000        | X8 = 56844288 (0x3636000);              
            // 0x00E58A18: LDR x8, [x8, #0xbd8]       | X8 = 1152921504654397440;               
            // 0x00E58A1C: LDR x0, [x8]               | X0 = typeof(System.InvalidOperationException);
            System.InvalidOperationException val_1 = null;
            // 0x00E58A20: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.InvalidOperationException), ????);
            // 0x00E58A24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00E58A28: MOV x19, x0                | X19 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00E58A2C: BL #0x1e66414              | .ctor();                                
            val_1 = new System.InvalidOperationException();
            // 0x00E58A30: ADRP x8, #0x3611000        | X8 = 56692736 (0x3611000);              
            // 0x00E58A34: LDR x8, [x8, #0xe90]       | X8 = 1152921509527782880;               
            // 0x00E58A38: MOV x0, x19                | X0 = 1152921504654397440 (0x1000000002D59000);//ML01
            // 0x00E58A3C: LDR x1, [x8]               | X1 = public System.Void ILRuntime.Mono.Cecil.ByReferenceType::set_IsValueType(bool value);
            // 0x00E58A40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? typeof(System.InvalidOperationException), ????);
            // 0x00E58A44: BL #0xe53e30               | X0 = sub_E53E30( ?? typeof(System.InvalidOperationException), ????);
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58A48 (15043144), len: 8  VirtAddr: 0x00E58A48 RVA: 0x00E58A48 token: 100664266 methodIndex: 19345 delegateWrapperIndex: 0 methodInvoker: 0
        public override bool get_IsByReference()
        {
            //
            // Disasemble & Code
            // 0x00E58A48: ORR w0, wzr, #1            | W0 = 1(0x1);                            
            // 0x00E58A4C: RET                        |  return (System.Boolean)true;           
            return (bool)1;
            //  |  // // {name=val_0, type=System.Boolean, size=1, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00E58A50 (15043152), len: 148  VirtAddr: 0x00E58A50 RVA: 0x00E58A50 token: 100664267 methodIndex: 19346 delegateWrapperIndex: 0 methodInvoker: 0
        public ByReferenceType(ILRuntime.Mono.Cecil.TypeReference type)
        {
            //
            // Disasemble & Code
            // 0x00E58A50: STP x22, x21, [sp, #-0x30]! | stack[1152921509528023952] = ???;  stack[1152921509528023960] = ???;  //  dest_result_addr=1152921509528023952 |  dest_result_addr=1152921509528023960
            // 0x00E58A54: STP x20, x19, [sp, #0x10]  | stack[1152921509528023968] = ???;  stack[1152921509528023976] = ???;  //  dest_result_addr=1152921509528023968 |  dest_result_addr=1152921509528023976
            // 0x00E58A58: STP x29, x30, [sp, #0x20]  | stack[1152921509528023984] = ???;  stack[1152921509528023992] = ???;  //  dest_result_addr=1152921509528023984 |  dest_result_addr=1152921509528023992
            // 0x00E58A5C: ADD x29, sp, #0x20         | X29 = (1152921509528023952 + 32) = 1152921509528023984 (0x10000001255333B0);
            // 0x00E58A60: ADRP x21, #0x3734000       | X21 = 57884672 (0x3734000);             
            // 0x00E58A64: LDRB w8, [x21, #0xad6]     | W8 = (bool)static_value_03734AD6;       
            // 0x00E58A68: MOV x20, x1                | X20 = type;//m1                         
            // 0x00E58A6C: MOV x19, x0                | X19 = 1152921509528036000 (0x10000001255362A0);//ML01
            // 0x00E58A70: TBNZ w8, #0, #0xe58a8c     | if (static_value_03734AD6 == true) goto label_0;
            // 0x00E58A74: ADRP x8, #0x35fc000        | X8 = 56606720 (0x35FC000);              
            // 0x00E58A78: LDR x8, [x8, #0x170]       | X8 = 0x2B8FEF8;                         
            // 0x00E58A7C: LDR w0, [x8]               | W0 = 0x1682;                            
            // 0x00E58A80: BL #0x2782188              | X0 = sub_2782188( ?? 0x1682, ????);     
            // 0x00E58A84: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00E58A88: STRB w8, [x21, #0xad6]     | static_value_03734AD6 = true;            //  dest_result_addr=57887446
            label_0:
            // 0x00E58A8C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58A90: MOV x0, x19                | X0 = 1152921509528036000 (0x10000001255362A0);//ML01
            // 0x00E58A94: MOV x1, x20                | X1 = type;//m1                          
            // 0x00E58A98: BL #0x11e0120              | this..ctor(type:  type);                
            // 0x00E58A9C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00E58AA0: LDR x8, [x8, #0xa48]       | X8 = 1152921504737091584;               
            // 0x00E58AA4: LDR x0, [x8]               | X0 = typeof(ILRuntime.Mono.Cecil.Mixin);
            // 0x00E58AA8: LDRB w8, [x0, #0x10a]      | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_10A;
            // 0x00E58AAC: TBZ w8, #0, #0xe58abc      | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x00E58AB0: LDR w8, [x0, #0xbc]        | W8 = ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished;
            // 0x00E58AB4: CBNZ w8, #0xe58abc         | if (ILRuntime.Mono.Cecil.Mixin.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x00E58AB8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(ILRuntime.Mono.Cecil.Mixin), ????);
            label_2:
            // 0x00E58ABC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x00E58AC0: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
            // 0x00E58AC4: MOV x1, x20                | X1 = type;//m1                          
            // 0x00E58AC8: BL #0x11d28e8              | ILRuntime.Mono.Cecil.Mixin.CheckType(type:  0);
            ILRuntime.Mono.Cecil.Mixin.CheckType(type:  0);
            // 0x00E58ACC: ORR w8, wzr, #0x10         | W8 = 16(0x10);                          
            // 0x00E58AD0: STRB w8, [x19, #0x50]      | mem[1152921509528036080] = 0x10;         //  dest_result_addr=1152921509528036080
            mem[1152921509528036080] = 16;
            // 0x00E58AD4: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
            // 0x00E58AD8: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
            // 0x00E58ADC: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
            // 0x00E58AE0: RET                        |  return;                                
            return;
        
        }
    
    }

}
