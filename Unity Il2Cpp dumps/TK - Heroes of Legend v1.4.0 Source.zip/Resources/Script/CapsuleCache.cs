using UnityEngine;
private class RecastGraph.CapsuleCache
{
    // Fields
    public int rows; //  0x00000010
    public float height; //  0x00000014
    public UnityEngine.Vector3[] verts; //  0x00000018
    public int[] tris; //  0x00000020
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x0142424C (21119564), len: 8  VirtAddr: 0x0142424C RVA: 0x0142424C token: 100683161 methodIndex: 50915 delegateWrapperIndex: 0 methodInvoker: 0
    public RecastGraph.CapsuleCache()
    {
        //
        // Disasemble & Code
        // 0x0142424C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x01424250: B #0x16f59f0               | this..ctor(); return;                   
        return;
    
    }

}
