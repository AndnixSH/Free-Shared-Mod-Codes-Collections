using UnityEngine;
public class CameraAnimation : MonoBehaviour
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x00BA718C (12218764), len: 8  VirtAddr: 0x00BA718C RVA: 0x00BA718C token: 100693314 methodIndex: 25654 delegateWrapperIndex: 0 methodInvoker: 0
    public CameraAnimation()
    {
        //
        // Disasemble & Code
        // 0x00BA718C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00BA7190: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00BA7194 (12218772), len: 144  VirtAddr: 0x00BA7194 RVA: 0x00BA7194 token: 100693315 methodIndex: 25655 delegateWrapperIndex: 0 methodInvoker: 0
    public void PlayAnimationEnd()
    {
        //
        // Disasemble & Code
        // 0x00BA7194: STP x20, x19, [sp, #-0x20]! | stack[1152921514970344704] = ???;  stack[1152921514970344712] = ???;  //  dest_result_addr=1152921514970344704 |  dest_result_addr=1152921514970344712
        // 0x00BA7198: STP x29, x30, [sp, #0x10]  | stack[1152921514970344720] = ???;  stack[1152921514970344728] = ???;  //  dest_result_addr=1152921514970344720 |  dest_result_addr=1152921514970344728
        // 0x00BA719C: ADD x29, sp, #0x10         | X29 = (1152921514970344704 + 16) = 1152921514970344720 (0x1000000269B66D10);
        // 0x00BA71A0: ADRP x19, #0x3733000       | X19 = 57880576 (0x3733000);             
        // 0x00BA71A4: LDRB w8, [x19, #0xae5]     | W8 = (bool)static_value_03733AE5;       
        // 0x00BA71A8: TBNZ w8, #0, #0xba71c4     | if (static_value_03733AE5 == true) goto label_0;
        // 0x00BA71AC: ADRP x8, #0x35d2000        | X8 = 56434688 (0x35D2000);              
        // 0x00BA71B0: LDR x8, [x8, #0xb58]       | X8 = 0x2B90148;                         
        // 0x00BA71B4: LDR w0, [x8]               | W0 = 0x1716;                            
        // 0x00BA71B8: BL #0x2782188              | X0 = sub_2782188( ?? 0x1716, ????);     
        // 0x00BA71BC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00BA71C0: STRB w8, [x19, #0xae5]     | static_value_03733AE5 = true;            //  dest_result_addr=57883365
        label_0:
        // 0x00BA71C4: ADRP x8, #0x3676000        | X8 = 57106432 (0x3676000);              
        // 0x00BA71C8: LDR x8, [x8, #0x440]       | X8 = 1152921504898326528;               
        // 0x00BA71CC: LDR x0, [x8]               | X0 = typeof(CEvent.ZEvent);             
        CEvent.ZEvent val_1 = null;
        // 0x00BA71D0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(CEvent.ZEvent), ????);
        // 0x00BA71D4: ADRP x8, #0x3681000        | X8 = 57151488 (0x3681000);              
        // 0x00BA71D8: LDR x8, [x8, #0x910]       | X8 = (string**)(1152921514885511152)("CAMERA_PATROL_PLAY_END");
        // 0x00BA71DC: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA71E0: MOV x19, x0                | X19 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BA71E4: LDR x1, [x8]               | X1 = "CAMERA_PATROL_PLAY_END";          
        // 0x00BA71E8: BL #0xd80ce8               | .ctor(name:  "CAMERA_PATROL_PLAY_END"); 
        val_1 = new CEvent.ZEvent(name:  "CAMERA_PATROL_PLAY_END");
        // 0x00BA71EC: ADRP x8, #0x35cc000        | X8 = 56410112 (0x35CC000);              
        // 0x00BA71F0: LDR x8, [x8, #0xde0]       | X8 = 1152921504898379776;               
        // 0x00BA71F4: LDR x0, [x8]               | X0 = typeof(CEvent.ZEventCenter);       
        // 0x00BA71F8: LDRB w8, [x0, #0x10a]      | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_10A;
        // 0x00BA71FC: TBZ w8, #0, #0xba720c      | if (CEvent.ZEventCenter.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00BA7200: LDR w8, [x0, #0xbc]        | W8 = CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished;
        // 0x00BA7204: CBNZ w8, #0xba720c         | if (CEvent.ZEventCenter.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00BA7208: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(CEvent.ZEventCenter), ????);
        label_2:
        // 0x00BA720C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00BA7210: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00BA7214: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00BA7218: MOV x1, x19                | X1 = 1152921504898326528 (0x10000000115FA000);//ML01
        // 0x00BA721C: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00BA7220: B #0xd7de90                | CEvent.ZEventCenter.DispatchEvent(ev:  0); return;
        CEvent.ZEventCenter.DispatchEvent(ev:  0);
        return;
    
    }

}
