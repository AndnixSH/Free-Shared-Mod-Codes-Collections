using UnityEngine;
public class BezierMover : MonoBehaviour
{
    // Fields
    public UnityEngine.Transform[] points; //  0x00000018
    public float tangentLengths; //  0x00000020
    public float speed; //  0x00000024
    private float time; //  0x00000028
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B8E684 (12117636), len: 20  VirtAddr: 0x00B8E684 RVA: 0x00B8E684 token: 100682700 methodIndex: 25113 delegateWrapperIndex: 0 methodInvoker: 0
    public BezierMover()
    {
        //
        // Disasemble & Code
        // 0x00B8E684: ORR x8, xzr, #0x3f8000003f800000 | X8 = 4575657222473777152(0x3F8000003F800000);
        // 0x00B8E688: MOVK x8, #0x40a0, lsl #16  | X8 = 4575657223549616128 (0x3F8000007FA00000);
        // 0x00B8E68C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E690: STR x8, [x0, #0x20]        | this.tangentLengths = NaN; this.speed = 1;  //  dest_result_addr=1152921513300194576 dest_result_addr=1152921513300194580
        this.tangentLengths = 0f;
        this.speed = 1f;
        // 0x00B8E694: B #0x1b76fd4               | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E698 (12117656), len: 128  VirtAddr: 0x00B8E698 RVA: 0x00B8E698 token: 100682701 methodIndex: 25114 delegateWrapperIndex: 0 methodInvoker: 0
    private void Awake()
    {
        //
        // Disasemble & Code
        // 0x00B8E698: STP x20, x19, [sp, #-0x20]! | stack[1152921513300298608] = ???;  stack[1152921513300298616] = ???;  //  dest_result_addr=1152921513300298608 |  dest_result_addr=1152921513300298616
        // 0x00B8E69C: STP x29, x30, [sp, #0x10]  | stack[1152921513300298624] = ???;  stack[1152921513300298632] = ???;  //  dest_result_addr=1152921513300298624 |  dest_result_addr=1152921513300298632
        // 0x00B8E6A0: ADD x29, sp, #0x10         | X29 = (1152921513300298608 + 16) = 1152921513300298624 (0x10000002062B8B80);
        // 0x00B8E6A4: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8E6A8: LDRB w8, [x20, #0xa2a]     | W8 = (bool)static_value_03733A2A;       
        // 0x00B8E6AC: MOV x19, x0                | X19 = 1152921513300310640 (0x10000002062BBA70);//ML01
        // 0x00B8E6B0: TBNZ w8, #0, #0xb8e6cc     | if (static_value_03733A2A == true) goto label_0;
        // 0x00B8E6B4: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B8E6B8: LDR x8, [x8, #0xc40]       | X8 = 0x2B8F364;                         
        // 0x00B8E6BC: LDR w0, [x8]               | W0 = 0x139B;                            
        // 0x00B8E6C0: BL #0x2782188              | X0 = sub_2782188( ?? 0x139B, ????);     
        // 0x00B8E6C4: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E6C8: STRB w8, [x20, #0xa2a]     | static_value_03733A2A = true;            //  dest_result_addr=57883178
        label_0:
        // 0x00B8E6CC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E6D0: MOV x0, x19                | X0 = 1152921513300310640 (0x10000002062BBA70);//ML01
        // 0x00B8E6D4: BL #0x20d50fc              | X0 = this.get_gameObject();             
        UnityEngine.GameObject val_1 = this.gameObject;
        // 0x00B8E6D8: ADRP x8, #0x35fe000        | X8 = 56614912 (0x35FE000);              
        // 0x00B8E6DC: LDR x8, [x8, #0x810]       | X8 = 1152921504697475072;               
        // 0x00B8E6E0: MOV x19, x0                | X19 = val_1;//m1                        
        // 0x00B8E6E4: LDR x8, [x8]               | X8 = typeof(UnityEngine.Object);        
        // 0x00B8E6E8: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Object.__il2cppRuntimeField_10A;
        // 0x00B8E6EC: TBZ w9, #0, #0xb8e700      | if (UnityEngine.Object.__il2cppRuntimeField_has_cctor == 0) goto label_2;
        // 0x00B8E6F0: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Object.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E6F4: CBNZ w9, #0xb8e700         | if (UnityEngine.Object.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
        // 0x00B8E6F8: MOV x0, x8                 | X0 = 1152921504697475072 (0x100000000566E000);//ML01
        // 0x00B8E6FC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Object), ????);
        label_2:
        // 0x00B8E700: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8E704: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E708: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B8E70C: MOV x1, x19                | X1 = val_1;//m1                         
        // 0x00B8E710: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x00B8E714: B #0x1b78acc               | UnityEngine.Object.Destroy(obj:  0); return;
        UnityEngine.Object.Destroy(obj:  0);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E718 (12117784), len: 8  VirtAddr: 0x00B8E718 RVA: 0x00B8E718 token: 100682702 methodIndex: 25115 delegateWrapperIndex: 0 methodInvoker: 0
    private void Update()
    {
        //
        // Disasemble & Code
        // 0x00B8E718: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
        // 0x00B8E71C: B #0xb8e720                | this.Move(progress:  false); return;    
        this.Move(progress:  false);
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8EA2C (12118572), len: 2424  VirtAddr: 0x00B8EA2C RVA: 0x00B8EA2C token: 100682703 methodIndex: 25116 delegateWrapperIndex: 0 methodInvoker: 0
    private UnityEngine.Vector3 Plot(float t)
    {
        //
        // Disasemble & Code
        // 0x00B8EA2C: STP d15, d14, [sp, #-0x90]! | stack[1152921513301218816] = ???;  stack[1152921513301218824] = ???;  //  dest_result_addr=1152921513301218816 |  dest_result_addr=1152921513301218824
        // 0x00B8EA30: STP d13, d12, [sp, #0x10]  | stack[1152921513301218832] = ???;  stack[1152921513301218840] = ???;  //  dest_result_addr=1152921513301218832 |  dest_result_addr=1152921513301218840
        // 0x00B8EA34: STP d11, d10, [sp, #0x20]  | stack[1152921513301218848] = ???;  stack[1152921513301218856] = ???;  //  dest_result_addr=1152921513301218848 |  dest_result_addr=1152921513301218856
        // 0x00B8EA38: STP d9, d8, [sp, #0x30]    | stack[1152921513301218864] = ???;  stack[1152921513301218872] = ???;  //  dest_result_addr=1152921513301218864 |  dest_result_addr=1152921513301218872
        // 0x00B8EA3C: STP x26, x25, [sp, #0x40]  | stack[1152921513301218880] = ???;  stack[1152921513301218888] = ???;  //  dest_result_addr=1152921513301218880 |  dest_result_addr=1152921513301218888
        // 0x00B8EA40: STP x24, x23, [sp, #0x50]  | stack[1152921513301218896] = ???;  stack[1152921513301218904] = ???;  //  dest_result_addr=1152921513301218896 |  dest_result_addr=1152921513301218904
        // 0x00B8EA44: STP x22, x21, [sp, #0x60]  | stack[1152921513301218912] = ???;  stack[1152921513301218920] = ???;  //  dest_result_addr=1152921513301218912 |  dest_result_addr=1152921513301218920
        // 0x00B8EA48: STP x20, x19, [sp, #0x70]  | stack[1152921513301218928] = ???;  stack[1152921513301218936] = ???;  //  dest_result_addr=1152921513301218928 |  dest_result_addr=1152921513301218936
        // 0x00B8EA4C: STP x29, x30, [sp, #0x80]  | stack[1152921513301218944] = ???;  stack[1152921513301218952] = ???;  //  dest_result_addr=1152921513301218944 |  dest_result_addr=1152921513301218952
        // 0x00B8EA50: ADD x29, sp, #0x80         | X29 = (1152921513301218816 + 128) = 1152921513301218944 (0x1000000206399680);
        // 0x00B8EA54: SUB sp, sp, #0xb0          | SP = (1152921513301218816 - 176) = 1152921513301218640 (0x1000000206399550);
        // 0x00B8EA58: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8EA5C: LDRB w8, [x20, #0xa2b]     | W8 = (bool)static_value_03733A2B;       
        // 0x00B8EA60: MOV v8.16b, v0.16b         | V8 = t;//m1                             
        // 0x00B8EA64: MOV x19, x0                | X19 = 1152921513301230960 (0x100000020639C570);//ML01
        // 0x00B8EA68: TBNZ w8, #0, #0xb8ea84     | if (static_value_03733A2B == true) goto label_0;
        // 0x00B8EA6C: ADRP x8, #0x35f6000        | X8 = 56582144 (0x35F6000);              
        // 0x00B8EA70: LDR x8, [x8, #0x938]       | X8 = 0x2B8F36C;                         
        // 0x00B8EA74: LDR w0, [x8]               | W0 = 0x139D;                            
        // 0x00B8EA78: BL #0x2782188              | X0 = sub_2782188( ?? 0x139D, ????);     
        // 0x00B8EA7C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8EA80: STRB w8, [x20, #0xa2b]     | static_value_03733A2B = true;            //  dest_result_addr=57883179
        label_0:
        // 0x00B8EA84: STUR wzr, [x29, #-0x88]    | stack[1152921513301218808] = 0x0;        //  dest_result_addr=1152921513301218808
        // 0x00B8EA88: STUR xzr, [x29, #-0x90]    | stack[1152921513301218800] = 0x0;        //  dest_result_addr=1152921513301218800
        // 0x00B8EA8C: STR wzr, [sp, #0x98]       | stack[1152921513301218792] = 0x0;        //  dest_result_addr=1152921513301218792
        // 0x00B8EA90: STR xzr, [sp, #0x90]       | stack[1152921513301218784] = 0x0;        //  dest_result_addr=1152921513301218784
        // 0x00B8EA94: STR wzr, [sp, #0x88]       | stack[1152921513301218776] = 0x0;        //  dest_result_addr=1152921513301218776
        // 0x00B8EA98: STR xzr, [sp, #0x80]       | stack[1152921513301218768] = 0x0;        //  dest_result_addr=1152921513301218768
        // 0x00B8EA9C: STR wzr, [sp, #0x78]       | stack[1152921513301218760] = 0x0;        //  dest_result_addr=1152921513301218760
        // 0x00B8EAA0: STR xzr, [sp, #0x70]       | stack[1152921513301218752] = 0x0;        //  dest_result_addr=1152921513301218752
        // 0x00B8EAA4: STR wzr, [sp, #0x68]       | stack[1152921513301218744] = 0x0;        //  dest_result_addr=1152921513301218744
        // 0x00B8EAA8: STR xzr, [sp, #0x60]       | stack[1152921513301218736] = 0x0;        //  dest_result_addr=1152921513301218736
        // 0x00B8EAAC: STR wzr, [sp, #0x58]       | stack[1152921513301218728] = 0x0;        //  dest_result_addr=1152921513301218728
        // 0x00B8EAB0: STR xzr, [sp, #0x50]       | stack[1152921513301218720] = 0x0;        //  dest_result_addr=1152921513301218720
        // 0x00B8EAB4: LDR x20, [x19, #0x18]      | X20 = this.points; //P2                 
        // 0x00B8EAB8: CBNZ x20, #0xb8eac0        | if (this.points != null) goto label_1;  
        if(this.points != null)
        {
            goto label_1;
        }
        // 0x00B8EABC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x139D, ????);     
        label_1:
        // 0x00B8EAC0: ADRP x8, #0x363f000        | X8 = 56881152 (0x363F000);              
        // 0x00B8EAC4: LDR x8, [x8, #0x3b0]       | X8 = 1152921504695345152;               
        // 0x00B8EAC8: LDR w24, [x20, #0x18]      | W24 = this.points.Length; //P2          
        // 0x00B8EACC: LDR x0, [x8]               | X0 = typeof(UnityEngine.Mathf);         
        // 0x00B8EAD0: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Mathf.__il2cppRuntimeField_10A;
        // 0x00B8EAD4: TBZ w8, #0, #0xb8eae4      | if (UnityEngine.Mathf.__il2cppRuntimeField_has_cctor == 0) goto label_3;
        // 0x00B8EAD8: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished;
        // 0x00B8EADC: CBNZ w8, #0xb8eae4         | if (UnityEngine.Mathf.__il2cppRuntimeField_cctor_finished != 0) goto label_3;
        // 0x00B8EAE0: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Mathf), ????);
        label_3:
        // 0x00B8EAE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EAE8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EAEC: MOV v0.16b, v8.16b         | V0 = t;//m1                             
        // 0x00B8EAF0: BL #0x1a7dc18              | X0 = UnityEngine.Mathf.FloorToInt(f:  t);
        int val_1 = UnityEngine.Mathf.FloorToInt(f:  t);
        // 0x00B8EAF4: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EAF8: MOV w20, w0                | W20 = val_1;//m1                        
        // 0x00B8EAFC: CBNZ x21, #0xb8eb04        | if (this.points != null) goto label_4;  
        if(this.points != null)
        {
            goto label_4;
        }
        // 0x00B8EB00: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_4:
        // 0x00B8EB04: ADD w8, w20, #1            | W8 = (val_1 + 1);                       
        int val_2 = val_1 + 1;
        // 0x00B8EB08: LDR w9, [x21, #0x18]       | W9 = this.points.Length; //P2           
        // 0x00B8EB0C: SDIV w10, w8, w24          | W10 = ((val_1 + 1) / this.points.Length);
        int val_3 = val_2 / this.points.Length;
        // 0x00B8EB10: MSUB w8, w10, w24, w8      | W8 = (val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length);
        val_2 = val_2 - (val_3 * this.points.Length);
        // 0x00B8EB14: SXTW x22, w8               | X22 = (long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length));
        // 0x00B8EB18: CMP w8, w9                 | STATE = COMPARE((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length), this.points.Length)
        // 0x00B8EB1C: B.LO #0xb8eb2c             | if (val_2 < this.points.Length) goto label_5;
        if(val_2 < this.points.Length)
        {
            goto label_5;
        }
        // 0x00B8EB20: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? val_1, ????);      
        // 0x00B8EB24: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EB28: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? val_1, ????);      
        label_5:
        // 0x00B8EB2C: ADD x8, x21, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EB30: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_44 = this.points[(long)val_2];
        // 0x00B8EB34: STR s8, [sp, #0x38]        | stack[1152921513301218696] = t;          //  dest_result_addr=1152921513301218696
        // 0x00B8EB38: CBNZ x21, #0xb8eb40        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_6;
        if(val_44 != null)
        {
            goto label_6;
        }
        // 0x00B8EB3C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
        label_6:
        // 0x00B8EB40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EB44: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EB48: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_4 = val_44.position;
        // 0x00B8EB4C: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EB50: MOV v8.16b, v0.16b         | V8 = val_4.x;//m1                       
        // 0x00B8EB54: MOV v9.16b, v1.16b         | V9 = val_4.y;//m1                       
        // 0x00B8EB58: MOV v10.16b, v2.16b        | V10 = val_4.z;//m1                      
        // 0x00B8EB5C: CBNZ x21, #0xb8eb64        | if (this.points != null) goto label_7;  
        if(this.points != null)
        {
            goto label_7;
        }
        // 0x00B8EB60: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0], ????);
        label_7:
        // 0x00B8EB64: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8EB68: SDIV w9, w20, w24          | W9 = (val_1 / this.points.Length);      
        int val_5 = val_1 / this.points.Length;
        // 0x00B8EB6C: MSUB w9, w9, w24, w20      | W9 = val_1 - ((val_1 / this.points.Length) * this.points.Length);
        val_5 = val_1 - (val_5 * this.points.Length);
        // 0x00B8EB70: SXTW x23, w9               | X23 = (long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length));
        // 0x00B8EB74: CMP w9, w8                 | STATE = COMPARE(val_1 - ((val_1 / this.points.Length) * this.points.Length), this.points.Length)
        // 0x00B8EB78: B.LO #0xb8eb88             | if (val_5 < this.points.Length) goto label_8;
        if(val_5 < this.points.Length)
        {
            goto label_8;
        }
        // 0x00B8EB7C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0], ????);
        // 0x00B8EB80: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EB84: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0], ????);
        label_8:
        // 0x00B8EB88: ADD x8, x21, x23, lsl #3   | X8 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EB8C: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_45 = this.points[(long)val_5];
        // 0x00B8EB90: CBNZ x21, #0xb8eb98        | if (this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0] != null) goto label_9;
        if(val_45 != null)
        {
            goto label_9;
        }
        // 0x00B8EB94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0], ????);
        label_9:
        // 0x00B8EB98: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EB9C: MOV x0, x21                | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EBA0: BL #0x2693510              | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_6 = val_45.position;
        // 0x00B8EBA4: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8EBA8: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B8EBAC: MOV v11.16b, v0.16b        | V11 = val_6.x;//m1                      
        // 0x00B8EBB0: MOV v12.16b, v1.16b        | V12 = val_6.y;//m1                      
        // 0x00B8EBB4: MOV v13.16b, v2.16b        | V13 = val_6.z;//m1                      
        // 0x00B8EBB8: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8EBBC: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8EBC0: TBZ w8, #0, #0xb8ebd0      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B8EBC4: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8EBC8: CBNZ w8, #0xb8ebd0         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B8EBCC: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_11:
        // 0x00B8EBD0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EBD4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EBD8: MOV v0.16b, v8.16b         | V0 = val_4.x;//m1                       
        // 0x00B8EBDC: MOV v1.16b, v9.16b         | V1 = val_4.y;//m1                       
        // 0x00B8EBE0: MOV v2.16b, v10.16b        | V2 = val_4.z;//m1                       
        // 0x00B8EBE4: MOV v3.16b, v11.16b        | V3 = val_6.x;//m1                       
        // 0x00B8EBE8: MOV v4.16b, v12.16b        | V4 = val_6.y;//m1                       
        // 0x00B8EBEC: MOV v5.16b, v13.16b        | V5 = val_6.z;//m1                       
        // 0x00B8EBF0: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        UnityEngine.Vector3 val_7 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z}, b:  new UnityEngine.Vector3() {x = val_6.x, y = val_6.y, z = val_6.z});
        // 0x00B8EBF4: SUB x0, x29, #0x90         | X0 = (1152921513301218944 - 144) = 1152921513301218800 (0x10000002063995F0);
        // 0x00B8EBF8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EBFC: STP s0, s1, [x29, #-0x90]  | stack[1152921513301218800] = val_7.x;  stack[1152921513301218804] = val_7.y;  //  dest_result_addr=1152921513301218800 |  dest_result_addr=1152921513301218804
        // 0x00B8EC00: STUR s2, [x29, #-0x88]     | stack[1152921513301218808] = val_7.z;    //  dest_result_addr=1152921513301218808
        // 0x00B8EC04: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B8EC08: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EC0C: MOV v8.16b, v0.16b         | V8 = val_7.x;//m1                       
        // 0x00B8EC10: MOV v9.16b, v1.16b         | V9 = val_7.y;//m1                       
        // 0x00B8EC14: MOV v10.16b, v2.16b        | V10 = val_7.z;//m1                      
        // 0x00B8EC18: CBNZ x21, #0xb8ec20        | if (this.points != null) goto label_12; 
        if(this.points != null)
        {
            goto label_12;
        }
        // 0x00B8EC1C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995F0, ????);
        label_12:
        // 0x00B8EC20: ADD w8, w24, w20           | W8 = (this.points.Length + val_1);      
        int val_8 = this.points.Length + val_1;
        // 0x00B8EC24: LDR w9, [x21, #0x18]       | W9 = this.points.Length; //P2           
        // 0x00B8EC28: SUB w8, w8, #1             | W8 = ((this.points.Length + val_1) - 1);
        val_8 = val_8 - 1;
        // 0x00B8EC2C: SDIV w10, w8, w24          | W10 = (((this.points.Length + val_1) - 1) / this.points.Length);
        int val_9 = val_8 / this.points.Length;
        // 0x00B8EC30: MSUB w8, w10, w24, w8      | W8 = ((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length)
        val_8 = val_8 - (val_9 * this.points.Length);
        // 0x00B8EC34: SXTW x25, w8               | X25 = (long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length));
        // 0x00B8EC38: CMP w8, w9                 | STATE = COMPARE(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length), this.points.Length)
        // 0x00B8EC3C: B.LO #0xb8ec4c             | if (val_8 < this.points.Length) goto label_13;
        if(val_8 < this.points.Length)
        {
            goto label_13;
        }
        // 0x00B8EC40: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000002063995F0, ????);
        // 0x00B8EC44: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EC48: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002063995F0, ????);
        label_13:
        // 0x00B8EC4C: ADD x8, x21, x25, lsl #3   | X8 = this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EC50: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_46 = this.points[(long)val_8];
        // 0x00B8EC54: CBNZ x21, #0xb8ec5c        | if (this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0] != null) goto label_14;
        if(val_46 != null)
        {
            goto label_14;
        }
        // 0x00B8EC58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995F0, ????);
        label_14:
        // 0x00B8EC5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EC60: MOV x0, x21                | X0 = this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EC64: BL #0x2693510              | X0 = this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_10 = val_46.position;
        // 0x00B8EC68: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EC6C: MOV v11.16b, v0.16b        | V11 = val_10.x;//m1                     
        // 0x00B8EC70: MOV v12.16b, v1.16b        | V12 = val_10.y;//m1                     
        // 0x00B8EC74: MOV v13.16b, v2.16b        | V13 = val_10.z;//m1                     
        // 0x00B8EC78: CBNZ x21, #0xb8ec80        | if (this.points != null) goto label_15; 
        if(this.points != null)
        {
            goto label_15;
        }
        // 0x00B8EC7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0], ????);
        label_15:
        // 0x00B8EC80: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8EC84: CMP w23, w8                | STATE = COMPARE((long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8EC88: B.LO #0xb8ec98             | if ((long)val_5 < this.points.Length) goto label_16;
        if((long)val_5 < this.points.Length)
        {
            goto label_16;
        }
        // 0x00B8EC8C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0], ????);
        // 0x00B8EC90: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EC94: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0], ????);
        label_16:
        // 0x00B8EC98: ADD x8, x21, x23, lsl #3   | X8 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EC9C: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_47 = this.points[(long)val_5];
        // 0x00B8ECA0: CBNZ x21, #0xb8eca8        | if (this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0] != null) goto label_17;
        if(val_47 != null)
        {
            goto label_17;
        }
        // 0x00B8ECA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)(((this.points.Length + val_1) - 1) - ((((this.points.Length + val_1) - 1) / this.points.Length) * this.points.Length))][0], ????);
        label_17:
        // 0x00B8ECA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ECAC: MOV x0, x21                | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8ECB0: BL #0x2693510              | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_11 = val_47.position;
        // 0x00B8ECB4: MOV v3.16b, v0.16b         | V3 = val_11.x;//m1                      
        // 0x00B8ECB8: MOV v4.16b, v1.16b         | V4 = val_11.y;//m1                      
        // 0x00B8ECBC: MOV v5.16b, v2.16b         | V5 = val_11.z;//m1                      
        // 0x00B8ECC0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8ECC4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ECC8: MOV v0.16b, v11.16b        | V0 = val_10.x;//m1                      
        // 0x00B8ECCC: MOV v1.16b, v12.16b        | V1 = val_10.y;//m1                      
        // 0x00B8ECD0: MOV v2.16b, v13.16b        | V2 = val_10.z;//m1                      
        // 0x00B8ECD4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_10.x, y = val_10.y, z = val_10.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        // 0x00B8ECD8: ADD x0, sp, #0x90          | X0 = (1152921513301218640 + 144) = 1152921513301218784 (0x10000002063995E0);
        // 0x00B8ECDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ECE0: STP s0, s1, [sp, #0x90]    | stack[1152921513301218784] = val_12.x;  stack[1152921513301218788] = val_12.y;  //  dest_result_addr=1152921513301218784 |  dest_result_addr=1152921513301218788
        // 0x00B8ECE4: STR s2, [sp, #0x98]        | stack[1152921513301218792] = val_12.z;   //  dest_result_addr=1152921513301218792
        // 0x00B8ECE8: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B8ECEC: MOV v3.16b, v0.16b         | V3 = val_12.x;//m1                      
        // 0x00B8ECF0: MOV v4.16b, v1.16b         | V4 = val_12.y;//m1                      
        // 0x00B8ECF4: MOV v5.16b, v2.16b         | V5 = val_12.z;//m1                      
        // 0x00B8ECF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8ECFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ED00: MOV v0.16b, v8.16b         | V0 = val_7.x;//m1                       
        // 0x00B8ED04: MOV v1.16b, v9.16b         | V1 = val_7.y;//m1                       
        // 0x00B8ED08: MOV v2.16b, v10.16b        | V2 = val_7.z;//m1                       
        // 0x00B8ED0C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z});
        UnityEngine.Vector3 val_13 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_7.x, y = val_7.y, z = val_7.z}, b:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z});
        // 0x00B8ED10: ADD x0, sp, #0x80          | X0 = (1152921513301218640 + 128) = 1152921513301218768 (0x10000002063995D0);
        // 0x00B8ED14: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ED18: STP s0, s1, [sp, #0x80]    | stack[1152921513301218768] = val_13.x;  stack[1152921513301218772] = val_13.y;  //  dest_result_addr=1152921513301218768 |  dest_result_addr=1152921513301218772
        // 0x00B8ED1C: STR s2, [sp, #0x88]        | stack[1152921513301218776] = val_13.z;   //  dest_result_addr=1152921513301218776
        // 0x00B8ED20: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B8ED24: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8ED28: MOV v11.16b, v0.16b        | V11 = val_13.x;//m1                     
        // 0x00B8ED2C: STR s1, [sp, #0x4c]        | stack[1152921513301218716] = val_13.y;   //  dest_result_addr=1152921513301218716
        // 0x00B8ED30: STR s2, [sp, #0x48]        | stack[1152921513301218712] = val_13.z;   //  dest_result_addr=1152921513301218712
        // 0x00B8ED34: CBNZ x21, #0xb8ed3c        | if (this.points != null) goto label_18; 
        if(this.points != null)
        {
            goto label_18;
        }
        // 0x00B8ED38: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995D0, ????);
        label_18:
        // 0x00B8ED3C: ADD w8, w20, #2            | W8 = (val_1 + 2);                       
        int val_14 = val_1 + 2;
        // 0x00B8ED40: LDR w9, [x21, #0x18]       | W9 = this.points.Length; //P2           
        // 0x00B8ED44: SDIV w10, w8, w24          | W10 = ((val_1 + 2) / this.points.Length);
        int val_15 = val_14 / this.points.Length;
        // 0x00B8ED48: MSUB w8, w10, w24, w8      | W8 = (val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length);
        val_14 = val_14 - (val_15 * this.points.Length);
        // 0x00B8ED4C: SXTW x25, w8               | X25 = (long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length));
        // 0x00B8ED50: CMP w8, w9                 | STATE = COMPARE((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length), this.points.Length)
        // 0x00B8ED54: B.LO #0xb8ed64             | if (val_14 < this.points.Length) goto label_19;
        if(val_14 < this.points.Length)
        {
            goto label_19;
        }
        // 0x00B8ED58: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000002063995D0, ????);
        // 0x00B8ED5C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ED60: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002063995D0, ????);
        label_19:
        // 0x00B8ED64: ADD x8, x21, x25, lsl #3   | X8 = this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8ED68: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_48 = this.points[(long)val_14];
        // 0x00B8ED6C: CBNZ x21, #0xb8ed74        | if (this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0] != null) goto label_20;
        if(val_48 != null)
        {
            goto label_20;
        }
        // 0x00B8ED70: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995D0, ????);
        label_20:
        // 0x00B8ED74: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8ED78: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8ED7C: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_16 = val_48.position;
        // 0x00B8ED80: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8ED84: MOV v8.16b, v0.16b         | V8 = val_16.x;//m1                      
        // 0x00B8ED88: MOV v9.16b, v1.16b         | V9 = val_16.y;//m1                      
        // 0x00B8ED8C: MOV v12.16b, v2.16b        | V12 = val_16.z;//m1                     
        // 0x00B8ED90: CBNZ x21, #0xb8ed98        | if (this.points != null) goto label_21; 
        if(this.points != null)
        {
            goto label_21;
        }
        // 0x00B8ED94: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0], ????);
        label_21:
        // 0x00B8ED98: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8ED9C: CMP w22, w8                | STATE = COMPARE((long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8EDA0: B.LO #0xb8edb0             | if ((long)val_2 < this.points.Length) goto label_22;
        if((long)val_2 < this.points.Length)
        {
            goto label_22;
        }
        // 0x00B8EDA4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0], ????);
        // 0x00B8EDA8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EDAC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0], ????);
        label_22:
        // 0x00B8EDB0: ADD x8, x21, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EDB4: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_49 = this.points[(long)val_2];
        // 0x00B8EDB8: CBNZ x21, #0xb8edc0        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_23;
        if(val_49 != null)
        {
            goto label_23;
        }
        // 0x00B8EDBC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)((val_1 + 2) - (((val_1 + 2) / this.points.Length) * this.points.Length))][0], ????);
        label_23:
        // 0x00B8EDC0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EDC4: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EDC8: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_17 = val_49.position;
        // 0x00B8EDCC: MOV v3.16b, v0.16b         | V3 = val_17.x;//m1                      
        // 0x00B8EDD0: MOV v4.16b, v1.16b         | V4 = val_17.y;//m1                      
        // 0x00B8EDD4: MOV v5.16b, v2.16b         | V5 = val_17.z;//m1                      
        // 0x00B8EDD8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EDDC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EDE0: MOV v0.16b, v8.16b         | V0 = val_16.x;//m1                      
        // 0x00B8EDE4: MOV v1.16b, v9.16b         | V1 = val_16.y;//m1                      
        // 0x00B8EDE8: MOV v2.16b, v12.16b        | V2 = val_16.z;//m1                      
        // 0x00B8EDEC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_17.x, y = val_17.y, z = val_17.z});
        // 0x00B8EDF0: ADD x0, sp, #0x70          | X0 = (1152921513301218640 + 112) = 1152921513301218752 (0x10000002063995C0);
        // 0x00B8EDF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EDF8: STP s0, s1, [sp, #0x70]    | stack[1152921513301218752] = val_18.x;  stack[1152921513301218756] = val_18.y;  //  dest_result_addr=1152921513301218752 |  dest_result_addr=1152921513301218756
        // 0x00B8EDFC: STR s2, [sp, #0x78]        | stack[1152921513301218760] = val_18.z;   //  dest_result_addr=1152921513301218760
        // 0x00B8EE00: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B8EE04: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EE08: MOV v8.16b, v0.16b         | V8 = val_18.x;//m1                      
        // 0x00B8EE0C: MOV v9.16b, v1.16b         | V9 = val_18.y;//m1                      
        // 0x00B8EE10: MOV v12.16b, v2.16b        | V12 = val_18.z;//m1                     
        // 0x00B8EE14: CBNZ x21, #0xb8ee1c        | if (this.points != null) goto label_24; 
        if(this.points != null)
        {
            goto label_24;
        }
        // 0x00B8EE18: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995C0, ????);
        label_24:
        // 0x00B8EE1C: ADD w8, w20, w24           | W8 = (val_1 + this.points.Length);      
        int val_19 = val_1 + this.points.Length;
        // 0x00B8EE20: LDR w9, [x21, #0x18]       | W9 = this.points.Length; //P2           
        // 0x00B8EE24: SDIV w10, w8, w24          | W10 = ((val_1 + this.points.Length) / this.points.Length);
        int val_20 = val_19 / this.points.Length;
        // 0x00B8EE28: MSUB w8, w10, w24, w8      | W8 = (val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.poin
        val_19 = val_19 - (val_20 * this.points.Length);
        // 0x00B8EE2C: SXTW x24, w8               | X24 = (long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length));
        // 0x00B8EE30: CMP w8, w9                 | STATE = COMPARE((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length), this.points.Length)
        // 0x00B8EE34: B.LO #0xb8ee44             | if (val_19 < this.points.Length) goto label_25;
        if(val_19 < this.points.Length)
        {
            goto label_25;
        }
        // 0x00B8EE38: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000002063995C0, ????);
        // 0x00B8EE3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EE40: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002063995C0, ????);
        label_25:
        // 0x00B8EE44: ADD x8, x21, x24, lsl #3   | X8 = this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EE48: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_50 = this.points[(long)val_19];
        // 0x00B8EE4C: CBNZ x21, #0xb8ee54        | if (this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0] != null) goto label_26;
        if(val_50 != null)
        {
            goto label_26;
        }
        // 0x00B8EE50: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995C0, ????);
        label_26:
        // 0x00B8EE54: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EE58: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EE5C: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_21 = val_50.position;
        // 0x00B8EE60: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EE64: MOV v13.16b, v0.16b        | V13 = val_21.x;//m1                     
        // 0x00B8EE68: MOV v14.16b, v1.16b        | V14 = val_21.y;//m1                     
        // 0x00B8EE6C: MOV v15.16b, v2.16b        | V15 = val_21.z;//m1                     
        // 0x00B8EE70: CBNZ x21, #0xb8ee78        | if (this.points != null) goto label_27; 
        if(this.points != null)
        {
            goto label_27;
        }
        // 0x00B8EE74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0], ????);
        label_27:
        // 0x00B8EE78: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8EE7C: CMP w22, w8                | STATE = COMPARE((long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8EE80: B.LO #0xb8ee90             | if ((long)val_2 < this.points.Length) goto label_28;
        if((long)val_2 < this.points.Length)
        {
            goto label_28;
        }
        // 0x00B8EE84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0], ????);
        // 0x00B8EE88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EE8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0], ????);
        label_28:
        // 0x00B8EE90: ADD x8, x21, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EE94: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_51 = this.points[(long)val_2];
        // 0x00B8EE98: CBNZ x21, #0xb8eea0        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_29;
        if(val_51 != null)
        {
            goto label_29;
        }
        // 0x00B8EE9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)((val_1 + this.points.Length) - (((val_1 + this.points.Length) / this.points.Length) * this.points.Length))][0], ????);
        label_29:
        // 0x00B8EEA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EEA4: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EEA8: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_22 = val_51.position;
        // 0x00B8EEAC: MOV v3.16b, v0.16b         | V3 = val_22.x;//m1                      
        // 0x00B8EEB0: MOV v4.16b, v1.16b         | V4 = val_22.y;//m1                      
        // 0x00B8EEB4: MOV v5.16b, v2.16b         | V5 = val_22.z;//m1                      
        // 0x00B8EEB8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EEBC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EEC0: MOV v0.16b, v13.16b        | V0 = val_21.x;//m1                      
        // 0x00B8EEC4: MOV v1.16b, v14.16b        | V1 = val_21.y;//m1                      
        // 0x00B8EEC8: MOV v2.16b, v15.16b        | V2 = val_21.z;//m1                      
        // 0x00B8EECC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z}, b:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z});
        UnityEngine.Vector3 val_23 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_21.x, y = val_21.y, z = val_21.z}, b:  new UnityEngine.Vector3() {x = val_22.x, y = val_22.y, z = val_22.z});
        // 0x00B8EED0: ADD x0, sp, #0x60          | X0 = (1152921513301218640 + 96) = 1152921513301218736 (0x10000002063995B0);
        // 0x00B8EED4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EED8: STP s0, s1, [sp, #0x60]    | stack[1152921513301218736] = val_23.x;  stack[1152921513301218740] = val_23.y;  //  dest_result_addr=1152921513301218736 |  dest_result_addr=1152921513301218740
        // 0x00B8EEDC: STR s2, [sp, #0x68]        | stack[1152921513301218744] = val_23.z;   //  dest_result_addr=1152921513301218744
        // 0x00B8EEE0: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B8EEE4: MOV v3.16b, v0.16b         | V3 = val_23.x;//m1                      
        // 0x00B8EEE8: MOV v4.16b, v1.16b         | V4 = val_23.y;//m1                      
        // 0x00B8EEEC: MOV v5.16b, v2.16b         | V5 = val_23.z;//m1                      
        // 0x00B8EEF0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EEF4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EEF8: MOV v0.16b, v8.16b         | V0 = val_18.x;//m1                      
        // 0x00B8EEFC: MOV v1.16b, v9.16b         | V1 = val_18.y;//m1                      
        // 0x00B8EF00: MOV v2.16b, v12.16b        | V2 = val_18.z;//m1                      
        // 0x00B8EF04: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        UnityEngine.Vector3 val_24 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z}, b:  new UnityEngine.Vector3() {x = val_23.x, y = val_23.y, z = val_23.z});
        // 0x00B8EF08: ADD x0, sp, #0x50          | X0 = (1152921513301218640 + 80) = 1152921513301218720 (0x10000002063995A0);
        // 0x00B8EF0C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EF10: STP s0, s1, [sp, #0x50]    | stack[1152921513301218720] = val_24.x;  stack[1152921513301218724] = val_24.y;  //  dest_result_addr=1152921513301218720 |  dest_result_addr=1152921513301218724
        // 0x00B8EF14: STR s2, [sp, #0x58]        | stack[1152921513301218728] = val_24.z;   //  dest_result_addr=1152921513301218728
        // 0x00B8EF18: BL #0x2699d94              | X0 = label_UnityEngine_Vector3_Normalize_GL02699D94();
        // 0x00B8EF1C: STP s1, s0, [sp, #0x40]    | stack[1152921513301218704] = val_24.y;  stack[1152921513301218708] = val_24.x;  //  dest_result_addr=1152921513301218704 |  dest_result_addr=1152921513301218708
        // 0x00B8EF20: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EF24: STR s2, [sp, #0x3c]        | stack[1152921513301218700] = val_24.z;   //  dest_result_addr=1152921513301218700
        // 0x00B8EF28: CBNZ x21, #0xb8ef30        | if (this.points != null) goto label_30; 
        if(this.points != null)
        {
            goto label_30;
        }
        // 0x00B8EF2C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995A0, ????);
        label_30:
        // 0x00B8EF30: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8EF34: CMP w23, w8                | STATE = COMPARE((long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8EF38: B.LO #0xb8ef48             | if ((long)val_5 < this.points.Length) goto label_31;
        if((long)val_5 < this.points.Length)
        {
            goto label_31;
        }
        // 0x00B8EF3C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x10000002063995A0, ????);
        // 0x00B8EF40: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EF44: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x10000002063995A0, ????);
        label_31:
        // 0x00B8EF48: ADD x8, x21, x23, lsl #3   | X8 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EF4C: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_52 = this.points[(long)val_5];
        // 0x00B8EF50: CBNZ x21, #0xb8ef58        | if (this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0] != null) goto label_32;
        if(val_52 != null)
        {
            goto label_32;
        }
        // 0x00B8EF54: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x10000002063995A0, ????);
        label_32:
        // 0x00B8EF58: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EF5C: MOV x0, x21                | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EF60: BL #0x2693510              | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_25 = val_52.position;
        // 0x00B8EF64: STP s1, s0, [sp, #0x2c]    | stack[1152921513301218684] = val_25.y;  stack[1152921513301218688] = val_25.x;  //  dest_result_addr=1152921513301218684 |  dest_result_addr=1152921513301218688
        // 0x00B8EF68: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8EF6C: MOV v12.16b, v2.16b        | V12 = val_25.z;//m1                     
        // 0x00B8EF70: CBNZ x21, #0xb8ef78        | if (this.points != null) goto label_33; 
        if(this.points != null)
        {
            goto label_33;
        }
        // 0x00B8EF74: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        label_33:
        // 0x00B8EF78: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8EF7C: CMP w23, w8                | STATE = COMPARE((long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8EF80: B.LO #0xb8ef90             | if ((long)val_5 < this.points.Length) goto label_34;
        if((long)val_5 < this.points.Length)
        {
            goto label_34;
        }
        // 0x00B8EF84: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        // 0x00B8EF88: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EF8C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        label_34:
        // 0x00B8EF90: ADD x8, x21, x23, lsl #3   | X8 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8EF94: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_53 = this.points[(long)val_5];
        // 0x00B8EF98: CBNZ x21, #0xb8efa0        | if (this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0] != null) goto label_35;
        if(val_53 != null)
        {
            goto label_35;
        }
        // 0x00B8EF9C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        label_35:
        // 0x00B8EFA0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EFA4: MOV x0, x21                | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8EFA8: BL #0x2693510              | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_26 = val_53.position;
        // 0x00B8EFAC: MOV v9.16b, v1.16b         | V9 = val_26.y;//m1                      
        // 0x00B8EFB0: LDR s3, [x19, #0x20]       | S3 = this.tangentLengths; //P2          
        // 0x00B8EFB4: MOV v10.16b, v2.16b        | V10 = val_26.z;//m1                     
        // 0x00B8EFB8: STR s11, [sp, #0x34]       | stack[1152921513301218692] = val_13.x;   //  dest_result_addr=1152921513301218692
        // 0x00B8EFBC: LDP s2, s1, [sp, #0x48]    | S2 = val_13.z; S1 = val_13.y;            //  | 
        // 0x00B8EFC0: MOV v8.16b, v0.16b         | V8 = val_26.x;//m1                      
        // 0x00B8EFC4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EFC8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EFCC: MOV v0.16b, v11.16b        | V0 = val_13.x;//m1                      
        // 0x00B8EFD0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, d:  this.tangentLengths);
        UnityEngine.Vector3 val_27 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, d:  this.tangentLengths);
        // 0x00B8EFD4: MOV v3.16b, v0.16b         | V3 = val_27.x;//m1                      
        // 0x00B8EFD8: MOV v4.16b, v1.16b         | V4 = val_27.y;//m1                      
        // 0x00B8EFDC: MOV v5.16b, v2.16b         | V5 = val_27.z;//m1                      
        // 0x00B8EFE0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EFE4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8EFE8: MOV v0.16b, v8.16b         | V0 = val_26.x;//m1                      
        // 0x00B8EFEC: MOV v1.16b, v9.16b         | V1 = val_26.y;//m1                      
        // 0x00B8EFF0: MOV v2.16b, v10.16b        | V2 = val_26.z;//m1                      
        // 0x00B8EFF4: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z});
        UnityEngine.Vector3 val_28 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_26.x, y = val_26.y, z = val_26.z}, b:  new UnityEngine.Vector3() {x = val_27.x, y = val_27.y, z = val_27.z});
        // 0x00B8EFF8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8EFFC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F000: MOV v15.16b, v0.16b        | V15 = val_28.x;//m1                     
        // 0x00B8F004: MOV v10.16b, v1.16b        | V10 = val_28.y;//m1                     
        // 0x00B8F008: MOV v11.16b, v2.16b        | V11 = val_28.z;//m1                     
        // 0x00B8F00C: BL #0x20d3ba8              | X0 = UnityEngine.Color.get_red();       
        UnityEngine.Color val_29 = UnityEngine.Color.red;
        // 0x00B8F010: ADRP x8, #0x35f8000        | X8 = 56590336 (0x35F8000);              
        // 0x00B8F014: LDR x8, [x8, #0x130]       | X8 = 1152921504692469760;               
        // 0x00B8F018: MOV v13.16b, v0.16b        | V13 = val_29.r;//m1                     
        // 0x00B8F01C: MOV v14.16b, v1.16b        | V14 = val_29.g;//m1                     
        // 0x00B8F020: MOV v8.16b, v2.16b         | V8 = val_29.b;//m1                      
        // 0x00B8F024: LDR x0, [x8]               | X0 = typeof(UnityEngine.Debug);         
        // 0x00B8F028: MOV v9.16b, v3.16b         | V9 = val_29.a;//m1                      
        // 0x00B8F02C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Debug.__il2cppRuntimeField_10A;
        // 0x00B8F030: TBZ w8, #0, #0xb8f040      | if (UnityEngine.Debug.__il2cppRuntimeField_has_cctor == 0) goto label_37;
        // 0x00B8F034: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Debug.__il2cppRuntimeField_cctor_finished;
        // 0x00B8F038: CBNZ w8, #0xb8f040         | if (UnityEngine.Debug.__il2cppRuntimeField_cctor_finished != 0) goto label_37;
        // 0x00B8F03C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Debug), ????);
        label_37:
        // 0x00B8F040: STP s8, s9, [sp, #8]       | stack[1152921513301218648] = val_29.b;  stack[1152921513301218652] = val_29.a;  //  dest_result_addr=1152921513301218648 |  dest_result_addr=1152921513301218652
        // 0x00B8F044: STP s13, s14, [sp]         | stack[1152921513301218640] = val_29.r;  stack[1152921513301218644] = val_29.g;  //  dest_result_addr=1152921513301218640 |  dest_result_addr=1152921513301218644
        // 0x00B8F048: LDP s1, s0, [sp, #0x2c]    | S1 = val_25.y; S0 = val_25.x;            //  | 
        // 0x00B8F04C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F050: MOV v2.16b, v12.16b        | V2 = val_25.z;//m1                      
        // 0x00B8F054: MOV v3.16b, v15.16b        | V3 = val_28.x;//m1                      
        // 0x00B8F058: MOV v4.16b, v10.16b        | V4 = val_28.y;//m1                      
        // 0x00B8F05C: MOV v5.16b, v11.16b        | V5 = val_28.z;//m1                      
        // 0x00B8F060: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F064: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z}, end:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z}, color:  new UnityEngine.Color() {r = val_29.r, g = val_29.b});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_25.x, y = val_25.y, z = val_25.z}, end:  new UnityEngine.Vector3() {x = val_28.x, y = val_28.y, z = val_28.z}, color:  new UnityEngine.Color() {r = val_29.r, g = val_29.b});
        // 0x00B8F068: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8F06C: CBNZ x21, #0xb8f074        | if (this.points != null) goto label_38; 
        if(this.points != null)
        {
            goto label_38;
        }
        // 0x00B8F070: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_38:
        // 0x00B8F074: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8F078: CMP w22, w8                | STATE = COMPARE((long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8F07C: B.LO #0xb8f08c             | if ((long)val_2 < this.points.Length) goto label_39;
        if((long)val_2 < this.points.Length)
        {
            goto label_39;
        }
        // 0x00B8F080: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8F084: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F088: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_39:
        // 0x00B8F08C: ADD x8, x21, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8F090: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_54 = this.points[(long)val_2];
        // 0x00B8F094: CBNZ x21, #0xb8f09c        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_40;
        if(val_54 != null)
        {
            goto label_40;
        }
        // 0x00B8F098: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_40:
        // 0x00B8F09C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F0A0: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8F0A4: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_30 = val_54.position;
        // 0x00B8F0A8: MOV v8.16b, v0.16b         | V8 = val_30.x;//m1                      
        // 0x00B8F0AC: MOV v9.16b, v1.16b         | V9 = val_30.y;//m1                      
        // 0x00B8F0B0: LDR s3, [x19, #0x20]       | S3 = this.tangentLengths; //P2          
        // 0x00B8F0B4: MOV v10.16b, v2.16b        | V10 = val_30.z;//m1                     
        // 0x00B8F0B8: LDP s1, s0, [sp, #0x40]    | S1 = val_24.y; S0 = val_24.x;            //  | 
        // 0x00B8F0BC: LDR s2, [sp, #0x3c]        | S2 = val_24.z;                          
        // 0x00B8F0C0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F0C4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F0C8: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z}, d:  this.tangentLengths);
        UnityEngine.Vector3 val_31 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z}, d:  this.tangentLengths);
        // 0x00B8F0CC: MOV v3.16b, v0.16b         | V3 = val_31.x;//m1                      
        // 0x00B8F0D0: MOV v4.16b, v1.16b         | V4 = val_31.y;//m1                      
        // 0x00B8F0D4: MOV v5.16b, v2.16b         | V5 = val_31.z;//m1                      
        // 0x00B8F0D8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F0DC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F0E0: MOV v0.16b, v8.16b         | V0 = val_30.x;//m1                      
        // 0x00B8F0E4: MOV v1.16b, v9.16b         | V1 = val_30.y;//m1                      
        // 0x00B8F0E8: MOV v2.16b, v10.16b        | V2 = val_30.z;//m1                      
        // 0x00B8F0EC: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_30.x, y = val_30.y, z = val_30.z}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z});
        UnityEngine.Vector3 val_32 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_30.x, y = val_30.y, z = val_30.z}, b:  new UnityEngine.Vector3() {x = val_31.x, y = val_31.y, z = val_31.z});
        // 0x00B8F0F0: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8F0F4: MOV v8.16b, v0.16b         | V8 = val_32.x;//m1                      
        // 0x00B8F0F8: MOV v9.16b, v1.16b         | V9 = val_32.y;//m1                      
        // 0x00B8F0FC: MOV v12.16b, v2.16b        | V12 = val_32.z;//m1                     
        // 0x00B8F100: CBNZ x21, #0xb8f108        | if (this.points != null) goto label_41; 
        if(this.points != null)
        {
            goto label_41;
        }
        // 0x00B8F104: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_41:
        // 0x00B8F108: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8F10C: CMP w22, w8                | STATE = COMPARE((long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8F110: B.LO #0xb8f120             | if ((long)val_2 < this.points.Length) goto label_42;
        if((long)val_2 < this.points.Length)
        {
            goto label_42;
        }
        // 0x00B8F114: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8F118: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F11C: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_42:
        // 0x00B8F120: ADD x8, x21, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8F124: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_55 = this.points[(long)val_2];
        // 0x00B8F128: CBNZ x21, #0xb8f130        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_43;
        if(val_55 != null)
        {
            goto label_43;
        }
        // 0x00B8F12C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_43:
        // 0x00B8F130: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F134: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8F138: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_33 = val_55.position;
        // 0x00B8F13C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F140: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F144: MOV v10.16b, v0.16b        | V10 = val_33.x;//m1                     
        // 0x00B8F148: MOV v11.16b, v1.16b        | V11 = val_33.y;//m1                     
        // 0x00B8F14C: MOV v13.16b, v2.16b        | V13 = val_33.z;//m1                     
        // 0x00B8F150: BL #0x20d3bbc              | X0 = UnityEngine.Color.get_green();     
        UnityEngine.Color val_34 = UnityEngine.Color.green;
        // 0x00B8F154: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F158: STP s2, s3, [sp, #8]       | stack[1152921513301218648] = val_34.b;  stack[1152921513301218652] = val_34.a;  //  dest_result_addr=1152921513301218648 |  dest_result_addr=1152921513301218652
        // 0x00B8F15C: STP s0, s1, [sp]           | stack[1152921513301218640] = val_34.r;  stack[1152921513301218644] = val_34.g;  //  dest_result_addr=1152921513301218640 |  dest_result_addr=1152921513301218644
        // 0x00B8F160: MOV v0.16b, v8.16b         | V0 = val_32.x;//m1                      
        // 0x00B8F164: MOV v1.16b, v9.16b         | V1 = val_32.y;//m1                      
        // 0x00B8F168: MOV v2.16b, v12.16b        | V2 = val_32.z;//m1                      
        // 0x00B8F16C: MOV v3.16b, v10.16b        | V3 = val_33.x;//m1                      
        // 0x00B8F170: MOV v4.16b, v11.16b        | V4 = val_33.y;//m1                      
        // 0x00B8F174: MOV v5.16b, v13.16b        | V5 = val_33.z;//m1                      
        // 0x00B8F178: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F17C: BL #0x1a5cb54              | UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z}, end:  new UnityEngine.Vector3() {x = val_33.x, y = val_33.y, z = val_33.z}, color:  new UnityEngine.Color() {r = val_34.r, g = val_34.b});
        UnityEngine.Debug.DrawLine(start:  new UnityEngine.Vector3() {x = val_32.x, y = val_32.y, z = val_32.z}, end:  new UnityEngine.Vector3() {x = val_33.x, y = val_33.y, z = val_33.z}, color:  new UnityEngine.Color() {r = val_34.r, g = val_34.b});
        // 0x00B8F180: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8F184: CBNZ x21, #0xb8f18c        | if (this.points != null) goto label_44; 
        if(this.points != null)
        {
            goto label_44;
        }
        // 0x00B8F188: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_44:
        // 0x00B8F18C: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8F190: CMP w23, w8                | STATE = COMPARE((long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8F194: B.LO #0xb8f1a4             | if ((long)val_5 < this.points.Length) goto label_45;
        if((long)val_5 < this.points.Length)
        {
            goto label_45;
        }
        // 0x00B8F198: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8F19C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F1A0: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_45:
        // 0x00B8F1A4: ADD x8, x21, x23, lsl #3   | X8 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8F1A8: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_56 = this.points[(long)val_5];
        // 0x00B8F1AC: CBNZ x21, #0xb8f1b4        | if (this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0] != null) goto label_46;
        if(val_56 != null)
        {
            goto label_46;
        }
        // 0x00B8F1B0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_46:
        // 0x00B8F1B4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F1B8: MOV x0, x21                | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8F1BC: BL #0x2693510              | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_35 = val_56.position;
        // 0x00B8F1C0: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8F1C4: MOV v15.16b, v0.16b        | V15 = val_35.x;//m1                     
        // 0x00B8F1C8: MOV v9.16b, v2.16b         | V9 = val_35.z;//m1                      
        // 0x00B8F1CC: STR s1, [sp, #0x30]        | stack[1152921513301218688] = val_35.y;   //  dest_result_addr=1152921513301218688
        // 0x00B8F1D0: CBNZ x21, #0xb8f1d8        | if (this.points != null) goto label_47; 
        if(this.points != null)
        {
            goto label_47;
        }
        // 0x00B8F1D4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        label_47:
        // 0x00B8F1D8: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8F1DC: CMP w23, w8                | STATE = COMPARE((long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8F1E0: B.LO #0xb8f1f0             | if ((long)val_5 < this.points.Length) goto label_48;
        if((long)val_5 < this.points.Length)
        {
            goto label_48;
        }
        // 0x00B8F1E4: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        // 0x00B8F1E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F1EC: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        label_48:
        // 0x00B8F1F0: ADD x8, x21, x23, lsl #3   | X8 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8F1F4: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_57 = this.points[(long)val_5];
        // 0x00B8F1F8: CBNZ x21, #0xb8f200        | if (this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0] != null) goto label_49;
        if(val_57 != null)
        {
            goto label_49;
        }
        // 0x00B8F1FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0], ????);
        label_49:
        // 0x00B8F200: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F204: MOV x0, x21                | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8F208: BL #0x2693510              | X0 = this.points[(long)(int)(val_1 - ((val_1 / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_36 = val_57.position;
        // 0x00B8F20C: MOV v8.16b, v0.16b         | V8 = val_36.x;//m1                      
        // 0x00B8F210: MOV v10.16b, v1.16b        | V10 = val_36.y;//m1                     
        // 0x00B8F214: LDR s3, [x19, #0x20]       | S3 = this.tangentLengths; //P2          
        // 0x00B8F218: MOV v11.16b, v2.16b        | V11 = val_36.z;//m1                     
        // 0x00B8F21C: LDR s0, [sp, #0x34]        | S0 = val_13.x;                          
        // 0x00B8F220: LDP s2, s1, [sp, #0x48]    | S2 = val_13.z; S1 = val_13.y;            //  | 
        // 0x00B8F224: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F228: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F22C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, d:  this.tangentLengths);
        UnityEngine.Vector3 val_37 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_13.x, y = val_13.y, z = val_13.z}, d:  this.tangentLengths);
        // 0x00B8F230: MOV v3.16b, v0.16b         | V3 = val_37.x;//m1                      
        // 0x00B8F234: MOV v4.16b, v1.16b         | V4 = val_37.y;//m1                      
        // 0x00B8F238: MOV v5.16b, v2.16b         | V5 = val_37.z;//m1                      
        // 0x00B8F23C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F240: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F244: MOV v0.16b, v8.16b         | V0 = val_36.x;//m1                      
        // 0x00B8F248: MOV v1.16b, v10.16b        | V1 = val_36.y;//m1                      
        // 0x00B8F24C: MOV v2.16b, v11.16b        | V2 = val_36.z;//m1                      
        // 0x00B8F250: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z}, b:  new UnityEngine.Vector3() {x = val_37.x, y = val_37.y, z = val_37.z});
        UnityEngine.Vector3 val_38 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_36.x, y = val_36.y, z = val_36.z}, b:  new UnityEngine.Vector3() {x = val_37.x, y = val_37.y, z = val_37.z});
        // 0x00B8F254: LDR x21, [x19, #0x18]      | X21 = this.points; //P2                 
        // 0x00B8F258: MOV v10.16b, v0.16b        | V10 = val_38.x;//m1                     
        // 0x00B8F25C: MOV v11.16b, v1.16b        | V11 = val_38.y;//m1                     
        // 0x00B8F260: MOV v12.16b, v2.16b        | V12 = val_38.z;//m1                     
        // 0x00B8F264: CBNZ x21, #0xb8f26c        | if (this.points != null) goto label_50; 
        if(this.points != null)
        {
            goto label_50;
        }
        // 0x00B8F268: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_50:
        // 0x00B8F26C: LDR w8, [x21, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8F270: CMP w22, w8                | STATE = COMPARE((long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8F274: B.LO #0xb8f284             | if ((long)val_2 < this.points.Length) goto label_51;
        if((long)val_2 < this.points.Length)
        {
            goto label_51;
        }
        // 0x00B8F278: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8F27C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F280: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_51:
        // 0x00B8F284: ADD x8, x21, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8F288: LDR x21, [x8, #0x20]       | X21 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_58 = this.points[(long)val_2];
        // 0x00B8F28C: CBNZ x21, #0xb8f294        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_52;
        if(val_58 != null)
        {
            goto label_52;
        }
        // 0x00B8F290: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_52:
        // 0x00B8F294: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F298: MOV x0, x21                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8F29C: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_39 = val_58.position;
        // 0x00B8F2A0: MOV v8.16b, v0.16b         | V8 = val_39.x;//m1                      
        // 0x00B8F2A4: MOV v13.16b, v1.16b        | V13 = val_39.y;//m1                     
        // 0x00B8F2A8: LDR s3, [x19, #0x20]       | S3 = this.tangentLengths; //P2          
        // 0x00B8F2AC: MOV v14.16b, v2.16b        | V14 = val_39.z;//m1                     
        // 0x00B8F2B0: LDP s1, s0, [sp, #0x40]    | S1 = val_24.y; S0 = val_24.x;            //  | 
        // 0x00B8F2B4: LDR s2, [sp, #0x3c]        | S2 = val_24.z;                          
        // 0x00B8F2B8: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F2BC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F2C0: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z}, d:  this.tangentLengths);
        UnityEngine.Vector3 val_40 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = val_24.x, y = val_24.y, z = val_24.z}, d:  this.tangentLengths);
        // 0x00B8F2C4: MOV v3.16b, v0.16b         | V3 = val_40.x;//m1                      
        // 0x00B8F2C8: MOV v4.16b, v1.16b         | V4 = val_40.y;//m1                      
        // 0x00B8F2CC: MOV v5.16b, v2.16b         | V5 = val_40.z;//m1                      
        // 0x00B8F2D0: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F2D4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F2D8: MOV v0.16b, v8.16b         | V0 = val_39.x;//m1                      
        // 0x00B8F2DC: MOV v1.16b, v13.16b        | V1 = val_39.y;//m1                      
        // 0x00B8F2E0: MOV v2.16b, v14.16b        | V2 = val_39.z;//m1                      
        // 0x00B8F2E4: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_39.x, y = val_39.y, z = val_39.z}, b:  new UnityEngine.Vector3() {x = val_40.x, y = val_40.y, z = val_40.z});
        UnityEngine.Vector3 val_41 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_39.x, y = val_39.y, z = val_39.z}, b:  new UnityEngine.Vector3() {x = val_40.x, y = val_40.y, z = val_40.z});
        // 0x00B8F2E8: LDR x19, [x19, #0x18]      | X19 = this.points; //P2                 
        // 0x00B8F2EC: MOV v13.16b, v0.16b        | V13 = val_41.x;//m1                     
        // 0x00B8F2F0: MOV v14.16b, v1.16b        | V14 = val_41.y;//m1                     
        // 0x00B8F2F4: MOV v8.16b, v2.16b         | V8 = val_41.z;//m1                      
        // 0x00B8F2F8: CBNZ x19, #0xb8f300        | if (this.points != null) goto label_53; 
        if(this.points != null)
        {
            goto label_53;
        }
        // 0x00B8F2FC: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_53:
        // 0x00B8F300: LDR w8, [x19, #0x18]       | W8 = this.points.Length; //P2           
        // 0x00B8F304: CMP w22, w8                | STATE = COMPARE((long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length)), this.points.Length)
        // 0x00B8F308: B.LO #0xb8f318             | if ((long)val_2 < this.points.Length) goto label_54;
        if((long)val_2 < this.points.Length)
        {
            goto label_54;
        }
        // 0x00B8F30C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? 0x0, ????);        
        // 0x00B8F310: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F314: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? 0x0, ????);        
        label_54:
        // 0x00B8F318: ADD x8, x19, x22, lsl #3   | X8 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))]; //PARR1 
        // 0x00B8F31C: LDR x19, [x8, #0x20]       | X19 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0]
        UnityEngine.Transform val_59 = this.points[(long)val_2];
        // 0x00B8F320: CBNZ x19, #0xb8f328        | if (this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0] != null) goto label_55;
        if(val_59 != null)
        {
            goto label_55;
        }
        // 0x00B8F324: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_55:
        // 0x00B8F328: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F32C: MOV x0, x19                | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0];//m1
        // 0x00B8F330: BL #0x2693510              | X0 = this.points[(long)(int)((val_1 + 1) - (((val_1 + 1) / this.points.Length) * this.points.Length))][0].get_position();
        UnityEngine.Vector3 val_42 = val_59.position;
        // 0x00B8F334: LDR s4, [sp, #0x38]        | S4 = t;                                 
        // 0x00B8F338: SCVTF s3, w20              | S3 = (float)(val_1);                    
        float val_60 = (float)val_1;
        // 0x00B8F33C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8F340: MOV v5.16b, v12.16b        | V5 = val_38.z;//m1                      
        // 0x00B8F344: FSUB s3, s4, s3            | S3 = (t - val_1);                       
        val_60 = t - val_60;
        // 0x00B8F348: STR s3, [sp, #0x20]        | stack[1152921513301218672] = (t - val_1);  //  dest_result_addr=1152921513301218672
        // 0x00B8F34C: STP s1, s2, [sp, #0x14]    | stack[1152921513301218660] = val_42.y;  stack[1152921513301218664] = val_42.z;  //  dest_result_addr=1152921513301218660 |  dest_result_addr=1152921513301218664
        // 0x00B8F350: STR s0, [sp, #0x10]        | stack[1152921513301218656] = val_42.x;   //  dest_result_addr=1152921513301218656
        // 0x00B8F354: STP s14, s8, [sp, #4]      | stack[1152921513301218644] = val_41.y;  stack[1152921513301218648] = val_41.z;  //  dest_result_addr=1152921513301218644 |  dest_result_addr=1152921513301218648
        // 0x00B8F358: LDR s1, [sp, #0x30]        | S1 = val_35.y;                          
        // 0x00B8F35C: MOV v0.16b, v15.16b        | V0 = val_35.x;//m1                      
        // 0x00B8F360: MOV v2.16b, v9.16b         | V2 = val_35.z;//m1                      
        // 0x00B8F364: MOV v3.16b, v10.16b        | V3 = val_38.x;//m1                      
        // 0x00B8F368: MOV v4.16b, v11.16b        | V4 = val_38.y;//m1                      
        // 0x00B8F36C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8F370: STR s13, [sp]              | stack[1152921513301218640] = val_41.x;   //  dest_result_addr=1152921513301218640
        // 0x00B8F374: BL #0x16842f4              | X0 = Pathfinding.AstarMath.CubicBezier(p0:  new UnityEngine.Vector3() {x = val_35.x, y = val_35.y, z = val_35.z}, p1:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, p2:  new UnityEngine.Vector3() {x = val_41.x, y = val_41.z, z = val_42.x}, p3:  new UnityEngine.Vector3() {x = val_42.z, y = (float)val_1}, t:  val_35.y);
        UnityEngine.Vector3 val_43 = Pathfinding.AstarMath.CubicBezier(p0:  new UnityEngine.Vector3() {x = val_35.x, y = val_35.y, z = val_35.z}, p1:  new UnityEngine.Vector3() {x = val_38.x, y = val_38.y, z = val_38.z}, p2:  new UnityEngine.Vector3() {x = val_41.x, y = val_41.z, z = val_42.x}, p3:  new UnityEngine.Vector3() {x = val_42.z, y = val_60}, t:  val_35.y);
        // 0x00B8F378: SUB sp, x29, #0x80         | SP = (1152921513301218944 - 128) = 1152921513301218816 (0x1000000206399600);
        // 0x00B8F37C: LDP x29, x30, [sp, #0x80]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8F380: LDP x20, x19, [sp, #0x70]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8F384: LDP x22, x21, [sp, #0x60]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8F388: LDP x24, x23, [sp, #0x50]  | X24 = ; X23 = ;                          //  | 
        // 0x00B8F38C: LDP x26, x25, [sp, #0x40]  | X26 = ; X25 = ;                          //  | 
        // 0x00B8F390: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B8F394: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B8F398: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B8F39C: LDP d15, d14, [sp], #0x90  | D15 = ; D14 = ;                          //  | 
        // 0x00B8F3A0: RET                        |  return new UnityEngine.Vector3() {x = val_43.x, y = val_43.y, z = val_43.z};
        return new UnityEngine.Vector3() {x = val_43.x, y = val_43.y, z = val_43.z};
        //  |  // // {name=val_0.x, type=System.Single, size=4, nSRN=0 }
        //  |  // // {name=val_0.y, type=System.Single, size=4, nSRN=1 }
        //  |  // // {name=val_0.z, type=System.Single, size=4, nSRN=2 }
    
    }
    //
    // Offset in libil2cpp.so: 0x00B8E720 (12117792), len: 780  VirtAddr: 0x00B8E720 RVA: 0x00B8E720 token: 100682704 methodIndex: 25117 delegateWrapperIndex: 0 methodInvoker: 0
    private void Move(bool progress)
    {
        //
        // Disasemble & Code
        //  | 
        float val_20;
        //  | 
        float val_21;
        //  | 
        float val_22;
        // 0x00B8E720: STP d15, d14, [sp, #-0x70]! | stack[1152921513302035360] = ???;  stack[1152921513302035368] = ???;  //  dest_result_addr=1152921513302035360 |  dest_result_addr=1152921513302035368
        // 0x00B8E724: STP d13, d12, [sp, #0x10]  | stack[1152921513302035376] = ???;  stack[1152921513302035384] = ???;  //  dest_result_addr=1152921513302035376 |  dest_result_addr=1152921513302035384
        // 0x00B8E728: STP d11, d10, [sp, #0x20]  | stack[1152921513302035392] = ???;  stack[1152921513302035400] = ???;  //  dest_result_addr=1152921513302035392 |  dest_result_addr=1152921513302035400
        // 0x00B8E72C: STP d9, d8, [sp, #0x30]    | stack[1152921513302035408] = ???;  stack[1152921513302035416] = ???;  //  dest_result_addr=1152921513302035408 |  dest_result_addr=1152921513302035416
        // 0x00B8E730: STP x22, x21, [sp, #0x40]  | stack[1152921513302035424] = ???;  stack[1152921513302035432] = ???;  //  dest_result_addr=1152921513302035424 |  dest_result_addr=1152921513302035432
        // 0x00B8E734: STP x20, x19, [sp, #0x50]  | stack[1152921513302035440] = ???;  stack[1152921513302035448] = ???;  //  dest_result_addr=1152921513302035440 |  dest_result_addr=1152921513302035448
        // 0x00B8E738: STP x29, x30, [sp, #0x60]  | stack[1152921513302035456] = ???;  stack[1152921513302035464] = ???;  //  dest_result_addr=1152921513302035456 |  dest_result_addr=1152921513302035464
        // 0x00B8E73C: ADD x29, sp, #0x60         | X29 = (1152921513302035360 + 96) = 1152921513302035456 (0x1000000206460C00);
        // 0x00B8E740: SUB sp, sp, #0x20          | SP = (1152921513302035360 - 32) = 1152921513302035328 (0x1000000206460B80);
        // 0x00B8E744: ADRP x20, #0x3733000       | X20 = 57880576 (0x3733000);             
        // 0x00B8E748: LDRB w8, [x20, #0xa2c]     | W8 = (bool)static_value_03733A2C;       
        // 0x00B8E74C: MOV x19, x0                | X19 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E750: TBNZ w8, #0, #0xb8e76c     | if (static_value_03733A2C == true) goto label_0;
        // 0x00B8E754: ADRP x8, #0x3658000        | X8 = 56983552 (0x3658000);              
        // 0x00B8E758: LDR x8, [x8, #0xd30]       | X8 = 0x2B8F368;                         
        // 0x00B8E75C: LDR w0, [x8]               | W0 = 0x139C;                            
        // 0x00B8E760: BL #0x2782188              | X0 = sub_2782188( ?? 0x139C, ????);     
        // 0x00B8E764: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B8E768: STRB w8, [x20, #0xa2c]     | static_value_03733A2C = true;            //  dest_result_addr=57883180
        label_0:
        // 0x00B8E76C: STR wzr, [sp, #0x18]       | stack[1152921513302035352] = 0x0;        //  dest_result_addr=1152921513302035352
        // 0x00B8E770: STR xzr, [sp, #0x10]       | stack[1152921513302035344] = 0x0;        //  dest_result_addr=1152921513302035344
        // 0x00B8E774: LDR s4, [x19, #0x28]       | S4 = this.time; //P2                    
        // 0x00B8E778: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B8E77C: FMOV s0, #1.00000000       | S0 = 1;                                 
        float val_17 = 1f;
        // 0x00B8E780: LDR s3, [x8, #0x964]       | S3 = 0.0001;                            
        // 0x00B8E784: FADD s8, s4, s0            | S8 = (this.time + 1f);                  
        float val_1 = this.time + val_17;
        // 0x00B8E788: FMOV s2, #0.50000000       | S2 = 0.5;                               
        val_20 = 0.5f;
        // 0x00B8E78C: FADD s0, s8, s4            | S0 = ((this.time + 1f) + this.time);    
        val_17 = val_1 + this.time;
        // 0x00B8E790: FSUB s1, s8, s4            | S1 = ((this.time + 1f) - this.time);    
        val_21 = val_1 - this.time;
        // 0x00B8E794: FMUL s0, s0, s2            | S0 = (((this.time + 1f) + this.time) * val_20);
        val_22 = val_17 * val_20;
        // 0x00B8E798: STR s3, [sp, #0xc]         | stack[1152921513302035340] = 0x38D1B717;  //  dest_result_addr=1152921513302035340
        // 0x00B8E79C: FCMP s1, s3                | STATE = COMPARE(((this.time + 1f) - this.time), 9.99999974737875E-05)
        // 0x00B8E7A0: B.LE #0xb8e8cc             | if (val_21 <= 0.0001f) goto label_7;    
        if(val_21 <= 0.0001f)
        {
            goto label_7;
        }
        // 0x00B8E7A4: ADRP x21, #0x3673000       | X21 = 57094144 (0x3673000);             
        // 0x00B8E7A8: LDR x21, [x21, #0x488]     | X21 = 1152921504695078912;              
        label_8:
        // 0x00B8E7AC: MOV v15.16b, v8.16b        | V15 = (this.time + 1f);//m1             
        label_6:
        // 0x00B8E7B0: MOV x0, x19                | X0 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E7B4: STR s4, [sp, #8]           | stack[1152921513302035336] = this.time;  //  dest_result_addr=1152921513302035336
        // 0x00B8E7B8: MOV v8.16b, v0.16b         | V8 = (((this.time + 1f) + this.time) * val_20);//m1
        // 0x00B8E7BC: BL #0xb8ea2c               | X0 = this.Plot(t:  val_22 = 1f * val_20);
        UnityEngine.Vector3 val_2 = this.Plot(t:  val_22);
        // 0x00B8E7C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E7C4: MOV x0, x19                | X0 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E7C8: MOV v9.16b, v0.16b         | V9 = val_2.x;//m1                       
        // 0x00B8E7CC: MOV v10.16b, v1.16b        | V10 = val_2.y;//m1                      
        // 0x00B8E7D0: MOV v11.16b, v2.16b        | V11 = val_2.z;//m1                      
        // 0x00B8E7D4: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_3 = this.transform;
        // 0x00B8E7D8: MOV x20, x0                | X20 = val_3;//m1                        
        // 0x00B8E7DC: CBNZ x20, #0xb8e7e4        | if (val_3 != null) goto label_2;        
        if(val_3 != null)
        {
            goto label_2;
        }
        // 0x00B8E7E0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_3, ????);      
        label_2:
        // 0x00B8E7E4: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E7E8: MOV x0, x20                | X0 = val_3;//m1                         
        // 0x00B8E7EC: BL #0x2693510              | X0 = val_3.get_position();              
        UnityEngine.Vector3 val_4 = val_3.position;
        // 0x00B8E7F0: LDR x0, [x21]              | X0 = typeof(UnityEngine.Vector3);       
        // 0x00B8E7F4: MOV v12.16b, v0.16b        | V12 = val_4.x;//m1                      
        // 0x00B8E7F8: MOV v13.16b, v1.16b        | V13 = val_4.y;//m1                      
        // 0x00B8E7FC: MOV v14.16b, v2.16b        | V14 = val_4.z;//m1                      
        // 0x00B8E800: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8E804: TBZ w8, #0, #0xb8e814      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_4;
        // 0x00B8E808: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E80C: CBNZ w8, #0xb8e814         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_4;
        // 0x00B8E810: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_4:
        // 0x00B8E814: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E818: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E81C: MOV v0.16b, v9.16b         | V0 = val_2.x;//m1                       
        // 0x00B8E820: MOV v1.16b, v10.16b        | V1 = val_2.y;//m1                       
        // 0x00B8E824: MOV v2.16b, v11.16b        | V2 = val_2.z;//m1                       
        // 0x00B8E828: MOV v3.16b, v12.16b        | V3 = val_4.x;//m1                       
        // 0x00B8E82C: MOV v4.16b, v13.16b        | V4 = val_4.y;//m1                       
        // 0x00B8E830: MOV v5.16b, v14.16b        | V5 = val_4.z;//m1                       
        // 0x00B8E834: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        UnityEngine.Vector3 val_5 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_2.x, y = val_2.y, z = val_2.z}, b:  new UnityEngine.Vector3() {x = val_4.x, y = val_4.y, z = val_4.z});
        // 0x00B8E838: ADD x0, sp, #0x10          | X0 = (1152921513302035328 + 16) = 1152921513302035344 (0x1000000206460B90);
        // 0x00B8E83C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E840: STP s0, s1, [sp, #0x10]    | stack[1152921513302035344] = val_5.x;  stack[1152921513302035348] = val_5.y;  //  dest_result_addr=1152921513302035344 |  dest_result_addr=1152921513302035348
        // 0x00B8E844: STR s2, [sp, #0x18]        | stack[1152921513302035352] = val_5.z;    //  dest_result_addr=1152921513302035352
        // 0x00B8E848: BL #0x269a374              | X0 = label_UnityEngine_Vector3_Distance_GL0269A374();
        // 0x00B8E84C: LDR s11, [x19, #0x24]      | S11 = this.speed; //P2                  
        // 0x00B8E850: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E854: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E858: MOV v9.16b, v0.16b         | V9 = val_5.x;//m1                       
        // 0x00B8E85C: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_6 = UnityEngine.Time.deltaTime;
        // 0x00B8E860: LDR s12, [x19, #0x24]      | S12 = this.speed; //P2                  
        // 0x00B8E864: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E868: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E86C: MOV v10.16b, v0.16b        | V10 = val_6;//m1                        
        // 0x00B8E870: BL #0x2690bb8              | X0 = UnityEngine.Time.get_deltaTime();  
        float val_7 = UnityEngine.Time.deltaTime;
        // 0x00B8E874: FMUL s1, s11, s10          | S1 = (this.speed * val_6);              
        float val_8 = this.speed * val_6;
        // 0x00B8E878: FMUL s0, s12, s0           | S0 = (this.speed * val_7);              
        val_7 = this.speed * val_7;
        // 0x00B8E87C: FMUL s0, s1, s0            | S0 = ((this.speed * val_6) * (this.speed * val_7));
        val_7 = val_8 * val_7;
        // 0x00B8E880: FCMP s9, s0                | STATE = COMPARE(val_5.x, ((this.speed * val_6) * (this.speed * val_7)))
        // 0x00B8E884: B.GT #0xb8e8ac             | if (val_5.x > val_7) goto label_5;      
        if(val_5.x > val_7)
        {
            goto label_5;
        }
        // 0x00B8E888: FADD s0, s15, s8           | S0 = ((this.time + 1f) + (((this.time + 1f) + this.time) * val_20));
        float val_9 = val_1 + val_22;
        // 0x00B8E88C: FMOV s2, #0.50000000       | S2 = 0.5;                               
        // 0x00B8E890: FMUL s0, s0, s2            | S0 = (((this.time + 1f) + (((this.time + 1f) + this.time) * val_20)) * 0.5f);
        val_22 = val_9 * 0.5f;
        // 0x00B8E894: LDR s2, [sp, #0xc]         | S2 = 0.0001;                            
        val_20 = 0.0001f;
        // 0x00B8E898: FSUB s1, s15, s8           | S1 = ((this.time + 1f) - (((this.time + 1f) + this.time) * val_20));
        val_21 = val_1 - val_22;
        // 0x00B8E89C: MOV v4.16b, v8.16b         | V4 = (((this.time + 1f) + this.time) * val_20);//m1
        // 0x00B8E8A0: FCMP s1, s2                | STATE = COMPARE(((this.time + 1f) - (((this.time + 1f) + this.time) * val_20)), 9.99999974737875E-05)
        // 0x00B8E8A4: B.GT #0xb8e7b0             | if (val_21 > val_20) goto label_6;      
        if(val_21 > val_20)
        {
            goto label_6;
        }
        // 0x00B8E8A8: B #0xb8e8cc                |  goto label_7;                          
        goto label_7;
        label_5:
        // 0x00B8E8AC: LDR s4, [sp, #8]           | S4 = this.time;                         
        // 0x00B8E8B0: FMOV s2, #0.50000000       | S2 = 0.5;                               
        // 0x00B8E8B4: FADD s0, s8, s4            | S0 = ((((this.time + 1f) + this.time) * val_20) + this.time);
        float val_10 = val_22 + this.time;
        // 0x00B8E8B8: FMUL s0, s0, s2            | S0 = (((((this.time + 1f) + this.time) * val_20) + this.time) * 0.5f);
        val_22 = val_10 * 0.5f;
        // 0x00B8E8BC: LDR s2, [sp, #0xc]         | S2 = 0.0001;                            
        val_20 = 0.0001f;
        // 0x00B8E8C0: FSUB s1, s8, s4            | S1 = ((((this.time + 1f) + this.time) * val_20) - this.time);
        val_21 = val_22 - this.time;
        // 0x00B8E8C4: FCMP s1, s2                | STATE = COMPARE(((((this.time + 1f) + this.time) * val_20) - this.time), 9.99999974737875E-05)
        // 0x00B8E8C8: B.GT #0xb8e7ac             | if (val_21 > val_20) goto label_8;      
        if(val_21 > val_20)
        {
            goto label_8;
        }
        label_7:
        // 0x00B8E8CC: MOV x0, x19                | X0 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E8D0: STR s0, [x19, #0x28]       | this.time = (((((this.time + 1f) + this.time) * val_20) + this.time) * 0.5f);  //  dest_result_addr=1152921513302047512
        this.time = val_22;
        // 0x00B8E8D4: BL #0xb8ea2c               | X0 = this.Plot(t:  val_22 = val_10 * 0.5f);
        UnityEngine.Vector3 val_11 = this.Plot(t:  val_22);
        // 0x00B8E8D8: ADRP x8, #0x2a92000        | X8 = 44638208 (0x2A92000);              
        // 0x00B8E8DC: MOV v8.16b, v0.16b         | V8 = val_11.x;//m1                      
        // 0x00B8E8E0: MOV v9.16b, v1.16b         | V9 = val_11.y;//m1                      
        // 0x00B8E8E4: LDR s0, [x19, #0x28]       | S0 = this.time; //P2                    
        float val_18 = this.time;
        // 0x00B8E8E8: LDR s1, [x8, #0x774]       | S1 = 0.001;                             
        // 0x00B8E8EC: MOV x0, x19                | X0 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E8F0: MOV v10.16b, v2.16b        | V10 = val_11.z;//m1                     
        // 0x00B8E8F4: FADD s0, s0, s1            | S0 = (this.time + 0.001f);              
        val_18 = val_18 + 0.001f;
        // 0x00B8E8F8: BL #0xb8ea2c               | X0 = this.Plot(t:  this.time = this.time + 0.001f);
        UnityEngine.Vector3 val_12 = this.Plot(t:  val_18);
        // 0x00B8E8FC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E900: MOV x0, x19                | X0 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E904: MOV v11.16b, v0.16b        | V11 = val_12.x;//m1                     
        // 0x00B8E908: MOV v12.16b, v1.16b        | V12 = val_12.y;//m1                     
        // 0x00B8E90C: MOV v13.16b, v2.16b        | V13 = val_12.z;//m1                     
        // 0x00B8E910: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_13 = this.transform;
        // 0x00B8E914: MOV x20, x0                | X20 = val_13;//m1                       
        // 0x00B8E918: CBNZ x20, #0xb8e920        | if (val_13 != null) goto label_9;       
        if(val_13 != null)
        {
            goto label_9;
        }
        // 0x00B8E91C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_13, ????);     
        label_9:
        // 0x00B8E920: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E924: MOV x0, x20                | X0 = val_13;//m1                        
        // 0x00B8E928: MOV v0.16b, v8.16b         | V0 = val_11.x;//m1                      
        // 0x00B8E92C: MOV v1.16b, v9.16b         | V1 = val_11.y;//m1                      
        // 0x00B8E930: MOV v2.16b, v10.16b        | V2 = val_11.z;//m1                      
        // 0x00B8E934: BL #0x26935b8              | val_13.set_position(value:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        val_13.position = new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z};
        // 0x00B8E938: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E93C: MOV x0, x19                | X0 = 1152921513302047472 (0x1000000206463AF0);//ML01
        // 0x00B8E940: BL #0x20d5094              | X0 = this.get_transform();              
        UnityEngine.Transform val_14 = this.transform;
        // 0x00B8E944: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
        // 0x00B8E948: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
        // 0x00B8E94C: MOV x19, x0                | X19 = val_14;//m1                       
        // 0x00B8E950: LDR x8, [x8]               | X8 = typeof(UnityEngine.Vector3);       
        // 0x00B8E954: LDRB w9, [x8, #0x10a]      | W9 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
        // 0x00B8E958: TBZ w9, #0, #0xb8e96c      | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_11;
        // 0x00B8E95C: LDR w9, [x8, #0xbc]        | W9 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E960: CBNZ w9, #0xb8e96c         | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
        // 0x00B8E964: MOV x0, x8                 | X0 = 1152921504695078912 (0x1000000005425000);//ML01
        // 0x00B8E968: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
        label_11:
        // 0x00B8E96C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E970: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E974: MOV v0.16b, v11.16b        | V0 = val_12.x;//m1                      
        // 0x00B8E978: MOV v1.16b, v12.16b        | V1 = val_12.y;//m1                      
        // 0x00B8E97C: MOV v2.16b, v13.16b        | V2 = val_12.z;//m1                      
        // 0x00B8E980: MOV v3.16b, v8.16b         | V3 = val_11.x;//m1                      
        // 0x00B8E984: MOV v4.16b, v9.16b         | V4 = val_11.y;//m1                      
        // 0x00B8E988: MOV v5.16b, v10.16b        | V5 = val_11.z;//m1                      
        // 0x00B8E98C: BL #0x26950c4              | X0 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Subtraction(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
        // 0x00B8E990: ADRP x8, #0x3642000        | X8 = 56893440 (0x3642000);              
        // 0x00B8E994: LDR x8, [x8, #0xd78]       | X8 = 1152921504695132160;               
        // 0x00B8E998: MOV v8.16b, v0.16b         | V8 = val_15.x;//m1                      
        // 0x00B8E99C: MOV v9.16b, v1.16b         | V9 = val_15.y;//m1                      
        // 0x00B8E9A0: MOV v10.16b, v2.16b        | V10 = val_15.z;//m1                     
        // 0x00B8E9A4: LDR x0, [x8]               | X0 = typeof(UnityEngine.Quaternion);    
        // 0x00B8E9A8: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_10A;
        // 0x00B8E9AC: TBZ w8, #0, #0xb8e9bc      | if (UnityEngine.Quaternion.__il2cppRuntimeField_has_cctor == 0) goto label_13;
        // 0x00B8E9B0: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished;
        // 0x00B8E9B4: CBNZ w8, #0xb8e9bc         | if (UnityEngine.Quaternion.__il2cppRuntimeField_cctor_finished != 0) goto label_13;
        // 0x00B8E9B8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Quaternion), ????);
        label_13:
        // 0x00B8E9BC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B8E9C0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E9C4: MOV v0.16b, v8.16b         | V0 = val_15.x;//m1                      
        // 0x00B8E9C8: MOV v1.16b, v9.16b         | V1 = val_15.y;//m1                      
        // 0x00B8E9CC: MOV v2.16b, v10.16b        | V2 = val_15.z;//m1                      
        // 0x00B8E9D0: BL #0x1b7e8c4              | X0 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
        UnityEngine.Quaternion val_16 = UnityEngine.Quaternion.LookRotation(forward:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
        // 0x00B8E9D4: MOV v8.16b, v0.16b         | V8 = val_16.x;//m1                      
        // 0x00B8E9D8: MOV v9.16b, v1.16b         | V9 = val_16.y;//m1                      
        // 0x00B8E9DC: MOV v10.16b, v2.16b        | V10 = val_16.z;//m1                     
        // 0x00B8E9E0: MOV v11.16b, v3.16b        | V11 = val_16.w;//m1                     
        // 0x00B8E9E4: CBNZ x19, #0xb8e9ec        | if (val_14 != null) goto label_14;      
        if(val_14 != null)
        {
            goto label_14;
        }
        // 0x00B8E9E8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x0, ????);        
        label_14:
        // 0x00B8E9EC: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B8E9F0: MOV x0, x19                | X0 = val_14;//m1                        
        // 0x00B8E9F4: MOV v0.16b, v8.16b         | V0 = val_16.x;//m1                      
        // 0x00B8E9F8: MOV v1.16b, v9.16b         | V1 = val_16.y;//m1                      
        // 0x00B8E9FC: MOV v2.16b, v10.16b        | V2 = val_16.z;//m1                      
        // 0x00B8EA00: MOV v3.16b, v11.16b        | V3 = val_16.w;//m1                      
        // 0x00B8EA04: BL #0x26938b0              | val_14.set_rotation(value:  new UnityEngine.Quaternion() {x = val_16.x, y = val_16.y, z = val_16.z, w = val_16.w});
        val_14.rotation = new UnityEngine.Quaternion() {x = val_16.x, y = val_16.y, z = val_16.z, w = val_16.w};
        // 0x00B8EA08: SUB sp, x29, #0x60         | SP = (1152921513302035456 - 96) = 1152921513302035360 (0x1000000206460BA0);
        // 0x00B8EA0C: LDP x29, x30, [sp, #0x60]  | X29 = ; X30 = ;                          //  | 
        // 0x00B8EA10: LDP x20, x19, [sp, #0x50]  | X20 = ; X19 = ;                          //  | 
        // 0x00B8EA14: LDP x22, x21, [sp, #0x40]  | X22 = ; X21 = ;                          //  | 
        // 0x00B8EA18: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
        // 0x00B8EA1C: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
        // 0x00B8EA20: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
        // 0x00B8EA24: LDP d15, d14, [sp], #0x70  | D15 = ; D14 = ;                          //  | 
        // 0x00B8EA28: RET                        |  return;                                
        return;
    
    }

}
