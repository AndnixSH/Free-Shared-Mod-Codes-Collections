using UnityEngine;
public class all_configCfg : CsCfgBase
{
    // Fields
    public int id; //  0x00000010
    public string att_key; //  0x00000018
    public int att_type; //  0x00000020
    public int int_value; //  0x00000024
    public string string_value; //  0x00000028
    public string att_des; //  0x00000030
    
    // Methods
    //
    // Offset in libil2cpp.so: 0x00B25A00 (11688448), len: 8  VirtAddr: 0x00B25A00 RVA: 0x00B25A00 token: 100690502 methodIndex: 24766 delegateWrapperIndex: 0 methodInvoker: 0
    public all_configCfg()
    {
        //
        // Disasemble & Code
        // 0x00B25A00: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x00B25A04: B #0xb46154                | this..ctor(); return;                   
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x00B25A08 (11688456), len: 420  VirtAddr: 0x00B25A08 RVA: 0x00B25A08 token: 100690503 methodIndex: 24767 delegateWrapperIndex: 0 methodInvoker: 0
    public override void Init(System.Collections.Generic.Dictionary<string, string> _info)
    {
        //
        // Disasemble & Code
        // 0x00B25A08: STP x22, x21, [sp, #-0x30]! | stack[1152921514528503024] = ???;  stack[1152921514528503032] = ???;  //  dest_result_addr=1152921514528503024 |  dest_result_addr=1152921514528503032
        // 0x00B25A0C: STP x20, x19, [sp, #0x10]  | stack[1152921514528503040] = ???;  stack[1152921514528503048] = ???;  //  dest_result_addr=1152921514528503040 |  dest_result_addr=1152921514528503048
        // 0x00B25A10: STP x29, x30, [sp, #0x20]  | stack[1152921514528503056] = ???;  stack[1152921514528503064] = ???;  //  dest_result_addr=1152921514528503056 |  dest_result_addr=1152921514528503064
        // 0x00B25A14: ADD x29, sp, #0x20         | X29 = (1152921514528503024 + 32) = 1152921514528503056 (0x100000024F607510);
        // 0x00B25A18: ADRP x21, #0x3733000       | X21 = 57880576 (0x3733000);             
        // 0x00B25A1C: LDRB w8, [x21, #0x73e]     | W8 = (bool)static_value_0373373E;       
        // 0x00B25A20: MOV x20, x1                | X20 = _info;//m1                        
        // 0x00B25A24: MOV x19, x0                | X19 = 1152921514528515072 (0x100000024F60A400);//ML01
        // 0x00B25A28: TBNZ w8, #0, #0xb25a44     | if (static_value_0373373E == true) goto label_0;
        // 0x00B25A2C: ADRP x8, #0x3608000        | X8 = 56655872 (0x3608000);              
        // 0x00B25A30: LDR x8, [x8, #0x118]       | X8 = 0x2B8ABF8;                         
        // 0x00B25A34: LDR w0, [x8]               | W0 = 0x1BC;                             
        // 0x00B25A38: BL #0x2782188              | X0 = sub_2782188( ?? 0x1BC, ????);      
        // 0x00B25A3C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x00B25A40: STRB w8, [x21, #0x73e]     | static_value_0373373E = true;            //  dest_result_addr=57882430
        label_0:
        // 0x00B25A44: CBNZ x20, #0xb25a4c        | if (_info != null) goto label_1;        
        if(_info != null)
        {
            goto label_1;
        }
        // 0x00B25A48: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x1BC, ????);      
        label_1:
        // 0x00B25A4C: ADRP x8, #0x3677000        | X8 = 57110528 (0x3677000);              
        // 0x00B25A50: ADRP x21, #0x3667000       | X21 = 57044992 (0x3667000);             
        // 0x00B25A54: LDR x8, [x8, #0xf28]       | X8 = (string**)(1152921510122275760)("id");
        // 0x00B25A58: LDR x21, [x21, #0x90]      | X21 = 1152921510817398768;              
        // 0x00B25A5C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25A60: LDR x1, [x8]               | X1 = "id";                              
        // 0x00B25A64: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25A68: BL #0x23fc26c              | X0 = _info.get_Item(key:  "id");        
        string val_1 = _info.Item["id"];
        // 0x00B25A6C: MOV x1, x0                 | X1 = val_1;//m1                         
        // 0x00B25A70: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25A74: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25A78: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_2 = System.Int32.Parse(s:  0);
        // 0x00B25A7C: STR w0, [x19, #0x10]       | this.id = val_2;                         //  dest_result_addr=1152921514528515088
        this.id = val_2;
        // 0x00B25A80: CBZ x20, #0xb25aa4         | if (_info == null) goto label_2;        
        if(_info == null)
        {
            goto label_2;
        }
        // 0x00B25A84: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B25A88: LDR x8, [x8, #0xb70]       | X8 = (string**)(1152921514528461920)("att_key");
        // 0x00B25A8C: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25A90: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25A94: LDR x1, [x8]               | X1 = "att_key";                         
        // 0x00B25A98: BL #0x23fc26c              | X0 = _info.get_Item(key:  "att_key");   
        string val_3 = _info.Item["att_key"];
        // 0x00B25A9C: STR x0, [x19, #0x18]       | this.att_key = val_3;                    //  dest_result_addr=1152921514528515096
        this.att_key = val_3;
        // 0x00B25AA0: B #0xb25ac8                |  goto label_3;                          
        goto label_3;
        label_2:
        // 0x00B25AA4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2, ????);      
        // 0x00B25AA8: ADRP x8, #0x35b8000        | X8 = 56328192 (0x35B8000);              
        // 0x00B25AAC: LDR x8, [x8, #0xb70]       | X8 = (string**)(1152921514528461920)("att_key");
        // 0x00B25AB0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25AB4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25AB8: LDR x1, [x8]               | X1 = "att_key";                         
        // 0x00B25ABC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "att_key");   
        string val_4 = _info.Item["att_key"];
        // 0x00B25AC0: STR x0, [x19, #0x18]       | this.att_key = val_4;                    //  dest_result_addr=1152921514528515096
        this.att_key = val_4;
        // 0x00B25AC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_4, ????);      
        label_3:
        // 0x00B25AC8: ADRP x8, #0x35d8000        | X8 = 56459264 (0x35D8000);              
        // 0x00B25ACC: LDR x8, [x8, #0xef8]       | X8 = (string**)(1152921514528470208)("att_type");
        // 0x00B25AD0: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25AD4: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25AD8: LDR x1, [x8]               | X1 = "att_type";                        
        // 0x00B25ADC: BL #0x23fc26c              | X0 = _info.get_Item(key:  "att_type");  
        string val_5 = _info.Item["att_type"];
        // 0x00B25AE0: MOV x1, x0                 | X1 = val_5;//m1                         
        // 0x00B25AE4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25AE8: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25AEC: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_6 = System.Int32.Parse(s:  0);
        // 0x00B25AF0: STR w0, [x19, #0x20]       | this.att_type = val_6;                   //  dest_result_addr=1152921514528515104
        this.att_type = val_6;
        // 0x00B25AF4: CBZ x20, #0xb25b28         | if (_info == null) goto label_4;        
        if(_info == null)
        {
            goto label_4;
        }
        // 0x00B25AF8: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x00B25AFC: LDR x8, [x8, #0xee8]       | X8 = (string**)(1152921514528474400)("int_value");
        // 0x00B25B00: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25B04: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25B08: LDR x1, [x8]               | X1 = "int_value";                       
        // 0x00B25B0C: BL #0x23fc26c              | X0 = _info.get_Item(key:  "int_value"); 
        string val_7 = _info.Item["int_value"];
        // 0x00B25B10: MOV x1, x0                 | X1 = val_7;//m1                         
        // 0x00B25B14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25B18: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25B1C: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_8 = System.Int32.Parse(s:  0);
        // 0x00B25B20: STR w0, [x19, #0x24]       | this.int_value = val_8;                  //  dest_result_addr=1152921514528515108
        this.int_value = val_8;
        // 0x00B25B24: B #0xb25b5c                |  goto label_5;                          
        goto label_5;
        label_4:
        // 0x00B25B28: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_6, ????);      
        // 0x00B25B2C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
        // 0x00B25B30: LDR x8, [x8, #0xee8]       | X8 = (string**)(1152921514528474400)("int_value");
        // 0x00B25B34: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25B38: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25B3C: LDR x1, [x8]               | X1 = "int_value";                       
        // 0x00B25B40: BL #0x23fc26c              | X0 = _info.get_Item(key:  "int_value"); 
        string val_9 = _info.Item["int_value"];
        // 0x00B25B44: MOV x1, x0                 | X1 = val_9;//m1                         
        // 0x00B25B48: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x00B25B4C: MOV x2, xzr                | X2 = 0 (0x0);//ML01                     
        // 0x00B25B50: BL #0x1e63bd4              | X0 = System.Int32.Parse(s:  0);         
        int val_10 = System.Int32.Parse(s:  0);
        // 0x00B25B54: STR w0, [x19, #0x24]       | this.int_value = val_10;                 //  dest_result_addr=1152921514528515108
        this.int_value = val_10;
        // 0x00B25B58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_10, ????);     
        label_5:
        // 0x00B25B5C: ADRP x8, #0x35e0000        | X8 = 56492032 (0x35E0000);              
        // 0x00B25B60: LDR x8, [x8, #0x9c8]       | X8 = (string**)(1152921514528482688)("string_value");
        // 0x00B25B64: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25B68: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25B6C: LDR x1, [x8]               | X1 = "string_value";                    
        // 0x00B25B70: BL #0x23fc26c              | X0 = _info.get_Item(key:  "string_value");
        string val_11 = _info.Item["string_value"];
        // 0x00B25B74: STR x0, [x19, #0x28]       | this.string_value = val_11;              //  dest_result_addr=1152921514528515112
        this.string_value = val_11;
        // 0x00B25B78: CBNZ x20, #0xb25b80        | if (_info != null) goto label_6;        
        if(_info != null)
        {
            goto label_6;
        }
        // 0x00B25B7C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_11, ????);     
        label_6:
        // 0x00B25B80: ADRP x8, #0x3653000        | X8 = 56963072 (0x3653000);              
        // 0x00B25B84: LDR x8, [x8, #0xf98]       | X8 = (string**)(1152921514528486880)("att_des");
        // 0x00B25B88: LDR x2, [x21]              | X2 = public System.String System.Collections.Generic.Dictionary<System.String, System.String>::get_Item(System.String key);
        // 0x00B25B8C: MOV x0, x20                | X0 = _info;//m1                         
        // 0x00B25B90: LDR x1, [x8]               | X1 = "att_des";                         
        // 0x00B25B94: BL #0x23fc26c              | X0 = _info.get_Item(key:  "att_des");   
        string val_12 = _info.Item["att_des"];
        // 0x00B25B98: STR x0, [x19, #0x30]       | this.att_des = val_12;                   //  dest_result_addr=1152921514528515120
        this.att_des = val_12;
        // 0x00B25B9C: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x00B25BA0: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x00B25BA4: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x00B25BA8: RET                        |  return;                                
        return;
    
    }

}
