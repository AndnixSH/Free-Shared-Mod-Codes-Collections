using UnityEngine;

namespace Pathfinding
{
    internal class AstarSplines
    {
        // Methods
        //
        // Offset in libil2cpp.so: 0x01686668 (23619176), len: 8  VirtAddr: 0x01686668 RVA: 0x01686668 token: 100681932 methodIndex: 49881 delegateWrapperIndex: 0 methodInvoker: 0
        public AstarSplines()
        {
            //
            // Disasemble & Code
            // 0x01686668: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168666C: B #0x16f59f0               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x01686670 (23619184), len: 504  VirtAddr: 0x01686670 RVA: 0x01686670 token: 100681933 methodIndex: 49882 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Vector3 CatmullRom(UnityEngine.Vector3 previous, UnityEngine.Vector3 start, UnityEngine.Vector3 end, UnityEngine.Vector3 next, float elapsedTime)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            //  | 
            float val_2;
            // 0x01686670: STP d15, d14, [sp, #-0x60]! | stack[1152921513157231632] = ???;  stack[1152921513157231640] = ???;  //  dest_result_addr=1152921513157231632 |  dest_result_addr=1152921513157231640
            // 0x01686674: STP d13, d12, [sp, #0x10]  | stack[1152921513157231648] = ???;  stack[1152921513157231656] = ???;  //  dest_result_addr=1152921513157231648 |  dest_result_addr=1152921513157231656
            // 0x01686678: STP d11, d10, [sp, #0x20]  | stack[1152921513157231664] = ???;  stack[1152921513157231672] = ???;  //  dest_result_addr=1152921513157231664 |  dest_result_addr=1152921513157231672
            // 0x0168667C: STP d9, d8, [sp, #0x30]    | stack[1152921513157231680] = ???;  stack[1152921513157231688] = ???;  //  dest_result_addr=1152921513157231680 |  dest_result_addr=1152921513157231688
            // 0x01686680: STP x20, x19, [sp, #0x40]  | stack[1152921513157231696] = ???;  stack[1152921513157231704] = ???;  //  dest_result_addr=1152921513157231696 |  dest_result_addr=1152921513157231704
            // 0x01686684: STP x29, x30, [sp, #0x50]  | stack[1152921513157231712] = ???;  stack[1152921513157231720] = ???;  //  dest_result_addr=1152921513157231712 |  dest_result_addr=1152921513157231720
            // 0x01686688: ADD x29, sp, #0x50         | X29 = (1152921513157231632 + 80) = 1152921513157231712 (0x10000001FDA48460);
            // 0x0168668C: STP s4, s5, [sp, #-0x20]!  | stack[1152921513157231600] = start.y;  stack[1152921513157231604] = start.z;  //  dest_result_addr=1152921513157231600 |  dest_result_addr=1152921513157231604
            // 0x01686690: MOV v10.16b, v1.16b        | V10 = previous.y;//m1                   
            // 0x01686694: LDR s1, [x29, #0x28]       | S1 = next.x;                            
            // 0x01686698: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x0168669C: MOV v8.16b, v3.16b         | V8 = start.x;//m1                       
            // 0x016866A0: MOV v9.16b, v2.16b         | V9 = previous.z;//m1                    
            // 0x016866A4: STR s1, [sp, #0x1c]        | stack[1152921513157231628] = next.x;     //  dest_result_addr=1152921513157231628
            // 0x016866A8: LDR s1, [x29, #0x24]       | S1 = val_1;                              //  find_add[1152921513157219728]
            // 0x016866AC: MOV v11.16b, v0.16b        | V11 = previous.x;//m1                   
            // 0x016866B0: STR s1, [sp, #0x18]        | stack[1152921513157231624] = val_1;      //  dest_result_addr=1152921513157231624
            // 0x016866B4: LDR s1, [x29, #0x20]       | S1 = end.z;                             
            // 0x016866B8: STR s1, [sp, #0x14]        | stack[1152921513157231620] = end.z;      //  dest_result_addr=1152921513157231620
            // 0x016866BC: LDR s1, [x29, #0x18]       | S1 = end.y;                             
            // 0x016866C0: STR s1, [sp, #0x10]        | stack[1152921513157231616] = end.y;      //  dest_result_addr=1152921513157231616
            // 0x016866C4: LDR s1, [x29, #0x14]       | S1 = val_2;                              //  find_add[1152921513157219728]
            // 0x016866C8: STR s1, [sp, #0xc]         | stack[1152921513157231612] = val_2;      //  dest_result_addr=1152921513157231612
            // 0x016866CC: LDR s1, [x29, #0x10]       | S1 = end.x;                             
            // 0x016866D0: STR s1, [sp, #8]           | stack[1152921513157231608] = end.x;      //  dest_result_addr=1152921513157231608
            // 0x016866D4: LDR s14, [x29, #0x30]      | S14 = next.y;                           
            float val_19 = next.y;
            // 0x016866D8: LDRB w8, [x19, #0xef]      | W8 = (bool)static_value_037380EF;       
            // 0x016866DC: TBNZ w8, #0, #0x16866f8    | if (static_value_037380EF == true) goto label_0;
            // 0x016866E0: ADRP x8, #0x3619000        | X8 = 56725504 (0x3619000);              
            // 0x016866E4: LDR x8, [x8, #0xe58]       | X8 = 0x2B8EE18;                         
            // 0x016866E8: LDR w0, [x8]               | W0 = 0x1246;                            
            // 0x016866EC: BL #0x2782188              | X0 = sub_2782188( ?? 0x1246, ????);     
            // 0x016866F0: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016866F4: STRB w8, [x19, #0xef]      | static_value_037380EF = true;            //  dest_result_addr=57901295
            label_0:
            // 0x016866F8: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x016866FC: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x01686700: FMUL s12, s14, s14         | S12 = (next.y * next.y);                
            float val_3 = val_19 * val_19;
            // 0x01686704: FMUL s15, s12, s14         | S15 = ((next.y * next.y) * next.y);     
            float val_4 = val_3 * val_19;
            // 0x01686708: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x0168670C: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01686710: TBZ w8, #0, #0x1686720     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x01686714: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01686718: CBNZ w8, #0x1686720        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x0168671C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x01686720: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x01686724: FMUL s13, s15, s1          | S13 = (((next.y * next.y) * next.y) * 0.5f);
            float val_5 = val_4 * 0.5f;
            // 0x01686728: FSUB s0, s12, s13          | S0 = ((next.y * next.y) - (((next.y * next.y) * next.y) * 0.5f));
            float val_6 = val_3 - val_5;
            // 0x0168672C: FMUL s14, s14, s1          | S14 = (next.y * 0.5f);                  
            val_19 = val_19 * 0.5f;
            // 0x01686730: FSUB s3, s0, s14           | S3 = (((next.y * next.y) - (((next.y * next.y) * next.y) * 0.5f)) - (next.y * 0.5f));
            float val_7 = val_6 - val_19;
            // 0x01686734: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686738: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168673C: MOV v0.16b, v11.16b        | V0 = previous.x;//m1                    
            // 0x01686740: MOV v1.16b, v10.16b        | V1 = previous.y;//m1                    
            // 0x01686744: MOV v2.16b, v9.16b         | V2 = previous.z;//m1                    
            // 0x01686748: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = previous.x, y = previous.y, z = previous.z}, d:  float val_7 = val_6 - next.y);
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = previous.x, y = previous.y, z = previous.z}, d:  val_7);
            // 0x0168674C: MOV v9.16b, v0.16b         | V9 = val_8.x;//m1                       
            // 0x01686750: MOV v10.16b, v1.16b        | V10 = val_8.y;//m1                      
            // 0x01686754: FMOV s0, #1.50000000       | S0 = 1.5;                               
            // 0x01686758: FMOV s1, #-2.50000000      | S1 = -2.5;                              
            // 0x0168675C: FMUL s15, s15, s0          | S15 = (((next.y * next.y) * next.y) * 1.5f);
            val_4 = val_4 * 1.5f;
            // 0x01686760: FMUL s0, s12, s1           | S0 = ((next.y * next.y) * -2.5f);       
            float val_9 = val_3 * (-2.5f);
            // 0x01686764: FADD s0, s15, s0           | S0 = ((((next.y * next.y) * next.y) * 1.5f) + ((next.y * next.y) * -2.5f));
            val_9 = val_4 + val_9;
            // 0x01686768: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x0168676C: MOV v11.16b, v2.16b        | V11 = val_8.z;//m1                      
            // 0x01686770: FADD s3, s0, s1            | S3 = (((((next.y * next.y) * next.y) * 1.5f) + ((next.y * next.y) * -2.5f)) + 1f);
            float val_10 = val_9 + 1f;
            // 0x01686774: LDP s1, s2, [sp]           | S1 = start.y; S2 = start.z;              //  | 
            // 0x01686778: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x0168677C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686780: MOV v0.16b, v8.16b         | V0 = start.x;//m1                       
            // 0x01686784: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, d:  float val_10 = val_9 + 1f);
            UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, d:  val_10);
            // 0x01686788: MOV v3.16b, v0.16b         | V3 = val_11.x;//m1                      
            // 0x0168678C: MOV v4.16b, v1.16b         | V4 = val_11.y;//m1                      
            // 0x01686790: MOV v5.16b, v2.16b         | V5 = val_11.z;//m1                      
            // 0x01686794: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686798: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x0168679C: MOV v0.16b, v9.16b         | V0 = val_8.x;//m1                       
            // 0x016867A0: MOV v1.16b, v10.16b        | V1 = val_8.y;//m1                       
            // 0x016867A4: MOV v2.16b, v11.16b        | V2 = val_8.z;//m1                       
            // 0x016867A8: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
            UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
            // 0x016867AC: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
            // 0x016867B0: FADD s0, s12, s12          | S0 = ((next.y * next.y) + (next.y * next.y));
            float val_13 = val_3 + val_3;
            // 0x016867B4: FSUB s0, s0, s15           | S0 = (((next.y * next.y) + (next.y * next.y)) - (((next.y * next.y) * next.y) * 1.5f));
            val_13 = val_13 - val_4;
            // 0x016867B8: MOV v9.16b, v1.16b         | V9 = val_12.y;//m1                      
            // 0x016867BC: MOV v10.16b, v2.16b        | V10 = val_12.z;//m1                     
            // 0x016867C0: FADD s3, s14, s0           | S3 = ((next.y * 0.5f) + (((next.y * next.y) + (next.y * next.y)) - (((next.y * next.y) * next.y) * 1.5f)));
            float val_14 = val_19 + val_13;
            // 0x016867C4: LDP s0, s1, [sp, #8]       | S0 = end.x; S1 = val_2;                  //  | 
            // 0x016867C8: LDR s2, [sp, #0x10]        | S2 = end.y;                             
            // 0x016867CC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016867D0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016867D4: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.x, y = val_2, z = end.y}, d:  float val_14 = next.y + val_13);
            UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.x, y = val_2, z = end.y}, d:  val_14);
            // 0x016867D8: MOV v3.16b, v0.16b         | V3 = val_15.x;//m1                      
            // 0x016867DC: MOV v4.16b, v1.16b         | V4 = val_15.y;//m1                      
            // 0x016867E0: MOV v5.16b, v2.16b         | V5 = val_15.z;//m1                      
            // 0x016867E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016867E8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016867EC: MOV v0.16b, v8.16b         | V0 = val_12.x;//m1                      
            // 0x016867F0: MOV v1.16b, v9.16b         | V1 = val_12.y;//m1                      
            // 0x016867F4: MOV v2.16b, v10.16b        | V2 = val_12.z;//m1                      
            // 0x016867F8: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
            UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
            // 0x016867FC: MOV v8.16b, v0.16b         | V8 = val_16.x;//m1                      
            // 0x01686800: FMOV s0, #0.50000000       | S0 = 0.5;                               
            float val_20 = 0.5f;
            // 0x01686804: FMUL s0, s12, s0           | S0 = ((next.y * next.y) * 0.5f);        
            val_20 = val_3 * val_20;
            // 0x01686808: MOV v9.16b, v1.16b         | V9 = val_16.y;//m1                      
            // 0x0168680C: MOV v10.16b, v2.16b        | V10 = val_16.z;//m1                     
            // 0x01686810: FSUB s3, s13, s0           | S3 = ((((next.y * next.y) * next.y) * 0.5f) - ((next.y * next.y) * 0.5f));
            float val_17 = val_5 - val_20;
            // 0x01686814: LDP s0, s1, [sp, #0x14]    | S0 = end.z; S1 = val_1;                  //  | 
            // 0x01686818: LDR s2, [sp, #0x1c]        | S2 = next.x;                            
            // 0x0168681C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686820: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686824: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.z, y = val_1, z = next.x}, d:  float val_17 = val_5 - 0.5f);
            UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.z, y = val_1, z = next.x}, d:  val_17);
            // 0x01686828: MOV v3.16b, v0.16b         | V3 = val_18.x;//m1                      
            // 0x0168682C: MOV v4.16b, v1.16b         | V4 = val_18.y;//m1                      
            // 0x01686830: MOV v5.16b, v2.16b         | V5 = val_18.z;//m1                      
            // 0x01686834: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686838: MOV v0.16b, v8.16b         | V0 = val_16.x;//m1                      
            // 0x0168683C: MOV v1.16b, v9.16b         | V1 = val_16.y;//m1                      
            // 0x01686840: MOV v2.16b, v10.16b        | V2 = val_16.z;//m1                      
            // 0x01686844: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686848: SUB sp, x29, #0x50         | SP = (1152921513157231712 - 80) = 1152921513157231632 (0x10000001FDA48410);
            // 0x0168684C: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01686850: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01686854: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01686858: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x0168685C: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01686860: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01686864: B #0x2694984               | return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
            return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
        
        }
        //
        // Offset in libil2cpp.so: 0x01686868 (23619688), len: 504  VirtAddr: 0x01686868 RVA: 0x01686868 token: 100681934 methodIndex: 49883 delegateWrapperIndex: 0 methodInvoker: 0
        public static UnityEngine.Vector3 CatmullRomOLD(UnityEngine.Vector3 previous, UnityEngine.Vector3 start, UnityEngine.Vector3 end, UnityEngine.Vector3 next, float elapsedTime)
        {
            //
            // Disasemble & Code
            //  | 
            float val_1;
            //  | 
            float val_2;
            // 0x01686868: STP d15, d14, [sp, #-0x60]! | stack[1152921513157343632] = ???;  stack[1152921513157343640] = ???;  //  dest_result_addr=1152921513157343632 |  dest_result_addr=1152921513157343640
            // 0x0168686C: STP d13, d12, [sp, #0x10]  | stack[1152921513157343648] = ???;  stack[1152921513157343656] = ???;  //  dest_result_addr=1152921513157343648 |  dest_result_addr=1152921513157343656
            // 0x01686870: STP d11, d10, [sp, #0x20]  | stack[1152921513157343664] = ???;  stack[1152921513157343672] = ???;  //  dest_result_addr=1152921513157343664 |  dest_result_addr=1152921513157343672
            // 0x01686874: STP d9, d8, [sp, #0x30]    | stack[1152921513157343680] = ???;  stack[1152921513157343688] = ???;  //  dest_result_addr=1152921513157343680 |  dest_result_addr=1152921513157343688
            // 0x01686878: STP x20, x19, [sp, #0x40]  | stack[1152921513157343696] = ???;  stack[1152921513157343704] = ???;  //  dest_result_addr=1152921513157343696 |  dest_result_addr=1152921513157343704
            // 0x0168687C: STP x29, x30, [sp, #0x50]  | stack[1152921513157343712] = ???;  stack[1152921513157343720] = ???;  //  dest_result_addr=1152921513157343712 |  dest_result_addr=1152921513157343720
            // 0x01686880: ADD x29, sp, #0x50         | X29 = (1152921513157343632 + 80) = 1152921513157343712 (0x10000001FDA639E0);
            // 0x01686884: STP s4, s5, [sp, #-0x20]!  | stack[1152921513157343600] = start.y;  stack[1152921513157343604] = start.z;  //  dest_result_addr=1152921513157343600 |  dest_result_addr=1152921513157343604
            // 0x01686888: MOV v10.16b, v1.16b        | V10 = previous.y;//m1                   
            // 0x0168688C: LDR s1, [x29, #0x28]       | S1 = next.x;                            
            // 0x01686890: ADRP x19, #0x3738000       | X19 = 57901056 (0x3738000);             
            // 0x01686894: MOV v8.16b, v3.16b         | V8 = start.x;//m1                       
            // 0x01686898: MOV v9.16b, v2.16b         | V9 = previous.z;//m1                    
            // 0x0168689C: STR s1, [sp, #0x1c]        | stack[1152921513157343628] = next.x;     //  dest_result_addr=1152921513157343628
            // 0x016868A0: LDR s1, [x29, #0x24]       | S1 = val_1;                              //  find_add[1152921513157331728]
            // 0x016868A4: MOV v11.16b, v0.16b        | V11 = previous.x;//m1                   
            // 0x016868A8: STR s1, [sp, #0x18]        | stack[1152921513157343624] = val_1;      //  dest_result_addr=1152921513157343624
            // 0x016868AC: LDR s1, [x29, #0x20]       | S1 = end.z;                             
            // 0x016868B0: STR s1, [sp, #0x14]        | stack[1152921513157343620] = end.z;      //  dest_result_addr=1152921513157343620
            // 0x016868B4: LDR s1, [x29, #0x18]       | S1 = end.y;                             
            // 0x016868B8: STR s1, [sp, #0x10]        | stack[1152921513157343616] = end.y;      //  dest_result_addr=1152921513157343616
            // 0x016868BC: LDR s1, [x29, #0x14]       | S1 = val_2;                              //  find_add[1152921513157331728]
            // 0x016868C0: STR s1, [sp, #0xc]         | stack[1152921513157343612] = val_2;      //  dest_result_addr=1152921513157343612
            // 0x016868C4: LDR s1, [x29, #0x10]       | S1 = end.x;                             
            // 0x016868C8: STR s1, [sp, #8]           | stack[1152921513157343608] = end.x;      //  dest_result_addr=1152921513157343608
            // 0x016868CC: LDR s14, [x29, #0x30]      | S14 = next.y;                           
            float val_19 = next.y;
            // 0x016868D0: LDRB w8, [x19, #0xf0]      | W8 = (bool)static_value_037380F0;       
            // 0x016868D4: TBNZ w8, #0, #0x16868f0    | if (static_value_037380F0 == true) goto label_0;
            // 0x016868D8: ADRP x8, #0x35fa000        | X8 = 56598528 (0x35FA000);              
            // 0x016868DC: LDR x8, [x8, #0x6a0]       | X8 = 0x2B8EE1C;                         
            // 0x016868E0: LDR w0, [x8]               | W0 = 0x1247;                            
            // 0x016868E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x1247, ????);     
            // 0x016868E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x016868EC: STRB w8, [x19, #0xf0]      | static_value_037380F0 = true;            //  dest_result_addr=57901296
            label_0:
            // 0x016868F0: ADRP x8, #0x3673000        | X8 = 57094144 (0x3673000);              
            // 0x016868F4: LDR x8, [x8, #0x488]       | X8 = 1152921504695078912;               
            // 0x016868F8: FMUL s12, s14, s14         | S12 = (next.y * next.y);                
            float val_3 = val_19 * val_19;
            // 0x016868FC: FMUL s15, s12, s14         | S15 = ((next.y * next.y) * next.y);     
            float val_4 = val_3 * val_19;
            // 0x01686900: LDR x0, [x8]               | X0 = typeof(UnityEngine.Vector3);       
            // 0x01686904: LDRB w8, [x0, #0x10a]      | W8 = UnityEngine.Vector3.__il2cppRuntimeField_10A;
            // 0x01686908: TBZ w8, #0, #0x1686918     | if (UnityEngine.Vector3.__il2cppRuntimeField_has_cctor == 0) goto label_2;
            // 0x0168690C: LDR w8, [x0, #0xbc]        | W8 = UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished;
            // 0x01686910: CBNZ w8, #0x1686918        | if (UnityEngine.Vector3.__il2cppRuntimeField_cctor_finished != 0) goto label_2;
            // 0x01686914: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(UnityEngine.Vector3), ????);
            label_2:
            // 0x01686918: FMOV s1, #0.50000000       | S1 = 0.5;                               
            // 0x0168691C: FMUL s13, s15, s1          | S13 = (((next.y * next.y) * next.y) * 0.5f);
            float val_5 = val_4 * 0.5f;
            // 0x01686920: FSUB s0, s12, s13          | S0 = ((next.y * next.y) - (((next.y * next.y) * next.y) * 0.5f));
            float val_6 = val_3 - val_5;
            // 0x01686924: FMUL s14, s14, s1          | S14 = (next.y * 0.5f);                  
            val_19 = val_19 * 0.5f;
            // 0x01686928: FSUB s3, s0, s14           | S3 = (((next.y * next.y) - (((next.y * next.y) * next.y) * 0.5f)) - (next.y * 0.5f));
            float val_7 = val_6 - val_19;
            // 0x0168692C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686930: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686934: MOV v0.16b, v11.16b        | V0 = previous.x;//m1                    
            // 0x01686938: MOV v1.16b, v10.16b        | V1 = previous.y;//m1                    
            // 0x0168693C: MOV v2.16b, v9.16b         | V2 = previous.z;//m1                    
            // 0x01686940: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = previous.x, y = previous.y, z = previous.z}, d:  float val_7 = val_6 - next.y);
            UnityEngine.Vector3 val_8 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = previous.x, y = previous.y, z = previous.z}, d:  val_7);
            // 0x01686944: MOV v9.16b, v0.16b         | V9 = val_8.x;//m1                       
            // 0x01686948: MOV v10.16b, v1.16b        | V10 = val_8.y;//m1                      
            // 0x0168694C: FMOV s0, #1.50000000       | S0 = 1.5;                               
            // 0x01686950: FMOV s1, #-2.50000000      | S1 = -2.5;                              
            // 0x01686954: FMUL s15, s15, s0          | S15 = (((next.y * next.y) * next.y) * 1.5f);
            val_4 = val_4 * 1.5f;
            // 0x01686958: FMUL s0, s12, s1           | S0 = ((next.y * next.y) * -2.5f);       
            float val_9 = val_3 * (-2.5f);
            // 0x0168695C: FADD s0, s15, s0           | S0 = ((((next.y * next.y) * next.y) * 1.5f) + ((next.y * next.y) * -2.5f));
            val_9 = val_4 + val_9;
            // 0x01686960: FMOV s1, #1.00000000       | S1 = 1;                                 
            // 0x01686964: MOV v11.16b, v2.16b        | V11 = val_8.z;//m1                      
            // 0x01686968: FADD s3, s0, s1            | S3 = (((((next.y * next.y) * next.y) * 1.5f) + ((next.y * next.y) * -2.5f)) + 1f);
            float val_10 = val_9 + 1f;
            // 0x0168696C: LDP s1, s2, [sp]           | S1 = start.y; S2 = start.z;              //  | 
            // 0x01686970: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686974: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686978: MOV v0.16b, v8.16b         | V0 = start.x;//m1                       
            // 0x0168697C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, d:  float val_10 = val_9 + 1f);
            UnityEngine.Vector3 val_11 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = start.x, y = start.y, z = start.z}, d:  val_10);
            // 0x01686980: MOV v3.16b, v0.16b         | V3 = val_11.x;//m1                      
            // 0x01686984: MOV v4.16b, v1.16b         | V4 = val_11.y;//m1                      
            // 0x01686988: MOV v5.16b, v2.16b         | V5 = val_11.z;//m1                      
            // 0x0168698C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686990: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686994: MOV v0.16b, v9.16b         | V0 = val_8.x;//m1                       
            // 0x01686998: MOV v1.16b, v10.16b        | V1 = val_8.y;//m1                       
            // 0x0168699C: MOV v2.16b, v11.16b        | V2 = val_8.z;//m1                       
            // 0x016869A0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
            UnityEngine.Vector3 val_12 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_8.x, y = val_8.y, z = val_8.z}, b:  new UnityEngine.Vector3() {x = val_11.x, y = val_11.y, z = val_11.z});
            // 0x016869A4: MOV v8.16b, v0.16b         | V8 = val_12.x;//m1                      
            // 0x016869A8: FADD s0, s12, s12          | S0 = ((next.y * next.y) + (next.y * next.y));
            float val_13 = val_3 + val_3;
            // 0x016869AC: FSUB s0, s0, s15           | S0 = (((next.y * next.y) + (next.y * next.y)) - (((next.y * next.y) * next.y) * 1.5f));
            val_13 = val_13 - val_4;
            // 0x016869B0: MOV v9.16b, v1.16b         | V9 = val_12.y;//m1                      
            // 0x016869B4: MOV v10.16b, v2.16b        | V10 = val_12.z;//m1                     
            // 0x016869B8: FADD s3, s14, s0           | S3 = ((next.y * 0.5f) + (((next.y * next.y) + (next.y * next.y)) - (((next.y * next.y) * next.y) * 1.5f)));
            float val_14 = val_19 + val_13;
            // 0x016869BC: LDP s0, s1, [sp, #8]       | S0 = end.x; S1 = val_2;                  //  | 
            // 0x016869C0: LDR s2, [sp, #0x10]        | S2 = end.y;                             
            // 0x016869C4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016869C8: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016869CC: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.x, y = val_2, z = end.y}, d:  float val_14 = next.y + val_13);
            UnityEngine.Vector3 val_15 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.x, y = val_2, z = end.y}, d:  val_14);
            // 0x016869D0: MOV v3.16b, v0.16b         | V3 = val_15.x;//m1                      
            // 0x016869D4: MOV v4.16b, v1.16b         | V4 = val_15.y;//m1                      
            // 0x016869D8: MOV v5.16b, v2.16b         | V5 = val_15.z;//m1                      
            // 0x016869DC: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x016869E0: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x016869E4: MOV v0.16b, v8.16b         | V0 = val_12.x;//m1                      
            // 0x016869E8: MOV v1.16b, v9.16b         | V1 = val_12.y;//m1                      
            // 0x016869EC: MOV v2.16b, v10.16b        | V2 = val_12.z;//m1                      
            // 0x016869F0: BL #0x2694984              | X0 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
            UnityEngine.Vector3 val_16 = UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_12.x, y = val_12.y, z = val_12.z}, b:  new UnityEngine.Vector3() {x = val_15.x, y = val_15.y, z = val_15.z});
            // 0x016869F4: MOV v8.16b, v0.16b         | V8 = val_16.x;//m1                      
            // 0x016869F8: FMOV s0, #0.50000000       | S0 = 0.5;                               
            float val_20 = 0.5f;
            // 0x016869FC: FMUL s0, s12, s0           | S0 = ((next.y * next.y) * 0.5f);        
            val_20 = val_3 * val_20;
            // 0x01686A00: MOV v9.16b, v1.16b         | V9 = val_16.y;//m1                      
            // 0x01686A04: MOV v10.16b, v2.16b        | V10 = val_16.z;//m1                     
            // 0x01686A08: FSUB s3, s13, s0           | S3 = ((((next.y * next.y) * next.y) * 0.5f) - ((next.y * next.y) * 0.5f));
            float val_17 = val_5 - val_20;
            // 0x01686A0C: LDP s0, s1, [sp, #0x14]    | S0 = end.z; S1 = val_1;                  //  | 
            // 0x01686A10: LDR s2, [sp, #0x1c]        | S2 = next.x;                            
            // 0x01686A14: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686A18: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686A1C: BL #0x2699140              | X0 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.z, y = val_1, z = next.x}, d:  float val_17 = val_5 - 0.5f);
            UnityEngine.Vector3 val_18 = UnityEngine.Vector3.op_Multiply(a:  new UnityEngine.Vector3() {x = end.z, y = val_1, z = next.x}, d:  val_17);
            // 0x01686A20: MOV v3.16b, v0.16b         | V3 = val_18.x;//m1                      
            // 0x01686A24: MOV v4.16b, v1.16b         | V4 = val_18.y;//m1                      
            // 0x01686A28: MOV v5.16b, v2.16b         | V5 = val_18.z;//m1                      
            // 0x01686A2C: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
            // 0x01686A30: MOV v0.16b, v8.16b         | V0 = val_16.x;//m1                      
            // 0x01686A34: MOV v1.16b, v9.16b         | V1 = val_16.y;//m1                      
            // 0x01686A38: MOV v2.16b, v10.16b        | V2 = val_16.z;//m1                      
            // 0x01686A3C: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x01686A40: SUB sp, x29, #0x50         | SP = (1152921513157343712 - 80) = 1152921513157343632 (0x10000001FDA63990);
            // 0x01686A44: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x01686A48: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x01686A4C: LDP d9, d8, [sp, #0x30]    | D9 = ; D8 = ;                            //  | 
            // 0x01686A50: LDP d11, d10, [sp, #0x20]  | D11 = ; D10 = ;                          //  | 
            // 0x01686A54: LDP d13, d12, [sp, #0x10]  | D13 = ; D12 = ;                          //  | 
            // 0x01686A58: LDP d15, d14, [sp], #0x60  | D15 = ; D14 = ;                          //  | 
            // 0x01686A5C: B #0x2694984               | return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
            return UnityEngine.Vector3.op_Addition(a:  new UnityEngine.Vector3() {x = val_16.x, y = val_16.y, z = val_16.z}, b:  new UnityEngine.Vector3() {x = val_18.x, y = val_18.y, z = val_18.z});
        
        }
    
    }

}
