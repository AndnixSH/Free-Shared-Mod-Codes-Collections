using UnityEngine;
internal sealed class DeflateManager.CompressFunc : MulticastDelegate
{
    // Methods
    //
    // Offset in libil2cpp.so: 0x026C54BC (40654012), len: 16  VirtAddr: 0x026C54BC RVA: 0x026C54BC token: 100663752 methodIndex: 21308 delegateWrapperIndex: 0 methodInvoker: 0
    public DeflateManager.CompressFunc(object object, IntPtr method)
    {
        //
        // Disasemble & Code
        // 0x026C54BC: LDR x8, [x2]               | X8 = method;                            
        // 0x026C54C0: STP x1, x2, [x0, #0x20]    | mem[1152921509704090576] = object;  mem[1152921509704090584] = method;  //  dest_result_addr=1152921509704090576 |  dest_result_addr=1152921509704090584
        mem[1152921509704090576] = object;
        mem[1152921509704090584] = method;
        // 0x026C54C4: STR x8, [x0, #0x10]        | mem[1152921509704090560] = method;       //  dest_result_addr=1152921509704090560
        mem[1152921509704090560] = method;
        // 0x026C54C8: RET                        |  return;                                
        return;
    
    }
    //
    // Offset in libil2cpp.so: 0x026C54CC (40654028), len: 528  VirtAddr: 0x026C54CC RVA: 0x026C54CC token: 100663753 methodIndex: 21309 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual Pathfinding.Ionic.Zlib.BlockState Invoke(Pathfinding.Ionic.Zlib.FlushType flush)
    {
        //
        // Disasemble & Code
        //  | 
        var val_7;
        //  | 
        var val_8;
        //  | 
        var val_9;
        label_1:
        // 0x026C54CC: STP x22, x21, [sp, #-0x30]! | stack[1152921509704206880] = ???;  stack[1152921509704206888] = ???;  //  dest_result_addr=1152921509704206880 |  dest_result_addr=1152921509704206888
        // 0x026C54D0: STP x20, x19, [sp, #0x10]  | stack[1152921509704206896] = ???;  stack[1152921509704206904] = ???;  //  dest_result_addr=1152921509704206896 |  dest_result_addr=1152921509704206904
        // 0x026C54D4: STP x29, x30, [sp, #0x20]  | stack[1152921509704206912] = ???;  stack[1152921509704206920] = ???;  //  dest_result_addr=1152921509704206912 |  dest_result_addr=1152921509704206920
        // 0x026C54D8: ADD x29, sp, #0x20         | X29 = (1152921509704206880 + 32) = 1152921509704206912 (0x100000012FD38A40);
        // 0x026C54DC: SUB sp, sp, #0x10          | SP = (1152921509704206880 - 16) = 1152921509704206864 (0x100000012FD38A10);
        // 0x026C54E0: MOV x22, x0                | X22 = 1152921509704218928 (0x100000012FD3B930);//ML01
        // 0x026C54E4: LDR x0, [x22, #0x58]       | 
        // 0x026C54E8: MOV w19, w1                | W19 = flush;//m1                        
        // 0x026C54EC: CBZ x0, #0x26c54f8         | if (this == null) goto label_0;         
        if(this == null)
        {
            goto label_0;
        }
        // 0x026C54F0: MOV w1, w19                | W1 = flush;//m1                         
        // 0x026C54F4: BL #0x26c54cc              |  R0 = label_1();                        
        label_0:
        // 0x026C54F8: LDR x0, [x22, #0x10]       | 
        // 0x026C54FC: STR x0, [sp, #8]           | stack[1152921509704206872] = this;       //  dest_result_addr=1152921509704206872
        // 0x026C5500: LDP x20, x21, [x22, #0x20] |                                          //  | 
        // 0x026C5504: MOV x0, x21                | X0 = X21;//m1                           
        // 0x026C5508: BL #0x2796f94              | X0 = sub_2796F94( ?? X21, ????);        
        // 0x026C550C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x026C5510: BL #0x27c09a4              | X0 = sub_27C09A4( ?? X21, ????);        
        // 0x026C5514: AND w8, w0, #1             | W8 = (X21 & 1);                         
        var val_1 = X21 & 1;
        // 0x026C5518: TBZ w8, #0, #0x26c55a8     | if (((X21 & 1) & 0x1) == 0) goto label_2;
        if((val_1 & 1) == 0)
        {
            goto label_2;
        }
        // 0x026C551C: LDRSH w8, [x21, #0x4c]     | W8 = X21 + 76;                          
        // 0x026C5520: CMN w8, #1                 | STATE = COMPARE(X21 + 76, 0x1)          
        // 0x026C5524: B.EQ #0x26c55bc            | if (X21 + 76 == 0x1) goto label_6;      
        if((X21 + 76) == 1)
        {
            goto label_6;
        }
        // 0x026C5528: CBZ x20, #0x26c5538        | if (X20 == 0) goto label_4;             
        if(X20 == 0)
        {
            goto label_4;
        }
        // 0x026C552C: LDR x8, [x20]              | X8 = X20;                               
        // 0x026C5530: LDRB w8, [x8, #0xed]       | W8 = X20 + 237;                         
        // 0x026C5534: TBNZ w8, #0, #0x26c55bc    | if ((X20 + 237 & 0x1) != 0) goto label_6;
        if(((X20 + 237) & 1) != 0)
        {
            goto label_6;
        }
        label_4:
        // 0x026C5538: LDR x8, [x22, #0x18]       | 
        // 0x026C553C: CBZ x8, #0x26c55bc         | if (X20 + 237 == 0) goto label_6;       
        if((X20 + 237) == 0)
        {
            goto label_6;
        }
        // 0x026C5540: MOV x0, x21                | X0 = X21;//m1                           
        // 0x026C5544: BL #0x27c0990              | X0 = sub_27C0990( ?? X21, ????);        
        // 0x026C5548: MOV w22, w0                | W22 = X21;//m1                          
        // 0x026C554C: MOV x0, x21                | X0 = X21;//m1                           
        // 0x026C5550: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_2 = X21.pressedSprite;
        // 0x026C5554: BL #0x2774ea0              | X0 = sub_2774EA0( ?? val_2, ????);      
        // 0x026C5558: TBZ w22, #0, #0x26c5608    | if ((X21 & 0x1) == 0) goto label_7;     
        if((X21 & 1) == 0)
        {
            goto label_7;
        }
        // 0x026C555C: TBZ w0, #0, #0x26c5664     | if ((val_2 & 0x1) == 0) goto label_8;   
        if((val_2 & 1) == 0)
        {
            goto label_8;
        }
        // 0x026C5560: LDR x8, [x20]              | X8 = X20;                               
        var val_11 = X20;
        // 0x026C5564: LDR x1, [x21, #0x18]       | X1 = X21 + 24;                          
        // 0x026C5568: LDRH w2, [x21, #0x4c]      | W2 = X21 + 76;                          
        // 0x026C556C: LDRH w9, [x8, #0x102]      | W9 = X20 + 258;                         
        // 0x026C5570: CBZ x9, #0x26c559c         | if (X20 + 258 == 0) goto label_9;       
        if((X20 + 258) == 0)
        {
            goto label_9;
        }
        // 0x026C5574: LDR x10, [x8, #0x98]       | X10 = X20 + 152;                        
        var val_5 = X20 + 152;
        // 0x026C5578: MOV x11, xzr               | X11 = 0 (0x0);//ML01                    
        var val_6 = 0;
        // 0x026C557C: ADD x10, x10, #8           | X10 = (X20 + 152 + 8);                  
        val_5 = val_5 + 8;
        label_11:
        // 0x026C5580: LDUR x12, [x10, #-8]       | X12 = (X20 + 152 + 8) + -8;             
        // 0x026C5584: CMP x12, x1                | STATE = COMPARE((X20 + 152 + 8) + -8, X21 + 24)
        // 0x026C5588: B.EQ #0x26c5688            | if ((X20 + 152 + 8) + -8 == X21 + 24) goto label_10;
        if(((X20 + 152 + 8) + -8) == (X21 + 24))
        {
            goto label_10;
        }
        // 0x026C558C: ADD x11, x11, #1           | X11 = (0 + 1);                          
        val_6 = val_6 + 1;
        // 0x026C5590: ADD x10, x10, #0x10        | X10 = ((X20 + 152 + 8) + 16);           
        val_5 = val_5 + 16;
        // 0x026C5594: CMP x11, x9                | STATE = COMPARE((0 + 1), X20 + 258)     
        // 0x026C5598: B.LO #0x26c5580            | if (0 < X20 + 258) goto label_11;       
        if(val_6 < (X20 + 258))
        {
            goto label_11;
        }
        label_9:
        // 0x026C559C: MOV x0, x20                | X0 = X20;//m1                           
        val_7 = X20;
        // 0x026C55A0: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
        // 0x026C55A4: B #0x26c5698               |  goto label_12;                         
        goto label_12;
        label_2:
        // 0x026C55A8: LDRB w8, [x21, #0x4e]      | W8 = X21 + 78;                          
        // 0x026C55AC: CMP w8, #1                 | STATE = COMPARE(X21 + 78, 0x1)          
        // 0x026C55B0: B.NE #0x26c55e0            | if (X21 + 78 != 0x1) goto label_13;     
        if((X21 + 78) != 1)
        {
            goto label_13;
        }
        // 0x026C55B4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026C55B8: B #0x26c55c0               |  goto label_14;                         
        goto label_14;
        label_6:
        // 0x026C55BC: MOV x0, x20                | X0 = X20;//m1                           
        label_14:
        // 0x026C55C0: LDR x3, [sp, #8]           | X3 = this;                              
        // 0x026C55C4: MOV w1, w19                | W1 = flush;//m1                         
        // 0x026C55C8: MOV x2, x21                | X2 = X21;//m1                           
        label_23:
        // 0x026C55CC: SUB sp, x29, #0x20         | SP = (1152921509704206912 - 32) = 1152921509704206880 (0x100000012FD38A20);
        // 0x026C55D0: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026C55D4: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026C55D8: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026C55DC: BR x3                      | X0 = this( ?? X20, ????);               
        label_13:
        // 0x026C55E0: LDR x4, [sp, #8]           | X4 = this;                              
        // 0x026C55E4: MOV x0, xzr                | X0 = 0 (0x0);//ML01                     
        // 0x026C55E8: MOV x1, x20                | X1 = X20;//m1                           
        // 0x026C55EC: MOV w2, w19                | W2 = flush;//m1                         
        // 0x026C55F0: MOV x3, x21                | X3 = X21;//m1                           
        // 0x026C55F4: SUB sp, x29, #0x20         | SP = (1152921509704206912 - 32) = 1152921509704206880 (0x100000012FD38A20);
        // 0x026C55F8: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026C55FC: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026C5600: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026C5604: BR x4                      | X0 = this( ?? 0x0, ????);               
        label_7:
        // 0x026C5608: LDRH w22, [x21, #0x4c]     | W22 = X21 + 76;                         
        // 0x026C560C: TBZ w0, #0, #0x26c5678     | if ((val_2 & 0x1) == 0) goto label_15;  
        if((val_2 & 1) == 0)
        {
            goto label_15;
        }
        // 0x026C5610: MOV x0, x21                | X0 = X21;//m1                           
        // 0x026C5614: BL #0x27c0a0c              | X0 = X21.get_pressedSprite();           
        UnityEngine.Sprite val_3 = X21.pressedSprite;
        // 0x026C5618: LDR x9, [x20]              | X9 = X20;                               
        // 0x026C561C: MOV x8, x0                 | X8 = val_3;//m1                         
        // 0x026C5620: LDRH w10, [x9, #0x102]     | W10 = X20 + 258;                        
        // 0x026C5624: CBZ x10, #0x26c5650        | if (X20 + 258 == 0) goto label_16;      
        if((X20 + 258) == 0)
        {
            goto label_16;
        }
        // 0x026C5628: LDR x11, [x9, #0x98]       | X11 = X20 + 152;                        
        var val_7 = X20 + 152;
        // 0x026C562C: MOV x12, xzr               | X12 = 0 (0x0);//ML01                    
        var val_8 = 0;
        // 0x026C5630: ADD x11, x11, #8           | X11 = (X20 + 152 + 8);                  
        val_7 = val_7 + 8;
        label_18:
        // 0x026C5634: LDUR x13, [x11, #-8]       | X13 = (X20 + 152 + 8) + -8;             
        // 0x026C5638: CMP x13, x8                | STATE = COMPARE((X20 + 152 + 8) + -8, val_3)
        // 0x026C563C: B.EQ #0x26c56bc            | if ((X20 + 152 + 8) + -8 == val_3) goto label_17;
        if(((X20 + 152 + 8) + -8) == val_3)
        {
            goto label_17;
        }
        // 0x026C5640: ADD x12, x12, #1           | X12 = (0 + 1);                          
        val_8 = val_8 + 1;
        // 0x026C5644: ADD x11, x11, #0x10        | X11 = ((X20 + 152 + 8) + 16);           
        val_7 = val_7 + 16;
        // 0x026C5648: CMP x12, x10               | STATE = COMPARE((0 + 1), X20 + 258)     
        // 0x026C564C: B.LO #0x26c5634            | if (0 < X20 + 258) goto label_18;       
        if(val_8 < (X20 + 258))
        {
            goto label_18;
        }
        label_16:
        // 0x026C5650: MOV x0, x20                | X0 = X20;//m1                           
        val_8 = X20;
        // 0x026C5654: MOV x1, x8                 | X1 = val_3;//m1                         
        // 0x026C5658: MOV w2, w22                | W2 = X21 + 76;//m1                      
        // 0x026C565C: BL #0x2776c24              | X0 = sub_2776C24( ?? X20, ????);        
        // 0x026C5660: B #0x26c56cc               |  goto label_19;                         
        goto label_19;
        label_8:
        // 0x026C5664: LDRH w8, [x21, #0x4c]      | W8 = X21 + 76;                          
        // 0x026C5668: LDR x9, [x20]              | X9 = X20;                               
        // 0x026C566C: ADD x8, x9, x8, lsl #4     | X8 = (X20 + (X21 + 76) << 4);           
        var val_4 = X20 + ((X21 + 76) << 4);
        // 0x026C5670: LDR x0, [x8, #0x118]       | X0 = (X20 + (X21 + 76) << 4) + 280;     
        val_9 = mem[(X20 + (X21 + 76) << 4) + 280];
        val_9 = (X20 + (X21 + 76) << 4) + 280;
        // 0x026C5674: B #0x26c569c               |  goto label_20;                         
        goto label_20;
        label_15:
        // 0x026C5678: LDR x8, [x20]              | X8 = X20;                               
        var val_9 = X20;
        // 0x026C567C: ADD x8, x8, w22, uxtw #4   | X8 = (X20 + X21 + 76);                  
        val_9 = val_9 + (X21 + 76);
        // 0x026C5680: LDP x3, x2, [x8, #0x110]   | X3 = (X20 + X21 + 76) + 272; X2 = (X20 + X21 + 76) + 272 + 8; //  | 
        // 0x026C5684: B #0x26c56d0               |  goto label_21;                         
        goto label_21;
        label_10:
        // 0x026C5688: LDR w9, [x10]              | W9 = (X20 + 152 + 8);                   
        var val_10 = val_5;
        // 0x026C568C: ADD w9, w9, w2             | W9 = ((X20 + 152 + 8) + X21 + 76);      
        val_10 = val_10 + (X21 + 76);
        // 0x026C5690: ADD x8, x8, w9, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
        val_11 = val_11 + val_10;
        // 0x026C5694: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
        val_7 = val_11 + 272;
        label_12:
        // 0x026C5698: LDR x0, [x0, #8]           | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
        val_9 = mem[((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8];
        val_9 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
        label_20:
        // 0x026C569C: MOV x1, x21                | X1 = X21;//m1                           
        // 0x026C56A0: BL #0x2796ec8              | X0 = sub_2796EC8( ?? ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8, ????);
        // 0x026C56A4: MOV x8, x0                 | X8 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
        // 0x026C56A8: LDR x3, [x8]               | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;
        // 0x026C56AC: MOV x0, x20                | X0 = X20;//m1                           
        // 0x026C56B0: MOV w1, w19                | W1 = flush;//m1                         
        // 0x026C56B4: MOV x2, x8                 | X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8;//m1
        // 0x026C56B8: B #0x26c55cc               |  goto label_23;                         
        goto label_23;
        label_17:
        // 0x026C56BC: LDR w8, [x11]              | W8 = (X20 + 152 + 8);                   
        var val_12 = val_7;
        // 0x026C56C0: ADD w8, w8, w22            | W8 = ((X20 + 152 + 8) + X21 + 76);      
        val_12 = val_12 + (X21 + 76);
        // 0x026C56C4: ADD x8, x9, w8, uxtw #4    | X8 = (X20 + ((X20 + 152 + 8) + X21 + 76));
        val_12 = X20 + val_12;
        // 0x026C56C8: ADD x0, x8, #0x110         | X0 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272);
        val_8 = val_12 + 272;
        label_19:
        // 0x026C56CC: LDP x3, x2, [x0]           | X3 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272); X2 = ((X20 + ((X20 + 152 + 8) + X21 + 76)) + 272) + 8; //  | 
        label_21:
        // 0x026C56D0: MOV x0, x20                | X0 = X20;//m1                           
        // 0x026C56D4: MOV w1, w19                | W1 = flush;//m1                         
        // 0x026C56D8: B #0x26c55cc               |  goto label_23;                         
        goto label_23;
    
    }
    //
    // Offset in libil2cpp.so: 0x026C56DC (40654556), len: 140  VirtAddr: 0x026C56DC RVA: 0x026C56DC token: 100663754 methodIndex: 21310 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual System.IAsyncResult BeginInvoke(Pathfinding.Ionic.Zlib.FlushType flush, System.AsyncCallback callback, object object)
    {
        //
        // Disasemble & Code
        // 0x026C56DC: STP x22, x21, [sp, #-0x30]! | stack[1152921509704347552] = ???;  stack[1152921509704347560] = ???;  //  dest_result_addr=1152921509704347552 |  dest_result_addr=1152921509704347560
        // 0x026C56E0: STP x20, x19, [sp, #0x10]  | stack[1152921509704347568] = ???;  stack[1152921509704347576] = ???;  //  dest_result_addr=1152921509704347568 |  dest_result_addr=1152921509704347576
        // 0x026C56E4: STP x29, x30, [sp, #0x20]  | stack[1152921509704347584] = ???;  stack[1152921509704347592] = ???;  //  dest_result_addr=1152921509704347584 |  dest_result_addr=1152921509704347592
        // 0x026C56E8: ADD x29, sp, #0x20         | X29 = (1152921509704347552 + 32) = 1152921509704347584 (0x100000012FD5AFC0);
        // 0x026C56EC: SUB sp, sp, #0x20          | SP = (1152921509704347552 - 32) = 1152921509704347520 (0x100000012FD5AF80);
        // 0x026C56F0: ADRP x22, #0x3742000       | X22 = 57942016 (0x3742000);             
        // 0x026C56F4: LDRB w8, [x22, #0x5d0]     | W8 = (bool)static_value_037425D0;       
        // 0x026C56F8: MOV x19, x3                | X19 = object;//m1                       
        // 0x026C56FC: MOV x20, x2                | X20 = callback;//m1                     
        // 0x026C5700: MOV x21, x0                | X21 = 1152921509704359600 (0x100000012FD5DEB0);//ML01
        // 0x026C5704: STR w1, [sp, #0x1c]        | stack[1152921509704347548] = flush;      //  dest_result_addr=1152921509704347548
        // 0x026C5708: TBNZ w8, #0, #0x26c5724    | if (static_value_037425D0 == true) goto label_0;
        // 0x026C570C: ADRP x8, #0x365a000        | X8 = 56991744 (0x365A000);              
        // 0x026C5710: LDR x8, [x8, #0x278]       | X8 = 0x2B92710;                         
        // 0x026C5714: LDR w0, [x8]               | W0 = 0x2089;                            
        // 0x026C5718: BL #0x2782188              | X0 = sub_2782188( ?? 0x2089, ????);     
        // 0x026C571C: ORR w8, wzr, #1            | W8 = 1(0x1);                            
        // 0x026C5720: STRB w8, [x22, #0x5d0]     | static_value_037425D0 = true;            //  dest_result_addr=57943504
        label_0:
        // 0x026C5724: ADRP x8, #0x3605000        | X8 = 56643584 (0x3605000);              
        // 0x026C5728: LDR x8, [x8, #0xd20]       | X8 = 1152921504753278976;               
        // 0x026C572C: ADD x1, sp, #0x1c          | X1 = (1152921509704347520 + 28) = 1152921509704347548 (0x100000012FD5AF9C);
        // 0x026C5730: LDR x0, [x8]               | X0 = typeof(Pathfinding.Ionic.Zlib.FlushType);
        // 0x026C5734: STP xzr, xzr, [sp, #8]     | stack[1152921509704347528] = 0x0;  stack[1152921509704347536] = 0x0;  //  dest_result_addr=1152921509704347528 |  dest_result_addr=1152921509704347536
        // 0x026C5738: BL #0x27bc028              | X0 = 1152921509704403888 = (Il2CppObject*)Box((RuntimeClass*)typeof(Pathfinding.Ionic.Zlib.FlushType), flush);
        // 0x026C573C: STR x0, [sp, #8]           | stack[1152921509704347528] = flush;      //  dest_result_addr=1152921509704347528
        // 0x026C5740: ADD x1, sp, #8             | X1 = (1152921509704347520 + 8) = 1152921509704347528 (0x100000012FD5AF88);
        // 0x026C5744: MOV x0, x21                | X0 = 1152921509704359600 (0x100000012FD5DEB0);//ML01
        // 0x026C5748: MOV x2, x20                | X2 = callback;//m1                      
        // 0x026C574C: MOV x3, x19                | X3 = object;//m1                        
        // 0x026C5750: BL #0x278fb00              | X0 = sub_278FB00( ?? this, ????);       
        // 0x026C5754: SUB sp, x29, #0x20         | SP = (1152921509704347584 - 32) = 1152921509704347552 (0x100000012FD5AFA0);
        // 0x026C5758: LDP x29, x30, [sp, #0x20]  | X29 = ; X30 = ;                          //  | 
        // 0x026C575C: LDP x20, x19, [sp, #0x10]  | X20 = ; X19 = ;                          //  | 
        // 0x026C5760: LDP x22, x21, [sp], #0x30  | X22 = ; X21 = ;                          //  | 
        // 0x026C5764: RET                        |  return (System.IAsyncResult)this;      
        return (System.IAsyncResult)this;
        //  |  // // {name=val_0, type=System.IAsyncResult, size=8, nGRN=0 }
    
    }
    //
    // Offset in libil2cpp.so: 0x026C5768 (40654696), len: 64  VirtAddr: 0x026C5768 RVA: 0x026C5768 token: 100663755 methodIndex: 21311 delegateWrapperIndex: 0 methodInvoker: 0
    public virtual Pathfinding.Ionic.Zlib.BlockState EndInvoke(System.IAsyncResult result)
    {
        //
        // Disasemble & Code
        // 0x026C5768: STP x20, x19, [sp, #-0x20]! | stack[1152921509704480048] = ???;  stack[1152921509704480056] = ???;  //  dest_result_addr=1152921509704480048 |  dest_result_addr=1152921509704480056
        // 0x026C576C: STP x29, x30, [sp, #0x10]  | stack[1152921509704480064] = ???;  stack[1152921509704480072] = ???;  //  dest_result_addr=1152921509704480064 |  dest_result_addr=1152921509704480072
        // 0x026C5770: ADD x29, sp, #0x10         | X29 = (1152921509704480048 + 16) = 1152921509704480064 (0x100000012FD7B540);
        // 0x026C5774: MOV x8, x1                 | X8 = result;//m1                        
        // 0x026C5778: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
        // 0x026C577C: MOV x0, x8                 | X0 = result;//m1                        
        // 0x026C5780: BL #0x278fde8              | X0 = sub_278FDE8( ?? result, ????);     
        // 0x026C5784: MOV x19, x0                | X19 = result;//m1                       
        // 0x026C5788: CBNZ x19, #0x26c5790       | if (result != null) goto label_0;       
        if(result != null)
        {
            goto label_0;
        }
        // 0x026C578C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? result, ????);     
        label_0:
        // 0x026C5790: MOV x0, x19                | X0 = result;//m1                        
        // 0x026C5794: BL #0x27bc4e8              | result.System.IDisposable.Dispose();    
        result.System.IDisposable.Dispose();
        // 0x026C5798: LDR w0, [x0]               | W0 = typeof(System.IAsyncResult);       
        // 0x026C579C: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
        // 0x026C57A0: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
        // 0x026C57A4: RET                        |  return (Pathfinding.Ionic.Zlib.BlockState)typeof(System.IAsyncResult);
        return (Pathfinding.Ionic.Zlib.BlockState)null;
        //  |  // // {name=val_0, type=Pathfinding.Ionic.Zlib.BlockState, size=8, nGRN=0 }
    
    }

}
