using UnityEngine;

namespace Pathfinding
{
    [UnityEngine.AddComponentMenu] // 0x285C3B4
    [Serializable]
    public class AdvancedSmooth : MonoModifier
    {
        // Fields
        public float turningRadius; //  0x00000024
        public Pathfinding.AdvancedSmooth.MaxTurn turnConstruct1; //  0x00000028
        public Pathfinding.AdvancedSmooth.ConstantTurn turnConstruct2; //  0x00000030
        
        // Properties
        public override Pathfinding.ModifierData input { get; }
        public override Pathfinding.ModifierData output { get; }
        
        // Methods
        //
        // Offset in libil2cpp.so: 0x00D1E2E4 (13755108), len: 136  VirtAddr: 0x00D1E2E4 RVA: 0x00D1E2E4 token: 100683399 methodIndex: 49702 delegateWrapperIndex: 0 methodInvoker: 0
        public AdvancedSmooth()
        {
            //
            // Disasemble & Code
            // 0x00D1E2E4: STP x20, x19, [sp, #-0x20]! | stack[1152921513478590624] = ???;  stack[1152921513478590632] = ???;  //  dest_result_addr=1152921513478590624 |  dest_result_addr=1152921513478590632
            // 0x00D1E2E8: STP x29, x30, [sp, #0x10]  | stack[1152921513478590640] = ???;  stack[1152921513478590648] = ???;  //  dest_result_addr=1152921513478590640 |  dest_result_addr=1152921513478590648
            // 0x00D1E2EC: ADD x29, sp, #0x10         | X29 = (1152921513478590624 + 16) = 1152921513478590640 (0x1000000210CC10B0);
            // 0x00D1E2F0: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1E2F4: LDRB w8, [x20, #0x2dd]     | W8 = (bool)static_value_037342DD;       
            // 0x00D1E2F8: MOV x19, x0                | X19 = 1152921513478602656 (0x1000000210CC3FA0);//ML01
            // 0x00D1E2FC: TBNZ w8, #0, #0xd1e318     | if (static_value_037342DD == true) goto label_0;
            // 0x00D1E300: ADRP x8, #0x3638000        | X8 = 56852480 (0x3638000);              
            // 0x00D1E304: LDR x8, [x8, #0x6a0]       | X8 = 0x2B8AA5C;                         
            // 0x00D1E308: LDR w0, [x8]               | W0 = 0x155;                             
            // 0x00D1E30C: BL #0x2782188              | X0 = sub_2782188( ?? 0x155, ????);      
            // 0x00D1E310: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1E314: STRB w8, [x20, #0x2dd]     | static_value_037342DD = true;            //  dest_result_addr=57885405
            label_0:
            // 0x00D1E318: ORR w8, wzr, #0x3f800000   | W8 = 1065353216(0x3F800000);            
            // 0x00D1E31C: STR w8, [x19, #0x24]       | this.turningRadius = 1;                  //  dest_result_addr=1152921513478602692
            this.turningRadius = 1f;
            // 0x00D1E320: ADRP x8, #0x361c000        | X8 = 56737792 (0x361C000);              
            // 0x00D1E324: LDR x8, [x8, #0x880]       | X8 = 1152921504848433152;               
            // 0x00D1E328: LDR x0, [x8]               | X0 = typeof(AdvancedSmooth.MaxTurn);    
            AdvancedSmooth.MaxTurn val_1 = null;
            // 0x00D1E32C: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AdvancedSmooth.MaxTurn), ????);
            // 0x00D1E330: MOV x20, x0                | X20 = 1152921504848433152 (0x100000000E665000);//ML01
            // 0x00D1E334: BL #0xd1e36c               | .ctor();                                
            val_1 = new AdvancedSmooth.MaxTurn();
            // 0x00D1E338: STR x20, [x19, #0x28]      | this.turnConstruct1 = typeof(AdvancedSmooth.MaxTurn);  //  dest_result_addr=1152921513478602696
            this.turnConstruct1 = val_1;
            // 0x00D1E33C: ADRP x8, #0x362e000        | X8 = 56811520 (0x362E000);              
            // 0x00D1E340: LDR x8, [x8, #0xb40]       | X8 = 1152921504848486400;               
            // 0x00D1E344: LDR x0, [x8]               | X0 = typeof(AdvancedSmooth.ConstantTurn);
            AdvancedSmooth.ConstantTurn val_2 = null;
            // 0x00D1E348: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(AdvancedSmooth.ConstantTurn), ????);
            // 0x00D1E34C: MOV x20, x0                | X20 = 1152921504848486400 (0x100000000E672000);//ML01
            // 0x00D1E350: BL #0xd1e424               | .ctor();                                
            val_2 = new AdvancedSmooth.ConstantTurn();
            // 0x00D1E354: STR x20, [x19, #0x30]      | this.turnConstruct2 = typeof(AdvancedSmooth.ConstantTurn);  //  dest_result_addr=1152921513478602704
            this.turnConstruct2 = val_2;
            // 0x00D1E358: LDP x29, x30, [sp, #0x10]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1E35C: MOV x0, x19                | X0 = 1152921513478602656 (0x1000000210CC3FA0);//ML01
            // 0x00D1E360: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E364: LDP x20, x19, [sp], #0x20  | X20 = ; X19 = ;                          //  | 
            // 0x00D1E368: B #0x155916c               | this..ctor(); return;                   
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1E494 (13755540), len: 8  VirtAddr: 0x00D1E494 RVA: 0x00D1E494 token: 100683400 methodIndex: 49703 delegateWrapperIndex: 0 methodInvoker: 0
        public override Pathfinding.ModifierData get_input()
        {
            //
            // Disasemble & Code
            // 0x00D1E494: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00D1E498: RET                        |  return (Pathfinding.ModifierData)0x8;  
            return (Pathfinding.ModifierData)8;
            //  |  // // {name=val_0, type=Pathfinding.ModifierData, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1E49C (13755548), len: 8  VirtAddr: 0x00D1E49C RVA: 0x00D1E49C token: 100683401 methodIndex: 49704 delegateWrapperIndex: 0 methodInvoker: 0
        public override Pathfinding.ModifierData get_output()
        {
            //
            // Disasemble & Code
            // 0x00D1E49C: ORR w0, wzr, #8            | W0 = 8(0x8);                            
            // 0x00D1E4A0: RET                        |  return (Pathfinding.ModifierData)0x8;  
            return (Pathfinding.ModifierData)8;
            //  |  // // {name=val_0, type=Pathfinding.ModifierData, size=8, nGRN=0 }
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1E4A4 (13755556), len: 812  VirtAddr: 0x00D1E4A4 RVA: 0x00D1E4A4 token: 100683402 methodIndex: 49705 delegateWrapperIndex: 0 methodInvoker: 0
        public override void Apply(Pathfinding.Path p, Pathfinding.ModifierData source)
        {
            //
            // Disasemble & Code
            //  | 
            var val_7;
            //  | 
            ConstantTurn val_8;
            //  | 
            int val_9;
            // 0x00D1E4A4: STP x28, x27, [sp, #-0x60]! | stack[1152921513479005408] = ???;  stack[1152921513479005416] = ???;  //  dest_result_addr=1152921513479005408 |  dest_result_addr=1152921513479005416
            // 0x00D1E4A8: STP x26, x25, [sp, #0x10]  | stack[1152921513479005424] = ???;  stack[1152921513479005432] = ???;  //  dest_result_addr=1152921513479005424 |  dest_result_addr=1152921513479005432
            // 0x00D1E4AC: STP x24, x23, [sp, #0x20]  | stack[1152921513479005440] = ???;  stack[1152921513479005448] = ???;  //  dest_result_addr=1152921513479005440 |  dest_result_addr=1152921513479005448
            // 0x00D1E4B0: STP x22, x21, [sp, #0x30]  | stack[1152921513479005456] = ???;  stack[1152921513479005464] = ???;  //  dest_result_addr=1152921513479005456 |  dest_result_addr=1152921513479005464
            // 0x00D1E4B4: STP x20, x19, [sp, #0x40]  | stack[1152921513479005472] = ???;  stack[1152921513479005480] = ???;  //  dest_result_addr=1152921513479005472 |  dest_result_addr=1152921513479005480
            // 0x00D1E4B8: STP x29, x30, [sp, #0x50]  | stack[1152921513479005488] = ???;  stack[1152921513479005496] = ???;  //  dest_result_addr=1152921513479005488 |  dest_result_addr=1152921513479005496
            // 0x00D1E4BC: ADD x29, sp, #0x50         | X29 = (1152921513479005408 + 80) = 1152921513479005488 (0x1000000210D26530);
            // 0x00D1E4C0: SUB sp, sp, #0x10          | SP = (1152921513479005408 - 16) = 1152921513479005392 (0x1000000210D264D0);
            // 0x00D1E4C4: ADRP x20, #0x3734000       | X20 = 57884672 (0x3734000);             
            // 0x00D1E4C8: LDRB w8, [x20, #0x2de]     | W8 = (bool)static_value_037342DE;       
            // 0x00D1E4CC: MOV x19, x1                | X19 = p;//m1                            
            // 0x00D1E4D0: MOV x22, x0                | X22 = 1152921513479017504 (0x1000000210D29420);//ML01
            // 0x00D1E4D4: TBNZ w8, #0, #0xd1e4f0     | if (static_value_037342DE == true) goto label_0;
            // 0x00D1E4D8: ADRP x8, #0x35c8000        | X8 = 56393728 (0x35C8000);              
            // 0x00D1E4DC: LDR x8, [x8, #0xaf0]       | X8 = 0x2B8AA60;                         
            // 0x00D1E4E0: LDR w0, [x8]               | W0 = 0x156;                             
            // 0x00D1E4E4: BL #0x2782188              | X0 = sub_2782188( ?? 0x156, ????);      
            // 0x00D1E4E8: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1E4EC: STRB w8, [x20, #0x2de]     | static_value_037342DE = true;            //  dest_result_addr=57885406
            label_0:
            // 0x00D1E4F0: CBNZ x19, #0xd1e4f8        | if (p != null) goto label_1;            
            if(p != null)
            {
                goto label_1;
            }
            // 0x00D1E4F4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x156, ????);      
            label_1:
            // 0x00D1E4F8: LDR x20, [x19, #0x68]      | X20 = p.vectorPath; //P2                
            // 0x00D1E4FC: CBNZ x20, #0xd1e504        | if (p.vectorPath != null) goto label_2; 
            if(p.vectorPath != null)
            {
                goto label_2;
            }
            // 0x00D1E500: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x156, ????);      
            label_2:
            // 0x00D1E504: ADRP x8, #0x3667000        | X8 = 57044992 (0x3667000);              
            // 0x00D1E508: LDR x8, [x8, #0x790]       | X8 = 1152921513167055872;               
            // 0x00D1E50C: MOV x0, x20                | X0 = p.vectorPath;//m1                  
            // 0x00D1E510: LDR x1, [x8]               | X1 = public T[] System.Collections.Generic.List<UnityEngine.Vector3>::ToArray();
            // 0x00D1E514: BL #0x2643064              | X0 = p.vectorPath.ToArray();            
            T[] val_1 = p.vectorPath.ToArray();
            // 0x00D1E518: MOV x21, x0                | X21 = val_1;//m1                        
            // 0x00D1E51C: CBZ x21, #0xd1e7b0         | if (val_1 == null) goto label_4;        
            if(val_1 == null)
            {
                goto label_4;
            }
            // 0x00D1E520: LDR w8, [x21, #0x18]       | W8 = val_1.Length; //P2                 
            // 0x00D1E524: CMP w8, #3                 | STATE = COMPARE(val_1.Length, 0x3)      
            // 0x00D1E528: B.LT #0xd1e7b0             | if (val_1.Length < 3) goto label_4;     
            if(val_1.Length < 3)
            {
                goto label_4;
            }
            // 0x00D1E52C: ADRP x8, #0x3641000        | X8 = 56889344 (0x3641000);              
            // 0x00D1E530: LDR x8, [x8, #0x968]       | X8 = 1152921504616644608;               
            // 0x00D1E534: LDR x0, [x8]               | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<UnityEngine.Vector3> val_2 = null;
            // 0x00D1E538: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00D1E53C: ADRP x8, #0x35c2000        | X8 = 56369152 (0x35C2000);              
            // 0x00D1E540: LDR x8, [x8, #0xe90]       | X8 = 1152921510909820656;               
            // 0x00D1E544: MOV x20, x0                | X20 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E548: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::.ctor();
            // 0x00D1E54C: BL #0x263edc8              | .ctor();                                
            val_2 = new System.Collections.Generic.List<UnityEngine.Vector3>();
            // 0x00D1E550: CBNZ x20, #0xd1e558        | if ( != 0) goto label_5;                
            if(null != 0)
            {
                goto label_5;
            }
            // 0x00D1E554: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? .ctor(), ????);    
            label_5:
            // 0x00D1E558: LDR w8, [x21, #0x18]       | W8 = val_1.Length; //P2                 
            // 0x00D1E55C: CBNZ w8, #0xd1e56c         | if (val_1.Length != 0) goto label_6;    
            if(val_1.Length != 0)
            {
                goto label_6;
            }
            // 0x00D1E560: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? .ctor(), ????);    
            // 0x00D1E564: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E568: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? .ctor(), ????);    
            label_6:
            // 0x00D1E56C: ADRP x8, #0x361b000        | X8 = 56733696 (0x361B000);              
            // 0x00D1E570: LDP s0, s1, [x21, #0x20]   | S0 = val_1[0] S1 = val_1[0]              //  | 
            T val_7 = val_1[0];
            T val_8 = val_1[0];
            // 0x00D1E574: LDR x8, [x8, #0x7b0]       | X8 = 1152921510909120752;               
            // 0x00D1E578: LDR s2, [x21, #0x28]       | S2 = val_1[1]                           
            T val_9 = val_1[1];
            // 0x00D1E57C: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E580: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
            // 0x00D1E584: BL #0x263fe28              | Add(item:  new UnityEngine.Vector3() {x = val_1[0], y = val_1[0], z = val_1[1]});
            Add(item:  new UnityEngine.Vector3() {x = val_7, y = val_8, z = val_9});
            // 0x00D1E588: ADRP x27, #0x3640000       | X27 = 56885248 (0x3640000);             
            // 0x00D1E58C: LDR x27, [x27, #0x640]     | X27 = 1152921504848539648;              
            // 0x00D1E590: LDR w23, [x22, #0x24]      | W23 = this.turningRadius; //P2          
            // 0x00D1E594: LDR x0, [x27]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
            val_7 = null;
            // 0x00D1E598: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
            // 0x00D1E59C: TBZ w8, #0, #0xd1e5b0      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_8;
            // 0x00D1E5A0: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
            // 0x00D1E5A4: CBNZ w8, #0xd1e5b0         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_8;
            // 0x00D1E5A8: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
            // 0x00D1E5AC: LDR x0, [x27]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
            val_7 = null;
            label_8:
            // 0x00D1E5B0: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
            // 0x00D1E5B4: STR w23, [x8]              | AdvancedSmooth.TurnConstructor.ThreeSixtyRadians = this.turningRadius;  //  dest_result_addr=1152921504848543744
            AdvancedSmooth.TurnConstructor.ThreeSixtyRadians = this.turningRadius;
            // 0x00D1E5B8: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            // 0x00D1E5BC: SUB w9, w8, #1             | W9 = (val_1.Length - 1);                
            int val_3 = val_1.Length - 1;
            // 0x00D1E5C0: CMP w9, #2                 | STATE = COMPARE((val_1.Length - 1), 0x2)
            // 0x00D1E5C4: B.LT #0xd1e754             | if (val_3 < 2) goto label_9;            
            if(val_3 < 2)
            {
                goto label_9;
            }
            // 0x00D1E5C8: ADRP x28, #0x35fc000       | X28 = 56606720 (0x35FC000);             
            // 0x00D1E5CC: ADRP x26, #0x3647000       | X26 = 56913920 (0x3647000);             
            // 0x00D1E5D0: LDR x28, [x28, #0x200]     | X28 = 1152921504616644608;              
            // 0x00D1E5D4: LDR x26, [x26, #0x320]     | X26 = 1152921513478963808;              
            // 0x00D1E5D8: ORR w23, wzr, #1           | W23 = 1(0x1);                           
            UnityEngine.Vector3[] val_11 = 1;
            label_22:
            // 0x00D1E5DC: LDR x0, [x28]              | X0 = typeof(System.Collections.Generic.List<T>);
            System.Collections.Generic.List<Turn> val_4 = null;
            // 0x00D1E5E0: BL #0x27bc0c8              | X0 = System.Collections.Generic.List<T>::Add(this, T*, RuntimeMethod)( ?? typeof(System.Collections.Generic.List<T>), ????);
            // 0x00D1E5E4: LDR x1, [x26]              | X1 = public System.Void System.Collections.Generic.List<Turn>::.ctor();
            // 0x00D1E5E8: MOV x24, x0                | X24 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E5EC: BL #0x25a600c              | .ctor();                                
            val_4 = new System.Collections.Generic.List<Turn>();
            // 0x00D1E5F0: LDR x0, [x27]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
            // 0x00D1E5F4: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
            // 0x00D1E5F8: TBZ w8, #0, #0xd1e608      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00D1E5FC: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
            // 0x00D1E600: CBNZ w8, #0xd1e608         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00D1E604: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
            label_11:
            // 0x00D1E608: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00D1E60C: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x00D1E610: BL #0xd1e7d0               | AdvancedSmooth.TurnConstructor.Setup(i:  241692672, vectorPath:  1);
            AdvancedSmooth.TurnConstructor.Setup(i:  241692672, vectorPath:  val_11);
            // 0x00D1E614: LDR x25, [x22, #0x28]      | X25 = this.turnConstruct1; //P2         
            // 0x00D1E618: CBNZ x25, #0xd1e620        | if (this.turnConstruct1 != null) goto label_12;
            if(this.turnConstruct1 != null)
            {
                goto label_12;
            }
            // 0x00D1E61C: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
            label_12:
            // 0x00D1E620: LDR x8, [x25]              | X8 = typeof(MaxTurn);                   
            // 0x00D1E624: MOV x0, x25                | X0 = this.turnConstruct1;//m1           
            // 0x00D1E628: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00D1E62C: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x00D1E630: LDP x9, x3, [x8, #0x150]   | X9 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_150; X3 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_158; //  | 
            // 0x00D1E634: BLR x9                     | X0 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_150();
            // 0x00D1E638: LDR x25, [x22, #0x30]      | X25 = this.turnConstruct2; //P2         
            // 0x00D1E63C: CBNZ x25, #0xd1e644        | if (this.turnConstruct2 != null) goto label_13;
            if(this.turnConstruct2 != null)
            {
                goto label_13;
            }
            // 0x00D1E640: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.turnConstruct1, ????);
            label_13:
            // 0x00D1E644: LDR x8, [x25]              | X8 = typeof(ConstantTurn);              
            // 0x00D1E648: MOV x0, x25                | X0 = this.turnConstruct2;//m1           
            // 0x00D1E64C: MOV w1, w23                | W1 = 1 (0x1);//ML01                     
            // 0x00D1E650: MOV x2, x21                | X2 = val_1;//m1                         
            // 0x00D1E654: LDP x9, x3, [x8, #0x150]   | X9 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_150; X3 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_158; //  | 
            // 0x00D1E658: BLR x9                     | X0 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_150();
            // 0x00D1E65C: BL #0xd1eb04               | AdvancedSmooth.TurnConstructor.PostPrepare();
            AdvancedSmooth.TurnConstructor.PostPrepare();
            // 0x00D1E660: LDR x25, [x22, #0x28]      | X25 = this.turnConstruct1; //P2         
            // 0x00D1E664: CBNZ x25, #0xd1e66c        | if (this.turnConstruct1 != null) goto label_14;
            if(this.turnConstruct1 != null)
            {
                goto label_14;
            }
            // 0x00D1E668: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.turnConstruct2, ????);
            label_14:
            // 0x00D1E66C: LDR x8, [x25]              | X8 = typeof(MaxTurn);                   
            // 0x00D1E670: CMP w23, #1                | STATE = COMPARE(0x1, 0x1)               
            // 0x00D1E674: B.NE #0xd1e6a0             | if (1 != 0x1) goto label_15;            
            if(val_11 != 1)
            {
                goto label_15;
            }
            // 0x00D1E678: LDP x9, x2, [x8, #0x170]   | X9 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_170; X2 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_178; //  | 
            // 0x00D1E67C: MOV x0, x25                | X0 = this.turnConstruct1;//m1           
            // 0x00D1E680: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E684: BLR x9                     | X0 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_170();
            // 0x00D1E688: LDR x25, [x22, #0x30]      | X25 = this.turnConstruct2; //P2         
            val_8 = this.turnConstruct2;
            // 0x00D1E68C: CBNZ x25, #0xd1e694        | if (this.turnConstruct2 != null) goto label_16;
            if(val_8 != null)
            {
                goto label_16;
            }
            // 0x00D1E690: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.turnConstruct1, ????);
            label_16:
            // 0x00D1E694: LDR x8, [x25]              | X8 = typeof(ConstantTurn);              
            // 0x00D1E698: LDP x9, x2, [x8, #0x170]   | X9 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_170; X2 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_178; //  | 
            // 0x00D1E69C: B #0xd1e6c4                |  goto label_17;                         
            goto label_17;
            label_15:
            // 0x00D1E6A0: LDP x9, x2, [x8, #0x190]   | X9 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_190; X2 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_198; //  | 
            // 0x00D1E6A4: MOV x0, x25                | X0 = this.turnConstruct1;//m1           
            // 0x00D1E6A8: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E6AC: BLR x9                     | X0 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_190();
            // 0x00D1E6B0: LDR x25, [x22, #0x30]      | X25 = this.turnConstruct2; //P2         
            val_8 = this.turnConstruct2;
            // 0x00D1E6B4: CBNZ x25, #0xd1e6bc        | if (this.turnConstruct2 != null) goto label_18;
            if(val_8 != null)
            {
                goto label_18;
            }
            // 0x00D1E6B8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.turnConstruct1, ????);
            label_18:
            // 0x00D1E6BC: LDR x8, [x25]              | X8 = typeof(ConstantTurn);              
            // 0x00D1E6C0: LDP x9, x2, [x8, #0x190]   | X9 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_190; X2 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_198; //  | 
            label_17:
            // 0x00D1E6C4: MOV x0, x25                | X0 = this.turnConstruct2;//m1           
            // 0x00D1E6C8: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E6CC: BLR x9                     | X0 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_190();
            // 0x00D1E6D0: MOV x0, x22                | X0 = 1152921513479017504 (0x1000000210D29420);//ML01
            // 0x00D1E6D4: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E6D8: MOV x2, x20                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E6DC: BL #0xd1eb6c               | this.EvaluatePaths(turnList:  val_4, output:  val_2);
            this.EvaluatePaths(turnList:  val_4, output:  val_2);
            // 0x00D1E6E0: LDR w8, [x21, #0x18]       | W8 = val_1.Length; //P2                 
            int val_10 = val_1.Length;
            // 0x00D1E6E4: SUB w8, w8, #2             | W8 = (val_1.Length - 2);                
            val_10 = val_10 - 2;
            // 0x00D1E6E8: CMP w23, w8                | STATE = COMPARE(0x1, (val_1.Length - 2))
            // 0x00D1E6EC: B.NE #0xd1e730             | if (1 != val_1.Length) goto label_19;   
            if(val_11 != val_10)
            {
                goto label_19;
            }
            // 0x00D1E6F0: LDR x25, [x22, #0x28]      | X25 = this.turnConstruct1; //P2         
            // 0x00D1E6F4: CBNZ x25, #0xd1e6fc        | if (this.turnConstruct1 != null) goto label_20;
            if(this.turnConstruct1 != null)
            {
                goto label_20;
            }
            // 0x00D1E6F8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            label_20:
            // 0x00D1E6FC: LDR x8, [x25]              | X8 = typeof(MaxTurn);                   
            // 0x00D1E700: MOV x0, x25                | X0 = this.turnConstruct1;//m1           
            // 0x00D1E704: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E708: LDP x9, x2, [x8, #0x180]   | X9 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_180; X2 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_188; //  | 
            // 0x00D1E70C: BLR x9                     | X0 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_180();
            // 0x00D1E710: LDR x25, [x22, #0x30]      | X25 = this.turnConstruct2; //P2         
            val_8 = this.turnConstruct2;
            // 0x00D1E714: CBNZ x25, #0xd1e71c        | if (this.turnConstruct2 != null) goto label_21;
            if(val_8 != null)
            {
                goto label_21;
            }
            // 0x00D1E718: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.turnConstruct1, ????);
            label_21:
            // 0x00D1E71C: LDR x8, [x25]              | X8 = typeof(ConstantTurn);              
            // 0x00D1E720: MOV x0, x25                | X0 = this.turnConstruct2;//m1           
            // 0x00D1E724: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E728: LDP x9, x2, [x8, #0x180]   | X9 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_180; X2 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_188; //  | 
            // 0x00D1E72C: BLR x9                     | X0 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_180();
            label_19:
            // 0x00D1E730: MOV x0, x22                | X0 = 1152921513479017504 (0x1000000210D29420);//ML01
            // 0x00D1E734: MOV x1, x24                | X1 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E738: MOV x2, x20                | X2 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E73C: BL #0xd1eb6c               | this.EvaluatePaths(turnList:  val_4, output:  val_2);
            this.EvaluatePaths(turnList:  val_4, output:  val_2);
            // 0x00D1E740: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_9 = val_1.Length;
            // 0x00D1E744: ADD w23, w23, #1           | W23 = (1 + 1);                          
            val_11 = val_11 + 1;
            // 0x00D1E748: SUB w9, w8, #1             | W9 = (val_1.Length - 1);                
            int val_5 = val_9 - 1;
            // 0x00D1E74C: CMP w23, w9                | STATE = COMPARE((1 + 1), (val_1.Length - 1))
            // 0x00D1E750: B.LT #0xd1e5dc             | if (1 < val_5) goto label_22;           
            if(val_11 < val_5)
            {
                goto label_22;
            }
            label_9:
            // 0x00D1E754: CBNZ x20, #0xd1e760        | if ( != 0) goto label_23;               
            if(null != 0)
            {
                goto label_23;
            }
            // 0x00D1E758: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this, ????);       
            // 0x00D1E75C: LDR x8, [x21, #0x18]       | X8 = val_1.Length; //P2                 
            val_9 = val_1.Length;
            label_23:
            // 0x00D1E760: ADRP x23, #0x361b000       | X23 = 56733696 (0x361B000);             
            // 0x00D1E764: LDR x23, [x23, #0x7b0]     | X23 = 1152921510909120752;              
            // 0x00D1E768: ORR x9, xzr, #0xffffffff00000000 | X9 = -4294967296(0xFFFFFFFF00000000);   
            var val_12 = -4294967296;
            // 0x00D1E76C: ADD x9, x9, x8, lsl #32    | X9 = (-4294967296 + (val_1.Length) << 32);
            val_12 = val_12 + ((val_1.Length) << 32);
            // 0x00D1E770: ASR x22, x9, #0x20         | X22 = ((-4294967296 + (val_1.Length) << 32) >> 32);
            var val_6 = val_12 >> 32;
            // 0x00D1E774: CMP w22, w8                | STATE = COMPARE(((-4294967296 + (val_1.Length) << 32) >> 32), val_1.Length)
            // 0x00D1E778: B.LO #0xd1e788             | if (val_6 < val_9) goto label_24;       
            if(val_6 < val_9)
            {
                goto label_24;
            }
            // 0x00D1E77C: BL #0x27af0c4              | X0 = sub_27AF0C4( ?? this, ????);       
            // 0x00D1E780: MOV x1, xzr                | X1 = 0 (0x0);//ML01                     
            // 0x00D1E784: BL #0x27ae3bc              | X0 = sub_27AE3BC( ?? this, ????);       
            label_24:
            // 0x00D1E788: ORR w8, wzr, #0xc          | W8 = 12(0xC);                           
            var val_13 = 12;
            // 0x00D1E78C: MADD x8, x22, x8, x21      | X8 = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1;
            val_13 = val_1 + (val_6 * val_13);
            // 0x00D1E790: LDP s0, s1, [x8, #0x20]    | S0 = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 32; S1 = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 32 + 4; //  | 
            // 0x00D1E794: LDR s2, [x8, #0x28]        | S2 = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 40;
            // 0x00D1E798: LDR x1, [x23]              | X1 = public System.Void System.Collections.Generic.List<UnityEngine.Vector3>::Add(UnityEngine.Vector3 item);
            // 0x00D1E79C: MOV x0, x20                | X0 = 1152921504616644608 (0x1000000000958000);//ML01
            // 0x00D1E7A0: BL #0x263fe28              | Add(item:  new UnityEngine.Vector3() {x = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 32, y = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 32 + 4, z = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 40});
            Add(item:  new UnityEngine.Vector3() {x = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 32, y = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 32 + 4, z = (((-4294967296 + (val_1.Length) << 32) >> 32) * 12) + val_1 + 40});
            // 0x00D1E7A4: CBNZ x19, #0xd1e7ac        | if (p != null) goto label_25;           
            if(p != null)
            {
                goto label_25;
            }
            // 0x00D1E7A8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(System.Collections.Generic.List<T>), ????);
            label_25:
            // 0x00D1E7AC: STR x20, [x19, #0x68]      | p.vectorPath = typeof(System.Collections.Generic.List<T>);  //  dest_result_addr=0
            p.vectorPath = val_2;
            label_4:
            // 0x00D1E7B0: SUB sp, x29, #0x50         | SP = (1152921513479005488 - 80) = 1152921513479005408 (0x1000000210D264E0);
            // 0x00D1E7B4: LDP x29, x30, [sp, #0x50]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1E7B8: LDP x20, x19, [sp, #0x40]  | X20 = ; X19 = ;                          //  | 
            // 0x00D1E7BC: LDP x22, x21, [sp, #0x30]  | X22 = ; X21 = ;                          //  | 
            // 0x00D1E7C0: LDP x24, x23, [sp, #0x20]  | X24 = ; X23 = ;                          //  | 
            // 0x00D1E7C4: LDP x26, x25, [sp, #0x10]  | X26 = ; X25 = ;                          //  | 
            // 0x00D1E7C8: LDP x28, x27, [sp], #0x60  | X28 = ; X27 = ;                          //  | 
            // 0x00D1E7CC: RET                        |  return;                                
            return;
        
        }
        //
        // Offset in libil2cpp.so: 0x00D1EB6C (13757292), len: 492  VirtAddr: 0x00D1EB6C RVA: 0x00D1EB6C token: 100683403 methodIndex: 49706 delegateWrapperIndex: 0 methodInvoker: 0
        private void EvaluatePaths(System.Collections.Generic.List<Pathfinding.AdvancedSmooth.Turn> turnList, System.Collections.Generic.List<UnityEngine.Vector3> output)
        {
            //
            // Disasemble & Code
            //  | 
            var val_3;
            //  | 
            var val_4;
            //  | 
            var val_5;
            //  | 
            var val_6;
            //  | 
            var val_7;
            //  | 
            var val_8;
            //  | 
            var val_9;
            //  | 
            var val_10;
            //  | 
            var val_11;
            //  | 
            var val_12;
            //  | 
            var val_13;
            //  | 
            var val_14;
            //  | 
            var val_15;
            //  | 
            var val_16;
            //  | 
            var val_17;
            // 0x00D1EB6C: STP x26, x25, [sp, #-0x50]! | stack[1152921513479215728] = ???;  stack[1152921513479215736] = ???;  //  dest_result_addr=1152921513479215728 |  dest_result_addr=1152921513479215736
            // 0x00D1EB70: STP x24, x23, [sp, #0x10]  | stack[1152921513479215744] = ???;  stack[1152921513479215752] = ???;  //  dest_result_addr=1152921513479215744 |  dest_result_addr=1152921513479215752
            // 0x00D1EB74: STP x22, x21, [sp, #0x20]  | stack[1152921513479215760] = ???;  stack[1152921513479215768] = ???;  //  dest_result_addr=1152921513479215760 |  dest_result_addr=1152921513479215768
            // 0x00D1EB78: STP x20, x19, [sp, #0x30]  | stack[1152921513479215776] = ???;  stack[1152921513479215784] = ???;  //  dest_result_addr=1152921513479215776 |  dest_result_addr=1152921513479215784
            // 0x00D1EB7C: STP x29, x30, [sp, #0x40]  | stack[1152921513479215792] = ???;  stack[1152921513479215800] = ???;  //  dest_result_addr=1152921513479215792 |  dest_result_addr=1152921513479215800
            // 0x00D1EB80: ADD x29, sp, #0x40         | X29 = (1152921513479215728 + 64) = 1152921513479215792 (0x1000000210D59AB0);
            // 0x00D1EB84: ADRP x22, #0x3734000       | X22 = 57884672 (0x3734000);             
            // 0x00D1EB88: LDRB w8, [x22, #0x2df]     | W8 = (bool)static_value_037342DF;       
            // 0x00D1EB8C: MOV x21, x2                | X21 = output;//m1                       
            val_13 = output;
            // 0x00D1EB90: MOV x20, x1                | X20 = turnList;//m1                     
            // 0x00D1EB94: MOV x19, x0                | X19 = 1152921513479227808 (0x1000000210D5C9A0);//ML01
            val_14 = this;
            // 0x00D1EB98: TBNZ w8, #0, #0xd1ebb4     | if (static_value_037342DF == true) goto label_0;
            // 0x00D1EB9C: ADRP x8, #0x3620000        | X8 = 56754176 (0x3620000);              
            // 0x00D1EBA0: LDR x8, [x8, #0xc90]       | X8 = 0x2B8AA64;                         
            // 0x00D1EBA4: LDR w0, [x8]               | W0 = 0x157;                             
            // 0x00D1EBA8: BL #0x2782188              | X0 = sub_2782188( ?? 0x157, ????);      
            // 0x00D1EBAC: ORR w8, wzr, #1            | W8 = 1(0x1);                            
            // 0x00D1EBB0: STRB w8, [x22, #0x2df]     | static_value_037342DF = true;            //  dest_result_addr=57885407
            label_0:
            // 0x00D1EBB4: CBNZ x20, #0xd1ebbc        | if (turnList != null) goto label_1;     
            if(turnList != null)
            {
                goto label_1;
            }
            // 0x00D1EBB8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? 0x157, ????);      
            label_1:
            // 0x00D1EBBC: ADRP x8, #0x35e2000        | X8 = 56500224 (0x35E2000);              
            // 0x00D1EBC0: LDR x8, [x8, #0xda8]       | X8 = 1152921513479191520;               
            // 0x00D1EBC4: MOV x0, x20                | X0 = turnList;//m1                      
            // 0x00D1EBC8: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Turn>::Sort();
            // 0x00D1EBCC: BL #0x25a9f40              | turnList.Sort();                        
            turnList.Sort();
            // 0x00D1EBD0: ADRP x25, #0x363a000       | X25 = 56860672 (0x363A000);             
            // 0x00D1EBD4: ADRP x26, #0x3670000       | X26 = 57081856 (0x3670000);             
            // 0x00D1EBD8: LDR x25, [x25, #0x248]     | X25 = 1152921513479192544;              
            val_15 = 1152921513479192544;
            // 0x00D1EBDC: LDR x26, [x26, #0xc00]     | X26 = 1152921513479193568;              
            // 0x00D1EBE0: MOV w24, wzr               | W24 = 0 (0x0);//ML01                    
            val_16 = 0;
            // 0x00D1EBE4: B #0xd1ebec                |  goto label_2;                          
            goto label_2;
            label_8:
            // 0x00D1EBE8: ADD w24, w24, #1           | W24 = (val_16 + 1) = val_16 (0x00000001);
            val_16 = 1;
            label_2:
            // 0x00D1EBEC: CBNZ x20, #0xd1ebf4        | if (turnList != null) goto label_3;     
            if(turnList != null)
            {
                goto label_3;
            }
            // 0x00D1EBF0: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? turnList, ????);   
            label_3:
            // 0x00D1EBF4: LDR x1, [x25]              | X1 = public System.Int32 System.Collections.Generic.List<Turn>::get_Count();
            // 0x00D1EBF8: MOV x0, x20                | X0 = turnList;//m1                      
            // 0x00D1EBFC: BL #0x25aa418              | X0 = turnList.get_Count();              
            int val_1 = turnList.Count;
            // 0x00D1EC00: CMP w24, w0                | STATE = COMPARE(0x1, val_1)             
            // 0x00D1EC04: B.GE #0xd1ec54             | if (val_16 >= val_1) goto label_4;      
            if(val_16 >= val_1)
            {
                goto label_4;
            }
            // 0x00D1EC08: CBNZ w24, #0xd1ebe8        | if (0x1 != 0) goto label_8;             
            if(val_16 != 0)
            {
                goto label_8;
            }
            // 0x00D1EC0C: CBNZ x20, #0xd1ec14        | if (turnList != null) goto label_6;     
            if(turnList != null)
            {
                goto label_6;
            }
            // 0x00D1EC10: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_6:
            // 0x00D1EC14: LDR x2, [x26]              | X2 = public Turn System.Collections.Generic.List<Turn>::get_Item(int index);
            // 0x00D1EC18: MOV w1, wzr                | W1 = 0 (0x0);//ML01                     
            // 0x00D1EC1C: MOV x0, x20                | X0 = turnList;//m1                      
            // 0x00D1EC20: BL #0x25aa420              | X0 = turnList.get_Item(index:  0);      
            Turn val_2 = turnList.Item[0];
            // 0x00D1EC24: MOV x22, x0                | X22 = val_2.length;//m1                 
            // 0x00D1EC28: MOV x23, x1                | X23 = val_2.constructor;//m1            
            // 0x00D1EC2C: CBNZ x23, #0xd1ec34        | if (val_2.constructor != null) goto label_7;
            if(val_2.constructor != null)
            {
                goto label_7;
            }
            // 0x00D1EC30: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_2.length, ????);
            label_7:
            // 0x00D1EC34: LDR x8, [x23]              |  //  not_find_field!1:0
            // 0x00D1EC38: MOV x0, x23                | X0 = val_2.constructor;//m1             
            // 0x00D1EC3C: MOV x1, x22                | X1 = val_2.length;//m1                  
            // 0x00D1EC40: MOV x2, x23                | X2 = val_2.constructor;//m1             
            // 0x00D1EC44: LDP x9, x4, [x8, #0x1a0]   | X9 = mem[val_2.constructor] + 416; X4 = mem[val_2.constructor] + 416 + 8; //  | 
            // 0x00D1EC48: MOV x3, x21                | X3 = output;//m1                        
            // 0x00D1EC4C: BLR x9                     | X0 = mem[val_2.constructor] + 416();    
            // 0x00D1EC50: B #0xd1ebe8                |  goto label_8;                          
            goto label_8;
            label_4:
            // 0x00D1EC54: CBNZ x20, #0xd1ec5c        | if (turnList != null) goto label_9;     
            if(turnList != null)
            {
                goto label_9;
            }
            // 0x00D1EC58: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? val_1, ????);      
            label_9:
            // 0x00D1EC5C: ADRP x8, #0x35ce000        | X8 = 56418304 (0x35CE000);              
            // 0x00D1EC60: LDR x8, [x8, #0x1c0]       | X8 = 1152921513479194592;               
            // 0x00D1EC64: MOV x0, x20                | X0 = turnList;//m1                      
            // 0x00D1EC68: LDR x1, [x8]               | X1 = public System.Void System.Collections.Generic.List<Turn>::Clear();
            // 0x00D1EC6C: BL #0x25a7928              | turnList.Clear();                       
            turnList.Clear();
            // 0x00D1EC70: ADRP x20, #0x3640000       | X20 = 56885248 (0x3640000);             
            // 0x00D1EC74: LDR x20, [x20, #0x640]     | X20 = 1152921504848539648;              
            // 0x00D1EC78: LDR x0, [x20]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
            val_17 = null;
            // 0x00D1EC7C: LDRB w8, [x0, #0x10a]      | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_10A;
            // 0x00D1EC80: TBZ w8, #0, #0xd1ec94      | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_has_cctor == 0) goto label_11;
            // 0x00D1EC84: LDR w8, [x0, #0xbc]        | W8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished;
            // 0x00D1EC88: CBNZ w8, #0xd1ec94         | if (AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_cctor_finished != 0) goto label_11;
            // 0x00D1EC8C: BL #0x27977a4              | X0 = sub_27977A4( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
            // 0x00D1EC90: LDR x0, [x20]              | X0 = typeof(AdvancedSmooth.TurnConstructor);
            val_17 = null;
            label_11:
            // 0x00D1EC94: LDR x8, [x0, #0xa0]        | X8 = AdvancedSmooth.TurnConstructor.__il2cppRuntimeField_static_fields;
            // 0x00D1EC98: LDRB w8, [x8, #0x58]       | W8 = AdvancedSmooth.TurnConstructor.changedPreviousTangent;
            // 0x00D1EC9C: CBZ w8, #0xd1ecec          | if (AdvancedSmooth.TurnConstructor.changedPreviousTangent == false) goto label_12;
            if(AdvancedSmooth.TurnConstructor.changedPreviousTangent == false)
            {
                goto label_12;
            }
            // 0x00D1ECA0: LDR x20, [x19, #0x28]      | X20 = this.turnConstruct1; //P2         
            // 0x00D1ECA4: CBNZ x20, #0xd1ecac        | if (this.turnConstruct1 != null) goto label_13;
            if(this.turnConstruct1 != null)
            {
                goto label_13;
            }
            // 0x00D1ECA8: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? typeof(AdvancedSmooth.TurnConstructor), ????);
            label_13:
            // 0x00D1ECAC: LDR x8, [x20]              | X8 = typeof(MaxTurn);                   
            // 0x00D1ECB0: MOV x0, x20                | X0 = this.turnConstruct1;//m1           
            // 0x00D1ECB4: LDP x9, x1, [x8, #0x160]   | X9 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_160; X1 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_168; //  | 
            // 0x00D1ECB8: BLR x9                     | X0 = typeof(AdvancedSmooth.MaxTurn).__il2cppRuntimeField_160();
            // 0x00D1ECBC: LDR x19, [x19, #0x30]      | X19 = this.turnConstruct2; //P2         
            // 0x00D1ECC0: CBNZ x19, #0xd1ecc8        | if (this.turnConstruct2 != null) goto label_14;
            if(this.turnConstruct2 != null)
            {
                goto label_14;
            }
            // 0x00D1ECC4: BL #0x27ae4d8              | X0 = sub_27AE4D8( ?? this.turnConstruct1, ????);
            label_14:
            // 0x00D1ECC8: LDR x8, [x19]              | X8 = typeof(ConstantTurn);              
            // 0x00D1ECCC: MOV x0, x19                | X0 = this.turnConstruct2;//m1           
            // 0x00D1ECD0: LDP x2, x1, [x8, #0x160]   | X2 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_160; X1 = typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_168; //  | 
            // 0x00D1ECD4: LDP x29, x30, [sp, #0x40]  | X29 = ; X30 = ;                          //  | 
            // 0x00D1ECD8: LDP x20, x19, [sp, #0x30]  | X20 = ; X19 = ;                          //  | 
            val_14 = ???;
            // 0x00D1ECDC: LDP x22, x21, [sp, #0x20]  | X22 = ; X21 = ;                          //  | 
            val_13 = ???;
            // 0x00D1ECE0: LDP x24, x23, [sp, #0x10]  | X24 = ; X23 = ;                          //  | 
            // 0x00D1ECE4: LDP x26, x25, [sp], #0x50  | X26 = ; X25 = ;                          //  | 
            val_15 = ???;
            // 0x00D1ECE8: BR x2                      | goto typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_160;
            goto typeof(AdvancedSmooth.ConstantTurn).__il2cppRuntimeField_160;
            label_12:
            // 0x00D1ECEC: LDP x29, x30, [sp, #0x40]  | X29 = val_3; X30 = val_4;                //  find_add[1152921513479203808] |  find_add[1152921513479203808]
            // 0x00D1ECF0: LDP x20, x19, [sp, #0x30]  | X20 = val_5; X19 = val_6;                //  find_add[1152921513479203808] |  find_add[1152921513479203808]
            // 0x00D1ECF4: LDP x22, x21, [sp, #0x20]  | X22 = val_7; X21 = val_8;                //  find_add[1152921513479203808] |  find_add[1152921513479203808]
            // 0x00D1ECF8: LDP x24, x23, [sp, #0x10]  | X24 = val_9; X23 = val_10;               //  find_add[1152921513479203808] |  find_add[1152921513479203808]
            // 0x00D1ECFC: LDP x26, x25, [sp], #0x50  | X26 = val_11; X25 = val_12;              //  find_add[1152921513479203808] |  find_add[1152921513479203808]
            // 0x00D1ED00: RET                        |  return;                                
            return;
        
        }
    
    }

}
